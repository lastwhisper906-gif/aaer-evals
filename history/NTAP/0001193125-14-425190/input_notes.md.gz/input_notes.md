# NTAP notes — 0001193125-14-425190


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-14-425190:notes:1]
[same as prior period, unchanged from 0001193125-14-325455:notes:1]

[0001193125-14-425190:notes:2]
Our fiscal year is reported on a 52- or 53-week year ending on
 the last Friday in April. Each quarter of fiscal 2015 and 2014 is a
 13-week period.

[0001193125-14-425190:notes:3]
The accompanying unaudited condensed consolidated financial
 statements have been prepared by the Company, and reflect all
 adjustments, consisting only of normal recurring adjustments, that
 are, in the opinion of management, necessary for the fair
 presentation of our financial position, results of operations,
 comprehensive income and cash flows for the interim periods
 presented. The statements have been prepared in accordance with
 accounting principles generally accepted in the United States of
 America (GAAP) for interim financial information and in accordance
 with the instructions to Form 10-Q and Rule 10-01 of Regulation
 S-X. Accordingly, these statements do not include all information
 and footnotes required by GAAP for annual consolidated financial
 statements, and should be read in conjunction with our audited
 consolidated financial statements as of and for the fiscal year
 ended April 25, 2014 contained in our Annual Report on Form
 10-K filed with the Securities and Exchange Commission on
 June 17, 2014. The results of operations for the three and six
 months ended October 24, 2014 are not necessarily indicative
 of the operating results to be expected for the full fiscal year or
 future operating periods.

[0001193125-14-425190:notes:4]
The preparation of the condensed consolidated financial
 statements in conformity with GAAP requires management to make
 estimates and assumptions that affect the reported amounts of
 assets and liabilities and disclosure of contingent assets and
 liabilities at the date of the financial statements and the
 reported amounts of revenues and expenses during the reporting
 periods. Such estimates include, but are not limited to, revenue
 recognition, reserves and allowances; inventory valuation and
 purchase order accruals; valuation of goodwill and intangibles;
 restructuring reserves; product warranties; employee benefit
 accruals; stock-based compensation; loss contingencies; investment
 impairments; income taxes and fair value measurements. Actual
 results could differ materially from those estimates.

[0001193125-14-425190:notes:5]
There have been no significant changes in our significant
 accounting policies as of and for the six months ended
 October 24, 2014, as compared to the significant accounting
 policies described in our Annual Report on Form 10-K for the fiscal
 year ended April 25, 2014.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-425190:notes:6]
14.  Commitments and Contingencies

[0001193125-14-425190:notes:7]
Operating Lease Commitments

[0001193125-14-425190:notes:8]
We lease various equipment, vehicles and office space in the
 U.S. and internationally. As of October 24, 2014, future
 annual minimum lease payments under non-cancelable operating leases
 with an initial term in excess of one year totaled $206.5
 million.

[0001193125-14-425190:notes:9]
Purchase Orders and Other Commitments

[0001193125-14-425190:notes:10]
In the ordinary course of business we make commitments to
 third-party contract manufacturers, to manage manufacturer lead
 times and meet product forecasts, and to other parties, to purchase
 various key components used in the manufacture of our products. We
 establish accruals for estimated losses on purchased components to
 the extent we believe it is probable that such components will not
 be utilized in future operations. To the extent that product
 forecasts are not achieved, our commitments and associated accruals
 may change. As of October 24, 2014, we had $253.2 million in
 non-cancelable purchase commitments with our contract
 manufacturers. In addition, we recorded a liability for firm,
 non-cancelable and unconditional purchase commitments with contract
 manufacturers for quantities in excess of our future demand
 forecasts through a charge to cost of product revenues. As of
 October 24, 2014 and April 25, 2014, such liability
 amounted to $8.7 million and $11.5 million, respectively, and is
 included in other current liabilities in our condensed consolidated
 balance sheets.

[0001193125-14-425190:notes:11]
In addition to commitments with contract manufacturers and
 component suppliers, we have open purchase orders and contractual
 obligations associated with our ordinary course of business for
 which we have not received goods or services. As of
 October 24, 2014, we had $73.3 million in capital purchase
 commitments and $197.0 million in other purchase
 commitments.

[0001193125-14-425190:notes:12]
Product Warranties

[0001193125-14-425190:notes:13]
We generally provide customers a warranty on software of ninety
 days and a warranty on hardware of three years. The following
 tables summarize the activity related to product warranty
 liabilities and their balances as reported in our condensed
 consolidated balance sheets (in millions):

[0001193125-14-425190:notes:14]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Balance at beginning of period |  | $ | 104.1 |  |  | $ | 119.8 |  |  | $ | 110.0 |  |  | $ | 117.2 |  |
| Expense accrued during the period |  |  | 8.3 |  |  |  | 14.3 |  |  |  | 18.8 |  |  |  | 38.3 |  |
| Warranty costs incurred |  |  | (15.8 | ) |  |  | (18.1 | ) |  |  | (32.2 | ) |  |  | (39.5 | ) |
| Balance at end of period |  | $ | 96.6 |  |  | $ | 116.0 |  |  | $ | 96.6 |  |  | $ | 116.0 |  |

[0001193125-14-425190:notes:15]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Other current liabilities |  | $ | 64.2 |  |  | $ | 73.0 |  |
| Other long-term liabilities |  |  | 32.4 |  |  |  | 37.0 |  |
| Total |  | $ | 96.6 |  |  | $ | 110.0 |  |

[0001193125-14-425190:notes:16]
Financing Guarantees

[0001193125-14-425190:notes:17]
Some of our customers have entered into recourse and
 non-recourse financing leasing arrangements using third-party
 financing companies, and in some situations, we enter into customer
 financing arrangements for our products and services that are
 contemporaneously sold on a recourse or non-recourse basis to
 third-party financing companies. Under the terms of recourse
 leases, which are generally three years or less, we remain liable
 for the aggregate unpaid remaining lease payments to the
 third-party leasing companies in the event of end-user customer
 default. These arrangements are generally collateralized by a
 security interest in the underlying assets. Under the terms of the
 non-recourse leases, we do not have any continuing obligations or
 liabilities to the third-party financing companies. Where we
 provide a guarantee for recourse leases, we defer revenues subject
 to the industry-specific software revenue recognition guidance, and
 recognize revenues for non-software deliverables in accordance with
 our multiple deliverable revenue arrangement policy. In connection
 with certain recourse financing arrangements, we receive advance
 payments associated with undelivered elements that are subject to
 customer refund rights. We defer revenue associated with these
 advance payments until the related refund rights expire and we
 perform the services.

[0001193125-14-425190:notes:18]
The following schedule of financing guarantees represents the
 total maximum potential future payments under financing
 arrangements with third parties and the related deferred revenue
 (in millions):

[0001193125-14-425190:notes:19]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Maximum guaranteed payment contingencies |  | $ | 214.1 |  |  | $ | 205.8 |  |
| Deferred revenue associated with financing guarantees |  |  | (197.4 | ) |  |  | (193.1 | ) |
| Net amount |  | $ | 16.7 |  |  | $ | 12.7 |  |

[0001193125-14-425190:notes:20]
To date, we have not experienced material losses under our
 lease financing programs or other financing
 arrangements.

[0001193125-14-425190:notes:21]
Legal Contingencies

[0001193125-14-425190:notes:22]
When a loss is considered probable and reasonably estimable, we
 record a liability in the amount of our best estimate for the
 ultimate loss. However, the likelihood of a loss with respect to a
 particular contingency is often difficult to predict, and
 determining a meaningful estimate of the loss or a range of loss
 may not be practicable based on the information available and the
 potential effect of future events and decisions by third parties
 that will determine the ultimate resolution of the
 contingency.

[0001193125-14-425190:notes:23]
We are subject to various legal proceedings and claims that
 arise in the normal course of business. No accrual has been
 recorded as of October 24, 2014 related to such matters as
 they are not probable and/or reasonably estimable.


## us-gaap:DebtDisclosureTextBlock

[0001193125-14-425190:notes:24]
7.  Financing
 Arrangements

[0001193125-14-425190:notes:25]
Long-term Debt

[0001193125-14-425190:notes:26]
The following table summarizes the carrying value of our
 long-term debt (in millions):

[0001193125-14-425190:notes:27]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.375% Senior Notes due 2021 |  |  | 500.0 |  |  |  | 3.54 | % |  |  | 0.0 |  |  |  | N/A |  |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500.0 |  |  |  |  |  |  |  | 1,000.0 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.6 | ) |  |  |  |  |  |  | (4.5 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,494.4 |  |  |  |  |  |  | $ | 995.5 |  |  |  |  |  |

[0001193125-14-425190:notes:28]
N/A - Not
 Applicable

[0001193125-14-425190:notes:29]
Senior Notes

[0001193125-14-425190:notes:30]
On June 5, 2014 we issued $500.0 million aggregate par
 value of 3.375% Senior Notes, with a maturity date of June 15,
 2021, and received proceeds of approximately $494.7 million, net of
 discount and issuance costs, which will be used for general
 corporate purposes, including possible stock repurchases,
 dividends, capital expenditures, working capital and potential
 acquisitions and strategic transactions. Our 2.00% Senior Notes and
 3.25% Senior Notes, with a par value of $750.0 million and $250.0
 million, respectively, were issued in December 2012. We
 collectively refer to such long-term debt as our Senior Notes.
 Interest on our Senior Notes is paid semi-annually on June 15
 and December 15. Our Senior Notes, which are unsecured,
 unsubordinated obligations, rank equally in right of payment with
 any future senior unsecured indebtedness.

[0001193125-14-425190:notes:31]
We may redeem the Senior Notes in whole or in part at any time
 at our option at specified redemption prices. In addition, upon the
 occurrence of certain change of control triggering events, we may
 be required to repurchase the Senior Notes at 101% of their
 aggregate principal amount, plus accrued and unpaid interest to the
 date of repurchase. The Senior Notes also include covenants that
 limit our ability to incur debt secured by liens on assets or on
 shares of stock or indebtedness of our subsidiaries; to engage in
 sale and lease-back transactions; and to consolidate, merge or sell
 all or substantially all of our assets. As of October 24,
 2014, we were in compliance with all covenants associated with the
 Senior Notes.

[0001193125-14-425190:notes:32]
As of October 24, 2014, our aggregate future principal
 debt maturities are as follows (in millions):

[0001193125-14-425190:notes:33]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750.0 |  |
| Thereafter |  |  | 750.0 |  |
| Total |  | $ | 1,500.0 |  |

[0001193125-14-425190:notes:34]
Credit Facility

[0001193125-14-425190:notes:35]
In December 2012, we entered into a credit agreement with a
 syndicated group of lenders that is scheduled to expire on
 December 21, 2017 and provides for an unsecured $250.0 million
 revolving credit facility that is comprised of revolving loans,
 Eurocurrency loans and/or swingline loans. The credit facility
 includes a $100.0 million foreign currency sub-facility, a $50.0
 million letter of credit sub-facility and a $10.0 million swingline
 sub-facility available on same-day notice. Available borrowings
 under the credit facility are reduced by the amount of any
 outstanding borrowings on the sub-facilities. We may also, subject
 to certain requirements, request an increase in the facility up
 to an additional $100.0 million and request two additional
 one-year extensions, subject to certain conditions. The proceeds
 from the facility may be used by us for general corporate
 purposes.

[0001193125-14-425190:notes:36]
Borrowings under the facility, except for swingline loans,
 accrue interest in arrears at an alternate base rate as defined in
 the credit agreement or, at our option, an adjusted London
 Interbank Offered Rate (LIBOR) plus in each case, a spread (based
 on our public debt ratings and the type of loan) ranging from 0.2%
 to 1.2%. Swingline borrowings accrue interest at an alternate base
 rate. In addition, we are required to pay fees to maintain the
 credit facility, whether or not we have outstanding borrowings. The
 facility contains financial covenants requiring us to maintain a
 maximum leverage ratio of not more than 3.0:1.0 and a minimum
 interest coverage ratio of not less than 3.5:1.0. The facility
 contains customary affirmative and negative covenants, including
 covenants that limit our ability to incur debt secured by liens on
 assets or indebtedness of our subsidiaries and to consolidate,
 merge or sell all or substantially all of our assets. As of
 October 24, 2014, no borrowings were outstanding under the
 facility and we were in compliance with all covenants associated
 with the facility.

[0001193125-14-425190:notes:37]
Other Long-Term Financing Arrangements

[0001193125-14-425190:notes:38]
The following presents the amounts due under other long-term
 financing arrangements (in millions):

[0001193125-14-425190:notes:39]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Other long-term financing arrangements |  | $ | 21.8 |  |  | $ | 13.1 |  |
| Less: current portion |  |  | (9.5 | ) |  |  | (6.6 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 12.3 |  |  | $ | 6.5 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-14-425190:notes:40]
12.  Net
 Income per Share

[0001193125-14-425190:notes:41]
The following is a calculation of basic and diluted net income
 per share (in millions, except per share amounts):

[0001193125-14-425190:notes:42]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 159.8 |  |  | $ | 166.8 |  |  | $ | 248.2 |  |  | $ | 248.4 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 318.1 |  |  |  | 340.7 |  |  |  | 320.8 |  |  |  | 345.8 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 5.4 |  |  |  | 7.5 |  |  |  | 5.5 |  |  |  | 7.2 |  |
| Dilutive impact of assumed conversion of Convertible Notes |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.1 |  |
| Dilutive impact of warrants |  |  | 0.0 |  |  |  | 0.9 |  |  |  | 0.0 |  |  |  | 0.4 |  |
| Shares used in diluted computation |  |  | 323.5 |  |  |  | 349.1 |  |  |  | 326.3 |  |  |  | 354.5 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.50 |  |  | $ | 0.49 |  |  | $ | 0.77 |  |  | $ | 0.72 |  |
| Diluted |  | $ | 0.49 |  |  | $ | 0.48 |  |  | $ | 0.76 |  |  | $ | 0.70 |  |

[0001193125-14-425190:notes:43]
[same as prior period, unchanged from 0001193125-14-325455:notes:42]

[0001193125-14-425190:notes:44]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Employee equity award plans |  |  | 7.3 |  |  |  | 7.2 |  |  |  | 7.9 |  |  |  | 6.9 |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001193125-14-425190:notes:45]
[same as prior period, unchanged from 0001193125-14-325455:notes:44]

[0001193125-14-425190:notes:46]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| United States |  | $ | 987.0 |  |  | $ | 1,021.4 |  |
| International |  |  | 94.7 |  |  |  | 87.4 |  |
| Total |  | $ | 1,081.7 |  |  | $ | 1,108.8 |  |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-14-425190:notes:47]
[same as prior period, unchanged from 0001193125-14-325455:notes:46]

[0001193125-14-425190:notes:48]
|  |  | October 24, 2014 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 1,863.3 |  |  | $ | 0.0 |  |  | $ | 1,863.3 |  |  | $ | 0.0 |  |
| U.S. Treasury and government debt securities |  |  | 157.6 |  |  |  | 97.3 |  |  |  | 60.3 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 222.6 |  |  |  | 0.0 |  |  |  | 222.6 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 345.6 |  |  |  | 0.0 |  |  |  | 345.6 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 23.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 23.0 |  |
| Equity funds |  |  | 33.0 |  |  |  | 33.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign currency contracts |  |  | 4.1 |  |  |  | 0.0 |  |  |  | 4.1 |  |  |  | 0.0 |  |
| Total |  | $ | 2,649.2 |  |  | $ | 130.3 |  |  | $ | 2,495.9 |  |  | $ | 23.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | (3.2 | ) |  | $ | 0.0 |  |  | $ | (3.2 | ) |  | $ | 0.0 |  |


## us-gaap:ScheduleOfShareBasedCompensationRestrictedStockUnitsAwardActivityTableTextBlock

[0001193125-14-425190:notes:49]
[same as prior period, unchanged from 0001193125-14-325455:notes:48]

[0001193125-14-425190:notes:50]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 25, 2014 |  |  | 13.2 |  |  | $ | 38.35 |  |
| Granted |  |  | 5.8 |  |  |  | 35.37 |  |
| Vested |  |  | (3.6 | ) |  |  | 38.99 |  |
| Forfeited |  |  | (1.1 | ) |  |  | 37.84 |  |
| Outstanding as of October 24, 2014 |  |  | 14.3 |  |  |  | 37.02 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001193125-14-425190:notes:51]
[same as prior period, unchanged from 0001193125-14-325455:notes:53]

[0001193125-14-425190:notes:52]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
|  |  |  |  |  | Gross Unrealized |  |  |  |  |  |  |  |  | Gross Unrealized |  |  |  |  |
|  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |
| Corporate bonds |  | $ | 1,855.4 |  |  | $ | 8.1 |  |  | $ | (0.2 | ) |  | $ | 1,863.3 |  |  | $ | 2,142.3 |  |  | $ | 10.5 |  |  | $ | (0.5 | ) |  | $ | 2,152.3 |  |
| U.S. Treasury and government debt securities |  |  | 157.0 |  |  |  | 0.6 |  |  |  | 0.0 |  |  |  | 157.6 |  |  |  | 263.4 |  |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 263.6 |  |
| Commercial paper |  |  | 222.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 222.6 |  |  |  | 168.4 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 168.4 |  |
| Certificates of deposit |  |  | 345.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 345.6 |  |  |  | 245.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 245.0 |  |
| Auction rate securities |  |  | 23.3 |  |  |  | 0.0 |  |  |  | (0.3 | ) |  |  | 23.0 |  |  |  | 36.9 |  |  |  | 0.0 |  |  |  | (0.9 | ) |  |  | 36.0 |  |
| Equity funds |  |  | 33.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 33.0 |  |  |  | 32.7 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 32.7 |  |
| Total debt and equity securities |  | $ | 2,636.9 |  |  | $ | 8.7 |  |  | $ | (0.5 | ) |  | $ | 2,645.1 |  |  | $ | 2,888.7 |  |  | $ | 10.8 |  |  | $ | (1.5 | ) |  | $ | 2,898.0 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-14-425190:notes:53]
[same as prior period, unchanged from 0001193125-14-325455:notes:55]

[0001193125-14-425190:notes:54]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Purchased components |  | $ | 23.3 |  |  | $ | 17.6 |  |
| Finished goods |  |  | 84.3 |  |  |  | 104.8 |  |
| Inventories |  | $ | 107.6 |  |  | $ | 122.4 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0001193125-14-425190:notes:55]
[same as prior period, unchanged from 0001193125-14-325455:notes:57]

[0001193125-14-425190:notes:56]
|  |  | Six Months Ended October 24, 2014 |  |  | Six Months Ended October 25, 2013 |  |
|  |  | (March 2014 Plan) |  |  | (May 2013 Plan) |  |
| Balance at beginning of period |  | $ | 26.5 |  |  | $ | 0.0 |  |
| Net charges |  |  | 0.0 |  |  |  | 49.5 |  |
| Cash payments |  |  | (25.4 | ) |  |  | (45.4 | ) |
| Balance at end of period |  | $ | 1.1 |  |  | $ | 4.1 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-14-425190:notes:57]
[same as prior period, unchanged from 0001193125-14-325455:notes:59]

[0001193125-14-425190:notes:58]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 25, 2014 |  |  | 14.5 |  |  | $ | 34.10 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2.1 |  |  |  | 36.53 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (2.5 | ) |  |  | 25.55 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (0.4 | ) |  |  | 43.10 |  |  |  |  |  |  |  |  |  |
| Outstanding as of October 24, 2014 |  |  | 13.7 |  |  |  | 35.82 |  |  |  | 3.79 |  |  | $ | 96.3 |  |
| Vested and expected to vest as of October 24, 2014 |  |  | 13.1 |  |  |  | 35.78 |  |  |  | 3.68 |  |  |  | 93.7 |  |
| Exercisable as of October 24, 2014 |  |  | 9.0 |  |  |  | 35.25 |  |  |  | 2.75 |  |  |  | 75.3 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-425190:notes:59]
[same as prior period, unchanged from 0001193125-14-325455:notes:61]

[0001193125-14-425190:notes:60]
We operate in one industry segment: the design, manufacturing,
 marketing, and technical support of high-performance data
 management and networked storage solutions. We conduct business
 globally, and our sales and support activities are managed on a
 geographic basis. Our management reviews financial information
 presented on a consolidated basis, accompanied by disaggregated
 information it receives from its internal management system about
 revenues by geographic region, based on the location from which the
 customer relationship is managed, for purposes of allocating
 resources and evaluating financial performance. We do not allocate
 costs of revenues, research and development, sales and marketing,
 or general and administrative expenses to our geographic regions in
 this internal management reporting because management does not
 review operations or operating results, or make planning decisions,
 below the consolidated entity level.

[0001193125-14-425190:notes:61]
[same as prior period, unchanged from 0001193125-14-325455:notes:63]

[0001193125-14-425190:notes:62]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Americas (United States, Canada and Latin America) |  | $ | 906.1 |  |  | $ | 899.2 |  |  | $ | 1,737.3 |  |  | $ | 1,757.7 |  |
| Europe, Middle East and Africa |  |  | 437.6 |  |  |  | 445.0 |  |  |  | 882.5 |  |  |  | 893.0 |  |
| Asia Pacific |  |  | 198.8 |  |  |  | 205.7 |  |  |  | 411.9 |  |  |  | 415.4 |  |
| Net revenues |  | $ | 1,542.5 |  |  | $ | 1,549.9 |  |  | $ | 3,031.7 |  |  | $ | 3,066.1 |  |

[0001193125-14-425190:notes:63]
Americas revenues consist of sales to Americas commercial and
 U.S. public sector markets. Sales to customers inside the United
 States were $816.4 million and $800.7 million during the three
 months ended October 24, 2014 and October 25, 2013,
 respectively, and were $1,562.6 million and $1,573.5 million during
 the six months ended October 24, 2014 and October 25,
 2013, respectively. No single foreign country accounted for 10% or
 more of our net revenues for any period presented.

[0001193125-14-425190:notes:64]
[same as prior period, unchanged from 0001193125-14-325455:notes:66]

[0001193125-14-425190:notes:65]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| United States |  | $ | 850.8 |  |  | $ | 688.5 |  |
| International |  |  | 4,457.8 |  |  |  | 4,360.9 |  |
| Total |  | $ | 5,308.6 |  |  | $ | 5,049.4 |  |

[0001193125-14-425190:notes:66]
[same as prior period, unchanged from 0001193125-14-325455:notes:68]

[0001193125-14-425190:notes:67]
[same as prior period, unchanged from 0001193125-14-325455:notes:69]

[0001193125-14-425190:notes:68]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 23 | % |  |  | 23 | % |  |  | 22 | % |
| Avnet, Inc. |  |  | 17 | % |  |  | 16 | % |  |  | 17 | % |  |  | 16 | % |

[0001193125-14-425190:notes:69]
[same as prior period, unchanged from 0001193125-14-325455:notes:71]

[0001193125-14-425190:notes:70]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Arrow Electronics, Inc. |  |  | 12 | % |  |  | 14 | % |
| Avnet, Inc. |  |  | 15 | % |  |  | 16 | % |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001193125-14-425190:notes:71]
[same as prior period, unchanged from 0001193125-14-325455:notes:73]

[0001193125-14-425190:notes:72]
[same as prior period, unchanged from 0001193125-14-325455:notes:74]

[0001193125-14-425190:notes:73]
[same as prior period, unchanged from 0001193125-14-325455:notes:75]

[0001193125-14-425190:notes:74]
[same as prior period, unchanged from 0001193125-14-325455:notes:76]

[0001193125-14-425190:notes:75]
|  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Intrinsic value of exercises |  | $ | 37.5 |  |  | $ | 60.4 |  |
| Proceeds received from exercises |  | $ | 64.8 |  |  | $ | 113.2 |  |
| Fair value of options vested |  | $ | 18.6 |  |  | $ | 25.4 |  |

[0001193125-14-425190:notes:76]
[same as prior period, unchanged from 0001193125-14-325455:notes:78]

[0001193125-14-425190:notes:77]
[same as prior period, unchanged from 0001193125-14-325455:notes:79]

[0001193125-14-425190:notes:78]
|  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Shares withheld for taxes |  |  | 1.1 |  |  |  | 1.0 |  |
| Fair value of shares withheld |  | $ | 42.5 |  |  | $ | 39.3 |  |

[0001193125-14-425190:notes:79]
[same as prior period, unchanged from 0001193125-14-325455:notes:81]

[0001193125-14-425190:notes:80]
[same as prior period, unchanged from 0001193125-14-325455:notes:82]

[0001193125-14-425190:notes:81]
|  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Shares issued under the ESPP |  |  | 1.9 |  |  |  | 2.0 |  |
| Proceeds from issuance of shares |  | $ | 48.9 |  |  | $ | 49.9 |  |

[0001193125-14-425190:notes:82]
[same as prior period, unchanged from 0001193125-14-325455:notes:84]

[0001193125-14-425190:notes:83]
[same as prior period, unchanged from 0001193125-14-325455:notes:85]

[0001193125-14-425190:notes:84]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Cost of product revenues |  | $ | 1.6 |  |  | $ | 1.4 |  |  | $ | 3.1 |  |  | $ | 2.7 |  |
| Cost of service revenues |  |  | 4.0 |  |  |  | 4.2 |  |  |  | 8.4 |  |  |  | 8.2 |  |
| Sales and marketing |  |  | 30.4 |  |  |  | 31.1 |  |  |  | 57.4 |  |  |  | 61.6 |  |
| Research and development |  |  | 21.2 |  |  |  | 21.6 |  |  |  | 42.7 |  |  |  | 43.0 |  |
| General and administrative |  |  | 10.6 |  |  |  | 9.3 |  |  |  | 18.5 |  |  |  | 18.4 |  |
| Total stock-based compensation expense |  | $ | 67.8 |  |  | $ | 67.6 |  |  | $ | 130.1 |  |  | $ | 133.9 |  |

[0001193125-14-425190:notes:85]
As of October 24, 2014, total unrecognized compensation
 expense related to our equity awards was $456.0 million, which is
 expected to be recognized on a straight-line basis over a
 weighted-average remaining service period of
 2.6 years.

[0001193125-14-425190:notes:86]
[same as prior period, unchanged from 0001193125-14-325455:notes:88]

[0001193125-14-425190:notes:87]
|  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Income tax benefit associated with employee stock transactions |  | $ | 58.2 |  |  | $ | 1.8 |  |

[0001193125-14-425190:notes:88]
[same as prior period, unchanged from 0001193125-14-325455:notes:93]

[0001193125-14-425190:notes:89]
As of October 24, 2014, our Board of Directors has
 authorized the repurchase of up to $7.1 billion of our common
 stock. Under this program, which we may suspend or discontinue at
 any time, we may purchase shares of our outstanding common stock
 through open market and privately negotiated transactions at prices
 deemed appropriate by our management.

[0001193125-14-425190:notes:90]
The following table summarizes activity related to this program
 for the six months ended October 24, 2014 (in millions, except
 per share information):

[0001193125-14-425190:notes:91]
| Number of shares repurchased |  |  | 18.4 |  |
| Average price per share |  | $ | 39.10 |  |
| Aggregate purchase price |  | $ | 718.9 |  |
| Remaining authorization at end of period |  | $ | 405.9 |  |

[0001193125-14-425190:notes:92]
The aggregate purchase price of our stock repurchases for the
 six months ended October 24, 2014 consisted of $718.9 million
 of open market purchases, of which $523.0 million and $195.9
 million was allocated to additional paid-in capital and retained
 earnings, respectively.

[0001193125-14-425190:notes:93]
[same as prior period, unchanged from 0001193125-14-325455:notes:98]

[0001193125-14-425190:notes:94]
[same as prior period, unchanged from 0001193125-14-325455:notes:99]

[0001193125-14-425190:notes:95]
|  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Dividends per share declared and paid |  | $ | 0.330 |  |  | $ | 0.300 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 52.1 |  |  | $ | 0.0 |  |
| Dividend payments allocated to retained earnings |  | $ | 53.4 |  |  | $ | 102.7 |  |

[0001193125-14-425190:notes:96]
On November 12, 2014, we declared a cash dividend of
 $0.165 per share of common stock, payable on January 22, 2015
 to holders of record as of the close of business on January 9,
 2015. The timing and amount of future dividends will depend on
 market conditions, corporate business and financial considerations
 and regulatory requirements. All dividends declared have been
 determined by the Company to be legally authorized under the laws
 of the state in which we are incorporated.

[0001193125-14-425190:notes:97]
[same as prior period, unchanged from 0001193125-14-325455:notes:102]

[0001193125-14-425190:notes:98]
A reconciliation of retained earnings for the six months ended
 October 24, 2014 is as follows (in millions):

[0001193125-14-425190:notes:99]
| Balance as of April 25, 2014 |  | $ | 1.1 |  |
| Net income |  |  | 248.2 |  |
| Repurchases of common stock |  |  | (195.9 | ) |
| Dividends |  |  | (53.4 | ) |
| Balance as of October 24, 2014 |  | $ | 0.0 |  |

[0001193125-14-425190:notes:100]
[same as prior period, unchanged from 0001193125-14-325455:notes:105]

[0001193125-14-425190:notes:101]
Changes in accumulated other comprehensive income (AOCI) by
 component, net of tax, for the six months ended October 24,
 2014 are summarized below (in millions):

[0001193125-14-425190:notes:102]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 25, 2014 |  | $ | 5.5 |  |  | $ | (4.8 | ) |  | $ | 8.9 |  |  | $ | (0.5 | ) |  | $ | 9.1 |  |
| Other comprehensive income (loss) (OCI) before Reclassifications, net of tax |  |  | (10.8 | ) |  |  | 1.1 |  |  |  | (1.1 | ) |  |  | (4.3 | ) |  |  | (15.1 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | 0.0 |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 6.2 |  |  |  | 6.6 |  |
| Net OCI |  |  | (10.8 | ) |  |  | 1.3 |  |  |  | (0.9 | ) |  |  | 1.9 |  |  |  | (8.5 | ) |
| Balance as of October 24, 2014 |  | $ | (5.3 | ) |  | $ | (3.5 | ) |  | $ | 8.0 |  |  | $ | 1.4 |  |  | $ | 0.6 |  |

[0001193125-14-425190:notes:103]
[same as prior period, unchanged from 0001193125-14-325455:notes:108]

[0001193125-14-425190:notes:104]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |  |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |  | October 24, 2014 |  |  | October 25, 2013 |  |  |  |  |
| OCI Components |  | Amounts Reclassified from AOCI |  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |  |
| Recognized losses on defined benefit obligations |  | $ | 0.1 |  |  | $ | 0.0 |  |  | $ | 0.2 |  |  | $ | 0.0 |  |  |  | Operating expenses |  |
| Realized (gains) losses on available-for-sale securities |  |  | 0.0 |  |  |  | (1.0 | ) |  |  | 0.2 |  |  |  | (1.1 | ) |  |  | Other income (expense), net |  |
| Realized losses on cash flow hedges |  |  | 4.5 |  |  |  | 2.4 |  |  |  | 6.2 |  |  |  | 1.4 |  |  |  | Net revenues |  |
| Total reclassifications |  | $ | 4.6 |  |  | $ | 1.4 |  |  | $ | 6.6 |  |  | $ | 0.3 |  |  |  |  |  |


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-14-425190:notes:105]
3.  Statements
 of Cash Flows

[0001193125-14-425190:notes:106]
[same as prior period, unchanged from 0001193125-14-325455:notes:111]

[0001193125-14-425190:notes:107]
|  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 8.8 |  |  | $ | 27.1 |  |
| Acquisition of software through long-term financing |  | $ | 12.3 |  |  | $ | 11.4 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 68.6 |  |  | $ | 26.5 |  |
| Interest paid |  | $ | 11.9 |  |  | $ | 23.2 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001193125-14-425190:notes:108]
The
 table below provides a reconciliation of the beginning and ending
 balance of our Level 3 ARSs measured at fair value on a
 recurring basis using significant unobservable inputs (in
 millions).

[0001193125-14-425190:notes:109]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Balance at beginning of period |  | $ | 26.4 |  |  | $ | 42.2 |  |  | $ | 36.0 |  |  | $ | 42.0 |  |
| Total unrealized gains (losses), net included in other comprehensive income (loss) |  |  | 0.2 |  |  |  | (0.4 | ) |  |  | 0.6 |  |  |  | (0.2 | ) |
| Total realized gains included in earnings |  |  | 0.0 |  |  |  | 0.7 |  |  |  | 0.0 |  |  |  | 0.7 |  |
| Sales |  |  | 0.0 |  |  |  | (3.0 | ) |  |  | (10.0 | ) |  |  | (3.0 | ) |
| Settlements |  |  | (3.6 | ) |  |  | 0.0 |  |  |  | (3.6 | ) |  |  | 0.0 |  |
| Balance at end of period |  | $ | 23.0 |  |  | $ | 39.5 |  |  | $ | 23.0 |  |  | $ | 39.5 |  |


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-14-425190:notes:110]
1.  Description of Business and Significant
 Accounting Policies

[0001193125-14-425190:notes:111]
[same as prior period, unchanged from 0001193125-14-325455:notes:116]


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-14-425190:notes:112]
As of October 24, 2014, future amortization expense
 related to purchased intangible assets is as follows (in
 millions):

[0001193125-14-425190:notes:113]
| Fiscal Year |  | Amount |  |
| Remainder of 2015 |  | $ | 28.9 |  |
| 2016 |  |  | 53.6 |  |
| 2017 |  |  | 6.7 |  |
| 2018 |  |  | 3.3 |  |
| Total |  | $ | 92.5 |  |


## us-gaap:FairValueInputsAssetsQuantitativeInformationTableTextBlock

[0001193125-14-425190:notes:114]
Quantitative
 information about our Level 3 fair value measurements is as follows
 (fair value in millions):

[0001193125-14-425190:notes:115]
|  |  | Estimated Fair Value as of October 24, 2014 |  |  | Valuation Techniques |  | Unobservable Inputs |  | Range (Weighted average) |
| ARSs |  | $ | 23.0 |  |  | Discounted cash flow |  | Time-to-economic maturity |  | 0.5 yrs. –9.3 yrs. (3.4 yrs.) |
|  |  |  |  |  |  |  |  | Illiquidity premium |  | 1.2% - 1.6% (1.3%) |
|  |  |  |  |  |  |  |  | Coupon rate |  | 1.2% - 1.8% (1.4%) |
|  |  |  |  |  |  | Market comparable securities |  | Discount rate |  | 1.1% - 2.3% (1.5%) |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-14-425190:notes:116]
[same as prior period, unchanged from 0001193125-14-325455:notes:121]

[0001193125-14-425190:notes:117]
[same as prior period, unchanged from 0001193125-14-325455:notes:122]

[0001193125-14-425190:notes:118]
[same as prior period, unchanged from 0001193125-14-325455:notes:123]

[0001193125-14-425190:notes:119]
[same as prior period, unchanged from 0001193125-14-325455:notes:124]

[0001193125-14-425190:notes:120]
[same as prior period, unchanged from 0001193125-14-325455:notes:125]

[0001193125-14-425190:notes:121]
[same as prior period, unchanged from 0001193125-14-325455:notes:126]

[0001193125-14-425190:notes:122]
[same as prior period, unchanged from 0001193125-14-325455:notes:127]

[0001193125-14-425190:notes:123]
The unrealized losses on our available-for-sale investments
 were caused by market value declines as a result of the economic
 environment, as well as fluctuations in market interest rates.
 Because the declines in market value are attributable to changes in
 market conditions and not credit quality, and because we have
 determined that (i) we do not have the intent to sell any of
 these investments and (ii) it is not more likely than not that
 we will be required to sell any of these investments before
 recovery of the entire amortized cost basis, we have concluded that
 no other-than-temporary impairments were required to be recognized
 on these investments as of October 24, 2014.

[0001193125-14-425190:notes:124]
The following table presents the contractual maturities of our
 debt investments as of October 24, 2014 (in
 millions):

[0001193125-14-425190:notes:125]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,615.2 |  |  | $ | 1,618.1 |  |
| Due in two through five years |  |  | 965.4 |  |  |  | 971.0 |  |
| Due after ten years* |  |  | 23.3 |  |  |  | 23.0 |  |
|  |  | $ | 2,603.9 |  |  | $ | 2,612.1 |  |

[0001193125-14-425190:notes:126]
[same as prior period, unchanged from 0001193125-14-325455:notes:131]

[0001193125-14-425190:notes:127]
[same as prior period, unchanged from 0001193125-14-325455:notes:132]

[0001193125-14-425190:notes:128]
[same as prior period, unchanged from 0001193125-14-325455:notes:133]

[0001193125-14-425190:notes:129]
[same as prior period, unchanged from 0001193125-14-325455:notes:134]

[0001193125-14-425190:notes:130]
|  |  | October 24, 2014 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 224.9 |  |  | $ | 0.0 |  |  | $ | 224.9 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 2,364.2 |  |  |  | 97.3 |  |  |  | 2,266.9 |  |  |  | 0.0 |  |
| Other current assets |  |  | 9.7 |  |  |  | 5.6 |  |  |  | 4.1 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 50.4 |  |  |  | 27.4 |  |  |  | 0.0 |  |  |  | 23.0 |  |
| Total |  | $ | 2,649.2 |  |  | $ | 130.3 |  |  | $ | 2,495.9 |  |  | $ | 23.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | (3.2 | ) |  | $ | 0.0 |  |  | $ | (3.2 | ) |  | $ | 0.0 |  |

[0001193125-14-425190:notes:131]
Level 2 investments are held by a custodian who prices some of
 the investments using standard inputs in various asset price models
 or obtains investment prices from a third-party pricing provider
 that incorporates standard inputs in various asset price models. We
 review Level 2 inputs and fair value for reasonableness and the
 values may be further validated by comparison to multiple
 independent pricing sources. In addition, we review third-party
 pricing provider models, key inputs and assumptions and understand
 the pricing processes at our third-party providers in determining
 the overall reasonableness of the fair value of our Level 2
 financial instruments. As of October 24, 2014, we have not
 made any adjustments to the prices obtained from our third-party
 pricing providers.

[0001193125-14-425190:notes:132]
[same as prior period, unchanged from 0001193125-14-325455:notes:137]

[0001193125-14-425190:notes:133]
The table below provides a reconciliation of the beginning and
 ending balance of our Level 3 ARSs measured at fair value on a
 recurring basis using significant unobservable inputs (in
 millions).

[0001193125-14-425190:notes:134]
[same as prior period, unchanged from 0001193125-14-325455:notes:138]

[0001193125-14-425190:notes:135]
As of October 24, 2014, the fair value of our long-term
 debt was approximately $1,510.3 million. The fair value of our debt
 was based on observable market prices in a less active market and
 discounted cash flow models that take into consideration variables
 such as credit-rating and interest rate changes. All of our debt
 obligations are categorized as Level 2 instruments.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001193125-14-425190:notes:136]
[same as prior period, unchanged from 0001193125-14-325455:notes:140]

[0001193125-14-425190:notes:137]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
|  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |
| Developed technology |  | $ | 283.0 |  |  | $ | (191.1 | ) |  | $ | 91.9 |  |  | $ | 283.0 |  |  | $ | (162.6 | ) |  | $ | 120.4 |  |
| Customer contracts/relationships |  |  | 2.6 |  |  |  | (2.2 | ) |  |  | 0.4 |  |  |  | 9.6 |  |  |  | (9.0 | ) |  |  | 0.6 |  |
| Trademarks and trade names |  |  | 2.9 |  |  |  | (2.7 | ) |  |  | 0.2 |  |  |  | 2.9 |  |  |  | (2.4 | ) |  |  | 0.5 |  |
| Covenants not to compete |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.6 |  |  |  | (1.6 | ) |  |  | 0.0 |  |
| Total purchased intangible assets |  | $ | 288.5 |  |  | $ | (196.0 | ) |  | $ | 92.5 |  |  | $ | 297.1 |  |  | $ | (175.6 | ) |  | $ | 121.5 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001193125-14-425190:notes:138]
[same as prior period, unchanged from 0001193125-14-325455:notes:142]

[0001193125-14-425190:notes:139]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Auction rate securities |  | $ | 23.0 |  |  | $ | 36.0 |  |
| Deferred tax assets |  |  | 247.3 |  |  |  | 245.0 |  |
| Other assets |  |  | 255.8 |  |  |  | 248.5 |  |
| Other non-current assets |  | $ | 526.1 |  |  | $ | 529.5 |  |


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-14-425190:notes:140]
The effect of derivative instruments not designated as hedging
 instruments recognized in other income (expense), net on our
 condensed consolidated statements of operations was as follows (in
 millions):

[0001193125-14-425190:notes:141]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |  | October 24, 2014 |  |  | October 25, 2013 |  |
|  |  | Gain (Loss) Recognized into Income |  |  | Gain (Loss) Recognized into Income |  |
| Foreign exchange forward contracts |  | $ | (0.8 | ) |  | $ | 0.6 |  |  | $ | (1.6 | ) |  | $ | 0.8 |  |


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001193125-14-425190:notes:142]
[same as prior period, unchanged from 0001193125-14-325455:notes:146]

[0001193125-14-425190:notes:143]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Product |  | $ | 25.0 |  |  | $ | 23.4 |  |
| Software entitlements and maintenance and service |  |  | 3,022.0 |  |  |  | 3,076.8 |  |
| Total |  | $ | 3,047.0 |  |  | $ | 3,100.2 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,632.1 |  |  | $ | 1,653.8 |  |
| Long-term |  |  | 1,414.9 |  |  |  | 1,446.4 |  |
| Total |  | $ | 3,047.0 |  |  | $ | 3,100.2 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-14-425190:notes:144]
[same as prior period, unchanged from 0001193125-14-325455:notes:148]

[0001193125-14-425190:notes:145]
[same as prior period, unchanged from 0001193125-14-325455:notes:149]

[0001193125-14-425190:notes:146]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 153.0 |  |  | $ | 122.6 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  |  | 187.4 |  |  |  | 155.5 |  |
| Forward contracts purchased |  |  | 303.4 |  |  |  | 389.9 |  |

[0001193125-14-425190:notes:147]
We have master netting arrangements in place to mitigate the
 credit risk of our counterparties and to potentially reduce our
 losses due to counterparty nonperformance. We present our
 derivative instruments as net amounts in our condensed consolidated
 balance sheets. The gross and net fair value amounts of such
 instruments were not material as of October 24, 2014 and
 April 25, 2014. We did not recognize any gains and losses in
 earnings due to hedge ineffectiveness for any period
 presented.

[0001193125-14-425190:notes:148]
[same as prior period, unchanged from 0001193125-14-325455:notes:152]


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001193125-14-425190:notes:149]
[same as prior period, unchanged from 0001193125-14-325455:notes:153]

[0001193125-14-425190:notes:150]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |  | October 24, 2014 |  |  | October 25, 2013 |  |  | Statements of Operations Classifications |
| Developed technology |  | $ | 14.2 |  |  | $ | 14.3 |  |  | $ | 28.5 |  |  | $ | 28.6 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 0.1 |  |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.7 |  |  | Operating expenses |
| Trademarks and trade names |  |  | 0.2 |  |  |  | 0.1 |  |  |  | 0.3 |  |  |  | 0.2 |  |  | Operating expenses |
| Covenants not to compete |  |  | 0.0 |  |  |  | 0.2 |  |  |  | 0.0 |  |  |  | 0.3 |  |  | Operating expenses |
|  |  | $ | 14.5 |  |  | $ | 14.9 |  |  | $ | 29.0 |  |  | $ | 29.8 |  |  |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001193125-14-425190:notes:151]
[same as prior period, unchanged from 0001193125-14-325455:notes:155]

[0001193125-14-425190:notes:152]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Prepaid expenses and other current assets |  | $ | 225.2 |  |  | $ | 219.4 |  |
| Deferred tax assets |  |  | 254.2 |  |  |  | 270.3 |  |
| Other current assets |  | $ | 479.4 |  |  | $ | 489.7 |  |


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock

[0001193125-14-425190:notes:153]
A reconciliation of the beginning and ending amount of
 unrecognized tax benefits is as follows (in millions):

[0001193125-14-425190:notes:154]
|  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Balance at beginning of period |  | $ | 235.9 |  |  | $ | 189.6 |  |
| Additions based on tax positions related to the current year |  |  | 12.7 |  |  |  | 13.6 |  |
| Additions for tax positions of prior years |  |  | 98.8 |  |  |  | 1.0 |  |
| Decreases for tax positions of prior years |  |  | (18.6 | ) |  |  | (4.4 | ) |
| Settlements |  |  | (54.3 | ) |  |  | 0.0 |  |
| Balance at end of period |  | $ | 274.5 |  |  | $ | 199.8 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-425190:notes:155]
[same as prior period, unchanged from 0001193125-14-325455:notes:159]

[0001193125-14-425190:notes:156]
[same as prior period, unchanged from 0001193125-14-325455:notes:160]

[0001193125-14-425190:notes:157]
|  |  | Six Months Ended |  |
|  |  | October 24, 2014 |  |  | October 25, 2013 |  |
| Effective tax rates |  |  | 28.8 | % |  |  | 12.7 | % |

[0001193125-14-425190:notes:158]
Our effective tax rates reflect the impact of a significant
 amount of our earnings being taxed in foreign jurisdictions at
 rates below the U.S. statutory tax rate. In addition, our effective
 tax rate for the six months ended October 24, 2014 was
 impacted by the settlements of income tax audits as discussed
 below.

[0001193125-14-425190:notes:159]
In July 2014, the Internal Revenue Service (IRS) completed the
 examination of our fiscal 2005 to 2007 income tax returns upon
 approval by the Joint Committee of Taxation. We recorded a $47.4
 million income tax provision attributable to the audit settlement
 and related re-measurement of uncertain tax positions for tax years
 subject to future audits. The audit adjustments resulted in lower
 earnings in our foreign subsidiaries which reduced the taxability
 of dividends that were previously repatriated from such
 subsidiaries. Due to this reduction in taxable dividends, the
 conclusion of the fiscal 2005 to 2007 income tax audit resulted in
 a net refund of $8.0 million, excluding interest.

[0001193125-14-425190:notes:160]
In October 2014, the United Kingdom’s (UK’s) tax
 authority concluded the examination of our fiscal 2009 to 2012 UK
 income tax returns. We recorded a $1.0 million income tax benefit
 for the net impact of the audit adjustments and related release of
 unrecognized tax benefits.

[0001193125-14-425190:notes:161]
As of October 24, 2014, we had $274.5 million of gross
 unrecognized tax benefits, of which $220.2 million has been
 recorded in other long-term liabilities. Unrecognized tax benefits
 of $168.2 million, including penalties, interest and indirect
 benefits, would affect our provision for income taxes if
 recognized.

[0001193125-14-425190:notes:162]
[same as prior period, unchanged from 0001193125-14-325455:notes:165]

[0001193125-14-425190:notes:163]
[same as prior period, unchanged from 0001193125-14-325455:notes:166]

[0001193125-14-425190:notes:164]
Our Dutch subsidiaries have concluded an advanced transfer
 pricing agreement with the Dutch tax authorities that will be
 effective from May 1, 2015 to April 30, 2020. The
 advanced transfer pricing agreement has terms similar to our
 current agreement which is set to expire on April 30,
 2015.


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001193125-14-425190:notes:165]
[same as prior period, unchanged from 0001193125-14-325455:notes:168]

[0001193125-14-425190:notes:166]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Cash |  | $ | 2,680.3 |  |  | $ | 2,174.0 |  |
| Cash equivalents |  |  | 224.9 |  |  |  | 117.0 |  |
| Cash and cash equivalents |  | $ | 2,905.2 |  |  | $ | 2,291.0 |  |


## us-gaap:SubsequentEventsTextBlock

[0001193125-14-425190:notes:167]
15.  Subsequent Event

[0001193125-14-425190:notes:168]
On October 27, 2014, we completed the acquisition of
 Riverbed Technology, Inc.’s SteelStore product line for
 approximately $80.0 million in cash. The SteelStore product line
 supports leading backup applications and cloud providers so that
 customers have a choice in how they extend their existing data
 protection infrastructure into the cloud. We are in the process of
 completing the purchase price allocation for this acquisition. Pro
 forma results of operations have not been presented because the
 acquisition was not material to our results of
 operations.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-14-425190:notes:169]
[same as prior period, unchanged from 0001193125-14-325455:notes:170]

[0001193125-14-425190:notes:170]
[same as prior period, unchanged from 0001193125-14-325455:notes:171]

[0001193125-14-425190:notes:171]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Land |  | $ | 265.7 |  |  | $ | 265.7 |  |
| Buildings and building improvements |  |  | 605.5 |  |  |  | 541.7 |  |
| Leasehold improvements |  |  | 106.5 |  |  |  | 102.9 |  |
| Computer, production, engineering and other equipment |  |  | 778.1 |  |  |  | 753.8 |  |
| Software |  |  | 376.7 |  |  |  | 369.1 |  |
| Furniture and fixtures |  |  | 85.3 |  |  |  | 86.4 |  |
| Construction-in-progress |  |  | 20.7 |  |  |  | 72.9 |  |
|  |  |  | 2,238.5 |  |  |  | 2,192.5 |  |
| Accumulated depreciation and amortization |  |  | (1,156.8 | ) |  |  | (1,083.7 | ) |
| Property and equipment, net |  | $ | 1,081.7 |  |  | $ | 1,108.8 |  |

[0001193125-14-425190:notes:172]
[same as prior period, unchanged from 0001193125-14-325455:notes:173]

[0001193125-14-425190:notes:173]
|  |  | October 24, 2014 |  |  | April 25, 2014 |  |
| Computer software |  | $ | 83.5 |  |  | $ | 103.5 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-14-425190:notes:174]
[same as prior period, unchanged from 0001193125-14-325455:notes:175]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-14-425190:notes:175]
[same as prior period, unchanged from 0001193125-14-325455:notes:176]

[0001193125-14-425190:notes:176]
In May
 2013, we initiated a business restructuring plan under which we
 realigned internal resources, resulting in a reduction of our
 global workforce of approximately 7%. Such activities were
 completed in the year ended April 25, 2014. In March 2014, we
 initiated a business realignment plan designed to focus our
 resources on key strategic initiatives and streamline our business
 in light of the constrained IT spending environment, resulting in a
 reduction of our global workforce of approximately 4%. Such
 activities were substantially completed in the three months ended
 October 24, 2014. Restructuring and other charges consisted
 primarily of employee severance-related costs.

[0001193125-14-425190:notes:177]
[same as prior period, unchanged from 0001193125-14-325455:notes:178]
