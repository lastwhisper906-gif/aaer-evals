# NTAP 8-K — 0001564590-18-029561 filed 2018-11-14

## item codes, every 8-K on or before 2018-11-19

- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2018-11-19

- none on or before 2018-11-19

## item 2.02 — earnings release, exhibit 99.1

[0001564590-18-029561:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-18-029561:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-18-029561:8k_2_02:3]
Exhibit 99.1

[0001564590-18-029561:8k_2_02:4]
NetApp Reports Second Quarter Fiscal Year 2019 Results

[0001564590-18-029561:8k_2_02:5]
Strengthens Data Fabric Strategy with Substantial Innovation Across the Entire Portfolio

[0001564590-18-029561:8k_2_02:6]
| • | Net revenues of $1.52 billion grew 7% year-over-year |  |

[0001564590-18-029561:8k_2_02:7]
| • | Product revenue of $913 million grew 11% year-over-year |  |

[0001564590-18-029561:8k_2_02:8]
| • | All-flash array annualized net revenue run rate of $2.2 billion increased 29% year-over-year |  |

[0001564590-18-029561:8k_2_02:9]
| • | $663 million returned to shareholders in share repurchases and cash dividends |  |

[0001564590-18-029561:8k_2_02:10]
Sunnyvale, Calif.—November 14, 2018—NetApp (NASDAQ: NTAP) today reported financial results for the second quarter of fiscal year 2019, which ended October 26, 2018.

[0001564590-18-029561:8k_2_02:11]
“Through focus and disciplined execution, NetApp again delivered strong results in the second quarter. We introduced a tremendous amount of innovation across our portfolio that helps us drive share gains, expand our available market, and set the industry agenda,” said George Kurian, chief executive officer. “Our consistent and strong performance reflects the clear differentiation of our technology and the strength of our business model, as well as our customers' growing commitment to NetApp and value of our Data Fabric strategy.”

[0001564590-18-029561:8k_2_02:12]
Second Quarter Fiscal Year 2019 Financial Results

[0001564590-18-029561:8k_2_02:13]
| • | Net Revenues: $1.52 billion, increased 7% year-over-year from $1.42 billion* in the second quarter of fiscal 2018 |  |

[0001564590-18-029561:8k_2_02:14]
| • | Net Income: GAAP net income of $241 million, compared to GAAP net income of $174 million* in the second quarter of fiscal 2018; non-GAAP net income1 of $280 million, compared to non-GAAP net income of $221 million* in the second quarter of fiscal 2018 |  |

[0001564590-18-029561:8k_2_02:15]
| • | Earnings per Share: GAAP earnings per share2 of $0.91 compared to GAAP earnings per share of $0.63* in the second quarter of fiscal 2018; non-GAAP earnings per share of $1.06, compared to non-GAAP earnings per share of $0.80* in the second quarter of fiscal 2018 |  |

[0001564590-18-029561:8k_2_02:16]
| • | Cash, Cash Equivalents and Investments: $4.3 billion at the end of the second quarter of fiscal 2019 |  |

[0001564590-18-029561:8k_2_02:17]
| • | Cash from Operations: $165 million, compared to $314 million in the second quarter of fiscal 2018 |  |

[0001564590-18-029561:8k_2_02:18]
| • | Share Repurchase and Dividend: Returned $663 million to shareholders through share repurchases and cash dividends |  |

[0001564590-18-029561:8k_2_02:19]
* In the first quarter of fiscal 2019, NetApp adopted Revenue from Contracts with Customers (ASC 606) using the full retrospective method of adoption. Accordingly, NetApp’s condensed consolidated balance sheet as of April 27, 2018, condensed consolidated statements of operations and cash flows for all fiscal 2018 periods presented, and all related financial statement metrics included herein, have been restated to conform to the new rules.

[0001564590-18-029561:8k_2_02:20]
Third Quarter Fiscal Year 2019 Financial Outlook

[0001564590-18-029561:8k_2_02:21]
The Company provided the following financial guidance for the third quarter of fiscal year 2019:

[0001564590-18-029561:8k_2_02:22]
| •Net revenues are expected to be in the range of: | $1.550 billion to $1.650 billion |
|  | GAAP | Non-GAAP |
| •Earnings per share is expected to be in the range of: | $0.96-$1.02 | $1.12-$1.18 |

[0001564590-18-029561:8k_2_02:23]
Dividend

[0001564590-18-029561:8k_2_02:24]
Next cash dividend of $0.40 per share to be paid on January 23, 2019, to shareholders of record as of the close of business on January 4, 2019.

[0001564590-18-029561:8k_2_02:25]
Second Quarter Fiscal Year 2019 Business Highlights

[0001564590-18-029561:8k_2_02:26]
New Products and Solutions Help Data-Driven Organizations Thrive

[0001564590-18-029561:8k_2_02:27]
| - | NetApp announced new solutions to enable customers to deliver data-driven business outcomes for applications across hybrid cloud and multicloud environments, including NetApp™ Cloud Insights, Azure NetApp Files, Cloud Volumes Service, Cloud Volumes ONTAP™, NetApp HCI, SaaS Backup for Microsoft Office 365, and NetApp Data availability Services. |

[0001564590-18-029561:8k_2_02:28]
| - | NetApp announced expanded availability and features for NetApp Cloud Volumes for Google Cloud Platform (GCP) to help customers deploy workloads such as video rendering, databases, high-performance computing, and continuous integration on GCP. |

[0001564590-18-029561:8k_2_02:29]
| - | NetApp announced ONTAP 9.5, MAX Data, StorageGRID™ SG6060, NetApp Solution Support for FlexPod™, and Flash Performance Guarantee. These new data services and solutions further extend the NetApp Data Fabric across edge, core, and cloud, enabling organizations to fully realize the promise of artificial intelligence. |

[0001564590-18-029561:8k_2_02:30]
| - | NetApp introduced NetApp ONTAP AI proven architecture, powered by NVIDIA DGX supercomputers and NetApp AFF A800 cloud-connected all-flash storage, to simplify, accelerate, and scale the data pipeline across edge, core, and cloud for deep learning deployments and to help customers achieve real business impact with AI. |

[0001564590-18-029561:8k_2_02:31]
| - | NetApp announced: updates to Trident, its automated provisioner for solving the persistent storage challenge for containers; a new verified architecture for Red Hat OpenShift Container Platform on NetApp HCI; and enhanced flexibility for DevOps on both NetApp Cloud Volumes for Google Cloud Platform and NetApp Cloud Volumes for AWS. |

[0001564590-18-029561:8k_2_02:32]
| - | NetApp OnCommand™ System Manager 9.4 is now bundled with NetApp ONTAP 9.4 features improvements that simplify day-to-day operations. |

[0001564590-18-029561:8k_2_02:33]
| - | NetApp announced the acquisition of StackPointCloud, a leader in multicloud Kubernetes as a service and a contributor to the Kubernetes project. The combination of StackPointCloud with NetApp creates NetApp Kubernetes Service, the industry's first complete Kubernetes platform for multicloud deployments and a complete cloud-based stack for Azure, Google Cloud, AWS, and NetApp HCI. |

[0001564590-18-029561:8k_2_02:34]
NetApp Expands Strategic Partnerships

[0001564590-18-029561:8k_2_02:35]
| - | NetApp announced that it has partnered with DreamWorks to develop and oversee the studio’s customized Data Fabric approach, designed to enable expanded capabilities and future growth for the Glendale-based leader in family entertainment. |

[0001564590-18-029561:8k_2_02:36]
| - | NetApp announced a partnership with WuXi NextCODE, the world’s leading genomic data platform and analysis company, working to improve health for people around the globe. WuXi NextCODE will use NetApp Cloud Volumes for simplified deployment and optimized management of data-driven applications. |

[0001564590-18-029561:8k_2_02:37]
| - | Lenovo and NetApp announced a global, multifaceted partnership to bring innovative technology and a simplified experience to help customers modernize IT and accelerate their digital transformation. |

[0001564590-18-029561:8k_2_02:38]
NetApp Strengthens Leadership Team

[0001564590-18-029561:8k_2_02:39]
| - | NetApp announced the appointment of Atish Gude as the chief strategy officer (CSO), reporting to CEO George Kurian. |

[0001564590-18-029561:8k_2_02:40]
| - | NetApp announced the appointment of Debra McCowan as senior vice president and chief human resources officer (CHRO), reporting to CEO George Kurian. |

[0001564590-18-029561:8k_2_02:41]
Webcast and Conference Call Information

[0001564590-18-029561:8k_2_02:42]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:30 p.m. Pacific Time today.

[0001564590-18-029561:8k_2_02:43]
About NetApp

[0001564590-18-029561:8k_2_02:44]
NetApp is the data authority for hybrid cloud. We provide a full range of hybrid cloud data services that simplify management of applications and data across cloud and on-premises environments to accelerate digital transformation. Together with our partners, we empower global organizations to unleash the full potential of their data to expand customer touchpoints, foster greater innovation, and optimize their operations. For more information, visit www.netapp.com. #DataDriven

[0001564590-18-029561:8k_2_02:45]
for a variety of reasons, including, without limitation, general global political, macroeconomic and market conditions, changes in U.S. government spending, revenue seasonality and matters specific to our business, such as our ability to expand our total available market and grow our portfolio of products, customer demand for and acceptance of our products and services, our ability to successfully execute new business models, our ability to successfully execute on our Data Fabric strategy to generate profitable growth and stockholder return and our ability to manage our gross profit margins. These and other equally important factors are described in reports and documents we file from time to time with the Securities and Exchange Commission, including the factors described under the section titled “Risk Factors” in our most recently submitted reports on 10-Q and 10-K. We disclaim any obligation to update information contained in this press release whether as a result of new information, future events, or otherwise.

[0001564590-18-029561:8k_2_02:46]
###

[0001564590-18-029561:8k_2_02:47]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-18-029561:8k_2_02:48]
Footnotes

[0001564590-18-029561:8k_2_02:49]
1Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale of properties, and (h) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-18-029561:8k_2_02:50]
2GAAP earnings per share and non-GAAP earnings per share are calculated using the diluted number of shares.

[0001564590-18-029561:8k_2_02:51]
NetApp Usage of Non-GAAP Financial Information

[0001564590-18-029561:8k_2_02:52]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-18-029561:8k_2_02:53]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-18-029561:8k_2_02:54]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-18-029561:8k_2_02:55]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-18-029561:8k_2_02:56]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-18-029561:8k_2_02:57]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term

[0001564590-18-029561:8k_2_02:58]
incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-18-029561:8k_2_02:59]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-18-029561:8k_2_02:60]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-18-029561:8k_2_02:61]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-18-029561:8k_2_02:62]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-18-029561:8k_2_02:63]
G. Gains/losses on the sale of properties. These are gains/losses from the sale of our properties. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-18-029561:8k_2_02:64]
H. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of

[0001564590-18-029561:8k_2_02:65]
intellectual properties from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-18-029561:8k_2_02:66]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-18-029561:8k_2_02:67]
NETAPP, INC.

[0001564590-18-029561:8k_2_02:68]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-18-029561:8k_2_02:69]
(In millions)

[0001564590-18-029561:8k_2_02:70]
(Unaudited)

[0001564590-18-029561:8k_2_02:71]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,299 |  |  | $ | 5,391 |  |
| Accounts receivable |  |  | 765 |  |  |  | 1,047 |  |
| Inventories |  |  | 86 |  |  |  | 122 |  |
| Other current assets |  |  | 321 |  |  |  | 392 |  |
| Total current assets |  |  | 5,471 |  |  |  | 6,952 |  |
| Property and equipment, net |  |  | 770 |  |  |  | 756 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,811 |  |  |  | 1,833 |  |
| Other non-current assets |  |  | 499 |  |  |  | 450 |  |
| Total assets |  | $ | 8,551 |  |  | $ | 9,991 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 472 |  |  | $ | 609 |  |
| Accrued expenses |  |  | 652 |  |  |  | 825 |  |
| Commercial paper notes |  |  | 249 |  |  |  | 385 |  |
| Current portion of long-term debt |  |  | 399 |  |  |  | — |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,538 |  |  |  | 1,712 |  |
| Total current liabilities |  |  | 3,310 |  |  |  | 3,531 |  |
| Long-term debt |  |  | 1,144 |  |  |  | 1,541 |  |
| Other long-term liabilities |  |  | 899 |  |  |  | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,668 |  |  |  | 1,651 |  |
| Total liabilities |  |  | 7,021 |  |  |  | 7,715 |  |
| Stockholders' equity |  |  | 1,530 |  |  |  | 2,276 |  |
| Total liabilities and stockholders' equity |  | $ | 8,551 |  |  | $ | 9,991 |  |

[0001564590-18-029561:8k_2_02:72]
NETAPP, INC.

[0001564590-18-029561:8k_2_02:73]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-18-029561:8k_2_02:74]
(In millions, except per share amounts)

[0001564590-18-029561:8k_2_02:75]
(Unaudited)

[0001564590-18-029561:8k_2_02:76]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 913 |  |  | $ | 819 |  |  | $ | 1,788 |  |  | $ | 1,546 |  |
| Software maintenance |  |  | 236 |  |  |  | 224 |  |  |  | 465 |  |  |  | 447 |  |
| Hardware maintenance and other services |  |  | 368 |  |  |  | 372 |  |  |  | 738 |  |  |  | 743 |  |
| Net revenues |  |  | 1,517 |  |  |  | 1,415 |  |  |  | 2,991 |  |  |  | 2,736 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 428 |  |  |  | 397 |  |  |  | 826 |  |  |  | 773 |  |
| Cost of software maintenance |  |  | 8 |  |  |  | 6 |  |  |  | 15 |  |  |  | 13 |  |
| Cost of hardware maintenance and other services |  |  | 107 |  |  |  | 112 |  |  |  | 213 |  |  |  | 226 |  |
| Total cost of revenues |  |  | 543 |  |  |  | 515 |  |  |  | 1,054 |  |  |  | 1,012 |  |
| Gross profit |  |  | 974 |  |  |  | 900 |  |  |  | 1,937 |  |  |  | 1,724 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 408 |  |  |  | 421 |  |  |  | 817 |  |  |  | 844 |  |
| Research and development |  |  | 211 |  |  |  | 194 |  |  |  | 419 |  |  |  | 387 |  |
| General and administrative |  |  | 69 |  |  |  | 69 |  |  |  | 142 |  |  |  | 137 |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 19 |  |  |  | — |  |
| Total operating expenses |  |  | 688 |  |  |  | 684 |  |  |  | 1,397 |  |  |  | 1,368 |  |
| Income from operations |  |  | 286 |  |  |  | 216 |  |  |  | 540 |  |  |  | 356 |  |
| Other income, net |  |  | 7 |  |  |  | 6 |  |  |  | 25 |  |  |  | 11 |  |
| Income before income taxes |  |  | 293 |  |  |  | 222 |  |  |  | 565 |  |  |  | 367 |  |
| Provision for income taxes |  |  | 52 |  |  |  | 48 |  |  |  | 41 |  |  |  | 62 |  |
| Net income |  | $ | 241 |  |  | $ | 174 |  |  | $ | 524 |  |  | $ | 305 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.93 |  |  | $ | 0.65 |  |  | $ | 2.02 |  |  | $ | 1.13 |  |
| Diluted |  | $ | 0.91 |  |  | $ | 0.63 |  |  | $ | 1.96 |  |  | $ | 1.10 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 258 |  |  |  | 269 |  |  |  | 260 |  |  |  | 270 |  |
| Diluted |  |  | 264 |  |  |  | 275 |  |  |  | 267 |  |  |  | 277 |  |
| Cash dividends declared per share |  | $ | 0.40 |  |  | $ | 0.20 |  |  | $ | 0.80 |  |  | $ | 0.40 |  |

[0001564590-18-029561:8k_2_02:77]
NETAPP, INC.

[0001564590-18-029561:8k_2_02:78]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-18-029561:8k_2_02:79]
(In millions)

[0001564590-18-029561:8k_2_02:80]
(Unaudited)

[0001564590-18-029561:8k_2_02:81]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 241 |  |  | $ | 174 |  |  | $ | 524 |  |  | $ | 305 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 49 |  |  |  | 51 |  |  |  | 98 |  |  |  | 102 |  |
| Stock-based compensation |  |  | 38 |  |  |  | 39 |  |  |  | 78 |  |  |  | 87 |  |
| Deferred income taxes |  |  | 1 |  |  |  | 40 |  |  |  | (25 | ) |  |  | 40 |  |
| Other items, net |  |  | 3 |  |  |  | (10 | ) |  |  | 11 |  |  |  | (5 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (154 | ) |  |  | (80 | ) |  |  | 269 |  |  |  | 146 |  |
| Inventories |  |  | 11 |  |  |  | 34 |  |  |  | 36 |  |  |  | 58 |  |
| Accounts payable |  |  | 50 |  |  |  | 92 |  |  |  | (127 | ) |  |  | 34 |  |
| Accrued expenses |  |  | 59 |  |  |  | 67 |  |  |  | (162 | ) |  |  | (68 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (42 | ) |  |  | (61 | ) |  |  | (129 | ) |  |  | (163 | ) |
| Long-term taxes payable |  |  | (68 | ) |  |  | 2 |  |  |  | (63 | ) |  |  | 2 |  |
| Changes in other operating assets and liabilities, net |  |  | (23 | ) |  |  | (34 | ) |  |  | (19 | ) |  |  | 26 |  |
| Net cash provided by operating activities |  |  | 165 |  |  |  | 314 |  |  |  | 491 |  |  |  | 564 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 241 |  |  |  | (64 | ) |  |  | 489 |  |  |  | 48 |  |
| Purchases of property and equipment |  |  | (43 | ) |  |  | (29 | ) |  |  | (107 | ) |  |  | (65 | ) |
| Acquisitions of businesses, net of cash acquired |  |  | (3 | ) |  |  | (51 | ) |  |  | (3 | ) |  |  | (75 | ) |
| Other investing activities, net |  |  | — |  |  |  | (1 | ) |  |  | 2 |  |  |  | — |  |
| Net cash provided by (used in) investing activities |  |  | 195 |  |  |  | (145 | ) |  |  | 381 |  |  |  | (92 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 2 |  |  |  | 9 |  |  |  | 65 |  |  |  | 57 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (5 | ) |  |  | (3 | ) |  |  | (89 | ) |  |  | (60 | ) |
| Repurchase of common stock |  |  | (561 | ) |  |  | (150 | ) |  |  | (1,061 | ) |  |  | (300 | ) |
| Proceeds from (repayments of) commercial paper notes, net |  |  | 50 |  |  |  | (176 | ) |  |  | (135 | ) |  |  | 218 |  |
| Issuance of long-term debt, net |  |  | — |  |  |  | 795 |  |  |  | — |  |  |  | 795 |  |
| Dividends paid |  |  | (102 | ) |  |  | (54 | ) |  |  | (207 | ) |  |  | (108 | ) |
| Other financing activities, net |  |  | (1 | ) |  |  | (1 | ) |  |  | (2 | ) |  |  | (1 | ) |
| Net cash provided by (used in) financing activities |  |  | (617 | ) |  |  | 420 |  |  |  | (1,429 | ) |  |  | 601 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (11 | ) |  |  | (6 | ) |  |  | (25 | ) |  |  | 13 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | (268 | ) |  |  | 583 |  |  |  | (582 | ) |  |  | 1,086 |  |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,633 |  |  |  | 2,953 |  |  |  | 2,947 |  |  |  | 2,450 |  |
| End of period |  | $ | 2,365 |  |  | $ | 3,536 |  |  | $ | 2,365 |  |  | $ | 3,536 |  |

[0001564590-18-029561:8k_2_02:82]
SELECTED CONDENSED CONSOLIDATED BALANCE SHEET LINE ITEMS

[0001564590-18-029561:8k_2_02:83]
(In millions)

[0001564590-18-029561:8k_2_02:84]
(Unaudited)

[0001564590-18-029561:8k_2_02:85]
|  |  | As of April 27, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  |  | As Adjusted |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 1,009 |  |  | $ | 38 |  |  | $ | 1,047 |  |
| Inventories |  |  | 126 |  |  |  | (4 | ) |  |  | 122 |  |
| Other current assets |  |  | 330 |  |  |  | 62 |  |  |  | 392 |  |
| Other non-current assets |  |  | 420 |  |  |  | 30 |  |  |  | 450 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |
| Short-term deferred revenue and financed unearned services revenue |  | $ | 1,804 |  |  | $ | (92 | ) |  | $ | 1,712 |  |
| Other long-term liabilities |  |  | 961 |  |  |  | 31 |  |  |  | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,673 |  |  |  | (22 | ) |  |  | 1,651 |  |
| Total stockholders' equity |  |  | 2,067 |  |  |  | 209 |  |  |  | 2,276 |  |

[0001564590-18-029561:8k_2_02:86]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 27, 2017 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 807 |  |  | $ | 12 |  |  | $ | 819 |  |  | $ | 1,530 |  |  | $ | 16 |  |  | $ | 1,546 |  |
| Software maintenance |  |  | 240 |  |  |  | (16 | ) |  |  | 224 |  |  |  | 474 |  |  |  | (27 | ) |  |  | 447 |  |
| Hardware maintenance and other services |  |  | 375 |  |  |  | (3 | ) |  |  | 372 |  |  |  | 743 |  |  |  | — |  |  |  | 743 |  |
| Net revenues |  |  | 1,422 |  |  |  | (7 | ) |  |  | 1,415 |  |  |  | 2,747 |  |  |  | (11 | ) |  |  | 2,736 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 399 |  |  |  | (2 | ) |  |  | 397 |  |  |  | 770 |  |  |  | 3 |  |  |  | 773 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | — |  |  |  | 6 |  |  |  | 13 |  |  |  | — |  |  |  | 13 |  |
| Cost of hardware maintenance and other services |  |  | 115 |  |  |  | (3 | ) |  |  | 112 |  |  |  | 228 |  |  |  | (2 | ) |  |  | 226 |  |
| Total cost of revenues |  |  | 520 |  |  |  | (5 | ) |  |  | 515 |  |  |  | 1,011 |  |  |  | 1 |  |  |  | 1,012 |  |
| Gross profit |  |  | 902 |  |  |  | (2 | ) |  |  | 900 |  |  |  | 1,736 |  |  |  | (12 | ) |  |  | 1,724 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 420 |  |  |  | 1 |  |  |  | 421 |  |  |  | 845 |  |  |  | (1 | ) |  |  | 844 |  |
| Research and development |  |  | 194 |  |  |  | — |  |  |  | 194 |  |  |  | 387 |  |  |  | — |  |  |  | 387 |  |
| General and administrative |  |  | 69 |  |  |  | — |  |  |  | 69 |  |  |  | 137 |  |  |  | — |  |  |  | 137 |  |
| Total operating expenses |  |  | 683 |  |  |  | 1 |  |  |  | 684 |  |  |  | 1,369 |  |  |  | (1 | ) |  |  | 1,368 |  |
| Income from operations |  |  | 219 |  |  |  | (3 | ) |  |  | 216 |  |  |  | 367 |  |  |  | (11 | ) |  |  | 356 |  |
| Other income, net |  |  | 6 |  |  |  | — |  |  |  | 6 |  |  |  | 11 |  |  |  | — |  |  |  | 11 |  |
| Income before income taxes |  |  | 225 |  |  |  | (3 | ) |  |  | 222 |  |  |  | 378 |  |  |  | (11 | ) |  |  | 367 |  |
| Provision for income taxes |  |  | 50 |  |  |  | (2 | ) |  |  | 48 |  |  |  | 67 |  |  |  | (5 | ) |  |  | 62 |  |
| Net income |  | $ | 175 |  |  | $ | (1 | ) |  | $ | 174 |  |  | $ | 311 |  |  | $ | (6 | ) |  | $ | 305 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.65 |  |  | $ | — |  |  | $ | 0.65 |  |  | $ | 1.15 |  |  | $ | (0.02 | ) |  | $ | 1.13 |  |
| Diluted |  | $ | 0.64 |  |  | $ | (0.01 | ) |  | $ | 0.63 |  |  | $ | 1.12 |  |  | $ | (0.02 | ) |  | $ | 1.10 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 269 |  |  |  | 269 |  |  |  | 269 |  |  |  | 270 |  |  |  | 270 |  |  |  | 270 |  |
| Diluted |  |  | 275 |  |  |  | 275 |  |  |  | 275 |  |  |  | 277 |  |  |  | 277 |  |  |  | 277 |  |

[0001564590-18-029561:8k_2_02:87]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q2 FY'19 |  |  | Q1 FY'19 |  |  | Q2 FY'18 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 913 |  |  | $ | 875 |  |  | $ | 819 |  |
| Strategic |  | $ | 649 |  |  | $ | 612 |  |  | $ | 566 |  |
| Mature |  | $ | 264 |  |  | $ | 263 |  |  | $ | 253 |  |
| Software Maintenance |  | $ | 236 |  |  | $ | 229 |  |  | $ | 224 |  |
| Hardware Maintenance and Other Services |  | $ | 368 |  |  | $ | 370 |  |  | $ | 372 |  |
| Hardware Maintenance Support Contracts |  | $ | 303 |  |  | $ | 303 |  |  | $ | 306 |  |
| Professional and Other Services |  | $ | 65 |  |  | $ | 67 |  |  | $ | 66 |  |
| Net Revenues |  | $ | 1,517 |  |  | $ | 1,474 |  |  | $ | 1,415 |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'19 Revenue |  |  | % of Q1 FY'19 Revenue |  |  | % of Q2 FY'18 Revenue |  |
| Americas |  |  | 57 | % |  |  | 57 | % |  |  | 56 | % |
| Americas Commercial |  |  | 44 | % |  |  | 46 | % |  |  | 40 | % |
| U.S. Public Sector |  |  | 14 | % |  |  | 11 | % |  |  | 16 | % |
| EMEA |  |  | 28 | % |  |  | 29 | % |  |  | 30 | % |
| Asia Pacific |  |  | 15 | % |  |  | 14 | % |  |  | 14 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'19 Revenue |  |  | % of Q1 FY'19 Revenue |  |  | % of Q2 FY'18 Revenue |  |
| Direct |  |  | 23 | % |  |  | 29 | % |  |  | 22 | % |
| Indirect |  |  | 77 | % |  |  | 71 | % |  |  | 78 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'19 |  |  | Q1 FY'19 |  |  | Q2 FY'18 |  |
| Non-GAAP Gross Margin |  |  | 64.9 | % |  |  | 66.2 | % |  |  | 64.5 | % |
| Product |  |  | 54.1 | % |  |  | 55.7 | % |  |  | 52.7 | % |
| Software Maintenance |  |  | 96.6 | % |  |  | 96.9 | % |  |  | 97.3 | % |
| Hardware Maintenance and Other Services |  |  | 71.5 | % |  |  | 72.2 | % |  |  | 70.4 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'19 |  |  | Q1 FY'19 |  |  | Q2 FY'18 |  |
| Non-GAAP Income from Operations |  | $ | 336 |  |  | $ | 326 |  |  | $ | 269 |  |
| % of Net Revenues |  |  | 22.1 | % |  |  | 22.1 | % |  |  | 19.0 | % |
| Non-GAAP Income before Income Taxes |  | $ | 343 |  |  | $ | 344 |  |  | $ | 275 |  |
| Non-GAAP Effective Tax Rate |  |  | 18.5 | % |  |  | 18.3 | % |  |  | 19.6 | % |

[0001564590-18-029561:8k_2_02:88]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'19 |  |  | Q1 FY'19 |  |  | Q2 FY'18 |  |
| Non-GAAP Net Income |  | $ | 280 |  |  | $ | 281 |  |  | $ | 221 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 264 |  |  |  | 269 |  |  |  | 275 |  |
| Non-GAAP Income per Share, Diluted |  | $ | 1.06 |  |  | $ | 1.04 |  |  | $ | 0.80 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'19 |  |  | Q1 FY'19 |  |  | Q2 FY'18 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,206 |  |  | $ | 3,260 |  |  | $ | 3,059 |  |
| DSO (days) |  |  | 46 |  |  |  | 38 |  |  |  | 39 |  |
| DIO (days) |  |  | 14 |  |  |  | 17 |  |  |  | 18 |  |
| DPO (days) |  |  | 79 |  |  |  | 76 |  |  |  | 67 |  |
| CCC (days) |  |  | (19 | ) |  |  | (20 | ) |  |  | (10 | ) |
| Inventory Turns |  |  | 25 |  |  |  | 21 |  |  |  | 21 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'19 |  |  | Q1 FY'19 |  |  | Q2 FY'18 |  |
| Net Cash Provided by Operating Activities |  | $ | 165 |  |  | $ | 326 |  |  | $ | 314 |  |
| Purchases of Property and Equipment |  | $ | 43 |  |  | $ | 64 |  |  | $ | 29 |  |
| Free Cash Flow |  | $ | 122 |  |  | $ | 262 |  |  | $ | 285 |  |
| Free Cash Flow as a % of Net Revenues |  |  | 8.0 | % |  |  | 17.8 | % |  |  | 20.1 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001564590-18-029561:8k_2_02:89]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY19 |  |  | Q1'FY19 |  |  | Q2'FY18 |  |
| NET INCOME |  | $ | 241 |  |  | $ | 283 |  |  | $ | 174 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 12 |  |  |  | 13 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 38 |  |  |  | 40 |  |  |  | 39 |  |
| Restructuring charges |  |  | — |  |  |  | 19 |  |  |  | — |  |
| Income tax effects |  |  | (11 | ) |  |  | (40 | ) |  |  | (6 | ) |
| Income tax benefit of ASC 606 adoption |  |  | — |  |  |  | (34 | ) |  |  | — |  |
| NON-GAAP NET INCOME |  | $ | 280 |  |  | $ | 281 |  |  | $ | 221 |  |
| COST OF REVENUES |  | $ | 543 |  |  | $ | 511 |  |  | $ | 515 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (9 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (2 | ) |  |  | (4 | ) |  |  | (3 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 532 |  |  | $ | 498 |  |  | $ | 503 |  |
| COST OF PRODUCT REVENUES |  | $ | 428 |  |  | $ | 398 |  |  | $ | 397 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (9 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 419 |  |  | $ | 388 |  |  | $ | 387 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 107 |  |  | $ | 106 |  |  | $ | 112 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (3 | ) |  |  | (2 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 105 |  |  | $ | 103 |  |  | $ | 110 |  |
| GROSS PROFIT |  | $ | 974 |  |  | $ | 963 |  |  | $ | 900 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 9 |  |  |  | 9 |  |
| Stock-based compensation |  |  | 2 |  |  |  | 4 |  |  |  | 3 |  |
| NON-GAAP GROSS PROFIT |  | $ | 985 |  |  | $ | 976 |  |  | $ | 912 |  |

[0001564590-18-029561:8k_2_02:90]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY19 |  |  | Q1'FY19 |  |  | Q2'FY18 |  |
| SALES AND MARKETING EXPENSES |  | $ | 408 |  |  | $ | 409 |  |  | $ | 421 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (4 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (16 | ) |  |  | (17 | ) |  |  | (16 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 389 |  |  | $ | 388 |  |  | $ | 400 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 211 |  |  | $ | 208 |  |  | $ | 194 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (12 | ) |  |  | (12 | ) |  |  | (12 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 199 |  |  | $ | 196 |  |  | $ | 182 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 69 |  |  | $ | 73 |  |  | $ | 69 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (8 | ) |  |  | (7 | ) |  |  | (8 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 61 |  |  | $ | 66 |  |  | $ | 61 |  |
| RESTRUCTURING CHARGES |  | $ | — |  |  | $ | 19 |  |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | — |  |  |  | (19 | ) |  |  | — |  |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 688 |  |  | $ | 709 |  |  | $ | 684 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (4 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (36 | ) |  |  | (36 | ) |  |  | (36 | ) |
| Restructuring charges |  |  | — |  |  |  | (19 | ) |  |  | — |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 649 |  |  | $ | 650 |  |  | $ | 643 |  |

[0001564590-18-029561:8k_2_02:91]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY19 |  |  | Q1'FY19 |  |  | Q2'FY18 |  |
| INCOME FROM OPERATIONS |  | $ | 286 |  |  | $ | 254 |  |  | $ | 216 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 12 |  |  |  | 13 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 38 |  |  |  | 40 |  |  |  | 39 |  |
| Restructuring charges |  |  | — |  |  |  | 19 |  |  |  | — |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 336 |  |  | $ | 326 |  |  | $ | 269 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 293 |  |  | $ | 272 |  |  | $ | 222 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 12 |  |  |  | 13 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 38 |  |  |  | 40 |  |  |  | 39 |  |
| Restructuring charges |  |  | — |  |  |  | 19 |  |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 343 |  |  | $ | 344 |  |  | $ | 275 |  |
| PROVISION (BENEFIT) FOR INCOME TAXES |  | $ | 52 |  |  | $ | (11 | ) |  | $ | 48 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 11 |  |  |  | 40 |  |  |  | 6 |  |
| Income tax benefit of ASC 606 adoption |  |  | — |  |  |  | 34 |  |  |  | — |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 63 |  |  | $ | 63 |  |  | $ | 54 |  |
| NET INCOME PER SHARE |  | $ | 0.91 |  |  | $ | 1.05 |  |  | $ | 0.63 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.05 |  |
| Stock-based compensation |  |  | 0.14 |  |  |  | 0.15 |  |  |  | 0.14 |  |
| Restructuring charges |  |  | — |  |  |  | 0.07 |  |  |  | — |  |
| Income tax effects |  |  | (0.04 | ) |  |  | (0.15 | ) |  |  | (0.02 | ) |
| Income tax benefit of ASC 606 adoption |  |  | — |  |  |  | (0.13 | ) |  |  | — |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.06 |  |  | $ | 1.04 |  |  | $ | 0.80 |  |

[0001564590-18-029561:8k_2_02:92]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY19 |  |  | Q1'FY19 |  |  | Q2'FY18 |  |
| Gross margin-GAAP |  |  | 64.2 | % |  |  | 65.3 | % |  |  | 63.6 | % |
| Cost of revenues adjustments |  |  | 0.7 | % |  |  | 0.9 | % |  |  | 0.8 | % |
| Gross margin-Non-GAAP |  |  | 64.9 | % |  |  | 66.2 | % |  |  | 64.5 | % |
| GAAP cost of revenues |  | $ | 543 |  |  | $ | 511 |  |  | $ | 515 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (9 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (2 | ) |  |  | (4 | ) |  |  | (3 | ) |
| Non-GAAP cost of revenues |  | $ | 532 |  |  | $ | 498 |  |  | $ | 503 |  |
| Net revenues |  | $ | 1,517 |  |  | $ | 1,474 |  |  | $ | 1,415 |  |

[0001564590-18-029561:8k_2_02:93]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY19 |  |  | Q1'FY19 |  |  | Q2'FY18 |  |
| Product gross margin-GAAP |  |  | 53.1 | % |  |  | 54.5 | % |  |  | 51.5 | % |
| Cost of product revenues adjustments |  |  | 1.0 | % |  |  | 1.1 | % |  |  | 1.2 | % |
| Product gross margin-Non-GAAP |  |  | 54.1 | % |  |  | 55.7 | % |  |  | 52.7 | % |
| GAAP cost of product revenues |  | $ | 428 |  |  | $ | 398 |  |  | $ | 397 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (9 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 419 |  |  | $ | 388 |  |  | $ | 387 |  |
| Product revenues |  | $ | 913 |  |  | $ | 875 |  |  | $ | 819 |  |

[0001564590-18-029561:8k_2_02:94]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY19 |  |  | Q1'FY19 |  |  | Q2'FY18 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 70.9 | % |  |  | 71.4 | % |  |  | 69.9 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.5 | % |  |  | 0.8 | % |  |  | 0.5 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 71.5 | % |  |  | 72.2 | % |  |  | 70.4 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 107 |  |  | $ | 106 |  |  | $ | 112 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (3 | ) |  |  | (2 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 105 |  |  | $ | 103 |  |  | $ | 110 |  |
| Hardware maintenance and other services revenues |  | $ | 368 |  |  | $ | 370 |  |  | $ | 372 |  |

[0001564590-18-029561:8k_2_02:95]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q2'FY19 |  |  | Q1'FY19 |  |  | Q2'FY18 |  |
| GAAP effective tax rate |  |  | 17.7 | % |  |  | (4.0 | )% |  |  | 21.6 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 0.8 | % |  |  | 9.8 | % |  |  | (2.0 | )% |
| Income tax benefit of ASC 606 adoption |  |  | — | % |  |  | 12.5 | % |  |  | — | % |
| Non-GAAP effective tax rate |  |  | 18.5 | % |  |  | 18.3 | % |  |  | 19.6 | % |

[0001564590-18-029561:8k_2_02:96]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY19 |  |  | Q1'FY19 |  |  | Q2'FY18 |  |
| Net cash provided by operating activities |  | $ | 165 |  |  | $ | 326 |  |  | $ | 314 |  |
| Purchases of property and equipment |  |  | (43 | ) |  |  | (64 | ) |  |  | (29 | ) |
| Free cash flow |  | $ | 122 |  |  | $ | 262 |  |  | $ | 285 |  |

[0001564590-18-029561:8k_2_02:97]
Some items may not add or recalculate due to rounding.

[0001564590-18-029561:8k_2_02:98]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| THIRD QUARTER FISCAL 2019 |  |
|  |  | Third Quarter |  |
|  |  | Fiscal 2019 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $1.12 - $1.18 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Third Quarter Fiscal 2019: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.05 | ) |
| Stock-based compensation expense |  |  | (0.15 | ) |
| Income tax effects |  |  | 0.04 |  |
| Total Adjustments |  |  | (0.16 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.96 - $1.02 |  |

[0001564590-18-029561:8k_2_02:99]
Press Contact:

[0001564590-18-029561:8k_2_02:100]
Madge Miller

[0001564590-18-029561:8k_2_02:101]
NetApp

[0001564590-18-029561:8k_2_02:102]
1 408 419 5263

[0001564590-18-029561:8k_2_02:103]
madge.miller@netapp.com

[0001564590-18-029561:8k_2_02:104]
Investor Contact:

[0001564590-18-029561:8k_2_02:105]
Kris Newton

[0001564590-18-029561:8k_2_02:106]
NetApp

[0001564590-18-029561:8k_2_02:107]
1 408 822 3312

[0001564590-18-029561:8k_2_02:108]
kris.newton@netapp.com
