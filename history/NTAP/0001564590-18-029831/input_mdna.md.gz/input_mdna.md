# NTAP MD&A — 0001564590-18-029831


## mdna

[0001564590-18-029831:mdna:1]
[same as prior period, unchanged from 0001564590-18-022123:mdna:1]

[0001564590-18-029831:mdna:2]
26

[0001564590-18-029831:mdna:3]
[same as prior period, unchanged from 0001564590-18-022123:mdna:2]

[0001564590-18-029831:mdna:4]
[same as prior period, unchanged from 0001564590-18-022123:mdna:3]

[0001564590-18-029831:mdna:5]
[same as prior period, unchanged from 0001564590-18-022123:mdna:4]

[0001564590-18-029831:mdna:6]
[same as prior period, unchanged from 0001564590-18-022123:mdna:5]

[0001564590-18-029831:mdna:7]
[same as prior period, unchanged from 0001564590-18-022123:mdna:6]

[0001564590-18-029831:mdna:8]
[same as prior period, unchanged from 0001564590-18-022123:mdna:7]

[0001564590-18-029831:mdna:9]
[same as prior period, unchanged from 0001564590-18-022123:mdna:8]

[0001564590-18-029831:mdna:10]
[same as prior period, unchanged from 0001564590-18-022123:mdna:9]

[0001564590-18-029831:mdna:11]
[same as prior period, unchanged from 0001564590-18-022123:mdna:10]

[0001564590-18-029831:mdna:12]
[same as prior period, unchanged from 0001564590-18-022123:mdna:11]

[0001564590-18-029831:mdna:13]
[same as prior period, unchanged from 0001564590-18-022123:mdna:12]

[0001564590-18-029831:mdna:14]
[same as prior period, unchanged from 0001564590-18-022123:mdna:13]

[0001564590-18-029831:mdna:15]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we have historically grouped our products by “Strategic” and “Mature” solutions. Strategic solutions include Clustered ONTAP, branded E-Series, SolidFire, converged and hyper-converged infrastructure, enterprise software license agreements (ELAs) and other optional add-on software products. Mature solutions include 7-mode ONTAP, add-on hardware and related operating system (OS) software and original equipment manufacturers (OEM) products. Both our Mature and Strategic product lines include a mix of disk, hybrid and all flash storage media.

[0001564590-18-029831:mdna:16]
[same as prior period, unchanged from 0001564590-18-022123:mdna:15]

[0001564590-18-029831:mdna:17]
[same as prior period, unchanged from 0001564590-18-022123:mdna:16]

[0001564590-18-029831:mdna:18]
[same as prior period, unchanged from 0001564590-18-022123:mdna:17]

[0001564590-18-029831:mdna:19]
[same as prior period, unchanged from 0001564590-18-022123:mdna:18]

[0001564590-18-029831:mdna:20]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Net revenues |  | $ | 1,517 |  |  | $ | 1,415 |  |  | $ | 2,991 |  |  | $ | 2,736 |  |
| Gross profit |  | $ | 974 |  |  | $ | 900 |  |  | $ | 1,937 |  |  | $ | 1,724 |  |
| Gross profit margin percentage |  |  | 64 | % |  |  | 64 | % |  |  | 65 | % |  |  | 63 | % |
| Income from operations |  | $ | 286 |  |  | $ | 216 |  |  | $ | 540 |  |  | $ | 356 |  |
| Income from operations as a percentage of net revenues |  |  | 19 | % |  |  | 15 | % |  |  | 18 | % |  |  | 13 | % |
| Net income |  | $ | 241 |  |  | $ | 174 |  |  | $ | 524 |  |  | $ | 305 |  |
| Diluted net income per share |  | $ | 0.91 |  |  | $ | 0.63 |  |  | $ | 1.96 |  |  | $ | 1.10 |  |
| Operating cash flows |  | $ | 165 |  |  | $ | 314 |  |  | $ | 491 |  |  | $ | 564 |  |

[0001564590-18-029831:mdna:21]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,206 |  |  | $ | 3,363 |  |
| Cash conversion cycle (days) |  |  | (19 | ) |  |  | (14 | ) |

[0001564590-18-029831:mdna:22]
[same as prior period, unchanged from 0001564590-18-022123:mdna:21]

[0001564590-18-029831:mdna:23]
During the first six months of fiscal 2019, we repurchased 14 million shares of our common stock at an average price of $77.94 per share, for an aggregate of $1,061 million. We also declared aggregate cash dividends of $0.80 per share in that period, for which we paid an aggregate of $207 million.

[0001564590-18-029831:mdna:24]
[same as prior period, unchanged from 0001564590-18-022123:mdna:23]

[0001564590-18-029831:mdna:25]
As of the beginning of fiscal 2019, we adopted the new accounting standard Revenue from Contracts with Customers (ASC 606) using the full retrospective method of adoption. Accordingly, our prior period condensed consolidated financial statements and supplementary data, as presented herein, have been restated to conform to the new rules. As illustrated in Note 5 – Revenue of the Notes to Condensed Consolidated Financial Statements, the overall impact of adoption was not significant to prior periods. However, application of the new rules to our ELAs resulted in approximately $20 million and $110 million of product revenues for such arrangements in the second quarter and first six months of fiscal 2019, respectively, that are incremental to the amounts we would have recognized under the old standard. Under ASC 606, we recognize the software license fee component of our ELAs up-front, whereas under the prior rules the software license fee was recognized over the term of the ELA.

[0001564590-18-029831:mdna:26]
[same as prior period, unchanged from 0001564590-18-022123:mdna:27]

[0001564590-18-029831:mdna:27]
[same as prior period, unchanged from 0001564590-18-022123:mdna:28]

[0001564590-18-029831:mdna:28]
The summary of our significant accounting policies is included under Item 7 – Management’s Discussion and Analysis of Financial Condition and Results of Operations of our fiscal 2018 Form 10-K. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. There have been no material changes to the critical accounting policies and estimates as filed in such report, except with respect to revenue recognition as a result of the adoption of ASC 606 in the first quarter of fiscal 2019. Refer to Note 5 – Revenue of the Notes to Condensed Consolidated Financial Statements for details.

[0001564590-18-029831:mdna:29]
[same as prior period, unchanged from 0001564590-18-022123:mdna:31]

[0001564590-18-029831:mdna:30]
[same as prior period, unchanged from 0001564590-18-022123:mdna:32]

[0001564590-18-029831:mdna:31]
[same as prior period, unchanged from 0001564590-18-022123:mdna:30]

[0001564590-18-029831:mdna:32]
[same as prior period, unchanged from 0001564590-18-022123:mdna:33]

[0001564590-18-029831:mdna:33]
[same as prior period, unchanged from 0001564590-18-022123:mdna:34]

[0001564590-18-029831:mdna:34]
[same as prior period, unchanged from 0001564590-18-022123:mdna:35]

[0001564590-18-029831:mdna:35]
|  |  | Three Months Ended |  |  | Six Months Ended |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 60 |  | % |  | 58 |  | % |  | 60 |  | % |  | 57 |  | % |
| Software maintenance |  |  | 16 |  |  |  | 16 |  |  |  | 16 |  |  |  | 16 |  |  |
| Hardware maintenance and other services |  |  | 24 |  |  |  | 26 |  |  |  | 25 |  |  |  | 27 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 28 |  |  |  | 28 |  |  |  | 28 |  |  |  | 28 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | — |  |  |
| Cost of hardware maintenance and other services |  |  | 7 |  |  |  | 8 |  |  |  | 7 |  |  |  | 8 |  |  |
| Gross profit |  |  | 64 |  |  |  | 64 |  |  |  | 65 |  |  |  | 63 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 27 |  |  |  | 30 |  |  |  | 27 |  |  |  | 31 |  |  |
| Research and development |  |  | 14 |  |  |  | 14 |  |  |  | 14 |  |  |  | 14 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | — |  |  |
| Total operating expenses |  |  | 45 |  |  |  | 48 |  |  |  | 47 |  |  |  | 50 |  |  |
| Income from operations |  |  | 19 |  |  |  | 15 |  |  |  | 18 |  |  |  | 13 |  |  |
| Other income, net |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | — |  |  |
| Income before income taxes |  |  | 19 |  |  |  | 16 |  |  |  | 19 |  |  |  | 13 |  |  |
| Provision for income taxes |  |  | 3 |  |  |  | 3 |  |  |  | 1 |  |  |  | 2 |  |  |
| Net income |  |  | 16 |  | % |  | 12 |  | % |  | 18 |  | % |  | 11 |  | % |

[0001564590-18-029831:mdna:36]
[same as prior period, unchanged from 0001564590-18-022123:mdna:37]

[0001564590-18-029831:mdna:37]
[same as prior period, unchanged from 0001564590-18-022123:mdna:38]

[0001564590-18-029831:mdna:38]
[same as prior period, unchanged from 0001564590-18-022123:mdna:39]

[0001564590-18-029831:mdna:39]
Net revenues for the second quarter and first six months of fiscal 2019 were $1,517 million and $2,991 million, respectively, reflecting an increase of $102 million, or 7%, and $255 million, or 9%, respectively, compared to the corresponding periods of the prior year, reflecting higher product revenues.

[0001564590-18-029831:mdna:40]
Gross profit as a percentage of net revenues for the second quarter increased by half of one percentage point compared to the corresponding period in fiscal 2018, and increased almost two percentage points in the first six months of fiscal 2019 when compared to the corresponding period in fiscal 2018, primarily reflecting higher margins on product revenues. Gross profit margins on product revenues increased one and a half percentage points in the second quarter of fiscal 2019 and four percentage points in the first six months of fiscal 2019 compared to the corresponding periods of fiscal 2018, primarily reflecting high margins on revenue recognized during the current year periods related to the software license components of several ELAs, and, to a lesser extent, higher average selling prices (ASPs).

[0001564590-18-029831:mdna:41]
Sales and marketing, research and development, and general and administrative expenses for the second quarter and the first six months of fiscal 2019 totaled $688 million, or 45% of net revenues and $1,378 million, or 46% of net revenues, respectively, representing a decrease of three percentage points and four percentage points when compared to the second quarter and the first six months of fiscal 2019, respectively, primarily due to higher net revenues in the current year periods.

[0001564590-18-029831:mdna:42]
[same as prior period, unchanged from 0001564590-18-022123:mdna:43]

[0001564590-18-029831:mdna:43]
[same as prior period, unchanged from 0001564590-18-022123:mdna:44]

[0001564590-18-029831:mdna:44]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |
| Net revenues |  | $ | 1,517 |  |  | $ | 1,415 |  |  |  | 7 | % |  | $ | 2,991 |  |  | $ | 2,736 |  |  |  | 9 | % |

[0001564590-18-029831:mdna:45]
The increase in net revenues for the second quarter and first six months of fiscal 2019 compared to the corresponding periods of fiscal 2018 was primarily due to an increase in product revenues of $94 million and $242 million, respectively. Product revenues as a percentage of net revenues increased two percentage points and three percentage points in the second quarter and first six months of fiscal 2019, respectively, compared to the corresponding periods of fiscal 2018.

[0001564590-18-029831:mdna:46]
[same as prior period, unchanged from 0001564590-18-022123:mdna:47]

[0001564590-18-029831:mdna:47]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 22 | % |  |  | 23 | % |  |  | 23 | % |
| Tech Data Corporation |  |  | 21 | % |  |  | 19 | % |  |  | 19 | % |  |  | 20 | % |

[0001564590-18-029831:mdna:48]
[same as prior period, unchanged from 0001564590-18-022123:mdna:49]

[0001564590-18-029831:mdna:49]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |
| Product revenues |  | $ | 913 |  |  | $ | 819 |  |  |  | 11 | % |  | $ | 1,788 |  |  | $ | 1,546 |  |  |  | 16 | % |

[0001564590-18-029831:mdna:50]
Product revenues are derived through the sale of our strategic and mature solutions, and consist of sales of configured systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, original equipment manufacturer (OEM) products and add-on hardware and software.

[0001564590-18-029831:mdna:51]
Product revenues from strategic solutions represented 71% of product revenues in the second quarter and first six months of fiscal 2019, compared to 69% in the corresponding periods of the prior year. Product revenues from mature solutions represented 29% of product revenues in the second quarter and first six months of fiscal 2019, compared to 31% in the corresponding periods of the prior year.

[0001564590-18-029831:mdna:52]
Total product revenues from strategic solutions totaled $649 million in the second quarter of fiscal 2019 reflecting a 15% increase from $566 million in the second quarter of fiscal 2018. Total product revenues from strategic solutions totaled $1,261 million in the first six months of fiscal 2019 reflecting a 19% increase from $1,064 million in the first six months of fiscal 2018. Contributing to these increases was over $20 million and $110 million of revenues from the software license component of several ELAs in the second quarter and first six months of fiscal 2019, respectively, which, under ASC 606, were recognized up-front. There were no comparable ELAs in the second quarter or first six months of fiscal 2018. Revenues generated from the sale of optional add-on software, unrelated to ELAs, also increased in the second quarter and first six months of fiscal 2019 compared to the corresponding periods of the prior year.

[0001564590-18-029831:mdna:53]
Total product revenue from mature solutions totaled $264 million in the second quarter of fiscal 2019 reflecting a 4% increase from $253 million in the second quarter of fiscal 2018. Total product revenue from mature solutions totaled $527 million in the first six months of fiscal 2019 reflecting a 9% increase from $482 million in the first six months of fiscal 2018. These increases are primarily due to an increase in add-on hardware, storage and related OS revenues of 11% and 14% in the second quarter and first six months of fiscal 2019, respectively, compared to the corresponding periods of prior year. Additionally, OEM revenues increased by 6% and 25% in the second quarter and first six months of fiscal 2019, respectively, compared to the corresponding periods of the prior year. These increases were partially offset by our discontinuation of the 7-mode systems in the first quarter of fiscal 2019, reflecting the movement of customers to our newer products.

[0001564590-18-029831:mdna:54]
[same as prior period, unchanged from 0001564590-18-022123:mdna:55]

[0001564590-18-029831:mdna:55]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 236 |  |  | $ | 224 |  |  |  | 5 | % |  | $ | 465 |  |  | $ | 447 |  |  |  | 4 | % |

[0001564590-18-029831:mdna:56]
[same as prior period, unchanged from 0001564590-18-022123:mdna:59]

[0001564590-18-029831:mdna:57]
[same as prior period, unchanged from 0001564590-18-022123:mdna:57]

[0001564590-18-029831:mdna:58]
[same as prior period, unchanged from 0001564590-18-022123:mdna:58]

[0001564590-18-029831:mdna:59]
[same as prior period, unchanged from 0001564590-18-022123:mdna:60]

[0001564590-18-029831:mdna:60]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 368 |  |  | $ | 372 |  |  |  | (1 | )% |  | $ | 738 |  |  | $ | 743 |  |  |  | (1 | )% |

[0001564590-18-029831:mdna:61]
[same as prior period, unchanged from 0001564590-18-022123:mdna:62]

[0001564590-18-029831:mdna:62]
Hardware maintenance contract revenues were relatively flat year over year, at $303 million and $606 million, respectively, for the second quarter and first six months of fiscal 2019, compared to $306 million and $604 million, respectively, for the corresponding periods of the prior year.

[0001564590-18-029831:mdna:63]
Professional services and educational and training services revenues were $65 million and $132 million, respectively, for the second quarter and first six months of fiscal 2019, compared to $66 million and $139 million, respectively, for the corresponding periods of the prior year.

[0001564590-18-029831:mdna:64]
[same as prior period, unchanged from 0001564590-18-022123:mdna:65]

[0001564590-18-029831:mdna:65]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| United States, Canada and Latin America (Americas) |  |  | 57 | % |  |  | 56 | % |  |  | 57 | % |  |  | 55 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 28 | % |  |  | 30 | % |  |  | 29 | % |  |  | 30 | % |
| Asia Pacific (APAC) |  |  | 15 | % |  |  | 14 | % |  |  | 14 | % |  |  | 14 | % |

[0001564590-18-029831:mdna:66]
[same as prior period, unchanged from 0001564590-18-022123:mdna:67]

[0001564590-18-029831:mdna:67]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Our geographic distribution of revenues as a percentage of net revenues was relatively consistent in the second quarter and first six months of fiscal 2019 compared to the corresponding periods of fiscal 2018.

[0001564590-18-029831:mdna:68]
[same as prior period, unchanged from 0001564590-18-022123:mdna:69]

[0001564590-18-029831:mdna:69]
[same as prior period, unchanged from 0001564590-18-022123:mdna:70]

[0001564590-18-029831:mdna:70]
[same as prior period, unchanged from 0001564590-18-022123:mdna:71]

[0001564590-18-029831:mdna:71]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |
| Cost of product revenues |  | $ | 428 |  |  | $ | 397 |  |  |  | 8 | % |  | $ | 826 |  |  | $ | 773 |  |  |  | 7 | % |

[0001564590-18-029831:mdna:72]
[same as prior period, unchanged from 0001564590-18-022123:mdna:73]

[0001564590-18-029831:mdna:73]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2019 to Fiscal 2018 |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | 8 |  |  |  | 6 |  |
| Other |  |  | — |  |  |  | 1 |  |
| Total change |  |  | 8 |  |  |  | 7 |  |

[0001564590-18-029831:mdna:74]
31

[0001564590-18-029831:mdna:75]
Cost of product revenues represented 47% and 46% of product revenues for the second quarter and first six months of fiscal 2019, respectively, compared to 48% and 50% for the corresponding periods of fiscal 2018. Materials costs represented 91% and 89% of product costs for the second quarter and first six months of fiscal 2019, respectively, compared to 91% and 90% in the corresponding periods of fiscal 2018.

[0001564590-18-029831:mdna:76]
Materials costs increased $31 million and $47 million in the second quarter and first six months of fiscal 2019, respectively, compared to the corresponding periods of the prior year, primarily due to higher unit volumes of certain products.

[0001564590-18-029831:mdna:77]
Average unit materials costs for Clustered ONTAP systems increased by 12% and 13% in the second quarter and first six months of fiscal 2019, respectively, compared to the corresponding periods of the prior year.

[0001564590-18-029831:mdna:78]
Margins on revenue recognized for strategic solutions were higher during the second quarter and first six months of fiscal 2019 compared to the corresponding periods of fiscal 2018 primarily as a result of the benefit of high margins realized on the software license components of several ELAs, and, to a lesser extent, higher ASPs. Margins for mature products increased slightly in the second quarter and first six months of fiscal 2019 compared to the corresponding periods of the prior year.

[0001564590-18-029831:mdna:79]
[same as prior period, unchanged from 0001564590-18-022123:mdna:79]

[0001564590-18-029831:mdna:80]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 8 |  |  | $ | 6 |  |  |  | 33 | % |  | $ | 15 |  |  | $ | 13 |  |  |  | 15 | % |

[0001564590-18-029831:mdna:81]
Cost of software maintenance revenues in dollars was relatively flat in the second quarter and first six months of fiscal 2019 compared to the corresponding periods of fiscal 2018 and represented 3% of software maintenance revenues for both periods.

[0001564590-18-029831:mdna:82]
[same as prior period, unchanged from 0001564590-18-022123:mdna:82]

[0001564590-18-029831:mdna:83]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 107 |  |  | $ | 112 |  |  |  | (4 | )% |  | $ | 213 |  |  | $ | 226 |  |  |  | (6 | )% |

[0001564590-18-029831:mdna:84]
Cost of hardware maintenance and other services revenues decreased by $5 million, or 4%, and $13 million, or 6%, respectively, for the second quarter and first six months of fiscal 2019 compared to the corresponding periods of fiscal 2018, primarily due to the favorable impact of cost savings initiatives. Costs represented 29% of hardware maintenance and other services revenues in the second quarter and first six months of fiscal 2019, compared to 30% in the second quarter and first six months of fiscal 2018.

[0001564590-18-029831:mdna:85]
[same as prior period, unchanged from 0001564590-18-022123:mdna:85]

[0001564590-18-029831:mdna:86]
[same as prior period, unchanged from 0001564590-18-022123:mdna:86]

[0001564590-18-029831:mdna:87]
[same as prior period, unchanged from 0001564590-18-022123:mdna:87]

[0001564590-18-029831:mdna:88]
Total compensation costs included in operating expenses increased by $5 million and $10 million in the second quarter and first six months of fiscal 2019, respectively, compared to the corresponding periods of the prior year, each representing an increase of 1%. Stock-based compensation expenses decreased slightly in the current year, while the other components of compensation costs increased slightly. Average headcount was relatively flat in each period.

[0001564590-18-029831:mdna:89]
[same as prior period, unchanged from 0001564590-18-022123:mdna:89]

[0001564590-18-029831:mdna:90]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 408 |  |  | $ | 421 |  |  |  | (3 | )% |  | $ | 817 |  |  | $ | 844 |  |  |  | (3 | )% |

[0001564590-18-029831:mdna:91]
[same as prior period, unchanged from 0001564590-18-022123:mdna:91]

[0001564590-18-029831:mdna:92]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2019 to Fiscal 2018 |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (1 | ) |  |  | (1 | ) |
| Facilities and IT support costs |  |  | (1 | ) |  |  | (2 | ) |
| Other |  |  | (1 | ) |  |  | — |  |
| Total change |  |  | (3 | ) |  |  | (3 | ) |

[0001564590-18-029831:mdna:93]
Compensation costs decreased for the second quarter and first six months of fiscal 2019 compared to the corresponding periods of the prior year, reflecting a 2% decrease in average headcount in each of the current year periods. Facilities and IT support costs decreased in fiscal 2019 primarily due to cost containment efforts. Commissions expense was relatively consistent in each of the respective comparative periods.

[0001564590-18-029831:mdna:94]
[same as prior period, unchanged from 0001564590-18-022123:mdna:95]

[0001564590-18-029831:mdna:95]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |
| Research and development expenses |  | $ | 211 |  |  | $ | 194 |  |  |  | 9 | % |  | $ | 419 |  |  | $ | 387 |  |  |  | 8 | % |

[0001564590-18-029831:mdna:96]
[same as prior period, unchanged from 0001564590-18-022123:mdna:97]

[0001564590-18-029831:mdna:97]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2019 to Fiscal 2018 |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 5 |  |  |  | 5 |  |
| Development projects and outside services |  |  | 3 |  |  |  | 3 |  |
| Other |  |  | 1 |  |  |  | — |  |
| Total change |  |  | 9 |  |  |  | 8 |  |

[0001564590-18-029831:mdna:98]
The increase in compensation costs for the second quarter and first six months of fiscal 2019 compared to the corresponding periods in the prior year was attributable to an increase in average headcount of 6% and 7%, respectively, resulting in higher salaries, benefits and incentive compensation expense, partially offset by slightly lower stock-based compensation expense. The increase in headcount reflects our investment in additional engineering resources to support the expansion and enhancement of products and solutions targeted at our most important customer and market opportunities. Development projects and outside services for the second quarter and first six months of fiscal 2019 increased as a result of higher spending on materials and services associated with engineering activities to develop new products and enhance existing ones.

[0001564590-18-029831:mdna:99]
[same as prior period, unchanged from 0001564590-18-022123:mdna:100]

[0001564590-18-029831:mdna:100]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |
| General and administrative expenses |  | $ | 69 |  |  | $ | 69 |  |  |  | — | % |  | $ | 142 |  |  | $ | 137 |  |  |  | 4 | % |

[0001564590-18-029831:mdna:101]
33

[0001564590-18-029831:mdna:102]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and allocated facilities and IT support costs. Changes in general and administrative expense consisted of the following:

[0001564590-18-029831:mdna:103]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2019 to Fiscal 2018 |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 1 |  |  |  | 1 |  |
| Professional and legal fees and outside services |  |  | (3 | ) |  |  | (1 | ) |
| Facilities and IT support costs |  |  | 2 |  |  |  | 2 |  |
| Other |  |  | — |  |  |  | 2 |  |
| Total change |  |  | — |  |  |  | 4 |  |

[0001564590-18-029831:mdna:104]
The increase in compensation costs for the second quarter and first six months of fiscal 2019 compared to the corresponding periods of the prior year was attributable to a slight increase in average headcount, while the increase in facilities and IT support costs was primarily due to higher spending levels on IT projects. The decrease in professional and legal fees and outside services expense in the second quarter and the first six months of fiscal 2019 was primarily due to the lower spending levels on projects.

[0001564590-18-029831:mdna:105]
[same as prior period, unchanged from 0001564590-18-022123:mdna:103]

[0001564590-18-029831:mdna:106]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |
| Restructuring charges |  | $ | — |  |  | $ | — |  |  | NM |  | $ | 19 |  |  | $ | — |  |  | NM |

[0001564590-18-029831:mdna:107]
[same as prior period, unchanged from 0001564590-18-022123:mdna:105]

[0001564590-18-029831:mdna:108]
In the first quarter of fiscal 2019, we announced a restructuring plan (the May 2018 Plan) to reduce costs and redirect resources to our highest return activities, which included a reduction in our global workforce of less than 2%. Charges related to the plan consisted primarily of employee severance-related costs. Substantially all activities under the plan have been completed. See Note 11 – Restructuring Charges of the Notes to Condensed Consolidated Financial Statements for more details.

[0001564590-18-029831:mdna:109]
[same as prior period, unchanged from 0001564590-18-022123:mdna:107]

[0001564590-18-029831:mdna:110]
[same as prior period, unchanged from 0001564590-18-022123:mdna:108]

[0001564590-18-029831:mdna:111]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |
| Interest income |  | $ | 21 |  |  | $ | 19 |  |  |  | 11 | % |  | $ | 46 |  |  | $ | 35 |  |  |  | 31 | % |
| Interest expense |  |  | (14 | ) |  |  | (17 | ) |  |  | (18 | )% |  |  | (28 | ) |  |  | (30 | ) |  |  | (7 | )% |
| Other income, net |  |  | — |  |  |  | 4 |  |  |  | (100 | )% |  |  | 7 |  |  |  | 6 |  |  |  | 17 | % |
| Total |  | $ | 7 |  |  | $ | 6 |  |  |  | 17 | % |  | $ | 25 |  |  | $ | 11 |  |  |  | 127 | % |

[0001564590-18-029831:mdna:112]
Interest income increased in the second quarter and first six months of fiscal 2019 compared to the corresponding periods of the prior year, primarily due to a shift in our investment portfolio to higher-yielding investments, partially offset by a decrease in the size of the portfolio. Interest expense declined in the current year periods due to a reduction in the average amount of interest-bearing debt outstanding.

[0001564590-18-029831:mdna:113]
Provision for Income Taxes (in millions, except percentages):

[0001564590-18-029831:mdna:114]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | % Change |  |
| Provision for income taxes |  | $ | 52 |  |  | $ | 48 |  |  |  | 8 | % |  | $ | 41 |  |  | $ | 62 |  |  |  | (34 | )% |

[0001564590-18-029831:mdna:115]
Our effective tax rate for the second quarter of fiscal 2019 was 17.7% compared to an effective tax rate of 21.6% for the second quarter of fiscal 2018. Our effective tax rate for the first six months of fiscal 2019 was 7.3% compared to an effective tax rate of 16.9% for the corresponding period of fiscal 2018. Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations which are headquartered in the Netherlands, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rate decreased for the second quarter of fiscal 2019 compared to the corresponding period in the prior year primarily due the reduction of the federal income tax rate under U.S. tax reform and discrete impacts related to stock-based compensation. Our effective tax rate decreased for the first six months of fiscal 2019 compared to the corresponding period in the prior year primarily due to the recognition of a $34 million discrete tax benefit for adjustments to certain intercompany transactions resulting from the retrospective application of the new revenue standard, increased discrete benefits for stock-based compensation, and the reduction in the federal income tax rate.

[0001564590-18-029831:mdna:116]
On December 22, 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, the imposition of a one-time transition tax on deferred foreign earnings, and the creation of new taxes on certain foreign-sourced earnings. As of October 26, 2018, we have not fully completed the accounting for the tax impacts of the TCJA. No significant adjustments to prior period estimates or positions have been made in the current period. The provisional amounts recorded are based on reasonable estimates and our current interpretation and understanding of the TCJA. The final impacts of U.S. tax reform may differ, possibly materially, due to factors such as the issuance of further regulatory guidance, changes in interpretations, and the collection and analysis of additional information. The Company is also still evaluating the effects of the TCJA’s global minimum tax on intangible low-taxed income (“GILTI”) and has not yet made an accounting policy election to either account for the tax under a period cost method or a deferred method. For the first six months ended October 26, 2018, we have accounted for the GILTI tax under a period cost method as we continue to evaluate potential impacts. In accordance with Staff Accounting Bulletin 118, we will complete the accounting of the tax effects of the TCJA within the measurement period not to extend beyond one year from the enactment date.

[0001564590-18-029831:mdna:117]
As of October 26, 2018, we had $356 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $306 million would affect our provision for income taxes if recognized, and $324 million has been recorded in other long-term liabilities.

[0001564590-18-029831:mdna:118]
[same as prior period, unchanged from 0001564590-18-022123:mdna:116]

[0001564590-18-029831:mdna:119]
[same as prior period, unchanged from 0001564590-18-022123:mdna:117]

[0001564590-18-029831:mdna:120]
| (In millions, except percentages) |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Cash, cash equivalents and short-term investments |  | $ | 4,299 |  |  | $ | 5,391 |  |
| Principal amount of debt |  | $ | 1,800 |  |  | $ | 1,935 |  |

[0001564590-18-029831:mdna:121]
[same as prior period, unchanged from 0001564590-18-022123:mdna:119]

[0001564590-18-029831:mdna:122]
|  |  | Six Months Ended |  |
| (In millions) |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Net cash provided by operating activities |  | $ | 491 |  |  | $ | 564 |  |
| Net cash provided by (used in) investing activities |  |  | 381 |  |  |  | (92 | ) |
| Net cash provided by (used in) financing activities |  |  | (1,429 | ) |  |  | 601 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (25 | ) |  |  | 13 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | (582 | ) |  | $ | 1,086 |  |

[0001564590-18-029831:mdna:123]
35

[0001564590-18-029831:mdna:124]
[same as prior period, unchanged from 0001564590-18-022123:mdna:121]

[0001564590-18-029831:mdna:125]
As of October 26, 2018, our cash, cash equivalents and short-term investments were $4.3 billion, a decrease of $1.1 billion from April 27, 2018. The decrease was primarily due to $1.1 billion paid for the repurchase of our common stock, $207 million used for the payment of dividends, $135 million used for the net repayment of commercial paper notes, and $107 million in purchases of property and equipment, partially offset by $491 million of cash provided by operating activities. Working capital decreased by $1.3 billion to $2.2 billion as of October 26, 2018 compared to April 27, 2018 primarily due to the decreases in cash, cash equivalents and short-term investments discussed above, and the reclassification of $400 million principal amount of our senior notes to current liabilities.

[0001564590-18-029831:mdna:126]
[same as prior period, unchanged from 0001564590-18-022123:mdna:123]

[0001564590-18-029831:mdna:127]
[same as prior period, unchanged from 0001564590-18-022123:mdna:124]

[0001564590-18-029831:mdna:128]
|  |  | Three Months Ended |  |
| (In days) |  | October 26, 2018 |  |  | April 27, 2018 |  |  | October 27, 2017 |  |
| Days sales outstanding (1) |  |  | 46 |  |  |  | 58 |  |  |  | 39 |  |
| Days inventory outstanding (2) |  |  | 14 |  |  |  | 18 |  |  |  | 18 |  |
| Days payables outstanding (3) |  |  | (79 | ) |  |  | (90 | ) |  |  | (67 | ) |
| Cash conversion cycle (4) |  |  | (19 | ) |  |  | (14 | ) |  |  | (10 | ) |

[0001564590-18-029831:mdna:129]
[same as prior period, unchanged from 0001564590-18-022123:mdna:126]

[0001564590-18-029831:mdna:130]
| (1) | Days sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on ending accounts receivable and net revenue for each period. DSO is calculated by dividing accounts receivable by average net revenue per day for the current quarter (91 days for each of the quarters presented above). DSO for the second quarter of fiscal 2019 increased compared to the corresponding period of fiscal 2018 due to one of our major distributors choosing not to take advantage of an early payment discount in the current quarter, while it decreased compared to the fourth quarter of fiscal 2018 due to lower seasonal invoicing levels and more favorable shipping linearity. |

[0001564590-18-029831:mdna:131]
| (2) | Days inventory outstanding, referred to as DIO, measures the average number of days from procurement to sale of our products. DIO is based on ending inventory and cost of revenues for each period. DIO is calculated by dividing ending inventory by average cost of revenues per day for the current quarter. DIO for the second quarter of fiscal 2019 decreased compared to the corresponding period of fiscal 2018 and the fourth quarter of fiscal 2018, primarily due to lower levels of purchased components and finished goods, respectively, on hand at the end of the current quarter. |

[0001564590-18-029831:mdna:132]
| (3) | Days payables outstanding, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and cost of revenues for each period. DPO is calculated by dividing accounts payable by average cost of revenues per day for the current quarter. DPO for the second quarter of fiscal 2019 increased compared to the corresponding period of fiscal 2018, due to differences in the timing of purchases from and payments to our suppliers. DPO for the second quarter of fiscal 2019 decreased compared to the fourth quarter of 2018, primarily due to the timing of purchases from contract manufacturers. |

[0001564590-18-029831:mdna:133]
[same as prior period, unchanged from 0001564590-18-022123:mdna:130]

[0001564590-18-029831:mdna:134]
[same as prior period, unchanged from 0001564590-18-022123:mdna:131]

[0001564590-18-029831:mdna:135]
During the first six months of fiscal 2019, we generated cash from operating activities of $491 million, reflecting net income of $524 million, adjusted by non-cash depreciation and amortization of $98 million, and stock-based compensation of $78 million, compared to $564 million of cash generated from operating activities during the first six months of fiscal 2018.

[0001564590-18-029831:mdna:136]
Changes in assets and liabilities in the first six months of fiscal 2019 included the following:

[0001564590-18-029831:mdna:137]
|  | • | Accounts receivable decreased $269 million, reflecting lower DSO. |

[0001564590-18-029831:mdna:138]
|  | • | Accounts payable decreased $127 million, reflecting lower DPO. |

[0001564590-18-029831:mdna:139]
|  | • | Accrued expenses decreased $162 million, primarily due to employee compensation payouts related to fiscal year 2018 commissions and incentive compensation plans. |

[0001564590-18-029831:mdna:140]
|  | • | Deferred revenue and financed unearned services revenue decreased $129 million, primarily due to a decrease in deferred software and hardware maintenance contract revenues reflecting the seasonality of maintenance contract renewal activities. |

[0001564590-18-029831:mdna:141]
|  | • | Long-term taxes payable decreased $63 million, primarily due to transition taxes associated with U.S. tax reform. |

[0001564590-18-029831:mdna:142]
[same as prior period, unchanged from 0001564590-18-022123:mdna:137]

[0001564590-18-029831:mdna:143]
[same as prior period, unchanged from 0001564590-18-022123:mdna:138]

[0001564590-18-029831:mdna:144]
During the first six months of fiscal 2019, we generated $489 million from maturities and sales of investments, net of purchases, and paid $107 million for capital expenditures, compared to $48 million and $65 million, respectively, during the first six months of fiscal 2018.

[0001564590-18-029831:mdna:145]
[same as prior period, unchanged from 0001564590-18-022123:mdna:140]

[0001564590-18-029831:mdna:146]
During the first six months of fiscal 2019, we used $1.1 billion for the repurchase of fourteen million shares of our common stock, $207 million for the payment of dividends, and $135 million for the repayment of commercial paper notes, net, compared to $300 million used for the repurchase of seven million shares of common stock, $108 million used for the payment of dividends, $218 million generated from issuances of commercial paper notes, net, and $795 million generated from the issuance of long-term debt during the first six months of fiscal 2018.

[0001564590-18-029831:mdna:147]
[same as prior period, unchanged from 0001564590-18-022123:mdna:142]

[0001564590-18-029831:mdna:148]
[same as prior period, unchanged from 0001564590-18-022123:mdna:143]

[0001564590-18-029831:mdna:149]
Our principal sources of liquidity as of October 26, 2018 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001564590-18-029831:mdna:150]
[same as prior period, unchanged from 0001564590-18-022123:mdna:145]

[0001564590-18-029831:mdna:151]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Cash and cash equivalents |  | $ | 2,359 |  |  | $ | 2,941 |  |
| Short-term investments |  |  | 1,940 |  |  |  | 2,450 |  |
| Total |  | $ | 4,299 |  |  | $ | 5,391 |  |

[0001564590-18-029831:mdna:152]
As of October 26, 2018 and April 27, 2018, $3.9 billion and $4.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.4 billion and $0.9 billion, respectively, were available in the U.S. at the end of each period. The TCJA imposes a one-time transition tax on substantially all accumulated foreign earnings through December 31, 2017, and generally allows companies to make distributions of foreign earnings without incurring additional federal taxes. As a part of the provisional estimates recorded for the impacts of the TCJA, we have reviewed our projected global cash requirements and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested.

[0001564590-18-029831:mdna:153]
[same as prior period, unchanged from 0001564590-18-022123:mdna:148]

[0001564590-18-029831:mdna:154]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of October 26, 2018.

[0001564590-18-029831:mdna:155]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total

[0001564590-18-029831:mdna:156]
and domestically, including the following: working capital needs, capital expenditures, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, and other liquidity requirements associated with our operations. We also have an automatic shelf registration statement on file with the Securities and Exchange Commission (SEC). We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001564590-18-029831:mdna:157]
[same as prior period, unchanged from 0001564590-18-022123:mdna:151]

[0001564590-18-029831:mdna:158]
The following table summarizes the principal amount of our Senior Notes as of October 26, 2018 (in millions):

[0001564590-18-029831:mdna:159]
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| Total |  | $ | 1,550 |  |

[0001564590-18-029831:mdna:160]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 8 – Financing Arrangements of the Notes to Condensed Consolidated Financial Statements.

[0001564590-18-029831:mdna:161]
Commercial Paper Program and Credit Facility

[0001564590-18-029831:mdna:162]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of October 26, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $250 million, a weighted-average interest rate of 2.45% and maturities ranging from 4 days to 31 days.

[0001564590-18-029831:mdna:163]
In connection with the Program, we have a senior unsecured credit agreement that expires on December 10, 2021. The credit agreement provides a $1.0 billion revolving unsecured credit facility that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes, providing another potential source of liquidity to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement also includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of October 26, 2018, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-18-029831:mdna:164]
[same as prior period, unchanged from 0001564590-18-022123:mdna:158]

[0001564590-18-029831:mdna:165]
[same as prior period, unchanged from 0001564590-18-022123:mdna:159]

[0001564590-18-029831:mdna:166]
[same as prior period, unchanged from 0001564590-18-022123:mdna:160]

[0001564590-18-029831:mdna:167]
On November 14, 2018, we declared a cash dividend of $0.40 per share of common stock, payable on January 23, 2019 to holders of record as of the close of business on January 4, 2019.

[0001564590-18-029831:mdna:168]
Our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through October 26, 2018, we repurchased a total of 298 million shares of our common stock at an average price of $35.87 per share, for an aggregate purchase price of $10.7 billion. As of October 26, 2018, the remaining authorized amount for stock repurchases under this program was $2.9 billion.

[0001564590-18-029831:mdna:169]
[same as prior period, unchanged from 0001564590-18-022123:mdna:163]

[0001564590-18-029831:mdna:170]
[same as prior period, unchanged from 0001564590-18-022123:mdna:164]

[0001564590-18-029831:mdna:171]
[same as prior period, unchanged from 0001564590-18-022123:mdna:165]

[0001564590-18-029831:mdna:172]
As of October 26, 2018, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $172 million.

[0001564590-18-029831:mdna:173]
[same as prior period, unchanged from 0001564590-18-022123:mdna:168]

[0001564590-18-029831:mdna:174]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 26, 2018, we had $422 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-18-029831:mdna:175]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of October 26, 2018, we had $5 million in construction related obligations and $187 million in other purchase obligations.

[0001564590-18-029831:mdna:176]
[same as prior period, unchanged from 0001564590-18-022123:mdna:171]

[0001564590-18-029831:mdna:177]
As of October 26, 2018, our liability for uncertain tax positions was $324 million, including interest, penalties and certain income tax benefits. Due to uncertainties regarding tax audits and their possible outcomes, we are unable to make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-18-029831:mdna:178]
[same as prior period, unchanged from 0001564590-18-022123:mdna:173]

[0001564590-18-029831:mdna:179]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $43 million and $49 million of receivables during the six months ended October 26, 2018 and October 27, 2017, respectively.

[0001564590-18-029831:mdna:180]
[same as prior period, unchanged from 0001564590-18-022123:mdna:175]

[0001564590-18-029831:mdna:181]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of October 26, 2018 and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-18-029831:mdna:182]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of October 26, 2018, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-18-029831:mdna:183]
39

[0001564590-18-029831:mdna:184]
[same as prior period, unchanged from 0001564590-18-022123:mdna:178]

[0001564590-18-029831:mdna:185]
[same as prior period, unchanged from 0001564590-18-022123:mdna:179]

[0001564590-18-029831:mdna:186]
Legal Contingencies

[0001564590-18-029831:mdna:187]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0001564590-18-029831:mdna:188]
40
