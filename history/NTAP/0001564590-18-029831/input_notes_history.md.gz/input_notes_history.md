# NTAP note change history — 0001564590-18-022123 → 0001564590-18-029831


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-19):
[0001564590-18-029831:note_history:1]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $172 million as of October 26, 2018.
  (was, 2018-08-21, similarity 0.977):
[0001564590-18-022123:note_history:1]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $184 million as of July 27, 2018.

- changed (2018-11-19):
[0001564590-18-029831:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 26, 2018, we had $422 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 26, 2018 and April 27, 2018, such liability amounted to $16 million and $14 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2018-08-21, similarity 0.9889):
[0001564590-18-022123:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 27, 2018, we had $382 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 27, 2018 and April 27, 2018, such liability amounted to $22 million and $14 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2018-11-19):
[0001564590-18-029831:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 26, 2018, we had $5 million in construction related obligations and $187 million in other purchase obligations.
  (was, 2018-08-21, similarity 0.9849):
[0001564590-18-022123:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 27, 2018, we had $5 million in construction related obligations and $195 million in other purchase obligations.

- changed (2018-11-19):
[0001564590-18-029831:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $43 million and $49 million of receivables during the six months ended October 26, 2018 and October 27, 2017, respectively.
  (was, 2018-08-21, similarity 0.9713):
[0001564590-18-022123:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $30 million and $31 million of receivables during the three months ended July 27, 2018 and July 28, 2017, respectively.

- changed (2018-11-19):
[0001564590-18-029831:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of October 26, 2018 and April 27, 2018, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2018-08-21, similarity 0.7916):
[0001564590-18-022123:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of July 27, 2018 and April 27, 2018, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- added (2018-11-19):
[0001564590-18-029831:note_history:6]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 26, 2018, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- changed (2018-11-19):
[0001564590-18-029831:note_history:7]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of October 26, 2018 related to such matters.
  (was, 2018-08-21, similarity 0.9938):
[0001564590-18-022123:note_history:7]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of July 27, 2018 related to such matters.

- removed (2018-11-19):
[0001564590-18-022123:note_history:8]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 27, 2018, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-19):
[0001564590-18-029831:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 27, 2018 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 26, 2018 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2018-08-21, similarity 0.8761):
[0001564590-18-022123:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 27, 2018 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 27, 2018 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- changed (2018-11-19):
[0001564590-18-029831:note_history:10]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard, Revenue from Contracts with Customers (ASC 606), which establishes a comprehensive new revenue recognition model designed to depict the transfer of goods or services to a customer in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In the first quarter of fiscal 2019, we adopted this new standard using the full retrospective method of adoption. Accordingly, our prior period condensed consolidated financial statements and information, as presented herein, have been restated to conform to the new rules. Refer to Note 5 – Revenue for a summary of the impacts of adopting this standard, and a discussion of our updated policies related to revenue recognition.
  (was, 2018-08-21, similarity 0.97):
[0001564590-18-022123:note_history:10]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard, Revenue from Contracts with Customers (ASC 606), which establishes a comprehensive new revenue recognition model designed to depict the transfer of goods or services to a customer in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In the three months ended July 27, 2018, we adopted this new standard using the full retrospective method of adoption. Accordingly, our prior period condensed consolidated financial statements and information, as presented herein, have been restated to conform to the new rules. Refer to Note 6 – Revenue for a summary of the impacts of adopting this standard, and a discussion of our updated policies related to revenue recognition.

- changed (2018-11-19):
[0001564590-18-029831:note_history:11]
In October 2016, the FASB issued an accounting standards update (ASU) which eliminates the deferred tax effects of intra-entity asset transfers other than inventory. As a result, tax expense from the sale of an asset in the seller’s tax jurisdiction is recognized when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. In the first quarter of fiscal 2019, we adopted this ASU using a modified retrospective transition approach and recorded a cumulative-effect adjustment to decrease retained earnings by $51 million, with a corresponding reduction of prepaid taxes, which were classified as other non-current assets on our condensed consolidated balance sheets.
  (was, 2018-08-21, similarity 0.9429):
[0001564590-18-022123:note_history:11]
In October 2016, the FASB issued an accounting standards update (ASU) which eliminates the deferred tax effects of intra-entity asset transfers other than inventory. As a result, tax expense from the sale of an asset in the seller’s tax jurisdiction is recognized when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. In the three months ended July 27, 2018, we adopted this ASU using a modified retrospective transition approach and recorded a cumulative-effect adjustment to decrease retained earnings by $51 million, with a corresponding reduction of prepaid taxes, which were classified as other non-current assets on our condensed consolidated balance sheets, as of the beginning of the period.

- changed (2018-11-19):
[0001564590-18-029831:note_history:12]
In November 2016, the FASB issued an ASU that requires a statement of cash flows to explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. In the first quarter of fiscal 2019, we adopted this ASU using a retrospective transition method. Accordingly, our condensed consolidated statement of cash flows for the three and six months ended October 27, 2017, as presented herein, has been restated to comply with the new requirements. Refer to Note 4 – Supplemental Financial Information for a detail of the components of our cash, cash equivalents and restricted cash balances.
  (was, 2018-08-21, similarity 0.6065):
[0001564590-18-022123:note_history:12]
In November 2016, the FASB issued an ASU that requires a statement of cash flows to explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. In the three months ended July 27, 2018, we adopted this ASU using a retrospective transition method. Accordingly, our condensed consolidated statement of cash flows for the three months ended July 28, 2017, as presented herein, has been restated to comply with the new requirements. Refer to Note 5 – Supplemental Financial Information for a detail of the components of our cash, cash equivalents and restricted cash balances.

- changed (2018-11-19):
[0001564590-18-029831:note_history:13]
There have been no other significant changes in our significant accounting policies as of and for the six months ended October 26, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 27, 2018.
  (was, 2018-08-21, similarity 0.9634):
[0001564590-18-022123:note_history:13]
There have been no other significant changes in our significant accounting policies as of and for the three months ended July 27, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 27, 2018.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-19):
[0001564590-18-029831:note_history:14]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |  |  | 2.32 | % |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total senior notes |  |  | 1,543 |  |  |  |  |  |  |  | 1,541 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (399 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 1,144 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |
  (was, 2018-08-21, similarity 0.8688):
[0001564590-18-022123:note_history:14]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  |  | 400 |  |  |  | 2.32 | % |  |  | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (8 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,542 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |

- changed (2018-11-19):
[0001564590-18-029831:note_history:15]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 26, 2018, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2018-08-21, similarity 0.9915):
[0001564590-18-022123:note_history:15]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 27, 2018, we were in compliance with all covenants associated with the Senior Notes.

- changed (2018-11-19):
[0001564590-18-029831:note_history:16]
As of October 26, 2018, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2018-08-21, similarity 0.9405):
[0001564590-18-022123:note_history:16]
As of July 27, 2018, our aggregate future principal debt maturities are as follows (in millions):

- changed (2018-11-19):
[0001564590-18-029831:note_history:17]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of October 26, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $250 million, a weighted-average interest rate of 2.45% and maturities ranging from 4 days to 31 days. As of April 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $385 million, a weighted-average interest rate of 2.29% and maturities ranging from 19 days to 32 days.
  (was, 2018-08-21, similarity 0.9951):
[0001564590-18-022123:note_history:17]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of July 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $200 million, a weighted-average interest rate of 2.28% and maturities ranging from 14 days to 31 days. As of April 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $385 million, a weighted-average interest rate of 2.29% and maturities ranging from 19 days to 32 days.

- changed (2018-11-19):
[0001564590-18-029831:note_history:18]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of October 26, 2018 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.
  (was, 2018-08-21, similarity 0.9939):
[0001564590-18-022123:note_history:18]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of July 27, 2018 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-19):
[0001564590-18-029831:note_history:19]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |  |  | 2.32 | % |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total senior notes |  |  | 1,543 |  |  |  |  |  |  |  | 1,541 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (399 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 1,144 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |
  (was, 2018-08-21, similarity 0.8688):
[0001564590-18-022123:note_history:19]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  |  | 400 |  |  |  | 2.32 | % |  |  | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (8 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,542 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-19):
[0001564590-18-029831:note_history:20]
As of October 26, 2018, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2018-08-21, similarity 0.9405):
[0001564590-18-022123:note_history:20]
As of July 27, 2018, our aggregate future principal debt maturities are as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2018-11-19):
[0001564590-18-029831:note_history:21]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Product revenues |  | $ | 913 |  |  | $ | 819 |  |  | $ | 1,788 |  |  | $ | 1,546 |  |
| Strategic |  | 649 |  |  | 566 |  |  |  | 1,261 |  |  |  | 1,064 |  |
| Mature |  | 264 |  |  | 253 |  |  |  | 527 |  |  |  | 482 |  |
| Software maintenance revenues |  | 236 |  |  | 224 |  |  |  | 465 |  |  | 447 |  |
| Hardware maintenance and other services revenues |  | 368 |  |  | 372 |  |  |  | 738 |  |  | 743 |  |
| Hardware maintenance support contracts |  | 303 |  |  | 306 |  |  |  | 606 |  |  |  | 604 |  |
| Professional and other services |  | 65 |  |  | 66 |  |  |  | 132 |  |  |  | 139 |  |
| Net revenues |  | $ | 1,517 |  |  | $ | 1,415 |  |  | $ | 2,991 |  |  | $ | 2,736 |  |

- removed (2018-11-19):
[0001564590-18-022123:note_history:22]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Product revenues |  | $ | 875 |  |  | $ | 727 |  |
| Strategic |  |  | 612 |  |  |  | 498 |  |
| Mature |  |  | 263 |  |  |  | 229 |  |
| Software maintenance revenues |  | 229 |  |  | 223 |  |
| Hardware maintenance and other services revenues |  | 370 |  |  | 371 |  |
| Hardware maintenance support contracts |  |  | 303 |  |  |  | 298 |  |
| Professional and other services |  |  | 67 |  |  |  | 73 |  |
| Net revenues |  | $ | 1,474 |  |  | $ | 1,321 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-19):
[0001564590-18-029831:note_history:23]
|  |  | As of April 27, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  | As Adjusted |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 1,009 |  |  | $ | 38 |  |  | (1 | ) | $ | 1,047 |  |
| Inventories |  | $ | 126 |  |  | $ | (4 | ) |  |  |  | $ | 122 |  |
| Other current assets |  | $ | 330 |  |  | $ | 62 |  |  | (2 | ) | $ | 392 |  |
| Other non-current assets |  | $ | 420 |  |  | $ | 30 |  |  | (2 | ) | $ | 450 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term deferred revenue and financed unearned services revenue |  | $ | 1,804 |  |  | $ | (92 | ) |  | (3 | ) | $ | 1,712 |  |
| Other long-term liabilities |  | $ | 961 |  |  | $ | 31 |  |  | (4 | ) | $ | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  | $ | 1,673 |  |  | $ | (22 | ) |  | (3 | ) | $ | 1,651 |  |
| Accumulated deficit |  | $ | (218 | ) |  | $ | 209 |  |  | (5 | ) | $ | (9 | ) |
  (was, 2018-08-21, similarity 0.7652):
[0001564590-18-022123:note_history:23]
|  |  | As of April 27, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  | As Adjusted |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 1,009 |  |  | $ | 38 |  |  | (1 | ) | $ | 1,047 |  |
| Inventories |  |  | 126 |  |  |  | (4 | ) |  |  |  |  | 122 |  |
| Other current assets |  |  | 330 |  |  |  | 62 |  |  | (2 | ) |  | 392 |  |
| Other non-current assets |  |  | 420 |  |  |  | 30 |  |  | (2 | ) |  | 450 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term deferred revenue and financed unearned services revenue |  | $ | 1,804 |  |  | $ | (92 | ) |  | (3 | ) | $ | 1,712 |  |
| Other long-term liabilities |  |  | 961 |  |  |  | 31 |  |  | (4 | ) |  | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,673 |  |  |  | (22 | ) |  | (3 | ) |  | 1,651 |  |
| Accumulated deficit |  |  | (218 | ) |  |  | 209 |  |  | (5 | ) |  | (9 | ) |

- changed (2018-11-19):
[0001564590-18-029831:note_history:24]
The following table presents the impacts of adoption of ASC 606 to our statement of operations for the second quarter and first six months of fiscal 2018:
  (was, 2018-08-21, similarity 0.8913):
[0001564590-18-022123:note_history:24]
The following table presents the impacts of adoption of ASC 606 to our statement of operations for the first quarter of fiscal 2018:

- added (2018-11-19):
[0001564590-18-029831:note_history:25]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 27, 2017 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 807 |  |  | $ | 12 |  |  | $ | 819 |  |  | $ | 1,530 |  |  | $ | 16 |  |  | $ | 1,546 |  |
| Software maintenance |  |  | 240 |  |  |  | (16 | ) |  |  | 224 |  |  |  | 474 |  |  |  | (27 | ) |  |  | 447 |  |
| Hardware maintenance and other services |  |  | 375 |  |  |  | (3 | ) |  |  | 372 |  |  |  | 743 |  |  |  | — |  |  |  | 743 |  |
| Net revenues |  |  | 1,422 |  |  |  | (7 | ) |  |  | 1,415 |  |  |  | 2,747 |  |  |  | (11 | ) |  |  | 2,736 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 399 |  |  |  | (2 | ) |  |  | 397 |  |  |  | 770 |  |  |  | 3 |  |  |  | 773 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | — |  |  |  | 6 |  |  |  | 13 |  |  |  | — |  |  |  | 13 |  |
| Cost of hardware maintenance and other services |  |  | 115 |  |  |  | (3 | ) |  |  | 112 |  |  |  | 228 |  |  |  | (2 | ) |  |  | 226 |  |
| Total cost of revenues |  |  | 520 |  |  |  | (5 | ) |  |  | 515 |  |  |  | 1,011 |  |  |  | 1 |  |  |  | 1,012 |  |
| Gross profit |  |  | 902 |  |  |  | (2 | ) |  |  | 900 |  |  |  | 1,736 |  |  |  | (12 | ) |  |  | 1,724 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 420 |  |  |  | 1 |  |  |  | 421 |  |  |  | 845 |  |  |  | (1 | ) |  |  | 844 |  |
| Research and development |  |  | 194 |  |  |  | — |  |  |  | 194 |  |  |  | 387 |  |  |  | — |  |  |  | 387 |  |
| General and administrative |  |  | 69 |  |  |  | — |  |  |  | 69 |  |  |  | 137 |  |  |  | — |  |  |  | 137 |  |
| Total operating expenses |  |  | 683 |  |  |  | 1 |  |  |  | 684 |  |  |  | 1,369 |  |  |  | (1 | ) |  |  | 1,368 |  |
| Income from operations |  |  | 219 |  |  |  | (3 | ) |  |  | 216 |  |  |  | 367 |  |  |  | (11 | ) |  |  | 356 |  |
| Other income, net |  |  | 6 |  |  |  | — |  |  |  | 6 |  |  |  | 11 |  |  |  | — |  |  |  | 11 |  |
| Income before income taxes |  |  | 225 |  |  |  | (3 | ) |  |  | 222 |  |  |  | 378 |  |  |  | (11 | ) |  |  | 367 |  |
| Provision for income taxes |  |  | 50 |  |  |  | (2 | ) |  |  | 48 |  |  |  | 67 |  |  |  | (5 | ) |  |  | 62 |  |
| Net income |  | $ | 175 |  |  | $ | (1 | ) |  | $ | 174 |  |  | $ | 311 |  |  | $ | (6 | ) |  | $ | 305 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.65 |  |  | $ | — |  |  | $ | 0.65 |  |  | $ | 1.15 |  |  | $ | (0.02 | ) |  | $ | 1.13 |  |
| Diluted |  | $ | 0.64 |  |  | $ | (0.01 | ) |  | $ | 0.63 |  |  | $ | 1.12 |  |  | $ | (0.02 | ) |  | $ | 1.10 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 269 |  |  |  | 269 |  |  |  | 269 |  |  |  | 270 |  |  |  | 270 |  |  |  | 270 |  |
| Diluted |  |  | 275 |  |  |  | 275 |  |  |  | 275 |  |  |  | 277 |  |  |  | 277 |  |  |  | 277 |  |

- changed (2018-11-19):
[0001564590-18-029831:note_history:26]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we have historically grouped our products by “Strategic” and “Mature” solutions. Strategic solutions include Clustered ONTAP, branded E-Series, SolidFire, converged and hyper-converged infrastructure, ELAs and other optional add-on software products. Mature solutions include 7-mode ONTAP, add-on hardware and related operating system (OS) software and original equipment manufacturers (OEM) products. Both our Mature and Strategic product lines include a mix of disk, hybrid and all flash storage media. Additionally, we provide a variety of services including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training.
  (was, 2018-08-21, similarity 0.9826):
[0001564590-18-022123:note_history:26]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. Strategic solutions include Clustered ONTAP, branded E-Series, SolidFire, converged and hyper-converged infrastructure, ELAs and other optional add-on software products. Mature solutions include 7-mode ONTAP, add-on hardware and related operating system (OS) software and original equipment manufacturers (OEM) products. Both our Mature and Strategic product lines include a mix of disk, hybrid and all flash storage media. Additionally, we provide a variety of services including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training.

- added (2018-11-19):
[0001564590-18-029831:note_history:27]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Product revenues |  | $ | 913 |  |  | $ | 819 |  |  | $ | 1,788 |  |  | $ | 1,546 |  |
| Strategic |  | 649 |  |  | 566 |  |  |  | 1,261 |  |  |  | 1,064 |  |
| Mature |  | 264 |  |  | 253 |  |  |  | 527 |  |  |  | 482 |  |
| Software maintenance revenues |  | 236 |  |  | 224 |  |  |  | 465 |  |  | 447 |  |
| Hardware maintenance and other services revenues |  | 368 |  |  | 372 |  |  |  | 738 |  |  | 743 |  |
| Hardware maintenance support contracts |  | 303 |  |  | 306 |  |  |  | 606 |  |  |  | 604 |  |
| Professional and other services |  | 65 |  |  | 66 |  |  |  | 132 |  |  |  | 139 |  |
| Net revenues |  | $ | 1,517 |  |  | $ | 1,415 |  |  | $ | 2,991 |  |  | $ | 2,736 |  |

- changed (2018-11-19):
[0001564590-18-029831:note_history:28]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Deferred product revenue |  | $ | 102 |  |  | $ | 107 |  |
| Deferred services revenue |  |  | 3,010 |  |  |  | 3,134 |  |
| Financed unearned services revenue |  |  | 94 |  |  |  | 122 |  |
| Total |  | $ | 3,206 |  |  | $ | 3,363 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,538 |  |  | $ | 1,712 |  |
| Long-term |  |  | 1,668 |  |  |  | 1,651 |  |
| Total |  | $ | 3,206 |  |  | $ | 3,363 |  |
  (was, 2018-08-21, similarity 0.9852):
[0001564590-18-022123:note_history:28]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Deferred product revenue |  | $ | 102 |  |  | $ | 107 |  |
| Deferred services revenue |  |  | 3,046 |  |  |  | 3,134 |  |
| Financed unearned services revenue |  |  | 112 |  |  |  | 122 |  |
| Total |  | $ | 3,260 |  |  | $ | 3,363 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,623 |  |  | $ | 1,712 |  |
| Long-term |  |  | 1,637 |  |  |  | 1,651 |  |
| Total |  | $ | 3,260 |  |  | $ | 3,363 |  |

- added (2018-11-19):
[0001564590-18-029831:note_history:29]
|  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Balance at beginning of period |  | $ | 3,363 |  |  | $ | 3,213 |  |
| Additions |  |  | 1,067 |  |  |  | 1,031 |  |
| Revenue recognized during the period |  |  | (1,224 | ) |  |  | (1,185 | ) |
| Balance at end of period |  | $ | 3,206 |  |  | $ | 3,059 |  |

- changed (2018-11-19):
[0001564590-18-029831:note_history:30]
During the six months ended October 26, 2018 and October 27, 2017, we recognized $1,019 million and $1,017 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.
  (was, 2018-08-21, similarity 0.9004):
[0001564590-18-022123:note_history:30]
During the three months ended July 27, 2018 and July 28, 2017, we recognized $561 million and $528 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

- changed (2018-11-19):
[0001564590-18-029831:note_history:31]
As of October 26, 2018, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,206 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 48% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 27% in the next 13 to 24 months, and the remainder thereafter.
  (was, 2018-08-21, similarity 0.9925):
[0001564590-18-022123:note_history:31]
As of July 27, 2018, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,260 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 26% in the next 13 to 24 months, and the remainder thereafter.

- added (2018-11-19):
[0001564590-18-029831:note_history:32]
|  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Balance at beginning of period |  | $ | 137 |  |  | $ | 113 |  |
| Additions |  |  | 35 |  |  |  | 34 |  |
| Expense recognized during the period |  |  | (41 | ) |  |  | (32 | ) |
| Balance at end of period |  | $ | 131 |  |  | $ | 115 |  |

- changed (2018-11-19):
[0001564590-18-029831:note_history:33]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Other current assets |  | $ | 61 |  |  | $ | 66 |  |
| Other non-current assets |  |  | 70 |  |  |  | 71 |  |
| Total deferred commissions |  | $ | 131 |  |  | $ | 137 |  |
  (was, 2018-08-21, similarity 0.9708):
[0001564590-18-022123:note_history:33]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Other current assets |  | $ | 64 |  |  | $ | 66 |  |
| Other non-current assets |  |  | 71 |  |  |  | 71 |  |
| Total deferred commissions |  | $ | 135 |  |  | $ | 137 |  |

- removed (2018-11-19):
[0001564590-18-022123:note_history:34]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 723 |  |  | $ | 4 |  |  | $ | 727 |  |
| Software maintenance |  |  | 234 |  |  |  | (11 | ) |  |  | 223 |  |
| Hardware maintenance and other services |  |  | 368 |  |  |  | 3 |  |  |  | 371 |  |
| Net revenues |  |  | 1,325 |  |  |  | (4 | ) |  |  | 1,321 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 371 |  |  |  | 5 |  |  |  | 376 |  |
| Cost of software maintenance |  |  | 7 |  |  |  | — |  |  |  | 7 |  |
| Cost of hardware maintenance and other services |  |  | 113 |  |  |  | 1 |  |  |  | 114 |  |
| Total cost of revenues |  |  | 491 |  |  |  | 6 |  |  |  | 497 |  |
| Gross profit |  |  | 834 |  |  |  | (10 | ) |  |  | 824 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 425 |  |  |  | (2 | ) |  |  | 423 |  |
| Research and development |  |  | 193 |  |  |  | — |  |  |  | 193 |  |
| General and administrative |  |  | 68 |  |  |  | — |  |  |  | 68 |  |
| Total operating expenses |  |  | 686 |  |  |  | (2 | ) |  |  | 684 |  |
| Income from operations |  |  | 148 |  |  |  | (8 | ) |  |  | 140 |  |
| Other income, net |  |  | 5 |  |  |  | — |  |  |  | 5 |  |
| Income before income taxes |  |  | 153 |  |  |  | (8 | ) |  |  | 145 |  |
| Provision for income taxes |  |  | 17 |  |  |  | (3 | ) |  |  | 14 |  |
| Net income |  | $ | 136 |  |  | $ | (5 | ) |  | $ | 131 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.50 |  |  | $ | (0.01 | ) |  | $ | 0.49 |  |
| Diluted |  | $ | 0.49 |  |  | $ | (0.02 | ) |  | $ | 0.47 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 270 |  |  |  | 270 |  |  |  | 270 |  |
| Diluted |  |  | 278 |  |  |  | 278 |  |  |  | 278 |  |

- removed (2018-11-19):
[0001564590-18-022123:note_history:35]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Product revenues |  | $ | 875 |  |  | $ | 727 |  |
| Strategic |  |  | 612 |  |  |  | 498 |  |
| Mature |  |  | 263 |  |  |  | 229 |  |
| Software maintenance revenues |  | 229 |  |  | 223 |  |
| Hardware maintenance and other services revenues |  | 370 |  |  | 371 |  |
| Hardware maintenance support contracts |  |  | 303 |  |  |  | 298 |  |
| Professional and other services |  |  | 67 |  |  |  | 73 |  |
| Net revenues |  | $ | 1,474 |  |  | $ | 1,321 |  |

- removed (2018-11-19):
[0001564590-18-022123:note_history:36]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Balance at beginning of period |  | $ | 3,363 |  |  | $ | 3,213 |  |
| Additions |  |  | 511 |  |  |  | 497 |  |
| Revenue recognized during the period |  |  | (614 | ) |  |  | (583 | ) |
| Balance at end of period |  | $ | 3,260 |  |  | $ | 3,127 |  |

- removed (2018-11-19):
[0001564590-18-022123:note_history:37]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Balance at beginning of period |  | $ | 137 |  |  | $ | 113 |  |
| Additions |  |  | 19 |  |  |  | 18 |  |
| Expense recognized during the period |  |  | (21 | ) |  |  | (15 | ) |
| Balance at end of period |  | $ | 135 |  |  | $ | 116 |  |
