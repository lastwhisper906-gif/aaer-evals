# NTAP notes — 0001564590-18-029831


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-18-029831:notes:1]
[same as prior period, unchanged from 0001564590-18-022123:notes:1]

[0001564590-18-029831:notes:2]
[same as prior period, unchanged from 0001564590-18-022123:notes:2]

[0001564590-18-029831:notes:3]
[same as prior period, unchanged from 0001564590-18-022123:notes:3]

[0001564590-18-029831:notes:4]
[same as prior period, unchanged from 0001564590-18-022123:notes:4]

[0001564590-18-029831:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 27, 2018 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 26, 2018 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-18-029831:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; valuation of investment securities; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-18-029831:notes:7]
[same as prior period, unchanged from 0001564590-18-022123:notes:7]

[0001564590-18-029831:notes:8]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard, Revenue from Contracts with Customers (ASC 606), which establishes a comprehensive new revenue recognition model designed to depict the transfer of goods or services to a customer in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In the first quarter of fiscal 2019, we adopted this new standard using the full retrospective method of adoption. Accordingly, our prior period condensed consolidated financial statements and information, as presented herein, have been restated to conform to the new rules. Refer to Note 5 – Revenue for a summary of the impacts of adopting this standard, and a discussion of our updated policies related to revenue recognition.

[0001564590-18-029831:notes:9]
In October 2016, the FASB issued an accounting standards update (ASU) which eliminates the deferred tax effects of intra-entity asset transfers other than inventory. As a result, tax expense from the sale of an asset in the seller’s tax jurisdiction is recognized when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. In the first quarter of fiscal 2019, we adopted this ASU using a modified retrospective transition approach and recorded a cumulative-effect adjustment to decrease retained earnings by $51 million, with a corresponding reduction of prepaid taxes, which were classified as other non-current assets on our condensed consolidated balance sheets.

[0001564590-18-029831:notes:10]
In November 2016, the FASB issued an ASU that requires a statement of cash flows to explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. In the first quarter of fiscal 2019, we adopted this ASU using a retrospective transition method. Accordingly, our condensed consolidated statement of cash flows for the three and six months ended October 27, 2017, as presented herein, has been restated to comply with the new requirements. Refer to Note 4 – Supplemental Financial Information for a detail of the components of our cash, cash equivalents and restricted cash balances.

[0001564590-18-029831:notes:11]
There have been no other significant changes in our significant accounting policies as of and for the six months ended October 26, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 27, 2018.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-18-029831:notes:12]
3. Goodwill and Purchased Intangible Assets, Net

[0001564590-18-029831:notes:13]
Goodwill activity is summarized as follows (in millions):

[0001564590-18-029831:notes:14]
| Balance as of April 27, 2018 |  | $ | 1,739 |  |
| Additions |  |  | 3 |  |
| Balance as of October 26, 2018 |  | $ | 1,742 |  |

[0001564590-18-029831:notes:15]
On September 17, 2018, we acquired all of the outstanding shares of a privately-held software company for $3 million in cash. Substantially all of the purchase price was recorded to goodwill.

[0001564590-18-029831:notes:16]
[same as prior period, unchanged from 0001564590-18-022123:notes:16]

[0001564590-18-029831:notes:17]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 160 |  |  | $ | (95 | ) |  | $ | 65 |  |  | $ | 164 |  |  | $ | (80 | ) |  | $ | 84 |  |
| Customer contracts/relationships |  |  | 41 |  |  |  | (37 | ) |  |  | 4 |  |  |  | 43 |  |  |  | (33 | ) |  |  | 10 |  |
| Other purchased intangibles |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 9 |  |  |  | (9 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 201 |  |  | $ | (132 | ) |  | $ | 69 |  |  | $ | 216 |  |  | $ | (122 | ) |  | $ | 94 |  |

[0001564590-18-029831:notes:18]
[same as prior period, unchanged from 0001564590-18-022123:notes:18]

[0001564590-18-029831:notes:19]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Statements of |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | Operations Classification |
| Developed technology |  | $ | 9 |  |  | $ | 9 |  |  | $ | 18 |  |  | $ | 17 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 3 |  |  |  | 4 |  |  |  | 7 |  |  |  | 8 |  |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 2 |  |  | Operating expenses |
| Total |  | $ | 12 |  |  | $ | 14 |  |  | $ | 25 |  |  | $ | 27 |  |  |  |

[0001564590-18-029831:notes:20]
As of October 26, 2018, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-18-029831:notes:21]
| Fiscal Year |  | Amount |  |
| Remainder of 2019 |  | $ | 22 |  |
| 2020 |  |  | 31 |  |
| 2021 |  |  | 16 |  |
| Total |  | $ | 69 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-18-029831:notes:22]
4. Supplemental Financial Information

[0001564590-18-029831:notes:23]
[same as prior period, unchanged from 0001564590-18-022123:notes:23]

[0001564590-18-029831:notes:24]
[same as prior period, unchanged from 0001564590-18-022123:notes:24]

[0001564590-18-029831:notes:25]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Cash |  | $ | 2,251 |  |  | $ | 2,727 |  |
| Cash equivalents |  |  | 108 |  |  |  | 214 |  |
| Cash and cash equivalents |  | $ | 2,359 |  |  | $ | 2,941 |  |
| Short-term restricted cash |  |  | 5 |  |  |  | 5 |  |
| Long-term restricted cash |  |  | 1 |  |  |  | 1 |  |
| Restricted cash |  | $ | 6 |  |  | $ | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,365 |  |  | $ | 2,947 |  |

[0001564590-18-029831:notes:26]
[same as prior period, unchanged from 0001564590-18-022123:notes:26]

[0001564590-18-029831:notes:27]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Purchased components |  | $ | 12 |  |  | $ | 12 |  |
| Finished goods |  |  | 74 |  |  |  | 110 |  |
| Inventories |  | $ | 86 |  |  | $ | 122 |  |

[0001564590-18-029831:notes:28]
[same as prior period, unchanged from 0001564590-18-022123:notes:28]

[0001564590-18-029831:notes:29]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Land |  | $ | 106 |  |  | $ | 106 |  |
| Buildings and improvements |  |  | 604 |  |  |  | 594 |  |
| Leasehold improvements |  |  | 87 |  |  |  | 88 |  |
| Computer, production, engineering and other equipment |  |  | 786 |  |  |  | 733 |  |
| Computer software |  |  | 357 |  |  |  | 357 |  |
| Furniture and fixtures |  |  | 104 |  |  |  | 99 |  |
| Construction-in-progress |  |  | 8 |  |  |  | 27 |  |
|  |  |  | 2,052 |  |  |  | 2,004 |  |
| Accumulated depreciation and amortization |  |  | (1,282 | ) |  |  | (1,248 | ) |
| Property and equipment, net |  | $ | 770 |  |  | $ | 756 |  |

[0001564590-18-029831:notes:30]
In September 2017, we entered into an agreement to sell certain land and buildings located in Sunnyvale, California, through two separate and independent closings, the first of which was completed in the third quarter of fiscal 2018. The remaining properties, consisting of land with a net book value of $52 million, were classified as assets held for sale, and included as other current assets in our condensed consolidated balance sheets as of October 26, 2018 and April 27, 2018. We will consummate the sale of these properties, and receive cash proceeds of $96 million, upon the completion of the second closing, which is expected to occur within the next 12 months. That closing is subject to due diligence, certain termination rights and customary closing conditions, including local governmental approval of the subdivision of a land parcel.

[0001564590-18-029831:notes:31]
[same as prior period, unchanged from 0001564590-18-022123:notes:31]

[0001564590-18-029831:notes:32]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Deferred tax assets |  | $ | 223 |  |  | $ | 229 |  |
| Other assets |  |  | 276 |  |  |  | 221 |  |
| Other non-current assets |  | $ | 499 |  |  | $ | 450 |  |

[0001564590-18-029831:notes:33]
[same as prior period, unchanged from 0001564590-18-022123:notes:33]

[0001564590-18-029831:notes:34]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Accrued compensation and benefits |  | $ | 314 |  |  | $ | 441 |  |
| Product warranty liabilities |  |  | 26 |  |  |  | 25 |  |
| Other current liabilities |  |  | 312 |  |  |  | 359 |  |
| Accrued expenses |  | $ | 652 |  |  | $ | 825 |  |

[0001564590-18-029831:notes:35]
[same as prior period, unchanged from 0001564590-18-022123:notes:35]

[0001564590-18-029831:notes:36]
[same as prior period, unchanged from 0001564590-18-022123:notes:36]

[0001564590-18-029831:notes:37]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Balance at beginning of period |  | $ | 38 |  |  | $ | 44 |  |  | $ | 40 |  |  | $ | 50 |  |
| Expense accrued during the period |  |  | 6 |  |  |  | 7 |  |  |  | 10 |  |  |  | 8 |  |
| Warranty costs incurred |  |  | (5 | ) |  |  | (7 | ) |  |  | (11 | ) |  |  | (14 | ) |
| Balance at end of period |  | $ | 39 |  |  | $ | 44 |  |  | $ | 39 |  |  | $ | 44 |  |

[0001564590-18-029831:notes:38]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Accrued expenses |  | $ | 26 |  |  | $ | 25 |  |
| Other long-term liabilities |  |  | 13 |  |  |  | 15 |  |
| Total warranty liabilities |  | $ | 39 |  |  | $ | 40 |  |

[0001564590-18-029831:notes:39]
[same as prior period, unchanged from 0001564590-18-022123:notes:39]

[0001564590-18-029831:notes:40]
[same as prior period, unchanged from 0001564590-18-022123:notes:40]

[0001564590-18-029831:notes:41]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Liability for uncertain tax positions |  | $ | 324 |  |  | $ | 314 |  |
| Income taxes payable |  |  | 476 |  |  |  | 549 |  |
| Product warranty liabilities |  |  | 13 |  |  |  | 15 |  |
| Other liabilities |  |  | 86 |  |  |  | 114 |  |
| Other long-term liabilities |  | $ | 899 |  |  | $ | 992 |  |

[0001564590-18-029831:notes:42]
Statements of cash flows additional information (in millions):

[0001564590-18-029831:notes:43]
Non-cash investing and financing activities and supplemental cash flow information are as follows:

[0001564590-18-029831:notes:44]
|  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 7 |  |  | $ | 17 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 104 |  |  | $ | 28 |  |
| Interest paid |  | $ | 26 |  |  | $ | 24 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-18-029831:notes:45]
5. Revenue

[0001564590-18-029831:notes:46]
[same as prior period, unchanged from 0001564590-18-022123:notes:43]

[0001564590-18-029831:notes:47]
[same as prior period, unchanged from 0001564590-18-022123:notes:44]

[0001564590-18-029831:notes:48]
|  |  | As of April 27, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  | As Adjusted |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 1,009 |  |  | $ | 38 |  |  | (1 | ) | $ | 1,047 |  |
| Inventories |  | $ | 126 |  |  | $ | (4 | ) |  |  |  | $ | 122 |  |
| Other current assets |  | $ | 330 |  |  | $ | 62 |  |  | (2 | ) | $ | 392 |  |
| Other non-current assets |  | $ | 420 |  |  | $ | 30 |  |  | (2 | ) | $ | 450 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term deferred revenue and financed unearned services revenue |  | $ | 1,804 |  |  | $ | (92 | ) |  | (3 | ) | $ | 1,712 |  |
| Other long-term liabilities |  | $ | 961 |  |  | $ | 31 |  |  | (4 | ) | $ | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  | $ | 1,673 |  |  | $ | (22 | ) |  | (3 | ) | $ | 1,651 |  |
| Accumulated deficit |  | $ | (218 | ) |  | $ | 209 |  |  | (5 | ) | $ | (9 | ) |

[0001564590-18-029831:notes:49]
[same as prior period, unchanged from 0001564590-18-022123:notes:46]

[0001564590-18-029831:notes:50]
[same as prior period, unchanged from 0001564590-18-022123:notes:47]

[0001564590-18-029831:notes:51]
[same as prior period, unchanged from 0001564590-18-022123:notes:48]

[0001564590-18-029831:notes:52]
[same as prior period, unchanged from 0001564590-18-022123:notes:49]

[0001564590-18-029831:notes:53]
[same as prior period, unchanged from 0001564590-18-022123:notes:50]

[0001564590-18-029831:notes:54]
The following table presents the impacts of adoption of ASC 606 to our statement of operations for the second quarter and first six months of fiscal 2018:

[0001564590-18-029831:notes:55]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 27, 2017 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 807 |  |  | $ | 12 |  |  | $ | 819 |  |  | $ | 1,530 |  |  | $ | 16 |  |  | $ | 1,546 |  |
| Software maintenance |  |  | 240 |  |  |  | (16 | ) |  |  | 224 |  |  |  | 474 |  |  |  | (27 | ) |  |  | 447 |  |
| Hardware maintenance and other services |  |  | 375 |  |  |  | (3 | ) |  |  | 372 |  |  |  | 743 |  |  |  | — |  |  |  | 743 |  |
| Net revenues |  |  | 1,422 |  |  |  | (7 | ) |  |  | 1,415 |  |  |  | 2,747 |  |  |  | (11 | ) |  |  | 2,736 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 399 |  |  |  | (2 | ) |  |  | 397 |  |  |  | 770 |  |  |  | 3 |  |  |  | 773 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | — |  |  |  | 6 |  |  |  | 13 |  |  |  | — |  |  |  | 13 |  |
| Cost of hardware maintenance and other services |  |  | 115 |  |  |  | (3 | ) |  |  | 112 |  |  |  | 228 |  |  |  | (2 | ) |  |  | 226 |  |
| Total cost of revenues |  |  | 520 |  |  |  | (5 | ) |  |  | 515 |  |  |  | 1,011 |  |  |  | 1 |  |  |  | 1,012 |  |
| Gross profit |  |  | 902 |  |  |  | (2 | ) |  |  | 900 |  |  |  | 1,736 |  |  |  | (12 | ) |  |  | 1,724 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 420 |  |  |  | 1 |  |  |  | 421 |  |  |  | 845 |  |  |  | (1 | ) |  |  | 844 |  |
| Research and development |  |  | 194 |  |  |  | — |  |  |  | 194 |  |  |  | 387 |  |  |  | — |  |  |  | 387 |  |
| General and administrative |  |  | 69 |  |  |  | — |  |  |  | 69 |  |  |  | 137 |  |  |  | — |  |  |  | 137 |  |
| Total operating expenses |  |  | 683 |  |  |  | 1 |  |  |  | 684 |  |  |  | 1,369 |  |  |  | (1 | ) |  |  | 1,368 |  |
| Income from operations |  |  | 219 |  |  |  | (3 | ) |  |  | 216 |  |  |  | 367 |  |  |  | (11 | ) |  |  | 356 |  |
| Other income, net |  |  | 6 |  |  |  | — |  |  |  | 6 |  |  |  | 11 |  |  |  | — |  |  |  | 11 |  |
| Income before income taxes |  |  | 225 |  |  |  | (3 | ) |  |  | 222 |  |  |  | 378 |  |  |  | (11 | ) |  |  | 367 |  |
| Provision for income taxes |  |  | 50 |  |  |  | (2 | ) |  |  | 48 |  |  |  | 67 |  |  |  | (5 | ) |  |  | 62 |  |
| Net income |  | $ | 175 |  |  | $ | (1 | ) |  | $ | 174 |  |  | $ | 311 |  |  | $ | (6 | ) |  | $ | 305 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.65 |  |  | $ | — |  |  | $ | 0.65 |  |  | $ | 1.15 |  |  | $ | (0.02 | ) |  | $ | 1.13 |  |
| Diluted |  | $ | 0.64 |  |  | $ | (0.01 | ) |  | $ | 0.63 |  |  | $ | 1.12 |  |  | $ | (0.02 | ) |  | $ | 1.10 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 269 |  |  |  | 269 |  |  |  | 269 |  |  |  | 270 |  |  |  | 270 |  |  |  | 270 |  |
| Diluted |  |  | 275 |  |  |  | 275 |  |  |  | 275 |  |  |  | 277 |  |  |  | 277 |  |  |  | 277 |  |

[0001564590-18-029831:notes:56]
[same as prior period, unchanged from 0001564590-18-022123:notes:53]

[0001564590-18-029831:notes:57]
[same as prior period, unchanged from 0001564590-18-022123:notes:54]

[0001564590-18-029831:notes:58]
[same as prior period, unchanged from 0001564590-18-022123:notes:55]

[0001564590-18-029831:notes:59]
[same as prior period, unchanged from 0001564590-18-022123:notes:56]

[0001564590-18-029831:notes:60]
[same as prior period, unchanged from 0001564590-18-022123:notes:57]

[0001564590-18-029831:notes:61]
[same as prior period, unchanged from 0001564590-18-022123:notes:58]

[0001564590-18-029831:notes:62]
[same as prior period, unchanged from 0001564590-18-022123:notes:59]

[0001564590-18-029831:notes:63]
[same as prior period, unchanged from 0001564590-18-022123:notes:60]

[0001564590-18-029831:notes:64]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we have historically grouped our products by “Strategic” and “Mature” solutions. Strategic solutions include Clustered ONTAP, branded E-Series, SolidFire, converged and hyper-converged infrastructure, ELAs and other optional add-on software products. Mature solutions include 7-mode ONTAP, add-on hardware and related operating system (OS) software and original equipment manufacturers (OEM) products. Both our Mature and Strategic product lines include a mix of disk, hybrid and all flash storage media. Additionally, we provide a variety of services including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training.

[0001564590-18-029831:notes:65]
[same as prior period, unchanged from 0001564590-18-022123:notes:62]

[0001564590-18-029831:notes:66]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Product revenues |  | $ | 913 |  |  | $ | 819 |  |  | $ | 1,788 |  |  | $ | 1,546 |  |
| Strategic |  | 649 |  |  | 566 |  |  |  | 1,261 |  |  |  | 1,064 |  |
| Mature |  | 264 |  |  | 253 |  |  |  | 527 |  |  |  | 482 |  |
| Software maintenance revenues |  | 236 |  |  | 224 |  |  |  | 465 |  |  | 447 |  |
| Hardware maintenance and other services revenues |  | 368 |  |  | 372 |  |  |  | 738 |  |  | 743 |  |
| Hardware maintenance support contracts |  | 303 |  |  | 306 |  |  |  | 606 |  |  |  | 604 |  |
| Professional and other services |  | 65 |  |  | 66 |  |  |  | 132 |  |  |  | 139 |  |
| Net revenues |  | $ | 1,517 |  |  | $ | 1,415 |  |  | $ | 2,991 |  |  | $ | 2,736 |  |

[0001564590-18-029831:notes:67]
Revenues by geographic region are presented in Note 14 – Segment, Geographic, and Significant Customer Information.

[0001564590-18-029831:notes:68]
[same as prior period, unchanged from 0001564590-18-022123:notes:65]

[0001564590-18-029831:notes:69]
[same as prior period, unchanged from 0001564590-18-022123:notes:66]

[0001564590-18-029831:notes:70]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Deferred product revenue |  | $ | 102 |  |  | $ | 107 |  |
| Deferred services revenue |  |  | 3,010 |  |  |  | 3,134 |  |
| Financed unearned services revenue |  |  | 94 |  |  |  | 122 |  |
| Total |  | $ | 3,206 |  |  | $ | 3,363 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,538 |  |  | $ | 1,712 |  |
| Long-term |  |  | 1,668 |  |  |  | 1,651 |  |
| Total |  | $ | 3,206 |  |  | $ | 3,363 |  |

[0001564590-18-029831:notes:71]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 15 – Commitments and Contingencies for additional information related to these arrangements.

[0001564590-18-029831:notes:72]
[same as prior period, unchanged from 0001564590-18-022123:notes:69]

[0001564590-18-029831:notes:73]
|  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Balance at beginning of period |  | $ | 3,363 |  |  | $ | 3,213 |  |
| Additions |  |  | 1,067 |  |  |  | 1,031 |  |
| Revenue recognized during the period |  |  | (1,224 | ) |  |  | (1,185 | ) |
| Balance at end of period |  | $ | 3,206 |  |  | $ | 3,059 |  |

[0001564590-18-029831:notes:74]
During the six months ended October 26, 2018 and October 27, 2017, we recognized $1,019 million and $1,017 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001564590-18-029831:notes:75]
As of October 26, 2018, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,206 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 48% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 27% in the next 13 to 24 months, and the remainder thereafter.

[0001564590-18-029831:notes:76]
[same as prior period, unchanged from 0001564590-18-022123:notes:73]

[0001564590-18-029831:notes:77]
[same as prior period, unchanged from 0001564590-18-022123:notes:74]

[0001564590-18-029831:notes:78]
|  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Balance at beginning of period |  | $ | 137 |  |  | $ | 113 |  |
| Additions |  |  | 35 |  |  |  | 34 |  |
| Expense recognized during the period |  |  | (41 | ) |  |  | (32 | ) |
| Balance at end of period |  | $ | 131 |  |  | $ | 115 |  |

[0001564590-18-029831:notes:79]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Other current assets |  | $ | 61 |  |  | $ | 66 |  |
| Other non-current assets |  |  | 70 |  |  |  | 71 |  |
| Total deferred commissions |  | $ | 131 |  |  | $ | 137 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-18-029831:notes:80]
6. Other income, net

[0001564590-18-029831:notes:81]
[same as prior period, unchanged from 0001564590-18-022123:notes:78]

[0001564590-18-029831:notes:82]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Interest income |  | $ | 21 |  |  | $ | 19 |  |  | $ | 46 |  |  | $ | 35 |  |
| Interest expense |  |  | (14 | ) |  |  | (17 | ) |  |  | (28 | ) |  |  | (30 | ) |
| Other income, net |  |  | — |  |  |  | 4 |  |  |  | 7 |  |  |  | 6 |  |
| Total other income, net |  | $ | 7 |  |  | $ | 6 |  |  | $ | 25 |  |  | $ | 11 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-18-029831:notes:83]
7. Financial Instruments and Fair Value Measurements

[0001564590-18-029831:notes:84]
[same as prior period, unchanged from 0001564590-18-022123:notes:81]

[0001564590-18-029831:notes:85]
[same as prior period, unchanged from 0001564590-18-022123:notes:82]

[0001564590-18-029831:notes:86]
[same as prior period, unchanged from 0001564590-18-022123:notes:83]

[0001564590-18-029831:notes:87]
[same as prior period, unchanged from 0001564590-18-022123:notes:84]

[0001564590-18-029831:notes:88]
[same as prior period, unchanged from 0001564590-18-022123:notes:85]

[0001564590-18-029831:notes:89]
[same as prior period, unchanged from 0001564590-18-022123:notes:86]

[0001564590-18-029831:notes:90]
[same as prior period, unchanged from 0001564590-18-022123:notes:87]

[0001564590-18-029831:notes:91]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,614 |  |  | $ | — |  |  | $ | (40 | ) |  | $ | 1,574 |  |  | $ | 1,865 |  |  | $ | 1 |  |  | $ | (39 | ) |  | $ | 1,827 |  |
| U.S. Treasury and government debt securities |  |  | 362 |  |  |  | — |  |  |  | (4 | ) |  |  | 358 |  |  |  | 497 |  |  |  | — |  |  |  | (5 | ) |  |  | 492 |  |
| Commercial paper |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 230 |  |  |  | — |  |  |  | — |  |  |  | 230 |  |
| Certificates of deposit |  |  | 116 |  |  |  | — |  |  |  | — |  |  |  | 116 |  |  |  | 115 |  |  |  | — |  |  |  | — |  |  |  | 115 |  |
| Mutual funds |  |  | 34 |  |  |  | — |  |  |  | — |  |  |  | 34 |  |  |  | 31 |  |  |  | — |  |  |  | — |  |  |  | 31 |  |
| Total debt and equity securities |  | $ | 2,126 |  |  | $ | — |  |  | $ | (44 | ) |  | $ | 2,082 |  |  | $ | 2,738 |  |  | $ | 1 |  |  | $ | (44 | ) |  | $ | 2,695 |  |

[0001564590-18-029831:notes:92]
As of October 26, 2018 and April 27, 2018, the unrealized losses on our available-for-sale investments were caused by market value declines as a result of increasing market interest rates. Because the declines in market value are attributable to changes in market conditions and not credit quality, and because we have determined that (i) we do not have the intent to sell any of these investments and (ii) it is not more likely than not that we will be required to sell any of these investments before recovery of the entire amortized cost basis, we have determined that no other-than-temporary impairments were required to be recognized on these investments as of October 26, 2018 and April 27, 2018.

[0001564590-18-029831:notes:93]
The following table presents the contractual maturities of our debt investments as of October 26, 2018 (in millions):

[0001564590-18-029831:notes:94]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 679 |  |  | $ | 676 |  |
| Due after one year through five years |  |  | 835 |  |  |  | 821 |  |
| Due after five years through ten years |  |  | 578 |  |  |  | 551 |  |
|  |  | $ | 2,092 |  |  | $ | 2,048 |  |

[0001564590-18-029831:notes:95]
[same as prior period, unchanged from 0001564590-18-022123:notes:92]

[0001564590-18-029831:notes:96]
[same as prior period, unchanged from 0001564590-18-022123:notes:93]

[0001564590-18-029831:notes:97]
[same as prior period, unchanged from 0001564590-18-022123:notes:94]

[0001564590-18-029831:notes:98]
|  |  | October 26, 2018 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,251 |  |  | $ | 2,251 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,574 |  |  |  | — |  |  |  | 1,574 |  |
| U.S. Treasury and government debt securities |  |  | 358 |  |  |  | 190 |  |  |  | 168 |  |
| Certificates of deposit |  |  | 116 |  |  |  | — |  |  |  | 116 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,299 |  |  | $ | 2,441 |  |  | $ | 1,858 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 28 |  |  | $ | 28 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |

[0001564590-18-029831:notes:99]
[same as prior period, unchanged from 0001564590-18-022123:notes:96]

[0001564590-18-029831:notes:100]
[same as prior period, unchanged from 0001564590-18-022123:notes:97]

[0001564590-18-029831:notes:101]
| (3) | Reported as accrued expenses in the condensed consolidated balance sheets |

[0001564590-18-029831:notes:102]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of October 26, 2018 and April 27, 2018, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-18-029831:notes:103]
[same as prior period, unchanged from 0001564590-18-022123:notes:99]

[0001564590-18-029831:notes:104]
As of October 26, 2018 and April 27, 2018, the fair value of our long-term debt was approximately $1,524 million and $1,523 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-18-029831:notes:105]
8. Financing Arrangements

[0001564590-18-029831:notes:106]
Long-Term Debt

[0001564590-18-029831:notes:107]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-18-029831:notes:108]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |  |  | 2.32 | % |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total senior notes |  |  | 1,543 |  |  |  |  |  |  |  | 1,541 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (399 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 1,144 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |

[0001564590-18-029831:notes:109]
Senior Notes

[0001564590-18-029831:notes:110]
Our 2.00% Senior Notes and 3.30% Senior Notes, each with a principal amount of $400 million, were issued in September 2017. Interest on these Senior Notes is paid semi-annually in March and September. Our 3.375% Senior Notes and 3.25% Senior Notes, with principal amounts of $500 million and $250 million, respectively, were issued in June 2014 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-18-029831:notes:111]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 26, 2018, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-18-029831:notes:112]
As of October 26, 2018, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-18-029831:notes:113]
| Fiscal Year |  | Amount |  |
| 2020 |  | $ | 400 |  |
| 2022 |  |  | 500 |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| Total |  | $ | 1,550 |  |

[0001564590-18-029831:notes:114]
Commercial Paper Program and Credit Facility

[0001564590-18-029831:notes:115]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of October 26, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $250 million, a weighted-average interest rate of 2.45% and maturities ranging from 4 days to 31 days. As of April 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $385 million, a weighted-average interest rate of 2.29% and maturities ranging from 19 days to 32 days.

[0001564590-18-029831:notes:116]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of October 26, 2018 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-18-029831:notes:117]
9. Stockholders’ Equity

[0001564590-18-029831:notes:118]
[same as prior period, unchanged from 0001564590-18-022123:notes:114]

[0001564590-18-029831:notes:119]
As of October 26, 2018, we have certain equity incentive awards (awards) outstanding, which include stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and Employee Stock Purchase Plan (ESPP) awards.

[0001564590-18-029831:notes:120]
[same as prior period, unchanged from 0001564590-18-022123:notes:116]

[0001564590-18-029831:notes:121]
[same as prior period, unchanged from 0001564590-18-022123:notes:117]

[0001564590-18-029831:notes:122]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 27, 2018 |  |  | 1 |  |  | $ | 31.19 |  |  |  |  |  |  |  |  |  |
| Outstanding as of October 26, 2018 |  |  | 1 |  |  | $ | 30.49 |  |  |  | 3.27 |  |  | $ | 29 |  |
| Exercisable as of October 26, 2018 |  |  | 1 |  |  | $ | 32.21 |  |  |  | 2.92 |  |  | $ | 25 |  |

[0001564590-18-029831:notes:123]
[same as prior period, unchanged from 0001564590-18-022123:notes:119]

[0001564590-18-029831:notes:124]
[same as prior period, unchanged from 0001564590-18-022123:notes:120]

[0001564590-18-029831:notes:125]
|  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Intrinsic value of exercises |  | $ | 22 |  |  | $ | 11 |  |
| Proceeds received from exercises |  | $ | 17 |  |  | $ | 15 |  |
| Fair value of options vested |  | $ | 1 |  |  | $ | 5 |  |

[0001564590-18-029831:notes:126]
[same as prior period, unchanged from 0001564590-18-022123:notes:122]

[0001564590-18-029831:notes:127]
In the six months ended October 26, 2018, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria, in addition to the service based vesting criteria, such that the PBRSUs cliff-vest at the end of an approximate three year performance period, which began on the date specified in the grant agreements and ends the last day of fiscal 2021. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the current year, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of fiscal 2021. The fair values of these awards were fixed at grant date using a Monte Carlo simulation model. For the remaining PBRSUs granted, the number of shares issued will depend upon our achievement against a cumulative Adjusted Operating Income (AOI) target, as defined in the grant agreements, for the three year period from fiscal 2019 through 2021. The fair values of these awards were established consistent with our methodology for valuing time-based RSUs, while compensation cost is being recognized based on the probable outcome of the performance condition. The aggregate grant date fair value of all PBRSUs granted in the current year was $23 million, which is being recognized to compensation expense over the remaining applicable performance / service periods.

[0001564590-18-029831:notes:128]
[same as prior period, unchanged from 0001564590-18-022123:notes:124]

[0001564590-18-029831:notes:129]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 27, 2018 |  |  | 9 |  |  | $ | 32.91 |  |
| Granted |  |  | 3 |  |  | $ | 63.37 |  |
| Vested |  |  | (3 | ) |  | $ | 31.67 |  |
| Forfeited |  |  | (1 | ) |  | $ | 34.03 |  |
| Outstanding as of October 26, 2018 |  |  | 8 |  |  | $ | 44.55 |  |

[0001564590-18-029831:notes:130]
[same as prior period, unchanged from 0001564590-18-022123:notes:126]

[0001564590-18-029831:notes:131]
|  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 2 |  |
| Fair value of shares withheld |  | $ | 89 |  |  | $ | 60 |  |

[0001564590-18-029831:notes:132]
[same as prior period, unchanged from 0001564590-18-022123:notes:128]

[0001564590-18-029831:notes:133]
[same as prior period, unchanged from 0001564590-18-022123:notes:129]

[0001564590-18-029831:notes:134]
|  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Shares issued under the ESPP |  |  | 2 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 49 |  |  | $ | 42 |  |

[0001564590-18-029831:notes:135]
[same as prior period, unchanged from 0001564590-18-022123:notes:131]

[0001564590-18-029831:notes:136]
[same as prior period, unchanged from 0001564590-18-022123:notes:132]

[0001564590-18-029831:notes:137]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Cost of product revenues |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |
| Cost of hardware maintenance and other services revenues |  |  | 2 |  |  |  | 2 |  |  |  | 5 |  |  |  | 5 |  |
| Sales and marketing |  |  | 16 |  |  |  | 16 |  |  |  | 33 |  |  |  | 37 |  |
| Research and development |  |  | 12 |  |  |  | 12 |  |  |  | 24 |  |  |  | 27 |  |
| General and administrative |  |  | 8 |  |  |  | 8 |  |  |  | 15 |  |  |  | 16 |  |
| Total stock-based compensation expense |  | $ | 38 |  |  | $ | 39 |  |  | $ | 78 |  |  | $ | 87 |  |
| Income tax benefit for stock-based compensation expense |  | $ | 5 |  |  | $ | 9 |  |  | $ | 10 |  |  | $ | 18 |  |

[0001564590-18-029831:notes:138]
As of October 26, 2018, total unrecognized compensation expense related to our equity awards was $337 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.3 years.

[0001564590-18-029831:notes:139]
[same as prior period, unchanged from 0001564590-18-022123:notes:135]

[0001564590-18-029831:notes:140]
[same as prior period, unchanged from 0001564590-18-022123:notes:136]

[0001564590-18-029831:notes:141]
The following table summarizes activity related to this program for the six months ended October 26, 2018 (in millions, except per share amounts):

[0001564590-18-029831:notes:142]
| Number of shares repurchased |  |  | 14 |  |
| Average price per share |  | $ | 77.94 |  |
| Aggregate purchase price |  | $ | 1,061 |  |
| Remaining authorization at end of period |  | $ | 2,939 |  |

[0001564590-18-029831:notes:143]
The aggregate purchase price of our stock repurchases for the six months ended October 26, 2018 consisted of $1,061 million of open market purchases, of which $597 million and $464 million were allocated to additional paid-in capital and retained earnings (accumulated deficit), respectively.

[0001564590-18-029831:notes:144]
Since the May 13, 2003 inception of our stock repurchase program through October 26, 2018, we repurchased a total of 298 million shares of our common stock at an average price of $35.87 per share, for an aggregate purchase price of $10.7 billion.

[0001564590-18-029831:notes:145]
[same as prior period, unchanged from 0001564590-18-022123:notes:141]

[0001564590-18-029831:notes:146]
[same as prior period, unchanged from 0001564590-18-022123:notes:142]

[0001564590-18-029831:notes:147]
|  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Dividends per share declared |  | $ | 0.80 |  |  | $ | 0.40 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 207 |  |  | $ | — |  |
| Dividend payments allocated to retained earnings (accumulated deficit) |  | $ | — |  |  | $ | 108 |  |

[0001564590-18-029831:notes:148]
On November 14, 2018, we declared a cash dividend of $0.40 per share of common stock, payable on January 23, 2019 to holders of record as of the close of business on January 4, 2019. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-18-029831:notes:149]
[same as prior period, unchanged from 0001564590-18-022123:notes:145]

[0001564590-18-029831:notes:150]
[same as prior period, unchanged from 0001564590-18-022123:notes:146]

[0001564590-18-029831:notes:151]
| Balance as of April 27, 2018 |  | $ | (9 | ) |
| Cumulative-effect of new accounting principle |  |  | (51 | ) |
| Net income |  |  | 524 |  |
| Repurchases of common stock |  |  | (464 | ) |
| Balance as of October 26, 2018 |  | $ | — |  |

[0001564590-18-029831:notes:152]
In the first quarter of fiscal 2019, we adopted an ASU that eliminates the deferred tax effects of intra-entity asset transfers other than inventory and recorded the cumulative-effect of adoption to retained earnings (accumulated deficit). Refer to Note 1 – Description of Business and Significant Accounting Policies for details.

[0001564590-18-029831:notes:153]
Accumulated Other Comprehensive Income (Loss)

[0001564590-18-029831:notes:154]
Changes in accumulated other comprehensive income (loss) (AOCI) by component, net of tax, are summarized below (in millions):

[0001564590-18-029831:notes:155]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Total |  |
| Balance as of April 27, 2018 |  | $ | (27 | ) |  | $ | — |  |  | $ | (43 | ) |  | $ | (70 | ) |
| Other comprehensive income (loss), net of tax |  |  | (3 | ) |  |  | — |  |  |  | (1 | ) |  |  | (4 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |
| Total other comprehensive loss |  |  | (3 | ) |  |  | (1 | ) |  |  | (1 | ) |  |  | (5 | ) |
| Balance as of October 26, 2018 |  | $ | (30 | ) |  | $ | (1 | ) |  | $ | (44 | ) |  | $ | (75 | ) |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-18-029831:notes:156]
10. Derivatives and Hedging Activities

[0001564590-18-029831:notes:157]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is six months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of our agreements with them. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of October 26, 2018 or April 27, 2018. We did not recognize any gains or losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-18-029831:notes:158]
[same as prior period, unchanged from 0001564590-18-022123:notes:151]

[0001564590-18-029831:notes:159]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 182 |  |  | $ | — |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 101 |  |  | $ | 115 |  |
| Forward contracts purchased |  | $ | 237 |  |  | $ | 412 |  |

[0001564590-18-029831:notes:160]
The effect of cash flow hedges recognized in net revenues on our condensed consolidated statements of operations was immaterial in all periods presented.

[0001564590-18-029831:notes:161]
[same as prior period, unchanged from 0001564590-18-022123:notes:154]

[0001564590-18-029831:notes:162]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
|  |  | Gain (Loss) Recognized into Income |  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 2 |  |  | $ | 1 |  |  | $ | 12 |  |  | $ | (1 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-18-029831:notes:163]
11. Restructuring Charges `

[0001564590-18-029831:notes:164]
In the first quarter of fiscal 2019, we announced a restructuring plan (the May 2018 Plan) to reduce costs and redirect resources to our highest return activities, which included a reduction in our global workforce of less than 2%. Charges related to the plan consisted primarily of employee severance-related costs. Substantially all activities under the plan have been completed.

[0001564590-18-029831:notes:165]
Management previously approved the November 2016 Plan, under which we reduced our global workforce by approximately 6%. We completed all workforce related activities under this plan as of the end of fiscal 2017. The remaining balance as of October 26, 2018 principally relates to lease obligations that will be paid over their remaining terms.

[0001564590-18-029831:notes:166]
[same as prior period, unchanged from 0001564590-18-022123:notes:159]

[0001564590-18-029831:notes:167]
|  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |
|  |  | May 2018 Plan |  |  | November 2016 Plan |  |  | Total |  |  | November 2016 Plan |  |
| Balance at beginning of period |  | $ | — |  |  | $ | 6 |  |  | $ | 6 |  |  | $ | 13 |  |
| Net charges |  |  | 19 |  |  |  | — |  |  |  | 19 |  |  |  | — |  |
| Cash payments |  |  | (17 | ) |  |  | (1 | ) |  |  | (18 | ) |  |  | (5 | ) |
| Balance at end of period |  | $ | 2 |  |  | $ | 5 |  |  | $ | 7 |  |  | $ | 8 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-029831:notes:168]
12. Income Taxes

[0001564590-18-029831:notes:169]
[same as prior period, unchanged from 0001564590-18-022123:notes:162]

[0001564590-18-029831:notes:170]
|  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Effective tax rates |  |  | 7.3 | % |  |  | 16.9 | % |

[0001564590-18-029831:notes:171]
Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations which are headquartered in the Netherlands, being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory tax rate. The differences in effective tax rates for the six months ended October 26, 2018 and October 27, 2017 were primarily related to the adoption of the new revenue standard, differences in discrete benefits for stock-based compensation and the reduced federal income tax rate due to U.S. tax reform.

[0001564590-18-029831:notes:172]
The effective tax rate for the six months ended October 27, 2017 has been restated to reflect the retrospective application of the new revenue standard. During the six months ended October 26, 2018, we recognized a $34 million discrete tax benefit for adjustments to certain intercompany transactions resulting from the retrospective application of the new standard. See Note 5 – Revenue for additional details.

[0001564590-18-029831:notes:173]
On December 22, 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, the imposition of a one-time transition tax on deferred foreign earnings, and the creation of new taxes on certain foreign-sourced earnings. As of October 26, 2018, we have not fully completed the accounting for the tax impacts of the TCJA. No significant adjustments to prior period estimates or positions have been made in the current period. The provisional amounts recorded are based on reasonable estimates and our current interpretation and understanding of the TCJA. The final impacts of U.S. tax reform may differ, possibly materially, due to factors such as the issuance of further regulatory guidance, changes in interpretations, and the collection and analysis of additional information. The Company is also still evaluating the effects of the TCJA’s global minimum tax on intangible low-taxed income (“GILTI”) and has not yet made an accounting policy election to either account for the tax under a period cost method or a deferred method. For the six months ended October 26, 2018, we have accounted for the GILTI tax under a period cost method as we continue to evaluate potential impacts. In accordance with Staff Accounting Bulletin 118, we will complete the accounting of the tax effects of the TCJA within the measurement period not to extend beyond one year from the enactment date.

[0001564590-18-029831:notes:174]
As of October 26, 2018, we had $356 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $306 million would affect our provision for income taxes if recognized, and $324 million has been recorded in other long-term liabilities.

[0001564590-18-029831:notes:175]
We are currently undergoing federal income tax audits in the U.S. and several foreign tax jurisdictions. Transfer pricing calculations are key issues under audits in various jurisdictions, and are often subject to dispute and appeals. The IRS has concluded the examination of our tax returns for our fiscal years through 2010. The IRS commenced the examination of our federal income tax returns for our fiscal years 2012 and 2013 in August 2016. We expect this examination to conclude within the next 12 months.

[0001564590-18-029831:notes:176]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for such withholding tax and filed an appeal with the Danish Tax Tribunal. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012. In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). Parties were heard before the court in October 2017. During March 2018, the Advocate General issued an opinion which was largely in favor of NetApp, however, the CJEU is not bound by the opinion of the Advocate General. It is expected that the preliminary ruling will be issued during our fiscal year 2019. Once a ruling has been issued by the CJEU, it will be reviewed and may be subjected to additional briefing by the DHC. Once complete, the DHC will issue its final decision. We expect this decision to be issued during our fiscal year 2019 or 2020.

[0001564590-18-029831:notes:177]
[same as prior period, unchanged from 0001564590-18-022123:notes:170]


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-029831:notes:178]
13. Net Income per Share

[0001564590-18-029831:notes:179]
[same as prior period, unchanged from 0001564590-18-022123:notes:172]

[0001564590-18-029831:notes:180]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 241 |  |  | $ | 174 |  |  | $ | 524 |  |  | $ | 305 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 258 |  |  |  | 269 |  |  |  | 260 |  |  |  | 270 |  |
| Dilutive impact of employee equity award plans |  |  | 6 |  |  |  | 6 |  |  |  | 7 |  |  |  | 7 |  |
| Shares used in diluted computation |  |  | 264 |  |  |  | 275 |  |  |  | 267 |  |  |  | 277 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.93 |  |  | $ | 0.65 |  |  | $ | 2.02 |  |  | $ | 1.13 |  |
| Diluted |  | $ | 0.91 |  |  | $ | 0.63 |  |  | $ | 1.96 |  |  | $ | 1.10 |  |

[0001564590-18-029831:notes:181]
No potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculation for the three or six months ended October 26, 2018. For the three and six months ended October 27, 2017, 1 million and 2 million potential shares from outstanding awards, respectively, were excluded from the calculation as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-029831:notes:182]
14. Segment, Geographic, and Significant Customer Information

[0001564590-18-029831:notes:183]
[same as prior period, unchanged from 0001564590-18-022123:notes:176]

[0001564590-18-029831:notes:184]
[same as prior period, unchanged from 0001564590-18-022123:notes:177]

[0001564590-18-029831:notes:185]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| United States, Canada and Latin America (Americas) |  | $ | 868 |  |  | $ | 792 |  |  | $ | 1,711 |  |  | $ | 1,513 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 429 |  |  |  | 426 |  |  |  | 859 |  |  |  | 827 |  |
| Asia Pacific (APAC) |  |  | 220 |  |  |  | 197 |  |  |  | 421 |  |  |  | 396 |  |
| Net revenues |  | $ | 1,517 |  |  | $ | 1,415 |  |  | $ | 2,991 |  |  | $ | 2,736 |  |

[0001564590-18-029831:notes:186]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $789 million and $722 million during the three months ended October 26, 2018 and October 27, 2017, respectively, and were $1,550 million and 1,361 million during the six months ended October 26, 2018 and October 27, 2017, respectively.

[0001564590-18-029831:notes:187]
[same as prior period, unchanged from 0001564590-18-022123:notes:180]

[0001564590-18-029831:notes:188]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| U.S. |  | $ | 405 |  |  | $ | 853 |  |
| International |  |  | 3,894 |  |  |  | 4,538 |  |
| Total |  | $ | 4,299 |  |  | $ | 5,391 |  |

[0001564590-18-029831:notes:189]
[same as prior period, unchanged from 0001564590-18-022123:notes:182]

[0001564590-18-029831:notes:190]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| U.S. |  | $ | 580 |  |  | $ | 566 |  |
| International |  |  | 190 |  |  |  | 190 |  |
| Total |  | $ | 770 |  |  | $ | 756 |  |

[0001564590-18-029831:notes:191]
[same as prior period, unchanged from 0001564590-18-022123:notes:184]

[0001564590-18-029831:notes:192]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2018 |  |  | October 27, 2017 |  |  | October 26, 2018 |  |  | October 27, 2017 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 22 | % |  |  | 23 | % |  |  | 23 | % |
| Tech Data Corporation |  |  | 21 | % |  |  | 19 | % |  |  | 19 | % |  |  | 20 | % |

[0001564590-18-029831:notes:193]
The following customers accounted for 10% or more of accounts receivable:

[0001564590-18-029831:notes:194]
|  |  | October 26, 2018 |  |  | April 27, 2018 |  |
| Arrow Electronics, Inc. |  |  | 11 | % |  |  | 17 | % |
| Tech Data Corporation |  |  | 24 | % |  |  | 17 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-029831:notes:195]
15. Commitments and Contingencies

[0001564590-18-029831:notes:196]
Operating Leases

[0001564590-18-029831:notes:197]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $172 million as of October 26, 2018.

[0001564590-18-029831:notes:198]
Purchase Orders and Other Commitments

[0001564590-18-029831:notes:199]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 26, 2018, we had $422 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 26, 2018 and April 27, 2018, such liability amounted to $16 million and $14 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-18-029831:notes:200]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 26, 2018, we had $5 million in construction related obligations and $187 million in other purchase obligations.

[0001564590-18-029831:notes:201]
Financing Guarantees

[0001564590-18-029831:notes:202]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $43 million and $49 million of receivables during the six months ended October 26, 2018 and October 27, 2017, respectively.

[0001564590-18-029831:notes:203]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-18-029831:notes:204]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of October 26, 2018 and April 27, 2018, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-18-029831:notes:205]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 26, 2018, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-18-029831:notes:206]
Legal Contingencies

[0001564590-18-029831:notes:207]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-18-029831:notes:208]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-18-029831:notes:209]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of October 26, 2018 related to such matters.
