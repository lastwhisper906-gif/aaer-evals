# NTAP MD&A — 0001564590-20-005025


## mdna

[0001564590-20-005025:mdna:1]
[same as prior period, unchanged from 0001564590-19-043736:mdna:1]

[0001564590-20-005025:mdna:2]
[same as prior period, unchanged from 0001564590-19-043736:mdna:2]

[0001564590-20-005025:mdna:3]
[same as prior period, unchanged from 0001564590-19-043736:mdna:3]

[0001564590-20-005025:mdna:4]
[same as prior period, unchanged from 0001564590-19-043736:mdna:4]

[0001564590-20-005025:mdna:5]
[same as prior period, unchanged from 0001564590-19-043736:mdna:5]

[0001564590-20-005025:mdna:6]
[same as prior period, unchanged from 0001564590-19-043736:mdna:6]

[0001564590-20-005025:mdna:7]
[same as prior period, unchanged from 0001564590-19-043736:mdna:7]

[0001564590-20-005025:mdna:8]
[same as prior period, unchanged from 0001564590-19-043736:mdna:8]

[0001564590-20-005025:mdna:9]
[same as prior period, unchanged from 0001564590-19-043736:mdna:9]

[0001564590-20-005025:mdna:10]
[same as prior period, unchanged from 0001564590-19-043736:mdna:10]

[0001564590-20-005025:mdna:11]
[same as prior period, unchanged from 0001564590-19-043736:mdna:11]

[0001564590-20-005025:mdna:12]
[same as prior period, unchanged from 0001564590-19-043736:mdna:12]

[0001564590-20-005025:mdna:13]
[same as prior period, unchanged from 0001564590-19-043736:mdna:13]

[0001564590-20-005025:mdna:14]
[same as prior period, unchanged from 0001564590-19-043736:mdna:14]

[0001564590-20-005025:mdna:15]
[same as prior period, unchanged from 0001564590-19-043736:mdna:15]

[0001564590-20-005025:mdna:16]
[same as prior period, unchanged from 0001564590-19-043736:mdna:16]

[0001564590-20-005025:mdna:17]
[same as prior period, unchanged from 0001564590-19-043736:mdna:17]

[0001564590-20-005025:mdna:18]
[same as prior period, unchanged from 0001564590-19-043736:mdna:18]

[0001564590-20-005025:mdna:19]
[same as prior period, unchanged from 0001564590-19-043736:mdna:19]

[0001564590-20-005025:mdna:20]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Net revenues |  | $ | 1,404 |  |  | $ | 1,563 |  |  | $ | 4,011 |  |  | $ | 4,554 |  |
| Gross profit |  | $ | 941 |  |  | $ | 982 |  |  | $ | 2,682 |  |  | $ | 2,919 |  |
| Gross profit margin percentage |  |  | 67 | % |  |  | 63 | % |  |  | 67 | % |  |  | 64 | % |
| Income from operations |  | $ | 268 |  |  | $ | 311 |  |  | $ | 668 |  |  | $ | 851 |  |
| Income from operations as a percentage of net revenues |  |  | 19 | % |  |  | 20 | % |  |  | 17 | % |  |  | 19 | % |
| Net income |  | $ | 277 |  |  | $ | 249 |  |  | $ | 623 |  |  | $ | 773 |  |
| Diluted net income per share |  | $ | 1.21 |  |  | $ | 0.98 |  |  | $ | 2.64 |  |  | $ | 2.94 |  |
| Operating cash flows |  | $ | 420 |  |  | $ | 451 |  |  | $ | 677 |  |  | $ | 942 |  |

[0001564590-20-005025:mdna:21]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,573 |  |  | $ | 3,668 |  |
| Cash conversion cycle (days) |  |  | 1 |  |  |  | 3 |  |

[0001564590-20-005025:mdna:22]
[same as prior period, unchanged from 0001564590-19-043736:mdna:22]

[0001564590-20-005025:mdna:23]
During the first nine months of fiscal 2020, we repurchased 22 million shares of our common stock at an average price of $57.36 per share, for an aggregate of $1,250 million. We also declared aggregate cash dividends of $1.44 per share in that period, for which we paid an aggregate of $334 million.

[0001564590-20-005025:mdna:24]
[same as prior period, unchanged from 0001564590-19-043736:mdna:28]

[0001564590-20-005025:mdna:25]
[same as prior period, unchanged from 0001564590-19-043736:mdna:29]

[0001564590-20-005025:mdna:26]
[same as prior period, unchanged from 0001564590-19-043736:mdna:30]

[0001564590-20-005025:mdna:27]
[same as prior period, unchanged from 0001564590-19-043736:mdna:31]

[0001564590-20-005025:mdna:28]
[same as prior period, unchanged from 0001564590-19-043736:mdna:32]

[0001564590-20-005025:mdna:29]
[same as prior period, unchanged from 0001564590-19-043736:mdna:34]

[0001564590-20-005025:mdna:30]
[same as prior period, unchanged from 0001564590-19-043736:mdna:35]

[0001564590-20-005025:mdna:31]
[same as prior period, unchanged from 0001564590-19-043736:mdna:36]

[0001564590-20-005025:mdna:32]
[same as prior period, unchanged from 0001564590-19-043736:mdna:33]

[0001564590-20-005025:mdna:33]
[same as prior period, unchanged from 0001564590-19-043736:mdna:37]

[0001564590-20-005025:mdna:34]
|  |  | Three Months Ended |  |  | Nine Months Ended |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 56 |  | % |  | 62 |  | % |  | 55 |  | % |  | 60 |  | % |
| Software maintenance |  |  | 19 |  |  |  | 15 |  |  |  | 19 |  |  |  | 15 |  |  |
| Hardware maintenance and other services |  |  | 25 |  |  |  | 23 |  |  |  | 26 |  |  |  | 24 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 26 |  |  |  | 30 |  |  |  | 25 |  |  |  | 28 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 6 |  |  |  | 7 |  |  |  | 7 |  |  |  | 7 |  |  |
| Gross profit |  |  | 67 |  |  |  | 63 |  |  |  | 67 |  |  |  | 64 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 29 |  |  |  | 26 |  |  |  | 30 |  |  |  | 27 |  |  |
| Research and development |  |  | 15 |  |  |  | 13 |  |  |  | 16 |  |  |  | 14 |  |  |
| General and administrative |  |  | 4 |  |  |  | 4 |  |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | — |  |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |
| Total operating expenses |  |  | 48 |  |  |  | 43 |  |  |  | 50 |  |  |  | 45 |  |  |
| Income from operations |  |  | 19 |  |  |  | 20 |  |  |  | 17 |  |  |  | 19 |  |  |
| Other income, net |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |
| Income before income taxes |  |  | 20 |  |  |  | 20 |  |  |  | 17 |  |  |  | 19 |  |  |
| Provision (benefit) for income taxes |  |  | — |  |  |  | 4 |  |  |  | 2 |  |  |  | 2 |  |  |
| Net income |  |  | 20 |  | % |  | 16 |  | % |  | 16 |  | % |  | 17 |  | % |

[0001564590-20-005025:mdna:35]
[same as prior period, unchanged from 0001564590-19-043736:mdna:39]

[0001564590-20-005025:mdna:36]
[same as prior period, unchanged from 0001564590-19-043736:mdna:40]

[0001564590-20-005025:mdna:37]
[same as prior period, unchanged from 0001564590-19-043736:mdna:41]

[0001564590-20-005025:mdna:38]
Net revenues for the third quarter and first nine months of fiscal 2020 were $1,404 million and $4,011 million, respectively, reflecting a decrease of $159 million, or 10%, and $543 million, or 12%, respectively, compared to the corresponding periods of the prior year, primarily reflecting lower product revenues, partially offset by a slight increase in software maintenance revenues. Hardware maintenance and other services revenues decreased slightly compared to the corresponding periods of the prior year.

[0001564590-20-005025:mdna:39]
Gross profit as a percentage of net revenues for the third quarter and first nine months of fiscal 2020 increased by four percentage points and three percentage points, respectively, compared to the corresponding periods in fiscal 2019, primarily reflecting higher margins on product revenues and hardware maintenance and other services revenues. Gross profit margins on product revenues increased by three percentage points in the third quarter of fiscal 2020 and by one percentage point in the first nine months of fiscal 2020, compared to the corresponding periods of fiscal 2019. Gross profit margins in both the third quarter and first nine months of fiscal 2020 benefitted from a higher mix of All Flash FAS (AFF) product sales and cost reductions. These benefits were partially offset in the first nine months of fiscal 2020 by high-margin revenue recognized related to the software license components of several ELAs in the corresponding period of fiscal 2019, which did not repeat in fiscal 2020.

[0001564590-20-005025:mdna:40]
Sales and marketing, research and development, and general and administrative expenses for the third quarter and the first nine months of fiscal 2020 totaled $673 million, or 48% of net revenues and $2,031 million, or 51% of revenues, respectively, representing an increase of five percentage points and six percentage points, respectively, when compared to the corresponding periods of fiscal 2019, primarily due to lower net revenues in the current year periods.

[0001564590-20-005025:mdna:41]
[same as prior period, unchanged from 0001564590-19-043736:mdna:46]

[0001564590-20-005025:mdna:42]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |
| Net revenues |  | $ | 1,404 |  |  | $ | 1,563 |  |  |  | (10 | )% |  | $ | 4,011 |  |  | $ | 4,554 |  |  |  | (12 | )% |

[0001564590-20-005025:mdna:43]
[same as prior period, unchanged from 0001564590-19-043736:mdna:44]

[0001564590-20-005025:mdna:44]
The decrease in net revenues for the third quarter and first nine months of fiscal 2020 compared to the corresponding periods of fiscal 2019 was primarily due to a decrease in product revenues of $180 million and $553 million, respectively. Product revenues as a percentage of net revenues decreased by approximately six percentage points in each the third quarter and first nine months of fiscal 2020 compared to the corresponding periods of fiscal 2019.

[0001564590-20-005025:mdna:45]
[same as prior period, unchanged from 0001564590-19-043736:mdna:49]

[0001564590-20-005025:mdna:46]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Arrow Electronics, Inc. |  |  | 25 | % |  |  | 25 | % |  |  | 25 | % |  |  | 24 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 20 | % |  |  | 20 | % |  |  | 19 | % |

[0001564590-20-005025:mdna:47]
[same as prior period, unchanged from 0001564590-19-043736:mdna:51]

[0001564590-20-005025:mdna:48]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |
| Product revenues |  | $ | 787 |  |  | $ | 967 |  |  |  | (19 | )% |  | $ | 2,202 |  |  | $ | 2,755 |  |  |  | (20 | )% |

[0001564590-20-005025:mdna:49]
[same as prior period, unchanged from 0001564590-19-043736:mdna:53]

[0001564590-20-005025:mdna:50]
Under the revised Strategic and Mature product groupings, as described in the Overview section above, product revenues from strategic solutions represented 61% and 57% of product revenues in the third quarter and first nine months of fiscal 2020, respectively, compared to 53% and 54% in the corresponding periods of the prior year, respectively. Product revenues from mature solutions represented 39% and 43% of product revenues in the third quarter and first nine months of fiscal 2020, respectively, compared to 47% and 46% in the corresponding periods of the prior year, respectively.

[0001564590-20-005025:mdna:51]
Product revenues declined in the third quarter and first nine months of fiscal 2020 compared to the corresponding periods of the prior year primarily due less favorable macroeconomic conditions, lower enterprise IT spending and, in the first quarter of fiscal 2020, go-to-market execution issues experienced with some of our largest global customer accounts.

[0001564590-20-005025:mdna:52]
Total product revenues from strategic solutions totaled $483 million in the third quarter of fiscal 2020 reflecting a 7% decrease from $517 million in the third quarter of fiscal 2019. Total product revenues from strategic solutions totaled $1,262 million in the first nine months of fiscal 2020 reflecting a 15% decrease from $1,477 million in the first nine months of fiscal 2019. These decreases were primarily due to decreased sales of most product types in the current year periods. A portion of the decrease in the first nine months of fiscal 2020 was also attributable to a substantial amount of revenue recognized in the corresponding prior year period related to the software license components of several ELAs which did not repeat in fiscal 2020.

[0001564590-20-005025:mdna:53]
Total product revenue from mature solutions totaled $304 million in the third quarter of fiscal 2020 reflecting a 32% decrease from $450 million in the third quarter of fiscal 2019. Total product revenue from mature solutions totaled $940 million in the first nine months of fiscal 2020 reflecting a 26% decrease from $1,278 million in the first nine months of fiscal 2019. These decreases were primarily due to decreased sales of FAS Hybrid and OEM products, as well as add-on storage, in the current year periods.

[0001564590-20-005025:mdna:54]
[same as prior period, unchanged from 0001564590-19-043736:mdna:59]

[0001564590-20-005025:mdna:55]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 263 |  |  | $ | 239 |  |  |  | 10 | % |  | $ | 767 |  |  | $ | 704 |  |  |  | 9 | % |

[0001564590-20-005025:mdna:56]
[same as prior period, unchanged from 0001564590-19-043736:mdna:61]

[0001564590-20-005025:mdna:57]
[same as prior period, unchanged from 0001564590-19-043736:mdna:62]

[0001564590-20-005025:mdna:58]
[same as prior period, unchanged from 0001564590-19-043736:mdna:63]

[0001564590-20-005025:mdna:59]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 354 |  |  | $ | 357 |  |  |  | (1 | )% |  | $ | 1,042 |  |  | $ | 1,095 |  |  |  | (5 | )% |

[0001564590-20-005025:mdna:60]
[same as prior period, unchanged from 0001564590-19-043736:mdna:65]

[0001564590-20-005025:mdna:61]
Hardware maintenance contract revenues were relatively flat at $293 million for the third quarter of fiscal 2020, compared to $292 million, for the third quarter of fiscal 2019, while they decreased slightly to $863 million in the first nine months of fiscal 2020 compared to $898 million for the corresponding period of the prior year, primarily due to a decline in average selling price on contracts executed more recently.

[0001564590-20-005025:mdna:62]
Professional services and educational and training services revenues were $61 million and $179 million, respectively, for the third quarter and first nine months of fiscal 2020, compared to $65 million and $197 million, respectively, for the corresponding periods of the prior year.

[0001564590-20-005025:mdna:63]
[same as prior period, unchanged from 0001564590-19-043736:mdna:68]

[0001564590-20-005025:mdna:64]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| United States, Canada and Latin America (Americas) |  |  | 50 | % |  |  | 52 | % |  |  | 52 | % |  |  | 55 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 35 | % |  |  | 33 | % |  |  | 32 | % |  |  | 30 | % |
| Asia Pacific (APAC) |  |  | 15 | % |  |  | 14 | % |  |  | 15 | % |  |  | 14 | % |

[0001564590-20-005025:mdna:65]
[same as prior period, unchanged from 0001564590-19-043736:mdna:70]

[0001564590-20-005025:mdna:66]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. During the third quarter and first nine months of fiscal 2020, Americas revenues were negatively impacted by general macroeconomic conditions in the region and, in the first quarter of fiscal 2020, go-to-market execution issues with some of our largest customer accounts, which was reflected in the geographic distribution of revenues as a percentage of net revenues in the fiscal 2020 periods compared to the corresponding periods of fiscal 2019.

[0001564590-20-005025:mdna:67]
[same as prior period, unchanged from 0001564590-19-043736:mdna:72]

[0001564590-20-005025:mdna:68]
[same as prior period, unchanged from 0001564590-19-043736:mdna:73]

[0001564590-20-005025:mdna:69]
[same as prior period, unchanged from 0001564590-19-043736:mdna:74]

[0001564590-20-005025:mdna:70]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |
| Cost of product revenues |  | $ | 360 |  |  | $ | 469 |  |  |  | (23 | )% |  | $ | 1,013 |  |  | $ | 1,295 |  |  |  | (22 | )% |

[0001564590-20-005025:mdna:71]
[same as prior period, unchanged from 0001564590-19-043736:mdna:76]

[0001564590-20-005025:mdna:72]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2020 to Fiscal 2019 |  |  | Fiscal 2020 to Fiscal 2019 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | (23 | ) |  |  | (23 | ) |
| Other |  |  | — |  |  |  | 1 |  |
| Total change |  |  | (23 | ) |  |  | (22 | ) |

[0001564590-20-005025:mdna:73]
Cost of product revenues represented 46% of product revenues for the third quarter and first nine months of fiscal 2020, compared to 49% and 47% for the third quarter and first nine months of fiscal 2019, respectively. Materials costs represented 87% and 85% of product costs for the third quarter and first nine months of fiscal 2020, respectively, compared to 90% in the corresponding periods of fiscal 2019.

[0001564590-20-005025:mdna:74]
32

[0001564590-20-005025:mdna:75]
Materials costs decreased $107 million and $297 million in the third quarter and first nine months of fiscal 2020, respectively, compared to the corresponding periods of the prior year, primarily due to a decline in product revenue and, to a lesser extent, a decline in the price of certain product components. The average unit materials costs of both AFF and FAS Hybrid systems decreased in the third quarter and first nine months of fiscal 2020 compared to the corresponding periods of fiscal 2019.

[0001564590-20-005025:mdna:76]
Margins on revenue recognized for strategic solutions increased during the third quarter and first nine months of fiscal 2020 compared to the corresponding periods of fiscal 2019, while margins for mature solutions decreased.

[0001564590-20-005025:mdna:77]
[same as prior period, unchanged from 0001564590-19-043736:mdna:81]

[0001564590-20-005025:mdna:78]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 12 |  |  | $ | 10 |  |  |  | 20 | % |  | $ | 33 |  |  | $ | 25 |  |  |  | 32 | % |

[0001564590-20-005025:mdna:79]
Cost of software maintenance revenues in dollars were relatively flat in the third quarter and first nine months of fiscal 2020 compared to the corresponding periods of fiscal 2019 and represented 5% of software maintenance revenues for the third quarter of fiscal 2020, 4% for the first nine months of fiscal 2020, and 4% for each of the corresponding periods of fiscal 2019.

[0001564590-20-005025:mdna:80]
[same as prior period, unchanged from 0001564590-19-043736:mdna:84]

[0001564590-20-005025:mdna:81]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 91 |  |  | $ | 102 |  |  |  | (11 | )% |  | $ | 283 |  |  | $ | 315 |  |  |  | (10 | )% |

[0001564590-20-005025:mdna:82]
Cost of hardware maintenance and other services revenues decreased by $11 million, or 11%, and $32 million, or 10%, respectively, for the third quarter and first nine months of fiscal 2020 compared to the corresponding periods of fiscal 2019 as a result of cost savings initiatives, and , for the first nine months of fiscal 2020, the decrease in hardware maintenance and other services revenues. Costs represented 26% and 27% of hardware maintenance and other services revenues in the third quarter and first nine months of fiscal 2020, respectively, compared to 29% in the third quarter and first nine months of fiscal 2019.

[0001564590-20-005025:mdna:83]
[same as prior period, unchanged from 0001564590-19-043736:mdna:87]

[0001564590-20-005025:mdna:84]
[same as prior period, unchanged from 0001564590-19-043736:mdna:88]

[0001564590-20-005025:mdna:85]
[same as prior period, unchanged from 0001564590-19-043736:mdna:89]

[0001564590-20-005025:mdna:86]
Total compensation costs included in operating expenses decreased by $8 million and $21 million in the third quarter and first nine months of fiscal 2020, respectively, compared to the corresponding periods of the prior year, each representing a decrease of 1%, primarily due to lower incentive compensation expense and stock-based compensation expense, partially offset by higher salaries expense, reflecting a 2% increase in average headcount in the fiscal 2020 periods. Compensation costs were also favorably impacted by foreign exchange rate fluctuations in the first nine months of fiscal 2020.

[0001564590-20-005025:mdna:87]
[same as prior period, unchanged from 0001564590-19-043736:mdna:91]

[0001564590-20-005025:mdna:88]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 402 |  |  | $ | 401 |  |  |  | — | % |  | $ | 1,196 |  |  | $ | 1,218 |  |  |  | (2 | )% |

[0001564590-20-005025:mdna:89]
33

[0001564590-20-005025:mdna:90]
[same as prior period, unchanged from 0001564590-19-043736:mdna:93]

[0001564590-20-005025:mdna:91]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2020 to Fiscal 2019 |  |  | Fiscal 2020 to Fiscal 2019 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (2 | ) |  |  | (2 | ) |
| Advertising and marketing promotional expense |  |  | 1 |  |  |  | (1 | ) |
| Other |  |  | 1 |  |  |  | 1 |  |
| Total change |  |  | — |  |  |  | (2 | ) |

[0001564590-20-005025:mdna:92]
The decrease in compensation costs for the third quarter and first nine months of fiscal 2020 compared to the corresponding periods of the prior year reflected a 2% decrease in average headcount in each of the current year periods. Advertising and marketing promotional expense was relatively flat in the third quarter and first nine months of fiscal 2020 compared to the corresponding periods of the prior year, with the minor variations due primarily to the timing of marketing events and promotions. Sales and marketing expenses in the first nine months of fiscal 2020 also benefitted slightly from foreign exchange rate fluctuations.

[0001564590-20-005025:mdna:93]
[same as prior period, unchanged from 0001564590-19-043736:mdna:96]

[0001564590-20-005025:mdna:94]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |
| Research and development expenses |  | $ | 211 |  |  | $ | 203 |  |  |  | 4 | % |  | $ | 635 |  |  | $ | 622 |  |  |  | 2 | % |

[0001564590-20-005025:mdna:95]
[same as prior period, unchanged from 0001564590-19-043736:mdna:98]

[0001564590-20-005025:mdna:96]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2020 to Fiscal 2019 |  |  | Fiscal 2020 to Fiscal 2019 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 2 |  |  |  | 2 |  |
| Development projects and outside services |  |  | 1 |  |  |  | (1 | ) |
| Other |  |  | 1 |  |  |  | 1 |  |
| Total change |  |  | 4 |  |  |  | 2 |  |

[0001564590-20-005025:mdna:97]
The increase in compensation costs for the third quarter and first nine months of fiscal 2020 compared to the corresponding periods in the prior year was attributable to an increase in average headcount of 9% and 8%, respectively, resulting in higher salaries and benefits expense, partially offset by lower incentive compensation expense. The increase in headcount reflects our investment in additional engineering resources to support the expansion and enhancement of products and solutions targeted at our most important customer and market opportunities. Development projects and outside services expense was relatively flat in the third quarter and first nine months of fiscal 2020 with the minor fluctuations due to timing of development efforts for new product introductions.

[0001564590-20-005025:mdna:98]
[same as prior period, unchanged from 0001564590-19-043736:mdna:101]

[0001564590-20-005025:mdna:99]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |
| General and administrative expenses |  | $ | 60 |  |  | $ | 67 |  |  |  | (10 | )% |  | $ | 200 |  |  | $ | 209 |  |  |  | (4 | )% |

[0001564590-20-005025:mdna:100]
[same as prior period, unchanged from 0001564590-19-043736:mdna:103]

[0001564590-20-005025:mdna:101]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2020 to Fiscal 2019 |  |  | Fiscal 2020 to Fiscal 2019 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (4 | ) |  |  | (7 | ) |
| Professional and legal fees and outside services |  |  | (2 | ) |  |  | 7 |  |
| Facilities and IT support costs |  |  | (2 | ) |  |  | (4 | ) |
| Other |  |  | (2 | ) |  |  | — |  |
| Total change |  |  | (10 | ) |  |  | (4 | ) |

[0001564590-20-005025:mdna:102]
While average headcount increased in the third quarter and first nine months of fiscal 2020 compared to the corresponding periods of the prior year, compensation costs decreased because a greater percentage of employees were located in lower cost geographies. The fluctuations in professional and legal fees and outside services expense in the third quarter and the first nine months of fiscal 2020 were primarily due to the timing of our spend on business transformation projects, while the decreases in facilities and IT support costs were primarily due to lower spending levels on IT projects.

[0001564590-20-005025:mdna:103]
[same as prior period, unchanged from 0001564590-19-043736:mdna:106]

[0001564590-20-005025:mdna:104]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |
| Restructuring charges |  | $ | — |  |  | $ | — |  |  | NM |  | $ | 21 |  |  | $ | 19 |  |  |  | 11 | % |

[0001564590-20-005025:mdna:105]
[same as prior period, unchanged from 0001564590-19-043736:mdna:108]

[0001564590-20-005025:mdna:106]
[same as prior period, unchanged from 0001564590-19-043736:mdna:109]

[0001564590-20-005025:mdna:107]
[same as prior period, unchanged from 0001564590-19-043736:mdna:110]

[0001564590-20-005025:mdna:108]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |
| Gain on sale or derecognition of assets |  | $ | — |  |  | $ | — |  |  | NM |  | $ | (38 | ) |  | $ | — |  |  | NM |

[0001564590-20-005025:mdna:109]
[same as prior period, unchanged from 0001564590-19-043736:mdna:112]

[0001564590-20-005025:mdna:110]
In September 2017, we entered into an agreement to sell certain land and buildings located in Sunnyvale, California, through two separate and independent closings, the first of which was completed in the third quarter of fiscal 2018. The remaining properties, consisting of land, were classified as assets held for sale, and included as other current assets in our condensed consolidated balance sheet as of April 26, 2019. On August 29, 2019, the second closing occurred and we consummated the sale of the land, with a net book value of $53 million, and received cash proceeds of $96 million, resulting in a gain, net of direct selling costs, of $38 million.

[0001564590-20-005025:mdna:111]
[same as prior period, unchanged from 0001564590-19-043736:mdna:114]

[0001564590-20-005025:mdna:112]
[same as prior period, unchanged from 0001564590-19-043736:mdna:115]

[0001564590-20-005025:mdna:113]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |
| Interest income |  | $ | 10 |  |  | $ | 22 |  |  |  | (55 | )% |  | $ | 41 |  |  | $ | 68 |  |  |  | (40 | )% |
| Interest expense |  |  | (14 | ) |  |  | (16 | ) |  |  | (13 | )% |  |  | (41 | ) |  |  | (44 | ) |  |  | (7 | )% |
| Other income, net |  |  | 12 |  |  |  | 2 |  |  | NM |  |  |  | 26 |  |  |  | 9 |  |  |  | 189 | % |
| Total |  | $ | 8 |  |  | $ | 8 |  |  |  | — | % |  | $ | 26 |  |  | $ | 33 |  |  |  | (21 | )% |

[0001564590-20-005025:mdna:114]
[same as prior period, unchanged from 0001564590-19-043736:mdna:117]

[0001564590-20-005025:mdna:115]
Interest income decreased in the third quarter and first nine months of fiscal 2020 compared to the corresponding periods of the prior year due to a reduction in the size of our investment portfolio as a result of our sale of approximately $1.0 billion of available-for-sale debt securities in the first quarter of fiscal 2020. Other income, net increased in the first nine months of fiscal 2020 compared to the corresponding period of fiscal 2019 as a result of the $14 million gain we realized from the sale of these securities, while it increased in the third quarter of fiscal 2020 compared to the third quarter of fiscal 2019 primarily due to differences in foreign exchange gains and losses. Interest expense remained relatively flat in the third quarter and first nine months of fiscal 2020 compared to the corresponding periods of the prior year, as we repaid our maturing Senior Notes but increased our average outstanding commercial paper balance.

[0001564590-20-005025:mdna:116]
35

[0001564590-20-005025:mdna:117]
Provision (Benefit) for Income Taxes (in millions, except percentages):

[0001564590-20-005025:mdna:118]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | % Change |  |
| Provision (benefit) for income taxes |  | $ | (1 | ) |  | $ | 70 |  |  |  | (101 | )% |  | $ | 71 |  |  | $ | 111 |  |  |  | (36 | )% |

[0001564590-20-005025:mdna:119]
Our effective tax rate for the third quarter of fiscal 2020 was (0.4)% compared to 21.9% for the third quarter of fiscal 2019. Our effective tax rate for the first nine months of fiscal 2020 was 10.2% compared to 12.6% for the corresponding period of fiscal 2019. Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rate decreased for the third quarter of fiscal 2020 compared to the corresponding period of the prior year primarily due to the discrete tax benefits related to the lapse of statues of limitations and the differences in discrete tax benefits for stock-based compensation. Our effective tax rate decreased for the first nine months of fiscal 2020 compared to the corresponding period in the prior year primarily due to the same items that impacted the effective tax rate for the third quarter of fiscal 2020, partially offset by the discrete tax benefits related to the adoption of the new revenue standard in fiscal 2019.

[0001564590-20-005025:mdna:120]
[same as prior period, unchanged from 0001564590-19-043736:mdna:122]

[0001564590-20-005025:mdna:121]
We recognized a $50 million discrete tax benefit related to the lapse of certain statutes of limitations in the third quarter of fiscal 2020. During fiscal 2019, we adopted the new revenue accounting standard and, during the nine months ended January 25, 2019, we recognized a $34 million discrete tax benefit for adjustments to certain intercompany transactions resulting from the retrospective application of the new revenue accounting standard.

[0001564590-20-005025:mdna:122]
As of January 24, 2020, we had $187 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $165 million would affect our provision for income taxes if recognized, and $167 million has been recorded in other long-term liabilities.

[0001564590-20-005025:mdna:123]
[same as prior period, unchanged from 0001564590-19-043736:mdna:125]

[0001564590-20-005025:mdna:124]
[same as prior period, unchanged from 0001564590-19-043736:mdna:126]

[0001564590-20-005025:mdna:125]
| (In millions, except percentages) |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,008 |  |  | $ | 3,899 |  |
| Principal amount of debt |  | $ | 1,844 |  |  | $ | 1,799 |  |

[0001564590-20-005025:mdna:126]
[same as prior period, unchanged from 0001564590-19-043736:mdna:128]

[0001564590-20-005025:mdna:127]
|  |  | Nine Months Ended |  |
| (In millions) |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Net cash provided by operating activities |  | $ | 677 |  |  | $ | 942 |  |
| Net cash provided by investing activities |  |  | 1,227 |  |  |  | 521 |  |
| Net cash used in financing activities |  |  | (1,520 | ) |  |  | (2,117 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (4 | ) |  |  | (17 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 380 |  |  | $ | (671 | ) |

[0001564590-20-005025:mdna:128]
[same as prior period, unchanged from 0001564590-19-043736:mdna:130]

[0001564590-20-005025:mdna:129]
As of January 24, 2020, our cash, cash equivalents and short-term investments were $3.0 billion, a decrease of $0.9 billion from April 26, 2019. The decrease was primarily due to $1.3 billion paid for the repurchase of our common stock, $400 million used for the repayment of our Senior Notes due September 2019, $334 million used for the payment of dividends, and $100 million in purchases of property and equipment, partially offset by $443 million in proceeds from the issuance of commercial paper notes, net, $96 million in proceeds from the sale of properties, and $677 million of cash provided by operating activities. Working capital decreased by $1.0 billion to $0.7 billion as of January 24, 2020 compared to April 26, 2019 primarily due to the decreases in cash, cash equivalents and short-term investments discussed above.

[0001564590-20-005025:mdna:130]
[same as prior period, unchanged from 0001564590-19-043736:mdna:132]

[0001564590-20-005025:mdna:131]
[same as prior period, unchanged from 0001564590-19-043736:mdna:133]

[0001564590-20-005025:mdna:132]
|  |  | Three Months Ended |  |
| (In days) |  | January 24, 2020 |  |  | April 26, 2019 |  |  | January 25, 2019 |  |
| Days sales outstanding (1) |  |  | 53 |  |  |  | 70 |  |  |  | 51 |  |
| Days inventory outstanding (2) |  |  | 22 |  |  |  | 21 |  |  |  | 16 |  |
| Days payables outstanding (3) |  |  | (75 | ) |  |  | (87 | ) |  |  | (78 | ) |
| Cash conversion cycle (4) |  |  | 1 |  |  |  | 3 |  |  |  | (11 | ) |

[0001564590-20-005025:mdna:133]
[same as prior period, unchanged from 0001564590-19-043736:mdna:135]

[0001564590-20-005025:mdna:134]
| (1) | Days sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on ending accounts receivable and net revenue for each period. DSO is calculated by dividing accounts receivable by average net revenue per day for the current quarter (91 days for each of the quarters presented above). DSO for the third quarter of fiscal 2020 was relatively flat compared to the corresponding period of fiscal 2019, while it decreased compared to the fourth quarter of fiscal 2019 due to lower seasonal invoicing levels and more favorable shipping linearity. |

[0001564590-20-005025:mdna:135]
| (2) | Days inventory outstanding, referred to as DIO, measures the average number of days from procurement to sale of our products. DIO is based on ending inventory and cost of revenues for each period. DIO is calculated by dividing ending inventory by average cost of revenues per day for the current quarter. DIO for the third quarter of fiscal 2020 increased compared to the corresponding period of fiscal 2019 as a result of higher levels of on hand inventory and lower cost of revenues in the current year period, while it was relatively flat compared to the fourth quarter of fiscal 2019. |

[0001564590-20-005025:mdna:136]
| (3) | Days payables outstanding, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and cost of revenues for each period. DPO is calculated by dividing accounts payable by average cost of revenues per day for the current quarter. DPO for the third quarter of fiscal 2020 was relatively consistent with the corresponding period of fiscal 2019, while it decreased compared to the fourth quarter of 2019, primarily due to the timing of purchases from contract manufacturers. |

[0001564590-20-005025:mdna:137]
[same as prior period, unchanged from 0001564590-19-043736:mdna:139]

[0001564590-20-005025:mdna:138]
[same as prior period, unchanged from 0001564590-19-043736:mdna:140]

[0001564590-20-005025:mdna:139]
During the first nine months of fiscal 2020, we generated cash from operating activities of $677 million, reflecting net income of $623 million, adjusted by non-cash depreciation and amortization of $146 million, stock-based compensation of $118 million, and a gain on sale of properties of $38 million, compared to $942 million of cash generated from operating activities during the first nine months of fiscal 2019.

[0001564590-20-005025:mdna:140]
Changes in assets and liabilities in the first nine months of fiscal 2020 included the following:

[0001564590-20-005025:mdna:141]
|  | • | Accounts receivable decreased $394 million, reflecting lower DSO. |

[0001564590-20-005025:mdna:142]
|  | • | Accounts payable decreased $158 million, reflecting lower DPO. |

[0001564590-20-005025:mdna:143]
|  | • | Accrued expenses decreased $273 million, primarily due to employee compensation payouts related to fiscal year 2019 commissions and incentive compensation plans and payments of income taxes. |

[0001564590-20-005025:mdna:144]
[same as prior period, unchanged from 0001564590-19-043736:mdna:147]

[0001564590-20-005025:mdna:145]
[same as prior period, unchanged from 0001564590-19-043736:mdna:148]

[0001564590-20-005025:mdna:146]
During the first nine months of fiscal 2020, we generated $1.3 billion from maturities and sales of investments, net of purchases, and paid $100 million for capital expenditures, while during the first nine months of fiscal 2019, we generated $661 million from maturities and sales of investments, net of purchases, and paid $138 million for capital expenditures. Additionally, during the first nine months of fiscal 2020, we received $96 million for the sale of land in Sunnyvale, California and paid $56 million net to acquire a privately-held company.

[0001564590-20-005025:mdna:147]
[same as prior period, unchanged from 0001564590-19-043736:mdna:150]

[0001564590-20-005025:mdna:148]
During the first nine months of fiscal 2020, we used $1.3 billion for the repurchase of 22 million shares of our common stock, $334 million for the payment of dividends, and $400 million for the repayment of our Senior Notes due September 2019, partially offset by $443 million in proceeds from the issuance of commercial paper notes, net, compared to $1.6 billion used for the repurchase of 22 million shares of common stock, $306 million used for the payment of dividends, and $221 million used for the repayment of commercial paper notes, net, during the first nine months of fiscal 2019.

[0001564590-20-005025:mdna:149]
[same as prior period, unchanged from 0001564590-19-043736:mdna:152]

[0001564590-20-005025:mdna:150]
[same as prior period, unchanged from 0001564590-19-043736:mdna:153]

[0001564590-20-005025:mdna:151]
Our principal sources of liquidity as of January 24, 2020 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001564590-20-005025:mdna:152]
[same as prior period, unchanged from 0001564590-19-043736:mdna:155]

[0001564590-20-005025:mdna:153]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Cash and cash equivalents |  | $ | 2,705 |  |  | $ | 2,325 |  |
| Short-term investments |  |  | 303 |  |  |  | 1,574 |  |
| Total |  | $ | 3,008 |  |  | $ | 3,899 |  |

[0001564590-20-005025:mdna:154]
As of January 24, 2020 and April 26, 2019, $2.5 billion and $3.7 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.5 billion and $0.2 billion, respectively, were available in the U.S. The TCJA imposed a one-time transition tax on substantially all accumulated foreign earnings through December 31, 2017, and generally allows companies to make distributions of foreign earnings without incurring additional federal taxes. As a part of the recognition of the impacts of the TCJA, we have reviewed our projected global cash requirements and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested.

[0001564590-20-005025:mdna:155]
[same as prior period, unchanged from 0001564590-19-043736:mdna:158]

[0001564590-20-005025:mdna:156]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of January 24, 2020.

[0001564590-20-005025:mdna:157]
[same as prior period, unchanged from 0001564590-19-043736:mdna:161]

[0001564590-20-005025:mdna:158]
[same as prior period, unchanged from 0001564590-19-043736:mdna:162]

[0001564590-20-005025:mdna:159]
The following table summarizes the principal amount of our Senior Notes as of January 24, 2020 (in millions):

[0001564590-20-005025:mdna:160]
| 3.375% Senior Notes Due June 2021 |  | $ | 500 |  |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| Total |  | $ | 1,150 |  |

[0001564590-20-005025:mdna:161]
[same as prior period, unchanged from 0001564590-19-043736:mdna:165]

[0001564590-20-005025:mdna:162]
Commercial Paper Program and Credit Facility

[0001564590-20-005025:mdna:163]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of January 24, 2020, we had commercial paper notes outstanding with an aggregate principal amount of $694 million, a weighted-average interest rate of 1.97% and maturities generally less than three months.

[0001564590-20-005025:mdna:164]
In connection with the Program, we have a senior unsecured credit agreement that expires on December 10, 2021. The credit agreement provides a $1.0 billion revolving unsecured credit facility that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes, providing another potential source of liquidity to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement also includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of January 24, 2020, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-20-005025:mdna:165]
[same as prior period, unchanged from 0001564590-19-043736:mdna:169]

[0001564590-20-005025:mdna:166]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2020 to be between $50 million and $75 million.

[0001564590-20-005025:mdna:167]
[same as prior period, unchanged from 0001564590-19-043736:mdna:171]

[0001564590-20-005025:mdna:168]
On February 12, 2020, we declared a cash dividend of $0.48 per share of common stock, payable on April 22, 2020 to holders of record as of the close of business on April 3, 2020.

[0001564590-20-005025:mdna:169]
Our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through January 24, 2020, we repurchased a total of 335 million shares of our common stock at an average price of $38.76 per share, for an aggregate purchase price of $13.0 billion. As of January 24, 2020, the remaining authorized amount for stock repurchases under this program was $0.6 billion.

[0001564590-20-005025:mdna:170]
[same as prior period, unchanged from 0001564590-19-043736:mdna:174]

[0001564590-20-005025:mdna:171]
[same as prior period, unchanged from 0001564590-19-043736:mdna:175]

[0001564590-20-005025:mdna:172]
[same as prior period, unchanged from 0001564590-19-043736:mdna:176]

[0001564590-20-005025:mdna:173]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 24, 2020, we had $486 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-20-005025:mdna:174]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of January 24, 2020, we had $7 million in construction related obligations and $234 million in other purchase obligations.

[0001564590-20-005025:mdna:175]
[same as prior period, unchanged from 0001564590-19-043736:mdna:179]

[0001564590-20-005025:mdna:176]
As of January 24, 2020, our liability for uncertain tax positions was $167 million, including interest, penalties and certain income tax benefits. Due to uncertainties regarding tax audits and their possible outcomes, we are unable to make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-20-005025:mdna:177]
[same as prior period, unchanged from 0001564590-19-043736:mdna:181]

[0001564590-20-005025:mdna:178]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $49 million and $54 million of receivables during the first nine months of fiscal 2020 and fiscal 2019, respectively.

[0001564590-20-005025:mdna:179]
[same as prior period, unchanged from 0001564590-19-043736:mdna:183]

[0001564590-20-005025:mdna:180]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of January 24, 2020 and April 26, 2019, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-20-005025:mdna:181]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of January 24, 2020, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-20-005025:mdna:182]
[same as prior period, unchanged from 0001564590-19-043736:mdna:186]

[0001564590-20-005025:mdna:183]
[same as prior period, unchanged from 0001564590-19-043736:mdna:187]

[0001564590-20-005025:mdna:184]
Legal Contingencies

[0001564590-20-005025:mdna:185]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 16 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0001564590-20-005025:mdna:186]
[same as prior period, unchanged from 0001564590-19-043736:mdna:191]
