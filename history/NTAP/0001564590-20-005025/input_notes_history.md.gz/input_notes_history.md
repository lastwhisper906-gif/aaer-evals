# NTAP note change history — 0001564590-19-043736 → 0001564590-20-005025


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-02-18):
[0001564590-20-005025:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 24, 2020, we had $486 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 24, 2020 and April 26, 2019, such liability amounted to $10 million and $16 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2019-11-18, similarity 0.9859):
[0001564590-19-043736:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 25, 2019, we had $447 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 25, 2019 and April 26, 2019, such liability amounted to $13 million and $16 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2020-02-18):
[0001564590-20-005025:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 24, 2020, we had $7 million in construction related obligations and $234 million in other purchase obligations.
  (was, 2019-11-18, similarity 0.9809):
[0001564590-19-043736:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 25, 2019, we had $5 million in construction related obligations and $244 million in other purchase obligations.

- changed (2020-02-18):
[0001564590-20-005025:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $49 million and $54 million of receivables during the nine months ended January 24, 2020 and January 25, 2019, respectively.
  (was, 2019-11-18, similarity 0.9689):
[0001564590-19-043736:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $34 million and $43 million of receivables during the six months ended October 25, 2019 and October 26, 2018, respectively.

- changed (2020-02-18):
[0001564590-20-005025:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of January 24, 2020 and April 26, 2019, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2019-11-18, similarity 0.9938):
[0001564590-19-043736:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of October 25, 2019 and April 26, 2019, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- added (2020-02-18):
[0001564590-20-005025:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 24, 2020, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- changed (2020-02-18):
[0001564590-20-005025:note_history:6]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends.  No material accrual has been recorded as of January 24, 2020 related to such matters.
  (was, 2019-11-18, similarity 0.9921):
[0001564590-19-043736:note_history:6]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends.  No material accrual has been recorded as of October 25, 2019 related to such matters.

- removed (2020-02-18):
[0001564590-19-043736:note_history:7]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 25, 2019, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-02-18):
[0001564590-20-005025:note_history:8]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 26, 2019 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 24, 2020 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2019-11-18, similarity 0.9773):
[0001564590-19-043736:note_history:8]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 26, 2019 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 25, 2019 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- changed (2020-02-18):
[0001564590-20-005025:note_history:9]
There have been no other significant changes in our significant accounting policies as of and for the nine months ended January 24, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 26, 2019.
  (was, 2019-11-18, similarity 0.9597):
[0001564590-19-043736:note_history:9]
There have been no other significant changes in our significant accounting policies as of and for the six months ended October 25, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 26, 2019.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-18):
[0001564590-20-005025:note_history:10]
|  |  |  |  |  |  | January 24, 2020 |  |  | April 26, 2019 |  |
|  |  | Effective Interest Rate |  |  | Amount |  |  | Amount |  |
| 2.00% Senior Notes Due September 2019 |  | 2.32% |  |  | $ | — |  |  | $ | 400 |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  |  | 500 |  |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| Total principal amount |  |  |  |  |  |  | 1,150 |  |  |  | 1,550 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (4 | ) |  |  | (6 | ) |
| Total senior notes |  |  |  |  |  |  | 1,146 |  |  |  | 1,544 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | — |  |  |  | (400 | ) |
| Total long-term debt |  |  |  |  |  | $ | 1,146 |  |  | $ | 1,144 |  |
  (was, 2019-11-18, similarity 0.6728):
[0001564590-19-043736:note_history:10]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | — |  |  | N/A |  |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,150 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (5 | ) |  |  |  |  |  |  | (6 | ) |  |  |  |  |
| Total senior notes |  |  | 1,145 |  |  |  |  |  |  |  | 1,544 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | — |  |  |  |  |  |  |  | (400 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,145 |  |  |  |  |  |  | $ | 1,144 |  |  |  |  |  |

- changed (2020-02-18):
[0001564590-20-005025:note_history:11]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 24, 2020, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2019-11-18, similarity 0.9892):
[0001564590-19-043736:note_history:11]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 25, 2019, we were in compliance with all covenants associated with the Senior Notes.

- changed (2020-02-18):
[0001564590-20-005025:note_history:12]
As of January 24, 2020, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2019-11-18, similarity 0.9362):
[0001564590-19-043736:note_history:12]
As of October 25, 2019, our aggregate future principal debt maturities are as follows (in millions):

- changed (2020-02-18):
[0001564590-20-005025:note_history:13]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of January 24, 2020 and April 26, 2019, we had commercial paper notes outstanding with aggregate principal amounts of $694 million and $249 million, respectively, weighted-average interest rates of 1.97% and 2.73%, respectively, and maturities generally less than three months.
  (was, 2019-11-18, similarity 0.7921):
[0001564590-19-043736:note_history:13]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of October 25, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $499 million, a weighted-average interest rate of 2.20% and maturities ranging from 7 days to 91 days. As of April 26, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $249 million, a weighted-average interest rate of 2.73% and maturities ranging from 27 days to 38 days.

- changed (2020-02-18):
[0001564590-20-005025:note_history:14]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of January 24, 2020 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.
  (was, 2019-11-18, similarity 0.9922):
[0001564590-19-043736:note_history:14]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of October 25, 2019 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

- removed (2020-02-18):
[0001564590-19-043736:note_history:15]
N/A – Not Applicable


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-18):
[0001564590-20-005025:note_history:16]
|  |  |  |  |  |  | January 24, 2020 |  |  | April 26, 2019 |  |
|  |  | Effective Interest Rate |  |  | Amount |  |  | Amount |  |
| 2.00% Senior Notes Due September 2019 |  | 2.32% |  |  | $ | — |  |  | $ | 400 |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  |  | 500 |  |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| Total principal amount |  |  |  |  |  |  | 1,150 |  |  |  | 1,550 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (4 | ) |  |  | (6 | ) |
| Total senior notes |  |  |  |  |  |  | 1,146 |  |  |  | 1,544 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | — |  |  |  | (400 | ) |
| Total long-term debt |  |  |  |  |  | $ | 1,146 |  |  | $ | 1,144 |  |
  (was, 2019-11-18, similarity 0.6728):
[0001564590-19-043736:note_history:16]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | — |  |  | N/A |  |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,150 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (5 | ) |  |  |  |  |  |  | (6 | ) |  |  |  |  |
| Total senior notes |  |  | 1,145 |  |  |  |  |  |  |  | 1,544 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | — |  |  |  |  |  |  |  | (400 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,145 |  |  |  |  |  |  | $ | 1,144 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-18):
[0001564590-20-005025:note_history:17]
As of January 24, 2020, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2019-11-18, similarity 0.9362):
[0001564590-19-043736:note_history:17]
As of October 25, 2019, our aggregate future principal debt maturities are as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-02-18):
[0001564590-20-005025:note_history:18]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Product revenues |  | $ | 787 |  |  | $ | 967 |  |  | $ | 2,202 |  |  | $ | 2,755 |  |
| Strategic |  | 483 |  |  | 517 |  |  |  | 1,262 |  |  |  | 1,477 |  |
| Mature |  | 304 |  |  | 450 |  |  |  | 940 |  |  |  | 1,278 |  |
| Software maintenance revenues |  | 263 |  |  | 239 |  |  | 767 |  |  | 704 |  |
| Hardware maintenance and other services revenues |  | 354 |  |  | 357 |  |  |  | 1,042 |  |  |  | 1,095 |  |
| Hardware maintenance support contracts |  | 293 |  |  | 292 |  |  | 863 |  |  |  | 898 |  |
| Professional and other services |  | 61 |  |  | 65 |  |  | 179 |  |  |  | 197 |  |
| Net revenues |  | $ | 1,404 |  |  | $ | 1,563 |  |  | $ | 4,011 |  |  | $ | 4,554 |  |

- removed (2020-02-18):
[0001564590-19-043736:note_history:19]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Product revenues |  | $ | 771 |  |  | $ | 913 |  |  | $ | 1,415 |  |  | $ | 1,788 |  |
| Strategic |  | 442 |  |  | 485 |  |  |  | 779 |  |  |  | 960 |  |
| Mature |  | 329 |  |  | 428 |  |  |  | 636 |  |  |  | 828 |  |
| Software maintenance revenues |  | 254 |  |  | 236 |  |  |  | 504 |  |  | 465 |  |
| Hardware maintenance and other services revenues |  | 346 |  |  | 368 |  |  |  | 688 |  |  |  | 738 |  |
| Hardware maintenance support contracts |  | 286 |  |  | 303 |  |  |  | 570 |  |  |  | 606 |  |
| Professional and other services |  | 60 |  |  | 65 |  |  |  | 118 |  |  |  | 132 |  |
| Net revenues |  | $ | 1,371 |  |  | $ | 1,517 |  |  | $ | 2,607 |  |  | $ | 2,991 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-02-18):
[0001564590-20-005025:note_history:20]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. As our product portfolio evolves, market dynamics change, and management continues to assess our largest growth opportunities, we periodically change how we group certain products. Beginning in fiscal 2020, Strategic includes All-flash FAS (AFF) products, including all related add-on hardware and operating system (OS) software, private cloud solutions (including SolidFire, converged and hyper-converged infrastructure products, StorageGrid), enterprise software license agreements (ELAs) and other optional add-on software products. Mature now includes Hybrid FAS products, including all related add-on hardware and OS software, original equipment manufacturers (OEM) products, and branded E-Series. Prior to this grouping change, Hybrid FAS products and branded E-Series were included in Strategic, while all add-on hardware and OS software were included in Mature. For comparability, Strategic and Mature revenues presented for the prior year periods have been recast based on the revised groupings.
  (was, 2019-11-18, similarity 0.9988):
[0001564590-19-043736:note_history:20]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. As our product portfolio evolves, market dynamics change, and management continues to assess of our largest growth opportunities, we periodically change how we group certain products. Beginning in fiscal 2020, Strategic includes All-flash FAS (AFF) products, including all related add-on hardware and operating system (OS) software, private cloud solutions (including SolidFire, converged and hyper-converged infrastructure products, StorageGrid), enterprise software license agreements (ELAs) and other optional add-on software products. Mature now includes Hybrid FAS products, including all related add-on hardware and OS software, original equipment manufacturers (OEM) products, and branded E-Series. Prior to this grouping change, Hybrid FAS products and branded E-Series were included in Strategic, while all add-on hardware and OS software were included in Mature. For comparability, Strategic and Mature revenues presented for the prior year periods have been recast based on the revised groupings.

- added (2020-02-18):
[0001564590-20-005025:note_history:21]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Product revenues |  | $ | 787 |  |  | $ | 967 |  |  | $ | 2,202 |  |  | $ | 2,755 |  |
| Strategic |  | 483 |  |  | 517 |  |  |  | 1,262 |  |  |  | 1,477 |  |
| Mature |  | 304 |  |  | 450 |  |  |  | 940 |  |  |  | 1,278 |  |
| Software maintenance revenues |  | 263 |  |  | 239 |  |  | 767 |  |  | 704 |  |
| Hardware maintenance and other services revenues |  | 354 |  |  | 357 |  |  |  | 1,042 |  |  |  | 1,095 |  |
| Hardware maintenance support contracts |  | 293 |  |  | 292 |  |  | 863 |  |  |  | 898 |  |
| Professional and other services |  | 61 |  |  | 65 |  |  | 179 |  |  |  | 197 |  |
| Net revenues |  | $ | 1,404 |  |  | $ | 1,563 |  |  | $ | 4,011 |  |  | $ | 4,554 |  |

- changed (2020-02-18):
[0001564590-20-005025:note_history:22]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Deferred product revenue |  | $ | 73 |  |  | $ | 84 |  |
| Deferred services revenue |  |  | 3,439 |  |  |  | 3,502 |  |
| Financed unearned services revenue |  |  | 61 |  |  |  | 82 |  |
| Total |  | $ | 3,573 |  |  | $ | 3,668 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,795 |  |  | $ | 1,825 |  |
| Long-term |  |  | 1,778 |  |  |  | 1,843 |  |
| Total |  | $ | 3,573 |  |  | $ | 3,668 |  |
  (was, 2019-11-18, similarity 0.9812):
[0001564590-19-043736:note_history:22]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Deferred product revenue |  | $ | 85 |  |  | $ | 84 |  |
| Deferred services revenue |  |  | 3,314 |  |  |  | 3,502 |  |
| Financed unearned services revenue |  |  | 69 |  |  |  | 82 |  |
| Total |  | $ | 3,468 |  |  | $ | 3,668 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,718 |  |  | $ | 1,825 |  |
| Long-term |  |  | 1,750 |  |  |  | 1,843 |  |
| Total |  | $ | 3,468 |  |  | $ | 3,668 |  |

- added (2020-02-18):
[0001564590-20-005025:note_history:23]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Balance at beginning of period |  | $ | 3,668 |  |  | $ | 3,363 |  |
| Additions |  |  | 1,759 |  |  |  | 1,820 |  |
| Revenue recognized during the period |  |  | (1,854 | ) |  |  | (1,826 | ) |
| Balance at end of period |  | $ | 3,573 |  |  | $ | 3,357 |  |

- changed (2020-02-18):
[0001564590-20-005025:note_history:24]
During the nine months ended January 24, 2020 and January 25, 2019, we recognized $1,504 million and $1,410 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.
  (was, 2019-11-18, similarity 0.8912):
[0001564590-19-043736:note_history:24]
During the six months ended October 25, 2019 and October 26, 2018, we recognized $1,045 million and $1,019 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

- changed (2020-02-18):
[0001564590-20-005025:note_history:25]
As of January 24, 2020, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,573 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 25% in the next 13 to 24 months, and the remainder thereafter.
  (was, 2019-11-18, similarity 0.9905):
[0001564590-19-043736:note_history:25]
As of October 25, 2019, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,468 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 49% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 26% in the next 13 to 24 months, and the remainder thereafter.

- added (2020-02-18):
[0001564590-20-005025:note_history:26]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Balance at beginning of period |  | $ | 172 |  |  | $ | 137 |  |
| Additions |  |  | 52 |  |  |  | 62 |  |
| Expense recognized during the period |  |  | (72 | ) |  |  | (60 | ) |
| Balance at end of period |  | $ | 152 |  |  | $ | 139 |  |

- changed (2020-02-18):
[0001564590-20-005025:note_history:27]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Other current assets |  | $ | 64 |  |  | $ | 75 |  |
| Other non-current assets |  |  | 88 |  |  |  | 97 |  |
| Total deferred commissions |  | $ | 152 |  |  | $ | 172 |  |
  (was, 2019-11-18, similarity 0.9684):
[0001564590-19-043736:note_history:27]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Other current assets |  | $ | 66 |  |  | $ | 75 |  |
| Other non-current assets |  |  | 88 |  |  |  | 97 |  |
| Total deferred commissions |  | $ | 154 |  |  | $ | 172 |  |

- removed (2020-02-18):
[0001564590-19-043736:note_history:28]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Product revenues |  | $ | 771 |  |  | $ | 913 |  |  | $ | 1,415 |  |  | $ | 1,788 |  |
| Strategic |  | 442 |  |  | 485 |  |  |  | 779 |  |  |  | 960 |  |
| Mature |  | 329 |  |  | 428 |  |  |  | 636 |  |  |  | 828 |  |
| Software maintenance revenues |  | 254 |  |  | 236 |  |  |  | 504 |  |  | 465 |  |
| Hardware maintenance and other services revenues |  | 346 |  |  | 368 |  |  |  | 688 |  |  |  | 738 |  |
| Hardware maintenance support contracts |  | 286 |  |  | 303 |  |  |  | 570 |  |  |  | 606 |  |
| Professional and other services |  | 60 |  |  | 65 |  |  |  | 118 |  |  |  | 132 |  |
| Net revenues |  | $ | 1,371 |  |  | $ | 1,517 |  |  | $ | 2,607 |  |  | $ | 2,991 |  |

- removed (2020-02-18):
[0001564590-19-043736:note_history:29]
|  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Balance at beginning of period |  | $ | 3,668 |  |  | $ | 3,363 |  |
| Additions |  |  | 1,011 |  |  |  | 1,067 |  |
| Revenue recognized during the period |  |  | (1,211 | ) |  |  | (1,224 | ) |
| Balance at end of period |  | $ | 3,468 |  |  | $ | 3,206 |  |

- removed (2020-02-18):
[0001564590-19-043736:note_history:30]
|  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Balance at beginning of period |  | $ | 172 |  |  | $ | 137 |  |
| Additions |  |  | 32 |  |  |  | 35 |  |
| Expense recognized during the period |  |  | (50 | ) |  |  | (41 | ) |
| Balance at end of period |  | $ | 154 |  |  | $ | 131 |  |
