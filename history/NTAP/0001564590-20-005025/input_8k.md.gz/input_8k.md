# NTAP 8-K — 0001564590-20-004352 filed 2020-02-12

## item codes, every 8-K on or before 2020-02-18

- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2020-02-18

- none on or before 2020-02-18

## item 2.02 — earnings release, exhibit 99.1

[0001564590-20-004352:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-20-004352:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-20-004352:8k_2_02:3]
Exhibit 99.1

[0001564590-20-004352:8k_2_02:4]
NetApp Reports Third Quarter of Fiscal Year 2020 Results

[0001564590-20-004352:8k_2_02:5]
Solid Margins, Cash Flow and Operating Leverage

[0001564590-20-004352:8k_2_02:6]
| • | All-flash array annualized net revenue run rate of $2.3 billion increased 7% quarter-over-quarter |  |

[0001564590-20-004352:8k_2_02:7]
| • | NetApp™ cloud data services annualized recurring revenue of approximately $83 million, an increase of 146% year-over-year |  |

[0001564590-20-004352:8k_2_02:8]
| • | Consolidated GAAP gross margin of 67.0%, non-GAAP gross margin of 67.8%* |  |

[0001564590-20-004352:8k_2_02:9]
| • | $420 million in cash from operations; $388 million in free cash flow |  |

[0001564590-20-004352:8k_2_02:10]
| • | $608 million returned to shareholders in share repurchases and cash dividends |  |

[0001564590-20-004352:8k_2_02:11]
*Note: NetApp had no ELA revenue in Q3

[0001564590-20-004352:8k_2_02:12]
Sunnyvale, Calif.—February 12, 2020—NetApp (NASDAQ: NTAP) today reported financial results for the third quarter of fiscal year 2020, which ended on January 24, 2020.

[0001564590-20-004352:8k_2_02:13]
“Our third quarter results, highlighted by strong gross margins, cash flow and operating leverage, reflect our continued operational discipline. Customers are on a journey to the cloud and are looking to NetApp to help them address the complexities of data management in hybrid multicloud,” said George Kurian, chief executive officer. “We see significant opportunity ahead and are focused on replicating the areas where we have proven success. Our strong business model enables us to navigate the market dynamics, while making the strategic investments necessary to position the company for long-term growth.”

[0001564590-20-004352:8k_2_02:14]
Third Quarter of Fiscal Year 2020 Financial Results

[0001564590-20-004352:8k_2_02:15]
| • | Net Revenues: $1.40 billion, compared to $1.56 billion in the third quarter of fiscal 2019 |  |

[0001564590-20-004352:8k_2_02:16]
| • | Net Income: GAAP net income of $277 million, compared to GAAP net income of $249 million in the third quarter of fiscal 2019; non-GAAP net income1 of $265 million, compared to non-GAAP net income of $305 million in the third quarter of fiscal 2019 |  |

[0001564590-20-004352:8k_2_02:17]
| • | Earnings per Share: GAAP net income per share2 of $1.21 compared to GAAP net income per share of $0.98 in the third quarter of fiscal 2019; non-GAAP net income per share of $1.16, compared to non-GAAP net income per share of $1.20 in the third quarter of fiscal 2019 |  |

[0001564590-20-004352:8k_2_02:18]
| • | Cash, Cash Equivalents and Investments: $3.0 billion at the end of the third quarter of fiscal 2020 |  |

[0001564590-20-004352:8k_2_02:19]
| • | Cash Provided by Operations: $420 million, compared to $451 million in the third quarter of fiscal 2019 |  |

[0001564590-20-004352:8k_2_02:20]
| • | Share Repurchase and Dividend: Returned $608 million to shareholders through share repurchases and cash dividends |  |

[0001564590-20-004352:8k_2_02:21]
Organizational Update

[0001564590-20-004352:8k_2_02:22]
Ron Pasek, EVP, Chief Financial Officer, has informed NetApp of his intent to retire by the end of the fiscal year after a successful four-year tenure. Pasek will remain on to ensure a transition to his successor, which the Company expects to name prior to the end of the fiscal year. Pasek joined NetApp in April 2016, assuming leadership of the company's finance, customer leasing, workplace resources, internal audit, and IT functions. “Ron has been an integral part of the NetApp executive leadership team. He has helped increase product margins by 10 points, nearly doubled our earnings power and raised our dividend by over 100%,” said George Kurian, chief executive officer. “We are grateful for Ron’s achievements at NetApp and wish him well in his future endeavors.”

[0001564590-20-004352:8k_2_02:23]
Fourth Quarter of Fiscal Year 2020 Financial Outlook

[0001564590-20-004352:8k_2_02:24]
The Company provided the following financial guidance for the fourth quarter of fiscal year 2020:

[0001564590-20-004352:8k_2_02:25]
| •Net revenues are expected to be in the range of: | $1.455 billion to $1.605 billion |
|  | GAAP | Non-GAAP |
| •Earnings per share is expected to be in the range of: | $1.11 -$1.19 | $1.28 - $1.36 |

[0001564590-20-004352:8k_2_02:26]
Full Fiscal Year 2020 Financial Outlook
The Company updated the following financial guidance for the full fiscal year 2020:

[0001564590-20-004352:8k_2_02:27]
| •Net revenues are expected to decline approximately 10% year-over-year |
|  | GAAP | Non-GAAP |
| •Consolidated gross margins are expected to be in the range of: | 66% - 67% | 67% - 68% |
| •Operating margins are expected to be: | ~18% | ~21% |
| •GAAP earnings per share is expected to decline approximately 16% year-over-year, while Non-GAAP earnings per share is expected to decline approximately 7% year-over-year |

[0001564590-20-004352:8k_2_02:28]
Dividend

[0001564590-20-004352:8k_2_02:29]
Next cash dividend of $0.48 per share to be paid on April 22, 2020, to shareholders of record as of the close of business on April 3, 2020.

[0001564590-20-004352:8k_2_02:30]
Third Quarter of Fiscal Year 2020 Business Highlights

[0001564590-20-004352:8k_2_02:31]
Consistently Delivering Groundbreaking Innovations

[0001564590-20-004352:8k_2_02:32]
| ● | NetApp announced its reinvention of the customer experience with the NetApp Keystone™ program which offers a range of flexible solutions for customers, whether they choose to build or to buy their cloud infrastructure, on or off their premises. |

[0001564590-20-004352:8k_2_02:33]
| ● | To meet the increasing demand for object storage, NetApp announced new NetApp StorageGRID™ enhancements: StorageGRID 11.3 software, SGF6024 all-flash appliance, SG6060 expansion appliance, SG1000 service appliance, and StorageGRID tiering to Azure Blob storage. |

[0001564590-20-004352:8k_2_02:34]
| ● | NetApp Cloud Manager 3.7.5 (formerly OnCommand™ Cloud Manager) offers new features and tighter integration with the NetApp cloud portfolio which enables customers to get more out of their data. |

[0001564590-20-004352:8k_2_02:35]
| ● | NetApp enhanced NetApp Cloud Volumes ONTAP™ for AWS with new NetApp Cloud Backup Service, the new NetApp Cloud Compliance service, and the ability to leverage NVMe flash available on virtual compute instances. |

[0001564590-20-004352:8k_2_02:36]
| ● | NetApp has expanded its multiprotocol file services to encompass NFSv4.1, NFSv3, and SMB for both Azure NetApp Files and NetApp Cloud Volumes Service for AWS. With this expansion, NetApp now delivers the widest range of support for Microsoft Windows and Linux workloads. |

[0001564590-20-004352:8k_2_02:37]
| ● | NetApp introduced new storage systems: the NetApp AFF A400 end-to-end NVMe all-flash system, the NetApp FAS8700 high-end hybrid flash array, and the FAS8300 next-generation midrange hybrid flash array. |

[0001564590-20-004352:8k_2_02:38]
| ● | NetApp ONTAP 9.7 offers expanded integration of hybrid cloud, with seamless and efficient migration of tiered data between private and public clouds by using FabricPool, symmetric active-active host-to-LUN access, and extended scale-out NAS deployments. |

[0001564590-20-004352:8k_2_02:39]
| ● | Three new features for NetApp Cloud Insights were announced, including Kubernetes Topology Visualization, NetApp Cloud Secure Insider Threat Detection, and NetApp Active IQ™ Integration. |

[0001564590-20-004352:8k_2_02:40]
| ● | NetApp Active IQ Unified Manager 9.7 (formerly OnCommand Unified Manager) delivers enhanced simplicity, automation, active management, and virtualization layer monitoring and reporting, along with strengthened dark site support. |

[0001564590-20-004352:8k_2_02:41]
| ● | With the release of NetApp ONTAP Select 9.7, NetApp has introduced support for software RAID configurations backed by NVMe drives. |

[0001564590-20-004352:8k_2_02:42]
| ● | NetApp announced that NFS-based NetApp Cloud Volumes has been added to its cloud services offerings on premises in preview mode. |

[0001564590-20-004352:8k_2_02:43]
Growing Partnerships and Distinguished Awards

[0001564590-20-004352:8k_2_02:44]
| ● | NetApp and Google Cloud announced an expanded partnership, including the general availability of NetApp Cloud Volumes ONTAP and Cloud Volumes Service for Google Cloud. The expansion also includes the availability of Cloud Volumes Service in the U.K. region and support for Anthos on Cloud Volumes ONTAP, Cloud Volumes Service, and NetApp HCI. |

[0001564590-20-004352:8k_2_02:45]
| ● | Enterprise Networking Solutions, Inc. (ENS-Inc.) was granted a 3-year contract by the State of California Department of General Services to deliver NetApp data center modernization and hybrid cloud infrastructure solutions to the State of California. |

[0001564590-20-004352:8k_2_02:46]
| ● | NetApp and NVIDIA unveiled the NVIDIA DGX SuperPOD, which helps simplify supercomputing and enables AI for high-performance computing (HPC) teams. NetApp and NVIDIA also announced their collaboration on the NVIDIA Magnum IO, a multi-GPU, multinode networking and storage I/O optimization stack. |

[0001564590-20-004352:8k_2_02:47]
| ● | NetApp was named a leader of Scale-Out NAS (File-Based Storage) in the IDC MarketScape: Worldwide Scale-Out File-Based Storage 2019 Vendor Assessment.3 |

[0001564590-20-004352:8k_2_02:48]
| ● | NetApp was again named a leader in object storage in the IDC MarketScape: Worldwide Object-Based Storage 2019 Vendor Assessment.4 |

[0001564590-20-004352:8k_2_02:49]
NetApp Executive Team Grows with the Company

[0001564590-20-004352:8k_2_02:50]
| ● | NetApp appointed James Whitemore as the Company’s senior vice president and chief marketing officer, reporting to CEO George Kurian. |

[0001564590-20-004352:8k_2_02:51]
| ● | NetApp appointed Kim Stevenson as senior vice president and general manager of the NetApp Foundational Data Services business unit, reporting to Brad Anderson. |

[0001564590-20-004352:8k_2_02:52]
Webcast and Conference Call Information

[0001564590-20-004352:8k_2_02:53]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today.

[0001564590-20-004352:8k_2_02:54]
About NetApp

[0001564590-20-004352:8k_2_02:55]
NetApp is the leader in cloud data services, empowering global organizations to change their world with data. Together with our partners, we are the only ones who can help you build your unique data fabric. Simplify hybrid multicloud and securely deliver the right data, services and applications to the right people at the right time. Learn more at www.netapp.com.

[0001564590-20-004352:8k_2_02:56]
###

[0001564590-20-004352:8k_2_02:57]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-20-004352:8k_2_02:58]
Footnotes

[0001564590-20-004352:8k_2_02:59]
1Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, and (h) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-20-004352:8k_2_02:60]
2GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0001564590-20-004352:8k_2_02:61]
3NetApp was named a leader of Scale-Out NAS (File-Based Storage) in the IDC MarketScape: Worldwide Scale-Out File-Based Storage 2019 Vendor Assessment, https://www.netapp.com/us/media/ar-idc-marketscape-worldwide-scale-out-vendor-assessment.pdf.

[0001564590-20-004352:8k_2_02:62]
4NetApp was named a leader in object storage in the IDC MarketScape: Worldwide Object-Based Storage 2019 Vendor Assessment, https://www.netapp.com/us/media/idc-marketscape-worldwide-object-based-storage-2019-vendor-assessment.pdf.

[0001564590-20-004352:8k_2_02:63]
NetApp Usage of Non-GAAP Financial Information

[0001564590-20-004352:8k_2_02:64]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-20-004352:8k_2_02:65]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with

[0001564590-20-004352:8k_2_02:66]
GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-20-004352:8k_2_02:67]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-20-004352:8k_2_02:68]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-20-004352:8k_2_02:69]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-20-004352:8k_2_02:70]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-20-004352:8k_2_02:71]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-20-004352:8k_2_02:72]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-20-004352:8k_2_02:73]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-20-004352:8k_2_02:74]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-20-004352:8k_2_02:75]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-20-004352:8k_2_02:76]
H. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-20-004352:8k_2_02:77]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-20-004352:8k_2_02:78]
NETAPP, INC.

[0001564590-20-004352:8k_2_02:79]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-20-004352:8k_2_02:80]
(In millions)

[0001564590-20-004352:8k_2_02:81]
(Unaudited)

[0001564590-20-004352:8k_2_02:82]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,008 |  |  | $ | 3,899 |  |
| Accounts receivable |  |  | 821 |  |  |  | 1,216 |  |
| Inventories |  |  | 113 |  |  |  | 131 |  |
| Other current assets |  |  | 276 |  |  |  | 364 |  |
| Total current assets |  |  | 4,218 |  |  |  | 5,610 |  |
| Property and equipment, net |  |  | 740 |  |  |  | 759 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,813 |  |  |  | 1,782 |  |
| Other non-current assets |  |  | 712 |  |  |  | 590 |  |
| Total assets |  | $ | 7,483 |  |  | $ | 8,741 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 381 |  |  | $ | 542 |  |
| Accrued expenses |  |  | 660 |  |  |  | 851 |  |
| Commercial paper notes |  |  | 693 |  |  |  | 249 |  |
| Current portion of long-term debt |  |  | — |  |  |  | 400 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,795 |  |  |  | 1,825 |  |
| Total current liabilities |  |  | 3,529 |  |  |  | 3,867 |  |
| Long-term debt |  |  | 1,146 |  |  |  | 1,144 |  |
| Other long-term liabilities |  |  | 748 |  |  |  | 797 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,778 |  |  |  | 1,843 |  |
| Total liabilities |  |  | 7,201 |  |  |  | 7,651 |  |
| Stockholders' equity |  |  | 282 |  |  |  | 1,090 |  |
| Total liabilities and stockholders' equity |  | $ | 7,483 |  |  | $ | 8,741 |  |

[0001564590-20-004352:8k_2_02:83]
NETAPP, INC.

[0001564590-20-004352:8k_2_02:84]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-20-004352:8k_2_02:85]
(In millions, except per share amounts)

[0001564590-20-004352:8k_2_02:86]
(Unaudited)

[0001564590-20-004352:8k_2_02:87]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 787 |  |  | $ | 967 |  |  | $ | 2,202 |  |  | $ | 2,755 |  |
| Software maintenance |  |  | 263 |  |  |  | 239 |  |  |  | 767 |  |  |  | 704 |  |
| Hardware maintenance and other services |  |  | 354 |  |  |  | 357 |  |  |  | 1,042 |  |  |  | 1,095 |  |
| Net revenues |  |  | 1,404 |  |  |  | 1,563 |  |  |  | 4,011 |  |  |  | 4,554 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 360 |  |  |  | 469 |  |  |  | 1,013 |  |  |  | 1,295 |  |
| Cost of software maintenance |  |  | 12 |  |  |  | 10 |  |  |  | 33 |  |  |  | 25 |  |
| Cost of hardware maintenance and other services |  |  | 91 |  |  |  | 102 |  |  |  | 283 |  |  |  | 315 |  |
| Total cost of revenues |  |  | 463 |  |  |  | 581 |  |  |  | 1,329 |  |  |  | 1,635 |  |
| Gross profit |  |  | 941 |  |  |  | 982 |  |  |  | 2,682 |  |  |  | 2,919 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 402 |  |  |  | 401 |  |  |  | 1,196 |  |  |  | 1,218 |  |
| Research and development |  |  | 211 |  |  |  | 203 |  |  |  | 635 |  |  |  | 622 |  |
| General and administrative |  |  | 60 |  |  |  | 67 |  |  |  | 200 |  |  |  | 209 |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 21 |  |  |  | 19 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | (38 | ) |  |  | — |  |
| Total operating expenses |  |  | 673 |  |  |  | 671 |  |  |  | 2,014 |  |  |  | 2,068 |  |
| Income from operations |  |  | 268 |  |  |  | 311 |  |  |  | 668 |  |  |  | 851 |  |
| Other income, net |  |  | 8 |  |  |  | 8 |  |  |  | 26 |  |  |  | 33 |  |
| Income before income taxes |  |  | 276 |  |  |  | 319 |  |  |  | 694 |  |  |  | 884 |  |
| Provision (benefit) for income taxes |  |  | (1 | ) |  |  | 70 |  |  |  | 71 |  |  |  | 111 |  |
| Net income |  | $ | 277 |  |  | $ | 249 |  |  | $ | 623 |  |  | $ | 773 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.23 |  |  | $ | 1.00 |  |  | $ | 2.67 |  |  | $ | 3.01 |  |
| Diluted |  | $ | 1.21 |  |  | $ | 0.98 |  |  | $ | 2.64 |  |  | $ | 2.94 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 226 |  |  |  | 250 |  |  |  | 233 |  |  |  | 257 |  |
| Diluted |  |  | 229 |  |  |  | 255 |  |  |  | 236 |  |  |  | 263 |  |

[0001564590-20-004352:8k_2_02:88]
NETAPP, INC.

[0001564590-20-004352:8k_2_02:89]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-20-004352:8k_2_02:90]
(In millions)

[0001564590-20-004352:8k_2_02:91]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 277 |  |  | $ | 249 |  |  | $ | 623 |  |  | $ | 773 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 47 |  |  |  | 51 |  |  |  | 146 |  |  |  | 149 |  |
| Non-cash operating lease cost |  |  | 13 |  |  |  | — |  |  |  | 39 |  |  |  | — |  |
| Stock-based compensation |  |  | 36 |  |  |  | 43 |  |  |  | 118 |  |  |  | 121 |  |
| Deferred income taxes |  |  | — |  |  |  | 4 |  |  |  | (23 | ) |  |  | (21 | ) |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | (38 | ) |  |  | — |  |
| Other items, net |  |  | (3 | ) |  |  | (3 | ) |  |  | (16 | ) |  |  | 8 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (41 | ) |  |  | (104 | ) |  |  | 394 |  |  |  | 165 |  |
| Inventories |  |  | (2 | ) |  |  | (14 | ) |  |  | 18 |  |  |  | 22 |  |
| Accounts payable |  |  | (1 | ) |  |  | 26 |  |  |  | (158 | ) |  |  | (101 | ) |
| Accrued expenses |  |  | 42 |  |  |  | 77 |  |  |  | (273 | ) |  |  | (85 | ) |
| Deferred revenue and financed unearned services revenue |  |  | 104 |  |  |  | 146 |  |  |  | (93 | ) |  |  | 17 |  |
| Long-term taxes payable |  |  | (84 | ) |  |  | 3 |  |  |  | (133 | ) |  |  | (60 | ) |
| Changes in other operating assets and liabilities, net |  |  | 32 |  |  |  | (27 | ) |  |  | 73 |  |  |  | (46 | ) |
| Net cash provided by operating activities |  |  | 420 |  |  |  | 451 |  |  |  | 677 |  |  |  | 942 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 142 |  |  |  | 172 |  |  |  | 1,288 |  |  |  | 661 |  |
| Purchases of property and equipment |  |  | (32 | ) |  |  | (31 | ) |  |  | (100 | ) |  |  | (138 | ) |
| Proceeds from sale of properties |  |  | — |  |  |  | — |  |  |  | 96 |  |  |  | — |  |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | — |  |  |  | (56 | ) |  |  | (3 | ) |
| Other investing activities, net |  |  | 1 |  |  |  | (1 | ) |  |  | (1 | ) |  |  | 1 |  |
| Net cash provided by investing activities |  |  | 111 |  |  |  | 140 |  |  |  | 1,227 |  |  |  | 521 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 47 |  |  |  | 53 |  |  |  | 102 |  |  |  | 118 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (3 | ) |  |  | (3 | ) |  |  | (77 | ) |  |  | (92 | ) |
| Repurchase of common stock |  |  | (500 | ) |  |  | (550 | ) |  |  | (1,250 | ) |  |  | (1,611 | ) |
| Proceeds from (repayments of) commercial paper notes, net |  |  | 194 |  |  |  | (86 | ) |  |  | 443 |  |  |  | (221 | ) |
| Repayment of long-term debt |  |  | — |  |  |  | — |  |  |  | (400 | ) |  |  | — |  |
| Dividends paid |  |  | (108 | ) |  |  | (99 | ) |  |  | (334 | ) |  |  | (306 | ) |
| Other financing activities, net |  |  | (2 | ) |  |  | (3 | ) |  |  | (4 | ) |  |  | (5 | ) |
| Net cash used in financing activities |  |  | (372 | ) |  |  | (688 | ) |  |  | (1,520 | ) |  |  | (2,117 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 1 |  |  |  | 8 |  |  |  | (4 | ) |  |  | (17 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | 160 |  |  |  | (89 | ) |  |  | 380 |  |  |  | (671 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,551 |  |  |  | 2,365 |  |  |  | 2,331 |  |  |  | 2,947 |  |
| End of period |  | $ | 2,711 |  |  | $ | 2,276 |  |  | $ | 2,711 |  |  | $ | 2,276 |  |

[0001564590-20-004352:8k_2_02:92]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q3 FY'20 |  |  | Q2 FY'20 |  |  | Q3 FY'19 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 787 |  |  | $ | 771 |  |  | $ | 967 |  |
| Strategic* |  | $ | 483 |  |  | $ | 442 |  |  | $ | 517 |  |
| Mature* |  | $ | 304 |  |  | $ | 329 |  |  | $ | 450 |  |
| Software Maintenance |  | $ | 263 |  |  | $ | 254 |  |  | $ | 239 |  |
| Hardware Maintenance and Other Services |  | $ | 354 |  |  | $ | 346 |  |  | $ | 357 |  |
| Hardware Maintenance Support Contracts |  | $ | 293 |  |  | $ | 286 |  |  | $ | 292 |  |
| Professional and Other Services |  | $ | 61 |  |  | $ | 60 |  |  | $ | 65 |  |
| Net Revenues |  | $ | 1,404 |  |  | $ | 1,371 |  |  | $ | 1,563 |  |
| * In Q1 FY’20 we made changes to the products and solutions contained in each of the Strategic and Mature product groupings. Strategic now includes All-flash FAS products, including all related add-on hardware and OS software, private cloud solutions, enterprise software license agreements and other optional add-on software products. Mature now includes Hybrid FAS products, including all related add-on hardware and OS software, OEM products, and branded E-Series. Prior to this change, Hybrid FAS and branded E-Series were included in Strategic, while all add-on hardware and OS software were included in Mature. For comparability, Strategic and Mature revenues presented for the prior year period have been recast based on the revised groupings. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'20 Revenue |  |  | % of Q2 FY'20 Revenue |  |  | % of Q3 FY'19 Revenue |  |
| Americas |  |  | 50 | % |  |  | 56 | % |  |  | 52 | % |
| Americas Commercial |  |  | 39 | % |  |  | 42 | % |  |  | 41 | % |
| U.S. Public Sector |  |  | 11 | % |  |  | 14 | % |  |  | 11 | % |
| EMEA |  |  | 35 | % |  |  | 29 | % |  |  | 33 | % |
| Asia Pacific |  |  | 15 | % |  |  | 14 | % |  |  | 14 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'20 Revenue |  |  | % of Q2 FY'20 Revenue |  |  | % of Q3 FY'19 Revenue |  |
| Direct |  |  | 21 | % |  |  | 21 | % |  |  | 19 | % |
| Indirect |  |  | 79 | % |  |  | 79 | % |  |  | 81 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'20 |  |  | Q2 FY'20 |  |  | Q3 FY'19 |  |
| Non-GAAP Gross Margin |  |  | 67.8 | % |  |  | 68.6 | % |  |  | 63.7 | % |
| Product |  |  | 55.4 | % |  |  | 57.3 | % |  |  | 52.6 | % |
| Software Maintenance |  |  | 95.4 | % |  |  | 95.7 | % |  |  | 95.8 | % |
| Hardware Maintenance and Other Services |  |  | 74.9 | % |  |  | 73.7 | % |  |  | 72.3 | % |

[0001564590-20-004352:8k_2_02:93]
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'20 |  |  | Q2 FY'20 |  |  | Q3 FY'19 |  |
| Non-GAAP Income from Operations |  | $ | 312 |  |  | $ | 309 |  |  | $ | 367 |  |
| % of Net Revenues |  |  | 22.2 | % |  |  | 22.5 | % |  |  | 23.5 | % |
| Non-GAAP Income before Income Taxes |  | $ | 320 |  |  | $ | 312 |  |  | $ | 375 |  |
| Non-GAAP Effective Tax Rate |  |  | 17.2 | % |  |  | 17.6 | % |  |  | 18.7 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'20 |  |  | Q2 FY'20 |  |  | Q3 FY'19 |  |
| Non-GAAP Net Income |  | $ | 265 |  |  | $ | 257 |  |  | $ | 305 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 229 |  |  |  | 236 |  |  |  | 255 |  |
| Non-GAAP Income per Share, Diluted |  | $ | 1.16 |  |  | $ | 1.09 |  |  | $ | 1.20 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'20 |  |  | Q2 FY'20 |  |  | Q3 FY'19 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,573 |  |  | $ | 3,468 |  |  | $ | 3,357 |  |
| DSO (days) |  |  | 53 |  |  |  | 52 |  |  |  | 51 |  |
| DIO (days) |  |  | 22 |  |  |  | 23 |  |  |  | 16 |  |
| DPO (days) |  |  | 75 |  |  |  | 78 |  |  |  | 78 |  |
| CCC (days) |  |  | 1 |  |  |  | (4 | ) |  |  | (11 | ) |
| Inventory Turns |  |  | 16 |  |  |  | 16 |  |  |  | 23 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'20 |  |  | Q2 FY'20 |  |  | Q3 FY'19 |  |
| Net Cash Provided by (used in) Operating Activities |  | $ | 420 |  |  | $ | (53 | ) |  | $ | 451 |  |
| Purchases of Property and Equipment |  | $ | 32 |  |  | $ | 36 |  |  | $ | 31 |  |
| Free Cash Flow |  | $ | 388 |  |  | $ | (89 | ) |  | $ | 420 |  |
| Free Cash Flow as a % of Net Revenues |  |  | 27.6 | % |  |  | (6.5 | )% |  |  | 26.9 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001564590-20-004352:8k_2_02:94]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY20 |  |  | Q2'FY20 |  |  | Q3'FY19 |  |
| NET INCOME |  | $ | 277 |  |  | $ | 243 |  |  | $ | 249 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 8 |  |  |  | 11 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 36 |  |  |  | 40 |  |  |  | 43 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (38 | ) |  |  | — |  |
| Income tax effects |  |  | (6 | ) |  |  | 1 |  |  |  | — |  |
| Resolution of income tax matters |  |  | (50 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP NET INCOME |  | $ | 265 |  |  | $ | 257 |  |  | $ | 305 |  |
| COST OF REVENUES |  | $ | 463 |  |  | $ | 446 |  |  | $ | 581 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (11 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (4 | ) |  |  | (4 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 452 |  |  | $ | 431 |  |  | $ | 567 |  |
| COST OF PRODUCT REVENUES |  | $ | 360 |  |  | $ | 341 |  |  | $ | 469 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (11 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 351 |  |  | $ | 329 |  |  | $ | 458 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 91 |  |  | $ | 94 |  |  | $ | 102 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (3 | ) |  |  | (3 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 89 |  |  | $ | 91 |  |  | $ | 99 |  |
| GROSS PROFIT |  | $ | 941 |  |  | $ | 925 |  |  | $ | 982 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 8 |  |  |  | 11 |  |  |  | 10 |  |
| Stock-based compensation |  |  | 3 |  |  |  | 4 |  |  |  | 4 |  |
| NON-GAAP GROSS PROFIT |  | $ | 952 |  |  | $ | 940 |  |  | $ | 996 |  |

[0001564590-20-004352:8k_2_02:95]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY20 |  |  | Q2'FY20 |  |  | Q3'FY19 |  |
| SALES AND MARKETING EXPENSES |  | $ | 402 |  |  | $ | 389 |  |  | $ | 401 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | — |  |  |  | (3 | ) |
| Stock-based compensation |  |  | (15 | ) |  |  | (17 | ) |  |  | (19 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 387 |  |  | $ | 372 |  |  | $ | 379 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 211 |  |  | $ | 209 |  |  | $ | 203 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (13 | ) |  |  | (13 | ) |  |  | (13 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 198 |  |  | $ | 196 |  |  | $ | 190 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 60 |  |  | $ | 69 |  |  | $ | 67 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (5 | ) |  |  | (6 | ) |  |  | (7 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 55 |  |  | $ | 63 |  |  | $ | 60 |  |
| GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  |  | $ | (38 | ) |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | 38 |  |  |  | — |  |
| NON-GAAP GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 673 |  |  | $ | 629 |  |  | $ | 671 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | — |  |  |  | (3 | ) |
| Stock-based compensation |  |  | (33 | ) |  |  | (36 | ) |  |  | (39 | ) |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | 38 |  |  |  | — |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 640 |  |  | $ | 631 |  |  | $ | 629 |  |

[0001564590-20-004352:8k_2_02:96]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY20 |  |  | Q2'FY20 |  |  | Q3'FY19 |  |
| INCOME FROM OPERATIONS |  | $ | 268 |  |  | $ | 296 |  |  | $ | 311 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 8 |  |  |  | 11 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 36 |  |  |  | 40 |  |  |  | 43 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (38 | ) |  |  | — |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 312 |  |  | $ | 309 |  |  | $ | 367 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 276 |  |  | $ | 299 |  |  | $ | 319 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 8 |  |  |  | 11 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 36 |  |  |  | 40 |  |  |  | 43 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (38 | ) |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 320 |  |  | $ | 312 |  |  | $ | 375 |  |
| PROVISION (BENEFIT) FOR INCOME TAXES |  | $ | (1 | ) |  | $ | 56 |  |  | $ | 70 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 6 |  |  |  | (1 | ) |  |  | — |  |
| Resolution of income tax matters |  |  | 50 |  |  |  | — |  |  |  | — |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 55 |  |  | $ | 55 |  |  | $ | 70 |  |
| NET INCOME PER SHARE |  | $ | 1.21 |  |  | $ | 1.03 |  |  | $ | 0.98 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.03 |  |  |  | 0.05 |  |  |  | 0.05 |  |
| Stock-based compensation |  |  | 0.16 |  |  |  | 0.17 |  |  |  | 0.17 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (0.16 | ) |  |  | — |  |
| Income tax effects |  |  | (0.03 | ) |  |  | — |  |  |  | — |  |
| Resolution of income tax matters |  |  | (0.22 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.16 |  |  | $ | 1.09 |  |  | $ | 1.20 |  |

[0001564590-20-004352:8k_2_02:97]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY20 |  |  | Q2'FY20 |  |  | Q3'FY19 |  |
| Gross margin-GAAP |  |  | 67.0 | % |  |  | 67.5 | % |  |  | 62.8 | % |
| Cost of revenues adjustments |  |  | 0.8 | % |  |  | 1.1 | % |  |  | 0.9 | % |
| Gross margin-Non-GAAP |  |  | 67.8 | % |  |  | 68.6 | % |  |  | 63.7 | % |
| GAAP cost of revenues |  | $ | 463 |  |  | $ | 446 |  |  | $ | 581 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (11 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (4 | ) |  |  | (4 | ) |
| Non-GAAP cost of revenues |  | $ | 452 |  |  | $ | 431 |  |  | $ | 567 |  |
| Net revenues |  | $ | 1,404 |  |  | $ | 1,371 |  |  | $ | 1,563 |  |

[0001564590-20-004352:8k_2_02:98]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY20 |  |  | Q2'FY20 |  |  | Q3'FY19 |  |
| Product gross margin-GAAP |  |  | 54.3 | % |  |  | 55.8 | % |  |  | 51.5 | % |
| Cost of product revenues adjustments |  |  | 1.1 | % |  |  | 1.6 | % |  |  | 1.1 | % |
| Product gross margin-Non-GAAP |  |  | 55.4 | % |  |  | 57.3 | % |  |  | 52.6 | % |
| GAAP cost of product revenues |  | $ | 360 |  |  | $ | 341 |  |  | $ | 469 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (11 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 351 |  |  | $ | 329 |  |  | $ | 458 |  |
| Product revenues |  | $ | 787 |  |  | $ | 771 |  |  | $ | 967 |  |

[0001564590-20-004352:8k_2_02:99]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY20 |  |  | Q2'FY20 |  |  | Q3'FY19 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 74.3 | % |  |  | 72.8 | % |  |  | 71.4 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.6 | % |  |  | 0.9 | % |  |  | 0.8 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 74.9 | % |  |  | 73.7 | % |  |  | 72.3 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 91 |  |  | $ | 94 |  |  | $ | 102 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (3 | ) |  |  | (3 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 89 |  |  | $ | 91 |  |  | $ | 99 |  |
| Hardware maintenance and other services revenues |  | $ | 354 |  |  | $ | 346 |  |  | $ | 357 |  |

[0001564590-20-004352:8k_2_02:100]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q3'FY20 |  |  | Q2'FY20 |  |  | Q3'FY19 |  |
| GAAP effective tax rate |  |  | (0.4 | )% |  |  | 18.7 | % |  |  | 21.9 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 2.0 | % |  |  | (1.1 | )% |  |  | (2.7 | )% |
| Resolution of income tax matters |  |  | 15.6 | % |  |  | — | % |  |  | — | % |
| Non-GAAP effective tax rate |  |  | 17.2 | % |  |  | 17.6 | % |  |  | 19.3 | % |

[0001564590-20-004352:8k_2_02:101]
| RECONCILIATION OF NET CASH PROVIDED BY (USED IN) OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q3'FY20 |  |  | Q2'FY20 |  |  | Q3'FY19 |  |
| Net cash provided by (used in) operating activities |  | $ | 420 |  |  | $ | (53 | ) |  | $ | 451 |  |
| Purchases of property and equipment |  |  | (32 | ) |  |  | (36 | ) |  |  | (31 | ) |
| Free cash flow |  | $ | 388 |  |  | $ | (89 | ) |  | $ | 420 |  |

[0001564590-20-004352:8k_2_02:102]
Some items may not add or recalculate due to rounding.

[0001564590-20-004352:8k_2_02:103]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| FOURTH QUARTER FISCAL 2020 |  |
|  |  | Fourth Quarter |  |
|  |  | Fiscal 2020 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $1.28 - $1.36 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Fourth Quarter Fiscal 2020: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.04 | ) |
| Stock-based compensation expense |  |  | (0.17 | ) |
| Income tax effects |  |  | 0.04 |  |
| Total Adjustments |  |  | (0.17 | ) |
| GAAP Guidance - Net Income Per Share |  | $1.11 - $1.19 |  |

[0001564590-20-004352:8k_2_02:104]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| FISCAL 2020 |  |
| (Unaudited) |  |
|  |  | Fiscal 2020 |  |
| Gross Margin - Non-GAAP Guidance |  | 67% - 68% |  |
| Adjustment: |  |  |  |  |
| Cost of revenues adjustments |  | (1)% |  |
| Gross Margin - GAAP Guidance |  | 66% - 67% |  |
|  |  | Fiscal 2020 |  |
| Operating Margin - Non-GAAP Guidance |  | ~21% |  |
| Adjustments: |  |  |  |  |
| Amortization of intangible assets |  | (1)% |  |
| Stock-based compensation expense |  | (3)% |  |
| Gain on sale or derecognition of assets |  | 1% |  |
| Operating Margin - GAAP Guidance |  | ~18% |  |
|  |  | Fiscal 2020 versus Fiscal 2019 |  |
| Year-over-year Decrease in Net Income Per Share - Non-GAAP Guidance |  | (7)% |  |
| Adjustments: |  |  |  |  |
| Amortization of intangible assets |  | 1% |  |
| Restructuring charges |  | 1% |  |
| Gain on sale or derecognition of assets |  | (3)% |  |
| Income tax benefit of ASC 606 adoption |  | (3)% |  |
| Income tax effects |  | (5)% |  |
| Year-over-year Decrease in Net Income Per Share - GAAP Guidance |  | (16)% |  |
| Some items may not add or recalculate due to rounding |  |  |  |  |

[0001564590-20-004352:8k_2_02:105]
Press Contact:

[0001564590-20-004352:8k_2_02:106]
Amelia Vierra

[0001564590-20-004352:8k_2_02:107]
NetApp

[0001564590-20-004352:8k_2_02:108]
1 408 822 6403

[0001564590-20-004352:8k_2_02:109]
amelia.vierra@netapp.com

[0001564590-20-004352:8k_2_02:110]
Investor Contact:

[0001564590-20-004352:8k_2_02:111]
Lance Berger

[0001564590-20-004352:8k_2_02:112]
NetApp

[0001564590-20-004352:8k_2_02:113]
1 408 822 6628

[0001564590-20-004352:8k_2_02:114]
lance.berger@netapp.com

## item 5.02 — body, verbatim

[0001564590-20-004352:8k_body:1]
Item 5.02     Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001564590-20-004352:8k_body:2]
(b), (e)

[0001564590-20-004352:8k_body:3]
Retirement of Named Executive Officer

[0001564590-20-004352:8k_body:4]
On February 12, 2020, NetApp announced that Ronald J. Pasek informed the Company of his intent to retire from his position as Executive Vice President and Chief Financial Officer of the Company by the end of the Company’s fiscal year 2020 (“Fiscal 2020”). Mr. Pasek has agreed to work with the Company and its Board of Directors (the “Board”) to ensure an orderly transition.

[0001564590-20-004352:8k_body:5]
On February 8, 2020, the Compensation Committee (the “Committee”) of the Board approved the terms of a separation and release agreement with Mr. Pasek (the “Pasek Agreement”). The Pasek Agreement, upon becoming effective, provides for (i) release of all claims by Mr. Pasek in favor of the Company; (ii) a payment to Mr. Pasek of $626,000; and (iii) accelerated vesting of Mr. Pasek’s service-vested restricted stock units (“RSUs”) such that Mr. Pasek shall be entitled to the pro rata portion of the RSUs that would have otherwise vested in June 2020 (based on days of service during the vesting period). If Mr. Pasek remains an employee of the Company through the end of Fiscal 2020, he shall be entitled to: (i) payment of the amount earned under his Fiscal 2020 incentive compensation award in accordance with the terms and conditions approved by the Committee under the Company’s Executive Compensation Plan; and (ii) vesting of that portion of his outstanding performance-based restricted stock units (“PBRSUs”) with a performance period ending on April 24, 2020, with payout based on the actual performance of the Company relative to the metrics set forth in the grant agreement.

[0001564590-20-004352:8k_body:6]
On February 8, 2020, the Committee also approved the terms of a separation and release agreement with Henri Richard, (the “Richard Agreement”). As previously announced, Mr. Richard intends to retire from his position of Executive Vice President, World Wide Field and Customer Operations at the end of the Fiscal 2020. The Richard Agreement, upon becoming effective, provides for (i) release of all claims by Mr. Richard in favor of the Company; (ii) a payment to Mr. Richard of $300,000 and (iii) accelerated vesting of Mr. Richard’s RSUs such that Mr. Richard shall be entitled to the pro rata portion of the RSUs that would have otherwise vested in June 2020 (based on days of service during the vesting period). If Mr. Richard remains an employee of the Company through the end of Fiscal 2020, he shall be entitled to: (i) payment of the amount earned under his Fiscal 2020 incentive compensation award in accordance with the terms and conditions approved by the Committee under the Company’s Executive Compensation Plan and (ii) vesting of that portion of his outstanding PBRSUs with a performance period ending on April 24, 2020, based on the actual performance of the Company relative to the metrics set forth in the grant agreement. If Mr. Richard remains an employee of the Company through May 13, 2020, he is eligible for pro rata vesting of his outstanding PBRSUs in accordance with the terms of the applicable grant agreements.

[0001564590-20-004352:8k_body:7]
The foregoing summaries of the Pasek Agreement and the Richard Agreement do not purport to be complete and are qualified in their entirety by the full text of the applicable agreement, a copy of which will be filed with the Company’s Annual Report on Form 10-K for the year ending April 24, 2020.
