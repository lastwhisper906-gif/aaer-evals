# NTAP notes — 0001564590-20-005025


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-20-005025:notes:1]
[same as prior period, unchanged from 0001564590-19-043736:notes:1]

[0001564590-20-005025:notes:2]
[same as prior period, unchanged from 0001564590-19-043736:notes:2]

[0001564590-20-005025:notes:3]
[same as prior period, unchanged from 0001564590-19-043736:notes:3]

[0001564590-20-005025:notes:4]
[same as prior period, unchanged from 0001564590-19-043736:notes:4]

[0001564590-20-005025:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 26, 2019 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 24, 2020 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-20-005025:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-20-005025:notes:7]
[same as prior period, unchanged from 0001564590-19-043736:notes:7]

[0001564590-20-005025:notes:8]
In February 2016, the FASB issued an accounting standards update on financial reporting for leasing arrangements, including requiring lessees to recognize an operating lease with a term greater than one year on their balance sheets as a right-of-use (ROU) asset and corresponding lease liability, measured at the present value of the lease payments. In the first quarter of fiscal 2020, we adopted this new standard using the modified retrospective approach, electing the optional transition approach of not adjusting our comparative period financial statements for the impacts of adoption. We also elected the package of practical expedients that did not require us to reassess existing leases under the new guidance, and the practical expedient to not separate lease and non-lease components for all leases. Adoption of the new standard on April 27, 2019 resulted in the recognition of approximately $149 million of operating lease ROU assets, net of deferred rent and lease restructuring liabilities, $158 million of lease liabilities, and a cumulative-effect adjustment to retained earnings of $6 million on our condensed consolidated balance sheets. Adoption of the standard did not have a material impact on our condensed consolidated statements of operations or condensed consolidated statements of cash flows. Additional information is presented below and in Note 9 – Leases.

[0001564590-20-005025:notes:9]
[same as prior period, unchanged from 0001564590-19-043736:notes:9]

[0001564590-20-005025:notes:10]
[same as prior period, unchanged from 0001564590-19-043736:notes:10]

[0001564590-20-005025:notes:11]
[same as prior period, unchanged from 0001564590-19-043736:notes:11]

[0001564590-20-005025:notes:12]
There have been no other significant changes in our significant accounting policies as of and for the nine months ended January 24, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 26, 2019.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-20-005025:notes:13]
[same as prior period, unchanged from 0001564590-19-043736:notes:13]

[0001564590-20-005025:notes:14]
[same as prior period, unchanged from 0001564590-19-043736:notes:14]

[0001564590-20-005025:notes:15]
[same as prior period, unchanged from 0001564590-19-043736:notes:15]

[0001564590-20-005025:notes:16]
[same as prior period, unchanged from 0001564590-19-043736:notes:16]

[0001564590-20-005025:notes:17]
[same as prior period, unchanged from 0001564590-19-043736:notes:17]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-20-005025:notes:18]
[same as prior period, unchanged from 0001564590-19-043736:notes:18]

[0001564590-20-005025:notes:19]
[same as prior period, unchanged from 0001564590-19-043736:notes:19]

[0001564590-20-005025:notes:20]
| Balance as of April 26, 2019 |  | $ | 1,735 |  |
| Additions |  |  | 35 |  |
| Balance as of January 24, 2020 |  | $ | 1,770 |  |

[0001564590-20-005025:notes:21]
[same as prior period, unchanged from 0001564590-19-043736:notes:21]

[0001564590-20-005025:notes:22]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 186 |  |  | $ | (143 | ) |  | $ | 43 |  |  | $ | 160 |  |  | $ | (113 | ) |  | $ | 47 |  |
| Customer contracts/relationships |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 41 |  |  |  | (41 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 186 |  |  | $ | (143 | ) |  | $ | 43 |  |  | $ | 201 |  |  | $ | (154 | ) |  | $ | 47 |  |

[0001564590-20-005025:notes:23]
[same as prior period, unchanged from 0001564590-19-043736:notes:23]

[0001564590-20-005025:notes:24]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Statements of |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | Operations Classification |
| Developed technology |  | $ | 8 |  |  | $ | 10 |  |  | $ | 30 |  |  | $ | 28 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 10 |  |  | Operating expenses |
| Total |  | $ | 8 |  |  | $ | 13 |  |  | $ | 30 |  |  | $ | 38 |  |  |  |

[0001564590-20-005025:notes:25]
As of January 24, 2020, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-20-005025:notes:26]
| Fiscal Year |  | Amount |  |
| Remainder of 2020 |  | $ | 8 |  |
| 2021 |  |  | 25 |  |
| 2022 |  |  | 9 |  |
| 2023 |  |  | 1 |  |
| Total |  | $ | 43 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-20-005025:notes:27]
[same as prior period, unchanged from 0001564590-19-043736:notes:27]

[0001564590-20-005025:notes:28]
[same as prior period, unchanged from 0001564590-19-043736:notes:28]

[0001564590-20-005025:notes:29]
[same as prior period, unchanged from 0001564590-19-043736:notes:29]

[0001564590-20-005025:notes:30]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Cash and cash equivalents |  | $ | 2,705 |  |  | $ | 2,325 |  |
| Restricted cash |  |  | 6 |  |  |  | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,711 |  |  | $ | 2,331 |  |

[0001564590-20-005025:notes:31]
[same as prior period, unchanged from 0001564590-19-043736:notes:31]

[0001564590-20-005025:notes:32]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Purchased components |  | $ | 18 |  |  | $ | 8 |  |
| Finished goods |  |  | 95 |  |  |  | 123 |  |
| Inventories |  | $ | 113 |  |  | $ | 131 |  |

[0001564590-20-005025:notes:33]
[same as prior period, unchanged from 0001564590-19-043736:notes:33]

[0001564590-20-005025:notes:34]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Land |  | $ | 104 |  |  | $ | 106 |  |
| Buildings and improvements |  |  | 610 |  |  |  | 605 |  |
| Leasehold improvements |  |  | 87 |  |  |  | 86 |  |
| Computer, production, engineering and other equipment |  |  | 844 |  |  |  | 817 |  |
| Computer software |  |  | 359 |  |  |  | 357 |  |
| Furniture and fixtures |  |  | 107 |  |  |  | 105 |  |
| Construction-in-progress |  |  | 26 |  |  |  | 10 |  |
|  |  |  | 2,137 |  |  |  | 2,086 |  |
| Accumulated depreciation and amortization |  |  | (1,397 | ) |  |  | (1,327 | ) |
| Property and equipment, net |  | $ | 740 |  |  | $ | 759 |  |

[0001564590-20-005025:notes:35]
[same as prior period, unchanged from 0001564590-19-043736:notes:35]

[0001564590-20-005025:notes:36]
[same as prior period, unchanged from 0001564590-19-043736:notes:36]

[0001564590-20-005025:notes:37]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Deferred tax assets |  | $ | 222 |  |  | $ | 201 |  |
| Operating lease ROU assets |  |  | 142 |  |  |  | — |  |
| Other assets |  |  | 348 |  |  |  | 389 |  |
| Other non-current assets |  | $ | 712 |  |  | $ | 590 |  |

[0001564590-20-005025:notes:38]
Other non-current assets as of each January 24, 2020 and April 26, 2019 includes $78 million for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited, a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019.

[0001564590-20-005025:notes:39]
[same as prior period, unchanged from 0001564590-19-043736:notes:39]

[0001564590-20-005025:notes:40]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Accrued compensation and benefits |  | $ | 285 |  |  | $ | 433 |  |
| Product warranty liabilities |  |  | 26 |  |  |  | 25 |  |
| Operating lease liabilities |  |  | 50 |  |  |  | — |  |
| Other current liabilities |  |  | 299 |  |  |  | 393 |  |
| Accrued expenses |  | $ | 660 |  |  | $ | 851 |  |

[0001564590-20-005025:notes:41]
[same as prior period, unchanged from 0001564590-19-043736:notes:41]

[0001564590-20-005025:notes:42]
[same as prior period, unchanged from 0001564590-19-043736:notes:42]

[0001564590-20-005025:notes:43]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Balance at beginning of period |  | $ | 40 |  |  | $ | 39 |  |  | $ | 40 |  |  | $ | 40 |  |
| Expense accrued during the period |  |  | 7 |  |  |  | 6 |  |  |  | 19 |  |  |  | 16 |  |
| Warranty costs incurred |  |  | (6 | ) |  |  | (6 | ) |  |  | (18 | ) |  |  | (17 | ) |
| Balance at end of period |  | $ | 41 |  |  | $ | 39 |  |  | $ | 41 |  |  | $ | 39 |  |

[0001564590-20-005025:notes:44]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Accrued expenses |  | $ | 26 |  |  | $ | 25 |  |
| Other long-term liabilities |  |  | 15 |  |  |  | 15 |  |
| Total warranty liabilities |  | $ | 41 |  |  | $ | 40 |  |

[0001564590-20-005025:notes:45]
[same as prior period, unchanged from 0001564590-19-043736:notes:45]

[0001564590-20-005025:notes:46]
[same as prior period, unchanged from 0001564590-19-043736:notes:46]

[0001564590-20-005025:notes:47]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Liability for uncertain tax positions |  | $ | 167 |  |  | $ | 252 |  |
| Income taxes payable |  |  | 399 |  |  |  | 447 |  |
| Product warranty liabilities |  |  | 15 |  |  |  | 15 |  |
| Operating lease liabilities |  |  | 99 |  |  |  | — |  |
| Other liabilities |  |  | 68 |  |  |  | 83 |  |
| Other long-term liabilities |  | $ | 748 |  |  | $ | 797 |  |

[0001564590-20-005025:notes:48]
[same as prior period, unchanged from 0001564590-19-043736:notes:48]

[0001564590-20-005025:notes:49]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Interest income |  | $ | 10 |  |  | $ | 22 |  |  | $ | 41 |  |  | $ | 68 |  |
| Interest expense |  |  | (14 | ) |  |  | (16 | ) |  |  | (41 | ) |  |  | (44 | ) |
| Other income, net |  |  | 12 |  |  |  | 2 |  |  |  | 26 |  |  |  | 9 |  |
| Total other income, net |  | $ | 8 |  |  | $ | 8 |  |  | $ | 26 |  |  | $ | 33 |  |

[0001564590-20-005025:notes:50]
[same as prior period, unchanged from 0001564590-19-043736:notes:50]

[0001564590-20-005025:notes:51]
[same as prior period, unchanged from 0001564590-19-043736:notes:51]

[0001564590-20-005025:notes:52]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 7 |  |  | $ | 6 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 266 |  |  | $ | 150 |  |
| Interest paid |  | $ | 40 |  |  | $ | 41 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-005025:notes:53]
[same as prior period, unchanged from 0001564590-19-043736:notes:53]

[0001564590-20-005025:notes:54]
[same as prior period, unchanged from 0001564590-19-043736:notes:54]

[0001564590-20-005025:notes:55]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. As our product portfolio evolves, market dynamics change, and management continues to assess our largest growth opportunities, we periodically change how we group certain products. Beginning in fiscal 2020, Strategic includes All-flash FAS (AFF) products, including all related add-on hardware and operating system (OS) software, private cloud solutions (including SolidFire, converged and hyper-converged infrastructure products, StorageGrid), enterprise software license agreements (ELAs) and other optional add-on software products. Mature now includes Hybrid FAS products, including all related add-on hardware and OS software, original equipment manufacturers (OEM) products, and branded E-Series. Prior to this grouping change, Hybrid FAS products and branded E-Series were included in Strategic, while all add-on hardware and OS software were included in Mature. For comparability, Strategic and Mature revenues presented for the prior year periods have been recast based on the revised groupings.

[0001564590-20-005025:notes:56]
[same as prior period, unchanged from 0001564590-19-043736:notes:56]

[0001564590-20-005025:notes:57]
[same as prior period, unchanged from 0001564590-19-043736:notes:57]

[0001564590-20-005025:notes:58]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Product revenues |  | $ | 787 |  |  | $ | 967 |  |  | $ | 2,202 |  |  | $ | 2,755 |  |
| Strategic |  | 483 |  |  | 517 |  |  |  | 1,262 |  |  |  | 1,477 |  |
| Mature |  | 304 |  |  | 450 |  |  |  | 940 |  |  |  | 1,278 |  |
| Software maintenance revenues |  | 263 |  |  | 239 |  |  | 767 |  |  | 704 |  |
| Hardware maintenance and other services revenues |  | 354 |  |  | 357 |  |  |  | 1,042 |  |  |  | 1,095 |  |
| Hardware maintenance support contracts |  | 293 |  |  | 292 |  |  | 863 |  |  |  | 898 |  |
| Professional and other services |  | 61 |  |  | 65 |  |  | 179 |  |  |  | 197 |  |
| Net revenues |  | $ | 1,404 |  |  | $ | 1,563 |  |  | $ | 4,011 |  |  | $ | 4,554 |  |

[0001564590-20-005025:notes:59]
[same as prior period, unchanged from 0001564590-19-043736:notes:59]

[0001564590-20-005025:notes:60]
[same as prior period, unchanged from 0001564590-19-043736:notes:60]

[0001564590-20-005025:notes:61]
[same as prior period, unchanged from 0001564590-19-043736:notes:61]

[0001564590-20-005025:notes:62]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Deferred product revenue |  | $ | 73 |  |  | $ | 84 |  |
| Deferred services revenue |  |  | 3,439 |  |  |  | 3,502 |  |
| Financed unearned services revenue |  |  | 61 |  |  |  | 82 |  |
| Total |  | $ | 3,573 |  |  | $ | 3,668 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,795 |  |  | $ | 1,825 |  |
| Long-term |  |  | 1,778 |  |  |  | 1,843 |  |
| Total |  | $ | 3,573 |  |  | $ | 3,668 |  |

[0001564590-20-005025:notes:63]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 16 – Commitments and Contingencies for additional information related to these arrangements.

[0001564590-20-005025:notes:64]
[same as prior period, unchanged from 0001564590-19-043736:notes:64]

[0001564590-20-005025:notes:65]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Balance at beginning of period |  | $ | 3,668 |  |  | $ | 3,363 |  |
| Additions |  |  | 1,759 |  |  |  | 1,820 |  |
| Revenue recognized during the period |  |  | (1,854 | ) |  |  | (1,826 | ) |
| Balance at end of period |  | $ | 3,573 |  |  | $ | 3,357 |  |

[0001564590-20-005025:notes:66]
During the nine months ended January 24, 2020 and January 25, 2019, we recognized $1,504 million and $1,410 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001564590-20-005025:notes:67]
As of January 24, 2020, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,573 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 25% in the next 13 to 24 months, and the remainder thereafter.

[0001564590-20-005025:notes:68]
[same as prior period, unchanged from 0001564590-19-043736:notes:68]

[0001564590-20-005025:notes:69]
[same as prior period, unchanged from 0001564590-19-043736:notes:69]

[0001564590-20-005025:notes:70]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Balance at beginning of period |  | $ | 172 |  |  | $ | 137 |  |
| Additions |  |  | 52 |  |  |  | 62 |  |
| Expense recognized during the period |  |  | (72 | ) |  |  | (60 | ) |
| Balance at end of period |  | $ | 152 |  |  | $ | 139 |  |

[0001564590-20-005025:notes:71]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Other current assets |  | $ | 64 |  |  | $ | 75 |  |
| Other non-current assets |  |  | 88 |  |  |  | 97 |  |
| Total deferred commissions |  | $ | 152 |  |  | $ | 172 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-20-005025:notes:72]
[same as prior period, unchanged from 0001564590-19-043736:notes:72]

[0001564590-20-005025:notes:73]
[same as prior period, unchanged from 0001564590-19-043736:notes:73]

[0001564590-20-005025:notes:74]
[same as prior period, unchanged from 0001564590-19-043736:notes:74]

[0001564590-20-005025:notes:75]
[same as prior period, unchanged from 0001564590-19-043736:notes:75]

[0001564590-20-005025:notes:76]
[same as prior period, unchanged from 0001564590-19-043736:notes:76]

[0001564590-20-005025:notes:77]
[same as prior period, unchanged from 0001564590-19-043736:notes:77]

[0001564590-20-005025:notes:78]
[same as prior period, unchanged from 0001564590-19-043736:notes:78]

[0001564590-20-005025:notes:79]
[same as prior period, unchanged from 0001564590-19-043736:notes:79]

[0001564590-20-005025:notes:80]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 219 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 220 |  |  | $ | 1,359 |  |  | $ | 2 |  |  | $ | (8 | ) |  | $ | 1,353 |  |
| U.S. Treasury and government debt securities |  |  | 83 |  |  |  | — |  |  |  | — |  |  |  | 83 |  |  |  | 214 |  |  |  | — |  |  |  | (1 | ) |  |  | 213 |  |
| Certificates of deposit |  |  | 159 |  |  |  | — |  |  |  | — |  |  |  | 159 |  |  |  | 117 |  |  |  | — |  |  |  | — |  |  |  | 117 |  |
| Mutual funds |  |  | 38 |  |  |  | — |  |  |  | — |  |  |  | 38 |  |  |  | 35 |  |  |  | — |  |  |  | — |  |  |  | 35 |  |
| Total debt and equity securities |  | $ | 499 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 500 |  |  | $ | 1,725 |  |  | $ | 2 |  |  | $ | (9 | ) |  | $ | 1,718 |  |

[0001564590-20-005025:notes:81]
During the nine months ended January 24, 2020, we sold approximately $1.0 billion of corporate bonds held by foreign subsidiaries and recognized a gain on sale of $14 million, which is presented in other income, net on our condensed consolidated statement of operations.

[0001564590-20-005025:notes:82]
The following table presents the contractual maturities of our debt investments as of January 24, 2020 (in millions):

[0001564590-20-005025:notes:83]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 368 |  |  | $ | 368 |  |
| Due after one year through five years |  |  | 88 |  |  |  | 89 |  |
| Due after five years through ten years |  |  | 5 |  |  |  | 5 |  |
|  |  | $ | 461 |  |  | $ | 462 |  |

[0001564590-20-005025:notes:84]
[same as prior period, unchanged from 0001564590-19-043736:notes:84]

[0001564590-20-005025:notes:85]
[same as prior period, unchanged from 0001564590-19-043736:notes:85]

[0001564590-20-005025:notes:86]
[same as prior period, unchanged from 0001564590-19-043736:notes:86]

[0001564590-20-005025:notes:87]
|  |  | January 24, 2020 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,546 |  |  | $ | 2,546 |  |  | $ | — |  |
| Corporate bonds |  | $ | 220 |  |  |  | — |  |  |  | 220 |  |
| U.S. Treasury and government debt securities |  | $ | 83 |  |  |  | 56 |  |  |  | 27 |  |
| Certificates of deposit |  | $ | 159 |  |  |  | — |  |  |  | 159 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,008 |  |  | $ | 2,602 |  |  | $ | 406 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 8 |  |  | $ | 8 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 30 |  |  | $ | 30 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |

[0001564590-20-005025:notes:88]
[same as prior period, unchanged from 0001564590-19-043736:notes:88]

[0001564590-20-005025:notes:89]
[same as prior period, unchanged from 0001564590-19-043736:notes:89]

[0001564590-20-005025:notes:90]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of January 24, 2020 and April 26, 2019, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-20-005025:notes:91]
[same as prior period, unchanged from 0001564590-19-043736:notes:92]

[0001564590-20-005025:notes:92]
As of January 24, 2020 and April 26, 2019, the fair value of our long-term debt was approximately $1,185 million and $1,553 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-20-005025:notes:93]
8. Financing Arrangements

[0001564590-20-005025:notes:94]
Long-Term Debt

[0001564590-20-005025:notes:95]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-20-005025:notes:96]
|  |  |  |  |  |  | January 24, 2020 |  |  | April 26, 2019 |  |
|  |  | Effective Interest Rate |  |  | Amount |  |  | Amount |  |
| 2.00% Senior Notes Due September 2019 |  | 2.32% |  |  | $ | — |  |  | $ | 400 |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  |  | 500 |  |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| Total principal amount |  |  |  |  |  |  | 1,150 |  |  |  | 1,550 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (4 | ) |  |  | (6 | ) |
| Total senior notes |  |  |  |  |  |  | 1,146 |  |  |  | 1,544 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | — |  |  |  | (400 | ) |
| Total long-term debt |  |  |  |  |  | $ | 1,146 |  |  | $ | 1,144 |  |

[0001564590-20-005025:notes:97]
Senior Notes

[0001564590-20-005025:notes:98]
On September 27, 2019, we made an aggregate cash payment of $400 million to extinguish our 2.00% Senior Notes at maturity.

[0001564590-20-005025:notes:99]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017. Interest on these Senior Notes is paid semi-annually in March and September. Our 3.375% Senior Notes and 3.25% Senior Notes, with principal amounts of $500 million and $250 million, respectively, were issued in June 2014 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-20-005025:notes:100]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 24, 2020, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-20-005025:notes:101]
As of January 24, 2020, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-20-005025:notes:102]
| Fiscal Year |  | Amount |  |
| 2022 |  | $ | 500 |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| Total |  | $ | 1,150 |  |

[0001564590-20-005025:notes:103]
Commercial Paper Program and Credit Facility

[0001564590-20-005025:notes:104]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of January 24, 2020 and April 26, 2019, we had commercial paper notes outstanding with aggregate principal amounts of $694 million and $249 million, respectively, weighted-average interest rates of 1.97% and 2.73%, respectively, and maturities generally less than three months.

[0001564590-20-005025:notes:105]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of January 24, 2020 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0001564590-20-005025:notes:106]
[same as prior period, unchanged from 0001564590-19-043736:notes:108]

[0001564590-20-005025:notes:107]
[same as prior period, unchanged from 0001564590-19-043736:notes:109]

[0001564590-20-005025:notes:108]
[same as prior period, unchanged from 0001564590-19-043736:notes:110]

[0001564590-20-005025:notes:109]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 24, 2020 |  |
| Operating lease cost |  | $ | 13 |  |  | $ | 42 |  |
| Variable lease cost |  |  | 4 |  |  |  | 12 |  |
| Total lease cost |  | $ | 17 |  |  | $ | 54 |  |

[0001564590-20-005025:notes:110]
[same as prior period, unchanged from 0001564590-19-043736:notes:112]

[0001564590-20-005025:notes:111]
[same as prior period, unchanged from 0001564590-19-043736:notes:113]

[0001564590-20-005025:notes:112]
|  |  |  |  | Nine Months Ended |  |
|  |  |  |  | January 24, 2020 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  |  |  | $ | 43 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  |  |  | $ | 32 |  |

[0001564590-20-005025:notes:113]
[same as prior period, unchanged from 0001564590-19-043736:notes:115]

[0001564590-20-005025:notes:114]
|  |  |  |  | January 24, 2020 |  |
| Other non-current assets |  |  |  | $ | 142 |  |
| Total operating lease ROU assets |  |  |  | $ | 142 |  |
| Accrued expenses |  |  |  | $ | 50 |  |
| Other long-term liabilities |  |  |  |  | 99 |  |
| Total operating lease liabilities |  |  |  | $ | 149 |  |
| Weighted Average Remaining Lease Term |  |  |  | 4.0 years |  |
| Weighted Average Discount Rate |  |  |  |  | 2.7 | % |

[0001564590-20-005025:notes:115]
Future minimum operating lease payments as of January 24, 2020 are as follows (in millions):

[0001564590-20-005025:notes:116]
|  |  |  |  | Operating Leases |  |
| Fiscal 2020 (remainder) |  |  |  | $ | 14 |  |
| Fiscal 2021 |  |  |  |  | 51 |  |
| Fiscal 2022 |  |  |  |  | 37 |  |
| Fiscal 2023 |  |  |  |  | 22 |  |
| Fiscal 2024 |  |  |  |  | 15 |  |
| Thereafter |  |  |  |  | 19 |  |
| Total lease payments |  |  |  | $ | 158 |  |
| Less: Interest |  |  |  |  | (9 | ) |
| Total |  |  |  | $ | 149 |  |

[0001564590-20-005025:notes:117]
[same as prior period, unchanged from 0001564590-19-043736:notes:119]

[0001564590-20-005025:notes:118]
[same as prior period, unchanged from 0001564590-19-043736:notes:120]


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-20-005025:notes:119]
[same as prior period, unchanged from 0001564590-19-043736:notes:121]

[0001564590-20-005025:notes:120]
[same as prior period, unchanged from 0001564590-19-043736:notes:122]

[0001564590-20-005025:notes:121]
As of January 24, 2020, we have certain equity incentive awards (awards) outstanding, which include stock options and restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs). Also outstanding are purchase rights under our Employee Stock Purchase Plan (ESPP). During the second quarter of fiscal 2020, the 1999 Stock Option Plan, under which stock options and RSUs are granted, was extended for a 10 year term.

[0001564590-20-005025:notes:122]
[same as prior period, unchanged from 0001564590-19-043736:notes:124]

[0001564590-20-005025:notes:123]
Less than 1 million options were outstanding as of January 24, 2020 and April 26, 2019.

[0001564590-20-005025:notes:124]
[same as prior period, unchanged from 0001564590-19-043736:notes:126]

[0001564590-20-005025:notes:125]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Intrinsic value of exercises |  | $ | 4 |  |  | $ | 28 |  |
| Proceeds received from exercises |  | $ | 4 |  |  | $ | 23 |  |
| Fair value of options vested |  | $ | 1 |  |  | $ | 2 |  |

[0001564590-20-005025:notes:126]
[same as prior period, unchanged from 0001564590-19-043736:notes:128]

[0001564590-20-005025:notes:127]
[same as prior period, unchanged from 0001564590-19-043736:notes:129]

[0001564590-20-005025:notes:128]
In the nine months ended January 24, 2020, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria, in addition to the service based vesting criteria, such that the PBRSUs cliff-vest at the end of an approximate three year performance period, which began on the date specified in the grant agreements and ends the last day of fiscal 2022. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the current year, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of fiscal 2022. The fair values of these awards were fixed at grant date using a Monte Carlo simulation model. For the remaining PBRSUs granted, the number of shares issued will depend upon our achievement against a cumulative Adjusted Operating Income (AOI) target, as defined in the grant agreements, for the three year period from fiscal 2020 through 2022. The fair values of these awards were established consistent with our methodology for valuing time-based RSUs, while compensation cost is being recognized based on the probable outcome of the performance condition. The aggregate grant date fair value of all PBRSUs granted in the current year was $18 million, which is being recognized to compensation expense over the remaining applicable performance / service periods.

[0001564590-20-005025:notes:129]
[same as prior period, unchanged from 0001564590-19-043736:notes:131]

[0001564590-20-005025:notes:130]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 26, 2019 |  |  | 8 |  |  | $ | 45.68 |  |
| Granted |  |  | 3 |  |  | $ | 52.54 |  |
| Vested |  |  | (3 | ) |  | $ | 38.74 |  |
| Forfeited |  |  | (1 | ) |  | $ | 47.80 |  |
| Outstanding as of January 24, 2020 |  |  | 7 |  |  | $ | 51.79 |  |

[0001564590-20-005025:notes:131]
[same as prior period, unchanged from 0001564590-19-043736:notes:133]

[0001564590-20-005025:notes:132]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 77 |  |  | $ | 92 |  |

[0001564590-20-005025:notes:133]
[same as prior period, unchanged from 0001564590-19-043736:notes:135]

[0001564590-20-005025:notes:134]
[same as prior period, unchanged from 0001564590-19-043736:notes:136]

[0001564590-20-005025:notes:135]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Shares issued under the ESPP |  |  | 2 |  |  |  | 3 |  |
| Proceeds from issuance of shares |  | $ | 98 |  |  | $ | 96 |  |

[0001564590-20-005025:notes:136]
[same as prior period, unchanged from 0001564590-19-043736:notes:138]

[0001564590-20-005025:notes:137]
[same as prior period, unchanged from 0001564590-19-043736:notes:139]

[0001564590-20-005025:notes:138]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 2 |  |
| Cost of hardware maintenance and other services revenues |  |  | 2 |  |  |  | 3 |  |  |  | 7 |  |  |  | 8 |  |
| Sales and marketing |  |  | 15 |  |  |  | 19 |  |  |  | 50 |  |  |  | 52 |  |
| Research and development |  |  | 13 |  |  |  | 13 |  |  |  | 41 |  |  |  | 37 |  |
| General and administrative |  |  | 5 |  |  |  | 7 |  |  |  | 17 |  |  |  | 22 |  |
| Total stock-based compensation expense |  | $ | 36 |  |  | $ | 43 |  |  | $ | 118 |  |  | $ | 121 |  |
| Income tax benefit for stock-based compensation expense |  | $ | 3 |  |  | $ | 1 |  |  | $ | 11 |  |  | $ | 11 |  |

[0001564590-20-005025:notes:139]
As of January 24, 2020, total unrecognized compensation expense related to our equity awards was $315 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.1 years.

[0001564590-20-005025:notes:140]
[same as prior period, unchanged from 0001564590-19-043736:notes:142]

[0001564590-20-005025:notes:141]
[same as prior period, unchanged from 0001564590-19-043736:notes:143]

[0001564590-20-005025:notes:142]
The following table summarizes activity related to this program for the nine months ended January 24, 2020 (in millions, except per share amounts):

[0001564590-20-005025:notes:143]
| Number of shares repurchased |  |  | 22 |  |
| Average price per share |  | $ | 57.36 |  |
| Aggregate purchase price |  | $ | 1,250 |  |
| Remaining authorization at end of period |  | $ | 639 |  |

[0001564590-20-005025:notes:144]
The aggregate purchase price of our stock repurchases for the nine months ended January 24, 2020 consisted of $1,250 million of open market purchases, of which $621 million and $629 million were allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-20-005025:notes:145]
Since the May 13, 2003 inception of our stock repurchase program through January 24, 2020, we repurchased a total of 335 million shares of our common stock at an average price of $38.76 per share, for an aggregate purchase price of $13.0 billion.

[0001564590-20-005025:notes:146]
[same as prior period, unchanged from 0001564590-19-043736:notes:148]

[0001564590-20-005025:notes:147]
[same as prior period, unchanged from 0001564590-19-043736:notes:149]

[0001564590-20-005025:notes:148]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Dividends per share declared |  | $ | 1.44 |  |  | $ | 1.20 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 334 |  |  | $ | 306 |  |
| Dividend payments allocated to retained earnings |  | $ | — |  |  | $ | — |  |

[0001564590-20-005025:notes:149]
On February 12, 2020, we declared a cash dividend of $0.48 per share of common stock, payable on April 22, 2020 to holders of record as of the close of business on April 3, 2020. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-20-005025:notes:150]
[same as prior period, unchanged from 0001564590-19-043736:notes:152]

[0001564590-20-005025:notes:151]
[same as prior period, unchanged from 0001564590-19-043736:notes:153]

[0001564590-20-005025:notes:152]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 26, 2019 |  | $ | (34 | ) |  | $ | (3 | ) |  | $ | (7 | ) |  | $ | 1 |  |  | $ | (43 | ) |
| Other comprehensive income (loss), net of tax |  |  | (2 | ) |  |  | — |  |  |  | 22 |  |  |  | (1 | ) |  |  | 19 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | (1 | ) |  |  | (14 | ) |  |  | — |  |  |  | (15 | ) |
| Total other comprehensive income (loss) |  |  | (2 | ) |  |  | (1 | ) |  |  | 8 |  |  |  | (1 | ) |  |  | 4 |  |
| Balance as of January 24, 2020 |  | $ | (36 | ) |  | $ | (4 | ) |  | $ | 1 |  |  | $ | — |  |  | $ | (39 | ) |

[0001564590-20-005025:notes:153]
During the first nine months of fiscal 2020, realized gains of $14 million from the sale of available-for-sale debt securities were recorded in other income, net on our condensed consolidated statements of operations.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-20-005025:notes:154]
[same as prior period, unchanged from 0001564590-19-043736:notes:156]

[0001564590-20-005025:notes:155]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of our agreements with them. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of January 24, 2020 or April 26, 2019. All contracts have a maturity of less than 12 months.

[0001564590-20-005025:notes:156]
[same as prior period, unchanged from 0001564590-19-043736:notes:158]

[0001564590-20-005025:notes:157]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 171 |  |  | $ | 103 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 60 |  |  | $ | 121 |  |
| Forward contracts purchased |  | $ | 221 |  |  | $ | 363 |  |

[0001564590-20-005025:notes:158]
[same as prior period, unchanged from 0001564590-19-043736:notes:160]

[0001564590-20-005025:notes:159]
[same as prior period, unchanged from 0001564590-19-043736:notes:161]

[0001564590-20-005025:notes:160]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
|  |  | Gain (Loss) Recognized in Income |  |  | Gain (Loss) Recognized in Income |  |
| Foreign currency exchange contracts |  | $ | 5 |  |  | $ | (2 | ) |  | $ | 2 |  |  | $ | 10 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-005025:notes:161]
[same as prior period, unchanged from 0001564590-19-043736:notes:163]

[0001564590-20-005025:notes:162]
In the first quarter of fiscal 2020, we announced a restructuring plan (the May 2019 Plan) to reduce costs and redirect resources to our highest return activities, which included a reduction in our global workforce of approximately 2%. Charges related to the plan consisted primarily of employee severance-related costs. Substantially all activities under the plan have been completed.

[0001564590-20-005025:notes:163]
Management has previously approved several restructuring actions, including the May 2018 Plan and April 2019 Plan, under which we reduced our global workforce by less than 2%, and approximately 1%, respectively. Charges related to our restructuring plans consisted primarily of employee severance-related costs. Substantially all activities under the May 2018 Plan were complete as of the end of fiscal 2019, and substantially all activities under the April 2019 Plan were complete as of the end of the third quarter of fiscal 2020.

[0001564590-20-005025:notes:164]
[same as prior period, unchanged from 0001564590-19-043736:notes:166]

[0001564590-20-005025:notes:165]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |  |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  |  |
|  |  | May 2019 Plan |  |  | April 2019 Plan |  |  | November 2016 Plan |  |  | Total |  |  | May 2018 Plan |  |  | November 2016 Plan |  |  | Total |  |  |  |
| Balance at beginning of period |  | $ | — |  |  | $ | 15 |  |  | $ | 4 |  |  | $ | 19 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 6 |  |  |  |
| Net charges |  |  | 21 |  |  |  | — |  |  |  | — |  |  |  | 21 |  |  |  | 19 |  |  |  | — |  |  |  | 19 |  |  |  |
| Cash payments |  |  | (20 | ) |  |  | (14 | ) |  |  | — |  |  |  | (34 | ) |  |  | (18 | ) |  |  | (2 | ) |  |  | (20 | ) |  |  |
| Other |  |  | — |  |  |  | — |  |  |  | (4 | ) |  |  | (4 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  |
| Balance at end of period |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 1 |  |  | $ | 4 |  |  | $ | 5 |  |  |  |

[0001564590-20-005025:notes:166]
[same as prior period, unchanged from 0001564590-19-043736:notes:168]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-005025:notes:167]
[same as prior period, unchanged from 0001564590-19-043736:notes:169]

[0001564590-20-005025:notes:168]
[same as prior period, unchanged from 0001564590-19-043736:notes:170]

[0001564590-20-005025:notes:169]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Effective tax rates |  |  | 10.2 | % |  |  | 12.6 | % |

[0001564590-20-005025:notes:170]
Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations, being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory tax rate. The differences in effective tax rates for the nine months ended January 24, 2020 and January 25, 2019 were primarily due to discrete tax benefits, including lapses of statutes of limitations and tax on the sale of land in Sunnyvale, California in fiscal 2020, and the differences in discrete tax benefits for stock-based compensation and the adoption of the new revenue standard in fiscal 2019.

[0001564590-20-005025:notes:171]
[same as prior period, unchanged from 0001564590-19-043736:notes:173]

[0001564590-20-005025:notes:172]
We recognized a $50 million discrete tax benefit related to the lapse of certain statutes of limitations in the third quarter of fiscal 2020. During fiscal 2019, we adopted the new revenue accounting standard and for the nine months ended January 25, 2019, we recognized a $34 million discrete tax benefit for adjustments to certain intercompany transactions resulting from the retrospective application of the new revenue accounting standard.

[0001564590-20-005025:notes:173]
As of January 24, 2020, we had $187 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $165 million would affect our provision for income taxes if recognized, and $167 million has been recorded in other long-term liabilities.

[0001564590-20-005025:notes:174]
[same as prior period, unchanged from 0001564590-19-043736:notes:176]

[0001564590-20-005025:notes:175]
[same as prior period, unchanged from 0001564590-19-043736:notes:177]

[0001564590-20-005025:notes:176]
[same as prior period, unchanged from 0001564590-19-043736:notes:178]


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-005025:notes:177]
[same as prior period, unchanged from 0001564590-19-043736:notes:179]

[0001564590-20-005025:notes:178]
[same as prior period, unchanged from 0001564590-19-043736:notes:180]

[0001564590-20-005025:notes:179]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 277 |  |  | $ | 249 |  |  | $ | 623 |  |  | $ | 773 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 226 |  |  |  | 250 |  |  |  | 233 |  |  |  | 257 |  |
| Dilutive impact of employee equity award plans |  |  | 3 |  |  |  | 5 |  |  |  | 3 |  |  |  | 6 |  |
| Shares used in diluted computation |  |  | 229 |  |  |  | 255 |  |  |  | 236 |  |  |  | 263 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.23 |  |  | $ | 1.00 |  |  | $ | 2.67 |  |  | $ | 3.01 |  |
| Diluted |  | $ | 1.21 |  |  | $ | 0.98 |  |  | $ | 2.64 |  |  | $ | 2.94 |  |

[0001564590-20-005025:notes:180]
Three million potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for the three and nine months ended January 24, 2020, while less than 1 million potential shares were excluded from the calculation for the three and nine months ended January 25, 2019, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-005025:notes:181]
[same as prior period, unchanged from 0001564590-19-043736:notes:183]

[0001564590-20-005025:notes:182]
[same as prior period, unchanged from 0001564590-19-043736:notes:184]

[0001564590-20-005025:notes:183]
[same as prior period, unchanged from 0001564590-19-043736:notes:185]

[0001564590-20-005025:notes:184]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| United States, Canada and Latin America (Americas) |  | $ | 695 |  |  | $ | 814 |  |  | $ | 2,101 |  |  | $ | 2,525 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 494 |  |  |  | 523 |  |  |  | 1,298 |  |  |  | 1,382 |  |
| Asia Pacific (APAC) |  |  | 215 |  |  |  | 226 |  |  |  | 612 |  |  |  | 647 |  |
| Net revenues |  | $ | 1,404 |  |  | $ | 1,563 |  |  | $ | 4,011 |  |  | $ | 4,554 |  |

[0001564590-20-005025:notes:185]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $620 million and $744 million during the three months ended January 24, 2020 and January 25, 2019, respectively, and were $1,897 million and $2,294 million during the nine months ended January 24, 2020 and January 25, 2019, respectively.

[0001564590-20-005025:notes:186]
[same as prior period, unchanged from 0001564590-19-043736:notes:188]

[0001564590-20-005025:notes:187]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| U.S. |  | $ | 551 |  |  | $ | 159 |  |
| International |  |  | 2,457 |  |  |  | 3,740 |  |
| Total |  | $ | 3,008 |  |  | $ | 3,899 |  |

[0001564590-20-005025:notes:188]
[same as prior period, unchanged from 0001564590-19-043736:notes:190]

[0001564590-20-005025:notes:189]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| U.S. |  | $ | 555 |  |  | $ | 572 |  |
| International |  |  | 185 |  |  |  | 187 |  |
| Total |  | $ | 740 |  |  | $ | 759 |  |

[0001564590-20-005025:notes:190]
[same as prior period, unchanged from 0001564590-19-043736:notes:192]

[0001564590-20-005025:notes:191]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Arrow Electronics, Inc. |  |  | 25 | % |  |  | 25 | % |  |  | 25 | % |  |  | 24 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 20 | % |  |  | 20 | % |  |  | 19 | % |

[0001564590-20-005025:notes:192]
[same as prior period, unchanged from 0001564590-19-043736:notes:194]

[0001564590-20-005025:notes:193]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Arrow Electronics, Inc. |  |  | 10 | % |  |  | 11 | % |
| Tech Data Corporation |  |  | 15 | % |  |  | 24 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-005025:notes:194]
16. Commitments and Contingencies

[0001564590-20-005025:notes:195]
Purchase Orders and Other Commitments

[0001564590-20-005025:notes:196]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 24, 2020, we had $486 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 24, 2020 and April 26, 2019, such liability amounted to $10 million and $16 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-20-005025:notes:197]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 24, 2020, we had $7 million in construction related obligations and $234 million in other purchase obligations.

[0001564590-20-005025:notes:198]
Financing Guarantees

[0001564590-20-005025:notes:199]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $49 million and $54 million of receivables during the nine months ended January 24, 2020 and January 25, 2019, respectively.

[0001564590-20-005025:notes:200]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-20-005025:notes:201]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of January 24, 2020 and April 26, 2019, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-20-005025:notes:202]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 24, 2020, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-20-005025:notes:203]
Legal Contingencies

[0001564590-20-005025:notes:204]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-20-005025:notes:205]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. We believe the complaint is without merit and intend to defend the case vigorously.

[0001564590-20-005025:notes:206]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-20-005025:notes:207]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends.  No material accrual has been recorded as of January 24, 2020 related to such matters.
