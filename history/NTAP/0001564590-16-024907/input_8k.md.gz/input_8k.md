# NTAP 8-K — 0001564590-16-024497 filed 2016-08-17

## item codes, every 8-K on or before 2016-09-02

- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2016-09-02

- none on or before 2016-09-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-16-024497:8k_2_02:1]
EX-99.1
2
ntap-ex991_16.htm
EX-99.1

[0001564590-16-024497:8k_2_02:2]
ntap-ex991_16.htm

[0001564590-16-024497:8k_2_02:3]
Exhibit 99.1

[0001564590-16-024497:8k_2_02:4]
NETAPP REPORTS FIRST QUARTER FISCAL YEAR 2017 RESULTS

[0001564590-16-024497:8k_2_02:5]
Net Revenues of $1.29 Billion for the First Quarter

[0001564590-16-024497:8k_2_02:6]
| · | Clustered Data ONTAP™ deployed on 32% of installed base systems |

[0001564590-16-024497:8k_2_02:7]
| · | Deferred revenue and financed unearned services revenue up 8% year-over-year |

[0001564590-16-024497:8k_2_02:8]
| · | Free cash flow1 of $192 million, up more than 100% year-over-year |

[0001564590-16-024497:8k_2_02:9]
| · | $228 million returned to shareholders in share repurchases and cash dividends |

[0001564590-16-024497:8k_2_02:10]
Sunnyvale, Calif.—August 17, 2016—NetApp (NASDAQ: NTAP) today reported financial results for the first quarter fiscal year 2017, ended July 29, 2016.

[0001564590-16-024497:8k_2_02:11]
First Quarter Financial Results

[0001564590-16-024497:8k_2_02:12]
Net revenues for the first quarter of fiscal year 2017 were $1.29 billion. GAAP net income for the first quarter of fiscal year 2017 was $64 million, or $0.23 income per share,2 compared to GAAP net loss of $30 million, or $0.10 loss per share,3 for the comparable period of the prior year. Non-GAAP net income for the first quarter of fiscal year 2017 was $129 million, or $0.46 income per share,4 compared to non-GAAP net income of $89 million, or $0.29 income per share, for the comparable period of the prior year.

[0001564590-16-024497:8k_2_02:13]
Cash, Cash Equivalents and Investments

[0001564590-16-024497:8k_2_02:14]
NetApp ended the first quarter of fiscal year 2017 with $4.4 billion in total cash, cash equivalents and investments. During the first quarter of fiscal year 2017, the Company generated $228 million in cash from operations and returned $228 million to shareholders through share repurchases and a cash dividend.

[0001564590-16-024497:8k_2_02:15]
The Company announced the next cash dividend of $0.19 per share. The quarterly dividend will be paid on October 26, 2016, to shareholders of record as of the close of business on October 7, 2016.

[0001564590-16-024497:8k_2_02:16]
“We are pleased with our first quarter results. Our focus on disciplined execution of our strategy is yielding results and starting to change the trajectory of our business,” said George Kurian, chief executive officer. “We remain sharply focused on operating more efficiently while delivering market-leading innovations that are aligned to our customers' business and IT transformation priorities.”

[0001564590-16-024497:8k_2_02:17]
Q2 Fiscal Year 2017 Outlook

[0001564590-16-024497:8k_2_02:18]
The Company provided the following financial guidance for the second quarter of fiscal year 2017:

[0001564590-16-024497:8k_2_02:19]
| · | Net revenues are expected to be in the range of $1.265 billion to $1.415 billion. |

[0001564590-16-024497:8k_2_02:20]
| · | GAAP earnings per share is expected to be in the range of $0.31 to $0.36 per share. |

[0001564590-16-024497:8k_2_02:21]
| · | Non-GAAP earnings per share is expected to be in the range of $0.51 to $0.56 per share. |

[0001564590-16-024497:8k_2_02:22]
Business Highlights

[0001564590-16-024497:8k_2_02:23]
| · | Continued Leadership in Flash |

[0001564590-16-024497:8k_2_02:24]
|  | - | NetApp Flash Accelerates Docker Ecosystem with Native Storage Integration. Integration of the NetApp flash storage portfolio with the NetApp Docker Volume Plug-In (nDVP) allows containerized applications to take advantage of solid-state performance with true deployment flexibility. |

[0001564590-16-024497:8k_2_02:25]
|  | - | NetApp SolidFire Unveils Innovative Storage Purchasing Model for the Next-Generation Data Center. FlashForward Capacity Licensing creates significant flexibility and investment protection for customers to purchase storage infrastructure in alignment with the dynamic and growing nature of their businesses. |

[0001564590-16-024497:8k_2_02:26]
|  | - | NetApp SolidFire Introduces New Highest-Density SF-Series. The latest addition to the NetApp SolidFire SF-Series product line delivers twice the performance and capacity and version 9 of the SolidFire Element operating system (Fluorine) simplifies customers’ transitions to service delivery-oriented infrastructure. |

[0001564590-16-024497:8k_2_02:27]
|  | - | NetApp FlashAdvantage 3-4-5 Makes the All-Flash Data Center a Reality. The new FlashAdvantage 3-4-5 program now includes the industry’s only guaranteed efficiency data reduction of 4:1. This program, combined with the new NetApp 15TB solid state drives, will make flash the ideal workload consolidation platform for customers’ infrastructure needs. |

[0001564590-16-024497:8k_2_02:28]
| · | Strength Within the Hybrid Cloud |

[0001564590-16-024497:8k_2_02:29]
|  | - | NetApp Strengthens the Enterprise’s Ability to Protect and Manage Data Across the Hybrid Cloud. New enhancements to NetApp data protection software, including NetApp OnCommand™ Insight and new NetApp Data Protection Solutions for Microsoft Office 365, help customers reduce the risk of data loss while enabling business continuity with the right mix of cloud resources. |

[0001564590-16-024497:8k_2_02:30]
|  | - | NetApp Simplifies Transition to Hybrid Cloud, Next-Generation Data Center. With ONTAP 9 software, enterprises can quickly integrate the best of traditional and emerging technologies, incorporating flash, the cloud, and software-defined architectures to build a Data Fabric foundation across on-premises and cloud resources. |

[0001564590-16-024497:8k_2_02:31]
| · | Customers and Partners Achieve Success Through NetApp |

[0001564590-16-024497:8k_2_02:32]
|  | - | NetApp Helps Protect NASA Johnson Space Center’s Mission-Critical Data. With one of the largest cloud footprints of any U.S. federal government agency, NASA chose NetApp AltaVault™ to help protect NASA’s mission-critical data, optimize its cloud footprint, and drive down cost. |

[0001564590-16-024497:8k_2_02:33]
|  | - | NetApp Builds Momentum Within the Education Industry. NetApp AFF enabled the University of Scranton to enhance e-learning with a “bring your own device” program, which helped connect students and teachers anywhere in the world at any time. In addition, Seminole County Public Schools used NetApp FAS8040HA storage and AltaVault backup-to-cloud solutions to provide nonstop, secure data access and fast application response to more than 40 departments. |

[0001564590-16-024497:8k_2_02:34]
|  | - | Citrix Speeds Mobile Application Delivery with NetApp FlexPod with All Flash FAS. Citrix chose NetApp to support automated testing on a large scale, drive down latency, and work with the Citrix XenServer and NFS shared storage. NetApp’s performance, flexibility, rich data management features, and previous partnership with Citrix were key reasons NetApp was selected. |

[0001564590-16-024497:8k_2_02:35]
Webcast and Conference Call Information

[0001564590-16-024497:8k_2_02:36]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and

[0001564590-16-024497:8k_2_02:37]
other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:30 p.m. Pacific Time today.

[0001564590-16-024497:8k_2_02:38]
About NetApp

[0001564590-16-024497:8k_2_02:39]
Leading organizations worldwide count on NetApp for software, systems and services to manage and store their data. Customers value our teamwork, expertise and passion for helping them succeed now and into the future. To learn more, visit www.netapp.com.

[0001564590-16-024497:8k_2_02:40]
###

[0001564590-16-024497:8k_2_02:41]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-16-024497:8k_2_02:42]
1Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less cash used to acquire property and equipment.

[0001564590-16-024497:8k_2_02:43]
2 GAAP net income per share is calculated using the diluted number of shares.

[0001564590-16-024497:8k_2_02:44]
3 GAAP net loss per share is calculated using the basic number of shares and excludes common stock equivalents because the impact would be anti-dilutive.

[0001564590-16-024497:8k_2_02:45]
4Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) acquisition-related income and expenses, (d) restructuring and other charges, (e) asset impairments, (f) gains/losses on the sale of properties, and (g) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-16-024497:8k_2_02:46]
NetApp Usage of Non-GAAP Financial Information

[0001564590-16-024497:8k_2_02:47]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results and non-GAAP net income, non-GAAP effective tax rate, non-GAAP inventory turns, and free cash flow; and historical and projected non-GAAP net income per diluted share.

[0001564590-16-024497:8k_2_02:48]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP net income per share data when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management

[0001564590-16-024497:8k_2_02:49]
regarding financial and business trends relating to its financial condition and results of operations. In addition, NetApp believes that the presentation of non-GAAP inventory turns provides useful information to investors and management regarding financial and business trends relating to inventory management based on the operating activities of the periods presented. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock, after deducting capital expenditures. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for the analysis provided in the statement of cash flows.

[0001564590-16-024497:8k_2_02:50]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001564590-16-024497:8k_2_02:51]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-16-024497:8k_2_02:52]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-16-024497:8k_2_02:53]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-16-024497:8k_2_02:54]
C. Acquisition-related income and expenses. NetApp excludes acquisition-related income and expenses, including (a) merger termination proceeds, (b) due diligence, legal and other one-time integration charges, (c) the impact of inventory step-ups, and (d) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-16-024497:8k_2_02:55]
D. Restructuring and other charges. These charges include restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. These items are not ordinarily included in our annual operating plan and related budget due to the unpredictability of the timing and size of these events. We therefore exclude them in our assessment of operational performance.

[0001564590-16-024497:8k_2_02:56]
E. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-16-024497:8k_2_02:57]
F. Gains/losses on the sale of properties. These are gains/losses from the sale of our properties. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-16-024497:8k_2_02:58]
G. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual properties from acquisitions. Management believes

[0001564590-16-024497:8k_2_02:59]
that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-16-024497:8k_2_02:60]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-16-024497:8k_2_02:61]
NETAPP, INC.

[0001564590-16-024497:8k_2_02:62]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-16-024497:8k_2_02:63]
(In millions)

[0001564590-16-024497:8k_2_02:64]
(Unaudited)

[0001564590-16-024497:8k_2_02:65]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,421 |  |  | $ | 5,303 |  |
| Accounts receivable |  |  | 501 |  |  |  | 813 |  |
| Inventories |  |  | 81 |  |  |  | 98 |  |
| Other current assets |  |  | 220 |  |  |  | 234 |  |
| Total current assets |  |  | 5,223 |  |  |  | 6,448 |  |
| Property and equipment, net |  |  | 942 |  |  |  | 937 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,845 |  |  |  | 1,856 |  |
| Other non-current assets |  |  | 777 |  |  |  | 796 |  |
| Total assets |  | $ | 8,787 |  |  | $ | 10,037 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 239 |  |  | $ | 254 |  |
| Accrued expenses |  |  | 561 |  |  |  | 765 |  |
| Short-term loan |  |  | — |  |  |  | 849 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,724 |  |  |  | 1,794 |  |
| Total current liabilities |  |  | 2,524 |  |  |  | 3,662 |  |
| Long-term debt |  |  | 1,491 |  |  |  | 1,490 |  |
| Other long-term liabilities |  |  | 404 |  |  |  | 413 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,576 |  |  |  | 1,591 |  |
| Total liabilities |  |  | 5,995 |  |  |  | 7,156 |  |
| Stockholders' equity |  |  | 2,792 |  |  |  | 2,881 |  |
| Total liabilities and stockholders' equity |  | $ | 8,787 |  |  | $ | 10,037 |  |

[0001564590-16-024497:8k_2_02:66]
NETAPP, INC.

[0001564590-16-024497:8k_2_02:67]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-16-024497:8k_2_02:68]
(In millions, except per share amounts)

[0001564590-16-024497:8k_2_02:69]
(Unaudited)

[0001564590-16-024497:8k_2_02:70]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Product |  | $ | 660 |  |  | $ | 664 |  |
| Software maintenance |  |  | 241 |  |  |  | 248 |  |
| Hardware maintenance and other services |  |  | 393 |  |  |  | 423 |  |
| Net revenues |  |  | 1,294 |  |  |  | 1,335 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 359 |  |  |  | 345 |  |
| Cost of software maintenance |  |  | 8 |  |  |  | 10 |  |
| Cost of hardware maintenance and other services |  |  | 130 |  |  |  | 164 |  |
| Total cost of revenues |  |  | 497 |  |  |  | 519 |  |
| Gross profit |  |  | 797 |  |  |  | 816 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 429 |  |  |  | 492 |  |
| Research and development |  |  | 207 |  |  |  | 244 |  |
| General and administrative |  |  | 68 |  |  |  | 79 |  |
| Restructuring and other charges |  |  | — |  |  |  | 27 |  |
| Total operating expenses |  |  | 704 |  |  |  | 842 |  |
| Income (loss) from operations |  |  | 93 |  |  |  | (26 | ) |
| Other income (expense), net |  |  | (1 | ) |  |  | 4 |  |
| Income (loss) before income taxes |  |  | 92 |  |  |  | (22 | ) |
| Provision for income taxes |  |  | 28 |  |  |  | 8 |  |
| Net income (loss) |  | $ | 64 |  |  | $ | (30 | ) |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.23 |  |  | $ | (0.10 | ) |
| Diluted |  | $ | 0.23 |  |  | $ | (0.10 | ) |
| Shares used in net income (loss) per share calculations: |  |  |  |  |  |  |  |  |
| Basic |  |  | 279 |  |  |  | 304 |  |
| Diluted |  |  | 282 |  |  |  | 304 |  |
| Cash dividends declared per share |  | $ | 0.190 |  |  | $ | 0.180 |  |

[0001564590-16-024497:8k_2_02:71]
NETAPP, INC.

[0001564590-16-024497:8k_2_02:72]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-16-024497:8k_2_02:73]
(In millions)

[0001564590-16-024497:8k_2_02:74]
(Unaudited)

[0001564590-16-024497:8k_2_02:75]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 64 |  |  | $ | (30 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 60 |  |  |  | 69 |  |
| Stock-based compensation |  |  | 52 |  |  |  | 77 |  |
| Other non-cash items, net |  |  | 12 |  |  |  | (36 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 311 |  |  |  | 361 |  |
| Inventories |  |  | 17 |  |  |  | (47 | ) |
| Accounts payable |  |  | (30 | ) |  |  | (33 | ) |
| Accrued expenses |  |  | (198 | ) |  |  | (119 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (83 | ) |  |  | (121 | ) |
| Changes in other operating assets and liabilities, net |  |  | 23 |  |  |  | 8 |  |
| Net cash provided by operating activities |  |  | 228 |  |  |  | 129 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 313 |  |  |  | 778 |  |
| Purchases of property and equipment |  |  | (36 | ) |  |  | (38 | ) |
| Other investing activities, net |  |  | (1 | ) |  |  | 2 |  |
| Net cash provided by investing activities |  |  | 276 |  |  |  | 742 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuance of common stock under employee stock award plans |  |  | 9 |  |  |  | 19 |  |
| Repurchase of common stock |  |  | (175 | ) |  |  | (430 | ) |
| Repayment of short-term loan |  |  | (850 | ) |  |  | — |  |
| Dividends paid |  |  | (53 | ) |  |  | (54 | ) |
| Other financing activities, net |  |  | (2 | ) |  |  | 1 |  |
| Net cash used in financing activities |  |  | (1,071 | ) |  |  | (464 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (7 | ) |  |  | (5 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (574 | ) |  |  | 402 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,868 |  |  |  | 1,922 |  |
| End of period |  | $ | 2,294 |  |  | $ | 2,324 |  |

[0001564590-16-024497:8k_2_02:76]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q1 FY'17 |  |  | Q4 FY'16 |  |  | Q1 FY'16 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 660 |  |  | $ | 757 |  |  | $ | 664 |  |
| Strategic |  | $ | 400 |  |  | $ | 468 |  |  | $ | 323 |  |
| Mature |  | $ | 260 |  |  | $ | 289 |  |  | $ | 341 |  |
| Software Maintenance |  | $ | 241 |  |  | $ | 234 |  |  | $ | 248 |  |
| Hardware Maintenance and Other Services: |  | $ | 393 |  |  | $ | 389 |  |  | $ | 423 |  |
| Hardware Maintenance Support Contracts |  | $ | 323 |  |  | $ | 318 |  |  | $ | 346 |  |
| Professional and Other Services |  | $ | 70 |  |  | $ | 71 |  |  | $ | 77 |  |
| Net Revenues |  | $ | 1,294 |  |  | $ | 1,380 |  |  | $ | 1,335 |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'17 Revenue |  |  | % of Q4 FY'16 Revenue |  |  | % of Q1 FY'16 Revenue |  |
| Americas |  |  | 57 | % |  |  | 54 | % |  |  | 56 | % |
| Americas Commercial |  |  | 44 | % |  |  | 43 | % |  |  | 44 | % |
| U.S. Public Sector |  |  | 13 | % |  |  | 12 | % |  |  | 12 | % |
| EMEA |  |  | 30 | % |  |  | 33 | % |  |  | 31 | % |
| Asia Pacific |  |  | 13 | % |  |  | 13 | % |  |  | 13 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'17 Revenue |  |  | % of Q4 FY'16 Revenue |  |  | % of Q1 FY'16 Revenue |  |
| Direct |  |  | 23 | % |  |  | 26 | % |  |  | 22 | % |
| Indirect |  |  | 77 | % |  |  | 74 | % |  |  | 77 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'17 |  |  | Q4 FY'16 |  |  | Q1 FY'16 |  |
| Non-GAAP Gross Margin |  |  | 62.4 | % |  |  | 61.1 | % |  |  | 63.6 | % |
| Product |  |  | 46.7 | % |  |  | 46.8 | % |  |  | 51.2 | % |
| Software Maintenance |  |  | 96.7 | % |  |  | 96.2 | % |  |  | 96.2 | % |
| Hardware Maintenance and Other Services |  |  | 67.9 | % |  |  | 67.9 | % |  |  | 64.1 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'17 |  |  | Q4 FY'16 |  |  | Q1 FY'16 |  |
| Non-GAAP Income from Operations |  | $ | 156 |  |  | $ | 185 |  |  | $ | 103 |  |
| % of Net Revenues |  |  | 12.1 | % |  |  | 13.4 | % |  |  | 7.7 | % |
| Non-GAAP Income before Income Taxes |  | $ | 155 |  |  | $ | 181 |  |  | $ | 107 |  |
| Non-GAAP Effective Tax Rate |  |  | 16.6 | % |  |  | 13.1 | % |  |  | 17.0 | % |

[0001564590-16-024497:8k_2_02:77]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'17 |  |  | Q4 FY'16 |  |  | Q1 FY'16 |  |
| Non-GAAP Net Income |  | $ | 129 |  |  | $ | 157 |  |  | $ | 89 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 282 |  |  |  | 287 |  |  |  | 308 |  |
| Non-GAAP Income per Share, Diluted |  | $ | 0.46 |  |  | $ | 0.55 |  |  | $ | 0.29 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'17 |  |  | Q4 FY'16 |  |  | Q1 FY'16 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,300 |  |  | $ | 3,385 |  |  | $ | 3,066 |  |
| DSO (days) |  |  | 35 |  |  |  | 54 |  |  |  | 30 |  |
| Inventory Turns |  |  | 24 |  |  |  | 22 |  |  |  | 10 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized non-GAAP cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'17 |  |  | Q4 FY'16 |  |  | Q1 FY'16 |  |
| Net Cash Provided by Operating Activities |  | $ | 228 |  |  | $ | 345 |  |  | $ | 129 |  |
| Purchases of Property and Equipment |  | $ | 36 |  |  | $ | 35 |  |  | $ | 38 |  |
| Free Cash Flow |  | $ | 192 |  |  | $ | 310 |  |  | $ | 91 |  |
| Free Cash Flow as a % of Net Revenues |  |  | 14.8 | % |  |  | 22.5 | % |  |  | 6.8 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001564590-16-024497:8k_2_02:78]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY17 |  |  | Q4'FY16 |  |  | Q1'FY16 |  |
| NET INCOME (LOSS) |  | $ | 64 |  |  | $ | (8 | ) |  | $ | (30 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 25 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 52 |  |  |  | 61 |  |  |  | 77 |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | 11 |  |
| Restructuring and other charges |  |  | — |  |  |  | 80 |  |  |  | 27 |  |
| Acquisition-related expense |  |  | — |  |  |  | 6 |  |  |  | — |  |
| Gain on sale of properties |  |  | — |  |  |  | (51 | ) |  |  | — |  |
| Income tax effect of non-GAAP adjustments |  |  | 2 |  |  |  | (20 | ) |  |  | (23 | ) |
| Income tax expenses from integration of intellectual properties from acquisition |  |  | — |  |  |  | 64 |  |  |  | — |  |
| Settlement of income tax audit |  |  | — |  |  |  | — |  |  |  | 13 |  |
| NON-GAAP NET INCOME |  | $ | 129 |  |  | $ | 157 |  |  | $ | 89 |  |
| COST OF REVENUES |  | $ | 497 |  |  | $ | 562 |  |  | $ | 519 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (20 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (5 | ) |  |  | (8 | ) |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | (11 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 486 |  |  | $ | 537 |  |  | $ | 486 |  |
| COST OF PRODUCT REVENUES |  | $ | 359 |  |  | $ | 424 |  |  | $ | 345 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (20 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (2 | ) |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | (5 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 352 |  |  | $ | 403 |  |  | $ | 324 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 130 |  |  | $ | 129 |  |  | $ | 164 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (6 | ) |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | (6 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 126 |  |  | $ | 125 |  |  | $ | 152 |  |
| GROSS PROFIT |  | $ | 797 |  |  | $ | 818 |  |  | $ | 816 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 6 |  |  |  | 20 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 5 |  |  |  | 5 |  |  |  | 8 |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | 11 |  |
| NON-GAAP GROSS PROFIT |  | $ | 808 |  |  | $ | 843 |  |  | $ | 849 |  |

[0001564590-16-024497:8k_2_02:79]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY17 |  |  | Q4'FY16 |  |  | Q1'FY16 |  |
| SALES AND MARKETING EXPENSES |  | $ | 429 |  |  | $ | 434 |  |  | $ | 492 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | — |  |
| Stock-based compensation |  |  | (23 | ) |  |  | (26 | ) |  |  | (31 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 401 |  |  | $ | 403 |  |  | $ | 461 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 207 |  |  | $ | 201 |  |  | $ | 244 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (15 | ) |  |  | (20 | ) |  |  | (26 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 192 |  |  | $ | 181 |  |  | $ | 218 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 68 |  |  | $ | 84 |  |  | $ | 79 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (9 | ) |  |  | (10 | ) |  |  | (12 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 59 |  |  | $ | 74 |  |  | $ | 67 |  |
| RESTRUCTURING AND OTHER CHARGES |  | $ | — |  |  | $ | 80 |  |  | $ | 27 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  |  | — |  |  |  | (80 | ) |  |  | (27 | ) |
| NON-GAAP RESTRUCTURING AND OTHER CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | 6 |  |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | — |  |  |  | (6 | ) |  |  | — |  |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| GAIN ON SALE OF PROPERTIES |  | $ | — |  |  | $ | (51 | ) |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale of properties |  |  | — |  |  |  | 51 |  |  |  | — |  |
| NON-GAAP GAIN ON SALE OF PROPERTIES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 704 |  |  | $ | 754 |  |  | $ | 842 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | — |  |
| Stock-based compensation |  |  | (47 | ) |  |  | (56 | ) |  |  | (69 | ) |
| Restructuring and other charges |  |  | — |  |  |  | (80 | ) |  |  | (27 | ) |
| Acquisition-related expense |  |  | — |  |  |  | (6 | ) |  |  | — |  |
| Gain on sale of properties |  |  | — |  |  |  | 51 |  |  |  | — |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 652 |  |  | $ | 658 |  |  | $ | 746 |  |

[0001564590-16-024497:8k_2_02:80]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY17 |  |  | Q4'FY16 |  |  | Q1'FY16 |  |
| INCOME (LOSS) FROM OPERATIONS |  | $ | 93 |  |  | $ | 64 |  |  | $ | (26 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 25 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 52 |  |  |  | 61 |  |  |  | 77 |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | 11 |  |
| Restructuring and other charges |  |  | — |  |  |  | 80 |  |  |  | 27 |  |
| Acquisition-related expense |  |  | — |  |  |  | 6 |  |  |  | — |  |
| Gain on sale of properties |  |  | — |  |  |  | (51 | ) |  |  | — |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 156 |  |  | $ | 185 |  |  | $ | 103 |  |
| INCOME (LOSS) BEFORE INCOME TAXES |  | $ | 92 |  |  | $ | 60 |  |  | $ | (22 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 25 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 52 |  |  |  | 61 |  |  |  | 77 |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | 11 |  |
| Restructuring and other charges |  |  | — |  |  |  | 80 |  |  |  | 27 |  |
| Acquisition-related expense |  |  | — |  |  |  | 6 |  |  |  | — |  |
| Gain on sale of properties |  |  | — |  |  |  | (51 | ) |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 155 |  |  | $ | 181 |  |  | $ | 107 |  |
| PROVISION FOR INCOME TAXES |  | $ | 28 |  |  | $ | 68 |  |  | $ | 8 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | (2 | ) |  |  | 20 |  |  |  | 23 |  |
| Income tax expenses from integration of intellectual properties from acquisition |  |  | — |  |  |  | (64 | ) |  |  | — |  |
| Settlement of income tax audit |  |  | — |  |  |  | — |  |  |  | (13 | ) |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 26 |  |  | $ | 24 |  |  | $ | 18 |  |
| NET INCOME (LOSS) PER SHARE |  | $ | 0.23 |  |  | $ | (0.03 | ) |  | $ | (0.10 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.04 |  |  |  | 0.09 |  |  |  | 0.05 |  |
| Stock-based compensation |  |  | 0.18 |  |  |  | 0.21 |  |  |  | 0.25 |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | 0.04 |  |
| Restructuring and other charges |  |  | — |  |  |  | 0.28 |  |  |  | 0.09 |  |
| Acquisition-related expense |  |  | — |  |  |  | 0.02 |  |  |  | — |  |
| Gain on sale of properties |  |  | — |  |  |  | (0.18 | ) |  |  | — |  |
| Income tax effect of non-GAAP adjustments |  |  | 0.01 |  |  |  | (0.07 | ) |  |  | (0.08 | ) |
| Income tax expenses from integration of intellectual properties from acquisition |  |  | — |  |  |  | 0.23 |  |  |  | — |  |
| Settlement of income tax audit |  |  | — |  |  |  | — |  |  |  | 0.04 |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.46 |  |  | $ | 0.55 |  |  | $ | 0.29 |  |

[0001564590-16-024497:8k_2_02:81]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY17 |  |  | Q4'FY16 |  |  | Q1'FY16 |  |
| Gross margin-GAAP |  |  | 61.6 | % |  |  | 59.3 | % |  |  | 61.1 | % |
| Cost of revenues adjustments |  |  | 0.9 | % |  |  | 1.8 | % |  |  | 2.5 | % |
| Gross margin-Non-GAAP |  |  | 62.4 | % |  |  | 61.1 | % |  |  | 63.6 | % |
| GAAP cost of revenues |  | $ | 497 |  |  | $ | 562 |  |  | $ | 519 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (20 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (5 | ) |  |  | (8 | ) |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | (11 | ) |
| Non-GAAP cost of revenues |  | $ | 486 |  |  | $ | 537 |  |  | $ | 486 |  |
| Net revenues |  | $ | 1,294 |  |  | $ | 1,380 |  |  | $ | 1,335 |  |

[0001564590-16-024497:8k_2_02:82]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY17 |  |  | Q4'FY16 |  |  | Q1'FY16 |  |
| Product gross margin-GAAP |  |  | 45.6 | % |  |  | 44.0 | % |  |  | 48.0 | % |
| Cost of product revenues adjustments |  |  | 1.1 | % |  |  | 2.8 | % |  |  | 3.2 | % |
| Product gross margin-Non-GAAP |  |  | 46.7 | % |  |  | 46.8 | % |  |  | 51.2 | % |
| GAAP cost of product revenues |  | $ | 359 |  |  | $ | 424 |  |  | $ | 345 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (20 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (2 | ) |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | (5 | ) |
| Non-GAAP cost of product revenues |  | $ | 352 |  |  | $ | 403 |  |  | $ | 324 |  |
| Product revenues |  | $ | 660 |  |  | $ | 757 |  |  | $ | 664 |  |

[0001564590-16-024497:8k_2_02:83]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY17 |  |  | Q4'FY16 |  |  | Q1'FY16 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 66.9 | % |  |  | 66.8 | % |  |  | 61.2 | % |
| Cost of hardware maintenance and other services revenues adjustments |  |  | 1.0 | % |  |  | 1.0 | % |  |  | 2.8 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 67.9 | % |  |  | 67.9 | % |  |  | 64.1 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 130 |  |  | $ | 129 |  |  | $ | 164 |  |
| Cost of hardware maintenance and other services revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (6 | ) |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | (6 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 126 |  |  | $ | 125 |  |  | $ | 152 |  |
| Hardware maintenance and other services revenues |  | $ | 393 |  |  | $ | 389 |  |  | $ | 423 |  |

[0001564590-16-024497:8k_2_02:84]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q1'FY17 |  |  | Q4'FY16 |  |  | Q1'FY16 |  |
| GAAP effective tax rate |  |  | 30.4 | % |  |  | 113.3 | % |  |  | (36.4 | %) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | (13.8 | %) |  |  | (64.9 | %) |  |  | 65.5 | % |
| Income tax expenses from integration of intellectual properties from acquisition |  |  | — | % |  |  | (35.4 | %) |  |  | — | % |
| Settlement of income tax audit |  |  | — | % |  |  | — | % |  |  | (12.1 | %) |
| Non-GAAP effective tax rate |  |  | 16.6 | % |  |  | 13.1 | % |  |  | 17.0 | % |

[0001564590-16-024497:8k_2_02:85]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY17 |  |  | Q4'FY16 |  |  | Q1'FY16 |  |
| Net cash provided by operating activities |  | $ | 228 |  |  | $ | 345 |  |  | $ | 129 |  |
| Purchases of property and equipment |  |  | (36 | ) |  |  | (35 | ) |  |  | (38 | ) |
| Free cash flow |  | $ | 192 |  |  | $ | 310 |  |  | $ | 91 |  |

[0001564590-16-024497:8k_2_02:86]
| INVENTORY TURNS AND RECONCILIATION OF NON-GAAP TO GAAP |  |
| COST OF REVENUES USED IN INVENTORY TURNS |  |
| (In millions, except annualized inventory turns) |  |
|  |  | Q1'FY17 |  |  | Q4'FY16 |  |  | Q1'FY16 |  |
| Annualized inventory turns-GAAP |  |  | 25 |  |  |  | 23 |  |  |  | 11 |  |
| Cost of revenues adjustments |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Annualized inventory turns-Non-GAAP |  |  | 24 |  |  |  | 22 |  |  |  | 10 |  |
| GAAP cost of revenues |  | $ | 497 |  |  | $ | 562 |  |  | $ | 519 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (20 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (5 | ) |  |  | (8 | ) |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | (11 | ) |
| Non-GAAP cost of revenues |  | $ | 486 |  |  | $ | 537 |  |  | $ | 486 |  |
| Inventory |  | $ | 81 |  |  | $ | 98 |  |  | $ | 193 |  |

[0001564590-16-024497:8k_2_02:87]
Some items may not add or recalculate due to rounding.

[0001564590-16-024497:8k_2_02:88]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| SECOND QUARTER FISCAL 2017 |  |
|  |  | Second Quarter |  |
|  |  | Fiscal 2017 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $0.51 - $0.56 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Second Quarter Fiscal 2017: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.04 | ) |
| Stock-based compensation expense |  |  | (0.19 | ) |
| Income tax effect of non-GAAP adjustments |  |  | 0.03 |  |
| Total Adjustments |  |  | (0.20 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.31 - $0.36 |  |

[0001564590-16-024497:8k_2_02:89]
Press Contact:

[0001564590-16-024497:8k_2_02:90]
Kristin Bleier

[0001564590-16-024497:8k_2_02:91]
NetApp

[0001564590-16-024497:8k_2_02:92]
1 408 419 3098

[0001564590-16-024497:8k_2_02:93]
kristin.bleier@netapp.com

[0001564590-16-024497:8k_2_02:94]
Investor Contact:

[0001564590-16-024497:8k_2_02:95]
Kris Newton

[0001564590-16-024497:8k_2_02:96]
NetApp

[0001564590-16-024497:8k_2_02:97]
1 408 822 3312

[0001564590-16-024497:8k_2_02:98]
kris.newton@netapp.com
