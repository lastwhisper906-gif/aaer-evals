# NTAP MD&A — 0001564590-16-024907


## mdna

[0001564590-16-024907:mdna:1]
[same as prior period, unchanged from 0001564590-16-014119:mdna:1]

[0001564590-16-024907:mdna:2]
22

[0001564590-16-024907:mdna:3]
[same as prior period, unchanged from 0001564590-16-014119:mdna:3]

[0001564590-16-024907:mdna:4]
Our Company

[0001564590-16-024907:mdna:5]
We are a leading global provider of software, systems and services to manage and store customer data. We enable enterprises, service providers, governmental organizations, and partners to envision, deploy and evolve their information technology environments and to reduce costs and risk while driving growth and success for their organizations through our portfolio of products and services that satisfy a broad range of customer workloads across different data types and deployment models.

[0001564590-16-024907:mdna:6]
In order to provide better visibility into our transition from older products to our newer, higher growth products and greater clarity into the dynamics of our product revenue, rather than grouping our product revenues by hardware platform, we are now grouping them by “Strategic” and “Mature” solutions. Strategic solutions include clustered Data OnTap (cDOT), branded E-Series, SolidFire, AltaVault and optional add-on software products. Mature solutions include 7-mode OnTap, add-on hardware and related operating system (OS) software and original equipment manufacturers (OEM) products.

[0001564590-16-024907:mdna:7]
We continue to report services as software maintenance services and hardware maintenance and other services.

[0001564590-16-024907:mdna:8]
[same as prior period, unchanged from 0001564590-16-014119:mdna:4]

[0001564590-16-024907:mdna:9]
[same as prior period, unchanged from 0001564590-16-014119:mdna:5]

[0001564590-16-024907:mdna:10]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Net revenues |  | $ | 1,294 |  |  | $ | 1,335 |  |
| Gross profit |  | $ | 797 |  |  | $ | 816 |  |
| Gross profit margin percentage |  |  | 62 | % |  |  | 61 | % |
| Income (loss) from operations |  | $ | 93 |  |  | $ | (26 | ) |
| Income (loss) from operations as a percentage of net revenues |  |  | 7 | % |  |  | (2 | )% |
| Net income (loss) |  | $ | 64 |  |  | $ | (30 | ) |
| Diluted net income (loss) per share |  | $ | 0.23 |  |  | $ | (0.10 | ) |
| Operating cash flows |  | $ | 228 |  |  | $ | 129 |  |

[0001564590-16-024907:mdna:11]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,300 |  |  | $ | 3,385 |  |
| Days sales outstanding (DSO) |  |  | 35 |  |  |  | 54 |  |

[0001564590-16-024907:mdna:12]
[same as prior period, unchanged from 0001564590-16-014119:mdna:15]

[0001564590-16-024907:mdna:13]
[same as prior period, unchanged from 0001564590-16-014119:mdna:16]

[0001564590-16-024907:mdna:14]
The summary of our significant accounting policies is included under Item 7 – Management’s Discussion and Analysis of Financial Condition and Results of Operations of our 2016 Form 10-K. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. There have been no material changes to the critical accounting policies and estimates as filed in such report.

[0001564590-16-024907:mdna:15]
[same as prior period, unchanged from 0001564590-16-014119:mdna:18]

[0001564590-16-024907:mdna:16]
[same as prior period, unchanged from 0001564590-16-014119:mdna:19]

[0001564590-16-024907:mdna:17]
[same as prior period, unchanged from 0001564590-16-014119:mdna:20]

[0001564590-16-024907:mdna:18]
Our fiscal year is reported as a 52- or 53-week year that ends on the last Friday in April. Fiscal year 2017, ending April 28, 2017, is a 52-week year, with 13 weeks in each of its quarters. Fiscal year 2016, which ended on April 29, 2016, was a 53-week year, with its first quarter spanning 14 weeks and each subsequent quarter spanning 13 weeks. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0001564590-16-024907:mdna:19]
[same as prior period, unchanged from 0001564590-16-014119:mdna:22]

[0001564590-16-024907:mdna:20]
|  |  | Three Months Ended |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product |  |  | 51 |  | % |  | 50 |  | % |
| Software maintenance |  |  | 19 |  |  |  | 19 |  |  |
| Hardware maintenance and other services |  |  | 30 |  |  |  | 32 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 28 |  |  |  | 26 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 10 |  |  |  | 12 |  |  |
| Gross profit |  |  | 62 |  |  |  | 61 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 33 |  |  |  | 37 |  |  |
| Research and development |  |  | 16 |  |  |  | 18 |  |  |
| General and administrative |  |  | 5 |  |  |  | 6 |  |  |
| Restructuring and other charges |  |  | — |  |  |  | 2 |  |  |
| Total operating expenses |  |  | 54 |  |  |  | 63 |  |  |
| Income (loss) from operations |  |  | 7 |  |  |  | (2 | ) |  |
| Other income (expense), net |  |  | — |  |  |  | — |  |  |
| Income (loss) before income taxes |  |  | 7 |  |  |  | (2 | ) |  |
| Provision for income taxes |  |  | 2 |  |  |  | 1 |  |  |
| Net income (loss) |  |  | 5 |  | % |  | (2 | ) | % |

[0001564590-16-024907:mdna:21]
[same as prior period, unchanged from 0001564590-16-014119:mdna:24]

[0001564590-16-024907:mdna:22]
[same as prior period, unchanged from 0001564590-16-014119:mdna:25]

[0001564590-16-024907:mdna:23]
[same as prior period, unchanged from 0001564590-16-014119:mdna:26]

[0001564590-16-024907:mdna:24]
Net revenues for the first quarter of fiscal 2017 were $1,294 million reflecting a $41 million, or 3%, decrease compared to the corresponding period of the prior year. The primary reason for this decrease was the additional week of software and hardware maintenance services revenues in the first quarter of fiscal 2016.

[0001564590-16-024907:mdna:25]
Gross profit as a percentage of net revenues increased one percentage point for the first quarter of fiscal 2017 compared to the first quarter of fiscal 2016, primarily due to higher gross margins on software and hardware maintenance and other services revenues, partially offset by lower gross margins on product revenues.

[0001564590-16-024907:mdna:26]
Sales and marketing, research and development, and general and administrative expenses for the first quarter of fiscal 2017 totaled $704 million, or 54% as a percentage of net revenues, compared to $815 million, or 61% as a percentage of net revenues, for the corresponding period of the prior year. The decrease in expenses in dollars was primarily due to a decrease in average headcount as a result of our cost reduction programs and the impact of one more week in the first quarter of fiscal 2016 compared to fiscal 2017, partially offset by additional operating expenses related to the February 2016 acquisition of SolidFire, Inc.

[0001564590-16-024907:mdna:27]
[same as prior period, unchanged from 0001564590-16-014119:mdna:31]

[0001564590-16-024907:mdna:28]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  | % Change |  |
| Net revenues |  | $ | 1,294 |  |  | $ | 1,335 |  |  |  | (3 | )% |

[0001564590-16-024907:mdna:29]
Product revenues were flat in the first quarter of fiscal 2017 compared to the same period in the prior year. However, revenues from software and hardware maintenance and other services of $634 million in aggregate for the first quarter of fiscal 2017 decreased $37 million, reflecting approximately $40 million of additional software and hardware maintenance revenues in the first quarter of fiscal 2016 from the fourteenth week of the quarter. Product revenues represented 51% of net revenues for the first quarter of fiscal 2017 compared to 50% for the corresponding period of the prior year.

[0001564590-16-024907:mdna:30]
[same as prior period, unchanged from 0001564590-16-014119:mdna:35]

[0001564590-16-024907:mdna:31]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Arrow Electronics, Inc. |  |  | 20 | % |  |  | 22 | % |
| Avnet, Inc. |  |  | 19 | % |  |  | 18 | % |

[0001564590-16-024907:mdna:32]
[same as prior period, unchanged from 0001564590-16-014119:mdna:37]

[0001564590-16-024907:mdna:33]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  | % Change |  |
| Product revenues |  | $ | 660 |  |  | $ | 664 |  |  |  | (1 | )% |

[0001564590-16-024907:mdna:34]
Product revenues are derived through the sale of our strategic and mature solutions, and consist of sales of configured systems, which are bundled hardware and software products, as well as add-on storage and related OS, original equipment manufacturer (OEM) products and add-on hardware and software.

[0001564590-16-024907:mdna:35]
Product revenues from strategic solutions represented 61% of product revenues in the first quarter of fiscal 2017 compared to 49% in the first quarter of the prior year, while product revenues from mature solutions represented 39% and 51% of product revenues, respectively.

[0001564590-16-024907:mdna:36]
Total product revenues from strategic solutions totaled $400 million in the first quarter of fiscal 2017, reflecting a 24% increase from $323 million in the first quarter of fiscal 2016. This increase was primarily due to a 35% increase in unit volume of cDOT systems, partially offset by a decrease in Average Selling Price (ASP) reflecting a mix shift from high end to mid-range platforms, as well as higher discounting. Total product revenue from mature solutions totaled $260 million in the first quarter of fiscal 2017, reflecting a 24% decrease from $341 million in the first quarter of fiscal 2016. This decrease was primarily due to a 46% decrease in unit volume of 7-mode systems, while ASPs were relatively flat. In addition, add-on storage and related OS revenues declined 14% and OEM revenue declined 20%. These fluctuations reflect the on-going trend of movement of customer demand from our older products to our newer products.

[0001564590-16-024907:mdna:37]
[same as prior period, unchanged from 0001564590-16-014119:mdna:46]

[0001564590-16-024907:mdna:38]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 241 |  |  | $ | 248 |  |  |  | (3 | )% |

[0001564590-16-024907:mdna:39]
[same as prior period, unchanged from 0001564590-16-014119:mdna:48]

[0001564590-16-024907:mdna:40]
The fluctuations in software maintenance revenues reflect fluctuations in the aggregate contract value of the installed base under software maintenance contracts, which is recognized as revenue ratably over the terms of the underlying contracts. The decrease in software maintenance contract revenues in the first quarter of fiscal 2017 reflects one more week of maintenance revenue amortization in the first quarter of fiscal 2016 compared to fiscal 2017.

[0001564590-16-024907:mdna:41]
[same as prior period, unchanged from 0001564590-16-014119:mdna:50]

[0001564590-16-024907:mdna:42]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 393 |  |  | $ | 423 |  |  |  | (7 | )% |

[0001564590-16-024907:mdna:43]
[same as prior period, unchanged from 0001564590-16-014119:mdna:52]

[0001564590-16-024907:mdna:44]
Hardware maintenance contract revenues were $323 million for the first quarter of fiscal 2017 compared to $346 million for the first quarter of fiscal 2016. The decrease in hardware maintenance contract revenues reflects having one more week of maintenance revenue amortization in the first quarter of fiscal 2016 compared to the first quarter of fiscal 2017. Professional services and educational and training services revenues were $70 million for the first quarter of fiscal 2017 compared to $77 million in the first quarter of fiscal 2016.

[0001564590-16-024907:mdna:45]
[same as prior period, unchanged from 0001564590-16-014119:mdna:55]

[0001564590-16-024907:mdna:46]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| United States, Canada and Latin America (Americas) |  |  | 57 | % |  |  | 56 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 30 | % |  |  | 31 | % |
| Asia Pacific (APAC) |  |  | 13 | % |  |  | 13 | % |

[0001564590-16-024907:mdna:47]
[same as prior period, unchanged from 0001564590-16-014119:mdna:57]

[0001564590-16-024907:mdna:48]
Americas revenues consist of sales to Americas commercial and United States public sector (USPS) markets. Our geographic distribution of revenues as a percentage of net revenues was relatively consistent in the first quarter of fiscal 2017 compared to the first quarter of fiscal 2016.

[0001564590-16-024907:mdna:49]
[same as prior period, unchanged from 0001564590-16-014119:mdna:59]

[0001564590-16-024907:mdna:50]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping our storage products, amortization of purchased intangible assets, inventory write-downs, and warranty costs, (2) cost of software maintenance, which includes the costs of providing software maintenance and third-party royalty costs and (3) cost of hardware maintenance and other services revenues, which includes costs associated with providing support activities for hardware maintenance, global support partnership programs, professional services and educational and training services.

[0001564590-16-024907:mdna:51]
[same as prior period, unchanged from 0001564590-16-014119:mdna:63]

[0001564590-16-024907:mdna:52]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  | % Change |  |
| Cost of product revenues |  | $ | 359 |  |  | $ | 345 |  |  |  | 4 | % |

[0001564590-16-024907:mdna:53]
[same as prior period, unchanged from 0001564590-16-014119:mdna:65]

[0001564590-16-024907:mdna:54]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2017 to Fiscal 2016 |  |  |
|  |  | Percentage Change Points |  |  |
| Materials costs |  |  | 15 |  |  |
| Excess and obsolete inventory |  |  | (4 | ) |  |
| Amortization of purchased intangible assets |  |  | (2 | ) |  |
| Other |  |  | (5 | ) |  |
| Total change |  |  | 4 |  |  |

[0001564590-16-024907:mdna:55]
Cost of product revenues represented 54% of product revenues for the first quarter of fiscal 2017 compared to 52% in the first quarter of fiscal 2016.

[0001564590-16-024907:mdna:56]
Materials costs represented 90% of product costs for the first quarter of fiscal 2017 compared to 79% in the first quarter of fiscal 2016, and increased $52 million from the first quarter of fiscal 2016. Materials costs were impacted by a 53% increase for materials costs related to strategic products, primarily due to higher volumes for configured cDOT systems, partially offset by a 12% decrease in materials costs for mature products reflecting lower volumes in 7-Mode systems. Average unit materials costs for both cDOT and 7-mode systems increased in the first quarter of fiscal 2017 compared to the corresponding period in the prior year, due to a combination of changes in platform and configuration mix, resulting in lower standard margins for both strategic and mature products.

[0001564590-16-024907:mdna:57]
Excess and obsolete inventory write-downs decreased $8 million in the first quarter of fiscal 2017 compared to the first quarter of fiscal 2016, reflecting the benefits of our focus on inventory management improvements. The amortization of acquired intangibles decreased $8 million due to the impact of certain acquired developed technology being fully amortized by the end of fiscal 2016, partially offset by the amortization of developed technology related to the SolidFire acquisition.

[0001564590-16-024907:mdna:58]
[same as prior period, unchanged from 0001564590-16-014119:mdna:43]

[0001564590-16-024907:mdna:59]
[same as prior period, unchanged from 0001564590-16-014119:mdna:70]

[0001564590-16-024907:mdna:60]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 8 |  |  | $ | 10 |  |  |  | (20 | )% |

[0001564590-16-024907:mdna:61]
Cost of software maintenance revenues were relatively flat in the first quarter of fiscal 2017 compared to the first quarter of fiscal 2016. Cost of software maintenance revenues represented 3% and 4% of software maintenance revenues for the first quarters of fiscal 2017 and 2016, respectively.

[0001564590-16-024907:mdna:62]
[same as prior period, unchanged from 0001564590-16-014119:mdna:73]

[0001564590-16-024907:mdna:63]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 130 |  |  | $ | 164 |  |  |  | (21 | )% |

[0001564590-16-024907:mdna:64]
Cost of hardware maintenance and other services revenues decreased $34 million for the first quarter of fiscal 2017 compared to the corresponding period of the prior year, primarily due to the benefits of our cost reduction initiatives. Costs represented 33% of hardware and maintenance and other services revenues in the first quarter of fiscal 2017 compared to 39% in the first quarter of fiscal 2016.

[0001564590-16-024907:mdna:65]
[same as prior period, unchanged from 0001564590-16-014119:mdna:77]

[0001564590-16-024907:mdna:66]
[same as prior period, unchanged from 0001564590-16-014119:mdna:78]

[0001564590-16-024907:mdna:67]
Compensation costs represent the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0001564590-16-024907:mdna:68]
Total compensation costs included in operating expenses decreased $79 million, or 16%, for the first quarter of fiscal 2017 compared to the first quarter of fiscal 2016 primarily due to lower salary, stock-based compensation and incentive compensation expenses reflecting the impact of one more week in the first quarter of fiscal 2016 compared to fiscal 2017, and a 14% decrease in average headcount as a result of our recent cost reduction initiatives, partially offset by the impact of the SolidFire acquisition.

[0001564590-16-024907:mdna:69]
[same as prior period, unchanged from 0001564590-16-014119:mdna:82]

[0001564590-16-024907:mdna:70]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 429 |  |  | $ | 492 |  |  |  | (13 | )% |

[0001564590-16-024907:mdna:71]
[same as prior period, unchanged from 0001564590-16-014119:mdna:84]

[0001564590-16-024907:mdna:72]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2017 to Fiscal 2016 |  |  |
|  |  | Percentage Change Points |  |  |
| Compensation costs |  |  | (8 | ) |  |
| Facilities and IT support costs |  |  | (3 | ) |  |
| Other |  |  | (2 | ) |  |
| Total change |  |  | (13 | ) |  |

[0001564590-16-024907:mdna:73]
The decrease in compensation costs was primarily due to lower salary and stock-based compensation expenses reflecting an 11% decrease in average headcount from the prior year. Facilities and IT support costs decreased primarily due to cost containment efforts. In addition, sales and marketing expenses were lower in the first quarter of fiscal 2017 due to the impact of having one more week in the first quarter of fiscal 2016 compared to fiscal 2017.

[0001564590-16-024907:mdna:74]
[same as prior period, unchanged from 0001564590-16-014119:mdna:61]

[0001564590-16-024907:mdna:75]
[same as prior period, unchanged from 0001564590-16-014119:mdna:87]

[0001564590-16-024907:mdna:76]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  | % Change |  |
| Research and development expenses |  | $ | 207 |  |  | $ | 244 |  |  |  | (15 | )% |

[0001564590-16-024907:mdna:77]
[same as prior period, unchanged from 0001564590-16-014119:mdna:89]

[0001564590-16-024907:mdna:78]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2017 to Fiscal 2016 |  |  |
|  |  | Percentage Change Points |  |  |
| Compensation costs |  |  | (13 | ) |  |
| Other |  |  | (2 | ) |  |
| Total change |  |  | (15 | ) |  |

[0001564590-16-024907:mdna:79]
The decrease in compensation costs for the first quarter of fiscal 2017 compared to the corresponding period of the prior year was primarily due to lower salary and stock-based compensation expenses, reflecting a 19% decrease in average headcount. In addition, research and development expenses were lower in the first quarter of fiscal 2017 due to the impact of having one more week in the first quarter of fiscal 2016 compared to fiscal 2017.

[0001564590-16-024907:mdna:80]
[same as prior period, unchanged from 0001564590-16-014119:mdna:93]

[0001564590-16-024907:mdna:81]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  | % Change |  |
| General and administrative expenses |  | $ | 68 |  |  | $ | 79 |  |  |  | (14 | )% |

[0001564590-16-024907:mdna:82]
[same as prior period, unchanged from 0001564590-16-014119:mdna:95]

[0001564590-16-024907:mdna:83]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2017 to Fiscal 2016 |  |  |
|  |  | Percentage Change Points |  |  |
| Compensation costs |  |  | (12 | ) |  |
| Other |  |  | (2 | ) |  |
| Total change |  |  | (14 | ) |  |

[0001564590-16-024907:mdna:84]
The decrease in compensation costs for the first quarter of fiscal 2017 compared to the first quarter of fiscal 2016 was primarily due to lower salary and stock-based compensation expenses reflecting a 6% decrease in average headcount. In addition, general and administrative expenses were lower in the first quarter of fiscal 2017 due to the impact of having one more week in the first quarter of fiscal 2016 compared to fiscal 2017.

[0001564590-16-024907:mdna:85]
[same as prior period, unchanged from 0001564590-16-014119:mdna:98]

[0001564590-16-024907:mdna:86]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  | % Change |  |
| Restructuring and other charges |  | $ | — |  |  |  | 27 |  |  |  | (100 | )% |

[0001564590-16-024907:mdna:87]
During fiscal 2016, management approved two restructuring actions to streamline our business, eliminate costs and redirect resources to our highest return activities, which included a restructuring plan announced in May 2015 Plan, under which we reduced our global workforce by approximately 3%. Restructuring and other charges related to this plan consisted primarily of employee severance-related costs. See Note 11 – Restructuring and Other Charges of the Notes to Condensed Consolidated Financial Statements for more details regarding our restructuring plans.

[0001564590-16-024907:mdna:88]
[same as prior period, unchanged from 0001564590-16-014119:mdna:76]

[0001564590-16-024907:mdna:89]
[same as prior period, unchanged from 0001564590-16-014119:mdna:107]

[0001564590-16-024907:mdna:90]
[same as prior period, unchanged from 0001564590-16-014119:mdna:108]

[0001564590-16-024907:mdna:91]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  | % Change |  |
| Interest income |  | $ | 11 |  |  | $ | 13 |  |  |  | (15 | )% |
| Interest expense |  |  | (15 | ) |  |  | (11 | ) |  |  | 36 | % |
| Other income, net |  |  | 3 |  |  |  | 2 |  |  |  | 50 | % |
| Total |  | $ | (1 | ) |  | $ | 4 |  |  | NM |  |

[0001564590-16-024907:mdna:92]
NM - Not Meaningful

[0001564590-16-024907:mdna:93]
The decrease in interest income for the first quarter of fiscal 2017 compared to the first quarter of fiscal 2016 was primarily due to a decrease in our investment portfolio as a result of the liquidation of investments to repay our short-term loan.

[0001564590-16-024907:mdna:94]
Interest expense is primarily related to our Senior Notes.

[0001564590-16-024907:mdna:95]
[same as prior period, unchanged from 0001564590-16-014119:mdna:113]

[0001564590-16-024907:mdna:96]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  | % Change |  |
| Provision for income taxes |  | $ | 28 |  |  | $ | 8 |  |  |  | 250 | % |

[0001564590-16-024907:mdna:97]
Our effective tax rate for the first quarter of fiscal 2017 was 30.4% compared to an effective tax rate of (36.4)% for the first quarter of fiscal 2016. Our effective tax rates reflect our corporate legal entity structure and the global nature of our business, with a significant amount of our profits generated and taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The effective tax rates for both periods presented were favorably impacted by the geographic mix of profits. The difference in effective tax rates for the first quarters of fiscal 2017 and 2016 were primarily a result of differences in the respective periods’ income before income taxes, primarily the loss reported in the first quarter of fiscal 2016, as well as the impacts of discrete events described below.

[0001564590-16-024907:mdna:98]
In the first quarter of fiscal 2017, we adopted a new accounting standard that simplifies stock-based compensation income tax accounting and presentation within the financial statements. During the first quarter of fiscal 2017, we recorded a discrete charge of $13 million following the post-adoption rules which require that all excess tax benefits and deficiencies from stock-based compensation be recognized as a component of income tax expense.

[0001564590-16-024907:mdna:99]
In June 2015, the IRS signed a closing agreement on our fiscal 2008 to 2010 transfer pricing arrangements. During the first quarter of fiscal 2016, we recorded discrete charges totaling $13 million attributable to the transfer pricing audit settlements and the related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-16-024907:mdna:100]
As of July 29, 2016, we had $218 million of gross unrecognized tax benefits, of which $149 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $154 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-16-024907:mdna:101]
[same as prior period, unchanged from 0001564590-16-014119:mdna:120]

[0001564590-16-024907:mdna:102]
[same as prior period, unchanged from 0001564590-16-014119:mdna:122]

[0001564590-16-024907:mdna:103]
| (In millions, except percentages) |  | July 29, 2016 |  |  | April 29, 2016 |  |
| Cash and cash equivalents and short-term investments |  | $ | 4,421 |  |  | $ | 5,303 |  |
| Principal amount of debt |  | $ | 1,500 |  |  | $ | 2,350 |  |
| Debt as a percentage of stockholders' equity |  |  | 54 | % |  |  | 82 | % |

[0001564590-16-024907:mdna:104]
[same as prior period, unchanged from 0001564590-16-014119:mdna:124]

[0001564590-16-024907:mdna:105]
|  |  | Three Months Ended |  |
| (In millions) |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Net cash provided by operating activities |  | $ | 228 |  |  | $ | 129 |  |
| Net cash provided by investing activities |  |  | 276 |  |  |  | 742 |  |
| Net cash used in financing activities |  |  | (1,071 | ) |  |  | (464 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (7 | ) |  |  | (5 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (574 | ) |  | $ | 402 |  |

[0001564590-16-024907:mdna:106]
[same as prior period, unchanged from 0001564590-16-014119:mdna:126]

[0001564590-16-024907:mdna:107]
As of July 29, 2016, our cash, cash equivalents and short-term investments were $4.4 billion, a decrease of $0.9 billion from April 29, 2016. The decrease in the first quarter of fiscal 2017 was primarily due to $850 million used to repay our short-term loan, $175 million paid for the repurchase of our common stock and $53 million used for the payment of dividends, partially offset by $228 million of cash provided by operating activities. Accounts receivable DSO was 35 days for the first quarter of fiscal 2017 compared to 54 days for the fourth quarter of fiscal 2016 and 30 days for the first quarter of fiscal 2016 reflecting seasonal patterns of shipment linearity in the first quarter of our fiscal year compared to our fourth quarter, as well as in the first quarter of fiscal 2016, the favorable impact of the extra week of collections. Working capital decreased during the first quarter of fiscal 2017 by $87 million to $2.7 billion as of July 29, 2016 primarily as a result of a decrease in cash, cash equivalents and short-term investments and accounts receivable, partially offset by the repayment of our short-term loan and a decrease in accrued expenses.

[0001564590-16-024907:mdna:108]
[same as prior period, unchanged from 0001564590-16-014119:mdna:128]

[0001564590-16-024907:mdna:109]
In the first quarter of fiscal 2017, we generated cash from operating activities of $228 million, reflecting net income of $64 million, adjusted by non-cash depreciation and amortization of $60 million and stock-based compensation of $52 million, compared to $129 million of cash generated from operating activities during the first quarter of 2016.

[0001564590-16-024907:mdna:110]
Changes in assets and liabilities in the first quarter of fiscal 2017 included the following:

[0001564590-16-024907:mdna:111]
|  | · | Accounts receivable decreased $311 million, primarily due to lower seasonal invoicing levels in the first quarter of fiscal 2017 compared to the fourth quarter of fiscal 2016. |

[0001564590-16-024907:mdna:112]
|  | · | Accrued compensation decreased $132 million, primarily due to employee compensation payouts related to fiscal year 2016 commissions and incentive compensation plans, as well as payments of restructuring obligations. |

[0001564590-16-024907:mdna:113]
We expect that cash provided by operating activities may materially fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, vendor payment initiatives, tax benefits or charges from stock-based compensation, and the timing and amount of compensation and other payments.

[0001564590-16-024907:mdna:114]
[same as prior period, unchanged from 0001564590-16-014119:mdna:134]

[0001564590-16-024907:mdna:115]
During the first quarter of fiscal 2017, we generated $313 million from maturities and sales of investments, net of purchases, and paid $36 million for capital expenditures compared to $778 million and $38 million, respectively, during the first quarter of fiscal 2016.

[0001564590-16-024907:mdna:116]
[same as prior period, unchanged from 0001564590-16-014119:mdna:136]

[0001564590-16-024907:mdna:117]
During the first quarter of fiscal 2017, we used $850 million to repay our short-term loan, $175 million for the repurchase of 7 million shares of our common stock and $53 million for the payment of dividends, compared to $430 million used for the repurchase of common stock and $54 million for the payment of dividends during the first quarter of fiscal 2016.

[0001564590-16-024907:mdna:118]
[same as prior period, unchanged from 0001564590-16-014119:mdna:105]

[0001564590-16-024907:mdna:119]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including potential future issuances of debt, equity or other securities, will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all.

[0001564590-16-024907:mdna:120]
[same as prior period, unchanged from 0001564590-16-014119:mdna:140]

[0001564590-16-024907:mdna:121]
Our principal sources of liquidity as of July 29, 2016 consisted of cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001564590-16-024907:mdna:122]
[same as prior period, unchanged from 0001564590-16-014119:mdna:142]

[0001564590-16-024907:mdna:123]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
| Cash and cash equivalents |  | $ | 2,294 |  |  | $ | 2,868 |  |
| Short-term investments |  |  | 2,127 |  |  |  | 2,435 |  |
| Total |  | $ | 4,421 |  |  | $ | 5,303 |  |

[0001564590-16-024907:mdna:124]
As of July 29, 2016 and April 29, 2016, $3.8 billion and $4.8 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.6 billion and $0.5 billion, respectively, were available in the U.S. Most of the amounts held outside the U.S. can be repatriated to the U.S. but, under current law, would be subject to U.S. federal, state income and foreign withholding taxes. If we were to repatriate foreign earnings to fund cash requirements in the U.S., we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state tax credit carryforwards. However, our intent is to keep these funds permanently reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, and invest in critical or complementary technologies, and service interest and principal payments on our debt.

[0001564590-16-024907:mdna:125]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of July 29, 2016.

[0001564590-16-024907:mdna:126]
[same as prior period, unchanged from 0001564590-16-014119:mdna:146]

[0001564590-16-024907:mdna:127]
[same as prior period, unchanged from 0001564590-16-014119:mdna:147]

[0001564590-16-024907:mdna:128]
The following table summarizes the principal amount of our Senior Notes as of July 29, 2016 (in millions):

[0001564590-16-024907:mdna:129]
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |
| Total |  | $ | 1,500 |  |

[0001564590-16-024907:mdna:130]
[same as prior period, unchanged from 0001564590-16-014119:mdna:121]

[0001564590-16-024907:mdna:131]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 8 – Financing Arrangements of the Notes to Condensed Consolidated Financial Statements.

[0001564590-16-024907:mdna:132]
[same as prior period, unchanged from 0001564590-16-014119:mdna:154]

[0001564590-16-024907:mdna:133]
Credit Facility

[0001564590-16-024907:mdna:134]
Our credit facility, under which we may borrow up to $300 million, provides another potential source of liquidity. The credit facility is an unsecured five-year revolving credit facility that terminates on December 21, 2017 if no extensions have been requested at that time, and contains financial covenants requiring us to maintain a maximum leverage ratio and a minimum interest coverage ratio. We may also, subject to certain requirements, request an increase in the facility up to an additional $50 million and request two additional one-year extensions, subject to certain conditions. As of July 29, 2016, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-16-024907:mdna:135]
[same as prior period, unchanged from 0001564590-16-014119:mdna:160]

[0001564590-16-024907:mdna:136]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2017 to be between $100 million and $150 million.

[0001564590-16-024907:mdna:137]
[same as prior period, unchanged from 0001564590-16-014119:mdna:162]

[0001564590-16-024907:mdna:138]
On August 17, 2016, we declared a cash dividend of $0.19 per share of common stock, payable on October 26, 2016 to holders of record as of the close of business on October 7, 2016.

[0001564590-16-024907:mdna:139]
As of July 29, 2016, our Board of Directors had authorized the repurchase of up to $9.6 billion of our common stock under our stock repurchase program. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through July 29, 2016, we repurchased a total of 255 million shares of our common stock at an average price of $32.60 per share, for an aggregate purchase price of $8.3 billion. As of July 29, 2016, the remaining authorized amount for stock repurchases under this program was $1.3 billion, with no termination date, which we plan to complete by May 2018.

[0001564590-16-024907:mdna:140]
[same as prior period, unchanged from 0001564590-16-014119:mdna:165]

[0001564590-16-024907:mdna:141]
[same as prior period, unchanged from 0001564590-16-014119:mdna:166]

[0001564590-16-024907:mdna:142]
[same as prior period, unchanged from 0001564590-16-014119:mdna:167]

[0001564590-16-024907:mdna:143]
As of July 29, 2016, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $258 million.

[0001564590-16-024907:mdna:144]
[same as prior period, unchanged from 0001564590-16-014119:mdna:169]

[0001564590-16-024907:mdna:145]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of July 29, 2016, we had $249 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-16-024907:mdna:146]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of July 29, 2016, we had $41 million in construction-related obligations and $246 million in other purchase obligations.

[0001564590-16-024907:mdna:147]
[same as prior period, unchanged from 0001564590-16-014119:mdna:138]

[0001564590-16-024907:mdna:148]
[same as prior period, unchanged from 0001564590-16-014119:mdna:172]

[0001564590-16-024907:mdna:149]
As of July 29, 2016, our liability for uncertain tax positions was $138 million, including interest, penalties and offsetting indirect benefits. Due to the uncertainty of the timing of future cash payments, we cannot make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-16-024907:mdna:150]
Sale-leaseback Transaction

[0001564590-16-024907:mdna:151]
In fiscal 2016, we entered into sale-leaseback arrangements of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, the assets will remain on our condensed consolidated balance sheets and proceeds received by us from these transactions are reported as financing obligations. As of July 29, 2016, the balance of these financing obligations was $149 million. At the end of each respective leaseback period, or when our continuing involvement under the leaseback agreements ends, each transaction will be reported as a non-cash sale of land and buildings and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain on sale of properties.

[0001564590-16-024907:mdna:152]
[same as prior period, unchanged from 0001564590-16-014119:mdna:176]

[0001564590-16-024907:mdna:153]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $76 million and $42 million of receivables during the first quarter of fiscal 2017 and fiscal 2016, respectively.

[0001564590-16-024907:mdna:154]
[same as prior period, unchanged from 0001564590-16-014119:mdna:178]

[0001564590-16-024907:mdna:155]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of July 29, 2016 and April 29, 2016, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-16-024907:mdna:156]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of July 29, 2016, we have not been required to make any significant payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-16-024907:mdna:157]
[same as prior period, unchanged from 0001564590-16-014119:mdna:181]

[0001564590-16-024907:mdna:158]
[same as prior period, unchanged from 0001564590-16-014119:mdna:182]

[0001564590-16-024907:mdna:159]
Legal Contingencies

[0001564590-16-024907:mdna:160]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0001564590-16-024907:mdna:161]
[same as prior period, unchanged from 0001564590-16-014119:mdna:150]
