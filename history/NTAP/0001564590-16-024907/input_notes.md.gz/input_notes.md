# NTAP notes — 0001564590-16-024907


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-16-024907:notes:1]
[same as prior period, unchanged from 0001564590-16-014119:notes:1]

[0001564590-16-024907:notes:2]
[same as prior period, unchanged from 0001564590-16-014119:notes:2]

[0001564590-16-024907:notes:3]
[same as prior period, unchanged from 0001564590-16-014119:notes:3]

[0001564590-16-024907:notes:4]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2017, ending on April 28, 2017, is a 52-week year, with 13 weeks in each of its quarters. Fiscal year 2016, which ended on April 29, 2016, was a 53-week year, with 14 weeks in its first quarter and 13 weeks in each subsequent quarter.

[0001564590-16-024907:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income (loss) and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2016 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 29, 2016 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-16-024907:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-16-024907:notes:7]
Accounting Change – In the three months ended July 29, 2016, we early adopted a new accounting standards update that the Financial Accounting Standards Board (FASB) issued in March 2016 that simplifies the accounting for certain aspects of stock-based payments to employees. The new standard requires that certain amendments relevant to us be applied using a modified-retrospective transition method by means of a cumulative-effect adjustment to retained earnings as of the beginning of the period in which the guidance is adopted.

[0001564590-16-024907:notes:8]
In connection with the adoption, we elected to account for forfeitures as they occur and the cumulative-effect impact of that change in accounting policy was a $7 million increase in retained earnings and a corresponding decrease in additional paid-in capital as of April 30, 2016. We also recorded a $3 million cumulative-effect adjustment decrease to retained earnings and a related decrease in deferred tax assets related to the forfeiture rate policy change on outstanding stock-based awards as of April 30, 2016. The standard also eliminates the requirement that excess tax benefits be realized before companies can recognize them. Accordingly, we recorded a $17 million cumulative-effect adjustment increase in retained earnings and an offsetting increase in deferred tax assets for previously unrecognized excess tax benefits as of April 30, 2016.

[0001564590-16-024907:notes:9]
The new standard eliminated the requirement to report excess tax benefits and certain tax deficiencies related to share-based payment transactions as additional paid-in capital. As a result, we recognized $13 million of tax deficiencies in our provision for income taxes, rather than additional paid–in capital, for the three months ended July 29, 2016.

[0001564590-16-024907:notes:10]
We elected to report cash flows related to excess tax benefits on a prospective basis. The presentation requirements for cash flows related to employee taxes paid for withheld shares had no impact to our statements of cash flows since such cash flows have historically been presented as a financing activity.

[0001564590-16-024907:notes:11]
There have been no other significant changes in our significant accounting policies as of and for the three months ended July 29, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2016.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-16-024907:notes:12]
[same as prior period, unchanged from 0001564590-16-014119:notes:9]

[0001564590-16-024907:notes:13]
[same as prior period, unchanged from 0001564590-16-014119:notes:10]

[0001564590-16-024907:notes:14]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 38 |  |  | $ | 13 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 62 |  |  | $ | 40 |  |
| Interest paid |  | $ | 23 |  |  | $ | 20 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-16-024907:notes:15]
4. Purchased Intangible Assets, Net

[0001564590-16-024907:notes:16]
[same as prior period, unchanged from 0001564590-16-014119:notes:19]

[0001564590-16-024907:notes:17]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 129 |  |  | $ | (21 | ) |  | $ | 108 |  |  | $ | 403 |  |  | $ | (289 | ) |  | $ | 114 |  |
| Customer contracts/relationships |  |  | 43 |  |  |  | (8 | ) |  |  | 35 |  |  |  | 46 |  |  |  | (7 | ) |  |  | 39 |  |
| Other purchased intangibles |  |  | 9 |  |  |  | (2 | ) |  |  | 7 |  |  |  | 10 |  |  |  | (2 | ) |  |  | 8 |  |
| Total intangible assets subject to amortization |  |  | 181 |  |  |  | (31 | ) |  |  | 150 |  |  |  | 459 |  |  |  | (298 | ) |  |  | 161 |  |
| In-process research and development |  |  | 19 |  |  |  | — |  |  |  | 19 |  |  |  | 19 |  |  |  | — |  |  |  | 19 |  |
| Total purchased intangible assets |  | $ | 200 |  |  | $ | (31 | ) |  | $ | 169 |  |  | $ | 478 |  |  | $ | (298 | ) |  | $ | 180 |  |

[0001564590-16-024907:notes:18]
[same as prior period, unchanged from 0001564590-16-014119:notes:22]

[0001564590-16-024907:notes:19]
|  |  | Three Months Ended |  |  | Statement of |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  | Operations Classifications |
| Developed technology |  | $ | 6 |  |  | $ | 14 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 4 |  |  |  | — |  |  | Operating expenses |
| Other purchased intangibles |  |  | 1 |  |  |  | — |  |  | Operating expenses |
| Total |  | $ | 11 |  |  | $ | 14 |  |  |  |

[0001564590-16-024907:notes:20]
As of July 29, 2016, future amortization expense related to purchased intangible assets subject to amortization is as follows (in millions):

[0001564590-16-024907:notes:21]
| Fiscal Year |  | Amount |  |
| Remainder of 2017 |  | $ | 34 |  |
| 2018 |  |  | 43 |  |
| 2019 |  |  | 35 |  |
| 2020 |  |  | 23 |  |
| 2021 |  |  | 15 |  |
| Total |  | $ | 150 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-16-024907:notes:22]
5. Balance Sheet Details

[0001564590-16-024907:notes:23]
[same as prior period, unchanged from 0001564590-16-014119:notes:27]

[0001564590-16-024907:notes:24]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
| Cash |  | $ | 2,121 |  |  | $ | 2,714 |  |
| Cash equivalents |  |  | 173 |  |  |  | 154 |  |
| Cash and cash equivalents |  | $ | 2,294 |  |  | $ | 2,868 |  |

[0001564590-16-024907:notes:25]
[same as prior period, unchanged from 0001564590-16-014119:notes:29]

[0001564590-16-024907:notes:26]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
| Purchased components |  | $ | 11 |  |  | $ | 10 |  |
| Finished goods |  |  | 70 |  |  |  | 88 |  |
| Inventories |  | $ | 81 |  |  | $ | 98 |  |

[0001564590-16-024907:notes:27]
[same as prior period, unchanged from 0001564590-16-014119:notes:33]

[0001564590-16-024907:notes:28]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
| Land |  | $ | 215 |  |  | $ | 215 |  |
| Buildings and improvements |  |  | 605 |  |  |  | 605 |  |
| Leasehold improvements |  |  | 106 |  |  |  | 106 |  |
| Computer, production, engineering and other equipment |  |  | 744 |  |  |  | 751 |  |
| Computer software |  |  | 352 |  |  |  | 352 |  |
| Furniture and fixtures |  |  | 88 |  |  |  | 88 |  |
| Construction-in-progress |  |  | 108 |  |  |  | 74 |  |
|  |  |  | 2,218 |  |  |  | 2,191 |  |
| Accumulated depreciation and amortization |  |  | (1,276 | ) |  |  | (1,254 | ) |
| Property and equipment, net |  | $ | 942 |  |  | $ | 937 |  |

[0001564590-16-024907:notes:29]
[same as prior period, unchanged from 0001564590-16-014119:notes:36]

[0001564590-16-024907:notes:30]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
| Deferred tax assets |  | $ | 599 |  |  | $ | 621 |  |
| Other assets |  |  | 178 |  |  |  | 175 |  |
| Other non-current assets |  | $ | 777 |  |  | $ | 796 |  |

[0001564590-16-024907:notes:31]
[same as prior period, unchanged from 0001564590-16-014119:notes:38]

[0001564590-16-024907:notes:32]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
| Accrued compensation and benefits |  | $ | 239 |  |  | $ | 371 |  |
| Product warranty liability |  |  | 40 |  |  |  | 48 |  |
| Other current liabilities |  |  | 282 |  |  |  | 346 |  |
| Accrued expenses |  | $ | 561 |  |  | $ | 765 |  |

[0001564590-16-024907:notes:33]
[same as prior period, unchanged from 0001564590-16-014119:notes:40]

[0001564590-16-024907:notes:34]
[same as prior period, unchanged from 0001564590-16-014119:notes:41]

[0001564590-16-024907:notes:35]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Balance at beginning of period |  | $ | 70 |  |  | $ | 86 |  |
| Expense accrued during the period |  |  | 4 |  |  |  | 9 |  |
| Warranty costs incurred |  |  | (13 | ) |  |  | (14 | ) |
| Balance at end of period |  | $ | 61 |  |  | $ | 81 |  |

[0001564590-16-024907:notes:36]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
| Accrued expenses |  | $ | 40 |  |  | $ | 48 |  |
| Other long-term liabilities |  |  | 21 |  |  |  | 22 |  |
| Total warranty liabilities |  | $ | 61 |  |  | $ | 70 |  |

[0001564590-16-024907:notes:37]
[same as prior period, unchanged from 0001564590-16-014119:notes:44]

[0001564590-16-024907:notes:38]
[same as prior period, unchanged from 0001564590-16-014119:notes:45]

[0001564590-16-024907:notes:39]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
| Deferred product revenue |  | $ | 63 |  |  | $ | 68 |  |
| Deferred services revenue |  |  | 3,017 |  |  |  | 3,100 |  |
| Financed unearned services revenue |  |  | 220 |  |  |  | 217 |  |
| Total |  | $ | 3,300 |  |  | $ | 3,385 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,724 |  |  | $ | 1,794 |  |
| Long-term |  |  | 1,576 |  |  |  | 1,591 |  |
| Total |  | $ | 3,300 |  |  | $ | 3,385 |  |

[0001564590-16-024907:notes:40]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 15 for additional information related to these arrangements.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-16-024907:notes:41]
6. Other income (expense), net

[0001564590-16-024907:notes:42]
[same as prior period, unchanged from 0001564590-16-014119:notes:49]

[0001564590-16-024907:notes:43]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Interest income |  | $ | 11 |  |  | $ | 13 |  |
| Interest expense |  |  | (15 | ) |  |  | (11 | ) |
| Other income, net |  |  | 3 |  |  |  | 2 |  |
| Total other income (expense), net |  | $ | (1 | ) |  | $ | 4 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-16-024907:notes:44]
7. Financial Instruments and Fair Value Measurements

[0001564590-16-024907:notes:45]
[same as prior period, unchanged from 0001564590-16-014119:notes:52]

[0001564590-16-024907:notes:46]
[same as prior period, unchanged from 0001564590-16-014119:notes:53]

[0001564590-16-024907:notes:47]
[same as prior period, unchanged from 0001564590-16-014119:notes:54]

[0001564590-16-024907:notes:48]
[same as prior period, unchanged from 0001564590-16-014119:notes:55]

[0001564590-16-024907:notes:49]
[same as prior period, unchanged from 0001564590-16-014119:notes:56]

[0001564590-16-024907:notes:50]
[same as prior period, unchanged from 0001564590-16-014119:notes:57]

[0001564590-16-024907:notes:51]
[same as prior period, unchanged from 0001564590-16-014119:notes:58]

[0001564590-16-024907:notes:52]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,251 |  |  | $ | 7 |  |  | $ | — |  |  | $ | 1,258 |  |  | $ | 1,370 |  |  | $ | 5 |  |  | $ | (1 | ) |  | $ | 1,374 |  |
| U.S. Treasury and government debt securities |  |  | 634 |  |  |  | 2 |  |  |  | — |  |  |  | 636 |  |  |  | 878 |  |  |  | 2 |  |  |  | — |  |  |  | 880 |  |
| Foreign government debt securities |  |  | 32 |  |  |  | — |  |  |  | — |  |  |  | 32 |  |  |  | 35 |  |  |  | — |  |  |  | — |  |  |  | 35 |  |
| Commercial paper |  |  | 266 |  |  |  | — |  |  |  | — |  |  |  | 266 |  |  |  | 202 |  |  |  | — |  |  |  | — |  |  |  | 202 |  |
| Certificates of deposit |  |  | 108 |  |  |  | — |  |  |  | — |  |  |  | 108 |  |  |  | 98 |  |  |  | — |  |  |  | — |  |  |  | 98 |  |
| Mutual funds |  |  | 32 |  |  |  | — |  |  |  | — |  |  |  | 32 |  |  |  | 30 |  |  |  | — |  |  |  | — |  |  |  | 30 |  |
| Total debt and equity securities |  | $ | 2,323 |  |  | $ | 9 |  |  | $ | - |  |  | $ | 2,332 |  |  | $ | 2,613 |  |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 2,619 |  |

[0001564590-16-024907:notes:53]
As of July 29, 2016, gross unrealized losses related to individual securities were not significant.

[0001564590-16-024907:notes:54]
The following table presents the contractual maturities of our debt investments as of July 29, 2016 (in millions):

[0001564590-16-024907:notes:55]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 955 |  |  | $ | 956 |  |
| Due after one year through five years |  |  | 1,336 |  |  |  | 1,344 |  |
|  |  | $ | 2,291 |  |  | $ | 2,300 |  |

[0001564590-16-024907:notes:56]
[same as prior period, unchanged from 0001564590-16-014119:notes:63]

[0001564590-16-024907:notes:57]
[same as prior period, unchanged from 0001564590-16-014119:notes:64]

[0001564590-16-024907:notes:58]
[same as prior period, unchanged from 0001564590-16-014119:notes:65]

[0001564590-16-024907:notes:59]
|  |  | July 29, 2016 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,121 |  |  | $ | 2,121 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,258 |  |  |  | — |  |  |  | 1,258 |  |
| U.S. Treasury and government debt securities |  |  | 636 |  |  |  | 208 |  |  |  | 428 |  |
| Foreign government debt securities |  |  | 32 |  |  |  | — |  |  |  | 32 |  |
| Commercial paper |  |  | 266 |  |  |  | — |  |  |  | 266 |  |
| Certificates of deposit |  |  | 108 |  |  |  | — |  |  |  | 108 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,421 |  |  | $ | 2,329 |  |  | $ | 2,092 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 26 |  |  | $ | 26 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (2 | ) |  | $ | — |  |  | $ | (2 | ) |

[0001564590-16-024907:notes:60]
[same as prior period, unchanged from 0001564590-16-014119:notes:67]

[0001564590-16-024907:notes:61]
[same as prior period, unchanged from 0001564590-16-014119:notes:68]

[0001564590-16-024907:notes:62]
[same as prior period, unchanged from 0001564590-16-014119:notes:69]

[0001564590-16-024907:notes:63]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of July 29, 2016 and April 29, 2016, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-16-024907:notes:64]
[same as prior period, unchanged from 0001564590-16-014119:notes:71]

[0001564590-16-024907:notes:65]
As of July 29, 2016 and April 29, 2016, the fair value of our long-term debt was approximately $1,517 million and $1,519 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-16-024907:notes:66]
8. Financing Arrangements

[0001564590-16-024907:notes:67]
Long-Term Debt

[0001564590-16-024907:notes:68]
The following table summarizes information relating to our long-term debt (in millions, except interest rates):

[0001564590-16-024907:notes:69]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (9 | ) |  |  |  |  |  |  | (10 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,491 |  |  |  |  |  |  | $ | 1,490 |  |  |  |  |  |

[0001564590-16-024907:notes:70]
Senior Notes

[0001564590-16-024907:notes:71]
Our 3.375% Senior Notes, 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $500 million, $750 million and $250 million, respectively, were issued in June 2014, December 2012 and December 2012, respectively. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any future senior unsecured indebtedness.

[0001564590-16-024907:notes:72]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 29, 2016, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-16-024907:notes:73]
As of July 29, 2016, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-16-024907:notes:74]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| Thereafter |  |  | 750 |  |
| Total |  | $ | 1,500 |  |

[0001564590-16-024907:notes:75]
Credit Facility

[0001564590-16-024907:notes:76]
In December 2012, as amended in February 2016, we entered into a credit agreement with a syndicated group of lenders that is scheduled to expire on December 21, 2017 and provides for an unsecured $300 million revolving credit facility that is comprised of revolving loans, Eurocurrency loans and/or swingline loans. The credit facility includes a $100 million foreign currency sub-facility, a $50 million letter of credit sub-facility and a $10 million swingline sub-facility available on same-day notice. Available borrowings under the credit facility are reduced by the amount of any outstanding borrowings on the sub-facilities. We may also, subject to certain requirements, request an increase in the facility up to an additional $50 million and request two additional one-year extensions, subject to certain conditions. The proceeds from the facility may be used by us for general corporate purposes.

[0001564590-16-024907:notes:77]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of July 29, 2016, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-16-024907:notes:78]
Short-Term Loan

[0001564590-16-024907:notes:79]
In February 2016, in connection with the SolidFire acquisition, we entered into a short-term loan of $870 million with a maturity of November 2, 2016. As of July 29, 2016, we have repaid the loan in full and have terminated the related loan agreement.

[0001564590-16-024907:notes:80]
Sale-leaseback Transactions

[0001564590-16-024907:notes:81]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, the assets will remain on our condensed consolidated balance sheets, and proceeds received by us from these transactions are reported as financing obligations. As of July 29, 2016, the balance of these financing obligations was $149 million. At the end of each respective leaseback period, or when our continuing involvement under the leaseback agreements ends, each transaction will be reported as a non-cash sale of land and buildings and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain on sale of properties.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-16-024907:notes:82]
9. Stockholders’ Equity

[0001564590-16-024907:notes:83]
[same as prior period, unchanged from 0001564590-16-014119:notes:89]

[0001564590-16-024907:notes:84]
As of July 29, 2016, we have outstanding certain equity incentive awards (awards), which include stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and Employee Stock Purchase Plan (ESPP) awards.

[0001564590-16-024907:notes:85]
[same as prior period, unchanged from 0001564590-16-014119:notes:91]

[0001564590-16-024907:notes:86]
[same as prior period, unchanged from 0001564590-16-014119:notes:92]

[0001564590-16-024907:notes:87]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 29, 2016 |  |  | 9 |  |  | $ | 34.01 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (2 | ) |  | $ | 39.39 |  |  |  |  |  |  |  |  |  |
| Outstanding as of July 29, 2016 |  |  | 7 |  |  | $ | 33.75 |  |  |  | 3.42 |  |  | $ | 29 |  |
| Exercisable as of July 29, 2016 |  |  | 5 |  |  | $ | 39.29 |  |  |  | 2.22 |  |  | $ | 5 |  |

[0001564590-16-024907:notes:88]
[same as prior period, unchanged from 0001564590-16-014119:notes:94]

[0001564590-16-024907:notes:89]
[same as prior period, unchanged from 0001564590-16-014119:notes:95]

[0001564590-16-024907:notes:90]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Intrinsic value of exercises |  | $ | 3 |  |  | $ | 3 |  |
| Proceeds received from exercises |  | $ | 1 |  |  | $ | 7 |  |
| Fair value of options vested |  | $ | 5 |  |  | $ | 6 |  |

[0001564590-16-024907:notes:91]
[same as prior period, unchanged from 0001564590-16-014119:notes:97]

[0001564590-16-024907:notes:92]
In the three months ended July 29, 2016, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service based vesting criteria) such that the PBRSU cliff-vests at the end of either an approximate two year or three year performance period, which began on the date specified in the grant agreement and ends the last day of fiscal 2018 or 2019, respectively. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted, and will depend upon our Total Stockholder Return (TSR) as compared to an index TSR (each expressed as a growth rate percentage) calculated as of the applicable period end date. The fair values of the PBRSUs were fixed at grant date using a Monte Carlo simulation model and the related aggregate compensation cost of $15 million is being recognized over the shorter of the remaining applicable performance or service periods.

[0001564590-16-024907:notes:93]
[same as prior period, unchanged from 0001564590-16-014119:notes:100]

[0001564590-16-024907:notes:94]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 29, 2016 |  |  | 13 |  |  | $ | 32.46 |  |
| Granted |  |  | 4 |  |  | $ | 23.66 |  |
| Vested |  |  | (4 | ) |  | $ | 32.74 |  |
| Forfeited |  |  | (1 | ) |  | $ | 33.41 |  |
| Outstanding as of July 29, 2016 |  |  | 12 |  |  | $ | 28.88 |  |

[0001564590-16-024907:notes:95]
We primarily use the net share settlement approach upon vesting, where a portion of the shares are withheld as settlement of employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001564590-16-024907:notes:96]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 33 |  |  | $ | 38 |  |

[0001564590-16-024907:notes:97]
[same as prior period, unchanged from 0001564590-16-014119:notes:104]

[0001564590-16-024907:notes:98]
[same as prior period, unchanged from 0001564590-16-014119:notes:105]

[0001564590-16-024907:notes:99]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Shares issued under the ESPP |  |  | 2 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 42 |  |  | $ | 50 |  |

[0001564590-16-024907:notes:100]
[same as prior period, unchanged from 0001564590-16-014119:notes:107]

[0001564590-16-024907:notes:101]
[same as prior period, unchanged from 0001564590-16-014119:notes:108]

[0001564590-16-024907:notes:102]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 2 |  |
| Cost of hardware maintenance and other services revenues |  |  | 4 |  |  |  | 6 |  |
| Sales and marketing |  |  | 23 |  |  |  | 31 |  |
| Research and development |  |  | 15 |  |  |  | 26 |  |
| General and administrative |  |  | 9 |  |  |  | 12 |  |
| Total stock-based compensation expense |  | $ | 52 |  |  | $ | 77 |  |

[0001564590-16-024907:notes:103]
As of July 29, 2016, total unrecognized compensation expense related to our equity awards was $368 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.3 years.

[0001564590-16-024907:notes:104]
[same as prior period, unchanged from 0001564590-16-014119:notes:113]

[0001564590-16-024907:notes:105]
As of July 29, 2016, our Board of Directors has authorized the repurchase of up to $9.6 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management.

[0001564590-16-024907:notes:106]
The following table summarizes activity related to this program for the three months ended July 29, 2016 (in millions, except per share amounts):

[0001564590-16-024907:notes:107]
| Number of shares repurchased |  |  | 7 |  |
| Average price per share |  | $ | 24.20 |  |
| Aggregate purchase price |  | $ | 175 |  |
| Remaining authorization at end of period |  | $ | 1,324 |  |

[0001564590-16-024907:notes:108]
The aggregate purchase price of our stock repurchases for the three months ended July 29, 2016 consisted of $175 million of open market purchases, of which $93 million and $82 million were allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-16-024907:notes:109]
Since the May 13, 2003 inception of our stock repurchase program through July 29, 2016, we repurchased a total of 255 million shares of our common stock at an average price of $32.60 per share, for an aggregate purchase price of $8.3 billion.

[0001564590-16-024907:notes:110]
[same as prior period, unchanged from 0001564590-16-014119:notes:119]

[0001564590-16-024907:notes:111]
[same as prior period, unchanged from 0001564590-16-014119:notes:120]

[0001564590-16-024907:notes:112]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Dividends per share declared |  | $ | 0.19 |  |  | $ | 0.18 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 50 |  |  | $ | 54 |  |
| Dividend payments allocated to retained earnings |  | $ | 3 |  |  | $ | — |  |

[0001564590-16-024907:notes:113]
On August 17, 2016, we declared a cash dividend of $0.19 per share of common stock, payable on October 26, 2016 to holders of record as of the close of business on October 7, 2016. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-16-024907:notes:114]
[same as prior period, unchanged from 0001564590-16-014119:notes:123]

[0001564590-16-024907:notes:115]
[same as prior period, unchanged from 0001564590-16-014119:notes:124]

[0001564590-16-024907:notes:116]
| Balance as of April 29, 2016 |  | $ | — |  |
| Cumulative-effect of new accounting principle |  |  | 21 |  |
| Net income |  |  | 64 |  |
| Repurchases of common stock |  |  | (82 | ) |
| Dividends |  |  | (3 | ) |
| Balance as of July 29, 2016 |  | $ | — |  |

[0001564590-16-024907:notes:117]
[same as prior period, unchanged from 0001564590-16-014119:notes:126]

[0001564590-16-024907:notes:118]
[same as prior period, unchanged from 0001564590-16-014119:notes:127]

[0001564590-16-024907:notes:119]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 29, 2016 |  | $ | (19 | ) |  | $ | (16 | ) |  | $ | 6 |  |  | $ | (2 | ) |  | $ | (31 | ) |
| OCI before reclassifications, net of tax |  |  | (6 | ) |  |  | — |  |  |  | 3 |  |  |  | 3 |  |  |  | — |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total OCI |  |  | (6 | ) |  |  | — |  |  |  | 3 |  |  |  | 3 |  |  |  | — |  |
| Balance as of July 29, 2016 |  | $ | (25 | ) |  | $ | (16 | ) |  | $ | 9 |  |  | $ | 1 |  |  | $ | (31 | ) |

[0001564590-16-024907:notes:120]
[same as prior period, unchanged from 0001564590-16-014119:notes:129]

[0001564590-16-024907:notes:121]
|  |  | Three Months Ended |  |  |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |
| Recognized losses on defined benefit obligations |  | $ | — |  |  | $ | 1 |  |  | Operating expenses |
| Realized losses on cash flow hedges |  |  | — |  |  |  | 1 |  |  | Net revenues |
| Total reclassifications |  | $ | — |  |  | $ | 2 |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-16-024907:notes:122]
10. Derivatives and Hedging Activities

[0001564590-16-024907:notes:123]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of July 29, 2016 and April 29, 2016. We did not recognize any gains and losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-16-024907:notes:124]
[same as prior period, unchanged from 0001564590-16-014119:notes:133]

[0001564590-16-024907:notes:125]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 95 |  |  | $ | 99 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 157 |  |  | $ | 160 |  |
| Forward contracts purchased |  | $ | 227 |  |  | $ | 396 |  |

[0001564590-16-024907:notes:126]
The effect of derivative instruments designated as cash flow hedges recognized in net revenues on our condensed consolidated statements of operations is presented in the condensed consolidated statements of comprehensive income (loss) and Note 9 – Stockholders’ Equity.

[0001564590-16-024907:notes:127]
[same as prior period, unchanged from 0001564590-16-014119:notes:136]

[0001564590-16-024907:notes:128]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
|  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 4 |  |  | $ | (7 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-16-024907:notes:129]
11. Restructuring and Other Charges

[0001564590-16-024907:notes:130]
During fiscal 2016, management approved two restructuring actions to streamline our business, eliminate costs and redirect resources to our highest return activities. These actions consisted of the May 2015 Plan and the March 2016 Plan, under which we reduced our global workforce by an aggregate of approximately 14%. These plans have been substantially completed as of July 29, 2016. Restructuring and other charges related to these plans consisted primarily of employee severance-related costs.

[0001564590-16-024907:notes:131]
Activities related to the fiscal 2016 restructuring actions are summarized as follows (in millions):

[0001564590-16-024907:notes:132]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Balance at beginning of period |  | $ | 45 |  |  | $ | — |  |
| Net charges |  |  | — |  |  |  | 27 |  |
| Cash payments |  |  | (36 | ) |  |  | (11 | ) |
| Balance at end of period |  | $ | 9 |  |  | $ | 16 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-16-024907:notes:133]
12. Income Taxes

[0001564590-16-024907:notes:134]
[same as prior period, unchanged from 0001564590-16-014119:notes:143]

[0001564590-16-024907:notes:135]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Effective tax rates |  |  | 30.4 | % |  |  | (36.4 | )% |

[0001564590-16-024907:notes:136]
Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations which are headquartered in the Netherlands, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The differences in effective tax rates for the three months ended July 29, 2016 and July 31, 2015 were mainly a result of differences in year-to-date profits before tax, primarily the loss reported in the prior year, and the impacts of discrete events as described below.

[0001564590-16-024907:notes:137]
During the three months ended July 29, 2016, we adopted a new accounting standard that simplifies stock-based compensation income tax accounting and presentation within the financial statements. During the three months ended July 29, 2016, we recorded a discrete charge of $13 million following the post-adoption rules which require that all excess tax benefits and deficiencies from stock-based compensation be recognized as a component of income tax expense. See Note 1 – Description of Business and Significant Accounting Policies for more details regarding the adoption of this accounting standard.

[0001564590-16-024907:notes:138]
In June 2015, the Internal Revenue Service (IRS) signed a closing agreement on our fiscal 2008 to 2010 transfer pricing arrangements. During the three months ended July 31, 2015, we recorded discrete charges totaling $13 million attributable to the transfer pricing audit adjustment and related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-16-024907:notes:139]
[same as prior period, unchanged from 0001564590-16-014119:notes:150]

[0001564590-16-024907:notes:140]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Balance at beginning of period |  | $ | 216 |  |  | $ | 272 |  |
| Additions based on tax positions related to the current year |  |  | 2 |  |  |  | 4 |  |
| Additions for tax positions of prior years |  |  | — |  |  |  | 19 |  |
| Decreases for tax positions of prior years |  |  | — |  |  |  | (5 | ) |
| Settlements |  |  | — |  |  |  | (47 | ) |
| Balance at end of period |  | $ | 218 |  |  | $ | 243 |  |

[0001564590-16-024907:notes:141]
As of July 29, 2016, we had $218 million of gross unrecognized tax benefits, of which $149 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $154 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-16-024907:notes:142]
We are currently undergoing income tax audits in the United States (U.S.) and several foreign tax jurisdictions. Transfer pricing calculations are key issues under audits in various jurisdictions, and are often subject to dispute and appeals. The IRS has concluded the examination of our federal income tax returns for our fiscal years through 2010. The IRS commenced the examination of our federal income tax returns for our fiscal years 2012 and 2013 in August 2016.

[0001564590-16-024907:notes:143]
On September 17, 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 from our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. On December 19, 2011, the Danish Tax Tribunal issued a ruling that our Danish subsidiary was not liable for Danish withholding tax. The Danish tax examination agency appealed to the Danish High Court in March 2012. In February 2016, the Danish High Court referred the case to the European Court of Justice.

[0001564590-16-024907:notes:144]
[same as prior period, unchanged from 0001564590-16-014119:notes:155]


## us-gaap:EarningsPerShareTextBlock

[0001564590-16-024907:notes:145]
13. Net Income (Loss) per Share

[0001564590-16-024907:notes:146]
The following is a calculation of basic and diluted net income (loss) per share (in millions, except per share amounts):

[0001564590-16-024907:notes:147]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 64 |  |  | $ | (30 | ) |
| Denominator: |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 279 |  |  |  | 304 |  |
| Dilutive impact of employee equity award plans |  |  | 3 |  |  |  | — |  |
| Shares used in diluted computation |  |  | 282 |  |  |  | 304 |  |
| Net Income (Loss) per Share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.23 |  |  | $ | (0.10 | ) |
| Diluted |  | $ | 0.23 |  |  | $ | (0.10 | ) |

[0001564590-16-024907:notes:148]
We have excluded 15 million and 31 million weighted-average shares of common stock potentially issuable under employee equity award plans in the three months ended July 29, 2016 and July 31, 2015, respectively, from the diluted net income (loss) per share calculations as their effect would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-16-024907:notes:149]
14. Segment, Geographic, and Significant Customer Information

[0001564590-16-024907:notes:150]
[same as prior period, unchanged from 0001564590-16-014119:notes:162]

[0001564590-16-024907:notes:151]
[same as prior period, unchanged from 0001564590-16-014119:notes:163]

[0001564590-16-024907:notes:152]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| United States, Canada and Latin America (Americas) |  | $ | 736 |  |  | $ | 745 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 387 |  |  |  | 415 |  |
| Asia Pacific (APAC) |  |  | 171 |  |  |  | 175 |  |
| Net revenues |  | $ | 1,294 |  |  | $ | 1,335 |  |

[0001564590-16-024907:notes:153]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $666 million and $665 million during the three months ended July 29, 2016 and July 31, 2015, respectively.

[0001564590-16-024907:notes:154]
[same as prior period, unchanged from 0001564590-16-014119:notes:166]

[0001564590-16-024907:notes:155]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
| U.S. |  | $ | 565 |  |  | $ | 513 |  |
| International |  |  | 3,856 |  |  |  | 4,790 |  |
| Total |  | $ | 4,421 |  |  | $ | 5,303 |  |

[0001564590-16-024907:notes:156]
[same as prior period, unchanged from 0001564590-16-014119:notes:168]

[0001564590-16-024907:notes:157]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
| U.S. |  | $ | 772 |  |  | $ | 797 |  |
| International |  |  | 170 |  |  |  | 140 |  |
| Total |  | $ | 942 |  |  | $ | 937 |  |

[0001564590-16-024907:notes:158]
[same as prior period, unchanged from 0001564590-16-014119:notes:170]

[0001564590-16-024907:notes:159]
|  |  | Three Months Ended |  |
|  |  | July 29, 2016 |  |  | July 31, 2015 |  |
| Arrow Electronics, Inc. |  |  | 20 | % |  |  | 22 | % |
| Avnet, Inc. |  |  | 19 | % |  |  | 18 | % |

[0001564590-16-024907:notes:160]
[same as prior period, unchanged from 0001564590-16-014119:notes:172]

[0001564590-16-024907:notes:161]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
| Arrow Electronics, Inc. |  |  | 12 | % |  |  | 12 | % |
| Avnet, Inc. |  |  | 11 | % |  |  | 15 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-16-024907:notes:162]
15. Commitments and Contingencies

[0001564590-16-024907:notes:163]
Operating Leases

[0001564590-16-024907:notes:164]
We lease various equipment, vehicles and office space in the U.S. and internationally.

[0001564590-16-024907:notes:165]
Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $258 million as of July 29, 2016.

[0001564590-16-024907:notes:166]
Purchase Orders and Other Commitments

[0001564590-16-024907:notes:167]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of July 29, 2016, we had $249 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 29, 2016 and April 29, 2016, such liability amounted to $5 million and $7 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-16-024907:notes:168]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 29, 2016, we had $41 million in construction related obligations and $246 million in other purchase obligations.

[0001564590-16-024907:notes:169]
Financing Guarantees

[0001564590-16-024907:notes:170]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $76 million and $42 million of receivables during the three months ended July 29, 2016 and July 31, 2015, respectively.

[0001564590-16-024907:notes:171]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-16-024907:notes:172]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of July 29, 2016 and April 29, 2016, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-16-024907:notes:173]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 29, 2016, we have not been required to make any significant payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-16-024907:notes:174]
Legal Contingencies

[0001564590-16-024907:notes:175]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict, and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-16-024907:notes:176]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of July 29, 2016 related to such matters as they are not probable and/or reasonably estimable.
