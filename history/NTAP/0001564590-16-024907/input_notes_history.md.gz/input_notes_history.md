# NTAP note change history — 0001564590-16-014119 → 0001564590-16-024907


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-09-02):
[0001564590-16-024907:note_history:1]
Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $258 million as of July 29, 2016.
  (was, 2016-03-07, similarity 0.9836):
[0001564590-16-014119:note_history:1]
Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $216 million as of January 29, 2016.

- changed (2016-09-02):
[0001564590-16-024907:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of July 29, 2016, we had $249 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 29, 2016 and April 29, 2016, such liability amounted to $5 million and $7 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2016-03-07, similarity 0.9929):
[0001564590-16-014119:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of January 29, 2016, we had $265 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 29, 2016 and April 24, 2015, such liability amounted to $9 million and $17 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2016-09-02):
[0001564590-16-024907:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 29, 2016, we had $41 million in construction related obligations and $246 million in other purchase obligations.
  (was, 2016-03-07, similarity 0.9904):
[0001564590-16-014119:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 29, 2016, we had $45 million in construction related obligations and $203 million in other purchase obligations.

- changed (2016-09-02):
[0001564590-16-024907:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $76 million and $42 million of receivables during the three months ended July 29, 2016 and July 31, 2015, respectively.
  (was, 2016-03-07, similarity 0.9896):
[0001564590-16-014119:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $153 million and $145 million of receivables during the nine months ended January 29, 2016 and January 23, 2015, respectively.

- changed (2016-09-02):
[0001564590-16-024907:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of July 29, 2016 and April 29, 2016, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2016-03-07, similarity 0.9886):
[0001564590-16-014119:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of January 29, 2016 and April 24, 2015, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

- changed (2016-09-02):
[0001564590-16-024907:note_history:6]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 29, 2016, we have not been required to make any significant payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.
  (was, 2016-03-07, similarity 0.9895):
[0001564590-16-014119:note_history:6]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 29, 2016, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- changed (2016-09-02):
[0001564590-16-024907:note_history:7]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of July 29, 2016 related to such matters as they are not probable and/or reasonably estimable.
  (was, 2016-03-07, similarity 0.9843):
[0001564590-16-014119:note_history:7]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of January 29, 2016 related to such matters as they are not probable and/or reasonably estimable.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-09-02):
[0001564590-16-024907:note_history:8]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2017, ending on April 28, 2017, is a 52-week year, with 13 weeks in each of its quarters. Fiscal year 2016, which ended on April 29, 2016, was a 53-week year, with 14 weeks in its first quarter and 13 weeks in each subsequent quarter.
  (was, 2016-03-07, similarity 0.8649):
[0001564590-16-014119:note_history:8]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2016, ending on April 29, 2016, is a 53-week year, with 14 weeks in its first quarter and 13 weeks in each subsequent quarter. Fiscal year 2015, which ended on April 24, 2015, was a 52-week year, with 13 weeks in each of its quarters.

- changed (2016-09-02):
[0001564590-16-024907:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income (loss) and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2016 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 29, 2016 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2016-03-07, similarity 0.7661):
[0001564590-16-014119:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income (loss) and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2015 contained in our Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 12, 2015. The results of operations for the three and nine months ended January 29, 2016 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- added (2016-09-02):
[0001564590-16-024907:note_history:10]
Accounting Change – In the three months ended July 29, 2016, we early adopted a new accounting standards update that the Financial Accounting Standards Board (FASB) issued in March 2016 that simplifies the accounting for certain aspects of stock-based payments to employees. The new standard requires that certain amendments relevant to us be applied using a modified-retrospective transition method by means of a cumulative-effect adjustment to retained earnings as of the beginning of the period in which the guidance is adopted.

- added (2016-09-02):
[0001564590-16-024907:note_history:11]
In connection with the adoption, we elected to account for forfeitures as they occur and the cumulative-effect impact of that change in accounting policy was a $7 million increase in retained earnings and a corresponding decrease in additional paid-in capital as of April 30, 2016. We also recorded a $3 million cumulative-effect adjustment decrease to retained earnings and a related decrease in deferred tax assets related to the forfeiture rate policy change on outstanding stock-based awards as of April 30, 2016. The standard also eliminates the requirement that excess tax benefits be realized before companies can recognize them. Accordingly, we recorded a $17 million cumulative-effect adjustment increase in retained earnings and an offsetting increase in deferred tax assets for previously unrecognized excess tax benefits as of April 30, 2016.

- added (2016-09-02):
[0001564590-16-024907:note_history:12]
The new standard eliminated the requirement to report excess tax benefits and certain tax deficiencies related to share-based payment transactions as additional paid-in capital. As a result, we recognized $13 million of tax deficiencies in our provision for income taxes, rather than additional paid–in capital, for the three months ended July 29, 2016.

- added (2016-09-02):
[0001564590-16-024907:note_history:13]
We elected to report cash flows related to excess tax benefits on a prospective basis. The presentation requirements for cash flows related to employee taxes paid for withheld shares had no impact to our statements of cash flows since such cash flows have historically been presented as a financing activity.

- changed (2016-09-02):
[0001564590-16-024907:note_history:14]
There have been no other significant changes in our significant accounting policies as of and for the three months ended July 29, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2016.
  (was, 2016-03-07, similarity 0.6615):
[0001564590-16-014119:note_history:14]
There have been no significant changes in our significant accounting policies as of and for the nine months ended January 29, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 24, 2015.

- removed (2016-09-02):
[0001564590-16-014119:note_history:15]
During the three months ended January 29, 2016, we adopted an accounting standard that simplified the presentation of deferred taxes by requiring deferred tax assets and liabilities to be classified as noncurrent in a classified statement of financial position. We have adopted this accounting standard prospectively. Accordingly, the prior period amounts in our condensed consolidated balance sheets within this Quarterly Report on Form 10-Q were not adjusted to conform to the new accounting standard. The adoption of this accounting standard was not material to our condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-09-02):
[0001564590-16-024907:note_history:16]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (9 | ) |  |  |  |  |  |  | (10 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,491 |  |  |  |  |  |  | $ | 1,490 |  |  |  |  |  |
  (was, 2016-03-07, similarity 0.9155):
[0001564590-16-014119:note_history:16]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (4 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (6 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,490 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |

- changed (2016-09-02):
[0001564590-16-024907:note_history:17]
Our 3.375% Senior Notes, 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $500 million, $750 million and $250 million, respectively, were issued in June 2014, December 2012 and December 2012, respectively. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any future senior unsecured indebtedness.
  (was, 2016-03-07, similarity 0.8042):
[0001564590-16-014119:note_history:17]
In June 2014, we issued $500 million par value of 3.375% Senior Notes due June 15, 2021, and received proceeds of approximately $495 million, net of discount and issuance costs. Our 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $750 million and $250 million, respectively, were issued in December 2012. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any future senior unsecured indebtedness.

- changed (2016-09-02):
[0001564590-16-024907:note_history:18]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 29, 2016, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2016-03-07, similarity 0.9883):
[0001564590-16-014119:note_history:18]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 29, 2016, we were in compliance with all covenants associated with the Senior Notes.

- changed (2016-09-02):
[0001564590-16-024907:note_history:19]
As of July 29, 2016, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2016-03-07, similarity 0.973):
[0001564590-16-014119:note_history:19]
As of January 29, 2016, our aggregate future principal debt maturities are as follows (in millions):

- changed (2016-09-02):
[0001564590-16-024907:note_history:20]
In December 2012, as amended in February 2016, we entered into a credit agreement with a syndicated group of lenders that is scheduled to expire on December 21, 2017 and provides for an unsecured $300 million revolving credit facility that is comprised of revolving loans, Eurocurrency loans and/or swingline loans. The credit facility includes a $100 million foreign currency sub-facility, a $50 million letter of credit sub-facility and a $10 million swingline sub-facility available on same-day notice. Available borrowings under the credit facility are reduced by the amount of any outstanding borrowings on the sub-facilities. We may also, subject to certain requirements, request an increase in the facility up to an additional $50 million and request two additional one-year extensions, subject to certain conditions. The proceeds from the facility may be used by us for general corporate purposes.
  (was, 2016-03-07, similarity 0.9857):
[0001564590-16-014119:note_history:20]
In December 2012, we entered into a credit agreement with a syndicated group of lenders that is scheduled to expire on December 21, 2017 and provides for an unsecured $250 million revolving credit facility that is comprised of revolving loans, Eurocurrency loans and/or swingline loans. The credit facility includes a $100 million foreign currency sub-facility, a $50 million letter of credit sub-facility and a $10 million swingline sub-facility available on same-day notice. Available borrowings under the credit facility are reduced by the amount of any outstanding borrowings on the sub-facilities. We may also, subject to certain requirements, request an increase in the facility up to an additional $100 million and request two additional one-year extensions, subject to certain conditions. The proceeds from the facility may be used by us for general corporate purposes.

- changed (2016-09-02):
[0001564590-16-024907:note_history:21]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of July 29, 2016, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.
  (was, 2016-03-07, similarity 0.9968):
[0001564590-16-014119:note_history:21]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of January 29, 2016, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

- added (2016-09-02):
[0001564590-16-024907:note_history:22]
Short-Term Loan

- added (2016-09-02):
[0001564590-16-024907:note_history:23]
In February 2016, in connection with the SolidFire acquisition, we entered into a short-term loan of $870 million with a maturity of November 2, 2016. As of July 29, 2016, we have repaid the loan in full and have terminated the related loan agreement.

- added (2016-09-02):
[0001564590-16-024907:note_history:24]
Sale-leaseback Transactions

- added (2016-09-02):
[0001564590-16-024907:note_history:25]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, the assets will remain on our condensed consolidated balance sheets, and proceeds received by us from these transactions are reported as financing obligations. As of July 29, 2016, the balance of these financing obligations was $149 million. At the end of each respective leaseback period, or when our continuing involvement under the leaseback agreements ends, each transaction will be reported as a non-cash sale of land and buildings and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain on sale of properties.

- removed (2016-09-02):
[0001564590-16-014119:note_history:26]
Other Long-Term Financing Arrangements

- removed (2016-09-02):
[0001564590-16-014119:note_history:27]
The following presents the amounts due under other long-term financing arrangements (in millions):

- removed (2016-09-02):
[0001564590-16-014119:note_history:28]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 8 |  |  | $ | 16 |  |
| Less: current portion |  |  | (5 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 3 |  |  | $ | 6 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2016-09-02):
[0001564590-16-014119:note_history:29]
The following presents the amounts due under other long-term financing arrangements (in millions):

- removed (2016-09-02):
[0001564590-16-014119:note_history:30]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 8 |  |  | $ | 16 |  |
| Less: current portion |  |  | (5 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 3 |  |  | $ | 6 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-09-02):
[0001564590-16-024907:note_history:31]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (9 | ) |  |  |  |  |  |  | (10 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,491 |  |  |  |  |  |  | $ | 1,490 |  |  |  |  |  |
  (was, 2016-03-07, similarity 0.9155):
[0001564590-16-014119:note_history:31]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (4 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (6 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,490 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-09-02):
[0001564590-16-024907:note_history:32]
As of July 29, 2016, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2016-03-07, similarity 0.973):
[0001564590-16-014119:note_history:32]
As of January 29, 2016, our aggregate future principal debt maturities are as follows (in millions):


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2016-09-02):
[0001564590-16-014119:note_history:33]
17. Subsequent Events

- removed (2016-09-02):
[0001564590-16-014119:note_history:34]
SolidFire Acquisition

- removed (2016-09-02):
[0001564590-16-014119:note_history:35]
On February 2, 2016, we acquired all of the outstanding shares of privately-held SolidFire, Inc. (SolidFire), a maker of all-flash storage systems based in Colorado, for $855 million in cash. This acquisition extends our position in the all-flash array market by adding new flash offerings that will enhance our ability to deliver customers all-flash storage with a webscale architecture that simplifies data center operations and enables rapid deployments of new applications.

- removed (2016-09-02):
[0001564590-16-014119:note_history:36]
We are still in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation for this acquisition. We currently expect between $100 million and $200 million of the purchase price to be allocated to identifiable intangible assets other than goodwill. A preliminary purchase price allocation will be included in our consolidated financial statements for the year ending April 29, 2016.

- removed (2016-09-02):
[0001564590-16-014119:note_history:37]
The following unaudited pro forma condensed combined financial information gives effect to the acquisition of SolidFire as if it were consummated on April 26, 2014. The unaudited pro forma condensed combined financial information is presented for informational purposes only, and is not intended to represent or be indicative of the results of operations of the Company that would have been reported had the acquisition occurred on April 26, 2014 and should not be taken as representative of future consolidated results of operations of the combined company (in millions).

- removed (2016-09-02):
[0001564590-16-014119:note_history:38]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Net income |  | $ | 128 |  |  | $ | 153 |  |  | $ | 159 |  |  | $ | 341 |  |

- removed (2016-09-02):
[0001564590-16-014119:note_history:39]
Adjustments have been reflected in the unaudited pro forma condensed combined information to include the amortization of identifiable intangible assets, purchase accounting adjustments to deferred revenue, interest expense related to the associated financing arrangement and  costs directly attributable to the acquisition. Pro forma net revenues were not materially different than those presented in the condensed consolidated statements of operations.

- removed (2016-09-02):
[0001564590-16-014119:note_history:40]
Short-Term Loan

- removed (2016-09-02):
[0001564590-16-014119:note_history:41]
In connection with the acquisition, on February 2, 2016, we entered into a short-term loan of $870 million that matures on November 2, 2016. We may repay the loan before its maturity without penalty; however, we may not reborrow any borrowings that were repaid under the term loan agreement. As specified in the term loan agreement, interest on the outstanding borrowings accrues at an adjusted LIBOR plus a spread (based on our public debt ratings) or, at our option, a base rate. We may, from time to time, elect to convert the outstanding loan from one rate to another. We expect to repay the loan on or before the maturity date using funds generated from our global operations. The loan is subject to the same covenants as our credit facility.

- removed (2016-09-02):
[0001564590-16-014119:note_history:42]
Credit Facility Amendment

- removed (2016-09-02):
[0001564590-16-014119:note_history:43]
On February 2, 2016, we amended our existing credit facility to increase the unsecured revolving credit facility to $300 million.

- removed (2016-09-02):
[0001564590-16-014119:note_history:44]
Restructuring Event

- removed (2016-09-02):
[0001564590-16-014119:note_history:45]
On February 17, 2016, we committed to a restructuring and reduction in workforce to streamline our business and reduce operating expenses. In connection with these actions, we expect to reduce our worldwide headcount by approximately 12%. The reduction in workforce will be implemented through the end of the first quarter of fiscal 2017. We expect to incur aggregate charges of approximately $60 million to $70 million for employee terminations and other costs associated with the restructuring, consisting primarily of cash expenditures. The majority of these charges will be recognized in the fourth quarter of fiscal 2016.
