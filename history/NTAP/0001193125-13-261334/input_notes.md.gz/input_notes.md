# NTAP notes — 0001193125-13-261334


## us-gaap:ScheduleOfEffectiveIncomeTaxRateReconciliationTableTextBlock

[0001193125-13-261334:notes:1]
The provision
for income taxes differs from the amount computed by applying the
statutory federal income tax rate as follows (in
millions):

[0001193125-13-261334:notes:2]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Tax computed at federal statutory rate |  | $ | 198.3 |  |  | $ | 249.4 |  |  | $ | 277.9 |  |
| State income taxes, net of federal benefit |  |  | (2.0 | ) |  |  | 6.4 |  |  |  | 31.1 |  |
| Foreign earnings in lower tax jurisdictions |  |  | (144.4 | ) |  |  | (162.2 | ) |  |  | (146.9 | ) |
| Stock-based compensation |  |  | 18.4 |  |  |  | 14.4 |  |  |  | (1.3 | ) |
| Research and experimentation credits |  |  | (12.1 | ) |  |  | (10.9 | ) |  |  | (17.8 | ) |
| Resolution of income tax examinations |  |  | 0.1 |  |  |  | 7.3 |  |  |  | (21.1 | ) |
| Other |  |  | 3.0 |  |  |  | 2.6 |  |  |  | (0.9 | ) |
| Provision for income taxes |  | $ | 61.3 |  |  | $ | 107.0 |  |  | $ | 121.0 |  |


## us-gaap:ScheduleOfShareBasedCompensationEmployeeStockPurchasePlanActivityTableTextBlock

[0001193125-13-261334:notes:3]
Additional
information related to the purchase rights issued under the ESPP is
provided below (in millions, except per right
information):

[0001193125-13-261334:notes:4]
|  |  | Year Ended |  |
|  |  | April 26 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Weighted-average fair value per right granted |  | $ | 10.36 |  |  | $ | 12.87 |  |  | $ | 15.86 |  |
| Shares issued under the ESPP |  |  | 3.8 |  |  |  | 2.6 |  |  |  | 6.0 |  |
| Proceeds from issuance of shares under the ESPP |  | $ | 95.0 |  |  | $ | 89.6 |  |  | $ | 69.0 |  |


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-13-261334:notes:5]
5. Statements of
Cash Flows

[0001193125-13-261334:notes:6]
Non-cash
investing and financing activities and supplemental cash flow
information are as follows (in millions):

[0001193125-13-261334:notes:7]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Reclassification of equity component of Convertible Notes |  | $ | 62.6 |  |  | $ | 52.0 |  |  | $ | (114.6 | ) |
| Acquisition of property and equipment outstanding in accounts payable |  | $ | 20.2 |  |  | $ | 31.4 |  |  | $ | 39.3 |  |
| Acquisition of property and equipment through long-term financing |  | $ | 0.8 |  |  | $ | 3.6 |  |  | $ | 12.6 |  |
| Vested options assumed in acquisitions |  | $ | 1.2 |  |  | $ | 0.0 |  |  | $ | 3.3 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 46.7 |  |  | $ | 48.2 |  |  | $ | 27.9 |  |
| Interest paid, net of capitalized interest |  | $ | 22.8 |  |  | $ | 21.4 |  |  | $ | 22.7 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-13-261334:notes:8]
The following
is a calculation of basic and diluted net income per share (in
millions):

[0001193125-13-261334:notes:9]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 505.3 |  |  | $ | 605.4 |  |  | $ | 673.1 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 361.5 |  |  |  | 363.9 |  |  |  | 360.9 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 5.4 |  |  |  | 8.8 |  |  |  | 14.6 |  |
| Dilutive impact of assumed conversion of Convertible Notes |  |  | 1.1 |  |  |  | 9.4 |  |  |  | 12.7 |  |
| Dilutive impact of warrants |  |  | 0.0 |  |  |  | 2.2 |  |  |  | 5.5 |  |
| Shares used in diluted computation |  |  | 368.0 |  |  |  | 384.3 |  |  |  | 393.7 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.40 |  |  | $ | 1.66 |  |  | $ | 1.87 |  |
| Diluted |  | $ | 1.37 |  |  | $ | 1.58 |  |  | $ | 1.71 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-13-261334:notes:10]
11. Stockholders’ Equity

[0001193125-13-261334:notes:11]
Equity
Incentive Programs

[0001193125-13-261334:notes:12]
The 1999
Plan — As amended through August 30, 2011, the
1999 Stock Option Plan (the 1999 Plan) comprises five separate
equity incentive programs: (i) the Discretionary Option Grant
Program under which options may be granted to eligible individuals
at a fixed price per share; (ii) the Stock Appreciation Rights
Program under which eligible persons may be granted stock
appreciation rights that allow individuals to receive the
appreciation in fair market value of the shares; (iii) the
Stock Issuance Program under which eligible individuals may be
issued shares of common stock directly; (iv) the Performance
Share and Performance Unit Program (also known as RSUs) under which
eligible persons may be granted performance shares or performance
units which result in payment to the participant only if
performance goals or other vesting criteria are achieved and
(v) the Automatic Award Program under which nonemployee board
members automatically receive equity grants at designated intervals
over their period of board service.

[0001193125-13-261334:notes:13]
Under the 1999
Plan, the Board of Directors may grant to employees, nonemployee
directors, consultants and independent advisors options to purchase
shares of our common stock during their period of service. The
exercise price for an incentive stock option and a nonstatutory
option cannot be less than 100% of the fair market value of the
common stock on the grant date. Options granted under the 1999 Plan
generally vest over a four-year period. Options granted prior to
April 29, 2006, have a term of no more than 10 years
after the grant date and those granted after April 29, 2006
have a term of no more than seven years, subject to earlier
termination upon the occurrence of certain events. The 1999 Plan
prohibits the repricing of any outstanding stock option or stock
appreciation right after it has been granted or to cancel any
outstanding stock option or stock appreciation right and
immediately replace it with a new stock option or stock
appreciation right with a lower exercise price unless approved by
stockholders. RSUs granted under the 1999 Plan generally vest over
a four-year period with 25% vesting on each anniversary of the
grant date. The 1999 Plan limits the number of shares issued under
the Stock Issuance Program and the Performance Share and
Performance Unit Program to 8.9 million shares plus the sum of
(i) 50% of the number of shares subject to outstanding awards
as of August 17, 2009 that are cancelled and returned to the
1999 Plan and (ii) 50% of the number of shares added to the
1999 Plan after the 2009 Annual Meeting. The 1999 Plan limits the
initial value of performance units a participant may receive of not
more than $2.0 million. The 1999 Plan expires in August
2019.

[0001193125-13-261334:notes:14]
In fiscal 2013,
the 1999 Plan was amended to increase the shares reserved for
issuance under the plan by an additional 7.4 million shares.
As of April 26, 2013, 16.2 million shares were available
for grant under our equity incentive plans.

[0001193125-13-261334:notes:15]
Stock
Options

[0001193125-13-261334:notes:16]
A summary
of the
activity under our stock option plans and agreements is as follows
(in millions, except for the exercise price and contractual
term):

[0001193125-13-261334:notes:17]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 30, 2010 |  |  | 35.2 |  |  | $ | 23.02 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 3.9 |  |  |  | 45.28 |  |  |  |  |  |  |  |  |  |
| Assumed in acquisition |  |  | 0.2 |  |  |  | 16.56 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (13.8 | ) |  |  | 21.85 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (1.0 | ) |  |  | 34.43 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 29, 2011 |  |  | 24.5 |  |  |  | 26.62 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2.2 |  |  |  | 50.65 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (5.2 | ) |  |  | 21.54 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (0.9 | ) |  |  | 37.23 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 27, 2012 |  |  | 20.6 |  |  |  | 29.98 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2.4 |  |  |  | 28.87 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (3.0 | ) |  |  | 18.37 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (0.8 | ) |  |  | 40.11 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 26, 2013 |  |  | 19.2 |  |  |  | 31.27 |  |  |  | 3.36 |  |  | $ | 131.6 |  |
| Options vested and expected to vest as of April 26, 2013 |  |  | 18.8 |  |  |  | 31.14 |  |  |  | 3.31 |  |  |  | 130.3 |  |
| Exercisable as of April 26, 2013 |  |  | 14.7 |  |  |  | 29.15 |  |  |  | 2.77 |  |  |  | 118.8 |  |

[0001193125-13-261334:notes:18]
The
aggregate intrinsic value represents the pre-tax difference
between the exercise price of stock options and the quoted market
price of our stock on that day for all in-the-money
options.

[0001193125-13-261334:notes:19]
Additional
information related to our stock options is summarized below (in
millions, except per share information):

[0001193125-13-261334:notes:20]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Weighted-average fair value per share granted |  | $ | 11.52 |  |  | $ | 16.70 |  |  | $ | 15.83 |  |
| Weighted-average fair value per share of vested options assumed in acquisition |  |  | N/A |  |  |  | N/A |  |  | $ | 21.15 |  |
| Intrinsic value of options exercised |  | $ | 46.1 |  |  | $ | 116.9 |  |  | $ | 325.3 |  |
| Proceeds received from the exercise of stock options |  | $ | 56.5 |  |  | $ | 111.1 |  |  | $ | 301.1 |  |
| Fair value of options vested |  | $ | 55.9 |  |  | $ | 71.8 |  |  | $ | 96.6 |  |

[0001193125-13-261334:notes:21]
N/A — Not
Applicable

[0001193125-13-261334:notes:22]
Restricted Stock Units

[0001193125-13-261334:notes:23]
The following
table summarizes activity related to our RSUs (in millions, except
for fair value):

[0001193125-13-261334:notes:24]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 30, 2010 |  |  | 9.0 |  |  | $ | 23.92 |  |
| Granted |  |  | 4.7 |  |  |  | 49.13 |  |
| Vested |  |  | (2.9 | ) |  |  | 22.52 |  |
| Forfeited |  |  | (0.7 | ) |  |  | 27.57 |  |
| Outstanding as of April 29, 2011 |  |  | 10.1 |  |  |  | 35.79 |  |
| Granted |  |  | 6.5 |  |  |  | 47.17 |  |
| Vested |  |  | (3.7 | ) |  |  | 30.35 |  |
| Forfeited |  |  | (0.9 | ) |  |  | 40.91 |  |
| Outstanding as of April 27, 2012 |  |  | 12.0 |  |  |  | 43.28 |  |
| Granted |  |  | 6.0 |  |  |  | 29.94 |  |
| Vested |  |  | (4.0 | ) |  |  | 39.83 |  |
| Forfeited |  |  | (1.2 | ) |  |  | 40.95 |  |
| Outstanding as of April 26, 2013 |  |  | 12.8 |  |  |  | 38.36 |  |

[0001193125-13-261334:notes:25]
RSUs are
converted into common stock upon vesting. Upon the vesting of RSUs,
we primarily use the net share settlement approach, where a portion
of the shares are withheld as settlement of statutory employee
withholding taxes, which decreases the shares issued to the
employee by a corresponding value. The number and value of the
shares netted for employee taxes are summarized in the table below
(in millions):

[0001193125-13-261334:notes:26]
|  |  | Year Ended |  |
|  |  | April 26 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Shares withheld for taxes |  |  | 1.3 |  |  |  | 1.2 |  |  |  | 1.0 |  |
| Fair value of shares withheld |  | $ | 40.9 |  |  | $ | 52.0 |  |  | $ | 45.9 |  |

[0001193125-13-261334:notes:27]
Employee
Stock Purchase Plan

[0001193125-13-261334:notes:28]
Under the ESPP,
employees who elect to participate are granted options that include
a purchase price adjustment provision under which the employees may
purchase common stock at a 15% discount from the market value of
the common stock at certain specified dates within a two-year
offering period. In fiscal 2013, the ESPP was amended to increase
the shares reserved for issuance by an additional 5.0 million
shares of common stock. As of April 26, 2013, 6.1 million
shares were available for issuance. Additional information related
to the purchase rights issued under the ESPP is provided below (in
millions, except per right information):

[0001193125-13-261334:notes:29]
Stock-Based Compensation Expense

[0001193125-13-261334:notes:30]
Stock-based
compensation expense consists primarily of expenses for stock
options, RSUs and ESPP and is included in the consolidated
statements of operations as follows (in millions):

[0001193125-13-261334:notes:31]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Cost of product revenues |  | $ | 6.1 |  |  | $ | 5.4 |  |  | $ | 3.6 |  |
| Cost of service revenues |  |  | 19.4 |  |  |  | 17.8 |  |  |  | 14.4 |  |
| Sales and marketing |  |  | 132.2 |  |  |  | 126.0 |  |  |  | 81.5 |  |
| Research and development |  |  | 84.1 |  |  |  | 74.1 |  |  |  | 44.5 |  |
| General and administrative |  |  | 34.8 |  |  |  | 34.3 |  |  |  | 31.2 |  |
| Total stock-based compensation expense |  | $ | 276.6 |  |  | $ | 257.6 |  |  | $ | 175.2 |  |

[0001193125-13-261334:notes:32]
As of
April 26, 2013, total unrecognized compensation expense
related to our equity awards was $428.5 million, which is expected
to be recognized on a straight-line basis over a weighted-average
remaining service period of 2.3 years.

[0001193125-13-261334:notes:33]
Total income
tax benefit associated with employee stock transactions and
recognized in stockholders’ equity was as follows (in
millions):

[0001193125-13-261334:notes:34]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Income tax benefit associated with employee stock transactions |  | $ | 53.8 |  |  | $ | 107.5 |  |  | $ | 128.5 |  |

[0001193125-13-261334:notes:35]
Valuation
Assumptions

[0001193125-13-261334:notes:36]
The fair value
of each award is estimated on the grant date using the
Black-Scholes option pricing model, assuming no expected dividends
and the following weighted-average assumptions:

[0001193125-13-261334:notes:37]
|  |  | Stock Options Year Ended |  |  | ESPP Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Expected term in years |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 0.63 | % |  |  | 1.50 | % |  |  | 2.01 | % |  |  | 0.19 | % |  |  | 0.19 | % |  |  | 0.37 | % |
| Volatility |  |  | 41 | % |  |  | 36 | % |  |  | 37 | % |  |  | 40 | % |  |  | 44 | % |  |  | 39 | % |

[0001193125-13-261334:notes:38]
Stock
Repurchase Program

[0001193125-13-261334:notes:39]
During fiscal
2013, we repurchased and retired 18.1 million shares of our
common stock at an average price of $32.68 per share, for an
aggregate purchase price of $590.0 million, of which $176.2 million
and $413.8 million was allocated to additional paid-in capital and
retained earnings, respectively. During fiscal 2012, we repurchased
and retired 14.6 million shares of our common stock as
described below. During fiscal 2011, we did not repurchase any
shares of our common stock under the stock repurchase program.
Since the May 13, 2003 inception of our stock repurchase
program through April 26, 2013, we repurchased a total of
137.0 million shares of our common stock at an average price
of $30.05 per share, for an aggregate purchase price of $4.1
billion.

[0001193125-13-261334:notes:40]
As of
April 26, 2013, our Board of Directors had authorized the
repurchase of up to $5.5 billion of our common stock under our
stock repurchase program, including an increase of $1.5 billion
approved by our Board of Directors in fiscal 2013. As of
April 26, 2013, the remaining authorized amount for stock
repurchases under this program was $1.4 billion. Under this
program, we may purchase shares of our outstanding common stock
through open market and privately negotiated transactions at prices
deemed appropriate by our management. The stock repurchase program
may be suspended or discontinued at any time.

[0001193125-13-261334:notes:41]
Accelerated Share Repurchase
Agreements

[0001193125-13-261334:notes:42]
In fiscal 2012,
we entered into accelerated share repurchase agreements (ASRs) with
third parties under which we prepaid an aggregate of $600.0 million
to purchase shares of our common stock. The aggregate number of
shares ultimately purchased was determined based on the volume
weighted-average share price of our common stock over a specified
period of time. The contracts were settled in fiscal 2012. The
total number of shares repurchased and retired under these ASRs was
14.6 million shares at a price of $40.97 per share.

[0001193125-13-261334:notes:43]
Preferred
Stock

[0001193125-13-261334:notes:44]
Our Board of
Directors has the authority to issue up to 5.0 million shares
of preferred stock and to determine the price, rights, preferences,
privileges, and restrictions, including voting rights, of those
shares without any further vote or action by the
stockholders.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001193125-13-261334:notes:45]
Revenue
Recognition — We recognize revenue when:

[0001193125-13-261334:notes:46]
|  | • |  | Persuasive evidence of an arrangement exists. Customarily we have a purchase order and/or contract prior to recognizing revenue on an arrangement from our end users, customers, value-added resellers or distributors. |

[0001193125-13-261334:notes:47]
|  | • |  | Delivery has occurred. Our product is physically delivered to our customers. We typically do not allow for restocking rights with any of our value-added resellers or distributors. Products shipped with acceptance criteria or return rights are not recognized as revenue until all criteria are achieved. We do not recognize revenue if undelivered products or services exist that are essential to the functionality of the delivered product in an arrangement. |

[0001193125-13-261334:notes:48]
|  | • |  | The fee is fixed or determinable. Arrangements with payment terms extending beyond our standard terms, conditions and practices are not considered to be fixed or determinable. Revenue from such arrangements is recognized at the earlier of customer payment or when the fees become due and payable. We typically do not allow for price-protection rights with any of our value-added resellers or distributors. |

[0001193125-13-261334:notes:49]
|  | • |  | Collection is reasonably assured. If there is considerable doubt surrounding the creditworthiness of a customer at the outset of an arrangement, the associated revenue is deferred and recognized upon cash receipt. |

[0001193125-13-261334:notes:50]
The hardware
systems and software components essential to the functionality of
the hardware systems are considered non-software deliverables and
therefore are not subject to industry-specific software revenue
recognition guidance.

[0001193125-13-261334:notes:51]
Our product revenues also
include revenues from the sale of non-essential software products.
Non-essential software sales generally include a perpetual license
to our software. Non-essential software sales are subject to the
industry-specific software revenue recognition
guidance.

[0001193125-13-261334:notes:52]
Our multiple
element arrangements may include our systems, software
entitlements and maintenance (SEM), premium hardware maintenance
and services. SEM entitles our customers to receive unspecified
product upgrades and enhancements on a when-and-if-available basis,
and patch releases. Premium hardware maintenance services include
contracts for technical support and minimum response times.
Services include professional services and customer education and
training services. Revenues from SEM and premium hardware
maintenance services are recognized ratably over the contractual
term, generally from one to five years. We also offer extended
service contracts (which extend our standard parts warranty and may
include premium hardware maintenance) at the end of the original
warranty term; revenues from these contracts are recognized ratably
over the extended contract term. We sell professional services
either on a time and materials basis or under fixed price projects;
we recognize revenue for these services as they are
performed.

[0001193125-13-261334:notes:53]
For multiple
element arrangements, we allocate revenue to the software
deliverables and the non-software deliverables as a group based on
the relative selling prices of all of the deliverables in the
arrangement. For our non-software deliverables, we allocate the
arrangement consideration based on the relative selling price of
the deliverables using best estimate of selling price (BESP). For
our software entitlements and support services, we generally use
vendor-specific objective evidence of selling price (VSOE). When we
are unable to establish VSOE for our software entitlements and
support services, we use BESP in our allocation of arrangement
consideration.

[0001193125-13-261334:notes:54]
VSOE is based
upon the normal pricing and discounting practices for those
services when sold separately. VSOE is generally evidenced by a
substantial majority of historical stand-alone transactions falling
within a reasonably narrow range. In addition, we consider major
service type, customer classifications, and other variables in
determining VSOE.

[0001193125-13-261334:notes:55]
When VSOE
cannot be established, we attempt to establish the selling price of
each element based on third party evidence of selling price (TPE).
Generally, we are not able to determine TPE because our
go-to-market strategy differs from that of our peers and our
offerings contain a significant level of differentiation such that
the comparable pricing of products with similar functionality
cannot be obtained.

[0001193125-13-261334:notes:56]
We use BESP in
our allocation of arrangement consideration when VSOE or TPE are
not available. BESP is generally evidenced by a majority of
historical transactions falling within a reasonable price range. We
also consider multiple factors, including, but not limited to, cost
of products, gross margin objectives, historical pricing practices,
customer classes and distribution channels.

[0001193125-13-261334:notes:57]
We regularly
review VSOE, TPE, and BESP and maintain internal controls over the
establishment and updates of these estimates.

[0001193125-13-261334:notes:58]
For our
software deliverables, we use the residual method to recognize
revenue when an arrangement includes one or more elements to be
delivered at a future date and VSOE of all undelivered elements
exists. Typically, only SEM and/or service remain undelivered after
the product is delivered. Under the residual method, the fair value
of the undelivered elements is deferred and the remaining portion
of the consideration is recognized as product revenues for
delivered elements. If evidence of the fair value of one or more
undelivered elements does not exist, all revenue is generally
deferred until the earlier of when delivery of those elements
occurs or when fair value can be established. In instances where
the only undelivered element without fair value is SEM, the entire
arrangement is recognized ratably over the maintenance
period.

[0001193125-13-261334:notes:59]
We record
reductions to revenue for estimated sales returns at the time of
shipment. Sales returns are estimated based on historical sales
returns, current trends, and our expectations regarding future
experience. We monitor and analyze the accuracy of sales returns
estimates by reviewing actual returns and adjust them for future
expectations. Additionally, distributors and retail partners
participate in various cooperative marketing and other programs,
and we record estimated accruals and allowances for these programs.
We accrue for these programs based on contractual terms and
historical experience.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001193125-13-261334:notes:60]
The following
table presents cash, cash equivalents, restricted cash and
investments held in the United States and internationally in
various foreign subsidiaries (in millions):

[0001193125-13-261334:notes:61]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| United States |  | $ | 3,419.3 |  |  | $ | 2,697.6 |  |
| International |  |  | 3,586.8 |  |  |  | 2,763.8 |  |
| Total |  | $ | 7,006.1 |  |  | $ | 5,461.4 |  |


## us-gaap:InventoryPolicyTextBlock

[0001193125-13-261334:notes:62]
Inventories — Inventories are stated at the
lower of cost or market, which approximates actual cost on a
first-in, first-out basis. We write down for excess and obsolete
inventory based on the difference between the cost of inventory and
the estimated net realizable value based upon assumptions about
future demand forecasts and market conditions. At the point of a
loss recognition, a new, lower cost basis for that inventory is
established, and subsequent changes in facts or circumstances do
not result in the restoration or increase in that newly established
basis. In addition, we record a liability for firm, non-cancelable
and unconditional purchase commitments with contract manufacturers
and suppliers for quantities in excess of our future demand
forecasts consistent with our valuation of excess and obsolete
inventory.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001193125-13-261334:notes:63]
Property and
Equipment — Property and equipment are recorded at
cost. Depreciation and amortization is computed using the
straight-line method, generally over the following
periods:

[0001193125-13-261334:notes:64]
|  |  | Depreciation Life (years) |
| Buildings |  | 40 years |
| Building improvements |  | 10 years |
| Furniture and fixtures |  | 5 years |
| Computer, production, engineering and other equipment |  | 3 years |
| Software |  | 3 to 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |

[0001193125-13-261334:notes:65]
Construction in
progress will be depreciated over the estimated useful lives of the
respective assets when they are ready for use. We capitalize
interest on significant facility assets under construction and on
significant software development projects.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001193125-13-261334:notes:66]
The following
table presents property and equipment information for geographic
areas based on the physical location of the assets (in
millions):

[0001193125-13-261334:notes:67]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| United States |  | $ | 1,076.3 |  |  | $ | 1,038.9 |  |
| International |  |  | 94.6 |  |  |  | 98.3 |  |
| Total |  | $ | 1,170.9 |  |  | $ | 1,137.2 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-13-261334:notes:68]
Cash
Equivalents — Cash equivalents consist primarily of
money market funds. We consider all highly liquid debt investments
with original maturities of three months or less at the time of
purchase to be cash equivalents.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-13-261334:notes:69]
6. Business
Combinations

[0001193125-13-261334:notes:70]
Fiscal
2013 Acquisitions

[0001193125-13-261334:notes:71]
On
February 11, 2013, we acquired all of the outstanding shares
of ionGrid, a privately-held software company based in California,
for $17.1 million in cash. This acquisition provides our customers
with a secure, simple to use solution for accessing enterprise file
shares from mobile devices. On November 14, 2012, we acquired
all of the outstanding shares of CacheIQ, Inc., a privately-held
storage solutions company based in Texas, for $91.0 million in cash
and equity. This acquisition provides us with technology that
extends our capabilities to support non-disruptive operations for
enterprise data center environments. We will integrate this
technology into our product offerings over time. Together we refer
to these acquisitions as our fiscal 2013 acquisitions.

[0001193125-13-261334:notes:72]
Consideration
related to our fiscal 2013 acquisitions consisted of the following
(in millions):

[0001193125-13-261334:notes:73]
| Cash |  | $ | 106.9 |  |
| Equity |  |  | 1.2 |  |
| Total purchase price |  | $ | 108.1 |  |

[0001193125-13-261334:notes:74]
The purchase
price was allocated to the respective net tangible and intangible
assets of our fiscal 2013 acquisitions as of the dates of the
acquisitions based on various fair value estimates and analyses,
including work performed by third-party valuation
specialists.

[0001193125-13-261334:notes:75]
The following
are the preliminary estimated fair value of assets acquired and
liabilities assumed as of the respective closing dates (in
millions):

[0001193125-13-261334:notes:76]
| Cash |  | $ | 0.4 |  |
| Other current assets |  |  | 6.0 |  |
| Finite-lived intangible assets |  |  | 30.3 |  |
| Goodwill |  |  | 82.9 |  |
| Other assets |  |  | 1.0 |  |
| Total assets acquired |  |  | 120.6 |  |
| Current liabilities |  |  | (0.5 | ) |
| Deferred income taxes |  |  | (12.0 | ) |
| Total purchase price |  | $ | 108.1 |  |

[0001193125-13-261334:notes:77]
The goodwill
recorded from our fiscal 2013 acquisitions is comprised
of expected synergies from combining their respective
operations and that of the Company.

[0001193125-13-261334:notes:78]
Adjustments may
be made to the allocation of the purchase price during the
measurement periods to reflect adjustments related to facts
existing at the time of the acquisitions. None of the goodwill
recognized upon acquisition of our fiscal 2013 acquisitions is
deductible for tax purposes. The finite-lived intangible assets
acquired from our fiscal 2013 acquisitions consist of developed
technology and are amortized on a straight-line basis over three to
five year estimated useful lives.

[0001193125-13-261334:notes:79]
The results of
operations of our fiscal 2013 acquisitions have been included in
our consolidated statements of operations from their respective
acquisition dates. Pro forma results of operations have not been
presented because the acquisitions, individually and collectively,
were not material to our results of operations.

[0001193125-13-261334:notes:80]
Fiscal
2012 Acquisition

[0001193125-13-261334:notes:81]
On May 6,
2011, we completed the acquisition of certain assets related to the
Engenio external storage systems business (Engenio) of LSI
Corporation (LSI). We paid LSI $480.0 million in cash and also
assumed certain liabilities related to Engenio. During the three
years following the acquisition, LSI will pay us a total of
$13.0 million to service certain LSI customer warranties. This
acquisition enables us to address growing customer requirements in
the areas of high bandwidth and intensive analytics
workloads.

[0001193125-13-261334:notes:82]
The purchase
price was allocated to Engenio’s net tangible and intangible
assets as of the date of acquisition based on various fair value
estimates and analyses, including work performed by third-party
valuation specialists.

[0001193125-13-261334:notes:83]
The following
are the fair value of assets acquired and liabilities assumed as of
the closing date (in millions):

[0001193125-13-261334:notes:84]
| Current assets |  | $ | 49.8 |  |
| Property and equipment |  |  | 33.3 |  |
| Finite-lived intangible assets |  |  | 272.1 |  |
| Goodwill |  |  | 143.7 |  |
| Other assets |  |  | 9.3 |  |
| Total assets acquired |  |  | 508.2 |  |
| Current liabilities |  |  | (20.9 | ) |
| Other liabilities |  |  | (7.3 | ) |
| Total purchase price |  | $ | 480.0 |  |

[0001193125-13-261334:notes:85]
As this was an
asset acquisition, U.S. goodwill is deductible for income tax
purposes. The goodwill is comprised of expected synergies in
utilizing Engenio’s technology in our products and channels
(and vice versa), reduction in future combined research and
development expenses, and intangible assets, such as acquired
workforce, that do not qualify for separate recognition.

[0001193125-13-261334:notes:86]
The identified
intangible assets as of the date of acquisition, which are
amortized on a straight-line basis over their estimated useful
lives, consisted of the following (in millions):

[0001193125-13-261334:notes:87]
|  |  | Estimated Fair Value |  |  | Useful Life (Years) |  |
| Developed technology |  | $ | 216.0 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 45.0 |  |  |  | 2 |  |
| Trademarks and trade names |  |  | 7.0 |  |  |  | 2 |  |
| Order backlog |  |  | 2.5 |  |  |  | 0 |  |
| Covenant not to compete |  |  | 1.6 |  |  |  | 3 |  |
| Total identified intangible assets |  | $ | 272.1 |  |  |  |  |  |

[0001193125-13-261334:notes:88]
Our
consolidated net revenues for the year ended April 27, 2012
included $665.9 million attributable to Engenio since the
acquisition. Due to the integration of the combined businesses
since the date of acquisition, it is impracticable to determine the
earnings contributed by Engenio.

[0001193125-13-261334:notes:89]
The following
unaudited pro forma combined financial information gives effect to
the acquisition of Engenio as if it were consummated on May 1,
2010 (the beginning of the comparable prior annual reporting
period). Due to historically differing fiscal year ends of the
Company and Engenio, the unaudited pro forma combined financial
information for the year ended April 29, 2011 is based on
historical results of the Company for the year ended April 29,
2011 and the historical results of Engenio for the year ended
March 31, 2011.

[0001193125-13-261334:notes:90]
The unaudited
pro forma combined financial information is presented for
informational purposes only, is not intended to represent or be
indicative of the results of operations of the Company that would
have been reported had the acquisition occurred on May 1, 2010
and should not be taken as representative of future consolidated
results of operations of the combined company (in
millions):

[0001193125-13-261334:notes:91]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Net revenues |  | $ | 6,241.6 |  |  | $ | 5,827.4 |  |
| Net income |  | $ | 611.9 |  |  | $ | 605.5 |  |

[0001193125-13-261334:notes:92]
A nonrecurring
adjustment of $5.6 million has been reflected in the unaudited pro
forma combined information with the effect of increasing net income
for the year ended April 27, 2012 and decreasing net income
for the year ended April 29, 2011 to present the impact on
cost of revenues from the step-up in inventory as if the
acquisition occurred on May 1, 2010.

[0001193125-13-261334:notes:93]
Fiscal
2011 Acquisitions

[0001193125-13-261334:notes:94]
During fiscal
2011, we acquired all of the common stock of two privately-held
companies, Akorri Networks, Inc. and Bycast Inc., together referred
to as our fiscal 2011 acquisitions. Our fiscal 2011 acquisitions
were completed for total cash and equity consideration of $146.1
million. The Company recorded tangible net assets of $21.2 million,
finite-lived intangible assets of $45.6 million and goodwill, which
is not deductible for tax purposes, of $80.5 million associated
with these transactions. The results of operations of our fiscal
2011 acquisitions have been included in our consolidated statements
of operations from their respective acquisition dates.


## us-gaap:EarningsPerShareTextBlock

[0001193125-13-261334:notes:95]
14. Net Income per
Share

[0001193125-13-261334:notes:96]
The following
potential weighted-average shares of common stock have been
excluded from the diluted net income per share calculations, as
their effect would have been anti-dilutive (in
millions):

[0001193125-13-261334:notes:97]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Employee equity award plans |  |  | 15.1 |  |  |  | 9.9 |  |  |  | 2.6 |  |

[0001193125-13-261334:notes:98]
Dilutive shares
outstanding during fiscal 2013 do not include any effect resulting
from warrants, as their impact would have been anti-dilutive. The
Convertible Note hedges are not included in the calculation of
earnings per share for any period as their effect would have been
anti-dilutive. The Convertible Note hedges, if exercised upon
conversion of the Convertible Notes, are expected to reduce
approximately 80% of the dilutive effect of the Convertible Notes
when our stock price is above $31.85 per share.


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001193125-13-261334:notes:99]
Cash and
cash equivalents (in millions):

[0001193125-13-261334:notes:100]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Cash |  | $ | 1,634.7 |  |  | $ | 649.8 |  |
| Cash equivalents |  |  | 1,642.4 |  |  |  | 900.0 |  |
| Cash and cash equivalents |  | $ | 3,277.1 |  |  | $ | 1,549.8 |  |


## us-gaap:ScheduleOfDeferredTaxAssetsAndLiabilitiesTableTextBlock

[0001193125-13-261334:notes:101]
The components
of our deferred tax assets and liabilities are as follows (in
millions):

[0001193125-13-261334:notes:102]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Reserves and accruals |  | $ | 83.5 |  |  | $ | 70.2 |  |
| Acquired intangibles |  |  | 12.3 |  |  |  | 6.7 |  |
| Net operating loss and credit carryforwards |  |  | 76.5 |  |  |  | 97.7 |  |
| Stock-based compensation |  |  | 81.9 |  |  |  | 78.7 |  |
| Deferred revenue |  |  | 311.6 |  |  |  | 262.0 |  |
| Other |  |  | 20.7 |  |  |  | 15.1 |  |
| Gross deferred tax assets |  |  | 586.5 |  |  |  | 530.4 |  |
| Valuation allowance |  |  | (39.8 | ) |  |  | (32.4 | ) |
| Deferred tax assets, net of valuation allowance |  |  | 546.7 |  |  |  | 498.0 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Reserves and accruals |  |  | 7.7 |  |  |  | 4.7 |  |
| Acquired intangibles |  |  | 6.0 |  |  |  | 2.2 |  |
| Property and equipment |  |  | 71.5 |  |  |  | 67.9 |  |
| Convertible Notes |  |  | 4.4 |  |  |  | 15.2 |  |
| Other |  |  | 4.1 |  |  |  | 2.6 |  |
| Total deferred tax liabilities |  |  | 93.7 |  |  |  | 92.6 |  |
| Deferred tax assets, net of valuation allowance and deferred tax liabilities |  | $ | 453.0 |  |  | $ | 405.4 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-13-261334:notes:103]
9. Financial
Instruments and Fair Value Measurements

[0001193125-13-261334:notes:104]
The accounting
guidance for fair value measurements provides a framework for
measuring fair value on either a recurring or nonrecurring basis
whereby the inputs used in valuation techniques are assigned a
hierarchical level. The following are the three levels of inputs to
measure fair value:

[0001193125-13-261334:notes:105]
Level 1: Observable inputs that reflect quoted
prices (unadjusted) for identical assets or liabilities in active
markets.

[0001193125-13-261334:notes:106]
Level 2: Inputs that reflect quoted prices for
identical assets or liabilities in less active markets; quoted
prices for similar assets or liabilities in active markets;
benchmark yields, reported trades, broker/dealer quotes, inputs
other than quoted prices that are observable for the assets or
liabilities; or inputs that are derived principally from or
corroborated by observable market data by correlation or other
means.

[0001193125-13-261334:notes:107]
Level 3: Unobservable inputs that reflect our
own assumptions incorporated in valuation techniques used to
measure fair value. These assumptions are required to be consistent
with market participant assumptions that are reasonably
available.

[0001193125-13-261334:notes:108]
We consider an
active market to be one in which transactions for the asset or
liability occur with sufficient frequency and volume to provide
pricing information on an ongoing basis, and consider an inactive
market to be one in which there are infrequent or few transactions
for the asset or liability, the prices are not current, or price
quotations vary substantially either over time or among market
makers. Where appropriate, our own or the counterparty’s
non-performance risk is considered in measuring the fair values of
liabilities and assets, respectively.

[0001193125-13-261334:notes:109]
Investments

[0001193125-13-261334:notes:110]
The following
is a summary of our investments (in millions):

[0001193125-13-261334:notes:111]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
|  |  | Cost or Amortized Cost |  |  | Gross Unrealized |  |  | Estimated Fair Value |  |  | Cost or Amortized Cost |  |  | Gross Unrealized |  |  | Estimated Fair Value |  |
|  |  |  | Gains |  |  | Losses |  |  |  |  | Gains |  |  | Losses |  |  |
| Corporate bonds |  | $ | 3,132.8 |  |  | $ | 14.9 |  |  | $ | (0.6 | ) |  | $ | 3,147.1 |  |  | $ | 2,665.2 |  |  | $ | 9.5 |  |  | $ | (1.4 | ) |  | $ | 2,673.3 |  |
| U.S. Treasury and government debt securities |  |  | 392.8 |  |  |  | 0.9 |  |  |  | 0.0 |  |  |  | 393.7 |  |  |  | 836.7 |  |  |  | 1.2 |  |  |  | (0.1 | ) |  |  | 837.8 |  |
| Commercial paper |  |  | 178.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 178.5 |  |  |  | 164.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 164.6 |  |
| Certificates of deposit |  |  | 135.4 |  |  |  | 0.1 |  |  |  | 0.0 |  |  |  | 135.5 |  |  |  | 347.7 |  |  |  | 0.5 |  |  |  | 0.0 |  |  |  | 348.2 |  |
| Money market funds |  |  | 1,463.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,463.1 |  |  |  | 724.8 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 724.8 |  |
| Auction rate securities |  |  | 44.2 |  |  |  | 0.5 |  |  |  | (2.7 | ) |  |  | 42.0 |  |  |  | 54.1 |  |  |  | 0.9 |  |  |  | (4.0 | ) |  |  | 51.0 |  |
| Equity funds |  |  | 28.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 28.3 |  |  |  | 25.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 25.5 |  |
| Total debt and equity securities |  | $ | 5,375.1 |  |  | $ | 16.4 |  |  | $ | (3.3 | ) |  | $ | 5,388.2 |  |  | $ | 4,818.6 |  |  | $ | 12.1 |  |  | $ | (5.5 | ) |  | $ | 4,825.2 |  |

[0001193125-13-261334:notes:112]
We record
unrealized gains or losses on available-for-sale securities in
AOCI. The following table shows the gross unrealized losses and
estimated fair values of our investments, aggregated by investment
category and length of time that individual securities have been in
continuous unrealized loss positions, as of April 26, 2013 (in
millions):

[0001193125-13-261334:notes:113]
|  |  | Less than 12 Months |  |  | 12 Months or Greater |  |  | Total |  |
|  |  | Estimated Fair Value |  |  | Unrealized Losses |  |  | Estimated Fair Value |  |  | Unrealized Losses |  |  | Estimated Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  | $ | 698.1 |  |  | $ | (0.5 | ) |  | $ | 38.4 |  |  | $ | (0.1 | ) |  | $ | 736.5 |  |  | $ | (0.6 | ) |
| Auction rate securities |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 39.2 |  |  |  | (2.7 | ) |  |  | 39.2 |  |  |  | (2.7 | ) |
| Total |  | $ | 698.1 |  |  | $ | (0.5 | ) |  | $ | 77.6 |  |  | $ | (2.8 | ) |  | $ | 775.7 |  |  | $ | (3.3 | ) |

[0001193125-13-261334:notes:114]
The following
table shows the gross unrealized losses and estimated fair values
of our investments, aggregated by investment category and length of
time that individual securities have been in continuous unrealized
loss positions, as of April 27, 2012 (in millions):

[0001193125-13-261334:notes:115]
|  |  | Less than 12 Months |  |  | 12 Months or Greater |  |  | Total |  |
|  |  | Estimated Fair Value |  |  | Unrealized Losses |  |  | Estimated Fair Value |  |  | Unrealized Losses |  |  | Estimated Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  | $ | 771.1 |  |  | $ | (1.4 | ) |  | $ | 0.0 |  |  | $ | 0.0 |  |  | $ | 771.1 |  |  | $ | (1.4 | ) |
| Auction rate securities |  |  | 4.8 |  |  |  | (0.2 | ) |  |  | 38.8 |  |  |  | (3.8 | ) |  |  | 43.6 |  |  |  | (4.0 | ) |
| U.S. Treasury and government debt securities |  |  | 89.4 |  |  |  | (0.1 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 89.4 |  |  |  | (0.1 | ) |
| Total |  | $ | 865.3 |  |  | $ | (1.7 | ) |  | $ | 38.8 |  |  | $ | (3.8 | ) |  | $ | 904.1 |  |  | $ | (5.5 | ) |

[0001193125-13-261334:notes:116]
The unrealized
losses on our available-for-sale investments were caused by market
value declines as a result of the economic environment, as well as
fluctuations in market interest rates. Because the declines in
market value are attributable to changes in market conditions and
not credit quality, and because we have concluded currently that we
neither intend to sell nor is it more likely than not that we will
be required to sell these investments prior to a recovery of par
value, we do not consider these investments to be other-than
temporarily impaired as of April 26, 2013.

[0001193125-13-261334:notes:117]
The following
table presents the contractual maturities of our debt investments
as of April 26, 2013 (in millions):

[0001193125-13-261334:notes:118]
|  |  | Amortized Cost |  |  | Estimated Fair Value |  |
| Due in one year or less |  | $ | 1,282.4 |  |  | $ | 1,284.2 |  |
| Due in one through five years |  |  | 2,377.8 |  |  |  | 2,391.3 |  |
| Due after ten years* |  |  | 44.2 |  |  |  | 42.0 |  |
|  |  | $ | 3,704.4 |  |  | $ | 3,717.5 |  |

[0001193125-13-261334:notes:119]
| * | Consists of ARS which have contractual maturities of greater than 10 years. |

[0001193125-13-261334:notes:120]
Fair
Value of Financial Instruments

[0001193125-13-261334:notes:121]
The following
table summarizes our financial assets and liabilities measured at
fair value on a recurring basis as of April 26, 2013 (in
millions):

[0001193125-13-261334:notes:122]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 3,147.1 |  |  | $ | 0.0 |  |  | $ | 3,147.1 |  |  | $ | 0.0 |  |
| U.S. Treasury and government debt securities |  |  | 393.7 |  |  |  | 222.9 |  |  |  | 170.8 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 178.5 |  |  |  | 0.0 |  |  |  | 178.5 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 135.5 |  |  |  | 0.0 |  |  |  | 135.5 |  |  |  | 0.0 |  |
| Money market funds |  |  | 1,463.1 |  |  |  | 1,463.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 42.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 42.0 |  |
| Equity funds |  |  | 28.3 |  |  |  | 28.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign currency contracts |  |  | 1.2 |  |  |  | 0.0 |  |  |  | 1.2 |  |  |  | 0.0 |  |
| Total |  | $ | 5,389.4 |  |  | $ | 1,714.3 |  |  | $ | 3,633.1 |  |  | $ | 42.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | 3.1 |  |  | $ | 0.0 |  |  | $ | 3.1 |  |  | $ | 0.0 |  |

[0001193125-13-261334:notes:123]
The following
table summarizes the balance sheet classifications of our financial
assets and liabilities measured at fair value on a recurring basis
as of April 26, 2013 (in millions):

[0001193125-13-261334:notes:124]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 1,642.4 |  |  | $ | 1,463.1 |  |  | $ | 179.3 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 3,675.5 |  |  |  | 222.9 |  |  |  | 3,452.6 |  |  |  | 0.0 |  |
| Other current assets |  |  | 2.8 |  |  |  | 1.6 |  |  |  | 1.2 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 68.7 |  |  |  | 26.7 |  |  |  | 0.0 |  |  |  | 42.0 |  |
| Total |  | $ | 5,389.4 |  |  | $ | 1,714.3 |  |  | $ | 3,633.1 |  |  | $ | 42.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 3.1 |  |  | $ | 0.0 |  |  | $ | 3.1 |  |  | $ | 0.0 |  |

[0001193125-13-261334:notes:125]
The following
table summarizes our financial assets and liabilities measured at
fair value on a recurring basis as of April 27, 2012 (in
millions):

[0001193125-13-261334:notes:126]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,673.3 |  |  | $ | 0.0 |  |  | $ | 2,673.3 |  |  | $ | 0.0 |  |
| U.S. Treasury and government debt securities |  |  | 837.8 |  |  |  | 234.3 |  |  |  | 603.5 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 164.6 |  |  |  | 0.0 |  |  |  | 164.6 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 348.2 |  |  |  | 0.0 |  |  |  | 348.2 |  |  |  | 0.0 |  |
| Money market funds |  |  | 724.8 |  |  |  | 724.8 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 51.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 51.0 |  |
| Equity funds |  |  | 25.5 |  |  |  | 25.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign currency contracts |  |  | 2.7 |  |  |  | 0.0 |  |  |  | 2.7 |  |  |  | 0.0 |  |
| Total |  | $ | 4,827.9 |  |  | $ | 984.6 |  |  | $ | 3,792.3 |  |  | $ | 51.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | 2.6 |  |  | $ | 0.0 |  |  | $ | 2.6 |  |  | $ | 0.0 |  |

[0001193125-13-261334:notes:127]
The following
table summarizes the balance sheet classifications of our financial
assets and liabilities measured at fair value on a recurring basis
as of April 27, 2012 (in millions):

[0001193125-13-261334:notes:128]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 900.0 |  |  | $ | 724.8 |  |  | $ | 175.2 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 3,848.7 |  |  |  | 234.3 |  |  |  | 3,614.4 |  |  |  | 0.0 |  |
| Other current assets |  |  | 9.0 |  |  |  | 6.3 |  |  |  | 2.7 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 70.2 |  |  |  | 19.2 |  |  |  | 0.0 |  |  |  | 51.0 |  |
| Total |  | $ | 4,827.9 |  |  | $ | 984.6 |  |  | $ | 3,792.3 |  |  | $ | 51.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 2.6 |  |  | $ | 0.0 |  |  | $ | 2.6 |  |  | $ | 0.0 |  |

[0001193125-13-261334:notes:129]
Level 2
investments are held by a custodian who prices some of the
investments using standard inputs in various asset price models or
obtains investment prices from a third-party pricing provider that
incorporates standard inputs in various asset price models. We
review Level 2 inputs and fair value for reasonableness and the
values may be further validated by comparison to multiple
independent pricing sources. In addition, we review third-party
pricing provider models, key inputs and assumptions and understand
the pricing processes at our third-party providers in determining
the overall reasonableness of the fair value of our Level 2
financial instruments. As of April 26, 2013 and April 27,
2012, we have not made any adjustments to the prices obtained from
our third-party pricing providers.

[0001193125-13-261334:notes:130]
Quantitative
information about our Level 3 fair value measurements is as follows
(fair value in millions):

[0001193125-13-261334:notes:131]
|  |  | Fair Value at April 26, 2013 |  | Valuation Techniques |  | Unobservable Inputs |  | Range (Weighted average) |
| ARS |  | $ 42.0 |  | Discounted cash flow |  | Time-to-economic maturity |  | 6.7 yrs - 11.4 yrs (8.6 yrs) |
|  |  |  |  |  |  | Liquidity risk premium, market credit spread and other factors |  | 1.6% - 2.8% (2.0%) |
|  |  |  |  |  |  | Coupon rate |  | 0.8% - 2.7% (1.5%) |
|  |  |  |  | Market comparable securities |  | Discount rate |  | 3.3% - 7.3% (6.3%) |

[0001193125-13-261334:notes:132]
|  |  | Fair Value at April 27, 2012 |  | Valuation Techniques |  | Unobservable Inputs |  | Range (Weighted average) |
| ARS |  | $ 51.0 |  | Discounted cash flow |  | Time-to-economic maturity |  | 6.4 yrs - 16.1 yrs (10.2 yrs) |
|  |  |  |  |  |  | Liquidity risk premium, market credit spread and other factors |  | 1.8% - 3.2% (2.2%) |
|  |  |  |  |  |  | Coupon rate |  | 1.2% - 3.2% (1.8%) |
|  |  |  |  | Market comparable securities |  | Discount rate |  | 4.7% - 12.6% (8.6%) |

[0001193125-13-261334:notes:133]
All of our ARS
are classified as other non-current assets and are backed by pools
of student loans guaranteed by the U.S. Department of Education. We
estimate the fair value of each individual ARS using an income
(discounted cash flow) and market approach that incorporate both
observable and unobservable inputs. Key inputs into the discounted
cash flow analysis include the time-to-economic maturity, liquidity
risk premium, market credit spread and other factors and a coupon
rate. The key input into the market approach is a discount rate. A
significant increase (decrease) in the time-to-economic maturity,
liquidity risk premium, market credit spread and other factors,
coupon rate or discount rate could result in a significantly lower
(higher) fair value estimate. We review the fair value of our Level
3 financial instruments for overall reasonableness by reviewing
service provider pricing methodologies, key inputs and assumptions
and by understanding the processes used by our third-party service
provider. We will continue to monitor our ARS investments in light
of the debt market environment and evaluate these investments for
impairment and classification.

[0001193125-13-261334:notes:134]
The table below
provides a reconciliation of the beginning and ending balance of
our Level 3 ARS measured at fair value on a recurring basis
using significant unobservable inputs.

[0001193125-13-261334:notes:135]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Balance at beginning of period |  | $ | 51.0 |  |  | $ | 65.1 |  |  | $ | 69.0 |  |
| Total unrealized gains (losses), net included in other comprehensive income |  |  | 0.5 |  |  |  | 0.9 |  |  |  | (1.4 | ) |
| Total realized gains included in earnings |  |  | 1.1 |  |  |  | 0.7 |  |  |  | 0.0 |  |
| Settlements |  |  | (10.6 | ) |  |  | (15.7 | ) |  |  | (2.5 | ) |
| Balance at end of period |  | $ | 42.0 |  |  | $ | 51.0 |  |  | $ | 65.1 |  |

[0001193125-13-261334:notes:136]
Fair
Value of Debt

[0001193125-13-261334:notes:137]
As of
April 26, 2013, the fair value of our 2.00% Senior Notes and
3.25% Senior Notes (collectively referred to as the Senior Notes)
was approximately $1,007.7 million and the fair value of our
Convertible Notes, which includes the debt and equity components of
such, was approximately $1,393.6 million. As of April 27,
2012, the fair value of our Convertible Notes was approximately
$1,649.9 million. The fair value of our debt was based on
observable market prices in a less active market, discounted cash
flow models that take into consideration variables such as
credit-rating and interest rate changes, and in the case of
Convertible Notes, also takes into consideration the market price
of our stock. All of our debt obligations are categorized as Level
2 instruments.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-13-261334:notes:138]
8. Balance Sheet
Details

[0001193125-13-261334:notes:139]
Inventories (in millions):

[0001193125-13-261334:notes:140]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Purchased components |  | $ | 16.3 |  |  | $ | 30.9 |  |
| Finished goods |  |  | 123.2 |  |  |  | 130.6 |  |
| Inventories |  | $ | 139.5 |  |  | $ | 161.5 |  |

[0001193125-13-261334:notes:141]
Other
current assets (in millions):

[0001193125-13-261334:notes:142]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Prepaid expenses and other current assets |  | $ | 262.6 |  |  | $ | 225.4 |  |
| Short-term restricted cash |  |  | 8.9 |  |  |  | 8.6 |  |
| Deferred tax assets |  |  | 253.7 |  |  |  | 201.6 |  |
| Other current assets |  | $ | 525.2 |  |  | $ | 435.6 |  |

[0001193125-13-261334:notes:143]
Property
and equipment, net (in millions):

[0001193125-13-261334:notes:144]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Land |  | $ | 265.5 |  |  | $ | 247.6 |  |
| Buildings and building improvements |  |  | 534.8 |  |  |  | 417.9 |  |
| Leasehold improvements |  |  | 100.3 |  |  |  | 96.5 |  |
| Computer, production, engineering and other equipment |  |  | 714.0 |  |  |  | 638.1 |  |
| Software |  |  | 422.6 |  |  |  | 381.6 |  |
| Furniture and fixtures |  |  | 82.2 |  |  |  | 71.7 |  |
| Construction-in-progress |  |  | 19.9 |  |  |  | 107.1 |  |
|  |  |  | 2,139.3 |  |  |  | 1,960.5 |  |
| Accumulated depreciation and amortization |  |  | (968.4 | ) |  |  | (823.3 | ) |
| Property and equipment, net |  | $ | 1,170.9 |  |  | $ | 1,137.2 |  |

[0001193125-13-261334:notes:145]
In fiscal 2012,
we exercised our option under one of our synthetic leasing
arrangements to early terminate the lease and purchase the
facilities, including land and buildings, for $80.0 million, which
had a fair value of $44.3 million at the date of purchase. In
fiscal 2013, we exercised our options under our three remaining
synthetic leasing arrangements to terminate the leases and purchase
the related facilities, including land and buildings, for $69.6
million. The purchased facilities had an aggregate fair value of
$88.4 million at the dates of the respective purchases. We had
accounted for these leasing arrangements as operating leases. The
difference between the estimated fair value of the facilities and
their respective lease obligation had been accrued as additional
rent expense in our consolidated statement of operations and as a
residual value guarantee obligation in our consolidated balance
sheets. The terminations did not result in a material impact to our
operating results.

[0001193125-13-261334:notes:146]
Software
includes capitalized internal-use software development costs having
a net book value as follows (in millions):

[0001193125-13-261334:notes:147]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Computer software |  | $ | 162.5 |  |  | $ | 160.1 |  |

[0001193125-13-261334:notes:148]
Depreciation
and amortization expense related to property and equipment, net is
summarized below (in millions):

[0001193125-13-261334:notes:149]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Depreciation and amortization expense |  | $ | 258.8 |  |  | $ | 204.1 |  |  | $ | 147.9 |  |

[0001193125-13-261334:notes:150]
Included in
depreciation and amortization expense above is amortization related
to computer software, as summarized below (in millions):

[0001193125-13-261334:notes:151]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Computer software amortization expense |  | $ | 76.7 |  |  | $ | 53.8 |  |  | $ | 37.9 |  |

[0001193125-13-261334:notes:152]
Other
non-current assets (in millions):

[0001193125-13-261334:notes:153]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Auction rate securities |  | $ | 42.0 |  |  | $ | 51.0 |  |
| Deferred tax assets |  |  | 200.4 |  |  |  | 203.8 |  |
| Other assets |  |  | 242.2 |  |  |  | 172.6 |  |
| Other non-current assets |  | $ | 484.6 |  |  | $ | 427.4 |  |

[0001193125-13-261334:notes:154]
Short-term and long-term deferred revenue (in
millions):

[0001193125-13-261334:notes:155]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Product |  | $ | 15.7 |  |  | $ | 25.7 |  |
| SEM and service |  |  | 2,993.8 |  |  |  | 2,790.2 |  |
| Total |  | $ | 3,009.5 |  |  | $ | 2,815.9 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,563.3 |  |  | $ | 1,366.5 |  |
| Long-term |  |  | 1,446.2 |  |  |  | 1,449.4 |  |
| Total |  | $ | 3,009.5 |  |  | $ | 2,815.9 |  |

[0001193125-13-261334:notes:156]
Accumulated other comprehensive income (in
millions):

[0001193125-13-261334:notes:157]
The components
of AOCI, net of related immaterial tax effects, were as
follows:

[0001193125-13-261334:notes:158]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Accumulated foreign currency translation adjustments |  | $ | 2.0 |  |  | $ | 4.9 |  |
| Accumulated defined benefit obligation adjustments |  |  | (5.7 | ) |  |  | (4.4 | ) |
| Accumulated unrealized gains on available-for-sale securities |  |  | 11.4 |  |  |  | 4.9 |  |
| Accumulated unrealized gains (losses) on derivative instruments |  |  | 1.0 |  |  |  | (0.5 | ) |
| Total accumulated other comprehensive income |  | $ | 8.7 |  |  | $ | 4.9 |  |


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-13-261334:notes:159]
3. Concentration of
Risk

[0001193125-13-261334:notes:160]
Financial
instruments that potentially subject us to concentrations of credit
risk consist primarily of cash equivalents, investments, foreign
exchange contracts and accounts receivable. Cash equivalents and
short-term investments consist primarily of corporate bonds,
U.S. Treasury and government debt securities and money market
funds, all of which are considered high investment grade. Our
policy is to limit the amount of credit exposure through
diversification and investment in highly rated securities. We
further mitigate concentrations of credit risk in our investments
by limiting our investments in the debt securities of a single
issuer and by diversifying risk across geographies and type of
issuer.

[0001193125-13-261334:notes:161]
Our long term
investments, consisting primarily of ARS, have been and will
continue to be exposed to market risk due to uncertainties in the
credit and capital markets.

[0001193125-13-261334:notes:162]
In entering into
forward foreign exchange contracts, we have assumed the risk that
might arise from the possible inability of counterparties to meet
the terms of their contracts. The counterparties to these contracts
are major multinational commercial banks, and we do not expect any
losses as a result of counterparty defaults.

[0001193125-13-261334:notes:163]
We sell our
products primarily to large organizations in different industries
and geographies. We do not require collateral or other security to
support accounts receivable. In addition, we maintain an allowance
for potential credit losses. To reduce credit risk, we perform
ongoing credit evaluations on our customers’ financial
condition. We establish an allowance for doubtful accounts based
upon factors surrounding the credit risk of customers, historical
trends and other information and, to date, such losses have been
within management’s expectations. Concentrations of credit
risk with respect to trade accounts receivable are limited due to
the wide variety of customers who are dispersed across many
geographic regions.

[0001193125-13-261334:notes:164]
There are no
concentrations of business transacted with a particular market that
would severely impact our business in the near term. However, we
currently rely on a limited number of suppliers for certain key
components and a few key contract manufacturers to manufacture most
of our products; any disruption or termination of these
arrangements could materially adversely affect our operating
results.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001193125-13-261334:notes:165]
The following
customers accounted for 10% or more of net accounts
receivable:

[0001193125-13-261334:notes:166]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Arrow Electronics, Inc. |  |  | 16 | % |  |  | N/A |  |
| Avnet, Inc. |  |  | 14 | % |  |  | 11 | % |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001193125-13-261334:notes:167]
SCHEDULE II

[0001193125-13-261334:notes:168]
NETAPP,
INC.

[0001193125-13-261334:notes:169]
VALUATION AND
QUALIFYING ACCOUNTS

[0001193125-13-261334:notes:170]
Years Ended
April 26, 2013, April 27, 2012 and April 29,
2011

[0001193125-13-261334:notes:171]
(In
millions)

[0001193125-13-261334:notes:172]
| Description |  | Balance at Beginning of Period |  |  | Additions Charged (Credited) to Costs and Expenses |  |  | Reductions and Write-offs |  |  | Balance at End of Period |  |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 2013 |  | $ | 0.4 |  |  | $ | 4.2 |  |  | $ | 0.4 |  |  | $ | 4.2 |  |
| 2012 |  | $ | 0.5 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |
| 2011 |  | $ | 1.6 |  |  | $ | (0.8 | ) |  | $ | 0.3 |  |  | $ | 0.5 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001193125-13-261334:notes:173]
The provision
for income taxes consists of the following (in
millions):

[0001193125-13-261334:notes:174]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 85.3 |  |  | $ | 114.8 |  |  | $ | 113.0 |  |
| State |  |  | 14.6 |  |  |  | 26.2 |  |  |  | (1.3 | ) |
| Foreign |  |  | 38.0 |  |  |  | 26.9 |  |  |  | 35.6 |  |
| Total current |  |  | 137.9 |  |  |  | 167.9 |  |  |  | 147.3 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (56.9 | ) |  |  | (61.5 | ) |  |  | (27.5 | ) |
| State |  |  | (17.8 | ) |  |  | (16.4 | ) |  |  | 13.7 |  |
| Foreign |  |  | (1.9 | ) |  |  | 17.0 |  |  |  | (12.5 | ) |
| Total deferred |  |  | (76.6 | ) |  |  | (60.9 | ) |  |  | (26.3 | ) |
| Provision for income taxes |  | $ | 61.3 |  |  | $ | 107.0 |  |  | $ | 121.0 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-13-261334:notes:175]
16. Employee
Benefits and Deferred Compensation

[0001193125-13-261334:notes:176]
Employee
401(k) Plan

[0001193125-13-261334:notes:177]
We have
established a 401(k) tax-deferred savings plan. Employees meeting
the eligibility requirements, as defined, may contribute specified
percentages of their salaries, but not more than the statutory
limits. We match 100% of the first $1,000 of employee
contributions, then 50% for additional contributions, up to a
maximum match of $3,000 per employee. The matched contributions
vest over 3 years. The amounts we contributed to this plan,
net of forfeitures, were as follows (in millions):

[0001193125-13-261334:notes:178]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| 401(k) matching contributions |  | $ | 19.9 |  |  | $ | 20.0 |  |  | $ | 15.6 |  |

[0001193125-13-261334:notes:179]
Deferred
Compensation Plan

[0001193125-13-261334:notes:180]
We have a
non-qualified deferred compensation plan that allows a group of
employees within the United States to contribute base salary and
commissions or incentive compensation on a tax deferred basis in
excess of the IRS limits imposed on 401(k) plans. The marketable
securities related to these investments that are held in a rabbi
trust under the non-qualified deferred compensation plan and the
related deferred compensation plan liabilities under this plan were
as follows (in millions):

[0001193125-13-261334:notes:181]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Deferred compensation plan assets |  | $ | 28.3 |  |  | $ | 25.5 |  |
| Deferred compensation plan liabilities reported as: |  |  |  |  |  |  |  |  |
| Other current liabilities |  |  | 1.6 |  |  |  | 6.3 |  |
| Other long-term liabilities |  |  | 26.7 |  |  |  | 19.2 |  |

[0001193125-13-261334:notes:182]
Postretirement Health Care Plan

[0001193125-13-261334:notes:183]
We maintain a
plan to provide postretirement health and welfare benefits to
certain executives who meet certain age and service requirements.
Coverage continues through the duration of the lifetime of the
retiree or the retiree’s spouse, whichever is longer. There
is no funding requirement associated with the plan and none of the
benefit obligation was funded as of April 26, 2013. Assumed
health care cost trend rates have a significant effect on the
amounts reported for the health care plan.

[0001193125-13-261334:notes:184]
International Defined Benefit Plans

[0001193125-13-261334:notes:185]
We maintain
various defined benefit plans to provide termination and
postretirement benefits to certain eligible employees outside of
the United States. We also have disability benefits to certain
eligible employees in the United States. Eligibility is determined
based on the terms of our plans and local statutory requirements.
Assumed discount rates and expected long-term returns on plan
assets have significant effects on the amounts reported for the
defined benefit plans.

[0001193125-13-261334:notes:186]
Funded
Status

[0001193125-13-261334:notes:187]
The funded
status of our postretirement health care and international
termination and postretirement benefits was as follows (in
millions):

[0001193125-13-261334:notes:188]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Fair value of plan assets |  | $ | 17.3 |  |  | $ | 16.1 |  |
| Benefit obligations |  |  | (44.7 | ) |  |  | (38.3 | ) |
| Unfunded obligations |  | $ | (27.4 | ) |  | $ | (22.2 | ) |

[0001193125-13-261334:notes:189]
Amounts
recognized in the consolidated balance sheets were as follows (in
millions):

[0001193125-13-261334:notes:190]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Other long-term liabilities |  | $ | 27.4 |  |  | $ | 22.2 |  |
| Accumulated other comprehensive income |  | $ | (5.7 | ) |  | $ | (4.4 | ) |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-13-261334:notes:191]
Goodwill
activity is summarized as follows (in millions):

[0001193125-13-261334:notes:192]
| April 29, 2011 |  | $ | 760.3 |  |
| Additions |  |  | 143.7 |  |
| Adjustments |  |  | 1.2 |  |
| April 27, 2012 |  |  | 905.2 |  |
| Additions |  |  | 82.9 |  |
| April 26, 2013 |  | $ | 988.1 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-13-261334:notes:193]
As of
April 26, 2013, future amortization expense related to
purchased intangible assets is as follows (in millions):

[0001193125-13-261334:notes:194]
| Fiscal Year |  | Amount |  |
| 2014 |  | $ | 59.2 |  |
| 2015 |  |  | 57.8 |  |
| 2016 |  |  | 53.6 |  |
| 2017 |  |  | 6.7 |  |
| 2018 |  |  | 3.3 |  |
| Total |  | $ | 180.6 |  |


## us-gaap:ScheduleOfRentExpenseTableTextBlock

[0001193125-13-261334:notes:195]
Rent expense
consisted of the following (in millions):

[0001193125-13-261334:notes:196]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Facilities rent expense |  | $ | 48.7 |  |  | $ | 71.0 |  |  | $ | 51.7 |  |
| Equipment rent expense |  |  | 17.5 |  |  |  | 18.6 |  |  |  | 23.1 |  |
|  |  |  | 66.2 |  |  |  | 89.6 |  |  |  | 74.8 |  |
| Less: sublease income |  |  | (1.3 | ) |  |  | (1.4 | ) |  |  | (6.3 | ) |
| Net rent expense |  | $ | 64.9 |  |  | $ | 88.2 |  |  | $ | 68.5 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001193125-13-261334:notes:197]
Summarized
revenues by geographic region based on information from our
internal management system and utilized by our Chief Executive
Officer, who is considered our Chief Operating Decision Maker, is
as follows (in millions):

[0001193125-13-261334:notes:198]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Americas (United States, Canada and Latin America) |  | $ | 3,552.5 |  |  | $ | 3,529.7 |  |  | $ | 2,899.0 |  |
| Europe, Middle East and Africa |  |  | 1,928.8 |  |  |  | 1,936.5 |  |  |  | 1,719.1 |  |
| Asia Pacific |  |  | 851.1 |  |  |  | 767.0 |  |  |  | 504.5 |  |
| Net revenues |  | $ | 6,332.4 |  |  | $ | 6,233.2 |  |  | $ | 5,122.6 |  |


## us-gaap:DerivativesPolicyTextBlock

[0001193125-13-261334:notes:199]
Derivative
Instruments — Derivatives that are not designated as
hedges are adjusted to fair value through earnings. If the
derivative is designated as a cash flow hedge, the effective
portion of the contracts’ gains and losses resulting from
changes in fair value is recognized in AOCI until the forecasted
transaction is recognized in earnings. The ineffective portion of
the hedge is recognized in earnings immediately.

[0001193125-13-261334:notes:200]
As a result of
our significant international operations, we are subject to risks
associated with fluctuating exchange rates. We use derivative
financial instruments, principally foreign currency exchange
forward contracts and currency options, to attempt to minimize the
impact of exchange rate movements on our subsidiaries’ and
consolidated balance sheets and operating results. Factors that
could have an impact on the effectiveness of our hedging program
include the accuracy of forecasts and the volatility of foreign
currency markets. These programs reduce, but do not entirely
eliminate, the impact of currency exchange movements. The
maturities of these instruments are generally less than one
year.

[0001193125-13-261334:notes:201]
Currently, we
do not enter into any foreign exchange forward contracts to hedge
exposures related to firm commitments or nonmarketable investments.
Cash flows from our derivative programs are included under
operating activities in the consolidated statements of cash
flows.


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock

[0001193125-13-261334:notes:202]
A reconciliation
of the beginning and ending amount of unrecognized tax benefits is
as follows (in millions):

[0001193125-13-261334:notes:203]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Balance at beginning of period |  | $ | 161.0 |  |  | $ | 133.3 |  |  | $ | 134.5 |  |
| Additions based on tax positions related to the current year |  |  | 34.5 |  |  |  | 13.0 |  |  |  | 12.5 |  |
| Additions for tax positions of prior years |  |  | 1.0 |  |  |  | 22.1 |  |  |  | 26.3 |  |
| Decreases for tax positions of prior years |  |  | (6.9 | ) |  |  | (7.4 | ) |  |  | (40.0 | ) |
| Balance at end of period |  | $ | 189.6 |  |  | $ | 161.0 |  |  | $ | 133.3 |  |


## us-gaap:SubsequentEventsTextBlock

[0001193125-13-261334:notes:204]
18. Subsequent
Events

[0001193125-13-261334:notes:205]
Dividends
and Stock Repurchase Program

[0001193125-13-261334:notes:206]
On May 21,
2013, we announced a quarterly cash dividend of $0.15 per share of
common stock, payable on July 23, 2013 to holders of record as
of the close of business on July 11, 2013. The timing and
amount of future dividends will depend on market conditions,
corporate business and financial considerations and regulatory
requirements.

[0001193125-13-261334:notes:207]
In May 2013,
our Board of Directors approved an increase of $1.6 billion to our
stock repurchase program. Under this program, we may purchase
shares of our outstanding common stock through open market and
privately negotiated transactions at prices deemed appropriate by
our management. The stock repurchase program may be suspended or
discontinued at any time.

[0001193125-13-261334:notes:208]
Convertible Notes Settlement

[0001193125-13-261334:notes:209]
The Convertible
Notes matured on June 1, 2013. At the time of settlement, we
delivered $1.265 billion in cash to the holders for the outstanding
principal amount and issued 4.9 million shares of our common
stock for the excess conversion value. In addition, we exercised
the Convertible Note hedges, for which we received 3.9 million
shares from the counterparties.

[0001193125-13-261334:notes:210]
Accelerated Share Repurchase Agreement

[0001193125-13-261334:notes:211]
On June 5,
2013, we entered into a collared accelerated share repurchase
agreement (ASR) with a counterparty under which we prepaid $750.0
million to purchase shares of our common stock. In exchange for the
up-front payment, the counterparty committed to deliver a number of
shares during the ASR’s purchase period, which ends no later
than August 29, 2013, although the completion date may be
accelerated at the counterparty’s option. The total number of
shares to be delivered, and therefore the average price per share,
will be determined at the end of the purchase period based on the
volume weighted average price of our stock during that
period.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-13-261334:notes:212]
7. Goodwill and
Purchased Intangible Assets, Net

[0001193125-13-261334:notes:213]
We conducted
our annual goodwill impairment test during the three months ended
April 26, 2013. Based on this analysis, we determined that
there was no impairment to goodwill. We will continue to monitor
our recorded goodwill for indicators of impairment.

[0001193125-13-261334:notes:214]
Purchased
intangible assets, net are summarized below (in
millions):

[0001193125-13-261334:notes:215]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
|  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |
| Developed technology |  | $ | 312.4 |  |  | $ | (134.9 | ) |  | $ | 177.5 |  |  | $ | 282.1 |  |  | $ | (79.0 | ) |  | $ | 203.1 |  |
| Customer contracts/relationships |  |  | 54.7 |  |  |  | (53.1 | ) |  |  | 1.6 |  |  |  | 59.4 |  |  |  | (32.7 | ) |  |  | 26.7 |  |
| Trademarks and trade names |  |  | 9.9 |  |  |  | (8.9 | ) |  |  | 1.0 |  |  |  | 14.7 |  |  |  | (9.7 | ) |  |  | 5.0 |  |
| Covenants not to compete |  |  | 2.2 |  |  |  | (1.7 | ) |  |  | 0.5 |  |  |  | 2.2 |  |  |  | (1.0 | ) |  |  | 1.2 |  |
| Total purchased intangible assets |  | $ | 379.2 |  |  | $ | (198.6 | ) |  | $ | 180.6 |  |  | $ | 358.4 |  |  | $ | (122.4 | ) |  | $ | 236.0 |  |

[0001193125-13-261334:notes:216]
Amortization
expense for purchased intangible assets is summarized below (in
millions):

[0001193125-13-261334:notes:217]
|  |  | Year Ended |  |  | Statements of Operations Classifications |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |  |
| Developed technology |  | $ | 55.9 |  |  | $ | 55.8 |  |  | $ | 13.3 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 25.2 |  |  |  | 28.1 |  |  |  | 3.0 |  |  | Operating expenses |
| Trademarks and trade names |  |  | 4.0 |  |  |  | 4.2 |  |  |  | 1.2 |  |  | Operating expenses |
| Covenants not to compete |  |  | 0.7 |  |  |  | 0.9 |  |  |  | 0.2 |  |  | Operating expenses |
|  |  | $ | 85.8 |  |  | $ | 89.0 |  |  | $ | 17.7 |  |  |  |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001193125-13-261334:notes:218]
The notional
amount of our outstanding U.S. dollar equivalent foreign currency
exchange forward contracts consisted of the following (in
millions):

[0001193125-13-261334:notes:219]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| To purchase U.S. dollars |  | $ | 108.4 |  |  | $ | 126.6 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| To sell U.S. dollars |  |  | 158.2 |  |  |  | 101.1 |  |
| To purchase U.S. dollars |  |  | 358.4 |  |  |  | 414.1 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-13-261334:notes:220]
The following
customers, each of which is a distributor, accounted for 10% or
more of our net revenues:

[0001193125-13-261334:notes:221]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Arrow Electronics, Inc. |  |  | 19 | % |  |  | 17 | % |  |  | 18 | % |
| Avnet, Inc. |  |  | 15 | % |  |  | 12 | % |  |  | 12 | % |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001193125-13-261334:notes:222]
Impairment
of Long-Lived Assets — We review the carrying values
of long-lived assets whenever events and circumstances, such as
reductions in demand, lower projections of profitability,
significant changes in the manner of our use of acquired assets, or
significant negative industry or economic trends, indicate that the
net book value of an asset may not be recovered through expected
future cash flows from its use and eventual disposition. If this
review indicates that there is an impairment, the impaired asset is
written down to its fair value, which is typically calculated
using: (i) quoted market prices and/or (ii) expected
future cash flows utilizing a discount rate. Our estimates
regarding future anticipated net revenue and cash flows, the
remaining economic life of the products and technologies, or both,
may differ from those used to assess the recoverability of assets.
In that event, impairment charges or shortened useful lives of
certain long-lived assets may be required, resulting in charges to
our consolidated statements of operations when such determinations
are made.


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001193125-13-261334:notes:223]
The following
table summarizes our warranty reserves (in millions):

[0001193125-13-261334:notes:224]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Beginning balance |  | $ | 83.1 |  |  | $ | 40.5 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 17.5 |  |
| Expense accrued during the period |  |  | 94.8 |  |  |  | 67.9 |  |
| Warranty costs incurred |  |  | (60.7 | ) |  |  | (42.8 | ) |
| Ending balance |  | $ | 117.2 |  |  | $ | 83.1 |  |


## us-gaap:IncomeTaxPolicyTextBlock

[0001193125-13-261334:notes:225]
Income
Taxes — Deferred income tax assets and liabilities
are provided for temporary differences that will result in tax
deductions or income in future periods, as well as the future
benefit of tax credit carryforwards. A valuation allowance reduces
tax assets to their estimated realizable value. Tax attributes
related to the exercise of employee stock options are not realized
until they result in a reduction of taxes payable. We do not
include unrealized stock option attributes as components of our
gross deferred tax assets and corresponding valuation allowance
disclosures.

[0001193125-13-261334:notes:226]
Determining the
liability for uncertain tax positions requires us to make
significant estimates and judgments as to whether, and the extent
to which, additional taxes may be due based on potential tax audit
issues in the U.S. and other tax jurisdictions throughout the
world. Our estimates are based on the outcomes of previous audits,
as well as the precedents set in cases in which others have taken
similar tax positions to those taken by us. If we later determine
that our exposure is lower or that the liability is not sufficient
to cover our revised expectations, we adjust the liability and
effect a related change in our tax provision during the period in
which we make such a determination.

[0001193125-13-261334:notes:227]
The accounting
guidance for income taxes prescribes a comprehensive model for how
a company should recognize, measure, present, and disclose in its
financial statements uncertain tax positions that we have taken or
expect to take on a tax return (including a decision whether to
file or not to file a return in a particular jurisdiction). We
recognize the tax liability for uncertain income tax positions on
the income tax return based on the two-step process prescribed in
the interpretation. The first step is to determine whether it is
more likely than not that each income tax position would be
sustained upon audit. The second step is to estimate and measure
the tax benefit as the amount that has a greater than 50%
likelihood of being realized upon ultimate settlement with the tax
authority. Estimating these amounts requires us to determine the
probability of various possible outcomes. We evaluate these
uncertain tax positions on a quarterly basis.

[0001193125-13-261334:notes:228]
Significant
judgment is also required in determining any valuation allowance
recorded against deferred tax assets. In assessing the need for a
valuation allowance, we consider all available evidence, including
past operating results, estimates of future taxable income, and the
feasibility of tax planning strategies. In the event that we change
our determination as to the amount of deferred tax assets that can
be realized, we adjust our valuation allowance with a corresponding
impact to the provision for income taxes in the period in which
such determination is made.


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-13-261334:notes:229]
The effect of
derivative instruments not designated as hedges recognized in other
income, net on our consolidated statements of operations was as
follows (in millions):

[0001193125-13-261334:notes:230]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Derivatives Not Designated as Hedging Instruments |  | Gain (Loss) Recognized into Income |  |
| Foreign exchange forward contracts |  | $ | 6.5 |  |  | $ | 21.0 |  |  | $ | (20.6 | ) |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-13-261334:notes:231]
The
following table summarizes our financial assets and liabilities
measured at fair value on a recurring basis as of April 27,
2012 (in millions):


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-13-261334:notes:232]
13. Income
Taxes

[0001193125-13-261334:notes:233]
Income before
income taxes is as follows (in millions):

[0001193125-13-261334:notes:234]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Domestic |  | $ | (63.8 | ) |  | $ | 211.9 |  |  | $ | 307.6 |  |
| Foreign |  |  | 630.4 |  |  |  | 500.5 |  |  |  | 486.5 |  |
| Total |  | $ | 566.6 |  |  | $ | 712.4 |  |  | $ | 794.1 |  |

[0001193125-13-261334:notes:235]
Domestic income
before taxes is lower than foreign income before taxes due to
significant domestic expenses related to the amortization of
intangibles, stock based compensation and convertible debt
interest.

[0001193125-13-261334:notes:236]
Current and
non-current net deferred tax assets for fiscal 2013 and 2012 are as
follows (in millions):

[0001193125-13-261334:notes:237]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Current deferred tax assets, net |  | $ | 252.7 |  |  | $ | 201.6 |  |
| Non-current deferred tax assets, net |  |  | 200.3 |  |  |  | 203.8 |  |

[0001193125-13-261334:notes:238]
The valuation
allowance increased by $7.4 million and decreased by $13.1
million in fiscal 2013 and 2012, respectively. The $7.4 million
valuation allowance change during fiscal 2013 is attributable to a
corresponding change in deferred tax assets, primarily foreign tax
credit carryforwards in a foreign jurisdiction and state tax credit
carryforwards in certain states. During fiscal 2012, we recorded a
$7.1 million valuation allowance attributable to foreign tax credit
carryforwards in a foreign jurisdiction based on our future
operating plans. The remaining fiscal 2012 change in valuation
allowance was primarily attributable to a corresponding change in
deferred tax assets.

[0001193125-13-261334:notes:239]
As of
April 26, 2013, the federal and state net operating loss
carryforwards were approximately $43.4 million and
$83.5 million, respectively, before applying tax rates for the
respective jurisdictions. The federal and state tax credit
carryforwards were approximately $155.1 million and
$125.6 million, respectively. Certain acquired net operating
loss and credit carryforwards are subject to an annual limitation
under Internal Revenue Code Section 382, but are expected to
be realized with the exception of those which have a valuation
allowance. The federal and state net operating loss carryforwards
and credits will expire in various years from fiscal 2014 through
2033. If realized, $169.5 million, tax effected, of net operating
loss and tax credit carryovers will be recognized as additional
paid-in capital.

[0001193125-13-261334:notes:240]
Of the
$189.6 million of unrecognized tax benefits at April 26,
2013, $134.7 million has been recorded and included in other
long-term liabilities. Unrecognized tax benefits of $118.7 million,
including penalties and interest, would affect our provision for
income taxes if recognized.

[0001193125-13-261334:notes:241]
We recognize
accrued interest and penalties related to unrecognized foreign tax
benefits in the income tax provision. During fiscal 2013, 2012 and
2011, we recognized accrued interest and penalties of approximately
$1.2 million, $0.6 million and $0.2 million, respectively in
the consolidated statements of operations and $2.8 million and $1.6
million, respectively, were recorded on the consolidated balance
sheets as of April 26, 2013 and April 27,
2012.

[0001193125-13-261334:notes:242]
We are subject
to taxation in the United States, various states, and several
foreign jurisdictions.

[0001193125-13-261334:notes:243]
The tax years
that remain subject to examination for our major tax jurisdictions
are shown below:

[0001193125-13-261334:notes:244]
Tax
Years Subject to Examination for Major Tax Jurisdictions at
April 26, 2013

[0001193125-13-261334:notes:245]
| 2005 — 2012 |  | United States — federal income tax |
| 2005 — 2012 |  | United States — state and local income tax |
| 2008 — 2012 |  | Australia |
| 2009 — 2012 |  | Germany |
| 2006 — 2012 |  | India |
| 2006 — 2012 |  | Japan |
| 2009 — 2012 |  | The Netherlands |
| 2007 — 2012 |  | United Kingdom |
| 2007 — 2012 |  | Canada |

[0001193125-13-261334:notes:246]
In addition, we
are effectively subject to federal tax examination adjustments for
tax years ended on or after fiscal 2000, in that we have net
operating loss carryforwards from these years that could be subject
to adjustment, if and when utilized.

[0001193125-13-261334:notes:247]
We are currently
undergoing federal income tax audits in the United States and
several foreign tax jurisdictions. Transfer pricing calculations
are key issues under audits in various jurisdictions, and are often
subject to dispute and appeals. During fiscal 2013 and 2012, we
recorded income tax expense of $0.1 million and $7.3 million,
respectively, in connection with income tax audits. We recorded an
income tax benefit of $21.1 million in connection with income tax
audits concluded in fiscal 2011.

[0001193125-13-261334:notes:248]
In March 2013,
we received a draft Revenue Agent’s Report from the IRS for
our fiscal 2005 through 2007 income tax returns. We are currently
in the process of submitting information to draft a closing
agreement with the IRS for our fiscal 2007 income tax return. The
draft Revenue Agent’s report and the closing agreement will
be reviewed by certain higher authorities within the IRS and Joint
Committee on Taxation. We expect to conclude fiscal 2005 through
2007 IRS audits within the next fiscal year.

[0001193125-13-261334:notes:249]
In February
2012, the IRS commenced an examination of our fiscal 2008 through
2010 income tax returns.

[0001193125-13-261334:notes:250]
We are also
under audit by the California Franchise Tax Board for our fiscal
2007 and 2008 California income tax returns.

[0001193125-13-261334:notes:251]
On
September 17, 2010, the Danish Tax Authorities issued a
decision concluding that distributions declared in 2005 and 2006
from our Danish subsidiary were subject to Danish at-source
dividend withholding tax. We do not believe that our Danish
subsidiary is liable for withholding tax and filed an appeal with
the Danish Tax Tribunal to that effect. On December 19, 2011,
the Danish Tax Tribunal issued a ruling that our Danish subsidiary
was not liable for Danish withholding tax. The Danish tax
examination agency appealed to the Danish High Court in March
2012.

[0001193125-13-261334:notes:252]
During fiscal
2010, we recorded a $28.9 million unrecognized tax benefit to
provide for uncertainty related to the tax treatment of the
termination of our Convertible Note Hedges from a certain
counterparty. The unrecognized tax benefit will reverse in the
first quarter of fiscal 2014 upon the maturity of the Convertible
Notes.

[0001193125-13-261334:notes:253]
We are in
various stages of the examination and appeals process in connection
with tax audits worldwide, and it is difficult to determine when
these examinations will be settled. It is reasonably possible that
over the next twelve-month period, we may experience an increase or
decrease in unrecognized tax benefits. It is not possible to
determine either the magnitude or the range of any increase or
decrease at this time.

[0001193125-13-261334:notes:254]
Network
Appliance Systems India Pvt. Ltd., our Indian subsidiary, received
a tax holiday from the Indian tax authorities attributable to its
call center and research and development activities effective
June 6, 2003. These activities qualify under the Software
Technology Park of India (STPI) incentive for the development and
manufacture of computer software and information technology enabled
services. Under this tax holiday, net taxable income derived from
call center and research and development activities is exempt from
Indian taxation. The income tax holiday expired on March 31,
2011. Other tax and customs benefits remain available. The tax
benefit from the holiday and the impact to earnings per share was
$6.3 million and $0.02, respectively, in fiscal 2011.

[0001193125-13-261334:notes:255]
In April 2010,
our Dutch subsidiary received a favorable tax ruling from the Dutch
tax authorities effective May 1, 2010 that replaces the
previous Dutch tax ruling that expired on April 30, 2010. This
ruling results in both a lower level of earnings subject to tax in
the Netherlands and an extension of the expiration date to
April 30, 2015.

[0001193125-13-261334:notes:256]
As of
April 26, 2013, the amount of accumulated unremitted earnings
from our foreign subsidiaries is approximately $2.5 billion. We
have not provided U.S. income taxes and foreign withholding taxes
on the undistributed earnings of foreign subsidiaries because we
intend to permanently reinvest such earnings outside the U.S. If
these foreign earnings were to be repatriated in the future, the
related U.S. tax liability may be reduced by any foreign income
taxes previously paid on these earnings as well as tax attributes
carryforwards. We estimate the unrecognized deferred tax liability
related to these earnings to be $757.6 million as of April 26,
2013.


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-13-261334:notes:257]
Principles
of Consolidation — The consolidated financial
statements include the Company and its subsidiaries. Intercompany
accounts and transactions are eliminated in
consolidation.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-13-261334:notes:258]
19. Selected
Quarterly Financial Data (Unaudited)

[0001193125-13-261334:notes:259]
Selected
quarterly financial data is as follows (in millions, except per
share amounts):

[0001193125-13-261334:notes:260]
|  |  | Year Ended April 26, 2013 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net revenues |  | $ | 1,444.6 |  |  | $ | 1,541.2 |  |  | $ | 1,630.1 |  |  | $ | 1,716.5 |  |
| Total cost of revenues |  |  | 594.5 |  |  |  | 627.3 |  |  |  | 665.2 |  |  |  | 684.3 |  |
| Gross profit |  |  | 850.1 |  |  |  | 913.9 |  |  |  | 964.9 |  |  |  | 1,032.2 |  |
| Income before income taxes |  |  | 74.2 |  |  |  | 127.7 |  |  |  | 175.8 |  |  |  | 188.9 |  |
| Provision for income taxes |  |  | 10.4 |  |  |  | 18.1 |  |  |  | 17.7 |  |  |  | 15.1 |  |
| Net income |  | $ | 63.8 |  |  | $ | 109.6 |  |  | $ | 158.1 |  |  | $ | 173.8 |  |
| Net income per share, basic |  | $ | 0.17 |  |  | $ | 0.30 |  |  | $ | 0.44 |  |  | $ | 0.48 |  |
| Net income per share, diluted |  | $ | 0.17 |  |  | $ | 0.30 |  |  | $ | 0.43 |  |  | $ | 0.47 |  |

[0001193125-13-261334:notes:261]
|  |  | Year Ended April 27, 2012 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net revenues |  | $ | 1,458.2 |  |  | $ | 1,507.0 |  |  | $ | 1,565.5 |  |  | $ | 1,702.5 |  |
| Total cost of revenues |  |  | 561.3 |  |  |  | 594.0 |  |  |  | 657.0 |  |  |  | 707.5 |  |
| Gross profit |  |  | 896.9 |  |  |  | 913.0 |  |  |  | 908.5 |  |  |  | 995.0 |  |
| Income before income taxes |  |  | 167.1 |  |  |  | 183.9 |  |  |  | 146.9 |  |  |  | 214.5 |  |
| Provision for income taxes |  |  | 27.6 |  |  |  | 18.3 |  |  |  | 27.3 |  |  |  | 33.8 |  |
| Net income |  | $ | 139.5 |  |  | $ | 165.6 |  |  | $ | 119.6 |  |  | $ | 180.7 |  |
| Net income per share, basic |  | $ | 0.38 |  |  | $ | 0.46 |  |  | $ | 0.33 |  |  | $ | 0.50 |  |
| Net income per share, diluted |  | $ | 0.34 |  |  | $ | 0.44 |  |  | $ | 0.32 |  |  | $ | 0.47 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-13-261334:notes:262]
As of
April 26, 2013, our aggregate future principal debt maturities
are as follows (in millions):

[0001193125-13-261334:notes:263]
| Fiscal Year |  | Amount |  |
| 2014 |  | $ | 1,264.9 |  |
| 2015 |  |  | 0.0 |  |
| 2016 |  |  | 0.0 |  |
| 2017 |  |  | 0.0 |  |
| 2018 |  |  | 750.0 |  |
| Thereafter |  |  | 250.0 |  |
| Total |  | $ | 2,264.9 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-13-261334:notes:264]
10. Financing
Arrangements

[0001193125-13-261334:notes:265]
Long-term
Debt

[0001193125-13-261334:notes:266]
The following
table summarizes the carrying value of our long-term debt (in
millions):

[0001193125-13-261334:notes:267]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 0.0 |  |  |  | N/A |  |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 0.0 |  |  |  | N/A |  |
| 1.75% Convertible Notes Due 2013 |  |  | 1,264.9 |  |  |  | 6.31 | % |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total |  |  | 2,264.9 |  |  |  |  |  |  |  | 1,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (12.5 | ) |  |  |  |  |  |  | (62.6 | ) |  |  |  |  |
| Total |  |  | 2,252.4 |  |  |  |  |  |  |  | 1,202.3 |  |  |  |  |  |
| Less: Current portion |  |  | (1,257.8 | ) |  |  |  |  |  |  | (1,202.3 | ) |  |  |  |  |
| Total long-term debt |  | $ | 994.6 |  |  |  |  |  |  | $ | 0.0 |  |  |  |  |  |

[0001193125-13-261334:notes:268]
2.00% Senior Notes due 2017 and 3.25% Senior Notes
due 2022

[0001193125-13-261334:notes:269]
In December
2012, we issued $750.0 million principal amount of 2.00% Senior
Notes due on December 15, 2017 and $250.0 million principal
amount of 3.25% Senior Notes due on December 15, 2022. The
proceeds received were net of debt discounts of $5.8 million and
issuance costs of $6.9 million, both of which are amortized as
additional interest expense over the respective terms of the Senior
Notes using the effective interest method. The Senior Notes are
unsecured, unsubordinated obligations, which pay interest
semi-annually on June 15 and December 15 and rank equally
in right of payment with our other existing and future senior
unsecured indebtedness, including the Convertible Notes. Interest
expense associated with the Senior Notes was $9.4 million for the
year ended April 26, 2013. The proceeds from the Senior Notes
are available for general corporate purposes, including repayment
of certain indebtedness, capital expenditures, possible stock
repurchases, working capital and potential acquisitions and
strategic transactions.

[0001193125-13-261334:notes:270]
We may redeem
the Senior Notes in whole or in part, at any time at our option at
specified redemption prices. In addition, upon the occurrence of
certain change of control triggering events, we may be required to
repurchase the Senior Notes at 101% of their aggregate principal
amount, plus accrued and unpaid interest to the date of repurchase.
The Senior Notes also include covenants that limit our ability to
incur debt secured by liens on assets or on shares of stock or
indebtedness of our subsidiaries; to engage in sale and lease-back
transactions; and to consolidate, merge or sell all or
substantially all of our assets. As of April 26, 2013, we were
in compliance with all covenants associated with the Senior
Notes.

[0001193125-13-261334:notes:271]
1.75% Convertible Senior Notes due 2013

[0001193125-13-261334:notes:272]
On
June 10, 2008, we issued $1,265.0 million aggregate
principal amount of the Convertible Notes, with a maturity date of
June 1, 2013 as described below. The Convertible Notes are
unsecured, unsubordinated obligations of the Company, which pay
interest in cash semi-annually at a rate of 1.75% per annum.
Prior to maturity, the Convertible Notes may be converted based on
an initial conversion rate of 31.40 shares of common stock per
$1,000 principal amount of Convertible Notes (which represents an
initial effective conversion price of the Convertible Notes of
$31.85 per share). The Convertible Notes are not redeemable by us
prior to the maturity date.

[0001193125-13-261334:notes:273]
Prior to
March 1, 2013, the holders of the Convertible Notes may have
converted their Convertible Notes until the close of business on
the scheduled trading day immediately preceding the maturity date
if during any calendar quarter (and only during such calendar
quarter) the last reported sale price of our common stock for 20 or
more trading days in a period of 30 consecutive trading days ending
on the last trading day of the immediately preceding calendar
quarter exceeds 130% of the applicable conversion price in effect
for the Convertible Notes on the last trading day of such
immediately preceding calendar quarter; or upon other conditions
set forth in the indenture for the Convertible Notes. On or after
March 1, 2013, until the scheduled trading day immediately
preceding the maturity date, holders of the Convertible Notes may
be converted the Convertible Notes regardless of the foregoing
conditions.

[0001193125-13-261334:notes:274]
Our common
stock price exceeded the conversion threshold for the Convertible
Notes for at least 20 trading days during the 30 consecutive
trading days ended March 31, 2012. Accordingly, as of
April 27, 2012, the Convertible Notes were convertible at the
option of the holders and, therefore, the carrying value of the
Convertible Notes was classified as current portion of long-term
debt. Since the Convertible Notes were convertible at the option of
the holders and the principal amount was payable in cash, the
difference between the principal amount and the carrying value of
the Convertible Notes was reflected as equity on our consolidated
balance sheet as of April 27, 2012.

[0001193125-13-261334:notes:275]
Upon
conversion, a holder will receive cash in an amount equal to the
lesser of the conversion value and the principal amount of the
Convertible Notes, and shares of our common stock for any
conversion value in excess of the principal amount of the
Convertible Notes, if any. As of April 26, 2013, shares issued
related to the Convertible Notes were minimal. Based on the closing
price of our common stock of $34.87 on April 26, 2013, the
if-converted value of our Convertible Notes exceeds their principal
amount by approximately $120.1 million. See Note 18 regarding
the settlement of our Convertible Notes in June 2013.

[0001193125-13-261334:notes:276]
We separately
account for the liability and equity components of the Convertible
Notes. The initial debt component of the Convertible Notes was
valued at $1,017.0 million based on the contractual cash flows
discounted at an appropriate comparable market non-convertible debt
borrowing rate at the date of issuance of 6.31%, with the equity
component representing the residual amount of the proceeds of
$248.0 million which was recorded as a debt discount. Issuance
costs were allocated pro-rata based on the relative initial
carrying amounts of the debt and equity components. As a result,
$5.2 million of the issuance costs was allocated to the equity
component of the Convertible Notes, and $21.4 million of the
issuance costs remained classified as other non-current assets. The
debt discount and the issuance costs allocated to the debt
component are amortized as additional interest expense over the
term of the Convertible Notes using the effective interest method.
As of April 26, 2013 and April 27, 2012, the aggregate of
the mezzanine and permanent equity component of the Convertible
Notes was $244.9 million.

[0001193125-13-261334:notes:277]
Convertible
Note Hedges and Warrants

[0001193125-13-261334:notes:278]
Concurrent with
the issuance of the Convertible Notes, we purchased Convertible
Note hedges and sold warrants. The separate Convertible Note hedge
and warrant transactions are structured to reduce the potential
future economic dilution associated with the conversion of the
Convertible Notes.

[0001193125-13-261334:notes:279]
|  | • |  | Convertible Note Hedges: As of April 26, 2013 and April 27, 2012, we had arrangements with counterparties to buy up to approximately 31.8 million shares of our common stock, subject to anti-dilution adjustments, at a price of $31.85 per share, subject to adjustment. The Convertible Note hedge transactions expire at the earlier of (1) the last day on which any Convertible Notes remain outstanding or (2) the scheduled trading day immediately preceding the maturity date of the Convertible Notes. Upon exercise of the Convertible Note hedges, we have the option to receive cash or shares of our common stock equal to the difference between the then market price and the strike price of the Convertible Note hedges. See Note 18 regarding the exercise of our Convertible Note hedges in June 2013. |

[0001193125-13-261334:notes:280]
|  | • |  | Warrants: As of April 26, 2013 and April 27, 2012, we had outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |

[0001193125-13-261334:notes:281]
As of
April 26, 2013, we were subject to potential dilution on the
approximately 20% unhedged portion of our Convertible Notes upon
conversion, if on the date of conversion, the per-share market
price of our common stock exceeded the conversion price of $31.85.
As of April 26, 2013, we received a minimal number of shares
related to the Convertible Note hedge transactions.

[0001193125-13-261334:notes:282]
Interest
Expense on Convertible Notes

[0001193125-13-261334:notes:283]
The following
table presents the amount of interest expense recognized related to
the Convertible Notes (in millions):

[0001193125-13-261334:notes:284]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Contractual coupon interest expense |  | $ | 22.0 |  |  | $ | 22.0 |  |  | $ | 22.1 |  |
| Amortization of debt discount |  |  | 55.5 |  |  |  | 52.0 |  |  |  | 48.9 |  |
| Amortization of debt issuance costs |  |  | 4.8 |  |  |  | 4.5 |  |  |  | 4.2 |  |
| Less capitalized interest |  |  | (1.1 | ) |  |  | (5.0 | ) |  |  | 0.0 |  |
| Total interest expense related to Convertible Notes |  | $ | 81.2 |  |  | $ | 73.5 |  |  | $ | 75.2 |  |

[0001193125-13-261334:notes:285]
The following
table reflects the remaining debt discount related to the
Convertible Notes (in millions):

[0001193125-13-261334:notes:286]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Unamortized discount |  | $ | 7.1 |  |  | $ | 62.6 |  |

[0001193125-13-261334:notes:287]
Debt
Maturities

[0001193125-13-261334:notes:288]
Credit
Facility

[0001193125-13-261334:notes:289]
In December
2012, we entered into a credit agreement with a syndicated group of
lenders that provides for an unsecured $250.0 million five-year
revolving credit facility that is comprised of revolving loans,
Eurocurrency loans and/or swingline loans. The credit facility
includes a $100.0 million foreign currency sub-facility, a $50.0
million letter of credit sub-facility and a $10.0 million swingline
sub-facility available on same-day notice. Available borrowings
under the credit facility are reduced by the amount of any
outstanding borrowings on the sub-facilities. We may also, subject
to certain requirements, request an increase in the facility up
to an additional $100.0 million and request two additional
one-year extensions, subject to certain conditions. The proceeds
from the facility may be used by us for general corporate
purposes.

[0001193125-13-261334:notes:290]
Borrowings
under the facility, except for swingline loans, accrue interest in
arrears at an alternate base rate as defined in the credit
agreement or, at our option, an adjusted London Interbank Offered
Rate (LIBOR) plus in each case, a spread (based on our public debt
ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline
borrowings accrue interest at an alternate base rate. In addition,
we are required to pay fees to maintain the credit facility,
whether or not we have outstanding borrowings. The facility
terminates on December 21, 2017 if no extensions have been
requested and contains financial covenants requiring us to maintain
a maximum leverage ratio of not more than 3.0:1.0 and a minimum
interest coverage ratio of not less than 3.5:1.0. The facility
contains customary affirmative and negative covenants, including
covenants that limit our ability to incur debt secured by liens on
assets or indebtedness of our subsidiaries and to consolidate,
merge or sell all or substantially all of our assets. As of
April 26, 2013, no borrowings were outstanding under the
facility and we were in compliance with all covenants associated
with the facility.

[0001193125-13-261334:notes:291]
Other
Long-Term Financing Arrangements

[0001193125-13-261334:notes:292]
The following
presents the amounts due under other long-term financing
arrangements (in millions):

[0001193125-13-261334:notes:293]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 5.2 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.6 |  |  |  | 3.5 |  |
| Total |  | $ | 10.8 |  |  | $ | 12.6 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-13-261334:notes:294]
17. Commitments and
Contingencies

[0001193125-13-261334:notes:295]
Operating
Leases — We lease office space in several
U.S. locations. Outside the United States, larger leased sites
include sites in the Netherlands, Australia, China, France,
Germany, India, Japan, Singapore and the United Kingdom. We also
lease equipment and vehicles. During fiscal 2013, we terminated all
of our remaining synthetic lease arrangements.

[0001193125-13-261334:notes:296]
Future annual
minimum lease payments under all non-cancelable operating leases
with an initial term in excess of one year as of April 26,
2013 are as follows (in millions):

[0001193125-13-261334:notes:297]
|  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | 2018 |  |  | Thereafter |  |  | Total |  |
| Office operating lease payments |  | $ | 40.6 |  |  | $ | 38.8 |  |  | $ | 35.1 |  |  | $ | 18.3 |  |  | $ | 11.6 |  |  | $ | 27.2 |  |  | $ | 171.6 |  |
| Equipment operating lease payments |  |  | 25.7 |  |  |  | 15.7 |  |  |  | 8.7 |  |  |  | 2.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 52.1 |  |
| Total lease commitments |  | $ | 66.3 |  |  | $ | 54.5 |  |  | $ | 43.8 |  |  | $ | 20.3 |  |  | $ | 11.6 |  |  | $ | 27.2 |  |  | $ | 223.7 |  |

[0001193125-13-261334:notes:298]
Purchase
Orders and Other Commitments

[0001193125-13-261334:notes:299]
In the normal
course of business we make commitments to our third-party contract
manufacturers, to manage manufacturer lead times and meet product
forecasts, and to other parties, to purchase various key components
used in the manufacture of our products. We establish accruals for
estimated losses on purchased components to the extent we believe
it is probable that such components will not be utilized in future
operations. To the extent that such forecasts are not achieved, our
commitments and associated accruals may change. As of
April 26, 2013, we had $235.4 million in non-cancelable
purchase commitments with our contract manufacturers. In addition,
we recorded a liability for firm, non-cancelable and unconditional
purchase commitments with contract manufacturers for quantities in
excess of our future demand forecasts through a charge to cost of
product sales. As of April 26, 2013 and April 27, 2012,
such liability amounted to $9.5 million and $3.3 million,
respectively, and is included in other current liabilities in the
consolidated balance sheets.

[0001193125-13-261334:notes:300]
In addition to
commitments with contract manufacturers and component suppliers, we
have open purchase orders and contractual obligations associated
with our ordinary course business for which we have not received
goods or services. As of April 26, 2013, we had $86.1 million
in capital purchase commitments and $146.6 million in other
purchase commitments.

[0001193125-13-261334:notes:301]
During the
ordinary course of business, we provide standby letters of credit
or other guarantee instruments to third parties as required for
certain transactions initiated either by us or our subsidiaries. As
of April 26, 2013, our financial guarantees of
$10.1 million that were not recorded on our consolidated
balance sheets consisted of standby letters of credit related to
workers’ compensation, a customs guarantee, a corporate
credit card program, foreign rent guarantees and surety bonds,
which were primarily related to self-insurance.

[0001193125-13-261334:notes:302]
Product
Warranties

[0001193125-13-261334:notes:303]
We provide
customers a warranty on software of ninety days to five years and a
warranty on hardware of one to five years. The following table
summarizes our warranty reserves (in millions):

[0001193125-13-261334:notes:304]
Financing
Guarantees

[0001193125-13-261334:notes:305]
Some of our
customers have entered into recourse and non-recourse financing
leasing arrangements using third-party financing companies, and in
some situations, we enter into customer financing arrangements for
our products and services that are contemporaneously sold on a
recourse or non-recourse basis to third-party financing companies.
Under the terms of recourse leases, which are generally three years
or less, we remain liable for the aggregate unpaid remaining lease
payments to the third-party leasing companies in the event of
end-user customer default. These arrangements are generally
collateralized by a security interest in the underlying assets.
Under the terms of the nonrecourse leases, we do not have any
continuing obligations or liabilities to the third-party financing
companies. Where we provide a guarantee for recourse leases, we
defer revenues subject to the industry-specific software revenue
recognition guidance, and recognize revenues for non-software
deliverables in accordance with our multiple deliverable revenue
arrangement policy. In connection with certain recourse financing
arrangements, we receive advance payments associated with
undelivered elements that are subject to customer refund rights. We
defer revenue associated with these advance payments until the
related refund rights expire and we perform the
services.

[0001193125-13-261334:notes:306]
The aggregate
amount of financing guarantees representing the total maximum
potential future payments under financing arrangements with third
parties, and the related deferred revenue are summarized as follows
(in millions):

[0001193125-13-261334:notes:307]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Maximum guaranteed payment contingencies |  | $ | 182.4 |  |  | $ | 169.0 |  |
| Deferred revenue associated with financing guarantees |  |  | (168.6 | ) |  |  | (149.9 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 13.8 |  |  | $ | 19.1 |  |

[0001193125-13-261334:notes:308]
To date, we
have not experienced material losses under our lease financing
programs or other financing arrangements.

[0001193125-13-261334:notes:309]
Indemnification Agreements

[0001193125-13-261334:notes:310]
We enter into
standard indemnification agreements in the ordinary course of
business. Pursuant to these agreements, we agree to defend and
indemnify other parties, primarily our customers or business
partners or subcontractors, for damages and reasonable costs
incurred in any suit or claim brought against them alleging that
our products sold to them infringe any U.S. patent, copyright,
trade secret, or similar right. If a product becomes the subject of
an infringement claim, we may, at our option: (i) replace the
product with another non-infringing product that provides
substantially similar performance; (ii) modify the infringing
product so that it no longer infringes but remains functionally
equivalent; (iii) obtain the right for the customer to
continue using the product at our expense and for the reseller to
continue selling the product; (iv) take back the infringing
product and refund to the customer the purchase price paid less
depreciation amortized on a straight-line basis. We have not been
required to make material payments pursuant to these provisions
historically. We have not recorded any liability at April 26,
2013 related to these guarantees since the maximum amount of
potential future payments under such guarantees, indemnities and
warranties is not determinable, other than as described
above.

[0001193125-13-261334:notes:311]
Legal
Contingencies

[0001193125-13-261334:notes:312]
When a loss is
considered probable and reasonably estimable, we record a liability
in the amount of our best estimate for the ultimate loss. However,
the likelihood of a loss with respect to a particular contingency
is often difficult to predict and determining a meaningful estimate
of the loss or a range of loss may not be practicable based on the
information available and the potential effect of future events and
decisions by third parties that will determine the ultimate
resolution of the contingency.

[0001193125-13-261334:notes:313]
We are subject
to various legal proceedings and claims that arise in the normal
course of business. No accrual has been recorded as of
April 26, 2013 related to such matters as they are not
probable and/or reasonably estimable.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-13-261334:notes:314]
15. Segment,
Geographic, and Significant Customer Information

[0001193125-13-261334:notes:315]
We operate in
one industry segment: the design, manufacturing, marketing, and
technical support of high-performance networked storage solutions.
We conduct business globally, and our sales and support activities
are managed on a geographic basis. Our management reviews financial
information presented on a consolidated basis, accompanied by
disaggregated information it receives from its internal management
system about revenues by geographic region, based on the location
from which the customer relationship is managed, for purposes of
allocating resources and evaluating financial performance. We do
not allocate costs of revenues, research and development, sales and
marketing, or general and administrative expenses to our geographic
regions in this internal management system because management does
not review operations or operating results, or make planning
decisions, below the consolidated entity level.

[0001193125-13-261334:notes:316]
Americas
revenues consist of Americas commercial and U.S. public sector
markets. Sales to customers inside the United States accounted for
$3,152.7 million, $3,027.8 million and $2,593.2 million of Americas
net revenues during fiscal 2013, 2012 and 2011, respectively. Sales
to Germany accounted for $626.8 million, $632.6 million and $618.0
million during fiscal 2013, 2012 and 2011, respectively. No other
foreign country accounted for 10% or more of our net
revenues.

[0001193125-13-261334:notes:317]
The majority of
our assets, excluding cash, cash equivalents, restricted cash,
investments and accounts receivable, were attributable to our
domestic operations. The following table presents cash, cash
equivalents, restricted cash and investments held in the United
States and internationally in various foreign subsidiaries (in
millions):

[0001193125-13-261334:notes:318]
With the
exception of property and equipment, we do not identify or allocate
our long-lived assets by geographic area. The following table
presents property and equipment information for geographic areas
based on the physical location of the assets (in
millions):


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-13-261334:notes:319]
12. Derivatives and
Hedging Activities

[0001193125-13-261334:notes:320]
We use
derivative instruments to manage exposures to foreign currency
risk. Our primary objective in holding derivatives is to reduce the
volatility of earnings and cash flows associated with changes in
foreign currency exchange rates. The program is not designated for
trading or speculative purposes. Our derivatives expose us to
credit risk to the extent that the counterparties may be unable to
meet the terms of the agreement. We seek to mitigate such risk by
limiting our counterparties to major financial institutions. In
addition, the potential risk of loss with any one counterparty
resulting from this type of credit risk is monitored on an ongoing
basis. We also have in place master netting arrangements to
mitigate the credit risk of our counterparties and to potentially
reduce our losses due to counterparty nonperformance. All contracts
have a maturity of less than six months.

[0001193125-13-261334:notes:321]
Our major
foreign currency exchange exposures and related hedging programs
are described below:

[0001193125-13-261334:notes:322]
Balance
Sheet. We utilize foreign currency exchange forward and
option contracts to hedge against the short-term impact of foreign
currency exchange rate fluctuations related to certain
foreign-currency-denominated monetary assets and liabilities,
primarily intercompany receivables and payables. These foreign
currency exchange forward and option contracts are not designated
as hedging instruments and do not subject us to material balance
sheet risk due to exchange rate movements because the gains and
losses on these contracts are intended to offset the gains and
losses in the underlying foreign-currency-denominated monetary
assets and liabilities being hedged and the net amount is included
in earnings.

[0001193125-13-261334:notes:323]
Forecasted
Transactions. We use foreign currency exchange forward
contracts to hedge foreign currency exchange exposures related to
forecasted sales transactions denominated in certain foreign
currencies. These contracts are designated and qualify as cash flow
hedges and in general, closely match the underlying forecasted
transactions in duration. The contracts are carried on the
consolidated balance sheets at fair value, and the effective
portion of the contracts’ gains and losses resulting from
changes in fair value is recorded in AOCI until the forecasted
transaction is recognized in the consolidated statements of
operations. When the forecasted transactions occur, we reclassify
the related gains or losses on the cash flow hedges into net
revenues. If the underlying forecasted transactions do not occur,
or it becomes probable that they will not occur, within the defined
hedge period, the gains or losses on the related cash flow hedges
are reclassified from AOCI and recognized immediately in earnings.
We measure the effectiveness of hedges of forecasted transactions
on a monthly basis by comparing the fair values of the designated
foreign currency exchange forward purchase contracts with the fair
values of the forecasted transactions. Any ineffective portion of
the derivative hedging gain or loss, as well as changes in the fair
value of the derivative’s time value (which are excluded from
the assessment of hedge effectiveness), is recognized in current
period earnings.

[0001193125-13-261334:notes:324]
Over the next
12 months, we expect an immaterial amount of derivative losses
recorded in AOCI as of April 26, 2013 will be reclassified
into net revenues. The maximum length of time over which forecasted
foreign currency denominated revenues are hedged is six
months.

[0001193125-13-261334:notes:325]
The fair value
of our short-term foreign currency derivative instruments was not
material as of April 26, 2013 and April 27, 2012. We did
not recognize any gains or losses in earnings due to hedge
ineffectiveness for any period presented.

[0001193125-13-261334:notes:326]
The effect of
derivative instruments designated as cash flow hedges recognized in
net revenues on our consolidated statements of operations is
presented in the consolidated statements of comprehensive
income.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001193125-13-261334:notes:327]
Fair Value
Measurements and Impairments — All of our
available-for-sale investments are subject to periodic impairment
review. Investments are considered to be impaired when a decline in
fair value is judged to be other-than-temporary. This determination
requires significant judgment.

[0001193125-13-261334:notes:328]
For short-term
investments, impairment is determined based upon the specific facts
and circumstances present at the time, including factors such as
current economic and market conditions, the credit rating of the
security’s issuer, the length of time an investment’s
fair value has been below the carrying value, the extent to which
fair value is below cost, and our ability and intent to hold
investments for a period of time sufficient to allow for
anticipated recovery in value. If an investment’s decline in
fair value is caused by factors other than changes in interest
rates, it is deemed to be other-than-temporary and we reduce its
carrying value to its estimated fair value, as determined based on
quoted market prices, liquidation values or other metrics. Declines
in value judged to be other-than-temporary, if any, are recorded in
our consolidated statements of operations as incurred.

[0001193125-13-261334:notes:329]
For long-term
investments, such as auction rate securities (ARS), impairment is
determined based on fair value and marketability of these
investments. The valuation models used to estimate fair value
include numerous assumptions such as assessments of the underlying
structure of each security, expected cash flows, discount rates,
trading activity in the secondary market for similar securities,
credit ratings, workout periods, and overall capital market
liquidity.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001193125-13-261334:notes:330]
Foreign
Currency Translation — For international
subsidiaries whose functional currency is the local currency, gains
and losses resulting from translation of these foreign currency
financial statements into U.S. dollars are recorded in AOCI.
For subsidiaries where the functional currency is the
U.S. dollar, gains and losses resulting from the process of
remeasuring foreign currency financial statements into
U.S. dollars are included in other income (expense),
net.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-13-261334:notes:331]
2. Significant
Accounting Policies

[0001193125-13-261334:notes:332]
Fiscal
Year — Our fiscal year is reported on a 52- or
53-week year ending on the last Friday in April. Fiscal 2013, 2012
and 2011 were each 52-week years.

[0001193125-13-261334:notes:333]
Use of
Estimates — The preparation of the consolidated
financial statements in conformity with accounting principles
generally accepted in the United States of America (GAAP) requires
management to make estimates and assumptions that affect the
reported amounts of assets and liabilities and disclosure of
contingent assets and liabilities at the date of the financial
statements and the reported amounts of revenues and expenses during
the reporting periods. Such estimates include, but are not limited
to, revenue recognition, reserves and allowances; inventory
valuation and purchase order accruals; valuation of goodwill and
intangibles; restructuring reserves; product warranties; employee
benefit accruals; stock-based compensation; loss contingencies;
investment impairments; income taxes and fair value measurements.
Actual results could differ materially from those
estimates.

[0001193125-13-261334:notes:334]
Financial
Instruments — For certain financial instruments,
including accounts receivable and accounts payable, the carrying
amounts approximate their fair value due to their relatively short
maturities. The following methods were used to estimate the fair
value of each class of financial instruments for which it is
practicable to estimate that value.

[0001193125-13-261334:notes:335]
Short-Term
Investments — Short-term investments consist of
marketable debt or equity securities which are classified as
available-for-sale and are recognized at fair value. The
determination of fair value is further detailed in Note 9 of
the accompanying consolidated financial statements. We regularly
review our investment portfolio to identify and evaluate
investments that have indicators of possible impairment. Factors
considered in determining whether a loss is other-than-temporary
include, but are not limited to: the length of time and extent a
security’s fair value has been below its cost, the financial
condition and near-term prospects of the investee, the credit
quality of the security’s issuer, likelihood of recovery and
our intent and ability to hold the security for a period of time
sufficient to allow for any anticipated recovery in value. For our
debt instruments, we also evaluate whether we have the intent to
sell the security or it is more likely than not that we will be
required to sell the security before recovery of its cost basis. We
classify our investments as current or noncurrent based on the
nature of the investments and their availability for use in current
operations.

[0001193125-13-261334:notes:336]
Unrealized
gains and temporary losses, net of related taxes, are included in
accumulated other comprehensive income (loss) (AOCI). Upon
realization, those amounts are reclassified from AOCI to results of
operations. The amortization of premiums and discounts on the
investments are included in our results of operations.
Other-than-temporary impairments on available-for-sale debt
securities are determined to be either credit losses or losses due
to other factors. Impairments due to credit losses are recognized
in our results of operations and impairments due to other losses
are included in AOCI. Realized gains or losses on our short-term
investments are calculated based on the specific identification
method.

[0001193125-13-261334:notes:337]
Software
Development Costs — The costs for the development of
new software products and substantial enhancements to existing
software products are expensed as incurred until technological
feasibility has been established, at which time any additional
costs would be capitalized in accordance with the accounting
guidance for software. Because our current process for developing
software is essentially completed concurrently with the
establishment of technological feasibility, which occurs upon the
completion of a working model, no costs have been capitalized for
any of the periods presented.

[0001193125-13-261334:notes:338]
Internal-Use
Software Development Costs — We capitalize qualifying
costs, which are incurred during the application development stage,
for computer software developed or obtained for internal-use and
amortize them over the software’s estimated useful
life.

[0001193125-13-261334:notes:339]
Business
Combinations — We recognize identifiable assets acquired
and liabilities assumed at their acquisition date fair values.
Goodwill as of the acquisition date is measured as the excess of
consideration transferred over the net of the acquisition date fair
values of the assets acquired and the liabilities assumed. While we
use our best estimates and assumptions as a part of the purchase
price allocation process to accurately value assets acquired and
liabilities assumed at the acquisition date, our estimates are
inherently uncertain and subject to refinement. As a result, during
the measurement period, which may be up to one year from the
acquisition date, we record adjustments to the assets acquired and
liabilities assumed, with the corresponding offset to goodwill to
the extent that we identify adjustments to the preliminary purchase
price allocation. Upon the conclusion of the measurement period or
final determination of the values of assets acquired or liabilities
assumed, whichever comes first, any subsequent adjustments are
recorded to our consolidated statements of operations.

[0001193125-13-261334:notes:340]
Goodwill and
Purchased Intangible Assets — Goodwill is recorded
when the consideration paid for an acquisition exceeds the fair
value of net tangible and intangible assets acquired. Purchased
intangible assets are amortized on a straight-line basis over their
economic lives of three to six years for developed technology, two
to eight years for customer contracts/relationships, two to three
years for covenants not to compete and two to seven years for
trademarks and trade names as we believe this method most closely
reflects the pattern in which the economic benefits of the assets
will be consumed.

[0001193125-13-261334:notes:341]
Goodwill is
measured and tested for impairment on an annual basis in the fourth
quarter of our fiscal year or more frequently if we believe
indicators of impairment exist. Triggering events for impairment
reviews may be indicators such as adverse industry or economic
trends, restructuring actions, lower projections of profitability,
or a sustained decline in our market capitalization. The
performance of the test involves a two-step process. The first step
requires comparing the fair value of the each of our reporting
units to its net book value, including goodwill. We have three
reporting units, the fair values of which are determined based on
an allocation of our entity level market capitalization, as
determined through quoted market prices. A potential impairment
exists if the fair value of the reporting unit is lower than its
net book value. The second step of the process is only performed if
a potential impairment exists, and it involves determining the
difference between the fair value of the reporting unit’s net
assets other than goodwill to the fair value of the reporting unit
and if the difference is less than the net book value of goodwill,
an impairment exists and is recorded. We have not been required to
perform this second step of the process because the fair value of
our reporting units have exceeded their net book value for fiscal
2013, 2012 and 2011.

[0001193125-13-261334:notes:342]
Sales and
Value Added Taxes — Taxes collected from customers
and remitted to governmental authorities are presented on a net
basis in the accompanying consolidated statements of
operations.

[0001193125-13-261334:notes:343]
Product
Warranties — Estimated future hardware and software
warranty costs are recorded as a cost of product revenues when the
related revenue is recognized, based on historical and projected
warranty claim rates, historical and projected cost-per-claim and
knowledge of specific product failures that are outside our typical
experience. Factors that affect our warranty liability include the
number of installed units subject to warranty protection, product
failure rates, estimated material costs, estimated distribution
costs and estimated labor costs. We assess the adequacy of our
warranty accrual each quarter and adjust the amount as considered
necessary.

[0001193125-13-261334:notes:344]
Benefit
Plans — We have a postretirement health care plan
and various international defined benefit plans for certain of our
employees. We record actuarial gains and losses within AOCI and
amortize net gains or losses in excess of 10 percent of the greater
of the market value of plan assets or the plans’ projected
benefit obligation on a straight-line basis over the remaining
estimated service life of plan participants. The measurement date
for all defined benefit plans is our fiscal year end.

[0001193125-13-261334:notes:345]
Stock-Based
Compensation — We measure and recognize stock-based
compensation for all stock-based awards, including employee stock
options, restricted stock units (RSUs) and rights to purchase
shares under our employee stock purchase plan (ESPP), based on
their estimated fair value, and recognize the costs in our
financial statements using the single option straight-line approach
over the requisite service period for the entire award.

[0001193125-13-261334:notes:346]
The fair value
of employee RSUs is equal to the market value of our common stock
on the grant date of the award. Calculating the fair value of
employee stock options and the rights to purchase shares under the
ESPP requires estimates and significant judgment. The fair value of
each award is estimated on the grant date using the Black-Scholes
option pricing model, and is not remeasured as a result of
subsequent stock price fluctuations. Option-pricing models require
the input of highly subjective assumptions, including the expected
term of awards and the stock price volatility of the underlying
stock of such awards. Our expected term assumption is based
primarily on historical exercise and post-vesting forfeiture
experience. Effective fiscal 2013, our stock price volatility
assumption is based on a combination of our historical and implied
volatility, whereas prior to fiscal 2013, we solely used implied
volatility. The change in volatility assumption methodology was
based upon our assessment that blended volatility is more
representative of our future stock price trends as it weighs in the
longer term historical volatility with the near term future implied
volatility. Such change was not material to our fiscal 2013
consolidated financial statements.

[0001193125-13-261334:notes:347]
In addition,
the Black-Scholes option pricing model requires risk-free interest
rates and expected dividends. The risk-free interest rates are
based upon United States Treasury bills with equivalent expected
terms, and the expected dividends are based on our history and
expected dividend payouts.

[0001193125-13-261334:notes:348]
We estimate the
number of stock-based awards that will be forfeited due to employee
turnover. Our forfeiture assumption is primarily based on
historical experience.

[0001193125-13-261334:notes:349]
In the event of
a modification of stock-based awards, if the requisite service
period of the modified award is longer than the requisite service
period of the original award and, both before and after the
modification, it is probable that the awards will vest, we
recognize the unrecognized compensation cost remaining from the
original award plus the incremental compensation cost, if any, as a
result of a modification in its entirety over the remaining portion
of the requisite service period of the modified award.

[0001193125-13-261334:notes:350]
Net Income
per Share — Basic net income per share is computed
by dividing income available to common stockholders by the
weighted-average number of common shares outstanding. Diluted net
income per share is computed giving effect to all dilutive
potential shares that were outstanding during the period. Dilutive
potential common shares consist of common shares issuable upon
exercise of stock options, RSUs, ESPP shares, warrants and assumed
conversion of our 1.75% Convertible Senior Notes due 2013 (the
Convertible Notes). Repurchased shares that are held as treasury
stock are excluded from the outstanding shares.

[0001193125-13-261334:notes:351]
Treasury
Stock — We account for treasury stock under the cost
method. If treasury stock is re-issued at a price higher than its
cost, the difference is recorded as a component of additional
paid-in capital on our consolidated balance sheets. If treasury
stock is re-issued at a price lower than its cost, the difference
is recorded as a component of additional paid-in-capital to the
extent that there are gains to offset the losses. If there are no
treasury stock gains in additional paid-in-capital, the losses upon
re-issuance of treasury stock are recorded as a component of
retained earnings on our consolidated balance sheets. Upon the
retirement of treasury stock, we allocate the value of treasury
shares between additional paid-in capital and retained
earnings.
