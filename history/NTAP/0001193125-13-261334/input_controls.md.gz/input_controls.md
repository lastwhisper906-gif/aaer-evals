# NTAP 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001193125-13-261334:item_9a:1]
| Item 9A. | Controls and Procedures |

[0001193125-13-261334:item_9a:2]
(a) Evaluation of Disclosure Controls and Procedures

[0001193125-13-261334:item_9a:3]
The phrase
“disclosure controls and procedures” refers to controls and procedures designed to ensure that information required to be disclosed in our reports filed or submitted under the Securities Exchange Act of 1934, as amended (the Exchange Act),
such as this Annual Report on Form 10-K, is recorded, processed, summarized and reported within the time periods specified in the rules and forms of the U.S. Securities and Exchange Commission (SEC). Disclosure controls and procedures are also
designed to ensure that such information is accumulated and communicated to our management, including our CEO and CFO, as appropriate to allow timely decisions regarding required disclosure.

[0001193125-13-261334:item_9a:4]
Under the supervision and with the participation of our management, including our CEO and CFO, we conducted an evaluation of the
effectiveness of the design and operation of our disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, as of April 26, 2013, the end of the fiscal period covered by this Annual Report on
Form 10-K (the Evaluation Date). Based on this evaluation, our CEO and CFO concluded as of the Evaluation Date that our disclosure controls and procedures were effective such that the information required to be disclosed in our SEC reports
(i) is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms and (ii) is accumulated and communicated to our management, including our CEO and CFO, as appropriate to allow timely decisions
regarding required disclosure.

[0001193125-13-261334:item_9a:5]
(b) Management’s Report on Internal Control Over Financial Reporting

[0001193125-13-261334:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined
in Exchange Act Rule 13a-15(f). Our internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external
purposes in accordance with generally accepted accounting principles. Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to
future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001193125-13-261334:item_9a:7]
Under the supervision and with the participation of our management, including our principal executive officer and principal financial
officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting based on the criteria established in Internal Control — Integrated Framework issued by the Committee of Sponsoring
Organizations of the Treadway Commission (COSO). Based on this assessment, our management concluded that, as of April 26, 2013, our internal control over financial reporting was effective at the reasonable assurance level based on those
criteria.

[0001193125-13-261334:item_9a:8]
The effectiveness of our internal control over financial reporting as of April 26, 2013 has been audited by
Deloitte & Touche LLP, an independent registered public accounting firm, as stated in their report, which is included herein.

[0001193125-13-261334:item_9a:9]
(c) Changes in Internal Control Over Financial Reporting

[0001193125-13-261334:item_9a:10]
There has been no change in our internal control over financial reporting (as defined in Rule 13a-15(f) under the Exchange Act) identified in connection with our evaluation that occurred during the fourth
quarter of fiscal 2013 that has materially affected or is reasonably likely to materially affect our internal control over financial reporting.

[0001193125-13-261334:item_9a:11]
113

[0001193125-13-261334:item_9a:12]
(d) Report of Independent Registered Public Accounting Firm

[0001193125-13-261334:item_9a:13]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001193125-13-261334:item_9a:14]
To the Board of Directors and Stockholders of

[0001193125-13-261334:item_9a:15]
NetApp, Inc.

[0001193125-13-261334:item_9a:16]
Sunnyvale, California

[0001193125-13-261334:item_9a:17]
We have
audited the internal control over financial reporting of NetApp, Inc. and subsidiaries (collectively, the “Company”) as of April 26, 2013, based on criteria established in Internal Control — Integrated Framework
issued by the Committee of Sponsoring Organizations of the Treadway Commission. The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of
internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial
reporting based on our audit.

[0001193125-13-261334:item_9a:18]
We conducted our audit in accordance with the standards of the Public Company Accounting
Oversight Board (United States). Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included
obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing
such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001193125-13-261334:item_9a:19]
A company’s internal control over financial reporting is a process designed by, or under the supervision of, the company’s principal executive and principal financial officers, or persons
performing similar functions, and effected by the company’s board of directors, management, and other personnel to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for
external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable
detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with
generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding
prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s assets that could have a material effect on the financial statements.

[0001193125-13-261334:item_9a:20]
Because of the inherent limitations of internal control over financial reporting, including the possibility of collusion or improper management override of controls, material misstatements due to error or
fraud may not be prevented or detected on a timely basis. Also, projections of any evaluation of the effectiveness of the internal control over financial reporting to future periods are subject to the risk that the controls may become inadequate
because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001193125-13-261334:item_9a:21]
In our
opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of April 26, 2013, based on the criteria established in Internal Control — Integrated Framework issued by the
Committee of Sponsoring Organizations of the Treadway Commission.

[0001193125-13-261334:item_9a:22]
We have also audited, in accordance with the standards of
the Public Company Accounting Oversight Board (United States), the consolidated financial statements and financial statement schedule as of and for the year ended April 26, 2013 of the Company and our report dated June 17, 2013 expressed
an unqualified opinion on those financial statements and financial statement schedule.

[0001193125-13-261334:item_9a:23]
/s/ DELOITTE & TOUCHE LLP

[0001193125-13-261334:item_9a:24]
San Jose, California

[0001193125-13-261334:item_9a:25]
June 17, 2013

[0001193125-13-261334:item_9a:26]
114
