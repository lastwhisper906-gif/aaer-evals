# NTAP MD&A — 0001193125-13-261334


## mdna

[0001193125-13-261334:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001193125-13-261334:mdna:2]
The following discussion of our financial condition and results of operations should be read together with the financial statements and
the accompanying notes set forth under “Item 8. Financial Statements and Supplementary Data”. The following discussion also contains trend information and other forward-looking statements that involve a number of risks and
uncertainties. The Risk Factors set forth in “Item 1A. Risk Factors” are hereby incorporated into the discussion by reference.

[0001193125-13-261334:mdna:3]
Executive Overview

[0001193125-13-261334:mdna:4]
Our Company

[0001193125-13-261334:mdna:5]
We are a leading provider of innovative storage systems and data management solutions that form the foundation for efficient and flexible information technology (IT) infrastructures. Our storage systems
help customers streamline operations and lower the cost associated with storing and managing their data. Our unified fabric-attached storage platform offers a storage platform for business applications, shared infrastructures, and cloud
environments. Our E-Series platform offers modular flexibility and custom configuration capability for demanding workloads. We are a leading original equipment manufacturer (OEM) storage provider enabling OEMs to offer market-leading IT and storage
solutions that serve specific markets and customer requirements. In addition, we provide professional services, global support solutions, and customer education and training to help customers most effectively manage their data. We employ a
multichannel distribution strategy, selling products and services to end users and service providers through a direct sales force and through channel partners, including value-added resellers, system integrators, OEMs and distributors.

[0001193125-13-261334:mdna:6]
Financial Results and Key Performance Metrics Overview

[0001193125-13-261334:mdna:7]
The following table provides an overview of some of our key financial metrics for each of the last three fiscal years (in millions, except
per share amounts, percentages and days sales outstanding):

[0001193125-13-261334:mdna:8]
|  |  | Year Ended |  |
|  |  | April 26,2013 |  |  | April 27,2012 |  |  | April 29,2011 |  |
| Net revenues |  | $ | 6,332.4 |  |  | $ | 6,233.2 |  |  | $ | 5,122.6 |  |
| Gross profit |  | $ | 3,761.1 |  |  | $ | 3,713.4 |  |  | $ | 3,328.7 |  |
| Gross profit margin percentage |  |  | 59.4 | % |  |  | 59.6 | % |  |  | 65.0 | % |
| Income from operations |  | $ | 607.8 |  |  | $ | 746.5 |  |  | $ | 824.3 |  |
| Income from operations as a percentage of net revenues |  |  | 9.6 | % |  |  | 12.0 | % |  |  | 16.1 | % |
| Net income |  | $ | 505.3 |  |  | $ | 605.4 |  |  | $ | 673.1 |  |
| Diluted income per share |  | $ | 1.37 |  |  | $ | 1.58 |  |  | $ | 1.71 |  |
| Operating cash flows |  | $ | 1,386.3 |  |  | $ | 1,462.6 |  |  | $ | 1,346.3 |  |

[0001193125-13-261334:mdna:9]
|  |  | April 26,2013 |  |  | April 27,2012 |  |
| Deferred revenue |  | $ | 3,009.5 |  |  | $ | 2,815.9 |  |
| Days sales outstanding (DSO) |  |  | 42 |  |  |  | 44 |  |

[0001193125-13-261334:mdna:10]
|  | • |  | Net revenues: Our net revenues increased in fiscal 2013 compared to the prior year. This increase was primarily due to an increase in revenues in our Asia Pacific (APAC) geographical region as well as increases in hardware maintenance contract and software entitlements and maintenance (SEM) revenues generated from a higher installed base of our hardware and software products. |

[0001193125-13-261334:mdna:11]
|  | • |  | Gross profit margin percentage: Our gross profit margin as a percentage of net revenues decreased slightly in fiscal 2013 compared to the prior year reflecting higher warranty costs, offset by lower materials costs as a percentage of revenue due to changes in the revenue mix. |

[0001193125-13-261334:mdna:12]
37

[0001193125-13-261334:mdna:13]
|  | • |  | Income from operations as a percentage of net revenues: Our income from operations as a percentage of net revenues decreased in fiscal 2013 compared to the prior year primarily due to an increase in operating expenses related to increased headcount. |

[0001193125-13-261334:mdna:14]
|  | • |  | Net Income and Diluted Income per Share: The 17% and 13% decrease in net income and diluted income per share, respectively, in fiscal 2013 compared to the prior year reflects the lower operating income in dollars and as a percentage of net revenue as discussed above, partially offset by a decrease in our effective income tax rate of 4 percentage points. Diluted income per share in fiscal 2013 was favorably impacted by a 4% decrease in the number of dilutive shares, including a decrease in dilution from employee awards, the Convertible Notes and warrants. |

[0001193125-13-261334:mdna:15]
|  | • |  | Operating cash flows: Operating cash flows decreased 5% in fiscal 2013, reflecting a decrease in net income. |

[0001193125-13-261334:mdna:16]
|  | • |  | Deferred revenue: Total deferred revenue increased $193.6 million, or 7%, in fiscal 2013 compared to the prior year primarily due to an increase in deferred SEM and service revenue related to service contract sales and renewals. |

[0001193125-13-261334:mdna:17]
|  | • |  | DSO: DSO decreased in the fourth quarter of fiscal 2013 compared to the prior year primarily due to improvements in the percentage of the fourth quarter’s total shipments that occurred in the last month of the quarter (shipment linearity) of fiscal 2013. |

[0001193125-13-261334:mdna:18]
Debt Issuance

[0001193125-13-261334:mdna:19]
In December 2012, we issued $750.0 million principal
amount of 2.00% Senior Notes due on December 15, 2017 and $250.0 million principal amount of 3.25% Senior Notes due on December 15, 2022, (collectively referred to as the Senior Notes).

[0001193125-13-261334:mdna:20]
Credit Facility

[0001193125-13-261334:mdna:21]
In December 2012, we entered into a credit agreement with a syndicated group of lenders that provides for an unsecured $250.0 million five-year revolving credit facility. We may also, subject to certain
requirements, request an increase in the facility up to an additional $100.0 million and request two additional one-year extensions, subject to certain conditions.

[0001193125-13-261334:mdna:22]
Stock Repurchase Program Activity

[0001193125-13-261334:mdna:23]
During fiscal 2013, our Board of
Directors approved a $1.5 billion increase to our stock repurchase program and we repurchased 18.1 million shares of our common stock at an average price of $32.68 per share.

[0001193125-13-261334:mdna:24]
Recent Activity

[0001193125-13-261334:mdna:25]
Convertible Notes Settlement

[0001193125-13-261334:mdna:26]
The Convertible Notes matured on June 1,
2013. At the time of settlement, we delivered $1.265 billion in cash to the holders for the outstanding principal amount and issued 4.9 million shares of our common stock for the excess conversion value. In addition, we exercised the
Convertible Note Hedges, for which we received 3.9 million shares from the counterparties.

[0001193125-13-261334:mdna:27]
Dividends and Share
Repurchase Program

[0001193125-13-261334:mdna:28]
On May 21, 2013, we announced a quarterly cash dividend of $0.15 per share of common stock,
beginning in the first quarter of fiscal 2014, with the first dividend payable on July 23, 2013 to holders of record as of the close of business on July 11, 2013.

[0001193125-13-261334:mdna:29]
In May 2013, we announced an increase of $1.6 billion to our stock repurchase program,
resulting in an aggregate remaining program of $3.0 billion program. More information about our stock repurchase program is included in “Liquidity and Capital Resources”.

[0001193125-13-261334:mdna:30]
Accelerated Share Repurchase Agreement

[0001193125-13-261334:mdna:31]
On June 5, 2013, we entered into a collared accelerated share repurchase agreement (ASR) with a counterparty under which we prepaid $750.0 million to purchase shares of our common stock. In exchange
for the up-front payment, the counterparty committed to deliver a number of shares during the ASR’s purchase period, which ends no later than August 29, 2013, although the completion date may be accelerated at the counterparty’s
option. The total number of shares to be delivered, and therefore the average price per share, will be determined at the end of the purchase period based on the volume weighted average price of our stock during that period.

[0001193125-13-261334:mdna:32]
Fiscal 2014 Restructuring Plan

[0001193125-13-261334:mdna:33]
On May 15, 2013, we committed to a business restructuring plan intended to realign resources reducing our global workforce by approximately 900 employees. In connection with this plan, we anticipate
incurring between $50.0 million and $60.0 million in employee severance and other restructuring charges.

[0001193125-13-261334:mdna:34]
Critical Accounting Policies and
Estimates

[0001193125-13-261334:mdna:35]
Our consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting
principles (GAAP), which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenue and expenses, and the disclosure of contingent assets and liabilities. Our estimates are
based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the
accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0001193125-13-261334:mdna:36]
The summary of significant accounting policies is included in Note 2 to the consolidated financial statements. An accounting policy is deemed to be critical if it requires an accounting estimate to be
made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the
financial statements. The accounting policies described below reflect the significant judgments, estimates and assumptions used in the preparation of the consolidated financial statements.

[0001193125-13-261334:mdna:37]
Revenue Recognition, Reserves and Allowances

[0001193125-13-261334:mdna:38]
We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable and collection is reasonably assured. Revenue from the sale of hardware
systems and software components essential to the functionality of the hardware systems is recognized in accordance with general revenue recognition accounting guidance. Our product revenues also include revenues from the sale of non-essential
software products, which generally includes a perpetual license to our software. Non-essential software sales are subject to industry specific software revenue recognition accounting guidance. SEM and premium hardware maintenance services are
recognized ratably over their contractual terms, generally from one to five years.

[0001193125-13-261334:mdna:39]
For multiple element arrangements, we
allocate revenue to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement. For our non-software deliverables, we allocate the arrangement
consideration based on the relative selling price of the

[0001193125-13-261334:mdna:40]
deliverables using best estimate of selling price (BESP). For our software entitlements and support services, we generally use vendor-specific objective evidence of selling price (VSOE). When we
are unable to establish VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement consideration.

[0001193125-13-261334:mdna:41]
We establish the selling prices used for each deliverable based on VSOE, if available, third party evidence (TPE), if VSOE is not available, or BESP if neither VSOE nor TPE is available. Generally, we are
not able to determine TPE because our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained.

[0001193125-13-261334:mdna:42]
We record reductions to revenue for estimated sales returns at the time of shipment. We also maintain a separate allowance
for doubtful accounts for estimated losses based on our assessment of the collectability of specific customer accounts.

[0001193125-13-261334:mdna:43]
The
following are the key estimates and assumptions and corresponding uncertainties for recognizing revenue:

[0001193125-13-261334:mdna:44]
| Key Estimates and Assumptions |  | Key Uncertainties |
| We establish VSOE of selling price using the price charged for a deliverable when sold separately and generally evidenced by a substantial majority of historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer classifications, and other variables in determining VSOE. Our revenue estimates and assumptions are based on our ability to assert and maintain VSOE. BESP is generally evidenced by a majority of historical transactions falling within a reasonable price range. We also consider multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. Our revenue estimates and assumptions are based on our ability to maintain consistent BESP. |  | As our business and offerings evolve over time, modifications to our pricing and discounting methodologies, changes in the scope and nature of service offerings and/or changes in customer segmentation may result in a lack of consistency required to establish and/or maintain VSOE or to maintain consistent BESP. Additionally, technological changes resulting in variability in product costs and gross margins may require changes to our BESP model. Changes in BESP may result in a different allocation of revenue to the deliverables in multiple-element arrangements. These factors, among others, may adversely impact the amount of revenue and gross margins we report in a particular period. |
| Sales returns are estimated based on historical sales returns, current trends and our expectations regarding future experience. Additionally, distributors and retail partners participate in various cooperative marketing and other programs, and we maintain estimated accruals and allowances for these programs based on contractual terms and historical experience. |  | If there is insufficient relevant historical data in determining our sales returns estimates, or if we experience changes in practices related to sales returns or changes in market or competitive conditions resulting in higher than expected return rates, or if actual credits received by our distributors and partners deviate significantly from our estimates, our revenues may be adversely impacted. |
| Our allowance for bad debt is based on an analysis of accounts receivable and historical bad debts, customer concentration, customer solvency, current economic and geographic trends, and changes in customer payment terms and practices. |  | Our reserves for bad debt have generally been sufficient to cover credit losses. However, if the financial condition of our customers were to deteriorate, resulting in an impairment of their ability to make payments, additional allowances may be required. |

[0001193125-13-261334:mdna:45]
40

[0001193125-13-261334:mdna:46]
Inventory Valuation and Purchase Order Accruals

[0001193125-13-261334:mdna:47]
Inventories consist primarily of purchased components and finished goods and are stated at the lower of cost or market, which approximates
actual cost on a first-in, first-out basis. A provision is recorded when inventory is determined to be in excess of anticipated demand or obsolete in order to adjust inventory to its estimated realizable value. The following are the key estimates
and assumptions and corresponding uncertainties for estimating the value of our inventories:

[0001193125-13-261334:mdna:48]
| Key Estimates and Assumptions |  | Key Uncertainties |
| We perform an excess and obsolete analysis of our inventory based upon assumptions about future demand forecasts and market conditions. Inventories are written down based on excess and obsolete reserves determined primarily on assumptions about future demand forecasts and market conditions. |  | Although we use our best estimates to forecast future product demand, any significant unanticipated changes in demand or obsolescence related to technological developments, new product introductions, customer requirements, competition or other factors could have a significant impact on the valuation of our inventory. If actual market conditions are less favorable than those projected, additional write-downs and other charges against earnings that adversely impact gross margins may be required. If actual market conditions are more favorable, we may realize higher gross profits in the period when the written-down inventory is sold. |
|  |  | We are subject to a variety of environmental laws relating to the manufacture of our products. If there are changes to the current regulations, we may be required to make product design changes which may result in excess or obsolete inventory, which could adversely impact our operating results. |
| We make commitments to our third-party contract manufacturers and other suppliers to manage lead times and meet product forecasts and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on non-cancelable purchase commitments when we believe it is probable that the components will not be utilized in future operations. |  | If the actual materials demand is significantly lower than our forecast, we may be required to increase our recorded liabilities for estimated losses on non-cancelable purchase commitments which would adversely impact our operating results. |

[0001193125-13-261334:mdna:49]
Goodwill and Purchased Intangible Assets

[0001193125-13-261334:mdna:50]
We allocate the purchase price of acquisitions to identifiable assets acquired and liabilities assumed at their acquisition date fair
values based on established valuation techniques. Goodwill represents the residual value as of the acquisition date, which in most cases is measured as the excess of the purchase consideration transferred over the net of the acquisition date fair
values of the assets acquired and liabilities assumed.

[0001193125-13-261334:mdna:51]
The carrying values of purchased intangible assets are reviewed
whenever events and circumstances indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. We periodically review the estimated remaining useful lives of our
intangible assets. This review may result in impairment charges or shortened useful lives, resulting in charges to our consolidated statements of operations.

[0001193125-13-261334:mdna:52]
We review goodwill for impairment annually and whenever events or changes in circumstances
indicate the carrying value of an asset may not be recoverable. The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill
impairment test. For our annual goodwill impairment test in the fourth quarter of fiscal 2013, we performed a quantitative test at the reporting unit level and determined the fair value substantially exceeded the carrying value for each reporting
unit and, therefore, found no impairment of goodwill.

[0001193125-13-261334:mdna:53]
The following are the key estimates and assumptions and corresponding
uncertainties for estimating the value of our goodwill and purchased intangible assets:

[0001193125-13-261334:mdna:54]
| Key Estimates and Assumptions |  | Key Uncertainties |
| The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the new accounting guidance for the fair value measurement of nonfinancial assets. The valuation of purchased intangible assets is principally based on estimates of the future performance and cash flows expected to be generated by the acquired assets from the acquired business. |  | While we employ experts to determine the acquisition date fair value of acquired intangibles, the fair value of assets acquired and liabilities assumed are based on significant management assumptions and estimates, which are inherently uncertain and unpredictable and as a result, actual results may differ from estimates. If different assumptions were to be used, it could materially impact the purchase price allocation. |
| Evaluations of possible goodwill and purchased intangible assets impairment require us to make judgments and assumptions related to the allocation of our balance sheet and income statement amounts and estimate future cash flows and fair market values of our reporting units and assets. |  | In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill or purchased intangible assets. |
|  |  | Assumptions and estimates about future values of our goodwill and purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as the adverse impact of unanticipated changes in macroeconomic conditions and technological changes or new product introductions from competitors. They can also be affected by internal factors such as changes in business strategy or in forecasted product life cycles and roadmaps. Our ongoing consideration of these and other factors could result in future impairment charges or accelerated amortization expense, which could adversely affect our operating results. |

[0001193125-13-261334:mdna:55]
Product Warranties

[0001193125-13-261334:mdna:56]
Estimated future hardware and software warranty costs are recorded as a cost of product revenues when the related revenue is recognized. We assess the adequacy of our warranty accrual each quarter and
adjust the amount as considered necessary.

[0001193125-13-261334:mdna:57]
42

[0001193125-13-261334:mdna:58]
The following are the key estimates and assumptions and corresponding uncertainties for
product warranties:

[0001193125-13-261334:mdna:59]
| Key Estimates and Assumptions |  | Key Uncertainties |
| Estimated future software and hardware warranty costs are based on historical and projected warranty claim rates, product failure rates, historical and projected materials and logistics costs, distribution and labor costs and knowledge of specific product failures that are outside of our typical experience. We also evaluate our estimates to assess the adequacy of our warranty liability considering the size of the installed base of products subject to warranty protection and adjust the estimates as necessary. |  | Although we engage in product quality programs and processes, if we experience unexpected quality issues resulting in higher failure rates or experience increases in costs to remediate product failures, additional warranty costs may be incurred. Additionally, for new products our warranty liability is based on limited historical experience. If our projections differ from such limited experience, our warranty costs may increase, which could adversely impact our gross margins. |

[0001193125-13-261334:mdna:60]
Stock-Based Compensation

[0001193125-13-261334:mdna:61]
We recognize stock-based compensation expense for all share-based payment awards, net of an estimated forfeiture rate. We recognize
stock-based compensation expense on a straight-line basis over the requisite service period.

[0001193125-13-261334:mdna:62]
The following are the key
estimates and assumptions and corresponding uncertainties for our stock-based compensation:

[0001193125-13-261334:mdna:63]
| Key Estimates and Assumptions |  | Key Uncertainties |
| The fair value of employee stock options and rights to purchase shares under our Employee Stock Purchase Plan (ESPP) is estimated using the Black-Scholes option-pricing model. The key assumptions used in estimating the fair value of such awards include the expected term of the awards, risk free interest rates and the expected stock price volatility over the expected term of the awards. |  | To the extent that market conditions or company specific events lead to higher stock price volatility or employee stock option exercise behavior differs from expectations, the estimated fair value and stock-based compensation expense may differ significantly in future periods, which could impact our operating results. |
| Stock-based compensation expense is based on awards ultimately expected to meet service vesting conditions and is impacted by the estimated forfeiture rate. |  | If we experience employee turnover different from our historical rates, our stock-based compensation expense may differ significantly from what we have recorded in the current period. |

[0001193125-13-261334:mdna:64]
Valuation of Investment Securities

[0001193125-13-261334:mdna:65]
Our investments in debt securities are reported at fair value and are subject to periodic impairment review. Unrealized gains and losses
related to changes in the fair value of these securities are recognized in accumulated other comprehensive income, net of tax, unless they are determined to be other-than-temporary impairments. The ultimate value realized on these securities is
subject to market price volatility until they are sold. Our investment portfolio includes Auction Rate Securities (ARS), which we classify as long-term investments as there is no active market and we believe our ability to liquidate these
investments in the next twelve months is uncertain.

[0001193125-13-261334:mdna:66]
The following are the key estimates and assumptions and corresponding uncertainties for the
valuation of our investment securities:

[0001193125-13-261334:mdna:67]
| Key Estimates and Assumptions |  | Key Uncertainties |
| The estimated fair value of our debt securities, excluding ARS, is based on an evaluation of current economic and market conditions, the credit rating of the security’s issuer, the length of time and extent a security’s fair value has been below its amortized cost and our ability and intent to hold the security for a period of time sufficient to allow for anticipated recovery in value. In estimating the fair value of our ARS we consider the assessments of the underlying structure of each security, discounted expected cash flows, credit ratings, workout periods, trading activity for similar securities in the secondary market and overall capital market liquidity. |  | The fair value of our investments in debt securities, including ARS, could decrease significantly from uncertainties in the credit and capital markets, credit rating downgrades and/or solvency of the issuer, decreases in the marketability of the securities or changes in our ability and intent to continue to hold the securities. If the fair value of our investments decreases significantly we may incur impairment charges that could adversely affect our results of operations. |

[0001193125-13-261334:mdna:68]
Income Taxes

[0001193125-13-261334:mdna:69]
We record a tax provision for the anticipated tax consequences of the reported results of operations. The provision for income taxes is computed using the asset and liability method, under which deferred
tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax
assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. The Company records a valuation allowance to reduce
deferred tax assets to the amount that is believed more likely than not to be realized.

[0001193125-13-261334:mdna:70]
44

[0001193125-13-261334:mdna:71]
The following are the key estimates and assumptions and corresponding uncertainties for our
income taxes:

[0001193125-13-261334:mdna:72]
| Key Estimates and Assumptions |  | Key Uncertainties |
| Our income tax provision is based on existing current tax law and letter rulings we have with various tax authorities. |  | Our provision for income taxes is subject to volatility and could be adversely impacted by future changes in existing tax laws, such as a change in tax rate, possible U.S. changes to the taxation of earnings of our foreign subsidiaries, and uncertainties as to future renewals of favorable tax rulings. |
| Deferred income taxes have not been provided on the undistributed earnings of foreign subsidiaries because these earnings have been indefinitely reinvested and there is no plan in the foreseeable future to initiate any action that would precipitate the payment of income taxes thereon. |  | We consider the following matters, among others, in evaluating our plans for indefinite reinvestment: the forecasts, budgets and financial requirements of the parent and subsidiaries for both the long and short term; the tax consequences of a decision to reinvest; and any U.S. and foreign government programs designed to influence remittances. If factors change, future income tax expense and payments may differ significantly from the current period and could adversely affect our results of operations. |
| The determination of whether we should record or adjust a valuation allowance against our deferred tax assets is based on assumptions regarding our future profitability. |  | Our future profits could change resulting in a change to our determination as to the amount of deferred tax assets that can be realized. We could adjust our valuation allowance with a corresponding impact to the tax provision in the period in which such determination is made. |
| The estimates for our uncertain tax positions are based primarily on company specific circumstances, applicable tax laws, tax opinions from outside firms and past results from examinations of our income tax returns. |  | Significant judgment is required in evaluating our uncertain tax positions. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome or tax court rulings of these matters will not be different from that which is reflected in our historical tax provisions and accruals. |

[0001193125-13-261334:mdna:73]
New Accounting Standards

[0001193125-13-261334:mdna:74]
See Note 4 of the accompanying consolidated financial statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of
operations and financial condition.

[0001193125-13-261334:mdna:75]
Results of Operations

[0001193125-13-261334:mdna:76]
The following table sets forth certain Consolidated Statements of Operations data as a percentage of net revenues for the periods indicated:

[0001193125-13-261334:mdna:77]
|  |  | Year Ended |  |
|  |  | April 26,2013 |  |  | April 27,2012 |  |  | April 29,2011 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 64.6 | % |  |  | 67.6 | % |  |  | 65.7 | % |
| Software entitlements and maintenance |  |  | 14.1 |  |  |  | 13.0 |  |  |  | 14.1 |  |
| Service |  |  | 21.3 |  |  |  | 19.4 |  |  |  | 20.2 |  |
| Net revenues |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 31.0 |  |  |  | 31.7 |  |  |  | 26.2 |  |
| Cost of software entitlements and maintenance |  |  | 0.4 |  |  |  | 0.4 |  |  |  | 0.3 |  |
| Cost of service |  |  | 9.2 |  |  |  | 8.3 |  |  |  | 8.5 |  |
| Gross profit |  |  | 59.4 |  |  |  | 59.6 |  |  |  | 65.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 31.2 |  |  |  | 29.9 |  |  |  | 31.2 |  |
| Research and development |  |  | 14.3 |  |  |  | 13.3 |  |  |  | 12.7 |  |
| General and administrative |  |  | 4.3 |  |  |  | 4.2 |  |  |  | 4.9 |  |
| Acquisition-related expense |  |  | — |  |  |  | 0.2 |  |  |  | 0.1 |  |
| Total operating expenses |  |  | 49.8 |  |  |  | 47.6 |  |  |  | 48.9 |  |
| Income from operations |  |  | 9.6 |  |  |  | 12.0 |  |  |  | 16.1 |  |
| Other expense, net |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | (0.6 | ) |
| Income before income taxes |  |  | 9.0 |  |  |  | 11.4 |  |  |  | 15.5 |  |
| Provision for income taxes |  |  | 1.0 |  |  |  | 1.7 |  |  |  | 2.4 |  |
| Net income |  |  | 8.0 | % |  |  | 9.7 | % |  |  | 13.1 | % |

[0001193125-13-261334:mdna:78]
Discussion and Analysis of Results of Operations

[0001193125-13-261334:mdna:79]
Overview — Net revenues for fiscal 2013 were $6,332.4 million, up $99.2 million, or 2% compared to fiscal 2012.
The increase was due to increases in hardware maintenance contract and SEM revenues.

[0001193125-13-261334:mdna:80]
Net revenues for fiscal 2012 were
$6,233.2 million, up $1,110.6 million, or 22% compared to fiscal 2011. The increase was primarily due to $656.6 million of E-Series OEM revenues, continued demand for our storage efficiency and data management solutions, and an increase in
hardware maintenance contract revenues.

[0001193125-13-261334:mdna:81]
Gross profit as a percentage of revenue decreased less than 1% during fiscal 2013
compared to fiscal 2012. Gross profit as a percentage of revenue decreased 5% during fiscal 2012 compared to fiscal 2011, primarily due to the inclusion of lower gross margin E-Series OEM products in the revenue mix and the impact of higher
discounting. This decrease was partially offset by manufacturing cost reductions.

[0001193125-13-261334:mdna:82]
Sales and marketing, research and
development and general and administrative expenses for fiscal 2013 totaled $3,151.6 million, up 7% compared to fiscal 2012. The increase was primarily due to increased compensation costs resulting from a 9% increase in average headcount during
fiscal 2013 compared to fiscal 2012. Sales and marketing, research and development and general and administrative expenses for fiscal 2012 totaled $2,957.1 million, up 18% compared to fiscal 2011. The increase was primarily due to increased

[0001193125-13-261334:mdna:83]
compensation costs resulting from a 26% increase in average headcount during fiscal 2012 compared to fiscal 2011. The May 2011 acquisition of Engenio represented approximately 10% of the average
headcount for fiscal 2012.

[0001193125-13-261334:mdna:84]
Net Revenues (in millions, except percentages):

[0001193125-13-261334:mdna:85]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Net revenues |  | $ | 6,332.4 |  |  | $ | 6,233.2 |  |  |  | 2 | % |  | $ | 5,122.6 |  |  |  | 22 | % |

[0001193125-13-261334:mdna:86]
The increase in net revenues for fiscal 2013 was due to increases in service and SEM revenues of $216.6
million, partially offset by a decrease in product revenues of $117.4 million. Product revenues comprised 65% of net revenues for fiscal 2013 compared to 68% of net revenues for fiscal 2012.

[0001193125-13-261334:mdna:87]
The increase in net revenues for fiscal 2012 was primarily due to an increase in product revenues, which comprised 68% of net revenues in
fiscal 2012 compared to 66% of net revenues in fiscal 2011.

[0001193125-13-261334:mdna:88]
Sales through our indirect channels represented 81%, 78% and 73%
of net revenues in fiscal 2013, 2012 and 2011, respectively. Included in indirect channel sales was $787.2 million, $889.5 million and $233.1 million of OEM revenue during fiscal 2013, 2012 and 2011, respectively.

[0001193125-13-261334:mdna:89]
The following customers, each of which is a distributor, accounted for 10% or more of net revenues (in millions, except percentages):

[0001193125-13-261334:mdna:90]
|  |  | Year Ended |  |
|  |  | April 26,2013 |  |  | % of NetRevenues |  |  | April 27,2012 |  |  | % of NetRevenues |  |  | April 29,2011 |  |  | % of NetRevenues |  |
| Arrow Electronics, Inc. |  | $ | 1,222.4 |  |  |  | 19 | % |  | $ | 1,035.7 |  |  |  | 17 | % |  | $ | 903.0 |  |  |  | 18 | % |
| Avnet, Inc. |  | $ | 958.5 |  |  |  | 15 | % |  | $ | 753.6 |  |  |  | 12 | % |  | $ | 639.0 |  |  |  | 12 | % |

[0001193125-13-261334:mdna:91]
Product Revenues (in millions, except percentages):

[0001193125-13-261334:mdna:92]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Product revenues |  | $ | 4,092.3 |  |  | $ | 4,209.7 |  |  |  | (3 | )% |  | $ | 3,367.1 |  |  |  | 25 | % |

[0001193125-13-261334:mdna:93]
Product revenues consist of configured systems, which include bundled hardware and software products, and
non-configured products, which consist primarily of add-on storage, OEM products and add-on hardware and software products.

[0001193125-13-261334:mdna:94]
Total configured system revenues of $2,283.1 million increased by $63.4 million, or 3%, in fiscal 2013 compared to fiscal 2012, primarily
due to an increase in revenue from 2000 and 6000 series systems, partially offset by a decrease in 3000 series systems. Total configured systems unit volume increased 9% during fiscal 2013 compared to fiscal 2012. Unit volume for both the 2000 and
6000 series increased, while unit volume of the 3000 series systems decreased, reflecting a shift in customer demand from certain older 3000 series systems to certain newer 2000 series systems and increased demand for the 6000 series systems. The
average selling prices (ASP’s) across all series increased due to increased capacity during fiscal 2013 compared to fiscal 2012. However, ASPs of total configured systems decreased during fiscal 2013, due to a shift in sales from higher priced
3000 series systems to lower priced 2000 series systems.

[0001193125-13-261334:mdna:95]
Non-configured product revenues of $1,809.1 million decreased $180.9 million, or 9%, during
fiscal 2013 compared to fiscal 2012. This decrease was primarily due to lower revenue from non-configured OEM products, which declined 14%, and lower add-on storage revenue.

[0001193125-13-261334:mdna:96]
Total configured system revenues of $2,219.7 million increased by $163.2 million, or 8%, in fiscal 2012 compared to fiscal 2011, with the largest increase in the 6000 series systems, partially offset by a
decrease in the 2000 series systems. Total configured systems unit volume increased 6% during fiscal 2012 compared to fiscal 2011, reflecting increases in unit volume for both the 6000 and 3000 series systems, partially offset by a decrease in unit
volume for the 2000 series systems. The increases in the unit volume of the 6000 and 3000 series were due to customer demand for newer products within these series. The decrease in the 2000 series unit volume was primarily due to a decrease in
demand for the older products within this series, as well as a shift in demand to the newer 3000 series systems. The ASPs for total configured systems increased slightly during the period due to a shift in system revenue mix from the lower priced
2000 series to the higher priced 3000 and 6000 series. However, ASP’s across each series decreased primarily due to higher discounting.

[0001193125-13-261334:mdna:97]
Non-configured product revenues of $1,990.0 million increased $679.4 million, or 52%, during fiscal 2012 compared to fiscal 2011. This increase was primarily due to E-Series OEM product revenues of $650.7
million during fiscal 2012.

[0001193125-13-261334:mdna:98]
Our systems are highly configurable to respond to customer requirements in the open systems
storage markets that we serve. This can cause a wide variation in product configurations that can significantly impact revenues, cost of revenues and gross profits. Pricing changes, discounting practices, product competition, foreign currency, unit
volumes, customer mix, natural disasters and product material costs can also impact revenues, cost of revenues and/or gross profits. Disks are a significant component of our storage systems. Industry disk pricing has fallen every year; however, when
supplies are constrained, disk prices may increase. To the extent that disk prices increase or decrease, we intend to pass along those price increases or decreases to our customers while working to maintain relatively constant profit margins on our
disk drives. While our sales price per terabyte historically declines over time, improved system performance, increased capacity and software to manage this increased capacity have an offsetting favorable impact on product revenues.

[0001193125-13-261334:mdna:99]
Software Entitlements and Maintenance Revenues (in millions, except percentages):

[0001193125-13-261334:mdna:100]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Software entitlements and maintenance revenues |  | $ | 893.5 |  |  | $ | 812.2 |  |  |  | 10 | % |  | $ | 720.6 |  |  |  | 13 | % |

[0001193125-13-261334:mdna:101]
SEM contracts entitle customers to receive unspecified product upgrades and enhancements on a
when-and-if-available basis, bug fixes and patch releases.

[0001193125-13-261334:mdna:102]
The increases in SEM revenues in each period were due to increases
in the aggregate contract value of the installed base under SEM contracts, which is recognized as revenue ratably over the terms of the underlying contracts.

[0001193125-13-261334:mdna:103]
Service Revenues (in millions, except percentages):

[0001193125-13-261334:mdna:104]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Service revenues |  | $ | 1,346.6 |  |  | $ | 1,211.3 |  |  |  | 11 | % |  | $ | 1,034.9 |  |  |  | 17 | % |

[0001193125-13-261334:mdna:105]
Service revenues include hardware maintenance, professional services and educational and training
services.

[0001193125-13-261334:mdna:106]
48

[0001193125-13-261334:mdna:107]
Hardware maintenance contract revenues represent 74%, 70% and 66%, of service revenues in
fiscal 2013, 2012 and 2011, respectively. These revenues increased $143.5 million, or 17%, during fiscal 2013 compared to fiscal 2012 and increased $166.5 million, or 24% during fiscal 2012 compared to fiscal 2011. The increases in each year are a
result of increases in the installed base and aggregate contract values under service contracts. Professional services and educational and training services comprised 26%, 30% and 34% of service revenues for fiscal 2013, 2012 and 2011, respectively.

[0001193125-13-261334:mdna:108]
Revenues by Geographic Area (in millions, except percentages):

[0001193125-13-261334:mdna:109]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Americas (United States, Canada and Latin America) |  | $ | 3,552.5 |  |  | $ | 3,529.7 |  |  |  | 1 | % |  | $ | 2,899.0 |  |  |  | 22 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 1,928.8 |  |  |  | 1,936.5 |  |  |  | — | % |  |  | 1,719.1 |  |  |  | 13 | % |
| Asia Pacific (APAC) |  |  | 851.1 |  |  |  | 767.0 |  |  |  | 11 | % |  |  | 504.5 |  |  |  | 52 | % |
| Net revenues |  | $ | 6,332.4 |  |  | $ | 6,233.2 |  |  |  |  |  |  | $ | 5,122.6 |  |  |  |  |  |

[0001193125-13-261334:mdna:110]
Americas revenues consist of Americas commercial and U.S. public sector markets. Sales to customers
inside the United States comprised 89%, 86% and 89% of Americas net revenues during fiscal 2013, 2012 and 2011, respectively. During fiscal 2013, EMEA revenues were negatively impacted by the general macroeconomic conditions in the region. Sales to
Germany accounted for $626.8 million, $632.6 million and $618.0 million for fiscal 2013, 2012 and 2011, respectively. No other foreign country accounted for 10% or more of net revenues.

[0001193125-13-261334:mdna:111]
Cost of Revenues

[0001193125-13-261334:mdna:112]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping of our storage products, amortization of purchased intangible
assets, inventory write-downs, and warranty costs, (2) cost of SEM, which includes the costs of providing SEM and third-party royalty costs and (3) cost of service revenues, which reflects costs associated with providing support activities
for hardware, global support partnership programs, professional services and educational and training services.

[0001193125-13-261334:mdna:113]
Our gross
profit is impacted by a variety of factors, including pricing changes, discounting practices, foreign currency, product configuration, unit volumes, customer mix, revenue mix, natural disasters and product material costs. Service gross profit is
typically impacted by factors such as changes in the size of our installed base of products, as well as the timing of support service initiations and renewals, and incremental investments in our customer support infrastructure. If any of these
factors that impact our gross profit are adversely affected, whether by economic uncertainties or for other reasons, our gross profit could decline.

[0001193125-13-261334:mdna:114]
Cost of Product Revenues (in millions, except percentages):

[0001193125-13-261334:mdna:115]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Cost of product revenues |  | $ | 1,959.9 |  |  | $ | 1,979.9 |  |  |  | (1 | )% |  | $ | 1,342.0 |  |  |  | 48 | % |

[0001193125-13-261334:mdna:116]
The changes in cost of product revenues consisted of the following elements (in percentage
points of the total change):

[0001193125-13-261334:mdna:117]
|  |  | Year EndedFiscal 2013 toFiscal 2012PercentageChangePoints |  |  | Year EndedFiscal 2012 toFiscal 2011PercentageChangePoints |  |
| Materials cost |  |  | (3 | ) |  |  | 37 |  |
| Amortization expense |  |  | — |  |  |  | 3 |  |
| Excess and obsolete inventory |  |  | 1 |  |  |  | 1 |  |
| Warranty |  |  | 1 |  |  |  | 3 |  |
| Manufacturing overhead |  |  | — |  |  |  | 2 |  |
| Other |  |  | — |  |  |  | 2 |  |
| Total change |  |  | (1 | ) |  |  | 48 |  |

[0001193125-13-261334:mdna:118]
Materials cost represented 83%, 85% and 88% of product costs for fiscal 2013, 2012 and 2011,
respectively.

[0001193125-13-261334:mdna:119]
Materials cost decreased $58.9 million in fiscal 2013 compared to fiscal 2012 due to change in mix of
configured systems towards lower cost 2000 series systems, lower drive costs and lower OEM product volume resulting in an overall decrease in average unit materials cost. This decrease was partially offset by a 9% unit volume increase in configured
systems. In addition, cost of product revenues in fiscal 2013 reflected a $26.9 million increase in hardware-related warranty expense and an $11.7 million increase in inventory write-downs compared to fiscal 2012.

[0001193125-13-261334:mdna:120]
Materials cost for fiscal 2012 increased $503.0 million compared to fiscal 2011, primarily as a result of $368.6 million in materials
cost relating to the sales of E-Series OEM products. Materials cost increased on configured products due to a 6% volume increase, partially offset by average unit materials cost reductions. In addition, cost of product revenues in fiscal 2012
included an increase of $42.5 million in amortization expense related to developed technology intangible assets from the Engenio acquisition, a $36.1 million increase in warranty expense, primarily due to E-Series OEM products, and a $29.9 million
increase in manufacturing overhead.

[0001193125-13-261334:mdna:121]
Cost of product revenues represented 48%, 47% and 40% of product revenue for fiscal 2013,
2012 and 2011, respectively. The increase in costs as a percentage of revenues for fiscal 2012 compared to fiscal 2011, was primarily the result of E-Series OEM products, which have lower material margins than configured systems and add-on products
as well as lower materials margins on configured systems.

[0001193125-13-261334:mdna:122]
Cost of Software Entitlements and Maintenance Revenues (in
millions, except percentages):

[0001193125-13-261334:mdna:123]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Cost of software entitlements and maintenance revenues |  | $ | 28.3 |  |  | $ | 23.9 |  |  |  | 18 | % |  | $ | 15.7 |  |  |  | 52 | % |

[0001193125-13-261334:mdna:124]
Cost of SEM revenues increased each year primarily due to an increase in volume-related software support
costs. Cost of SEM revenues represented 3% of SEM revenues for fiscal 2013 and 2012 and 2% of SEM revenues for fiscal 2011.

[0001193125-13-261334:mdna:125]
Cost of Service Revenues (in millions, except percentages):

[0001193125-13-261334:mdna:126]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Cost of service revenues |  | $ | 583.1 |  |  | $ | 516.0 |  |  |  | 13 | % |  | $ | 436.2 |  |  |  | 18 | % |

[0001193125-13-261334:mdna:127]
Cost of service revenues increased in fiscal 2013, 2012 and 2011 primarily due to increases in contract
fulfillment, logistics and service delivery costs. Costs represented 43% of service revenues for fiscal 2013 and 2012 and 42% of service revenues for fiscal 2011.

[0001193125-13-261334:mdna:128]
Operating Expenses

[0001193125-13-261334:mdna:129]
Sales and Marketing, Research and Development
and General and Administrative Expenses

[0001193125-13-261334:mdna:130]
Compensation costs comprise the largest component of operating expenses. Included
in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation costs and employee incentive compensation plan costs.

[0001193125-13-261334:mdna:131]
Compensation costs included in operating expenses increased $111.1 million, or 7% during fiscal 2013 compared to fiscal 2012, primarily due to:

[0001193125-13-261334:mdna:132]
(i) an increase in salaries, benefits and other compensation-related costs of $86.5 million due to increases in average headcount;

[0001193125-13-261334:mdna:133]
(ii) an increase in stock-based compensation of $16.7 million due to increases in average headcount; and

[0001193125-13-261334:mdna:134]
(iii) an increase in incentive compensation expense of $7.9 million, reflecting increased headcount.

[0001193125-13-261334:mdna:135]
Compensation costs included in operating expenses increased approximately $273.6 million, or 21%, during fiscal 2012 compared to fiscal
2011, primarily due to:

[0001193125-13-261334:mdna:136]
(i) an increase in salaries, benefits and other compensation-related costs of $273.1 million due to an
increase in average headcount, which included the impact of the Engenio acquisition; and

[0001193125-13-261334:mdna:137]
(ii) an increase in stock-based
compensation of $77.2 million, including stock-based compensation expense of $10.9 million during fiscal 2012 related to the reset of the ESPP offering in December 2011;

[0001193125-13-261334:mdna:138]
(iii) partially offset by a decrease in incentive compensation expense of $76.6 million due to lower performance against plan operating targets in fiscal 2012.

[0001193125-13-261334:mdna:139]
Sales and Marketing (in millions, except percentages):

[0001193125-13-261334:mdna:140]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 1,974.8 |  |  | $ | 1,864.0 |  |  |  | 6 | % |  | $ | 1,597.0 |  |  |  | 17 | % |

[0001193125-13-261334:mdna:141]
Sales and marketing expense consists primarily of compensation costs, commissions, outside
services, allocated facilities and IT costs, advertising and marketing promotional expense and travel and entertainment expense. Sales and marketing expenses increased due to the following:

[0001193125-13-261334:mdna:142]
|  |  | Year EndedFiscal 2013 toFiscal 2012PercentageChangePoints |  |  | Year EndedFiscal 2012 toFiscal 2011PercentageChangePoints |  |
| Compensation costs |  |  | 3 |  |  |  | 11 |  |
| Commissions |  |  | — |  |  |  | (1 | ) |
| Amortization expense |  |  | — |  |  |  | 2 |  |
| Facilities and IT support costs |  |  | 2 |  |  |  | 2 |  |
| Other |  |  | 1 |  |  |  | 3 |  |
| Total change |  |  | 6 |  |  |  | 17 |  |

[0001193125-13-261334:mdna:143]
The increase in compensation costs during fiscal 2013 is primarily due to higher salaries and stock-based
compensation resulting from a 9% increase in average sales and marketing headcount compared to fiscal 2012. Facilities and IT support costs increased during fiscal 2013 due to our increased investment in sales IT systems.

[0001193125-13-261334:mdna:144]
The increase in compensation costs in fiscal 2012 reflects a 20% increase in average sales and marketing headcount compared to fiscal
2011, partially offset by a decrease in incentive compensation expense. Sales and marketing expense also reflects a decrease in commissions expense during fiscal 2012 due to lower individual attainment and commission rates. Amortization expense in
fiscal 2012 increased due to the addition of intangible assets from the Engenio acquisition. The increase in facilities and IT support costs in fiscal 2012 reflects our investment in sales IT systems and infrastructure.

[0001193125-13-261334:mdna:145]
Research and Development (in millions, except percentages):

[0001193125-13-261334:mdna:146]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Research and development expenses |  | $ | 904.2 |  |  | $ | 828.2 |  |  |  | 9 | % |  | $ | 648.6 |  |  |  | 28 | % |

[0001193125-13-261334:mdna:147]
Research and development expense consists primarily of compensation costs, allocated facilities and IT
costs, depreciation and amortization, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs. Research and development expenses increased due to the following:

[0001193125-13-261334:mdna:148]
|  |  | Year EndedFiscal 2013 toFiscal 2012PercentageChangePoints |  |  | Year EndedFiscal 2012 toFiscal 2011PercentageChangePoints |  |
| Compensation costs |  |  | 6 |  |  |  | 17 |  |
| Depreciation and amortization |  |  | 2 |  |  |  | 3 |  |
| Development projects |  |  | 1 |  |  |  | 2 |  |
| Facilities and IT support costs |  |  | — |  |  |  | 5 |  |
| Other |  |  | — |  |  |  | 1 |  |
| Total change |  |  | 9 |  |  |  | 28 |  |

[0001193125-13-261334:mdna:149]
The increase in compensation costs during fiscal 2013 is primarily due to higher salaries, stock-based
compensation and incentive plan compensation expense resulting from an increase of 9% in average engineering

[0001193125-13-261334:mdna:150]
52

[0001193125-13-261334:mdna:151]
headcount compared to fiscal 2012. Depreciation and amortization expense increased during fiscal 2013 due to higher levels of investment in engineering equipment.

[0001193125-13-261334:mdna:152]
The increase in compensation costs in fiscal 2012 reflects a 36% increase in average engineering headcount. This increase was partially
offset by a decrease in incentive compensation expense. The increase in facilities and IT support costs in fiscal 2012 reflects the Engenio acquisition. Depreciation and amortization expense in fiscal 2012 increased due to higher levels of
investment in engineering equipment.

[0001193125-13-261334:mdna:153]
We believe that our future performance will depend in large part on our ability to
maintain and enhance our current product line, develop new products that achieve market acceptance, maintain technological competitiveness and meet an expanding range of customer requirements. We expect to continue to spend on current and future
product development efforts, broaden our existing product offerings and introduce new products that expand our solutions portfolio.

[0001193125-13-261334:mdna:154]
General and Administrative (in millions, except percentages):

[0001193125-13-261334:mdna:155]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| General and administrative expenses |  | $ | 272.6 |  |  | $ | 264.9 |  |  |  | 3 | % |  | $ | 251.3 |  |  |  | 5 | % |

[0001193125-13-261334:mdna:156]
General and administrative expense consists primarily of compensation costs, professional and corporate
legal fees, outside services and allocated facilities and IT support costs. General and administrative expenses increased due to the following:

[0001193125-13-261334:mdna:157]
|  |  | Year EndedFiscal 2013 toFiscal 2012PercentageChangePoints |  |  | Year EndedFiscal 2012 toFiscal 2011PercentageChangePoints |  |
| Compensation costs |  |  | 3 |  |  |  | (2 | ) |
| Outside services |  |  | (2 | ) |  |  | 2 |  |
| Professional and corporate legal fees |  |  | — |  |  |  | 3 |  |
| Other |  |  | 2 |  |  |  | 2 |  |
| Total change |  |  | 3 |  |  |  | 5 |  |

[0001193125-13-261334:mdna:158]
The increase in compensation costs in fiscal 2013 is primarily due to higher salaries resulting from an
increase of 8% in average general and administrative headcount during fiscal 2013 compared to fiscal 2012. The decreases in outside services during fiscal 2013 reflect lower spending on contractors and various operational projects, as well as the
absence of Engenio integration activities in fiscal 2013.

[0001193125-13-261334:mdna:159]
The decrease in compensation costs in fiscal 2012 compared to
fiscal 2011 was primarily due to a decrease in incentive plan compensation expense. This decrease was partially offset by the impact of a 13% increase in average general and administrative headcount during fiscal 2012. Professional and corporate
legal fees were higher in fiscal 2012 as a result of a legal fee settlement during fiscal 2011 associated with the resolution of the Sun Microsystems litigation. The increase in outside services in fiscal 2012 reflects additional spending on
contractors and costs associated with the Engenio integration activities and various ongoing operational projects.

[0001193125-13-261334:mdna:160]
Acquisition-related Expense (in millions, except percentages):

[0001193125-13-261334:mdna:161]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Acquisition-related expense |  | $ | 1.7 |  |  | $ | 9.8 |  |  |  | (83 | )% |  | $ | 5.7 |  |  |  | 72 | % |

[0001193125-13-261334:mdna:162]
During fiscal 2013, we incurred $1.7 million of acquisition costs, primarily related to severance costs
associated with the termination of certain acquiree company employees.

[0001193125-13-261334:mdna:163]
During fiscal 2012, we incurred due diligence, legal
and integration charges of $9.8 million associated with our acquisition of Engenio. During fiscal 2011, we incurred $5.7 million of due diligence, legal and integration charges associated with our acquisitions.

[0001193125-13-261334:mdna:164]
Other Expense, Net

[0001193125-13-261334:mdna:165]
Interest Income (in millions, except percentages):

[0001193125-13-261334:mdna:166]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Interest income |  | $ | 42.2 |  |  | $ | 38.2 |  |  |  | 10 | % |  | $ | 39.9 |  |  |  | (4 | )% |

[0001193125-13-261334:mdna:167]
The increase in interest income for fiscal 2013 compared to fiscal 2012 was primarily due to increases in
our investment portfolio, partially offset by lower yields. The decrease in interest income for fiscal 2012 compared to fiscal 2011 was primarily due to lower yields on investments.

[0001193125-13-261334:mdna:168]
Interest Expense (in millions, except percentages):

[0001193125-13-261334:mdna:169]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Interest expense |  | $ | (91.7 | ) |  | $ | (74.7 | ) |  |  | 23 | % |  | $ | (75.9 | ) |  |  | (2 | )% |

[0001193125-13-261334:mdna:170]
During fiscal 2013, 2012 and 2011, we recognized non-cash interest expense from the amortization of debt
discount and issuance costs relating to our debt of $60.2 million, $52.9 million and $53.1 million, respectively. The coupon interest expense related to our debt was $30.4 million, $20.6 million and $22.1 million for fiscal 2013, 2012 and
2011, respectively. Total interest expense related to the Convertible Notes and the Senior Notes was $81.2 million and $9.4 million, respectively, for fiscal 2013. Total interest expense related to the Convertible Notes was $73.5 million and $75.2
million for fiscal 2012 and 2011, respectively.

[0001193125-13-261334:mdna:171]
Other Income, Net (in millions, except percentages):

[0001193125-13-261334:mdna:172]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Other income, net |  | $ | 8.3 |  |  | $ | 2.4 |  |  |  | 246 | % |  | $ | 5.8 |  |  |  | (59 | )% |

[0001193125-13-261334:mdna:173]
The increase in other income, net for fiscal 2013 compared to fiscal 2012 is primarily due to net foreign
exchange gains of $4.5 million. The decrease in other income, net in fiscal 2012 compared to fiscal 2011 was due to lower gains on investments.

[0001193125-13-261334:mdna:174]
Provision for Income Taxes (in millions, except percentages):

[0001193125-13-261334:mdna:175]
|  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | % Change |  |  | April 29, 2011 |  |  | % Change |  |
| Provision for income taxes |  | $ | 61.3 |  |  | $ | 107.0 |  |  |  | (43 | )% |  | $ | 121.0 |  |  |  | (12 | )% |

[0001193125-13-261334:mdna:176]
Our effective tax rate for fiscal 2013 was 10.8% compared to an effective tax rate of 15.0% for fiscal
2012, and an effective tax rate of 15.2% for fiscal 2011. Our effective tax rate reflects our corporate legal entity structure and the global nature of our business with a significant amount of our profits generated and taxed in foreign
jurisdictions at rates below the U.S. statutory tax rate. The effective tax rates for fiscal 2011 through fiscal 2013 were favorably impacted by the geographic mix of profits.

[0001193125-13-261334:mdna:177]
The effective tax rate of 10.8% in fiscal 2013 included a benefit of $144.4 million, or 25.5 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate
of 35%. Other key components of our effective tax rate for the year included a benefit of $12.1 million, or 2.1 percentage points, related to current year research and development credits, and an expense of $18.4 million, or 3.2 percentage points,
attributable to non-deductible stock-based compensation.

[0001193125-13-261334:mdna:178]
The effective tax rate of 15.0% in fiscal 2012 included a benefit of
$162.2 million, or 22.8 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 35%. Other key components of our effective tax rate for the year included a benefit of $10.9 million, or 1.5
percentage points, related to research and development credits, an expense of $14.4 million, or 2.0 percentage points, attributable to non-deductible stock-based compensation, an expense of $6.4 million, or 0.9 percentage points, on state tax
expense and an expense of $7.3 million, or 1.0 percentage point, in connection with income tax audits.

[0001193125-13-261334:mdna:179]
The effective tax rate
of 15.2% in fiscal 2011 included a benefit of $146.9 million, or 18.5 percentage points, related to foreign income tax rates that are lower than the U.S. federal statutory rate of 35%. Other key components of our effective tax rate
for the year include a benefit of $17.8 million, or 2.2 percentage points, related to research and development tax credits, a benefit of $1.3 million, or 0.2 percentage points, related to stock-based compensation and an IRS audit
settlement benefit of $21.1 million, or 2.7 percentage points, partially offset by the unfavorable impact of $31.1 million, or 3.9 percentage points, related to state income taxes.

[0001193125-13-261334:mdna:180]
On January 2, 2013, the American Taxpayer Relief Act of 2012 (the Act) was signed into law. Under the Act, the federal research
credit was retroactively extended for amounts paid or incurred after December 31, 2011, and before January 1, 2014. As a result of the extension, we recorded a benefit of $12.1 million related to the fiscal 2013 research credit and a
benefit of $3.2 million related to prior year credits that we will retroactively claim. Unless extended again, the federal research credit will expire on December 31, 2013.

[0001193125-13-261334:mdna:181]
In March 2013, we received a draft Revenue Agent’s Report from the IRS for our fiscal 2005 through 2007 income tax returns. We are
currently in the process of submitting information to draft a closing agreement with the IRS for our fiscal 2007 income tax return. The draft Revenue Agent’s Report and closing agreement will be subject to review by certain higher authorities
within the IRS and the Joint Committee on Taxation. Our fiscal 2008 through 2010 returns are currently under audit by the IRS.

[0001193125-13-261334:mdna:182]
On September 17, 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 from our
Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. On December 19, 2011, the
Danish Tax Tribunal issued a ruling that our Danish subsidiary was not liable for Danish withholding tax. The Danish tax examination agency appealed the ruling to the Danish High Court in March 2012.

[0001193125-13-261334:mdna:183]
We continue to monitor the progress of ongoing tax controversies and the impact, if any, of
the expected tolling of the statute of limitations in various taxing jurisdictions.

[0001193125-13-261334:mdna:184]
Liquidity and Capital Resources

[0001193125-13-261334:mdna:185]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash flows on our liquidity and
capital resources. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to
maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash
equivalents or investments from the values reported as of April 26, 2013.

[0001193125-13-261334:mdna:186]
Liquidity, Capital Resources and Cash
Requirements

[0001193125-13-261334:mdna:187]
| (Dollars in Millions) |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Cash, cash equivalents and short-term investments |  | $ | 6,952.6 |  |  | $ | 5,398.5 |  |
| Current portion of principal amount of Convertible Notes |  |  | 1,264.9 |  |  |  | 1,264.9 |  |
| Principal amount of Senior Notes |  |  | 1,000.0 |  |  |  | — |  |
| Debt as a % of stockholders’ equity |  |  | 48 | % |  |  | 28 | % |

[0001193125-13-261334:mdna:188]
The following is a summary of our cash flows:

[0001193125-13-261334:mdna:189]
|  |  | Year Ended |  |
| (In Millions) |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Net cash provided by operating activities |  | $ | 1,386.3 |  |  | $ | 1,462.6 |  |
| Net cash used in investing activities |  |  | (228.6 | ) |  |  | (2,310.4 | ) |
| Net cash provided by (used in) financing activities |  |  | 578.9 |  |  |  | (343.6 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (9.3 | ) |  |  | (16.1 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 1,727.3 |  |  | $ | (1,207.5 | ) |

[0001193125-13-261334:mdna:190]
Cash Flows

[0001193125-13-261334:mdna:191]
As of April 26, 2013, our cash, cash equivalents and short-term investments increased by $1.6 billion from April 27, 2012, to $7.0 billion. The increase was primarily a result of $1.4
billion of cash provided by operating activities and $1.0 billion of proceeds, net, received from the issuance of long-term debt, partially offset by $0.6 billion in cash paid for the repurchase of common stock and an aggregate $0.4 billion in
capital expenditures and business acquisitions. We derive our liquidity and capital resources primarily from our operating cash flows and from working capital. Accounts receivable days sales outstanding as of April 26, 2013 decreased to
42 days compared to 44 days as of April 27, 2012, primarily due to improvements in shipment linearity in the fourth quarter of fiscal 2013 compared to the same period in the prior year. Working capital increased by $1.3 billion to
$4.6 billion as of April 26, 2013, primarily due to the net increase in cash, cash equivalents and short-term investments as a result of the issuance of the long-term debt.

[0001193125-13-261334:mdna:192]
Cash Flows from Operating Activities

[0001193125-13-261334:mdna:193]
During fiscal 2013, we generated cash from operating activities of $1.4 billion. The primary sources of cash from operating activities during fiscal 2013 consisted of net income of
$505.3 million, adjusted by depreciation and amortization of $344.6 million and stock-based compensation of $276.6 million.

[0001193125-13-261334:mdna:194]
Changes in assets and liabilities during fiscal 2013 included the following:

[0001193125-13-261334:mdna:195]
|  | • |  | Deferred revenue increased due to an increase in deferred SEM and service revenue. |

[0001193125-13-261334:mdna:196]
|  | • |  | Accrued compensation and other current liabilities increased due to an increase in hardware-related warranty accruals and employee compensation plans. |

[0001193125-13-261334:mdna:197]
During fiscal 2012, we generated cash from operating activities of $1.5 billion. The primary sources
of cash from operating activities during fiscal 2012 consisted of net income of $605.4 million, adjusted by depreciation and amortization of $293.1 million and stock-based compensation of $257.6 million.

[0001193125-13-261334:mdna:198]
Changes in assets and liabilities during fiscal 2012 included the following:

[0001193125-13-261334:mdna:199]
|  | • |  | Deferred revenue increased due to an increase in deferred SEM and service revenue. |

[0001193125-13-261334:mdna:200]
|  | • |  | Accounts receivable increased due to higher invoicing in the fourth quarter of fiscal 2012 compared to the same period in the prior year. |

[0001193125-13-261334:mdna:201]
We expect that cash provided by operating activities may materially fluctuate in future periods as a result
of a number of factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, tax benefits from stock-based compensation, and the timing and amount of
compensation and other payments.

[0001193125-13-261334:mdna:202]
Cash Flows from Investing Activities

[0001193125-13-261334:mdna:203]
During fiscal 2013, we generated $177.0 million from maturities and sales of investments, net of purchases, completed business
acquisitions for net cash payments of $106.5 million and paid $303.3 million for capital expenditures, including $69.6 million related to buildings and land associated with the buyout of our remaining synthetic leases.

[0001193125-13-261334:mdna:204]
During fiscal 2012, we paid $1.4 billion for investments, net of maturities and sales, completed our acquisition of Engenio for a net
cash payment of $480.0 million and paid $407.1 million for capital expenditures, including $44.3 million related to buildings and land associated with the buyout of one of our synthetic leases.

[0001193125-13-261334:mdna:205]
Cash Flows from Financing Activities

[0001193125-13-261334:mdna:206]
During fiscal 2013, we generated $987.3 million, net, from the issuance of long-term debt, used $590.0 million for the repurchase of 18.1 million shares of common stock and received an aggregate of
$183.5 million of proceeds and excess tax benefits from employee equity award plans, net of shares withheld for taxes.

[0001193125-13-261334:mdna:207]
During
fiscal 2012, we used $600.0 million for the repurchase of 14.6 million shares of common stock, partially offset by an aggregate of $255.4 million of proceeds and excess tax benefits from employee equity award plans, net of shares withheld for
taxes.

[0001193125-13-261334:mdna:208]
Liquidity

[0001193125-13-261334:mdna:209]
Our principal sources of liquidity as of April 26, 2013 consisted of cash, cash equivalents and short-term investments, as well as
cash we expect to generate from operations.

[0001193125-13-261334:mdna:210]
Cash, cash equivalents and short-term investments consist of the following (in
millions):

[0001193125-13-261334:mdna:211]
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Cash and cash equivalents |  | $ | 3,277.1 |  |  | $ | 1,549.8 |  |
| Short-term investments |  |  | 3,675.5 |  |  |  | 3,848.7 |  |
| Total |  | $ | 6,952.6 |  |  | $ | 5,398.5 |  |

[0001193125-13-261334:mdna:212]
As of April 26, 2013, $3.4 billion of cash, cash equivalents and short-term investments were held in
the United States, while $3.6 billion was held in foreign countries. Most of the amounts held outside the United States can be repatriated to the United States but, under current law, would be subject to U.S. federal and state income taxes. If we
were to repatriate foreign earnings for cash requirements in the United States, we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state net operating loss and tax credit carry forwards. However,
our intent is to keep these funds permanently reinvested outside of the United States, and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our
working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies, and service interest and principal payments on our debt. Our contractual
obligations as of April 26, 2013 are summarized below in the Contractual Obligations table.

[0001193125-13-261334:mdna:213]
Key factors that could
affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable and inventories, our ability to effectively integrate acquired products, businesses
and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of cash will satisfy our working capital needs, capital expenditures, investment requirements, stock
repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. We
anticipate the cash used to settle the principal amount of our Convertible Notes due June 1, 2013 will come from our domestic cash. We anticipate the cash used for future dividends and share repurchases will come from our domestic cash and cash
generated from on-going domestic operating activities. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing
arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all.

[0001193125-13-261334:mdna:214]
Our investment portfolio, including auction rate securities, has been and will continue to be exposed to market risk due to trends in the
credit and capital markets. We continue to closely monitor current economic and market events to minimize our market risk on our investment portfolio. Based on our ability to access our cash and short-term investments, our expected operating cash
flows, and our other potential sources of cash, we do not anticipate that the lack of liquidity of these investments will impact our ability to fund working capital needs, capital expenditures, acquisitions, debt obligations or other cash
requirements. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. Our gross exposures to our investments in Greece, Italy, Portugal, and Spain are individually and collectively not material.

[0001193125-13-261334:mdna:215]
Long-term Debt

[0001193125-13-261334:mdna:216]
We have an automatic shelf registration statement on file with the SEC pursuant to which we may offer an unspecified amount of debt, equity and other securities. In December 2012, we utilized this shelf
registration

[0001193125-13-261334:mdna:217]
statement and issued $1.0 billion aggregate principal of senior unsecured notes consisting of $750.0 million of 2.00% Senior Notes due 2017 and $250.0 million of 3.25% Senior Notes due 2022,
collectively referred to as the Senior Notes. There are no financial covenants associated with the Senior Notes. For further information on the terms of the Senior Notes, see Note 10 of the accompanying consolidated financial statements.

[0001193125-13-261334:mdna:218]
As of April 26, 2013, we also had outstanding $1.265 billion of Convertible Notes, which became unconditionally convertible at the
option of the holders on March 1, 2013 and have a maturity date of June 1, 2013 (see Note 10 of the accompanying consolidated financial statements). The Convertible Notes were settled on June 3, 2013, at which time we delivered $1.265
billion in cash to the holders for the outstanding principal amount.

[0001193125-13-261334:mdna:219]
Credit Facility

[0001193125-13-261334:mdna:220]
We have an unsecured $250.0 million five-year revolving credit facility that terminates on December 21, 2017 if no extensions have
been requested and contains financial covenants requiring us to maintain a maximum leverage ratio and a minimum interest coverage ratio. We may also, subject to certain requirements, request an increase in the facility up to an additional
$100.0 million and request two additional one-year extensions, subject to certain conditions. As of April 26, 2013, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001193125-13-261334:mdna:221]
Capital Expenditure Requirements

[0001193125-13-261334:mdna:222]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through
existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes
in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We expect that our existing facilities and those being developed in North Carolina, India, California and other
locations worldwide are adequate for our requirements over at least the next two years and that additional space will be available as needed. Our capital expenditures were $303.3 million during fiscal 2013. We anticipate capital expenditures for
fiscal 2014 to be between $225.0 million and $275.0 million.

[0001193125-13-261334:mdna:223]
Dividends and Share Repurchase Program

[0001193125-13-261334:mdna:224]
On May 21, 2013, we announced a quarterly cash dividend of $0.15 per share of common stock, beginning in the first quarter of fiscal
2014, with the first dividend payable on July 23, 2013 to holders of record as of the close of business on July 11, 2013.

[0001193125-13-261334:mdna:225]
As of April 26, 2013, our Board of Directors had authorized the repurchase of up to $5.5 billion of our common stock under our stock repurchase program of which the remaining authorized amount was
$1.4 billion. On May 21, 2013, we announced an increase of $1.6 billion to this stock repurchase program. We plan to complete the remaining aggregate $3.0 billion program over the next three years and intend to complete $2.0 billion of
repurchases by May 2014, of which $1.0 billion is planned to be completed by September 2013. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed
appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. During fiscal 2013 we repurchased 18.1 million shares of our common stock.

[0001193125-13-261334:mdna:226]
The timing and amount of stock repurchase transactions and future dividends will depend on market conditions, corporate business and
financial considerations and regulatory requirements.

[0001193125-13-261334:mdna:227]
Contractual Obligations

[0001193125-13-261334:mdna:228]
The following table summarizes our contractual obligations at April 26, 2013 and the effect such obligations are expected to have on
our liquidity and cash flows in future periods (in millions):

[0001193125-13-261334:mdna:229]
|  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | 2018 |  |  | Thereafter |  |  | Total |  |
| Off-balance sheet commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Office operating lease payments |  | $ | 40.6 |  |  | $ | 38.8 |  |  | $ | 35.1 |  |  | $ | 18.3 |  |  | $ | 11.6 |  |  | $ | 27.2 |  |  | $ | 171.6 |  |
| Equipment operating lease payments |  |  | 25.7 |  |  |  | 15.7 |  |  |  | 8.7 |  |  |  | 2.0 |  |  |  | — |  |  |  | — |  |  |  | 52.1 |  |
| Purchase commitments with contract manufacturers(1) |  |  | 235.2 |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 235.4 |  |
| Capital expenditures |  |  | 56.3 |  |  |  | 15.2 |  |  |  | 13.0 |  |  |  | 0.9 |  |  |  | 0.7 |  |  |  | — |  |  |  | 86.1 |  |
| Other purchase obligations(2) |  |  | 76.4 |  |  |  | 36.7 |  |  |  | 19.7 |  |  |  | 12.1 |  |  |  | 1.7 |  |  |  | — |  |  |  | 146.6 |  |
| Total off-balance sheet commitments |  |  | 434.2 |  |  |  | 106.6 |  |  |  | 76.5 |  |  |  | 33.3 |  |  |  | 14.0 |  |  |  | 27.2 |  |  |  | 691.8 |  |
| Long-term debt obligations(3) |  |  | 1,299.3 |  |  |  | 23.1 |  |  |  | 23.1 |  |  |  | 23.1 |  |  |  | 773.1 |  |  |  | 290.7 |  |  |  | 2,432.4 |  |
| Long-term financing arrangements |  |  | 6.9 |  |  |  | 4.5 |  |  |  | 3.8 |  |  |  | 1.3 |  |  |  | — |  |  |  | — |  |  |  | 16.5 |  |
| Uncertain tax positions(4) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 137.5 |  |
| Total |  | $ | 1,740.4 |  |  | $ | 134.2 |  |  | $ | 103.4 |  |  | $ | 57.7 |  |  | $ | 787.1 |  |  | $ | 317.9 |  |  | $ | 3,278.2 |  |
| Other Commercial Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit |  | $ | 4.2 |  |  | $ | 1.1 |  |  | $ | 0.8 |  |  | $ | 1.9 |  |  | $ | 1.4 |  |  | $ | 0.7 |  |  | $ | 10.1 |  |

[0001193125-13-261334:mdna:230]
| (1) | Contract manufacturer commitments consist of obligations for on-hand inventories and non-cancelable purchase orders with our contract manufacturers. As of April 26, 2013, we recorded accruals of $9.5 million for firm, non-cancelable purchase commitments with these contract manufacturers for quantities in excess of our future demand forecasts, which is consistent with the valuation of our excess and obsolete inventory. |

[0001193125-13-261334:mdna:231]
| (2) | Purchase obligations represent an estimate of all open purchase orders and contractual obligations in the ordinary course of business, other than commitments with contract manufacturers, for which we have not received the goods or services. Purchase obligations do not include contracts that may be cancelled without penalty. Although open purchase orders are considered enforceable and legally binding, the terms generally allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services. |

[0001193125-13-261334:mdna:232]
| (3) | Included in long-term debt are obligations related to: |

[0001193125-13-261334:mdna:233]
|  | (a) | $1.265 billion principal amount of our Convertible Notes, which mature in June 2013 and |

[0001193125-13-261334:mdna:234]
|  | (b) | $1.0 billion principal amount of our Senior Notes, of which $750.0 million is due in December 2017 and $250.0 million is due in December 2022. |

[0001193125-13-261334:mdna:235]
Estimated interest payments for our long-term debt, assuming no early retirement of debt obligations are $167.5 million for fiscal 2014
through fiscal 2023.

[0001193125-13-261334:mdna:236]
| (4) | As of April 26, 2013, our liability for uncertain tax positions was $137.5 million, including interest and penalties, which due to the uncertainty of the timing of future payments, are presented in the total column on a separate line in this table. |

[0001193125-13-261334:mdna:237]
Some of the amounts in the table above are based on management’s estimates and assumptions, including the commitment duration, the possibility of renewal or termination, anticipated actions by
management and third parties and other factors. Because these estimates and assumptions are subjective, our actual future obligations may vary from those reflected in the table. We expect to fund our contractual obligations and other commitments in
the table above through existing cash, cash equivalents, investments, and cash generated from operations or to obtain additional financing, if necessary.

[0001193125-13-261334:mdna:238]
Legal Contingencies

[0001193125-13-261334:mdna:239]
We are subject to various legal proceedings and
claims which arise in the normal course of business. See further details on such matters in Note 17 to our consolidated financial statements.

[0001193125-13-261334:mdna:240]
Off-Balance Sheet Arrangements

[0001193125-13-261334:mdna:241]
In the ordinary course of business, we provide standby letters of credit or other guarantee instruments to third parties as required for
certain transactions initiated either by us or our subsidiaries. As of April 26, 2013, our financial guarantees of $10.1 million that were not recorded on our consolidated balance sheet consisted of standby letters of credit related to
workers’ compensation, a customs guarantee, a corporate credit card program, foreign rent guarantees and surety bonds, which were primarily related to self-insurance.

[0001193125-13-261334:mdna:242]
In the ordinary course of business, some of our customers have entered into recourse and non-recourse financing leasing arrangements using third-party financing companies, and in some situations, we enter
into customer financing arrangements for our products and services that are contemporaneously sold on a recourse or non-recourse basis to third-party financing companies. During the terms of recourse leases, which are generally three years or less,
we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific
software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance
payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of April 26, 2013, the
maximum guaranteed payment contingencies under our financing arrangements totaled $182.4 million and the related deferred revenue totaled $168.6 million.

[0001193125-13-261334:mdna:243]
We enter into indemnification agreements with third parties in the ordinary course of business. Generally, these indemnification agreements require us to reimburse losses suffered by the third-parties due
to various events, such as lawsuits arising from patent or copyright infringement. These indemnification obligations are considered off-balance sheet arrangements under accounting guidance.

[0001193125-13-261334:mdna:244]
61
