# NTAP note change history — 0001193125-12-487586 → 0001193125-13-084667


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-02-28):
[0001193125-13-084667:note_history:1]
As of January 25, 2013, future annual minimum lease
payments under all non-cancelable facilities and equipment
operating leases with an initial term in excess of one year totaled
$222.5 million. In the three months ended January 25, 2013, we
terminated all of our remaining synthetic lease
arrangements.
  (was, 2012-11-30, similarity 0.7558):
[0001193125-12-487586:note_history:1]
As of October 26, 2012, future annual minimum lease
payments under all non-cancelable facilities and equipment
operating leases with an initial term in excess of one year totaled
$334.6 million.

- changed (2013-02-28):
[0001193125-13-084667:note_history:2]
In the normal course of business we make commitments to our
third-party contract manufacturers, to manage manufacturer lead
times and meet product forecasts, and to other parties, to purchase
various key components used in the manufacture of our products. We
establish accruals for estimated losses on purchased components to
the extent we believe it is probable that such components will not
be utilized in future operations. To the extent that such forecasts
are not achieved, our commitments and associated accruals may
change. As of January 25, 2013, we had $282.4 million in
non-cancelable purchase commitments with our contract
manufacturers. In addition, we recorded a liability for firm,
non-cancelable and unconditional purchase commitments with contract
manufacturers for quantities in excess of our future demand
forecasts through a charge to cost of product sales. As of
January 25, 2013 and April 27, 2012, such liability
amounted to $8.1 million and $3.3 million, respectively, and is
included in other current liabilities in the condensed consolidated
balance sheets.
  (was, 2012-11-30, similarity 0.9868):
[0001193125-12-487586:note_history:2]
In the normal course of business we make commitments to our
third-party contract manufacturers, to manage manufacturer lead
times and meet product forecasts, and to other parties, to purchase
various key components used in the manufacture of our products. We
establish accruals for estimated losses on purchased components to
the extent we believe it is probable that such components will not
be utilized in future operations. To the extent that such forecasts
are not achieved, our commitments and associated accruals may
change. As of October 26, 2012, we had $266.7 million in
non-cancelable purchase commitments with our contract
manufacturers. In addition, we recorded a liability for firm,
non-cancelable and unconditional purchase commitments with contract
manufacturers for quantities in excess of our future demand
forecasts through a charge to cost of product sales. As of
October 26, 2012 and April 27, 2012, such liability
amounted to $8.5 million and $3.3 million, respectively, and is
included in other current liabilities in the condensed consolidated
balance sheets.

- changed (2013-02-28):
[0001193125-13-084667:note_history:3]
In addition to commitments with contract manufacturers and
component suppliers, we have open purchase orders and contractual
obligations associated with our ordinary course business for which
we have not received goods or services. As of January 25,
2013, we had $93.6 million in capital purchase commitments and
$182.3 million in other purchase commitments.
  (was, 2012-11-30, similarity 0.9797):
[0001193125-12-487586:note_history:3]
In addition to commitments with contract manufacturers and
component suppliers, we have open purchase orders and contractual
obligations associated with our ordinary course business for which
we have not received goods or services. As of October 26,
2012, we had $41.5 million in capital purchase commitments and
$190.1 million in other purchase commitments.

- changed (2013-02-28):
[0001193125-13-084667:note_history:4]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Beginning balance |  | $ | 111.8 |  |  | $ | 65.0 |  |  | $ | 83.1 |  |  | $ | 40.5 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 17.5 |  |
| Expense accrued during the period |  |  | 23.5 |  |  |  | 14.1 |  |  |  | 74.3 |  |  |  | 41.5 |  |
| Warranty costs incurred |  |  | (18.5 | ) |  |  | (10.9 | ) |  |  | (40.6 | ) |  |  | (31.3 | ) |
| Ending balance |  | $ | 116.8 |  |  | $ | 68.2 |  |  | $ | 116.8 |  |  | $ | 68.2 |  |
  (was, 2012-11-30, similarity 0.8709):
[0001193125-12-487586:note_history:4]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Beginning balance |  | $ | 96.5 |  |  | $ | 59.5 |  |  | $ | 83.1 |  |  | $ | 40.5 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 17.5 |  |
| Expense accrued during the period |  |  | 27.1 |  |  |  | 15.7 |  |  |  | 50.8 |  |  |  | 27.4 |  |
| Warranty costs incurred |  |  | (11.8 | ) |  |  | (10.2 | ) |  |  | (22.1 | ) |  |  | (20.4 | ) |
| Ending balance |  | $ | 111.8 |  |  | $ | 65.0 |  |  | $ | 111.8 |  |  | $ | 65.0 |  |

- added (2013-02-28):
[0001193125-13-084667:note_history:5]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Maximum guaranteed payment contingencies |  | $ | 180.9 |  |  | $ | 169.0 |  |
| Deferred revenue associated with financing guarantees |  |  | (164.4 | ) |  |  | (149.9 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 16.5 |  |  | $ | 19.1 |  |

- changed (2013-02-28):
[0001193125-13-084667:note_history:6]
We are subject to various legal proceedings and claims that
arise in the normal course of business. No material accrual has
been recorded as of January 25, 2013 related to such
matters.
  (was, 2012-11-30, similarity 0.9667):
[0001193125-12-487586:note_history:6]
We are subject to various legal proceedings and claims that
arise in the normal course of business. No material accrual has
been recorded as of October 26, 2012 related to such
matters.

- removed (2013-02-28):
[0001193125-12-487586:note_history:7]
As of October 26, 2012, we have three leasing arrangements
with BNP Paribas LLC (BNPPLC), one of which require us to lease
certain of our land to BNPPLC for a period of 99 years and all
of which require us to lease approximately 0.3 million square
feet of office space from BNPPLC for our headquarters in Sunnyvale,
California, which had an original cost of $69.6 million. Under
these leasing arrangements, we pay BNPPLC minimum lease payments,
which vary based on a fixed rate on the costs of the facilities on
the respective lease commencement dates. We make payments for each
of the leases for a term of five years. We have the option to renew
each of the leases for two consecutive five-year periods upon
approval by BNPPLC. The initial lease terms expire in December 2012
and January 2013. Upon expiration (or upon any earlier termination)
of the lease terms, we must elect one of the following options:
(i) purchase the buildings from BNPPLC at cost; (ii) if
certain conditions are met, arrange for the sale of the buildings
by BNPPLC to a third-party, and be liable for any deficiency
between the net proceeds received from the third-party and
BNPPLC’s cost, up to 85% of cost (residual guarantee); or
(iii) pay BNPPLC supplemental payments for an amount equal to
the difference between BNPPLC’s cost and fair value, up to
the residual guarantee, in which event we may recoup some or all of
such payments by arranging for a sale of each or all buildings by
BNPPLC during the ensuing two-year period.

- removed (2013-02-28):
[0001193125-12-487586:note_history:8]
These leases require us to maintain specified financial
covenants with which we were in compliance as of October 26,
2012. Such financial covenants include a maximum ratio of Total
Debt to Earnings before Interest, Taxes, Depreciation and
Amortization of less than 3:1 and a minimum amount of Unencumbered
Cash and Short-Term Investments of $300.0 million.

- removed (2013-02-28):
[0001193125-12-487586:note_history:9]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Maximum guaranteed payment contingencies |  | $ | 170.8 |  |  | $ | 169.0 |  |
| Deferred revenue associated with financing guarantees |  |  | (154.5 | ) |  |  | (149.9 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 16.3 |  |  | $ | 19.1 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-02-28):
[0001193125-13-084667:note_history:10]
Fiscal Year — Our fiscal year is reported on
a 52- or 53-week year ending on the last Friday in April. The
first, second and third quarters of fiscal 2013 and 2012 were each
13-week periods.
  (was, 2012-11-30, similarity 0.9577):
[0001193125-12-487586:note_history:10]
Fiscal Year — Our fiscal year is reported on
a 52- or 53-week year ending on the last Friday in April. The first
and second quarters of fiscal 2013 and 2012 were each 13-week
periods.

- changed (2013-02-28):
[0001193125-13-084667:note_history:11]
Basis of Presentation — The accompanying unaudited
condensed consolidated financial statements have been prepared by
the Company, and reflect all adjustments, consisting only of normal
recurring adjustments, that are, in the opinion of management,
necessary for the fair presentation of our financial position,
results of operations, comprehensive income and cash flows for the
interim periods presented. The statements have been prepared in
accordance with accounting principles generally accepted in the
United States of America (GAAP) for interim financial information
and in accordance with the instructions to Form 10-Q and Rule 10-01
of Regulation S-X. Accordingly, these statements do not include all
information and footnotes required by GAAP for annual consolidated
financial statements, and should be read in conjunction with our
audited consolidated financial statements as of and for the fiscal
year ended April 27, 2012 contained in our Annual Report on
Form 10-K filed with the Securities and Exchange Commission on
June 19, 2012. The results of operations for the three and
nine months ended January 25, 2013 are not necessarily
indicative of the operating results to be expected for the full
fiscal year or future operating periods.
  (was, 2012-11-30, similarity 0.8841):
[0001193125-12-487586:note_history:11]
Basis of Presentation — The accompanying unaudited
condensed consolidated financial statements have been prepared by
the Company, and reflect all adjustments, consisting only of normal
recurring adjustments, that are, in the opinion of management,
necessary for the fair presentation of our financial position,
results of operations, and cash flows for the interim periods
presented. The statements have been prepared in accordance with
accounting principles generally accepted in the United States of
America (GAAP) for interim financial information and in accordance
with the instructions to Form 10-Q and Rule 10-01 of Regulation
S-X. Accordingly, these statements do not include all information
and footnotes required by GAAP for annual consolidated financial
statements, and should be read in conjunction with our audited
consolidated financial statements as of and for the fiscal year
ended April 27, 2012 contained in our Annual Report on Form
10-K filed with the Securities and Exchange Commission on
June 19, 2012. The results of operations for the three and six
months ended October 26, 2012 are not necessarily indicative
of the operating results to be expected for the full fiscal year or
future operating periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-02-28):
[0001193125-13-084667:note_history:12]
There have been no significant changes in our significant
accounting policies as of and for the nine months ended
January 25, 2013, as compared to the significant accounting
policies described in our Annual Report on Form 10-K for the fiscal
year ended April 27, 2012.
  (was, 2012-11-30, similarity 0.9587):
[0001193125-12-487586:note_history:12]
There have been no significant changes in our significant
accounting policies as of and for the six months ended
October 26, 2012, as compared to the significant accounting
policies described in our Annual Report on Form 10-K for the fiscal
year ended April 27, 2012.


## ntap:DebtDiscountAndIssuanceCostTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2013-02-28):
[0001193125-12-487586:note_history:13]
The following table reflects the remaining debt discount and
issuance costs as of October 26, 2012 (in
millions):

- removed (2013-02-28):
[0001193125-12-487586:note_history:14]
| Remaining debt discount |  | $ | 35.5 |  |
| Remaining issuance costs |  |  | 3.0 |  |
| Remaining life of the Notes (years) |  |  | 0.6 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2013-02-28):
[0001193125-13-084667:note_history:15]
Long-term
Debt

- changed (2013-02-28):
[0001193125-13-084667:note_history:16]
The following table summarizes the carrying value of our
long-term debt (in millions):
  (was, 2012-11-30, similarity 0.795):
[0001193125-12-487586:note_history:16]
The following table reflects the carrying value of the Notes
(in millions):

- added (2013-02-28):
[0001193125-13-084667:note_history:17]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 0.0 |  |  |  | N/A |  |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 0.0 |  |  |  | N/A |  |
| 1.75% Convertible Notes Due 2013 |  |  | 1,264.9 |  |  |  | 6.31 | % |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total |  |  | 2,264.9 |  |  |  |  |  |  |  | 1,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (27.3 | ) |  |  |  |  |  |  | (62.6 | ) |  |  |  |  |
| Total |  |  | 2,237.6 |  |  |  |  |  |  |  | 1,202.3 |  |  |  |  |  |
| Less: Current portion |  |  | (1,243.3 | ) |  |  |  |  |  |  | (1,202.3 | ) |  |  |  |  |
| Total long-term debt |  | $ | 994.3 |  |  |  |  |  |  | $ | 0.0 |  |  |  |  |  |

- added (2013-02-28):
[0001193125-13-084667:note_history:18]
N/A - Not
Applicable

- added (2013-02-28):
[0001193125-13-084667:note_history:19]
2.00% Senior Notes due 2017 and 3.25% Senior Notes
due 2022

- added (2013-02-28):
[0001193125-13-084667:note_history:20]
In December 2012, we issued $750.0 million principal amount of
2.00% Senior Notes due on December 15, 2017 and $250.0 million
principal amount of 3.25% Senior Notes due on December 15,
2022 (collectively referred to as the Senior Notes). The proceeds
received were net of debt discounts of $5.8 million and issuance
costs of $6.9 million, both of which are amortized as additional
interest expense over the respective terms of the Senior Notes
using the effective interest method. The Senior Notes are
unsecured, unsubordinated obligations, which pay interest
semi-annually on June 15 and December 15 and rank equally
in right of payment with our other existing and future senior
unsecured indebtedness, including the Convertible Notes. During the
three months ended January 25, 2013, interest expense
associated with the Senior Notes was $3.1 million. The proceeds
from the Senior Notes are available for general corporate purposes,
including repayment of certain indebtedness, capital expenditures,
possible stock repurchases, working capital and potential
acquisitions and strategic transactions.

- added (2013-02-28):
[0001193125-13-084667:note_history:21]
We may redeem the Senior Notes in whole or in part, at any time
at our option at specified redemption prices. In addition, upon the
occurrence of certain change of control triggering events, we may
be required to repurchase the Senior Notes at 101% of their
aggregate principal amount, plus accrued and unpaid interest to the
date of repurchase. The Senior Notes also include covenants that
limit our ability to incur debt secured by liens on assets or on
shares of stock or indebtedness of our subsidiaries; to engage in
sale and lease-back transactions; and to consolidate, merge or sell
all or substantially all of our assets. As of January 25,
2013, we were in compliance with all covenants associated with the
Senior Notes.

- changed (2013-02-28):
[0001193125-13-084667:note_history:22]
On June 10, 2008, we issued $1,265.0 million
aggregate principal amount of 1.75% Convertible Senior Notes
due 2013 (the Convertible Notes). The Convertible Notes are
unsecured, unsubordinated obligations of the Company, which pay
interest in cash semi-annually at a rate of 1.75% per annum.
The Convertible Notes will mature on June 1, 2013 unless
earlier repurchased or converted in accordance with their terms
prior to such date. The Convertible Notes may be converted, under
the conditions specified below, based on an initial conversion rate
of 31.40 shares of common stock per $1,000 principal amount of
Convertible Notes (which represents an initial effective conversion
price of the Convertible Notes of $31.85 per share), subject to
adjustment as described in the indenture governing the Convertible
Notes.
  (was, 2012-11-30, similarity 0.8395):
[0001193125-12-487586:note_history:22]
On June 10, 2008, we issued $1,265.0 million
aggregate principal amount of 1.75% Convertible Senior Notes
due 2013 (the Notes). The Notes are unsecured, unsubordinated
obligations of the Company, which pay interest in cash
semi-annually at a rate of 1.75% per annum. The Notes will
mature on June 1, 2013 unless earlier repurchased or converted
in accordance with their terms prior to such date. The Notes may be
converted, under the conditions specified below, based on an
initial conversion rate of 31.40 shares of common stock per
$1,000 principal amount of Notes (which represents an initial
effective conversion price of the Notes of $31.85 per share),
subject to adjustment as described in the indenture governing the
Notes.

- changed (2013-02-28):
[0001193125-13-084667:note_history:23]
The Convertible Notes are not redeemable by us prior to the
maturity date. In the event of a fundamental change (as defined in
the indenture for the Convertible Notes), holders of the
Convertible Notes may require us to repurchase all or a portion of
their Convertible Notes at a repurchase price equal to 100% of the
principal amount of the Convertible Notes plus accrued and unpaid
interest, if any, to, but excluding, the fundamental change
repurchase date.
  (was, 2012-11-30, similarity 0.8084):
[0001193125-12-487586:note_history:23]
The Notes are not redeemable by us prior to the maturity date.
In the event of a fundamental change (as defined in the indenture
for the Notes), holders of the Notes may require us to repurchase
all or a portion of their Notes at a repurchase price equal to 100%
of the principal amount of the Notes plus accrued and unpaid
interest, if any, to, but excluding, the fundamental change
repurchase date.

- changed (2013-02-28):
[0001193125-13-084667:note_history:24]
The holders of the Convertible Notes may convert their
Convertible Notes until the close of business on the scheduled
trading day immediately preceding the maturity date if any of the
following conditions are met: (1) during the five business day
period after any five consecutive trading day period (the
measurement period) in which the trading price of the Convertible
Notes for each day in the measurement period was less than 98% of
an amount equal to (i) the last reported sale price of our
common stock multiplied by (ii) the conversion rate for the
Convertible Notes on each such day; (2) during any calendar
quarter (and only during such calendar quarter) if the last
reported sale price of our common stock for 20 or more trading days
in a period of 30 consecutive trading days ending on the last
trading day of the immediately preceding calendar quarter exceeds
130% of the applicable conversion price in effect for the
Convertible Notes on the last trading day of such immediately
preceding calendar quarter; or (3) upon the occurrence of
specified corporate transactions set forth in the indenture for the
Convertible Notes. On or after March 1, 2013, until the
scheduled trading day immediately preceding the maturity date,
holders of the Convertible Notes may convert their Convertible
Notes regardless of the foregoing conditions. Upon conversion, a
holder will receive cash in an amount equal to the lesser of the
conversion value and the principal amount of the Convertible Notes,
and shares of our common stock for any conversion value in excess
of the principal amount of the Convertible Notes, if any. Holders
of the Convertible Notes who convert their Convertible Notes in
connection with a fundamental change will, under certain
circumstances, be entitled to a make-whole premium in the form of
an increase in the conversion rate.
  (was, 2012-11-30, similarity 0.6983):
[0001193125-12-487586:note_history:24]
The holders of the Notes may convert their Notes until the
close of business on the scheduled trading day immediately
preceding the maturity date if any of the following conditions are
met: (1) during the five business day period after any five
consecutive trading day period (the measurement period) in which
the trading price of the Notes for each day in the measurement
period was less than 98% of an amount equal to (i) the last
reported sale price of our common stock multiplied by (ii) the
conversion rate for the Notes on each such day; (2) during any
calendar quarter (and only during such calendar quarter) if the
last reported sale price of our common stock for 20 or more trading
days in a period of 30 consecutive trading days ending on the last
trading day of the immediately preceding calendar quarter exceeds
130% of the applicable conversion price in effect for the Notes on
the last trading day of such immediately preceding calendar
quarter; or (3) upon the occurrence of specified corporate
transactions set forth in the indenture for the Notes. On or after
March 1, 2013, until the scheduled trading day immediately
preceding the maturity date, holders of the Notes may convert their
Notes regardless of the foregoing conditions. Upon conversion, a
holder will receive cash in an amount equal to the lesser of the
conversion value and the principal amount of the Notes, and shares
of our common stock for any conversion value in excess of the
principal amount of the Notes, if any. Holders of the Notes who
convert their Notes in connection with a fundamental change will,
under certain circumstances, be entitled to a make-whole premium in
the form of an increase in the conversion rate.

- added (2013-02-28):
[0001193125-13-084667:note_history:25]
Our common stock price did not exceed the conversion threshold
price of $41.41 per share set forth for the Convertible Notes for
at least 20 trading days during the 30 consecutive trading days
ended December 31, 2012, and accordingly, as of
January 25, 2013, the Convertible Notes were not convertible
at the option of the holders. Since the Convertible Notes were not
convertible, the difference between the principal amount and the
carrying value of the Convertible Notes was reflected as equity on
our condensed consolidated balance sheet as of January 25,
2013.

- added (2013-02-28):
[0001193125-13-084667:note_history:26]
The Convertible Notes become unconditionally convertible at the
option of the holders on March 1, 2013. At such time, the
difference between the principal amount and the carrying value of
the Convertible Notes will be reflected as convertible debt in
mezzanine on our condensed consolidated balance sheet.

- changed (2013-02-28):
[0001193125-13-084667:note_history:27]
Upon conversion of the Convertible Notes, we deliver cash up to
the principal amount of the Convertible Notes and, with respect to
any excess conversion value greater than the principal amount of
the Convertible Notes, shares of our common stock. As of
January 25, 2013, shares issued related to the Convertible
Notes were minimal. Based on the closing price of our common stock
of $36.15 on January 25, 2013, the if-converted value of our
Convertible Notes exceeded their principal amount by approximately
$170.9 million.
  (was, 2012-11-30, similarity 0.7939):
[0001193125-12-487586:note_history:27]
Upon conversion of the Notes, we deliver cash up to the
principal amount of the Notes and, with respect to any excess
conversion value greater than the principal amount of the Notes,
shares of our common stock. As of October 26, 2012, shares
issued related to the Notes were minimal. Based on the closing
price of our common stock of $27.88 on October 26, 2012, the
if-converted value of our Notes was below their principal
amount.

- changed (2013-02-28):
[0001193125-13-084667:note_history:28]
We separately account for the liability and equity components
of the Convertible Notes. The initial debt component of the
Convertible Notes was valued at $1,017.0 million based on the
contractual cash flows discounted at an appropriate comparable
market non-convertible debt borrowing rate at the date of issuance
of 6.31%, with the equity component representing the residual
amount of the proceeds of $248.0 million which was recorded as
a debt discount. Issuance costs were allocated pro-rata based on
the relative initial carrying amounts of the debt and equity
components. As a result, $5.2 million of the issuance costs
was allocated to the equity component of the Convertible Notes, and
$21.4 million of the issuance costs remained classified as
other non-current assets. The debt discount and the issuance costs
allocated to the debt component are amortized as additional
interest expense over the term of the Convertible Notes using the
effective interest method.
  (was, 2012-11-30, similarity 0.9235):
[0001193125-12-487586:note_history:28]
We separately account for the liability and equity components
of the Notes. The initial debt component of the Notes was valued at
$1,017.0 million based on the contractual cash flows
discounted at an appropriate comparable market non-convertible debt
borrowing rate at the date of issuance of 6.31%, with the equity
component representing the residual amount of the proceeds of
$248.0 million which was recorded as a debt discount. Issuance
costs were allocated pro-rata based on the relative initial
carrying amounts of the debt and equity components. As a result,
$5.2 million of the issuance costs was allocated to the equity
component of the Notes, and $21.4 million of the issuance
costs remained classified as other non-current assets. The debt
discount and the issuance costs allocated to the debt component are
amortized as additional interest expense over the term of the Notes
using the effective interest method and an effective interest rate
of 6.31% for all periods presented.

- changed (2013-02-28):
[0001193125-13-084667:note_history:29]
Convertible
Note Hedges and Warrants
  (was, 2012-11-30, similarity 0.8):
[0001193125-12-487586:note_history:29]
Note
Hedges and Warrants

- added (2013-02-28):
[0001193125-13-084667:note_history:30]
Concurrent with the issuance of the Convertible Notes, we
purchased Convertible Note hedges and sold warrants. The separate
Convertible Note hedge and warrant transactions are structured to
reduce the potential future economic dilution associated with the
conversion of the Convertible Notes.

- added (2013-02-28):
[0001193125-13-084667:note_history:31]
• Convertible Note Hedges: As of January 25, 2013
and April 27, 2012, we had arrangements with counterparties to
buy up to approximately 31.8 million shares of our common
stock, subject to anti-dilution adjustments, at a price of $31.85
per share, subject to adjustment. The Convertible Note hedge
transactions will expire at the earlier of (1) the last day on
which any Convertible Notes remain outstanding or (2) the
scheduled trading day immediately preceding the maturity date of
the Convertible Notes. Upon exercise of the Convertible Note
hedges, we have the option to receive cash or shares of our common
stock equal to the difference between the then market price and the
strike price of the Convertible Note hedges.

- changed (2013-02-28):
[0001193125-13-084667:note_history:32]
• Warrants: As of January 25, 2013 and
April 27, 2012, we had outstanding warrants for others to
acquire, subject to anti-dilution adjustments, 39.7 million
shares of our common stock at an exercise price of $41.28 per
share, subject to adjustment, on a series of days commencing on
September 3, 2013. Upon exercise of the warrants, we have the
option to deliver cash or shares of our common stock equal to the
difference between the then market price and the strike price of
the warrants.
  (was, 2012-11-30, similarity 0.985):
[0001193125-12-487586:note_history:32]
• Warrants: As of October 26, 2012 and
April 27, 2012, we had outstanding warrants for others to
acquire, subject to anti-dilution adjustments, 39.7 million
shares of our common stock at an exercise price of $41.28 per
share, subject to adjustment, on a series of days commencing on
September 3, 2013. Upon exercise of the warrants, we have the
option to deliver cash or shares of our common stock equal to the
difference between the then market price and the strike price of
the warrants.

- added (2013-02-28):
[0001193125-13-084667:note_history:33]
As of January 25, 2013, we were subject to potential
dilution on the approximately 20% unhedged portion of our
Convertible Notes upon conversion, if on the date of conversion,
the per-share market price of our common stock exceeds the
conversion price of $31.85.

- changed (2013-02-28):
[0001193125-13-084667:note_history:34]
As of January 25, 2013, we received a minimal number of
shares related to the Convertible Note hedge transactions and no
cash or shares were delivered related to the warrant
transactions.
  (was, 2012-11-30, similarity 0.9314):
[0001193125-12-487586:note_history:34]
As of October 26, 2012, we received a minimal number of
shares related to the Note hedge transactions and no cash or shares
were delivered related to the warrant transactions.

- added (2013-02-28):
[0001193125-13-084667:note_history:35]
Interest
Expense

- changed (2013-02-28):
[0001193125-13-084667:note_history:36]
The following table presents the amount of interest expense
recognized related to the Convertible Notes (in
millions):
  (was, 2012-11-30, similarity 0.9464):
[0001193125-12-487586:note_history:36]
The following table presents the amount of interest expense
recognized related to the Notes (in millions):

- changed (2013-02-28):
[0001193125-13-084667:note_history:37]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 27, 2012 |  |  | January 25, 2013 |  |  | January 27, 2012 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 16.5 |  |  | $ | 16.5 |  |
| Amortization of debt discount |  |  | 13.9 |  |  |  | 13.0 |  |  |  | 41.0 |  |  |  | 38.4 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 1.1 |  |  |  | 3.6 |  |  |  | 3.3 |  |
| Less capitalized interest |  |  | 0.0 |  |  |  | (0.9 | ) |  |  | (1.1 | ) |  |  | (4.3 | ) |
| Total interest expense related to Convertible Notes |  | $ | 20.6 |  |  | $ | 18.7 |  |  | $ | 60.0 |  |  | $ | 53.9 |  |
  (was, 2012-11-30, similarity 0.7628):
[0001193125-12-487586:note_history:37]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 11.0 |  |  | $ | 11.0 |  |
| Amortization of debt discount |  |  | 13.6 |  |  |  | 12.8 |  |  |  | 27.1 |  |  |  | 25.4 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 1.1 |  |  |  | 2.4 |  |  |  | 2.2 |  |
| Less capitalized interest |  |  | (0.6 | ) |  |  | (3.5 | ) |  |  | (1.1 | ) |  |  | (3.5 | ) |
| Total interest expense related to Notes |  | $ | 19.7 |  |  | $ | 15.9 |  |  | $ | 39.4 |  |  | $ | 35.1 |  |

- added (2013-02-28):
[0001193125-13-084667:note_history:38]
Debt
Maturities

- added (2013-02-28):
[0001193125-13-084667:note_history:39]
As of January 25, 2013, our aggregate future principal
debt maturities are as follows (in millions):

- added (2013-02-28):
[0001193125-13-084667:note_history:40]
| Fiscal Year |  | Amount |  |
| Remainder of 2013 |  | $ | 0.0 |  |
| 2014 |  |  | 1,264.9 |  |
| 2015 |  |  | 0.0 |  |
| 2016 |  |  | 0.0 |  |
| 2017 |  |  | 0.0 |  |
| Thereafter |  |  | 1,000.0 |  |
| Total |  | $ | 2,264.9 |  |

- added (2013-02-28):
[0001193125-13-084667:note_history:41]
Credit
Facility

- added (2013-02-28):
[0001193125-13-084667:note_history:42]
In December 2012, we entered into a credit agreement with a
syndicated group of lenders that provides for an unsecured $250.0
million five-year revolving credit facility that is comprised of
revolving loans, Eurocurrency loans and/or swingline loans. The
credit facility includes a $100.0 million foreign currency
sub-facility, a $50.0 million letter of credit sub-facility and a
$10.0 million swingline sub-facility available on same-day notice.
Available borrowings under the credit facility are reduced by the
amount of any outstanding borrowings on the sub-facilities. We may
also, subject to certain requirements, request an increase in the
facility up to an additional $100.0 million and request two
additional one-year extensions, subject to certain conditions. The
proceeds from the facility may be used by us for general corporate
purposes.

- added (2013-02-28):
[0001193125-13-084667:note_history:43]
Borrowings under the facility, except for swingline loans,
accrue interest in arrears at an alternate base rate as defined in
the credit agreement or, at our option, an adjusted London
Interbank Offered Rate (LIBOR) plus in each case, a spread (based
on our public debt ratings and the type of loan) ranging from 0.2%
to 1.2%. Swingline borrowings accrue interest at an alternate base
rate. In addition, we are required to pay fees to maintain the
credit facility, whether or not we have outstanding borrowings. The
facility terminates on December 21, 2017 if no extensions have
been requested and contains financial covenants requiring us to
maintain a maximum leverage ratio of not more than 3.0:1.0 and a
minimum interest coverage ratio of not less than 3.5:1.0. The
facility contains customary affirmative and negative covenants,
including covenants that limit our ability to incur debt secured by
liens on assets or indebtedness of our subsidiaries and to
consolidate, merge or sell all or substantially all of our assets.
As of January 25, 2013, no borrowings were outstanding under
the facility and we were in compliance with all covenants
associated with the facility.

- added (2013-02-28):
[0001193125-13-084667:note_history:44]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.4 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.6 |  |  |  | 3.5 |  |
| Total |  | $ | 12.0 |  |  | $ | 12.6 |  |

- removed (2013-02-28):
[0001193125-12-487586:note_history:45]
Our common stock price did not exceed the conversion threshold
price of $41.41 per share set forth for the Notes for at least 20
trading days during the 30 consecutive trading days ended
September 30, 2012, and accordingly, as of October 26,
2012, the Notes were not convertible at the option of the holder.
Since the Notes were not convertible, the difference between the
principal amount and the carrying value of the Notes was reflected
as equity on our condensed consolidated balance sheet as of
October 26, 2012.

- removed (2013-02-28):
[0001193125-12-487586:note_history:46]
The determination of whether or not the Notes are convertible
must continue to be performed quarterly. Consequently, if the
conversion threshold is exceeded during the quarter ending
January 25, 2013, the Notes will become unconditionally
convertible at that time. At such time that the Notes become
convertible at the option of the holder, the difference between the
principal amount and the carrying value of the Notes would be
reflected as convertible debt in mezzanine on our condensed
consolidated balance sheets.

- removed (2013-02-28):
[0001193125-12-487586:note_history:47]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| 1.75% Convertible Senior Notes due 2013 |  | $ | 1,264.9 |  |  | $ | 1,264.9 |  |
| Less: Unamortized discount |  |  | (35.5 | ) |  |  | (62.6 | ) |
| Net carrying amount of Notes |  | $ | 1,229.4 |  |  | $ | 1,202.3 |  |

- removed (2013-02-28):
[0001193125-12-487586:note_history:48]
The following table reflects the remaining debt discount and
issuance costs as of October 26, 2012 (in
millions):

- removed (2013-02-28):
[0001193125-12-487586:note_history:49]
| Remaining debt discount |  | $ | 35.5 |  |
| Remaining issuance costs |  |  | 3.0 |  |
| Remaining life of the Notes (years) |  |  | 0.6 |  |

- removed (2013-02-28):
[0001193125-12-487586:note_history:50]
Concurrent with the issuance of the Notes, we purchased Note
hedges and sold warrants. The separate Note hedge and warrant
transactions are structured to reduce the potential future economic
dilution associated with the conversion of the Notes.

- removed (2013-02-28):
[0001193125-12-487586:note_history:51]
• Note Hedges: As of October 26, 2012 and
April 27, 2012, we had arrangements with counterparties to buy
up to approximately 31.8 million shares of our common stock,
subject to anti-dilution adjustments, at a price of $31.85 per
share, subject to adjustment. The Note hedge transactions will
expire at the earlier of (1) the last day on which any Notes
remain outstanding or (2) the scheduled trading day
immediately preceding the maturity date of the Notes. Upon exercise
of the Note hedges, we have the option to receive cash or shares of
our common stock equal to the difference between the then market
price and the strike price of the hedges.

- removed (2013-02-28):
[0001193125-12-487586:note_history:52]
As of October 26, 2012, we were subject to potential
dilution on the approximately 20% unhedged portion of our Notes
upon conversion, if on the date of conversion, the per-share market
price of our common stock exceeds the conversion price of
$31.85.

- removed (2013-02-28):
[0001193125-12-487586:note_history:53]
Fair
Value of Notes

- removed (2013-02-28):
[0001193125-12-487586:note_history:54]
As of October 26, 2012, the fair value of the principal
amount of the Notes, which includes the debt and equity components,
was approximately $1,340.2 million, or 106.0% of the face value of
the Notes, based upon quoted market information provided by
third-party pricing providers (Level 1).

- removed (2013-02-28):
[0001193125-12-487586:note_history:55]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.0 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 6.3 |  |  |  | 3.5 |  |
| Total |  | $ | 12.3 |  |  | $ | 12.6 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2013-02-28):
[0001193125-13-084667:note_history:56]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.4 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.6 |  |  |  | 3.5 |  |
| Total |  | $ | 12.0 |  |  | $ | 12.6 |  |

- removed (2013-02-28):
[0001193125-12-487586:note_history:57]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.0 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 6.3 |  |  |  | 3.5 |  |
| Total |  | $ | 12.3 |  |  | $ | 12.6 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-02-28):
[0001193125-13-084667:note_history:58]
The
following table summarizes the carrying value of our long-term debt
(in millions):
  (was, 2012-11-30, similarity 0.795):
[0001193125-12-487586:note_history:58]
The following table reflects the carrying value of the Notes
(in millions):

- added (2013-02-28):
[0001193125-13-084667:note_history:59]
|  |  | January 25, 2013 |  |  | April 27, 2012 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 0.0 |  |  |  | N/A |  |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 0.0 |  |  |  | N/A |  |
| 1.75% Convertible Notes Due 2013 |  |  | 1,264.9 |  |  |  | 6.31 | % |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total |  |  | 2,264.9 |  |  |  |  |  |  |  | 1,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (27.3 | ) |  |  |  |  |  |  | (62.6 | ) |  |  |  |  |
| Total |  |  | 2,237.6 |  |  |  |  |  |  |  | 1,202.3 |  |  |  |  |  |
| Less: Current portion |  |  | (1,243.3 | ) |  |  |  |  |  |  | (1,202.3 | ) |  |  |  |  |
| Total long-term debt |  | $ | 994.3 |  |  |  |  |  |  | $ | 0.0 |  |  |  |  |  |

- added (2013-02-28):
[0001193125-13-084667:note_history:60]
N/A - Not
Applicable

- added (2013-02-28):
[0001193125-13-084667:note_history:61]
N/A - Not
Applicable

- removed (2013-02-28):
[0001193125-12-487586:note_history:62]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| 1.75% Convertible Senior Notes due 2013 |  | $ | 1,264.9 |  |  | $ | 1,264.9 |  |
| Less: Unamortized discount |  |  | (35.5 | ) |  |  | (62.6 | ) |
| Net carrying amount of Notes |  | $ | 1,229.4 |  |  | $ | 1,202.3 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2013-02-28):
[0001193125-13-084667:note_history:63]
As of
January 25, 2013, our aggregate future principal debt
maturities are as follows (in millions):

- added (2013-02-28):
[0001193125-13-084667:note_history:64]
| Fiscal Year |  | Amount |  |
| Remainder of 2013 |  | $ | 0.0 |  |
| 2014 |  |  | 1,264.9 |  |
| 2015 |  |  | 0.0 |  |
| 2016 |  |  | 0.0 |  |
| 2017 |  |  | 0.0 |  |
| Thereafter |  |  | 1,000.0 |  |
| Total |  | $ | 2,264.9 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2013-02-28):
[0001193125-12-487586:note_history:65]
16. Subsequent
Event

- removed (2013-02-28):
[0001193125-12-487586:note_history:66]
On November 14, 2012, we completed the acquisition of
CacheIQ, Inc., a privately held storage solutions company based in
Austin, Texas, for approximately $90.0 million in cash. This
acquisition provides us with intellectual property that extends our
capabilities to support non-disruptive operations for enterprise
data center environments. We will integrate this intellectual
property into our product offerings over time. Through
October 26, 2012, acquisition-related expenses associated with
the transaction were immaterial. We are in the process of
completing the purchase price allocation for this
acquisition. Pro forma results of operations have not been
presented because the acquisition was not material to our results
of operations.
