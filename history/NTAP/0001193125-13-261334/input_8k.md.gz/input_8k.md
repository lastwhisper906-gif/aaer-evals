# NTAP 8-K — 0001102624-13-000648 filed 2013-05-21

## item codes, every 8-K on or before 2013-06-17

- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2013-06-17

- none on or before 2013-06-17

## item 2.02 — earnings release, exhibit 99.1

[0001102624-13-000648:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-13-000648:8k_2_02:2]
exh99_1.htm

[0001102624-13-000648:8k_2_02:3]
Exhibit 99.1

[0001102624-13-000648:8k_2_02:4]
|  | Press Contact: | Investor Contact: |  |
|  | Ryan Lowry | Kris Newton |  |
|  | NetApp | NetApp |  |
|  | (408) 822-7544 | (408) 822-3312 |  |
|  | ryanl@netapp.com | kris.newton@netapp.com |  |

[0001102624-13-000648:8k_2_02:5]
NETAPP ANNOUNCES RESULTS FOR FOURTH QUARTER AND FISCAL YEAR 2013

[0001102624-13-000648:8k_2_02:6]
Announces $3 Billion Stock Repurchase Program; Initiates Quarterly Cash Dividend

[0001102624-13-000648:8k_2_02:7]
| ● | Q4 Revenues $1.717 Billion, Fiscal Year Revenues $6.332 Billion |

[0001102624-13-000648:8k_2_02:8]
| ● | Q4 GAAP EPS $0.47, Fiscal Year GAAP EPS $1.37 |

[0001102624-13-000648:8k_2_02:9]
| ● | Q4 Non-GAAP EPS $0.69, Fiscal Year Non-GAAP EPS $2.28 |

[0001102624-13-000648:8k_2_02:10]
Sunnyvale, Calif.—May 21, 2013—NetApp (NASDAQ: NTAP) today reported financial results for the fourth quarter and fiscal year 2013 ended April 26, 2013. Total revenues for the fourth quarter of fiscal year 2013 were $1.717 billion.

[0001102624-13-000648:8k_2_02:11]
GAAP net income for the fourth quarter of fiscal year 2013 was $174 million, or $0.47 per share,1 compared to GAAP net income of $181 million, or $0.47 per share, for the same period a year ago. Non-GAAP net income for the fourth quarter of fiscal year 2013 was $253 million, or $0.69 per share,2 compared to non-GAAP net income of $252 million, or $0.66 per share, for the same period a year ago.

[0001102624-13-000648:8k_2_02:12]
Total revenues for fiscal year 2013 were $6.332 billion, compared to total revenues of $6.233 billion for fiscal year 2012. GAAP net income for fiscal year 2013 was $505 million, or $1.37 per share, compared to GAAP net income of $605 million, or $1.58 per share, for fiscal year 2012. Non-GAAP net income for fiscal year 2013 was $841 million, or $2.28 per share, compared to non-GAAP net income of $926 million, or $2.41 per share, for fiscal year 2012.

[0001102624-13-000648:8k_2_02:13]
“The fourth quarter was highlighted by a continued strong uptake of clustered Data ONTAP®, an expansion of our leadership position in Flash, and double digit growth in branded bookings,” said Tom Georgens, president and CEO. “We are also pleased to announce enhancements to our capital allocation program, reflecting our confidence in our underlying business as well as our commitment to enhancing shareholder value.”

[0001102624-13-000648:8k_2_02:14]
Q1 Fiscal Year 2014 Outlook

[0001102624-13-000648:8k_2_02:15]
NetApp is providing the following financial guidance for the first quarter of fiscal year 2014:

[0001102624-13-000648:8k_2_02:16]
| ● | Revenues to be in the range of $1.475 billion to $1.575 billion. |

[0001102624-13-000648:8k_2_02:17]
| ● | GAAP earnings per share to be approximately $0.13 to $0.18 and non-GAAP earnings per share to be approximately $0.45 to $0.50. |

[0001102624-13-000648:8k_2_02:18]
| ● | Outstanding share count to decrease to approximately 367 million shares. |

[0001102624-13-000648:8k_2_02:19]
Business Highlights

[0001102624-13-000648:8k_2_02:20]
Capital Return to Shareholders

[0001102624-13-000648:8k_2_02:21]
The Company is increasing its current stock repurchase program, of which $1.4 billion remains outstanding, by an additional $1.6 billion. The Company plans to complete the aggregate $3 billion program over the next 3 years.  NetApp intends $2 billion of repurchases to be completed within the next 12 months, of which $1 billion is planned to be completed during the next 4 months. Under its stock repurchase program, NetApp can purchase shares of its outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by management.

[0001102624-13-000648:8k_2_02:22]
Additionally, NetApp has initiated a quarterly cash dividend of $0.15 per share of the Company’s common stock, which it intends to increase over time. The first dividend will be payable on July 23, 2013 to shareholders of record as of the close of business on July 11, 2013.

[0001102624-13-000648:8k_2_02:23]
The timing and amount of repurchase transactions under the program and future dividends will depend on market conditions, corporate business and financial considerations, and regulatory requirements.

[0001102624-13-000648:8k_2_02:24]
Resource Realignment

[0001102624-13-000648:8k_2_02:25]
The Company has undertaken a realignment of resources and restructuring which includes a global workforce reduction of approximately 900 employees. The Company expects to recognize an estimated aggregate $50 - $60 million pretax charge relating to employee severance and other restructuring charges.

[0001102624-13-000648:8k_2_02:26]
Quarterly Highlights

[0001102624-13-000648:8k_2_02:27]
In its fourth quarter of fiscal year 2013, NetApp continued to support customer success across a broad range of IT environments through its product and technology innovation and deepened strategic relationships with best-in-class partners.

[0001102624-13-000648:8k_2_02:28]
NetApp expanded its industry-leading flash portfolio with the availability of an all-flash array built on E-Series and previewed a new purpose-built all-flash storage architecture. NetApp also unveiled enhancements to its FAS high-end storage systems and continued to see industry momentum for clustered Data ONTAP. Finally, NetApp strengthened its partnerships with industry leaders VMware and SAP through deeper integration and joint solution development.

[0001102624-13-000648:8k_2_02:29]
Highlights include:

[0001102624-13-000648:8k_2_02:30]
NetApp Extends Leadership in Enterprise Flash Storage

[0001102624-13-000648:8k_2_02:31]
| ● | The new EF540 all-flash array is designed for today’s extreme performance-driven enterprise applications, while the purpose-built FlashRay product family is expected to deliver rich scale-out and storage efficiency features to maximize the benefits of all-flash arrays. With one of the strongest and broadest flash portfolios in the industry, including intelligent caching technologies Flash Cache™, Flash Pool™, and Flash Accel™, the new EF540 flash array and the forthcoming FlashRay family provide flexibility and choice and maximize the value of flash across the entire compute, network, and storage stack. |

[0001102624-13-000648:8k_2_02:32]
FAS and E-Series Innovation Helps Customers Accelerate Business

[0001102624-13-000648:8k_2_02:33]
| ● | Enhanced FAS high-end systems deliver increased performance and value. The new FAS/V6200, FAS6250, and FAS6290 systems leverage clustered Data ONTAP and enable IT operations to achieve a greater ROI while delivering high availability and scale for organizations’ most stringent application workloads. The new systems are flash enabled and can scale to over 65PB for increased agility. |

[0001102624-13-000648:8k_2_02:34]
8

[0001102624-13-000648:8k_2_02:35]
| ● | Big data and HPC customers accelerate time to market with new E-Series storage platform. With its seventh generation E-Series platform, the NetApp® E5500 builds on the modular scalability and proven reliability of previous generations and provides customers with a new level of performance and efficiency. The platform’s high-performance architecture, improved storage density, and additional support enhancements enable OEMs and customers to overcome the speed, scale, and reliability challenges posed by big data and high-performance computing environments. |

[0001102624-13-000648:8k_2_02:36]
Strengthened Partnerships Help Customers Transition to the Cloud

[0001102624-13-000648:8k_2_02:37]
| ● | NetApp and SAP collaborate to support next-generation solutions. In an effort to accelerate the deployment and delivery of database, analytics, and application solutions, NetApp and SAP will deepen their integration to support the SAP HANA platform and SAP NetWeaver Landscape Virtualization Management software. Through the expanded relationship, customers will have access to integrated solutions that reduce total cost of operations, drive greater business agility, and help them leverage the benefits of the cloud. |

[0001102624-13-000648:8k_2_02:38]
| ● | NetApp and VMware deliver integrated cloud infrastructure and mobile computing solutions to customers. New solutions and technology integration from NetApp and VMware combine the benefits of clustered Data ONTAP with VMware vCloud Suite and VMware Horizon Suite. The NetApp storage solution for VMware vCloud Suite enables enterprises and service providers to deliver a shared storage infrastructure for private cloud environments. The NetApp storage solution for VMware Horizon Suite delivers anytime access to desktops, applications, and data, and enables users to share the data securely. |

[0001102624-13-000648:8k_2_02:39]
NetApp Data ONTAP is Ranked the World’s #1 Branded Storage Operating System

[0001102624-13-000648:8k_2_02:40]
| ● | IDC ranked NetApp Data ONTAP as the world’s #1 branded storage operating system3 for calendar year 2012 within the open networked disk storage systems market. IDC’s Branded Storage Operating System results measure the value of the worldwide external disk storage systems market by revenue and new capacity shipments based on the underlying storage operating system in use. Data ONTAP ranked #1 in both categories. Built on more than 20 years of innovation, the Data ONTAP operating system has evolved to meet the changing needs of customers and help drive their success. Clustered Data ONTAP is the latest version, combining the richest data management feature set with clustering for unlimited scale, operational efficiency, and nondisruptive operations. |

[0001102624-13-000648:8k_2_02:41]
NetApp Enables Revlon to Simplify IT Operations

[0001102624-13-000648:8k_2_02:42]
| ● | Revlon turned to NetApp to help drive simplicity, agility, and cost efficiencies throughout all levels of its business, which ultimately helped the company make smarter IT decisions that help fuel company growth. By building on NetApp, Revlon successfully implemented a private cloud infrastructure that enabled the company to adapt to meet growing consumer demands. NetApp also helped Revlon harness its big data challenge, turning 3.6PB of data from a burden into a business driver. |

[0001102624-13-000648:8k_2_02:43]
Webcast and Conference Call Information

[0001102624-13-000648:8k_2_02:44]
The NetApp fourth quarter and fiscal year 2013 conference call will be broadcast live on the Internet at investors.netapp.com on Tuesday, May 21, 2013, at 2:30 p.m. Pacific Time. This press release and any other information related to the call will be posted on the Website at that location. An audio replay Webcast will be available after 4:00 p.m. Pacific Time on the Website.

[0001102624-13-000648:8k_2_02:45]
NetApp uses a hybrid format for disclosing key financial information associated with our quarterly results. Concurrent with the press release, NetApp posts a supplemental commentary with financial information and statistics to our Website at investors.netapp.com.

[0001102624-13-000648:8k_2_02:46]
We are also pleased to announce that the NetApp Annual Meeting of Stockholders has been scheduled for September 13, 2013 at 3:00 p.m. Pacific Time at the Company’s headquarters located at 495 East Java Drive, Sunnyvale, CA.

[0001102624-13-000648:8k_2_02:47]
About NetApp

[0001102624-13-000648:8k_2_02:48]
NetApp creates innovative storage and data management solutions that deliver outstanding cost efficiency and accelerate business breakthroughs. Our commitment to living our core values and consistently being recognized as a great place to work around the world are fundamental to our long-term growth and success, as well as the success of our pathway partners and customers. Discover our passion for helping companies around the world go further, faster at www.netapp.com.

[0001102624-13-000648:8k_2_02:49]
###

[0001102624-13-000648:8k_2_02:50]
NetApp, the NetApp logo, Go further, faster, Data ONTAP, FlashRay, Flash Accel, Flash Cache, and Flash Pool are trademarks or registered trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001102624-13-000648:8k_2_02:51]
| 1 | GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |
| 2 | Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. |
| 3 | IDC Worldwide Quarterly Disk Storage Systems Tracker Q4 2012, March 2013 (Open Networked Disk Storage Systems revenue) |

[0001102624-13-000648:8k_2_02:52]
NetApp Usage of Non-GAAP Financials

[0001102624-13-000648:8k_2_02:53]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-13-000648:8k_2_02:54]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation. We have historically reported similar non-GAAP financial measures to our investors and believe that the inclusion of comparative numbers provides consistency in our financial reporting at this time.

[0001102624-13-000648:8k_2_02:55]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 6,952.6 |  |  | $ | 5,398.5 |  |
| Accounts receivable, net |  |  | 800.9 |  |  |  | 830.9 |  |
| Inventories |  |  | 139.5 |  |  |  | 161.5 |  |
| Other current assets |  |  | 525.2 |  |  |  | 435.6 |  |
| Total current assets |  |  | 8,418.2 |  |  |  | 6,826.5 |  |
| Property and equipment, net |  |  | 1,170.9 |  |  |  | 1,137.2 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,168.7 |  |  |  | 1,141.2 |  |
| Other non-current assets |  |  | 484.6 |  |  |  | 427.4 |  |
| Total assets |  | $ | 11,242.4 |  |  | $ | 9,532.3 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 259.7 |  |  | $ | 233.1 |  |
| Accrued compensation and other current liabilities |  |  | 749.8 |  |  |  | 717.9 |  |
| Current portion of long-term debt |  |  | 1,257.8 |  |  |  | 1,202.3 |  |
| Short-term deferred revenue |  |  | 1,563.3 |  |  |  | 1,366.5 |  |
| Total current liabilities |  |  | 3,830.6 |  |  |  | 3,519.8 |  |
| Long-term debt |  |  | 994.6 |  |  |  | - |  |
| Other long-term liabilities |  |  | 253.5 |  |  |  | 206.9 |  |
| Long-term deferred revenue |  |  | 1,446.2 |  |  |  | 1,449.4 |  |
| Total liabilities |  |  | 6,524.9 |  |  |  | 5,176.1 |  |
| Convertible Notes |  |  | - |  |  |  | 62.6 |  |
| Stockholders' equity |  |  | 4,717.5 |  |  |  | 4,293.6 |  |
| Total liabilities and stockholders' equity |  | $ | 11,242.4 |  |  | $ | 9,532.3 |  |

[0001102624-13-000648:8k_2_02:56]
12

[0001102624-13-000648:8k_2_02:57]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,137.8 |  |  | $ | 1,165.1 |  |  | $ | 4,092.3 |  |  | $ | 4,209.7 |  |
| Software entitlements and maintenance |  |  | 227.0 |  |  |  | 212.5 |  |  |  | 893.5 |  |  |  | 812.2 |  |
| Service |  |  | 351.7 |  |  |  | 324.9 |  |  |  | 1,346.6 |  |  |  | 1,211.3 |  |
| Net revenues |  |  | 1,716.5 |  |  |  | 1,702.5 |  |  |  | 6,332.4 |  |  |  | 6,233.2 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 517.9 |  |  |  | 564.0 |  |  |  | 1,959.9 |  |  |  | 1,979.9 |  |
| Cost of software entitlements and maintenance |  |  | 7.4 |  |  |  | 6.8 |  |  |  | 28.3 |  |  |  | 23.9 |  |
| Cost of service |  |  | 159.0 |  |  |  | 136.7 |  |  |  | 583.1 |  |  |  | 516.0 |  |
| Total cost of revenues |  |  | 684.3 |  |  |  | 707.5 |  |  |  | 2,571.3 |  |  |  | 2,519.8 |  |
| Gross profit |  |  | 1,032.2 |  |  |  | 995.0 |  |  |  | 3,761.1 |  |  |  | 3,713.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 510.2 |  |  |  | 478.1 |  |  |  | 1,974.8 |  |  |  | 1,864.0 |  |
| Research and development |  |  | 243.4 |  |  |  | 221.6 |  |  |  | 904.2 |  |  |  | 828.2 |  |
| General and administrative |  |  | 74.2 |  |  |  | 71.5 |  |  |  | 272.6 |  |  |  | 264.9 |  |
| Acquisition-related expense |  |  | - |  |  |  | 2.4 |  |  |  | 1.7 |  |  |  | 9.8 |  |
| Total operating expenses |  |  | 827.8 |  |  |  | 773.6 |  |  |  | 3,153.3 |  |  |  | 2,966.9 |  |
| Income from operations |  |  | 204.4 |  |  |  | 221.4 |  |  |  | 607.8 |  |  |  | 746.5 |  |
| Other expense, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 10.1 |  |  |  | 10.6 |  |  |  | 42.2 |  |  |  | 38.2 |  |
| Interest expense |  |  | (28.0 | ) |  |  | (20.0 | ) |  |  | (91.7 | ) |  |  | (74.7 | ) |
| Other income, net |  |  | 2.4 |  |  |  | 2.5 |  |  |  | 8.3 |  |  |  | 2.4 |  |
| Total other expense, net |  |  | (15.5 | ) |  |  | (6.9 | ) |  |  | (41.2 | ) |  |  | (34.1 | ) |
| Income before income taxes |  |  | 188.9 |  |  |  | 214.5 |  |  |  | 566.6 |  |  |  | 712.4 |  |
| Provision for income taxes |  |  | 15.1 |  |  |  | 33.8 |  |  |  | 61.3 |  |  |  | 107.0 |  |
| Net income |  | $ | 173.8 |  |  | $ | 180.7 |  |  | $ | 505.3 |  |  | $ | 605.4 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.48 |  |  | $ | 0.50 |  |  | $ | 1.40 |  |  | $ | 1.66 |  |
| Diluted |  | $ | 0.47 |  |  | $ | 0.47 |  |  | $ | 1.37 |  |  | $ | 1.58 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 358.6 |  |  |  | 363.4 |  |  |  | 361.5 |  |  |  | 363.9 |  |
| Diluted |  |  | 368.2 |  |  |  | 381.7 |  |  |  | 368.0 |  |  |  | 384.3 |  |

[0001102624-13-000648:8k_2_02:58]
13

[0001102624-13-000648:8k_2_02:59]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOW |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 173.8 |  |  | $ | 180.7 |  |  | $ | 505.3 |  |  | $ | 605.4 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 89.1 |  |  |  | 82.6 |  |  |  | 344.6 |  |  |  | 293.1 |  |
| Stock-based compensation |  |  | 65.1 |  |  |  | 59.8 |  |  |  | 276.6 |  |  |  | 257.6 |  |
| Accretion of discount and issuance costs on debt |  |  | 16.2 |  |  |  | 14.2 |  |  |  | 60.2 |  |  |  | 52.9 |  |
| Excess tax benefit from stock-based compensation |  |  | (19.9 | ) |  |  | (32.6 | ) |  |  | (72.9 | ) |  |  | (113.3 | ) |
| Other, net |  |  | 2.3 |  |  |  | 33.5 |  |  |  | (6.0 | ) |  |  | 36.3 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (170.0 | ) |  |  | (146.2 | ) |  |  | 23.1 |  |  |  | (90.4 | ) |
| Inventories |  |  | 33.4 |  |  |  | (7.7 | ) |  |  | 22.0 |  |  |  | (16.5 | ) |
| Accounts payable |  |  | 41.1 |  |  |  | 21.8 |  |  |  | 25.1 |  |  |  | 11.4 |  |
| Accrued compensation and other current liabilities |  |  | 88.6 |  |  |  | 112.2 |  |  |  | 53.5 |  |  |  | (48.3 | ) |
| Deferred revenue |  |  | 135.4 |  |  |  | 271.9 |  |  |  | 198.1 |  |  |  | 506.4 |  |
| Changes in other operating assets and liabilities, net |  |  | 0.5 |  |  |  | (7.6 | ) |  |  | (43.3 | ) |  |  | (32.0 | ) |
| Net cash provided by operating activities |  |  | 455.6 |  |  |  | 582.6 |  |  |  | 1,386.3 |  |  |  | 1,462.6 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | (27.1 | ) |  |  | (1,403.7 | ) |  |  | 177.0 |  |  |  | (1,424.9 | ) |
| Purchases of property and equipment |  |  | (63.6 | ) |  |  | (124.2 | ) |  |  | (303.3 | ) |  |  | (407.1 | ) |
| Acquisitions of businesses, net of cash acquired |  |  | (17.1 | ) |  |  | - |  |  |  | (106.5 | ) |  |  | (480.0 | ) |
| Other investing activities, net |  |  | 1.2 |  |  |  | 1.6 |  |  |  | 4.2 |  |  |  | 1.6 |  |
| Net cash used in investing activities |  |  | (106.6 | ) |  |  | (1,526.3 | ) |  |  | (228.6 | ) |  |  | (2,310.4 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 15.1 |  |  |  | 41.1 |  |  |  | 110.6 |  |  |  | 142.1 |  |
| Repurchase and retirement of common stock |  |  | (180.0 | ) |  |  | - |  |  |  | (590.0 | ) |  |  | (600.0 | ) |
| Excess tax benefit from stock-based compensation |  |  | 19.9 |  |  |  | 32.6 |  |  |  | 72.9 |  |  |  | 113.3 |  |
| Issuance of long-term debt, net |  |  | - |  |  |  | - |  |  |  | 987.3 |  |  |  | - |  |
| Other financing activities, net |  |  | (1.2 | ) |  |  | (2.1 | ) |  |  | (1.9 | ) |  |  | 1.0 |  |
| Net cash provided by (used in) financing activities |  |  | (146.2 | ) |  |  | 71.6 |  |  |  | 578.9 |  |  |  | (343.6 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (7.4 | ) |  |  | 1.0 |  |  |  | (9.3 | ) |  |  | (16.1 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 195.4 |  |  |  | (871.1 | ) |  |  | 1,727.3 |  |  |  | (1,207.5 | ) |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 3,081.7 |  |  |  | 2,420.9 |  |  |  | 1,549.8 |  |  |  | 2,757.3 |  |
| End of period |  | $ | 3,277.1 |  |  | $ | 1,549.8 |  |  | $ | 3,277.1 |  |  | $ | 1,549.8 |  |

[0001102624-13-000648:8k_2_02:60]
14

[0001102624-13-000648:8k_2_02:61]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP AND GAAP |  |
| IN THE CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 26, 2013 |  |  | April 27, 2012 |  |  | April 26, 2013 |  |  | April 27, 2012 |  |
| SUMMARY RECONCILIATION OF NET INCOME |  |  |  |  |  |  |  |  |  |  |  |  |
| NET INCOME |  | $ | 173.8 |  |  | $ | 180.7 |  |  | $ | 505.3 |  |  | $ | 605.4 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 21.5 |  |  |  | 21.4 |  |  |  | 85.8 |  |  |  | 89.0 |  |
| Stock-based compensation |  |  | 65.1 |  |  |  | 59.8 |  |  |  | 276.6 |  |  |  | 257.6 |  |
| Acquisition-related expense |  |  | - |  |  |  | 2.4 |  |  |  | 1.7 |  |  |  | 17.8 |  |
| Non-cash interest expense |  |  | 16.2 |  |  |  | 14.2 |  |  |  | 60.2 |  |  |  | 52.9 |  |
| Gain on investments |  |  | - |  |  |  | (0.6 | ) |  |  | (0.7 | ) |  |  | (1.3 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (24.1 | ) |  |  | (25.5 | ) |  |  | (88.3 | ) |  |  | (95.2 | ) |
| NON-GAAP NET INCOME |  | $ | 252.5 |  |  | $ | 252.4 |  |  | $ | 840.6 |  |  | $ | 926.2 |  |
| NET INCOME PER SHARE |  | $ | 0.472 |  |  | $ | 0.473 |  |  | $ | 1.373 |  |  | $ | 1.575 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.058 |  |  |  | 0.056 |  |  |  | 0.233 |  |  |  | 0.232 |  |
| Stock-based compensation |  |  | 0.177 |  |  |  | 0.157 |  |  |  | 0.752 |  |  |  | 0.670 |  |
| Acquisition-related expense |  |  | - |  |  |  | 0.006 |  |  |  | 0.004 |  |  |  | 0.046 |  |
| Non-cash interest expense |  |  | 0.044 |  |  |  | 0.037 |  |  |  | 0.164 |  |  |  | 0.138 |  |
| Gain on investments |  |  | - |  |  |  | (0.001 | ) |  |  | (0.002 | ) |  |  | (0.003 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.065 | ) |  |  | (0.067 | ) |  |  | (0.240 | ) |  |  | (0.248 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.686 |  |  | $ | 0.661 |  |  | $ | 2.284 |  |  | $ | 2.410 |  |

[0001102624-13-000648:8k_2_02:62]
15

[0001102624-13-000648:8k_2_02:63]
| NETAPP, INC. |  |
| SUPPLEMENTAL INFORMATION |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended April 26, 2013 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Acquisition- related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 13.5 |  |  | $ | 1.4 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 14.9 |  |
| Cost of service revenues |  |  | 0.6 |  |  |  | 4.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 5.0 |  |
| Sales and marketing expenses |  |  | 7.4 |  |  |  | 30.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 37.8 |  |
| Research and development expenses |  |  | - |  |  |  | 20.3 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 20.3 |  |
| General and administrative expenses |  |  | - |  |  |  | 8.6 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 8.6 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 16.2 |  |  |  | - |  |  |  | 16.2 |  |
| Effect on income before income taxes |  | $ | 21.5 |  |  | $ | 65.1 |  |  | $ | - |  |  | $ | 16.2 |  |  | $ | - |  |  | $ | 102.8 |  |
|  |  | Three Months Ended April 27, 2012 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Acquisition- related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 14.0 |  |  | $ | 1.3 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 15.3 |  |
| Cost of service revenues |  |  | - |  |  |  | 4.0 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 4.0 |  |
| Sales and marketing expenses |  |  | 7.4 |  |  |  | 29.5 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 36.9 |  |
| Research and development expenses |  |  | - |  |  |  | 17.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 17.1 |  |
| General and administrative expenses |  |  | - |  |  |  | 7.9 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 7.9 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | 2.4 |  |  |  | - |  |  |  | - |  |  |  | 2.4 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 14.2 |  |  |  | - |  |  |  | 14.2 |  |
| Other income, net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.6 | ) |  |  | (0.6 | ) |
| Effect on income before income taxes |  | $ | 21.4 |  |  | $ | 59.8 |  |  | $ | 2.4 |  |  | $ | 14.2 |  |  | $ | (0.6 | ) |  | $ | 97.2 |  |
|  |  | Year Ended April 26, 2013 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Acquisition- related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 55.3 |  |  | $ | 6.1 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 61.4 |  |
| Cost of service revenues |  |  | 0.6 |  |  |  | 19.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 20.0 |  |
| Sales and marketing expense |  |  | 29.8 |  |  |  | 132.2 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 162.0 |  |
| Research and development expense |  |  | 0.1 |  |  |  | 84.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 84.2 |  |
| General and administrative expense |  |  | - |  |  |  | 34.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 34.8 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | 1.7 |  |  |  | - |  |  |  | - |  |  |  | 1.7 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 60.2 |  |  |  | - |  |  |  | 60.2 |  |
| Other income, net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |  |  | (0.7 | ) |
| Effect on income before income taxes |  | $ | 85.8 |  |  | $ | 276.6 |  |  | $ | 1.7 |  |  | $ | 60.2 |  |  | $ | (0.7 | ) |  | $ | 423.6 |  |
|  |  | Year Ended April 27, 2012 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Acquisition-related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 55.8 |  |  | $ | 5.4 |  |  | $ | 5.4 |  |  | $ | - |  |  | $ | - |  |  | $ | 66.6 |  |
| Cost of service revenues |  |  | - |  |  |  | 17.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 17.8 |  |
| Sales and marketing expense |  |  | 33.0 |  |  |  | 126.0 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 159.0 |  |
| Research and development expense |  |  | 0.2 |  |  |  | 74.1 |  |  |  | 2.6 |  |  |  | - |  |  |  | - |  |  |  | 76.9 |  |
| General and administrative expense |  |  | - |  |  |  | 34.3 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 34.3 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | 9.8 |  |  |  | - |  |  |  | - |  |  |  | 9.8 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 52.9 |  |  |  | - |  |  |  | 52.9 |  |
| Other income, net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (1.3 | ) |  |  | (1.3 | ) |
| Effect on income before income taxes |  | $ | 89.0 |  |  | $ | 257.6 |  |  | $ | 17.8 |  |  | $ | 52.9 |  |  | $ | (1.3 | ) |  | $ | 416.0 |  |

[0001102624-13-000648:8k_2_02:64]
16

[0001102624-13-000648:8k_2_02:65]
|  | NETAPP, INC. |
|  | RECONCILIATION OF NON GAAP GUIDANCE TO GAAP |
|  | EXPRESSED AS EARNINGS PER SHARE |
|  | FIRST QUARTER 2014 |
|  | (Unaudited) |
|  | First Quarter |
|  | 2014 |
| Non-GAAP Guidance - Net Income Per Share | $0.45 - $0.50 |
| Adjustments of Specific Items to |  |
| Net Income Per Share for the First |  |
| Quarter 2014: |  |
| Amortization of intangible assets | (0.04) |
| Stock-based compensation expense | (0.18) |
| Restructuring & other charges | (0.15) |
| Non-cash interest expense | (0.02) |
| Income tax effect | 0.07 |
| Total Adjustments | (0.32) |
| GAAP Guidance - Net Income Per Share | $0.13 - $0.18 |

[0001102624-13-000648:8k_2_02:66]
17
