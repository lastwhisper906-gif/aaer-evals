# NTAP 8-K — 0000950170-23-044130 filed 2023-08-23

## item codes, every 8-K on or before 2023-08-29

- 2023-08-23 0000950170-23-044130 — 2.02, 9.01
- 2023-08-10 0000950170-23-041348 — 5.02
- 2023-05-31 0000950170-23-025324 — 1.01, 2.02, 8.01, 9.01
- 2023-02-22 0000950170-23-003745 — 2.02, 9.01
- 2023-01-31 0001193125-23-019739 — 2.05, 7.01, 9.01
- 2022-11-29 0000950170-22-025793 — 2.02, 9.01
- 2022-11-16 0000950170-22-025317 — 5.02
- 2022-09-14 0000950170-22-018490 — 5.07
- 2022-08-24 0000950170-22-017731 — 2.02, 9.01
- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2023-08-29

- none on or before 2023-08-29

## item 2.02 — earnings release, exhibit 99.1

[0000950170-23-044130:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0000950170-23-044130:8k_2_02:2]
EX-99.1

[0000950170-23-044130:8k_2_02:3]
Exhibit 99.1

[0000950170-23-044130:8k_2_02:4]
NetApp reports first quarter of fiscal year 2024 results

[0000950170-23-044130:8k_2_02:5]
Net revenues of $1.43 billion for the first quarter

[0000950170-23-044130:8k_2_02:6]
•
Introduced significant innovations, including NetApp™ ASA A-Series, a new line of all-flash SAN storage systems

[0000950170-23-044130:8k_2_02:7]
•
Announced the Ransomware Recovery Guarantee, using NetApp’s comprehensive suite of integrated technologies to help customers protect against, detect, and recover from ransomware attacks

[0000950170-23-044130:8k_2_02:8]
•
AFF C-series fastest ramping all-flash systems launch in Company history; strong demand across all products in the family

[0000950170-23-044130:8k_2_02:9]
•
Cash from operations of $453 million increased 61% year over year; free cash flow1of $418 million grew 94% year over year

[0000950170-23-044130:8k_2_02:10]
•
$506 million returned to stockholders in share repurchases and cash dividends in the first quarter; representing 112% of cash from operations and 121% of free cash flow

[0000950170-23-044130:8k_2_02:11]
SAN JOSE, Calif.—August 23, 2023—NetApp (NASDAQ: NTAP) today reported financial results for the first quarter of fiscal year 2024, which ended on July 28, 2023.

[0000950170-23-044130:8k_2_02:12]
“We delivered a solid start to fiscal year 2024 in what continues to be a challenging macroeconomic environment. We are managing the elements within our control, driving better performance in our storage business, and building a more focused approach to cloud,” said George Kurian, chief executive officer. “In Q1, we introduced substantial innovation that helps our customers build stronger, smarter and more efficient hybrid multicloud infrastructures. I am delighted by the positive reception to our new products, as well as the differentiation and continued growth of our hyperscaler-managed storage services native to the leading public clouds.”

[0000950170-23-044130:8k_2_02:13]
First quarter of fiscal year 2024 financial results

[0000950170-23-044130:8k_2_02:14]
•
Net revenues: $1.43 billion, compared to $1.59 billion in the first quarter of fiscal year 2023; a year-over-year decrease of 10%.

[0000950170-23-044130:8k_2_02:15]
o
Hybrid Cloud segment revenue: $1.28 billion, compared to $1.46 billion in the first quarter of fiscal year 2023.

[0000950170-23-044130:8k_2_02:16]
o
Public Cloud segment revenue: $154 million, compared to $132 million in the first quarter of fiscal year 2023.

[0000950170-23-044130:8k_2_02:17]
•
Billings1: $1.30 billion, compared to $1.56 billion in the first quarter of fiscal year 2023; a year-over-year decrease of 17%.

[0000950170-23-044130:8k_2_02:18]
•
NetApp Public Cloud annualized revenue run rate (ARR)2: $619 million, compared to $584 million in the first quarter of fiscal year 2023; a year-over-year increase of 6%.

[0000950170-23-044130:8k_2_02:19]
•
All-flash array ARR3: $2.8 billion, compared to $3.0 billion in the first quarter of fiscal year 2023; a year-over-year decrease of 7%.

[0000950170-23-044130:8k_2_02:20]
•
Net income: GAAP net income of $149 million, compared to $214 million in the first quarter of fiscal year 2023; non-GAAP net income4 of $249 million, compared to $269 million in the first quarter of fiscal year 2023.

[0000950170-23-044130:8k_2_02:21]
•
Earnings per share: GAAP net income per share5 of $0.69 compared to $0.96 in the first quarter of fiscal year 2023; non-GAAP net income per share of $1.15 compared to $1.20 in the first quarter of fiscal year 2023.

[0000950170-23-044130:8k_2_02:22]
•
Cash, cash equivalents and investments: $2.98 billion at the end of the first quarter of fiscal year 2024.

[0000950170-23-044130:8k_2_02:23]
•
Cash provided by operations: $453 million, compared to $281 million in the first quarter of fiscal year 2023.

[0000950170-23-044130:8k_2_02:24]
•
Share repurchase and dividends: Returned $506 million to stockholders through share repurchases and cash dividends.

[0000950170-23-044130:8k_2_02:25]
Second quarter of fiscal year 2024 financial outlook

[0000950170-23-044130:8k_2_02:26]
The Company provided the following financial guidance for the second quarter of fiscal year 2024:

[0000950170-23-044130:8k_2_02:27]
| Net revenues are expected to be in the range of: | $1.455 billion to $1.605 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $0.90 - $1.00 | $1.35 - $1.45 |

[0000950170-23-044130:8k_2_02:28]
Full fiscal year 2024 financial outlook

[0000950170-23-044130:8k_2_02:29]
The Company reiterated the following financial guidance for the full fiscal year 2024:

[0000950170-23-044130:8k_2_02:30]
| Net revenues are expected to be down year-over-year in the low-to-mid single digits on a percentage basis. |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be: | ~69% | ~70% |
| Operating margins are expected to be: | ~18% | ~25% |
| Earnings per share is expected to be in the range of: | $3.75 - $3.95 | $5.65 - $5.85 |

[0000950170-23-044130:8k_2_02:31]
Dividend

[0000950170-23-044130:8k_2_02:32]
The next cash dividend of $0.50 per share is to be paid on October 25, 2023, to stockholders of record as of the close of business on October 6, 2023.

[0000950170-23-044130:8k_2_02:33]
First quarter of fiscal year 2024 business highlights

[0000950170-23-044130:8k_2_02:34]
Leading product innovation

[0000950170-23-044130:8k_2_02:35]
•
NetApp announced the ASA A-Series, a new line of all-flash SAN storage systems that delivers superior performance and scalability, a Six Nines Data Availability Guarantee, a 4:1 Storage Efficiency Guarantee, and hybrid cloud connectivity for business-critical applications and databases.

[0000950170-23-044130:8k_2_02:36]
•
NetApp introduced a Ransomware Recovery Guarantee. It uses the NetApp™ ONTAP™ innovative combination of key built-in security and ransomware protection features to automatically block known malicious file types, to block rogue admins and malicious users with multi-admin verification, and to provide tamper-proof NetApp Snapshot™ copies.

[0000950170-23-044130:8k_2_02:37]
•
NetApp announced that ONTAP One, the most comprehensive all-inclusive and built-in storage software, is now included on every NetApp AFF (A-Series and C-Series), ASA, and FAS system.

[0000950170-23-044130:8k_2_02:38]
•
NetApp announced the FAS2820 system, the latest addition to the NetApp hybrid flash portfolio, which offers up to a 50% performance improvement over its predecessor.

[0000950170-23-044130:8k_2_02:39]
•
NetApp and Cisco collaborated to develop a 100G FlexPod™ solution that is designed to deliver high performance, scalability, and reliability for data-intensive workloads.

[0000950170-23-044130:8k_2_02:40]
•
NetApp announced the availability of NetApp StorageGRID™ 11.7, the latest version of its software-defined object storage solution, and the StorageGRID SGF6112 appliance—the next-generation all-flash appliance for primary object storage workloads.

[0000950170-23-044130:8k_2_02:41]
•
NetApp announced new capabilities in the NetApp BlueXP™ unified control plane, such as simplified backup and recovery, data protection across more environments, and deployment in the most highly secured environments, including government sites.

[0000950170-23-044130:8k_2_02:42]
•
NetApp announced the general availability of BlueXP sustainability dashboard to all NetApp customers with a NetApp Support Site login, which includes three key components: environmental indicators, a sustainability score, and recommended actions.

[0000950170-23-044130:8k_2_02:43]
•
NetApp announced that NetApp Keystone™ storage-as-a-service (STaaS) solutions now provide proactive ransomware detection with Autonomous Ransomware Protection for continuous monitoring of NAS workloads at every data access point.

[0000950170-23-044130:8k_2_02:44]
•
NetApp announced the general availability of the latest update for NetApp Astra™ Control, which includes two major themes: adding finer control of the Astra Control application data management capabilities and making it easier than ever to use Astra Control at enterprise scale.

[0000950170-23-044130:8k_2_02:45]
•
NetApp introduced Spot Ocean CD, a continuous delivery solution for Kubernetes, which extends Spot Ocean and optimizes delivery of cloud applications by automating deployment strategies across clusters and workloads.

[0000950170-23-044130:8k_2_02:46]
Customer and partner momentum

[0000950170-23-044130:8k_2_02:47]
•
NetApp announced that Amazon FSx for NetApp ONTAP achieved Federal Risk and Authorization Management Program (FedRAMP) Moderate authorization in the AWS US East and AWS US West regions, and FedRAMP High authorization in AWS GovCloud US regions.

[0000950170-23-044130:8k_2_02:48]
•
NetApp announced the renewal of its strategic alliance and co-engineering partnership with DreamWorks Animation to remain DreamWorks’ preferred cloud data services provider.

[0000950170-23-044130:8k_2_02:49]
Corporate news and events

[0000950170-23-044130:8k_2_02:50]
•
NetApp released its 2023 State of CloudOps report, which found that only 33% of executives are “very confident” in their ability to operate in a public cloud environment.

[0000950170-23-044130:8k_2_02:51]
•
NetApp appointed Andrew Sotiropoulos as senior vice president and general manager for Asia-Pacific.

[0000950170-23-044130:8k_2_02:52]
Awards and recognition

[0000950170-23-044130:8k_2_02:53]
•
NetApp claimed the top spot in the SPECstorage Solution 2020 EDA Blended benchmark. NetApp technology was recognized for consistently delivering high performance to support more concurrent job sets than any other vendor, better scaling, and continued low latency as demands increase from more electronic design automation (EDA) workloads.

[0000950170-23-044130:8k_2_02:54]
•
NetApp was identified as best in class in the global cloud operations industry, receiving Frost & Sullivan’s 2023 Competitive Strategy Leadership Award.

[0000950170-23-044130:8k_2_02:55]
•
NetApp was named as one of America’s Climate Leaders by USA TODAY based on its commitment to reduce carbon emissions.

[0000950170-23-044130:8k_2_02:56]
•
NetApp was listed as one of the Best Companies to Work For by U.S. News.

[0000950170-23-044130:8k_2_02:57]
•
NetApp was named CRN’s 2023 Tech Innovator for Cloud Tools/Management.

[0000950170-23-044130:8k_2_02:58]
•
NetApp was recognized as one of the Best Places to Work by Disability:IN.

[0000950170-23-044130:8k_2_02:59]
•
NetApp was recognized as a finalist in the 2023 Microsoft US Partner of the Year Awards.

[0000950170-23-044130:8k_2_02:60]
•
NetApp CEO George Kurian was named one of the 25 Most Influential Executives of 2023 by CRN.

[0000950170-23-044130:8k_2_02:61]
•
NetApp’s Gabie Boko, senior vice president and chief marketing officer, was listed as one of HotTopics’ Top 100 Global B2B CMOs.

[0000950170-23-044130:8k_2_02:62]
•
NetApp’s Jenni Flinders, senior vice president, worldwide partner organization, was listed as one of CRN’s Most Powerful Women of the Channel for 2023.

[0000950170-23-044130:8k_2_02:63]
Webcast and conference call information

[0000950170-23-044130:8k_2_02:64]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:00 p.m. Pacific Time today.

[0000950170-23-044130:8k_2_02:65]
services, our ability to maintain our customer, partner, supplier and contract manufacturer relationships on favorable terms and conditions, general global political, macroeconomic and market conditions, including inflation, rising interest rates and foreign exchange volatility and the resulting impact on demand for our products, material cybersecurity and other security breaches, the impact of supply chain disruptions on our business operations, financial performance and results of operations, changes in U.S. government spending, revenue seasonality, changes in laws or regulations, including those relating to privacy, data protection and information security, and our ability to manage our gross profit margins. These and other equally important factors are described in reports and documents we file from time to time with the Securities and Exchange Commission, including the factors described under the section titled “Risk Factors” in our most recently submitted annual report on Form 10-K. We disclaim any obligation to update information contained in this press release whether as a result of new information, future events, or otherwise.

[0000950170-23-044130:8k_2_02:66]
###

[0000950170-23-044130:8k_2_02:67]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0000950170-23-044130:8k_2_02:68]
Footnotes

[0000950170-23-044130:8k_2_02:69]
1Refer to the NetApp Usage of Non-GAAP Financial Information section below for explanations of free cash flow and billings.

[0000950170-23-044130:8k_2_02:70]
2Public Cloud annualized revenue run rate (ARR) is calculated as the annualized value of all Public Cloud customer commitments with the assumption that any commitment expiring during the next 12 months will be renewed with its existing terms.

[0000950170-23-044130:8k_2_02:71]
3All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0000950170-23-044130:8k_2_02:72]
4Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) gains/losses on the sale of investments in equity securities, (i) debt extinguishment costs, and (j) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described

[0000950170-23-044130:8k_2_02:73]
below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes that the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0000950170-23-044130:8k_2_02:74]
5GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0000950170-23-044130:8k_2_02:75]
NetApp usage of non-GAAP financial information

[0000950170-23-044130:8k_2_02:76]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share. NetApp also presents the hardware and software components of our GAAP product revenues. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0000950170-23-044130:8k_2_02:77]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations.

[0000950170-23-044130:8k_2_02:78]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0000950170-23-044130:8k_2_02:79]
NetApp believes that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0000950170-23-044130:8k_2_02:80]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0000950170-23-044130:8k_2_02:81]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0000950170-23-044130:8k_2_02:82]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0000950170-23-044130:8k_2_02:83]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0000950170-23-044130:8k_2_02:84]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0000950170-23-044130:8k_2_02:85]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0000950170-23-044130:8k_2_02:86]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0000950170-23-044130:8k_2_02:87]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0000950170-23-044130:8k_2_02:88]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0000950170-23-044130:8k_2_02:89]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-23-044130:8k_2_02:90]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-23-044130:8k_2_02:91]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-23-044130:8k_2_02:92]
J. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges or benefits resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0000950170-23-044130:8k_2_02:93]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0000950170-23-044130:8k_2_02:94]
Constant Currency

[0000950170-23-044130:8k_2_02:95]
In periods in which the impacts of foreign currency exchange rate changes are significant, NetApp presents certain constant currency growth rates or quantifies the impact of foreign currency exchange rate changes on year-over-year fluctuations, including for net revenues, billings, and earnings. This constant currency information assumes the same foreign currency exchange rates that were in effect for the comparable prior-year period were used in translation of the current period results.

[0000950170-23-044130:8k_2_02:96]
About NetApp

[0000950170-23-044130:8k_2_02:97]
NetApp is a global, cloud-led, data-centric software company that empowers organizations to lead with data in the age of accelerated digital transformation. The company provides systems, software, and cloud services that enable them to run their applications optimally from data center to cloud, whether they are developing in the cloud, moving to the cloud, or creating their own cloudlike experiences on premises. With solutions that perform across diverse environments, NetApp helps organizations build their own data fabric and securely deliver the right data, services, and applications to the right people—anytime, anywhere. Learn more at www.netapp.com or follow us on Twitter, LinkedIn, Facebook, and Instagram.

[0000950170-23-044130:8k_2_02:98]
NETAPP, INC.

[0000950170-23-044130:8k_2_02:99]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-23-044130:8k_2_02:100]
(In millions)

[0000950170-23-044130:8k_2_02:101]
(Unaudited)

[0000950170-23-044130:8k_2_02:102]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 2,975 |  |  | $ | 3,070 |  |
| Accounts receivable |  |  | 653 |  |  |  | 987 |  |
| Inventories |  |  | 131 |  |  |  | 167 |  |
| Other current assets |  |  | 401 |  |  |  | 456 |  |
| Total current assets |  |  | 4,160 |  |  |  | 4,680 |  |
| Property and equipment, net |  |  | 641 |  |  |  | 650 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,925 |  |  |  | 2,940 |  |
| Other non-current assets |  |  | 1,544 |  |  |  | 1,548 |  |
| Total assets |  | $ | 9,270 |  |  | $ | 9,818 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 344 |  |  | $ | 392 |  |
| Accrued expenses |  |  | 778 |  |  |  | 857 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 2,127 |  |  |  | 2,218 |  |
| Total current liabilities |  |  | 3,249 |  |  |  | 3,467 |  |
| Long-term debt |  |  | 2,390 |  |  |  | 2,389 |  |
| Other long-term liabilities |  |  | 703 |  |  |  | 708 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 2,055 |  |  |  | 2,095 |  |
| Total liabilities |  |  | 8,397 |  |  |  | 8,659 |  |
| Stockholders' equity |  |  | 873 |  |  |  | 1,159 |  |
| Total liabilities and stockholders' equity |  | $ | 9,270 |  |  | $ | 9,818 |  |

[0000950170-23-044130:8k_2_02:103]
NETAPP, INC.

[0000950170-23-044130:8k_2_02:104]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-23-044130:8k_2_02:105]
(In millions, except per share amounts)

[0000950170-23-044130:8k_2_02:106]
(Unaudited)

[0000950170-23-044130:8k_2_02:107]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |
| Net revenues: |  |  |  |  |  |  |
| Product |  | $ | 590 |  |  | $ | 786 |  |
| Services |  |  | 842 |  |  |  | 806 |  |
| Net revenues |  |  | 1,432 |  |  |  | 1,592 |  |
| Cost of revenues: |  |  |  |  |  |  |
| Cost of product |  |  | 265 |  |  |  | 397 |  |
| Cost of services |  |  | 171 |  |  |  | 149 |  |
| Total cost of revenues |  |  | 436 |  |  |  | 546 |  |
| Gross profit |  |  | 996 |  |  |  | 1,046 |  |
| Operating expenses: |  |  |  |  |  |  |
| Sales and marketing |  |  | 468 |  |  |  | 458 |  |
| Research and development |  |  | 247 |  |  |  | 240 |  |
| General and administrative |  |  | 74 |  |  |  | 72 |  |
| Restructuring charges |  |  | 26 |  |  |  | 11 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 10 |  |
| Total operating expenses |  |  | 818 |  |  |  | 791 |  |
| Income from operations |  |  | 178 |  |  |  | 255 |  |
| Other income, net |  |  | 8 |  |  |  | 15 |  |
| Income before income taxes |  |  | 186 |  |  |  | 270 |  |
| Provision for income taxes |  |  | 37 |  |  |  | 56 |  |
| Net income |  | $ | 149 |  |  | $ | 214 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.70 |  |  | $ | 0.97 |  |
| Diluted |  | $ | 0.69 |  |  | $ | 0.96 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |
| Basic |  |  | 212 |  |  |  | 220 |  |
| Diluted |  |  | 216 |  |  |  | 224 |  |

[0000950170-23-044130:8k_2_02:108]
NETAPP, INC.

[0000950170-23-044130:8k_2_02:109]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-23-044130:8k_2_02:110]
(In millions)

[0000950170-23-044130:8k_2_02:111]
(Unaudited)

[0000950170-23-044130:8k_2_02:112]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income |  | $ | 149 |  |  | $ | 214 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 64 |  |  |  | 58 |  |
| Non-cash operating lease cost |  |  | 11 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 87 |  |  |  | 67 |  |
| Deferred income taxes |  |  | (6 | ) |  |  | (15 | ) |
| Other items, net |  |  | (2 | ) |  |  | (66 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |
| Accounts receivable |  |  | 332 |  |  |  | 364 |  |
| Inventories |  |  | 37 |  |  |  | (28 | ) |
| Accounts payable |  |  | (56 | ) |  |  | (90 | ) |
| Accrued expenses |  |  | (89 | ) |  |  | (208 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (133 | ) |  |  | (32 | ) |
| Long-term taxes payable |  |  | 1 |  |  |  | 1 |  |
| Changes in other operating assets and liabilities, net |  |  | 58 |  |  |  | 2 |  |
| Net cash provided by operating activities |  |  | 453 |  |  |  | 281 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of investments, net |  |  | (192 | ) |  |  | (131 | ) |
| Purchases of property and equipment |  |  | (35 | ) |  |  | (65 | ) |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | (491 | ) |
| Other investing activities, net |  |  | (1 | ) |  |  | 59 |  |
| Net cash used in investing activities |  |  | (228 | ) |  |  | (628 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 52 |  |  |  | 54 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (65 | ) |  |  | (52 | ) |
| Repurchase of common stock |  |  | (400 | ) |  |  | (350 | ) |
| Dividends paid |  |  | (106 | ) |  |  | (110 | ) |
| Other financing activities, net |  |  | (2 | ) |  |  | (1 | ) |
| Net cash used in financing activities |  |  | (521 | ) |  |  | (459 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | — |  |  |  | (18 | ) |
| Net change in cash, cash equivalents and restricted cash |  |  | (296 | ) |  |  | (824 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |
| Beginning of period |  |  | 2,322 |  |  |  | 4,119 |  |
| End of period |  | $ | 2,026 |  |  | $ | 3,295 |  |

[0000950170-23-044130:8k_2_02:113]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| Product |  | $ | 590 |  |  | $ | 744 |  |  | $ | 786 |  |
| Support |  |  | 611 |  |  |  | 598 |  |  |  | 598 |  |
| Professional and Other Services |  |  | 77 |  |  |  | 88 |  |  |  | 76 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,278 |  |  |  | 1,430 |  |  |  | 1,460 |  |
| Public Cloud Segment Net Revenues |  |  | 154 |  |  |  | 151 |  |  |  | 132 |  |
| Net Revenues |  | $ | 1,432 |  |  | $ | 1,581 |  |  | $ | 1,592 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| Product |  | $ | 326 |  |  | $ | 410 |  |  | $ | 391 |  |
| Support |  |  | 564 |  |  |  | 549 |  |  |  | 555 |  |
| Professional and Other Services |  |  | 19 |  |  |  | 33 |  |  |  | 24 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 909 |  |  |  | 992 |  |  |  | 970 |  |
| Public Cloud Segment Gross Profit |  |  | 103 |  |  |  | 99 |  |  |  | 92 |  |
| Total Segments Gross Profit |  |  | 1,012 |  |  |  | 1,091 |  |  |  | 1,062 |  |
| Amortization of Intangible Assets |  |  | (9 | ) |  |  | (10 | ) |  |  | (11 | ) |
| Stock-based Compensation |  |  | (7 | ) |  |  | (6 | ) |  |  | (5 | ) |
| Unallocated Cost of Revenues |  |  | (16 | ) |  |  | (16 | ) |  |  | (16 | ) |
| Gross Profit |  | $ | 996 |  |  | $ | 1,075 |  |  | $ | 1,046 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| Product |  |  | 55.3 | % |  |  | 55.1 | % |  |  | 49.7 | % |
| Support |  |  | 92.3 | % |  |  | 91.8 | % |  |  | 92.8 | % |
| Professional and Other Services |  |  | 24.7 | % |  |  | 37.5 | % |  |  | 31.6 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 71.1 | % |  |  | 69.4 | % |  |  | 66.4 | % |
| Public Cloud Segment Gross Margin |  |  | 66.9 | % |  |  | 65.6 | % |  |  | 69.7 | % |
| Product Revenues |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| Total |  | $ | 590 |  |  | $ | 744 |  |  | $ | 786 |  |
| Software* |  | $ | 342 |  |  | $ | 437 |  |  | $ | 476 |  |
| Hardware* |  | $ | 248 |  |  | $ | 307 |  |  | $ | 310 |  |
| Software and recurring support and public cloud revenue |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| Product - Software |  | $ | 342 |  |  | $ | 437 |  |  | $ | 476 |  |
| Support |  |  | 611 |  |  |  | 598 |  |  |  | 598 |  |
| Public Cloud |  |  | 154 |  |  |  | 151 |  |  |  | 132 |  |
| Software and recurring support and public cloud revenue* |  | $ | 1,107 |  |  | $ | 1,186 |  |  | $ | 1,206 |  |
| Software and recurring support and public cloud revenue as a percentage of net revenues |  |  | 77 | % |  |  | 75 | % |  |  | 76 | % |
| * Our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation. We have provided a breakdown of our GAAP product revenues into the software and hardware components, which are considered non-GAAP measures, to display the significance of software included in total product revenues. Software and recurring support and public cloud revenue is a non-GAAP measure because it includes the software component of our product revenues, but not the hardware component. |  |

[0000950170-23-044130:8k_2_02:114]
| Geographic Mix** |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'24 |  |  | % of Q4 FY'23 |  |  | % of Q1 FY'23 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 53 | % |  |  | 49 | % |  |  | 52 | % |
| Americas Commercial |  |  | 41 | % |  |  | 39 | % |  |  | 41 | % |
| U.S. Public Sector |  |  | 12 | % |  |  | 10 | % |  |  | 11 | % |
| EMEA |  |  | 31 | % |  |  | 36 | % |  |  | 32 | % |
| Asia Pacific |  |  | 16 | % |  |  | 15 | % |  |  | 16 | % |
| ** Effective in Q1 FY'24, management began evaluating revenues by geographic region based on the location to which products and services are delivered, rather than based on the location from which the customer relationship is managed. Prior period percentages have been conformed to the current period presentation. |  |
| Pathways Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'24 |  |  | % of Q4 FY'23 |  |  | % of Q1 FY'23 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 24 | % |  |  | 22 | % |  |  | 21 | % |
| Indirect |  |  | 76 | % |  |  | 78 | % |  |  | 79 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| Non-GAAP Income from Operations |  | $ | 309 |  |  | $ | 414 |  |  | $ | 360 |  |
| % of Net Revenues |  |  | 21.6 | % |  |  | 26.2 | % |  |  | 22.6 | % |
| Non-GAAP Income before Income Taxes |  | $ | 317 |  |  | $ | 419 |  |  | $ | 343 |  |
| Non-GAAP Effective Tax Rate |  |  | 21.5 | % |  |  | 20.3 | % |  |  | 21.6 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| Non-GAAP Net Income |  | $ | 249 |  |  | $ | 334 |  |  | $ | 269 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 216 |  |  |  | 217 |  |  |  | 224 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.15 |  |  | $ | 1.54 |  |  | $ | 1.20 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 4,182 |  |  | $ | 4,313 |  |  | $ | 4,170 |  |
| DSO (days) |  |  | 41 |  |  |  | 57 |  |  |  | 49 |  |
| DPO (days) |  |  | 72 |  |  |  | 70 |  |  |  | 86 |  |
| Inventory Turns |  |  | 13 |  |  |  | 12 |  |  |  | 9 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| Net Cash Provided by Operating Activities |  | $ | 453 |  |  | $ | 235 |  |  | $ | 281 |  |
| Purchases of Property and Equipment |  | $ | 35 |  |  | $ | 39 |  |  | $ | 65 |  |
| Free Cash Flow |  | $ | 418 |  |  | $ | 196 |  |  | $ | 216 |  |
| Free Cash Flow as % of Net Revenues |  |  | 29.2 | % |  |  | 12.4 | % |  |  | 13.6 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0000950170-23-044130:8k_2_02:115]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| NET INCOME |  | $ | 149 |  |  | $ | 245 |  |  | $ | 214 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 15 |  |  |  | 17 |  |  |  | 17 |  |
| Stock-based compensation |  |  | 87 |  |  |  | 74 |  |  |  | 67 |  |
| Restructuring charges |  |  | 26 |  |  |  | 11 |  |  |  | 11 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 3 |  |  |  | 10 |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | (32 | ) |
| Income tax effects |  |  | (31 | ) |  |  | 11 |  |  |  | (18 | ) |
| Income tax (benefits) expenses from integration of acquired companies |  |  | — |  |  |  | (27 | ) |  |  | — |  |
| NON-GAAP NET INCOME |  | $ | 249 |  |  | $ | 334 |  |  | $ | 269 |  |
| COST OF REVENUES |  | $ | 436 |  |  | $ | 506 |  |  | $ | 546 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (10 | ) |  |  | (11 | ) |
| Stock-based compensation |  |  | (7 | ) |  |  | (6 | ) |  |  | (5 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 420 |  |  | $ | 490 |  |  | $ | 530 |  |
| COST OF PRODUCT REVENUES |  | $ | 265 |  |  | $ | 335 |  |  | $ | 397 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 264 |  |  | $ | 334 |  |  | $ | 395 |  |
| COST OF SERVICES REVENUES |  | $ | 171 |  |  | $ | 171 |  |  | $ | 149 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (10 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (5 | ) |  |  | (4 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 156 |  |  | $ | 156 |  |  | $ | 135 |  |
| GROSS PROFIT |  | $ | 996 |  |  | $ | 1,075 |  |  | $ | 1,046 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 10 |  |  |  | 11 |  |
| Stock-based compensation |  |  | 7 |  |  |  | 6 |  |  |  | 5 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,012 |  |  | $ | 1,091 |  |  | $ | 1,062 |  |

[0000950170-23-044130:8k_2_02:116]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| SALES AND MARKETING EXPENSES |  | $ | 468 |  |  | $ | 442 |  |  | $ | 458 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (7 | ) |  |  | (6 | ) |
| Stock-based compensation |  |  | (36 | ) |  |  | (32 | ) |  |  | (28 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 426 |  |  | $ | 403 |  |  | $ | 424 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 247 |  |  | $ | 243 |  |  | $ | 240 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (32 | ) |  |  | (29 | ) |  |  | (24 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 215 |  |  | $ | 214 |  |  | $ | 216 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 74 |  |  | $ | 67 |  |  | $ | 72 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (12 | ) |  |  | (7 | ) |  |  | (10 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 62 |  |  | $ | 60 |  |  | $ | 62 |  |
| RESTRUCTURING CHARGES |  | $ | 26 |  |  | $ | 11 |  |  | $ | 11 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (26 | ) |  |  | (11 | ) |  |  | (11 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 3 |  |  | $ | 3 |  |  | $ | 10 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (3 | ) |  |  | (3 | ) |  |  | (10 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 818 |  |  | $ | 766 |  |  | $ | 791 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (7 | ) |  |  | (6 | ) |
| Stock-based compensation |  |  | (80 | ) |  |  | (68 | ) |  |  | (62 | ) |
| Restructuring charges |  |  | (26 | ) |  |  | (11 | ) |  |  | (11 | ) |
| Acquisition-related expense |  |  | (3 | ) |  |  | (3 | ) |  |  | (10 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 703 |  |  | $ | 677 |  |  | $ | 702 |  |

[0000950170-23-044130:8k_2_02:117]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| INCOME FROM OPERATIONS |  | $ | 178 |  |  | $ | 309 |  |  | $ | 255 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 15 |  |  |  | 17 |  |  |  | 17 |  |
| Stock-based compensation |  |  | 87 |  |  |  | 74 |  |  |  | 67 |  |
| Restructuring charges |  |  | 26 |  |  |  | 11 |  |  |  | 11 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 3 |  |  |  | 10 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 309 |  |  | $ | 414 |  |  | $ | 360 |  |
| OTHER INCOME, NET |  | $ | 8 |  |  | $ | 5 |  |  | $ | 15 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | (32 | ) |
| NON-GAAP OTHER INCOME (EXPENSE), NET |  | $ | 8 |  |  | $ | 5 |  |  | $ | (17 | ) |
| INCOME BEFORE INCOME TAXES |  | $ | 186 |  |  | $ | 314 |  |  | $ | 270 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 15 |  |  |  | 17 |  |  |  | 17 |  |
| Stock-based compensation |  |  | 87 |  |  |  | 74 |  |  |  | 67 |  |
| Restructuring charges |  |  | 26 |  |  |  | 11 |  |  |  | 11 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 3 |  |  |  | 10 |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | (32 | ) |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 317 |  |  | $ | 419 |  |  | $ | 343 |  |
| PROVISION FOR INCOME TAXES |  | $ | 37 |  |  | $ | 69 |  |  | $ | 56 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 31 |  |  |  | (11 | ) |  |  | 18 |  |
| Income tax benefits (expenses) from integration of acquired companies |  |  | — |  |  |  | 27 |  |  |  | — |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 68 |  |  | $ | 85 |  |  | $ | 74 |  |
| NET INCOME PER SHARE |  | $ | 0.69 |  |  | $ | 1.13 |  |  | $ | 0.96 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.07 |  |  |  | 0.08 |  |  |  | 0.08 |  |
| Stock-based compensation |  |  | 0.40 |  |  |  | 0.34 |  |  |  | 0.30 |  |
| Restructuring charges |  |  | 0.12 |  |  |  | 0.05 |  |  |  | 0.05 |  |
| Acquisition-related expense |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.04 |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | (0.14 | ) |
| Income tax effects |  |  | (0.14 | ) |  |  | 0.05 |  |  |  | (0.08 | ) |
| Income tax (benefits) expenses from integration of acquired companies |  |  | — |  |  |  | (0.12 | ) |  |  | — |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.15 |  |  | $ | 1.54 |  |  | $ | 1.20 |  |

[0000950170-23-044130:8k_2_02:118]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| Gross margin-GAAP |  |  | 69.6 | % |  |  | 68.0 | % |  |  | 65.7 | % |
| Cost of revenues adjustments |  |  | 1.1 | % |  |  | 1.0 | % |  |  | 1.0 | % |
| Gross margin-Non-GAAP |  |  | 70.7 | % |  |  | 69.0 | % |  |  | 66.7 | % |
| GAAP cost of revenues |  | $ | 436 |  |  | $ | 506 |  |  | $ | 546 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (10 | ) |  |  | (11 | ) |
| Stock-based compensation |  |  | (7 | ) |  |  | (6 | ) |  |  | (5 | ) |
| Non-GAAP cost of revenues |  | $ | 420 |  |  | $ | 490 |  |  | $ | 530 |  |
| Net revenues |  | $ | 1,432 |  |  | $ | 1,581 |  |  | $ | 1,592 |  |

[0000950170-23-044130:8k_2_02:119]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| Product gross margin-GAAP |  |  | 55.1 | % |  |  | 55.0 | % |  |  | 49.5 | % |
| Cost of product revenues adjustments |  |  | 0.2 | % |  |  | 0.1 | % |  |  | 0.3 | % |
| Product gross margin-Non-GAAP |  |  | 55.3 | % |  |  | 55.1 | % |  |  | 49.7 | % |
| GAAP cost of product revenues |  | $ | 265 |  |  | $ | 335 |  |  | $ | 397 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 264 |  |  | $ | 334 |  |  | $ | 395 |  |
| Product revenues |  | $ | 590 |  |  | $ | 744 |  |  | $ | 786 |  |

[0000950170-23-044130:8k_2_02:120]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| Services gross margin-GAAP |  |  | 79.7 | % |  |  | 79.6 | % |  |  | 81.5 | % |
| Cost of services revenues adjustments |  |  | 1.8 | % |  |  | 1.8 | % |  |  | 1.7 | % |
| Services gross margin-Non-GAAP |  |  | 81.5 | % |  |  | 81.4 | % |  |  | 83.3 | % |
| GAAP cost of services revenues |  | $ | 171 |  |  | $ | 171 |  |  | $ | 149 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (10 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (5 | ) |  |  | (4 | ) |
| Non-GAAP cost of services revenues |  | $ | 156 |  |  | $ | 156 |  |  | $ | 135 |  |
| Services revenues |  | $ | 842 |  |  | $ | 837 |  |  | $ | 806 |  |

[0000950170-23-044130:8k_2_02:121]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| GAAP effective tax rate |  |  | 19.9 | % |  |  | 22.0 | % |  |  | 20.7 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 1.6 | % |  |  | (10.3 | )% |  |  | 0.8 | % |
| Income tax benefits from integration of acquired companies |  |  | — | % |  |  | 8.6 | % |  |  | — | % |
| Non-GAAP effective tax rate |  |  | 21.5 | % |  |  | 20.3 | % |  |  | 21.6 | % |

[0000950170-23-044130:8k_2_02:122]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| Net cash provided by operating activities |  | $ | 453 |  |  | $ | 235 |  |  | $ | 281 |  |
| Purchases of property and equipment |  |  | (35 | ) |  |  | (39 | ) |  |  | (65 | ) |
| Free cash flow |  | $ | 418 |  |  | $ | 196 |  |  | $ | 216 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY24 |  |  | Q4'FY23 |  |  | Q1'FY23 |  |
| Net revenues |  | $ | 1,432 |  |  | $ | 1,581 |  |  | $ | 1,592 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | (133 | ) |  |  | 93 |  |  |  | (32 | ) |
| Billings |  | $ | 1,299 |  |  | $ | 1,674 |  |  | $ | 1,560 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0000950170-23-044130:8k_2_02:123]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| SECOND QUARTER FISCAL 2024 |
|  |  | Second Quarter |
|  |  | Fiscal 2024 |
| Non-GAAP Guidance - Net Income Per Share |  | $1.35-$1.45 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the Second Quarter Fiscal 2024: |  |  |
| Amortization of intangible assets |  | ($0.07) |
| Stock-based compensation expense |  | ($0.44) |
| Income tax effects |  | $0.06 |
| Total Adjustments |  | ($0.45) |
| GAAP Guidance - Net Income Per Share |  | $0.90-$1.00 |

[0000950170-23-044130:8k_2_02:124]
Some items may not add or recalculate due to rounding.

[0000950170-23-044130:8k_2_02:125]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| Fiscal 2024 |
|  |  | Fiscal 2024 |
| Gross Margin - Non-GAAP Guidance |  | ~70% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | (1)% |
| Gross Margin - GAAP Guidance |  | ~69% |
|  |  | Fiscal 2024 |
| Operating Margin - Non-GAAP Guidance |  | ~25% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | (1)% |
| Stock-based compensation expense |  | (6)% |
| Operating Margin - GAAP Guidance |  | ~18% |

[0000950170-23-044130:8k_2_02:126]
Some items may not add or recalculate due to rounding.

[0000950170-23-044130:8k_2_02:127]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| Fiscal 2024 |
|  |  | Fiscal 2024 |
| Non-GAAP Guidance - Net Income Per Share |  | $5.65-$5.85 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2024: |  |  |
| Amortization of intangible assets |  | ($0.27) |
| Stock-based compensation expense |  | ($1.78) |
| Restructuring charges |  | ($0.12) |
| Acquisition-related expenses |  | ($0.01) |
| Income tax effects |  | $0.28 |
| Total Adjustments |  | ($1.90) |
| GAAP Guidance - Net Income Per Share |  | $3.75-$3.95 |

[0000950170-23-044130:8k_2_02:128]
Some items may not add or recalculate due to rounding.

[0000950170-23-044130:8k_2_02:129]
Contacts:

[0000950170-23-044130:8k_2_02:130]
(Press)

[0000950170-23-044130:8k_2_02:131]
Kenya Hayes

[0000950170-23-044130:8k_2_02:132]
1 703 589 7595

[0000950170-23-044130:8k_2_02:133]
kenya.hayes@netapp.com

[0000950170-23-044130:8k_2_02:134]
(Investors)

[0000950170-23-044130:8k_2_02:135]
Kris Newton

[0000950170-23-044130:8k_2_02:136]
1 408 822 3312

[0000950170-23-044130:8k_2_02:137]
kris.newton@netapp.com
