# NTAP notes — 0000950170-23-045061


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000950170-23-045061:notes:1]
[same as prior period, unchanged from 0000950170-23-005545:notes:1]

[0000950170-23-045061:notes:2]
[same as prior period, unchanged from 0000950170-23-005545:notes:2]

[0000950170-23-045061:notes:3]
[same as prior period, unchanged from 0000950170-23-005545:notes:3]

[0000950170-23-045061:notes:4]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal years 2024 and 2023, ending on April 26, 2024 and April 28, 2023, respectively, are each 52-week years, with 13 weeks in each quarter.

[0000950170-23-045061:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 28, 2023 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 28, 2023 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0000950170-23-045061:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, the anticipated effects of which have been incorporated, as applicable, into management's estimates as of July 28, 2023.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000950170-23-045061:notes:7]
2. Recent Accounting Pronouncements

[0000950170-23-045061:notes:8]
Although there are new accounting pronouncements issued or proposed by the FASB that we have adopted or will adopt, as applicable, we do not believe any of these accounting pronouncements had or will have a material impact on our consolidated financial position, operating results, cash flows or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-23-045061:notes:9]
3. Business Combination

[0000950170-23-045061:notes:10]
[same as prior period, unchanged from 0000950170-23-005545:notes:10]

[0000950170-23-045061:notes:11]
[same as prior period, unchanged from 0000950170-23-005545:notes:11]

[0000950170-23-045061:notes:12]
[same as prior period, unchanged from 0000950170-23-005545:notes:12]

[0000950170-23-045061:notes:13]
[same as prior period, unchanged from 0000950170-23-005545:notes:26]

[0000950170-23-045061:notes:14]
|  |  | Amount |  |
| Cash |  | $ | 4 |  |
| Intangible assets |  |  | 107 |  |
| Goodwill |  |  | 413 |  |
| Other assets |  |  | 19 |  |
| Total assets acquired |  |  | 543 |  |
| Liabilities assumed |  |  | (45 | ) |
| Total purchase price |  | $ | 498 |  |

[0000950170-23-045061:notes:15]
[same as prior period, unchanged from 0000950170-23-005545:notes:15]

[0000950170-23-045061:notes:16]
[same as prior period, unchanged from 0000950170-23-005545:notes:16]

[0000950170-23-045061:notes:17]
[same as prior period, unchanged from 0000950170-23-005545:notes:17]

[0000950170-23-045061:notes:18]
[same as prior period, unchanged from 0000950170-23-005545:notes:18]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-23-045061:notes:19]
[same as prior period, unchanged from 0000950170-23-005545:notes:34]

[0000950170-23-045061:notes:20]
Goodwill by reportable segment as of July 28, 2023 is as follows (in millions):

[0000950170-23-045061:notes:21]
|  |  | Amount |  |
| Hybrid Cloud |  | $ | 1,714 |  |
| Public Cloud |  |  | 1,045 |  |
| Total goodwill |  | $ | 2,759 |  |

[0000950170-23-045061:notes:22]
[same as prior period, unchanged from 0000950170-23-005545:notes:40]

[0000950170-23-045061:notes:23]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 179 |  |  | $ | (83 | ) |  | $ | 96 |  |  | $ | 212 |  |  | $ | (107 | ) |  | $ | 105 |  |
| Customer contracts/relationships |  |  | 114 |  |  |  | (45 | ) |  |  | 69 |  |  |  | 118 |  |  |  | (44 | ) |  |  | 74 |  |
| Other purchased intangibles |  |  | 6 |  |  |  | (5 | ) |  |  | 1 |  |  |  | 6 |  |  |  | (4 | ) |  |  | 2 |  |
| Total purchased intangible assets |  | $ | 299 |  |  | $ | (133 | ) |  | $ | 166 |  |  | $ | 336 |  |  | $ | (155 | ) |  | $ | 181 |  |

[0000950170-23-045061:notes:24]
During the first quarter of fiscal 2024, we retired approximately $37 million of fully amortized intangible assets.

[0000950170-23-045061:notes:25]
[same as prior period, unchanged from 0000950170-23-005545:notes:42]

[0000950170-23-045061:notes:26]
|  |  | Three Months Ended |  |  | Statements of |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  | IncomeClassification |
| Developed technology |  | $ | 9 |  |  | $ | 10 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 5 |  |  |  | 6 |  |  | Operating expenses |
| Other purchased intangibles |  |  | 1 |  |  |  | 1 |  |  | Operating expenses |
| Total |  | $ | 15 |  |  | $ | 17 |  |  |  |

[0000950170-23-045061:notes:27]
As of July 28, 2023, future amortization expense related to purchased intangible assets is as follows (in millions):

[0000950170-23-045061:notes:28]
| Fiscal Year |  | Amount |  |
| 2024 (remainder) |  | $ | 42 |  |
| 2025 |  |  | 55 |  |
| 2026 |  |  | 39 |  |
| 2027 |  |  | 29 |  |
| 2028 |  |  | 1 |  |
| Total |  | $ | 166 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-23-045061:notes:29]
[same as prior period, unchanged from 0000950170-23-005545:notes:47]

[0000950170-23-045061:notes:30]
[same as prior period, unchanged from 0000950170-23-005545:notes:48]

[0000950170-23-045061:notes:31]
[same as prior period, unchanged from 0000950170-23-005545:notes:49]

[0000950170-23-045061:notes:32]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| Cash and cash equivalents |  | $ | 2,020 |  |  | $ | 2,316 |  |
| Restricted cash |  |  | 6 |  |  |  | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,026 |  |  | $ | 2,322 |  |

[0000950170-23-045061:notes:33]
[same as prior period, unchanged from 0000950170-23-005545:notes:51]

[0000950170-23-045061:notes:34]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| Purchased components |  | $ | 69 |  |  | $ | 65 |  |
| Finished goods |  |  | 62 |  |  |  | 102 |  |
| Inventories |  | $ | 131 |  |  | $ | 167 |  |

[0000950170-23-045061:notes:35]
[same as prior period, unchanged from 0000950170-23-005545:notes:53]

[0000950170-23-045061:notes:36]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 361 |  |  |  | 359 |  |
| Leasehold improvements |  |  | 82 |  |  |  | 91 |  |
| Computer, production, engineering and other equipment |  |  | 1,070 |  |  |  | 1,053 |  |
| Computer software |  |  | 329 |  |  |  | 325 |  |
| Furniture and fixtures |  |  | 78 |  |  |  | 84 |  |
| Construction-in-progress |  |  | 67 |  |  |  | 55 |  |
|  |  |  | 2,033 |  |  |  | 2,013 |  |
| Accumulated depreciation and amortization |  |  | (1,392 | ) |  |  | (1,363 | ) |
| Property and equipment, net |  | $ | 641 |  |  | $ | 650 |  |

[0000950170-23-045061:notes:37]
[same as prior period, unchanged from 0000950170-23-005545:notes:55]

[0000950170-23-045061:notes:38]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| Deferred tax assets |  | $ | 954 |  |  | $ | 948 |  |
| Operating lease ROU assets |  |  | 270 |  |  |  | 281 |  |
| Other assets |  |  | 320 |  |  |  | 319 |  |
| Other non-current assets |  | $ | 1,544 |  |  | $ | 1,548 |  |

[0000950170-23-045061:notes:39]
Other non-current assets as of July 28, 2023 and April 28, 2023 include $82 million and $80 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies. Our sales to LNTL are conducted on terms equivalent to those prevailing in an arm’s length transaction.

[0000950170-23-045061:notes:40]
[same as prior period, unchanged from 0000950170-23-005545:notes:58]

[0000950170-23-045061:notes:41]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| Accrued compensation and benefits |  | $ | 314 |  |  | $ | 363 |  |
| Product warranty liabilities |  |  | 18 |  |  |  | 17 |  |
| Operating lease liabilities |  |  | 44 |  |  |  | 47 |  |
| Other current liabilities |  |  | 402 |  |  |  | 430 |  |
| Accrued expenses |  | $ | 778 |  |  | $ | 857 |  |

[0000950170-23-045061:notes:42]
[same as prior period, unchanged from 0000950170-23-005545:notes:60]

[0000950170-23-045061:notes:43]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| Liability for uncertain tax positions |  | $ | 145 |  |  | $ | 144 |  |
| Income taxes payable |  |  | 215 |  |  |  | 215 |  |
| Product warranty liabilities |  |  | 9 |  |  |  | 8 |  |
| Operating lease liabilities |  |  | 238 |  |  |  | 248 |  |
| Other liabilities |  |  | 96 |  |  |  | 93 |  |
| Other long-term liabilities |  | $ | 703 |  |  | $ | 708 |  |

[0000950170-23-045061:notes:44]
[same as prior period, unchanged from 0000950170-23-005545:notes:62]

[0000950170-23-045061:notes:45]
[same as prior period, unchanged from 0000950170-23-005545:notes:63]

[0000950170-23-045061:notes:46]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| Deferred product revenue |  | $ | 21 |  |  | $ | 18 |  |
| Deferred services revenue |  |  | 4,119 |  |  |  | 4,247 |  |
| Financed unearned services revenue |  |  | 42 |  |  |  | 48 |  |
| Total |  | $ | 4,182 |  |  | $ | 4,313 |  |
| Reported as: |  |  |  |  |  |  |
| Short-term |  | $ | 2,127 |  |  | $ | 2,218 |  |
| Long-term |  |  | 2,055 |  |  |  | 2,095 |  |
| Total |  | $ | 4,182 |  |  | $ | 4,313 |  |

[0000950170-23-045061:notes:47]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 15 – Commitments and Contingencies for additional information related to these arrangements.

[0000950170-23-045061:notes:48]
During the three months ended July 28, 2023 and July 29, 2022, we recognized revenue of $658 million and $706 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0000950170-23-045061:notes:49]
As of July 28, 2023, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied approximated our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 51% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 24% in the next 13 to 24 months, and the remainder thereafter.

[0000950170-23-045061:notes:50]
[same as prior period, unchanged from 0000950170-23-005545:notes:69]

[0000950170-23-045061:notes:51]
[same as prior period, unchanged from 0000950170-23-005545:notes:70]

[0000950170-23-045061:notes:52]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| Other current assets |  | $ | 65 |  |  | $ | 64 |  |
| Other non-current assets |  |  | 96 |  |  |  | 99 |  |
| Total deferred commissions |  | $ | 161 |  |  | $ | 163 |  |

[0000950170-23-045061:notes:53]
Other income, net (in millions):

[0000950170-23-045061:notes:54]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |
| Interest income |  | $ | 28 |  |  | $ | 7 |  |
| Interest expense |  |  | (16 | ) |  |  | (18 | ) |
| Other, net |  |  | (4 | ) |  |  | 26 |  |
| Total other income, net |  | $ | 8 |  |  | $ | 15 |  |

[0000950170-23-045061:notes:55]
In the three months ended July 29, 2022, Other, net includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million.

[0000950170-23-045061:notes:56]
[same as prior period, unchanged from 0000950170-23-005545:notes:75]

[0000950170-23-045061:notes:57]
[same as prior period, unchanged from 0000950170-23-005545:notes:76]

[0000950170-23-045061:notes:58]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 21 |  |  | $ | 20 |  |  |  |
| Liabilities incurred to former owners of acquired business |  | $ | — |  |  | $ | 3 |  |  |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 9 |  |  | $ | 12 |  |  |  |
| Interest paid |  | $ | 23 |  |  | $ | 27 |  |  |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-23-045061:notes:59]
[same as prior period, unchanged from 0000950170-23-005545:notes:78]

[0000950170-23-045061:notes:60]
[same as prior period, unchanged from 0000950170-23-005545:notes:79]

[0000950170-23-045061:notes:61]
[same as prior period, unchanged from 0000950170-23-005545:notes:80]

[0000950170-23-045061:notes:62]
[same as prior period, unchanged from 0000950170-23-005545:notes:81]

[0000950170-23-045061:notes:63]
[same as prior period, unchanged from 0000950170-23-005545:notes:82]

[0000950170-23-045061:notes:64]
[same as prior period, unchanged from 0000950170-23-005545:notes:83]

[0000950170-23-045061:notes:65]
[same as prior period, unchanged from 0000950170-23-005545:notes:84]

[0000950170-23-045061:notes:66]
The following is a summary of our investments at their cost or amortized cost as of July 28, 2023 and April 28, 2023 (in millions):

[0000950170-23-045061:notes:67]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |  |
| U.S. Treasury and government debt securities |  |  | 1,005 |  |  |  | 754 |  |  |
| Money market funds |  |  | 436 |  |  |  | 794 |  |  |
| Certificates of deposit |  |  | 54 |  |  |  | 59 |  |  |
| Mutual funds |  |  | 39 |  |  |  | 36 |  |  |
| Total debt and equity securities |  | $ | 1,534 |  |  | $ | 1,643 |  |  |

[0000950170-23-045061:notes:68]
[same as prior period, unchanged from 0000950170-23-005545:notes:87]

[0000950170-23-045061:notes:69]
As of July 28, 2023, all our debt investments are due to mature in one year or less.

[0000950170-23-045061:notes:70]
[same as prior period, unchanged from 0000950170-23-005545:notes:89]

[0000950170-23-045061:notes:71]
[same as prior period, unchanged from 0000950170-23-005545:notes:90]

[0000950170-23-045061:notes:72]
|  |  | July 28, 2023 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 1,480 |  |  | $ | 1,480 |  |  | $ | — |  |
| Money market funds |  |  | 436 |  |  |  | 436 |  |  |  | — |  |
| Certificates of deposit |  |  | 54 |  |  |  | — |  |  |  | 54 |  |
| U.S. Treasury and government debt securities |  |  | 50 |  |  |  | 50 |  |  |  | — |  |
| Total cash and cash equivalents |  |  | 2,020 |  |  |  | 1,966 |  |  |  | 54 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 955 |  |  |  | 955 |  |  |  | — |  |
| Total short-term investments |  |  | 955 |  |  |  | 955 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 2,975 |  |  | $ | 2,921 |  |  | $ | 54 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 8 |  |  | $ | 8 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 31 |  |  | $ | 31 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0000950170-23-045061:notes:73]
|  |  | April 28, 2023 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 1,463 |  |  | $ | 1,463 |  |  | $ | — |  |
| Money market funds |  |  | 794 |  |  |  | 794 |  |  |  | — |  |
| Certificates of deposit |  |  | 59 |  |  |  | — |  |  |  | 59 |  |
| Total cash and cash equivalents |  |  | 2,316 |  |  |  | 2,257 |  |  |  | 59 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 754 |  |  |  | 754 |  |  |  | — |  |
| Total short-term investments |  |  | 754 |  |  |  | 754 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,070 |  |  | $ | 3,011 |  |  | $ | 59 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 29 |  |  | $ | 29 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |

[0000950170-23-045061:notes:74]
[same as prior period, unchanged from 0000950170-23-005545:notes:93]

[0000950170-23-045061:notes:75]
[same as prior period, unchanged from 0000950170-23-005545:notes:94]

[0000950170-23-045061:notes:76]
[same as prior period, unchanged from 0000950170-23-005545:notes:95]

[0000950170-23-045061:notes:77]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of July 28, 2023 and April 28, 2023, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0000950170-23-045061:notes:78]
[same as prior period, unchanged from 0000950170-23-005545:notes:97]

[0000950170-23-045061:notes:79]
As of July 28, 2023 and April 28, 2023, the fair value of our long-term debt was approximately $2,185 million and $2,206 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0000950170-23-045061:notes:80]
7. Financing Arrangements

[0000950170-23-045061:notes:81]
Long-Term Debt

[0000950170-23-045061:notes:82]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0000950170-23-045061:notes:83]
|  |  | Effective Interest Rate |  | July 28, 2023 |  |  | April 28, 2023 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,400 |  |  |  | 2,400 |  |
| Unamortized discount and issuance costs |  |  |  |  | (10 | ) |  |  | (11 | ) |
| Total long-term debt |  |  |  | $ | 2,390 |  |  | $ | 2,389 |  |

[0000950170-23-045061:notes:84]
Senior Notes

[0000950170-23-045061:notes:85]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were each issued in June 2020. Interest on each of these Senior Notes is payable semi-annually in June and December. Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September.

[0000950170-23-045061:notes:86]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0000950170-23-045061:notes:87]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 28, 2023, we were in compliance with all covenants associated with the Senior Notes.

[0000950170-23-045061:notes:88]
As of July 28, 2023, our aggregate future principal debt maturities are as follows (in millions):

[0000950170-23-045061:notes:89]
| Fiscal Year |  | Amount |  |
| 2024 (remainder) |  | $ | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| 2027 |  |  | — |  |
| 2028 |  |  | 550 |  |
| Thereafter |  |  | 700 |  |
| Total |  | $ | 2,400 |  |

[0000950170-23-045061:notes:90]
Commercial Paper Program and Credit Facility

[0000950170-23-045061:notes:91]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of July 28, 2023 or April 28, 2023.

[0000950170-23-045061:notes:92]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023 primarily to replace the London Interbank Offered Rate (LIBOR) with the Secured Overnight Financing Rate (SOFR) as the basis for establishing the interest rate applicable to certain borrowings under the agreement, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of July 28, 2023, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0000950170-23-045061:notes:93]
[same as prior period, unchanged from 0000950170-23-005545:notes:113]

[0000950170-23-045061:notes:94]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of July 28, 2023, have remaining lease terms not exceeding 19 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of July 28, 2023, have remaining lease terms not exceeding 4 years. As of July 28, 2023, our automobile leases have remaining lease terms not exceeding 4 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0000950170-23-045061:notes:95]
[same as prior period, unchanged from 0000950170-23-005545:notes:115]

[0000950170-23-045061:notes:96]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |
| Operating lease cost |  | $ | 14 |  |  | $ | 15 |  |
| Variable lease cost |  |  | 4 |  |  |  | 4 |  |
| Total lease cost |  | $ | 18 |  |  | $ | 19 |  |

[0000950170-23-045061:notes:97]
[same as prior period, unchanged from 0000950170-23-005545:notes:117]

[0000950170-23-045061:notes:98]
[same as prior period, unchanged from 0000950170-23-005545:notes:118]

[0000950170-23-045061:notes:99]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 14 |  |  | $ | 14 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  | $ | 9 |  |  | $ | 38 |  |

[0000950170-23-045061:notes:100]
[same as prior period, unchanged from 0000950170-23-005545:notes:120]

[0000950170-23-045061:notes:101]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| Other non-current assets |  | $ | 270 |  |  | $ | 281 |  |
| Total operating lease ROU assets |  | $ | 270 |  |  | $ | 281 |  |
| Accrued expenses |  | $ | 44 |  |  | $ | 47 |  |
| Other long-term liabilities |  |  | 238 |  |  |  | 248 |  |
| Total operating lease liabilities |  | $ | 282 |  |  | $ | 295 |  |
| Weighted Average Remaining Lease Term |  | 9.6 years |  |  | 9.4 years |  |
| Weighted Average Discount Rate |  |  | 3.0 | % |  |  | 3.0 | % |

[0000950170-23-045061:notes:102]
Future minimum operating lease payments as of July 28, 2023, are as follows (in millions):

[0000950170-23-045061:notes:103]
| Fiscal Year |  | Amount |  |
| 2024 (remainder) |  | $ | 38 |  |
| 2025 |  |  | 42 |  |
| 2026 |  |  | 36 |  |
| 2027 |  |  | 32 |  |
| 2028 |  |  | 28 |  |
| Thereafter |  |  | 152 |  |
| Total lease payments |  |  | 328 |  |
| Less: Interest |  |  | (46 | ) |
| Total |  | $ | 282 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000950170-23-045061:notes:104]
[same as prior period, unchanged from 0000950170-23-005545:notes:124]

[0000950170-23-045061:notes:105]
[same as prior period, unchanged from 0000950170-23-005545:notes:125]

[0000950170-23-045061:notes:106]
We granted approximately 4 million restricted stock units (RSUs), including performance-based RSUs (PBRSUs), during the three months ended July 28, 2023, with a weighted average grant date fair value of $77.82. As the remaining number of shares available for issuance under the 2021 Equity Incentive Plan (the 2021 Plan) was insufficient to support the grant of all these awards, most of these awards (the Contingent Awards) are currently subject to settlement, upon vesting, in an amount of cash equal to the product of (x) the fair market value of one share of the Company’s common stock on the day immediately preceding the vesting date and (y) the number of vested RSUs or earned PBRSUs. Because of this cash-settlement provision, the Contingent Awards are accounted for as liability awards and are subject to remeasurement to their fair value at the end of each reporting period. However, if stockholders approve an increase in the number of shares available for issuance under the 2021 Plan sufficient to permit all then-outstanding awards under the 2021 Plan to settle in shares (consistent with the proposal to be voted on at the Company’s 2023 Annual Meeting of Stockholders on September 13, 2023), any outstanding Contingent Awards will become share-settled, equity-classified, awards.

[0000950170-23-045061:notes:107]
In the three months ended July 28, 2023, we granted PBRSUs to certain of our executives, all of which are Contingent Awards. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSUs cliff-vest at the end of a three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the third fiscal year, following the grant date. The number of shares that will be used to calculate the settlement amount for all of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the three months ended July 28, 2023, the number of shares used to calculate the  settlement amount will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. For the remaining half of the PBRSUs granted in the three months ended July 28, 2023, the number of shares used to calculate the settlement amount will depend upon the Company's billings result average over the three-year performance period as compared to a predetermined billings target. Billings for purposes of measuring the performance of these PBRSUs means the total obtained by adding net revenues

[0000950170-23-045061:notes:108]
as reported on the Company's Consolidated Statements of Income to the amount reported as the change in deferred revenue and financed unearned services revenue on the Consolidated Statements of Cash Flows for the applicable measurement period, excluding the impact of fluctuations in foreign currency exchange rates. The aggregate grant date fair value of PBRSUs effectively granted in the current year was $32 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0000950170-23-045061:notes:109]
[same as prior period, unchanged from 0000950170-23-005545:notes:128]

[0000950170-23-045061:notes:110]
[same as prior period, unchanged from 0000950170-23-005545:notes:129]

[0000950170-23-045061:notes:111]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |
| Cost of services revenues |  |  | 6 |  |  |  | 4 |  |
| Sales and marketing |  |  | 36 |  |  |  | 28 |  |
| Research and development |  |  | 32 |  |  |  | 24 |  |
| General and administrative |  |  | 12 |  |  |  | 10 |  |
| Total stock-based compensation expense |  | $ | 87 |  |  | $ | 67 |  |

[0000950170-23-045061:notes:112]
For the three months ended July 28, 2023, $83 million of total stock-based compensation expense pertains to equity-classified awards, while the remainder pertains to the liability-classified Contingent Awards.

[0000950170-23-045061:notes:113]
As of July 28, 2023, total unrecognized compensation expense related to equity awards was $547 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.1 years. Total unrecognized compensation expense related to the liability-classified Contingent Awards was $307 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 3.7 years.

[0000950170-23-045061:notes:114]
[same as prior period, unchanged from 0000950170-23-005545:notes:132]

[0000950170-23-045061:notes:115]
As of July 28, 2023, our Board of Directors has authorized the repurchase of up to $16.1 billion of our common stock. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time.

[0000950170-23-045061:notes:116]
The following table summarizes activity related to the stock repurchase program for the three months ended July 28, 2023 (in millions, except for per share amounts):

[0000950170-23-045061:notes:117]
| Number of shares repurchased |  |  | 5 |  |
| Average price per share |  | $ | 74.14 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 24 |  |
| Stock repurchases allocated to retained earnings |  | $ | 376 |  |
| Remaining authorization at end of period |  | $ | 1,002 |  |

[0000950170-23-045061:notes:118]
Since the May 13, 2003 inception of our stock repurchase program through July 28, 2023, we repurchased a total of 365 million shares of our common stock at an average price of $41.38 per share, for an aggregate purchase price of $15.1 billion.

[0000950170-23-045061:notes:119]
[same as prior period, unchanged from 0000950170-23-005545:notes:137]

[0000950170-23-045061:notes:120]
[same as prior period, unchanged from 0000950170-23-005545:notes:138]

[0000950170-23-045061:notes:121]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |
| Dividends per share declared |  | $ | 0.50 |  |  | $ | 0.50 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 68 |  |  | $ | 106 |  |
| Dividend payments allocated to retained earnings |  | $ | 38 |  |  | $ | 4 |  |

[0000950170-23-045061:notes:122]
On August 22, 2023, we declared a cash dividend of $0.50 per share of common stock, payable on October 25, 2023 to holders of record as of the close of business on October 6, 2023. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0000950170-23-045061:notes:123]
[same as prior period, unchanged from 0000950170-23-005545:notes:142]

[0000950170-23-045061:notes:124]
[same as prior period, unchanged from 0000950170-23-005545:notes:143]

[0000950170-23-045061:notes:125]
|  |  | ForeignCurrencyTranslationAdjustments |  |  | DefinedBenefitObligationAdjustments |  |  | UnrealizedGains(Losses) onDerivativeInstruments |  |  | Total |  |
| Balance as of April 28, 2023 |  | $ | (48 | ) |  | $ | (3 | ) |  | $ | — |  |  | $ | (51 | ) |
| Other comprehensive gain, net of tax |  |  | 2 |  |  |  | — |  |  |  | 2 |  |  |  | 4 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |
| Total other comprehensive income |  |  | 2 |  |  |  | — |  |  |  | 1 |  |  |  | 3 |  |
| Balance as of July 28, 2023 |  | $ | (46 | ) |  | $ | (3 | ) |  | $ | 1 |  |  | $ | (48 | ) |

[0000950170-23-045061:notes:126]
[same as prior period, unchanged from 0000950170-23-005545:notes:145]

[0000950170-23-045061:notes:127]
|  |  | Three Months Ended |  |  |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  | Statements ofIncome Classification |
| Realized gains on cash flow hedges |  | $ | (1 | ) |  | $ | (1 | ) |  | Net revenues |
| Total reclassifications |  | $ | (1 | ) |  | $ | (1 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-23-045061:notes:128]
[same as prior period, unchanged from 0000950170-23-005545:notes:147]

[0000950170-23-045061:notes:129]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of July 28, 2023 or April 28, 2023. All contracts have a maturity of less than 12 months.

[0000950170-23-045061:notes:130]
[same as prior period, unchanged from 0000950170-23-005545:notes:149]

[0000950170-23-045061:notes:131]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 108 |  |  | $ | 95 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 885 |  |  | $ | 965 |  |
| Forward contracts purchased |  | $ | 184 |  |  | $ | 96 |  |

[0000950170-23-045061:notes:132]
[same as prior period, unchanged from 0000950170-23-005545:notes:151]

[0000950170-23-045061:notes:133]
The effect of derivative instruments not designated as hedging instruments recognized in other income, net on our condensed consolidated statements of income was as follows (in millions):

[0000950170-23-045061:notes:134]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |
| Foreign currency exchange contracts |  | $ | (4 | ) |  | $ | (21 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-23-045061:notes:135]
[same as prior period, unchanged from 0000950170-23-005545:notes:154]

[0000950170-23-045061:notes:136]
In the first quarter of fiscal 2024, we initiated a restructuring plan to redirect resources to highest return activities, and to optimize our global office space for our hybrid work model. In connection with the plan, we reduced our global workforce by approximately 1% and terminated certain real estate leases in various countries, resulting in restructuring charges comprised primarily of employee severance-related expenses and lease termination charges. The workforce related activities under the plan are substantially complete.

[0000950170-23-045061:notes:137]
In the first three months of fiscal 2023, we executed, or continued to execute, restructuring plans to redirect resources to highest return activities and to establish our international headquarters in Cork, Ireland, which included a reduction in our global workforce of less than 1% and resulted in restructuring charges comprised primarily of employee severance-related costs and legal and tax-related professional fees. Substantially all activities under these plans were complete as of the end of fiscal 2023.

[0000950170-23-045061:notes:138]
[same as prior period, unchanged from 0000950170-23-005545:notes:159]

[0000950170-23-045061:notes:139]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |
| Balance at beginning of period |  | $ | 36 |  |  | $ | 1 |  |
| Net charges |  |  | 26 |  |  |  | 11 |  |
| Cash payments |  |  | (31 | ) |  |  | (3 | ) |
| Balance at end of period |  | $ | 31 |  |  | $ | 9 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-045061:notes:140]
[same as prior period, unchanged from 0000950170-23-005545:notes:161]

[0000950170-23-045061:notes:141]
[same as prior period, unchanged from 0000950170-23-005545:notes:162]

[0000950170-23-045061:notes:142]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |
| Effective tax rates |  |  | 19.9 | % |  |  | 20.7 | % |

[0000950170-23-045061:notes:143]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. Our effective tax rate for the three months ended July 28, 2023 decreased from the prior year, primarily due to increased fiscal 2023 foreign tax credits resulting from Internal Revenue Service Notice 2023-55 released during the quarter, partially offset by an increase in stock compensation for which no tax benefit is currently recorded. The effective tax rate for the three months ended July 29, 2022, includes larger discrete tax benefits related to stock-based compensation than the current year.

[0000950170-23-045061:notes:144]
[same as prior period, unchanged from 0000950170-23-005545:notes:167]

[0000950170-23-045061:notes:145]
[same as prior period, unchanged from 0000950170-23-005545:notes:168]

[0000950170-23-045061:notes:146]
As of July 28, 2023, we had $221 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $145 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $145 million have been recorded in other long-term liabilities.


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-045061:notes:147]
[same as prior period, unchanged from 0000950170-23-005545:notes:170]

[0000950170-23-045061:notes:148]
[same as prior period, unchanged from 0000950170-23-005545:notes:171]

[0000950170-23-045061:notes:149]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |
| Numerator: |  |  |  |  |  |  |
| Net income |  | $ | 149 |  |  | $ | 214 |  |
| Denominator: |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 212 |  |  |  | 220 |  |
| Dilutive impact of employee equity award plans |  |  | 4 |  |  |  | 4 |  |
| Shares used in diluted computation |  |  | 216 |  |  |  | 224 |  |
| Net Income per Share: |  |  |  |  |  |  |
| Basic |  | $ | 0.70 |  |  | $ | 0.97 |  |
| Diluted |  | $ | 0.69 |  |  | $ | 0.96 |  |

[0000950170-23-045061:notes:150]
One and five million shares from outstanding employee awards were excluded from the diluted net income per share calculation for the three months ended July 28, 2023 and July 29, 2022, respectively, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-045061:notes:151]
[same as prior period, unchanged from 0000950170-23-005545:notes:174]

[0000950170-23-045061:notes:152]
[same as prior period, unchanged from 0000950170-23-005545:notes:175]

[0000950170-23-045061:notes:153]
[same as prior period, unchanged from 0000950170-23-005545:notes:176]

[0000950170-23-045061:notes:154]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage and data services, and cloud operations services. Public Cloud includes certain reseller arrangements in which the timing of our consideration follows the end user consumption of the reseller services.

[0000950170-23-045061:notes:155]
[same as prior period, unchanged from 0000950170-23-005545:notes:178]

[0000950170-23-045061:notes:156]
[same as prior period, unchanged from 0000950170-23-005545:notes:179]

[0000950170-23-045061:notes:157]
|  | Three Months Ended July 28, 2023 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 590 |  |  | $ | — |  |  | $ | 590 |  |
| Support revenues |  | 611 |  |  |  | — |  |  |  | 611 |  |
| Professional and other services revenues |  | 77 |  |  |  | — |  |  |  | 77 |  |
| Public cloud revenues |  | — |  |  |  | 154 |  |  |  | 154 |  |
| Net revenues |  | 1,278 |  |  |  | 154 |  |  |  | 1,432 |  |
| Cost of product revenues |  | 264 |  |  |  | — |  |  |  | 264 |  |
| Cost of support revenues |  | 47 |  |  |  | — |  |  |  | 47 |  |
| Cost of professional and other services revenues |  | 58 |  |  |  | — |  |  |  | 58 |  |
| Cost of public cloud revenues |  | — |  |  |  | 51 |  |  |  | 51 |  |
| Segment cost of revenues |  | 369 |  |  |  | 51 |  |  |  | 420 |  |
| Segment gross profit | $ | 909 |  |  | $ | 103 |  |  | $ | 1,012 |  |
| Segment gross margin |  | 71.1 | % |  |  | 66.9 | % |  |  | 70.7 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 16 |  |
| Total gross profit |  |  |  |  |  |  | $ | 996 |  |
| Total gross margin |  |  |  |  |  |  |  | 69.6 | % |
| 1 Unallocated cost of revenues are composed of $7 million of stock-based compensation expense and $9 million of amortization of intangible assets. |  |

[0000950170-23-045061:notes:158]
|  | Three Months Ended July 29, 2022 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 786 |  |  | $ | — |  |  | $ | 786 |  |
| Support revenues |  | 598 |  |  |  | — |  |  |  | 598 |  |
| Professional and other services revenues |  | 76 |  |  |  | — |  |  |  | 76 |  |
| Public cloud revenues |  | — |  |  |  | 132 |  |  |  | 132 |  |
| Net revenues |  | 1,460 |  |  |  | 132 |  |  |  | 1,592 |  |
| Cost of product revenues |  | 395 |  |  |  | — |  |  |  | 395 |  |
| Cost of support revenues |  | 43 |  |  |  | — |  |  |  | 43 |  |
| Cost of professional and other services revenues |  | 52 |  |  |  | — |  |  |  | 52 |  |
| Cost of public cloud revenues |  | — |  |  |  | 40 |  |  |  | 40 |  |
| Segment cost of revenues |  | 490 |  |  |  | 40 |  |  |  | 530 |  |
| Segment gross profit | $ | 970 |  |  | $ | 92 |  |  | $ | 1,062 |  |
| Segment gross margin |  | 66.4 | % |  |  | 69.7 | % |  |  | 66.7 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 16 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,046 |  |
| Total gross margin |  |  |  |  |  |  |  | 65.7 | % |
| 1 Unallocated cost of revenues are composed of $5 million of stock-based compensation expense and $11 million of amortization of intangible assets. |  |

[0000950170-23-045061:notes:159]
[same as prior period, unchanged from 0000950170-23-005545:notes:184]

[0000950170-23-045061:notes:160]
[same as prior period, unchanged from 0000950170-23-005545:notes:185]

[0000950170-23-045061:notes:161]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |
| United States, Canada and Latin America (Americas) |  | $ | 754 |  |  | $ | 827 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 446 |  |  |  | 509 |  |
| Asia Pacific (APAC) |  |  | 232 |  |  |  | 256 |  |
| Net revenues |  | $ | 1,432 |  |  | $ | 1,592 |  |

[0000950170-23-045061:notes:162]
Effective in the three months ended July 28, 2023, management began evaluating revenues by geographic region based on the location to which products and services are delivered, rather than based on the location from which the customer relationship is managed. Prior period numbers have been recast to conform to the current period presentation. Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $699 million and $772 million during the three months ended July 28, 2023 and July 29, 2022, respectively.

[0000950170-23-045061:notes:163]
[same as prior period, unchanged from 0000950170-23-005545:notes:188]

[0000950170-23-045061:notes:164]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| U.S. |  | $ | 842 |  |  | $ | 887 |  |
| International |  |  | 2,133 |  |  |  | 2,183 |  |
| Total |  | $ | 2,975 |  |  | $ | 3,070 |  |

[0000950170-23-045061:notes:165]
[same as prior period, unchanged from 0000950170-23-005545:notes:190]

[0000950170-23-045061:notes:166]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| U.S. |  | $ | 407 |  |  | $ | 413 |  |
| International |  |  | 234 |  |  |  | 237 |  |
| Total |  | $ | 641 |  |  | $ | 650 |  |

[0000950170-23-045061:notes:167]
[same as prior period, unchanged from 0000950170-23-005545:notes:192]

[0000950170-23-045061:notes:168]
[same as prior period, unchanged from 0000950170-23-005545:notes:193]

[0000950170-23-045061:notes:169]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 25 | % |
| TD Synnex Corporation (previously presented as Tech Data Corporation) |  |  | 21 | % |  |  | 21 | % |

[0000950170-23-045061:notes:170]
[same as prior period, unchanged from 0000950170-23-005545:notes:195]

[0000950170-23-045061:notes:171]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| Arrow Electronics, Inc. |  |  | 10 | % |  |  | 15 | % |
| TD Synnex Corporation (previously presented as Tech Data Corporation) |  |  | 17 | % |  |  | 19 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-045061:notes:172]
15. Commitments and Contingencies

[0000950170-23-045061:notes:173]
Purchase Orders and Other Commitments

[0000950170-23-045061:notes:174]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of July 28, 2023, we had approximately $0.5 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 28, 2023 and April 28, 2023, such liability amounted to $18 million and $15 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0000950170-23-045061:notes:175]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 28, 2023, we had approximately $0.3 billion in other purchase obligations.

[0000950170-23-045061:notes:176]
Financing Guarantees

[0000950170-23-045061:notes:177]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $19 million and $3 million of receivables during the three months ended July 28, 2023 and July 29, 2022, respectively.

[0000950170-23-045061:notes:178]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0000950170-23-045061:notes:179]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of July 28, 2023 and April 28, 2023, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-23-045061:notes:180]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 28, 2023, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-23-045061:notes:181]
Legal Contingencies

[0000950170-23-045061:notes:182]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0000950170-23-045061:notes:183]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0000950170-23-045061:notes:184]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of July 28, 2023 related to such matters.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000950170-23-045061:notes:185]
Item 5. Other Information.

[0000950170-23-045061:notes:186]
Insider Adoption or Termination of Trading Arrangements

[0000950170-23-045061:notes:187]
On June 7, 2023, Cesar Cernuda, President of the Company, entered into a 10b5-1 trading arrangement intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) promulgated under the Exchange Act. The trading arrangement will expire on June 7, 2024, and may be terminated earlier in the limited circumstances defined in the trading arrangement. An aggregate of 88,000 shares may be sold pursuant to the trading arrangement.

[0000950170-23-045061:notes:188]
On June 28, 2023, The Nevens Family 1997 Trust, a trust affiliated with T. Michael Nevens, Chair of the Board of Directors of the Company, entered into a 10b5-1 trading arrangement intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) promulgated under the Exchange Act. The trading arrangement will expire on September 30, 2024, and may be terminated earlier in the limited circumstances defined in the trading arrangement. An aggregate of 7,000 shares may be sold pursuant to the trading arrangement.

[0000950170-23-045061:notes:189]
No other directors or executive officers of the Company adopted, modified or terminated any contract, instruction or written plan for the purchase or sale of the Company’s securities that was intended to satisfy the affirmative defense conditions of Rule

[0000950170-23-045061:notes:190]
10b5-1(c) or any non-Rule 10b5 trading arrangement, (as defined in Item 408(c) of Regulation S-K) during the quarterly period covered by this report.
