# NTAP MD&A — 0000950170-23-045061


## mdna

[0000950170-23-045061:mdna:1]
[same as prior period, unchanged from 0000950170-23-005545:mdna:1]

[0000950170-23-045061:mdna:2]
[same as prior period, unchanged from 0000950170-23-005545:mdna:3]

[0000950170-23-045061:mdna:3]
[same as prior period, unchanged from 0000950170-23-005545:mdna:4]

[0000950170-23-045061:mdna:4]
NetApp is a global cloud-led, data-centric software company that empowers customers with hybrid multicloud solutions built for a better future. Building on more than three decades of innovation, we give customers the freedom to manage applications and data across hybrid multicloud environments. NetApp delivers value in simplicity, security, savings, and sustainability with automation and optimization for IT teams to thrive on premises, in the clouds, and everywhere in between. We are a proven leader in all-flash storage with the only storage OS natively available on the biggest clouds, and we believe we provide industry-leading protection and security, and innovative CloudOps services.

[0000950170-23-045061:mdna:5]
In a world of hybrid multicloud complexity, we envision a better IT experience—an evolved cloud state where on-premises and cloud environments are united as one. We build solutions that drive faster innovation wherever our customers’ data and applications live, with unified management and AI-driven optimization, giving organizations the freedom to do what’s best for today’s business and the flexibility to adapt for tomorrow. Our infrastructure, data, and application services are hybrid multicloud by design to deliver a unified experience that is integrated with the rich services of our cloud partners.

[0000950170-23-045061:mdna:6]
[same as prior period, unchanged from 0000950170-23-005545:mdna:6]

[0000950170-23-045061:mdna:7]
Hybrid Cloud offers a portfolio of storage management and infrastructure solutions that help customers recast their traditional data centers into modern data centers with the power of the cloud. Our Hybrid Cloud portfolio is designed to operate with public clouds to unlock the potential of hybrid, multi-cloud operations. We offer a broad portfolio of cloud-connected all-flash, hybrid-flash, and object storage systems, powered by intelligent data management software. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.

[0000950170-23-045061:mdna:8]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage and data services and cloud operations services. Our enterprise-class solutions and services enable customers to control and manage storage in the cloud, consume high-performance storage services for primary workloads, and optimize cloud environments for cost and efficiency. These solutions and services are generally available on the leading public clouds, including Amazon AWS, Microsoft Azure, and Google Cloud Platform.

[0000950170-23-045061:mdna:9]
[same as prior period, unchanged from 0000950170-23-005545:mdna:9]

[0000950170-23-045061:mdna:10]
[same as prior period, unchanged from 0000950170-23-005545:mdna:10]

[0000950170-23-045061:mdna:11]
Continuing global economic uncertainty, political conditions and fiscal challenges in the U.S. and abroad have resulted and may continue to result in adverse macroeconomic conditions, including inflation, rising interest rates, foreign exchange volatility, slower growth and possibly a recession. In particular, during the first quarter of fiscal 2024, and throughout fiscal 2023, we experienced a weakened demand environment, characterized by cloud optimizations and increased budget scrutiny, which resulted in smaller deal sizes, longer selling cycles, and delays of some deals.

[0000950170-23-045061:mdna:12]
If these macroeconomic uncertainties persist or worsen during the remainder of fiscal 2024, we may observe a further reduction in customer demand for our offerings, which could impact our operating results.

[0000950170-23-045061:mdna:13]
Supply Chain

[0000950170-23-045061:mdna:14]
Supply chain constraints, which substantially began to impact us in the first half of fiscal 2023, led to elevated product component and freight costs during the first quarter of fiscal 2023. Comparatively, in the first quarter of fiscal 2024, the supply chain substantially improved, resulting in lower costs.

[0000950170-23-045061:mdna:15]
[same as prior period, unchanged from 0000950170-23-005545:mdna:19]

[0000950170-23-045061:mdna:16]
During the first three months of fiscal 2024, we repurchased approximately 5 million shares of our common stock at an average price of $74.14 per share, for an aggregate of $400 million. We also declared aggregate cash dividends of $0.50 per share in that period, for which we paid $106 million.

[0000950170-23-045061:mdna:17]
[same as prior period, unchanged from 0000950170-23-005545:mdna:21]

[0000950170-23-045061:mdna:18]
In the first quarter of fiscal 2024, we initiated a restructuring plan to redirect resources to highest return activities and optimize our global office space for our hybrid work model. Aggregate restructuring charges incurred under the plan during the quarter totaled $26 million.

[0000950170-23-045061:mdna:19]
[same as prior period, unchanged from 0000950170-23-005545:mdna:23]

[0000950170-23-045061:mdna:20]
Our fiscal year is reported as a 52- or 53-week year that ends on the last Friday in April. Fiscal years 2024 and 2023, ending on April 26, 2024 and April 28, 2023, respectively, are each 52-week years, with 13 weeks in each of their quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0000950170-23-045061:mdna:21]
[same as prior period, unchanged from 0000950170-23-005545:mdna:25]

[0000950170-23-045061:mdna:22]
|  |  | Three Months Ended |  |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  |
| Net revenues: |  |  |  |  |  |  |  |
| Product |  |  | 41 | % |  |  | 49 | % |  |
| Services |  |  | 59 |  |  |  | 51 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product |  |  | 19 |  |  |  | 25 |  |  |
| Cost of services |  |  | 12 |  |  |  | 9 |  |  |
| Gross profit |  |  | 70 |  |  |  | 66 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 33 |  |  |  | 29 |  |  |
| Research and development |  |  | 17 |  |  |  | 15 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | 2 |  |  |  | 1 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | 1 |  |  |
| Total operating expenses |  |  | 57 |  |  |  | 50 |  |  |
| Income from operations |  |  | 12 |  |  |  | 16 |  |  |
| Other income, net |  |  | 1 |  |  |  | 1 |  |  |
| Income before income taxes |  |  | 13 |  |  |  | 17 |  |  |
| Provision for income taxes |  |  | 3 |  |  |  | 4 |  |  |
| Net income |  |  | 10 | % |  |  | 13 | % |  |

[0000950170-23-045061:mdna:23]
[same as prior period, unchanged from 0000950170-23-005545:mdna:27]

[0000950170-23-045061:mdna:24]
[same as prior period, unchanged from 0000950170-23-005545:mdna:28]

[0000950170-23-045061:mdna:25]
[same as prior period, unchanged from 0000950170-23-005545:mdna:29]

[0000950170-23-045061:mdna:26]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  | % Change |  |
| Net revenues |  | $ | 1,432 |  |  | $ | 1,592 |  |  |  | (10 | )% |

[0000950170-23-045061:mdna:27]
The decrease in net revenues for the first quarter of fiscal 2024 compared to the corresponding period of fiscal 2023 was primarily due to a decrease in product revenues, partially offset by an increase in services revenues. Product revenues as a percentage of net revenues decreased by eight percentage points in the first quarter of fiscal 2024, compared to the corresponding period of fiscal 2023, while services revenues as a percentage of net revenues increased by eight percentage points.

[0000950170-23-045061:mdna:28]
[same as prior period, unchanged from 0000950170-23-005545:mdna:33]

[0000950170-23-045061:mdna:29]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  | % Change |  |
| Product revenues |  | $ | 590 |  |  | $ | 786 |  |  |  | (25 | )% |
| Hardware (Non-GAAP) |  |  | 248 |  |  |  | 310 |  |  |  | (20 | )% |
| Software (Non-GAAP) |  |  | 342 |  |  |  | 476 |  |  |  | (28 | )% |

[0000950170-23-045061:mdna:30]
[same as prior period, unchanged from 0000950170-23-005545:mdna:35]

[0000950170-23-045061:mdna:31]
Product revenues are derived through the sale of our Hybrid Cloud solutions and consist of sales of configured all-flash array systems (including All-Flash FAS and QLC-Flash FAS) and hybrid systems, which are bundled hardware and software products, as

[0000950170-23-045061:mdna:32]
25

[0000950170-23-045061:mdna:33]
well as add-on flash, disk and/or hybrid storage and related OS, StorageGrid, OEM products, NetApp HCI and add-on optional software.

[0000950170-23-045061:mdna:34]
In order to provide visibility into the value created by our software innovation and R&D investment, we disclose the software and hardware components of our product revenues. Software product revenues includes the OS software and optional add-on software solutions attached to our systems across our entire product set, while hardware product revenues include the non-software component of our systems across the entire set. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, the hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0000950170-23-045061:mdna:35]
Total product revenues decreased in the first quarter of fiscal 2024 compared to the corresponding period of the prior year primarily due to lower sales of all flash array and hybrid systems, as a result of softening customer demand.

[0000950170-23-045061:mdna:36]
Revenues from the hardware component of product revenues represented 42% of product revenues in the first quarter of fiscal 2024 compared to 39% of product revenues in the corresponding period of the prior year. The software component of product revenues represented 58% of product revenues in the first quarter of fiscal 2024, compared to 61% of product revenues in the corresponding period of the prior year. The decrease in the software component percentage of product revenues in the first quarter of fiscal 2024 was primarily due to the mix of systems sold.

[0000950170-23-045061:mdna:37]
[same as prior period, unchanged from 0000950170-23-005545:mdna:40]

[0000950170-23-045061:mdna:38]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  | % Change |  |
| Services revenues |  | $ | 842 |  |  | $ | 806 |  |  |  | 4 | % |
| Support |  |  | 611 |  |  |  | 598 |  |  |  | 2 | % |
| Professional and other services |  |  | 77 |  |  |  | 76 |  |  |  | 1 | % |
| Public cloud |  |  | 154 |  |  |  | 132 |  |  |  | 17 | % |

[0000950170-23-045061:mdna:39]
[same as prior period, unchanged from 0000950170-23-005545:mdna:42]

[0000950170-23-045061:mdna:40]
[same as prior period, unchanged from 0000950170-23-005545:mdna:43]

[0000950170-23-045061:mdna:41]
Support revenues increased in the first quarter of fiscal 2024 compared to the corresponding period of the prior year as a result of a higher aggregate support contract value for our installed base.

[0000950170-23-045061:mdna:42]
Professional and other services revenues increased slightly in the first quarter of fiscal 2024 compared to the corresponding period of the prior year.

[0000950170-23-045061:mdna:43]
[same as prior period, unchanged from 0000950170-23-005545:mdna:46]

[0000950170-23-045061:mdna:44]
[same as prior period, unchanged from 0000950170-23-005545:mdna:47]

[0000950170-23-045061:mdna:45]
Public Cloud revenues increased in the first quarter of fiscal 2024 compared to the corresponding period of the prior year primarily due to customer demand for NetApp’s diversified cloud offerings, coupled with overall growth in the cloud market.

[0000950170-23-045061:mdna:46]
[same as prior period, unchanged from 0000950170-23-005545:mdna:50]

[0000950170-23-045061:mdna:47]
[same as prior period, unchanged from 0000950170-23-005545:mdna:51]

[0000950170-23-045061:mdna:48]
[same as prior period, unchanged from 0000950170-23-005545:mdna:52]

[0000950170-23-045061:mdna:49]
[same as prior period, unchanged from 0000950170-23-005545:mdna:53]

[0000950170-23-045061:mdna:50]
26

[0000950170-23-045061:mdna:51]
[same as prior period, unchanged from 0000950170-23-005545:mdna:54]

[0000950170-23-045061:mdna:52]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  | % Change |  |
| Cost of product revenues |  | $ | 265 |  |  | $ | 397 |  |  |  | (33 | )% |
| Hybrid Cloud |  |  | 264 |  |  |  | 395 |  |  |  | (33 | )% |
| Unallocated |  |  | 1 |  |  |  | 2 |  |  |  | (50 | )% |

[0000950170-23-045061:mdna:53]
[same as prior period, unchanged from 0000950170-23-005545:mdna:56]

[0000950170-23-045061:mdna:54]
Cost of Hybrid Cloud product revenues represented approximately 45% of product revenues for the first quarter of fiscal 2024 compared to 50% for the corresponding period of fiscal 2023. Materials costs represented 88% of cost of Hybrid Cloud product revenues for the first quarter of fiscal 2024, compared to 93% for the corresponding period of fiscal 2023.

[0000950170-23-045061:mdna:55]
Materials costs decreased by approximately $134 million in the first quarter of fiscal 2024 compared to the corresponding period of the prior year, reflecting the decrease in product revenues and lower component and freight costs as a result of supply chain improvements.

[0000950170-23-045061:mdna:56]
Hybrid Cloud product gross margins increased by approximately six percentage points in the first quarter of fiscal 2024, compared to the corresponding period of the prior year, primarily due to lower component and freight costs.

[0000950170-23-045061:mdna:57]
[same as prior period, unchanged from 0000950170-23-005545:mdna:60]

[0000950170-23-045061:mdna:58]
Unallocated cost of product revenues decreased in the first quarter of fiscal 2024 compared to the corresponding period of the prior year due to certain intangible assets becoming fully amortized during the first quarter of fiscal 2023.

[0000950170-23-045061:mdna:59]
[same as prior period, unchanged from 0000950170-23-005545:mdna:62]

[0000950170-23-045061:mdna:60]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  | % Change |  |
| Cost of services revenues |  | $ | 171 |  |  | $ | 149 |  |  |  | 15 | % |
| Support |  |  | 47 |  |  |  | 43 |  |  |  | 9 | % |
| Professional and other services |  |  | 58 |  |  |  | 52 |  |  |  | 12 | % |
| Public cloud |  |  | 51 |  |  |  | 40 |  |  |  | 28 | % |
| Unallocated |  |  | 15 |  |  |  | 14 |  |  |  | 7 | % |

[0000950170-23-045061:mdna:61]
[same as prior period, unchanged from 0000950170-23-005545:mdna:64]

[0000950170-23-045061:mdna:62]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, increased in the first quarter of fiscal 2024 compared to the corresponding period of fiscal 2023. Cost of Hybrid Cloud services revenues represented approximately 15% of Hybrid Cloud services revenues in the first quarter of fiscal 2024, compared to 14% for the corresponding period of fiscal 2023.

[0000950170-23-045061:mdna:63]
Hybrid Cloud support gross margins decreased by less than one percentage point in the first quarter of fiscal 2024 compared to the corresponding period of the prior year. Hybrid Cloud professional and other services gross margins decreased by seven percentage points in the first quarter of fiscal 2024 compared to the corresponding period of fiscal 2023, due to the mix of services provided.

[0000950170-23-045061:mdna:64]
[same as prior period, unchanged from 0000950170-23-005545:mdna:67]

[0000950170-23-045061:mdna:65]
Cost of Public Cloud revenues increased in the first quarter of fiscal 2024 compared to the corresponding period of fiscal 2023 reflecting the increase in Public Cloud revenues. Public Cloud gross margins decreased by three percentage points in the first quarter of fiscal 2024 compared to the corresponding period of fiscal 2023, primarily due to the mix of offerings provided.

[0000950170-23-045061:mdna:66]
[same as prior period, unchanged from 0000950170-23-005545:mdna:69]

[0000950170-23-045061:mdna:67]
Unallocated cost of services revenues were relatively flat in the first quarter of fiscal 2024 compared to the corresponding period of the prior year.

[0000950170-23-045061:mdna:68]
[same as prior period, unchanged from 0000950170-23-005545:mdna:71]

[0000950170-23-045061:mdna:69]
[same as prior period, unchanged from 0000950170-23-005545:mdna:72]

[0000950170-23-045061:mdna:70]
Sales and marketing, research and development, and general and administrative expenses for the first quarter of fiscal 2024 totaled $789 million, or 55% of net revenues, reflecting an increase of seven percentage points compared to the corresponding period of fiscal 2023, primarily due to the decrease in net revenues.

[0000950170-23-045061:mdna:71]
[same as prior period, unchanged from 0000950170-23-005545:mdna:76]

[0000950170-23-045061:mdna:72]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses increased by $19 million, or 4%, in the first quarter of fiscal 2024, compared to the corresponding period of the prior year, primarily due to increases in stock-based compensation and incentive compensation expenses. Stock-based compensation expense in the current year period also included incremental expense related to the reset and rollover mechanism of our employee stock purchase plan. These increases were partially offset by lower salaries expense, reflecting a 4% decrease in average headcount.

[0000950170-23-045061:mdna:73]
[same as prior period, unchanged from 0000950170-23-005545:mdna:78]

[0000950170-23-045061:mdna:74]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 468 |  |  | $ | 458 |  |  |  | 2 | % |

[0000950170-23-045061:mdna:75]
[same as prior period, unchanged from 0000950170-23-005545:mdna:81]

[0000950170-23-045061:mdna:76]
|  |  | Three Months Ended |  |
|  |  | Fiscal 2024 to Fiscal 2023 |  |
| Advertising and marketing promotional expense |  |  | 1 |  |
| Travel and entertainment |  |  | 1 |  |
| Total change |  |  | 2 |  |

[0000950170-23-045061:mdna:77]
Compensation costs and commissions remained relatively flat in the first quarter of fiscal 2024 compared to the corresponding period of the prior year.

[0000950170-23-045061:mdna:78]
Advertising and marketing promotional expense increased in the first quarter of fiscal 2024 compared to the corresponding period of the prior year, primarily due to higher spending on certain marketing programs.

[0000950170-23-045061:mdna:79]
Travel and entertainment expense increased in the first quarter of fiscal 2024 due to higher travel volume to support sales activities.

[0000950170-23-045061:mdna:80]
[same as prior period, unchanged from 0000950170-23-005545:mdna:87]

[0000950170-23-045061:mdna:81]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  | % Change |  |
| Research and development expenses |  | $ | 247 |  |  | $ | 240 |  |  |  | 3 | % |

[0000950170-23-045061:mdna:82]
Research and development expenses consist primarily of compensation costs, facilities and IT support costs, depreciation, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs. Changes in research and development expenses consisted of the following (in percentage points of the total change):

[0000950170-23-045061:mdna:83]
|  |  | Three Months Ended |  |
|  |  | Fiscal 2024 to Fiscal 2023 |  |
| Compensation costs |  |  | 4 |  |
| Development projects and outside services |  |  | (1 | ) |
| Total change |  |  | 3 |  |

[0000950170-23-045061:mdna:84]
The increase in compensation costs for the first quarter of fiscal 2024 compared to the corresponding period in the prior year was primarily attributable to higher stock-based compensation and incentive compensation expenses, partially offset by lower salaries expense, reflecting a decrease of 4% in average headcount.

[0000950170-23-045061:mdna:85]
28

[0000950170-23-045061:mdna:86]
The decrease in development projects and outside services for the first quarter of fiscal 2024 compared to the corresponding period in the prior year was primarily due to the lower spending on certain engineering projects.

[0000950170-23-045061:mdna:87]
[same as prior period, unchanged from 0000950170-23-005545:mdna:93]

[0000950170-23-045061:mdna:88]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  | % Change |  |
| General and administrative expenses |  | $ | 74 |  |  | $ | 72 |  |  |  | 3 | % |

[0000950170-23-045061:mdna:89]
[same as prior period, unchanged from 0000950170-23-005545:mdna:95]

[0000950170-23-045061:mdna:90]
|  |  | Three Months Ended |  |
|  |  | Fiscal 2024 to Fiscal 2023 |  |
| Compensation costs |  |  | 6 |  |
| Facilities and IT support costs |  |  | (2 | ) |
| Other |  |  | (1 | ) |
| Total change |  |  | 3 |  |

[0000950170-23-045061:mdna:91]
The increase in compensation costs in the first quarter of fiscal 2024 compared to the corresponding period of the prior year was attributable to higher expenses for all components of compensation costs.

[0000950170-23-045061:mdna:92]
The decrease in facilities and IT support costs in the first quarter of fiscal 2024 was primarily related to lower spending for certain IT projects.

[0000950170-23-045061:mdna:93]
[same as prior period, unchanged from 0000950170-23-005545:mdna:99]

[0000950170-23-045061:mdna:94]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  | % Change |  |
| Restructuring charges |  | $ | 26 |  |  | $ | 11 |  |  |  | 136 | % |

[0000950170-23-045061:mdna:95]
In the first quarter of fiscal 2024, we initiated a restructuring plan to redirect resources to highest return activities, and to optimize our global office space for our hybrid work model. In connection with the plan, we reduced our global workforce by approximately 1% and terminated certain real estate leases in various countries, resulting in restructuring charges comprised primarily of employee severance-related expenses and lease termination charges. The workforce related activities under the plan are substantially complete.

[0000950170-23-045061:mdna:96]
[same as prior period, unchanged from 0000950170-23-005545:mdna:103]

[0000950170-23-045061:mdna:97]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  | % Change |  |
| Acquisition-related expense |  | $ | 3 |  |  | $ | 10 |  |  |  | (70 | )% |

[0000950170-23-045061:mdna:98]
Acquisition-related expenses, totaled $3 million in the first quarter of fiscal 2024 and were primarily related to our integration of previous acquisitions.

[0000950170-23-045061:mdna:99]
Other Income, Net (in millions, except percentages)

[0000950170-23-045061:mdna:100]
The components of other income, net were as follows:

[0000950170-23-045061:mdna:101]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  | % Change |  |
| Interest income |  | $ | 28 |  |  | $ | 7 |  |  |  | 300 | % |
| Interest expense |  |  | (16 | ) |  |  | (18 | ) |  |  | (11 | )% |
| Other, net |  |  | (4 | ) |  |  | 26 |  |  | NM |  |
| Total |  | $ | 8 |  |  | $ | 15 |  |  | NM |  |

[0000950170-23-045061:mdna:102]
[same as prior period, unchanged from 0000950170-23-005545:mdna:101]

[0000950170-23-045061:mdna:103]
[same as prior period, unchanged from 0000950170-23-005545:mdna:32]

[0000950170-23-045061:mdna:104]
Interest income increased in the first quarter of fiscal 2024 compared to the corresponding period of the prior year due primarily to higher yields earned on our cash and investments. Interest expense decreased in the first quarter of fiscal 2024 compared to the corresponding period of fiscal 2023 due to the extinguishment of certain senior notes in the second quarter of fiscal 2023.

[0000950170-23-045061:mdna:105]
Other, net for the first three months of fiscal 2023 included a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million. The remaining differences in Other, net for the first quarter of fiscal 2024 as compared to the corresponding period of the prior year are partially due to foreign exchange gains and losses year-over-year.

[0000950170-23-045061:mdna:106]
Provision for Income Taxes (in millions, except percentages):

[0000950170-23-045061:mdna:107]
|  |  | Three Months Ended |  |
|  |  | July 28, 2023 |  |  | July 29, 2022 |  |  | % Change |  |
| Provision for income taxes |  | $ | 37 |  |  | $ | 56 |  |  |  | (34 | )% |

[0000950170-23-045061:mdna:108]
Our effective tax rate for the three months ended July 28, 2023 decreased from the prior year, primarily due to increased fiscal 2023 foreign tax credits resulting from new IRS guidance released during the quarter, partially offset by an increase in stock compensation for which no tax benefit is currently recorded. The effective tax rate for the three months ended July 29, 2022, includes larger discrete tax benefits related to stock-based compensation than the current year.

[0000950170-23-045061:mdna:109]
As of July 28, 2023, we had $221 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $145 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $145 million have been recorded in other long-term liabilities.

[0000950170-23-045061:mdna:110]
[same as prior period, unchanged from 0000950170-23-005545:mdna:120]

[0000950170-23-045061:mdna:111]
| (In millions) |  | July 28, 2023 |  |  | April 28, 2023 |  |
| Cash, cash equivalents and short-term investments |  | $ | 2,975 |  |  | $ | 3,070 |  |
| Principal amount of debt |  | $ | 2,400 |  |  | $ | 2,400 |  |

[0000950170-23-045061:mdna:112]
[same as prior period, unchanged from 0000950170-23-005545:mdna:122]

[0000950170-23-045061:mdna:113]
|  |  | Three Months Ended |  |
| (In millions) |  | July 28, 2023 |  |  | July 29, 2022 |  |
| Net cash provided by operating activities |  | $ | 453 |  |  | $ | 281 |  |
| Net cash used in investing activities |  |  | (228 | ) |  |  | (628 | ) |
| Net cash used in financing activities |  |  | (521 | ) |  |  | (459 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | — |  |  |  | (18 | ) |
| Net change in cash, cash equivalents and restricted cash |  | $ | (296 | ) |  | $ | (824 | ) |

[0000950170-23-045061:mdna:114]
[same as prior period, unchanged from 0000950170-23-005545:mdna:124]

[0000950170-23-045061:mdna:115]
As of July 28, 2023, our cash, cash equivalents and short-term investments were $3.0 billion, which represents a decrease of $95 million during the first three months of fiscal 2024. The decrease was primarily due to $400 million used for the repurchase of our common stock, $106 million used for the payment of dividends and $35 million used for purchases of property and equipment, partially offset by $453 million provided by operating activities. Net working capital was $0.9 billion as of July 28, 2023, a reduction of approximately $300 million when compared to April 28, 2023, primarily due to the decrease in cash, cash equivalents and short-term investments discussed above.

[0000950170-23-045061:mdna:116]
[same as prior period, unchanged from 0000950170-23-005545:mdna:126]

[0000950170-23-045061:mdna:117]
During the first three months of fiscal 2024, we generated cash from operating activities of $453 million, reflecting net income of $149 million which was increased by non-cash depreciation and amortization expense of $64 million and non-cash stock-based compensation expense of $87 million, compared to $281 million of cash generated from operating activities during the first three months of fiscal 2023.

[0000950170-23-045061:mdna:118]
Significant changes in assets and liabilities in the first three months of fiscal 2024 included the following:

[0000950170-23-045061:mdna:119]
•
Accounts receivable decreased $332 million, reflecting lower billings and more favorable invoicing linearity in the first quarter of fiscal 2024 compared to the fourth quarter of fiscal 2023.

[0000950170-23-045061:mdna:120]
•
Accrued expenses decreased by $89 million, primarily due to employee compensation payouts related to fiscal year 2023 incentive compensation and commissions plans.

[0000950170-23-045061:mdna:121]
•
Deferred revenue and financed unearned services revenue decreased by $133 million, primarily due to a decrease in deferred revenue for software and hardware support contracts, reflecting the seasonality of support contract renewal activities.

[0000950170-23-045061:mdna:122]
[same as prior period, unchanged from 0000950170-23-005545:mdna:132]

[0000950170-23-045061:mdna:123]
[same as prior period, unchanged from 0000950170-23-005545:mdna:133]

[0000950170-23-045061:mdna:124]
During the first three months of fiscal 2024, we used $192 million for the purchases of investments, net of maturities and sales, and paid $35 million for capital expenditures, as compared to the same period of fiscal 2023, in which we used $131 million for the purchases of investments, net of maturities and sales, and paid $65 million for capital expenditures. During the first three months of fiscal 2023, we paid approximately $491 million, net of cash acquired for a privately-held company, and received proceeds of $59 million from the sale of one of our minority investments.

[0000950170-23-045061:mdna:125]
[same as prior period, unchanged from 0000950170-23-005545:mdna:135]

[0000950170-23-045061:mdna:126]
During the first three months of fiscal 2024, cash flows used in financing activities totaled $521 million and included $400 million for the repurchase of approximately 5 million shares of common stock and $106 million for the payment of dividends. During the first three months of fiscal 2023, cash flows used in financing activities totaled $459 million and include $350 million for the repurchase of approximately 5.2 million shares of common stock and $110 million for the payment of dividends.

[0000950170-23-045061:mdna:127]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including cash, cash equivalents and short-term investments, cash generated from operations, and our ability to access capital markets and committed credit lines will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all. For further discussion of factors that could affect our cash flows and liquidity requirements, see Item 1A. Risk Factors.

[0000950170-23-045061:mdna:128]
[same as prior period, unchanged from 0000950170-23-005545:mdna:139]

[0000950170-23-045061:mdna:129]
Our principal sources of liquidity as of July 28, 2023 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-23-045061:mdna:130]
[same as prior period, unchanged from 0000950170-23-005545:mdna:141]

[0000950170-23-045061:mdna:131]
|  |  | July 28, 2023 |  |  | April 28, 2023 |  |
| Cash and cash equivalents |  | $ | 2,020 |  |  | $ | 2,316 |  |
| Short-term investments |  |  | 955 |  |  |  | 754 |  |
| Total |  | $ | 2,975 |  |  | $ | 3,070 |  |

[0000950170-23-045061:mdna:132]
As of July 28, 2023 and April 28, 2023, $2.1 billion and $2.2 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.9 billion each were available in the U.S.

[0000950170-23-045061:mdna:133]
[same as prior period, unchanged from 0000950170-23-005545:mdna:144]

[0000950170-23-045061:mdna:134]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of July 28, 2023.

[0000950170-23-045061:mdna:135]
[same as prior period, unchanged from 0000950170-23-005545:mdna:146]

[0000950170-23-045061:mdna:136]
[same as prior period, unchanged from 0000950170-23-005545:mdna:147]

[0000950170-23-045061:mdna:137]
The following table summarizes the principal amount of our Senior Notes as of July 28, 2023 (in millions):

[0000950170-23-045061:mdna:138]
|  |  | Amount |  |
| 3.30% Senior Notes Due September 2024 |  | $ | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,400 |  |

[0000950170-23-045061:mdna:139]
[same as prior period, unchanged from 0000950170-23-005545:mdna:150]

[0000950170-23-045061:mdna:140]
Commercial Paper Program and Credit Facility

[0000950170-23-045061:mdna:141]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of July 28, 2023.

[0000950170-23-045061:mdna:142]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023 primarily to replace the London Interbank Offered Rate (LIBOR) with the Secured Overnight Financing Rate (SOFR) as the basis for establishing the interest rate applicable to certain borrowings under the agreement, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of July 28, 2023, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-23-045061:mdna:143]
[same as prior period, unchanged from 0000950170-23-005545:mdna:155]

[0000950170-23-045061:mdna:144]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2024 to be between $125 million and $175 million.

[0000950170-23-045061:mdna:145]
[same as prior period, unchanged from 0000950170-23-005545:mdna:157]

[0000950170-23-045061:mdna:146]
The Tax Cuts and Jobs Act of 2017 imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits that had not previously been subject to U.S. income tax. As of July 28, 2023, outstanding payments related to the transition tax are estimated to be approximately $303 million of which $88 million, $115 million and $100 million are expected to be paid during fiscal 2024, fiscal 2025 and fiscal 2026, respectively. Our estimates for future transition tax payments, however, could change with further guidance or review from U.S. federal and state tax authorities or other regulatory bodies.

[0000950170-23-045061:mdna:147]
[same as prior period, unchanged from 0000950170-23-005545:mdna:159]

[0000950170-23-045061:mdna:148]
On August 22, 2023, we declared a cash dividend of $0.50 per share of common stock, payable on October 25, 2023, to holders of record as of the close of business on October 6, 2023.

[0000950170-23-045061:mdna:149]
As of July 28, 2023, our Board of Directors had authorized the repurchase of up to $16.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through July 28, 2023, we repurchased a total of 365 million shares of our common stock at an average price of $41.38 per share, for an aggregate purchase price of $15.1 billion. As of July 28, 2023, the remaining authorized amount for stock repurchases under this program was $1.0 billion.

[0000950170-23-045061:mdna:150]
[same as prior period, unchanged from 0000950170-23-005545:mdna:162]

[0000950170-23-045061:mdna:151]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled approximately $0.8 billion at July 28, 2023.

[0000950170-23-045061:mdna:152]
[same as prior period, unchanged from 0000950170-23-005545:mdna:164]

[0000950170-23-045061:mdna:153]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $19 million and $3 million of receivables during the first three months of fiscal 2024 and fiscal 2023, respectively.

[0000950170-23-045061:mdna:154]
[same as prior period, unchanged from 0000950170-23-005545:mdna:166]

[0000950170-23-045061:mdna:155]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of July 28, 2023 and April 28, 2023, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-23-045061:mdna:156]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of July 28, 2023, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-23-045061:mdna:157]
Legal Contingencies

[0000950170-23-045061:mdna:158]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0000950170-23-045061:mdna:159]
33

[0000950170-23-045061:mdna:160]
[same as prior period, unchanged from 0000950170-23-005545:mdna:171]

[0000950170-23-045061:mdna:161]
Our condensed consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (GAAP), which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and liabilities. Our estimates are based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0000950170-23-045061:mdna:162]
The summary of significant accounting policies is included under Item 7 – Management’s Discussion and Analysis of Financial Condition and Results of Operations of Annual Report on Form 10-K for the year ended April 28, 2023. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. There have been no material changes to the critical accounting policies and estimates as filed in such report.

[0000950170-23-045061:mdna:163]
34
