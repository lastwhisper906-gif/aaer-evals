# NTAP MD&A — 0001193125-25-189700


## mdna

[0001193125-25-189700:mdna:1]
[same as prior period, unchanged from 0000950170-25-029066:mdna:1]

[0001193125-25-189700:mdna:2]
[same as prior period, unchanged from 0000950170-25-029066:mdna:2]

[0001193125-25-189700:mdna:3]
[same as prior period, unchanged from 0000950170-25-029066:mdna:3]

[0001193125-25-189700:mdna:4]
NetApp helps customers make their data infrastructure more seamless, more dynamic, and higher performing. We were incorporated in 1992, are headquartered in San Jose, California, and provide a full range of enterprise-class software, systems and services that customers use to transform their data infrastructures across data types, workloads, and environments to realize business possibilities.

[0001193125-25-189700:mdna:5]
We leverage over thirty years of innovation to make data infrastructure intelligent. Our unified data storage solutions deliver flexible, simplified, and silo-free infrastructure. Our active data management capabilities focus on security, compliance, and sustainability, while our adaptive operations enhance performance, efficiency, and productivity. Our extensive portfolio integrates hybrid and multi-cloud environments, addressing key customer priorities such as modernizing legacy systems, enhancing resilience against ransomware, and developing scalable, high-performance data pipelines for artificial intelligence (AI) workloads.

[0001193125-25-189700:mdna:6]
NetApp empowers customers to harness their data for accelerated innovation, improved operations, and competitive advantage. Our unified data storage solutions provide the flexibility to consistently and easily store any data type and support any workload. As the only enterprise-grade storage service natively embedded in the world’s largest clouds, we power data across Amazon AWS, Microsoft Azure, and Google Cloud. Our integrated data services enable active data management, security, protection, governance, and sustainability. Additionally, our operational services support adaptive operations across infrastructure, applications, and teams. Together with our Hybrid Cloud products, these services enable customers to construct a seamless, intelligent data infrastructure across hybrid multi-cloud environments.

[0001193125-25-189700:mdna:7]
[same as prior period, unchanged from 0000950170-25-029066:mdna:6]

[0001193125-25-189700:mdna:8]
Hybrid Cloud offers a unified data storage portfolio of storage management and infrastructure solutions that helps customers modernize their data centers. Our Hybrid Cloud portfolio accommodates both structured and unstructured data with unified storage optimized for flash, disk, and cloud storage, capable of handling data-intensive workloads and applications. Hybrid Cloud includes software, hardware, and related support, along with professional and other services.

[0001193125-25-189700:mdna:9]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage, data services, and operational services. These services are generally available on the leading public clouds, including Amazon AWS, Microsoft Azure, and Google Cloud.

[0001193125-25-189700:mdna:10]
[same as prior period, unchanged from 0000950170-25-029066:mdna:9]

[0001193125-25-189700:mdna:11]
During the first three months of fiscal 2026, we repurchased 3.0 million shares of our common stock at an average price of $99.76 per share, for an aggregate purchase price of $300 million. We also declared aggregate cash dividends of $0.52 per share in that period, for which we paid $104 million.

[0001193125-25-189700:mdna:12]
Senior Notes Repayment

[0001193125-25-189700:mdna:13]
On June 23, 2025, upon maturity, we repaid the 1.875% Senior Notes due June 2025 for an aggregate amount of $757 million, comprised of the principal and unpaid interest.

[0001193125-25-189700:mdna:14]
[same as prior period, unchanged from 0000950170-25-029066:mdna:13]

[0001193125-25-189700:mdna:15]
Our fiscal year is reported as a 52- or 53-week year that ends on the last Friday in April. Fiscal years 2026 and 2025, ending on April 24, 2026 and April 25, 2025, respectively, are each 52-week years, with 13 weeks in each of their quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0001193125-25-189700:mdna:16]
[same as prior period, unchanged from 0000950170-25-029066:mdna:16]

[0001193125-25-189700:mdna:17]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |
| Revenues: |  |  |  |  |  |  |
| Product |  |  | 42 | % |  |  | 43 | % |
| Services |  |  | 58 |  |  |  | 57 |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |
| Cost of revenues: |  |  |  |  |  |  |
| Cost of product |  |  | 19 |  |  |  | 17 |  |
| Cost of services |  |  | 10 |  |  |  | 11 |  |
| Gross profit |  |  | 70 |  |  |  | 71 |  |
| Operating expenses: |  |  |  |  |  |  |
| Sales and marketing |  |  | 30 |  |  |  | 31 |  |
| Research and development |  |  | 16 |  |  |  | 16 |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |
| Restructuring charges |  |  | — |  |  |  | 1 |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |
| Total operating expenses |  |  | 51 |  |  |  | 53 |  |
| Income from operations |  |  | 20 |  |  |  | 18 |  |
| Other income, net |  |  | — |  |  |  | 1 |  |
| Income before income taxes |  |  | 19 |  |  |  | 19 |  |
| Provision for income taxes |  |  | 5 |  |  |  | 3 |  |
| Net income |  |  | 15 | % |  |  | 16 | % |

[0001193125-25-189700:mdna:18]
[same as prior period, unchanged from 0000950170-25-029066:mdna:18]

[0001193125-25-189700:mdna:19]
[same as prior period, unchanged from 0000950170-25-029066:mdna:19]

[0001193125-25-189700:mdna:20]
[same as prior period, unchanged from 0000950170-25-029066:mdna:20]

[0001193125-25-189700:mdna:21]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |  | % Change |  |
| Net revenues |  | $ | 1,559 |  |  | $ | 1,541 |  |  |  | 1 | % |

[0001193125-25-189700:mdna:22]
The increase in net revenues for the first quarter of fiscal 2026 compared to the corresponding period of the prior year was due to an increase in services revenues, partially offset by a decrease in product revenues. Product revenues as a percentage of net revenues decreased by one percentage point in the first quarter of fiscal 2026 compared to the corresponding period of fiscal 2025. Fluctuations in foreign currency exchange rates favorably impacted net revenues percent growth by approximately one percentage point in the first quarter of fiscal 2026, compared to the corresponding period of fiscal 2025.

[0001193125-25-189700:mdna:23]
[same as prior period, unchanged from 0000950170-25-029066:mdna:23]

[0001193125-25-189700:mdna:24]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |  | % Change |  |
| Product revenues |  | $ | 654 |  |  | $ | 669 |  |  |  | (2 | )% |

[0001193125-25-189700:mdna:25]
[same as prior period, unchanged from 0000950170-25-029066:mdna:25]

[0001193125-25-189700:mdna:26]
Product revenues are derived through the sale of our Hybrid Cloud solutions and consist of sales of configured all-flash array systems (including All-Flash FAS A-Series and All-Flash FAS C-Series with capacity flash) and hybrid systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, StorageGrid, OEM products, and add-on optional software.

[0001193125-25-189700:mdna:27]
Total product revenues decreased in the first quarter of fiscal 2026 compared to the corresponding period of the prior year primarily due to lower sales of hybrid systems, partially offset by higher sales of all-flash array systems and the favorable impact from foreign exchange rate fluctuations.

[0001193125-25-189700:mdna:28]
[same as prior period, unchanged from 0000950170-25-029066:mdna:30]

[0001193125-25-189700:mdna:29]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |  | % Change |  |
| Services revenues |  | $ | 905 |  |  | $ | 872 |  |  |  | 4 | % |
| Support |  |  | 647 |  |  |  | 631 |  |  |  | 3 | % |
| Professional and other services |  |  | 97 |  |  |  | 82 |  |  |  | 18 | % |
| Public cloud |  |  | 161 |  |  |  | 159 |  |  |  | 1 | % |

[0001193125-25-189700:mdna:30]
[same as prior period, unchanged from 0000950170-25-029066:mdna:32]

[0001193125-25-189700:mdna:31]
[same as prior period, unchanged from 0000950170-25-029066:mdna:33]

[0001193125-25-189700:mdna:32]
Support revenues increased marginally in the first quarter of fiscal 2026 compared to the corresponding period of the prior year, partly due to the favorable impact from foreign exchange rate fluctuations.

[0001193125-25-189700:mdna:33]
Professional and other services revenues increased in the first quarter of fiscal 2026 compared to the corresponding period of the prior year primarily due to an increase in revenues from our Keystone storage-as-a-service offering.

[0001193125-25-189700:mdna:34]
[same as prior period, unchanged from 0000950170-25-029066:mdna:36]

[0001193125-25-189700:mdna:35]
Public Cloud revenues are derived from the sale of public cloud offerings delivered primarily as-a-service, which include cloud storage, data services and operational services.

[0001193125-25-189700:mdna:36]
Public Cloud revenues increased marginally in the first quarter of fiscal 2026 compared to the corresponding period of the prior year, due to higher customer demand, driven by NetApp’s diversified cloud offerings and overall growth in the cloud market, partially offset by the loss of revenue from our Spot by NetApp business which we sold in the fourth quarter of fiscal 2025.

[0001193125-25-189700:mdna:37]
[same as prior period, unchanged from 0000950170-25-029066:mdna:39]

[0001193125-25-189700:mdna:38]
[same as prior period, unchanged from 0000950170-25-029066:mdna:40]

[0001193125-25-189700:mdna:39]
(1) cost of product revenues, composed of (a) cost of Hybrid Cloud product revenues, which includes the costs of manufacturing and shipping our products, inventory write-downs, and warranty costs, and (b) unallocated cost of product revenues, which includes stock-based compensation, and;

[0001193125-25-189700:mdna:40]
[same as prior period, unchanged from 0000950170-25-029066:mdna:42]

[0001193125-25-189700:mdna:41]
[same as prior period, unchanged from 0000950170-25-029066:mdna:44]

[0001193125-25-189700:mdna:42]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |  | % Change |  |
| Cost of product revenues |  | $ | 302 |  |  | $ | 269 |  |  |  | 12 | % |
| Hybrid Cloud |  |  | 301 |  |  |  | 268 |  |  |  | 12 | % |
| Unallocated |  |  | 1 |  |  |  | 1 |  |  |  | — | % |

[0001193125-25-189700:mdna:43]
[same as prior period, unchanged from 0000950170-25-029066:mdna:46]

[0001193125-25-189700:mdna:44]
Cost of Hybrid Cloud product revenues represented 46% of product revenues for the first quarter of fiscal 2026, compared to 40% for the corresponding period of the prior year. Materials costs represented 89% of cost of Hybrid Cloud product revenues for the first quarter of fiscal 2026, compared to 88% for the corresponding period of the prior year.

[0001193125-25-189700:mdna:45]
Materials costs increased by $30 million in the first quarter of fiscal 2026 compared to the corresponding period of the prior year.

[0001193125-25-189700:mdna:46]
Hybrid Cloud product gross margins decreased by six percentage points in the first quarter of fiscal 2026 compared to the corresponding period of the prior year primarily due to higher component costs.

[0001193125-25-189700:mdna:47]
[same as prior period, unchanged from 0000950170-25-029066:mdna:52]

[0001193125-25-189700:mdna:48]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |  | % Change |  |
| Cost of services revenues |  | $ | 159 |  |  | $ | 174 |  |  |  | (9 | )% |
| Support |  |  | 50 |  |  |  | 50 |  |  |  | — | % |
| Professional and other services |  |  | 68 |  |  |  | 64 |  |  |  | 6 | % |
| Public cloud |  |  | 32 |  |  |  | 46 |  |  |  | (30 | )% |
| Unallocated |  |  | 9 |  |  |  | 14 |  |  |  | (36 | )% |

[0001193125-25-189700:mdna:49]
[same as prior period, unchanged from 0000950170-25-029066:mdna:54]

[0001193125-25-189700:mdna:50]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, increased in the first quarter of fiscal 2026 compared to the corresponding period of the prior year. Cost of Hybrid Cloud services revenues represented 16% of Hybrid Cloud services revenues for both the first quarter of fiscal 2026 and the corresponding period of the prior year.

[0001193125-25-189700:mdna:51]
Hybrid Cloud support gross margins were relatively flat in the first quarter of fiscal 2026 compared to the corresponding period of the prior year. Hybrid Cloud professional and other services gross margins increased by eight percentage points in the first quarter of fiscal 2026 compared to the corresponding period of the prior year due primarily to the mix of services provided.

[0001193125-25-189700:mdna:52]
[same as prior period, unchanged from 0000950170-25-029066:mdna:57]

[0001193125-25-189700:mdna:53]
Cost of Public Cloud revenues decreased and gross margins increased by nine percentage points in the first quarter of fiscal 2026 compared to the corresponding period of the prior year. The decrease in cost of Public Cloud revenues and improved gross margins was due to cost optimization that included a decrease in fixed assets depreciation, and the mix of offerings provided which was impacted by the sale of our Spot by NetApp business in the fourth quarter of fiscal 2025.

[0001193125-25-189700:mdna:54]
[same as prior period, unchanged from 0000950170-25-029066:mdna:50]

[0001193125-25-189700:mdna:55]
Unallocated cost of services revenues decreased in the first quarter of fiscal 2026 compared to the corresponding period of the prior year, due to lower intangible asset amortization expense from the derecognition of certain intangible assets as a result of the sale of our Spot by NetApp business during the fourth quarter of fiscal 2025.

[0001193125-25-189700:mdna:56]
[same as prior period, unchanged from 0000950170-25-029066:mdna:62]

[0001193125-25-189700:mdna:57]
[same as prior period, unchanged from 0000950170-25-029066:mdna:63]

[0001193125-25-189700:mdna:58]
Sales and marketing, research and development, and general and administrative expenses for the first quarter of fiscal 2026 totaled $787 million, or 50% of net revenues, reflecting a decrease of two percentage points compared to the corresponding period of the prior year, primarily due to the increase in net revenues.

[0001193125-25-189700:mdna:59]
Compensation costs represent the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0001193125-25-189700:mdna:60]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses in the first quarter of fiscal 2026 were relatively flat compared to the corresponding period of the prior year, despite the unfavorable impact from fluctuations in foreign currency exchange rates.

[0001193125-25-189700:mdna:61]
[same as prior period, unchanged from 0000950170-25-029066:mdna:67]

[0001193125-25-189700:mdna:62]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 461 |  |  | $ | 471 |  |  |  | (2 | )% |

[0001193125-25-189700:mdna:63]
[same as prior period, unchanged from 0000950170-25-029066:mdna:69]

[0001193125-25-189700:mdna:64]
The decrease in sales and marketing expenses in the first quarter of fiscal 2026 compared to the corresponding period of the prior year was primarily due to lower compensation costs and lower spend on outside services.

[0001193125-25-189700:mdna:65]
[same as prior period, unchanged from 0000950170-25-029066:mdna:72]

[0001193125-25-189700:mdna:66]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |  | % Change |  |
| Research and development expenses |  | $ | 242 |  |  | $ | 252 |  |  |  | (4 | )% |

[0001193125-25-189700:mdna:67]
[same as prior period, unchanged from 0000950170-25-029066:mdna:74]

[0001193125-25-189700:mdna:68]
Research and development expenses decreased in the first quarter of fiscal 2026 compared to the corresponding period of the prior year, primarily attributable to lower compensation costs.

[0001193125-25-189700:mdna:69]
[same as prior period, unchanged from 0000950170-25-029066:mdna:76]

[0001193125-25-189700:mdna:70]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |  | % Change |  |
| General and administrative expenses |  | $ | 84 |  |  | $ | 75 |  |  |  | 12 | % |

[0001193125-25-189700:mdna:71]
[same as prior period, unchanged from 0000950170-25-029066:mdna:78]

[0001193125-25-189700:mdna:72]
General and administrative expenses increased in the first quarter of fiscal 2026 compared to the corresponding period of the prior year, primarily attributable to higher compensation costs.

[0001193125-25-189700:mdna:73]
[same as prior period, unchanged from 0000950170-25-029066:mdna:80]

[0001193125-25-189700:mdna:74]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |  | % Change |  |
| Restructuring charges |  | $ | 2 |  |  | $ | 17 |  |  |  | (88 | )% |

[0001193125-25-189700:mdna:75]
In the first quarter of fiscal 2026, we incurred charges related to a restructuring plan previously approved by management in the fourth quarter of fiscal 2025 to redirect resources to the highest return activities and reduce costs. The activities under the plan were substantially completed by the end of the first quarter of fiscal 2026.

[0001193125-25-189700:mdna:76]
In the first quarter of fiscal 2025, management approved a restructuring plan to redirect resources to highest return activities and reduce costs. The activities under the plan were substantially completed by the end of fiscal 2025.

[0001193125-25-189700:mdna:77]
Other (Expense) Income, Net (in millions, except percentages)

[0001193125-25-189700:mdna:78]
The components of other (expense) income, net were as follows:

[0001193125-25-189700:mdna:79]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |  | % Change |  |
| Interest income |  | $ | 36 |  |  | $ | 36 |  |  |  | — | % |
| Interest expense |  |  | (29 | ) |  |  | (16 | ) |  |  | 81 | % |
| Other, net |  |  | (12 | ) |  |  | (3 | ) |  | NM |  |
| Total |  | $ | (5 | ) |  | $ | 17 |  |  |  | (129 | )% |

[0001193125-25-189700:mdna:80]
[same as prior period, unchanged from 0000950170-25-029066:mdna:90]

[0001193125-25-189700:mdna:81]
Interest expense increased in the first quarter of fiscal 2026 compared to the corresponding period of the prior year due to a higher average outstanding aggregate principal amount of Senior Notes, with a higher average coupon rate.

[0001193125-25-189700:mdna:82]
[same as prior period, unchanged from 0000950170-25-029066:mdna:93]

[0001193125-25-189700:mdna:83]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |  | % Change |  |
| Provision for income taxes |  | $ | 71 |  |  | $ | 51 |  |  |  | 39 | % |
| Effective tax rate |  |  | 23.4 | % |  |  | 17.1 | % |  | NM |  |

[0001193125-25-189700:mdna:84]
NM – Not Meaningful

[0001193125-25-189700:mdna:85]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate which is offset by non-deductible stock-based compensation and state taxes. Our effective tax rate for the three months ended July 25, 2025 includes a decrease in discrete tax benefits related to stock-based compensation compared to the corresponding period of the prior year.

[0001193125-25-189700:mdna:86]
As of July 25, 2025, we had $69 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $48 million of net unrecognized tax benefits would affect our provision for income taxes if recognized and have been recorded in other long-term liabilities.

[0001193125-25-189700:mdna:87]
[same as prior period, unchanged from 0000950170-25-029066:mdna:97]

[0001193125-25-189700:mdna:88]
| (In millions) |  | July 25, 2025 |  |  | April 25,2025 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,324 |  |  | $ | 3,846 |  |
| Principal amount of debt |  | $ | 2,500 |  |  | $ | 3,250 |  |

[0001193125-25-189700:mdna:89]
[same as prior period, unchanged from 0000950170-25-029066:mdna:99]

[0001193125-25-189700:mdna:90]
|  |  | Three Months Ended |  |
| (In millions) |  | July 25, 2025 |  |  | July 26, 2024 |  |
| Net cash provided by operating activities |  | $ | 673 |  |  | $ | 341 |  |
| Net cash used in investing activities |  |  | (181 | ) |  |  | (51 | ) |
| Net cash used in financing activities |  |  | (1,157 | ) |  |  | (548 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 7 |  |  |  | 8 |  |
| Net change in cash, cash equivalents and restricted cash |  | $ | (658 | ) |  | $ | (250 | ) |

[0001193125-25-189700:mdna:91]
[same as prior period, unchanged from 0000950170-25-029066:mdna:101]

[0001193125-25-189700:mdna:92]
As of July 25, 2025, our cash, cash equivalents and short-term investments were $3.3 billion, which represents a decrease of $522 million during the first three months of fiscal 2026. The decrease was primarily due to a $750 million principal repayment of our 1.875% Senior Notes due June 2025, $300 million used for the repurchase of our common stock, $104 million used for the payment of dividends, and $53 million used for purchases of property and equipment, partially offset by $673 million provided by operating activities. Our working capital was $1.1 billion as of July 25, 2025, reflecting a decrease of $71 million when compared to April 25, 2025.

[0001193125-25-189700:mdna:93]
[same as prior period, unchanged from 0000950170-25-029066:mdna:103]

[0001193125-25-189700:mdna:94]
During the first three months of fiscal 2026, cash provided by operating activities reflected net income of $233 million which was increased for non-cash depreciation and amortization expense of $51 million and non-cash stock-based compensation expense of $83 million. During the first three months of fiscal 2025, cash provided by operating activities reflected net income of $248 million which was increased for non-cash depreciation and amortization expense of $63 million and non-cash stock-based compensation expense of $85 million.

[0001193125-25-189700:mdna:95]
Significant changes in assets and liabilities in the first three months of fiscal 2026 included the following:

[0001193125-25-189700:mdna:96]
•
Accounts receivable decreased $466 million, reflecting lower billings and more favorable invoicing linearity in the first quarter of fiscal 2026 compared to the fourth quarter of fiscal 2025.

[0001193125-25-189700:mdna:97]
•
Accrued expenses decreased by $240 million, primarily due to employee compensation payments related to our fiscal 2025 incentive compensation plan accrual.

[0001193125-25-189700:mdna:98]
•
Accounts payable decreased by $107 million, reflecting lower purchases and the timing of payments to our suppliers in the first quarter of fiscal 2026 compared to the fourth quarter of fiscal 2025.

[0001193125-25-189700:mdna:99]
[same as prior period, unchanged from 0000950170-25-029066:mdna:110]

[0001193125-25-189700:mdna:100]
[same as prior period, unchanged from 0000950170-25-029066:mdna:60]

[0001193125-25-189700:mdna:101]
[same as prior period, unchanged from 0000950170-25-029066:mdna:111]

[0001193125-25-189700:mdna:102]
During the first three months of fiscal 2026, we used $143 million for purchases of investments, net of maturities and sales, and paid $53 million for capital expenditures, as compared to the same period of fiscal 2025, in which we used $10 million for the purchases of investments, net of maturities and sales, and paid $41 million for capital expenditures.

[0001193125-25-189700:mdna:103]
[same as prior period, unchanged from 0000950170-25-029066:mdna:114]

[0001193125-25-189700:mdna:104]
During the first three months of fiscal 2026, we used $750 million for the principal repayment upon maturity of our 1.875% Senior Notes due in June 2025, $300 million for the repurchase of 3.0 million shares of common stock, and $104 million for the payment of dividends. During the first three months of fiscal 2025, we used $400 million for the repurchase of 3.3 million shares of common stock and $107 million for the payment of dividends.

[0001193125-25-189700:mdna:105]
[same as prior period, unchanged from 0000950170-25-029066:mdna:116]

[0001193125-25-189700:mdna:106]
[same as prior period, unchanged from 0000950170-25-029066:mdna:117]

[0001193125-25-189700:mdna:107]
Our principal sources of liquidity as of July 25, 2025 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001193125-25-189700:mdna:108]
[same as prior period, unchanged from 0000950170-25-029066:mdna:119]

[0001193125-25-189700:mdna:109]
|  |  | July 25, 2025 |  |  | April 25, 2025 |  |
| Cash and cash equivalents |  | $ | 2,085 |  |  | $ | 2,742 |  |
| Short-term investments |  |  | 1,239 |  |  |  | 1,104 |  |
| Total |  | $ | 3,324 |  |  | $ | 3,846 |  |

[0001193125-25-189700:mdna:110]
As of July 25, 2025 and April 25, 2025, $2.8 billion and $2.5 billion , respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $514 million and $1.3 billion, respectively, were available in the U.S.

[0001193125-25-189700:mdna:111]
[same as prior period, unchanged from 0000950170-25-029066:mdna:122]

[0001193125-25-189700:mdna:112]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of July 25, 2025.

[0001193125-25-189700:mdna:113]
31

[0001193125-25-189700:mdna:114]
[same as prior period, unchanged from 0000950170-25-029066:mdna:124]

[0001193125-25-189700:mdna:115]
[same as prior period, unchanged from 0000950170-25-029066:mdna:125]

[0001193125-25-189700:mdna:116]
The following table summarizes the principal amount of our Senior Notes as of July 25, 2025 (in millions):

[0001193125-25-189700:mdna:117]
|  |  | Amount |  |
| 2.375% Senior Notes Due June 2027 |  | $ | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| 5.50% Senior Notes Due June 2032 |  |  | 625 |  |
| 5.70% Senior Notes Due June 2035 |  |  | 625 |  |
| Total |  | $ | 2,500 |  |

[0001193125-25-189700:mdna:118]
[same as prior period, unchanged from 0000950170-25-029066:mdna:128]

[0001193125-25-189700:mdna:119]
On June 23, 2025, upon maturity, we repaid our 1.875% Senior Notes due June 2025 for an aggregate amount of $757 million, comprised of the principal and unpaid interest.

[0001193125-25-189700:mdna:120]
Commercial Paper Program and Credit Facility

[0001193125-25-189700:mdna:121]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of July 25, 2025.

[0001193125-25-189700:mdna:122]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in March 2025, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on March 5, 2030, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of July 25, 2025, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0001193125-25-189700:mdna:123]
[same as prior period, unchanged from 0000950170-25-029066:mdna:134]

[0001193125-25-189700:mdna:124]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2026 to be between $125 million and $175 million.

[0001193125-25-189700:mdna:125]
[same as prior period, unchanged from 0000950170-25-029066:mdna:136]

[0001193125-25-189700:mdna:126]
The Tax Cuts and Jobs Act of 2017 imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits that had not previously been subject to U.S. income tax. As of July 25, 2025, a final transition tax payment of $179 million remained outstanding and was paid during the second quarter of fiscal 2026.

[0001193125-25-189700:mdna:127]
[same as prior period, unchanged from 0000950170-25-029066:mdna:138]

[0001193125-25-189700:mdna:128]
On August 21, 2025, we declared a cash dividend of $0.52 per share of common stock, payable on October 22, 2025, to holders of record as of the close of business on October 3, 2025.

[0001193125-25-189700:mdna:129]
32

[0001193125-25-189700:mdna:130]
In the first quarter of fiscal 2026, our Board of Directors authorized the repurchase of an additional $1.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. As of July 25, 2025, the remaining authorized amount for stock repurchases under this program was $1.2 billion.

[0001193125-25-189700:mdna:131]
[same as prior period, unchanged from 0000950170-25-029066:mdna:141]

[0001193125-25-189700:mdna:132]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled $1.3 billion at July 25, 2025.

[0001193125-25-189700:mdna:133]
[same as prior period, unchanged from 0000950170-25-029066:mdna:143]

[0001193125-25-189700:mdna:134]
We have and continue to enter into financing and leasing contracts through the ordinary course of business. These arrangements and related financing guarantees are described in Note 14 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1. There has been no material change in our financing guarantees as described in our 2025 Annual Report on Form 10-K.

[0001193125-25-189700:mdna:135]
Legal Contingencies

[0001193125-25-189700:mdna:136]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 14 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1.

[0001193125-25-189700:mdna:137]
[same as prior period, unchanged from 0000950170-25-029066:mdna:147]

[0001193125-25-189700:mdna:138]
There have been no material changes to our critical accounting policies and estimates as described in our 2025 Annual Report on Form 10-K.
