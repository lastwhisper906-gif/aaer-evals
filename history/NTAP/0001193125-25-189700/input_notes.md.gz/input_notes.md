# NTAP notes — 0001193125-25-189700


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-25-189700:notes:1]
[same as prior period, unchanged from 0000950170-25-029066:notes:1]

[0001193125-25-189700:notes:2]
NetApp, Inc. (we, us, our, NetApp, or the Company) helps customers make their data infrastructure more seamless, more dynamic, and higher performing. We provide a full range of enterprise-class software, systems and services that customers use to transform their data infrastructures across data types, workloads, and environments to realize business possibilities.

[0001193125-25-189700:notes:3]
[same as prior period, unchanged from 0000950170-25-029066:notes:3]

[0001193125-25-189700:notes:4]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal years 2026 and 2025, ending on April 24, 2026 and April 25, 2025, respectively, are each 52-week years, with 13 weeks in each quarter.

[0001193125-25-189700:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 25, 2025 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 25, 2025 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001193125-25-189700:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, the anticipated effects of which have been incorporated, as applicable, into management's estimates as of July 25, 2025.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001193125-25-189700:notes:7]
2. Recent Accounting Pronouncements

[0001193125-25-189700:notes:8]
In November 2024, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires additional disclosure of the nature of expenses included in the income statement. The standard requires disclosures about specific types of expenses included in the expense captions presented in the income statement as well as disclosures about selling expenses. This ASU is effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027, with early adoption permitted. The requirements should be applied on a prospective basis while retrospective application is permitted. We are currently evaluating the effect of this pronouncement on our disclosures.

[0001193125-25-189700:notes:9]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which expands the disclosures required for income taxes.  While retrospective application is permitted, we will adopt this standard in our Form 10-K for the year ending April 24, 2026 on a prospective basis. We are currently assessing the effect of the adoption of this standard on our disclosures.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-25-189700:notes:10]
[same as prior period, unchanged from 0000950170-25-029066:notes:11]

[0001193125-25-189700:notes:11]
Goodwill by reportable segment as of July 25, 2025 is as follows (in millions):

[0001193125-25-189700:notes:12]
|  |  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Balance as of April 25, 2025 |  | $ | 1,714 |  |  | $ | 1,009 |  |  | $ | 2,723 |  |
| Impact of foreign currency translation |  |  | — |  |  |  | 11 |  |  |  | 11 |  |
| Balance as of July 25, 2025 |  | $ | 1,714 |  |  | $ | 1,020 |  |  | $ | 2,734 |  |

[0001193125-25-189700:notes:13]
[same as prior period, unchanged from 0000950170-25-029066:notes:15]

[0001193125-25-189700:notes:14]
|  |  | July 25, 2025 |  |  | April 25, 2025 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 55 |  |  | $ | (36 | ) |  | $ | 19 |  |  | $ | 55 |  |  | $ | (33 | ) |  | $ | 22 |  |
| Customer contracts/relationships |  |  | 50 |  |  |  | (32 | ) |  |  | 18 |  |  |  | 50 |  |  |  | (29 | ) |  |  | 21 |  |
| Other purchased intangibles |  |  | 2 |  |  |  | (2 | ) |  |  | — |  |  |  | 2 |  |  |  | (2 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 107 |  |  | $ | (70 | ) |  | $ | 37 |  |  | $ | 107 |  |  | $ | (64 | ) |  | $ | 43 |  |

[0001193125-25-189700:notes:15]
[same as prior period, unchanged from 0000950170-25-029066:notes:18]

[0001193125-25-189700:notes:16]
|  |  | Three Months Ended | Statements of |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |  | IncomeClassifications |
| Developed technology |  | $ | 3 |  |  | $ | 8 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 3 |  |  |  | 6 |  |  | Operating expenses |
| Total |  | $ | 6 |  |  | $ | 14 |  |  |  |

[0001193125-25-189700:notes:17]
As of July 25, 2025, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001193125-25-189700:notes:18]
| Fiscal Year |  | Amount |  |
| 2026 (remainder) |  | $ | 15 |  |
| 2027 |  |  | 21 |  |
| 2028 |  |  | 1 |  |
| Total |  | $ | 37 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-25-189700:notes:19]
[same as prior period, unchanged from 0000950170-25-029066:notes:22]

[0001193125-25-189700:notes:20]
[same as prior period, unchanged from 0000950170-25-029066:notes:23]

[0001193125-25-189700:notes:21]
[same as prior period, unchanged from 0000950170-25-029066:notes:24]

[0001193125-25-189700:notes:22]
|  |  | July 25, 2025 |  |  | April 25,2025 |  |
| Cash and cash equivalents |  | $ | 2,085 |  |  | $ | 2,742 |  |
| Restricted cash |  |  | 6 |  |  |  | 7 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,091 |  |  | $ | 2,749 |  |

[0001193125-25-189700:notes:23]
[same as prior period, unchanged from 0000950170-25-029066:notes:26]

[0001193125-25-189700:notes:24]
|  |  | July 25, 2025 |  |  | April 25,2025 |  |
| Purchased components |  | $ | 66 |  |  | $ | 81 |  |
| Finished goods |  |  | 67 |  |  |  | 105 |  |
| Inventories |  | $ | 133 |  |  | $ | 186 |  |

[0001193125-25-189700:notes:25]
[same as prior period, unchanged from 0000950170-25-029066:notes:28]

[0001193125-25-189700:notes:26]
|  |  | July 25, 2025 |  |  | April 25,2025 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 374 |  |  |  | 374 |  |
| Leasehold improvements |  |  | 106 |  |  |  | 103 |  |
| Computer, production, engineering and other equipment |  |  | 1,194 |  |  |  | 1,172 |  |
| Computer software |  |  | 331 |  |  |  | 329 |  |
| Furniture and fixtures |  |  | 64 |  |  |  | 62 |  |
| Construction-in-progress |  |  | 55 |  |  |  | 49 |  |
|  |  |  | 2,170 |  |  |  | 2,135 |  |
| Accumulated depreciation and amortization |  |  | (1,600 | ) |  |  | (1,572 | ) |
| Property and equipment, net |  | $ | 570 |  |  | $ | 563 |  |

[0001193125-25-189700:notes:27]
[same as prior period, unchanged from 0000950170-25-029066:notes:31]

[0001193125-25-189700:notes:28]
|  |  | July 25, 2025 |  |  | April 25,2025 |  |
| Deferred tax assets |  | $ | 985 |  |  | $ | 994 |  |
| Operating lease right-of-use (ROU) assets |  |  | 244 |  |  |  | 241 |  |
| Other assets |  |  | 422 |  |  |  | 408 |  |
| Other non-current assets |  | $ | 1,651 |  |  | $ | 1,643 |  |

[0001193125-25-189700:notes:29]
Other non-current assets as of July 25, 2025 and April 25, 2025 include $93 million and $92 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies.

[0001193125-25-189700:notes:30]
[same as prior period, unchanged from 0000950170-25-029066:notes:34]

[0001193125-25-189700:notes:31]
|  |  | July 25, 2025 |  |  | April 25,2025 |  |
| Accrued compensation and benefits |  | $ | 332 |  |  | $ | 513 |  |
| Product warranty liabilities |  |  | 17 |  |  |  | 18 |  |
| Operating lease liabilities |  |  | 41 |  |  |  | 40 |  |
| Other current liabilities |  |  | 505 |  |  |  | 551 |  |
| Accrued expenses |  | $ | 895 |  |  | $ | 1,122 |  |

[0001193125-25-189700:notes:32]
[same as prior period, unchanged from 0000950170-25-029066:notes:36]

[0001193125-25-189700:notes:33]
|  |  | July 25, 2025 |  |  | April 25,2025 |  |
| Liability for uncertain tax positions |  | $ | 48 |  |  | $ | 45 |  |
| Product warranty liabilities |  |  | 9 |  |  |  | 9 |  |
| Operating lease liabilities |  |  | 219 |  |  |  | 216 |  |
| Other liabilities |  |  | 118 |  |  |  | 109 |  |
| Other long-term liabilities |  | $ | 394 |  |  | $ | 379 |  |

[0001193125-25-189700:notes:34]
[same as prior period, unchanged from 0000950170-25-029066:notes:38]

[0001193125-25-189700:notes:35]
[same as prior period, unchanged from 0000950170-25-029066:notes:39]

[0001193125-25-189700:notes:36]
|  |  | July 25, 2025 |  |  | April 25,2025 |  |
| Deferred product revenue |  | $ | 69 |  |  | $ | 66 |  |
| Deferred services revenue |  |  | 4,417 |  |  |  | 4,428 |  |
| Financed unearned services revenue |  |  | 40 |  |  |  | 42 |  |
| Total |  | $ | 4,526 |  |  | $ | 4,536 |  |
| Reported as: |  |  |  |  |  |  |
| Short-term |  | $ | 2,270 |  |  | $ | 2,279 |  |
| Long-term |  |  | 2,256 |  |  |  | 2,257 |  |
| Total |  | $ | 4,526 |  |  | $ | 4,536 |  |

[0001193125-25-189700:notes:37]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 14 – Commitments and Contingencies for additional information related to these arrangements.

[0001193125-25-189700:notes:38]
During the three months ended July 25, 2025 and July 26, 2024, we recognized revenue of $714 million and $670 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001193125-25-189700:notes:39]
[same as prior period, unchanged from 0000950170-25-029066:notes:43]

[0001193125-25-189700:notes:40]
As of July 25, 2025, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $4.9 billion. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 49% of our remaining performance obligations in the next 12 months and the remainder thereafter.

[0001193125-25-189700:notes:41]
[same as prior period, unchanged from 0000950170-25-029066:notes:45]

[0001193125-25-189700:notes:42]
[same as prior period, unchanged from 0000950170-25-029066:notes:46]

[0001193125-25-189700:notes:43]
|  |  | July 25, 2025 |  |  | April 25,2025 |  |
| Other current assets |  | $ | 65 |  |  | $ | 64 |  |
| Other non-current assets |  |  | 103 |  |  |  | 104 |  |
| Total deferred commissions |  | $ | 168 |  |  | $ | 168 |  |

[0001193125-25-189700:notes:44]
Other (expense) income, net (in millions):

[0001193125-25-189700:notes:45]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |
| Interest income |  | $ | 36 |  |  | $ | 36 |  |
| Interest expense |  |  | (29 | ) |  |  | (16 | ) |
| Other, net |  |  | (12 | ) |  |  | (3 | ) |
| Total other (expense) income, net |  | $ | (5 | ) |  | $ | 17 |  |

[0001193125-25-189700:notes:46]
[same as prior period, unchanged from 0000950170-25-029066:notes:50]

[0001193125-25-189700:notes:47]
[same as prior period, unchanged from 0000950170-25-029066:notes:51]

[0001193125-25-189700:notes:48]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 12 |  |  | $ | 13 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 11 |  |  | $ | 21 |  |
| Interest paid |  | $ | 23 |  |  | $ | 23 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-25-189700:notes:49]
[same as prior period, unchanged from 0000950170-25-029066:notes:56]

[0001193125-25-189700:notes:50]
[same as prior period, unchanged from 0000950170-25-029066:notes:57]

[0001193125-25-189700:notes:51]
[same as prior period, unchanged from 0000950170-25-029066:notes:58]

[0001193125-25-189700:notes:52]
[same as prior period, unchanged from 0000950170-25-029066:notes:59]

[0001193125-25-189700:notes:53]
[same as prior period, unchanged from 0000950170-25-029066:notes:60]

[0001193125-25-189700:notes:54]
[same as prior period, unchanged from 0000950170-25-029066:notes:61]

[0001193125-25-189700:notes:55]
[same as prior period, unchanged from 0000950170-25-029066:notes:62]

[0001193125-25-189700:notes:56]
The following is a summary of our investments at their cost or amortized cost as of July 25, 2025 and April 25, 2025 (in millions):

[0001193125-25-189700:notes:57]
|  |  | July 25, 2025 |  |  | April 25,2025 |  |
| U.S. Treasury and government debt securities |  | $ | 1,239 |  |  | $ | 2,025 |  |
| Money market funds |  |  | 1,419 |  |  |  | 1,126 |  |
| Certificates of deposit |  |  | 33 |  |  |  | 24 |  |
| Mutual funds |  |  | 48 |  |  |  | 41 |  |
| Total debt and equity securities |  | $ | 2,739 |  |  | $ | 3,216 |  |

[0001193125-25-189700:notes:58]
[same as prior period, unchanged from 0000950170-25-029066:notes:65]

[0001193125-25-189700:notes:59]
As of July 25, 2025, all our debt investments are due to mature in one year or less.

[0001193125-25-189700:notes:60]
[same as prior period, unchanged from 0000950170-25-029066:notes:67]

[0001193125-25-189700:notes:61]
[same as prior period, unchanged from 0000950170-25-029066:notes:68]

[0001193125-25-189700:notes:62]
|  |  | July 25, 2025 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 633 |  |  | $ | 633 |  |  | $ | — |  |
| Money market funds |  |  | 1,419 |  |  |  | 1,419 |  |  |  | — |  |
| Certificates of deposit |  |  | 33 |  |  |  | — |  |  |  | 33 |  |
| Total cash and cash equivalents |  |  | 2,085 |  |  |  | 2,052 |  |  |  | 33 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 1,239 |  |  |  | 1,239 |  |  |  | — |  |
| Total short-term investments |  |  | 1,239 |  |  |  | 1,239 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,324 |  |  | $ | 3,291 |  |  | $ | 33 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 42 |  |  | $ | 42 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |

[0001193125-25-189700:notes:63]
|  |  | April 25, 2025 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 671 |  |  | $ | 671 |  |  | $ | — |  |
| Money market funds |  |  | 1,126 |  |  |  | 1,126 |  |  |  | — |  |
| Certificates of deposit |  |  | 24 |  |  |  | — |  |  |  | 24 |  |
| U.S. Treasury and government debt securities |  |  | 921 |  |  |  | 921 |  |  |  | — |  |
| Total cash and cash equivalents |  |  | 2,742 |  |  |  | 2,718 |  |  |  | 24 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 1,104 |  |  |  | 1,104 |  |  |  | — |  |
| Total short-term investments |  |  | 1,104 |  |  |  | 1,104 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,846 |  |  | $ | 3,822 |  |  | $ | 24 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 34 |  |  | $ | 34 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (2 | ) |  | $ | — |  |  | $ | (2 | ) |

[0001193125-25-189700:notes:64]
[same as prior period, unchanged from 0000950170-25-029066:notes:71]

[0001193125-25-189700:notes:65]
[same as prior period, unchanged from 0000950170-25-029066:notes:72]

[0001193125-25-189700:notes:66]
[same as prior period, unchanged from 0000950170-25-029066:notes:73]

[0001193125-25-189700:notes:67]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of July 25, 2025 and April 25, 2025, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001193125-25-189700:notes:68]
[same as prior period, unchanged from 0000950170-25-029066:notes:75]

[0001193125-25-189700:notes:69]
As of July 25, 2025 and April 25, 2025, the fair value of our long-term debt, which includes the current portion of long-term debt, was $2,443 million and $3,143 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0001193125-25-189700:notes:70]
6. Financing Arrangements

[0001193125-25-189700:notes:71]
Long-Term Debt

[0001193125-25-189700:notes:72]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001193125-25-189700:notes:73]
|  |  | Effective Interest Rate |  | July 25, 2025 |  |  | April 25, 2025 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  | $ | — |  |  | $ | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| 5.50% Senior Notes Due June 2032 |  | 5.71% |  |  | 625 |  |  |  | 625 |  |
| 5.70% Senior Notes Due June 2035 |  | 5.90% |  |  | 625 |  |  |  | 625 |  |
| Total principal amount |  |  |  |  | 2,500 |  |  |  | 3,250 |  |
| Unamortized discount and issuance costs |  |  |  |  | (15 | ) |  |  | (15 | ) |
| Total senior notes |  |  |  |  | 2,485 |  |  |  | 3,235 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (750 | ) |
| Total long-term debt |  |  |  | $ | 2,485 |  |  | $ | 2,485 |  |

[0001193125-25-189700:notes:74]
Senior Notes

[0001193125-25-189700:notes:75]
On June 23, 2025, upon maturity, we repaid the 1.875% Senior Notes due June 2025 for an aggregate amount of $757 million, comprised of the principal and unpaid interest.

[0001193125-25-189700:notes:76]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness. Interest on our Senior Notes is payable semi-annually.

[0001193125-25-189700:notes:77]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 25, 2025, we were in compliance with all covenants associated with the Senior Notes.

[0001193125-25-189700:notes:78]
As of July 25, 2025, our aggregate future principal debt maturities are as follows (in millions):

[0001193125-25-189700:notes:79]
| Fiscal Year |  | Amount |  |
| 2026 |  | $ | — |  |
| 2027 |  |  | — |  |
| 2028 |  |  | 550 |  |
| 2029 |  |  | — |  |
| 2030 |  |  | — |  |
| Thereafter |  |  | 1,950 |  |
| Total |  | $ | 2,500 |  |

[0001193125-25-189700:notes:80]
Commercial Paper Program and Credit Facility

[0001193125-25-189700:notes:81]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of July 25, 2025 or April 25, 2025.

[0001193125-25-189700:notes:82]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in March 2025, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on March 5, 2030, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of July 25, 2025, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0001193125-25-189700:notes:83]
[same as prior period, unchanged from 0000950170-25-029066:notes:90]

[0001193125-25-189700:notes:84]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of July 25, 2025, have remaining lease terms not exceeding 16 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of July 25, 2025, have remaining lease terms not exceeding 4 years. As of July 25, 2025, our automobile leases have remaining lease terms not exceeding 4 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0001193125-25-189700:notes:85]
[same as prior period, unchanged from 0000950170-25-029066:notes:92]

[0001193125-25-189700:notes:86]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |
| Operating lease cost |  | $ | 13 |  |  | $ | 13 |  |
| Variable lease cost |  |  | 4 |  |  |  | 4 |  |
| Total lease cost |  | $ | 17 |  |  | $ | 17 |  |

[0001193125-25-189700:notes:87]
[same as prior period, unchanged from 0000950170-25-029066:notes:94]

[0001193125-25-189700:notes:88]
[same as prior period, unchanged from 0000950170-25-029066:notes:95]

[0001193125-25-189700:notes:89]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 12 |  |  | $ | 12 |  |
| ROU assets obtained in exchange for new operating lease obligations |  | $ | 8 |  |  | $ | 3 |  |

[0001193125-25-189700:notes:90]
[same as prior period, unchanged from 0000950170-25-029066:notes:97]

[0001193125-25-189700:notes:91]
|  |  | July 25, 2025 |  |  | April 25, 2025 |  |
| Other non-current assets |  | $ | 244 |  |  | $ | 241 |  |
| Total operating lease ROU assets |  | $ | 244 |  |  | $ | 241 |  |
| Accrued expenses |  | $ | 41 |  |  | $ | 40 |  |
| Other long-term liabilities |  |  | 219 |  |  |  | 216 |  |
| Total operating lease liabilities |  | $ | 260 |  |  | $ | 256 |  |
| Weighted Average Remaining Lease Term |  | 8.2 years |  |  | 8.5 years |  |
| Weighted Average Discount Rate |  |  | 3.5 | % |  |  | 3.4 | % |

[0001193125-25-189700:notes:92]
Future minimum operating lease payments as of July 25, 2025, are as follows (in millions):

[0001193125-25-189700:notes:93]
| Fiscal Year |  |  |  | Amount |  |
| 2026 (remainder) |  |  |  | $ | 37 |  |
| 2027 |  |  |  |  | 45 |  |
| 2028 |  |  |  |  | 39 |  |
| 2029 |  |  |  |  | 35 |  |
| 2030 |  |  |  |  | 30 |  |
| Thereafter |  |  |  |  | 114 |  |
| Total lease payments |  |  |  |  | 300 |  |
| Less: Interest |  |  |  |  | (40 | ) |
| Total |  |  |  | $ | 260 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001193125-25-189700:notes:94]
[same as prior period, unchanged from 0000950170-25-029066:notes:101]

[0001193125-25-189700:notes:95]
[same as prior period, unchanged from 0000950170-25-029066:notes:102]

[0001193125-25-189700:notes:96]
We granted 3 million restricted stock units (RSUs), including performance-based RSUs (PBRSUs), with a weighted average grant date fair value of $103.99 per share during the three months ended July 25, 2025.

[0001193125-25-189700:notes:97]
In the three months ended July 25, 2025, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSUs cliff-vest at the end of a three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the third fiscal year, following the grant date. The number of shares that will be used to calculate the settlement amount for all of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the three months ended July 25, 2025, the number of shares used to calculate the settlement amount will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. For the remaining half of the PBRSUs granted in the three months ended July 25, 2025, the number of shares used to calculate the settlement amount will depend upon the Company's billings result average over the three-year performance period. The billings result average is computed based on achievement against annual billings targets, with each target set at the beginning of the respective fiscal year, during the three-year performance period. Billings for purposes of measuring the performance of these PBRSUs means the total obtained by adding net revenues as reported on the Company's Consolidated Statements of Income to the amount reported as the change in deferred revenue

[0001193125-25-189700:notes:98]
and financed unearned services revenue on the Consolidated Statements of Cash Flows for the applicable measurement period, excluding the impact of fluctuations in foreign currency exchange rates. The aggregate grant date fair value of PBRSUs granted in the current year was $51 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0001193125-25-189700:notes:99]
[same as prior period, unchanged from 0000950170-25-029066:notes:106]

[0001193125-25-189700:notes:100]
[same as prior period, unchanged from 0000950170-25-029066:notes:107]

[0001193125-25-189700:notes:101]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |
| Cost of hardware support and other services revenues |  |  | 6 |  |  |  | 6 |  |
| Sales and marketing |  |  | 34 |  |  |  | 35 |  |
| Research and development |  |  | 25 |  |  |  | 31 |  |
| General and administrative |  |  | 17 |  |  |  | 12 |  |
| Total stock-based compensation expense |  | $ | 83 |  |  | $ | 85 |  |

[0001193125-25-189700:notes:102]
As of July 25, 2025, total unrecognized compensation expense related to equity awards was $845 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.4 years.

[0001193125-25-189700:notes:103]
[same as prior period, unchanged from 0000950170-25-029066:notes:110]

[0001193125-25-189700:notes:104]
In the first quarter of fiscal 2026, our Board of Directors authorized the repurchase of an additional $1.1 billion of our common stock. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time.

[0001193125-25-189700:notes:105]
The following table summarizes activity related to the stock repurchase program for the three months ended July 25, 2025 (in millions, except for per share amounts):

[0001193125-25-189700:notes:106]
| Number of shares repurchased |  |  | 3.0 |  |
| Average price per share |  | $ | 99.76 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 67 |  |
| Stock repurchases allocated to retained earnings |  | $ | 233 |  |
| Remaining authorization at end of period |  | $ | 1,152 |  |

[0001193125-25-189700:notes:107]
[same as prior period, unchanged from 0000950170-25-029066:notes:115]

[0001193125-25-189700:notes:108]
[same as prior period, unchanged from 0000950170-25-029066:notes:116]

[0001193125-25-189700:notes:109]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |
| Dividends per share declared |  | $ | 0.52 |  |  | $ | 0.52 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 104 |  |  | $ | 35 |  |
| Dividend payments allocated to retained earnings |  | $ | — |  |  | $ | 72 |  |

[0001193125-25-189700:notes:110]
On August 21, 2025, we declared a cash dividend of $0.52 per share of common stock, payable on October 22, 2025 to holders of record as of the close of business on October 3, 2025. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-25-189700:notes:111]
[same as prior period, unchanged from 0000950170-25-029066:notes:124]

[0001193125-25-189700:notes:112]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of July 25, 2025 or April 25, 2025. All contracts have a maturity of less than 12 months.

[0001193125-25-189700:notes:113]
[same as prior period, unchanged from 0000950170-25-029066:notes:126]

[0001193125-25-189700:notes:114]
|  |  | July 25, 2025 |  |  | April 25, 2025 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 119 |  |  | $ | 81 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 1,533 |  |  | $ | 790 |  |

[0001193125-25-189700:notes:115]
The gain (loss) of cash flow hedges recognized in net revenues is presented in the condensed consolidated statements of comprehensive income.

[0001193125-25-189700:notes:116]
The effect of derivative instruments not designated as hedging instruments recognized in other (expense) income, net on our condensed consolidated statements of income was as follows (in millions):

[0001193125-25-189700:notes:117]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |
|  |  | Gain Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 18 |  |  | $ | 13 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-25-189700:notes:118]
[same as prior period, unchanged from 0000950170-25-029066:notes:131]

[0001193125-25-189700:notes:119]
In the first quarter of fiscal 2026, we incurred charges related to a restructuring plan previously approved by management in the fourth quarter of fiscal 2025 to redirect resources to the highest return activities and reduce costs. The activities under the plan were substantially completed by the end of the first quarter of fiscal 2026.

[0001193125-25-189700:notes:120]
In the first quarter of fiscal 2025, management approved a restructuring plan to redirect resources to highest return activities and reduce costs. The activities under the plan were substantially completed by the end of fiscal 2025.

[0001193125-25-189700:notes:121]
[same as prior period, unchanged from 0000950170-25-029066:notes:134]

[0001193125-25-189700:notes:122]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |
| Balance at beginning of period |  | $ | 51 |  |  | $ | 10 |  |
| Net charges |  |  | 2 |  |  |  | 17 |  |
| Cash payments |  |  | (37 | ) |  |  | (9 | ) |
| Balance at end of period |  | $ | 16 |  |  | $ | 18 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-25-189700:notes:123]
[same as prior period, unchanged from 0000950170-25-029066:notes:136]

[0001193125-25-189700:notes:124]
[same as prior period, unchanged from 0000950170-25-029066:notes:137]

[0001193125-25-189700:notes:125]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |
| Effective tax rates |  |  | 23.4 | % |  |  | 17.1 | % |

[0001193125-25-189700:notes:126]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate which is offset by non-deductible stock-based compensation and state taxes. Our effective tax rate for the three months ended July 25, 2025 includes a decrease in discrete tax benefits related to stock-based compensation compared to the corresponding period of the prior year.

[0001193125-25-189700:notes:127]
On July 4, 2025, the reconciliation bill H.R. 1, referred to as the One Big Beautiful Bill Act (OBBB), was signed into law in the United States. The OBBB contains several changes to corporate taxation including the extension of key provisions of the 2017 Tax Cuts and Jobs Act and modifications to the international tax framework. The legislation has multiple effective dates, with certain provisions effective in our fiscal year 2026 and others phased in through our fiscal year 2027. We are still in the process of evaluating the impact of the OBBB on our financial statements, but an estimate of the financial impact has been included in our operating results for the three months ended July 25, 2025. The OBBB did not have a material impact to our income tax provision for the three months ended July 25, 2025.

[0001193125-25-189700:notes:128]
We are currently subject to Pillar Two rules relating to a global minimum tax enacted by The Organisation for Economic Co-operation and Development (OECD). As of July 25, 2025, Pillar Two taxes do not have a significant impact on our financial statements, particularly due to the safe harbor relief during the transition period, but we are still closely monitoring developments.

[0001193125-25-189700:notes:129]
[same as prior period, unchanged from 0000950170-25-029066:notes:141]

[0001193125-25-189700:notes:130]
[same as prior period, unchanged from 0000950170-25-029066:notes:142]

[0001193125-25-189700:notes:131]
As of July 25, 2025, we had $69 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $48 million of net unrecognized tax benefits would affect our provision for income taxes if recognized and have been recorded in other long-term liabilities.


## us-gaap:EarningsPerShareTextBlock

[0001193125-25-189700:notes:132]
[same as prior period, unchanged from 0000950170-25-029066:notes:144]

[0001193125-25-189700:notes:133]
[same as prior period, unchanged from 0000950170-25-029066:notes:145]

[0001193125-25-189700:notes:134]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |
| Numerator: |  |  |  |  |  |  |
| Net income |  | $ | 233 |  |  | $ | 248 |  |
| Denominator: |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 201 |  |  |  | 206 |  |
| Dilutive impact of employee equity award plans |  |  | 2 |  |  |  | 6 |  |
| Shares used in diluted computation |  |  | 203 |  |  |  | 212 |  |
| Net Income per Share: |  |  |  |  |  |  |
| Basic |  | $ | 1.16 |  |  | $ | 1.20 |  |
| Diluted |  | $ | 1.15 |  |  | $ | 1.17 |  |

[0001193125-25-189700:notes:135]
[same as prior period, unchanged from 0000950170-25-029066:notes:147]

[0001193125-25-189700:notes:136]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |
| Employee equity award plans |  |  | — |  |  |  | 1 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-25-189700:notes:137]
[same as prior period, unchanged from 0000950170-25-029066:notes:149]

[0001193125-25-189700:notes:138]
Our operations are organized into two segments: Hybrid Cloud and Public Cloud. The two segments are based on the information reviewed by our Chief Operating Decision Maker (CODM), who is the Chief Executive Officer, to evaluate results and allocate resources. The CODM measures performance of each segment based on segment revenue and segment gross profit by comparing actual revenue and gross profit results to historical results and previously forecasted financial information. We do not allocate to our segments certain cost of revenues which we manage at the corporate level. These unallocated costs include stock-based compensation and amortization of intangible assets. We do not allocate assets to our segments.

[0001193125-25-189700:notes:139]
Hybrid Cloud offers a unified data storage portfolio of storage management and infrastructure solutions that helps customers modernize their data centers. This portfolio accommodates both structured and unstructured data with unified storage optimized for flash, disk, and cloud storage, capable of handling data-intensive workloads and applications. Hybrid Cloud includes software, hardware, and related support, along with professional and other services.

[0001193125-25-189700:notes:140]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage, data services, and operational services. Public Cloud includes certain reseller arrangements in which the timing of our consideration follows the end user consumption of the reseller services.

[0001193125-25-189700:notes:141]
[same as prior period, unchanged from 0000950170-25-029066:notes:153]

[0001193125-25-189700:notes:142]
[same as prior period, unchanged from 0000950170-25-029066:notes:154]

[0001193125-25-189700:notes:143]
|  | Three Months Ended July 25, 2025 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Product revenues | $ | 654 |  |  | $ | — |  |  | $ | 654 |  |
| Support revenues |  | 647 |  |  |  | — |  |  |  | 647 |  |
| Professional and other services revenues |  | 97 |  |  |  | — |  |  |  | 97 |  |
| Public cloud revenues |  | — |  |  |  | 161 |  |  |  | 161 |  |
| Net revenues |  | 1,398 |  |  |  | 161 |  |  |  | 1,559 |  |
| Cost of product revenues |  | 301 |  |  |  | — |  |  |  | 301 |  |
| Cost of support revenues |  | 50 |  |  |  | — |  |  |  | 50 |  |
| Cost of professional and other services revenues |  | 68 |  |  |  | — |  |  |  | 68 |  |
| Cost of public cloud revenues |  | — |  |  |  | 32 |  |  |  | 32 |  |
| Segment cost of revenues |  | 419 |  |  |  | 32 |  |  |  | 451 |  |
| Segment gross profit | $ | 979 |  |  | $ | 129 |  |  | $ | 1,108 |  |
| Segment gross margin |  | 70.0 | % |  |  | 80.1 | % |  |  | 71.1 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 10 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,098 |  |
| Total gross margin |  |  |  |  |  |  |  | 70.4 | % |
| 1 Unallocated cost of revenues are composed of $7 million of stock-based compensation expense and $3 million of amortization of intangible assets. |  |

[0001193125-25-189700:notes:144]
|  | Three Months Ended July 26, 2024 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Product revenues | $ | 669 |  |  | $ | — |  |  | $ | 669 |  |
| Support revenues |  | 631 |  |  |  | — |  |  |  | 631 |  |
| Professional and other services revenues |  | 82 |  |  |  | — |  |  |  | 82 |  |
| Public cloud revenues |  | — |  |  |  | 159 |  |  |  | 159 |  |
| Net revenues |  | 1,382 |  |  |  | 159 |  |  |  | 1,541 |  |
| Cost of product revenues |  | 268 |  |  |  | — |  |  |  | 268 |  |
| Cost of support revenues |  | 50 |  |  |  | — |  |  |  | 50 |  |
| Cost of professional and other services revenues |  | 64 |  |  |  | — |  |  |  | 64 |  |
| Cost of public cloud revenues |  | — |  |  |  | 46 |  |  |  | 46 |  |
| Segment cost of revenues |  | 382 |  |  |  | 46 |  |  |  | 428 |  |
| Segment gross profit | $ | 1,000 |  |  | $ | 113 |  |  | $ | 1,113 |  |
| Segment gross margin |  | 72.4 | % |  |  | 71.1 | % |  |  | 72.2 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 15 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,098 |  |
| Total gross margin |  |  |  |  |  |  |  | 71.3 | % |
| 1 Unallocated cost of revenues are composed of $7 million of stock-based compensation expense and $8 million of amortization of intangible assets. |  |

[0001193125-25-189700:notes:145]
[same as prior period, unchanged from 0000950170-25-029066:notes:159]

[0001193125-25-189700:notes:146]
[same as prior period, unchanged from 0000950170-25-029066:notes:160]

[0001193125-25-189700:notes:147]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |
| United States, Canada and Latin America (Americas) |  | $ | 791 |  |  | $ | 763 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 503 |  |  |  | 513 |  |
| Asia Pacific (APAC) |  |  | 265 |  |  |  | 265 |  |
| Net revenues |  | $ | 1,559 |  |  | $ | 1,541 |  |

[0001193125-25-189700:notes:148]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $746 million and $699 million during the three months ended July 25, 2025 and July 26, 2024, respectively.

[0001193125-25-189700:notes:149]
[same as prior period, unchanged from 0000950170-25-029066:notes:163]

[0001193125-25-189700:notes:150]
|  |  | July 25, 2025 |  |  | April 25, 2025 |  |
| U.S. |  | $ | 514 |  |  | $ | 1,320 |  |
| International |  |  | 2,810 |  |  |  | 2,526 |  |
| Total |  | $ | 3,324 |  |  | $ | 3,846 |  |

[0001193125-25-189700:notes:151]
[same as prior period, unchanged from 0000950170-25-029066:notes:165]

[0001193125-25-189700:notes:152]
|  |  | July 25, 2025 |  |  | April 25, 2025 |  |
| U.S. |  | $ | 346 |  |  | $ | 344 |  |
| International |  |  | 224 |  |  |  | 219 |  |
| Total |  | $ | 570 |  |  | $ | 563 |  |

[0001193125-25-189700:notes:153]
[same as prior period, unchanged from 0000950170-25-029066:notes:167]

[0001193125-25-189700:notes:154]
[same as prior period, unchanged from 0000950170-25-029066:notes:168]

[0001193125-25-189700:notes:155]
|  |  | Three Months Ended |  |
|  |  | July 25, 2025 |  |  | July 26, 2024 |  |
| Arrow Electronics, Inc. |  |  | 23 | % |  |  | 23 | % |
| TD Synnex Corporation |  |  | 21 | % |  |  | 22 | % |

[0001193125-25-189700:notes:156]
[same as prior period, unchanged from 0000950170-25-029066:notes:170]

[0001193125-25-189700:notes:157]
|  |  | July 25, 2025 |  |  | April 25, 2025 |  |
| Arrow Electronics, Inc. |  |  | 6 | % |  |  | 10 | % |
| TD Synnex Corporation |  |  | 15 | % |  |  | 27 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-25-189700:notes:158]
14. Commitments and Contingencies

[0001193125-25-189700:notes:159]
Purchase Orders and Other Commitments

[0001193125-25-189700:notes:160]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of July 25, 2025, we had $0.7 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 25, 2025 and April 25, 2025, such liability amounted to $24 million and $22 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001193125-25-189700:notes:161]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 25, 2025, we had $0.6 billion in other purchase obligations.

[0001193125-25-189700:notes:162]
Financing Guarantees

[0001193125-25-189700:notes:163]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution. We sold $10 million and $19 million of receivables during the three months ended July 25, 2025 and July 26, 2024, respectively.

[0001193125-25-189700:notes:164]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user.

[0001193125-25-189700:notes:165]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of July 25, 2025 and April 25, 2025, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001193125-25-189700:notes:166]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 25, 2025, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make material payments under these arrangements is remote.

[0001193125-25-189700:notes:167]
Legal Contingencies

[0001193125-25-189700:notes:168]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a

[0001193125-25-189700:notes:169]
meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001193125-25-189700:notes:170]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigation brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001193125-25-189700:notes:171]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of July 25, 2025 related to such matters.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001193125-25-189700:notes:172]
[same as prior period, unchanged from 0000950170-25-029066:notes:186]

[0001193125-25-189700:notes:173]
[same as prior period, unchanged from 0000950170-25-029066:notes:187]

[0001193125-25-189700:notes:174]
On June 26, 2025, Daniel De Lorenzo, Vice President, Chief Accounting Officer of the Company, entered into a 10b5-1 trading arrangement intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) promulgated under the Exchange Act. The trading arrangement will expire on September 25, 2026, and may be terminated earlier in the limited circumstances defined in the trading arrangement. An aggregate of up to 3,308 shares may be sold pursuant to the trading arrangement.

[0001193125-25-189700:notes:175]
[same as prior period, unchanged from 0000950170-25-029066:notes:189]
