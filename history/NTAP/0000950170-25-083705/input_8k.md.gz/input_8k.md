# NTAP 8-K — 0000950170-25-078936 filed 2025-05-29

## item codes, every 8-K on or before 2025-06-09

- 2025-05-29 0000950170-25-078936 — 2.02, 5.02, 8.01, 9.01
- 2025-03-26 0000950170-25-045244 — 5.02, 7.01, 9.01
- 2025-03-17 0001193125-25-055656 — 1.01, 2.03, 8.01, 9.01
- 2025-03-05 0001193125-25-047187 — 1.01, 2.03, 9.01
- 2025-02-27 0000950170-25-029022 — 2.02, 9.01
- 2025-02-26 0001193125-25-036882 — 5.02, 9.01
- 2025-01-28 0001193125-25-014441 — 5.02, 9.01
- 2024-11-21 0000950170-24-129714 — 2.02, 9.01
- 2024-09-12 0000950170-24-105928 — 5.02, 5.07, 9.01
- 2024-08-28 0000950170-24-101383 — 2.02, 5.02, 9.01
- 2024-05-30 0000950170-24-066567 — 2.02, 8.01, 9.01
- 2024-04-09 0000950170-24-042957 — 5.02
- 2024-02-29 0000950170-24-023060 — 2.02, 9.01
- 2023-11-28 0000950170-23-066400 — 2.02, 9.01
- 2023-11-16 0000950170-23-064506 — 5.02, 5.03, 9.01
- 2023-09-15 0000950170-23-048229 — 5.02, 5.07, 9.01
- 2023-08-23 0000950170-23-044130 — 2.02, 9.01
- 2023-08-10 0000950170-23-041348 — 5.02
- 2023-05-31 0000950170-23-025324 — 1.01, 2.02, 8.01, 9.01
- 2023-02-22 0000950170-23-003745 — 2.02, 9.01
- 2023-01-31 0001193125-23-019739 — 2.05, 7.01, 9.01
- 2022-11-29 0000950170-22-025793 — 2.02, 9.01
- 2022-11-16 0000950170-22-025317 — 5.02
- 2022-09-14 0000950170-22-018490 — 5.07
- 2022-08-24 0000950170-22-017731 — 2.02, 9.01
- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2025-06-09

- none on or before 2025-06-09

## item 2.02 — earnings release, exhibit 99.1

[0000950170-25-078936:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0000950170-25-078936:8k_2_02:2]
EX-99.1

[0000950170-25-078936:8k_2_02:3]
Exhibit 99.1

[0000950170-25-078936:8k_2_02:4]
NetApp Reports Record Results for Fourth Quarter and Fiscal Year 2025

[0000950170-25-078936:8k_2_02:5]
Fourth quarter net revenues of $1.73 billion, an increase of 4% year-over-year;

[0000950170-25-078936:8k_2_02:6]
Fiscal year 2025 net revenues of $6.57 billion, an increase of 5% year-over-year

[0000950170-25-078936:8k_2_02:7]
•
Record all-flash array annualized net revenue run rate1 of $4.1 billion, an increase of 14% year-over-year

[0000950170-25-078936:8k_2_02:8]
•
Record first-party and marketplace Public Cloud services revenue of $416 million in fiscal year 2025, an increase of 43% year-over-year

[0000950170-25-078936:8k_2_02:9]
•
Record billings2 of $6.78 billion for fiscal year 2025, an increase of 8% year-over-year

[0000950170-25-078936:8k_2_02:10]
•
Record GAAP gross profit of $1.19 billion for the fourth quarter; record non-GAAP gross profit2 of $1.20 billion

[0000950170-25-078936:8k_2_02:11]
•
Record GAAP gross profit of $4.61 billion for fiscal year 2025; record non-GAAP gross profit of $4.67 billion

[0000950170-25-078936:8k_2_02:12]
•
GAAP operating profit of $348 million for the fourth quarter; record non-GAAP operating profit2 of $496 million

[0000950170-25-078936:8k_2_02:13]
•
Record GAAP operating profit of $1.34 billion for fiscal year 2025; record non-GAAP operating profit of $1.86 billion

[0000950170-25-078936:8k_2_02:14]
•
Record GAAP operating margins of 20% for fiscal year 2025; record non-GAAP operating margins2 of 28%

[0000950170-25-078936:8k_2_02:15]
•
Returned $1.57 billion to stockholders through share repurchases and cash dividends in fiscal year 2025

[0000950170-25-078936:8k_2_02:16]
SAN JOSE, Calif.—May 29, 2025—NetApp (NASDAQ: NTAP), the intelligent data infrastructure company, today reported financial results for the fourth quarter and fiscal year 2025, which ended on April 25, 2025.

[0000950170-25-078936:8k_2_02:17]
“Fiscal Year 2025 marked many revenue and profitability records, driven by significant market share gains in all-flash storage and accelerating growth in our first party and marketplace storage services. During the year, we refreshed our entire systems portfolio, sharpened the focus of our cloud services, and positioned ourselves to lead in the enterprise AI market,” said George Kurian, Chief Executive Officer. “We are starting fiscal year 2026 following a year of market share gains, armed with the strongest portfolio in the company’s history and a differentiated value proposition that addresses customers’ top priorities. Looking ahead, I am confident our continued innovation and market expansion will drive sustainable long-term growth.”

[0000950170-25-078936:8k_2_02:18]
Fourth Quarter of Fiscal Year 2025 Financial Results

[0000950170-25-078936:8k_2_02:19]
•
Net revenues: $1.73 billion, compared to $1.67 billion in the fourth quarter of fiscal year 2024; a year-over-year increase of 4%.

[0000950170-25-078936:8k_2_02:20]
•
Hybrid Cloud segment revenue: $1.57 billion, compared to $1.52 billion in the fourth quarter of fiscal year 2024.

[0000950170-25-078936:8k_2_02:21]
•
Public Cloud segment revenue: $164 million, compared to $152 million in the fourth quarter of fiscal year 2024.

[0000950170-25-078936:8k_2_02:22]
•
Billings: $2.03 billion, compared to $1.81 billion in the fourth quarter of fiscal year 2024; a year-over-year increase of 12%.

[0000950170-25-078936:8k_2_02:23]
•
All-flash array ARR: $4.1 billion, compared to $3.6 billion in the fourth quarter of fiscal year 2024; a year-over-year increase of 14%.

[0000950170-25-078936:8k_2_02:24]
•
Net income: GAAP net income of $340 million, compared to $291 million in the fourth quarter of fiscal year 2024; non-GAAP net income of $397 million, compared to $382 million in the fourth quarter of fiscal year 2024.

[0000950170-25-078936:8k_2_02:25]
•
Earnings per share: GAAP net income per share3 of $1.65, compared to $1.37 in the fourth quarter of fiscal year 2024; non-GAAP net income per share2 of $1.93, compared to $1.80 in the fourth quarter of fiscal year 2024.

[0000950170-25-078936:8k_2_02:26]
•
Cash, cash equivalents and investments: $3.85 billion at the end of the fourth quarter of fiscal year 2025.

[0000950170-25-078936:8k_2_02:27]
•
Cash provided by operations: $675 million, compared to $613 million in the fourth quarter of fiscal year 2024.

[0000950170-25-078936:8k_2_02:28]
•
Share repurchases and dividends: Returned $355 million to stockholders through share repurchases and cash dividends.

[0000950170-25-078936:8k_2_02:29]
Fiscal Year 2025 Financial Highlights

[0000950170-25-078936:8k_2_02:30]
•
Net revenues: $6.57 billion, compared to $6.27 billion in fiscal year 2024; a year-over-year increase of 5%.

[0000950170-25-078936:8k_2_02:31]
•
Hybrid Cloud segment revenue: $5.91 billion, compared to $5.66 billion in fiscal year 2024.

[0000950170-25-078936:8k_2_02:32]
•
Public Cloud segment revenue: $665 million, compared to $611 million in fiscal year 2024.

[0000950170-25-078936:8k_2_02:33]
•
Billings: $6.78 billion, compared to $6.25 billion in fiscal year 2024; a year-over-year increase of 8%.

[0000950170-25-078936:8k_2_02:34]
•
Net income: GAAP net income of $1.19 billion, compared to $986 million in fiscal year 2024; non-GAAP net income of $1.52 billion, compared to $1.38 billion in fiscal year 2024.

[0000950170-25-078936:8k_2_02:35]
•
Earnings per share: GAAP net income per share of $5.67 compared to $4.63 in fiscal year 2024; non-GAAP net income per share of $7.25 compared to $6.46 in fiscal year 2024.

[0000950170-25-078936:8k_2_02:36]
•
Cash provided by operations: $1.51 billion, compared to $1.69 billion in fiscal year 2024.

[0000950170-25-078936:8k_2_02:37]
•
Share repurchases and dividends: Returned $1.57 billion to stockholders through share repurchases and cash dividends.

[0000950170-25-078936:8k_2_02:38]
First Quarter of Fiscal Year 2026 Financial Outlook

[0000950170-25-078936:8k_2_02:39]
The Company provided the following financial guidance for the first quarter of fiscal year 2026:

[0000950170-25-078936:8k_2_02:40]
| Net revenues are expected to be in the range of: | $1.455 billion - $1.605 billion |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 70% - 71% | 71% - 72% |
| Operating margins are expected to be in the range of: | 19% - 20% | 25% - 26% |
| Earnings per share is expected to be in the range of: | $1.06 - $1.16 | $1.48 - $1.58 |

[0000950170-25-078936:8k_2_02:41]
Full Fiscal Year 2026 Financial Outlook

[0000950170-25-078936:8k_2_02:42]
The Company provided the following financial guidance for the full fiscal year 2026:

[0000950170-25-078936:8k_2_02:43]
| Net revenues are expected to be in the range of: | $6.625 billion - $6.875 billion |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 70% - 71% | 71% - 72% |
| Operating margins are expected to be in the range of: | 22.8% - 23.8% | 28.8% - 29.8% |
| Earnings per share is expected to be in the range of: | $5.80 - $6.10 | $7.60 - $7.90 |

[0000950170-25-078936:8k_2_02:44]
Dividend

[0000950170-25-078936:8k_2_02:45]
The next cash dividend of $0.52 per share is to be paid on July 23, 2025, to stockholders of record as of the close of business on July 3, 2025.

[0000950170-25-078936:8k_2_02:46]
Fourth Quarter of Fiscal Year 2025 Business Highlights

[0000950170-25-078936:8k_2_02:47]
Leading Product Innovation

[0000950170-25-078936:8k_2_02:48]
•
NetApp announced updates to its enterprise storage portfolio, expanding the ASA block-optimized family with systems targeted for remote or branch offices, giving customers even more options for simple, powerful, and affordable block storage.

[0000950170-25-078936:8k_2_02:49]
•
NetApp updated the NetApp EF portfolio with 30TB or 60TB QLC drives to provide the fast, affordable, high-performance, and high-capacity options required for demanding workloads such as media and entertainment, HPC and AI, and high-performance databases.

[0000950170-25-078936:8k_2_02:50]
•
NetApp introduced the NetApp FAS50 array, striking the right balance between price and performance optimization to enable businesses to store and manage secondary workloads efficiently.

[0000950170-25-078936:8k_2_02:51]
•
NetApp released new data security capabilities, including post-quantum cryptography, enhanced ransomware protection, expanded backup and recovery support, and professional security services, to help customers strengthen their cyber resilience at the storage layer.

[0000950170-25-078936:8k_2_02:52]
•
NetApp announced the NetApp™ cyber vaulting solution, powered by SnapLock™ compliance software, delivering confidentiality, integrity, and availability of data while maintaining storage infrastructure agility and efficiency.

[0000950170-25-078936:8k_2_02:53]
•
NetApp introduced NetApp Trident™ 25.02 software with powerful new capabilities – from Fibre Channel support to advanced data protection – to simplify storage deployment and management on Kubernetes for both on-premises and cloud environments.

[0000950170-25-078936:8k_2_02:54]
•
NetApp announced an enhancement to BlueXP™ workload factory for GenAI, enabling it to derive insights from images in PDF and Word documents, supporting multimodal data analysis for deeper, more accurate AI-powered insights.

[0000950170-25-078936:8k_2_02:55]
Customer and Partner Momentum

[0000950170-25-078936:8k_2_02:56]
•
The NFL named NetApp its Official Intelligent Data Infrastructure partner as the company works with the league to develop cutting-edge, silo-free storage technology that will allow it to manage its data to drive innovation.

[0000950170-25-078936:8k_2_02:57]
•
NVIDIA validated NetApp’s high-performance enterprise storage with NetApp ONTAP™ for NVIDIA DGX SuperPOD, NVIDIA Cloud Partners, and NVIDIA-Certified Systems, powering AI training and inferencing workloads.

[0000950170-25-078936:8k_2_02:58]
•
NetApp and NVIDIA integrated the NVIDIA AI Data Platform with NetApp ONTAP to advance agentic AI, enabling businesses to power AI reasoning and inference through a unified, high-performance data pipeline optimized for hybrid cloud and unstructured data.

[0000950170-25-078936:8k_2_02:59]
•
NetApp announced the general availability of Domino Volumes for NetApp ONTAP, giving users the ability to unify, orchestrate, and govern AI and data across environments with Domino’s enterprise AI platform backed by NetApp.

[0000950170-25-078936:8k_2_02:60]
•
Microsoft announced new capabilities for Azure NetApp Files, including a Flexible service level and enhanced scale and performance features, enabling organizations to control how they manage capacity and performance demands.

[0000950170-25-078936:8k_2_02:61]
•
NetApp announced NetApp Cloud Volumes ONTAP Freemium deployment through the Microsoft Azure Marketplace, saving time and streamlining the setup of Cloud Volumes ONTAP instances.

[0000950170-25-078936:8k_2_02:62]
•
NetApp and Google Cloud announced new enhancements to Google Cloud NetApp Volumes that boost scalability, performance, and AI integration, enabling enterprises to manage petabyte-scale workloads and seamlessly connect with tools like Vertex AI for advanced data-driven innovation.

[0000950170-25-078936:8k_2_02:63]
•
NetApp introduced Autonomous Ransomware Protection for Amazon FSx for NetApp ONTAP, bringing industry-leading ransomware detection capabilities to AWS Cloud with FSx for ONTAP, enhancing data security.

[0000950170-25-078936:8k_2_02:64]
•
United Kingdom (U.K.) distributor TD SYNNEX announced that it was appointed distributor for the NetApp Keystone™ storage-as-a-service solution in the U.K. and Ireland.

[0000950170-25-078936:8k_2_02:65]
•
Australian cloud hosting provider Servers Australia announced a strategic collaboration with NetApp to support secure, high-performance, and scalable IT infrastructure.

[0000950170-25-078936:8k_2_02:66]
Corporate News and Events

[0000950170-25-078936:8k_2_02:67]
•
NetApp further honed the focus of its Public Cloud segment with the completion of the sale of the Spot by NetApp business to Flexera.

[0000950170-25-078936:8k_2_02:68]
•
NetApp released new research identifying the trade-offs between U.K. business’ sustainability goals and AI ambitions, revealing that technology companies are struggling to balance both due to data management challenges.

[0000950170-25-078936:8k_2_02:69]
Awards and Recognition

[0000950170-25-078936:8k_2_02:70]
•
NetApp received the 2025 Google Cloud Infrastructure Modernization Partner of the Year for Storage award for its achievements in the Google Cloud ecosystem, helping joint customers accelerate cloud workloads with intelligent data infrastructure and bring AI to their data with NetApp and Google Cloud.

[0000950170-25-078936:8k_2_02:71]
•
NetApp was named a Customers’ Choice in the 2025 Gartner Peer Insights Voice of the Customer for Primary Storage Platforms, with 98% of verified users saying they would recommend the company for its intelligent, secure, and scalable data infrastructure.

[0000950170-25-078936:8k_2_02:72]
•
NetApp was recognized in CRN's AI 100 Awards as one of the "25 Hottest AI Companies for Data Center and Edge," with CEO George Kurian highlighting NetApp’s success in AI-specific use cases and its ability to bridge the gap between AI systems and enterprise data.

[0000950170-25-078936:8k_2_02:73]
•
As part of CRN’s 2025 Storage 100 Awards, NetApp was named as a vendor bringing software capabilities, services, and cloud connectivity to storage technology, highlighting the company’s leadership in bringing on-premises storage to the cloud.

[0000950170-25-078936:8k_2_02:74]
•
NetApp was named one of the “Hottest Data Center Companies of 2025” as part of CRN’s Data Center 50 List, described as the only enterprise-grade storage service embedded into the world’s largest public clouds.

[0000950170-25-078936:8k_2_02:75]
•
NetApp was listed as one of the “Coolest Data Management and Integration Tool Companies” for CRN’s 2025 Big Data 100 Awards, spotlighting NetApp’s hardware and software storage offerings.

[0000950170-25-078936:8k_2_02:76]
•
GigaOm’s Sonar report named NetApp a leader in the SaaS market, making it a standout company for partners and customers to consider.

[0000950170-25-078936:8k_2_02:77]
•
NetApp was recognized as a Champion in the first-ever Canalys Global Channel Leadership Matrix, underscoring its excellence in channel management and commitment to partner success.

[0000950170-25-078936:8k_2_02:78]
•
NetApp’s Partner Sphere Partner Program was given five stars in CRN’s “2025 Partner Program Guide,” highlighting NetApp’s new Partner Services benefit.

[0000950170-25-078936:8k_2_02:79]
•
Jenni Flinders, SVP of NetApp’s Worldwide Partner Organization, was recognized as one of the 50 Most Influential Channel Leaders in CRN’s 2025 Channel Chiefs Awards, highlighting her commitment to NetApp partners and use of NetApp’s new Partner Hub portal.

[0000950170-25-078936:8k_2_02:80]
•
NetApp’s Channel Lead for the U.K. and Ireland, Sonya Mathieu, was recognized in CRN’s Channel Leaders EMEA List, highlighting her clear vision, execution, and influence on NetApp’s channel programs.

[0000950170-25-078936:8k_2_02:81]
Board and Executive Leadership Announcements

[0000950170-25-078936:8k_2_02:82]
•
NetApp appointed Frank Pelzer, Chief Operating Officer of Spotnana, to its Board of Directors. Pelzer brings deep expertise in cloud, finance, and software to support NetApp’s continued growth in intelligent data infrastructure.

[0000950170-25-078936:8k_2_02:83]
•
NetApp appointed Beth O’Callahan as Chief Administrative Officer, formalizing her prior role as Chief Legal Officer and Interim Chief Human Resources Officer. Her expanded role includes Human Resources, Workplace Experience, and Corporate Communications functions alongside Legal, Compliance, Government Relations, and Sustainability to drive greater alignment and execution across the business.

[0000950170-25-078936:8k_2_02:84]
Webcast and Conference Call Information

[0000950170-25-078936:8k_2_02:85]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today.

[0000950170-25-078936:8k_2_02:86]
###

[0000950170-25-078936:8k_2_02:87]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0000950170-25-078936:8k_2_02:88]
Footnotes

[0000950170-25-078936:8k_2_02:89]
1All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0000950170-25-078936:8k_2_02:90]
2Refer to “NetApp Usage of Non-GAAP Financial Information” below for explanations of consolidated non-GAAP gross profit, non-GAAP operating profit, non-GAAP gross margins, non-GAAP operating margins, non-GAAP net income, non-GAAP net income per share, free cash flow, and billings.

[0000950170-25-078936:8k_2_02:91]
3GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0000950170-25-078936:8k_2_02:92]
NetApp Usage of Non-GAAP Financial Information

[0000950170-25-078936:8k_2_02:93]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP gross profit, non-GAAP operating profit, historical non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share.

[0000950170-25-078936:8k_2_02:94]
In prior periods, NetApp presented the hardware and software components of our GAAP product revenues to illustrate the significance and value of the Company’s software. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures.

[0000950170-25-078936:8k_2_02:95]
Effective in fiscal year 2025, NetApp no longer presents the non-GAAP hardware and software components of our product revenues, as management no longer considers them to be key financial measures. The Company’s current strategy is expected to deliver investor value through growth in total revenues, including product revenues, while maintaining operational discipline to drive earnings leverage. While software continues to be the primary value driver of our products, NetApp is primarily focused on driving growth in total product revenues, through the sale of configured storage systems comprised of both hardware and software, with less focus on the pricing of each component.

[0000950170-25-078936:8k_2_02:96]
Additionally, the Company is considering potential opportunities to simplify pricing for certain products in the future, which may eliminate the existence of separate prices for hardware and software components and/or impact our ability to allocate between them.

[0000950170-25-078936:8k_2_02:97]
NetApp believes that the presentation of its non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp’s management uses non-GAAP measures in making operating decisions because it believes that the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0000950170-25-078936:8k_2_02:98]
NetApp believes that the presentation of non-GAAP gross profit, non-GAAP operating profit, non-GAAP gross margins, non-GAAP operating margins, non-GAAP effective tax rate, non-GAAP net income, and non-GAAP earnings per share data, provides investors with supplemental metrics that assist in understanding current results and future prospects, earnings and profitability that are complementary to GAAP metrics. Each of these non-GAAP metrics is defined as the applicable GAAP metric adjusted to exclude the items defined in A through I below, as applicable, while our non-GAAP effective tax rate and non-GAAP net income also reflect a non-GAAP tax provision, as described in item J below, instead of our GAAP tax provision. Non-GAAP net income per share is computed as non-GAAP net income divided by the diluted number of shares for the applicable period.

[0000950170-25-078936:8k_2_02:99]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0000950170-25-078936:8k_2_02:100]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0000950170-25-078936:8k_2_02:101]
Non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0000950170-25-078936:8k_2_02:102]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0000950170-25-078936:8k_2_02:103]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0000950170-25-078936:8k_2_02:104]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0000950170-25-078936:8k_2_02:105]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0000950170-25-078936:8k_2_02:106]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0000950170-25-078936:8k_2_02:107]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0000950170-25-078936:8k_2_02:108]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0000950170-25-078936:8k_2_02:109]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer and/or lose control of assets to a third party. This is inclusive of third-party advisory, legal and other costs that result directly from and are essential to a sale transaction and that would not have been incurred had the decision to sell not been made. Management believes that these

[0000950170-25-078936:8k_2_02:110]
transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0000950170-25-078936:8k_2_02:111]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0000950170-25-078936:8k_2_02:112]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such non-recurring costs do not reflect the results of its underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0000950170-25-078936:8k_2_02:113]
J. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges or benefits that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges or benefits resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0000950170-25-078936:8k_2_02:114]
Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures. A detailed reconciliation of our non-GAAP to GAAP results can be found herein.

[0000950170-25-078936:8k_2_02:115]
Constant Currency

[0000950170-25-078936:8k_2_02:116]
In periods in which the impacts of foreign currency exchange rate changes are significant, NetApp presents certain constant currency growth rates or quantifies the impact of foreign currency exchange rate changes on year-over-year fluctuations, including for net revenues, billings, and earnings. This constant currency information assumes the same foreign currency exchange rates that were in effect for the comparable prior-year period were used in translation of the current period results.

[0000950170-25-078936:8k_2_02:117]
About NetApp

[0000950170-25-078936:8k_2_02:118]
NetApp is the intelligent data infrastructure company, combining unified data storage, integrated data, operational and workload services to turn a world of disruption into opportunity for every customer. NetApp creates silo-free infrastructure, harnessing observability and AI to enable the industry’s best data management. As the only enterprise-grade storage service natively embedded in the world’s biggest clouds, our data storage delivers seamless flexibility. In addition, our data services create a data advantage through superior cyber resilience, governance, and application agility. Our operational and workload services provide continuous optimization of performance and efficiency for infrastructure and workloads through observability and AI. No matter the data type, workload, or environment, with NetApp you can transform your data infrastructure to realize your business possibilities. Learn more at www.netapp.com or follow us on X, LinkedIn, Facebook, and Instagram.

[0000950170-25-078936:8k_2_02:119]
NETAPP, INC.

[0000950170-25-078936:8k_2_02:120]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-25-078936:8k_2_02:121]
(In millions)

[0000950170-25-078936:8k_2_02:122]
(Unaudited)

[0000950170-25-078936:8k_2_02:123]
|  |  | April 25, 2025 |  |  | April 26,2024 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,846 |  |  | $ | 3,252 |  |
| Accounts receivable |  |  | 1,246 |  |  |  | 1,007 |  |
| Inventories |  |  | 186 |  |  |  | 186 |  |
| Other current assets |  |  | 573 |  |  |  | 452 |  |
| Total current assets |  |  | 5,851 |  |  |  | 4,897 |  |
| Property and equipment, net |  |  | 563 |  |  |  | 604 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,766 |  |  |  | 2,883 |  |
| Other non-current assets |  |  | 1,643 |  |  |  | 1,503 |  |
| Total assets |  | $ | 10,823 |  |  | $ | 9,887 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 511 |  |  | $ | 517 |  |
| Accrued expenses |  |  | 1,122 |  |  |  | 1,013 |  |
| Current portion of long-term debt |  |  | 750 |  |  |  | 400 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 2,279 |  |  |  | 2,176 |  |
| Total current liabilities |  |  | 4,662 |  |  |  | 4,106 |  |
| Long-term debt |  |  | 2,485 |  |  |  | 1,992 |  |
| Other long-term liabilities |  |  | 379 |  |  |  | 585 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 2,257 |  |  |  | 2,058 |  |
| Total liabilities |  |  | 9,783 |  |  |  | 8,741 |  |
| Stockholders' equity |  |  | 1,040 |  |  |  | 1,146 |  |
| Total liabilities and stockholders' equity |  | $ | 10,823 |  |  | $ | 9,887 |  |

[0000950170-25-078936:8k_2_02:124]
NETAPP, INC.

[0000950170-25-078936:8k_2_02:125]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-25-078936:8k_2_02:126]
(In millions, except per share amounts)

[0000950170-25-078936:8k_2_02:127]
(Unaudited)

[0000950170-25-078936:8k_2_02:128]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 845 |  |  | $ | 806 |  |  | $ | 3,040 |  |  | $ | 2,849 |  |
| Services |  |  | 887 |  |  |  | 862 |  |  |  | 3,532 |  |  |  | 3,419 |  |
| Net revenues |  |  | 1,732 |  |  |  | 1,668 |  |  |  | 6,572 |  |  |  | 6,268 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 378 |  |  |  | 314 |  |  |  | 1,284 |  |  |  | 1,137 |  |
| Cost of services |  |  | 161 |  |  |  | 178 |  |  |  | 675 |  |  |  | 698 |  |
| Total cost of revenues |  |  | 539 |  |  |  | 492 |  |  |  | 1,959 |  |  |  | 1,835 |  |
| Gross profit |  |  | 1,193 |  |  |  | 1,176 |  |  |  | 4,613 |  |  |  | 4,433 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 458 |  |  |  | 460 |  |  |  | 1,865 |  |  |  | 1,828 |  |
| Research and development |  |  | 256 |  |  |  | 271 |  |  |  | 1,012 |  |  |  | 1,029 |  |
| General and administrative |  |  | 85 |  |  |  | 78 |  |  |  | 311 |  |  |  | 308 |  |
| Restructuring charges |  |  | 45 |  |  |  | — |  |  |  | 83 |  |  |  | 44 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 1 |  |  |  | 5 |  |  |  | 10 |  |
| Total operating expenses |  |  | 845 |  |  |  | 810 |  |  |  | 3,276 |  |  |  | 3,219 |  |
| Income from operations |  |  | 348 |  |  |  | 366 |  |  |  | 1,337 |  |  |  | 1,214 |  |
| Other income, net |  |  | 6 |  |  |  | 14 |  |  |  | 46 |  |  |  | 49 |  |
| Income before income taxes |  |  | 354 |  |  |  | 380 |  |  |  | 1,383 |  |  |  | 1,263 |  |
| Provision for income taxes |  |  | 14 |  |  |  | 89 |  |  |  | 197 |  |  |  | 277 |  |
| Net income |  | $ | 340 |  |  | $ | 291 |  |  | $ | 1,186 |  |  | $ | 986 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.67 |  |  | $ | 1.41 |  |  | $ | 5.81 |  |  | $ | 4.74 |  |
| Diluted |  | $ | 1.65 |  |  | $ | 1.37 |  |  | $ | 5.67 |  |  | $ | 4.63 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 203 |  |  |  | 206 |  |  |  | 204 |  |  |  | 208 |  |
| Diluted |  |  | 206 |  |  |  | 212 |  |  |  | 209 |  |  |  | 213 |  |

[0000950170-25-078936:8k_2_02:129]
NETAPP, INC.

[0000950170-25-078936:8k_2_02:130]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-25-078936:8k_2_02:131]
(In millions)

[0000950170-25-078936:8k_2_02:132]
(Unaudited)

[0000950170-25-078936:8k_2_02:133]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 340 |  |  | $ | 291 |  |  | $ | 1,186 |  |  | $ | 986 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 53 |  |  |  | 64 |  |  |  | 243 |  |  |  | 255 |  |
| Non-cash operating lease cost |  |  | 10 |  |  |  | 11 |  |  |  | 41 |  |  |  | 45 |  |
| Stock-based compensation |  |  | 95 |  |  |  | 88 |  |  |  | 386 |  |  |  | 357 |  |
| Deferred income taxes |  |  | 10 |  |  |  | 55 |  |  |  | (100 | ) |  |  | 53 |  |
| Other items, net |  |  | 25 |  |  |  | (17 | ) |  |  | - |  |  |  | (13 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (323 | ) |  |  | (228 | ) |  |  | (219 | ) |  |  | (33 | ) |
| Inventories |  |  | 81 |  |  |  | (55 | ) |  |  | (1 | ) |  |  | (18 | ) |
| Accounts payable |  |  | 69 |  |  |  | 120 |  |  |  | (8 | ) |  |  | 123 |  |
| Accrued expenses |  |  | 156 |  |  |  | 129 |  |  |  | 62 |  |  |  | 113 |  |
| Deferred revenue and financed unearned services revenue |  |  | 300 |  |  |  | 146 |  |  |  | 208 |  |  |  | (14 | ) |
| Long-term taxes payable |  |  | (123 | ) |  |  | 1 |  |  |  | (207 | ) |  |  | (106 | ) |
| Changes in other operating assets and liabilities, net |  |  | (18 | ) |  |  | 8 |  |  |  | (85 | ) |  |  | (63 | ) |
| Net cash provided by operating activities |  |  | 675 |  |  |  | 613 |  |  |  | 1,506 |  |  |  | 1,685 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| (Purchases) redemptions of investments, net |  |  | (345 | ) |  |  | (251 | ) |  |  | 245 |  |  |  | (580 | ) |
| Purchases of property and equipment |  |  | (35 | ) |  |  | (46 | ) |  |  | (168 | ) |  |  | (155 | ) |
| Other investing activities, net |  |  | 67 |  |  |  | — |  |  |  | 70 |  |  |  | — |  |
| Net cash (used in) provided by investing activities |  |  | (313 | ) |  |  | (297 | ) |  |  | 147 |  |  |  | (735 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | — |  |  |  | — |  |  |  | 108 |  |  |  | 100 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (31 | ) |  |  | (19 | ) |  |  | (199 | ) |  |  | (127 | ) |
| Repurchase of common stock |  |  | (250 | ) |  |  | (100 | ) |  |  | (1,150 | ) |  |  | (900 | ) |
| Issuances of debt, net of issuance costs |  |  | 1,240 |  |  |  | — |  |  |  | 1,240 |  |  |  | — |  |
| Repayments and extinguishment of debt |  |  | — |  |  |  | — |  |  |  | (400 | ) |  |  | — |  |
| Dividends paid |  |  | (105 | ) |  |  | (104 | ) |  |  | (424 | ) |  |  | (416 | ) |
| Other financing activities, net |  |  | (3 | ) |  |  | (1 | ) |  |  | (3 | ) |  |  | (1 | ) |
| Net cash provided by (used in) financing activities |  |  | 851 |  |  |  | (224 | ) |  |  | (828 | ) |  |  | (1,344 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 18 |  |  |  | (9 | ) |  |  | 15 |  |  |  | (19 | ) |
| Net change in cash, cash equivalents and restricted cash |  |  | 1,231 |  |  |  | 83 |  |  |  | 840 |  |  |  | (413 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 1,518 |  |  |  | 1,826 |  |  |  | 1,909 |  |  |  | 2,322 |  |
| End of period |  | $ | 2,749 |  |  | $ | 1,909 |  |  | $ | 2,749 |  |  | $ | 1,909 |  |

[0000950170-25-078936:8k_2_02:134]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| Product |  | $ | 845 |  |  | $ | 758 |  |  | $ | 806 |  |  | $ | 3,040 |  |  | $ | 2,849 |  |
| Support |  |  | 625 |  |  |  | 621 |  |  |  | 623 |  |  |  | 2,512 |  |  |  | 2,488 |  |
| Professional and Other Services |  |  | 98 |  |  |  | 88 |  |  |  | 87 |  |  |  | 355 |  |  |  | 320 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,568 |  |  |  | 1,467 |  |  |  | 1,516 |  |  |  | 5,907 |  |  |  | 5,657 |  |
| Public Cloud Segment Net Revenues |  |  | 164 |  |  |  | 174 |  |  |  | 152 |  |  |  | 665 |  |  |  | 611 |  |
| Net Revenues |  | $ | 1,732 |  |  | $ | 1,641 |  |  | $ | 1,668 |  |  | $ | 6,572 |  |  | $ | 6,268 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| Product |  | $ | 468 |  |  | $ | 430 |  |  | $ | 494 |  |  | $ | 1,762 |  |  | $ | 1,718 |  |
| Support |  |  | 577 |  |  |  | 573 |  |  |  | 574 |  |  |  | 2,315 |  |  |  | 2,293 |  |
| Professional and Other Services |  |  | 28 |  |  |  | 25 |  |  |  | 20 |  |  |  | 94 |  |  |  | 77 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 1,073 |  |  |  | 1,028 |  |  |  | 1,088 |  |  |  | 4,171 |  |  |  | 4,088 |  |
| Public Cloud Segment Gross Profit |  |  | 130 |  |  |  | 133 |  |  |  | 104 |  |  |  | 500 |  |  |  | 408 |  |
| Total Segments Gross Profit |  |  | 1,203 |  |  |  | 1,161 |  |  |  | 1,192 |  |  |  | 4,671 |  |  |  | 4,496 |  |
| Amortization of Intangible Assets |  |  | (3 | ) |  |  | (8 | ) |  |  | (8 | ) |  |  | (28 | ) |  |  | (34 | ) |
| Stock-based Compensation |  |  | (7 | ) |  |  | (8 | ) |  |  | (8 | ) |  |  | (30 | ) |  |  | (29 | ) |
| Unallocated Cost of Revenues |  |  | (10 | ) |  |  | (16 | ) |  |  | (16 | ) |  |  | (58 | ) |  |  | (63 | ) |
| Gross Profit |  | $ | 1,193 |  |  | $ | 1,145 |  |  | $ | 1,176 |  |  | $ | 4,613 |  |  | $ | 4,433 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| Product |  |  | 55.4 | % |  |  | 56.7 | % |  |  | 61.3 | % |  |  | 58.0 | % |  |  | 60.3 | % |
| Support |  |  | 92.3 | % |  |  | 92.3 | % |  |  | 92.1 | % |  |  | 92.2 | % |  |  | 92.2 | % |
| Professional and Other Services |  |  | 28.6 | % |  |  | 28.4 | % |  |  | 23.0 | % |  |  | 26.5 | % |  |  | 24.1 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 68.4 | % |  |  | 70.1 | % |  |  | 71.8 | % |  |  | 70.6 | % |  |  | 72.3 | % |
| Public Cloud Segment Gross Margin |  |  | 79.3 | % |  |  | 76.4 | % |  |  | 68.4 | % |  |  | 75.2 | % |  |  | 66.8 | % |

[0000950170-25-078936:8k_2_02:135]
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'25 |  |  | % of Q3 FY'25 |  |  | % of Q4 FY'24 |  |  | % of FY 2025 |  |  | % of FY 2024 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 51 | % |  |  | 51 | % |  |  | 51 | % |  |  | 51 | % |  |  | 51 | % |
| Americas Commercial |  |  | 42 | % |  |  | 41 | % |  |  | 41 | % |  |  | 40 | % |  |  | 40 | % |
| U.S. Public Sector |  |  | 9 | % |  |  | 10 | % |  |  | 10 | % |  |  | 11 | % |  |  | 11 | % |
| EMEA |  |  | 34 | % |  |  | 34 | % |  |  | 34 | % |  |  | 34 | % |  |  | 34 | % |
| Asia Pacific |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |

[0000950170-25-078936:8k_2_02:136]
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'25 |  |  | % of Q3 FY'25 |  |  | % of Q4 FY'24 |  |  | % of FY 2025 |  |  | % of FY 2024 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 22 | % |  |  | 21 | % |  |  | 24 | % |  |  | 22 | % |  |  | 24 | % |
| Indirect |  |  | 78 | % |  |  | 79 | % |  |  | 76 | % |  |  | 78 | % |  |  | 76 | % |

[0000950170-25-078936:8k_2_02:137]
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| Non-GAAP Income from Operations |  | $ | 496 |  |  | $ | 492 |  |  | $ | 469 |  |  | $ | 1,862 |  |  | $ | 1,682 |  |
| % of Net Revenues |  |  | 28.6 | % |  |  | 30.0 | % |  |  | 28.1 | % |  |  | 28.3 | % |  |  | 26.8 | % |
| Non-GAAP Income before Income Taxes |  | $ | 492 |  |  | $ | 500 |  |  | $ | 483 |  |  | $ | 1,901 |  |  | $ | 1,726 |  |
| Non-GAAP Effective Tax Rate |  |  | 19.3 | % |  |  | 20.6 | % |  |  | 20.9 | % |  |  | 20.2 | % |  |  | 20.3 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| Non-GAAP Net Income |  | $ | 397 |  |  | $ | 397 |  |  | $ | 382 |  |  | $ | 1,516 |  |  | $ | 1,375 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 206 |  |  |  | 208 |  |  |  | 212 |  |  |  | 209 |  |  |  | 213 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.93 |  |  | $ | 1.91 |  |  | $ | 1.80 |  |  | $ | 7.25 |  |  | $ | 6.46 |  |

[0000950170-25-078936:8k_2_02:138]
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  |  |  |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 4,536 |  |  | $ | 4,122 |  |  | $ | 4,234 |  |  |  |  |  |
| DSO (days) |  |  | 65 |  |  |  | 50 |  |  |  | 55 |  |  |  |  |  |
| DPO (days) |  |  | 86 |  |  |  | 80 |  |  |  | 96 |  |  |  |  |  |
| Inventory Turns |  |  | 12 |  |  |  | 7 |  |  |  | 11 |  |  |  |  |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |

[0000950170-25-078936:8k_2_02:139]
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| Net Cash Provided by Operating Activities |  | $ | 675 |  |  | $ | 385 |  |  | $ | 613 |  |  | $ | 1,506 |  |  | $ | 1,685 |  |
| Purchases of Property and Equipment |  | $ | 35 |  |  | $ | 47 |  |  | $ | 46 |  |  | $ | 168 |  |  | $ | 155 |  |
| Free Cash Flow |  | $ | 640 |  |  | $ | 338 |  |  | $ | 567 |  |  | $ | 1,338 |  |  | $ | 1,530 |  |
| Free Cash Flow as % of Net Revenues |  |  | 37.0 | % |  |  | 20.6 | % |  |  | 34.0 | % |  |  | 20.4 | % |  |  | 24.4 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0000950170-25-078936:8k_2_02:140]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| NET INCOME |  | $ | 340 |  |  | $ | 299 |  |  | $ | 291 |  |  | $ | 1,186 |  |  | $ | 986 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 6 |  |  |  | 13 |  |  |  | 14 |  |  |  | 47 |  |  |  | 57 |  |
| Stock-based compensation |  |  | 95 |  |  |  | 103 |  |  |  | 88 |  |  |  | 386 |  |  |  | 357 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (5 | ) |
| Restructuring charges |  |  | 45 |  |  |  | 9 |  |  |  | — |  |  |  | 83 |  |  |  | 44 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |  |  | 5 |  |  |  | 10 |  |
| Gains/losses on the sale or derecognition of assets |  |  | 1 |  |  |  | 3 |  |  |  | — |  |  |  | 7 |  |  |  | — |  |
| Gain on sale of equity investment |  |  | (10 | ) |  |  | — |  |  |  | — |  |  |  | (10 | ) |  |  | — |  |
| Income tax effects |  |  | (42 | ) |  |  | (32 | ) |  |  | (12 | ) |  |  | (149 | ) |  |  | (74 | ) |
| Resolution of income tax matters |  |  | (39 | ) |  |  | — |  |  |  | — |  |  |  | (39 | ) |  |  | — |  |
| NON-GAAP NET INCOME |  | $ | 397 |  |  | $ | 397 |  |  | $ | 382 |  |  | $ | 1,516 |  |  | $ | 1,375 |  |
| COST OF REVENUES |  | $ | 539 |  |  | $ | 496 |  |  | $ | 492 |  |  | $ | 1,959 |  |  | $ | 1,835 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (8 | ) |  |  | (8 | ) |  |  | (28 | ) |  |  | (34 | ) |
| Stock-based compensation |  |  | (7 | ) |  |  | (8 | ) |  |  | (8 | ) |  |  | (30 | ) |  |  | (29 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 529 |  |  | $ | 480 |  |  | $ | 476 |  |  | $ | 1,901 |  |  | $ | 1,772 |  |
| COST OF PRODUCT REVENUES |  | $ | 378 |  |  | $ | 330 |  |  | $ | 314 |  |  | $ | 1,284 |  |  | $ | 1,137 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (1 | ) |  |  | (2 | ) |  |  | (2 | ) |  |  | (6 | ) |  |  | (6 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 377 |  |  | $ | 328 |  |  | $ | 312 |  |  | $ | 1,278 |  |  | $ | 1,131 |  |
| COST OF SERVICES REVENUES |  | $ | 161 |  |  | $ | 166 |  |  | $ | 178 |  |  | $ | 675 |  |  | $ | 698 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (8 | ) |  |  | (8 | ) |  |  | (28 | ) |  |  | (34 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (6 | ) |  |  | (6 | ) |  |  | (24 | ) |  |  | (23 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 152 |  |  | $ | 152 |  |  | $ | 164 |  |  | $ | 623 |  |  | $ | 641 |  |
| GROSS PROFIT |  | $ | 1,193 |  |  | $ | 1,145 |  |  | $ | 1,176 |  |  | $ | 4,613 |  |  | $ | 4,433 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 3 |  |  |  | 8 |  |  |  | 8 |  |  |  | 28 |  |  |  | 34 |  |
| Stock-based compensation |  |  | 7 |  |  |  | 8 |  |  |  | 8 |  |  |  | 30 |  |  |  | 29 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,203 |  |  | $ | 1,161 |  |  | $ | 1,192 |  |  | $ | 4,671 |  |  | $ | 4,496 |  |

[0000950170-25-078936:8k_2_02:141]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| SALES AND MARKETING EXPENSES |  | $ | 458 |  |  | $ | 451 |  |  | $ | 460 |  |  | $ | 1,865 |  |  | $ | 1,828 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (5 | ) |  |  | (6 | ) |  |  | (19 | ) |  |  | (23 | ) |
| Stock-based compensation |  |  | (40 | ) |  |  | (44 | ) |  |  | (34 | ) |  |  | (162 | ) |  |  | (143 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 415 |  |  | $ | 402 |  |  | $ | 420 |  |  | $ | 1,684 |  |  | $ | 1,662 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 256 |  |  | $ | 247 |  |  | $ | 271 |  |  | $ | 1,012 |  |  | $ | 1,029 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (31 | ) |  |  | (36 | ) |  |  | (33 | ) |  |  | (135 | ) |  |  | (132 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 225 |  |  | $ | 211 |  |  | $ | 238 |  |  | $ | 877 |  |  | $ | 897 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 85 |  |  | $ | 74 |  |  | $ | 78 |  |  | $ | 311 |  |  | $ | 308 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (17 | ) |  |  | (15 | ) |  |  | (13 | ) |  |  | (59 | ) |  |  | (53 | ) |
| Gains/losses on the sale or derecognition of assets |  |  | (1 | ) |  |  | (3 | ) |  |  | — |  |  |  | (4 | ) |  |  | — |  |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 67 |  |  | $ | 56 |  |  | $ | 65 |  |  | $ | 248 |  |  | $ | 255 |  |
| RESTRUCTURING CHARGES |  | $ | 45 |  |  | $ | 9 |  |  | $ | — |  |  | $ | 83 |  |  | $ | 44 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (45 | ) |  |  | (9 | ) |  |  | — |  |  |  | (83 | ) |  |  | (44 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 1 |  |  | $ | 2 |  |  | $ | 1 |  |  | $ | 5 |  |  | $ | 10 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (1 | ) |  |  | (2 | ) |  |  | (1 | ) |  |  | (5 | ) |  |  | (10 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 845 |  |  | $ | 783 |  |  | $ | 810 |  |  | $ | 3,276 |  |  | $ | 3,219 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (5 | ) |  |  | (6 | ) |  |  | (19 | ) |  |  | (23 | ) |
| Stock-based compensation |  |  | (88 | ) |  |  | (95 | ) |  |  | (80 | ) |  |  | (356 | ) |  |  | (328 | ) |
| Restructuring charges |  |  | (45 | ) |  |  | (9 | ) |  |  | — |  |  |  | (83 | ) |  |  | (44 | ) |
| Acquisition-related expense |  |  | (1 | ) |  |  | (2 | ) |  |  | (1 | ) |  |  | (5 | ) |  |  | (10 | ) |
| Gains/losses on the sale or derecognition of assets |  |  | (1 | ) |  |  | (3 | ) |  |  | — |  |  |  | (4 | ) |  |  | — |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 707 |  |  | $ | 669 |  |  | $ | 723 |  |  | $ | 2,809 |  |  | $ | 2,814 |  |

[0000950170-25-078936:8k_2_02:142]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| INCOME FROM OPERATIONS |  | $ | 348 |  |  | $ | 362 |  |  | $ | 366 |  |  | $ | 1,337 |  |  | $ | 1,214 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 6 |  |  |  | 13 |  |  |  | 14 |  |  |  | 47 |  |  |  | 57 |  |
| Stock-based compensation |  |  | 95 |  |  |  | 103 |  |  |  | 88 |  |  |  | 386 |  |  |  | 357 |  |
| Restructuring charges |  |  | 45 |  |  |  | 9 |  |  |  | — |  |  |  | 83 |  |  |  | 44 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |  |  | 5 |  |  |  | 10 |  |
| Gains/losses on the sale or derecognition of assets |  |  | 1 |  |  |  | 3 |  |  |  | — |  |  |  | 4 |  |  |  | — |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 496 |  |  | $ | 492 |  |  | $ | 469 |  |  | $ | 1,862 |  |  | $ | 1,682 |  |
| OTHER INCOME, NET |  | $ | 6 |  |  | $ | 8 |  |  | $ | 14 |  |  | $ | 46 |  |  | $ | 49 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (5 | ) |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |
| Gain on sale of equity investment |  |  | (10 | ) |  |  | — |  |  |  | — |  |  |  | (10 | ) |  |  | — |  |
| NON-GAAP OTHER INCOME (EXPENSE), NET |  | $ | (4 | ) |  | $ | 8 |  |  | $ | 14 |  |  | $ | 39 |  |  | $ | 44 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 354 |  |  | $ | 370 |  |  | $ | 380 |  |  | $ | 1,383 |  |  | $ | 1,263 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 6 |  |  |  | 13 |  |  |  | 14 |  |  |  | 47 |  |  |  | 57 |  |
| Stock-based compensation |  |  | 95 |  |  |  | 103 |  |  |  | 88 |  |  |  | 386 |  |  |  | 357 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (5 | ) |
| Restructuring charges |  |  | 45 |  |  |  | 9 |  |  |  | — |  |  |  | 83 |  |  |  | 44 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |  |  | 5 |  |  |  | 10 |  |
| Gains/losses on the sale or derecognition of assets |  |  | 1 |  |  |  | 3 |  |  |  | — |  |  |  | 7 |  |  |  | — |  |
| Gain on sale of equity investment |  |  | (10 | ) |  |  | — |  |  |  | — |  |  |  | (10 | ) |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 492 |  |  | $ | 500 |  |  | $ | 483 |  |  | $ | 1,901 |  |  | $ | 1,726 |  |
| PROVISION FOR INCOME TAXES |  | $ | 14 |  |  | $ | 71 |  |  | $ | 89 |  |  | $ | 197 |  |  | $ | 277 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 42 |  |  |  | 32 |  |  |  | 12 |  |  |  | 149 |  |  |  | 74 |  |
| Resolution of income tax matters |  |  | 39 |  |  |  | — |  |  |  | — |  |  |  | 39 |  |  |  | — |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 95 |  |  | $ | 103 |  |  | $ | 101 |  |  | $ | 385 |  |  | $ | 351 |  |
| NET INCOME PER SHARE |  | $ | 1.65 |  |  | $ | 1.44 |  |  | $ | 1.37 |  |  | $ | 5.67 |  |  | $ | 4.63 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.03 |  |  |  | 0.06 |  |  |  | 0.07 |  |  |  | 0.22 |  |  |  | 0.27 |  |
| Stock-based compensation |  |  | 0.46 |  |  |  | 0.50 |  |  |  | 0.42 |  |  |  | 1.85 |  |  |  | 1.68 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.02 | ) |
| Restructuring charges |  |  | 0.22 |  |  |  | 0.04 |  |  |  | — |  |  |  | 0.40 |  |  |  | 0.21 |  |
| Acquisition-related expense |  |  | 0.01 |  |  |  | 0.01 |  |  |  | — |  |  |  | 0.03 |  |  |  | 0.05 |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  | 0.01 |  |  |  | — |  |  |  | 0.03 |  |  |  | — |  |
| Gain on sale of equity investment |  |  | (0.05 | ) |  |  | — |  |  |  | — |  |  |  | (0.05 | ) |  |  | — |  |
| Income tax effects |  |  | (0.20 | ) |  |  | (0.15 | ) |  |  | (0.06 | ) |  |  | (0.71 | ) |  |  | (0.35 | ) |
| Resolution of income tax matters |  |  | (0.19 | ) |  |  | — |  |  |  | — |  |  |  | (0.19 | ) |  |  | — |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.93 |  |  | $ | 1.91 |  |  | $ | 1.80 |  |  | $ | 7.25 |  |  | $ | 6.46 |  |

[0000950170-25-078936:8k_2_02:143]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| Gross margin-GAAP |  |  | 68.9 | % |  |  | 69.8 | % |  |  | 70.5 | % |  |  | 70.2 | % |  |  | 70.7 | % |
| Cost of revenues adjustments |  |  | 0.6 | % |  |  | 0.9 | % |  |  | 1.0 | % |  |  | 0.9 | % |  |  | 1.0 | % |
| Gross margin-Non-GAAP |  |  | 69.5 | % |  |  | 70.7 | % |  |  | 71.5 | % |  |  | 71.1 | % |  |  | 71.7 | % |
| GAAP cost of revenues |  | $ | 539 |  |  | $ | 496 |  |  | $ | 492 |  |  | $ | 1,959 |  |  | $ | 1,835 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (8 | ) |  |  | (8 | ) |  |  | (28 | ) |  |  | (34 | ) |
| Stock-based compensation |  |  | (7 | ) |  |  | (8 | ) |  |  | (8 | ) |  |  | (30 | ) |  |  | (29 | ) |
| Non-GAAP cost of revenues |  | $ | 529 |  |  | $ | 480 |  |  | $ | 476 |  |  | $ | 1,901 |  |  | $ | 1,772 |  |
| Net revenues |  | $ | 1,732 |  |  | $ | 1,641 |  |  | $ | 1,668 |  |  | $ | 6,572 |  |  | $ | 6,268 |  |

[0000950170-25-078936:8k_2_02:144]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| Product gross margin-GAAP |  |  | 55.3 | % |  |  | 56.5 | % |  |  | 61.0 | % |  |  | 57.8 | % |  |  | 60.1 | % |
| Cost of product revenues adjustments |  |  | 0.1 | % |  |  | 0.2 | % |  |  | 0.3 | % |  |  | 0.2 | % |  |  | 0.3 | % |
| Product gross margin-Non-GAAP |  |  | 55.4 | % |  |  | 56.7 | % |  |  | 61.3 | % |  |  | 58.0 | % |  |  | 60.3 | % |
| GAAP cost of product revenues |  | $ | 378 |  |  | $ | 330 |  |  | $ | 314 |  |  | $ | 1,284 |  |  | $ | 1,137 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (1 | ) |  |  | (2 | ) |  |  | (2 | ) |  |  | (6 | ) |  |  | (6 | ) |
| Non-GAAP cost of product revenues |  | $ | 377 |  |  | $ | 328 |  |  | $ | 312 |  |  | $ | 1,278 |  |  | $ | 1,131 |  |
| Product revenues |  | $ | 845 |  |  | $ | 758 |  |  | $ | 806 |  |  | $ | 3,040 |  |  | $ | 2,849 |  |

[0000950170-25-078936:8k_2_02:145]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| Services gross margin-GAAP |  |  | 81.8 | % |  |  | 81.2 | % |  |  | 79.4 | % |  |  | 80.9 | % |  |  | 79.6 | % |
| Cost of services revenues adjustments |  |  | 1.1 | % |  |  | 1.6 | % |  |  | 1.6 | % |  |  | 1.5 | % |  |  | 1.7 | % |
| Services gross margin-Non-GAAP |  |  | 82.9 | % |  |  | 82.8 | % |  |  | 81.0 | % |  |  | 82.4 | % |  |  | 81.3 | % |
| GAAP cost of services revenues |  | $ | 161 |  |  | $ | 166 |  |  | $ | 178 |  |  | $ | 675 |  |  | $ | 698 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (8 | ) |  |  | (8 | ) |  |  | (28 | ) |  |  | (34 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (6 | ) |  |  | (6 | ) |  |  | (24 | ) |  |  | (23 | ) |
| Non-GAAP cost of services revenues |  | $ | 152 |  |  | $ | 152 |  |  | $ | 164 |  |  | $ | 623 |  |  | $ | 641 |  |
| Services revenues |  | $ | 887 |  |  | $ | 883 |  |  | $ | 862 |  |  | $ | 3,532 |  |  | $ | 3,419 |  |

[0000950170-25-078936:8k_2_02:146]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| OPERATING MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| Operating margin-GAAP |  |  | 20.1 | % |  |  | 22.1 | % |  |  | 21.9 | % |  |  | 20.3 | % |  |  | 19.4 | % |
| Adjustments: |  |  | 8.5 | % |  |  | 7.9 | % |  |  | 6.2 | % |  |  | 8.0 | % |  |  | 7.5 | % |
| Operating margin-Non-GAAP |  |  | 28.6 | % |  |  | 30.0 | % |  |  | 28.1 | % |  |  | 28.3 | % |  |  | 26.8 | % |
| GAAP income from operations |  | $ | 348 |  |  | $ | 362 |  |  | $ | 366 |  |  | $ | 1,337 |  |  | $ | 1,214 |  |
| Income from operations adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 6 |  |  |  | 13 |  |  |  | 14 |  |  |  | 47 |  |  |  | 57 |  |
| Stock-based compensation |  |  | 95 |  |  |  | 103 |  |  |  | 88 |  |  |  | 386 |  |  |  | 357 |  |
| Restructuring charges |  |  | 45 |  |  |  | 9 |  |  |  | — |  |  |  | 83 |  |  |  | 44 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |  |  | 5 |  |  |  | 10 |  |
| Gains/losses on the sale or derecognition of assets |  |  | 1 |  |  |  | 3 |  |  |  | — |  |  |  | 4 |  |  |  | — |  |
| Non-GAAP income from operations |  | $ | 496 |  |  | $ | 492 |  |  | $ | 469 |  |  | $ | 1,862 |  |  | $ | 1,682 |  |
| Net revenues |  | $ | 1,732 |  |  | $ | 1,641 |  |  | $ | 1,668 |  |  | $ | 6,572 |  |  | $ | 6,268 |  |

[0000950170-25-078936:8k_2_02:147]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| GAAP effective tax rate |  |  | 4.0 | % |  |  | 19.2 | % |  |  | 23.4 | % |  |  | 14.2 | % |  |  | 21.9 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 4.3 | % |  |  | 1.4 | % |  |  | (2.5 | )% |  |  | 3.2 | % |  |  | (1.6 | )% |
| Resolution of income tax matters |  |  | 11.0 | % |  |  | — | % |  |  | — | % |  |  | 2.8 | % |  |  | — | % |
| Non-GAAP effective tax rate |  |  | 19.3 | % |  |  | 20.6 | % |  |  | 20.9 | % |  |  | 20.2 | % |  |  | 20.3 | % |

[0000950170-25-078936:8k_2_02:148]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| Net cash provided by operating activities |  | $ | 675 |  |  | $ | 385 |  |  | $ | 613 |  |  | $ | 1,506 |  |  | $ | 1,685 |  |
| Purchases of property and equipment |  |  | (35 | ) |  |  | (47 | ) |  |  | (46 | ) |  |  | (168 | ) |  |  | (155 | ) |
| Free cash flow |  | $ | 640 |  |  | $ | 338 |  |  | $ | 567 |  |  | $ | 1,338 |  |  | $ | 1,530 |  |

[0000950170-25-078936:8k_2_02:149]
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q4'FY25 |  |  | Q3'FY25 |  |  | Q4'FY24 |  |  | FY2025 |  |  | FY2024 |  |
| Net revenues |  | $ | 1,732 |  |  | $ | 1,641 |  |  | $ | 1,668 |  |  | $ | 6,572 |  |  | $ | 6,268 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | 300 |  |  |  | 72 |  |  |  | 146 |  |  |  | 208 |  |  |  | (14 | ) |
| Billings |  | $ | 2,032 |  |  | $ | 1,713 |  |  | $ | 1,814 |  |  | $ | 6,780 |  |  | $ | 6,254 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000950170-25-078936:8k_2_02:150]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| FIRST QUARTER FISCAL 2026 |
|  |  | First Quarter |
|  |  | Fiscal 2026 |
| Gross Margin - GAAP Guidance |  | 70% - 71% |
| Adjustments: |  |  |
| Cost of revenues adjustments |  | 1% |
| Gross Margin - Non-GAAP Guidance |  | 71% - 72% |
|  |  | First Quarter |
|  |  | Fiscal 2026 |
| Operating Margin - GAAP Guidance |  | 19% - 20% |
| Adjustments: |  |  |
| Stock-based compensation expense |  | 6% |
| Operating Margin - Non-GAAP Guidance |  | 25% - 26% |

[0000950170-25-078936:8k_2_02:151]
Some items may not add or recalculate due to rounding.

[0000950170-25-078936:8k_2_02:152]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FIRST QUARTER FISCAL 2026 |
|  |  | First Quarter |
|  |  | Fiscal 2026 |
| GAAP Guidance - Net Income Per Share |  | $1.06 - $1.16 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the First Quarter Fiscal 2026: |  |  |
| Amortization of intangible assets |  | $0.03 |
| Stock-based compensation expense |  | $0.47 |
| Income tax effects |  | ($0.08) |
| Total Adjustments |  | $0.42 |
| Non-GAAP Guidance - Net Income Per Share |  | $1.48 - $1.58 |

[0000950170-25-078936:8k_2_02:153]
Some items may not add or recalculate due to rounding.

[0000950170-25-078936:8k_2_02:154]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| Fiscal 2026 |
|  |  | Fiscal 2026 |
| Gross Margin - GAAP Guidance |  | 70% - 71% |
| Adjustments: |  |  |
| Cost of revenues adjustments |  | 1% |
| Gross Margin - Non-GAAP Guidance |  | 71% - 72% |
|  |  | Fiscal 2026 |
| Operating Margin - GAAP Guidance |  | 22.8% - 23.8% |
| Adjustments: |  |  |
| Stock-based compensation expense |  | 6% |
| Operating Margin - Non-GAAP Guidance |  | 28.8% - 29.8% |

[0000950170-25-078936:8k_2_02:155]
Some items may not add or recalculate due to rounding.

[0000950170-25-078936:8k_2_02:156]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| Fiscal 2026 |
|  |  | Fiscal 2026 |
| GAAP Guidance - Net Income Per Share |  | $5.80 - $6.10 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2026: |  |  |
| Amortization of intangible assets |  | $0.10 |
| Stock-based compensation expense |  | $2.04 |
| Income tax effects |  | ($0.34) |
| Total Adjustments |  | $1.80 |
| Non-GAAP Guidance - Net Income Per Share |  | $7.60 - $7.90 |

[0000950170-25-078936:8k_2_02:157]
Some items may not add or recalculate due to rounding.

[0000950170-25-078936:8k_2_02:158]
Contacts:

[0000950170-25-078936:8k_2_02:159]
(Press)

[0000950170-25-078936:8k_2_02:160]
Kenya Hayes

[0000950170-25-078936:8k_2_02:161]
1 703 589 7595

[0000950170-25-078936:8k_2_02:162]
kenya.hayes@netapp.com

[0000950170-25-078936:8k_2_02:163]
(Investors)

[0000950170-25-078936:8k_2_02:164]
Kris Newton

[0000950170-25-078936:8k_2_02:165]
1 408 822 3312

[0000950170-25-078936:8k_2_02:166]
kris.newton@netapp.com

## item 5.02 — body, verbatim

[0000950170-25-078936:8k_body:1]
Item 5.02 Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0000950170-25-078936:8k_body:2]
On May 23, 2025, Harvinder Bhela informed the Company of his decision to transition from his role of Executive Vice President and Chief Product Officer by June 20, 2025. Mr. Bhela has agreed to assist the Company with an orderly transition of his duties.
