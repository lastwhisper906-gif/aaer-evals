# NTAP notes — 0000950170-25-083705


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000950170-25-083705:notes:1]
The information called for by Part III of this Form 10-K is hereby incorporated by reference from the definitive Proxy Statement for our annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after April 25, 2025.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000950170-25-083705:notes:2]
Item 1C.  Cybersecurity

[0000950170-25-083705:notes:3]
Risk Management and Strategy

[0000950170-25-083705:notes:4]
The Company regularly assesses risks from cybersecurity threats, monitors its information systems for potential vulnerabilities, and tests those systems pursuant to the Company’s cybersecurity policies, standards, processes and practices, which are integrated into the Company’s overall risk management system. To protect the Company’s information systems from cybersecurity threats, the Company uses various security technologies and tools that help the Company identify, escalate, investigate, manage, resolve and recover from security incidents in a timely manner. These efforts include:

[0000950170-25-083705:notes:5]
•
ongoing collection of threat intelligence and environment awareness through monitoring,

[0000950170-25-083705:notes:6]
•
data protection management and vulnerability monitoring through data loss prevention and exfiltration tools,

[0000950170-25-083705:notes:7]
•
cybersecurity risk management processes and practices,

[0000950170-25-083705:notes:8]
•
control assurance,

[0000950170-25-083705:notes:9]
•
secure development of new products,

[0000950170-25-083705:notes:10]
•
identity and access management,

[0000950170-25-083705:notes:11]
•
incident response, auditing and monitoring, and

[0000950170-25-083705:notes:12]
•
maintaining a 24x7 security operations center to allow for always available incident response.

[0000950170-25-083705:notes:13]
The Company takes a risk-based approach to cybersecurity and has implemented cybersecurity policies throughout its operations that are designed to address cybersecurity threats and incidents. In particular, the Company follows an incident escalation process that is incorporated into its incident and risk management processes. In the event the Company identifies a cybersecurity incident, its senior management, consisting of the Chief Financial Officer, Chief Information Security Officer (CISO), Chief Administrative Officer, and Executive Vice President of Business Technology and Operations review the facts and circumstances involved in such cybersecurity incident, or series of related cybersecurity incidents.

[0000950170-25-083705:notes:14]
The Company partners with third parties to assess the effectiveness of its cybersecurity prevention and response systems and processes, including third-party review of the Company’s Information Security Management System for ISO 27001 controls, assessment of the Company’s cloud products and managed services according to the American Institute of CPAs (AICPA) Service Organization Control (SOC) Audit Type II, and new product validation as part of the Company’s secure development lifecycle. The Company additionally engages third-party providers in support of endpoint detection and responses, data loss prevention efforts, and incident management efforts.

[0000950170-25-083705:notes:15]
To date, the Company is not aware of cybersecurity threats, including as a result of any previous cybersecurity incidents, that have materially affected or are reasonably likely to materially affect the Company, including its business strategy, results of operations or financial condition. For additional discussion of cybersecurity risks and potential related impacts on the Company, refer to the risk factors in Part I, Item 1A. “Risk Factors,” including “If a material cybersecurity or other security breach impacts our services, systems, supply chain, or end-user customer systems, or if stored data is improperly accessed, our business could suffer significant harm.”

[0000950170-25-083705:notes:16]
Governance

[0000950170-25-083705:notes:17]
NetApp's Board of Directors oversees the Company’s risk management process, including cybersecurity risks, directly and through its committees. The Audit Committee of the Board of Directors oversees the Company’s risk management program, which focuses on the most significant risks the Company faces in the short-, intermediate-, and long-term timeframes. The Company’s CISO regularly updates each of the Board of Directors and the Audit Committee at least twice a year.  Such updates include a review of cybersecurity risks affecting the Company, related metrics, and any incidents or issues that require attention from the Board of Directors.

[0000950170-25-083705:notes:18]
The CISO provides leadership, strategic direction, and oversight for NetApp’s Global Security Risk and Compliance functions and security program. Global Security executives oversee management of risks and track projects progress, remediations, and any issues related to cybersecurity risks.

[0000950170-25-083705:notes:19]
NetApp’s CISO is responsible for leading the assessment and management of cybersecurity risks. The current CISO has over 30 years of experience in IT and information security, including over 16 years with NetApp in roles of increasing seniority, and is a

[0000950170-25-083705:notes:20]
Certified Information Security Auditor, Certified Information Security Manager with ISACA and a Certified Information Systems Security Professional with ISC2. The CISO stays informed on information security risks through regular meetings on key cybersecurity projects and KPIs. Updates are communicated to the Global Security Steering Committee, which provides quarterly reports to the Board of Directors and to the Audit Committee.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000950170-25-083705:notes:21]
1. Description of Business and Significant Accounting Policies

[0000950170-25-083705:notes:22]
Description of Business — NetApp, Inc. (we, us, NetApp, or the Company) helps customers make their data infrastructure more seamless, more dynamic, and higher performing. We provide a full range of enterprise-class software, systems and services that customers use to transform their data infrastructures across data types, workloads, and environments to realize business possibilities.

[0000950170-25-083705:notes:23]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal years 2025, 2024 and 2023, which ended on April 25, 2025, April 26, 2024 and April 28, 2023, respectively, are all 52-week years, with 13 weeks in each of their quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended on the last Friday of April and the associated quarters, months and periods of those fiscal years.

[0000950170-25-083705:notes:24]
Principles of Consolidation — The consolidated financial statements include the Company and its subsidiaries. Intercompany accounts and transactions are eliminated in consolidation.

[0000950170-25-083705:notes:25]
Use of Estimates — The preparation of the consolidated financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, the anticipated effects of which have been incorporated, as applicable, into management’s estimates as of and for the year ended April 25, 2025.

[0000950170-25-083705:notes:26]
Cash Equivalents — We consider all highly liquid debt investments with original maturities of three months or less at the time of purchase to be cash equivalents.

[0000950170-25-083705:notes:27]
Available-for-Sale Investments — We classify our investments in debt securities as available-for-sale investments. Debt securities primarily consist of U.S. Treasury and government debt securities and certificates of deposit. These investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of debt securities sold. These investments are recorded in the consolidated balance sheets at fair value.

[0000950170-25-083705:notes:28]
Unrealized gains and temporary losses, net of related taxes, are included in accumulated other comprehensive income (loss) (AOCI). Upon realization, those amounts are reclassified from AOCI to earnings. The amortization of premiums and discounts on the investments are included in our results of operations. Realized gains and losses are calculated based on the specific identification method.

[0000950170-25-083705:notes:29]
We classify our investments as current or noncurrent based on the nature of the investments and their availability for use in current operations.

[0000950170-25-083705:notes:30]
Impairments on Investments — All of our available-for-sale investments are subject to periodic impairment review. When the fair value of a debt security is less than its amortized cost, we assess what amount of the difference, if any, is caused by expected credit losses. The amount of the difference representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in earnings, and the amount relating to all other factors is recognized in other comprehensive income (OCI). If we intend to sell the security, or if it is more likely than not we will be required to sell the security before recovery of the amortized cost basis, the entire difference between the amortized cost and the fair value of the debt security is recognized in earnings.

[0000950170-25-083705:notes:31]
Inventories — Inventories are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. We write down excess and obsolete inventory based on the difference between the cost of inventory and the estimated net realizable value. Net realizable value is estimated using management’s best estimate of forecasts for future demand and expectations regarding market conditions. At the point of a loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts or circumstances do not result in the restoration or increase in that newly established basis. In addition, we record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0000950170-25-083705:notes:32]
Property and Equipment — Property and equipment are recorded at cost.

[0000950170-25-083705:notes:33]
Depreciation and amortization is computed using the straight-line method, generally over the following periods:

[0000950170-25-083705:notes:34]
|  |  | Depreciation Life |
| Buildings and improvements |  | 10 to 40 years |
| Furniture and fixtures |  | 5 years |
| Computer, production, engineering and other equipment |  | 2 to 3 years |
| Computer software |  | 3 to 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |

[0000950170-25-083705:notes:35]
Construction in progress will be depreciated over the estimated useful lives of the respective assets when they are ready for use. We capitalize interest on significant facility assets under construction and on significant software development projects. Interest capitalized during the periods presented was not material.

[0000950170-25-083705:notes:36]
Software Development Costs — The costs for the development of new software products and substantial enhancements to existing software products are expensed as incurred until technological feasibility has been established, at which time any additional costs would be capitalized in accordance with the accounting guidance for software. Because our current process for developing software is essentially completed concurrently with the establishment of technological feasibility, which occurs upon the completion of a working model, no costs have been capitalized for any of the periods presented.

[0000950170-25-083705:notes:37]
Internal-Use Software Development Costs — We capitalize qualifying costs, which are incurred during the application development stage, for computer software developed or obtained for internal-use to property and equipment, net and amortize them over the software’s estimated useful life.

[0000950170-25-083705:notes:38]
Business Combinations — We recognize identifiable assets acquired and liabilities assumed at their acquisition date fair values, with the exception of contract assets and liabilities, which we recognize in accordance with our revenue recognition policy as if we had originally executed the customer contract. Goodwill as of the acquisition date is measured as the excess of consideration transferred over the net of the acquisition date values of the assets acquired and liabilities assumed. While we use our best estimates and assumptions as a part of the purchase price allocation process to accurately value assets acquired and liabilities assumed at the acquisition date, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of income.

[0000950170-25-083705:notes:39]
Goodwill and Purchased Intangible Assets — Goodwill is recorded when the consideration paid for an acquisition exceeds the value of net tangible and intangible assets acquired. Purchased intangible assets with finite lives are generally amortized on a straight-line basis over their economic lives of three to five years for developed technology, two to five years for customer contracts/relationships, two to three years for covenants not to compete and two to five years for trademarks and trade names as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. In-process research and development is accounted for as an indefinite lived intangible asset and is assessed for potential impairment annually until development is complete or when events or circumstances indicate that their carrying amounts might be impaired. Upon completion of development, in-process research and development is accounted for as a finite-lived intangible asset.

[0000950170-25-083705:notes:40]
The carrying value of goodwill is tested for impairment on an annual basis in the fourth quarter of our fiscal year, or more frequently if we believe indicators of impairment exist. Triggering events for impairment reviews may be indicators such as adverse industry or economic trends, restructuring actions, lower projections of profitability, or a sustained decline in our market capitalization. For the purpose of impairment testing, we have two reporting units, which are the same as our two reportable segments. We initially conduct a qualitative assessment to determine whether it is necessary to perform a quantitative goodwill impairment test. The performance of the quantitative impairment test requires comparing the fair value of each reporting unit to its carrying amount, including goodwill. The fair value of each reporting unit is based on a combination of the income approach and the market approach.

[0000950170-25-083705:notes:41]
Under the income approach, we estimate the fair value of a reporting unit based on the present value of estimated future cash flows. Cash flow projections are based on discrete forecast periods as well as terminal value determinations, and are derived based on forecasted revenue growth rates and operating margins. These cash flow projections are discounted to arrive at the fair value of each reporting unit. The discount rate used is based on the weighted-average cost of capital of comparable public companies adjusted for the relevant risk associated with business specific characteristics and the uncertainty related to the reporting unit's ability to execute on the projected cash flows. Under the market approach, we estimate the fair value based on market multiples of revenue and earnings derived from comparable publicly traded companies with operating and investment characteristics similar to the reporting unit. In addition, we make certain judgments and assumptions in allocating shared assets and liabilities to individual reporting units to determine the carrying amount of each reporting unit. An impairment exists if the fair value of a reporting unit is lower than its carrying amount. The impairment loss is measured based on the amount by which the carrying amount of the reporting unit exceeds its fair value, with the recognized loss not to exceed the total amount of allocated goodwill. We did not recognize any impairment charges on our goodwill in any of the periods presented.

[0000950170-25-083705:notes:42]
Impairment of Long-Lived Assets — We review the carrying values of long-lived assets whenever events and circumstances, such as reductions in demand, lower projections of profitability, significant changes in the manner of our use of acquired assets, or significant negative industry or economic trends, indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. If this review indicates that there is an impairment, the impaired asset is written down to its fair value, which is typically calculated using: (i) quoted market prices and/or (ii) expected future cash flows utilizing a discount rate. Our estimates regarding future anticipated cash flows, the remaining economic life of the products and technologies, or both, may differ materially from actual cash flows and remaining economic life. In that event, impairment charges or shortened useful lives of certain long-lived assets may be required, resulting in charges to our consolidated statements of income when such determinations are made.

[0000950170-25-083705:notes:43]
Derivative Instruments — Our derivative instruments, which are carried at fair value in our consolidated balance sheets, consist of foreign currency exchange contracts as described below:

[0000950170-25-083705:notes:44]
Balance Sheet Hedges — We utilize foreign currency exchange forward and option contracts to hedge against the short-term impact of foreign currency exchange rate fluctuations related to certain foreign currency denominated monetary assets and liabilities, primarily intercompany receivables and payables. These derivative instruments are not designated as hedging instruments and do not subject us to material balance sheet risk due to exchange rate movements because the gains and losses on these contracts are intended to offset the gains and losses in the underlying foreign currency denominated monetary assets and liabilities being hedged, and the net amount is included in earnings.

[0000950170-25-083705:notes:45]
Cash Flow Hedges — We utilize foreign currency exchange forward contracts to hedge foreign currency exchange exposures related to forecasted sales transactions denominated in certain foreign currencies. These derivative instruments are designated and qualify as cash flow hedges and, in general, closely match the underlying forecasted transactions in duration. The effective portion of the contracts’ gains and losses resulting from changes in fair value is recorded in AOCI until the forecasted transaction is recognized in the consolidated statements of income. When the forecasted transactions occur, we reclassify the related gains or losses on the cash flow hedges into net revenues. If the underlying forecasted transactions do not occur, or it becomes probable that they will not occur within the defined hedge period, the gains or losses on the related cash flow hedges are reclassified from AOCI and recognized immediately in earnings. We measure the effectiveness of hedges of forecasted transactions on a monthly basis by comparing the fair values of the designated foreign currency exchange forward purchase contracts with the fair values of the forecasted transactions.

[0000950170-25-083705:notes:46]
Factors that could have an impact on the effectiveness of our hedging programs include the accuracy of forecasts and the volatility of foreign currency markets. These programs reduce, but do not entirely eliminate, the impact of currency exchange movements. Currently, we do not enter into any foreign currency exchange forward contracts to hedge exposures related to firm commitments. Cash flows from our derivative programs are included under operating activities in the consolidated statements of cash flows.

[0000950170-25-083705:notes:47]
Revenue Recognition — We recognize revenue by applying the following five step approach.

[0000950170-25-083705:notes:48]
•
Identification of the contract, or contracts, with a customer — A contract with a customer is within the scope of ASC 606 when it meets all the following criteria:

[0000950170-25-083705:notes:49]
-
It is enforceable

[0000950170-25-083705:notes:50]
-
It defines each party’s rights

[0000950170-25-083705:notes:51]
-
It identifies the payment terms

[0000950170-25-083705:notes:52]
-
It has commercial substance, and

[0000950170-25-083705:notes:53]
-
We determine that collection of substantially all consideration for goods or services that will be transferred is probable based on the customer’s intent and ability to pay

[0000950170-25-083705:notes:54]
•
Identification of the performance obligations in the contract — Performance obligations promised in a contract are identified based on the goods or services (or a bundle of goods and services) that will be transferred to the customer that are distinct.

[0000950170-25-083705:notes:55]
•
Determination of the transaction price — The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer.

[0000950170-25-083705:notes:56]
•
Allocation of the transaction price to the performance obligations in the contract — Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation.

[0000950170-25-083705:notes:57]
•
Recognition of revenue when, or as, we satisfy a performance obligation — We satisfy performance obligations either over time or at a point in time.

[0000950170-25-083705:notes:58]
Customarily we have a purchase order from or executed contract with our customers that establishes the goods and services to be transferred and the consideration to be received.

[0000950170-25-083705:notes:59]
We combine two or more contracts entered into at or near the same time with the same customer as a single contract if the contracts are negotiated as one package with a single commercial objective, if the amount of consideration to be paid on one contract depends on the price or performance of the other contract or if the goods and services promised in each of the contracts are a single performance obligation.

[0000950170-25-083705:notes:60]
Our contracts with customers may include hardware systems, software licenses, software support, hardware support, public cloud services and other services. Software support contracts entitle our customers to receive unspecified upgrades and enhancements on a when-and-if-available basis, and patch releases. Hardware support services include contracts for extended warranty and technical support with minimum response times. Other services include professional services and customer education and training services.

[0000950170-25-083705:notes:61]
We identify performance obligations in our contracts to be those goods and services that are distinct. A good or service is distinct where the customer can benefit from the good or service either on its own or together with other resources that are readily available from third parties or from us, and is distinct in the context of the contract, where the transfer of the good or service is separately identifiable from other promises in the contract.

[0000950170-25-083705:notes:62]
If a contract includes multiple promised goods or services, we apply judgment to determine whether promised goods or services are distinct. If they are not, we combine the goods and services until we have a distinct performance obligation. For example, a configured storage system inclusive of the operating system (OS) software essential to its functionality is considered a single performance obligation, while optional add-on software is a separate performance obligation. In general, hardware support, software support, and different types of professional services are each separate performance obligations.

[0000950170-25-083705:notes:63]
We determine the transaction price of our contracts with customers based on the consideration to which we will be entitled in exchange for transferring goods or services. Consideration promised may include fixed amounts, variable amounts or both. We sell public cloud services either on a subscription basis or a consumption basis. We sell professional services either on a time and materials basis or under fixed price projects.

[0000950170-25-083705:notes:64]
We evaluate variable consideration in arrangements with contract terms such as rights of return, potential penalties and acceptance clauses. We generally use the expected value method, primarily relying on our history, to estimate variable consideration. However, when we believe it to provide a better estimate, we use the most likely amount method. In either case, we consider variable consideration only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recognized will not occur. Reassessments of our variable consideration may occur as historical information changes. Transaction prices are also adjusted for the effects of time value of money if the timing of payments provides either the customer or us a significant benefit of financing.

[0000950170-25-083705:notes:65]
Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation on a relative standalone selling price basis. We determine standalone selling price based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price by maximizing the use of observable inputs including pricing strategy, market data, internally-approved pricing guidelines related to the performance obligations and other observable inputs. We regularly review standalone selling prices and maintain internal controls over the establishment and updates of these estimates. Variable consideration is also allocated to the performance obligations. If the terms of variable consideration relate to one performance obligation, it is entirely allocated to that obligation. Otherwise, it is allocated to all the performance obligations in the contract.

[0000950170-25-083705:notes:66]
We typically recognize revenue at a point in time upon the transfer of goods to a customer. Products we transfer at a point in time include our configured hardware systems, OS software licenses, optional add-on software licenses and add-on hardware. Services are typically transferred over time and revenue is recognized based on an appropriate method for measuring our progress toward

[0000950170-25-083705:notes:67]
completion of the performance obligation. Our stand-ready services, including both hardware and software support, are transferred ratably over the period of the contract. Our public cloud services are transferred either 1) for subscription arrangements, ratably over the subscription period or 2) for consumption-based arrangements, as actually consumed by the customer. For other services such as our fixed professional services contracts, we use an input method to determine the percentage of completion. That is, we estimate the effort to date versus the expected effort required over the life of the contract.

[0000950170-25-083705:notes:68]
Deferred Commissions — We capitalize sales commissions that are incremental direct costs of obtaining customer contracts for which revenue is not immediately recognized and classify them as current or non-current based on the terms of the related contracts. Capitalized commissions are amortized based on the transfer of goods or services to which they relate, typically over one to three years, and are also periodically reviewed for impairment. Amortization expense is recorded to sales and marketing expense in our consolidated statements of income.

[0000950170-25-083705:notes:69]
Leases — We determine if an arrangement is or contains a lease at inception, and we classify leases as operating or finance leases at commencement. In our consolidated balance sheets, operating lease right-of-use (ROU) assets are included in other non-current assets, while finance lease ROU assets are included in property and equipment, net. Lease liabilities for both types of leases are included in accrued expenses and other long-term liabilities. ROU assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over that term.

[0000950170-25-083705:notes:70]
Operating and finance lease ROU assets and liabilities are recognized at commencement based on the present value of lease payments over the lease term. ROU assets also include any lease payments made prior to lease commencement and exclude lease incentives. The lease term is the noncancelable period of the lease and includes options to extend or terminate the lease when it is reasonably certain that an option will be exercised. As the rate implicit in our leases is typically not readily determinable, in computing the present value of lease payments we generally use our incremental borrowing rate based on information available at the commencement date. Variable lease payments not dependent on an index or rate are expensed as incurred and not included within the calculation of ROU assets and lease liabilities. Lease expense for operating lease payments is recognized on a straight-line basis over the lease term.

[0000950170-25-083705:notes:71]
We do not separate non-lease components from lease components for any class of leases, and we do not recognize ROU assets and lease liabilities for leases with a lease term of twelve months or less.

[0000950170-25-083705:notes:72]
Foreign Currency Translation — For international subsidiaries whose functional currency is the local currency, gains and losses resulting from translation of these foreign currency financial statements into U.S. dollars are recorded in AOCI. For international subsidiaries where the functional currency is the U.S. dollar, gains and losses resulting from the process of remeasuring foreign currency financial statements into U.S. dollars are included in other (expense) income, net.

[0000950170-25-083705:notes:73]
Benefit Plans — We record actuarial gains and losses associated with defined benefit plans within AOCI and amortize net gains or losses in excess of 10 percent of the greater of the market value of plan assets as of the beginning of the fiscal year or the plans' projected benefit obligation on a straight-line basis over the remaining estimated service life of plan participants. The measurement date for all defined benefit plans is our fiscal year end.

[0000950170-25-083705:notes:74]
Stock-Based Compensation — We measure and recognize stock-based compensation for all stock-based awards, including employee stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and rights to purchase shares under our employee stock purchase plan (ESPP), based on their estimated fair value, and recognize the costs in our financial statements using the straight-line attribution approach over the requisite service period for the entire award.

[0000950170-25-083705:notes:75]
The fair value of employee time-based RSUs, and PBRSUs that include a performance condition, is equal to the market value of our common stock on the grant date of the award, less the present value of expected dividends during the vesting period, discounted at a risk-free interest rate. The fair value of PBRSUs that include a market condition is measured using a Monte Carlo simulation model on the date of grant.

[0000950170-25-083705:notes:76]
The fair value of time-based RSUs, and PBRSUs that include a market condition, is not remeasured as a result of subsequent stock price fluctuations. When there is a change in management’s estimate of expected achievement relative to the performance target for PBRSUs that include a performance condition, such as our achievement against a billings result average target, the change in estimate results in the recognition of a cumulative adjustment of stock-based compensation expense.

[0000950170-25-083705:notes:77]
Our expected term assumption is based primarily on historical exercise and post-vesting forfeiture experience. Our stock price volatility assumption is based on a combination of our historical and implied volatility. The risk-free interest rates are based upon United States (U.S.) Treasury bills with equivalent expected terms, and the expected dividends are based on our history and expected dividend payouts.

[0000950170-25-083705:notes:78]
We account for forfeitures of stock-based awards as they occur.

[0000950170-25-083705:notes:79]
Income Taxes — Deferred income tax assets and liabilities are provided for temporary differences that will result in tax deductions or income in future periods, as well as the future benefit of tax credit carryforwards. A valuation allowance reduces tax assets to their estimated realizable value.

[0000950170-25-083705:notes:80]
We recognize the tax liability for uncertain income tax positions on the income tax return based on the two-step process prescribed in the interpretation. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. We recognize interest and penalties related to unrecognized tax benefits within the provision for income taxes line on the accompanying consolidated statements of income.

[0000950170-25-083705:notes:81]
Net Income per Share — Basic net income per share is computed by dividing net income by the weighted-average number of common shares outstanding. Diluted net income per share is computed giving effect to the weighted-average number of dilutive potential shares that were outstanding during the period using the treasury stock method. Potential dilutive common shares consist primarily of outstanding stock options, shares to be purchased under our employee stock purchase plan and unvested RSUs.

[0000950170-25-083705:notes:82]
Treasury Stock — We account for treasury stock under the cost method. Upon the retirement of treasury stock, we allocate the value of treasury shares between common stock, additional paid-in capital and retained earnings.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000950170-25-083705:notes:83]
2. Recent Accounting Pronouncements

[0000950170-25-083705:notes:84]
Recent Accounting Pronouncements Not Yet Adopted

[0000950170-25-083705:notes:85]
In November 2024, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires additional disclosure of the nature of expenses included in the income statement. The standard requires disclosures about specific types of expenses included in the expense captions presented in the income statement as well as disclosures about selling expenses. This ASU is effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027, with early adoption permitted. The requirements should be applied on a prospective basis while retrospective application is permitted. We are currently evaluating the effect of this pronouncement on our disclosures.

[0000950170-25-083705:notes:86]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which expands the disclosures required for income taxes. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The amendment should be applied on a prospective basis while retrospective application is permitted. We are currently evaluating the effect of this pronouncement on our income tax disclosures.

[0000950170-25-083705:notes:87]
Recently Adopted Accounting Pronouncement

[0000950170-25-083705:notes:88]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires disclosure of incremental segment information on an annual and interim basis. We adopted this standard for our annual period beginning fiscal year 2025 on a retrospective basis to all periods presented. The adoption of this standard did not result in a significant change to our consolidated financial statement disclosures. See Note 15 – Segment, Geographic, and Significant Customer Information of the Notes to Consolidated Financial Statements for our reportable segment disclosures.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-25-083705:notes:89]
3. Concentration of Risk

[0000950170-25-083705:notes:90]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, investments, foreign currency exchange contracts and accounts receivable. We maintain the majority of our cash and cash equivalents with several major financial institutions where the deposits exceed federally insured limits. Cash equivalents and short-term investments consist primarily of money market funds, U.S. Treasury and government debt securities and certificates of deposit, all of which are considered high investment grade. Our policy is to limit the amount of credit exposure through diversification and investment in highly rated securities. We further mitigate concentrations of credit risk in our investments by limiting our investments in the debt securities of a single issuer and by diversifying risk across geographies and type of issuer. General macroeconomic uncertainty has led to an increase in market volatility, however, management believes that the financial institutions that hold our cash, cash equivalents and investments are financially sound and, accordingly, are subject to minimal credit risk.

[0000950170-25-083705:notes:91]
By entering into foreign currency exchange contracts, we have assumed the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and we do not expect any losses as a result of counterparty defaults.

[0000950170-25-083705:notes:92]
We sell our products primarily to large organizations in different industries and geographies. We do not require collateral or other security to support accounts receivable. In addition, we maintain an allowance for potential credit losses. To reduce credit risk, we perform ongoing credit evaluations on our customers’ financial condition. We establish an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information, including the expected impact of macroeconomic disruptions, and, to date, such losses have been within management’s expectations. Concentrations of credit risk with respect to trade accounts receivable are limited due to the wide variety of customers who are dispersed across many geographic regions.

[0000950170-25-083705:notes:93]
There are no concentrations of business transacted with a particular market that would severely impact our business in the near term. However, we rely on a limited number of suppliers for certain key components and a few key contract manufacturers to manufacture most of our products; any disruption, or termination of these arrangements could materially adversely affect our operating results.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-25-083705:notes:94]
4. Business Combinations

[0000950170-25-083705:notes:95]
Fiscal 2023 Acquisition

[0000950170-25-083705:notes:96]
Instaclustr Acquisition

[0000950170-25-083705:notes:97]
On May 20, 2022, we acquired all the outstanding shares of privately-held Instaclustr US Holding, Inc. (Instaclustr) for $498 million. Instaclustr is a leading platform provider of fully managed open-source database, pipeline and workflow applications delivered as-a-service.

[0000950170-25-083705:notes:98]
The acquisition-date values of the assets acquired and liabilities assumed are as follows (in millions):

[0000950170-25-083705:notes:99]
|  |  | Amount |  |
| Cash |  | $ | 4 |  |
| Intangible assets |  |  | 107 |  |
| Goodwill |  |  | 413 |  |
| Other assets |  |  | 19 |  |
| Total assets acquired |  |  | 543 |  |
| Liabilities assumed |  |  | (45 | ) |
| Total purchase price |  | $ | 498 |  |

[0000950170-25-083705:notes:100]
The components of the intangible assets acquired were as follows (in millions, except useful life):

[0000950170-25-083705:notes:101]
|  |  | Amount |  |  | Estimated useful life(years) |  |
| Developed technology |  | $ | 55 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 50 |  |  |  | 5 |  |
| Trade name |  |  | 2 |  |  |  | 3 |  |
| Total intangible assets |  | $ | 107 |  |  |  |  |

[0000950170-25-083705:notes:102]
The acquired net assets and assumed debt of Instaclustr were recorded at their estimated values. We determined the estimated values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expect to realize revenue synergies and anticipate opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated value of its identifiable net assets acquired, and as a result, we have recorded goodwill in connection with the acquisition. The goodwill is not deductible for income tax purposes.

[0000950170-25-083705:notes:103]
The results of operations related to the acquisition of Instaclustr have been included in our consolidated statements of income from the acquisition date. Pro forma results of operations have not been presented because the impact from the acquisition was not material to our consolidated results of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-25-083705:notes:104]
5. Goodwill and Purchased Intangible Assets, Net

[0000950170-25-083705:notes:105]
Goodwill activity is summarized as follows (in millions):

[0000950170-25-083705:notes:106]
|  |  | Amount |  |
| Balance as of April 28, 2023 |  | $ | 2,759 |  |
| Additions |  |  | — |  |
| Balance as of April 26, 2024 |  |  | 2,759 |  |
| Additions |  |  | — |  |
| Derecognition |  |  | (36 | ) |
| Balance as of April 25, 2025 |  | $ | 2,723 |  |

[0000950170-25-083705:notes:107]
During fiscal 2025, we derecognized a portion of the Public Cloud goodwill in connection with the sale of our cloud optimization and management software business known as Spot by NetApp, which formed part of our Public Cloud reportable segment. See "Gains/losses on the sale or derecognition of assets" section contained in Note 6 – Supplemental Financial Information for additional information related to this derecognition.

[0000950170-25-083705:notes:108]
Goodwill by reportable segment as of April 25, 2025 is as follows (in millions):

[0000950170-25-083705:notes:109]
|  |  | Amount |  |
| Hybrid Cloud |  | $ | 1,714 |  |
| Public Cloud |  |  | 1,009 |  |
| Total goodwill |  | $ | 2,723 |  |

[0000950170-25-083705:notes:110]
Purchased intangible assets, net are summarized below (in millions):

[0000950170-25-083705:notes:111]
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 55 |  |  | $ | (33 | ) |  | $ | 22 |  |  | $ | 179 |  |  | $ | (108 | ) |  | $ | 71 |  |
| Customer contracts/relationships |  |  | 50 |  |  |  | (29 | ) |  |  | 21 |  |  |  | 114 |  |  |  | (62 | ) |  |  | 52 |  |
| Other purchased intangibles |  |  | 2 |  |  |  | (2 | ) |  |  | — |  |  |  | 6 |  |  |  | (5 | ) |  |  | 1 |  |
| Total purchased intangible assets |  | $ | 107 |  |  | $ | (64 | ) |  | $ | 43 |  |  | $ | 299 |  |  | $ | (175 | ) |  | $ | 124 |  |

[0000950170-25-083705:notes:112]
During fiscal 2025, we retired $25 million of fully amortized intangible assets. We also derecognized certain intangible assets, net in connection with the sale of our Spot by NetApp business. See "Gains/losses on the sale or derecognition of assets" section contained in Note 6 – Supplemental Financial Information for additional information related to this derecognition.

[0000950170-25-083705:notes:113]
Amortization expense for purchased intangible assets is summarized below (in millions):

[0000950170-25-083705:notes:114]
|  |  | Year Ended |  |  | Statements of |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |  | IncomeClassifications |
| Developed technology |  | $ | 28 |  |  | $ | 34 |  |  | $ | 42 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 19 |  |  |  | 22 |  |  |  | 24 |  |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | 1 |  |  |  | 2 |  |  | Operating expenses |
| Total |  | $ | 47 |  |  | $ | 57 |  |  | $ | 68 |  |  |  |

[0000950170-25-083705:notes:115]
As of April 25, 2025, future amortization expense related to purchased intangible assets is as follows (in millions):

[0000950170-25-083705:notes:116]
| Fiscal Year |  | Amount |  |
| 2026 |  | $ | 21 |  |
| 2027 |  |  | 21 |  |
| 2028 |  |  | 1 |  |
| 2029 |  |  | — |  |
| Total |  | $ | 43 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-25-083705:notes:117]
6. Supplemental Financial Information

[0000950170-25-083705:notes:118]
Cash and cash equivalents (in millions):

[0000950170-25-083705:notes:119]
The following table presents cash and cash equivalents as reported in our consolidated balance sheets, as well as the sum of cash, cash equivalents and restricted cash as reported on our consolidated statements of cash flows:

[0000950170-25-083705:notes:120]
|  |  | April 25, 2025 |  |  | April 26,2024 |  |
| Cash and cash equivalents |  | $ | 2,742 |  |  | $ | 1,903 |  |
| Restricted cash |  |  | 7 |  |  |  | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,749 |  |  | $ | 1,909 |  |

[0000950170-25-083705:notes:121]
Inventories (in millions):

[0000950170-25-083705:notes:122]
|  |  | April 25, 2025 |  |  | April 26,2024 |  |
| Purchased components |  | $ | 81 |  |  | $ | 116 |  |
| Finished goods |  |  | 105 |  |  |  | 70 |  |
| Inventories |  | $ | 186 |  |  | $ | 186 |  |

[0000950170-25-083705:notes:123]
Property and equipment, net (in millions):

[0000950170-25-083705:notes:124]
|  |  | April 25, 2025 |  |  | April 26,2024 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 374 |  |  |  | 367 |  |
| Leasehold improvements |  |  | 103 |  |  |  | 81 |  |
| Computer, production, engineering and other equipment |  |  | 1,172 |  |  |  | 1,101 |  |
| Computer software |  |  | 329 |  |  |  | 340 |  |
| Furniture and fixtures |  |  | 62 |  |  |  | 77 |  |
| Construction-in-progress |  |  | 49 |  |  |  | 70 |  |
|  |  |  | 2,135 |  |  |  | 2,082 |  |
| Accumulated depreciation and amortization |  |  | (1,572 | ) |  |  | (1,478 | ) |
| Property and equipment, net |  | $ | 563 |  |  | $ | 604 |  |

[0000950170-25-083705:notes:125]
During fiscal 2025, we derecognized certain property and equipment, net in connection with the sale of our Spot by NetApp business. See "Gains/losses on the sale or derecognition of assets" section below for additional information related to this derecognition.

[0000950170-25-083705:notes:126]
Depreciation and amortization expense related to property and equipment, net is summarized below (in millions):

[0000950170-25-083705:notes:127]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26,2024 |  |  | April 28,2023 |  |
| Depreciation and amortization expense |  | $ | 196 |  |  | $ | 198 |  |  | $ | 181 |  |

[0000950170-25-083705:notes:128]
Other non-current assets (in millions):

[0000950170-25-083705:notes:129]
|  |  | April 25, 2025 |  |  | April 26,2024 |  |
| Deferred tax assets |  | $ | 994 |  |  | $ | 896 |  |
| Operating lease ROU assets |  |  | 241 |  |  |  | 247 |  |
| Other assets |  |  | 408 |  |  |  | 360 |  |
| Other non-current assets |  | $ | 1,643 |  |  | $ | 1,503 |  |

[0000950170-25-083705:notes:130]
Other non-current assets as of April 25, 2025 and April 26, 2024 include $92 million and $85 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies.

[0000950170-25-083705:notes:131]
Accrued expenses (in millions):

[0000950170-25-083705:notes:132]
|  |  | April 25, 2025 |  |  | April 26,2024 |  |
| Accrued compensation and benefits |  | $ | 513 |  |  | $ | 538 |  |
| Product warranty liabilities |  |  | 18 |  |  |  | 18 |  |
| Operating lease liabilities |  |  | 40 |  |  |  | 40 |  |
| Other current liabilities |  |  | 551 |  |  |  | 417 |  |
| Accrued expenses |  | $ | 1,122 |  |  | $ | 1,013 |  |

[0000950170-25-083705:notes:133]
Other long-term liabilities (in millions):

[0000950170-25-083705:notes:134]
|  |  | April 25, 2025 |  |  | April 26,2024 |  |
| Liability for uncertain tax positions |  | $ | 45 |  |  | $ | 153 |  |
| Income taxes payable |  |  | — |  |  |  | 100 |  |
| Product warranty liabilities |  |  | 9 |  |  |  | 9 |  |
| Operating lease liabilities |  |  | 216 |  |  |  | 220 |  |
| Other liabilities |  |  | 109 |  |  |  | 103 |  |
| Other long-term liabilities |  | $ | 379 |  |  | $ | 585 |  |

[0000950170-25-083705:notes:135]
Deferred revenue and financed unearned services revenue

[0000950170-25-083705:notes:136]
The following table summarizes the components of our deferred revenue and financed unearned services revenue balance as reported in our consolidated balance sheets (in millions):

[0000950170-25-083705:notes:137]
|  |  | April 25, 2025 |  |  | April 26,2024 |  |
| Deferred product revenue |  | $ | 66 |  |  | $ | 59 |  |
| Deferred services revenue |  |  | 4,428 |  |  |  | 4,123 |  |
| Financed unearned services revenue |  |  | 42 |  |  |  | 52 |  |
| Total |  | $ | 4,536 |  |  | $ | 4,234 |  |
| Reported as: |  |  |  |  |  |  |
| Short-term |  | $ | 2,279 |  |  | $ | 2,176 |  |
| Long-term |  |  | 2,257 |  |  |  | 2,058 |  |
| Total |  | $ | 4,536 |  |  | $ | 4,234 |  |

[0000950170-25-083705:notes:138]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 17 – Commitments and Contingencies for additional information related to these arrangements.

[0000950170-25-083705:notes:139]
During the years ended April 25, 2025 and April 26, 2024, we recognized revenue of $2,176 million and $2,218 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0000950170-25-083705:notes:140]
Remaining performance obligations

[0000950170-25-083705:notes:141]
As of April 25, 2025, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $5.0 billion. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 49% of our remaining performance obligations in the next 12 months and the remainder thereafter.

[0000950170-25-083705:notes:142]
Deferred commissions

[0000950170-25-083705:notes:143]
The following table summarizes deferred commissions balances as reported in our consolidated balance sheets (in millions):

[0000950170-25-083705:notes:144]
|  |  | April 25, 2025 |  |  | April 26,2024 |  |
| Other current assets |  | $ | 64 |  |  | $ | 69 |  |
| Other non-current assets |  |  | 104 |  |  |  | 100 |  |
| Total deferred commissions |  | $ | 168 |  |  | $ | 169 |  |

[0000950170-25-083705:notes:145]
During the years ended April 25, 2025 and April 26, 2024, we recognized amortization expense from deferred commissions of $123 million and $101 million, respectively, and there were no impairment charges recognized.

[0000950170-25-083705:notes:146]
Other income, net (in millions):

[0000950170-25-083705:notes:147]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Interest income |  | $ | 112 |  |  | $ | 112 |  |  | $ | 69 |  |
| Interest expense |  |  | (64 | ) |  |  | (64 | ) |  |  | (67 | ) |
| Other, net |  |  | (2 | ) |  |  | 1 |  |  |  | 46 |  |
| Total other income, net |  | $ | 46 |  |  | $ | 49 |  |  | $ | 48 |  |

[0000950170-25-083705:notes:148]
Other, net for fiscal 2023 includes $22 million of other income for non-refundable, up-front payments from customers in Russia for support contracts, which we were not able to fulfill due to imposed sanctions and for which we have no remaining legal obligation to perform. Other, net for fiscal 2023 also includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of $59 million.

[0000950170-25-083705:notes:149]
Statements of cash flows additional information (in millions):

[0000950170-25-083705:notes:150]
Supplemental cash flow information related to our operating leases is included in Note 9 – Leases. Non-cash investing activities and other supplemental cash flow information are presented below:

[0000950170-25-083705:notes:151]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 14 |  |  | $ | 16 |  |  | $ | 12 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 412 |  |  | $ | 357 |  |  | $ | 386 |  |
| Interest paid |  | $ | 53 |  |  | $ | 59 |  |  | $ | 65 |  |

[0000950170-25-083705:notes:152]
Gains/losses on the sale or derecognition of assets

[0000950170-25-083705:notes:153]
In January 2025, we and Flexera Software LLC entered into a definitive agreement for the sale of our cloud optimization and management software business known as Spot by NetApp, which formed part of our Public Cloud reportable segment. Total sale consideration consists of (i) $70 million in up-front cash consideration and (ii) up to $49 million in cash consideration contingent upon the achievement of certain financial performance metrics during the period from January 1, 2025 through December 31, 2025. The transaction closed on March 3, 2025, and we received the up-front cash consideration, recognized $20 million for contingent consideration in other current assets, derecognized the assets and liabilities conveyed to Flexera, and recorded certain transaction costs. No material gain or loss was recorded to our consolidated statements of income.

[0000950170-25-083705:notes:154]
The major classes of assets and liabilities derecognized on the transaction close date are (in millions):

[0000950170-25-083705:notes:155]
|  |  | Amount |  |
| Assets: |  |  |  |
| Property and equipment, net |  | $ | 13 |  |
| Goodwill |  |  | 36 |  |
| Purchased intangible assets, net |  |  | 34 |  |
| Total Assets |  |  | 83 |  |
| Liabilities: |  |  |  |
| Short-term deferred revenue and financed unearned service revenue |  |  | 1 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-25-083705:notes:156]
7. Financial Instruments and Fair Value Measurements

[0000950170-25-083705:notes:157]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis, whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the three levels of inputs to measure fair value:

[0000950170-25-083705:notes:158]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0000950170-25-083705:notes:159]
Level 2: Inputs that reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; benchmark yields, reported trades, broker/dealer quotes, inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0000950170-25-083705:notes:160]
Level 3: Unobservable inputs that reflect our own assumptions incorporated in valuation techniques used to measure fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0000950170-25-083705:notes:161]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and consider an inactive market to be one in which there are infrequent or few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty’s non-performance risk is considered in measuring the fair values of liabilities and assets, respectively.

[0000950170-25-083705:notes:162]
Investments

[0000950170-25-083705:notes:163]
The following is a summary of our investments at their cost or amortized cost as of April 25, 2025 and April 26, 2024 (in millions):

[0000950170-25-083705:notes:164]
|  |  | April 25, 2025 |  |  | April 26,2024 |  |
| U.S. Treasury and government debt securities |  | $ | 2,025 |  |  | $ | 1,349 |  |
| Money market funds |  |  | 1,126 |  |  |  | 1,161 |  |
| Certificates of deposit |  |  | 24 |  |  |  | 12 |  |
| Mutual funds |  |  | 41 |  |  |  | 38 |  |
| Total debt and equity securities |  | $ | 3,216 |  |  | $ | 2,560 |  |

[0000950170-25-083705:notes:165]
The fair value of our investments approximates their cost or amortized cost for both periods presented. Investments in mutual funds relate to the non-qualified deferred compensation plan offered to certain employees.

[0000950170-25-083705:notes:166]
As of April 25, 2025, all our debt investments are due to mature in one year or less.

[0000950170-25-083705:notes:167]
Fair Value of Financial Instruments

[0000950170-25-083705:notes:168]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis (in millions):

[0000950170-25-083705:notes:169]
|  |  | April 25, 2025 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 671 |  |  | $ | 671 |  |  | $ | — |  |
| Money market funds |  |  | 1,126 |  |  |  | 1,126 |  |  |  | — |  |
| Certificates of deposit |  |  | 24 |  |  |  | — |  |  |  | 24 |  |
| U.S. Treasury and government debt securities |  |  | 921 |  |  |  | 921 |  |  |  | — |  |
| Total cash and cash equivalents |  |  | 2,742 |  |  |  | 2,718 |  |  |  | 24 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 1,104 |  |  |  | 1,104 |  |  |  | — |  |
| Total short-term investments |  |  | 1,104 |  |  |  | 1,104 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,846 |  |  | $ | 3,822 |  |  | $ | 24 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 34 |  |  | $ | 34 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (2 | ) |  | $ | — |  |  | $ | (2 | ) |

[0000950170-25-083705:notes:170]
|  |  | April 26, 2024 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 730 |  |  | $ | 730 |  |  | $ | — |  |
| Money market funds |  |  | 1,161 |  |  |  | 1,161 |  |  |  | — |  |
| Certificates of deposit |  |  | 12 |  |  |  | — |  |  |  | 12 |  |
| Total cash and cash equivalents |  |  | 1,903 |  |  |  | 1,891 |  |  |  | 12 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 1,349 |  |  |  | 1,349 |  |  |  | — |  |
| Total short-term investments |  |  | 1,349 |  |  |  | 1,349 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,252 |  |  | $ | 3,240 |  |  | $ | 12 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 32 |  |  | $ | 32 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (13 | ) |  | $ | — |  |  | $ | (13 | ) |

[0000950170-25-083705:notes:171]
(1)
Reported as other current assets in the consolidated balance sheets

[0000950170-25-083705:notes:172]
(2)
Reported as other non-current assets in the consolidated balance sheets

[0000950170-25-083705:notes:173]
(3)
Reported as accrued expenses in the consolidated balance sheets

[0000950170-25-083705:notes:174]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of April 25, 2025 and April 26, 2024, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0000950170-25-083705:notes:175]
Fair Value of Debt

[0000950170-25-083705:notes:176]
As of April 25, 2025 and April 26, 2024, the fair value of our long-term debt, including the current portion, was $3,143 million and $2,209 million, respectively. These fair values of our long-term debt were based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0000950170-25-083705:notes:177]
8. Financing Arrangements

[0000950170-25-083705:notes:178]
Long-Term Debt

[0000950170-25-083705:notes:179]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0000950170-25-083705:notes:180]
|  |  | Effective Interest Rate |  | April 25, 2025 |  |  | April 26, 2024 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  | $ | — |  |  | $ | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| 5.50% Senior Notes Due June 2032 |  | 5.71% |  |  | 625 |  |  |  | — |  |
| 5.70% Senior Notes Due June 2035 |  | 5.90% |  |  | 625 |  |  |  | — |  |
| Total principal amount |  |  |  |  | 3,250 |  |  |  | 2,400 |  |
| Unamortized discount and issuance costs |  |  |  |  | (15 | ) |  |  | (8 | ) |
| Total senior notes |  |  |  |  | 3,235 |  |  |  | 2,392 |  |
| Less: Current portion of long-term debt |  |  |  |  | (750 | ) |  |  | (400 | ) |
| Total long-term debt |  |  |  | $ | 2,485 |  |  | $ | 1,992 |  |

[0000950170-25-083705:notes:181]
Senior Notes

[0000950170-25-083705:notes:182]
In March 2025, we issued $625 million aggregate principal amount of 5.50% Senior Notes due 2032 and $625 million aggregate principal amount of 5.70% Senior Notes due 2035, for which we received total proceeds of $1.24 billion, net of discount and issuance costs. Interest on these Senior Notes is payable semi-annually in March and September.

[0000950170-25-083705:notes:183]
On September 30, 2024, upon maturity, we repaid the 3.30% Senior Notes due September 2024 for an aggregate amount of $407 million, comprised of the principal and unpaid interest.

[0000950170-25-083705:notes:184]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0000950170-25-083705:notes:185]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of April 25, 2025, we were in compliance with all covenants associated with the Senior Notes.

[0000950170-25-083705:notes:186]
As of April 25, 2025, our aggregate future principal debt maturities are as follows (in millions):

[0000950170-25-083705:notes:187]
| Fiscal Year |  | Amount |  |
| 2026 |  | $ | 750 |  |
| 2027 |  |  | — |  |
| 2028 |  |  | 550 |  |
| 2029 |  |  | — |  |
| Thereafter |  |  | 1,950 |  |
| Total |  | $ | 3,250 |  |

[0000950170-25-083705:notes:188]
Commercial Paper Program and Credit Facility

[0000950170-25-083705:notes:189]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of April 25, 2025 or April 26, 2024.

[0000950170-25-083705:notes:190]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in March 2025, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on March 5, 2030, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of April 25, 2025, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0000950170-25-083705:notes:191]
9. Leases

[0000950170-25-083705:notes:192]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of April 25, 2025, have remaining lease terms not exceeding 17 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of April 25, 2025, have remaining lease terms not exceeding 4 years. As of April 25, 2025, our automobile leases have remaining lease terms not exceeding 5 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0000950170-25-083705:notes:193]
The components of lease cost related to our operating leases were as follows (in millions):

[0000950170-25-083705:notes:194]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Operating lease cost |  | $ | 51 |  |  | $ | 53 |  |
| Variable lease cost |  |  | 15 |  |  |  | 15 |  |
| Total lease cost |  | $ | 66 |  |  | $ | 68 |  |

[0000950170-25-083705:notes:195]
Variable lease cost is primarily attributable to amounts paid to lessors for common area maintenance and utility charges under our real estate leases.

[0000950170-25-083705:notes:196]
The supplemental cash flow information related to our operating leases is as follows (in millions):

[0000950170-25-083705:notes:197]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 48 |  |  | $ | 50 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  | $ | 25 |  |  | $ | 17 |  |

[0000950170-25-083705:notes:198]
The supplemental balance sheet information related to our operating leases is as follows (in millions, except lease term and discount rate):

[0000950170-25-083705:notes:199]
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Other non-current assets |  | $ | 241 |  |  | $ | 247 |  |
| Total operating lease ROU assets |  | $ | 241 |  |  | $ | 247 |  |
| Accrued expenses |  | $ | 40 |  |  | $ | 40 |  |
| Other long-term liabilities |  |  | 216 |  |  |  | 220 |  |
| Total operating lease liabilities |  | $ | 256 |  |  | $ | 260 |  |
| Weighted Average Remaining Lease Term |  | 8.5 years |  |  | 9.2 years |  |
| Weighted Average Discount Rate |  |  | 3.4 | % |  |  | 3.1 | % |

[0000950170-25-083705:notes:200]
Future minimum operating lease payments as of April 25, 2025 are as follows (in millions):

[0000950170-25-083705:notes:201]
| Fiscal Year |  |  |  | Amount |  |
| 2026 |  |  |  | $ | 47 |  |
| 2027 |  |  |  |  | 42 |  |
| 2028 |  |  |  |  | 36 |  |
| 2029 |  |  |  |  | 31 |  |
| 2030 |  |  |  |  | 29 |  |
| Thereafter |  |  |  |  | 111 |  |
| Total lease payments |  |  |  |  | 296 |  |
| Less: Interest |  |  |  |  | (40 | ) |
| Total |  |  |  | $ | 256 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000950170-25-083705:notes:202]
10. Stockholders’ Equity

[0000950170-25-083705:notes:203]
Equity Incentive Programs

[0000950170-25-083705:notes:204]
The 2021 Plan — The 2021 Equity Incentive Plan (the 2021 Plan) was adopted by our Board of Directors and approved by the stockholders on September 10, 2021. The 2021 Plan replaced the 1999 Stock Option Plan (the 1999 Plan), and the 1999 Plan terminated effective as of September 11, 2021, except that the 1999 Plan will continue to govern awards outstanding thereunder as of the date of such plan’s termination and such awards will continue in force and effect until terminated pursuant to their terms. The 2021 Plan provides for the granting of incentive stock options, nonstatutory stock options, stock appreciation rights, restricted stock, restricted stock units, and performance awards to our employees, directors, and consultants.

[0000950170-25-083705:notes:205]
Under the 2021 Plan, the Board of Directors may grant to employees, nonemployee directors, consultants and independent advisors options to purchase shares of our common stock during their period of service. The exercise price for an incentive stock option and a nonstatutory option cannot be less than 100% of the fair market value of the common stock on the grant date. The 2021 Plan prohibits the repricing of any outstanding stock option or stock appreciation right after it has been granted or to cancel any outstanding stock option or stock appreciation right and immediately replace it with a new stock option or stock appreciation right with a lower exercise price unless approved by stockholders. RSUs granted under the 2021 Plan include time-based RSUs that generally vest over a four-year period with 25% vesting on the first anniversary of the grant date and 6.25% vesting quarterly thereafter. The Compensation Committee of the Board of Directors (the Compensation Committee) has the discretion to use different vesting schedules. In addition, performance-based RSUs may be granted under the 2021 Plan and are subject to performance criteria and vesting terms specified by the Compensation Committee.

[0000950170-25-083705:notes:206]
During fiscal 2025, the shares reserved for issuance under the Plan were increased by 3 million shares of common stock. As of April 25, 2025, 11 million shares were available for grant under the 2021 Plan.

[0000950170-25-083705:notes:207]
Restricted Stock Units

[0000950170-25-083705:notes:208]
In fiscal 2025, 2024 and 2023, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSUs cliff-vest at the end of a three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the third fiscal year, following the grant date. The number of shares that will be used to calculate the settlement amount for all of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in fiscal 2025 and 2024, and for most of the PBRSUs granted in fiscal 2023, the number of shares used to calculate

[0000950170-25-083705:notes:209]
the settlement amount will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. For the remaining half of the PBRSUs granted in the fiscal 2025 and 2024, the number of shares used to calculate the settlement amount will depend upon the Company's billings result average over the three-year performance period. The billings result average is computed based on achievement against annual billings targets, with each target set at the beginning of the respective fiscal year, during the three-year performance period. Billings for purposes of measuring the performance of these PBRSUs means the total obtained by adding net revenues as reported on the Company's Consolidated Statements of Income to the amount reported as the change in deferred revenue and financed unearned services revenue on the Consolidated Statements of Cash Flows for the applicable measurement period, excluding the impact of fluctuations in foreign currency exchange rates. The aggregate grant date fair value of all PBRSUs granted in fiscal 2025, 2024 and 2023 was $67 million, $39 million and $28 million, respectively, and these amounts are being recognized to compensation expense over the remaining performance/service periods.

[0000950170-25-083705:notes:210]
As of April 25, 2025, April 26, 2024 and April 28, 2023, there were approximately 1 million PBRSUs outstanding.

[0000950170-25-083705:notes:211]
The following table summarizes information related to RSUs, including PBRSUs (in millions, except for fair value):

[0000950170-25-083705:notes:212]
|  |  | Number ofShares |  |  | Weighted-AverageGrant Date Fair Value |  |
| Outstanding as of April 29, 2022 |  |  | 10 |  |  | $ | 64.09 |  |
| Granted |  |  | 8 |  |  | $ | 59.87 |  |
| Vested |  |  | (4 | ) |  | $ | 62.85 |  |
| Forfeited |  |  | (2 | ) |  | $ | 61.99 |  |
| Outstanding as of April 28, 2023 |  |  | 12 |  |  | $ | 62.08 |  |
| Granted |  |  | 5 |  |  | $ | 76.46 |  |
| Vested |  |  | (5 | ) |  | $ | 59.32 |  |
| Forfeited |  |  | (1 | ) |  | $ | 65.17 |  |
| Outstanding as of April 26, 2024 |  |  | 11 |  |  | $ | 68.87 |  |
| Granted |  |  | 4 |  |  | $ | 123.45 |  |
| Vested |  |  | (5 | ) |  | $ | 72.07 |  |
| Forfeited |  |  | (2 | ) |  | $ | 78.21 |  |
| Outstanding as of April 25, 2025 |  |  | 8 |  |  | $ | 91.30 |  |

[0000950170-25-083705:notes:213]
We primarily use the net share settlement approach upon vesting, where a portion of the shares are withheld as settlement of employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0000950170-25-083705:notes:214]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Shares withheld for taxes |  |  | 2 |  |  |  | 2 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 199 |  |  | $ | 128 |  |  | $ | 84 |  |

[0000950170-25-083705:notes:215]
Employee Stock Purchase Plan

[0000950170-25-083705:notes:216]
Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. On September 13, 2023, the ESPP was amended to increase the shares reserved for issuance by 3 million shares of common stock. As of April 25, 2025, 2 million shares were available for issuance. The following table summarizes activity related to the purchase rights issued under the ESPP (in millions):

[0000950170-25-083705:notes:217]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Shares issued under the ESPP |  |  | 2 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 108 |  |  | $ | 99 |  |

[0000950170-25-083705:notes:218]
Stock-Based Compensation Expense

[0000950170-25-083705:notes:219]
Stock-based compensation expense is included in the consolidated statements of income as follows (in millions):

[0000950170-25-083705:notes:220]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Cost of product revenues |  | $ | 6 |  |  | $ | 6 |  |  | $ | 5 |  |
| Cost of hardware support and other services revenues |  |  | 24 |  |  |  | 23 |  |  |  | 19 |  |
| Sales and marketing |  |  | 162 |  |  |  | 143 |  |  |  | 135 |  |
| Research and development |  |  | 135 |  |  |  | 132 |  |  |  | 111 |  |
| General and administrative |  |  | 59 |  |  |  | 53 |  |  |  | 42 |  |
| Total stock-based compensation expense |  | $ | 386 |  |  | $ | 357 |  |  | $ | 312 |  |

[0000950170-25-083705:notes:221]
As of April 25, 2025, total unrecognized compensation expense related to our equity awards was $573 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.0 years.

[0000950170-25-083705:notes:222]
Valuation Assumptions

[0000950170-25-083705:notes:223]
The valuation of RSUs and ESPP purchase rights and the underlying weighted-average assumptions are summarized as follows:

[0000950170-25-083705:notes:224]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| RSUs: |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 4.6 | % |  |  | 4.9 | % |  |  | 3.1 | % |
| Expected dividend yield |  |  | 1.8 | % |  |  | 2.6 | % |  |  | 2.9 | % |
| Weighted-average fair value per share granted |  | $ | 123.45 |  |  | $ | 76.46 |  |  | $ | 59.87 |  |
| ESPP: |  |  |  |  |  |  |  |  |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 5.2 | % |  |  | 4.9 | % |  |  | 3.9 | % |
| Expected volatility |  |  | 31 | % |  |  | 30 | % |  |  | 36 | % |
| Expected dividend yield |  |  | 1.7 | % |  |  | 2.8 | % |  |  | 2.9 | % |
| Weighted-average fair value per right granted |  | $ | 29.70 |  |  | $ | 17.37 |  |  | $ | 21.28 |  |

[0000950170-25-083705:notes:225]
Stock Repurchase Program

[0000950170-25-083705:notes:226]
As of April 25, 2025, our Board of Directors has authorized the repurchase of up to $17.1 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time.

[0000950170-25-083705:notes:227]
The following table summarizes activity related to the stock repurchase program for our fiscal years of 2025, 2024 and 2023 (in millions, except for per share amounts):

[0000950170-25-083705:notes:228]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Number of shares repurchased |  |  | 10.2 |  |  |  | 11.5 |  |  |  | 12.8 |  |
| Average price per share |  | $ | 112.55 |  |  | $ | 77.87 |  |  | $ | 66.42 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 50 |  |  | $ | 102 |  |  | $ | 45 |  |
| Stock repurchases allocated to retained earnings |  | $ | 1,100 |  |  | $ | 798 |  |  | $ | 805 |  |
| Remaining authorization at end of period |  | $ | 352 |  |  | $ | 502 |  |  | $ | 402 |  |

[0000950170-25-083705:notes:229]
Since the May 13, 2003 inception of our stock repurchase program through April 25, 2025, we repurchased a total of 382 million shares of our common stock at an average price of $43.93 per share, for an aggregate purchase price of $16.8 billion. On May 22, 2025 our Board of Directors authorized the repurchase of an additional $1.1 billion of our common stock.

[0000950170-25-083705:notes:230]
Preferred Stock

[0000950170-25-083705:notes:231]
Our Board of Directors has the authority to issue up to 5 million shares of preferred stock and to determine the price, rights, preferences, privileges, and restrictions, including voting rights, of those shares without any further vote or action by the stockholders. No shares of preferred stock were issued or outstanding in any period presented.

[0000950170-25-083705:notes:232]
Dividends

[0000950170-25-083705:notes:233]
The following is a summary of our fiscal 2025, 2024 and 2023 activities related to dividends on our common stock (in millions, except per share amounts).

[0000950170-25-083705:notes:234]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Dividends per share declared |  | $ | 2.08 |  |  | $ | 2.00 |  |  | $ | 2.00 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 130 |  |  | $ | 171 |  |  | $ | 106 |  |
| Dividend payments allocated to retained earnings |  | $ | 294 |  |  | $ | 245 |  |  | $ | 326 |  |

[0000950170-25-083705:notes:235]
On May 22, 2025, we declared a cash dividend of $0.52 per share of common stock, payable on July 23, 2025 to shareholders of record as of the close of business on July 3, 2025. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by the Company to be legally authorized under the laws of the state in which we are incorporated.

[0000950170-25-083705:notes:236]
Accumulated Other Comprehensive Income (Loss)

[0000950170-25-083705:notes:237]
Changes in accumulated other comprehensive income (loss) (AOCI) by component, net of tax, are summarized below (in millions):

[0000950170-25-083705:notes:238]
|  |  | ForeignCurrencyTranslationAdjustments |  |  | DefinedBenefitObligationAdjustments |  |  | UnrealizedGains(Losses) on Available-for-SaleSecurities |  |  | UnrealizedGains(Losses) onCash Flow Hedges |  |  | Total |  |
| Balance as of April 29, 2022 |  | $ | (44 | ) |  | $ | (1 | ) |  | $ | — |  |  | $ | 1 |  |  | $ | (44 | ) |
| Other comprehensive loss, net of tax |  |  | (4 | ) |  |  | (2 | ) |  |  | — |  |  |  | (6 | ) |  |  | (12 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | 5 |  |
| Total other comprehensive loss |  |  | (4 | ) |  |  | (2 | ) |  |  | — |  |  |  | (1 | ) |  |  | (7 | ) |
| Balance as of April 28, 2023 |  |  | (48 | ) |  |  | (3 | ) |  |  | — |  |  |  | — |  |  |  | (51 | ) |
| Other comprehensive income (loss), net of tax |  |  | (5 | ) |  |  | (4 | ) |  |  | — |  |  |  | 2 |  |  |  | (7 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |
| Total other comprehensive income (loss), net of tax |  |  | (5 | ) |  |  | (4 | ) |  |  | — |  |  |  | 1 |  |  |  | (8 | ) |
| Balance as of April 26, 2024 |  |  | (53 | ) |  |  | (7 | ) |  |  | — |  |  |  | 1 |  |  |  | (59 | ) |
| Other comprehensive income (loss), net of tax |  |  | (3 | ) |  |  | (2 | ) |  |  | 1 |  |  |  | (2 | ) |  |  | (6 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |
| Total other comprehensive income (loss), net of tax |  |  | (3 | ) |  |  | (2 | ) |  |  | 1 |  |  |  | (3 | ) |  |  | (7 | ) |
| Balance as of April 25, 2025 |  | $ | (56 | ) |  | $ | (9 | ) |  | $ | 1 |  |  | $ | (2 | ) |  | $ | (66 | ) |

[0000950170-25-083705:notes:239]
The amounts reclassified out of AOCI are as follows (in millions):

[0000950170-25-083705:notes:240]
|  |  | Year Ended |  |  | Statements of Income |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |  | Classification |
| Realized (gains) losses on cash flow hedges |  | $ | (1 | ) |  | $ | (1 | ) |  | $ | 5 |  |  | Net revenues |
| Total reclassifications |  | $ | (1 | ) |  | $ | (1 | ) |  | $ | 5 |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-25-083705:notes:241]
11. Derivatives and Hedging Activities

[0000950170-25-083705:notes:242]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of April 25, 2025 or April 26, 2024. All contracts have a maturity of less than 12 months.

[0000950170-25-083705:notes:243]
The notional amount of our outstanding U.S. dollar equivalent foreign currency exchange forward contracts consisted of the following (in millions):

[0000950170-25-083705:notes:244]
|  |  | April 25, 2025 |  |  | April 26,2024 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 81 |  |  | $ | 71 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 790 |  |  | $ | 881 |  |
| Forward contracts purchased |  | $ | — |  |  | $ | 11 |  |

[0000950170-25-083705:notes:245]
The effect of cash flow hedges recognized in net revenues is presented in the consolidated statements of comprehensive income and Note 10 – Stockholders’ Equity.

[0000950170-25-083705:notes:246]
The effect of derivative instruments not designated as hedging instruments recognized in other income, net on our consolidated statements of income was as follows (in millions):

[0000950170-25-083705:notes:247]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
|  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 38 |  |  | $ | (59 | ) |  | $ | 4 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-25-083705:notes:248]
12. Restructuring Charges

[0000950170-25-083705:notes:249]
In the fourth quarter of fiscal 2025, management approved a restructuring plan to redirect resources to the highest return activities and reduce costs. Charges related to the plan consisted primarily of employee severance-related costs and lease termination charges. The activities under the plan are expected to be substantially completed by the end of the first quarter of fiscal 2026.

[0000950170-25-083705:notes:250]
In the first nine months of fiscal 2025, management approved restructuring plans to redirect resources to the highest return activities and reduce costs, which included in the third quarter of fiscal 2025, a plan approved related to the sale of our cloud optimization and management software business known as Spot by NetApp. Charges related to the plans consisted primarily of employee severance-related costs. The activities under these plans were substantially complete by the end of fiscal 2025.

[0000950170-25-083705:notes:251]
In fiscal 2024, management approved restructuring plans to redirect resources to the highest return activities and reduce costs. Charges related to the plans consisted primarily of employee severance-related costs. One of the plans also included termination of certain real estate leases in various countries, resulting in lease termination charges. The activities under these plans were substantially complete by the end of fiscal 2024.

[0000950170-25-083705:notes:252]
In fiscal 2023, we executed, or continued to execute, restructuring plans to redirect resources to the highest return activities, reduce costs and establish our international headquarters in Cork, Ireland. These plans resulted in restructuring charges comprised primarily of employee severance-related costs and legal and tax-related professional fees. Activities under these plans were substantially complete by the end of fiscal 2023.

[0000950170-25-083705:notes:253]
Activities related to our restructuring plans are summarized as follows (in millions):

[0000950170-25-083705:notes:254]
|  |  | Total |  |
| Balance as of April 29, 2022 |  | $ | 3 |  |
| Net charges |  |  | 120 |  |
| Cash payments |  |  | (87 | ) |
| Balance as of April 28, 2023 |  |  | 36 |  |
| Net charges |  |  | 44 |  |
| Cash payments |  |  | (70 | ) |
| Balance as of April 26, 2024 |  |  | 10 |  |
| Net charges |  |  | 83 |  |
| Cash payments |  |  | (42 | ) |
| Balance as of April 25, 2025 |  | $ | 51 |  |

[0000950170-25-083705:notes:255]
Liabilities for our restructuring activities are included in accrued expenses in our consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-25-083705:notes:256]
13. Income Taxes

[0000950170-25-083705:notes:257]
Income before income taxes is as follows (in millions):

[0000950170-25-083705:notes:258]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Domestic |  | $ | 606 |  |  | $ | 472 |  |  | $ | 420 |  |
| Foreign |  |  | 777 |  |  |  | 791 |  |  |  | 646 |  |
| Total |  | $ | 1,383 |  |  | $ | 1,263 |  |  | $ | 1,066 |  |

[0000950170-25-083705:notes:259]
The provision (benefit) for income taxes consists of the following (in millions):

[0000950170-25-083705:notes:260]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Current: |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 131 |  |  | $ | 89 |  |  | $ | 209 |  |
| State |  |  | 38 |  |  |  | 25 |  |  |  | 39 |  |
| Foreign |  |  | 128 |  |  |  | 110 |  |  |  | 150 |  |
| Total current |  |  | 297 |  |  |  | 224 |  |  |  | 398 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (102 | ) |  |  | 24 |  |  |  | (44 | ) |
| State |  |  | (16 | ) |  |  | 6 |  |  |  | (3 | ) |
| Foreign |  |  | 18 |  |  |  | 23 |  |  |  | (559 | ) |
| Total deferred |  |  | (100 | ) |  |  | 53 |  |  |  | (606 | ) |
| Provision (benefit) for income taxes |  | $ | 197 |  |  | $ | 277 |  |  | $ | (208 | ) |

[0000950170-25-083705:notes:261]
During the fourth quarter of fiscal 2025, the Internal Revenue Service (“IRS”) substantially completed the examination of our fiscal 2018 and fiscal 2019 U.S. income tax returns, and we recognized a tax benefit of $36 million attributable to the release of related tax reserves.

[0000950170-25-083705:notes:262]
During the second quarter of fiscal 2023, we completed an intra-entity asset transfer of certain IP to our international headquarters (the “IP Transfer”). The transaction resulted in a step-up of tax-deductible basis in the transferred assets, and accordingly, created a temporary difference where the tax basis exceeded the financial statement basis of such intangible assets, which resulted in the recognition of a discrete tax benefit and related deferred tax asset of $524 million during the second quarter of fiscal 2023.  Management applied significant judgment when determining the fair value of the IP, which serves as the tax basis of the deferred tax asset. With the assistance of third-party valuation specialists, the fair value of the IP was determined principally based on the present value of projected cash flows related to the IP which reflects management’s assumptions regarding projected revenues, earnings before interest and taxes, and a discount rate. The tax-deductible amortization related to the transferred IP rights will be recognized in future periods and any amortization that is unused in a particular year can be carried forward indefinitely. The deferred tax asset and the tax benefit were measured based on the enacted tax rates expected to apply in the years the asset is expected to be realized. We

[0000950170-25-083705:notes:263]
expect to realize the deferred tax asset resulting from the IP Transfer and will assess the realizability of the deferred tax asset quarterly.

[0000950170-25-083705:notes:264]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We did not believe that our Danish subsidiary was liable for such withholding tax and filed an appeal with the Danish Tax Tribunal, which issued a ruling in favor of NetApp in December 2011. However, following escalations within the Danish judicial system over the course of numerous years, on January 9, 2023, the Danish Supreme Court ruled the 2005 dividend was subject to withholding tax while the smaller 2006 distribution would not be subject to withholding tax. The Danish Supreme Court ruling on the distributions declared in 2005 and 2006 is non-appealable. During fiscal 2023, we recorded $69 million of discrete tax expense, which includes $23 million of withholding tax and $46 million of interest.

[0000950170-25-083705:notes:265]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0000950170-25-083705:notes:266]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Tax computed at federal statutory rate |  | $ | 290 |  |  | $ | 265 |  |  | $ | 224 |  |
| State income taxes, net of federal benefit |  |  | 14 |  |  |  | 22 |  |  |  | 24 |  |
| Foreign earnings in lower tax jurisdictions |  |  | (14 | ) |  |  | (40 | ) |  |  | (43 | ) |
| Stock-based compensation |  |  | (21 | ) |  |  | 12 |  |  |  | 25 |  |
| Research and development credits |  |  | (31 | ) |  |  | (22 | ) |  |  | (24 | ) |
| Benefit for foreign derived intangible income |  |  | (28 | ) |  |  | — |  |  |  | — |  |
| Global minimum tax on intangible income |  |  | 12 |  |  |  | 46 |  |  |  | 61 |  |
| Tax charges (benefits) from integration of acquired companies |  |  | 1 |  |  |  | 4 |  |  |  | (27 | ) |
| Tax benefit due to IP Transfer |  |  | — |  |  |  | — |  |  |  | (524 | ) |
| Resolution of income tax matters (1) |  |  | (39 | ) |  |  | (4 | ) |  |  | 71 |  |
| Other |  |  | 13 |  |  |  | (6 | ) |  |  | 5 |  |
| Provision (benefit) for income taxes |  | $ | 197 |  |  | $ | 277 |  |  | $ | (208 | ) |

[0000950170-25-083705:notes:267]
(1)
During fiscal 2025, we recognized a tax benefit related to the IRS examination of our fiscal 2018 and fiscal 2019 U.S. income tax returns. During fiscal 2024, we recognized a tax benefit related to the lapse of statute of limitations for certain issues in our fiscal 2020 U.S. tax returns. During fiscal 2023, we recognized tax expense related to a Danish Supreme Court decision related to withholding tax on a 2005 distribution as well as tax expense related to the IRS examination of our fiscal 2018 and 2019 U.S. tax returns.

[0000950170-25-083705:notes:268]
The components of our deferred tax assets and liabilities are as follows (in millions):

[0000950170-25-083705:notes:269]
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Deferred tax assets: |  |  |  |  |  |  |
| Reserves and accruals |  | $ | 188 |  |  | $ | 126 |  |
| Net operating loss and credit carryforwards |  |  | 138 |  |  |  | 129 |  |
| Stock-based compensation |  |  | 25 |  |  |  | 25 |  |
| Deferred revenue and financed unearned services revenue |  |  | 250 |  |  |  | 252 |  |
| Acquired intangibles |  |  | 483 |  |  |  | 499 |  |
| Capitalized research and development (1) |  |  | 198 |  |  |  | 141 |  |
| Other |  |  | 6 |  |  |  | 12 |  |
| Gross deferred tax assets |  |  | 1,288 |  |  |  | 1,184 |  |
| Valuation allowance |  |  | (119 | ) |  |  | (121 | ) |
| Deferred tax assets, net of valuation allowance |  |  | 1,169 |  |  |  | 1,063 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Prepaids and accruals |  |  | 87 |  |  |  | 90 |  |
| Acquired intangibles |  |  | 84 |  |  |  | 68 |  |
| Property and equipment |  |  | 26 |  |  |  | 36 |  |
| Other |  |  | 6 |  |  |  | 3 |  |
| Total deferred tax liabilities |  |  | 203 |  |  |  | 197 |  |
| Deferred tax assets, net of valuation allowance and deferred tax liabilities |  | $ | 966 |  |  | $ | 866 |  |

[0000950170-25-083705:notes:270]
(1)
As required under the Tax Cuts and Jobs Act of 2017, research and development expenditures are capitalized and amortized beginning in our fiscal 2023.

[0000950170-25-083705:notes:271]
The valuation allowance decreased by $2 million in fiscal 2025. The decrease is mainly attributable to corresponding changes in deferred tax assets, primarily certain state tax credit carryforwards.

[0000950170-25-083705:notes:272]
As of April 25, 2025, we have federal net operating loss carryforwards of $9 million. In addition, we have gross state net operating loss and tax credit carryforwards of $4 million and $146 million, respectively. The majority of the state credit carryforwards are California research credits which are offset by a valuation allowance as we believe it is more likely than not that these credits will not be utilized. We also have $9 million of U.S. foreign tax credit carryforwards and $33 million of foreign tax credit carryforwards of which the majority were generated by our Dutch subsidiary and are fully offset by a valuation allowance. Certain acquired net operating loss carryforwards are subject to an annual limitation under Internal Revenue Code Section 382, but are expected to be realized with the exception of those which have a valuation allowance. The state and foreign net operating loss carryforwards and credits will expire in various years from fiscal 2026 through 2042. The federal net operating loss carryforwards, the California research credit, and the Dutch foreign tax credit carryforwards do not expire.

[0000950170-25-083705:notes:273]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0000950170-25-083705:notes:274]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Balance at beginning of period |  | $ | 220 |  |  | $ | 222 |  |  | $ | 220 |  |
| Additions based on tax positions related to the current year |  |  | 8 |  |  |  | 7 |  |  |  | 9 |  |
| Additions for tax positions of prior years |  |  | 4 |  |  |  | — |  |  |  | 1 |  |
| Decreases for tax positions of prior years |  |  | (25 | ) |  |  | (2 | ) |  |  | (5 | ) |
| Settlements |  |  | (139 | ) |  |  | (7 | ) |  |  | (3 | ) |
| Balance at end of period |  | $ | 68 |  |  | $ | 220 |  |  | $ | 222 |  |

[0000950170-25-083705:notes:275]
As of April 25, 2025, we had $68 million of gross unrecognized tax benefits, of which $45 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $47 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0000950170-25-083705:notes:276]
We recognized expense for increases to accrued interest and penalties related to unrecognized tax benefits in the income tax provision of $4 million, $11 million and $7 million, respectively, in fiscal 2025, fiscal 2024 and fiscal 2023. Accrued interest and penalties of $8 million and $33 million were recorded in the consolidated balance sheets as of April 25, 2025 and April 26, 2024, respectively.

[0000950170-25-083705:notes:277]
The Organisation for Economic Co-operation and Development (“OECD”) recently enacted model rules for a new global minimum tax framework known as Pillar Two. These rules have been agreed to by most OECD members. The OECD has since issued administrative guidance providing transition and safe harbor rules around the implementation of Pillar Two rules. On February 1, 2023, the FASB indicated that they believe taxes imposed under Pillar Two is an alternative minimum tax. Accordingly, deferred tax assets and liabilities associated with the minimum tax would not be recognized or adjusted for the estimated future effects of the minimum tax but would be recognized in the period incurred. We are currently subject to Pillar Two rules starting in our fiscal year 2025. As of April 25, 2025, Pillar Two taxes do not have a significant impact on our financial statements, particularly due to the safe harbor relief during the transition period, but we are still closely monitoring developments.

[0000950170-25-083705:notes:278]
The tax years that remain subject to examination for our major tax jurisdictions are shown below:

[0000950170-25-083705:notes:279]
Fiscal Years Subject to Examination for Major Tax Jurisdictions at April 25, 2025

[0000950170-25-083705:notes:280]
| 2022 — 2025 |  | United States — federal income tax |
| 2020 — 2025 |  | United States — state and local income tax |
| 2020 — 2025 |  | Australia |
| 2018 — 2025 |  | Germany |
| 2007 — 2025 |  | India |
| 2019 — 2025 |  | The Netherlands |
| 2018 — 2025 |  | Canada |
| 2020 — 2025 |  | Japan |
| 2019 — 2025 |  | Cyprus |
| 2022 — 2025 |  | United Kingdom |
| 2023 — 2025 |  | France |
| 2022 — 2025 |  | Ireland |

[0000950170-25-083705:notes:281]
We are currently undergoing various income tax audits in the U.S. and audits in several foreign tax jurisdictions. Transfer pricing calculations are key topics under these audits and are often subject to dispute and appeals.

[0000950170-25-083705:notes:282]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. As a result of uncertainties regarding tax audits and their possible outcomes, an estimate of the range of possible impacts to unrecognized tax benefits in the next twelve months cannot be made at this time.

[0000950170-25-083705:notes:283]
As of April 25, 2025, we continue to record a deferred tax liability related to state taxes on unremitted earnings of certain foreign entities. We estimate the unrecognized deferred tax liability related to the earnings we expect to be indefinitely reinvested to be immaterial. We will continue to monitor our plans to indefinitely reinvest undistributed earnings of foreign subsidiaries and will assess the related unrecognized deferred tax liability considering our ongoing projected global cash requirements, tax consequences associated with repatriation and any U.S. or foreign government programs designed to influence remittances.


## us-gaap:EarningsPerShareTextBlock

[0000950170-25-083705:notes:284]
14. Net Income per Share

[0000950170-25-083705:notes:285]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0000950170-25-083705:notes:286]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,186 |  |  | $ | 986 |  |  | $ | 1,274 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 204 |  |  |  | 208 |  |  |  | 217 |  |
| Dilutive impact of employee equity award plans |  |  | 5 |  |  |  | 5 |  |  |  | 3 |  |
| Shares used in diluted computation |  |  | 209 |  |  |  | 213 |  |  |  | 220 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 5.81 |  |  | $ | 4.74 |  |  | $ | 5.87 |  |
| Diluted |  | $ | 5.67 |  |  | $ | 4.63 |  |  | $ | 5.79 |  |

[0000950170-25-083705:notes:287]
The following table presents the numbers of potential shares of common stock from outstanding employee equity awards that have been excluded from the computation of diluted net income per share, as their inclusion would have had an anti-dilutive effect, for the periods presented (in millions):

[0000950170-25-083705:notes:288]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Employee equity award plans |  |  | 1 |  |  |  | 2 |  |  |  | 6 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-25-083705:notes:289]
15. Segment, Geographic, and Significant Customer Information

[0000950170-25-083705:notes:290]
Our operations are organized into two segments: Hybrid Cloud and Public Cloud. The two segments are based on the information reviewed by our Chief Operating Decision Maker (CODM), who is the Chief Executive Officer, to evaluate results and allocate resources. The CODM measures performance of each segment based on segment revenue and segment gross profit by comparing actual revenue and gross profit results to historical results and previously forecasted financial information. We do not allocate to our segments certain cost of revenues which we manage at the corporate level. These unallocated costs include stock-based compensation and amortization of intangible assets. We do not allocate assets to our segments.

[0000950170-25-083705:notes:291]
Hybrid Cloud offers a unified data storage portfolio of storage management and infrastructure solutions that helps customers modernize their data centers. This portfolio accommodates both structured and unstructured data with unified storage optimized for flash, disk, and cloud storage, capable of handling data-intensive workloads and applications. Hybrid Cloud includes software, hardware, and related support, along with professional and other services.

[0000950170-25-083705:notes:292]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage, data services, and operational services. Public Cloud includes certain reseller arrangements in which the timing of our consideration follows the end user consumption of the reseller services.

[0000950170-25-083705:notes:293]
Segment Revenues and Gross Profit

[0000950170-25-083705:notes:294]
Financial information by segment is as follows (in millions, except percentages):

[0000950170-25-083705:notes:295]
|  | Year Ended April 25, 2025 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Product revenues | $ | 3,040 |  |  | $ | — |  |  | $ | 3,040 |  |
| Support revenues |  | 2,512 |  |  |  | — |  |  |  | 2,512 |  |
| Professional and other services revenues |  | 355 |  |  |  | — |  |  |  | 355 |  |
| Public cloud revenues |  | — |  |  |  | 665 |  |  |  | 665 |  |
| Net revenues |  | 5,907 |  |  |  | 665 |  |  |  | 6,572 |  |
| Cost of product revenues |  | 1,278 |  |  |  | — |  |  |  | 1,278 |  |
| Cost of support revenues |  | 197 |  |  |  | — |  |  |  | 197 |  |
| Cost of professional and other services revenues |  | 261 |  |  |  | — |  |  |  | 261 |  |
| Cost of public cloud revenues |  | — |  |  |  | 165 |  |  |  | 165 |  |
| Segment cost of revenues |  | 1,736 |  |  |  | 165 |  |  |  | 1,901 |  |
| Segment gross profit | $ | 4,171 |  |  | $ | 500 |  |  | $ | 4,671 |  |
| Segment gross margin |  | 70.6 | % |  |  | 75.2 | % |  |  | 71.1 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 58 |  |
| Total gross profit |  |  |  |  |  |  | $ | 4,613 |  |
| Total gross margin |  |  |  |  |  |  |  | 70.2 | % |
| 1 Unallocated cost of revenues are composed of $30 million of stock-based compensation expense and $28 million of amortization of intangible assets. |  |

[0000950170-25-083705:notes:296]
|  | Year Ended April 26, 2024 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Product revenues | $ | 2,849 |  |  | $ | — |  |  | $ | 2,849 |  |
| Support revenues |  | 2,488 |  |  |  | — |  |  |  | 2,488 |  |
| Professional and other services revenues |  | 320 |  |  |  | — |  |  |  | 320 |  |
| Public cloud revenues |  | — |  |  |  | 611 |  |  |  | 611 |  |
| Net revenues |  | 5,657 |  |  |  | 611 |  |  |  | 6,268 |  |
| Cost of product revenues |  | 1,131 |  |  |  | — |  |  |  | 1,131 |  |
| Cost of support revenues |  | 195 |  |  |  | — |  |  |  | 195 |  |
| Cost of professional and other services revenues |  | 243 |  |  |  | — |  |  |  | 243 |  |
| Cost of public cloud revenues |  | — |  |  |  | 203 |  |  |  | 203 |  |
| Segment cost of revenues |  | 1,569 |  |  |  | 203 |  |  |  | 1,772 |  |
| Segment gross profit | $ | 4,088 |  |  | $ | 408 |  |  | $ | 4,496 |  |
| Segment gross margin |  | 72.3 | % |  |  | 66.8 | % |  |  | 71.7 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 63 |  |
| Total gross profit |  |  |  |  |  |  | $ | 4,433 |  |
| Total gross margin |  |  |  |  |  |  |  | 70.7 | % |
| 1 Unallocated cost of revenues are composed of $29 million of stock-based compensation expense and $34 million of amortization of intangible assets. |  |

[0000950170-25-083705:notes:297]
|  | Year Ended April 28, 2023 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Product revenues | $ | 3,049 |  |  | $ | — |  |  | $ | 3,049 |  |
| Support revenues |  | 2,419 |  |  |  | — |  |  |  | 2,419 |  |
| Professional and other services revenues |  | 319 |  |  |  | — |  |  |  | 319 |  |
| Public cloud revenues |  | — |  |  |  | 575 |  |  |  | 575 |  |
| Net revenues |  | 5,787 |  |  |  | 575 |  |  |  | 6,362 |  |
| Cost of product revenues |  | 1,511 |  |  |  | — |  |  |  | 1,511 |  |
| Cost of support revenues |  | 181 |  |  |  | — |  |  |  | 181 |  |
| Cost of professional and other services revenues |  | 211 |  |  |  | — |  |  |  | 211 |  |
| Cost of public cloud revenues |  | — |  |  |  | 184 |  |  |  | 184 |  |
| Segment cost of revenues |  | 1,903 |  |  |  | 184 |  |  |  | 2,087 |  |
| Segment gross profit | $ | 3,884 |  |  | $ | 391 |  |  | $ | 4,275 |  |
| Segment gross margin |  | 67.1 | % |  |  | 68.0 | % |  |  | 67.2 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 66 |  |
| Total gross profit |  |  |  |  |  |  | $ | 4,209 |  |
| Total gross margin |  |  |  |  |  |  |  | 66.2 | % |
| 1 Unallocated cost of revenues are composed of $24 million of stock-based compensation expense and $42 million of amortization of intangible assets. |  |

[0000950170-25-083705:notes:298]
Geographical Revenues and Certain Assets

[0000950170-25-083705:notes:299]
Revenues summarized by geographic region are as follows (in millions):

[0000950170-25-083705:notes:300]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| United States, Canada and Latin America (Americas) |  | $ | 3,347 |  |  | $ | 3,193 |  |  | $ | 3,237 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 2,204 |  |  |  | 2,104 |  |  |  | 2,148 |  |
| Asia Pacific (APAC) |  |  | 1,021 |  |  |  | 971 |  |  |  | 977 |  |
| Net revenues |  | $ | 6,572 |  |  | $ | 6,268 |  |  | $ | 6,362 |  |

[0000950170-25-083705:notes:301]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $3,092 million, $2,952 million and $3,007 million during fiscal 2025, 2024 and 2023, respectively.

[0000950170-25-083705:notes:302]
The majority of our assets, excluding cash, cash equivalents, short-term investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents and short-term investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0000950170-25-083705:notes:303]
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| U.S. |  | $ | 1,320 |  |  | $ | 1,142 |  |
| International |  |  | 2,526 |  |  |  | 2,110 |  |
| Total |  | $ | 3,846 |  |  | $ | 3,252 |  |

[0000950170-25-083705:notes:304]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment information for geographic areas based on the physical location of the assets (in millions):

[0000950170-25-083705:notes:305]
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| U.S. |  | $ | 344 |  |  | $ | 378 |  |
| International |  |  | 219 |  |  |  | 226 |  |
| Total |  | $ | 563 |  |  | $ | 604 |  |

[0000950170-25-083705:notes:306]
Significant Customers

[0000950170-25-083705:notes:307]
The following customers, each of which is a distributor, accounted for 10% or more of our net revenues:

[0000950170-25-083705:notes:308]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Arrow Electronics, Inc. |  |  | 21 | % |  |  | 22 | % |  |  | 24 | % |
| TD Synnex Corporation (previously presented as Tech Data Corporation) |  |  | 24 | % |  |  | 22 | % |  |  | 21 | % |

[0000950170-25-083705:notes:309]
The following customers accounted for 10% or more of accounts receivable:

[0000950170-25-083705:notes:310]
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Arrow Electronics, Inc. |  |  | 10 | % |  |  | 10 | % |
| TD Synnex Corporation |  |  | 27 | % |  |  | 26 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-25-083705:notes:311]
16. Employee Benefits and Deferred Compensation

[0000950170-25-083705:notes:312]
Employee 401(k) Plan

[0000950170-25-083705:notes:313]
Our 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit. We match 100% of the first 2% of eligible earnings an employee contributes to the 401(k) Plan, and then match 50% of the next 4% of eligible earnings an employee contributes. An employee receives the full 4% match when he/she contributes at least 6% of his/her eligible earnings, up to a maximum calendar year matching contribution of $6,000. Our employer matching contributions to the 401(k) Plan were as follows (in millions):

[0000950170-25-083705:notes:314]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| 401(k) matching contributions |  | $ | 30 |  |  | $ | 29 |  |  | $ | 33 |  |

[0000950170-25-083705:notes:315]
Deferred Compensation Plan

[0000950170-25-083705:notes:316]
We have a non-qualified deferred compensation plan that allows a group of employees within the U.S. to contribute base salary and commissions or incentive compensation on a tax deferred basis in excess of the IRS limits imposed on 401(k) plans. The marketable securities related to these investments are held in a Rabbi Trust. The related deferred compensation plan assets and liabilities under the non-qualified deferred compensation plan were as follows (in millions):

[0000950170-25-083705:notes:317]
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Deferred compensation plan assets |  | $ | 41 |  |  | $ | 38 |  |
| Deferred compensation liabilities reported as: |  |  |  |  |  |  |
| Accrued expenses |  | $ | 7 |  |  | $ | 6 |  |
| Other long-term liabilities |  | $ | 34 |  |  | $ | 32 |  |

[0000950170-25-083705:notes:318]
Defined Benefit Plans

[0000950170-25-083705:notes:319]
We maintain various defined benefit plans to provide termination and postretirement benefits to certain eligible employees outside of the U.S. We also provide disability benefits to certain eligible employees in the U.S. Eligibility is determined based on the terms of our plans and local statutory requirements.

[0000950170-25-083705:notes:320]
The funded status of our defined benefit plans, which is recognized in other long-term liabilities in our consolidated balance sheets, was as follows (in millions):

[0000950170-25-083705:notes:321]
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Fair value of plan assets |  | $ | 66 |  |  | $ | 55 |  |
| Benefit obligations |  |  | (106 | ) |  |  | (91 | ) |
| Unfunded obligations |  | $ | (40 | ) |  | $ | (36 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-25-083705:notes:322]
17. Commitments and Contingencies

[0000950170-25-083705:notes:323]
Purchase Orders and Other Commitments

[0000950170-25-083705:notes:324]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of April 25, 2025, we had $0.4 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 25, 2025 and April 26, 2024, such liability amounted to $22 million and $20 million, respectively, and is included in accrued expenses in our consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0000950170-25-083705:notes:325]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of April 25, 2025, we had $0.6 billion in other purchase obligations.

[0000950170-25-083705:notes:326]
Of the total $1.0 billion in purchase commitments, $0.6 billion is due in fiscal 2026, with the remainder due thereafter.

[0000950170-25-083705:notes:327]
Financing Guarantees

[0000950170-25-083705:notes:328]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $65 million, $67 million and $38 million of receivables during fiscal 2025, 2024 and 2023, respectively.

[0000950170-25-083705:notes:329]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0000950170-25-083705:notes:330]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of April 25, 2025 and April 26, 2024, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-25-083705:notes:331]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of April 25, 2025, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0000950170-25-083705:notes:332]
Legal Contingencies

[0000950170-25-083705:notes:333]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0000950170-25-083705:notes:334]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigation brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0000950170-25-083705:notes:335]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of April 25, 2025 related to such matters.


## dei:AuditorOpinionTextBlock

[0000950170-25-083705:notes:336]
We have audited the accompanying consolidated balance sheets of NetApp, Inc. and its subsidiaries (the "Company") as of April 25, 2025, and April 26, 2024, the related consolidated statements of income, comprehensive income, stockholders' equity, and cash flows, for each of the three years in the period ended April 25, 2025, and the related notes (collectively referred to as the "financial statements"). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of April 25, 2025, and April 26, 2024, and the results of its operations and its cash flows for each of the three years in the period ended April 25, 2025, in conformity with accounting principles generally accepted in the United States of America.

[0000950170-25-083705:notes:337]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of April 25, 2025, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission and our report dated June 9, 2025, expressed an unqualified opinion on the Company's internal control over financial reporting.
