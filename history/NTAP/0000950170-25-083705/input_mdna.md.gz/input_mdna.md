# NTAP MD&A — 0000950170-25-083705


## mdna

[0000950170-25-083705:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000950170-25-083705:mdna:2]
The following discussion of our financial condition and results of operations should be read together with the financial statements and the accompanying notes set forth under Part II, Item 8. – Financial Statements and Supplementary Data. The following discussion also contains trend information and other forward-looking statements that involve a number of risks and uncertainties. The Risk Factors set forth in Part I, Item 1A. – Risk Factors are hereby incorporated into the discussion by reference.

[0000950170-25-083705:mdna:3]
Executive Overview

[0000950170-25-083705:mdna:4]
Our Company

[0000950170-25-083705:mdna:5]
NetApp helps customers make their data infrastructure more seamless, more dynamic, and higher performing. We were incorporated in 1992, are headquartered in San Jose, California, and provide a full range of enterprise-class software, systems and services that customers use to transform their data infrastructures across data types, workloads, and environments to realize business possibilities.

[0000950170-25-083705:mdna:6]
We leverage over thirty years of innovation to make data infrastructure intelligent. Our unified data storage solutions deliver flexible, simplified, and silo-free infrastructure. Our active data management capabilities focus on security, compliance, and sustainability, while our adaptive operations enhance performance, efficiency, and productivity. Our extensive portfolio integrates hybrid and multi-cloud environments, addressing key customer priorities such as modernizing legacy systems, enhancing resilience against ransomware, and developing scalable, high-performance data pipelines for artificial intelligence (AI) workloads.

[0000950170-25-083705:mdna:7]
NetApp empowers customers to harness their data for accelerated innovation, improved operations, and competitive advantage. Our unified data storage solutions provide the flexibility to consistently and easily store any data type and support any workload. As the only enterprise-grade storage service natively embedded in the world’s largest clouds, we power data across Amazon AWS, Microsoft Azure, and Google Cloud. Our integrated data services enable active data management, security, protection, governance, and sustainability. Additionally, our operational services support adaptive operations across infrastructure, applications, and teams. Together with our Hybrid Cloud products, these services enable customers to construct a seamless, intelligent data infrastructure across hybrid multi-cloud environments.

[0000950170-25-083705:mdna:8]
Our operations are organized into two segments: Hybrid Cloud and Public Cloud.

[0000950170-25-083705:mdna:9]
Hybrid Cloud offers a unified data storage portfolio of storage management and infrastructure solutions that helps customers modernize their data centers. Our Hybrid Cloud portfolio accommodates both structured and unstructured data with unified storage optimized for flash, disk, and cloud storage, capable of handling data-intensive workloads and applications. Hybrid Cloud includes software, hardware, and related support, along with professional and other services.

[0000950170-25-083705:mdna:10]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage, data services, and operational services. These services are generally available on the leading public clouds, including Amazon AWS, Microsoft Azure, and Google Cloud.

[0000950170-25-083705:mdna:11]
Financial Results and Key Performance Metrics Overview

[0000950170-25-083705:mdna:12]
The following table provides an overview of key financial metrics for each of the last three fiscal years (in millions, except per share amounts and percentages):

[0000950170-25-083705:mdna:13]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |  | April 28, 2023 |  |
| Net revenues |  | $ | 6,572 |  |  | $ | 6,268 |  |  | $ | 6,362 |  |
| Gross profit |  | $ | 4,613 |  |  | $ | 4,433 |  |  | $ | 4,209 |  |
| Gross margin |  |  | 70 | % |  |  | 71 | % |  |  | 66 | % |
| Income from operations |  | $ | 1,337 |  |  | $ | 1,214 |  |  | $ | 1,018 |  |
| Income from operations as a percentage of net revenues |  |  | 20 | % |  |  | 19 | % |  |  | 16 | % |
| Provision (benefit) for income taxes |  | $ | 197 |  |  | $ | 277 |  |  | $ | (208 | ) |
| Net income |  | $ | 1,186 |  |  | $ | 986 |  |  | $ | 1,274 |  |
| Diluted net income per share |  | $ | 5.67 |  |  | $ | 4.63 |  |  | $ | 5.79 |  |
| Net cash provided by operating activities |  | $ | 1,506 |  |  | $ | 1,685 |  |  | $ | 1,107 |  |

[0000950170-25-083705:mdna:14]
|  |  | April 25, 2025 |  |  | April 26,2024 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 4,536 |  |  | $ | 4,234 |  |

[0000950170-25-083705:mdna:15]
•
Net revenues: Our net revenues increased approximately 5% in fiscal 2025 compared to fiscal 2024, due to increases in both product revenues and services revenues.

[0000950170-25-083705:mdna:16]
•
Gross margin: Our gross margin decreased less than one percentage point in fiscal 2025 compared to fiscal 2024, due to the decrease in gross margins on product revenues.

[0000950170-25-083705:mdna:17]
•
Income from operations as a percentage of net revenues: Our income from operations as a percentage of net revenues increased by one percentage point in fiscal 2025 compared to fiscal 2024, primarily due to higher net revenues.

[0000950170-25-083705:mdna:18]
•
Provision (benefit) for income taxes: Our provision for income taxes decreased in fiscal 2025 compared to fiscal 2024 primarily as a result of differences in discrete tax impacts in each year.

[0000950170-25-083705:mdna:19]
•
Net income and Diluted net income per share: The increase in both net income and diluted net income per share in fiscal 2025 compared to fiscal 2024 reflect the factors discussed above.

[0000950170-25-083705:mdna:20]
Stock Repurchase Program and Dividend Activity

[0000950170-25-083705:mdna:21]
During fiscal 2025, we repurchased 10.2 million shares of our common stock at an average price of $112.55 per share, for an aggregate purchase price of $1.2 billion. We also declared aggregate cash dividends of $2.08 per share in fiscal 2025, for which we paid a total of $424 million.

[0000950170-25-083705:mdna:22]
Restructuring Events

[0000950170-25-083705:mdna:23]
During fiscal 2025, we executed several restructuring plans and recognized expenses totaling $83 million consisting primarily of employee severance-related costs.

[0000950170-25-083705:mdna:24]
Senior Notes Issuance

[0000950170-25-083705:mdna:25]
In March 2025, we issued $625 million aggregate principal amount of 5.50% Senior Notes due 2032 and $625 million aggregate principal amount of 5.70% Senior Notes due 2035, for which we received total proceeds of $1.24 billion, net of discount and issuance costs.

[0000950170-25-083705:mdna:26]
Results of Operations

[0000950170-25-083705:mdna:27]
Our fiscal year is reported on a 52- or 53-week year that ends on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal years 2025, 2024 and 2023, which ended on April 25, 2025, April 26, 2024 and April 28, 2023, respectively, are all 52-week years, with 13 weeks in each of their quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to our fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0000950170-25-083705:mdna:28]
The following table sets forth certain Consolidated Statements of Income data as a percentage of net revenues for the periods indicated:

[0000950170-25-083705:mdna:29]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product |  |  | 46 | % |  |  | 45 | % |  |  | 48 | % |
| Services |  |  | 54 |  |  |  | 55 |  |  |  | 52 |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 20 |  |  |  | 18 |  |  |  | 24 |  |
| Cost of services |  |  | 10 |  |  |  | 11 |  |  |  | 10 |  |
| Gross profit |  |  | 70 |  |  |  | 71 |  |  |  | 66 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 28 |  |  |  | 29 |  |  |  | 29 |  |
| Research and development |  |  | 15 |  |  |  | 16 |  |  |  | 15 |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 4 |  |
| Restructuring charges |  |  | 1 |  |  |  | 1 |  |  |  | 2 |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |
| Total operating expenses |  |  | 50 |  |  |  | 51 |  |  |  | 50 |  |
| Income from operations |  |  | 20 |  |  |  | 19 |  |  |  | 16 |  |
| Other income, net |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |
| Income before income taxes |  |  | 21 |  |  |  | 20 |  |  |  | 17 |  |
| Provision (benefit) for income taxes |  |  | 3 |  |  |  | 4 |  |  |  | (3 | ) |
| Net income |  |  | 18 | % |  |  | 16 | % |  |  | 20 | % |

[0000950170-25-083705:mdna:30]
Percentages may not add due to rounding

[0000950170-25-083705:mdna:31]
Discussion and Analysis of Results of Operations

[0000950170-25-083705:mdna:32]
Net Revenues (in millions, except percentages):

[0000950170-25-083705:mdna:33]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | % Change |  |  | 2023 |  |  | % Change |  |
| Net revenues |  | $ | 6,572 |  |  | $ | 6,268 |  |  |  | 5 | % |  | $ | 6,362 |  |  |  | (1 | )% |

[0000950170-25-083705:mdna:34]
The increase in net revenues for fiscal 2025 compared to fiscal 2024 was due to an increase in both product revenues and services revenues. Product revenues as a percentage of net revenues increased by approximately one percentage point in fiscal 2025 compared to fiscal 2024, while services revenues as a percentage of net revenues decreased by approximately one percentage point.

[0000950170-25-083705:mdna:35]
The decrease in net revenues for fiscal 2024 compared to fiscal 2023 was due to a decrease in product revenues partially offset by an increase in services revenues. Product revenues as a percentage of net revenues decreased by approximately three percentage points in fiscal 2024 compared to fiscal 2023, while services revenues as a percentage of net revenues increased by approximately three percentage points.

[0000950170-25-083705:mdna:36]
Sales through our indirect channels represented 78%, 76% and 78% of net revenues in fiscal 2025, 2024 and 2023, respectively.

[0000950170-25-083705:mdna:37]
The following customers, each of which is a distributor, accounted for 10% or more of net revenues:

[0000950170-25-083705:mdna:38]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Arrow Electronics, Inc. |  |  | 21 | % |  |  | 22 | % |  |  | 24 | % |
| TD Synnex Corporation (previously presented as Tech Data Corporation) |  |  | 24 | % |  |  | 22 | % |  |  | 21 | % |

[0000950170-25-083705:mdna:39]
Product Revenues (in millions, except percentages):

[0000950170-25-083705:mdna:40]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | % Change |  |  | 2023 |  |  | % Change |  |
| Product revenues |  | $ | 3,040 |  |  | $ | 2,849 |  |  |  | 7 | % |  | $ | 3,049 |  |  |  | (7 | )% |

[0000950170-25-083705:mdna:41]
Hybrid Cloud

[0000950170-25-083705:mdna:42]
In prior years, we presented the hardware and software components of our GAAP product revenues to illustrate the significance and value of the Company’s software. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. Effective in fiscal 2025, we are no longer presenting the non-GAAP hardware and software components of our product revenues, as management no longer considers them to be key financial measures. Our current strategy is expected to deliver investor value through growth in total revenues, including product revenues, while maintaining operational discipline to drive earnings leverage. While software continues to be the primary value driver of our products, NetApp is primarily focused on driving growth in total product revenues, through the sale of configured storage systems comprised of both hardware and software, with less focus on the pricing of each component. Additionally, we are considering potential opportunities to simplify pricing for certain products in the future, which may eliminate the existence of separate prices for hardware and software components and/or impact our ability to allocate between them.

[0000950170-25-083705:mdna:43]
Product revenues are derived through the sale of our Hybrid Cloud solutions and consist of sales of configured all-flash array systems (including All-Flash FAS A-Series and All-Flash FAS C-Series with capacity flash) and hybrid systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, StorageGrid, OEM products, NetApp HCI and add-on optional software.

[0000950170-25-083705:mdna:44]
Total product revenues increased in fiscal 2025 compared to fiscal 2024, primarily due to higher sales of C-Series all-flash array systems, partially offset by a decrease in sales of hybrid systems.

[0000950170-25-083705:mdna:45]
Total product revenues decreased in fiscal 2024 compared to fiscal 2023, primarily due to lower sales of hybrid systems due to softening customer demand, partially offset by an increase in sales of C-Series all-flash array systems.

[0000950170-25-083705:mdna:46]
Services Revenues (in millions, except percentages):

[0000950170-25-083705:mdna:47]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | % Change |  |  | 2023 |  |  | % Change |  |
| Services revenues |  | $ | 3,532 |  |  | $ | 3,419 |  |  |  | 3 | % |  | $ | 3,313 |  |  |  | 3 | % |
| Support |  |  | 2,512 |  |  |  | 2,488 |  |  |  | 1 | % |  |  | 2,419 |  |  |  | 3 | % |
| Professional and other services |  |  | 355 |  |  |  | 320 |  |  |  | 11 | % |  |  | 319 |  |  |  | — | % |
| Public cloud |  |  | 665 |  |  |  | 611 |  |  |  | 9 | % |  |  | 575 |  |  |  | 6 | % |

[0000950170-25-083705:mdna:48]
Hybrid Cloud

[0000950170-25-083705:mdna:49]
Hybrid Cloud services revenues are derived from the sale of: (1) support, which includes both hardware and software support contracts (the latter of which entitle customers to receive unspecified product upgrades and enhancements, bug fixes and patch releases), and (2) professional and other services, which include customer education and training.

[0000950170-25-083705:mdna:50]
Support revenues increased marginally in fiscal 2025 compared to fiscal 2024 and increased in fiscal 2024 compared to fiscal 2023 as a result of a higher aggregate support contract value for our installed base.

[0000950170-25-083705:mdna:51]
Professional and other services revenues increased in fiscal 2025 compared to fiscal 2024 primarily due to an increase in revenues from our Keystone storage-as-a-service offering and remained relatively flat in fiscal 2024 compared to fiscal 2023.

[0000950170-25-083705:mdna:52]
Public Cloud

[0000950170-25-083705:mdna:53]
Public Cloud revenues are derived from the sale of public cloud offerings delivered primarily as-a-service, which include cloud storage, data services and operational services.

[0000950170-25-083705:mdna:54]
Public Cloud revenues increased in fiscal 2025 and fiscal 2024 compared to the respective prior years primarily due to customer demand for NetApp’s diversified cloud offerings, coupled with overall growth in the cloud market.

[0000950170-25-083705:mdna:55]
Revenues by Geographic Area:

[0000950170-25-083705:mdna:56]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| United States, Canada and Latin America (Americas) |  |  | 51 | % |  |  | 51 | % |  |  | 51 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 34 | % |  |  | 34 | % |  |  | 34 | % |
| Asia Pacific (APAC) |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |

[0000950170-25-083705:mdna:57]
Percentages may not add due to rounding

[0000950170-25-083705:mdna:58]
Americas revenues consist of sales to Americas commercial and United States (U.S.) public sector markets. Demand across geographies was relatively consistent for each fiscal year presented.

[0000950170-25-083705:mdna:59]
Cost of Revenues

[0000950170-25-083705:mdna:60]
Our cost of revenues consists of:

[0000950170-25-083705:mdna:61]
(1) cost of product revenues, composed of (a) cost of Hybrid Cloud product revenues, which includes the costs of manufacturing and shipping our products, inventory write-downs, and warranty costs, and (b) unallocated cost of product revenues, which includes stock-based compensation and amortization of intangibles, and;

[0000950170-25-083705:mdna:62]
(2) cost of services revenues, composed of (a) cost of support revenues, which includes the costs of providing support activities for hardware and software support, global support partnership programs, and third party royalty costs, (b) cost of professional and other services revenues, (c) cost of public cloud revenues, constituting the cost of providing our Public Cloud offerings which includes depreciation and amortization expense and third party datacenter fees, and (d) unallocated cost of services revenues, which includes stock-based compensation and amortization of intangibles.

[0000950170-25-083705:mdna:63]
Cost of Product Revenues (in millions, except percentages):

[0000950170-25-083705:mdna:64]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | % Change |  |  | 2023 |  |  | % Change |  |
| Cost of product revenues |  | $ | 1,284 |  |  | $ | 1,137 |  |  |  | 13 | % |  | $ | 1,517 |  |  |  | (25 | )% |
| Hybrid Cloud |  |  | 1,278 |  |  |  | 1,131 |  |  |  | 13 | % |  |  | 1,511 |  |  |  | (25 | )% |
| Unallocated |  |  | 6 |  |  |  | 6 |  |  |  | — | % |  |  | 6 |  |  |  | — | % |

[0000950170-25-083705:mdna:65]
Hybrid Cloud

[0000950170-25-083705:mdna:66]
Cost of Hybrid Cloud product revenues represented 42%, 40% and 50% of Hybrid Cloud product revenues in fiscal 2025, 2024 and 2023, respectively. Materials costs represented 89%, 88% and 94% of cost of Hybrid Cloud product revenues in fiscal 2025, 2024 and 2023, respectively.

[0000950170-25-083705:mdna:67]
Materials costs increased by $140 million in fiscal 2025 compared to fiscal 2024 primarily reflecting the increase in product revenues.

[0000950170-25-083705:mdna:68]
Hybrid Cloud product gross margins decreased by approximately two percentage points in fiscal 2025 compared to fiscal 2024 primarily due to higher component costs.

[0000950170-25-083705:mdna:69]
Materials costs decreased by $418 million in fiscal 2024 compared to fiscal 2023 reflecting lower component and freight costs as a result of supply chain improvements. Materials costs were also impacted by the decrease in product revenues in fiscal 2024.

[0000950170-25-083705:mdna:70]
Hybrid Cloud product gross margins increased by approximately ten percentage points in fiscal 2024 compared to fiscal 2023 primarily due to lower component and freight costs.

[0000950170-25-083705:mdna:71]
Unallocated

[0000950170-25-083705:mdna:72]
Unallocated cost of product revenues were consistent for each fiscal year presented.

[0000950170-25-083705:mdna:73]
Cost of Services Revenues (in millions, except percentages):

[0000950170-25-083705:mdna:74]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | % Change |  |  | 2023 |  |  | % Change |  |
| Cost of services revenues |  | $ | 675 |  |  | $ | 698 |  |  |  | (3 | )% |  | $ | 636 |  |  |  | 10 | % |
| Support |  |  | 197 |  |  |  | 195 |  |  |  | 1 | % |  |  | 181 |  |  |  | 8 | % |
| Professional and other services |  |  | 261 |  |  |  | 243 |  |  |  | 7 | % |  |  | 211 |  |  |  | 15 | % |
| Public cloud |  |  | 165 |  |  |  | 203 |  |  |  | (19 | )% |  |  | 184 |  |  |  | 10 | % |
| Unallocated |  |  | 52 |  |  |  | 57 |  |  |  | (9 | )% |  |  | 60 |  |  |  | (5 | )% |

[0000950170-25-083705:mdna:75]
Hybrid Cloud

[0000950170-25-083705:mdna:76]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, increased in fiscal 2025 and fiscal 2024 compared to the respective prior years reflecting the increase in Hybrid Cloud services revenues. Cost of Hybrid Cloud services revenues represented 16%, 16% and 14% of Hybrid Cloud services revenues in fiscal 2025, 2024 and 2023, respectively.

[0000950170-25-083705:mdna:77]
Hybrid Cloud support gross margins were similar in fiscal 2025, fiscal 2024 and fiscal 2023. Hybrid Cloud professional and other services gross margins increased by approximately two percentage points in fiscal 2025 compared to fiscal 2024 while they decreased by approximately ten percentage points in fiscal 2024 compared to fiscal 2023 primarily due to the mix of services provided.

[0000950170-25-083705:mdna:78]
Public Cloud

[0000950170-25-083705:mdna:79]
Cost of Public Cloud revenues decreased in fiscal 2025 compared to fiscal 2024, while Public Cloud gross margins increased by eight percentage points in fiscal 2025 compared to fiscal 2024. The decrease in cost of Public Cloud revenues and improved gross margins was due to cost optimization that included a decrease in fixed assets depreciation and the mix of offerings provided.

[0000950170-25-083705:mdna:80]
Cost of Public Cloud revenues increased in fiscal 2024 compared to fiscal 2023, reflecting the increase in Public Cloud revenues. Public Cloud gross margins decreased by one percentage point in fiscal 2024 compared to fiscal 2023 primarily due to the mix of offerings provided.

[0000950170-25-083705:mdna:81]
Unallocated

[0000950170-25-083705:mdna:82]
Unallocated cost of services revenues decreased in fiscal 2025 compared to fiscal 2024 due to the derecognition of certain intangible assets as a result of the sale of our cloud optimization and management software business known as Spot by NetApp during the fourth quarter of fiscal 2025. Unallocated cost of services revenues decreased in fiscal 2024 compared to fiscal 2023 due to certain intangible assets becoming fully amortized during the first quarter of fiscal 2024.

[0000950170-25-083705:mdna:83]
Operating Expenses

[0000950170-25-083705:mdna:84]
Sales and Marketing, Research and Development and General and Administrative Expenses

[0000950170-25-083705:mdna:85]
Sales and marketing, research and development, and general and administrative expenses for fiscal 2025 totaled $3,188 million, or 49% of net revenues, representing a decrease of one percentage point compared to fiscal 2024.

[0000950170-25-083705:mdna:86]
Sales and marketing, research and development, and general and administrative expenses for fiscal 2024 totaled $3,165 million, or 50% of net revenues, representing an increase of two percentage points compared to fiscal 2023.

[0000950170-25-083705:mdna:87]
Compensation costs represent the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0000950170-25-083705:mdna:88]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses in fiscal 2025 were relatively flat compared to fiscal 2024.

[0000950170-25-083705:mdna:89]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses increased by $115 million, or 6%, during fiscal 2024 compared to fiscal 2023, primarily due to higher incentive compensation expense

[0000950170-25-083705:mdna:90]
reflecting higher operating performance against goals. The increase was partially offset by lower salaries expense, reflecting a decrease in average headcount of 7%.

[0000950170-25-083705:mdna:91]
Sales and Marketing (in millions, except percentages):

[0000950170-25-083705:mdna:92]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | % Change |  |  | 2023 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 1,865 |  |  | $ | 1,828 |  |  |  | 2 | % |  | $ | 1,829 |  |  |  | — | % |

[0000950170-25-083705:mdna:93]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, facilities and IT support costs, advertising and marketing promotional expense and travel and entertainment expense.

[0000950170-25-083705:mdna:94]
The increase in sales and marketing expenses in fiscal 2025 compared to fiscal 2024 was primarily due to an increase in sales commission expenses.

[0000950170-25-083705:mdna:95]
All primary components of sales and marketing expenses were relatively consistent in fiscal 2024 compared to fiscal 2023.

[0000950170-25-083705:mdna:96]
Research and Development (in millions, except percentages):

[0000950170-25-083705:mdna:97]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | % Change |  |  | 2023 |  |  | % Change |  |
| Research and development expenses |  | $ | 1,012 |  |  | $ | 1,029 |  |  |  | (2 | )% |  | $ | 956 |  |  |  | 8 | % |

[0000950170-25-083705:mdna:98]
Research and development expenses consist primarily of compensation costs, facilities and IT support costs, depreciation, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs.

[0000950170-25-083705:mdna:99]
The decrease in research and development expenses in fiscal 2025 compared to fiscal 2024 was primarily due to lower compensation costs.

[0000950170-25-083705:mdna:100]
The increase in research and development expenses in fiscal 2024 compared to fiscal 2023 was primarily due to higher compensation costs, attributable to higher incentive compensation expense and stock-based compensation expense, partially offset by lower salaries expense, reflecting a decrease in average headcount of 5%.

[0000950170-25-083705:mdna:101]
General and Administrative (in millions, except percentages):

[0000950170-25-083705:mdna:102]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | % Change |  |  | 2023 |  |  | % Change |  |
| General and administrative expenses |  | $ | 311 |  |  | $ | 308 |  |  |  | 1 | % |  | $ | 265 |  |  |  | 16 | % |

[0000950170-25-083705:mdna:103]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and facilities and IT support costs.

[0000950170-25-083705:mdna:104]
General and administrative expenses remained relatively flat in fiscal 2025 compared to fiscal 2024.

[0000950170-25-083705:mdna:105]
The increase in general and administrative expenses in fiscal 2024 compared to fiscal 2023 was attributable to increases in all components of compensation costs, but predominately incentive compensation expense. Professional and legal fees and outside services expense was also slightly higher in fiscal 2024 due to higher spending on certain business transformation projects.

[0000950170-25-083705:mdna:106]
Restructuring Charges (in millions, except percentages):

[0000950170-25-083705:mdna:107]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | % Change |  |  | 2023 |  |  | % Change |  |
| Restructuring charges |  | $ | 83 |  |  | $ | 44 |  |  |  | 89 | % |  | $ | 120 |  |  |  | (63 | )% |

[0000950170-25-083705:mdna:108]
In an effort to reduce our cost structure and redirect resources to our highest return activities, in fiscal 2025, 2024 and 2023, we initiated a number of business realignment plans designed to streamline our business and focus on key strategic opportunities. These plans resulted in aggregate charges of $83 million, $44 million, and $120 million, respectively, consisting primarily of employee severance-related costs. Additionally, the aggregate charges for fiscal 2025 and fiscal 2024 included optimization of our global office space for our hybrid work model. See Note 12 – Restructuring Charges of the Notes to Consolidated Financial Statements included in Part II, Item 8 for more details regarding our restructuring plans.

[0000950170-25-083705:mdna:109]
Acquisition-related Expense (in millions, except percentages):

[0000950170-25-083705:mdna:110]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | % Change |  |  | 2023 |  |  | % Change |  |
| Acquisition-related expense |  | $ | 5 |  |  | $ | 10 |  |  |  | (50 | )% |  | $ | 21 |  |  |  | (52 | )% |

[0000950170-25-083705:mdna:111]
We incurred $5 million, $10 million and $21 million of acquisition-related expenses, primarily consisting of legal and consulting fees, in fiscal 2025, fiscal 2024 and fiscal 2023, respectively, associated with our acquisitions and subsequent integrations.

[0000950170-25-083705:mdna:112]
Other Income, Net (in millions, except percentages)

[0000950170-25-083705:mdna:113]
The components of other income, net were as follows:

[0000950170-25-083705:mdna:114]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | % Change |  |  | 2023 |  |  | % Change |  |
| Interest income |  | $ | 112 |  |  | $ | 112 |  |  |  | — | % |  | $ | 69 |  |  |  | 62 | % |
| Interest expense |  |  | (64 | ) |  |  | (64 | ) |  |  | — | % |  |  | (67 | ) |  |  | (4 | )% |
| Other, net |  |  | (2 | ) |  |  | 1 |  |  | NM |  |  |  | 46 |  |  | NM |  |
| Total |  | $ | 46 |  |  | $ | 49 |  |  |  | (6 | )% |  | $ | 48 |  |  |  | 2 | % |

[0000950170-25-083705:mdna:115]
NM - Not Meaningful

[0000950170-25-083705:mdna:116]
Interest income and interest expense in fiscal 2025 were relatively flat compared to fiscal 2024. Each component of other income, net was relatively flat in fiscal 2025 compared to fiscal 2024.

[0000950170-25-083705:mdna:117]
Interest income increased in fiscal 2024 compared to fiscal 2023 primarily due to higher yields earned on our cash and investments.

[0000950170-25-083705:mdna:118]
Interest expense decreased in fiscal 2024 compared to fiscal 2023 due to the extinguishment of certain senior notes in the second quarter of fiscal 2023.

[0000950170-25-083705:mdna:119]
Other, net for fiscal 2023 includes $22 million of other income for non-refundable, up-front payments from customers in Russia for support contracts, which we were not able to fulfill due to imposed sanctions and for which we have no remaining legal obligation to perform. Other, net for fiscal 2023 also includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of $59 million. The remaining difference in Other, net for fiscal 2024 compared to fiscal 2023 is primarily due to differences in foreign exchange gains and losses.

[0000950170-25-083705:mdna:120]
Provision (Benefit) for Income Taxes (in millions, except percentages):

[0000950170-25-083705:mdna:121]
Our provision (benefit) for income taxes and effective tax rates were as follows:

[0000950170-25-083705:mdna:122]
|  |  | Fiscal Year |  |
|  |  | 2025 |  |  | 2024 |  |  | % Change |  |  | 2023 |  |  | % Change |  |
| Provision (benefit) for income taxes |  | $ | 197 |  |  | $ | 277 |  |  |  | (29 | )% |  | $ | (208 | ) |  |  | (233 | )% |
| Effective tax rate |  |  | 14.2 | % |  |  | 21.9 | % |  | NM |  |  |  | (19.5 | )% |  | NM |  |

[0000950170-25-083705:mdna:123]
NM - Not Meaningful

[0000950170-25-083705:mdna:124]
The differences in the effective tax rates between fiscal years were primarily due to fiscal 2025 benefits related to the Internal Revenue Service (“IRS”) examination of our fiscal 2018 and fiscal 2019 U.S. income tax returns and fiscal 2023 benefits resulting from an intra-entity asset transfer of certain IP, partially offset by discrete tax expense recorded as a result of the Danish Supreme Court ruling received January 9, 2023.

[0000950170-25-083705:mdna:125]
During the fourth quarter of fiscal 2025, the IRS substantially completed the examination of our fiscal 2018 and fiscal 2019 U.S. income tax returns, and we recognized a tax benefit of $36 million attributable to the release of related tax reserves.

[0000950170-25-083705:mdna:126]
During fiscal 2023, we completed an intra-entity asset transfer of certain IP to our international headquarters (the “IP Transfer”). The transaction resulted in a step-up of tax-deductible basis in the transferred assets, and accordingly, created a temporary difference where the tax basis exceeded the financial statement basis of such intangible assets, which resulted in the recognition of a discrete tax benefit and related deferred tax asset of $524 million during the second quarter of fiscal 2023. Management applied significant judgment when determining the fair value of the IP, which serves as the tax basis of the deferred tax asset. With the assistance of third-party valuation specialists, the fair value of the IP was determined principally based on the present value of projected cash flows related to the IP which reflects management’s assumptions regarding projected revenues, earnings before interest and taxes, and a discount rate. The tax-deductible amortization related to the transferred IP rights will be recognized in future periods and any amortization that is unused in a particular year can be carried forward indefinitely. The deferred tax asset and the tax benefit were measured based on the enacted tax rates expected to apply in the years the asset is expected to be realized. We expect to realize the deferred tax asset resulting from the IP Transfer and will assess the realizability of the deferred tax asset quarterly. Any Organisation for Economic Co-operation and Development’s actions adopted internationally could impact our financial results in future periods. The impact of the transaction to net cash provided by or used in operating, investing and financing activities on the consolidated statements of cash flows during fiscal 2023 was not material.

[0000950170-25-083705:mdna:127]
During fiscal 2023, the Danish Supreme Court issued a non-appealable ruling on the distributions declared in 2005 and 2006. The Danish Supreme Court ruled the 2005 dividend was subject to at-source dividend withholding tax while the smaller 2006 distribution would not be subject to withholding tax. During fiscal 2023, we recorded $69 million of tax expense, which includes $23 million of withholding tax and $46 million of interest.

[0000950170-25-083705:mdna:128]
Liquidity, Capital Resources and Cash Requirements

[0000950170-25-083705:mdna:129]
| (In millions) |  | April 25, 2025 |  |  | April 26,2024 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,846 |  |  | $ | 3,252 |  |
| Principal amount of debt |  | $ | 3,250 |  |  | $ | 2,400 |  |

[0000950170-25-083705:mdna:130]
The following is a summary of our cash flow activities:

[0000950170-25-083705:mdna:131]
|  |  | Fiscal Year |  |
| (In millions) |  | 2025 |  |  | 2024 |  |
| Net cash provided by operating activities |  | $ | 1,506 |  |  | $ | 1,685 |  |
| Net cash provided by (used in) investing activities |  |  | 147 |  |  |  | (735 | ) |
| Net cash used in financing activities |  |  | (828 | ) |  |  | (1,344 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 15 |  |  |  | (19 | ) |
| Net change in cash, cash equivalents and restricted cash |  | $ | 840 |  |  | $ | (413 | ) |

[0000950170-25-083705:mdna:132]
As of April 25, 2025, our cash, cash equivalents and short-term investments totaled $3.8 billion, reflecting an increase of $594 million from April 26, 2024. The increase was primarily due to $1.24 billion of net proceeds from the issuance of Senior Notes and $1.5 billion of cash generated from operating activities, partially offset by $1.2 billion used to repurchase shares of our common stock, a $400 million principal repayment of our 3.30% Senior Notes due September 2024, $424 million used for the payment of dividends, and $168 million in purchases of property and equipment. Net working capital was $1.2 billion as of April 25, 2025, an increase of $398 million when compared to April 26, 2024, primarily due to the increases in cash, cash equivalents and short-term investments discussed above.

[0000950170-25-083705:mdna:133]
Cash Flows from Operating Activities

[0000950170-25-083705:mdna:134]
During fiscal 2025, cash provided by operating activities reflected net income of $1.2 billion which was increased for non-cash depreciation and amortization expense of $243 million and non-cash stock-based compensation expense of $386 million.

[0000950170-25-083705:mdna:135]
Significant changes in assets and liabilities during fiscal 2025 included the following:

[0000950170-25-083705:mdna:136]
•
Accounts receivable increased by $219 million, primarily reflecting higher billing in the fourth quarter of fiscal 2025 compared to the fourth quarter of fiscal 2024.

[0000950170-25-083705:mdna:137]
•
Deferred revenue and financed unearned services revenue increased by $208 million, primarily due to an increase in deferred revenue for software and hardware support contracts.

[0000950170-25-083705:mdna:138]
•
Long-term taxes payable decreased by $207 million, primarily due to settlements associated with certain IRS tax examinations and changes in prior period tax positions.

[0000950170-25-083705:mdna:139]
44

[0000950170-25-083705:mdna:140]
During fiscal 2024, cash provided by operating activities reflected net income of $1.0 billion which was increased for non-cash depreciation and amortization expense of $255 million and non-cash stock-based compensation expense of $357 million.

[0000950170-25-083705:mdna:141]
Significant changes in assets and liabilities during fiscal 2024 included the following:

[0000950170-25-083705:mdna:142]
•
Accounts payable increased by $123 million, primarily reflecting the timing of inventory purchases from, and payments to, our contract manufacturers.

[0000950170-25-083705:mdna:143]
•
Accrued expenses increased by $113 million, primarily due to higher employee compensation accruals as of the end of fiscal 2024 compared to fiscal 2023 related to incentive compensation and commissions plans.

[0000950170-25-083705:mdna:144]
We expect that cash provided by operating activities may materially fluctuate in future periods due to a number of factors, including fluctuations in our operating results, shipping linearity, accounts receivable collections performance, inventory and supply chain management, vendor payment initiatives, and the timing and amount of compensation, income taxes and other payments.

[0000950170-25-083705:mdna:145]
Cash Flows from Investing Activities

[0000950170-25-083705:mdna:146]
During fiscal 2025, we generated $245 million primarily from maturities and sales of investments, net of purchases, and paid $168 million for capital expenditures. Additionally, we received proceeds of $70 million from the sale of our Spot by NetApp business.

[0000950170-25-083705:mdna:147]
During fiscal 2024, we used $580 million for the purchases of investments, net of maturities and sales, and $155 million for capital expenditures.

[0000950170-25-083705:mdna:148]
Cash Flows from Financing Activities

[0000950170-25-083705:mdna:149]
During fiscal 2025, we used $1.2 billion for the repurchase of 10.2 million shares of common stock, $424 million for the payment of dividends and $400 million principal repayment upon maturity, partially offset by $1.24 billion of net proceeds from the issuance of Senior Notes.

[0000950170-25-083705:mdna:150]
During fiscal 2024, we used $900 million for the repurchase of 11.5 million shares of common stock, and $416 million for the payment of dividends.

[0000950170-25-083705:mdna:151]
Key factors that that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including cash, cash equivalents and short-term investments, cash generated from operations, and our ability to access capital markets and committed credit lines will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months and thereafter for the foreseeable future. We may choose to periodically raise additional debt capital based on certain conditions, including the refinancing of upcoming maturities and/or for potential strategic acquisitions and investments. Our ability to obtain this or any additional financing that we may pursue or need, will depend on, among other things, our business plans, operating performance and the condition of the capital markets at the time we seek financing. We may not be able to obtain such financing on terms acceptable to us or at all. In the event our liquidity is insufficient and we are unable to enter into new financing arrangements, we may be required to curtail spending and implement additional cost saving measures and restructuring actions. We cannot be certain that we will continue to generate cash flows at or above current levels. For further discussion of factors that could affect our cash flows and liquidity requirements, see Item 1A. Risk Factors.

[0000950170-25-083705:mdna:152]
Liquidity

[0000950170-25-083705:mdna:153]
Our principal sources of liquidity as of April 25, 2025 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-25-083705:mdna:154]
Cash, cash equivalents and short-term investments consisted of the following (in millions):

[0000950170-25-083705:mdna:155]
|  |  | April 25, 2025 |  |  | April 26,2024 |  |
| Cash and cash equivalents |  | $ | 2,742 |  |  | $ | 1,903 |  |
| Short-term investments |  |  | 1,104 |  |  |  | 1,349 |  |
| Total |  | $ | 3,846 |  |  | $ | 3,252 |  |

[0000950170-25-083705:mdna:156]
45

[0000950170-25-083705:mdna:157]
As of April 25, 2025 and April 26, 2024, $2.5 billion and $2.1 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $1.3 billion and $1.2 billion, respectively, were available in the U.S.

[0000950170-25-083705:mdna:158]
Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies through asset purchases and/or business acquisitions, service interest and principal payments on our debt, fund our stock repurchase program, and pay dividends, as and if declared. In the ordinary course of business, we engage in periodic reviews of opportunities to invest in or acquire companies or units in companies to expand our total addressable market, leverage technological synergies and establish new streams of revenue, particularly in our Public Cloud segment.

[0000950170-25-083705:mdna:159]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of April 25, 2025.

[0000950170-25-083705:mdna:160]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. We also have an automatic shelf registration statement on file with the U.S. Securities and Exchange Commission (SEC). We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0000950170-25-083705:mdna:161]
Senior Notes

[0000950170-25-083705:mdna:162]
The following table summarizes the principal amount of our Senior Notes as of April 25, 2025 (in millions):

[0000950170-25-083705:mdna:163]
|  |  | Amount |  |
| 1.875% Senior Notes Due June 2025 |  | $ | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| 5.50% Senior Notes Due June 2032 |  |  | 625 |  |
| 5.70% Senior Notes Due June 2035 |  |  | 625 |  |
| Total |  | $ | 3,250 |  |

[0000950170-25-083705:mdna:164]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 8 – Financing Arrangements of the Notes to Consolidated Financial Statements included in Part II, Item 8.

[0000950170-25-083705:mdna:165]
In March 2025, we issued $625 million aggregate principal amount of 5.50% Senior Notes due 2032 and $625 million aggregate principal amount of 5.70% Senior Notes due 2035, for which we received total proceeds of $1.24 billion, net of discount and issuance costs. Interest on these Senior Notes is payable semi-annually in March and September.

[0000950170-25-083705:mdna:166]
On September 30, 2024, upon maturity, we repaid our 3.30% Senior Notes due September 2024 for an aggregate amount of $407 million, comprised of the principal and unpaid interest.

[0000950170-25-083705:mdna:167]
Commercial Paper Program and Credit Facility

[0000950170-25-083705:mdna:168]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of April 25, 2025.

[0000950170-25-083705:mdna:169]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in March 2025, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on March 5, 2030, with an option for us

[0000950170-25-083705:mdna:170]
46

[0000950170-25-083705:mdna:171]
to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of April 25, 2025, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-25-083705:mdna:172]
Capital Expenditure Requirements

[0000950170-25-083705:mdna:173]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for fiscal 2026 to be between $175 million and $225 million.

[0000950170-25-083705:mdna:174]
Transition Tax Payments

[0000950170-25-083705:mdna:175]
The Tax Cuts and Jobs Act of 2017 imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits that had not previously been subject to U.S. income tax. As of April 25, 2025, a final transition tax payment of $178 million remains outstanding and is expected to be paid during fiscal 2026. During fiscal 2025, transition tax payments totaled $115 million.

[0000950170-25-083705:mdna:176]
Dividends and Stock Repurchase Program

[0000950170-25-083705:mdna:177]
On May 22, 2025, we declared a cash dividend of $0.52 per share of common stock, payable on July 23, 2025 to holders of record as of the close of business on July 3, 2025.

[0000950170-25-083705:mdna:178]
As of April 25, 2025, our Board of Directors had authorized the repurchase of up to $17.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through April 25, 2025, we repurchased a total of 382 million shares of our common stock at an average price of $43.93 per share, for an aggregate purchase price of $16.8 billion. As of April 25, 2025, the remaining authorized amount for stock repurchases under this program was $0.4 billion. On May 22, 2025 our Board of Directors authorized the repurchase of an additional $1.1 billion of our common stock.

[0000950170-25-083705:mdna:179]
Purchase Commitments

[0000950170-25-083705:mdna:180]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled $1.0 billion at April 25, 2025, of which $0.6 billion is due in fiscal 2026, with the remainder due thereafter.

[0000950170-25-083705:mdna:181]
Financing Guarantees

[0000950170-25-083705:mdna:182]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $65 million and $67 million of receivables during fiscal 2025 and 2024, respectively.

[0000950170-25-083705:mdna:183]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user.

[0000950170-25-083705:mdna:184]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of April 25, 2025 and April 26, 2024, the aggregate amount

[0000950170-25-083705:mdna:185]
by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-25-083705:mdna:186]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of April 25, 2025, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0000950170-25-083705:mdna:187]
Legal Contingencies

[0000950170-25-083705:mdna:188]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 17 – Commitments and Contingencies of the Notes to Consolidated Financial Statements included in Part II, Item 8.

[0000950170-25-083705:mdna:189]
Critical Accounting Policies and Estimates

[0000950170-25-083705:mdna:190]
Our consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (GAAP), which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and liabilities. Our estimates are based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0000950170-25-083705:mdna:191]
The summary of significant accounting policies is included in Note 1 – Description of Business and Significant Accounting Policies of the Notes to Consolidated Financial Statements included in Part II, Item 8. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. The accounting policies described below reflect the significant judgments, estimates and assumptions used in the preparation of the consolidated financial statements.

[0000950170-25-083705:mdna:192]
Revenue Recognition

[0000950170-25-083705:mdna:193]
Our contracts with customers often include the transfer of multiple products and services to the customer. In determining the amount and timing of revenue recognition, we assess which products and services are distinct performance obligations and allocate the transaction price, which may include fixed and/or variable amounts, among each performance obligation on a relative standalone selling price (SSP) basis. The following are the key estimates and assumptions and corresponding uncertainties included in this approach:

[0000950170-25-083705:mdna:194]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | We evaluate whether products and services promised in our contracts with customers are distinct performance obligations that should be accounted for separately versus together. |  |  | In certain contracts, the determination of our distinct performance obligations requires significant judgment. As our business and offerings to customers change over time, the products and services we determine to be distinct performance obligations may change. Such changes may adversely impact the amount of revenue and gross margin we report in a particular period. |
|  | In determining the transaction price of our contracts, we estimate variable consideration based on the expected value, primarily relying on our history. In certain situations, we may also use the most likely amount as the basis of our estimate. |  |  | We may have insufficient relevant historical data or other information to arrive at an accurate estimate of variable consideration using either the “expected value” or “most likely amount” method. Additionally, changes in business practices, such as those related to sales returns or marketing programs, may introduce new forms of variable consideration, as well as more complexity and uncertainty in the estimation process. |

[0000950170-25-083705:mdna:195]
48

[0000950170-25-083705:mdna:196]
|  | In contracts with multiple performance obligations, we establish SSPs based on the price at which products and services are sold separately. If SSPs are not observable through past transactions, we estimate them by maximizing the use of observable inputs including pricing strategy, market data, internally-approved pricing guidelines related to the performance obligations and other observable inputs. |  |  | As our business and offerings evolve over time, modifications to our pricing and discounting methodologies, changes in the scope and nature of product and service offerings and/or changes in customer segmentation may result in a lack of consistency, making it difficult to establish and/or maintain SSPs. Changes in SSPs could result in different and unanticipated allocations of revenue in contracts with multiple performance obligations. These factors, among others, may adversely impact the amount of revenue and gross margin we report in a particular period. |

[0000950170-25-083705:mdna:197]
Inventory Valuation and Purchase Order Accruals

[0000950170-25-083705:mdna:198]
Inventories consist primarily of purchased components and finished goods and are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. A provision is recorded when inventory is determined to be in excess of anticipated demand or obsolete in order to adjust inventory to its estimated realizable value. The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our inventories:

[0000950170-25-083705:mdna:199]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | We periodically perform an excess and obsolete analysis of our inventory. Inventories are written down based on excess and obsolete reserves determined primarily on assumptions about future demand forecasts and market conditions. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. |  |  | Although we use our best estimates to forecast future product demand, any significant unanticipated changes in demand, including due to macroeconomic uncertainties, or obsolescence related to technological developments, new product introductions, customer requirements, competition or other factors could have a significant impact on the valuation of our inventory. If actual market conditions are less favorable than those projected, additional write-downs and other charges against earnings that adversely impact gross margins may be required. If actual market conditions are more favorable, we may realize higher gross profits in the period when the written-down inventory is sold. We are subject to a variety of environmental laws relating to the manufacture of our products. If there are changes to the current regulations, we may be required to make product design changes which may result in excess or obsolete inventory, which could adversely impact our operating results. |
|  | We make commitments to our third-party contract manufacturers and other suppliers to manage lead times and meet product forecasts and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on non-cancelable purchase commitments when we believe it is probable that the components will not be utilized in future operations. |  |  | If the actual materials demand is significantly lower than our forecast, we may be required to increase our recorded liabilities for estimated losses on non-cancelable purchase commitments. |

[0000950170-25-083705:mdna:200]
Goodwill and Purchased Intangible Assets

[0000950170-25-083705:mdna:201]
We allocate the purchase price of acquisitions to identifiable assets acquired and liabilities assumed at their acquisition date fair values based on established valuation techniques. Goodwill represents the residual value as of the acquisition date, which in most cases is measured as the excess of the purchase consideration transferred over the net of the acquisition date fair values of the assets acquired and liabilities assumed.

[0000950170-25-083705:mdna:202]
The carrying values of purchased intangible assets are reviewed whenever events and circumstances indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. We periodically review the estimated remaining useful lives of our intangible assets. This review may result in impairment charges or shortened useful lives, resulting in charges to our consolidated statements of income.

[0000950170-25-083705:mdna:203]
49

[0000950170-25-083705:mdna:204]
We review goodwill for impairment annually and whenever events or changes in circumstances indicate the carrying amount of one of our reporting units may exceed its fair value. The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. For our annual goodwill impairment test in the fourth quarter of fiscal 2025, we performed a qualitative assessment of goodwill impairment by evaluating relevant factors to determine whether it is more likely than not that the fair value of each of our reporting units is less than their carrying values. As a result of the qualitative assessment, we determined the quantitative test was not necessary and there was no impairment of goodwill.

[0000950170-25-083705:mdna:205]
50

[0000950170-25-083705:mdna:206]
The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our goodwill and purchased intangible assets:

[0000950170-25-083705:mdna:207]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the accounting guidance for the fair value measurement of nonfinancial assets.The valuation of purchased intangible assets is principally based on estimates of the future performance and cash flows expected to be generated by the acquired assets from the acquired business. |  |  | While we employ experts to determine the acquisition date fair value of acquired intangibles, the fair values of assets acquired and liabilities assumed are based on significant management assumptions and estimates, which are inherently uncertain and highly subjective and as a result, actual results may differ from estimates. If different assumptions were to be used, it could materially impact the purchase price allocation. |
|  | Evaluations of possible goodwill and purchased intangible asset impairment require us to make judgments and assumptions related to the allocation of our balance sheet and income statement amounts and estimate future cash flows and fair market values of our reporting units and assets. |  |  | In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill or purchased intangible assets. Assumptions and estimates about expected future cash flows and the fair values of our reporting units and purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as the adverse impact of unanticipated changes in macroeconomic conditions, and technological changes or new product introductions from competitors. They can also be affected by internal factors such as changes in business strategy or in forecasted product life cycles and roadmaps. Our ongoing consideration of these and other factors could result in future impairment charges or accelerated amortization expense, which could adversely affect our operating results. |

[0000950170-25-083705:mdna:208]
Income Taxes

[0000950170-25-083705:mdna:209]
We are subject to income taxes in the United States and numerous foreign jurisdictions. We compute our provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets or liabilities are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0000950170-25-083705:mdna:210]
The following are the key estimates and assumptions and corresponding uncertainties for our income taxes:

[0000950170-25-083705:mdna:211]
51

[0000950170-25-083705:mdna:212]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | Our income tax provision is based on existing tax law and advanced pricing agreements or letter rulings we have with various tax authorities. |  |  | Our provision for income taxes is subject to volatility and could be adversely impacted by future changes in existing tax laws, such as a change in tax rate, possible U.S. changes to the taxation of earnings of our foreign subsidiaries, and uncertainties as to future renewals of favorable tax agreements and rulings. |
|  | The determination of whether we should record or adjust a valuation allowance against our deferred tax assets is based on assumptions regarding our future profitability. |  |  | Our future profits could differ from current expectations resulting in a change to our determination as to the amount of deferred tax assets that are more likely than not to be realized. We could adjust our valuation allowance with a corresponding impact to the tax provision in the period in which such determination is made. |
|  | The estimates for our uncertain tax positions are based primarily on company specific circumstances, applicable tax laws, tax opinions from outside firms and past results from examinations of our income tax returns. |  |  | Significant judgment is required in evaluating our uncertain tax positions. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome or tax court rulings of these matters will not be different from that which is reflected in our historical tax provisions and accruals. |
