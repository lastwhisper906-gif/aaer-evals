# NTAP MD&A — 0000950170-22-025960


## mdna

[0000950170-22-025960:mdna:1]
[same as prior period, unchanged from 0000950170-22-017904:mdna:1]

[0000950170-22-025960:mdna:2]
[same as prior period, unchanged from 0000950170-22-017904:mdna:3]

[0000950170-22-025960:mdna:3]
[same as prior period, unchanged from 0000950170-22-017904:mdna:4]

[0000950170-22-025960:mdna:4]
[same as prior period, unchanged from 0000950170-22-017904:mdna:5]

[0000950170-22-025960:mdna:5]
[same as prior period, unchanged from 0000950170-22-017904:mdna:6]

[0000950170-22-025960:mdna:6]
[same as prior period, unchanged from 0000950170-22-017904:mdna:7]

[0000950170-22-025960:mdna:7]
[same as prior period, unchanged from 0000950170-22-017904:mdna:8]

[0000950170-22-025960:mdna:8]
[same as prior period, unchanged from 0000950170-22-017904:mdna:9]

[0000950170-22-025960:mdna:9]
[same as prior period, unchanged from 0000950170-22-017904:mdna:10]

[0000950170-22-025960:mdna:10]
Continuing global economic uncertainty, political conditions and fiscal challenges in the U.S. and abroad have resulted, and could continue to result in adverse macroeconomic conditions, including inflation, rising interest rates, foreign exchange volatility, slower growth or recession. In particular, during the first six months of fiscal 2023, we continued to experience inflationary pressure, constraints in our supply chain and foreign exchange volatility. We also observed a slowdown in customer demand during the second quarter of fiscal 2023 as a result of continuing global economic uncertainty.

[0000950170-22-025960:mdna:11]
Ongoing supply chain constraints, which substantially began to impact us in the second half of fiscal 2022, led to higher product component and freight costs in the first six months of fiscal 2023 than incurred in the first six months of fiscal 2022, and increased our cost of revenues. Supply chain constraints also delayed our ability to fulfill certain customer orders during the first six months of fiscal 2023.

[0000950170-22-025960:mdna:12]
If these macroeconomic uncertainties or supply chain challenges persist or worsen in the second half of fiscal 2023, we may continue to observe reduced customer demand for our offerings, increased competition for critical components, challenges fulfilling certain customer orders or continued increases in component and freight costs, any of which could impact our operating results, including our ability to achieve historical levels of revenue growth.

[0000950170-22-025960:mdna:13]
[same as prior period, unchanged from 0000950170-22-017904:mdna:14]

[0000950170-22-025960:mdna:14]
The COVID-19 pandemic and efforts to control its spread have significantly curtailed the movement of people, goods and services worldwide, including in many of the regions in which we sell our products and services and conduct our business operations. We have taken precautionary measures intended to minimize the risk of the virus to our employees, our customers, and the communities in which we operate. Since March 2020, the vast majority of our employees have been working remotely.

[0000950170-22-025960:mdna:15]
[same as prior period, unchanged from 0000950170-22-017904:mdna:16]

[0000950170-22-025960:mdna:16]
Beginning in February 2022, in response to Russian military actions in Ukraine, the U.S. and other countries imposed sanctions on Russia, and we suspended business operations, including sales, support on existing contracts and professional services, in Russia and Belarus. In the second quarter of fiscal 2023, we discontinued business operations in Russia, Belarus, and certain regions of Ukraine. The impact of these actions was not significant to our results in either the second quarter or first six months of fiscal 2023.

[0000950170-22-025960:mdna:17]
[same as prior period, unchanged from 0000950170-22-017904:mdna:18]

[0000950170-22-025960:mdna:18]
[same as prior period, unchanged from 0000950170-22-017904:mdna:19]

[0000950170-22-025960:mdna:19]
28

[0000950170-22-025960:mdna:20]
During the first six months of fiscal 2023, we repurchased approximately 7 million shares of our common stock at an average price of $67.70 per share, for an aggregate of $500 million. We also declared aggregate cash dividends of $0.50 per share in that period, for which we paid $218 million.

[0000950170-22-025960:mdna:21]
[same as prior period, unchanged from 0000950170-22-017904:mdna:24]

[0000950170-22-025960:mdna:22]
In the first six months of fiscal 2023, we executed a restructuring plan to redirect resources to highest return activities, and also continued restructuring activities related to the establishment of an international headquarters. Aggregate restructuring charges incurred under these two plans during the second quarter and first six months totaled $11 million and $22 million, respectively.

[0000950170-22-025960:mdna:23]
As part of the establishment of our international headquarters, we executed an intra-entity transfer of certain intellectual property which resulted in the recognition of a discrete tax benefit of $524 million in the second quarter of fiscal 2023.

[0000950170-22-025960:mdna:24]
[same as prior period, unchanged from 0000950170-22-017904:mdna:26]

[0000950170-22-025960:mdna:25]
[same as prior period, unchanged from 0000950170-22-017904:mdna:27]

[0000950170-22-025960:mdna:26]
[same as prior period, unchanged from 0000950170-22-017904:mdna:28]

[0000950170-22-025960:mdna:27]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | October 28, 2022 |  |  | October 29, 2021 |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 50 | % |  |  | 52 | % |  |  | 50 | % |  |  | 51 | % |  |
| Services |  |  | 50 |  |  |  | 48 |  |  |  | 50 |  |  |  | 49 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 25 |  |  |  | 24 |  |  |  | 25 |  |  |  | 23 |  |  |
| Cost of services |  |  | 10 |  |  |  | 9 |  |  |  | 9 |  |  |  | 9 |  |  |
| Gross profit |  |  | 65 |  |  |  | 68 |  |  |  | 66 |  |  |  | 68 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 29 |  |  |  | 30 |  |  |  | 29 |  |  |  | 30 |  |  |
| Research and development |  |  | 15 |  |  |  | 14 |  |  |  | 15 |  |  |  | 14 |  |  |
| General and administrative |  |  | 4 |  |  |  | 5 |  |  |  | 4 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Total operating expenses |  |  | 48 |  |  |  | 49 |  |  |  | 49 |  |  |  | 50 |  |  |
| Income from operations |  |  | 17 |  |  |  | 19 |  |  |  | 16 |  |  |  | 18 |  |  |
| Other income (expense), net |  |  | 1 |  |  |  | (1 | ) |  |  | 1 |  |  |  | (1 | ) |  |
| Income before income taxes |  |  | 18 |  |  |  | 18 |  |  |  | 18 |  |  |  | 17 |  |  |
| (Benefit) provision for income taxes |  |  | (27 | ) |  |  | 4 |  |  |  | (12 | ) |  |  | 3 |  |  |
| Net income |  |  | 45 | % |  |  | 14 | % |  |  | 30 | % |  |  | 14 | % |  |

[0000950170-22-025960:mdna:28]
[same as prior period, unchanged from 0000950170-22-017904:mdna:30]

[0000950170-22-025960:mdna:29]
[same as prior period, unchanged from 0000950170-22-017904:mdna:31]

[0000950170-22-025960:mdna:30]
[same as prior period, unchanged from 0000950170-22-017904:mdna:32]

[0000950170-22-025960:mdna:31]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |
| Net revenues |  | $ | 1,663 |  |  | $ | 1,566 |  |  |  | 6 | % |  | $ | 3,255 |  |  | $ | 3,024 |  |  |  | 8 | % |

[0000950170-22-025960:mdna:32]
The increase in net revenues for the second quarter and first six months of fiscal 2023 compared to the corresponding periods of fiscal 2022 was due to an increase in both product revenues and services revenues. Product revenues as a percentage of net revenues decreased by less than two percentage points in the second quarter and first six months of fiscal 2023, respectively, compared to the corresponding periods of fiscal 2022. Fluctuations in foreign currency exchange rates adversely impacted net revenues percent growth by approximately five percentage points in both the second quarter and first six months of fiscal 2023 compared to the corresponding periods of fiscal 2022.

[0000950170-22-025960:mdna:33]
[same as prior period, unchanged from 0000950170-22-017904:mdna:67]

[0000950170-22-025960:mdna:34]
[same as prior period, unchanged from 0000950170-22-017904:mdna:36]

[0000950170-22-025960:mdna:35]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |
| Product revenues |  | $ | 837 |  |  | $ | 814 |  |  |  | 3 | % |  | $ | 1,623 |  |  | $ | 1,544 |  |  |  | 5 | % |
| Hardware (Non-GAAP) |  |  | 342 |  |  |  | 339 |  |  |  | 1 | % |  |  | 652 |  |  |  | 655 |  |  |  | — | % |
| Software (Non-GAAP) |  |  | 495 |  |  |  | 475 |  |  |  | 4 | % |  |  | 971 |  |  |  | 889 |  |  |  | 9 | % |

[0000950170-22-025960:mdna:36]
[same as prior period, unchanged from 0000950170-22-017904:mdna:38]

[0000950170-22-025960:mdna:37]
[same as prior period, unchanged from 0000950170-22-017904:mdna:39]

[0000950170-22-025960:mdna:38]
[same as prior period, unchanged from 0000950170-22-017904:mdna:40]

[0000950170-22-025960:mdna:39]
Total product revenues increased in the second quarter and first six months of fiscal 2023 compared to the corresponding periods of the prior year primarily driven by an increase in sales of hybrid systems, despite the unfavorable impact from foreign exchange rate fluctuations.

[0000950170-22-025960:mdna:40]
Revenues from the hardware component of product revenues represented 41% and 40% of product revenues in the second quarter and first six months of fiscal 2023, compared to 42% of product revenues in the corresponding periods of the prior year. The software component of product revenues represented 59% and 60% of product revenues in the second quarter and first six months of fiscal 2023, compared to 58% of product revenues in the corresponding periods of the prior year. The increase in the software component percentage of product revenues in the second quarter and first six months of fiscal 2023 was primarily due to the mix of systems sold.

[0000950170-22-025960:mdna:41]
[same as prior period, unchanged from 0000950170-22-017904:mdna:43]

[0000950170-22-025960:mdna:42]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |
| Services revenues |  | $ | 826 |  |  | $ | 752 |  |  |  | 10 | % |  | $ | 1,632 |  |  | $ | 1,480 |  |  |  | 10 | % |
| Support |  |  | 607 |  |  |  | 590 |  |  |  | 3 | % |  |  | 1,205 |  |  |  | 1,168 |  |  |  | 3 | % |
| Professional and other services |  |  | 77 |  |  |  | 75 |  |  |  | 3 | % |  |  | 153 |  |  |  | 146 |  |  |  | 5 | % |
| Public cloud |  |  | 142 |  |  |  | 87 |  |  |  | 63 | % |  |  | 274 |  |  |  | 166 |  |  |  | 65 | % |

[0000950170-22-025960:mdna:43]
[same as prior period, unchanged from 0000950170-22-017904:mdna:45]

[0000950170-22-025960:mdna:44]
[same as prior period, unchanged from 0000950170-22-017904:mdna:46]

[0000950170-22-025960:mdna:45]
Support revenues increased in the second quarter and first six months of fiscal 2023 compared to the corresponding periods of the prior year, primarily due to growth in sales of all-flash systems (which carry a higher support dollar content than our other products) in recent periods, and a higher aggregate support contract value for our installed based in the current year, despite the unfavorable impact from foreign exchange rate fluctuations.

[0000950170-22-025960:mdna:46]
Professional and other services revenues increased in the second quarter and first six months of fiscal 2023 compared to the corresponding periods of the prior year primarily due to an increase in demand from increased product sales.

[0000950170-22-025960:mdna:47]
[same as prior period, unchanged from 0000950170-22-017904:mdna:49]

[0000950170-22-025960:mdna:48]
[same as prior period, unchanged from 0000950170-22-017904:mdna:50]

[0000950170-22-025960:mdna:49]
30

[0000950170-22-025960:mdna:50]
Public Cloud revenues increased in the second quarter and first six months of fiscal 2023 compared to the corresponding periods of the prior year primarily due to strong customer demand for NetApp’s diversified cloud offerings, coupled with overall growth in the cloud market, and the acquisitions of Instaclustr early in the first quarter of fiscal 2023 and CloudCheckr in the third quarter of fiscal 2022.

[0000950170-22-025960:mdna:51]
[same as prior period, unchanged from 0000950170-22-017904:mdna:52]

[0000950170-22-025960:mdna:52]
[same as prior period, unchanged from 0000950170-22-017904:mdna:53]

[0000950170-22-025960:mdna:53]
[same as prior period, unchanged from 0000950170-22-017904:mdna:54]

[0000950170-22-025960:mdna:54]
[same as prior period, unchanged from 0000950170-22-017904:mdna:55]

[0000950170-22-025960:mdna:55]
[same as prior period, unchanged from 0000950170-22-017904:mdna:56]

[0000950170-22-025960:mdna:56]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |
| Cost of product revenues |  | $ | 418 |  |  | $ | 372 |  |  |  | 12 | % |  | $ | 815 |  |  | $ | 701 |  |  |  | 16 | % |
| Hybrid Cloud |  |  | 417 |  |  |  | 369 |  |  |  | 13 | % |  |  | 812 |  |  |  | 695 |  |  |  | 17 | % |
| Unallocated |  |  | 1 |  |  |  | 3 |  |  |  | (67 | )% |  |  | 3 |  |  |  | 6 |  |  |  | (50 | )% |

[0000950170-22-025960:mdna:57]
[same as prior period, unchanged from 0000950170-22-017904:mdna:58]

[0000950170-22-025960:mdna:58]
Cost of Hybrid Cloud product revenues represented 50% of product revenues for the second quarter and first six months of fiscal 2023 compared to 46% and 45% for the corresponding periods of fiscal 2022. Materials costs represented 95% and 94% of cost of Hybrid Cloud product revenues for the second quarter and first six months of fiscal 2023, respectively, compared to 92% and 91% for the corresponding periods of fiscal 2022.

[0000950170-22-025960:mdna:59]
Materials costs increased by approximately $54 million and $126 million in the second quarter and first six months of fiscal 2023 compared to the corresponding periods of the prior year, reflecting the increases in product revenues, the mix of systems sold, and higher component and freight costs as a result of COVID-19 related supply chain challenges.

[0000950170-22-025960:mdna:60]
Hybrid Cloud product gross margins decreased by approximately four percentage points and five percentage points in the second quarter and first six months of fiscal 2023, respectively, compared to the corresponding periods of the prior year, primarily due to the impact of higher component and freight costs, and the adverse impacts of fluctuations in foreign currency exchange rates on product revenues.

[0000950170-22-025960:mdna:61]
[same as prior period, unchanged from 0000950170-22-017904:mdna:62]

[0000950170-22-025960:mdna:62]
Unallocated cost of product revenues decreased in the second quarter and first six months of fiscal 2023 compared to the corresponding periods of the prior year due to certain intangible assets becoming fully amortized during the first quarter of fiscal 2023.

[0000950170-22-025960:mdna:63]
[same as prior period, unchanged from 0000950170-22-017904:mdna:64]

[0000950170-22-025960:mdna:64]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |
| Cost of services revenues |  | $ | 158 |  |  | $ | 135 |  |  |  | 17 | % |  | $ | 307 |  |  | $ | 265 |  |  |  | 16 | % |
| Support |  |  | 45 |  |  |  | 48 |  |  |  | (6 | )% |  |  | 88 |  |  |  | 96 |  |  |  | (8 | )% |
| Professional and other services |  |  | 54 |  |  |  | 54 |  |  |  | — | % |  |  | 106 |  |  |  | 105 |  |  |  | 1 | % |
| Public cloud |  |  | 45 |  |  |  | 25 |  |  |  | 80 | % |  |  | 85 |  |  |  | 48 |  |  |  | 77 | % |
| Unallocated |  |  | 14 |  |  |  | 8 |  |  |  | 75 | % |  |  | 28 |  |  |  | 16 |  |  |  | 75 | % |

[0000950170-22-025960:mdna:65]
[same as prior period, unchanged from 0000950170-22-017904:mdna:66]

[0000950170-22-025960:mdna:66]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, decreased in the second quarter and first six months of fiscal 2023 compared to the corresponding periods of fiscal 2022. Cost of Hybrid Cloud services revenues represented approximately 14% of Hybrid Cloud services revenues in the second quarter and first six months of fiscal 2023, compared to 15% for the corresponding periods of fiscal 2022.

[0000950170-22-025960:mdna:67]
Hybrid Cloud support gross margins increased by one percentage point in the second quarter and first six months of fiscal 2023 compared to the corresponding periods of the prior year due to growth in support revenues achieved with a slightly reduced cost base resulting from operational efficiencies. Hybrid Cloud professional and other services gross margins increased by two percentage points and three percentage points in the second quarter and first six months of fiscal 2023, respectively, compared to the corresponding periods of the prior year due to the mix of services provided.

[0000950170-22-025960:mdna:68]
[same as prior period, unchanged from 0000950170-22-017904:mdna:70]

[0000950170-22-025960:mdna:69]
Cost of Public Cloud revenues increased in the second quarter and first six months of fiscal 2023 compared to the corresponding periods of fiscal 2022 reflecting the increase in Public Cloud revenues. Public Cloud gross margins decreased by three percentage points and two percentage points in the second quarter and first six months of fiscal 2023, respectively, compared to the corresponding periods of fiscal 2022, primarily due to the mix of offerings provided.

[0000950170-22-025960:mdna:70]
[same as prior period, unchanged from 0000950170-22-017904:mdna:72]

[0000950170-22-025960:mdna:71]
Unallocated cost of services revenues increased in the second quarter and first six months of fiscal 2023 compared to the corresponding periods of the prior year due to our acquisitions of Instaclustr in the first quarter of fiscal 2023 and CloudCheckr in the third quarter of fiscal 2022, which resulted in higher amortization expense from acquired intangible assets.

[0000950170-22-025960:mdna:72]
[same as prior period, unchanged from 0000950170-22-017904:mdna:74]

[0000950170-22-025960:mdna:73]
[same as prior period, unchanged from 0000950170-22-017904:mdna:75]

[0000950170-22-025960:mdna:74]
Sales and marketing, research and development, and general and administrative expenses for the second quarter and first six months of fiscal 2023 totaled $789 million, or 47% of net revenues, and $1,559 million, or 48% of net revenues, respectively, reflecting a decrease of one percentage point each, compared to the corresponding periods of fiscal 2022, primarily as a result of scaling our cost structure as revenues grow.

[0000950170-22-025960:mdna:75]
While fluctuations in foreign currency exchange rates adversely impacted net revenues in the second quarter and first six months of fiscal 2023 compared to the corresponding periods of fiscal 2022, they favorably impacted operating expenses by approximately 4% and 3%, respectively.

[0000950170-22-025960:mdna:76]
[same as prior period, unchanged from 0000950170-22-017904:mdna:77]

[0000950170-22-025960:mdna:77]
Total compensation costs included in operating expenses increased by $30 million, or 7%, in the second quarter of fiscal 2023 compared to the corresponding period of the prior year, primarily as a result of a 12% increase in average headcount.

[0000950170-22-025960:mdna:78]
Total compensation costs included in operating expenses increased by $86 million, or 10%, in the first six months of fiscal 2023 compared to the corresponding period of the prior year, primarily as a result of an 11% increase in average headcount.

[0000950170-22-025960:mdna:79]
[same as prior period, unchanged from 0000950170-22-017904:mdna:79]

[0000950170-22-025960:mdna:80]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 479 |  |  | $ | 465 |  |  |  | 3 | % |  | $ | 937 |  |  | $ | 916 |  |  |  | 2 | % |

[0000950170-22-025960:mdna:81]
[same as prior period, unchanged from 0000950170-22-017904:mdna:81]

[0000950170-22-025960:mdna:82]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2023 to Fiscal 2022 |  |  | Fiscal 2023 to Fiscal 2022 |  |
| Compensation costs |  |  | 2 |  |  |  | 3 |  |
| Commissions |  |  | (2 | ) |  |  | (2 | ) |
| Travel and entertainment |  |  | 2 |  |  |  | 1 |  |
| Other |  |  | 1 |  |  |  | — |  |
| Total change |  |  | 3 |  |  |  | 2 |  |

[0000950170-22-025960:mdna:83]
The increase in compensation costs for the second quarter and first six months of fiscal 2023, compared to the corresponding periods of the prior year reflected an increase in average headcount of approximately 10% and 9%, respectively. The expansion of our sales and marketing teams are expected to support our ability to execute on key market opportunities. The impact of the increase in headcount was partially offset by the impact of foreign exchange rate fluctuations.

[0000950170-22-025960:mdna:84]
The decrease in commissions expense for the second quarter and first six months of fiscal 2023 compared to the corresponding periods of the prior year was primarily due to lower performance against sales goals.

[0000950170-22-025960:mdna:85]
Travel and entertainment expense increased in the second quarter and first six months of fiscal 2023 compared to the corresponding periods of the prior year as COVID-19 related travel restrictions eased.

[0000950170-22-025960:mdna:86]
[same as prior period, unchanged from 0000950170-22-017904:mdna:86]

[0000950170-22-025960:mdna:87]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |
| Research and development expenses |  | $ | 243 |  |  | $ | 216 |  |  |  | 13 | % |  | $ | 483 |  |  | $ | 426 |  |  |  | 13 | % |

[0000950170-22-025960:mdna:88]
[same as prior period, unchanged from 0000950170-22-017904:mdna:88]

[0000950170-22-025960:mdna:89]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2023 to Fiscal 2022 |  |  | Fiscal 2023 to Fiscal 2022 |  |
| Compensation costs |  |  | 9 |  |  |  | 12 |  |
| Development projects and outside services |  |  | 2 |  |  |  | 1 |  |
| Other |  |  | 2 |  |  |  | — |  |
| Total change |  |  | 13 |  |  |  | 13 |  |

[0000950170-22-025960:mdna:90]
The increase in compensation costs for the second quarter and first six months of fiscal 2023 compared to the corresponding periods in the prior year was primarily attributable to an increase in average headcount of 16% and 14%, respectively. The expansion of our research and development teams are expected to support our ability to continue expanding and enhancing our portfolio offerings. The impact of the increase in headcount was partially offset by the impact of foreign exchange rate fluctuations.

[0000950170-22-025960:mdna:91]
The increase in development projects and outside services for the second quarter and first six months of fiscal 2023 compared to the corresponding periods in the prior year was primarily due to the higher spending on certain engineering projects.

[0000950170-22-025960:mdna:92]
[same as prior period, unchanged from 0000950170-22-017904:mdna:91]

[0000950170-22-025960:mdna:93]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |
| General and administrative expenses |  | $ | 67 |  |  | $ | 76 |  |  |  | (12 | )% |  | $ | 139 |  |  | $ | 142 |  |  |  | (2 | )% |

[0000950170-22-025960:mdna:94]
[same as prior period, unchanged from 0000950170-22-017904:mdna:93]

[0000950170-22-025960:mdna:95]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2023 to Fiscal 2022 |  |  | Fiscal 2023 to Fiscal 2022 |  |
| Compensation costs |  |  | (1 | ) |  |  | 3 |  |
| Professional and legal fees and outside services |  |  | (8 | ) |  |  | (3 | ) |
| Facilities and IT support costs |  |  | (7 | ) |  |  | (5 | ) |
| Other |  |  | 4 |  |  |  | 3 |  |
| Total change |  |  | (12 | ) |  |  | (2 | ) |

[0000950170-22-025960:mdna:96]
The decrease in compensation costs in the second quarter of fiscal 2023 compared to the corresponding period of the prior year was primarily attributable to lower incentive compensation expense, partially offset by the increase in salaries, benefits and stock-based compensation expenses.

[0000950170-22-025960:mdna:97]
The increase in compensation costs in the first six months of fiscal 2023 compared to the corresponding periods of the prior year was primarily attributable to the increase in salaries, benefits and stock-based compensation expenses, partially offset by the decrease in incentive compensation expense.

[0000950170-22-025960:mdna:98]
The decrease in professional and legal fees and outside services expense in the second quarter and the first six months of fiscal 2023 was primarily due to lower spending on business transformation projects and a decrease in legal fees.

[0000950170-22-025960:mdna:99]
The decrease in facilities and IT support costs in the second quarter and first six months of fiscal 2023 was primarily related to lower spending for certain IT projects.

[0000950170-22-025960:mdna:100]
[same as prior period, unchanged from 0000950170-22-017904:mdna:96]

[0000950170-22-025960:mdna:101]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |
| Restructuring charges |  | $ | 11 |  |  | $ | 7 |  |  |  | 57 | % |  | $ | 22 |  |  | $ | 29 |  |  |  | (24 | )% |

[0000950170-22-025960:mdna:102]
In the second quarter and first six months of fiscal 2023, we recognized $11 million and $22 million, respectively, in restructuring charges, which consisted primarily of severance-related costs, legal costs and tax-related consulting costs, for ongoing restructuring activities related to the establishment of an international headquarters in Cork, Ireland, and a restructuring plan in the first six months of fiscal 2023 to redirect resources to highest return activities which resulted in a reduction of our global workforce by approximately 1%.

[0000950170-22-025960:mdna:103]
[same as prior period, unchanged from 0000950170-22-017904:mdna:101]

[0000950170-22-025960:mdna:104]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |
| Acquisition-related expense |  | $ | 5 |  |  | $ | 1 |  |  | NM |  | $ | 15 |  |  | $ | 2 |  |  | NM |

[0000950170-22-025960:mdna:105]
[same as prior period, unchanged from 0000950170-22-017904:mdna:103]

[0000950170-22-025960:mdna:106]
Acquisition-related expenses, primarily legal and consulting fees, totaled $5 million and $15 million in the second quarter and first six months of fiscal 2023, respectively, and were primarily related to our acquisition of Instaclustr US Holding, Inc.

[0000950170-22-025960:mdna:107]
[same as prior period, unchanged from 0000950170-22-017904:mdna:105]

[0000950170-22-025960:mdna:108]
[same as prior period, unchanged from 0000950170-22-017904:mdna:106]

[0000950170-22-025960:mdna:109]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  |
| Interest income |  | $ | 14 |  |  | $ | 1 |  |  | NM |  |  | $ | 21 |  |  | $ | 3 |  |  | NM |  |
| Interest expense |  |  | (17 | ) |  |  | (18 | ) |  |  | (6 | )% |  |  | (35 | ) |  |  | (36 | ) |  |  | (3 | )% |
| Other, net |  |  | 26 |  |  |  | 3 |  |  | NM |  |  |  | 52 |  |  |  | 7 |  |  | NM |  |
| Total |  | $ | 23 |  |  | $ | (14 | ) |  | NM |  |  | $ | 38 |  |  | $ | (26 | ) |  | NM |  |

[0000950170-22-025960:mdna:110]
[same as prior period, unchanged from 0000950170-22-017904:mdna:108]

[0000950170-22-025960:mdna:111]
Interest income increased in the second quarter and first six months of fiscal 2023 compared to the corresponding periods of the prior year due primarily to higher yields earned on our cash and investments. Interest expense remained flat in the second quarter and first six months of fiscal 2023 compared to the corresponding periods of fiscal 2022.

[0000950170-22-025960:mdna:112]
In the second quarter of fiscal 2023, Other, net includes $21 million of other income for non-refundable, up-front payments from customers in Russia for support contracts, which we were not able to fulfill due to imposed sanctions and for which we have no remaining legal obligation to perform. Other, net for the first six months of fiscal 2023 also includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million. The remaining differences in Other, net for the second quarter and first six months of fiscal 2023 as compared to the corresponding periods of the prior year are partially due to foreign exchange gains and losses year-over-year.

[0000950170-22-025960:mdna:113]
[same as prior period, unchanged from 0000950170-22-017904:mdna:111]

[0000950170-22-025960:mdna:114]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |  | October 28, 2022 |  |  | October 29, 2021 |  |  | % Change |
| (Benefit) provision for income taxes |  | $ | (445 | ) |  | $ | 56 |  |  | NM |  | $ | (389 | ) |  | $ | 91 |  |  | NM |

[0000950170-22-025960:mdna:115]
NM – Not Meaningful

[0000950170-22-025960:mdna:116]
Our effective tax rate for the three and six months ended October 28, 2022, decreased compared to the corresponding periods of the prior year, primarily due to the discrete tax benefit resulting from an intra-entity asset transfer of certain IP.

[0000950170-22-025960:mdna:117]
During the second quarter of fiscal 2023, we completed an intra-entity asset transfer of certain IP to our international headquarters (the “IP Transfer”). The transaction resulted in a step-up of tax-deductible basis in the transferred assets, and accordingly, created a temporary difference where the tax basis exceeded the financial statement basis of such intangible assets, which resulted in the recognition of a discrete tax benefit and related deferred tax asset of $524 million during the second quarter of fiscal 2023.  Management applied significant judgment when determining the fair value of the IP, which serves as the tax basis of the deferred tax asset. With the assistance of third-party valuation specialists, the fair value of the IP was determined principally based on the present value of projected cash flows related to the IP which reflects management’s assumptions regarding projected revenues, expenses and a discount rate. The tax-deductible amortization related to the transferred IP rights will be recognized in future periods and any amortization that is unused in a particular year can be carried forward indefinitely. The deferred tax asset and the tax benefit were measured based on the enacted tax rates expected to apply in the years the asset is expected to be realized. We expect to realize the deferred tax asset resulting from the IP Transfer and will assess the realizability of the deferred tax asset quarterly. Any Organisation for Economic Co-operation and Development’s (“OECD”) actions adopted internationally, could impact our financial results in future periods. The impact of the transaction to net cash provided by or used in operating, investing and financing activities on the condensed consolidated statements of cash flows during the quarter ended October 28, 2022, was not material.

[0000950170-22-025960:mdna:118]
As of October 28, 2022, we had $225 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $140 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $140 million have been recorded in other long-term liabilities.

[0000950170-22-025960:mdna:119]
[same as prior period, unchanged from 0000950170-22-017904:mdna:115]

[0000950170-22-025960:mdna:120]
| (In millions) |  | October 28, 2022 |  |  | April 29, 2022 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,033 |  |  | $ | 4,134 |  |
| Principal amount of debt |  | $ | 2,400 |  |  | $ | 2,650 |  |

[0000950170-22-025960:mdna:121]
[same as prior period, unchanged from 0000950170-22-017904:mdna:117]

[0000950170-22-025960:mdna:122]
|  |  | Six Months Ended |  |
| (In millions) |  | October 28, 2022 |  |  | October 29, 2021 |  |
| Net cash provided by operating activities |  | $ | 495 |  |  | $ | 540 |  |
| Net cash used in investing activities |  |  | (916 | ) |  |  | (85 | ) |
| Net cash used in financing activities |  |  | (979 | ) |  |  | (461 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (43 | ) |  |  | (13 | ) |
| Net change in cash, cash equivalents and restricted cash |  | $ | (1,443 | ) |  | $ | (19 | ) |

[0000950170-22-025960:mdna:123]
[same as prior period, unchanged from 0000950170-22-017904:mdna:119]

[0000950170-22-025960:mdna:124]
As of October 28, 2022, our cash, cash equivalents and short-term investments were $3.0 billion, which represents a decrease of $1.1 billion for the first six months of fiscal 2023. The decrease was primarily due to $491 million, net of cash acquired, used for the acquisition of a privately-held company, $500 million paid for the repurchase of our common stock, $218 million used for the payment of dividends and $250 million repayment of our Senior Notes, partially offset by $495 million provided by operating activities. Net working capital was $1.2 billion as of October 28, 2022, a reduction of $784 million when compared to April 29, 2022, primarily due to the decrease in cash, cash equivalents and short-term investments discussed above.

[0000950170-22-025960:mdna:125]
[same as prior period, unchanged from 0000950170-22-017904:mdna:121]

[0000950170-22-025960:mdna:126]
During the first six months of fiscal 2023, we generated cash from operating activities of $495 million, reflecting net income of $964 million which was reduced by $524 million for non-cash deferred tax benefits and increased for non-cash depreciation and amortization expense of $117 million and non-cash stock-based compensation expense of $145 million, compared to $540 million of cash generated from operating activities during the first six months of fiscal 2022.

[0000950170-22-025960:mdna:127]
Significant changes in assets and liabilities in the first six months of fiscal 2023 included the following:

[0000950170-22-025960:mdna:128]
•
Accounts receivable decreased $313 million, reflecting typical lower billings in the first six months of fiscal 2023 compared to the last six months of fiscal 2022.

[0000950170-22-025960:mdna:129]
•
Accrued expenses decreased by $108 million, primarily due to employee compensation payouts related to fiscal year 2022 incentive compensation and commissions plans.

[0000950170-22-025960:mdna:130]
We expect that cash provided by operating activities may materially fluctuate in future periods due to a number of factors, including fluctuations in our operating results, shipping linearity, accounts receivable collections performance, inventory and supply chain management, vendor payment initiatives, and the timing and amount of compensation, income taxes and other payments.

[0000950170-22-025960:mdna:131]
[same as prior period, unchanged from 0000950170-22-017904:mdna:128]

[0000950170-22-025960:mdna:132]
During the first six months of fiscal 2023, we used $342 million for the purchases of investments, net of maturities and sales, and paid $142 million for capital expenditures, as compared to the same period of fiscal 2022, in which we generated $26 million from maturities and sales of investments, net of purchases, and paid $97 million for capital expenditures. During the first six months of fiscal 2023, we paid approximately $491 million, net of cash acquired for a privately-held company, as compared to $14 million, net of cash acquired, that we paid for a privately-held company in the first six months of fiscal 2022. Additionally, we received proceeds of $59 million from the sale of one of our minority investments during the first six months of fiscal 2023.

[0000950170-22-025960:mdna:133]
[same as prior period, unchanged from 0000950170-22-017904:mdna:130]

[0000950170-22-025960:mdna:134]
During the first six months of fiscal 2023, cash flows used in financing activities totaled $979 million and include $500 million for the repurchase of approximately 7 million shares of common stock, $218 million for the payment of dividends and $250 million to redeem our Senior Notes due in December 2022. During the first six months of fiscal 2022, cash flows used in financing activities totaled $461 million and included $225 million for the repurchase of approximately 3 million shares of common stock and $224 million for the payment of dividends.

[0000950170-22-025960:mdna:135]
[same as prior period, unchanged from 0000950170-22-017904:mdna:132]

[0000950170-22-025960:mdna:136]
[same as prior period, unchanged from 0000950170-22-017904:mdna:133]

[0000950170-22-025960:mdna:137]
Our principal sources of liquidity as of October 28, 2022 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-22-025960:mdna:138]
[same as prior period, unchanged from 0000950170-22-017904:mdna:135]

[0000950170-22-025960:mdna:139]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| Cash and cash equivalents |  | $ | 2,669 |  |  | $ | 4,112 |  |
| Short-term investments |  |  | 364 |  |  |  | 22 |  |
| Total |  | $ | 3,033 |  |  | $ | 4,134 |  |

[0000950170-22-025960:mdna:140]
As of October 28, 2022 and April 29, 2022, $1.4 billion and $2.3 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $1.6 billion and $1.8 billion, respectively, were available in the U.S.

[0000950170-22-025960:mdna:141]
[same as prior period, unchanged from 0000950170-22-017904:mdna:138]

[0000950170-22-025960:mdna:142]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of October 28, 2022.

[0000950170-22-025960:mdna:143]
[same as prior period, unchanged from 0000950170-22-017904:mdna:140]

[0000950170-22-025960:mdna:144]
[same as prior period, unchanged from 0000950170-22-017904:mdna:141]

[0000950170-22-025960:mdna:145]
The following table summarizes the principal amount of our Senior Notes as of October 28, 2022 (in millions):

[0000950170-22-025960:mdna:146]
|  |  | Amount |  |
| 3.30% Senior Notes Due September 2024 |  | $ | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,400 |  |

[0000950170-22-025960:mdna:147]
[same as prior period, unchanged from 0000950170-22-017904:mdna:144]

[0000950170-22-025960:mdna:148]
On September 15, 2022, we extinguished our 3.25% Senior Notes due December 2022 for an aggregate cash redemption price of $252 million, comprised of the principal and unpaid interest.

[0000950170-22-025960:mdna:149]
Commercial Paper Program and Credit Facility

[0000950170-22-025960:mdna:150]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of October 28, 2022.

[0000950170-22-025960:mdna:151]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of October 28, 2022, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-22-025960:mdna:152]
[same as prior period, unchanged from 0000950170-22-017904:mdna:149]

[0000950170-22-025960:mdna:153]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2023 to be between $100 million and $200 million.

[0000950170-22-025960:mdna:154]
Transition Tax Payments

[0000950170-22-025960:mdna:155]
The Tax Cuts and Jobs Act of 2017 imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits that had not previously been subject to U.S. income tax. As of October 28, 2022, outstanding payments related to the transition tax are estimated to be approximately $303 million of which $88 million, $115 million and $100 million are expected to be paid during fiscal 2024, fiscal 2025 and fiscal 2026, respectively. During the first six months of fiscal 2023, transition tax payments totaled $48 million. Our estimates for future transition tax payments, however, could change with further guidance or review from U.S. federal and state tax authorities or other regulatory bodies.

[0000950170-22-025960:mdna:156]
[same as prior period, unchanged from 0000950170-22-017904:mdna:151]

[0000950170-22-025960:mdna:157]
On November 21, 2022, we declared a cash dividend of $0.50 per share of common stock, payable on January 25, 2023, to holders of record as of the close of business on January 6, 2023.

[0000950170-22-025960:mdna:158]
As of October 28, 2022, our Board of Directors had authorized the repurchase of up to $15.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through October 28, 2022, we repurchased a total of 355 million shares of our common stock at an average price of $40.52 per share, for an aggregate purchase price of $14.4 billion. As of October 28, 2022, the remaining authorized amount for stock repurchases under this program was $0.7 billion.

[0000950170-22-025960:mdna:159]
[same as prior period, unchanged from 0000950170-22-017904:mdna:154]

[0000950170-22-025960:mdna:160]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled approximately $0.9 billion at October 28, 2022.

[0000950170-22-025960:mdna:161]
38

[0000950170-22-025960:mdna:162]
[same as prior period, unchanged from 0000950170-22-017904:mdna:156]

[0000950170-22-025960:mdna:163]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $10 million and $38 million of receivables during the first six months of fiscal 2023 and fiscal 2022, respectively.

[0000950170-22-025960:mdna:164]
[same as prior period, unchanged from 0000950170-22-017904:mdna:159]

[0000950170-22-025960:mdna:165]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of October 28, 2022 and April 29, 2022, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-22-025960:mdna:166]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of October 28, 2022, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-22-025960:mdna:167]
Legal Contingencies

[0000950170-22-025960:mdna:168]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0000950170-22-025960:mdna:169]
[same as prior period, unchanged from 0000950170-22-017904:mdna:164]

[0000950170-22-025960:mdna:170]
[same as prior period, unchanged from 0000950170-22-017904:mdna:165]

[0000950170-22-025960:mdna:171]
The summary of significant accounting policies is included under Item 7 – Management’s Discussion and Analysis of Financial Condition and Results of Operations of our fiscal 2022 Form 10-K. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. There have been no material changes to the critical accounting policies and estimates as filed in such report, except with respect to Income Taxes, specifically estimates related to the intra-entity asset transfer of the IP to our international headquarters during the second quarter of fiscal 2023. The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of the IP:

[0000950170-22-025960:mdna:172]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| · | The assessment of the fair value of the IP transferred to our international headquarters is based on factors that market participants would use in an orderly transaction in accordance with the accounting guidance for the fair value measurement of nonfinancial assets and transfer pricing principles from the Organisation for Economic Co-operation and Development. The valuation of our IP is principally based on estimates of the future performance and cash flows expected to be generated through use of the IP. |  | · | While we employ experts to determine the fair value of IP, its fair value is based on significant management assumptions and estimates, which are inherently uncertain and highly subjective and as a result, actual results may differ from estimates. If different assumptions were to be used, it could materially impact the IP valuation. Volatile macroeconomic and market conditions caused by the COVID-19 pandemic have increased the level of uncertainty and subjectivity of certain management assumptions and estimates. |

[0000950170-22-025960:mdna:173]
40
