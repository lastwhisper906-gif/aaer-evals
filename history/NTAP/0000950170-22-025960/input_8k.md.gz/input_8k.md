# NTAP 8-K — 0000950170-22-025793 filed 2022-11-29

## item codes, every 8-K on or before 2022-12-01

- 2022-11-29 0000950170-22-025793 — 2.02, 9.01
- 2022-11-16 0000950170-22-025317 — 5.02
- 2022-09-14 0000950170-22-018490 — 5.07
- 2022-08-24 0000950170-22-017731 — 2.02, 9.01
- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2022-12-01

- none on or before 2022-12-01

## item 2.02 — earnings release, exhibit 99.1

[0000950170-22-025793:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0000950170-22-025793:8k_2_02:2]
EX-99.1

[0000950170-22-025793:8k_2_02:3]
Exhibit 99.1

[0000950170-22-025793:8k_2_02:4]
NetApp reports second quarter of fiscal year 2023 results

[0000950170-22-025793:8k_2_02:5]
Delivers all time Q2 company highs for revenue, billings, gross profit dollars, operating income and EPS

[0000950170-22-025793:8k_2_02:6]
•
Net revenues for the second quarter grew 6% year-over-year to $1.66 billion, 12% in constant currency1

[0000950170-22-025793:8k_2_02:7]
•
Q2 product revenue grew 3% year-over-year to $837 million, the seventh consecutive quarter of year-over-year growth

[0000950170-22-025793:8k_2_02:8]
•
Q2 billings2 were $1.60 billion, an increase of 3% year-over-year, 9% in constant currency

[0000950170-22-025793:8k_2_02:9]
•
NetApp™ Public Cloud annualized revenue run rate (ARR)3 increased 55% year-over-year to $603 million

[0000950170-22-025793:8k_2_02:10]
•
All-flash array ARR4 increased 2% year-over-year to $3.1 billion

[0000950170-22-025793:8k_2_02:11]
•
$258 million returned to shareholders in share repurchases and cash dividends in the second quarter

[0000950170-22-025793:8k_2_02:12]
SAN JOSE, Calif.—November 29, 2022—NetApp (NASDAQ: NTAP) today reported financial results for the second quarter of fiscal year 2023, which ended on October 28, 2022.

[0000950170-22-025793:8k_2_02:13]
“We delivered a solid quarter in a dynamic environment, with all-time highs for Q2 revenue, billings, gross profit dollars, operating income, and EPS,” said George Kurian, chief executive officer. “Our modern approach to the hybrid multicloud delivers significant value to our customers and creates sizeable opportunity for us. In a challenging macro environment, we remain focused on innovation, execution, and operational discipline.”

[0000950170-22-025793:8k_2_02:14]
Second quarter of fiscal year 2023 financial results

[0000950170-22-025793:8k_2_02:15]
•
Net revenues: $1.66 billion, compared to $1.57 billion in the second quarter of fiscal year 2022.

[0000950170-22-025793:8k_2_02:16]
o
Hybrid Cloud segment revenue: $1.52 billion, compared to $1.48 billion in the second quarter of fiscal year 2022.

[0000950170-22-025793:8k_2_02:17]
o
Public Cloud segment revenue: $142 million, compared to $87 million in the second quarter of fiscal year 2022.

[0000950170-22-025793:8k_2_02:18]
•
Net income: GAAP net income of $750 million, compared to $224 million in the second quarter of fiscal year 2022; non-GAAP net income5 of $326 million, compared to $292 million in the second quarter of fiscal year 2022. The year-over-year fluctuations in GAAP and Non-GAAP net income each include an unfavorable impact of approximately $47 million from foreign currency exchange rate changes.

[0000950170-22-025793:8k_2_02:19]
•
Earnings per share: GAAP net income per share6 of $3.41, compared to $0.98 in the second quarter of fiscal year 2022; non-GAAP net income per share of $1.48, compared to $1.28 in the second quarter of fiscal year 2022. The year-over-year fluctuations in GAAP and Non-GAAP net income per share each include an unfavorable impact of approximately $0.21 from foreign currency exchange rate changes.

[0000950170-22-025793:8k_2_02:20]
•
Cash, cash equivalents and investments: $3.03 billion at the end of the second quarter of fiscal year 2023.

[0000950170-22-025793:8k_2_02:21]
•
Cash provided by operations: $214 million, compared to $298 million in the second quarter of fiscal year 2022.

[0000950170-22-025793:8k_2_02:22]
•
Share repurchase and dividends: Returned $258 million to shareholders through share repurchases and cash dividends.

[0000950170-22-025793:8k_2_02:23]
Third quarter of fiscal year 2023 financial outlook

[0000950170-22-025793:8k_2_02:24]
The Company provided the following financial guidance for the third quarter of fiscal year 2023:

[0000950170-22-025793:8k_2_02:25]
| Net revenues are expected to be in the range of: | $1.525 billion to $1.675 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $0.88 - $0.98 | $1.25 - $1.35 |

[0000950170-22-025793:8k_2_02:26]
Full fiscal year 2023 financial outlook

[0000950170-22-025793:8k_2_02:27]
The Company provided the following financial guidance for the full fiscal year 2023:

[0000950170-22-025793:8k_2_02:28]
| Net revenues are expected to grow in the range of: | 2% to 4% |
| Public Cloud ARR is expected to exit the fiscal year at: | ~$700 million |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 65% - 66% | 66% - 67% |
| Operating margins are expected to be: | ~17% | ~23% |
| Earnings per share is expected to be: | $6.29 - $6.49 | $5.30 - $5.50 |

[0000950170-22-025793:8k_2_02:29]
Dividend

[0000950170-22-025793:8k_2_02:30]
The next cash dividend of $0.50 per share is to be paid on January 25, 2023, to shareholders of record as of the close of business on January 6, 2023.

[0000950170-22-025793:8k_2_02:31]
Second quarter of fiscal year 2023 business highlights

[0000950170-22-025793:8k_2_02:32]
Leading product innovation

[0000950170-22-025793:8k_2_02:33]
•
NetApp launched ONTAP™ Essentials as an extension to Cloud Insights for all ONTAP customers as part of its advisor-level and higher support contracts.

[0000950170-22-025793:8k_2_02:34]
•
NetApp added several enhancements to NetApp SnapCenter™ to help customers tackle enterprise data protection challenges.

[0000950170-22-025793:8k_2_02:35]
•
Spot by NetApp launched a new API that returns Spot Ocean by NetApp managed nodes in a cluster, providing detailed information about the nodes in the cluster as well as Ocean related information.

[0000950170-22-025793:8k_2_02:36]
•
Spot by NetApp announced updates to Elastigroup, now supporting the use of multiple AMIs in a single Elastigroup.

[0000950170-22-025793:8k_2_02:37]
•
Spot by NetApp introduced Network Cost Analysis for Ocean, which provides Kubernetes application-level visibility of network cost and shows spend and usage trends.

[0000950170-22-025793:8k_2_02:38]
Customer and partner momentum

[0000950170-22-025793:8k_2_02:39]
•
NetApp and VMware expanded their alliance, helping customers reduce the cost, complexity, and risk of migrating and modernizing enterprise-class workloads in hybrid multicloud environments.

[0000950170-22-025793:8k_2_02:40]
•
VMware, in collaboration with NetApp and Amazon Web Services, announced the general availability of Amazon FSx for NetApp ONTAP with VMware Cloud on AWS.

[0000950170-22-025793:8k_2_02:41]
•
NetApp and VMware announced the expansion of the FlexPod™ hybrid cloud portfolio — with AWS, Azure, and Google Cloud — to offer a new FlexPod hybrid multicloud solution with VMware Cloud Foundation.

[0000950170-22-025793:8k_2_02:42]
•
Google Cloud leveraged NetApp to offer a secure, hybrid ecosystem that enables customers to accelerate the development of AI and ML for medical imaging with its Medical Imaging Suite on Google Cloud.

[0000950170-22-025793:8k_2_02:43]
•
Yale New Haven Health, the largest healthcare provider in Connecticut, transformed its AI and analytics with a unified data lake to support clinicians and patients with the help of NVIDIA and NetApp.

[0000950170-22-025793:8k_2_02:44]
•
Spot by NetApp helped Lacework drive DevOps productivity, leveraging Ocean to simplify cost management and automate optimization.

[0000950170-22-025793:8k_2_02:45]
Corporate news and events

[0000950170-22-025793:8k_2_02:46]
•
NetApp announced its intent to launch the NetApp Partner Sphere, its new holistic partner program, in NetApp fiscal year 2024.

[0000950170-22-025793:8k_2_02:47]
•
NetApp announced its 15th year of sponsorship and participation in the Grace Hopper Celebration (GHC), the largest global conference for women in technology.

[0000950170-22-025793:8k_2_02:48]
NetApp awards and recognition

[0000950170-22-025793:8k_2_02:49]
•
Gartner has placed NetApp in its Leader quadrant in the 2022 Magic Quadrant for Primary Storage7 for NetApp AFF all-flash array storage appliance and the NetApp Cloud Volumes ONTAP software-defined storage service.

[0000950170-22-025793:8k_2_02:50]
•
Gartner’s Critical Capabilities for Primary Storage study listed NetApp with the highest scores for Cloud IT Operations and Containers use cases.7

[0000950170-22-025793:8k_2_02:51]
•
GigaOm has named Spot by NetApp a leader and outperformer among 13 FinOps vendors evaluated, based on a combination of features, product innovation, and maturity in the FinOps marketplace.8

[0000950170-22-025793:8k_2_02:52]
•
NetApp AI was recognized by Frost & Sullivan with a 2022 Best Practices Enabling Technology Leadership Award in the North American AI healthcare solutions industry.9

[0000950170-22-025793:8k_2_02:53]
•
NetApp CEO George Kurian was named one of the Top 25 Most Influential Executives and Jenni Flinders, SVP, Worldwide Partner Organization, was included among the Top 25 Channel Sales Leaders in CRN’s Top 100 Executives of 2022.10

[0000950170-22-025793:8k_2_02:54]
•
Maarten van Velsen, senior director of Partner Sales Excellence at NetApp, was selected as one of CRN's  100 People You Don’t Know But Should for 2022.11

[0000950170-22-025793:8k_2_02:55]
•
NetApp won a 2022 Stratus Award presented by the Business Intelligence Group for best Hybrid Cloud Provider.12

[0000950170-22-025793:8k_2_02:56]
•
Maya Zakhour, area partner leader at NetApp, was the recipient of the Influential Business Leader of the Year Award at the Future Enterprise Awards 2022.13

[0000950170-22-025793:8k_2_02:57]
Webcast and conference call information

[0000950170-22-025793:8k_2_02:58]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:00 p.m. Pacific Time today.

[0000950170-22-025793:8k_2_02:59]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0000950170-22-025793:8k_2_02:60]
Footnotes

[0000950170-22-025793:8k_2_02:61]
1Refer to the Constant Currency section below for an explanation of constant currency growth rates and the impact of foreign currency exchange rate changes on year-over-year fluctuations in earnings.

[0000950170-22-025793:8k_2_02:62]
2Refer to the NetApp Usage of Non-GAAP Financial Information section below for an explanation of billings.

[0000950170-22-025793:8k_2_02:63]
3Public Cloud annualized revenue run rate (ARR) is calculated as the annualized value of all Public Cloud customer commitments with the assumption that any commitment expiring during the next 12 months will be renewed with its existing terms.

[0000950170-22-025793:8k_2_02:64]
4All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0000950170-22-025793:8k_2_02:65]
5Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) gains/losses on the sale of investments in equity securities, (i) debt extinguishment costs, and (j) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes that the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. 6GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0000950170-22-025793:8k_2_02:66]
7NetApp Blog, Gabie Boko, October 20, 2022. NetApp #1 in Cloud IT Operations & Containers for Primary Storage.

[0000950170-22-025793:8k_2_02:67]
8Spot by NetApp Blog, Courtney Wilson, August 4, 2022. GigaOm Radar: Spot Leads the Way in FinOps Tools.

[0000950170-22-025793:8k_2_02:68]
9NetApp Blog, Mike McNamara, October 20, 2022.

[0000950170-22-025793:8k_2_02:69]
10CRN, Staff Reporters, August 1, 2022.  The 25 Most Influential Executives Of 2022.

[0000950170-22-025793:8k_2_02:70]
11CRN, Jennifer Follette, September 26, 2022.The 100 People You Don’t Know But Should 2022.

[0000950170-22-025793:8k_2_02:71]
12Business Intelligence Group, September 27, 2022. 59 Leading Cloud Computing Companies, Products and Services.

[0000950170-22-025793:8k_2_02:72]
13Tahawultech.com, Daniel Shepherd, October 11, 2022. Future Enterprise Awards 2022 winners revealed.

[0000950170-22-025793:8k_2_02:73]
NetApp usage of non-GAAP financial information

[0000950170-22-025793:8k_2_02:74]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share. NetApp also presents the hardware and software components of our GAAP product revenues. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0000950170-22-025793:8k_2_02:75]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations.

[0000950170-22-025793:8k_2_02:76]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0000950170-22-025793:8k_2_02:77]
NetApp believes that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0000950170-22-025793:8k_2_02:78]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0000950170-22-025793:8k_2_02:79]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0000950170-22-025793:8k_2_02:80]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0000950170-22-025793:8k_2_02:81]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0000950170-22-025793:8k_2_02:82]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0000950170-22-025793:8k_2_02:83]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0000950170-22-025793:8k_2_02:84]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0000950170-22-025793:8k_2_02:85]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0000950170-22-025793:8k_2_02:86]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0000950170-22-025793:8k_2_02:87]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-22-025793:8k_2_02:88]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-22-025793:8k_2_02:89]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-22-025793:8k_2_02:90]
J. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0000950170-22-025793:8k_2_02:91]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared

[0000950170-22-025793:8k_2_02:92]
in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0000950170-22-025793:8k_2_02:93]
Constant Currency

[0000950170-22-025793:8k_2_02:94]
NetApp presents certain constant currency growth rates or quantifies the impact of foreign currency exchange rate changes on year-over-year fluctuations, including for net revenues, billings, and earnings. This constant currency information assumes the same foreign currency exchange rates that were in effect for the comparable prior-year period were used in translation of the current period results.

[0000950170-22-025793:8k_2_02:95]
About NetApp

[0000950170-22-025793:8k_2_02:96]
NetApp is a global, cloud-led, data-centric software company that empowers organizations to lead with data in the age of accelerated digital transformation. The company provides systems, software, and cloud services that enable them to run their applications optimally from data center to cloud, whether they are developing in the cloud, moving to the cloud, or creating their own cloudlike experiences on premises. With solutions that perform across diverse environments, NetApp helps organizations build their own data fabric and securely deliver the right data, services, and applications to the right people—anytime, anywhere. Learn more at www.netapp.com or follow us on Twitter, LinkedIn, Facebook, and Instagram.

[0000950170-22-025793:8k_2_02:97]
NETAPP, INC.

[0000950170-22-025793:8k_2_02:98]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-22-025793:8k_2_02:99]
(In millions)

[0000950170-22-025793:8k_2_02:100]
(Unaudited)

[0000950170-22-025793:8k_2_02:101]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,033 |  |  | $ | 4,134 |  |
| Accounts receivable |  |  | 910 |  |  |  | 1,230 |  |
| Inventories |  |  | 244 |  |  |  | 204 |  |
| Other current assets |  |  | 416 |  |  |  | 377 |  |
| Total current assets |  |  | 4,603 |  |  |  | 5,945 |  |
| Property and equipment, net |  |  | 661 |  |  |  | 602 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,982 |  |  |  | 2,488 |  |
| Other non-current assets |  |  | 1,534 |  |  |  | 991 |  |
| Total assets |  | $ | 9,780 |  |  | $ | 10,026 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 584 |  |  | $ | 607 |  |
| Accrued expenses |  |  | 819 |  |  |  | 925 |  |
| Current portion of long-term debt |  |  | — |  |  |  | 250 |  |

[0000950170-22-025793:8k_2_02:102]
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,992 |  |  |  | 2,171 |  |
| Total current liabilities |  |  | 3,395 |  |  |  | 3,953 |  |
| Long-term debt |  |  | 2,387 |  |  |  | 2,386 |  |
| Other long-term liabilities |  |  | 737 |  |  |  | 788 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 2,059 |  |  |  | 2,061 |  |
| Total liabilities |  |  | 8,578 |  |  |  | 9,188 |  |
| Stockholders' equity |  |  | 1,202 |  |  |  | 838 |  |
| Total liabilities and stockholders' equity |  | $ | 9,780 |  |  | $ | 10,026 |  |

[0000950170-22-025793:8k_2_02:103]
NETAPP, INC.

[0000950170-22-025793:8k_2_02:104]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-22-025793:8k_2_02:105]
(In millions, except per share amounts)

[0000950170-22-025793:8k_2_02:106]
(Unaudited)

[0000950170-22-025793:8k_2_02:107]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | October 28, 2022 |  |  | October 29, 2021 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 837 |  |  | $ | 814 |  |  | $ | 1,623 |  |  | $ | 1,544 |  |
| Services |  |  | 826 |  |  |  | 752 |  |  |  | 1,632 |  |  |  | 1,480 |  |
| Net revenues |  |  | 1,663 |  |  |  | 1,566 |  |  |  | 3,255 |  |  |  | 3,024 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 418 |  |  |  | 372 |  |  |  | 815 |  |  |  | 701 |  |
| Cost of services |  |  | 158 |  |  |  | 135 |  |  |  | 307 |  |  |  | 265 |  |
| Total cost of revenues |  |  | 576 |  |  |  | 507 |  |  |  | 1,122 |  |  |  | 966 |  |
| Gross profit |  |  | 1,087 |  |  |  | 1,059 |  |  |  | 2,133 |  |  |  | 2,058 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 479 |  |  |  | 465 |  |  |  | 937 |  |  |  | 916 |  |
| Research and development |  |  | 243 |  |  |  | 216 |  |  |  | 483 |  |  |  | 426 |  |
| General and administrative |  |  | 67 |  |  |  | 76 |  |  |  | 139 |  |  |  | 142 |  |
| Restructuring charges |  |  | 11 |  |  |  | 7 |  |  |  | 22 |  |  |  | 29 |  |
| Acquisition-related expense |  |  | 5 |  |  |  | 1 |  |  |  | 15 |  |  |  | 2 |  |
| Total operating expenses |  |  | 805 |  |  |  | 765 |  |  |  | 1,596 |  |  |  | 1,515 |  |
| Income from operations |  |  | 282 |  |  |  | 294 |  |  |  | 537 |  |  |  | 543 |  |
| Other income (expense), net |  |  | 23 |  |  |  | (14 | ) |  |  | 38 |  |  |  | (26 | ) |
| Income before income taxes |  |  | 305 |  |  |  | 280 |  |  |  | 575 |  |  |  | 517 |  |
| (Benefit) provision for income taxes |  |  | (445 | ) |  |  | 56 |  |  |  | (389 | ) |  |  | 91 |  |
| Net income |  | $ | 750 |  |  | $ | 224 |  |  | $ | 964 |  |  | $ | 426 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.46 |  |  | $ | 1.00 |  |  | $ | 4.40 |  |  | $ | 1.91 |  |
| Diluted |  | $ | 3.41 |  |  | $ | 0.98 |  |  | $ | 4.34 |  |  | $ | 1.86 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 217 |  |  |  | 223 |  |  |  | 219 |  |  |  | 223 |  |
| Diluted |  |  | 220 |  |  |  | 229 |  |  |  | 222 |  |  |  | 229 |  |

[0000950170-22-025793:8k_2_02:108]
NETAPP, INC.

[0000950170-22-025793:8k_2_02:109]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-22-025793:8k_2_02:110]
(In millions)

[0000950170-22-025793:8k_2_02:111]
(Unaudited)

[0000950170-22-025793:8k_2_02:112]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | October 28, 2022 |  |  | October 29, 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 750 |  |  | $ | 224 |  |  | $ | 964 |  |  | $ | 426 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 59 |  |  |  | 46 |  |  |  | 117 |  |  |  | 92 |  |
| Non-cash operating lease cost |  |  | 13 |  |  |  | 15 |  |  |  | 27 |  |  |  | 28 |  |
| Stock-based compensation |  |  | 78 |  |  |  | 62 |  |  |  | 145 |  |  |  | 115 |  |
| Deferred income taxes |  |  | (555 | ) |  |  | (17 | ) |  |  | (570 | ) |  |  | (32 | ) |
| Other items, net |  |  | (61 | ) |  |  | (16 | ) |  |  | (127 | ) |  |  | (12 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (51 | ) |  |  | 5 |  |  |  | 313 |  |  |  | 292 |  |
| Inventories |  |  | (12 | ) |  |  | (47 | ) |  |  | (40 | ) |  |  | (41 | ) |
| Accounts payable |  |  | 62 |  |  |  | 62 |  |  |  | (28 | ) |  |  | 11 |  |
| Accrued expenses |  |  | 100 |  |  |  | 36 |  |  |  | (108 | ) |  |  | (206 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (61 | ) |  |  | (15 | ) |  |  | (93 | ) |  |  | (97 | ) |
| Long-term taxes payable |  |  | (85 | ) |  |  | (57 | ) |  |  | (84 | ) |  |  | (65 | ) |
| Changes in other operating assets and liabilities, net |  |  | (23 | ) |  |  | — |  |  |  | (21 | ) |  |  | 29 |  |
| Net cash provided by operating activities |  |  | 214 |  |  |  | 298 |  |  |  | 495 |  |  |  | 540 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| (Purchases) redemptions of investments, net |  |  | (211 | ) |  |  | 15 |  |  |  | (342 | ) |  |  | 26 |  |
| Purchases of property and equipment |  |  | (77 | ) |  |  | (46 | ) |  |  | (142 | ) |  |  | (97 | ) |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | — |  |  |  | (491 | ) |  |  | (14 | ) |
| Other investing activities, net |  |  | — |  |  |  | — |  |  |  | 59 |  |  |  | — |  |
| Net cash used in investing activities |  |  | (288 | ) |  |  | (31 | ) |  |  | (916 | ) |  |  | (85 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | — |  |  |  | — |  |  |  | 54 |  |  |  | 53 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (11 | ) |  |  | (6 | ) |  |  | (63 | ) |  |  | (63 | ) |
| Repurchase of common stock |  |  | (150 | ) |  |  | (125 | ) |  |  | (500 | ) |  |  | (225 | ) |
| Repayments and extinguishment of debt |  |  | (250 | ) |  |  | — |  |  |  | (250 | ) |  |  | — |  |
| Dividends paid |  |  | (108 | ) |  |  | (112 | ) |  |  | (218 | ) |  |  | (224 | ) |
| Other financing activities, net |  |  | (1 | ) |  |  | — |  |  |  | (2 | ) |  |  | (2 | ) |
| Net cash used in financing activities |  |  | (520 | ) |  |  | (243 | ) |  |  | (979 | ) |  |  | (461 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (25 | ) |  |  | (8 | ) |  |  | (43 | ) |  |  | (13 | ) |
| Net change in cash, cash equivalents and restricted cash |  |  | (619 | ) |  |  | 16 |  |  |  | (1,443 | ) |  |  | (19 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 3,295 |  |  |  | 4,500 |  |  |  | 4,119 |  |  |  | 4,535 |  |
| End of period |  | $ | 2,676 |  |  | $ | 4,516 |  |  | $ | 2,676 |  |  | $ | 4,516 |  |

[0000950170-22-025793:8k_2_02:113]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| Product |  | $ | 837 |  |  | $ | 786 |  |  | $ | 814 |  |
| Support |  |  | 607 |  |  |  | 598 |  |  |  | 590 |  |
| Professional and Other Services |  |  | 77 |  |  |  | 76 |  |  |  | 75 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,521 |  |  |  | 1,460 |  |  |  | 1,479 |  |
| Public Cloud Segment Net Revenues |  |  | 142 |  |  |  | 132 |  |  |  | 87 |  |
| Net Revenues |  | $ | 1,663 |  |  | $ | 1,592 |  |  | $ | 1,566 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| Product |  | $ | 420 |  |  | $ | 391 |  |  | $ | 445 |  |
| Support |  |  | 562 |  |  |  | 555 |  |  |  | 542 |  |
| Professional and Other Services |  |  | 23 |  |  |  | 24 |  |  |  | 21 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 1,005 |  |  |  | 970 |  |  |  | 1,008 |  |
| Public Cloud Segment Gross Profit |  |  | 97 |  |  |  | 92 |  |  |  | 62 |  |
| Total Segments Gross Profit |  |  | 1,102 |  |  |  | 1,062 |  |  |  | 1,070 |  |
| Amortization of Intangible Assets |  |  | (10 | ) |  |  | (11 | ) |  |  | (7 | ) |
| Stock-based Compensation |  |  | (5 | ) |  |  | (5 | ) |  |  | (4 | ) |
| Unallocated Cost of Revenues |  |  | (15 | ) |  |  | (16 | ) |  |  | (11 | ) |
| Gross Profit |  | $ | 1,087 |  |  | $ | 1,046 |  |  | $ | 1,059 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| Product |  |  | 50.2 | % |  |  | 49.7 | % |  |  | 54.7 | % |
| Support |  |  | 92.6 | % |  |  | 92.8 | % |  |  | 91.9 | % |
| Professional and Other Services |  |  | 29.9 | % |  |  | 31.6 | % |  |  | 28.0 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 66.1 | % |  |  | 66.4 | % |  |  | 68.2 | % |
| Public Cloud Segment Gross Margin |  |  | 68.3 | % |  |  | 69.7 | % |  |  | 71.3 | % |
| Product Revenues |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| Total |  | $ | 837 |  |  | $ | 786 |  |  | $ | 814 |  |
| Software* |  | $ | 495 |  |  | $ | 476 |  |  | $ | 475 |  |
| Hardware* |  | $ | 342 |  |  | $ | 310 |  |  | $ | 339 |  |
| Software and recurring support and public cloud revenue |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| Product - Software |  | $ | 495 |  |  | $ | 476 |  |  | $ | 475 |  |
| Support |  |  | 607 |  |  |  | 598 |  |  |  | 590 |  |
| Public Cloud |  |  | 142 |  |  |  | 132 |  |  |  | 87 |  |
| Software and recurring support and public cloud revenue* |  | $ | 1,244 |  |  | $ | 1,206 |  |  | $ | 1,152 |  |
| Software and recurring support and public cloud revenue as a percentage of net revenues |  |  | 75 | % |  |  | 76 | % |  |  | 74 | % |
| * Our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation. We have provided a breakdown of our GAAP product revenues into the software and hardware components, which are considered non-GAAP measures, to display the significance of software included in total product revenues. Software and recurring support and public cloud revenue is a non-GAAP measure because it includes the software component of our product revenues, but not the hardware component. |  |

[0000950170-22-025793:8k_2_02:114]
| Geographic Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'23 |  |  | % of Q1 FY'23 |  |  | % of Q2 FY'22 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 54 | % |  |  | 54 | % |  |  | 55 | % |
| Americas Commercial |  |  | 40 | % |  |  | 42 | % |  |  | 43 | % |
| U.S. Public Sector |  |  | 14 | % |  |  | 12 | % |  |  | 12 | % |
| EMEA |  |  | 32 | % |  |  | 31 | % |  |  | 29 | % |
| Asia Pacific |  |  | 14 | % |  |  | 15 | % |  |  | 15 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'23 |  |  | % of Q1 FY'23 |  |  | % of Q2 FY'22 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 23 | % |  |  | 21 | % |  |  | 24 | % |
| Indirect |  |  | 77 | % |  |  | 79 | % |  |  | 76 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| Non-GAAP Income from Operations |  | $ | 393 |  |  | $ | 360 |  |  | $ | 374 |  |
| % of Net Revenues |  |  | 23.6 | % |  |  | 22.6 | % |  |  | 23.9 | % |
| Non-GAAP Income before Income Taxes |  | $ | 416 |  |  | $ | 343 |  |  | $ | 360 |  |
| Non-GAAP Effective Tax Rate |  |  | 21.6 | % |  |  | 21.6 | % |  |  | 18.9 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| Non-GAAP Net Income |  | $ | 326 |  |  | $ | 269 |  |  | $ | 292 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 220 |  |  |  | 224 |  |  |  | 229 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.48 |  |  | $ | 1.20 |  |  | $ | 1.28 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 4,051 |  |  | $ | 4,170 |  |  | $ | 3,866 |  |
| DSO (days) |  |  | 50 |  |  |  | 49 |  |  |  | 38 |  |
| DPO (days) |  |  | 92 |  |  |  | 86 |  |  |  | 78 |  |
| Inventory Turns |  |  | 9 |  |  |  | 9 |  |  |  | 13 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| Net Cash Provided by Operating Activities |  | $ | 214 |  |  | $ | 281 |  |  | $ | 298 |  |
| Purchases of Property and Equipment |  | $ | 77 |  |  | $ | 65 |  |  | $ | 46 |  |
| Free Cash Flow |  | $ | 137 |  |  | $ | 216 |  |  | $ | 252 |  |
| Free Cash Flow as % of Net Revenues |  |  | 8.2 | % |  |  | 13.6 | % |  |  | 16.1 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0000950170-22-025793:8k_2_02:115]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| NET INCOME |  | $ | 750 |  |  | $ | 214 |  |  | $ | 224 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 17 |  |  |  | 17 |  |  |  | 10 |  |
| Stock-based compensation |  |  | 78 |  |  |  | 67 |  |  |  | 62 |  |
| Restructuring charges |  |  | 11 |  |  |  | 11 |  |  |  | 7 |  |
| Acquisition-related expense |  |  | 5 |  |  |  | 10 |  |  |  | 1 |  |
| Gain on sale of equity investment |  |  | — |  |  |  | (32 | ) |  |  | — |  |
| Income tax effects |  |  | (11 | ) |  |  | (18 | ) |  |  | (13 | ) |
| Income tax expenses from integration of acquired companies |  |  | — |  |  |  | — |  |  |  | 1 |  |
| Income tax benefit from intra-entity intellectual property transfer |  |  | (524 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP NET INCOME |  | $ | 326 |  |  | $ | 269 |  |  | $ | 292 |  |
| COST OF REVENUES |  | $ | 576 |  |  | $ | 546 |  |  | $ | 507 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (11 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (5 | ) |  |  | (4 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 561 |  |  | $ | 530 |  |  | $ | 496 |  |
| COST OF PRODUCT REVENUES |  | $ | 418 |  |  | $ | 397 |  |  | $ | 372 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | (1 | ) |  |  | (2 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 417 |  |  | $ | 395 |  |  | $ | 369 |  |
| COST OF SERVICES REVENUES |  | $ | 158 |  |  | $ | 149 |  |  | $ | 135 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (10 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (3 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 144 |  |  | $ | 135 |  |  | $ | 127 |  |
| GROSS PROFIT |  | $ | 1,087 |  |  | $ | 1,046 |  |  | $ | 1,059 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 10 |  |  |  | 11 |  |  |  | 7 |  |
| Stock-based compensation |  |  | 5 |  |  |  | 5 |  |  |  | 4 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,102 |  |  | $ | 1,062 |  |  | $ | 1,070 |  |

[0000950170-22-025793:8k_2_02:116]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| SALES AND MARKETING EXPENSES |  | $ | 479 |  |  | $ | 458 |  |  | $ | 465 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (6 | ) |  |  | (3 | ) |
| Stock-based compensation |  |  | (35 | ) |  |  | (28 | ) |  |  | (29 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 437 |  |  | $ | 424 |  |  | $ | 433 |  |

[0000950170-22-025793:8k_2_02:117]
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 243 |  |  | $ | 240 |  |  | $ | 216 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (26 | ) |  |  | (24 | ) |  |  | (19 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 217 |  |  | $ | 216 |  |  | $ | 197 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 67 |  |  | $ | 72 |  |  | $ | 76 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (12 | ) |  |  | (10 | ) |  |  | (10 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 55 |  |  | $ | 62 |  |  | $ | 66 |  |
| RESTRUCTURING CHARGES |  | $ | 11 |  |  | $ | 11 |  |  | $ | 7 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (11 | ) |  |  | (11 | ) |  |  | (7 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 5 |  |  | $ | 10 |  |  | $ | 1 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (5 | ) |  |  | (10 | ) |  |  | (1 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 805 |  |  | $ | 791 |  |  | $ | 765 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (6 | ) |  |  | (3 | ) |
| Stock-based compensation |  |  | (73 | ) |  |  | (62 | ) |  |  | (58 | ) |
| Restructuring charges |  |  | (11 | ) |  |  | (11 | ) |  |  | (7 | ) |
| Acquisition-related expense |  |  | (5 | ) |  |  | (10 | ) |  |  | (1 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 709 |  |  | $ | 702 |  |  | $ | 696 |  |

[0000950170-22-025793:8k_2_02:118]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| INCOME FROM OPERATIONS |  | $ | 282 |  |  | $ | 255 |  |  | $ | 294 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 17 |  |  |  | 17 |  |  |  | 10 |  |
| Stock-based compensation |  |  | 78 |  |  |  | 67 |  |  |  | 62 |  |
| Restructuring charges |  |  | 11 |  |  |  | 11 |  |  |  | 7 |  |
| Acquisition-related expense |  |  | 5 |  |  |  | 10 |  |  |  | 1 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 393 |  |  | $ | 360 |  |  | $ | 374 |  |
| OTHER INCOME (EXPENSE), NET |  | $ | 23 |  |  | $ | 15 |  |  | $ | (14 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Gain on sale of equity investment |  |  | — |  |  |  | (32 | ) |  |  | — |  |
| NON-GAAP OTHER INCOME (EXPENSE), NET |  | $ | 23 |  |  | $ | (17 | ) |  | $ | (14 | ) |
| INCOME BEFORE INCOME TAXES |  | $ | 305 |  |  | $ | 270 |  |  | $ | 280 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 17 |  |  |  | 17 |  |  |  | 10 |  |
| Stock-based compensation |  |  | 78 |  |  |  | 67 |  |  |  | 62 |  |
| Restructuring charges |  |  | 11 |  |  |  | 11 |  |  |  | 7 |  |
| Acquisition-related expense |  |  | 5 |  |  |  | 10 |  |  |  | 1 |  |
| Gain on sale of equity investment |  |  | — |  |  |  | (32 | ) |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 416 |  |  | $ | 343 |  |  | $ | 360 |  |

[0000950170-22-025793:8k_2_02:119]
| (BENEFIT) PROVISION FOR INCOME TAXES |  | $ | (445 | ) |  | $ | 56 |  |  | $ | 56 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 11 |  |  |  | 18 |  |  |  | 13 |  |
| Income tax expenses from integration of acquired companies |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| Income tax benefit from intra-entity intellectual property transfer |  |  | 524 |  |  |  | — |  |  |  | — |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 90 |  |  | $ | 74 |  |  | $ | 68 |  |
| NET INCOME PER SHARE |  | $ | 3.41 |  |  | $ | 0.96 |  |  | $ | 0.98 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.08 |  |  |  | 0.08 |  |  |  | 0.04 |  |
| Stock-based compensation |  |  | 0.35 |  |  |  | 0.30 |  |  |  | 0.27 |  |
| Restructuring charges |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.03 |  |
| Acquisition-related expense |  |  | 0.02 |  |  |  | 0.04 |  |  |  | — |  |
| Gain on sale of equity investment |  |  | — |  |  |  | (0.14 | ) |  |  | — |  |
| Income tax effects |  |  | (0.05 | ) |  |  | (0.08 | ) |  |  | (0.06 | ) |
| Income tax benefit from intra-entity intellectual property transfer |  |  | (2.38 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.48 |  |  | $ | 1.20 |  |  | $ | 1.28 |  |

[0000950170-22-025793:8k_2_02:120]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| Gross margin-GAAP |  |  | 65.4 | % |  |  | 65.7 | % |  |  | 67.6 | % |
| Cost of revenues adjustments |  |  | 0.9 | % |  |  | 1.0 | % |  |  | 0.7 | % |
| Gross margin-Non-GAAP |  |  | 66.3 | % |  |  | 66.7 | % |  |  | 68.3 | % |
| GAAP cost of revenues |  | $ | 576 |  |  | $ | 546 |  |  | $ | 507 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (11 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (5 | ) |  |  | (4 | ) |
| Non-GAAP cost of revenues |  | $ | 561 |  |  | $ | 530 |  |  | $ | 496 |  |
| Net revenues |  | $ | 1,663 |  |  | $ | 1,592 |  |  | $ | 1,566 |  |

[0000950170-22-025793:8k_2_02:121]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| Product gross margin-GAAP |  |  | 50.1 | % |  |  | 49.5 | % |  |  | 54.3 | % |
| Cost of product revenues adjustments |  |  | 0.1 | % |  |  | 0.3 | % |  |  | 0.4 | % |
| Product gross margin-Non-GAAP |  |  | 50.2 | % |  |  | 49.7 | % |  |  | 54.7 | % |
| GAAP cost of product revenues |  | $ | 418 |  |  | $ | 397 |  |  | $ | 372 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | (1 | ) |  |  | (2 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 417 |  |  | $ | 395 |  |  | $ | 369 |  |
| Product revenues |  | $ | 837 |  |  | $ | 786 |  |  | $ | 814 |  |

[0000950170-22-025793:8k_2_02:122]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| SERVICES GROSS MARGIN |  |

[0000950170-22-025793:8k_2_02:123]
| ($ in millions) |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| Services gross margin-GAAP |  |  | 80.9 | % |  |  | 81.5 | % |  |  | 82.0 | % |
| Cost of services revenues adjustments |  |  | 1.7 | % |  |  | 1.7 | % |  |  | 1.1 | % |
| Services gross margin-Non-GAAP |  |  | 82.6 | % |  |  | 83.3 | % |  |  | 83.1 | % |
| GAAP cost of services revenues |  | $ | 158 |  |  | $ | 149 |  |  | $ | 135 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (10 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (3 | ) |
| Non-GAAP cost of services revenues |  | $ | 144 |  |  | $ | 135 |  |  | $ | 127 |  |
| Services revenues |  | $ | 826 |  |  | $ | 806 |  |  | $ | 752 |  |

[0000950170-22-025793:8k_2_02:124]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| GAAP effective tax rate |  |  | (145.9 | )% |  |  | 20.7 | % |  |  | 20.0 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 41.6 | % |  |  | 0.8 | % |  |  | (0.8 | )% |
| Income tax expenses from integration of acquired companies |  |  | — | % |  |  | — | % |  |  | (0.4 | )% |
| Income tax benefit from intra-entity intellectual property transfer |  |  | 126.0 | % |  |  | — | % |  |  | — | % |
| Non-GAAP effective tax rate |  |  | 21.6 | % |  |  | 21.6 | % |  |  | 18.9 | % |

[0000950170-22-025793:8k_2_02:125]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| Net cash provided by operating activities |  | $ | 214 |  |  | $ | 281 |  |  | $ | 298 |  |
| Purchases of property and equipment |  |  | (77 | ) |  |  | (65 | ) |  |  | (46 | ) |
| Free cash flow |  | $ | 137 |  |  | $ | 216 |  |  | $ | 252 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY23 |  |  | Q1'FY23 |  |  | Q2'FY22 |  |
| Net revenues |  | $ | 1,663 |  |  | $ | 1,592 |  |  | $ | 1,566 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | (61 | ) |  |  | (32 | ) |  |  | (15 | ) |
| Billings |  | $ | 1,602 |  |  | $ | 1,560 |  |  | $ | 1,551 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0000950170-22-025793:8k_2_02:126]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| THIRD QUARTER FISCAL 2023 |
|  |  | Third Quarter |
|  |  | Fiscal 2023 |
| Non-GAAP Guidance - Net Income Per Share |  | $1.25-$1.35 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the Third Quarter Fiscal 2023: |  |  |
| Amortization of intangible assets |  | ($0.08) |
| Stock-based compensation expense |  | ($0.35) |
| Income tax effects |  | $0.06 |
| Total Adjustments |  | ($0.37) |
| GAAP Guidance - Net Income Per Share |  | $0.88-$0.98 |

[0000950170-22-025793:8k_2_02:127]
Some items may not add or recalculate due to rounding.

[0000950170-22-025793:8k_2_02:128]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| FISCAL 2023 |
|  |  | Fiscal 2023 |
| Gross Margin - Non-GAAP Guidance |  | 66% - 67% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | (1)% |
| Gross Margin - GAAP Guidance |  | 65% - 66% |
|  |  | Fiscal 2023 |
| Operating Margin - Non-GAAP Guidance |  | ~23% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | (1)% |
| Stock-based compensation expense |  | (5)% |
| Operating Margin - GAAP Guidance |  | ~17% |

[0000950170-22-025793:8k_2_02:129]
Some items may not add or recalculate due to rounding.

[0000950170-22-025793:8k_2_02:130]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FISCAL 2023 |
|  |  | Fiscal 2023 |
| Non-GAAP Guidance - Net Income Per Share |  | $5.30 - $5.50 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2023: |  |  |
| Amortization of intangible assets |  | ($0.31) |
| Stock-based compensation expense |  | ($1.37) |
| Restructuring charges |  | ($0.10) |
| Acquisition-related expenses |  | ($0.07) |
| Gain on sale of equity investment |  | $0.14 |
| Income tax benefit from intra-entity intellectual property transfer |  | $2.37 |
| Income tax effects |  | $0.33 |
| Total Adjustments |  | $0.99 |
| GAAP Guidance - Net Income Per Share |  | $6.29 - $6.49 |

[0000950170-22-025793:8k_2_02:131]
Some items may not add or recalculate due to rounding.

[0000950170-22-025793:8k_2_02:132]
Contacts:

[0000950170-22-025793:8k_2_02:133]
(Press)

[0000950170-22-025793:8k_2_02:134]
Chris Drago

[0000950170-22-025793:8k_2_02:135]
1 831 900 8889

[0000950170-22-025793:8k_2_02:136]
chris.drago@netapp.com

[0000950170-22-025793:8k_2_02:137]
(Investors)

[0000950170-22-025793:8k_2_02:138]
Lance Berger

[0000950170-22-025793:8k_2_02:139]
1 408 822 6628

[0000950170-22-025793:8k_2_02:140]
lance.berger@netapp.com
