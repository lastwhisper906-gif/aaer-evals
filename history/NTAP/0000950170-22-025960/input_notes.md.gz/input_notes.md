# NTAP notes — 0000950170-22-025960


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000950170-22-025960:notes:1]
[same as prior period, unchanged from 0000950170-22-017904:notes:1]

[0000950170-22-025960:notes:2]
NetApp, Inc. (we, us, NetApp, or the Company) is a global cloud-led, data-centric software company that provides organizations the ability to manage and share their data across on-premises, private and public clouds. We provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.

[0000950170-22-025960:notes:3]
[same as prior period, unchanged from 0000950170-22-017904:notes:3]

[0000950170-22-025960:notes:4]
[same as prior period, unchanged from 0000950170-22-017904:notes:4]

[0000950170-22-025960:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2022 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 28, 2022 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0000950170-22-025960:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; valuation of intellectual property; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates. Management’s estimates include, as applicable, the anticipated impacts of the COVID-19 pandemic.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000950170-22-025960:notes:7]
2. Recent Accounting Pronouncements

[0000950170-22-025960:notes:8]
Although there are new accounting pronouncements issued or proposed by the FASB that we have adopted or will adopt, as applicable, we do not believe any of these accounting pronouncements had or will have a material impact on our consolidated financial position, operating results, cash flows or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-22-025960:notes:9]
[same as prior period, unchanged from 0000950170-22-017904:notes:9]

[0000950170-22-025960:notes:10]
[same as prior period, unchanged from 0000950170-22-017904:notes:10]

[0000950170-22-025960:notes:11]
Instaclustr Acquisition

[0000950170-22-025960:notes:12]
On May 20, 2022, we acquired all the outstanding shares of privately-held Instaclustr US Holding, Inc., (Instaclustr) for approximately $498 million. Instaclustr is a leading platform provider of fully managed open-source database, pipeline and workflow applications delivered as-a-service.

[0000950170-22-025960:notes:13]
[same as prior period, unchanged from 0000950170-22-017904:notes:13]

[0000950170-22-025960:notes:14]
[same as prior period, unchanged from 0000950170-22-017904:notes:14]

[0000950170-22-025960:notes:15]
[same as prior period, unchanged from 0000950170-22-017904:notes:15]

[0000950170-22-025960:notes:16]
[same as prior period, unchanged from 0000950170-22-017904:notes:16]

[0000950170-22-025960:notes:17]
[same as prior period, unchanged from 0000950170-22-017904:notes:17]

[0000950170-22-025960:notes:18]
[same as prior period, unchanged from 0000950170-22-017904:notes:18]

[0000950170-22-025960:notes:19]
[same as prior period, unchanged from 0000950170-22-017904:notes:19]

[0000950170-22-025960:notes:20]
[same as prior period, unchanged from 0000950170-22-017904:notes:20]

[0000950170-22-025960:notes:21]
[same as prior period, unchanged from 0000950170-22-017904:notes:21]

[0000950170-22-025960:notes:22]
The acquisition-date values of the assets acquired are as follows (in millions):

[0000950170-22-025960:notes:23]
[same as prior period, unchanged from 0000950170-22-017904:notes:23]

[0000950170-22-025960:notes:24]
[same as prior period, unchanged from 0000950170-22-017904:notes:24]

[0000950170-22-025960:notes:25]
[same as prior period, unchanged from 0000950170-22-017904:notes:25]

[0000950170-22-025960:notes:26]
[same as prior period, unchanged from 0000950170-22-017904:notes:26]

[0000950170-22-025960:notes:27]
[same as prior period, unchanged from 0000950170-22-017904:notes:27]

[0000950170-22-025960:notes:28]
[same as prior period, unchanged from 0000950170-22-017904:notes:28]

[0000950170-22-025960:notes:29]
[same as prior period, unchanged from 0000950170-22-017904:notes:29]

[0000950170-22-025960:notes:30]
On June 18, 2021, we acquired all the outstanding shares of privately-held Data Mechanics Inc. (Data Mechanics), a provider of managed platforms for big data processing and cloud analytics headquartered in Paris, France, for approximately $15 million in cash.

[0000950170-22-025960:notes:31]
[same as prior period, unchanged from 0000950170-22-017904:notes:31]

[0000950170-22-025960:notes:32]
[same as prior period, unchanged from 0000950170-22-017904:notes:32]

[0000950170-22-025960:notes:33]
[same as prior period, unchanged from 0000950170-22-017904:notes:33]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-22-025960:notes:34]
[same as prior period, unchanged from 0000950170-22-017904:notes:34]

[0000950170-22-025960:notes:35]
[same as prior period, unchanged from 0000950170-22-017904:notes:35]

[0000950170-22-025960:notes:36]
|  |  | Amount |  |
| Balance as of April 29, 2022 |  | $ | 2,346 |  |
| Additions |  |  | 421 |  |
| Balance as of October 28, 2022 |  | $ | 2,767 |  |

[0000950170-22-025960:notes:37]
[same as prior period, unchanged from 0000950170-22-017904:notes:37]

[0000950170-22-025960:notes:38]
Goodwill by reportable segment as of October 28, 2022 is as follows (in millions):

[0000950170-22-025960:notes:39]
[same as prior period, unchanged from 0000950170-22-017904:notes:39]

[0000950170-22-025960:notes:40]
[same as prior period, unchanged from 0000950170-22-017904:notes:40]

[0000950170-22-025960:notes:41]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 212 |  |  | $ | (87 | ) |  | $ | 125 |  |  | $ | 157 |  |  | $ | (65 | ) |  | $ | 92 |  |
| Customer contracts/relationships |  |  | 118 |  |  |  | (31 | ) |  |  | 87 |  |  |  | 68 |  |  |  | (20 | ) |  |  | 48 |  |
| Other purchased intangibles |  |  | 6 |  |  |  | (3 | ) |  |  | 3 |  |  |  | 4 |  |  |  | (2 | ) |  |  | 2 |  |
| Total purchased intangible assets |  | $ | 336 |  |  | $ | (121 | ) |  | $ | 215 |  |  | $ | 229 |  |  | $ | (87 | ) |  | $ | 142 |  |

[0000950170-22-025960:notes:42]
[same as prior period, unchanged from 0000950170-22-017904:notes:42]

[0000950170-22-025960:notes:43]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Statements of |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | IncomeClassification |
| Developed technology |  | $ | 11 |  |  | $ | 7 |  |  | $ | 21 |  |  | $ | 14 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 6 |  |  |  | 2 |  |  |  | 12 |  |  |  | 3 |  |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 2 |  |  | Operating expenses |
| Total |  | $ | 17 |  |  | $ | 10 |  |  | $ | 34 |  |  | $ | 19 |  |  |  |

[0000950170-22-025960:notes:44]
As of October 28, 2022, future amortization expense related to purchased intangible assets is as follows (in millions):

[0000950170-22-025960:notes:45]
| Fiscal Year |  | Amount |  |
| 2023 (remainder) |  | $ | 34 |  |
| 2024 |  |  | 57 |  |
| 2025 |  |  | 55 |  |
| 2026 |  |  | 39 |  |
| 2027 |  |  | 29 |  |
| 2028 |  |  | 1 |  |
| Total |  | $ | 215 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000950170-22-025960:notes:46]
The
Goodwill by reportable segment as of October 28, 2022 is as follows (in millions):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-22-025960:notes:47]
[same as prior period, unchanged from 0000950170-22-017904:notes:46]

[0000950170-22-025960:notes:48]
[same as prior period, unchanged from 0000950170-22-017904:notes:47]

[0000950170-22-025960:notes:49]
[same as prior period, unchanged from 0000950170-22-017904:notes:48]

[0000950170-22-025960:notes:50]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| Cash and cash equivalents |  | $ | 2,669 |  |  | $ | 4,112 |  |
| Restricted cash |  |  | 7 |  |  |  | 7 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,676 |  |  | $ | 4,119 |  |

[0000950170-22-025960:notes:51]
[same as prior period, unchanged from 0000950170-22-017904:notes:50]

[0000950170-22-025960:notes:52]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| Purchased components |  | $ | 144 |  |  | $ | 131 |  |
| Finished goods |  |  | 100 |  |  |  | 73 |  |
| Inventories |  | $ | 244 |  |  | $ | 204 |  |

[0000950170-22-025960:notes:53]
[same as prior period, unchanged from 0000950170-22-017904:notes:52]

[0000950170-22-025960:notes:54]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 358 |  |  |  | 353 |  |
| Leasehold improvements |  |  | 89 |  |  |  | 92 |  |
| Computer, production, engineering and other equipment |  |  | 984 |  |  |  | 904 |  |
| Computer software |  |  | 326 |  |  |  | 316 |  |
| Furniture and fixtures |  |  | 76 |  |  |  | 76 |  |
| Construction-in-progress |  |  | 85 |  |  |  | 65 |  |
|  |  |  | 1,964 |  |  |  | 1,852 |  |
| Accumulated depreciation and amortization |  |  | (1,303 | ) |  |  | (1,250 | ) |
| Property and equipment, net |  | $ | 661 |  |  | $ | 602 |  |

[0000950170-22-025960:notes:55]
[same as prior period, unchanged from 0000950170-22-017904:notes:54]

[0000950170-22-025960:notes:56]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| Deferred tax assets |  | $ | 930 |  |  | $ | 362 |  |
| Operating lease ROU assets |  |  | 298 |  |  |  | 294 |  |
| Other assets |  |  | 306 |  |  |  | 335 |  |
| Other non-current assets |  | $ | 1,534 |  |  | $ | 991 |  |

[0000950170-22-025960:notes:57]
Other non-current assets as of October 28, 2022 and April 29, 2022 include $77 million and $73 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies. Our sales to LNTL are conducted on terms equivalent to those prevailing in an arm’s length transaction.

[0000950170-22-025960:notes:58]
[same as prior period, unchanged from 0000950170-22-017904:notes:57]

[0000950170-22-025960:notes:59]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| Accrued compensation and benefits |  | $ | 338 |  |  | $ | 462 |  |
| Product warranty liabilities |  |  | 17 |  |  |  | 17 |  |
| Operating lease liabilities |  |  | 47 |  |  |  | 47 |  |
| Other current liabilities |  |  | 417 |  |  |  | 399 |  |
| Accrued expenses |  | $ | 819 |  |  | $ | 925 |  |

[0000950170-22-025960:notes:60]
[same as prior period, unchanged from 0000950170-22-017904:notes:59]

[0000950170-22-025960:notes:61]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| Liability for uncertain tax positions |  | $ | 140 |  |  | $ | 131 |  |
| Income taxes payable |  |  | 215 |  |  |  | 303 |  |
| Product warranty liabilities |  |  | 8 |  |  |  | 9 |  |
| Operating lease liabilities |  |  | 261 |  |  |  | 257 |  |
| Other liabilities |  |  | 113 |  |  |  | 88 |  |
| Other long-term liabilities |  | $ | 737 |  |  | $ | 788 |  |

[0000950170-22-025960:notes:62]
[same as prior period, unchanged from 0000950170-22-017904:notes:61]

[0000950170-22-025960:notes:63]
[same as prior period, unchanged from 0000950170-22-017904:notes:62]

[0000950170-22-025960:notes:64]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| Deferred product revenue |  | $ | 22 |  |  | $ | 31 |  |
| Deferred services revenue |  |  | 3,980 |  |  |  | 4,140 |  |
| Financed unearned services revenue |  |  | 49 |  |  |  | 61 |  |
| Total |  | $ | 4,051 |  |  | $ | 4,232 |  |
| Reported as: |  |  |  |  |  |  |
| Short-term |  | $ | 1,992 |  |  | $ | 2,171 |  |
| Long-term |  |  | 2,059 |  |  |  | 2,061 |  |
| Total |  | $ | 4,051 |  |  | $ | 4,232 |  |

[0000950170-22-025960:notes:65]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 15 – Commitments and Contingencies for additional information related to these arrangements.

[0000950170-22-025960:notes:66]
During the six months ended October 28, 2022 and October 29, 2021, we recognized revenue of $1,280 million and $1,183 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0000950170-22-025960:notes:67]
As of October 28, 2022, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied approximated our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as

[0000950170-22-025960:notes:68]
revenue approximately 49% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 24% in the next 13 to 24 months, and the remainder thereafter.

[0000950170-22-025960:notes:69]
[same as prior period, unchanged from 0000950170-22-017904:notes:68]

[0000950170-22-025960:notes:70]
[same as prior period, unchanged from 0000950170-22-017904:notes:69]

[0000950170-22-025960:notes:71]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| Other current assets |  | $ | 62 |  |  | $ | 80 |  |
| Other non-current assets |  |  | 105 |  |  |  | 117 |  |
| Total deferred commissions |  | $ | 167 |  |  | $ | 197 |  |

[0000950170-22-025960:notes:72]
[same as prior period, unchanged from 0000950170-22-017904:notes:71]

[0000950170-22-025960:notes:73]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | October 28, 2022 |  |  | October 29, 2021 |  |
| Interest income |  | $ | 14 |  |  | $ | 1 |  |  | $ | 21 |  |  | $ | 3 |  |
| Interest expense |  |  | (17 | ) |  |  | (18 | ) |  |  | (35 | ) |  |  | (36 | ) |
| Other, net |  |  | 26 |  |  |  | 3 |  |  |  | 52 |  |  |  | 7 |  |
| Total other income (expense), net |  | $ | 23 |  |  | $ | (14 | ) |  | $ | 38 |  |  | $ | (26 | ) |

[0000950170-22-025960:notes:74]
In the second quarter of fiscal 2023, Other, net includes $21 million of other income for non-refundable, up-front payments from customers in Russia for support contracts, which we were not able to fulfill due to imposed sanctions and for which we have no remaining legal obligation to perform. During the six months ended of fiscal 2023, Other, net also includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million in the first quarter of fiscal 2023.

[0000950170-22-025960:notes:75]
[same as prior period, unchanged from 0000950170-22-017904:notes:74]

[0000950170-22-025960:notes:76]
[same as prior period, unchanged from 0000950170-22-017904:notes:75]

[0000950170-22-025960:notes:77]
|  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 27 |  |  | $ | 21 |  |  |  |
| Liabilities incurred to former owners of acquired business |  | $ | 3 |  |  | $ | — |  |  |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 203 |  |  | $ | 232 |  |  |  |
| Interest paid |  | $ | 36 |  |  | $ | 34 |  |  |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-22-025960:notes:78]
[same as prior period, unchanged from 0000950170-22-017904:notes:77]

[0000950170-22-025960:notes:79]
[same as prior period, unchanged from 0000950170-22-017904:notes:78]

[0000950170-22-025960:notes:80]
[same as prior period, unchanged from 0000950170-22-017904:notes:79]

[0000950170-22-025960:notes:81]
[same as prior period, unchanged from 0000950170-22-017904:notes:80]

[0000950170-22-025960:notes:82]
[same as prior period, unchanged from 0000950170-22-017904:notes:81]

[0000950170-22-025960:notes:83]
[same as prior period, unchanged from 0000950170-22-017904:notes:82]

[0000950170-22-025960:notes:84]
[same as prior period, unchanged from 0000950170-22-017904:notes:83]

[0000950170-22-025960:notes:85]
The following is a summary of our investments at their cost or amortized cost for the periods ended October 28, 2022 and April 29, 2022 (in millions):

[0000950170-22-025960:notes:86]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |  |
| Corporate bonds |  | $ | 9 |  |  | $ | 9 |  |  |
| U.S. Treasury and government debt securities |  |  | 355 |  |  |  | 13 |  |  |
| Money market funds |  |  | 666 |  |  |  | 2,166 |  |  |
| Certificates of deposit |  |  | 31 |  |  |  | 71 |  |  |
| Mutual funds |  |  | 36 |  |  |  | 36 |  |  |
| Total debt and equity securities |  | $ | 1,097 |  |  | $ | 2,295 |  |  |

[0000950170-22-025960:notes:87]
[same as prior period, unchanged from 0000950170-22-017904:notes:86]

[0000950170-22-025960:notes:88]
As of October 28, 2022, all our debt investments are due to mature in one year or less.

[0000950170-22-025960:notes:89]
[same as prior period, unchanged from 0000950170-22-017904:notes:88]

[0000950170-22-025960:notes:90]
[same as prior period, unchanged from 0000950170-22-017904:notes:89]

[0000950170-22-025960:notes:91]
|  |  | October 28, 2022 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 1,972 |  |  | $ | 1,972 |  |  | $ | — |  |
| Money market funds |  |  | 666 |  |  |  | 666 |  |  |  | — |  |
| Certificates of deposit |  |  | 31 |  |  |  | — |  |  |  | 31 |  |
| Total cash and cash equivalents |  |  | 2,669 |  |  |  | 2,638 |  |  |  | 31 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9 |  |  |  | — |  |  |  | 9 |  |
| U.S. Treasury and government debt securities |  |  | 355 |  |  |  | 355 |  |  |  | — |  |
| Total short-term investments |  |  | 364 |  |  |  | 355 |  |  |  | 9 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,033 |  |  | $ | 2,993 |  |  | $ | 40 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 29 |  |  | $ | 29 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |

[0000950170-22-025960:notes:92]
|  |  | April 29, 2022 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 1,875 |  |  | $ | 1,875 |  |  | $ | — |  |
| Money market funds |  |  | 2,166 |  |  |  | 2,166 |  |  |  | — |  |
| Certificates of deposit |  |  | 71 |  |  |  | — |  |  |  | 71 |  |
| Total cash and cash equivalents |  |  | 4,112 |  |  |  | 4,041 |  |  |  | 71 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9 |  |  |  | — |  |  |  | 9 |  |
| U.S. Treasury and government debt securities |  |  | 13 |  |  |  | 13 |  |  |  | — |  |
| Total short-term investments |  |  | 22 |  |  |  | 13 |  |  |  | 9 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,134 |  |  | $ | 4,054 |  |  | $ | 80 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 30 |  |  | $ | 30 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (29 | ) |  | $ | — |  |  | $ | (29 | ) |

[0000950170-22-025960:notes:93]
[same as prior period, unchanged from 0000950170-22-017904:notes:92]

[0000950170-22-025960:notes:94]
[same as prior period, unchanged from 0000950170-22-017904:notes:93]

[0000950170-22-025960:notes:95]
[same as prior period, unchanged from 0000950170-22-017904:notes:94]

[0000950170-22-025960:notes:96]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of October 28, 2022 and April 29, 2022, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0000950170-22-025960:notes:97]
[same as prior period, unchanged from 0000950170-22-017904:notes:97]

[0000950170-22-025960:notes:98]
As of October 28, 2022 and April 29, 2022, the fair value of our long-term debt was approximately $2,124 million and $2,491 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0000950170-22-025960:notes:99]
7. Financing Arrangements

[0000950170-22-025960:notes:100]
Long-Term Debt

[0000950170-22-025960:notes:101]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0000950170-22-025960:notes:102]
|  |  | Effective Interest Rate |  | October 28, 2022 |  |  | April 29, 2022 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | — |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,400 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (13 | ) |  |  | (14 | ) |
| Total senior notes |  |  |  |  | 2,387 |  |  |  | 2,636 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (250 | ) |
| Total long-term debt |  |  |  | $ | 2,387 |  |  | $ | 2,386 |  |

[0000950170-22-025960:notes:103]
Senior Notes

[0000950170-22-025960:notes:104]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were each issued in

[0000950170-22-025960:notes:105]
June 2020. Interest on each of these Senior Notes is payable semi-annually in June and December. Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September.

[0000950170-22-025960:notes:106]
On September 15, 2022, we extinguished our 3.25% Senior Notes due December 2022 for an aggregate cash redemption price of $252 million, comprised of the principal and unpaid interest.

[0000950170-22-025960:notes:107]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0000950170-22-025960:notes:108]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 28, 2022, we were in compliance with all covenants associated with the Senior Notes.

[0000950170-22-025960:notes:109]
As of October 28, 2022, our aggregate future principal debt maturities are as follows (in millions):

[0000950170-22-025960:notes:110]
| Fiscal Year |  | Amount |  |
| 2023 (remainder) |  | $ | — |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| 2027 |  |  | — |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,400 |  |

[0000950170-22-025960:notes:111]
Commercial Paper Program and Credit Facility

[0000950170-22-025960:notes:112]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of October 28, 2022 or April 29, 2022.

[0000950170-22-025960:notes:113]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in January 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of October 28, 2022, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0000950170-22-025960:notes:114]
[same as prior period, unchanged from 0000950170-22-017904:notes:114]

[0000950170-22-025960:notes:115]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of October 28, 2022, have remaining lease terms not exceeding 19 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of October 28, 2022, have remaining lease terms not exceeding 4 years. As of October 28, 2022, our automobile leases have remaining lease terms not exceeding 4 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0000950170-22-025960:notes:116]
[same as prior period, unchanged from 0000950170-22-017904:notes:116]

[0000950170-22-025960:notes:117]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | October 28, 2022 |  |  | October 29, 2021 |  |
| Operating lease cost |  | $ | 16 |  |  | $ | 16 |  |  | $ | 31 |  |  | $ | 31 |  |
| Variable lease cost |  |  | 4 |  |  |  | 4 |  |  |  | 8 |  |  |  | 8 |  |
| Total lease cost |  | $ | 20 |  |  | $ | 20 |  |  | $ | 39 |  |  | $ | 39 |  |

[0000950170-22-025960:notes:118]
[same as prior period, unchanged from 0000950170-22-017904:notes:118]

[0000950170-22-025960:notes:119]
[same as prior period, unchanged from 0000950170-22-017904:notes:119]

[0000950170-22-025960:notes:120]
|  |  |  |  | Six Months Ended |  |
|  |  |  |  |  |  | October 28, 2022 |  |  | October 29, 2021 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  |  |  |  |  | $ | 29 |  |  | $ | 28 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  |  |  |  |  | $ | 31 |  |  | $ | 178 |  |

[0000950170-22-025960:notes:121]
[same as prior period, unchanged from 0000950170-22-017904:notes:121]

[0000950170-22-025960:notes:122]
|  |  |  |  |  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| Other non-current assets |  |  |  |  |  | $ | 298 |  |  | $ | 294 |  |
| Total operating lease ROU assets |  |  |  |  |  | $ | 298 |  |  | $ | 294 |  |
| Accrued expenses |  |  |  |  |  | $ | 47 |  |  | $ | 47 |  |
| Other long-term liabilities |  |  |  |  |  |  | 261 |  |  |  | 257 |  |
| Total operating lease liabilities |  |  |  |  |  | $ | 308 |  |  | $ | 304 |  |
| Weighted Average Remaining Lease Term |  |  |  |  |  | 9.6 years |  |  | 9.6 years |  |
| Weighted Average Discount Rate |  |  |  |  |  |  | 2.9 | % |  |  | 2.8 | % |

[0000950170-22-025960:notes:123]
Future minimum operating lease payments as of October 28, 2022, are as follows (in millions):

[0000950170-22-025960:notes:124]
| Fiscal Year |  |  |  |  |  | Amount |  |
| 2023 (remainder) |  |  |  |  |  | $ | 28 |  |
| 2024 |  |  |  |  |  |  | 50 |  |
| 2025 |  |  |  |  |  |  | 40 |  |
| 2026 |  |  |  |  |  |  | 36 |  |
| 2027 |  |  |  |  |  |  | 31 |  |
| Thereafter |  |  |  |  |  |  | 175 |  |
| Total lease payments |  |  |  |  |  |  | 360 |  |
| Less: Interest |  |  |  |  |  |  | (52 | ) |
| Total |  |  |  |  |  | $ | 308 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000950170-22-025960:notes:125]
[same as prior period, unchanged from 0000950170-22-017904:notes:125]

[0000950170-22-025960:notes:126]
[same as prior period, unchanged from 0000950170-22-017904:notes:126]

[0000950170-22-025960:notes:127]
We granted approximately 6 million restricted stock units (RSUs) with a weighted average grant date fair value of $59.43 per share, including performance-based RSUs (PBRSUs), during the six months ended October 28, 2022. In the six months ended October 28, 2022, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSUs cliff-vest at the end of an approximate one, two or three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the first, second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle most of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the six months ended October 28, 2022, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. The fair values of these TSR performance-based awards were fixed at grant date using a Monte Carlo simulation model. For the remaining half of the PBRSUs granted in the six months ended October 28, 2022, the number of shares issued will depend upon the Company's billings result average over the three-year performance period as compared to a predetermined billings target. Billings for purposes of measuring the performance of these PBRSUs means the total obtained by adding net revenues as reported on the Company's Consolidated Statements of Income to the

[0000950170-22-025960:notes:128]
amount reported as the change in deferred revenue and financed unearned services revenue on the Consolidated Statements of Cash Flows for the applicable measurement period, excluding the impact of fluctuations in foreign currency exchange rates. The fair values of these billings PBRSUs were established consistent with our methodology for valuing time-based RSUs, while compensation cost is being recognized based on the probable outcome of the performance condition. The aggregate grant date fair value of PBRSUs effectively granted in the current year was $27 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0000950170-22-025960:notes:129]
[same as prior period, unchanged from 0000950170-22-017904:notes:128]

[0000950170-22-025960:notes:130]
[same as prior period, unchanged from 0000950170-22-017904:notes:129]

[0000950170-22-025960:notes:131]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | October 28, 2022 |  |  | October 29, 2021 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |
| Cost of services revenues |  |  | 4 |  |  |  | 4 |  |  |  | 8 |  |  |  | 6 |  |
| Sales and marketing |  |  | 35 |  |  |  | 29 |  |  |  | 63 |  |  |  | 55 |  |
| Research and development |  |  | 26 |  |  |  | 18 |  |  |  | 50 |  |  |  | 34 |  |
| General and administrative |  |  | 12 |  |  |  | 10 |  |  |  | 22 |  |  |  | 18 |  |
| Total stock-based compensation expense |  | $ | 78 |  |  | $ | 62 |  |  | $ | 145 |  |  | $ | 115 |  |

[0000950170-22-025960:notes:132]
As of October 28, 2022, total unrecognized compensation expense related to our equity awards was $714 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.5 years.

[0000950170-22-025960:notes:133]
[same as prior period, unchanged from 0000950170-22-017904:notes:132]

[0000950170-22-025960:notes:134]
As of October 28, 2022, our Board of Directors has authorized the repurchase of up to $15.1 billion of our common stock. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time.

[0000950170-22-025960:notes:135]
The following table summarizes activity related to the stock repurchase program for the six months ended October 28, 2022 (in millions, except for per share amounts):

[0000950170-22-025960:notes:136]
| Number of shares repurchased |  |  | 7 |  |
| Average price per share |  | $ | 67.70 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 25 |  |
| Stock repurchases allocated to retained earnings |  | $ | 475 |  |
| Remaining authorization at end of period |  | $ | 752 |  |

[0000950170-22-025960:notes:137]
Since the May 13, 2003 inception of our stock repurchase program through October 28, 2022, we repurchased a total of 355 million shares of our common stock at an average price of $40.52 per share, for an aggregate purchase price of $14.4 billion.

[0000950170-22-025960:notes:138]
[same as prior period, unchanged from 0000950170-22-017904:notes:137]

[0000950170-22-025960:notes:139]
[same as prior period, unchanged from 0000950170-22-017904:notes:138]

[0000950170-22-025960:notes:140]
|  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |
| Dividends per share declared |  | $ | 1.00 |  |  | $ | 1.00 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 106 |  |  | $ | — |  |
| Dividend payments allocated to retained earnings |  | $ | 112 |  |  | $ | 224 |  |

[0000950170-22-025960:notes:141]
On November 21, 2022, we declared a cash dividend of $0.50 per share of common stock, payable on January 25, 2023 to holders of record as of the close of business on January 6, 2023. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0000950170-22-025960:notes:142]
[same as prior period, unchanged from 0000950170-22-017904:notes:141]

[0000950170-22-025960:notes:143]
[same as prior period, unchanged from 0000950170-22-017904:notes:142]

[0000950170-22-025960:notes:144]
|  |  | ForeignCurrencyTranslationAdjustments |  |  | DefinedBenefitObligationAdjustments |  |  | UnrealizedGains(Losses) onDerivativeInstruments |  |  | Total |  |
| Balance as of April 29, 2022 |  | $ | (44 | ) |  | $ | (1 | ) |  | $ | 1 |  |  | $ | (44 | ) |
| Other comprehensive income (loss), net of tax |  |  | (18 | ) |  |  | — |  |  |  | 4 |  |  |  | (14 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | (4 | ) |  |  | (4 | ) |
| Total other comprehensive loss |  |  | (18 | ) |  |  | — |  |  |  | — |  |  |  | (18 | ) |
| Balance as of October 28, 2022 |  | $ | (62 | ) |  | $ | (1 | ) |  | $ | 1 |  |  | $ | (62 | ) |

[0000950170-22-025960:notes:145]
[same as prior period, unchanged from 0000950170-22-017904:notes:144]

[0000950170-22-025960:notes:146]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | Statements ofIncome Classification |
| Realized gains on cash flow hedges |  | $ | (3 | ) |  | $ | (1 | ) |  | $ | (4 | ) |  | $ | (1 | ) |  | Net revenues |
| Total reclassifications |  | $ | (3 | ) |  | $ | (1 | ) |  | $ | (4 | ) |  | $ | (1 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-22-025960:notes:147]
[same as prior period, unchanged from 0000950170-22-017904:notes:146]

[0000950170-22-025960:notes:148]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of October 28, 2022 or April 29, 2022. All contracts have a maturity of less than 12 months.

[0000950170-22-025960:notes:149]
[same as prior period, unchanged from 0000950170-22-017904:notes:148]

[0000950170-22-025960:notes:150]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 182 |  |  | $ | 78 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 731 |  |  | $ | 841 |  |
| Forward contracts purchased |  | $ | 106 |  |  | $ | 129 |  |

[0000950170-22-025960:notes:151]
[same as prior period, unchanged from 0000950170-22-017904:notes:150]

[0000950170-22-025960:notes:152]
[same as prior period, unchanged from 0000950170-22-017904:notes:151]

[0000950170-22-025960:notes:153]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | October 28, 2022 |  |  | October 29, 2021 |  |
| Foreign currency exchange contracts |  | $ | (34 | ) |  | $ | (17 | ) |  | $ | (55 | ) |  | $ | (26 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-22-025960:notes:154]
[same as prior period, unchanged from 0000950170-22-017904:notes:153]

[0000950170-22-025960:notes:155]
In the first six months of fiscal 2023, we executed a restructuring plan to redirect resources to highest return activities, which included a reduction in our global workforce of approximately 1% and consisted primarily of employee severance-related costs.

[0000950170-22-025960:notes:156]
We also continued activities related to the establishment of an international headquarters in Cork, Ireland, during the first six months of fiscal 2023, and incurred restructuring charges consisting primarily of severance-related costs and legal and tax-related professional fees. Activities under this plan, for which we expect to incur additional charges, will continue during the remainder of fiscal 2023.

[0000950170-22-025960:notes:157]
During the first six months of fiscal 2022, we executed a restructuring plan to reduce the amount of office space we occupied as we allow more employees to work remotely. In connection with the plan, we also reduced our global workforce by approximately 1%. Charges related to the plan consisted primarily of office relocation costs, lease termination fees, and employee severance-related costs. Substantially all activities under the plan had been completed by the end of fiscal 2022.

[0000950170-22-025960:notes:158]
[same as prior period, unchanged from 0000950170-22-017904:notes:157]

[0000950170-22-025960:notes:159]
|  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |
| Balance at beginning of period |  | $ | 1 |  |  | $ | 1 |  |
| Net charges |  |  | 22 |  |  |  | 29 |  |
| Cash payments |  |  | (14 | ) |  |  | (28 | ) |
| Balance at end of period |  | $ | 9 |  |  | $ | 2 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-22-025960:notes:160]
[same as prior period, unchanged from 0000950170-22-017904:notes:159]

[0000950170-22-025960:notes:161]
[same as prior period, unchanged from 0000950170-22-017904:notes:160]

[0000950170-22-025960:notes:162]
|  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |
| Effective tax rates |  |  | (67.7 | )% |  |  | 17.6 | % |

[0000950170-22-025960:notes:163]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. Our effective tax rate for the six months ended October 28, 2022 was primarily driven by a discrete tax benefit of $524 million that resulted from an intra-entity asset transfer of certain intellectual property ("IP"). Additionally, our effective tax rate for the six months ended October 28, 2022, includes an increase from the prior year primarily due to the capitalization of research and development expenses partially offset by the discrete benefits related to stock-based compensation. Under the Tax Cuts and Jobs Act of 2017, costs incurred beginning in our fiscal 2023 are to be amortized over five or 15 years depending on where the research activities are conducted. The effective tax rate for the six months ended October 29, 2021, includes the impact of discrete tax benefits for lapses of statute of limitations as well as larger benefits related to stock-based compensation as compared to the current year.

[0000950170-22-025960:notes:164]
During the second quarter of fiscal 2023, we completed an intra-entity asset transfer of certain IP to our international headquarters (the “IP Transfer”). The transaction resulted in a step-up of tax-deductible basis in the transferred assets, and accordingly, created a temporary difference where the tax basis exceeded the financial statement basis of such intangible assets, which resulted in the recognition of a discrete tax benefit and related deferred tax asset of $524 million during the second quarter of fiscal 2023.  Management applied significant judgment when determining the fair value of the IP, which serves as the tax basis of the deferred tax asset. With the assistance of third-party valuation specialists, the fair value of the IP was determined principally based on the present value of projected cash flows related to the IP which reflects management’s assumptions regarding projected revenues, expenses and a discount rate. The tax-deductible amortization related to the transferred IP rights will be recognized in future periods and any amortization that is unused in a particular year can be carried forward indefinitely. The deferred tax asset and the tax benefit were measured based on the enacted tax rates expected to apply in the years the asset is expected to be realized. We expect to realize the deferred tax asset resulting from the IP Transfer and will assess the realizability of the deferred tax asset quarterly. Any Organisation for Economic Co-operation and Development’s (“OECD”) actions adopted internationally, could impact our financial results in future periods.

[0000950170-22-025960:notes:165]
As of October 28, 2022, we had $225 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $140 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $140 million have been recorded in other long-term liabilities.

[0000950170-22-025960:notes:166]
[same as prior period, unchanged from 0000950170-22-017904:notes:164]

[0000950170-22-025960:notes:167]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for such withholding tax and filed an appeal with the Danish Tax Tribunal. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012.

[0000950170-22-025960:notes:168]
In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). In March 2018, the Advocate General issued an opinion which was largely in favor of NetApp. The CJEU was not bound by the opinion of the Advocate General and issued its preliminary ruling in February 2019. The CJEU ruling did not preclude the Danish Tax Authorities from imposing withholding tax on distributions based on the benefits of certain European Union directives. On May 3, 2021, the DHC reached a decision resulting in NetApp prevailing on the predominate distribution made in 2005. The smaller distribution made in 2006 was ruled in favor of the Danish Tax Authorities. On May 28, 2021, the Danish Tax Authorities appealed the DHC decision to the Danish Supreme Court. We believe it is more likely than not that our distributions were not subject to withholding tax and we will continue to support our position in the appeals process with the Danish Supreme Court.

[0000950170-22-025960:notes:169]
[same as prior period, unchanged from 0000950170-22-017904:notes:166]


## us-gaap:EarningsPerShareTextBlock

[0000950170-22-025960:notes:170]
[same as prior period, unchanged from 0000950170-22-017904:notes:167]

[0000950170-22-025960:notes:171]
[same as prior period, unchanged from 0000950170-22-017904:notes:168]

[0000950170-22-025960:notes:172]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | October 28, 2022 |  |  | October 29, 2021 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 750 |  |  | $ | 224 |  |  | $ | 964 |  |  | $ | 426 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 217 |  |  |  | 223 |  |  |  | 219 |  |  |  | 223 |  |
| Dilutive impact of employee equity award plans |  |  | 3 |  |  |  | 6 |  |  |  | 3 |  |  |  | 6 |  |
| Shares used in diluted computation |  |  | 220 |  |  |  | 229 |  |  |  | 222 |  |  |  | 229 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.46 |  |  | $ | 1.00 |  |  | $ | 4.40 |  |  | $ | 1.91 |  |
| Diluted |  | $ | 3.41 |  |  | $ | 0.98 |  |  | $ | 4.34 |  |  | $ | 1.86 |  |

[0000950170-22-025960:notes:173]
Six million and five million shares from outstanding employee awards each were excluded from the diluted net income per share calculation for the three and six months ended October 28, 2022, respectively, as their inclusion would have been anti-dilutive. No potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for the three and six months ended October 29, 2021.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-22-025960:notes:174]
[same as prior period, unchanged from 0000950170-22-017904:notes:171]

[0000950170-22-025960:notes:175]
[same as prior period, unchanged from 0000950170-22-017904:notes:172]

[0000950170-22-025960:notes:176]
[same as prior period, unchanged from 0000950170-22-017904:notes:173]

[0000950170-22-025960:notes:177]
[same as prior period, unchanged from 0000950170-22-017904:notes:174]

[0000950170-22-025960:notes:178]
[same as prior period, unchanged from 0000950170-22-017904:notes:175]

[0000950170-22-025960:notes:179]
[same as prior period, unchanged from 0000950170-22-017904:notes:176]

[0000950170-22-025960:notes:180]
|  | Three Months Ended October 28, 2022 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 837 |  |  | $ | — |  |  | $ | 837 |  |
| Support revenues |  | 607 |  |  |  | — |  |  |  | 607 |  |
| Professional and other services revenues |  | 77 |  |  |  | — |  |  |  | 77 |  |
| Public cloud revenues |  | — |  |  |  | 142 |  |  |  | 142 |  |
| Net revenues |  | 1,521 |  |  |  | 142 |  |  |  | 1,663 |  |
| Cost of product revenues |  | 417 |  |  |  | — |  |  |  | 417 |  |
| Cost of support revenues |  | 45 |  |  |  | — |  |  |  | 45 |  |
| Cost of professional and other services revenues |  | 54 |  |  |  | — |  |  |  | 54 |  |
| Cost of public cloud revenues |  | — |  |  |  | 45 |  |  |  | 45 |  |
| Segment cost of revenues |  | 516 |  |  |  | 45 |  |  |  | 561 |  |
| Segment gross profit | $ | 1,005 |  |  | $ | 97 |  |  | $ | 1,102 |  |
| Segment gross margin |  | 66.1 | % |  |  | 68.3 | % |  |  | 66.3 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 15 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,087 |  |
| Total gross margin |  |  |  |  |  |  |  | 65.4 | % |
| 1 Unallocated cost of revenues are composed of $5 million of stock-based compensation expense and $10 million of amortization of intangible assets. |  |

[0000950170-22-025960:notes:181]
|  | Three Months Ended October 29, 2021 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 814 |  |  | $ | — |  |  | $ | 814 |  |
| Support revenues |  | 590 |  |  |  | — |  |  |  | 590 |  |
| Professional and other services revenues |  | 75 |  |  |  | — |  |  |  | 75 |  |
| Public cloud revenues |  | — |  |  |  | 87 |  |  |  | 87 |  |
| Net revenues |  | 1,479 |  |  |  | 87 |  |  |  | 1,566 |  |
| Cost of product revenues |  | 369 |  |  |  | — |  |  |  | 369 |  |
| Cost of support revenues |  | 48 |  |  |  | — |  |  |  | 48 |  |
| Cost of professional and other services revenues |  | 54 |  |  |  | — |  |  |  | 54 |  |
| Cost of public cloud revenues |  | — |  |  |  | 25 |  |  |  | 25 |  |
| Segment cost of revenues |  | 471 |  |  |  | 25 |  |  |  | 496 |  |
| Segment gross profit | $ | 1,008 |  |  | $ | 62 |  |  | $ | 1,070 |  |
| Segment gross margin |  | 68.2 | % |  |  | 71.3 | % |  |  | 68.3 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 11 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,059 |  |
| Total gross margin |  |  |  |  |  |  |  | 67.6 | % |
| 1 Unallocated cost of revenues are composed of $4 million of stock-based compensation expense and $7 million of amortization of intangible assets. |  |

[0000950170-22-025960:notes:182]
|  | Six Months Ended October 28, 2022 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 1,623 |  |  | $ | — |  |  | $ | 1,623 |  |
| Support revenues |  | 1,205 |  |  |  | — |  |  |  | 1,205 |  |
| Professional and other services revenues |  | 153 |  |  |  | — |  |  |  | 153 |  |
| Public cloud revenues |  | — |  |  |  | 274 |  |  |  | 274 |  |
| Net revenues |  | 2,981 |  |  |  | 274 |  |  |  | 3,255 |  |
| Cost of product revenues |  | 812 |  |  |  | — |  |  |  | 812 |  |
| Cost of support revenues |  | 88 |  |  |  | — |  |  |  | 88 |  |
| Cost of professional and other services revenues |  | 106 |  |  |  | — |  |  |  | 106 |  |
| Cost of public cloud revenues |  | — |  |  |  | 85 |  |  |  | 85 |  |
| Segment cost of revenues |  | 1,006 |  |  |  | 85 |  |  |  | 1,091 |  |
| Segment gross profit | $ | 1,975 |  |  | $ | 189 |  |  | $ | 2,164 |  |
| Segment gross margin |  | 66.3 | % |  |  | 69.0 | % |  |  | 66.5 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 31 |  |
| Total gross profit |  |  |  |  |  |  | $ | 2,133 |  |
| Total gross margin |  |  |  |  |  |  |  | 65.5 | % |
| 1 Unallocated cost of revenues are composed of $10 million of stock-based compensation expense and $21 million of amortization of intangible assets. |  |

[0000950170-22-025960:notes:183]
|  | Six Months Ended October 29, 2021 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 1,544 |  |  | $ | — |  |  | $ | 1,544 |  |
| Support revenues |  | 1,168 |  |  |  | — |  |  |  | 1,168 |  |
| Professional and other services revenues |  | 146 |  |  |  | — |  |  |  | 146 |  |
| Public cloud revenues |  | — |  |  |  | 166 |  |  |  | 166 |  |
| Net revenues |  | 2,858 |  |  |  | 166 |  |  |  | 3,024 |  |
| Cost of product revenues |  | 695 |  |  |  | — |  |  |  | 695 |  |
| Cost of support revenues |  | 96 |  |  |  | — |  |  |  | 96 |  |
| Cost of professional and other services revenues |  | 105 |  |  |  | — |  |  |  | 105 |  |
| Cost of public cloud revenues |  | — |  |  |  | 48 |  |  |  | 48 |  |
| Segment cost of revenues |  | 896 |  |  |  | 48 |  |  |  | 944 |  |
| Segment gross profit | $ | 1,962 |  |  | $ | 118 |  |  | $ | 2,080 |  |
| Segment gross margin |  | 68.6 | % |  |  | 71.1 | % |  |  | 68.8 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 22 |  |
| Total gross profit |  |  |  |  |  |  | $ | 2,058 |  |
| Total gross margin |  |  |  |  |  |  |  | 68.1 | % |
| 1 Unallocated cost of revenues are composed of $8 million of stock-based compensation expense and $14 million of amortization of intangible assets. |  |

[0000950170-22-025960:notes:184]
[same as prior period, unchanged from 0000950170-22-017904:notes:179]

[0000950170-22-025960:notes:185]
[same as prior period, unchanged from 0000950170-22-017904:notes:180]

[0000950170-22-025960:notes:186]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | October 28, 2022 |  |  | October 29, 2021 |  |
| United States, Canada and Latin America (Americas) |  | $ | 889 |  |  | $ | 868 |  |  | $ | 1,745 |  |  | $ | 1,654 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 535 |  |  |  | 461 |  |  |  | 1,035 |  |  |  | 915 |  |
| Asia Pacific (APAC) |  |  | 239 |  |  |  | 237 |  |  |  | 475 |  |  |  | 455 |  |
| Net revenues |  | $ | 1,663 |  |  | $ | 1,566 |  |  | $ | 3,255 |  |  | $ | 3,024 |  |

[0000950170-22-025960:notes:187]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $769 million and $773 million during the three months ended October 28, 2022 and October 29, 2021, respectively, and were $1,527 million and $1,469 million during the six months ended October 28, 2022 and October 29, 2021, respectively.

[0000950170-22-025960:notes:188]
[same as prior period, unchanged from 0000950170-22-017904:notes:183]

[0000950170-22-025960:notes:189]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| U.S. |  | $ | 1,590 |  |  | $ | 1,820 |  |
| International |  |  | 1,443 |  |  |  | 2,314 |  |
| Total |  | $ | 3,033 |  |  | $ | 4,134 |  |

[0000950170-22-025960:notes:190]
[same as prior period, unchanged from 0000950170-22-017904:notes:185]

[0000950170-22-025960:notes:191]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| U.S. |  | $ | 431 |  |  | $ | 392 |  |
| International |  |  | 230 |  |  |  | 210 |  |
| Total |  | $ | 661 |  |  | $ | 602 |  |

[0000950170-22-025960:notes:192]
[same as prior period, unchanged from 0000950170-22-017904:notes:187]

[0000950170-22-025960:notes:193]
[same as prior period, unchanged from 0000950170-22-017904:notes:188]

[0000950170-22-025960:notes:194]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2022 |  |  | October 29, 2021 |  |  | October 28, 2022 |  |  | October 29, 2021 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 24 | % |  |  | 25 | % |  |  | 24 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 20 | % |  |  | 20 | % |  |  | 20 | % |

[0000950170-22-025960:notes:195]
[same as prior period, unchanged from 0000950170-22-017904:notes:190]

[0000950170-22-025960:notes:196]
|  |  | October 28, 2022 |  |  | April 29, 2022 |  |
| Arrow Electronics, Inc. |  |  | 15 | % |  |  | 10 | % |
| Tech Data Corporation |  |  | 19 | % |  |  | 19 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-22-025960:notes:197]
15. Commitments and Contingencies

[0000950170-22-025960:notes:198]
Purchase Orders and Other Commitments

[0000950170-22-025960:notes:199]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of October 28, 2022, we had approximately $0.6 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 28, 2022 and April 29, 2022, such liability amounted to $20 million and $18 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0000950170-22-025960:notes:200]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 28, 2022, we had approximately $0.3 billion in other purchase obligations.

[0000950170-22-025960:notes:201]
Financing Guarantees

[0000950170-22-025960:notes:202]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $10 million and $38 million of receivables during the first six months ended October 28, 2022 and October 29, 2021, respectively.

[0000950170-22-025960:notes:203]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0000950170-22-025960:notes:204]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of October 28, 2022 and April 29, 2022, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-22-025960:notes:205]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 28, 2022, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount

[0000950170-22-025960:notes:206]
of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-22-025960:notes:207]
Legal Contingencies

[0000950170-22-025960:notes:208]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0000950170-22-025960:notes:209]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. The defendants' Motion to Dismiss was granted and on February 26, 2021 and the judge entered judgment in favor of NetApp and the other defendants. On March 26, 2021, plaintiffs filed a notice of appeal. The parties subsequently engaged in settlement discussions, and on July 30, 2021 entered into a Memorandum of Understanding (MOU) providing for the settlement of the class action. Pursuant to the terms of the MOU, NetApp has agreed to pay approximately $2.0 million in connection with the settlement, and this amount was accrued during the three months ended July 30, 2021. The parties subsequently executed a stipulation of settlement, which contains no admission of liability, wrongdoing or responsibility by any of the parties, and which provides that the class action will be dismissed with prejudice, with mutual releases by all parties, upon final court approval. On September 24, 2021, plaintiff filed an unopposed motion seeking court approval of the settlement. On May 2, 2022, the court preliminarily approved the settlement. On September 1, 2022, the court held a final approval hearing, approved the settlement and dismissed the case with prejudice.

[0000950170-22-025960:notes:210]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0000950170-22-025960:notes:211]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of October 28, 2022 related to such matters.
