# NTAP note change history — 0000950170-22-017904 → 0000950170-22-025960


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-12-01):
[0000950170-22-025960:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of October 28, 2022, we had approximately $0.6 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 28, 2022 and April 29, 2022, such liability amounted to $20 million and $18 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2022-08-30, similarity 0.9893):
[0000950170-22-017904:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of July 29, 2022, we had approximately $0.9 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 29, 2022 and April 29, 2022, such liability amounted to $23 million and $18 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2022-12-01):
[0000950170-22-025960:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 28, 2022, we had approximately $0.3 billion in other purchase obligations.
  (was, 2022-08-30, similarity 0.9832):
[0000950170-22-017904:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 29, 2022, we had approximately $0.3 billion in other purchase obligations.

- changed (2022-12-01):
[0000950170-22-025960:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $10 million and $38 million of receivables during the first six months ended October 28, 2022 and October 29, 2021, respectively.
  (was, 2022-08-30, similarity 0.9684):
[0000950170-22-017904:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $3 million and $17 million of receivables during the three months ended July 29, 2022 and July 30, 2021, respectively.

- changed (2022-12-01):
[0000950170-22-025960:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of October 28, 2022 and April 29, 2022, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2022-08-30, similarity 0.9951):
[0000950170-22-017904:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of July 29, 2022 and April 29, 2022, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- changed (2022-12-01):
[0000950170-22-025960:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 28, 2022, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount
  (was, 2022-08-30, similarity 0.6606):
[0000950170-22-017904:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 29, 2022, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- added (2022-12-01):
[0000950170-22-025960:note_history:6]
of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- changed (2022-12-01):
[0000950170-22-025960:note_history:7]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. The defendants' Motion to Dismiss was granted and on February 26, 2021 and the judge entered judgment in favor of NetApp and the other defendants. On March 26, 2021, plaintiffs filed a notice of appeal. The parties subsequently engaged in settlement discussions, and on July 30, 2021 entered into a Memorandum of Understanding (MOU) providing for the settlement of the class action. Pursuant to the terms of the MOU, NetApp has agreed to pay approximately $2.0 million in connection with the settlement, and this amount was accrued during the three months ended July 30, 2021. The parties subsequently executed a stipulation of settlement, which contains no admission of liability, wrongdoing or responsibility by any of the parties, and which provides that the class action will be dismissed with prejudice, with mutual releases by all parties, upon final court approval. On September 24, 2021, plaintiff filed an unopposed motion seeking court approval of the settlement. On May 2, 2022, the court preliminarily approved the settlement. On September 1, 2022, the court held a final approval hearing, approved the settlement and dismissed the case with prejudice.
  (was, 2022-08-30, similarity 0.9136):
[0000950170-22-017904:note_history:7]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. The defendants' Motion to Dismiss was granted and on February 26, 2021 and the judge entered judgment in favor of NetApp and the other defendants. On March 26, 2021, plaintiffs filed a notice of appeal. The parties subsequently engaged in settlement discussions, and on July 30, 2021 entered into a Memorandum of Understanding (MOU) providing for the settlement of the class action.  Pursuant to the terms of the MOU, NetApp has agreed to pay approximately $2.0 million in connection with the settlement, and this amount was accrued during the three months ended July 30, 2021. The parties subsequently executed a stipulation of settlement, which contains no admission of liability, wrongdoing or responsibility by any of the parties, and which provides that the class action will be dismissed with prejudice, with mutual releases by all parties, upon final court approval. On September 24, 2021, plaintiff filed an unopposed motion seeking court approval of the settlement. On May 2, 2022, the court preliminarily approved the settlement, subject to further consideration at a final approval hearing, which is scheduled to be held on September 1, 2022. The court’s approval of settlement will remain preliminary pending the outcome of the final approval hearing.

- changed (2022-12-01):
[0000950170-22-025960:note_history:8]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of October 28, 2022 related to such matters.
  (was, 2022-08-30, similarity 0.9939):
[0000950170-22-017904:note_history:8]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of July 29, 2022 related to such matters.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-12-01):
[0000950170-22-025960:note_history:9]
NetApp, Inc. (we, us, NetApp, or the Company) is a global cloud-led, data-centric software company that provides organizations the ability to manage and share their data across on-premises, private and public clouds. We provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.
  (was, 2022-08-30, similarity 0.9906):
[0000950170-22-017904:note_history:9]
NetApp, Inc. (we, us, or the Company) is a global cloud-led, data-centric software company that provides organizations the ability to manage and share their data across on-premises, private and public clouds. We provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.

- changed (2022-12-01):
[0000950170-22-025960:note_history:10]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2022 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 28, 2022 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2022-08-30, similarity 0.8787):
[0000950170-22-017904:note_history:10]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2022 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 29, 2022 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- changed (2022-12-01):
[0000950170-22-025960:note_history:11]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; valuation of intellectual property; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates. Management’s estimates include, as applicable, the anticipated impacts of the COVID-19 pandemic.
  (was, 2022-08-30, similarity 0.9792):
[0000950170-22-017904:note_history:11]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates. Management’s estimates include, as applicable, the anticipated impacts of the COVID-19 pandemic.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-12-01):
[0000950170-22-025960:note_history:12]
|  |  | Effective Interest Rate |  | October 28, 2022 |  |  | April 29, 2022 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | — |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,400 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (13 | ) |  |  | (14 | ) |
| Total senior notes |  |  |  |  | 2,387 |  |  |  | 2,636 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (250 | ) |
| Total long-term debt |  |  |  | $ | 2,387 |  |  | $ | 2,386 |  |
  (was, 2022-08-30, similarity 0.9834):
[0000950170-22-017904:note_history:12]
|  |  | Effective Interest Rate |  | July 29, 2022 |  |  | April 29, 2022 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | 250 |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,650 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (13 | ) |  |  | (14 | ) |
| Total senior notes |  |  |  |  | 2,637 |  |  |  | 2,636 |  |
| Less: Current portion of long-term debt |  |  |  |  | (250 | ) |  |  | (250 | ) |
| Total long-term debt |  |  |  | $ | 2,387 |  |  | $ | 2,386 |  |

- changed (2022-12-01):
[0000950170-22-025960:note_history:13]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were each issued in
  (was, 2022-08-30, similarity 0.793):
[0000950170-22-017904:note_history:13]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were issued in June 2020. Interest on these Senior Notes is payable semi-annually in June and December.

- added (2022-12-01):
[0000950170-22-025960:note_history:14]
June 2020. Interest on each of these Senior Notes is payable semi-annually in June and December. Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September.

- added (2022-12-01):
[0000950170-22-025960:note_history:15]
On September 15, 2022, we extinguished our 3.25% Senior Notes due December 2022 for an aggregate cash redemption price of $252 million, comprised of the principal and unpaid interest.

- changed (2022-12-01):
[0000950170-22-025960:note_history:16]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 28, 2022, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2022-08-30, similarity 0.9915):
[0000950170-22-017904:note_history:16]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 29, 2022, we were in compliance with all covenants associated with the Senior Notes.

- changed (2022-12-01):
[0000950170-22-025960:note_history:17]
As of October 28, 2022, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2022-08-30, similarity 0.9405):
[0000950170-22-017904:note_history:17]
As of July 29, 2022, our aggregate future principal debt maturities are as follows (in millions):

- changed (2022-12-01):
[0000950170-22-025960:note_history:18]
| Fiscal Year |  | Amount |  |
| 2023 (remainder) |  | $ | — |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| 2027 |  |  | — |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,400 |  |
  (was, 2022-08-30, similarity 0.9941):
[0000950170-22-017904:note_history:18]
| Fiscal Year |  | Amount |  |
| 2023 (remainder) |  | $ | 250 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| 2027 |  |  | — |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |

- changed (2022-12-01):
[0000950170-22-025960:note_history:19]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of October 28, 2022 or April 29, 2022.
  (was, 2022-08-30, similarity 0.9933):
[0000950170-22-017904:note_history:19]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of July 29, 2022 or April 29, 2022.

- changed (2022-12-01):
[0000950170-22-025960:note_history:20]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in January 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of October 28, 2022, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.
  (was, 2022-08-30, similarity 0.9931):
[0000950170-22-017904:note_history:20]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in January 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of July 29, 2022, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.

- removed (2022-12-01):
[0000950170-22-017904:note_history:21]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September. Our 3.25% Senior Notes, with a principal amount of $250 million, were issued in December 2012 with interest paid semi-annually in June and December.

- removed (2022-12-01):
[0000950170-22-017904:note_history:22]
In August 2022, we called for redemption of the aggregate principal amount of 3.25% Senior Notes due December 2022. The aggregate redemption price to be paid is $252 million, comprised of the principal and unpaid interest. The redemption date is September 15, 2022.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-12-01):
[0000950170-22-025960:note_history:23]
|  |  | Effective Interest Rate |  | October 28, 2022 |  |  | April 29, 2022 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | — |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,400 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (13 | ) |  |  | (14 | ) |
| Total senior notes |  |  |  |  | 2,387 |  |  |  | 2,636 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (250 | ) |
| Total long-term debt |  |  |  | $ | 2,387 |  |  | $ | 2,386 |  |
  (was, 2022-08-30, similarity 0.9834):
[0000950170-22-017904:note_history:23]
|  |  | Effective Interest Rate |  | July 29, 2022 |  |  | April 29, 2022 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | 250 |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,650 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (13 | ) |  |  | (14 | ) |
| Total senior notes |  |  |  |  | 2,637 |  |  |  | 2,636 |  |
| Less: Current portion of long-term debt |  |  |  |  | (250 | ) |  |  | (250 | ) |
| Total long-term debt |  |  |  | $ | 2,387 |  |  | $ | 2,386 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-12-01):
[0000950170-22-025960:note_history:24]
As of October 28, 2022, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2022-08-30, similarity 0.9405):
[0000950170-22-017904:note_history:24]
As of July 29, 2022, our aggregate future principal debt maturities are as follows (in millions):

- changed (2022-12-01):
[0000950170-22-025960:note_history:25]
| Fiscal Year |  | Amount |  |
| 2023 (remainder) |  | $ | — |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| 2027 |  |  | — |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,400 |  |
  (was, 2022-08-30, similarity 0.9941):
[0000950170-22-017904:note_history:25]
| Fiscal Year |  | Amount |  |
| 2023 (remainder) |  | $ | 250 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| 2027 |  |  | — |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |
