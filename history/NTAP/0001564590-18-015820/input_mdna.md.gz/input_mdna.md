# NTAP MD&A — 0001564590-18-015820


## mdna

[0001564590-18-015820:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001564590-18-015820:mdna:2]
The following discussion of our financial condition and results of operations should be read together with the financial statements and the accompanying notes set forth under Item 8. – Financial Statements and Supplementary Data. The following discussion also contains trend information and other forward-looking statements that involve a number of risks and uncertainties. The Risk Factors set forth in Item 1A. – Risk Factors are hereby incorporated into the discussion by reference.

[0001564590-18-015820:mdna:3]
Executive Overview

[0001564590-18-015820:mdna:4]
Our Company

[0001564590-18-015820:mdna:5]
We are the data authority for the hybrid cloud. Digital transformation remains top of mind for executives. In order to successfully digitally transform, data must become the lifeblood of an organization and be used as a business accelerator. Data-driven digital transformations accelerate business outcomes. Together with our partners, we empower global organizations to unleash the full potential of their data to enable new customer touchpoints, create innovative business opportunities and optimize operations.

[0001564590-18-015820:mdna:6]
NetApp delivers a Data Fabric built for the data-driven world. Our Data Fabric simplifies and integrates data management across clouds and on-premises to accelerate digital transformation, enabling our customers to manage, secure and protect their data at the scale needed to accommodate the exponential data growth of the digital world. It delivers integrated data management services and applications for data visibility and insights, data access and control, and data protection and security.

[0001564590-18-015820:mdna:7]
We focus on delivering an exceptional customer experience to become our customers’ preferred data partner. NetApp’s unique approach to managing data holistically enables organizations to inspire innovation with the cloud, build clouds to accelerate new services, and modernize IT architecture with cloud-connected flash.

[0001564590-18-015820:mdna:8]
With NetApp products and solutions, customers can:

[0001564590-18-015820:mdna:9]
|  | • | Continually fuel business growth by delivering data-rich customer experiences through new application deployments that easily use data and services regardless of where they reside or in what form. |

[0001564590-18-015820:mdna:10]
|  | • | Accelerate digital transformation by developing a next-generation, cloud-architected infrastructure that manages data and services as one integrated resource supporting both public and private clouds. |

[0001564590-18-015820:mdna:11]
|  | • | Free the resources necessary to fund transformation by deploying the industry’s leading flash storage solution, which is highly efficient and scales from the edge to the core to the cloud. |

[0001564590-18-015820:mdna:12]
Customers are attracted by the speed and scale benefits of the public cloud but need new data management capabilities to keep control of data as it moves beyond the walls of the enterprise. NetApp believes the hybrid cloud is fast becoming the dominant model for enterprise IT. Whether an organization is targeting an all-cloud, hybrid cloud, or multi-cloud strategy, NetApp Cloud Data Services accelerate the time it takes to deploy or develop an application by making the data requirements seamless to the application layer.

[0001564590-18-015820:mdna:13]
Budget constraints and skill imbalances lead our customers to seek help in integrating, deploying and managing the solutions they need to stay competitive. This drives demand for converged and hyper-converged infrastructure solutions. FlexPod is the converged infrastructure of choice for many of the largest enterprises around the globe. Customers can break free from the limits of first-generation HCI with NetApp HCI and attain guaranteed performance with high levels flexibility, scale, automation, and integration with the Data Fabric.

[0001564590-18-015820:mdna:14]
Flash plays a key role in customers’ digital transformation efforts as they seek to gain advantage through greater speed, responsiveness and value from key business applications - all while lowering total cost of ownership. All-flash array technology is the de facto choice for primary application workloads as customers seek performance and economic benefits from replacing hard disk installations. With a highly differentiated and broad portfolio of all-flash and hybrid array offerings, NetApp is well positioned to enable customers to accomplish this transition.

[0001564590-18-015820:mdna:15]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. Strategic solutions include Clustered ONTAP, branded E-Series, SolidFire, converged and hyper-converged infrastructure, and optional add-on software products. Mature solutions include 7-mode ONTAP, add-on hardware and related operating system (OS) software and original equipment manufacturers (OEM) products. Both our Mature and Strategic product lines include a mix of disk, hybrid and all flash storage media.

[0001564590-18-015820:mdna:16]
Additionally, we provide a variety of services including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training to help customers most effectively manage their data. Revenues generated by our Cloud Data Services offerings are included in software maintenance revenues.

[0001564590-18-015820:mdna:17]
31

[0001564590-18-015820:mdna:18]
Financial Results and Key Performance Metrics Overview

[0001564590-18-015820:mdna:19]
The following table provides an overview of some of our key financial metrics for each of the last three fiscal years (in millions, except per share amounts, percentages and cash conversion cycle):

[0001564590-18-015820:mdna:20]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Net revenues |  | $ | 5,911 |  |  | $ | 5,519 |  |  | $ | 5,546 |  |
| Gross profit |  | $ | 3,699 |  |  | $ | 3,390 |  |  | $ | 3,373 |  |
| Gross profit margin percentage |  |  | 63 | % |  |  | 61 | % |  |  | 61 | % |
| Income from operations |  | $ | 1,125 |  |  | $ | 665 |  |  | $ | 348 |  |
| Income from operations as a percentage of net revenues |  |  | 19 | % |  |  | 12 | % |  |  | 6 | % |
| Provision for income taxes |  | $ | 1,090 |  |  | $ | 156 |  |  | $ | 116 |  |
| Net income |  | $ | 76 |  |  | $ | 509 |  |  | $ | 229 |  |
| Diluted net income per share |  | $ | 0.28 |  |  | $ | 1.81 |  |  | $ | 0.77 |  |
| Operating cash flows |  | $ | 1,478 |  |  | $ | 986 |  |  | $ | 974 |  |

[0001564590-18-015820:mdna:21]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,477 |  |  | $ | 3,342 |  |
| Cash conversion cycle |  |  | (15 | ) |  |  | 15 |  |

[0001564590-18-015820:mdna:22]
|  | • | Net revenues: Our net revenues increased 7% in fiscal 2018 compared to fiscal 2017. This was primarily due to an increase of 15% in product revenues, partially offset by a 3% decrease in software and hardware maintenance and other services revenues. |

[0001564590-18-015820:mdna:23]
|  | • | Gross profit margin percentage: Our gross profit margin as a percentage of net revenues increased by one percentage point in fiscal 2018 compared to fiscal 2017, reflecting an increase in gross profit margin on product revenues, and, to a lesser extent, an increase in gross profit margin on hardware maintenance and other services revenues. |

[0001564590-18-015820:mdna:24]
|  | • | Income from operations as a percentage of net revenues: Our income from operations as a percentage of net revenues increased in fiscal 2018 compared to fiscal 2017 primarily due to higher product gross margin and lower operating expenses as a result of a gain on sale of certain of our properties. |

[0001564590-18-015820:mdna:25]
|  | • | Provision for income taxes: Our provision for income taxes increased significantly in fiscal 2018 compared to fiscal 2017 as a result of significant charges recorded in connection with U.S. tax reform enacted in fiscal 2018. |

[0001564590-18-015820:mdna:26]
|  | • | Net income and Diluted income per share: The 85% decrease in both net income and diluted net income per share in fiscal 2018 compared to fiscal 2017 reflect the factors discussed above. Diluted net income per share was favorably impacted by a 2% decrease in the annual weighted average number of dilutive shares, primarily due to share repurchases. |

[0001564590-18-015820:mdna:27]
|  | • | Operating cash flows: Operating cash flows increased by 50% in fiscal 2018 compared to fiscal 2017, reflecting changes in operating assets and liabilities, partially offset by lower net income. |

[0001564590-18-015820:mdna:28]
|  | • | Deferred revenue and financed unearned services revenue: Total deferred revenue and financed unearned services revenue increased $135 million, or 4%, as of fiscal 2018 year end compared to fiscal 2017 year end primarily due to increases in the installed base and aggregate contract values under software and hardware maintenance contracts. |

[0001564590-18-015820:mdna:29]
|  | • | Cash Conversion Cycle: Our cash conversion cycle was (15) days in the fourth quarter of fiscal 2018, compared to 15 days in the corresponding period of fiscal 2017, reflecting higher Days Payables Outstanding and lower Days Inventory Outstanding, partially offset by higher Days Sales Outstanding. |

[0001564590-18-015820:mdna:30]
Stock Repurchase Program and Dividend Activity

[0001564590-18-015820:mdna:31]
During fiscal 2018, we repurchased 15 million shares of our common stock at an average price of $51.57 per share, for an aggregate purchase price of $794 million. We also declared cash dividends of an aggregate of $0.80 per share in fiscal 2018, for which we paid an aggregate of $214 million.

[0001564590-18-015820:mdna:32]
Senior Notes Issuance and Redemption

[0001564590-18-015820:mdna:33]
In September 2017, we issued $400 million aggregate principal amount of 2.00% Senior Notes due on September 27, 2019 and $400 million aggregate principal amount of 3.30% Senior Notes due on September 29, 2024, for which we received total proceeds of approximately $795 million, net of discount and issuance costs. On November 3, 2017, we extinguished our 2.00% Senior Notes due December 2017 for an aggregate redemption price of $751 million, plus accrued and unpaid interest.

[0001564590-18-015820:mdna:34]
32

[0001564590-18-015820:mdna:35]
Real Estate Transactions

[0001564590-18-015820:mdna:36]
On September 8, 2017, we entered into an agreement to sell certain land and buildings for a total of $306 million, through two separate and independent closings. On December 7, 2017, the first closing date, we consummated the sale of properties with a net book value of $66 million for cash proceeds of $210 million, resulting in a gain, net of direct selling costs, of $142 million.

[0001564590-18-015820:mdna:37]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings. The arrangement did not qualify for sale-leaseback accounting and instead was accounted for as a financing transaction. In December 2017, we terminated the leases and recorded a non-cash sale of properties with a net book value of $54 million, the extinguishment of $130 million in financing obligations, and a gain of $76 million.

[0001564590-18-015820:mdna:38]
Tax Reform

[0001564590-18-015820:mdna:39]
On December 22, 2017, the 2017 Tax Reform Reconciliation Act, originally referred to as the Tax Cuts and Jobs Act (TCJA), was enacted into law. This tax reform legislation contains several key tax provisions that affected us, including a one-time mandatory transition tax on accumulated foreign earnings and a reduction of the U.S. corporate income tax rate to 21% effective January 1, 2018, among others. Our net income in fiscal 2018 includes a one-time tax reform-related provisional charge of $858 million.

[0001564590-18-015820:mdna:40]
Critical Accounting Policies and Estimates

[0001564590-18-015820:mdna:41]
Our consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (GAAP), which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and liabilities. Our estimates are based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0001564590-18-015820:mdna:42]
The summary of significant accounting policies is included in Note 1 – Description of Business and Significant Accounting Policies of the Notes to Consolidated Financial Statements. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. The accounting policies described below reflect the significant judgments, estimates and assumptions used in the preparation of the consolidated financial statements.

[0001564590-18-015820:mdna:43]
Revenue Recognition, Reserves and Allowances

[0001564590-18-015820:mdna:44]
We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable and collection is reasonably assured. Revenue from the sale of hardware systems and software components essential to the functionality of the hardware systems is recognized in accordance with general revenue recognition accounting guidance. Our product revenues also include revenues from the sale of non-essential software products, which generally includes a perpetual license to our software. Non-essential software sales are subject to industry specific software revenue recognition accounting guidance. Software maintenance and hardware maintenance services revenues are recognized ratably over their contractual terms, generally from one to five years.

[0001564590-18-015820:mdna:45]
For multiple element arrangements, we allocate revenue to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement. For our non-software deliverables, we allocate the arrangement consideration based on the relative selling price of the deliverables using estimated selling price (ESP). For our software maintenance services, we generally use vendor-specific objective evidence of selling price (VSOE). When we are unable to establish VSOE for our software maintenance services, we use ESP in our allocation of arrangement consideration.

[0001564590-18-015820:mdna:46]
The selling price for each element is based upon the following selling price hierarchy: VSOE if available, third party evidence (TPE) if VSOE is not available, or ESP if neither VSOE nor TPE are available. Generally, we are not able to determine TPE because our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained.

[0001564590-18-015820:mdna:47]
We record reductions to revenue for estimated sales returns at the time of shipment. We also maintain a separate allowance for doubtful accounts for estimated losses based on our assessment of the collectability of specific customer accounts.

[0001564590-18-015820:mdna:48]
The following are the key estimates and assumptions and corresponding uncertainties for recognizing revenue:

[0001564590-18-015820:mdna:49]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |

[0001564590-18-015820:mdna:50]
33

[0001564590-18-015820:mdna:51]
| • | We establish VSOE of selling price using the price charged for a deliverable when sold separately and generally evidenced by a substantial majority of historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer type, and other variables in determining VSOE. Our revenue estimates and assumptions are based on our ability to assert and maintain VSOE. ESP is generally evidenced by a majority of historical transactions falling within a reasonable price range. We also consider multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer type and distribution channels. Our revenue estimates and assumptions are based on our ability to maintain consistent ESP. |  | • | As our business and offerings evolve over time, modifications to our pricing and discounting methodologies, changes in the scope and nature of service offerings and/or changes in customer segmentation may result in a lack of consistency required to establish and/or maintain key revenue estimates and assumptions. Additionally, technological changes resulting in variability in product costs and gross margins may require changes to certain estimates and assumptions. Such changes may result in a different allocation of revenue to the deliverables in multiple-element arrangements. These factors, among others, may adversely impact the amount of revenue and gross margin we report in a particular period. |
| • | Sales returns are estimated based on historical sales returns, current trends and our expectations regarding future experience. Additionally, distributors and partners participate in various marketing and other programs, and we maintain estimated accruals and allowances for these programs based on contractual terms and historical experience. |  | • | If there is insufficient relevant historical data for determining our sales returns estimates, or if we experience changes in practices related to sales returns or changes in market or competitive conditions resulting in higher than expected return rates, or if actual credits received by our distributors and partners deviate significantly from our estimates, our revenues may be adversely impacted. |

[0001564590-18-015820:mdna:52]
Inventory Valuation and Purchase Order Accruals

[0001564590-18-015820:mdna:53]
Inventories consist primarily of purchased components and finished goods and are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. A provision is recorded when inventory is determined to be in excess of anticipated demand or obsolete in order to adjust inventory to its estimated realizable value. The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our inventories:

[0001564590-18-015820:mdna:54]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | We periodically perform an excess and obsolete analysis of our inventory. Inventories are written down based on excess and obsolete reserves determined primarily on assumptions about future demand forecasts and market conditions. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. |  | • | Although we use our best estimates to forecast future product demand, any significant unanticipated changes in demand or obsolescence related to technological developments, new product introductions, customer requirements, competition or other factors could have a significant impact on the valuation of our inventory. If actual market conditions are less favorable than those projected, additional write-downs and other charges against earnings that adversely impact gross margins may be required. If actual market conditions are more favorable, we may realize higher gross profits in the period when the written-down inventory is sold. We are subject to a variety of environmental laws relating to the manufacture of our products. If there are changes to the current regulations, we may be required to make product design changes which may result in excess or obsolete inventory, which could adversely impact our operating results. |
| • | We make commitments to our third-party contract manufacturers and other suppliers to manage lead times and meet product forecasts and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on non-cancelable purchase commitments when we believe it is probable that the components will not be utilized in future operations. |  | • | If the actual materials demand is significantly lower than our forecast, we may be required to increase our recorded liabilities for estimated losses on non-cancelable purchase commitments which would adversely impact our operating results. |

[0001564590-18-015820:mdna:55]
Goodwill and Purchased Intangible Assets

[0001564590-18-015820:mdna:56]
We allocate the purchase price of acquisitions to identifiable assets acquired and liabilities assumed at their acquisition date fair

[0001564590-18-015820:mdna:57]
34

[0001564590-18-015820:mdna:58]
values based on established valuation techniques. Goodwill represents the residual value as of the acquisition date, which in most cases is measured as the excess of the purchase consideration transferred over the net of the acquisition date fair values of the assets acquired and liabilities assumed.

[0001564590-18-015820:mdna:59]
The carrying values of purchased intangible assets are reviewed whenever events and circumstances indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. We periodically review the estimated remaining useful lives of our intangible assets. This review may result in impairment charges or shortened useful lives, resulting in charges to our consolidated statements of operations.

[0001564590-18-015820:mdna:60]
We review goodwill for impairment annually and whenever events or changes in circumstances indicate the carrying amount of our reporting unit may exceed its fair value. The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. For our annual goodwill impairment test in the fourth quarter of fiscal 2018, we performed a quantitative test and determined the fair value of our reporting unit substantially exceeded its carrying amount, therefore, found no impairment of goodwill.

[0001564590-18-015820:mdna:61]
The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our goodwill and purchased intangible assets:

[0001564590-18-015820:mdna:62]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the accounting guidance for the fair value measurement of nonfinancial assets. The valuation of purchased intangible assets is principally based on estimates of the future performance and cash flows expected to be generated by the acquired assets from the acquired business. |  | • | While we employ experts to determine the acquisition date fair value of acquired intangibles, the fair values of assets acquired and liabilities assumed are based on significant management assumptions and estimates, which are inherently uncertain and highly subjective and as a result, actual results may differ from estimates. If different assumptions were to be used, it could materially impact the purchase price allocation. |
| • | Evaluations of possible goodwill and purchased intangible assets impairment require us to make judgments and assumptions related to the allocation of our balance sheet and income statement amounts and estimate future cash flows and fair market values of our reporting unit and assets. |  | • | In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill or purchased intangible assets. Assumptions and estimates about expected future cash flows and the fair values of our reporting unit and purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as the adverse impact of unanticipated changes in macroeconomic conditions and technological changes or new product introductions from competitors. They can also be affected by internal factors such as changes in business strategy or in forecasted product life cycles and roadmaps. Our ongoing consideration of these and other factors could result in future impairment charges or accelerated amortization expense, which could adversely affect our operating results. |

[0001564590-18-015820:mdna:63]
Product Warranties

[0001564590-18-015820:mdna:64]
Estimated future hardware and software warranty costs are recorded as a cost of product revenues at the time of product shipment. We assess the adequacy of our warranty accrual each quarter and adjust the amount as considered necessary.

[0001564590-18-015820:mdna:65]
The following are the key estimates and assumptions and corresponding uncertainties for product warranties:

[0001564590-18-015820:mdna:66]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | Estimated future software and hardware warranty costs are based on historical and projected warranty claim rates, product failure rates, historical and projected materials and logistics costs, distribution and labor costs and knowledge of specific product failures that are outside of our typical experience. We also evaluate our estimates to assess the adequacy of our warranty liability considering the size of the installed base of products subject to warranty protection and adjust the estimates as necessary. |  | • | Although we engage in product quality programs and processes, if we experience unexpected quality issues resulting in higher failure rates or experience increases in costs to remediate product failures, additional warranty costs may be incurred. Additionally, for new products our warranty liability is based on limited historical experience. If our projections differ from such limited experience, our warranty costs may increase, which could adversely impact our gross margins. |

[0001564590-18-015820:mdna:67]
Valuation of Investment Securities

[0001564590-18-015820:mdna:68]
Our investments in debt securities are reported at fair value and are subject to periodic impairment review. Unrealized gains and losses related to changes in the fair value of these securities are recognized in accumulated other comprehensive income, net of tax, unless they are determined to be other-than-temporary impairments. The ultimate value realized on these securities is subject to market price volatility until they are sold.

[0001564590-18-015820:mdna:69]
The following are the key estimates and assumptions and corresponding uncertainties for the valuation of our investment securities:

[0001564590-18-015820:mdna:70]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | The estimated fair value of our debt securities, and the associated accounting for unrealized losses is based on an evaluation of current economic and market conditions, the credit rating of the security’s issuer, the length of time and extent the security’s fair value has been below its amortized cost and our ability and intent to hold the security for a period of time sufficient to allow for anticipated recovery in value. If we determine that an investment has an other-than-temporary decline in fair value, we recognize the investment loss in earnings. |  | • | The fair value of our investments in debt securities could decrease significantly from uncertainties in the credit and capital markets, credit rating downgrades and/or solvency of the issuer, decreases in the marketability of the securities. If the fair value of our investments decreases significantly and, if because of changes in our ability and intent to continue to hold the securities or other factors, it is determined to be other-than-temporary, we may incur impairment charges that could adversely affect our results of operations. |

[0001564590-18-015820:mdna:71]
36

[0001564590-18-015820:mdna:72]
Income Taxes

[0001564590-18-015820:mdna:73]
We are subject to income taxes in the United States and numerous foreign jurisdictions. We compute our provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0001564590-18-015820:mdna:74]
The following are the key estimates and assumptions and corresponding uncertainties for our income taxes:

[0001564590-18-015820:mdna:75]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | Our income tax provision is based on existing tax law and advanced pricing agreements or letter rulings we have with various tax authorities. |  | • | Our provision for income taxes is subject to volatility and could be adversely impacted by future changes in existing tax laws, such as a change in tax rate, possible U.S. changes to the taxation of earnings of our foreign subsidiaries, and uncertainties as to future renewals of favorable tax agreements and rulings. |
| • | The determination of whether we should record or adjust a valuation allowance against our deferred tax assets is based on assumptions regarding our future profitability. |  | • | Our future profits could differ from current expectations resulting in a change to our determination as to the amount of deferred tax assets that are more likely than not to be realized. We could adjust our valuation allowance with a corresponding impact to the tax provision in the period in which such determination is made. |
| • | The estimates for our uncertain tax positions are based primarily on company specific circumstances, applicable tax laws, tax opinions from outside firms and past results from examinations of our income tax returns. |  | • | Significant judgment is required in evaluating our uncertain tax positions. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome or tax court rulings of these matters will not be different from that which is reflected in our historical tax provisions and accruals. |

[0001564590-18-015820:mdna:76]
New Accounting Standards

[0001564590-18-015820:mdna:77]
See Note 2 – Recent Accounting Standards Not Yet Effective of the Notes to Consolidated Financial Statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on our financial statements.

[0001564590-18-015820:mdna:78]
37

[0001564590-18-015820:mdna:79]
Results of Operations

[0001564590-18-015820:mdna:80]
Our fiscal year is reported on a 52- or 53-week year that ends on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2018, which ended on April 27, 2018, and fiscal year 2017, which ended on April 28, 2017, were each 52-week years. Fiscal year 2016, which ended on April 29, 2016, was a 53-week year. Unless otherwise stated, references to particular years, quarters, months and periods refer to our fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0001564590-18-015820:mdna:81]
The following table sets forth certain Consolidated Statements of Operations data as a percentage of net revenues for the periods indicated:

[0001564590-18-015820:mdna:82]
|  |  | Fiscal Year |  |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 59 |  | % |  | 54 |  | % |  | 54 |  | % |
| Software maintenance |  |  | 16 |  |  |  | 17 |  |  |  | 17 |  |  |
| Hardware maintenance and other services |  |  | 25 |  |  |  | 28 |  |  |  | 29 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 29 |  |  |  | 29 |  |  |  | 28 |  |  |
| Cost of software maintenance |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 8 |  |  |  | 9 |  |  |  | 10 |  |  |
| Gross profit |  |  | 63 |  |  |  | 61 |  |  |  | 61 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 29 |  |  |  | 30 |  |  |  | 32 |  |  |
| Research and development |  |  | 13 |  |  |  | 14 |  |  |  | 16 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 6 |  |  |
| Restructuring charges |  |  | — |  |  |  | 1 |  |  |  | 2 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Gain on sale of properties |  |  | (4 | ) |  |  | — |  |  |  | (1 | ) |  |
| Total operating expenses |  |  | 44 |  |  |  | 49 |  |  |  | 55 |  |  |
| Income from operations |  |  | 19 |  |  |  | 12 |  |  |  | 6 |  |  |
| Other income (expense), net |  |  | 1 |  |  |  | — |  |  |  | — |  |  |
| Income before income taxes |  |  | 20 |  |  |  | 12 |  |  |  | 6 |  |  |
| Provision for income taxes |  |  | 18 |  |  |  | 3 |  |  |  | 2 |  |  |
| Net income |  |  | 1 |  | % |  | 9 |  | % |  | 4 |  | % |

[0001564590-18-015820:mdna:83]
Percentages may not add due to rounding

[0001564590-18-015820:mdna:84]
Discussion and Analysis of Results of Operations

[0001564590-18-015820:mdna:85]
Overview — Net revenues for fiscal 2018 were $5,911 million, an increase of $392 million, or 7% compared to fiscal 2017, reflecting higher product revenues, partially offset by slightly lower hardware maintenance and other services revenues. Net revenues for fiscal 2017 were $5,519 million, a decrease of $27 million, relatively flat compared to fiscal 2016, reflecting lower hardware maintenance and other services revenues, partially offset by higher product revenues and software maintenance revenues.

[0001564590-18-015820:mdna:86]
Gross profit as a percentage of net revenues for fiscal 2018 increased one percentage point compared to fiscal 2017, reflecting higher margins on product revenues and slightly higher margins on hardware maintenance and other services revenues. Gross profit margins on product revenues in fiscal 2018 increased three and a half percentage points compared to fiscal 2017, primarily due to higher average selling prices (ASPs), and, to a lesser extent, the favorable impact of foreign exchange rate fluctuations. Gross profit as a percentage of net revenues for fiscal 2017 was relatively flat compared to fiscal 2016, reflecting lower margins on product revenues, mostly offset by higher margins on hardware maintenance and other services revenues.

[0001564590-18-015820:mdna:87]
Sales and marketing, research and development, and general and administrative expenses for fiscal 2018 totaled $2,792 million, or 47% of net revenues, representing a decrease of one and a half percentage points compared to fiscal 2017, primarily due to higher net revenues in the current year, coupled with relatively consistent average headcount in both fiscal years. Sales and marketing, research and development, and general and administrative expenses for fiscal 2017 totaled $2,683 million, or 49% of net revenues, representing a decrease of 5 percentage points compared to fiscal 2016, primarily due to a lower average headcount as a result of our restructuring plans as well as other cost reduction initiatives, partially offset by additional operating expenses related to our acquisition of SolidFire, Inc. (SolidFire).

[0001564590-18-015820:mdna:88]
38

[0001564590-18-015820:mdna:89]
Net Revenues (in millions, except percentages):

[0001564590-18-015820:mdna:90]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  |  | 2016 |  |  | % Change |  |
| Net revenues |  |  | $ | 5,911 |  |  | $ | 5,519 |  |  |  | 7 | % |  | $ | 5,546 |  |  |  | — | % |

[0001564590-18-015820:mdna:91]
The increase in net revenues for fiscal 2018 compared to fiscal 2017 was primarily due to an increase of $455 million in product revenues, partially offset by a decrease of $56 million in hardware maintenance and other services revenues, while software maintenance revenues were relatively flat. Product revenues as a percent of net revenues increased four percentage points in fiscal 2018 compared to fiscal 2017.

[0001564590-18-015820:mdna:92]
The decrease in net revenues for fiscal 2017 compared to fiscal 2016 was primarily due to a decrease of $63 million in hardware maintenance and other services revenues, partially offset by an increase of $20 million in product revenues and an increase of $16 million in software maintenance revenues. Product revenues as a percent of net revenues increased one percentage point in fiscal 2017 compared to fiscal 2016.

[0001564590-18-015820:mdna:93]
Sales through our indirect channels represented 79%, 78% and 77% of net revenues in fiscal 2018, 2017 and 2016, respectively.

[0001564590-18-015820:mdna:94]
The following customers, each of which is a distributor, accounted for 10% or more of net revenues:

[0001564590-18-015820:mdna:95]
|  |  | Fiscal Year |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Arrow Electronics, Inc. |  |  | 23 | % |  |  | 22 | % |  |  | 22 | % |
| Tech Data Corporation (previously presented as Avnet, Inc.) |  |  | 19 | % |  |  | 20 | % |  |  | 19 | % |

[0001564590-18-015820:mdna:96]
Product Revenues (in millions, except percentages):

[0001564590-18-015820:mdna:97]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  |  | 2016 |  |  | % Change |  |
| Product revenues |  |  | $ | 3,461 |  |  | $ | 3,006 |  |  |  | 15 | % |  | $ | 2,986 |  |  |  | 1 | % |

[0001564590-18-015820:mdna:98]
Product revenues are derived through the sale of our strategic and mature solutions, and consist of sales of configured systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, original equipment manufacturer (OEM) products and add-on hardware and software.

[0001564590-18-015820:mdna:99]
Product revenues from strategic solutions represented 71% of product revenues in fiscal 2018, compared to 66% in fiscal 2017. Product revenues from mature solutions represented 29% of product revenues in fiscal 2018, compared to 34% in fiscal 2017.

[0001564590-18-015820:mdna:100]
Total product revenues from strategic solutions totaled $2,449 million in fiscal 2018, reflecting a 24% increase from $1,971 million in fiscal 2017. This increase was primarily due to a 4% increase in unit volume of Clustered ONTAP systems and an increase in ASP driven by sales of our All-Flash FAS products. Total product revenue from mature solutions totaled $1,012 million in fiscal 2018, reflecting a 2% decrease from $1,035 million in fiscal 2017, primarily due to a 73% decrease in unit volume of 7-mode systems and a 13% decrease in OEM revenues, partially offset by a 13% increase in add-on hardware, storage and related OS revenues. These fluctuations reflect our planned transition of our product offerings and the adoption by our customers of our newer all-flash and hybrid-cloud compatible products.

[0001564590-18-015820:mdna:101]
Total product revenues from strategic solutions totaled $1,971 million in fiscal 2017, reflecting a 17% increase from $1,682 million in fiscal 2016. This increase was primarily due to a 15% increase in unit volume of Clustered ONTAP systems, partially offset by a decrease in ASP reflecting higher discounting and promotional programs. Total product revenue from mature solutions totaled $1,035 million in fiscal 2017, reflecting a 21% decrease from $1,304 million in fiscal 2016, primarily due to a 57% decrease in unit volume of 7-mode systems, as well as a decrease in ASP. In addition, add-on hardware, storage and related OS revenues decreased 11%, while OEM revenues increased 4%.

[0001564590-18-015820:mdna:102]
Our systems are highly configurable to respond to customer requirements in the open systems storage markets that we serve. This can cause a wide variation in product configurations that can significantly impact revenues, cost of revenues and gross profits. Pricing changes, discounting practices, product competition, foreign currency, unit volumes, customer mix, natural disasters and product materials costs can also impact revenues, cost of revenues and/or gross profits. Disk drive and flash storage materials are a significant component of our storage systems. While our sales price per terabyte historically declines over time, improved system performance, increased capacity and software to manage this increased capacity have an offsetting favorable impact on product revenues.

[0001564590-18-015820:mdna:103]
Software Maintenance Revenues (in millions, except percentages):

[0001564590-18-015820:mdna:104]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  |  | 2016 |  |  | % Change |  |
| Software maintenance revenues |  |  | $ | 958 |  |  | $ | 965 |  |  |  | (1 | )% |  | $ | 949 |  |  |  | 2 | % |

[0001564590-18-015820:mdna:105]
Software maintenance revenues are associated with contracts which entitle customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, bug fixes and patch releases, as well as internet and telephone access to technical support personnel located in our global support centers.

[0001564590-18-015820:mdna:106]
The fluctuations in software maintenance revenues reflect fluctuations in the aggregate contract value of the installed base under software maintenance contracts, which is recognized as revenue ratably over the terms of the underlying contracts. Software maintenance revenues in fiscal 2016 were also favorably impacted by the additional week of deferred revenue amortization in the first quarter of that year.

[0001564590-18-015820:mdna:107]
Hardware Maintenance and Other Services Revenues (in millions, except percentages):

[0001564590-18-015820:mdna:108]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  |  | 2016 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  |  | $ | 1,492 |  |  | $ | 1,548 |  |  |  | (4 | )% |  | $ | 1,611 |  |  |  | (4 | )% |

[0001564590-18-015820:mdna:109]
Hardware maintenance and other services revenues include hardware maintenance, professional services and educational and training services revenues.

[0001564590-18-015820:mdna:110]
Hardware maintenance contract revenues were $1,213 million, $1,265 million and $1,316 million in fiscal 2018, 2017 and 2016, respectively, reflecting a year over year decrease of 4% in each of fiscal 2018 and fiscal 2017. These decreases were primarily attributable to a decline in ASP on contracts executed during those years. Lower contract renewal rates also contributed to the decrease in fiscal 2018.

[0001564590-18-015820:mdna:111]
Professional services and educational and training services revenues were $279 million, $283 million and $295 million in fiscal 2018, 2017 and 2016, respectively.

[0001564590-18-015820:mdna:112]
Revenues by Geographic Area:

[0001564590-18-015820:mdna:113]
|  |  | Fiscal Year |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| United States, Canada and Latin America (Americas) |  |  | 54 | % |  |  | 56 | % |  |  | 55 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 32 | % |  |  | 31 | % |  |  | 32 | % |
| Asia Pacific (APAC) |  |  | 14 | % |  |  | 13 | % |  |  | 13 | % |

[0001564590-18-015820:mdna:114]
Percentages may not add due to rounding

[0001564590-18-015820:mdna:115]
Americas revenues consist of sales to Americas commercial and United States (U.S.) public sector markets. During fiscal 2018 revenues increased in all geographic areas, with the largest percentage increases seen in EMEA and APAC. The increases in these geographic areas reflect higher product revenues and, to a lesser extent, the favorable impact of foreign exchange rate fluctuations. Revenues in fiscal 2017 were relatively flat compared to fiscal 2016 across all geographical areas. During fiscal 2016, we experienced declining revenues in all geographic areas, with the largest percentage decline in the Americas U.S. public sector market.

[0001564590-18-015820:mdna:116]
Cost of Revenues

[0001564590-18-015820:mdna:117]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping our storage products, amortization of purchased intangible assets, inventory write-downs, and warranty costs, (2) cost of software maintenance, which includes the costs of providing software maintenance and third-party royalty costs and (3) cost of hardware maintenance and other services revenues, which includes costs associated with providing support activities for hardware maintenance, global support partnership programs, professional services and educational and training services.

[0001564590-18-015820:mdna:118]
Cost of Product Revenues (in millions, except percentages):

[0001564590-18-015820:mdna:119]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  |  | 2016 |  |  | % Change |  |
| Cost of product revenues |  |  | $ | 1,738 |  |  | $ | 1,614 |  |  |  | 8 | % |  | $ | 1,558 |  |  |  | 4 | % |

[0001564590-18-015820:mdna:120]
The changes in cost of product revenues consisted of the following (in percentage points of the total change):

[0001564590-18-015820:mdna:121]
|  |  | Fiscal 2018 to Fiscal 2017 |  |  | Fiscal 2017 to Fiscal 2016 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | 7 |  |  |  | 9 |  |
| Warranty |  |  | — |  |  |  | (1 | ) |
| Amortization of purchased intangible assets |  |  | — |  |  |  | (2 | ) |
| Other |  |  | 1 |  |  |  | (2 | ) |
| Total change |  |  | 8 |  |  |  | 4 |  |

[0001564590-18-015820:mdna:122]
Cost of product revenues represented 50%, 54% and 52% of product revenues for fiscal 2018, 2017 and 2016, respectively. Materials cost represented 91%, 91% and 85% of product costs for fiscal 2018, 2017 and 2016, respectively.

[0001564590-18-015820:mdna:123]
Materials costs increased $107 million in fiscal 2018 compared to fiscal 2017, reflecting a 14% increase in materials costs related to strategic products, primarily due to higher unit volume of Clustered ONTAP systems.

[0001564590-18-015820:mdna:124]
An increase in ASP for strategic systems resulted in higher margins for strategic products in fiscal 2018 compared to the prior year. Margins in fiscal 2018 also benefitted from the favorable impact of foreign exchange rate fluctuations. Margins for mature products were relatively consistent in fiscal 2018 compared to the prior year.

[0001564590-18-015820:mdna:125]
Materials costs increased $143 million in fiscal 2017 compared to fiscal 2016, reflecting a 32% increase in materials costs related to strategic products, primarily due to higher unit volume of Clustered ONTAP systems.

[0001564590-18-015820:mdna:126]
A decrease in ASP for strategic systems combined with the increase in unit materials costs resulted in lower gross margins for strategic products in fiscal 2017 compared to the prior year. Average unit materials costs for mature products were relatively flat compared to the prior year, which when combined with a decrease in ASP resulted in lower gross margins for mature products.

[0001564590-18-015820:mdna:127]
Cost of product revenues in fiscal 2017 compared to fiscal 2016 were also favorably impacted by an $18 million decrease in warranty expense, reflecting our product quality and cost reduction efforts, and a decrease of $31 million in the amortization of intangibles due to the impact of certain acquired developed technologies being fully amortized by the end of fiscal 2016, partially offset by amortization related to the SolidFire acquisition.

[0001564590-18-015820:mdna:128]
Cost of Software Maintenance Revenues (in millions, except percentages):

[0001564590-18-015820:mdna:129]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  |  | 2016 |  |  | % Change |  |
| Cost of software maintenance revenues |  |  | $ | 25 |  |  | $ | 28 |  |  |  | (11 | )% |  | $ | 37 |  |  |  | (24 | )% |

[0001564590-18-015820:mdna:130]
Cost of software maintenance revenues decreased in fiscal 2018 compared to fiscal 2017, and in fiscal 2017 compared to fiscal 2016. Cost of software maintenance revenues represented 3%, 3% and 4% of software maintenance revenues for fiscal 2018, 2017 and 2016, respectively.

[0001564590-18-015820:mdna:131]
Cost of Hardware Maintenance and Other Services Revenues (in millions, except percentages):

[0001564590-18-015820:mdna:132]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  |  | 2016 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  |  | $ | 449 |  |  | $ | 487 |  |  |  | (8 | )% |  | $ | 578 |  |  |  | (16 | )% |

[0001564590-18-015820:mdna:133]
Cost of hardware maintenance and other services revenues decreased $38 million, or 8%, in fiscal 2018 compared to fiscal 2017 and decreased $91 million, or 16%, in fiscal 2017 compared to fiscal 2016. Costs represented 30%, 31% and 36% of hardware maintenance and other services revenues for fiscal 2018, 2017 and 2016, respectively.

[0001564590-18-015820:mdna:134]
41

[0001564590-18-015820:mdna:135]
Operating Expenses

[0001564590-18-015820:mdna:136]
Sales and Marketing, Research and Development and General and Administrative Expenses

[0001564590-18-015820:mdna:137]
Compensation costs represent the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0001564590-18-015820:mdna:138]
Total compensation costs included in operating expenses increased $21 million, or 1% during fiscal 2018 compared to fiscal 2017, primarily due to higher incentive compensation expense, reflecting stronger operating performance against goals, and higher salary expense, reflecting merit increases and the unfavorable impact of foreign exchange rate fluctuations. These increases were partially offset by lower stock-based compensation expense. Average headcount was relatively consistent in both fiscal years.

[0001564590-18-015820:mdna:139]
Total compensation costs included in operating expenses decreased $149 million, or 9% during fiscal 2017 compared to fiscal 2016, primarily due to lower salary and stock-based compensation expenses, reflecting a 13% decrease in average headcount as a result of cost reduction initiatives, partially offset by higher incentive compensation expense, reflecting stronger operating performance against goals.

[0001564590-18-015820:mdna:140]
Sales and Marketing (in millions, except percentages):

[0001564590-18-015820:mdna:141]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  |  | 2016 |  |  | % Change |  |
| Sales and marketing expenses |  |  | $ | 1,729 |  |  | $ | 1,633 |  |  |  | 6 | % |  | $ | 1,792 |  |  |  | (9 | )% |

[0001564590-18-015820:mdna:142]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, allocated facilities and IT support costs, advertising and marketing promotional expense and travel and entertainment expense. The changes in sales and marketing expenses consisted of the following:

[0001564590-18-015820:mdna:143]
|  |  | Fiscal 2018 to Fiscal 2017 |  |  | Fiscal 2017 to Fiscal 2016 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 1 |  |  |  | (4 | ) |
| Commissions |  |  | 4 |  |  |  | — |  |
| Facilities and IT support costs |  |  | — |  |  |  | (3 | ) |
| Other |  |  | 1 |  |  |  | (2 | ) |
| Total change |  |  | 6 |  |  |  | (9 | ) |

[0001564590-18-015820:mdna:144]
The increase in compensation costs in fiscal 2018 reflects higher average salaries due to merit increases and the unfavorable impact of foreign exchange rate fluctuations, partially offset by a slight reduction in average headcount. The increase in commissions expense is due to higher performance against sales goals.

[0001564590-18-015820:mdna:145]
The decrease in compensation costs during fiscal 2017 reflects a 10% decrease in average headcount from the prior year. Facilities and IT support costs decreased during fiscal 2017 primarily due to cost containment efforts.

[0001564590-18-015820:mdna:146]
Research and Development (in millions, except percentages):

[0001564590-18-015820:mdna:147]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  |  | 2016 |  |  | % Change |  |
| Research and development expenses |  |  | $ | 783 |  |  | $ | 779 |  |  |  | 1 | % |  | $ | 861 |  |  |  | (10 | )% |

[0001564590-18-015820:mdna:148]
Research and development expenses consist primarily of compensation costs, allocated facilities and IT support costs, depreciation, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs. Changes in research and development expense consisted of the following:

[0001564590-18-015820:mdna:149]
|  |  | Fiscal 2018 to Fiscal 2017 |  |  | Fiscal 2017 to Fiscal 2016 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 1 |  |  |  | (7 | ) |
| Development projects and outside services |  |  | 1 |  |  |  | — |  |
| Depreciation |  |  | (1 | ) |  |  | (1 | ) |
| Facilities and IT support costs |  |  | (1 | ) |  |  | (1 | ) |
| Other |  |  | 1 |  |  |  | (1 | ) |
| Total change |  |  | 1 |  |  |  | (10 | ) |

[0001564590-18-015820:mdna:150]
The increase in compensation costs for fiscal 2018 reflects higher incentive compensation expense, partially offset by lower stock-based compensation expense. Development projects and outside services expense increased as a result of higher spending on materials and services associated with engineering activities to develop new products and enhance existing products.

[0001564590-18-015820:mdna:151]
Depreciation expense was favorably impacted in each of fiscal 2018 and fiscal 2017 by certain equipment becoming fully depreciated, and facilities and IT support costs decreased primarily due to cost containment efforts.

[0001564590-18-015820:mdna:152]
Compensation costs for fiscal 2017 were favorably impacted by lower salary and stock-based compensation expenses due to a decrease of 18% in average headcount, but were unfavorably impacted by higher incentive compensation expense.

[0001564590-18-015820:mdna:153]
General and Administrative (in millions, except percentages):

[0001564590-18-015820:mdna:154]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  |  | 2016 |  |  | % Change |  |
| General and administrative expenses |  |  | $ | 280 |  |  | $ | 271 |  |  |  | 3 | % |  | $ | 307 |  |  |  | (12 | )% |

[0001564590-18-015820:mdna:155]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and allocated facilities and IT support costs. Changes in general and administrative expense consisted of the following:

[0001564590-18-015820:mdna:156]
|  |  | Fiscal 2018 to Fiscal 2017 |  |  | Fiscal 2017 to Fiscal 2016 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (4 | ) |  |  | (4 | ) |
| Professional and legal fees and outside services |  |  | 6 |  |  |  | (8 | ) |
| Facilities and IT support costs |  |  | 2 |  |  |  | 2 |  |
| Other |  |  | (1 | ) |  |  | (2 | ) |
| Total change |  |  | 3 |  |  |  | (12 | ) |

[0001564590-18-015820:mdna:157]
The decrease in compensation costs for fiscal 2018 reflects lower salary, benefits and stock-based compensation expenses due to an 8% decrease in average headcount, partially offset by higher incentive compensation expense. The increase in professional and legal fees and outside services expense in fiscal 2018 was primarily due to higher spending levels on projects and outside services, while the increase in facilities and IT support costs was primarily due to an increase in spending on IT projects.

[0001564590-18-015820:mdna:158]
Compensation costs for fiscal 2017 were favorably impacted by lower salary and stock-based compensation expenses due to a decrease of 11% in average headcount, but were unfavorably impacted by higher incentive compensation expense. The decrease in professional and legal fees and outside services expense in fiscal 2017 was primarily due to lower spending levels on consulting fees and projects. Facilities and IT support costs increased during fiscal 2017 primarily due to an increase in spending on IT projects.

[0001564590-18-015820:mdna:159]
Restructuring Charges (in millions, except percentages):

[0001564590-18-015820:mdna:160]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  |  | 2016 |  |  | % Change |  |
| Restructuring charges |  |  | $ | — |  |  | $ | 52 |  |  |  | (100 | )% |  | $ | 108 |  |  |  | (52 | )% |

[0001564590-18-015820:mdna:161]
In response to changes in market conditions and market demand for our products, in fiscal years 2017 and 2016, we initiated a number of business realignment plans designed to streamline our business, reduce our cost structure and focus our resources on key strategic opportunities, resulting in aggregate reductions of our global workforce of approximately 6% and 14% in fiscal 2017 and 2016, respectively, for which we recognized aggregate charges of $52 million and $108 million, consisting primarily of employee severance costs. See Note 13 – Restructuring Charges of the Notes to Consolidated Financial Statements for more details regarding our restructuring plans.

[0001564590-18-015820:mdna:162]
Acquisition-related Expense (in millions, except percentages):

[0001564590-18-015820:mdna:163]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  | 2016 |  |  | % Change |  |
| Acquisition-related expense |  |  | $ | — |  |  | $ | — |  |  | NM |  | $ | 8 |  |  |  | (100 | )% |

[0001564590-18-015820:mdna:164]
NM - Not Meaningful

[0001564590-18-015820:mdna:165]
During fiscal 2016, we incurred $8 million of acquisition costs, primarily related to legal and consulting fees, employee severance costs, and asset impairments associated with our acquisition of SolidFire.

[0001564590-18-015820:mdna:166]
Gain on Sale of Properties (in millions, except percentages):

[0001564590-18-015820:mdna:167]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  | 2016 |  |  | % Change |  |
| Gain on sale of properties |  |  | $ | (218 | ) |  | $ | (10 | ) |  | NM |  | $ | (51 | ) |  |  | (80 | )% |

[0001564590-18-015820:mdna:168]
NM - Not Meaningful

[0001564590-18-015820:mdna:169]
On September 8, 2017, we entered into an agreement to sell certain properties previously classified as assets held-for-sale for a total of $306 million, through two separate and independent closings. On December 7, 2017, the date of the first closing, we consummated the sale of properties with a net book value of $66 million, for cash proceeds of $210 million, resulting in a gain, net of direct selling costs, of $142 million.

[0001564590-18-015820:mdna:170]
During fiscal 2018, our continuing involvement with properties subject to a sale-leaseback arrangement entered into in fiscal 2016 ended, and as a result we recorded a non-cash sale of properties, extinguished the associated financing obligation and recognized a gain of $76 million.

[0001564590-18-015820:mdna:171]
In fiscal 2017, our continuing involvement with certain properties subject to a sale-leaseback arrangement entered into in fiscal 2016 ended, and as a result we recorded a non-cash sale of properties, extinguished the associated financing obligation and recognized a gain of $10 million.

[0001564590-18-015820:mdna:172]
In fiscal 2016, we sold certain properties, which had a net book value of $51 million and related sales proceeds of $102 million, resulting in a gain of $51 million.

[0001564590-18-015820:mdna:173]
Other Income (Expense), Net (in millions, except percentages)

[0001564590-18-015820:mdna:174]
The components of other income (expense), net were as follows:

[0001564590-18-015820:mdna:175]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  |  | 2016 |  |  | % Change |  |
| Interest income |  |  | $ | 79 |  |  | $ | 44 |  |  |  | 80 | % |  | $ | 46 |  |  |  | (4 | )% |
| Interest expense |  |  |  | (62 | ) |  |  | (52 | ) |  |  | 19 | % |  |  | (49 | ) |  |  | 6 | % |
| Other income, net |  |  |  | 24 |  |  |  | 8 |  |  |  | 200 | % |  |  | — |  |  | NM |  |
| Total |  |  | $ | 41 |  |  | $ | — |  |  | NM |  |  | $ | (3 | ) |  |  | (100 | )% |

[0001564590-18-015820:mdna:176]
NM - Not Meaningful

[0001564590-18-015820:mdna:177]
Interest income increased during fiscal 2018 compared to fiscal 2017, primarily due to a shift in our investment portfolio to higher-yielding investments. Interest income decreased slightly during fiscal 2017 compared to fiscal 2016, primarily due to a decrease in the size of our investment portfolio.

[0001564590-18-015820:mdna:178]
Interest expense increased in fiscal years 2018 and 2017 primarily as a result of our commercial paper program, which began in the third quarter of fiscal 2017, and the September 2017 issuance of $800 million aggregate principal amount of Senior Notes which have a higher weighted average interest rate than the $750 million aggregate principal amount of Senior Notes extinguished in November 2017.

[0001564590-18-015820:mdna:179]
44

[0001564590-18-015820:mdna:180]
Other income, net increased during fiscal 2018 compared to fiscal 2017 primarily due to higher net foreign exchange gains.

[0001564590-18-015820:mdna:181]
Provision for Income Taxes (in millions, except percentages):

[0001564590-18-015820:mdna:182]
|  |  |  | Fiscal Year |  |
|  |  |  | 2018 |  |  | 2017 |  |  | % Change |  |  | 2016 |  |  | % Change |  |
| Provision for income taxes |  |  | $ | 1,090 |  |  | $ | 156 |  |  |  | 599 | % |  | $ | 116 |  |  |  | 34 | % |

[0001564590-18-015820:mdna:183]
Our effective tax rate for fiscal 2018 was 93.5% compared to an effective tax rate of 23.5% for fiscal 2017, and an effective tax rate of 33.6% for fiscal 2016. Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations which are headquartered in the Netherlands, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rate for fiscal 2018 was substantially higher compared to the prior years primarily due to the provisional effects of the TCJA enacted on December 22, 2017.

[0001564590-18-015820:mdna:184]
Key components of the effective tax rate of 93.5% in fiscal 2018 included a one-time transition tax charge on accumulated foreign earnings of approximately $732 million, or 62.8 percentage points, a charge of $126 million, or 10.8 percentage points, related to the remeasurement of deferred tax assets and liabilities due to tax rate changes, offset by a benefit of $108 million, or 9.3 percentage points, from foreign profits taxed at effective tax rates lower than our blended U.S. federal statutory rate of 30.5%, and a tax benefit of $23 million, or 2.0 percentage points, attributable to stock-based compensation.

[0001564590-18-015820:mdna:185]
Key components of the effective tax rate of 23.5% in fiscal 2017 included a benefit of $100 million, or 15.0 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 35%, and a tax charge of $16 million, or 2.4 percentage points, attributable to stock-based compensation.

[0001564590-18-015820:mdna:186]
Key components of the effective tax rate of 33.6% in fiscal 2016 included a benefit of $81 million, or 23.5 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 35%, a charge of $64 million, or 18.6 percentage points, related to the integration of SolidFire intellectual property into our tax structure, a tax charge of $20 million, or 5.8 percentage points, in connection with the settlement of income tax audits, and a benefit of $14 million, or 4.1 percentage points, related to research and development credits.

[0001564590-18-015820:mdna:187]
On December 22, 2017, the TCJA was enacted into law. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate, the imposition of a one-time transition tax on deferred foreign earnings, and a shift to a modified territorial tax regime. Given the timing and pace of regulatory guidance, the Securities and Exchange Commission issued Staff Accounting Bulletin (SAB) 118, which allows for the recording of provisional amounts related to U.S. tax reform and subsequent related adjustments during a measurement period.

[0001564590-18-015820:mdna:188]
As of April 27, 2018, we have not fully completed the accounting for the tax impacts of the TCJA and, in connection with SAB 118, have recorded provisional tax charges based on reasonable estimates for the remeasurement of deferred tax assets and liabilities based on the new corporate rate and for the transition tax on our total post-1986 foreign earnings and profits (E&P). The TCJA also includes provisions for a global minimum tax on intangible low-taxed income (GMT) of foreign subsidiaries, a base erosion anti-abuse tax on certain intercompany payments, and beneficial tax treatment for foreign derived intangible income. These provisions will be effective for us beginning in our fiscal 2019. We will continue to refine provisional balances and make adjustments during the measurement period based on the issuance of further regulatory guidance, changes in interpretations, and the collection and analysis of additional information; these adjustments could be material to our financial statements. The provisional amounts recorded during the current year are explained below.

[0001564590-18-015820:mdna:189]
The TJCA decreased the U.S. federal corporate tax rate from 35% to 21% as of January 1, 2018. For fiscal 2018, this decrease results in a blended statutory tax rate of 30.5%. As a result of the tax rate change, we remeasured our deferred tax assets and liabilities based on the rates at which they are expected to reverse in future periods. We recorded a $126 million tax expense for fiscal 2018 related to all tax rate changes. The final remeasurement impact could vary from the provisional amount if actual future activities impacting deferred tax balances differ from our estimates.

[0001564590-18-015820:mdna:190]
The TCJA imposes a mandatory, one-time transition tax on accumulated foreign E&P not previously subject to U.S. income tax at a rate of 15.5% on earnings to the extent of foreign cash and other liquid assets, and 8% on the remaining earnings. For fiscal 2018, we recorded $732 million of tax expense for the estimated U.S. federal and state income tax impacts of the transition tax. Our estimates may change with further guidance from U.S. federal and state tax authorities or other regulatory bodies and additional analyses that we expect to complete during the measurement period with respect to various components of the computations. We intend to make the election to pay the one-time transition tax over a period of eight years.

[0001564590-18-015820:mdna:191]
45

[0001564590-18-015820:mdna:192]
Under the TCJA, the GMT provision taxes foreign income in excess of a deemed return on tangible assets of foreign corporations. Under U.S. GAAP, companies are allowed to make an accounting policy election to either (i) account for GMT as a component of tax expense in the period in which a company is subject to the rules (the period cost method), or (ii) account for GMT in a company’s measurement of deferred taxes (the deferred method). Because of the complexity of the new tax rules, we are continuing to evaluate this provision and the application of ASC 740 and have not yet made an accounting policy election.

[0001564590-18-015820:mdna:193]
During fiscal 2017, we adopted a new accounting standard that simplifies stock-based compensation income tax accounting and presentation within the financial statements and recorded a charge of $18 million following the post-adoption rules which require that all excess tax benefits and deficiencies from stock-based compensation be recognized as a component of income tax expense.

[0001564590-18-015820:mdna:194]
We are currently undergoing various income tax audits in the U.S. and several foreign tax jurisdictions. Transfer pricing calculations are key issues under these audits and are often subject to dispute and appeals.

[0001564590-18-015820:mdna:195]
In October 2015, the Internal Revenue Service (IRS) completed the examination of our fiscal 2008 to 2010 income tax returns and made certain agreed-to transfer pricing adjustments. During fiscal 2016, we recorded charges totaling $23 million attributable to the audit settlements and the related re-measurement of uncertain tax positions for tax years subject to future audits. The IRS commenced the examination of our federal tax returns for our fiscal years 2012 and 2013 in August 2016. In addition, we are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal 2001, in that we have carryforward attributes from these years that could be subject to adjustment in the tax years of utilization.

[0001564590-18-015820:mdna:196]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for such withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012. In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). Parties were heard before the court in October 2017. During March 2018, the Advocate General issued an opinion which was largely in favor of NetApp, however, the CJEU is not bound by the opinion of the Advocate General. It is expected that the preliminary ruling will be issued during our fiscal year 2019. Once a ruling has been issued by the CJEU, it will be reviewed and may be subjected to additional briefing by the DHC. Once complete, the DHC will then issue its final decision.  We expect this decision to be complete sometime during our fiscal year 2019 or 2020.

[0001564590-18-015820:mdna:197]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. As a result of uncertainties regarding tax audits and their possible outcomes, an estimate of the range of possible impacts to unrecognized tax benefits in the next twelve months cannot be made at this time.

[0001564590-18-015820:mdna:198]
Liquidity, Capital Resources and Cash Requirements

[0001564590-18-015820:mdna:199]
| (In millions, except percentages) |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Cash, cash equivalents and short-term investments |  | $ | 5,391 |  |  | $ | 4,921 |  |
| Principal amount of debt |  | $ | 1,935 |  |  | $ | 2,000 |  |
| Debt as a percentage of stockholders' equity |  |  | 94 | % |  |  | 72 | % |

[0001564590-18-015820:mdna:200]
The following is a summary of our cash flow activities:

[0001564590-18-015820:mdna:201]
|  |  | Fiscal Year |  |
| (In millions) |  | 2018 |  |  | 2017 |  |
| Net cash provided by operating activities |  | $ | 1,478 |  |  | $ | 986 |  |
| Net cash used in investing activities |  |  | (21 | ) |  |  | (220 | ) |
| Net cash used in financing activities |  |  | (986 | ) |  |  | (1,179 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 26 |  |  |  | (11 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 497 |  |  | $ | (424 | ) |

[0001564590-18-015820:mdna:202]
46

[0001564590-18-015820:mdna:203]
As of April 27, 2018, our cash, cash equivalents and short-term investments totaled $5.4 billion, reflecting an increase of $0.5 billion from April 28, 2017. The increase was primarily due to $1.5 billion of cash provided by operating activities, $795 million of net proceeds from the issuance of long-term debt, and $210 million in proceeds from the sale of properties, partially offset by $750 million paid to redeem our Senior Notes due in December 2017, $794 million in cash paid for the repurchase of our common stock,  $214 million in cash used for the payment of dividends, $145 million in purchases of property of equipment, and $115 million used for the net repayment of commercial paper notes. Working capital increased by $1.2 billion to $3.2 billion as of April 27, 2018 primarily due to an increase in cash and cash equivalents, as discussed above, and the fiscal 2018 redemption of our Senior Notes due December 2017 using net proceeds from the issuance of long-term debt.

[0001564590-18-015820:mdna:204]
Cash Conversion Cycle

[0001564590-18-015820:mdna:205]
The following table presents the components of our cash conversion cycle for the fourth quarter of each of the past three fiscal years:

[0001564590-18-015820:mdna:206]
|  |  | Three Months Ended |  |
| (In days) |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Days sales outstanding (1) |  |  | 56 |  |  |  | 45 |  |  |  | 54 |  |
| Days inventory outstanding (2) |  |  | 19 |  |  |  | 26 |  |  |  | 16 |  |
| Days payables outstanding (3) |  |  | (90 | ) |  |  | (56 | ) |  |  | (41 | ) |
| Cash conversion cycle (4) |  |  | (15 | ) |  |  | 15 |  |  |  | 28 |  |

[0001564590-18-015820:mdna:207]
Days may not add due to rounding

[0001564590-18-015820:mdna:208]
| (1) | Days sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on ending accounts receivable and net revenue for each period. DSO is calculated by dividing accounts receivable by average net revenue per day for the current quarter (91 days for each of the fourth quarters presented above). The increase in DSO in the fourth quarter of fiscal 2018 compared to the corresponding period of fiscal 2017 was due to less favorable shipping linearity in the current quarter, while the decrease in the fourth quarter of fiscal 2017 compared to the corresponding period of fiscal 2016 was due to more favorable shipping linearity in the fiscal 2017 period. |

[0001564590-18-015820:mdna:209]
| (2) | Days inventory outstanding, referred to as DIO, measures the average number of days from procurement to sale of our products. DIO is based on ending inventory and cost of revenues for each period. DIO is calculated by dividing ending inventory by average cost of revenues per day for the current quarter. The decrease in DIO in the fourth quarter of fiscal 2018 compared to the corresponding period of fiscal 2017 was primarily due to strong product sales towards the end of current quarter. Compared to the corresponding period in fiscal 2016, the increase in DIO in the fourth quarter of fiscal 2017 was due primarily to the timing of inventory purchases, and to a lesser extent, the higher cost of flash compared to disk storage. |

[0001564590-18-015820:mdna:210]
| (3) | Days payables outstanding, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and cost of revenues for each period. DPO is calculated by dividing accounts payable by average cost of revenues per day for the current quarter. The year over year increases in DPO in each of the fourth quarters of fiscal 2018 and fiscal 2017 were primarily the result of improved vendor payables management and extensions of payment terms with our suppliers. |

[0001564590-18-015820:mdna:211]
| (4) | The cash conversion cycle is the sum of DSO and DIO less DPO. Items which may cause the cash conversion cycle in a particular period to differ include, but are not limited to, changes in business mix, changes in payment terms (including extended payment terms from suppliers), shipment linearity, seasonal trends and the timing of revenue recognition and inventory purchases within the period. |

[0001564590-18-015820:mdna:212]
Cash Flows from Operating Activities

[0001564590-18-015820:mdna:213]
During fiscal 2018, we generated cash from operating activities of $1.5 billion, reflecting net income of $76 million, adjusted by non-cash depreciation and amortization of $198 million, stock-based compensation of $161 million, a deferred income tax provision of $277 million, and a gain on sale of properties of $218 million.

[0001564590-18-015820:mdna:214]
Changes in assets and liabilities during fiscal 2018 included the following:

[0001564590-18-015820:mdna:215]
|  | • | Accounts receivable increased $272 million, reflecting higher DSO. |

[0001564590-18-015820:mdna:216]
|  | • | Accounts payable increased $262 million, reflecting higher DPO. |

[0001564590-18-015820:mdna:217]
|  | • | Long-term taxes payable increased $714 million, primarily due to a one-time transition tax liability recorded as a result of the impact of U.S. tax reform, which will be paid over a period of eight years. |

[0001564590-18-015820:mdna:218]
During fiscal 2017, we generated cash from operating activities of $986 million, reflecting net income of $509 million, adjusted by non-cash depreciation and amortization of $226 million, stock-based compensation of $195 million and a deferred income tax provision of $90 million.

[0001564590-18-015820:mdna:219]
Changes in assets and liabilities during fiscal 2017 included the following:

[0001564590-18-015820:mdna:220]
|  | • | Accounts receivable decreased $81 million, reflecting lower DSO. |

[0001564590-18-015820:mdna:221]
|  | • | Inventories increased $65 million, reflecting higher DIO. |

[0001564590-18-015820:mdna:222]
|  | • | Accounts payable increased $94 million, reflecting higher DPO. |

[0001564590-18-015820:mdna:223]
|  | • | Accrued expenses decreased $86 million primarily due to the payment of restructuring obligations. |

[0001564590-18-015820:mdna:224]
We expect that cash provided by operating activities may materially fluctuate in future periods due to a number of factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, vendor payment initiatives, tax benefits or charges from stock-based compensation, and the timing and amount of compensation and other payments.

[0001564590-18-015820:mdna:225]
Cash Flows from Investing Activities

[0001564590-18-015820:mdna:226]
During fiscal 2018, we used $10 million for the purchases of investments, net of maturities and sales, and paid $145 million for capital expenditures. Additionally, we paid $75 million to acquire two privately-held companies, and received proceeds of $210 million from the sale of properties.

[0001564590-18-015820:mdna:227]
During fiscal 2017, we used $43 million for the purchase of investments, net of maturities and sales, and paid $175 million for capital expenditures.

[0001564590-18-015820:mdna:228]
Cash Flows from Financing Activities

[0001564590-18-015820:mdna:229]
During fiscal 2018, we used $750 million to redeem our Senior Notes due in December 2017, $115 million for the repayment of our commercial paper notes, net of issuances, $794 million for the repurchase of 15 million shares of our common stock, $214 million for the payment of dividends, and generated $795 million in cash from the issuance of long-term debt.

[0001564590-18-015820:mdna:230]
During fiscal 2017, we used $850 million to repay our short-term loan related to the SolidFire acquisition, $705 million for the repurchase of 22 million shares of our common stock, $208 million for the payment of dividends, and generated $499 million in cash from issuances of commercial paper notes, net of repayments.

[0001564590-18-015820:mdna:231]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies, and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including potential future issuances of debt, equity or other securities, will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all.

[0001564590-18-015820:mdna:232]
Liquidity

[0001564590-18-015820:mdna:233]
Our principal sources of liquidity as of April 27, 2018 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001564590-18-015820:mdna:234]
Cash, cash equivalents and short-term investments consisted of the following (in millions):

[0001564590-18-015820:mdna:235]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Cash and cash equivalents |  | $ | 2,941 |  |  | $ | 2,444 |  |
| Short-term investments |  |  | 2,450 |  |  |  | 2,477 |  |
| Total |  | $ | 5,391 |  |  | $ | 4,921 |  |

[0001564590-18-015820:mdna:236]
As of April 27, 2018 and April 28, 2017, $4.5 billion of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.9 billion and $0.4 billion, respectively, were available in the U.S. The TCJA imposes a one-time transition tax on substantially all accumulated foreign earnings through December 31, 2017 which resulted in $732 million of tax expense in fiscal 2018, and generally allows companies to make distributions of foreign earnings without incurring additional federal taxes. As a part of the provisional estimates recorded during the year, we considered the impacts of the TCJA in relation to our projected global cash requirements and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested. For further information, see Note 14 – Income Taxes.

[0001564590-18-015820:mdna:237]
Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, and invest in critical or complementary technologies, service interest and principal payments on our debt, fund our stock repurchase program, and pay dividends, as and if declared.

[0001564590-18-015820:mdna:238]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of April 27, 2018.

[0001564590-18-015820:mdna:239]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, and other liquidity requirements associated with our operations. We also have an automatic shelf registration statement on file with the Securities and Exchange Commission. We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001564590-18-015820:mdna:240]
Senior Notes

[0001564590-18-015820:mdna:241]
The following table summarizes the principal amount of our Senior Notes as of April 27, 2018 (in millions):

[0001564590-18-015820:mdna:242]
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| Total |  | $ | 1,550 |  |

[0001564590-18-015820:mdna:243]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 10 – Financing Arrangements of the Notes to Consolidated Financial Statements.

[0001564590-18-015820:mdna:244]
Commercial Paper Program and Credit Facility

[0001564590-18-015820:mdna:245]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. On July 17, 2017 we amended the Program to increase the maximum amounts available that may be borrowed, repaid and re-borrowed to an aggregate face or principal amount of the notes outstanding of $1.0 billion, as compared to $600 million prior to the amendment. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of April 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $385 million, a weighted-average interest rate of 2.29% and maturities ranging from 19 days to 32 days.

[0001564590-18-015820:mdna:246]
In connection with the Program, we have a new senior unsecured credit agreement that expires on December 10, 2021, and we terminated our existing credit agreement that had been scheduled to expire on December 21, 2017. The new credit agreement, which as amended on July 17, 2017, provides a $1.0 billion revolving unsecured credit facility that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes, providing another potential source of liquidity to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement also includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of April 27, 2018, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-18-015820:mdna:247]
Capital Expenditure Requirements

[0001564590-18-015820:mdna:248]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for fiscal 2019 to be between $175 million and $225 million.

[0001564590-18-015820:mdna:249]
49

[0001564590-18-015820:mdna:250]
Dividends and Stock Repurchase Program

[0001564590-18-015820:mdna:251]
On May 23, 2018, we declared a cash dividend of $0.40 per share of common stock, payable on July 25, 2018 to holders of record as of the close of business on July 6, 2018.

[0001564590-18-015820:mdna:252]
As of April 27, 2018, our Board of Directors had authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program, including a $4.0 billion increase approved by our Board of Directors in April 2018. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through April 27, 2018, we repurchased a total of 284 million shares of our common stock at an average price of $33.85 per share, for an aggregate purchase price of $9.6 billion.

[0001564590-18-015820:mdna:253]
The timing and amount of stock repurchase transactions and future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements.

[0001564590-18-015820:mdna:254]
Contractual Obligations

[0001564590-18-015820:mdna:255]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. The following table summarizes our contractual obligations at April 27, 2018 (in millions):

[0001564590-18-015820:mdna:256]
|  |  |  | 2019 |  |  |  | 2020 |  |  |  | 2021 |  |  |  | 2022 |  |  |  | 2023 |  |  | Thereafter |  |  | Total |  |
| Office space and equipment lease commitments |  | $ | 55 |  |  | $ | 46 |  |  | $ | 34 |  |  | $ | 22 |  |  | $ | 13 |  |  | $ | 23 |  |  | $ | 193 |  |
| Purchase commitments with contract manufacturers (1) |  |  | 374 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 374 |  |
| Construction related obligations |  |  | 7 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 7 |  |
| Other purchase obligations (2) |  |  | 109 |  |  |  | 38 |  |  |  | 22 |  |  |  | 9 |  |  |  | 5 |  |  |  | 10 |  |  |  | 193 |  |
| Total off-balance sheet commitments |  |  | 545 |  |  |  | 84 |  |  |  | 56 |  |  |  | 31 |  |  |  | 18 |  |  |  | 33 |  |  |  | 767 |  |
| Commercial paper notes (3) |  |  | 385 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 385 |  |
| Long-term debt obligations (4) |  |  | 46 |  |  |  | 442 |  |  |  | 38 |  |  |  | 530 |  |  |  | 271 |  |  |  | 420 |  |  |  | 1,747 |  |
| Long-term financing arrangements |  |  | 4 |  |  |  | 4 |  |  |  | 1 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 9 |  |
| Uncertain tax positions (5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 314 |  |
| Total contractual obligations |  | $ | 980 |  |  | $ | 530 |  |  | $ | 95 |  |  | $ | 561 |  |  | $ | 289 |  |  | $ | 453 |  |  | $ | 3,222 |  |

[0001564590-18-015820:mdna:257]
| (1) | Contract manufacturer commitments consist of obligations for on-hand inventories and non-cancelable purchase orders with our contract manufacturers. We record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts. As of April 27, 2018, such liability amounted to $14 million and is included in accrued expenses in our consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. |

[0001564590-18-015820:mdna:258]
| (2) | Purchase obligations represent an estimate of all open purchase orders and contractual obligations associated with our ordinary course of business, in addition to inventory commitments with contract manufacturers, for which we have not received the goods or services. Purchase obligations do not include contracts that may be canceled without penalty. Although open purchase orders are considered enforceable and legally binding, the terms generally allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services. |

[0001564590-18-015820:mdna:259]
| (3) | Represents principal payments on our commercial paper notes. |

[0001564590-18-015820:mdna:260]
| (4) | Included in long-term debt are obligations related to our $1.6 billion principal amount of our Senior Notes, of which $400 million is due in September 2019, $500 million is due in June 2021, $250 million is due in December 2022 and $400 million is due in September 2024. Estimated interest payments for our long-term debt, assuming no early retirement of debt obligations, are $197 million for fiscal 2019 through fiscal 2025. |

[0001564590-18-015820:mdna:261]
| (5) | As of April 27, 2018, our liability for uncertain tax positions was $314 million, including interest, penalties and offsetting indirect benefits, which due to the uncertainty of the timing of future payments, is presented in the total column on a separate line in this table. |

[0001564590-18-015820:mdna:262]
Some of the amounts in the table above are based on management’s estimates and assumptions, including the commitment duration, the possibility of renewal or termination, anticipated actions by management and third parties and other factors. Because these estimates and assumptions are subjective, our actual future obligations may vary from those reflected in the table.

[0001564590-18-015820:mdna:263]
Financing Guarantees

[0001564590-18-015820:mdna:264]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $67 million and $183 million of receivables during fiscal 2018 and 2017, respectively.

[0001564590-18-015820:mdna:265]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-18-015820:mdna:266]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of April 27, 2018 and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-18-015820:mdna:267]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of April 27, 2018, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0001564590-18-015820:mdna:268]
Indemnification Agreements

[0001564590-18-015820:mdna:269]
We enter into indemnification agreements with third parties in the ordinary course of business. Generally, these indemnification agreements require us to reimburse losses suffered by the third-parties due to various events, such as lawsuits arising from patent or copyright infringement. These indemnification obligations are considered off-balance sheet arrangements under accounting guidance.

[0001564590-18-015820:mdna:270]
Legal Contingencies

[0001564590-18-015820:mdna:271]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 18 – Commitments and Contingencies of the Notes to Consolidated Financial Statements.
