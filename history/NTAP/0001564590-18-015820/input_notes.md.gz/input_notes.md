# NTAP notes — 0001564590-18-015820


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-18-015820:notes:1]
1. Description of Business and Significant Accounting Policies

[0001564590-18-015820:notes:2]
Description of Business — NetApp, Inc. (we, us, or the Company) provides global organizations the ability to manage and share their data across on-premises, private and public clouds. Together with our partners, we provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.

[0001564590-18-015820:notes:3]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2018, which ended on April 27, 2018, and fiscal year 2017, which ended on April 28, 2017, were each 52-week years; fiscal year 2016, which ended on April 29, 2016, was a 53-week year. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended on the last Friday of April and the associated quarters, months and periods of those fiscal years.

[0001564590-18-015820:notes:4]
Principles of Consolidation — The consolidated financial statements include the Company and its subsidiaries. Intercompany accounts and transactions are eliminated in consolidation.

[0001564590-18-015820:notes:5]
Use of Estimates — The preparation of the consolidated financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-18-015820:notes:6]
Cash Equivalents — We consider all highly liquid debt investments with original maturities of three months or less at the time of purchase to be cash equivalents.

[0001564590-18-015820:notes:7]
Available-for-Sale Investments — We classify our investments in debt securities as available-for-sale investments. Debt securities primarily consist of corporate bonds, U.S. Treasury and government debt securities, commercial paper and certificates of deposit. These available-for-sale investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of debt securities sold. These investments are recorded in the consolidated balance sheets at fair value.

[0001564590-18-015820:notes:8]
Unrealized gains and temporary losses, net of related taxes, are included in accumulated other comprehensive income (loss) (AOCI). Upon realization, those amounts are reclassified from AOCI to earnings. The amortization of premiums and discounts on the investments are included in our results of operations. Realized gains and losses on our available-for-sale investments are calculated based on the specific identification method.

[0001564590-18-015820:notes:9]
We classify our investments as current or noncurrent based on the nature of the investments and their availability for use in current operations.

[0001564590-18-015820:notes:10]
Other-than-Temporary Impairments on Investments — All of our available-for-sale investments are subject to periodic impairment review. When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and we assess whether the impairment is other-than-temporary. An impairment is considered other-than-temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of the entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost basis of the security. If impairment is considered other-than-temporary based on condition (i) or (ii) described above, the entire difference between the amortized cost and the fair value of the debt security is recognized in the results of operations. If an impairment is considered other-than-temporary based on condition (iii) described above, the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in earnings, and the amount relating to all other factors is recognized in other comprehensive income (OCI).

[0001564590-18-015820:notes:11]
Inventories — Inventories are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. We write down excess and obsolete inventory based on the difference between the cost of inventory and the estimated net realizable value based upon assumptions about future demand forecasts and market conditions. At the point of a loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts or circumstances do not result in the restoration or increase in that newly established basis. In addition, we record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0001564590-18-015820:notes:12]
Property and Equipment — Property and equipment are recorded at cost.

[0001564590-18-015820:notes:13]
Depreciation and amortization is computed using the straight-line method, generally over the following periods:

[0001564590-18-015820:notes:14]
|  |  | Depreciation Life |
| Buildings and improvements |  | 10 to 40 years |
| Furniture and fixtures |  | 5 years |
| Computer, production, engineering and other equipment |  | 2 to 3 years |
| Computer software |  | 3 to 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |

[0001564590-18-015820:notes:15]
Construction in progress will be depreciated over the estimated useful lives of the respective assets when they are ready for use. We capitalize interest on significant facility assets under construction and on significant software development projects.

[0001564590-18-015820:notes:16]
Software Development Costs — The costs for the development of new software products and substantial enhancements to existing software products are expensed as incurred until technological feasibility has been established, at which time any additional costs would be capitalized in accordance with the accounting guidance for software. Because our current process for developing software is essentially completed concurrently with the establishment of technological feasibility, which occurs upon the completion of a working model, no costs have been capitalized for any of the periods presented.

[0001564590-18-015820:notes:17]
Internal-Use Software Development Costs — We capitalize qualifying costs, which are incurred during the application development stage, for computer software developed or obtained for internal-use and amortize them over the software’s estimated useful life.

[0001564590-18-015820:notes:18]
Business Combinations — We recognize identifiable assets acquired and liabilities assumed at their acquisition date fair values. Goodwill as of the acquisition date is measured as the excess of consideration transferred over the net of the acquisition date fair values of the assets acquired and the liabilities assumed. While we use our best estimates and assumptions as a part of the purchase price allocation process to accurately value assets acquired and liabilities assumed at the acquisition date, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001564590-18-015820:notes:19]
Goodwill and Purchased Intangible Assets — Goodwill is recorded when the consideration paid for an acquisition exceeds the fair value of net tangible and intangible assets acquired. Purchased intangible assets with finite lives are amortized on a straight-line basis over their economic lives of three to six years for developed technology, two to eight years for customer contracts/relationships, two to three years for covenants not to compete and two to seven years for trademarks and trade names as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. In-process research and development is accounted for as an indefinite lived intangible asset and is assessed for potential impairment annually until development is complete or when events or circumstances indicate that their carrying amounts might be impaired. Upon completion of development, in-process research and development is accounted for as a finite-lived intangible asset.

[0001564590-18-015820:notes:20]
The carrying value of goodwill is tested for impairment on an annual basis in the fourth quarter of our fiscal year, or more frequently if we believe indicators of impairment exist. Triggering events for impairment reviews may be indicators such as adverse industry or economic trends, restructuring actions, lower projections of profitability, or a sustained decline in our market capitalization. For the purpose of impairment testing, we have a single reporting unit. The performance of the quantitative impairment test requires comparing the fair value of our reporting unit to its carrying amount, including goodwill. The fair value of our reporting unit is based on our entity level market capitalization, as determined through quoted market prices. An impairment exists if the fair value of our reporting unit is lower than its carrying amount. The impairment loss is measured based on the amount by which the carrying amount of our reporting unit exceeds its fair value, with the recognized loss not to exceed the total amount of goodwill. The fair value of our reporting unit has substantially exceeded its carrying amount in all periods presented.

[0001564590-18-015820:notes:21]
Impairment of Long-Lived Assets — We review the carrying values of long-lived assets whenever events and circumstances, such as reductions in demand, lower projections of profitability, significant changes in the manner of our use of acquired assets, or significant negative industry or economic trends, indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. If this review indicates that there is an impairment, the impaired asset is written down to its fair value, which is typically calculated using: (i) quoted market prices and/or (ii) expected future cash flows utilizing a discount rate. Our estimates regarding future anticipated cash flows, the remaining economic life of the products and technologies, or both, may differ from those used to assess the recoverability of assets. In that event, impairment charges or shortened useful lives of certain long-lived assets may be required, resulting in charges to our consolidated statements of operations when such determinations are made.

[0001564590-18-015820:notes:22]
Derivative Instruments — Our derivative instruments, which are carried at fair value in our consolidated balance sheets, consist primarily of foreign currency exchange contracts utilized to hedge against the short-term impact of foreign currency exchange rate fluctuations related to certain foreign currency denominated monetary assets and liabilities, primarily intercompany receivables and payables. These derivative instruments are not designated as hedging instruments and do not subject us to material balance sheet risk due to exchange rate movements because the gains and losses on these contracts are intended to offset the gains and losses in the underlying foreign currency denominated monetary assets and liabilities being hedged, and the net amount is included in earnings.

[0001564590-18-015820:notes:23]
Factors that could have an impact on the effectiveness of our hedging program include the accuracy of forecasts and the volatility of foreign currency markets. The program reduces, but does not entirely eliminate, the impact of currency exchange movements. Currently, we do not enter into any foreign currency exchange forward contracts to hedge exposures related to forecasted sales transactions, forecasted expenditures or firm commitments. Cash flows from our derivative program are included under operating activities in the consolidated statements of cash flows.

[0001564590-18-015820:notes:24]
Revenue Recognition — We recognize revenue when:

[0001564590-18-015820:notes:25]
|  | • | Persuasive evidence of an arrangement exists. Customarily we have a purchase order and/or contract prior to recognizing revenue on an arrangement from our end users, customers, value-added resellers or distributors. |

[0001564590-18-015820:notes:26]
|  | • | Delivery has occurred. Our product is physically delivered to our customers. We typically do not allow for restocking rights with any of our value-added resellers or distributors. Products shipped with acceptance criteria or return rights are not recognized as revenue until all criteria are achieved. We do not recognize revenue if undelivered products or services exist that are essential to the functionality of the delivered product in an arrangement. |

[0001564590-18-015820:notes:27]
|  | • | The fee is fixed or determinable. Arrangements with payment terms extending beyond our standard terms, conditions and practices are not considered to be fixed or determinable. Revenue from such arrangements is recognized at the earlier of customer payment or when the fees become due and payable. We typically do not allow for price-protection rights with any of our value-added resellers or distributors. |

[0001564590-18-015820:notes:28]
|  | • | Collection is reasonably assured. If there is considerable doubt surrounding the creditworthiness of a customer at the outset of an arrangement, the associated revenue is deferred and recognized upon cash receipt. |

[0001564590-18-015820:notes:29]
The hardware systems and software components essential to the functionality of the hardware systems are considered non-software deliverables and therefore are not subject to industry-specific software revenue recognition guidance.

[0001564590-18-015820:notes:30]
Our product revenues also include revenues from the sale of non-essential software products. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales are subject to the industry-specific software revenue recognition guidance.

[0001564590-18-015820:notes:31]
Our multiple element arrangements may include our systems, software maintenance, hardware maintenance and other services. Software maintenance contracts entitle our customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, and patch releases. Hardware maintenance services include contracts for extended warranty, technical support and minimum response times. Other services include professional services and customer education and training services. Revenues from software maintenance and hardware maintenance services are recognized ratably over the contractual term, generally from one to five years. We also offer extended warranty contracts (which extend our standard parts warranty and may include premium hardware maintenance) at the end of the original warranty term; revenues from these contracts are recognized ratably over their respective contract term. We sell professional services either on a time and materials basis or under fixed price projects; we recognize revenue for these services as they are performed.

[0001564590-18-015820:notes:32]
For multiple element arrangements, we allocate revenue to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement. The selling price for each element is based upon the following selling price hierarchy: vendor specific objective evidence of selling price (VSOE) if available, third party evidence (TPE) if VSOE is not available, or estimated selling price (ESP) if neither VSOE nor TPE are available. ESP is generally evidenced by a majority of historical transactions falling within a reasonable price range. We also consider multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, type of customer and distribution channels. For our non-software deliverables, we generally allocate the arrangement consideration based on the relative selling price of the deliverables using ESP. For our software maintenance services, we generally use VSOE. When we are unable to establish VSOE for our software maintenance services, we use ESP in our allocation of arrangement consideration.

[0001564590-18-015820:notes:33]
VSOE is based upon the normal pricing and discounting practices for those services when sold separately. VSOE is generally evidenced by a substantial majority of historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer type, and other variables in determining VSOE.

[0001564590-18-015820:notes:34]
When VSOE cannot be established, we attempt to establish the selling price of each element based on third party evidence of selling price (TPE). Generally, we are not able to determine TPE because our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained.

[0001564590-18-015820:notes:35]
We regularly review VSOE, TPE, and ESP and maintain internal controls over the establishment and updates of these estimates.

[0001564590-18-015820:notes:36]
For our software deliverables, we use the residual method to recognize revenue when an arrangement includes one or more elements to be delivered at a future date and VSOE of all undelivered elements exists. Typically, only software maintenance, hardware maintenance and/or other services remain undelivered after the product is delivered. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the consideration is recognized as product revenues for delivered elements. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is software maintenance, the entire arrangement is recognized ratably over the maintenance period.

[0001564590-18-015820:notes:37]
We record reductions to revenue for estimated sales returns at the time of shipment. Sales returns are estimated based on historical sales returns, current trends, and our expectations regarding future experience. We monitor and analyze the accuracy of sales returns estimates by reviewing actual returns and adjust them for future expectations. Additionally, distributors and retail partners participate in various marketing and other programs, and we record estimated accruals and allowances for these programs. We accrue for these programs based on contractual terms and historical experience. Sales and value added taxes collected from customers and remitted to governmental authorities are presented on a net basis in the accompanying consolidated statements of operations.

[0001564590-18-015820:notes:38]
Product Warranties — Estimated future hardware and software warranty costs are recorded as a cost of product revenues at the time of product shipment, based on historical and projected warranty claim rates, historical and projected cost-per-claim and knowledge of specific product failures that are outside our typical experience. Factors that affect our warranty liability include the number of installed units subject to warranty protection, product failure rates, and estimated materials, distribution and labor costs. We assess the adequacy of our warranty accrual each quarter and adjust the amount as considered necessary.

[0001564590-18-015820:notes:39]
Foreign Currency Translation — For international subsidiaries whose functional currency is the local currency, gains and losses resulting from translation of these foreign currency financial statements into U.S. dollars are recorded in AOCI. For subsidiaries where the functional currency is the U.S. dollar, gains and losses resulting from the process of remeasuring foreign currency financial statements into U.S. dollars are included in other income (expense), net.

[0001564590-18-015820:notes:40]
Benefit Plans — We record actuarial gains and losses associated with defined benefit plans within AOCI and amortize net gains or losses in excess of 10 percent of the greater of the market value of plan assets or the plans' projected benefit obligation on a straight-line basis over the remaining estimated service life of plan participants. The measurement date for all defined benefit plans is our fiscal year end.

[0001564590-18-015820:notes:41]
Stock-Based Compensation — We measure and recognize stock-based compensation for all stock-based awards, including employee stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and rights to purchase shares under our employee stock purchase plan (ESPP), based on their estimated fair value, and recognize the costs in our financial statements using the single option straight-line approach over the requisite service period for the entire award.

[0001564590-18-015820:notes:42]
The fair value of employee time-based RSUs is equal to the market value of our common stock on the grant date of the award, less the present value of expected dividends during the vesting period, discounted at a risk-free interest rate. The fair value of PBRSUs is measured using a Monte Carlo simulation model on the date of grant.

[0001564590-18-015820:notes:43]
The fair value of each award is estimated on the grant date and is not remeasured as a result of subsequent stock price fluctuations. Our expected term assumption is based primarily on historical exercise and post-vesting forfeiture experience. Our stock price volatility assumption is based on a combination of our historical and implied volatility. The risk-free interest rates are based upon United States (U.S.) Treasury bills with equivalent expected terms, and the expected dividends are based on our history and expected dividend payouts.

[0001564590-18-015820:notes:44]
We account for forfeitures of stock-based awards as they occur.

[0001564590-18-015820:notes:45]
Income Taxes — Deferred income tax assets and liabilities are provided for temporary differences that will result in tax deductions or income in future periods, as well as the future benefit of tax credit carryforwards. A valuation allowance reduces tax assets to their estimated realizable value.

[0001564590-18-015820:notes:46]
We recognize the tax liability for uncertain income tax positions on the income tax return based on the two-step process prescribed in the interpretation. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. We recognize interest and penalties related to unrecognized tax benefits within the income tax expense line in the accompanying consolidated statements of operations.

[0001564590-18-015820:notes:47]
Net Income per Share — Basic net income per share is computed by dividing income available to common stockholders by the weighted-average number of common shares outstanding. Diluted net income per share is computed giving effect to all dilutive potential shares that were outstanding during the period. Potential dilutive common shares consist primarily of outstanding stock options, shares to be purchased under our employee stock purchase plan and unvested RSUs.

[0001564590-18-015820:notes:48]
Treasury Stock — We account for treasury stock under the cost method. Upon the retirement of treasury stock, we allocate the value of treasury shares between common stock, additional paid-in capital and retained earnings.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-18-015820:notes:49]
3. Concentration of Risk

[0001564590-18-015820:notes:50]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, investments, foreign currency exchange contracts and accounts receivable. Cash equivalents and short-term investments consist primarily of corporate bonds, U.S. Treasury and government debt securities, commercial paper and certificates of deposit, all of which are considered high investment grade. Our policy is to limit the amount of credit exposure through diversification and investment in highly rated securities. We further mitigate concentrations of credit risk in our investments by limiting our investments in the debt securities of a single issuer and by diversifying risk across geographies and type of issuer.

[0001564590-18-015820:notes:51]
By entering into foreign currency exchange contracts, we have assumed the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and we do not expect any losses as a result of counterparty defaults.

[0001564590-18-015820:notes:52]
We sell our products primarily to large organizations in different industries and geographies. We do not require collateral or other security to support accounts receivable. In addition, we maintain an allowance for potential credit losses. To reduce credit risk, we perform ongoing credit evaluations on our customers’ financial condition. We establish an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information and, to date, such losses have been within management’s expectations. Concentrations of credit risk with respect to trade accounts receivable are limited due to the wide variety of customers who are dispersed across many geographic regions.

[0001564590-18-015820:notes:53]
There are no concentrations of business transacted with a particular market that would severely impact our business in the near term. However, we rely on a limited number of suppliers for certain key components and a few key contract manufacturers to manufacture most of our products; any disruption or termination of these arrangements could materially adversely affect our operating results.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-18-015820:notes:54]
4. Statements of Cash Flows Additional Information

[0001564590-18-015820:notes:55]
Non-cash investing and financing activities and supplemental cash flow information are as follows (in millions):

[0001564590-18-015820:notes:56]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 24 |  |  | $ | 19 |  |  | $ | 18 |  |
| Non-cash extinguishment of sale-leaseback financing obligations |  | $ | 130 |  |  | $ | 19 |  |  | $ | — |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 87 |  |  | $ | 102 |  |  | $ | 161 |  |
| Interest paid |  | $ | 58 |  |  | $ | 44 |  |  | $ | 43 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-18-015820:notes:57]
5. Business Combinations

[0001564590-18-015820:notes:58]
Fiscal 2018 Acquisitions

[0001564590-18-015820:notes:59]
On August 4, 2017, we acquired all of the outstanding shares of Greenqloud ehf., a privately-held provider of cloud management software based in Iceland, for $51 million in cash, of which we preliminarily allocated $10 million to developed technology, $38 million to goodwill, and the remainder to other assets.

[0001564590-18-015820:notes:60]
On June 15, 2017, we acquired all of the outstanding shares of Plexistor Ltd., a privately-held provider of software defined memory architecture based in Israel, for $24 million in cash, of which we allocated $6 million to developed technology, $17 million to goodwill, and the remainder to other assets.

[0001564590-18-015820:notes:61]
Fiscal 2017 Acquisition

[0001564590-18-015820:notes:62]
On March 24, 2017, we acquired all of the outstanding shares of a privately-held consulting and software development company for $8 million in cash. Substantially all of the purchase price was recorded to goodwill.

[0001564590-18-015820:notes:63]
Fiscal 2016 Acquisition

[0001564590-18-015820:notes:64]
On February 2, 2016, we acquired all of the outstanding shares of privately-held SolidFire, Inc. (SolidFire), a maker of all-flash storage systems based in Colorado, for $850 million in cash. This acquisition extends our position in the all-flash array market by adding new flash offerings that enhance our ability to deliver customers all-flash storage with a webscale architecture that simplifies data center operations and enables rapid deployments of new applications.

[0001564590-18-015820:notes:65]
The acquired assets and assumed liabilities were recorded at their estimated fair values. We determined the estimated fair values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expected to realize revenue synergies, leverage and expand the existing SolidFire sales channels and product development resources, and utilize the existing workforce. We also anticipated opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated fair value of SolidFire’s identifiable net assets acquired, and as a result, we have recorded goodwill in connection with this acquisition. The U.S. goodwill is not deductible for income tax purposes.

[0001564590-18-015820:notes:66]
The fair values of assets acquired and liabilities assumed on the closing date are summarized as follows (in millions):

[0001564590-18-015820:notes:67]
| Cash |  | $ | 8 |  |
| Intangible assets |  |  | 168 |  |
| Goodwill |  |  | 649 |  |
| Other assets |  |  | 56 |  |
| Total assets acquired |  |  | 881 |  |
| Liabilities assumed |  |  | (31 | ) |
| Total purchase price |  | $ | 850 |  |

[0001564590-18-015820:notes:68]
The components of intangible assets acquired were as follows (in millions, except useful life):

[0001564590-18-015820:notes:69]
|  |  |  |  |  |  | Estimated useful life (years) |
| Developed technology |  | $ | 99 |  |  | 5 |
| Customer contracts/relationships |  |  | 41 |  |  | 3 |
| Trade name |  |  | 9 |  |  | 2 |
| Total intangible assets subject to amortization |  |  | 149 |  |  |  |
| In-process research and development |  |  | 19 |  |  | N/A |
| Total intangible assets |  | $ | 168 |  |  |  |

[0001564590-18-015820:notes:70]
N/A - Not applicable

[0001564590-18-015820:notes:71]
In-process research and development was valued with input from valuation specialists using the multi-period excess earnings method under the income approach by discounting forecasted cash flows directly related to the products expected to result from the associated project, net of returns on contributory assets. The in-process development project acquired related to a major new generation of the SolidFire technology platform.

[0001564590-18-015820:notes:72]
The results of operations related to the SolidFire acquisition have been included in our consolidated statements of operations from the acquisition date. The following unaudited pro forma condensed combined financial information gives effect to the acquisition of SolidFire as if it had been consummated on April 26, 2014. The unaudited pro forma condensed combined financial information is presented for informational purposes only, and is not intended to represent or be indicative of the results of operations of the Company that would have been reported had the acquisition occurred on April 26, 2014 and should not be taken as representative of future consolidated results of operations of the combined company (in millions).

[0001564590-18-015820:notes:73]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |
| Net income |  | $ | 219 |  |

[0001564590-18-015820:notes:74]
Adjustments have been reflected in the unaudited pro forma condensed combined information to include the amortization of identifiable intangible assets, purchase accounting adjustments to deferred revenue, interest expense related to the associated financing arrangement, costs directly attributable to the acquisition and impacts to our provision for income taxes as a result of the acquisition. Pro forma net revenues were not materially different than those presented in the consolidated statements of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-18-015820:notes:75]
6. Goodwill and Purchased Intangible Assets, Net

[0001564590-18-015820:notes:76]
Goodwill activity is summarized as follows (in millions):

[0001564590-18-015820:notes:77]
| Balance as of April 29, 2016 |  | $ | 1,676 |  |
| Goodwill acquired |  |  | 8 |  |
| Balance as of April 28, 2017 |  |  | 1,684 |  |
| Goodwill acquired |  |  | 55 |  |
| Balance as of April 27, 2018 |  | $ | 1,739 |  |

[0001564590-18-015820:notes:78]
Purchased intangible assets are summarized below (in millions):

[0001564590-18-015820:notes:79]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 164 |  |  | $ | (80 | ) |  | $ | 84 |  |  | $ | 148 |  |  | $ | (44 | ) |  | $ | 104 |  |
| Customer contracts/relationships |  |  | 43 |  |  |  | (33 | ) |  |  | 10 |  |  |  | 43 |  |  |  | (19 | ) |  |  | 24 |  |
| Other purchased intangibles |  |  | 9 |  |  |  | (9 | ) |  |  | — |  |  |  | 9 |  |  |  | (6 | ) |  |  | 3 |  |
| Total purchased intangible assets |  | $ | 216 |  |  | $ | (122 | ) |  | $ | 94 |  |  | $ | 200 |  |  | $ | (69 | ) |  | $ | 131 |  |

[0001564590-18-015820:notes:80]
In fiscal 2017, the in-process research and development project related to the SolidFire acquisition was completed, and the associated intangible asset was reclassified to developed technology.

[0001564590-18-015820:notes:81]
Amortization expense for purchased intangible assets is summarized below (in millions):

[0001564590-18-015820:notes:82]
|  |  | Year Ended |  |  | Statement of |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | Operations Classifications |
| Developed technology |  | $ | 36 |  |  | $ | 29 |  |  | $ | 61 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 14 |  |  |  | 14 |  |  |  | 5 |  |  | Operating expenses |
| Other purchased intangibles |  |  | 3 |  |  |  | 5 |  |  |  | 1 |  |  | Operating expenses |
| Total |  | $ | 53 |  |  | $ | 48 |  |  | $ | 67 |  |  |  |

[0001564590-18-015820:notes:83]
As of April 27, 2018, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-18-015820:notes:84]
| Fiscal Year |  | Amount |  |
| 2019 |  |  | 47 |  |
| 2020 |  |  | 31 |  |
| 2021 |  |  | 16 |  |
| Total |  | $ | 94 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-18-015820:notes:85]
7. Balance Sheet Details

[0001564590-18-015820:notes:86]
Cash and cash equivalents (in millions):

[0001564590-18-015820:notes:87]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Cash |  | $ | 2,727 |  |  | $ | 2,275 |  |
| Cash equivalents |  |  | 214 |  |  |  | 169 |  |
| Cash and cash equivalents |  | $ | 2,941 |  |  | $ | 2,444 |  |

[0001564590-18-015820:notes:88]
Inventories (in millions):

[0001564590-18-015820:notes:89]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Purchased components |  | $ | 12 |  |  | $ | 28 |  |
| Finished goods |  |  | 114 |  |  |  | 135 |  |
| Inventories |  | $ | 126 |  |  | $ | 163 |  |

[0001564590-18-015820:notes:90]
Property and equipment, net (in millions):

[0001564590-18-015820:notes:91]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Land |  | $ | 106 |  |  | $ | 132 |  |
| Buildings and improvements |  |  | 594 |  |  |  | 612 |  |
| Leasehold improvements |  |  | 88 |  |  |  | 93 |  |
| Computer, production, engineering and other equipment |  |  | 733 |  |  |  | 741 |  |
| Computer software |  |  | 357 |  |  |  | 353 |  |
| Furniture and fixtures |  |  | 99 |  |  |  | 90 |  |
| Construction-in-progress |  |  | 27 |  |  |  | 26 |  |
|  |  |  | 2,004 |  |  |  | 2,047 |  |
| Accumulated depreciation and amortization |  |  | (1,248 | ) |  |  | (1,248 | ) |
| Property and equipment, net |  | $ | 756 |  |  | $ | 799 |  |

[0001564590-18-015820:notes:92]
As of April 28, 2017, we had classified certain land and buildings located in Sunnyvale, California, previously reported as property and equipment as assets held-for-sale and included their book value of $118 million in other current assets in the consolidated balance sheets. On September 8, 2017, we entered into an agreement to sell these properties for a total of $306 million, through two separate and independent closings. On December 7, 2017, the first closing occurred and we consummated the sale of properties with a net book value of $66 million for cash proceeds of $210 million, resulting in a gain, net of direct selling costs, of $142 million.

[0001564590-18-015820:notes:93]
The remaining properties, consisting of land with a net book value of $52 million, continue to be classified as assets held-for-sale as of April 27, 2018. We will consummate the sale of these properties, and receive cash proceeds of $96 million, upon the occurrence of the second closing, which is expected to occur within the next 12 months. That closing is subject to due diligence, certain termination rights and customary closing conditions, including local governmental approval of the subdivision of a land parcel.

[0001564590-18-015820:notes:94]
Depreciation and amortization expense related to property and equipment, net is summarized below (in millions):

[0001564590-18-015820:notes:95]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Depreciation and amortization expense |  | $ | 145 |  |  | $ | 178 |  |  | $ | 212 |  |

[0001564590-18-015820:notes:96]
Other non-current assets (in millions):

[0001564590-18-015820:notes:97]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Deferred tax assets |  | $ | 270 |  |  | $ | 525 |  |
| Other assets |  |  | 150 |  |  |  | 156 |  |
| Other non-current assets |  | $ | 420 |  |  | $ | 681 |  |

[0001564590-18-015820:notes:98]
Accrued expenses (in millions):

[0001564590-18-015820:notes:99]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Accrued compensation and benefits |  | $ | 441 |  |  | $ | 340 |  |
| Sale-leaseback financing obligations |  |  | — |  |  |  | 130 |  |
| Product warranty liabilities |  |  | 25 |  |  |  | 33 |  |
| Other current liabilities |  |  | 359 |  |  |  | 279 |  |
| Accrued expenses |  | $ | 825 |  |  | $ | 782 |  |

[0001564590-18-015820:notes:100]
Product warranty liabilities:

[0001564590-18-015820:notes:101]
Equipment and software systems sales include a standard product warranty. The following tables summarize the activity related to product warranty liabilities and their balances as reported in our consolidated balance sheets (in millions):

[0001564590-18-015820:notes:102]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Balance at beginning of period |  | $ | 50 |  |  | $ | 70 |  |
| Expense accrued during the period |  |  | 16 |  |  |  | 17 |  |
| Warranty costs incurred |  |  | (26 | ) |  |  | (37 | ) |
| Balance at end of period |  | $ | 40 |  |  | $ | 50 |  |

[0001564590-18-015820:notes:103]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Accrued expenses |  | $ | 25 |  |  | $ | 33 |  |
| Other long-term liabilities |  |  | 15 |  |  |  | 17 |  |
| Total warranty liabilities |  | $ | 40 |  |  | $ | 50 |  |

[0001564590-18-015820:notes:104]
Warranty expense accrued during the period includes amounts accrued for systems at the time of shipment, adjustments for changes in estimated costs for warranties on systems shipped in the period and changes in estimated costs for warranties on systems shipped in prior periods.

[0001564590-18-015820:notes:105]
Other long-term liabilities (in millions):

[0001564590-18-015820:notes:106]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Liability for uncertain tax positions |  | $ | 314 |  |  | $ | 148 |  |
| Income taxes payable |  |  | 549 |  |  |  | — |  |
| Product warranty liabilities |  |  | 15 |  |  |  | 17 |  |
| Other liabilities |  |  | 83 |  |  |  | 84 |  |
| Other long-term liabilities |  | $ | 961 |  |  | $ | 249 |  |

[0001564590-18-015820:notes:107]
Deferred revenue and financed unearned services revenue (in millions):

[0001564590-18-015820:notes:108]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Deferred product revenue |  | $ | 119 |  |  | $ | 124 |  |
| Deferred services revenue |  |  | 3,236 |  |  |  | 2,999 |  |
| Financed unearned services revenue |  |  | 122 |  |  |  | 219 |  |
| Total |  | $ | 3,477 |  |  | $ | 3,342 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,804 |  |  | $ | 1,744 |  |
| Long-term |  |  | 1,673 |  |  |  | 1,598 |  |
| Total |  | $ | 3,477 |  |  | $ | 3,342 |  |

[0001564590-18-015820:notes:109]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 18 – Commitments and Contingencies for additional information related to these arrangements.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-18-015820:notes:110]
8. Other income (expense), net

[0001564590-18-015820:notes:111]
Other income (expense), net consists of the following (in millions):

[0001564590-18-015820:notes:112]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Interest income |  | $ | 79 |  |  | $ | 44 |  |  | $ | 46 |  |
| Interest expense |  |  | (62 | ) |  |  | (52 | ) |  |  | (49 | ) |
| Other income, net |  |  | 24 |  |  |  | 8 |  |  |  | — |  |
| Total other income (expense), net |  | $ | 41 |  |  | $ | — |  |  | $ | (3 | ) |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-18-015820:notes:113]
9. Financial Instruments and Fair Value Measurements

[0001564590-18-015820:notes:114]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis, whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the three levels of inputs to measure fair value:

[0001564590-18-015820:notes:115]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001564590-18-015820:notes:116]
Level 2: Inputs that reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; benchmark yields, reported trades, broker/dealer quotes, inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0001564590-18-015820:notes:117]
Level 3: Unobservable inputs that reflect our own assumptions incorporated in valuation techniques used to measure fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0001564590-18-015820:notes:118]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and consider an inactive market to be one in which there are infrequent or few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty’s non-performance risk is considered in measuring the fair values of liabilities and assets, respectively.

[0001564590-18-015820:notes:119]
Investments

[0001564590-18-015820:notes:120]
The following is a summary of our investments (in millions):

[0001564590-18-015820:notes:121]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,861 |  |  | $ | 1 |  |  | $ | (39 | ) |  | $ | 1,823 |  |  | $ | 1,535 |  |  | $ | 3 |  |  | $ | (2 | ) |  | $ | 1,536 |  |
| U.S. Treasury and government debt securities |  |  | 497 |  |  |  | — |  |  |  | (5 | ) |  |  | 492 |  |  |  | 629 |  |  |  | 1 |  |  |  | (2 | ) |  |  | 628 |  |
| Foreign government debt securities |  |  | 4 |  |  |  | — |  |  |  | — |  |  |  | 4 |  |  |  | 21 |  |  |  | — |  |  |  | — |  |  |  | 21 |  |
| Commercial paper |  |  | 230 |  |  |  | — |  |  |  | — |  |  |  | 230 |  |  |  | 362 |  |  |  | — |  |  |  | — |  |  |  | 362 |  |
| Certificates of deposit |  |  | 115 |  |  |  | — |  |  |  | — |  |  |  | 115 |  |  |  | 99 |  |  |  | — |  |  |  | — |  |  |  | 99 |  |
| Mutual funds |  |  | 31 |  |  |  | — |  |  |  | — |  |  |  | 31 |  |  |  | 31 |  |  |  | — |  |  |  | — |  |  |  | 31 |  |
| Total debt and equity securities |  | $ | 2,738 |  |  | $ | 1 |  |  | $ | (44 | ) |  | $ | 2,695 |  |  | $ | 2,677 |  |  | $ | 4 |  |  | $ | (4 | ) |  | $ | 2,677 |  |

[0001564590-18-015820:notes:122]
As of April 27, 2018, the unrealized losses on our available-for-sale investments were caused by market value declines as a result of increasing market interest rates. Because the declines in market value are attributable to changes in market conditions and not credit quality, and because we have determined that (i) we do not have the intent to sell any of these investments and (ii) it is not more likely than not that we will be required to sell any of these investments before recovery of the entire amortized cost basis, we have determined that no other-than-temporary impairments were required to be recognized on these investments as of April 27, 2018.

[0001564590-18-015820:notes:123]
The following table presents the contractual maturities of our debt investments as of April 27, 2018 (in millions):

[0001564590-18-015820:notes:124]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 968 |  |  | $ | 966 |  |
| Due after one year through five years |  |  | 1,110 |  |  |  | 1,094 |  |
| Due after five years through ten years |  |  | 629 |  |  |  | 604 |  |
|  |  | $ | 2,707 |  |  | $ | 2,664 |  |

[0001564590-18-015820:notes:125]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0001564590-18-015820:notes:126]
Fair Value of Financial Instruments

[0001564590-18-015820:notes:127]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis (in millions):

[0001564590-18-015820:notes:128]
|  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,727 |  |  | $ | 2,727 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,823 |  |  |  | — |  |  |  | 1,823 |  |
| U.S. Treasury and government debt securities |  |  | 492 |  |  |  | 253 |  |  |  | 239 |  |
| Foreign government debt securities |  |  | 4 |  |  |  | — |  |  |  | 4 |  |
| Commercial paper |  |  | 230 |  |  |  | — |  |  |  | 230 |  |
| Certificates of deposit |  |  | 115 |  |  |  | — |  |  |  | 115 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 5,391 |  |  | $ | 2,980 |  |  | $ | 2,411 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 25 |  |  | $ | 25 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0001564590-18-015820:notes:129]
|  |  | April 28, 2017 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,275 |  |  | $ | 2,275 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,536 |  |  |  | — |  |  |  | 1,536 |  |
| U.S. Treasury and government debt securities |  |  | 628 |  |  |  | 273 |  |  |  | 355 |  |
| Foreign government debt securities |  |  | 21 |  |  |  | — |  |  |  | 21 |  |
| Commercial paper |  |  | 362 |  |  |  | — |  |  |  | 362 |  |
| Certificates of deposit |  |  | 99 |  |  |  | — |  |  |  | 99 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,921 |  |  | $ | 2,548 |  |  | $ | 2,373 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 24 |  |  | $ | 24 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |

[0001564590-18-015820:notes:130]
| (1) | Reported as other current assets in the consolidated balance sheets |

[0001564590-18-015820:notes:131]
| (2) | Reported as other non-current assets in the consolidated balance sheets |

[0001564590-18-015820:notes:132]
| (3) | Reported as accrued expenses in the consolidated balance sheets |

[0001564590-18-015820:notes:133]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of April 27, 2018 and April 28, 2017, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-18-015820:notes:134]
Fair Value of Debt

[0001564590-18-015820:notes:135]
As of April 27, 2018 and April 28, 2017, the fair value of our long-term debt was approximately $1,523 million and $1,520 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-18-015820:notes:136]
10. Financing Arrangements

[0001564590-18-015820:notes:137]
Long-Term Debt

[0001564590-18-015820:notes:138]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-18-015820:notes:139]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | — |  |  | N/A |  |  | $ | 750 |  |  |  | 2.25 | % |
| 2.00% Senior Notes Due September 2019 |  |  | 400 |  |  |  | 2.32 | % |  |  | — |  |  | N/A |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | — |  |  | N/A |  |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (9 | ) |  |  |  |  |  |  | (7 | ) |  |  |  |  |
| Total senior notes |  |  | 1,541 |  |  |  |  |  |  |  | 1,493 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | — |  |  |  |  |  |  |  | (749 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,541 |  |  |  |  |  |  | $ | 744 |  |  |  |  |  |

[0001564590-18-015820:notes:140]
Senior Notes

[0001564590-18-015820:notes:141]
In September 2017, we issued $400 million aggregate principal amount of 2.00% Senior Notes due on September 27, 2019 and $400 million aggregate principal amount of 3.30% Senior Notes due on September 29, 2024, for which we received total proceeds of approximately $795 million, net of discount and issuance costs. On November 3, 2017, we extinguished our 2.00% Senior Notes due December 2017 for an aggregate cash redemption price of $751 million, plus accrued and unpaid interest.

[0001564590-18-015820:notes:142]
Interest on our Senior Notes issued in September 2017 is payable semi-annually in March and September. Our 3.375% Senior Notes and 3.25% Senior Notes, with principal amounts of $500 million and $250 million, respectively, were issued in June 2014 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-18-015820:notes:143]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of April 27, 2018, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-18-015820:notes:144]
As of April 27, 2018, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-18-015820:notes:145]
| Fiscal Year |  | Amount |  |
| 2020 |  | $ | 400 |  |
| 2022 |  |  | 500 |  |
| 2023 |  |  | 250 |  |
| Thereafter |  |  | 400 |  |
| Total |  | $ | 1,550 |  |

[0001564590-18-015820:notes:146]
Commercial Paper Program and Credit Facility

[0001564590-18-015820:notes:147]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended on July 17, 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of April 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $385 million, a weighted-average interest rate of 2.29% and maturities ranging from 19 days to 32 days. As of April 28, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $500 million, a weighted-average interest rate of 1.26% and maturities ranging from 7 days to 38 days.

[0001564590-18-015820:notes:148]
In connection with the Program, we have a new senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended on July 17, 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of April 27, 2018, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-18-015820:notes:149]
Sale-leaseback Transactions

[0001564590-18-015820:notes:150]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates through December 31, 2017. These properties did not qualify for sale-leaseback accounting and as a result they were accounted for as financing transactions. During fiscal 2017, we terminated one of the leases and recorded a non-cash sale of properties with a net book value of $9 million, the extinguishment of $19 million in financing obligations, and a gain of $10 million. During fiscal 2018, we terminated the remaining leases and recorded a non-cash sale of properties with a net book value of $54 million, the extinguishment of $130 million in financing obligations, and a gain of $76 million. As of April 27, 2018, there are no balances remaining on our consolidated balance sheets associated with this sale-leaseback arrangement.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-18-015820:notes:151]
11. Stockholders’ Equity

[0001564590-18-015820:notes:152]
Equity Incentive Programs

[0001564590-18-015820:notes:153]
The 1999 Plan — As most recently amended on September 14, 2017, the 1999 Stock Option Plan (the Plan) comprises five separate equity incentive programs: (i) the Discretionary Option Grant Program under which options may be granted to eligible individuals at a fixed price per share; (ii) the Stock Appreciation Rights Program under which eligible persons may be granted stock appreciation rights that allow individuals to receive the appreciation in fair market value of the shares; (iii) the Stock Issuance Program under which eligible individuals may be issued shares of common stock directly; (iv) the Performance Share and Performance Unit Program under which eligible persons may be granted performance shares or performance units which result in payment to the participant only if performance goals or other vesting criteria are achieved and (v) the Automatic Award Program under which nonemployee board members automatically receive equity grants at designated intervals over their period of board service. The Plan expires in August 2019.

[0001564590-18-015820:notes:154]
Under the Plan, the Board of Directors may grant to employees, nonemployee directors, consultants and independent advisors options to purchase shares of our common stock during their period of service. The exercise price for an incentive stock option and a nonstatutory option cannot be less than 100% of the fair market value of the common stock on the grant date. Options granted under the Plan generally vest over a four-year period. Options granted generally have a term of seven years after the grant date, subject to earlier termination upon the occurrence of certain events. The Plan prohibits the repricing of any outstanding stock option or stock appreciation right after it has been granted or to cancel any outstanding stock option or stock appreciation right and immediately replace it with a new stock option or stock appreciation right with a lower exercise price unless approved by stockholders. RSUs granted under the Plan include time-based RSUs that generally vest over a four-year period with 25% vesting on each anniversary of the grant date. The Compensation Committee of the Board of Directors (the Compensation Committee) has the discretion to use different vesting schedules. In addition, performance-based RSUs may be granted under the Plan and are subject to performance criteria and vesting terms specified by the Compensation Committee.

[0001564590-18-015820:notes:155]
Under the Plan, the number of shares reserved for issuance is reduced by two shares for every share subject to a full value award, which are specified to be grants that are in the form of performance shares and/or performance unit awards, stock, restricted stock or restricted stock units. The Plan (i) limits the number of shares that may be granted pursuant to awards under the Stock Issuance Program to a participant in any calendar year to 1 million, (ii) limits the initial value of performance units a participant may receive to not more than $5 million and (iii) limits the number of performance shares a participant may receive in a calendar year to 1 million.

[0001564590-18-015820:notes:156]
During fiscal 2018, the shares reserved for issuance under the Plan were increased by approximately 9 million shares of common stock. As of April 27, 2018, 26 million shares were available for grant under the Plan.

[0001564590-18-015820:notes:157]
Stock Options

[0001564590-18-015820:notes:158]
The following table summarizes information related to our stock options (in millions, except exercise price and contractual term):

[0001564590-18-015820:notes:159]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 24, 2015 |  |  | 12 |  |  | $ | 37.74 |  |  |  |  |  |  |  |  |  |
| Assumed in acquisition |  |  | 2 |  |  | $ | 5.20 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (2 | ) |  | $ | 19.64 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (3 | ) |  | $ | 38.27 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 29, 2016 |  |  | 9 |  |  | $ | 34.01 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (3 | ) |  | $ | 25.61 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (2 | ) |  | $ | 39.36 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 28, 2017 |  |  | 4 |  |  | $ | 35.76 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (2 | ) |  | $ | 36.99 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (1 | ) |  | $ | 40.50 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 27, 2018 |  |  | 1 |  |  | $ | 31.19 |  |  |  | 3.48 |  |  | $ | 44 |  |
| Exercisable as of April 27, 2018 |  |  | 1 |  |  | $ | 34.30 |  |  |  | 2.91 |  |  | $ | 34 |  |

[0001564590-18-015820:notes:160]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our stock on that day for all in-the-money options.

[0001564590-18-015820:notes:161]
Additional information related to our stock options is summarized below (in millions):

[0001564590-18-015820:notes:162]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Intrinsic value of exercises |  | $ | 37 |  |  | $ | 26 |  |  | $ | 16 |  |
| Proceeds received from exercises |  | $ | 88 |  |  | $ | 60 |  |  | $ | 27 |  |
| Fair value of options vested |  | $ | 8 |  |  | $ | 15 |  |  | $ | 15 |  |

[0001564590-18-015820:notes:163]
Restricted Stock Units

[0001564590-18-015820:notes:164]
In fiscal 2018, 2017 and 2016, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service based vesting criteria) such that the PBRSU cliff-vests at the end of either an approximate two year or three year performance period, which began on the date specified in the grant agreement and ends on the last day of the second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted, and will depend upon our Total Stockholder Return (TSR) as compared to an index TSR (each expressed as a growth rate percentage) calculated as of the applicable period end date. The fair values of the PBRSUs were fixed at grant date using a Monte Carlo simulation model and the related aggregate compensation cost of PBRSUs granted in fiscal 2018, 2017 and 2016 of $20 million, $15 million and $20 million, respectively, is being recognized over the shorter of the remaining applicable performance or service periods.

[0001564590-18-015820:notes:165]
As of April 27, 2018 and April 28, 2017, there were approximately 1 million PBRSUs outstanding.

[0001564590-18-015820:notes:166]
The following table summarizes information related to RSUs, including PBRSUs, (in millions, except for fair value):

[0001564590-18-015820:notes:167]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 24, 2015 |  |  | 13 |  |  | $ | 36.58 |  |
| Granted |  |  | 7 |  |  | $ | 29.26 |  |
| Vested |  |  | (5 | ) |  | $ | 37.72 |  |
| Forfeited |  |  | (2 | ) |  | $ | 34.85 |  |
| Outstanding as of April 29, 2016 |  |  | 13 |  |  | $ | 32.46 |  |
| Granted |  |  | 5 |  |  | $ | 24.99 |  |
| Vested |  |  | (5 | ) |  | $ | 32.03 |  |
| Forfeited |  |  | (2 | ) |  | $ | 31.66 |  |
| Outstanding as of April 28, 2017 |  |  | 11 |  |  | $ | 28.81 |  |
| Granted |  |  | 4 |  |  | $ | 39.74 |  |
| Vested |  |  | (5 | ) |  | $ | 30.59 |  |
| Forfeited |  |  | (1 | ) |  | $ | 29.54 |  |
| Outstanding as of April 27, 2018 |  |  | 9 |  |  | $ | 32.91 |  |

[0001564590-18-015820:notes:168]
We primarily use the net share settlement approach upon vesting, where a portion of the shares are withheld as settlement of employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001564590-18-015820:notes:169]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Shares withheld for taxes |  |  | 2 |  |  |  | 2 |  |  |  | 2 |  |
| Fair value of shares withheld |  | $ | 75 |  |  | $ | 48 |  |  | $ | 50 |  |

[0001564590-18-015820:notes:170]
Employee Stock Purchase Plan

[0001564590-18-015820:notes:171]
Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. On September 14, 2017, the ESPP was amended to increase the shares reserved for issuance by approximately 3 million shares of common stock. As of April 27, 2018, 8 million shares were available for issuance. The following table summarizes activity related to the purchase rights issued under the ESPP (in millions):

[0001564590-18-015820:notes:172]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Shares issued under the ESPP |  |  | 4 |  |  |  | 4 |  |  |  | 3 |  |
| Proceeds from issuance of shares |  | $ | 85 |  |  | $ | 80 |  |  | $ | 93 |  |

[0001564590-18-015820:notes:173]
Stock-Based Compensation Expense

[0001564590-18-015820:notes:174]
Stock-based compensation expense is included in the consolidated statements of operations as follows (in millions):

[0001564590-18-015820:notes:175]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Cost of product revenues |  | $ | 3 |  |  | $ | 4 |  |  | $ | 5 |  |
| Cost of hardware maintenance and other services revenues |  |  | 10 |  |  |  | 13 |  |  |  | 19 |  |
| Sales and marketing |  |  | 68 |  |  |  | 84 |  |  |  | 110 |  |
| Research and development |  |  | 49 |  |  |  | 59 |  |  |  | 84 |  |
| General and administrative |  |  | 31 |  |  |  | 35 |  |  |  | 42 |  |
| Total stock-based compensation expense |  | $ | 161 |  |  | $ | 195 |  |  | $ | 260 |  |
| Income tax benefit for stock-based compensation |  | $ | 29 |  |  | $ | 41 |  |  | $ | 53 |  |

[0001564590-18-015820:notes:176]
As of April 27, 2018, total unrecognized compensation expense related to our equity awards was $206 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.2 years.

[0001564590-18-015820:notes:177]
Valuation Assumptions

[0001564590-18-015820:notes:178]
The valuation of RSUs and ESPP purchase rights and the underlying weighted-average assumptions are summarized as follows:

[0001564590-18-015820:notes:179]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| RSUs: |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 1.4 | % |  |  | 1.0 | % |  |  | 0.6 | % |
| Expected dividend yield |  |  | 2.0 | % |  |  | 3.1 | % |  |  | 2.3 | % |
| Weighted-average fair value per share granted |  | $ | 39.74 |  |  | $ | 24.99 |  |  | $ | 29.26 |  |
| ESPP: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 1.4 | % |  |  | 0.8 | % |  |  | 0.5 | % |
| Expected volatility |  |  | 28 | % |  |  | 30 | % |  |  | 27 | % |
| Expected dividend yield |  |  | 2.0 | % |  |  | 3.1 | % |  |  | 2.3 | % |
| Weighted-average fair value per right granted |  | $ | 12.34 |  |  | $ | 7.85 |  |  | $ | 8.18 |  |

[0001564590-18-015820:notes:180]
In connection with our fiscal 2016 acquisition of SolidFire, we assumed all of the then outstanding unvested options to purchase SolidFire common stock and converted those into unvested options to purchase 2 million shares of our common stock. The weighted average assumptions used to value these options, as of the acquisition date, were an expected term of 4.3 years, risk-free interest rate of 1.1%, expected volatility of 31% and expected dividend yield of 3.3%. The weighted average fair value per share of these options was $14.32.

[0001564590-18-015820:notes:181]
Stock Repurchase Program

[0001564590-18-015820:notes:182]
As of April 27, 2018, our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program, including a $4.0 billion increase approved by our Board of Directors in April 2018. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management.

[0001564590-18-015820:notes:183]
The following table summarizes activity related to this program (in millions, except per share amounts):

[0001564590-18-015820:notes:184]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Number of shares repurchased |  |  | 15 |  |  |  | 22 |  |  |  | 33 |  |
| Average price per share |  | $ | 51.57 |  |  | $ | 32.72 |  |  | $ | 28.80 |  |
| Aggregate purchase price |  | $ | 794 |  |  | $ | 705 |  |  | $ | 960 |  |
| Remaining authorization at end of period |  | $ | 4,000 |  |  | $ | 794 |  |  | $ | 1,499 |  |

[0001564590-18-015820:notes:185]
The aggregate purchase price of our stock repurchases for fiscal 2018 consisted of $794 million of open market purchases, of which, $568 million and $226 million was allocated to additional paid-in capital and retained earnings (accumulated deficit), respectively.

[0001564590-18-015820:notes:186]
Since the May 13, 2003 inception of our stock repurchase program through April 27, 2018, we repurchased a total of 284 million shares of our common stock at an average price of $33.85 per share, for an aggregate purchase price of $9.6 billion.

[0001564590-18-015820:notes:187]
Preferred Stock

[0001564590-18-015820:notes:188]
Our Board of Directors has the authority to issue up to 5 million shares of preferred stock and to determine the price, rights, preferences, privileges, and restrictions, including voting rights, of those shares without any further vote or action by the stockholders. No shares of preferred stock were issued or outstanding in any period presented.

[0001564590-18-015820:notes:189]
Dividends

[0001564590-18-015820:notes:190]
The following is a summary of our fiscal 2018, 2017 and 2016 activities related to dividends on our common stock (in millions, except per share amounts).

[0001564590-18-015820:notes:191]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Dividends per share declared |  | $ | 0.80 |  |  | $ | 0.76 |  |  | $ | 0.72 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 106 |  |  | $ | 88 |  |  | $ | 125 |  |
| Dividend payments allocated to retained earnings (accumulated deficit) |  | $ | 108 |  |  | $ | 120 |  |  | $ | 85 |  |

[0001564590-18-015820:notes:192]
On May 23, 2018, we declared a cash dividend of $0.40 per share of common stock, payable on July 25, 2018 to shareholders of record as of the close of business on July 6, 2018. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by the Company to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-18-015820:notes:193]
Accumulated Other Comprehensive Income (Loss)

[0001564590-18-015820:notes:194]
Changes in AOCI by component, net of tax, are summarized below (in millions):

[0001564590-18-015820:notes:195]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 29, 2016 |  | $ | (19 | ) |  | $ | (16 | ) |  | $ | 6 |  |  | $ | (2 | ) |  | $ | (31 | ) |
| OCI before reclassifications, net of tax |  |  | (10 | ) |  |  | 16 |  |  |  | (6 | ) |  |  | 8 |  |  |  | 8 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (6 | ) |  |  | (6 | ) |
| Total OCI |  |  | (10 | ) |  |  | 16 |  |  |  | (6 | ) |  |  | 2 |  |  |  | 2 |  |
| Balance as of April 28, 2017 |  |  | (29 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (29 | ) |
| OCI before reclassifications, net of tax |  |  | 2 |  |  |  | 1 |  |  |  | (43 | ) |  |  | — |  |  |  | (40 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| Total OCI |  |  | 2 |  |  |  | — |  |  |  | (43 | ) |  |  | — |  |  |  | (41 | ) |
| Balance as of April 27, 2018 |  | $ | (27 | ) |  | $ | — |  |  | $ | (43 | ) |  | $ | — |  |  | $ | (70 | ) |

[0001564590-18-015820:notes:196]
The amounts reclassified out of AOCI are as follows (in millions):

[0001564590-18-015820:notes:197]
|  |  | Year Ended |  |  |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |
| Recognized (gains) losses on defined benefit obligations |  | $ | (2 | ) |  | $ | 1 |  |  |  | 2 |  |  | Operating expenses |
| Realized gains on available-for-sale securities |  |  | — |  |  |  | — |  |  |  | (1 | ) |  | Other income (expense), net |
| Realized (gains) losses on cash flow hedges |  |  | — |  |  |  | (6 | ) |  |  | 1 |  |  | Net revenues |
| Total reclassifications |  | $ | (2 | ) |  | $ | (5 | ) |  | $ | 2 |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-18-015820:notes:198]
12. Derivatives and Hedging Activities

[0001564590-18-015820:notes:199]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of our agreements with them. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of April 27, 2018 or April 28, 2017. We did not recognize any gains or losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-18-015820:notes:200]
The notional amount of our outstanding U.S. dollar equivalent foreign currency exchange forward contracts consisted of the following (in millions):

[0001564590-18-015820:notes:201]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Forward contracts sold |  | $ | 115 |  |  | $ | 165 |  |
| Forward contracts purchased |  | $ | 412 |  |  | $ | 257 |  |

[0001564590-18-015820:notes:202]
As of April 27, 2018 and April 28, 2017, there were no instruments designated as cash flow hedges outstanding.

[0001564590-18-015820:notes:203]
The effect of cash flow hedges recognized in net revenues is presented in the consolidated statements of comprehensive income and Note 11 – Stockholders’ Equity.

[0001564590-18-015820:notes:204]
The effect of derivative instruments not designated as hedging instruments recognized in other income (expense), net on our consolidated statements of operations was as follows (in millions):

[0001564590-18-015820:notes:205]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
|  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | (9 | ) |  | $ | 1 |  |  | $ | (4 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-18-015820:notes:206]
13. Restructuring Charges

[0001564590-18-015820:notes:207]
Management has previously approved several restructuring actions to streamline our business, eliminate costs and redirect resources to our highest return activities, including the May 2015 Plan, the March 2016 Plan and the November 2016 Plan, under which we reduced our global workforce by approximately 3%, 11% and 6%, respectively. Charges related to our restructuring plans consisted primarily of employee severance-related costs. We completed all workforce related activities under these plans as of the end of fiscal 2017. The remaining balance under the November 2016 Plan as of April 27, 2018 principally related to lease obligations that will be paid over their remaining terms.

[0001564590-18-015820:notes:208]
Activities related to our restructuring plans are summarized as follows (in millions):

[0001564590-18-015820:notes:209]
|  |  | November 2016 Plan |  |  | March 2016 Plan |  |  | May 2015 Plan |  | Total |  |
| Balance as of April 24, 2015 |  | $ | — |  |  | $ | — |  |  | $ | — |  | $ | — |  |
| Net charges |  |  | — |  |  |  | 80 |  |  |  | 28 |  |  | 108 |  |
| Cash payments |  |  | — |  |  |  | (35 | ) |  |  | (28 | ) |  | (63 | ) |
| Balance as of April 29, 2016 |  |  | — |  |  |  | 45 |  |  |  | — |  |  | 45 |  |
| Net charges |  |  | 52 |  |  |  | — |  |  |  | — |  |  | 52 |  |
| Cash payments |  |  | (39 | ) |  |  | (45 | ) |  |  | — |  |  | (84 | ) |
| Balance as of April 28, 2017 |  |  | 13 |  |  |  | — |  |  |  | — |  |  | 13 |  |
| Net charges |  |  | — |  |  |  | — |  |  |  | — |  |  | — |  |
| Cash payments |  |  | (7 | ) |  |  | — |  |  |  | — |  |  | (7 | ) |
| Balance as of April 27, 2018 |  | $ | 6 |  |  | $ | — |  |  | $ | — |  | $ | 6 |  |

[0001564590-18-015820:notes:210]
Liabilities for our restructuring activities are included in accrued expenses in our consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-015820:notes:211]
14. Income Taxes

[0001564590-18-015820:notes:212]
Income before income taxes is as follows (in millions):

[0001564590-18-015820:notes:213]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Domestic |  | $ | 565 |  |  | $ | 206 |  |  | $ | 88 |  |
| Foreign |  |  | 601 |  |  |  | 459 |  |  |  | 257 |  |
| Total |  | $ | 1,166 |  |  | $ | 665 |  |  | $ | 345 |  |

[0001564590-18-015820:notes:214]
Domestic income before taxes is lower than foreign income before taxes due to significant domestic expenses related to stock-based compensation.

[0001564590-18-015820:notes:215]
The provision for income taxes consists of the following (in millions):

[0001564590-18-015820:notes:216]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 764 |  |  | $ | 22 |  |  | $ | 180 |  |
| State |  |  | 10 |  |  |  | 3 |  |  |  | 14 |  |
| Foreign |  |  | 39 |  |  |  | 41 |  |  |  | 35 |  |
| Total current |  |  | 813 |  |  |  | 66 |  |  |  | 229 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 250 |  |  |  | 75 |  |  |  | (91 | ) |
| State |  |  | 26 |  |  |  | 18 |  |  |  | (17 | ) |
| Foreign |  |  | 1 |  |  |  | (3 | ) |  |  | (5 | ) |
| Total deferred |  |  | 277 |  |  |  | 90 |  |  |  | (113 | ) |
| Provision for income taxes |  | $ | 1,090 |  |  | $ | 156 |  |  | $ | 116 |  |

[0001564590-18-015820:notes:217]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0001564590-18-015820:notes:218]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Tax computed at federal statutory rate |  | $ | 356 |  |  | $ | 233 |  |  | $ | 121 |  |
| State income taxes, net of federal benefit |  |  | 17 |  |  |  | 9 |  |  |  | (4 | ) |
| Foreign earnings in lower tax jurisdictions |  |  | (108 | ) |  |  | (100 | ) |  |  | (81 | ) |
| Stock-based compensation |  |  | (23 | ) |  |  | 16 |  |  |  | 13 |  |
| Research and development credits |  |  | (10 | ) |  |  | (8 | ) |  |  | (14 | ) |
| Resolution of income tax examinations |  |  | — |  |  |  | — |  |  |  | 20 |  |
| Domestic production activities deduction |  |  | (7 | ) |  |  | (4 | ) |  |  | (10 | ) |
| Tax charge from integration of intellectual property from the SolidFire acquisition |  |  | — |  |  |  | — |  |  |  | 64 |  |
| Tax rate changes |  |  | 126 |  |  |  | 5 |  |  |  | 1 |  |
| Transition tax |  |  | 732 |  |  |  | — |  |  |  | — |  |
| Other |  |  | 7 |  |  |  | 5 |  |  |  | 6 |  |
| Provision for income taxes |  | $ | 1,090 |  |  | $ | 156 |  |  | $ | 116 |  |

[0001564590-18-015820:notes:219]
We generated foreign earnings in lower tax jurisdictions primarily related to income from our European operations which are headquartered in the Netherlands.

[0001564590-18-015820:notes:220]
On December 22, 2017, the 2017 Tax Reform Reconciliation Act, originally referred to as the TCJA was enacted into law. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate, the imposition of a one-time transition tax on deferred foreign earnings, and a shift to a modified territorial tax regime. Given the timing and pace of regulatory guidance, the Securities and Exchange Commission issued Staff Accounting Bulletin (SAB) 118, which allows for the recording of provisional amounts related to U.S. tax reform and subsequent related adjustments during a measurement period.

[0001564590-18-015820:notes:221]
As of April 27, 2018, we have not fully completed the accounting for the tax impacts of the TCJA and, in connection with SAB 118, have recorded provisional tax charges based on reasonable estimates for the remeasurement of deferred tax assets and liabilities based on the new corporate rate and for the transition tax on our total post-1986 foreign earnings and profits (E&P). The TCJA also includes provisions for a global minimum tax on intangible low-taxed income (GMT) of foreign subsidiaries, a base erosion anti-abuse tax on certain intercompany payments, and beneficial tax treatment for foreign derived intangible income. These provisions will be effective for us beginning in our fiscal 2019. We will continue to refine provisional balances and make adjustments during the measurement period based on the issuance of further regulatory guidance, changes in interpretations, and the collection and analysis of additional information; these adjustments could be material to our financial statements. The provisional amounts recorded during the current year are explained below.

[0001564590-18-015820:notes:222]
The TCJA decreased the U.S. federal corporate tax rate from 35% to 21% as of January 1, 2018.  For fiscal 2018, this decrease results in a blended statutory tax rate of 30.5%. As a result of the tax rate change, we remeasured our deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future periods. We recorded $126 million of tax expense for fiscal 2018 related to all tax rate changes. The final remeasurement impact could vary from the provisional amount if actual future activities impacting deferred tax balances differ from our estimates.

[0001564590-18-015820:notes:223]
The TCJA imposes a mandatory, one-time transition tax on accumulated foreign E&P not previously subject to U.S. income tax at a rate of 15.5% on earnings to the extent of foreign cash and other liquid assets, and 8% on the remaining earnings. For fiscal 2018, we recorded $732 million of tax expense for the estimated U.S. federal and state income tax impacts of the transition tax. Our estimates may change with further guidance from U.S. federal and state tax authorities or other regulatory bodies and additional analyses that we expect to complete during the measurement period with respect to various components of the computations. We intend to make the election to pay the one-time transition tax over a period of eight years.

[0001564590-18-015820:notes:224]
Under the TCJA, the GMT provision taxes foreign income in excess of a deemed return on tangible assets of foreign corporations. Under U.S. GAAP, companies are allowed to make an accounting policy election to either (i) account for GMT as a component of tax expense in the period in which a company is subject to the rules (the period cost method), or (ii) account for GMT in a company’s measurement of deferred taxes (the deferred method). Because of the complexity of the new tax rules, we are continuing to evaluate this provision and the application of ASC 740 and have not yet made an accounting policy election.

[0001564590-18-015820:notes:225]
During fiscal 2017, we adopted a new accounting standard that simplifies stock-based compensation income tax accounting and presentation within the financial statements and recorded a tax charge of $18 million following the post-adoption rules which require that all excess tax benefits and deficiencies from stock-based compensation be recognized as a component of income tax expense.

[0001564590-18-015820:notes:226]
During fiscal 2016, we acquired SolidFire and recorded a tax charge of $64 million related to the integration of SolidFire intellectual property into our worldwide operations.

[0001564590-18-015820:notes:227]
The components of our deferred tax assets and liabilities are as follows (in millions):

[0001564590-18-015820:notes:228]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Reserves and accruals |  | $ | 57 |  |  | $ | 149 |  |
| Net operating loss and credit carryforwards |  |  | 131 |  |  |  | 104 |  |
| Stock-based compensation |  |  | 22 |  |  |  | 49 |  |
| Deferred revenue |  |  | 211 |  |  |  | 329 |  |
| Other |  |  | 29 |  |  |  | 32 |  |
| Gross deferred tax assets |  |  | 450 |  |  |  | 663 |  |
| Valuation allowance |  |  | (109 | ) |  |  | (94 | ) |
| Deferred tax assets, net of valuation allowance |  |  | 341 |  |  |  | 569 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Prepaids and accruals |  |  | 2 |  |  |  | 3 |  |
| Acquired intangibles |  |  | 29 |  |  |  | 36 |  |
| Property and equipment |  |  | 25 |  |  |  | 4 |  |
| Other |  |  | 16 |  |  |  | 2 |  |
| Total deferred tax liabilities |  |  | 72 |  |  |  | 45 |  |
| Deferred tax assets, net of valuation allowance and deferred tax liabilities |  | $ | 269 |  |  | $ | 524 |  |

[0001564590-18-015820:notes:229]
The valuation allowance increased by $15 million in fiscal 2018. The increase is mainly attributable to corresponding changes in deferred tax assets, primarily foreign tax credit carryforwards and certain state tax credit carryforwards.

[0001564590-18-015820:notes:230]
As of April 27, 2018, we have federal net operating loss and tax credit carryforwards of approximately $7 million and $3 million, respectively. In addition, we have gross state net operating loss and tax credit carryforwards of $29 million and $146 million, respectively. The majority of the state credit carryforwards are California research credits which are offset by a valuation allowance as we believe it is more likely than not that these credits will not be utilized. We also have $4 million of foreign net operating losses, and $28 million of foreign tax credit carryforwards generated by our Dutch subsidiary which are fully offset by a valuation allowance. Certain acquired net operating loss and credit carryforwards are subject to an annual limitation under Internal Revenue Code Section 382, but are expected to be realized with the exception of those which have a valuation allowance. The federal, state, and foreign net operating loss carryforwards and credits will expire in various years from fiscal 2019 through 2038. The California research credit and Dutch foreign tax credit carryforwards do not expire.

[0001564590-18-015820:notes:231]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001564590-18-015820:notes:232]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Balance at beginning of period |  | $ | 218 |  |  | $ | 216 |  |  | $ | 272 |  |
| Additions based on tax positions related to the current year |  |  | 131 |  |  |  | 7 |  |  |  | 14 |  |
| Additions for tax positions of prior years |  |  | — |  |  |  | 7 |  |  |  | 21 |  |
| Decreases for tax positions of prior years |  |  | (1 | ) |  |  | — |  |  |  | (39 | ) |
| Settlements |  |  | — |  |  |  | (12 | ) |  |  | (52 | ) |
| Balance at end of period |  | $ | 348 |  |  | $ | 218 |  |  | $ | 216 |  |

[0001564590-18-015820:notes:233]
As of April 27, 2018, we had $348 million of gross unrecognized tax benefits, of which $318 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $294 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized. As a result of U.S. tax reform, we recorded provisional gross unrecognized tax benefits of $114 million.

[0001564590-18-015820:notes:234]
We recognized accrued interest and penalties related to unrecognized tax benefits in the income tax provision of approximately $5 million in each of fiscal 2018 and 2017, and $2 million in fiscal 2016. Accrued interest and penalties of $22 million and $16 million were recorded in the consolidated balance sheets as of April 27, 2018 and April 28, 2017, respectively.

[0001564590-18-015820:notes:235]
The tax years that remain subject to examination for our major tax jurisdictions are shown below:

[0001564590-18-015820:notes:236]
Fiscal Years Subject to Examination for Major Tax Jurisdictions at April 27, 2018

[0001564590-18-015820:notes:237]
| 2012 — 2018 |  | United States — federal income tax |
| 2008 — 2018 |  | United States — state and local income tax |
| 2012 — 2018 |  | Australia |
| 2013 — 2018 |  | Germany |
| 2007 — 2018 |  | India |
| 2012 — 2018 |  | Japan |
| 2013 — 2018 |  | The Netherlands |
| 2015 — 2018 |  | United Kingdom |
| 2010 — 2018 |  | Canada |

[0001564590-18-015820:notes:238]
We are currently undergoing various income tax audits in the U.S. and several foreign tax jurisdictions. Transfer pricing calculations are key issues under these audits and are often subject to dispute and appeals.

[0001564590-18-015820:notes:239]
In October 2015, the Internal Revenue Service (IRS) completed the examination of our fiscal 2008 to 2010 income tax returns and made certain agreed-to transfer pricing adjustments. During fiscal 2016, we recorded charges totaling $23 million attributable to audit settlements and the related re-measurement of uncertain tax positions for tax years subject to future audits.  The IRS commenced the examination of our federal income tax returns for our fiscal years 2012 and 2013 in August 2016. In addition, we are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal 2001, in that we have carryforward attributes from these years that could be subject to adjustment in the tax years of utilization.

[0001564590-18-015820:notes:240]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for such withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012. In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). Parties were heard before the court in October 2017. During March 2018, the Advocate General issued an opinion which was largely in favor of NetApp, however, the CJEU is not bound by the opinion of the Advocate General. It is expected that the preliminary ruling will be issued during our fiscal year 2019. Once a ruling has been issued by the CJEU, it will be reviewed and may be subjected to additional briefing by the DHC. Once complete, the DHC will then issue its final decision. We expect this decision to be complete sometime during our fiscal year 2019 or 2020.

[0001564590-18-015820:notes:241]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. As a result of uncertainties regarding tax audits and their possible outcomes, an estimate of the range of possible impacts to unrecognized tax benefits in the next twelve months cannot be made at this time.

[0001564590-18-015820:notes:242]
Prior to the passage of the TCJA, we had not provided U.S. income taxes and foreign withholding taxes on the undistributed earnings of foreign subsidiaries because we had intended to indefinitely reinvest such earnings outside the U.S. The TCJA imposes a one-time transition tax on substantially all accumulated foreign earnings through December 31, 2017 and generally allows companies to make distributions of foreign earnings without incurring additional federal taxes. As a part of the provisional estimates recorded during fiscal 2018, we considered the impacts of the TCJA and reviewed our projected global cash requirements, and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested. As of April 27, 2018, we estimate the unrecognized deferred tax liability related to the earnings we expect to be indefinitely reinvested to be immaterial. We will continue to monitor our plans to indefinitely reinvest undistributed earnings of foreign subsidiaries and will assess the related unrecognized deferred tax liability considering our ongoing projected global cash requirements, tax consequences associated with repatriation and any U.S. or foreign government programs designed to influence remittances.


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-015820:notes:243]
15. Net Income per Share

[0001564590-18-015820:notes:244]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0001564590-18-015820:notes:245]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 76 |  |  | $ | 509 |  |  | $ | 229 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 268 |  |  |  | 275 |  |  |  | 294 |  |
| Dilutive impact of employee equity award plans |  |  | 8 |  |  |  | 6 |  |  |  | 3 |  |
| Shares used in diluted computation |  |  | 276 |  |  |  | 281 |  |  |  | 297 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.28 |  |  | $ | 1.85 |  |  | $ | 0.78 |  |
| Diluted |  | $ | 0.28 |  |  | $ | 1.81 |  |  | $ | 0.77 |  |

[0001564590-18-015820:notes:246]
Potential shares from outstanding employee equity awards totaling 1 million, 6 million and 12 million for fiscal 2018, 2017 and 2016, respectively, were excluded from the diluted net income per share calculations as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-015820:notes:247]
16. Segment, Geographic, and Significant Customer Information

[0001564590-18-015820:notes:248]
We operate in one industry segment: the design, manufacturing, marketing, and technical support of high-performance storage and data management solutions. We conduct business globally, and our sales and support activities are managed on a geographic basis. Our management reviews financial information presented on a consolidated basis, accompanied by disaggregated information it receives from our internal management system about revenues by geographic region, based on the location from which the customer relationship is managed, for purposes of allocating resources and evaluating financial performance. We do not allocate costs of revenues, research and development, sales and marketing, or general and administrative expenses to our geographic regions in this internal management reporting because management does not review operations or operating results, or make planning decisions, below the consolidated entity level.

[0001564590-18-015820:notes:249]
Summarized revenues by geographic region based on information from our internal management system and utilized by our Chief Executive Officer, who is considered our Chief Operating Decision Maker, is as follows (in millions):

[0001564590-18-015820:notes:250]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| United States, Canada and Latin America (Americas) |  | $ | 3,184 |  |  | $ | 3,077 |  |  | $ | 3,067 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 1,883 |  |  |  | 1,712 |  |  |  | 1,757 |  |
| Asia Pacific (APAC) |  |  | 844 |  |  |  | 730 |  |  |  | 722 |  |
| Net revenues |  | $ | 5,911 |  |  | $ | 5,519 |  |  | $ | 5,546 |  |

[0001564590-18-015820:notes:251]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $2,861 million, $2,774 million and $2,753 million during fiscal 2018, 2017 and 2016, respectively.

[0001564590-18-015820:notes:252]
The majority of our assets, excluding cash, cash equivalents, short-term investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents and short-term investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0001564590-18-015820:notes:253]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| U.S. |  | $ | 853 |  |  | $ | 425 |  |
| International |  |  | 4,538 |  |  |  | 4,496 |  |
| Total |  | $ | 5,391 |  |  | $ | 4,921 |  |

[0001564590-18-015820:notes:254]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment information for geographic areas based on the physical location of the assets (in millions):

[0001564590-18-015820:notes:255]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| U.S. |  | $ | 566 |  |  | $ | 593 |  |
| International |  |  | 190 |  |  |  | 206 |  |
| Total |  | $ | 756 |  |  | $ | 799 |  |

[0001564590-18-015820:notes:256]
The following customers, each of which is a distributor, accounted for 10% or more of our net revenues:

[0001564590-18-015820:notes:257]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Arrow Electronics, Inc. |  |  | 23 | % |  |  | 22 | % |  |  | 22 | % |
| Tech Data Corporation (previously presented as Avnet, Inc.) |  |  | 19 | % |  |  | 20 | % |  |  | 19 | % |

[0001564590-18-015820:notes:258]
The following customers accounted for 10% or more of accounts receivable:

[0001564590-18-015820:notes:259]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Arrow Electronics, Inc. |  |  | 17 | % |  |  | 15 | % |
| Tech Data Corporation (previously presented as Avnet, Inc.) |  |  | 17 | % |  |  | 14 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-18-015820:notes:260]
17. Employee Benefits and Deferred Compensation

[0001564590-18-015820:notes:261]
Employee 401(k) Plan

[0001564590-18-015820:notes:262]
Our 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit. We match 100% of the first 2% of eligible earnings an employee contributes to the 401(k) Plan, and then match 50% of the next 4% of eligible earnings an employee contributes. An employee receives the full 4% match when he/she contributes at least 6% of his/her eligible earnings, up to a maximum calendar year matching contribution of $6,000. Our employer matching contributions to the 401(k) Plan were as follows (in millions):

[0001564590-18-015820:notes:263]
|  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| 401(k) matching contributions |  | $ | 28 |  |  | $ | 30 |  |  | $ | 35 |  |

[0001564590-18-015820:notes:264]
Deferred Compensation Plan

[0001564590-18-015820:notes:265]
We have a non-qualified deferred compensation plan that allows a group of employees within the U.S. to contribute base salary and commissions or incentive compensation on a tax deferred basis in excess of the IRS limits imposed on 401(k) plans. The marketable securities related to these investments are held in a Rabbi Trust. The related deferred compensation plan assets and liabilities under the non-qualified deferred compensation plan were as follows (in millions):

[0001564590-18-015820:notes:266]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Deferred compensation plan assets |  | $ | 31 |  |  | $ | 31 |  |
| Deferred compensation liabilities reported as: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 6 |  |  | $ | 7 |  |
| Other long-term liabilities |  | $ | 25 |  |  | $ | 24 |  |

[0001564590-18-015820:notes:267]
Postretirement Health Care Plan

[0001564590-18-015820:notes:268]
Certain of our executive officers are eligible to participate in our Executive Retirement Medical Plan (the ERM Plan). The ERM Plan provides, upon retirement, medical benefits beyond the COBRA maximum benefit period to a defined group of senior executives based on minimum age, years of service and position. The ERM Plan was unfunded as of April 28, 2017 and April 27, 2018, and there is no minimum funding requirement under the ERM Plan.

[0001564590-18-015820:notes:269]
In November 2016, we made certain amendments to the ERM Plan, which prior to amendment, provided group health insurance benefits to eligible retirees. Effective January 1, 2017, the amended ERM Plan provides each eligible retiree with a capped reimbursement of premiums for the period from January 1, 2017 through December 31, 2019. During the period from December 31, 2019 through December 31, 2021, participants in the ERM Plan will be eligible to receive a lump sum cash payment equal to two years of projected health care costs, or a prorated portion thereof, pursuant to the methodology set forth in the ERM Plan. Such payment will be made by us outside the ERM Plan as the ERM Plan is expected to terminate on December 31, 2019.

[0001564590-18-015820:notes:270]
These plan amendments resulted in a prior service credit adjustment, with the following impacts to our consolidated financial statements in fiscal 2017 (in millions):

[0001564590-18-015820:notes:271]
| Decrease in other long-term liabilities |  | $ | 23 |  |
| Decrease in deferred tax assets |  | $ | 9 |  |
| Other comprehensive income, net of taxes |  | $ | 14 |  |

[0001564590-18-015820:notes:272]
Other Defined Benefit Plans

[0001564590-18-015820:notes:273]
We maintain various defined benefit plans to provide termination and postretirement benefits to certain eligible employees outside of the U.S. We also provide disability benefits to certain eligible employees in the U.S. Eligibility is determined based on the terms of our plans and local statutory requirements.

[0001564590-18-015820:notes:274]
Funded Status

[0001564590-18-015820:notes:275]
The funded status of our postretirement health care and other defined benefit plans, which is recognized in other long-term liabilities in our consolidated balance sheets, was as follows (in millions):

[0001564590-18-015820:notes:276]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Fair value of plan assets |  | $ | 25 |  |  | $ | 23 |  |
| Benefit obligations |  |  | (53 | ) |  |  | (50 | ) |
| Unfunded obligations |  | $ | (28 | ) |  | $ | (27 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-015820:notes:277]
18. Commitments and Contingencies

[0001564590-18-015820:notes:278]
Operating Leases

[0001564590-18-015820:notes:279]
We lease various equipment, vehicles and office space in the U.S. and internationally.

[0001564590-18-015820:notes:280]
Future annual minimum lease payments under all non-cancelable operating leases with an initial term in excess of one year as of April 27, 2018 are as follows (in millions):

[0001564590-18-015820:notes:281]
|  |  |  | 2019 |  |  |  | 2020 |  |  |  | 2021 |  |  |  | 2022 |  |  |  | 2023 |  |  | Thereafter |  |  | Total |  |
| Operating lease commitments |  | $ | 55 |  |  | $ | 46 |  |  | $ | 34 |  |  | $ | 22 |  |  | $ | 13 |  |  | $ | 23 |  |  | $ | 193 |  |

[0001564590-18-015820:notes:282]
Rent expense under all cancelable and non-cancelable operating leases was $59 million, $64 million and $69 million in fiscal 2018, 2017 and 2016, respectively.

[0001564590-18-015820:notes:283]
Purchase Orders and Other Commitments

[0001564590-18-015820:notes:284]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of April 27, 2018, we had $374 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 27, 2018 and April 28, 2017, such liability amounted to $14 million and $10 million, respectively, and is included in accrued expenses in our consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-18-015820:notes:285]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of April 27, 2018, we had $7 million in construction related obligations and $193 million in other purchase obligations.

[0001564590-18-015820:notes:286]
Financing Guarantees

[0001564590-18-015820:notes:287]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $67 million, $183 million and $243 million of receivables during fiscal 2018, 2017 and 2016, respectively.

[0001564590-18-015820:notes:288]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-18-015820:notes:289]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of April 27, 2018, and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-18-015820:notes:290]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of April 27, 2018, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0001564590-18-015820:notes:291]
Indemnification Agreements

[0001564590-18-015820:notes:292]
We enter into standard indemnification agreements in the ordinary course of business. Pursuant to these agreements, we agree to defend and indemnify other parties, primarily our customers or business partners or subcontractors, for damages and reasonable costs incurred in any suit or claim brought against them alleging that our products sold to them infringe any U.S. patent, copyright, trade secret, or similar right. If a product becomes the subject of an infringement claim, we may, at our option: (i) replace the product with another non-infringing product that provides substantially similar performance; (ii) modify the infringing product so that it no longer infringes but remains functionally equivalent; (iii) obtain the right for the customer to continue using the product at our expense and for the reseller to continue selling the product; (iv) take back the infringing product and refund to the customer the purchase price paid less depreciation amortized on a straight-line basis. We have not been required to make material payments pursuant to these provisions historically. We have not recorded any liability at April 27, 2018 related to these guarantees since the maximum amount of potential future payments under such guarantees, indemnities and warranties is not determinable, other than as described above.

[0001564590-18-015820:notes:293]
Legal Contingencies

[0001564590-18-015820:notes:294]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-18-015820:notes:295]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-18-015820:notes:296]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of April 27, 2018 related to such matters.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001564590-18-015820:notes:297]
Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights.
