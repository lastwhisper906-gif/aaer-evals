# NTAP 8-K — 0001564590-18-014236 filed 2018-05-23

## item codes, every 8-K on or before 2018-06-19

- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2018-06-19

- none on or before 2018-06-19

## item 2.02 — earnings release, exhibit 99.1

[0001564590-18-014236:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-18-014236:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-18-014236:8k_2_02:3]
Exhibit 99.1

[0001564590-18-014236:8k_2_02:4]
NetApp Reports Fourth Quarter and Fiscal Year 2018 Results

[0001564590-18-014236:8k_2_02:5]
Net Revenues of $1.64 Billion for the Fourth Quarter and $5.91 Billion for Fiscal Year 2018

[0001564590-18-014236:8k_2_02:6]
| • | Net revenue for fiscal year 2018 increased 7% year-over-year |  |

[0001564590-18-014236:8k_2_02:7]
| • | Product revenue for fiscal year 2018 grew 15% year-over-year |  |

[0001564590-18-014236:8k_2_02:8]
| • | All-flash array annualized net revenue run rate of $2.4 billion increased 43% year-over-year |  |

[0001564590-18-014236:8k_2_02:9]
| • | Free Cash Flow was 23% of revenue for fiscal year 2018 and increased 64% year-over-year |  |

[0001564590-18-014236:8k_2_02:10]
| • | $1.01 billion returned to shareholders in share repurchases and cash dividends in fiscal year 2018 |  |

[0001564590-18-014236:8k_2_02:11]
Sunnyvale, Calif.—May 23, 2018—NetApp (NASDAQ: NTAP) today reported financial results for the fourth quarter and fiscal year 2018, ended April 27, 2018.

[0001564590-18-014236:8k_2_02:12]
“The fourth quarter marked a great finish to a strong year. We successfully pivoted to the growth areas of the market, expanded our opportunity with HCI and new cloud partnerships, and improved operational discipline to deliver sustained and profitable growth,” said George Kurian, chief executive officer. “Clear innovation leadership, coupled with strong go-to-market execution, has enabled us to gain share in all key product categories and in every geography. Our momentum with customers continues to accelerate and we are increasingly viewed as a critical strategic partner for data-driven digital transformations.”

[0001564590-18-014236:8k_2_02:13]
Fourth Quarter Fiscal Year 2018 Financial Results

[0001564590-18-014236:8k_2_02:14]
| • | Net Revenues: $1.64 billion, increased 11% year-over-year from $1.48 billion in the fourth quarter of fiscal 2017 |  |

[0001564590-18-014236:8k_2_02:15]
| • | Net Income: GAAP net income of $271 million, compared to GAAP net income of $190 million in the fourth quarter of fiscal 2017; non-GAAP net income1 of $288 million, compared to non-GAAP net income of $239 million in the fourth quarter of fiscal 2017 |  |

[0001564590-18-014236:8k_2_02:16]
| • | Earnings per Share: GAAP earnings per share2 of $0.99 compared to GAAP earnings per share of $0.68 in the fourth quarter of fiscal 2017; non-GAAP earnings per share of $1.05, compared to non-GAAP earnings per share of $0.86 in the fourth quarter of fiscal 2017 |  |

[0001564590-18-014236:8k_2_02:17]
| • | Cash, Cash Equivalents and Investments: $5.4 billion at the end of fiscal 2018 |  |

[0001564590-18-014236:8k_2_02:18]
| • | Cash from Operations: $494 million, compared to $365 million in the fourth quarter of fiscal 2017 |  |

[0001564590-18-014236:8k_2_02:19]
| • | Share Repurchase and Dividend: Returned $397 million to shareholders through share repurchases and a cash dividend |  |

[0001564590-18-014236:8k_2_02:20]
Fiscal Year 2018 Financial Results

[0001564590-18-014236:8k_2_02:21]
| • | Net Revenues: $5.91 billion, increased 7% year-over-year from $5.52 billion in fiscal 2017 |  |

[0001564590-18-014236:8k_2_02:22]
| • | Net Income: GAAP net income of $76 million*, compared to GAAP net income of $509 million in fiscal 2017; non-GAAP net income of $957 million, compared to non-GAAP net income of $768 million in fiscal 2017 |  |

[0001564590-18-014236:8k_2_02:23]
| • | Earnings per Share: GAAP earnings per share of $0.28*, compared to GAAP earnings per share of $1.81 in fiscal 2017; non-GAAP earnings per share of $3.47, compared to non-GAAP earnings per share of $2.73 in fiscal 2017 |  |

[0001564590-18-014236:8k_2_02:24]
| • | Cash from Operations: $1.48 billion, compared to $986 million in fiscal year 2017 |  |

[0001564590-18-014236:8k_2_02:25]
| • | Share Repurchase and Dividend: Returned $1.01 billion to shareholders through share repurchases and cash dividends |  |

[0001564590-18-014236:8k_2_02:26]
*On December 22, 2017, The 2017 Tax Reform Reconciliation Act was enacted into law. This tax reform legislation contains several key tax provisions that affected the company, including a one-time mandatory transition tax on accumulated foreign earnings and a reduction of the U.S. corporate income tax rate to 21% effective January 1, 2018, among others. GAAP net income in fiscal year 2018 was impacted by a resulting one-time charge of approximately $850 million.

[0001564590-18-014236:8k_2_02:27]
First Quarter Fiscal Year 2019 Financial Outlook

[0001564590-18-014236:8k_2_02:28]
The Company provided the following financial guidance for the first quarter of fiscal year 2019:

[0001564590-18-014236:8k_2_02:29]
| •Net revenues are expected to be in the range of $1.365 billion to $1.465 billion |  |  |
|  | GAAP | Non-GAAP |
| •Earnings per share is expected to be in the range of: | $0.53-$0.59 | $0.76-$0.82 |

[0001564590-18-014236:8k_2_02:30]
Full Fiscal Year 2019 Financial Outlook

[0001564590-18-014236:8k_2_02:31]
The Company provided the following financial guidance for the full fiscal year 2019:

[0001564590-18-014236:8k_2_02:32]
| •Net revenues are expected to grow in the mid-single digits |  |  |
|  | GAAP | Non-GAAP |
| •Consolidated gross margins are expected to be: | ~62% | ~63% |
| •Operating margins are expected to be in the range of: | 18%-19% | 20%-21% |

[0001564590-18-014236:8k_2_02:33]
| •Effective tax rate is expected to be: | ~22% | ~18% |

[0001564590-18-014236:8k_2_02:34]
Dividend

[0001564590-18-014236:8k_2_02:35]
| • | In the first quarter of fiscal year 2019, the Company will double its quarterly dividend to $0.40 per share. The quarterly dividend will be paid on July 25, 2018 to shareholders of record as of the close of business on July 6, 2018. |

[0001564590-18-014236:8k_2_02:36]
Fourth Quarter Fiscal Year 2018 Business Highlights

[0001564590-18-014236:8k_2_02:37]
| • | Ducati partners with NetApp to drive digital transformation of motorcycle racing in the MotoGP World Championship, counting on the NetApp™ Data Fabric as it participates in 19 races in 15 countries on 5 continents around the globe. Ducati will use NetApp technologies to modernize its IT and data protection infrastructure, enhancing data protection and security. |

[0001564590-18-014236:8k_2_02:38]
| • | NetApp helps customers build General Data Protection Regulation (GDPR)–compliant processes. NetApp helps customers integrate NetApp and partner technologies to enable them to identify where personal information is held, improve their data management and governance processes, and build GDPR-compliant processes into their day-to-day activities. |

[0001564590-18-014236:8k_2_02:39]
| • | NetApp is one of the few data management companies with a dedicated healthcare solutions team and is uniquely positioned to assist healthcare organizations providing secure access to critical information, so customers can quickly accelerate workloads and analytics and can integrate cloud data services with industry-leading simplicity and efficiency. |

[0001564590-18-014236:8k_2_02:40]
Webcast and Conference Call Information

[0001564590-18-014236:8k_2_02:41]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:00 p.m. Pacific Time today.

[0001564590-18-014236:8k_2_02:42]
About NetApp

[0001564590-18-014236:8k_2_02:43]
NetApp is the data authority for hybrid cloud. We provide a full range of hybrid cloud data services that simplify management of applications and data across cloud and on-premises environments to accelerate digital transformation. Together with our partners, we empower global organizations to unleash the full potential of their data to expand customer touchpoints, foster greater innovation, and optimize their operations. For more information, visit www.netapp.com. #DataDriven

[0001564590-18-014236:8k_2_02:44]
###

[0001564590-18-014236:8k_2_02:45]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-18-014236:8k_2_02:46]
Footnotes

[0001564590-18-014236:8k_2_02:47]
1Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale of properties, and (h) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-18-014236:8k_2_02:48]
2GAAP earnings per share and non-GAAP earnings per share are calculated using the diluted number of shares.

[0001564590-18-014236:8k_2_02:49]
NetApp Usage of Non-GAAP Financial Information

[0001564590-18-014236:8k_2_02:50]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-18-014236:8k_2_02:51]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-18-014236:8k_2_02:52]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-18-014236:8k_2_02:53]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-18-014236:8k_2_02:54]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-18-014236:8k_2_02:55]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based

[0001564590-18-014236:8k_2_02:56]
compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-18-014236:8k_2_02:57]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-18-014236:8k_2_02:58]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-18-014236:8k_2_02:59]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-18-014236:8k_2_02:60]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-18-014236:8k_2_02:61]
G. Gains/losses on the sale of properties. These are gains/losses from the sale of our properties. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-18-014236:8k_2_02:62]
H. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual properties from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-18-014236:8k_2_02:63]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or

[0001564590-18-014236:8k_2_02:64]
principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-18-014236:8k_2_02:65]
NETAPP, INC.

[0001564590-18-014236:8k_2_02:66]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-18-014236:8k_2_02:67]
(In millions)

[0001564590-18-014236:8k_2_02:68]
(Unaudited)

[0001564590-18-014236:8k_2_02:69]
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,391 |  |  | $ | 4,921 |  |
| Accounts receivable |  |  | 1,009 |  |  |  | 731 |  |
| Inventories |  |  | 126 |  |  |  | 163 |  |
| Other current assets |  |  | 330 |  |  |  | 383 |  |
| Total current assets |  |  | 6,856 |  |  |  | 6,198 |  |
| Property and equipment, net |  |  | 756 |  |  |  | 799 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,833 |  |  |  | 1,815 |  |
| Other non-current assets |  |  | 420 |  |  |  | 681 |  |
| Total assets |  | $ | 9,865 |  |  | $ | 9,493 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 609 |  |  | $ | 347 |  |
| Accrued expenses |  |  | 825 |  |  |  | 782 |  |
| Commercial paper notes |  |  | 385 |  |  |  | 500 |  |
| Current portion of long-term debt |  |  | — |  |  |  | 749 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,804 |  |  |  | 1,744 |  |
| Total current liabilities |  |  | 3,623 |  |  |  | 4,122 |  |
| Long-term debt |  |  | 1,541 |  |  |  | 744 |  |
| Other long-term liabilities |  |  | 961 |  |  |  | 249 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,673 |  |  |  | 1,598 |  |
| Total liabilities |  |  | 7,798 |  |  |  | 6,713 |  |
| Stockholders' equity |  |  | 2,067 |  |  |  | 2,780 |  |
| Total liabilities and stockholders' equity |  | $ | 9,865 |  |  | $ | 9,493 |  |

[0001564590-18-014236:8k_2_02:70]
NETAPP, INC.

[0001564590-18-014236:8k_2_02:71]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-18-014236:8k_2_02:72]
(In millions, except per share amounts)

[0001564590-18-014236:8k_2_02:73]
(Unaudited)

[0001564590-18-014236:8k_2_02:74]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,011 |  |  | $ | 852 |  |  | $ | 3,461 |  |  | $ | 3,006 |  |
| Software maintenance |  |  | 247 |  |  |  | 242 |  |  |  | 958 |  |  |  | 965 |  |
| Hardware maintenance and other services |  |  | 383 |  |  |  | 387 |  |  |  | 1,492 |  |  |  | 1,548 |  |
| Net revenues |  |  | 1,641 |  |  |  | 1,481 |  |  |  | 5,911 |  |  |  | 5,519 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 500 |  |  |  | 444 |  |  |  | 1,738 |  |  |  | 1,614 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | 6 |  |  |  | 25 |  |  |  | 28 |  |
| Cost of hardware maintenance and other services |  |  | 113 |  |  |  | 118 |  |  |  | 449 |  |  |  | 487 |  |
| Total cost of revenues |  |  | 619 |  |  |  | 568 |  |  |  | 2,212 |  |  |  | 2,129 |  |
| Gross profit |  |  | 1,022 |  |  |  | 913 |  |  |  | 3,699 |  |  |  | 3,390 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 461 |  |  |  | 405 |  |  |  | 1,729 |  |  |  | 1,633 |  |
| Research and development |  |  | 203 |  |  |  | 191 |  |  |  | 783 |  |  |  | 779 |  |
| General and administrative |  |  | 71 |  |  |  | 70 |  |  |  | 280 |  |  |  | 271 |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 52 |  |
| Gain on sale of properties |  |  | — |  |  |  | — |  |  |  | (218 | ) |  |  | (10 | ) |
| Total operating expenses |  |  | 735 |  |  |  | 666 |  |  |  | 2,574 |  |  |  | 2,725 |  |
| Income from operations |  |  | 287 |  |  |  | 247 |  |  |  | 1,125 |  |  |  | 665 |  |
| Other income (expense), net |  |  | 16 |  |  |  | 1 |  |  |  | 41 |  |  |  | — |  |
| Income before income taxes |  |  | 303 |  |  |  | 248 |  |  |  | 1,166 |  |  |  | 665 |  |
| Provision for income taxes |  |  | 32 |  |  |  | 58 |  |  |  | 1,090 |  |  |  | 156 |  |
| Net income |  | $ | 271 |  |  | $ | 190 |  |  | $ | 76 |  |  | $ | 509 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.02 |  |  | $ | 0.70 |  |  | $ | 0.28 |  |  | $ | 1.85 |  |
| Diluted |  | $ | 0.99 |  |  | $ | 0.68 |  |  | $ | 0.28 |  |  | $ | 1.81 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 265 |  |  |  | 270 |  |  |  | 268 |  |  |  | 275 |  |
| Diluted |  |  | 273 |  |  |  | 278 |  |  |  | 276 |  |  |  | 281 |  |
| Cash dividends declared per share |  | $ | 0.20 |  |  | $ | 0.19 |  |  | $ | 0.80 |  |  | $ | 0.76 |  |

[0001564590-18-014236:8k_2_02:75]
NETAPP, INC.

[0001564590-18-014236:8k_2_02:76]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-18-014236:8k_2_02:77]
(In millions)

[0001564590-18-014236:8k_2_02:78]
(Unaudited)

[0001564590-18-014236:8k_2_02:79]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 27, 2018 |  |  | April 28, 2017 |  |  | April 27, 2018 |  |  | April 28, 2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 271 |  |  | $ | 190 |  |  | $ | 76 |  |  | $ | 509 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 48 |  |  |  | 53 |  |  |  | 198 |  |  |  | 226 |  |
| Stock-based compensation |  |  | 36 |  |  |  | 46 |  |  |  | 161 |  |  |  | 195 |  |
| Deferred income taxes |  |  | 19 |  |  |  | 17 |  |  |  | 277 |  |  |  | 90 |  |
| Gain on sale of properties |  |  | — |  |  |  | — |  |  |  | (218 | ) |  |  | (10 | ) |
| Other items, net |  |  | (19 | ) |  |  | 2 |  |  |  | (27 | ) |  |  | (6 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (264 | ) |  |  | (127 | ) |  |  | (272 | ) |  |  | 81 |  |
| Inventories |  |  | (28 | ) |  |  | (38 | ) |  |  | 37 |  |  |  | (65 | ) |
| Accounts payable |  |  | 147 |  |  |  | 81 |  |  |  | 262 |  |  |  | 94 |  |
| Accrued expenses |  |  | 104 |  |  |  | 35 |  |  |  | 162 |  |  |  | (86 | ) |
| Deferred revenue and financed unearned services revenue |  |  | 226 |  |  |  | 111 |  |  |  | 124 |  |  |  | (37 | ) |
| Long-term taxes payable |  |  | (9 | ) |  |  | 10 |  |  |  | 714 |  |  |  | (6 | ) |
| Changes in other operating assets and liabilities, net |  |  | (37 | ) |  |  | (15 | ) |  |  | (16 | ) |  |  | 1 |  |
| Net cash provided by operating activities |  |  | 494 |  |  |  | 365 |  |  |  | 1,478 |  |  |  | 986 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | 168 |  |  |  | (45 | ) |  |  | (10 | ) |  |  | (43 | ) |
| Purchases of property and equipment |  |  | (48 | ) |  |  | (38 | ) |  |  | (145 | ) |  |  | (175 | ) |
| Proceeds from sale of properties |  |  | — |  |  |  | — |  |  |  | 210 |  |  |  | — |  |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | (8 | ) |  |  | (75 | ) |  |  | (8 | ) |
| Other investing activities, net |  |  | — |  |  |  | 4 |  |  |  | (1 | ) |  |  | 6 |  |
| Net cash provided by (used in) investing activities |  |  | 120 |  |  |  | (87 | ) |  |  | (21 | ) |  |  | (220 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 16 |  |  |  | 28 |  |  |  | 173 |  |  |  | 140 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (8 | ) |  |  | (6 | ) |  |  | (75 | ) |  |  | (48 | ) |
| Repurchase of common stock |  |  | (344 | ) |  |  | (129 | ) |  |  | (794 | ) |  |  | (705 | ) |
| Proceeds from (repayments of) commercial paper notes, net |  |  | (247 | ) |  |  | 107 |  |  |  | (115 | ) |  |  | 499 |  |
| Issuance of long-term debt, net |  |  | — |  |  |  | — |  |  |  | 795 |  |  |  | — |  |
| Repayment of short-term loan |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (850 | ) |
| Repayment of long-term debt |  |  | — |  |  |  | — |  |  |  | (750 | ) |  |  | — |  |
| Dividends paid |  |  | (53 | ) |  |  | (51 | ) |  |  | (214 | ) |  |  | (208 | ) |
| Other financing activities, net |  |  | — |  |  |  | — |  |  |  | (6 | ) |  |  | (7 | ) |
| Net cash used in financing activities |  |  | (636 | ) |  |  | (51 | ) |  |  | (986 | ) |  |  | (1,179 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (11 | ) |  |  | 4 |  |  |  | 26 |  |  |  | (11 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (33 | ) |  |  | 231 |  |  |  | 497 |  |  |  | (424 | ) |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,974 |  |  |  | 2,213 |  |  |  | 2,444 |  |  |  | 2,868 |  |
| End of period |  | $ | 2,941 |  |  | $ | 2,444 |  |  | $ | 2,941 |  |  | $ | 2,444 |  |

[0001564590-18-014236:8k_2_02:80]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q4 FY'18 |  |  | Q3 FY'18 |  |  | Q4 FY'17 |  |  | FY 2018 |  |  | FY 2017 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,011 |  |  | $ | 920 |  |  | $ | 852 |  |  | $ | 3,461 |  |  | $ | 3,006 |  |
| Strategic |  | $ | 745 |  |  | $ | 647 |  |  | $ | 596 |  |  | $ | 2,449 |  |  | $ | 1,971 |  |
| Mature |  | $ | 266 |  |  | $ | 273 |  |  | $ | 256 |  |  | $ | 1,012 |  |  | $ | 1,035 |  |
| Software Maintenance |  | $ | 247 |  |  | $ | 237 |  |  | $ | 242 |  |  | $ | 958 |  |  | $ | 965 |  |
| Hardware Maintenance and Other Services |  | $ | 383 |  |  | $ | 366 |  |  | $ | 387 |  |  | $ | 1,492 |  |  | $ | 1,548 |  |
| Hardware Maintenance Support Contracts |  | $ | 310 |  |  | $ | 299 |  |  | $ | 313 |  |  | $ | 1,213 |  |  | $ | 1,265 |  |
| Professional and Other Services |  | $ | 73 |  |  | $ | 67 |  |  | $ | 74 |  |  | $ | 279 |  |  | $ | 283 |  |
| Net Revenues |  | $ | 1,641 |  |  | $ | 1,523 |  |  | $ | 1,481 |  |  | $ | 5,911 |  |  | $ | 5,519 |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'18 Revenue |  |  | % of Q3 FY'18 Revenue |  |  | % of Q4 FY'17 Revenue |  |  | % of FY 2018 Revenue |  |  | % of FY 2017 Revenue |  |
| Americas |  |  | 51 | % |  |  | 54 | % |  |  | 54 | % |  |  | 54 | % |  |  | 56 | % |
| Americas Commercial |  |  | 39 | % |  |  | 44 | % |  |  | 42 | % |  |  | 41 | % |  |  | 43 | % |
| U.S. Public Sector |  |  | 12 | % |  |  | 10 | % |  |  | 12 | % |  |  | 13 | % |  |  | 13 | % |
| EMEA |  |  | 34 | % |  |  | 32 | % |  |  | 32 | % |  |  | 32 | % |  |  | 31 | % |
| Asia Pacific |  |  | 15 | % |  |  | 14 | % |  |  | 14 | % |  |  | 14 | % |  |  | 13 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'18 Revenue |  |  | % of Q3 FY'18 Revenue |  |  | % of Q4 FY'17 Revenue |  |  | % of FY 2018 Revenue |  |  | % of FY 2017 Revenue |  |
| Direct |  |  | 21 | % |  |  | 22 | % |  |  | 22 | % |  |  | 21 | % |  |  | 22 | % |
| Indirect |  |  | 79 | % |  |  | 78 | % |  |  | 78 | % |  |  | 79 | % |  |  | 78 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'18 |  |  | Q3 FY'18 |  |  | Q4 FY'17 |  |  | FY 2018 |  |  | FY 2017 |  |
| Non-GAAP Gross Margin |  |  | 63.0 | % |  |  | 62.6 | % |  |  | 62.5 | % |  |  | 63.4 | % |  |  | 62.3 | % |
| Product |  |  | 51.5 | % |  |  | 50.2 | % |  |  | 48.9 | % |  |  | 50.9 | % |  |  | 47.4 | % |
| Software Maintenance |  |  | 97.6 | % |  |  | 97.5 | % |  |  | 97.5 | % |  |  | 97.4 | % |  |  | 97.1 | % |
| Hardware Maintenance and Other Services |  |  | 71.0 | % |  |  | 71.3 | % |  |  | 70.3 | % |  |  | 70.6 | % |  |  | 69.4 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'18 |  |  | Q3 FY'18 |  |  | Q4 FY'17 |  |  | FY 2018 |  |  | FY 2017 |  |
| Non-GAAP Income from Operations |  | $ | 335 |  |  | $ | 310 |  |  | $ | 306 |  |  | $ | 1,126 |  |  | $ | 950 |  |
| % of Net Revenues |  |  | 20.4 | % |  |  | 20.4 | % |  |  | 20.7 | % |  |  | 19.0 | % |  |  | 17.2 | % |
| Non-GAAP Income before Income Taxes |  | $ | 351 |  |  | $ | 324 |  |  | $ | 307 |  |  | $ | 1,167 |  |  | $ | 950 |  |
| Non-GAAP Effective Tax Rate |  |  | 17.9 | % |  |  | 15.7 | % |  |  | 22.1 | % |  |  | 18.0 | % |  |  | 19.2 | % |

[0001564590-18-014236:8k_2_02:81]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'18 |  |  | Q3 FY'18 |  |  | Q4 FY'17 |  |  | FY 2018 |  |  | FY 2017 |  |
| Non-GAAP Net Income |  | $ | 288 |  |  | $ | 273 |  |  | $ | 239 |  |  | $ | 957 |  |  | $ | 768 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 273 |  |  |  | 276 |  |  |  | 278 |  |  |  | 276 |  |  |  | 281 |  |
| Non-GAAP Income per Share, Diluted |  | $ | 1.05 |  |  | $ | 0.99 |  |  | $ | 0.86 |  |  | $ | 3.47 |  |  | $ | 2.73 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'18 |  |  | Q3 FY'18 |  |  | Q4 FY'17 |  |  |  |  |  |  |  |  |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,477 |  |  | $ | 3,269 |  |  | $ | 3,342 |  |  |  |  |  |  |  |  |  |
| DSO (days) |  |  | 56 |  |  |  | 45 |  |  |  | 45 |  |  |  |  |  |  |  |  |  |
| DIO (days) |  |  | 19 |  |  |  | 15 |  |  |  | 26 |  |  |  |  |  |  |  |  |  |
| DPO (days) |  |  | 90 |  |  |  | 72 |  |  |  | 56 |  |  |  |  |  |  |  |  |  |
| CCC (days) |  |  | (15 | ) |  |  | (11 | ) |  |  | 15 |  |  |  |  |  |  |  |  |  |
| Inventory Turns |  |  | 20 |  |  |  | 24 |  |  |  | 14 |  |  |  |  |  |  |  |  |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'18 |  |  | Q3 FY'18 |  |  | Q4 FY'17 |  |  | FY 2018 |  |  | FY 2017 |  |
| Net Cash Provided by Operating Activities |  | $ | 494 |  |  | $ | 420 |  |  | $ | 365 |  |  | $ | 1,478 |  |  | $ | 986 |  |
| Purchases of Property and Equipment |  | $ | 48 |  |  | $ | 32 |  |  | $ | 38 |  |  | $ | 145 |  |  | $ | 175 |  |
| Free Cash Flow |  | $ | 446 |  |  | $ | 388 |  |  | $ | 327 |  |  | $ | 1,333 |  |  | $ | 811 |  |
| Free Cash Flow as a % of Net Revenues |  |  | 27.2 | % |  |  | 25.5 | % |  |  | 22.1 | % |  |  | 22.6 | % |  |  | 14.7 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |

[0001564590-18-014236:8k_2_02:82]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q4'FY17 |  |  | FY2018 |  |  | FY2017 |  |
| NET INCOME (LOSS) |  | $ | 271 |  |  | $ | (506 | ) |  | $ | 190 |  |  | $ | 76 |  |  | $ | 509 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 12 |  |  |  | 14 |  |  |  | 13 |  |  |  | 53 |  |  |  | 48 |  |
| Stock-based compensation |  |  | 36 |  |  |  | 38 |  |  |  | 46 |  |  |  | 161 |  |  |  | 195 |  |
| Litigation settlements |  |  | — |  |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 52 |  |
| Gain on sale of properties |  |  | — |  |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |  |  | (10 | ) |
| Income tax effects |  |  | (31 | ) |  |  | 84 |  |  |  | (10 | ) |  |  | 24 |  |  |  | (26 | ) |
| Tax reform |  |  | — |  |  |  | 856 |  |  |  | — |  |  |  | 856 |  |  |  | — |  |
| NON-GAAP NET INCOME |  | $ | 288 |  |  | $ | 273 |  |  | $ | 239 |  |  | $ | 957 |  |  | $ | 768 |  |
| COST OF REVENUES |  | $ | 619 |  |  | $ | 582 |  |  | $ | 568 |  |  | $ | 2,212 |  |  | $ | 2,129 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (10 | ) |  |  | (8 | ) |  |  | (36 | ) |  |  | (29 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (4 | ) |  |  | (13 | ) |  |  | (17 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 607 |  |  | $ | 569 |  |  | $ | 556 |  |  | $ | 2,163 |  |  | $ | 2,083 |  |
| COST OF PRODUCT REVENUES |  | $ | 500 |  |  | $ | 468 |  |  | $ | 444 |  |  | $ | 1,738 |  |  | $ | 1,614 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (10 | ) |  |  | (8 | ) |  |  | (36 | ) |  |  | (29 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | (3 | ) |  |  | (4 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 490 |  |  | $ | 458 |  |  | $ | 435 |  |  | $ | 1,699 |  |  | $ | 1,581 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 113 |  |  | $ | 108 |  |  | $ | 118 |  |  | $ | 449 |  |  | $ | 487 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (3 | ) |  |  | (3 | ) |  |  | (10 | ) |  |  | (13 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 111 |  |  | $ | 105 |  |  | $ | 115 |  |  | $ | 439 |  |  | $ | 474 |  |
| GROSS PROFIT |  | $ | 1,022 |  |  | $ | 941 |  |  | $ | 913 |  |  | $ | 3,699 |  |  | $ | 3,390 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 10 |  |  |  | 8 |  |  |  | 36 |  |  |  | 29 |  |
| Stock-based compensation |  |  | 3 |  |  |  | 3 |  |  |  | 4 |  |  |  | 13 |  |  |  | 17 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,034 |  |  | $ | 954 |  |  | $ | 925 |  |  | $ | 3,748 |  |  | $ | 3,436 |  |

[0001564590-18-014236:8k_2_02:83]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q4'FY17 |  |  | FY2018 |  |  | FY2017 |  |
| SALES AND MARKETING EXPENSES |  | $ | 461 |  |  | $ | 423 |  |  | $ | 405 |  |  | $ | 1,729 |  |  | $ | 1,633 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (4 | ) |  |  | (5 | ) |  |  | (17 | ) |  |  | (19 | ) |
| Stock-based compensation |  |  | (15 | ) |  |  | (16 | ) |  |  | (20 | ) |  |  | (68 | ) |  |  | (84 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 443 |  |  | $ | 403 |  |  | $ | 380 |  |  | $ | 1,644 |  |  | $ | 1,530 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 203 |  |  | $ | 193 |  |  | $ | 191 |  |  | $ | 783 |  |  | $ | 779 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (11 | ) |  |  | (11 | ) |  |  | (13 | ) |  |  | (49 | ) |  |  | (59 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 192 |  |  | $ | 182 |  |  | $ | 178 |  |  | $ | 734 |  |  | $ | 720 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 71 |  |  | $ | 72 |  |  | $ | 70 |  |  | $ | 280 |  |  | $ | 271 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (7 | ) |  |  | (8 | ) |  |  | (9 | ) |  |  | (31 | ) |  |  | (35 | ) |
| Litigation settlements |  |  | — |  |  |  | (5 | ) |  |  | — |  |  |  | (5 | ) |  |  | — |  |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 64 |  |  | $ | 59 |  |  | $ | 61 |  |  | $ | 244 |  |  | $ | 236 |  |
| RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 52 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (52 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| GAIN ON SALE OF PROPERTIES |  | $ | — |  |  | $ | (218 | ) |  | $ | — |  |  | $ | (218 | ) |  | $ | (10 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale of properties |  |  | — |  |  |  | 218 |  |  |  | — |  |  |  | 218 |  |  |  | 10 |  |
| NON-GAAP GAIN ON SALE OF PROPERTIES |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 735 |  |  | $ | 470 |  |  | $ | 666 |  |  | $ | 2,574 |  |  | $ | 2,725 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (4 | ) |  |  | (5 | ) |  |  | (17 | ) |  |  | (19 | ) |
| Stock-based compensation |  |  | (33 | ) |  |  | (35 | ) |  |  | (42 | ) |  |  | (148 | ) |  |  | (178 | ) |
| Litigation settlements |  |  | — |  |  |  | (5 | ) |  |  | — |  |  |  | (5 | ) |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (52 | ) |
| Gain on sale of properties |  |  | — |  |  |  | 218 |  |  |  | — |  |  |  | 218 |  |  |  | 10 |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 699 |  |  | $ | 644 |  |  | $ | 619 |  |  | $ | 2,622 |  |  | $ | 2,486 |  |

[0001564590-18-014236:8k_2_02:84]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q4'FY17 |  |  | FY2018 |  |  | FY2017 |  |
| INCOME FROM OPERATIONS |  | $ | 287 |  |  | $ | 471 |  |  | $ | 247 |  |  | $ | 1,125 |  |  | $ | 665 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 12 |  |  |  | 14 |  |  |  | 13 |  |  |  | 53 |  |  |  | 48 |  |
| Stock-based compensation |  |  | 36 |  |  |  | 38 |  |  |  | 46 |  |  |  | 161 |  |  |  | 195 |  |
| Litigation settlements |  |  | — |  |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 52 |  |
| Gain on sale of properties |  |  | — |  |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |  |  | (10 | ) |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 335 |  |  | $ | 310 |  |  | $ | 306 |  |  | $ | 1,126 |  |  | $ | 950 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 303 |  |  | $ | 485 |  |  | $ | 248 |  |  | $ | 1,166 |  |  | $ | 665 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 12 |  |  |  | 14 |  |  |  | 13 |  |  |  | 53 |  |  |  | 48 |  |
| Stock-based compensation |  |  | 36 |  |  |  | 38 |  |  |  | 46 |  |  |  | 161 |  |  |  | 195 |  |
| Litigation settlements |  |  | — |  |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 52 |  |
| Gain on sale of properties |  |  | — |  |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |  |  | (10 | ) |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 351 |  |  | $ | 324 |  |  | $ | 307 |  |  | $ | 1,167 |  |  | $ | 950 |  |
| PROVISION FOR INCOME TAXES |  | $ | 32 |  |  | $ | 991 |  |  | $ | 58 |  |  | $ | 1,090 |  |  | $ | 156 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 31 |  |  |  | (84 | ) |  |  | 10 |  |  |  | (24 | ) |  |  | 26 |  |
| Tax reform |  |  | — |  |  |  | (856 | ) |  |  | — |  |  |  | (856 | ) |  |  | — |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 63 |  |  | $ | 51 |  |  | $ | 68 |  |  | $ | 210 |  |  | $ | 182 |  |
| NET INCOME (LOSS) PER SHARE |  | $ | 0.99 |  |  | $ | (1.89 | ) |  | $ | 0.68 |  |  | $ | 0.28 |  |  | $ | 1.81 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.04 |  |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.19 |  |  |  | 0.17 |  |
| Stock-based compensation |  |  | 0.13 |  |  |  | 0.14 |  |  |  | 0.17 |  |  |  | 0.58 |  |  |  | 0.69 |  |
| Litigation settlements |  |  | — |  |  |  | 0.02 |  |  |  | — |  |  |  | 0.02 |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.19 |  |
| Gain on sale of properties |  |  | - |  |  |  | (0.81 | ) |  |  | — |  |  |  | (0.79 | ) |  |  | (0.04 | ) |
| Income tax effects |  |  | (0.11 | ) |  |  | 0.31 |  |  |  | (0.04 | ) |  |  | 0.09 |  |  |  | (0.09 | ) |
| Tax reform |  |  | — |  |  |  | 3.19 |  |  |  | — |  |  |  | 3.10 |  |  |  | — |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.05 |  |  | $ | 0.99 |  |  | $ | 0.86 |  |  | $ | 3.47 |  |  | $ | 2.73 |  |
| In Q3'FY18, our GAAP net loss per share was calculated using basic shares of 268 million, as the impact of common stock equivalents would have been anti-dilutive. Additionally, each adjustment presented in the reconciliation was computed using basic shares. However, because we reported net income on a non-GAAP basis, non-GAAP net income per share was computed using diluted shares of 276 million. As a result of the difference in the number of shares, the summation of GAAP net loss per share and the adjustments does not equal non-GAAP net income per share. |  |

[0001564590-18-014236:8k_2_02:85]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q4'FY17 |  |  | FY2018 |  |  | FY2017 |  |
| Gross margin-GAAP |  |  | 62.3 | % |  |  | 61.8 | % |  |  | 61.6 | % |  |  | 62.6 | % |  |  | 61.4 | % |
| Cost of revenues adjustments |  |  | 0.7 | % |  |  | 0.9 | % |  |  | 0.8 | % |  |  | 0.8 | % |  |  | 0.8 | % |
| Gross margin-Non-GAAP |  |  | 63.0 | % |  |  | 62.6 | % |  |  | 62.5 | % |  |  | 63.4 | % |  |  | 62.3 | % |
| GAAP cost of revenues |  | $ | 619 |  |  | $ | 582 |  |  | $ | 568 |  |  | $ | 2,212 |  |  | $ | 2,129 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (10 | ) |  |  | (8 | ) |  |  | (36 | ) |  |  | (29 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (4 | ) |  |  | (13 | ) |  |  | (17 | ) |
| Non-GAAP cost of revenues |  | $ | 607 |  |  | $ | 569 |  |  | $ | 556 |  |  | $ | 2,163 |  |  | $ | 2,083 |  |
| Net revenues |  | $ | 1,641 |  |  | $ | 1,523 |  |  | $ | 1,481 |  |  | $ | 5,911 |  |  | $ | 5,519 |  |

[0001564590-18-014236:8k_2_02:86]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q4'FY17 |  |  | FY2018 |  |  | FY2017 |  |
| Product gross margin-GAAP |  |  | 50.5 | % |  |  | 49.1 | % |  |  | 47.9 | % |  |  | 49.8 | % |  |  | 46.3 | % |
| Cost of product revenues adjustments |  |  | 1.0 | % |  |  | 1.1 | % |  |  | 1.1 | % |  |  | 1.1 | % |  |  | 1.1 | % |
| Product gross margin-Non-GAAP |  |  | 51.5 | % |  |  | 50.2 | % |  |  | 48.9 | % |  |  | 50.9 | % |  |  | 47.4 | % |
| GAAP cost of product revenues |  | $ | 500 |  |  | $ | 468 |  |  | $ | 444 |  |  | $ | 1,738 |  |  | $ | 1,614 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (10 | ) |  |  | (8 | ) |  |  | (36 | ) |  |  | (29 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | (3 | ) |  |  | (4 | ) |
| Non-GAAP cost of product revenues |  | $ | 490 |  |  | $ | 458 |  |  | $ | 435 |  |  | $ | 1,699 |  |  | $ | 1,581 |  |
| Product revenues |  | $ | 1,011 |  |  | $ | 920 |  |  | $ | 852 |  |  | $ | 3,461 |  |  | $ | 3,006 |  |

[0001564590-18-014236:8k_2_02:87]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q4'FY17 |  |  | FY2018 |  |  | FY2017 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 70.5 | % |  |  | 70.5 | % |  |  | 69.5 | % |  |  | 69.9 | % |  |  | 68.5 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.5 | % |  |  | 0.8 | % |  |  | 0.8 | % |  |  | 0.7 | % |  |  | 0.8 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 71.0 | % |  |  | 71.3 | % |  |  | 70.3 | % |  |  | 70.6 | % |  |  | 69.4 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 113 |  |  | $ | 108 |  |  | $ | 118 |  |  | $ | 449 |  |  | $ | 487 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (3 | ) |  |  | (3 | ) |  |  | (10 | ) |  |  | (13 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 111 |  |  | $ | 105 |  |  | $ | 115 |  |  | $ | 439 |  |  | $ | 474 |  |
| Hardware maintenance and other services revenues |  | $ | 383 |  |  | $ | 366 |  |  | $ | 387 |  |  | $ | 1,492 |  |  | $ | 1,548 |  |

[0001564590-18-014236:8k_2_02:88]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q4'FY17 |  |  | FY2018 |  |  | FY2017 |  |
| GAAP effective tax rate |  |  | 10.6 | % |  |  | 204.3 | % |  |  | 23.4 | % |  |  | 93.5 | % |  |  | 23.5 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 7.3 | % |  |  | (12.1 | )% |  |  | (1.3 | )% |  |  | (2.1 | )% |  |  | (4.3 | )% |
| Tax reform |  |  | — | % |  |  | (176.5 | )% |  |  | — | % |  |  | (73.4 | )% |  |  | — | % |
| Non-GAAP effective tax rate |  |  | 17.9 | % |  |  | 15.7 | % |  |  | 22.1 | % |  |  | 18.0 | % |  |  | 19.2 | % |

[0001564590-18-014236:8k_2_02:89]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q4'FY17 |  |  | FY2018 |  |  | FY2017 |  |
| Net cash provided by operating activities |  | $ | 494 |  |  | $ | 420 |  |  | $ | 365 |  |  | $ | 1,478 |  |  | $ | 986 |  |
| Purchases of property and equipment |  |  | (48 | ) |  |  | (32 | ) |  |  | (38 | ) |  |  | (145 | ) |  |  | (175 | ) |
| Free cash flow |  | $ | 446 |  |  | $ | 388 |  |  | $ | 327 |  |  | $ | 1,333 |  |  | $ | 811 |  |

[0001564590-18-014236:8k_2_02:90]
Some items may not add or recalculate due to rounding.

[0001564590-18-014236:8k_2_02:91]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| FIRST QUARTER FISCAL 2019 |  |
|  |  | First Quarter |  |
|  |  | Fiscal 2019 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $0.76 - $0.82 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the First Quarter Fiscal 2019: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.05 | ) |
| Stock-based compensation expense |  |  | (0.15 | ) |
| Restructuring charges |  |  | (0.07 | ) |
| Income tax effects |  |  | 0.04 |  |
| Total Adjustments |  |  | (0.23 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.53 - 0.59 |  |

[0001564590-18-014236:8k_2_02:92]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| FISCAL 2019 |
| (Unaudited) |
|  |  | GROSS MARGIN |
| Gross Margin - Non-GAAP Guidance |  | ~63% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | (1)% |
| Gross Margin - GAAP Guidance |  | ~62% |
|  |  | OPERATING MARGIN |
| Operating Margin - Non-GAAP Guidance |  | 20% - 21% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | (1)% |
| Stock-based compensation expense |  | (2)% |
| Gain on sale of properties |  | 1% |
| Operating Margin - GAAP Guidance |  | 18% - 19% |
|  |  | EFFECTIVE TAX RATE |
| Effective Tax Rate - Non-GAAP Guidance |  | ~18% |
| Adjustment: |  |  |
| Income tax effects |  | 4% |
| Effective Tax Rate - GAAP Guidance |  | ~22% |
| Some items may not add or recalculate due to rounding |  |  |

[0001564590-18-014236:8k_2_02:93]
Press Contact:

[0001564590-18-014236:8k_2_02:94]
Madge Miller

[0001564590-18-014236:8k_2_02:95]
NetApp

[0001564590-18-014236:8k_2_02:96]
1 408 419 5263

[0001564590-18-014236:8k_2_02:97]
madge.miller@netapp.com

[0001564590-18-014236:8k_2_02:98]
Investor Contact:

[0001564590-18-014236:8k_2_02:99]
Kris Newton

[0001564590-18-014236:8k_2_02:100]
NetApp

[0001564590-18-014236:8k_2_02:101]
1 408 822 3312

[0001564590-18-014236:8k_2_02:102]
kris.newton@netapp.com

## item 5.02 — body, verbatim

[0001564590-18-014236:8k_body:1]
Item 5.02     Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001564590-18-014236:8k_body:2]
(e)

[0001564590-18-014236:8k_body:3]
Fiscal 2019 Compensation

[0001564590-18-014236:8k_body:4]
On May 17, 2018, the Compensation Committee (the “Committee”) of the Board of Directors of NetApp, Inc. (the “Company”) approved the fiscal year 2019 (“FY 19”) terms of cash compensation for the named executive officers identified below in the amounts reflected below:

[0001564590-18-014236:8k_body:5]
Named Executive Officer

[0001564590-18-014236:8k_body:6]
FY 19 Salary (1)

[0001564590-18-014236:8k_body:7]
FY 19 Target Incentive Compensation Award (2) (3)

[0001564590-18-014236:8k_body:8]
George Kurian

[0001564590-18-014236:8k_body:9]
Chief Executive Officer and President

[0001564590-18-014236:8k_body:10]
$925,000 (4)

[0001564590-18-014236:8k_body:11]
170%

[0001564590-18-014236:8k_body:12]
Ronald J. Pasek

[0001564590-18-014236:8k_body:13]
Executive Vice President and Chief Financial Officer

[0001564590-18-014236:8k_body:14]
$600,000

[0001564590-18-014236:8k_body:15]
110%

[0001564590-18-014236:8k_body:16]
Henri Richard

[0001564590-18-014236:8k_body:17]
Executive Vice President, Worldwide Field and Customer Operations

[0001564590-18-014236:8k_body:18]
$600,000

[0001564590-18-014236:8k_body:19]
110%

[0001564590-18-014236:8k_body:20]
Joel D. Reich

[0001564590-18-014236:8k_body:21]
Executive Vice President, Product Operations

[0001564590-18-014236:8k_body:22]
$524,000

[0001564590-18-014236:8k_body:23]
110%

[0001564590-18-014236:8k_body:24]
Matthew K. Fawcett

[0001564590-18-014236:8k_body:25]
Senior Vice President, General Counsel and Secretary

[0001564590-18-014236:8k_body:26]
$538,000

[0001564590-18-014236:8k_body:27]
80%

[0001564590-18-014236:8k_body:28]
(1)

[0001564590-18-014236:8k_body:29]
Effective April 28, 2018.

[0001564590-18-014236:8k_body:30]
(2)

[0001564590-18-014236:8k_body:31]
Expressed as a target percentage of base salary.  Incentive compensation for the Company’s named executive officers will be established pursuant and subject to the terms of the Company’s Executive Compensation Plan, as amended by the Company to reflect the elimination of the exception for qualified performance-based compensation under Section 162(m) of the Internal Revenue Code.

[0001564590-18-014236:8k_body:32]
(3)

[0001564590-18-014236:8k_body:33]
All target incentive compensation awards are unchanged from fiscal year 2018.

[0001564590-18-014236:8k_body:34]
(4)

[0001564590-18-014236:8k_body:35]
Mr. Kurian’s salary is unchanged from fiscal year 2018.

[0001564590-18-014236:8k_body:36]
Performance-Based Restricted Stock Units

[0001564590-18-014236:8k_body:37]
On May 17, 2018, the Committee approved terms of performance-based restricted stock units that are expected to be granted and become effective in June 2018 under one of two forms of Restricted Stock Unit Agreement (Performance-Based) (each, a “PBRSU Agreement” and together, the “PBRSU Agreements”).  The two forms of PBRSU Agreement are substantially similar except for the inclusion of the applicable performance metric in the applicable PBRSU Agreement.  The PBRSU Agreements have terms that are substantially consistent with the terms contained in the form of Restricted Stock Unit Agreement (Performance-Based) included as an exhibit to the Company’s Form 8-K filed on June 26, 2015 (the “Original Agreement”), subject to the following changes:

[0001564590-18-014236:8k_body:38]
•

[0001564590-18-014236:8k_body:39]
The performance period will be three years, subject to earlier termination under circumstances described in the PBRSU Agreement, and such circumstances are consistent with the provisions of the Original Agreement.

[0001564590-18-014236:8k_body:40]
•

[0001564590-18-014236:8k_body:41]
50% of the target number of RSUs will become eligible to vest based upon the Company’s Total Stockholder Return (as such term is defined in the applicable PBRSU Agreement) as compared to the total stockholder return of certain benchmark peers of the Company and not, as provided in the Original Agreement, as compared to the total stockholder return of companies listed in an index.  The performance level necessary to achieve the maximum level of achievement for this performance metric and the percentage of RSUs that become eligible to vest upon satisfying the threshold target for this performance metric have been revised from the values shown in the Original Agreement.

[0001564590-18-014236:8k_body:42]
•

[0001564590-18-014236:8k_body:43]
A new performance metric has been added such that 50% of the target number of RSUs will become eligible to vest based upon the Company’s cumulative Adjusted Operating Income (as such term is defined in the applicable PBRSU Agreement) during the performance period, with a threshold, target and maximum level of achievement.

[0001564590-18-014236:8k_body:44]
The foregoing summary of the PBRSU Agreements does not purport to be complete and is qualified in its entirety by the full text of the PBRSU Agreements, copies of which will be filed with the Company’s Quarterly Report on Form 10-Q for the quarter ending July 27, 2018.
