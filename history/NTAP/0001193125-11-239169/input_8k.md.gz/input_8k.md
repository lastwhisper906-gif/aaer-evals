# NTAP 8-K — 0001102624-11-000512 filed 2011-08-17

## item codes, every 8-K on or before 2011-09-01

- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2011-09-01

- none on or before 2011-09-01

## item 2.02 — earnings release, exhibit 99.1

[0001102624-11-000512:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-11-000512:8k_2_02:2]
exh99_1.htm

[0001102624-11-000512:8k_2_02:3]
Exhibit 99.1 PRESS RELEASE

[0001102624-11-000512:8k_2_02:4]
|  | Press Contact: | Investor Contact: |  |
|  | Ryan Lowry | Shauna O’Boyle |  |
|  | NetApp | NetApp |  |
|  | (408) 822-7544 | (408) 822-7655 |  |
|  | ryanl@netapp.com | oboyle@netapp.com |  |

[0001102624-11-000512:8k_2_02:5]
NETAPP ANNOUNCES RESULTS FOR FIRST QUARTER FISCAL YEAR 2012

[0001102624-11-000512:8k_2_02:6]
Company Reports Q1 FY’12 Revenues of $1.458 Billion; Up 26% Year Over Year

[0001102624-11-000512:8k_2_02:7]
Sunnyvale, Calif.—August 17, 2011—NetApp (NASDAQ: NTAP) today reported results for the first quarter of fiscal year 2012, which ended July 29, 2011. Revenues for the first quarter of fiscal year 2012 totaled $1.458 billion compared to revenues of $1.154 billion for the same period one year ago.

[0001102624-11-000512:8k_2_02:8]
For the first quarter of fiscal year 2012, GAAP net income was $139.5 million, or $0.34 per share1, compared to GAAP net income of $150.7 million, or $0.40 per share, for the same period a year ago. Non-GAAP net income for the first quarter of fiscal year 2012 was $222.3 million, or $0.55 per share2, compared to non-GAAP net income of $190.9 million, or $0.51 per share, for the same period a year ago.

[0001102624-11-000512:8k_2_02:9]
“Despite the challenging macroeconomic environment modestly impacting our revenue growth, NetApp still produced earnings per share slightly above the midpoint of our targeted range.  The company achieved record levels of FAS6000 systems sales, near record numbers of new enterprise customer wins, and our new E-series sales exceeded our forecast,” said Tom Georgens, president and CEO.  “Our gross margin performance demonstrates the strength of our competitive position in the market, helping us to achieve healthy operating results and earnings per share.”

[0001102624-11-000512:8k_2_02:10]
Outlook

[0001102624-11-000512:8k_2_02:11]
| ● | NetApp estimates revenue for the second quarter of fiscal year 2012 to be in the range of $1.500 billion to $1.600 billion, which equates to approximately 3% to 10% sequential revenue growth and approximately 20% to 28% year-over-year revenue growth. |

[0001102624-11-000512:8k_2_02:12]
| ● | NetApp estimates that second quarter fiscal year 2012 GAAP earnings per share will be approximately $0.38 to $0.42 per share. NetApp estimates that second quarter fiscal year 2012 non-GAAP earnings per share will be approximately $0.58 to $0.62 per share. |

[0001102624-11-000512:8k_2_02:13]
| ● | NetApp estimates that share count for the second quarter of fiscal year 2012 will decrease to approximately 392 million shares, including an estimated 10 million shares from the company’s outstanding convertible notes3 and 2 million shares from outstanding warrants. Share count does not include the company’s outstanding note hedges which are expected to offset 80% of the dilution from the convertible notes at maturity or conversion. |

[0001102624-11-000512:8k_2_02:14]
Business Highlights

[0001102624-11-000512:8k_2_02:15]
In the first quarter of fiscal year 2012, NetApp innovation continued to help customers and partners more effectively manage significant data growth and capitalize on tomorrow’s business opportunities. During the quarter, NetApp completed its purchase of the Engenio external storage systems business from LSI Corporation and unveiled new solutions to address growing customer requirements in the areas of big bandwidth and analytics. Additionally, NetApp continued to be a partner of choice for customers in their transition to the cloud. NetApp again received several awards honoring its innovation leadership, channel excellence, and culture, most recently being named one of the world’s most innovative companies by Forbes magazine. Highlights for the quarter included the following:

[0001102624-11-000512:8k_2_02:16]
NetApp Builds on E-Series Platform, Delivers Solutions to Help Customers and OEMs Address Big Data Requirements

[0001102624-11-000512:8k_2_02:17]
| ● | The new NetApp® E5400 storage system delivers compelling performance for big-bandwidth applications, extreme storage density, and exceptional uptime, enabling OEMs to address their customers’ growing high-performance workload requirements. NetApp also introduced two new solutions built on the E-Series platform. The Full-Motion Video Storage Solution enables government agencies to take advantage of full-motion video technology to make better decisions in the field. The Hadoop Storage Solution gives customers the ability to speed deployment and simplify management of Hadoop infrastructures for improved analytics. |

[0001102624-11-000512:8k_2_02:18]
NetApp Accelerates Customers’ Path to the Cloud

[0001102624-11-000512:8k_2_02:19]
| ● | NetApp bolsters management capabilities to provide common foundation for enterprise clouds. New technologies in NetApp OnCommand™ management software enable customers to accelerate and simplify their transition to public, private, and hybrid cloud models. The NetApp Alliance Technology Partner Program also now includes cloud management leaders, delivering integration between industry-leading cloud management solutions and NetApp to provide customers with end-to-end management of the entire cloud infrastructure. |

[0001102624-11-000512:8k_2_02:20]
| ● | NetApp collaborates with Microsoft and Cisco to help customers transition to a private cloud. The NetApp Hyper-V Cloud Fast Track with Cisco data center architecture design offers customers advanced management and service automation capabilities to accelerate private cloud deployment and improve operations. With this new solution NetApp is also now part of Microsoft’s Hyper-V Cloud Fast Track program, further strengthening the relationship between the two companies. |

[0001102624-11-000512:8k_2_02:21]
| ● | NetApp and Cisco FlexPod data center solution shows strong market momentum. NetApp and Cisco now have more than 150 customers who have implemented data center solutions based on the FlexPod™ design architecture. The pretested architectural design guide combines networking, computing, and storage in a shared infrastructure and helps channel partners accelerate and simplify customers’ transition to the cloud. |

[0001102624-11-000512:8k_2_02:22]
Milestones and Awards

[0001102624-11-000512:8k_2_02:23]
| ● | NetApp named one of world’s most innovative companies by Forbes magazine. NetApp, the only major storage vendor to make the list of 100 companies, was recognized for building a culture of innovation that has transformed the foundation of its customers’ business and has been a catalyst to their success. This innovation has been a major driver behind NetApp’s growth and continued success. |

[0001102624-11-000512:8k_2_02:24]
| ● | NetApp continues to rank as one of the best places to work. NetApp was once again named a “best place to work,” ranking #4 in Minnesota in the small employer category, #5 in Washington, D.C. in the large company category, and #14 in Boston in the medium-size category. The honors are a testament to NetApp’s model company approach, strong culture, and talented employees. |

[0001102624-11-000512:8k_2_02:25]
| ● | NetApp recognized for continued channel leadership. NetApp was named to Everything Channel’s CRN Virtualization 100 list due to its success in helping resellers grow their business and support their customers. |

[0001102624-11-000512:8k_2_02:26]
Webcast and Conference Call Information

[0001102624-11-000512:8k_2_02:27]
The NetApp first quarter fiscal year 2012 results conference call will be broadcast live on the Internet at investors.netapp.com on Wednesday, August 17, at 2 p.m. Pacific time. This press release and any other information related to the call will also be posted on the Web site at that location. An audio replay Webcast will be available after 4 p.m. Pacific time on the Web site.

[0001102624-11-000512:8k_2_02:28]
NetApp uses a hybrid format for disclosing key financial information associated with our quarterly results. Concurrent with the press release, NetApp posts a supplemental commentary with financial information and statistics to our Web site at investors.netapp.com.

[0001102624-11-000512:8k_2_02:29]
About NetApp

[0001102624-11-000512:8k_2_02:30]
NetApp creates innovative storage and data management solutions that deliver outstanding cost efficiency and accelerate business breakthroughs. Discover our passion for helping companies around the world go further, faster at www.netapp.com.

[0001102624-11-000512:8k_2_02:31]
###

[0001102624-11-000512:8k_2_02:32]
NetApp, the NetApp logo, Go further, faster, Engenio, FlexPod, and OnCommand are trademarks or registered trademarks of NetApp, Inc. All other marks are the property of their respective owners and should be treated as such.

[0001102624-11-000512:8k_2_02:33]
| 1GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |

[0001102624-11-000512:8k_2_02:34]
| 2Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation expenses, acquisition related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our convertible debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |

[0001102624-11-000512:8k_2_02:35]
| 380% hedged on maturity or conversion of the convertible notes. |

[0001102624-11-000512:8k_2_02:36]
NetApp Usage of Non-GAAP Financials

[0001102624-11-000512:8k_2_02:37]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation expenses, acquisition related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our convertible debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-11-000512:8k_2_02:38]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation. We have historically reported similar non-GAAP financial measures to our investors and believe that the inclusion of comparative numbers provides consistency in our financial reporting at this time.

[0001102624-11-000512:8k_2_02:39]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | July 29, 2011 |  |  | April 29, 2011 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,714.1 |  |  | $ | 5,174.7 |  |
| Accounts receivable, net |  |  | 597.0 |  |  |  | 742.6 |  |
| Inventories |  |  | 138.2 |  |  |  | 108.5 |  |
| Other current assets |  |  | 388.3 |  |  |  | 339.4 |  |
| Total current assets |  |  | 5,837.6 |  |  |  | 6,365.2 |  |
| Property and equipment, net |  |  | 993.3 |  |  |  | 911.6 |  |
| Goodwill and other intangible assets, net |  |  | 1,204.8 |  |  |  | 813.3 |  |
| Long-term investments and restricted cash |  |  | 60.1 |  |  |  | 69.2 |  |
| Other non-current assets |  |  | 350.0 |  |  |  | 339.5 |  |
| Total assets |  | $ | 8,445.8 |  |  | $ | 8,498.8 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 250.8 |  |  | $ | 232.8 |  |
| Accrued compensation and other current liabilities |  |  | 516.5 |  |  |  | 763.0 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | 1,163.1 |  |  |  | 1,150.4 |  |
| Short-term deferred revenue |  |  | 1,240.8 |  |  |  | 1,226.6 |  |
| Total current liabilities |  |  | 3,171.2 |  |  |  | 3,372.8 |  |
| Other long-term liabilities |  |  | 206.1 |  |  |  | 192.9 |  |
| Long-term deferred revenue |  |  | 1,141.7 |  |  |  | 1,088.3 |  |
| Total liabilities |  |  | 4,519.0 |  |  |  | 4,654.0 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | 101.9 |  |  |  | 114.6 |  |
| Stockholders' equity |  |  | 3,824.9 |  |  |  | 3,730.2 |  |
| Total liabilities and stockholders' equity |  | $ | 8,445.8 |  |  | $ | 8,498.8 |  |

[0001102624-11-000512:8k_2_02:40]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Revenues: |  |  |  |  |  |  |
| Product |  | $ | 965.7 |  |  | $ | 737.5 |  |
| Software entitlements and maintenance |  |  | 198.2 |  |  |  | 174.2 |  |
| Service |  |  | 294.3 |  |  |  | 242.0 |  |
| Net revenues |  |  | 1,458.2 |  |  |  | 1,153.7 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 437.4 |  |  |  | 310.2 |  |
| Cost of software entitlements and maintenance |  |  | 5.3 |  |  |  | 3.4 |  |
| Cost of service |  |  | 118.6 |  |  |  | 102.3 |  |
| Total cost of revenues |  |  | 561.3 |  |  |  | 415.9 |  |
| Gross profit |  |  | 896.9 |  |  |  | 737.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 454.8 |  |  |  | 354.2 |  |
| Research and development |  |  | 198.6 |  |  |  | 149.5 |  |
| General and administrative |  |  | 65.1 |  |  |  | 56.2 |  |
| Acquisition related expense |  |  | 2.2 |  |  |  | 0.3 |  |
| Total operating expenses |  |  | 720.7 |  |  |  | 560.2 |  |
| Income from operations |  |  | 176.2 |  |  |  | 177.6 |  |
| Other expense, net |  |  |  |  |  |  |  |  |
| Interest income |  |  | 10.6 |  |  |  | 9.8 |  |
| Interest expense |  |  | (19.4 | ) |  |  | (18.6 | ) |
| Other income (expense), net |  |  | (0.3 | ) |  |  | 2.2 |  |
| Total other expense, net |  |  | (9.1 | ) |  |  | (6.6 | ) |
| Income before income taxes |  |  | 167.1 |  |  |  | 171.0 |  |
| Provision for income taxes |  |  | 27.6 |  |  |  | 20.3 |  |
| Net income |  | $ | 139.5 |  |  | $ | 150.7 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.38 |  |  | $ | 0.43 |  |
| Diluted |  | $ | 0.34 |  |  | $ | 0.40 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |
| Basic |  |  | 370.3 |  |  |  | 352.4 |  |
| Diluted |  |  | 405.5 |  |  |  | 374.3 |  |

[0001102624-11-000512:8k_2_02:41]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOW |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Cash Flows from Operating Activities: |  |  |  |  |  |  |
| Net income |  | $ | 139.5 |  |  | $ | 150.7 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 68.5 |  |  |  | 40.7 |  |
| Stock-based compensation |  |  | 58.1 |  |  |  | 44.3 |  |
| Accretion of discount and issue costs on notes |  |  | 13.7 |  |  |  | 12.9 |  |
| Unrealized losses (gains) on derivative activities |  |  | (6.7 | ) |  |  | 10.8 |  |
| Tax benefit (charges) from stock-based compensation |  |  | 28.7 |  |  |  | (12.0 | ) |
| Excess tax benefit from stock-based compensation |  |  | (32.1 | ) |  |  | - |  |
| Other, net |  |  | (23.9 | ) |  |  | 11.8 |  |
| Changes in assets and liabilities, net of acquisition of businesses: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 145.0 |  |  |  | 91.6 |  |
| Inventories |  |  | 6.8 |  |  |  | 25.0 |  |
| Accounts payable |  |  | 22.8 |  |  |  | (34.4 | ) |
| Accrued compensation and other current liabilities |  |  | (248.3 | ) |  |  | (221.6 | ) |
| Deferred revenue |  |  | 66.7 |  |  |  | 25.7 |  |
| Changes in other operating assets and liabilities, net |  |  | 1.8 |  |  |  | 31.8 |  |
| Net cash provided by operating activities |  |  | 240.6 |  |  |  | 177.3 |  |
| Cash Flows from Investing Activities: |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | 245.8 |  |  |  | (293.9 | ) |
| Purchases of property and equipment |  |  | (98.3 | ) |  |  | (40.2 | ) |
| Acquisition of businesses, net of cash acquired |  |  | (480.0 | ) |  |  | (74.9 | ) |
| Other investing activities, net |  |  | 1.7 |  |  |  | 0.1 |  |
| Net cash used in investing activities |  |  | (330.8 | ) |  |  | (408.9 | ) |
| Cash Flows from Financing Activities: |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 46.6 |  |  |  | 139.9 |  |
| Repurchase and retirement of common stock |  |  | (200.0 | ) |  |  | - |  |
| Excess tax benefit from stock-based compensation |  |  | 32.1 |  |  |  | - |  |
| Other financing activities |  |  | 0.3 |  |  |  | - |  |
| Net cash provided by (used in) financing activities |  |  | (121.0 | ) |  |  | 139.9 |  |
| Effect of Exchange Rate Changes on Cash and Cash Equivalents |  |  | (2.9 | ) |  |  | (1.3 | ) |
| Net Decrease in Cash and Cash Equivalents |  |  | (214.1 | ) |  |  | (93.0 | ) |
| Cash and Cash Equivalents: |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,757.3 |  |  |  | 1,705.0 |  |
| End of period |  | $ | 2,543.2 |  |  | $ | 1,612.0 |  |

[0001102624-11-000512:8k_2_02:42]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP AND GAAP |  |
| IN THE CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| SUMMARY RECONCILIATION OF NET INCOME |  |  |  |  |  |  |
| NET INCOME |  | $ | 139.5 |  |  | $ | 150.7 |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 24.3 |  |  |  | 5.5 |  |
| Stock-based compensation expenses |  |  | 58.1 |  |  |  | 44.3 |  |
| Acquisition related expense |  |  | 10.2 |  |  |  | 0.3 |  |
| Non-cash interest expense |  |  | 13.7 |  |  |  | 12.9 |  |
| Gain on investments |  |  | - |  |  |  | (2.5 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (23.5 | ) |  |  | (20.3 | ) |
| NON-GAAP NET INCOME |  | $ | 222.3 |  |  | $ | 190.9 |  |
| NET INCOME PER SHARE |  | $ | 0.344 |  |  | $ | 0.403 |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.060 |  |  |  | 0.015 |  |
| Stock-based compensation expenses |  |  | 0.143 |  |  |  | 0.118 |  |
| Acquisition related expense |  |  | 0.025 |  |  |  | 0.001 |  |
| Non-cash interest expense |  |  | 0.034 |  |  |  | 0.034 |  |
| Gain on investments |  |  | - |  |  |  | (0.007 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.058 | ) |  |  | (0.054 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.548 |  |  | $ | 0.510 |  |

[0001102624-11-000512:8k_2_02:43]
| NETAPP, INC. |  |
| SUPPLEMENTAL INFORMATION |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended July 29, 2011 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation Expenses |  |  | Acquisition Related Expense |  |  | Non-Cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 13.9 |  |  | $ | 1.1 |  |  | $ | 5.4 |  |  | $ | - |  |  | $ | - |  |  | $ | 20.4 |  |
| Cost of service revenues |  |  | - |  |  |  | 3.9 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3.9 |  |
| Sales and marketing expense |  |  | 10.3 |  |  |  | 28.6 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 38.9 |  |
| Research and development expense |  |  | 0.1 |  |  |  | 16.0 |  |  |  | 2.6 |  |  |  | - |  |  |  | - |  |  |  | 18.7 |  |
| General and administrative expense |  |  | - |  |  |  | 8.5 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 8.5 |  |
| Acquisition related expense |  |  | - |  |  |  | - |  |  |  | 2.2 |  |  |  | - |  |  |  | - |  |  |  | 2.2 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 13.7 |  |  |  | - |  |  |  | 13.7 |  |
| Other income (expense), net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Effect on income before income taxes |  | $ | 24.3 |  |  | $ | 58.1 |  |  | $ | 10.2 |  |  | $ | 13.7 |  |  | $ | - |  |  | $ | 106.3 |  |
|  |  | Three Months Ended July 30, 2010 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation Expenses |  |  | Acquisition Related Expense |  |  | Non-Cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 4.4 |  |  | $ | 0.9 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 5.3 |  |
| Cost of service revenues |  |  | - |  |  |  | 3.9 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3.9 |  |
| Sales and marketing expense |  |  | 1.1 |  |  |  | 20.6 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 21.7 |  |
| Research and development expense |  |  | - |  |  |  | 11.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 11.1 |  |
| General and administrative expense |  |  | - |  |  |  | 7.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 7.8 |  |
| Acquisition related expense |  |  | - |  |  |  | - |  |  |  | 0.3 |  |  |  | - |  |  |  | - |  |  |  | 0.3 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 12.9 |  |  |  | - |  |  |  | 12.9 |  |
| Other income (expense), net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (2.5 | ) |  |  | (2.5 | ) |
| Effect on income before income taxes |  | $ | 5.5 |  |  | $ | 44.3 |  |  | $ | 0.3 |  |  | $ | 12.9 |  |  | $ | (2.5 | ) |  | $ | 60.5 |  |

[0001102624-11-000512:8k_2_02:44]
|  | NETAPP, INC. |
|  | RECONCILIATION OF NON GAAP GUIDANCE TO GAAP |
|  | EXPRESSED AS EARNINGS PER SHARE |
|  | SECOND QUARTER 2012 |
|  | (Unaudited) |
|  | Second Quarter |
|  | 2012 |
| Non-GAAP Guidance | $0.58 - $0.62 |
| Adjustments of Specific Items to |  |
| Net Income Per Share for the Second |  |
| Quarter 2012: |  |
| Amortization of intangible assets | (0.06) |
| Stock based compensation expense | (0.15) |
| Acquisition-related expense | (0.01) |
| Non cash interest expense | (0.04) |
| Income tax effect | 0.06 |
| Total Adjustments | (0.20) |
| GAAP Guidance -Net Income Per Share | $0.38 - $0.42 |
