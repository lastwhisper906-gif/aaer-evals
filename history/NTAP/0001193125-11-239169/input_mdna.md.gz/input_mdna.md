# NTAP MD&A — 0001193125-11-239169


## mdna

[0001193125-11-239169:mdna:1]
[same as prior period, unchanged from 0001193125-11-056223:mdna:1]

[0001193125-11-239169:mdna:2]
[same as prior period, unchanged from 0001193125-11-056223:mdna:2]

[0001193125-11-239169:mdna:3]
[same as prior period, unchanged from 0001193125-11-056223:mdna:3]

[0001193125-11-239169:mdna:4]
[same as prior period, unchanged from 0001193125-11-056223:mdna:4]

[0001193125-11-239169:mdna:5]
[same as prior period, unchanged from 0001193125-11-056223:mdna:5]

[0001193125-11-239169:mdna:6]
[same as prior period, unchanged from 0001193125-11-056223:mdna:6]

[0001193125-11-239169:mdna:7]
|  | • |  | acquisitions and joint ventures, growth opportunities, investments and legal proceedings; |

[0001193125-11-239169:mdna:8]
[same as prior period, unchanged from 0001193125-11-056223:mdna:8]

[0001193125-11-239169:mdna:9]
[same as prior period, unchanged from 0001193125-11-056223:mdna:9]

[0001193125-11-239169:mdna:10]
[same as prior period, unchanged from 0001193125-11-056223:mdna:10]

[0001193125-11-239169:mdna:11]
[same as prior period, unchanged from 0001193125-11-056223:mdna:11]

[0001193125-11-239169:mdna:12]
[same as prior period, unchanged from 0001193125-11-056223:mdna:12]

[0001193125-11-239169:mdna:13]
[same as prior period, unchanged from 0001193125-11-056223:mdna:13]

[0001193125-11-239169:mdna:14]
|  | • |  | compliance with laws, regulations and debt covenants; |

[0001193125-11-239169:mdna:15]
[same as prior period, unchanged from 0001193125-11-056223:mdna:15]

[0001193125-11-239169:mdna:16]
[same as prior period, unchanged from 0001193125-11-056223:mdna:16]

[0001193125-11-239169:mdna:17]
[same as prior period, unchanged from 0001193125-11-056223:mdna:17]

[0001193125-11-239169:mdna:18]
[same as prior period, unchanged from 0001193125-11-056223:mdna:18]

[0001193125-11-239169:mdna:19]
[same as prior period, unchanged from 0001193125-11-056223:mdna:19]

[0001193125-11-239169:mdna:20]
[same as prior period, unchanged from 0001193125-11-056223:mdna:20]

[0001193125-11-239169:mdna:21]
[same as prior period, unchanged from 0001193125-11-056223:mdna:21]

[0001193125-11-239169:mdna:22]
[same as prior period, unchanged from 0001193125-11-056223:mdna:22]

[0001193125-11-239169:mdna:23]
[same as prior period, unchanged from 0001193125-11-056223:mdna:23]

[0001193125-11-239169:mdna:24]
[same as prior period, unchanged from 0001193125-11-056223:mdna:24]

[0001193125-11-239169:mdna:25]
[same as prior period, unchanged from 0001193125-11-056223:mdna:25]

[0001193125-11-239169:mdna:26]
[same as prior period, unchanged from 0001193125-11-056223:mdna:26]

[0001193125-11-239169:mdna:27]
[same as prior period, unchanged from 0001193125-11-056223:mdna:27]

[0001193125-11-239169:mdna:28]
[same as prior period, unchanged from 0001193125-11-056223:mdna:28]

[0001193125-11-239169:mdna:29]
[same as prior period, unchanged from 0001193125-11-056223:mdna:29]

[0001193125-11-239169:mdna:30]
[same as prior period, unchanged from 0001193125-11-056223:mdna:30]

[0001193125-11-239169:mdna:31]
[same as prior period, unchanged from 0001193125-11-056223:mdna:31]

[0001193125-11-239169:mdna:32]
[same as prior period, unchanged from 0001193125-11-056223:mdna:32]

[0001193125-11-239169:mdna:33]
[same as prior period, unchanged from 0001193125-11-056223:mdna:33]

[0001193125-11-239169:mdna:34]
[same as prior period, unchanged from 0001193125-11-056223:mdna:34]

[0001193125-11-239169:mdna:35]
[same as prior period, unchanged from 0001193125-11-056223:mdna:35]

[0001193125-11-239169:mdna:36]
[same as prior period, unchanged from 0001193125-11-056223:mdna:36]

[0001193125-11-239169:mdna:37]
[same as prior period, unchanged from 0001193125-11-056223:mdna:37]

[0001193125-11-239169:mdna:38]
[same as prior period, unchanged from 0001193125-11-056223:mdna:38]

[0001193125-11-239169:mdna:39]
[same as prior period, unchanged from 0001193125-11-056223:mdna:39]

[0001193125-11-239169:mdna:40]
[same as prior period, unchanged from 0001193125-11-056223:mdna:40]

[0001193125-11-239169:mdna:41]
[same as prior period, unchanged from 0001193125-11-056223:mdna:41]

[0001193125-11-239169:mdna:42]
|  | • |  | the results of our ongoing litigation, tax audits, government audits and inquiries; and |

[0001193125-11-239169:mdna:43]
[same as prior period, unchanged from 0001193125-11-056223:mdna:43]

[0001193125-11-239169:mdna:44]
[same as prior period, unchanged from 0001193125-11-056223:mdna:44]

[0001193125-11-239169:mdna:45]
[same as prior period, unchanged from 0001193125-11-056223:mdna:45]

[0001193125-11-239169:mdna:46]
[same as prior period, unchanged from 0001193125-11-056223:mdna:46]

[0001193125-11-239169:mdna:47]
[same as prior period, unchanged from 0001193125-11-056223:mdna:47]

[0001193125-11-239169:mdna:48]
[same as prior period, unchanged from 0001193125-11-056223:mdna:48]

[0001193125-11-239169:mdna:49]
[same as prior period, unchanged from 0001193125-11-056223:mdna:49]

[0001193125-11-239169:mdna:50]
[same as prior period, unchanged from 0001193125-11-056223:mdna:50]

[0001193125-11-239169:mdna:51]
[same as prior period, unchanged from 0001193125-11-056223:mdna:51]

[0001193125-11-239169:mdna:52]
[same as prior period, unchanged from 0001193125-11-056223:mdna:52]

[0001193125-11-239169:mdna:53]
[same as prior period, unchanged from 0001193125-11-056223:mdna:53]

[0001193125-11-239169:mdna:54]
[same as prior period, unchanged from 0001193125-11-056223:mdna:54]

[0001193125-11-239169:mdna:55]
[same as prior period, unchanged from 0001193125-11-056223:mdna:55]

[0001193125-11-239169:mdna:56]
[same as prior period, unchanged from 0001193125-11-056223:mdna:56]

[0001193125-11-239169:mdna:57]
[same as prior period, unchanged from 0001193125-11-056223:mdna:57]

[0001193125-11-239169:mdna:58]
[same as prior period, unchanged from 0001193125-11-056223:mdna:58]

[0001193125-11-239169:mdna:59]
[same as prior period, unchanged from 0001193125-11-056223:mdna:59]

[0001193125-11-239169:mdna:60]
[same as prior period, unchanged from 0001193125-11-056223:mdna:60]

[0001193125-11-239169:mdna:61]
[same as prior period, unchanged from 0001193125-11-056223:mdna:61]

[0001193125-11-239169:mdna:62]
[same as prior period, unchanged from 0001193125-11-056223:mdna:62]

[0001193125-11-239169:mdna:63]
[same as prior period, unchanged from 0001193125-11-056223:mdna:63]

[0001193125-11-239169:mdna:64]
[same as prior period, unchanged from 0001193125-11-056223:mdna:64]

[0001193125-11-239169:mdna:65]
[same as prior period, unchanged from 0001193125-11-056223:mdna:65]

[0001193125-11-239169:mdna:66]
[same as prior period, unchanged from 0001193125-11-056223:mdna:66]

[0001193125-11-239169:mdna:67]
[same as prior period, unchanged from 0001193125-11-056223:mdna:67]

[0001193125-11-239169:mdna:68]
[same as prior period, unchanged from 0001193125-11-056223:mdna:68]

[0001193125-11-239169:mdna:69]
[same as prior period, unchanged from 0001193125-11-056223:mdna:69]

[0001193125-11-239169:mdna:70]
[same as prior period, unchanged from 0001193125-11-056223:mdna:70]

[0001193125-11-239169:mdna:71]
[same as prior period, unchanged from 0001193125-11-056223:mdna:71]

[0001193125-11-239169:mdna:72]
[same as prior period, unchanged from 0001193125-11-056223:mdna:72]

[0001193125-11-239169:mdna:73]
[same as prior period, unchanged from 0001193125-11-056223:mdna:73]

[0001193125-11-239169:mdna:74]
[same as prior period, unchanged from 0001193125-11-056223:mdna:74]

[0001193125-11-239169:mdna:75]
[same as prior period, unchanged from 0001193125-11-056223:mdna:75]

[0001193125-11-239169:mdna:76]
[same as prior period, unchanged from 0001193125-11-056223:mdna:76]

[0001193125-11-239169:mdna:77]
[same as prior period, unchanged from 0001193125-11-056223:mdna:77]

[0001193125-11-239169:mdna:78]
[same as prior period, unchanged from 0001193125-11-056223:mdna:78]

[0001193125-11-239169:mdna:79]
[same as prior period, unchanged from 0001193125-11-056223:mdna:79]

[0001193125-11-239169:mdna:80]
[same as prior period, unchanged from 0001193125-11-056223:mdna:80]

[0001193125-11-239169:mdna:81]
[same as prior period, unchanged from 0001193125-11-056223:mdna:81]

[0001193125-11-239169:mdna:82]
[same as prior period, unchanged from 0001193125-11-056223:mdna:82]

[0001193125-11-239169:mdna:83]
[same as prior period, unchanged from 0001193125-11-056223:mdna:83]

[0001193125-11-239169:mdna:84]
[same as prior period, unchanged from 0001193125-11-056223:mdna:84]

[0001193125-11-239169:mdna:85]
[same as prior period, unchanged from 0001193125-11-056223:mdna:85]

[0001193125-11-239169:mdna:86]
[same as prior period, unchanged from 0001193125-11-056223:mdna:86]

[0001193125-11-239169:mdna:87]
[same as prior period, unchanged from 0001193125-11-056223:mdna:87]

[0001193125-11-239169:mdna:88]
[same as prior period, unchanged from 0001193125-11-056223:mdna:88]

[0001193125-11-239169:mdna:89]
[same as prior period, unchanged from 0001193125-11-056223:mdna:89]

[0001193125-11-239169:mdna:90]
[same as prior period, unchanged from 0001193125-11-056223:mdna:90]

[0001193125-11-239169:mdna:91]
[same as prior period, unchanged from 0001193125-11-056223:mdna:91]

[0001193125-11-239169:mdna:92]
[same as prior period, unchanged from 0001193125-11-056223:mdna:92]

[0001193125-11-239169:mdna:93]
[same as prior period, unchanged from 0001193125-11-056223:mdna:93]

[0001193125-11-239169:mdna:94]
[same as prior period, unchanged from 0001193125-11-056223:mdna:94]

[0001193125-11-239169:mdna:95]
[same as prior period, unchanged from 0001193125-11-056223:mdna:95]

[0001193125-11-239169:mdna:96]
[same as prior period, unchanged from 0001193125-11-056223:mdna:96]

[0001193125-11-239169:mdna:97]
[same as prior period, unchanged from 0001193125-11-056223:mdna:97]

[0001193125-11-239169:mdna:98]
[same as prior period, unchanged from 0001193125-11-056223:mdna:98]

[0001193125-11-239169:mdna:99]
[same as prior period, unchanged from 0001193125-11-056223:mdna:99]

[0001193125-11-239169:mdna:100]
[same as prior period, unchanged from 0001193125-11-056223:mdna:100]

[0001193125-11-239169:mdna:101]
[same as prior period, unchanged from 0001193125-11-056223:mdna:101]

[0001193125-11-239169:mdna:102]
[same as prior period, unchanged from 0001193125-11-056223:mdna:102]

[0001193125-11-239169:mdna:103]
[same as prior period, unchanged from 0001193125-11-056223:mdna:103]

[0001193125-11-239169:mdna:104]
[same as prior period, unchanged from 0001193125-11-056223:mdna:104]

[0001193125-11-239169:mdna:105]
[same as prior period, unchanged from 0001193125-11-056223:mdna:105]

[0001193125-11-239169:mdna:106]
[same as prior period, unchanged from 0001193125-11-056223:mdna:106]

[0001193125-11-239169:mdna:107]
[same as prior period, unchanged from 0001193125-11-056223:mdna:107]

[0001193125-11-239169:mdna:108]
[same as prior period, unchanged from 0001193125-11-056223:mdna:108]

[0001193125-11-239169:mdna:109]
[same as prior period, unchanged from 0001193125-11-056223:mdna:109]

[0001193125-11-239169:mdna:110]
[same as prior period, unchanged from 0001193125-11-056223:mdna:110]

[0001193125-11-239169:mdna:111]
[same as prior period, unchanged from 0001193125-11-056223:mdna:111]

[0001193125-11-239169:mdna:112]
[same as prior period, unchanged from 0001193125-11-056223:mdna:112]

[0001193125-11-239169:mdna:113]
[same as prior period, unchanged from 0001193125-11-056223:mdna:113]

[0001193125-11-239169:mdna:114]
[same as prior period, unchanged from 0001193125-11-056223:mdna:114]

[0001193125-11-239169:mdna:115]
[same as prior period, unchanged from 0001193125-11-056223:mdna:115]

[0001193125-11-239169:mdna:116]
[same as prior period, unchanged from 0001193125-11-056223:mdna:116]

[0001193125-11-239169:mdna:117]
[same as prior period, unchanged from 0001193125-11-056223:mdna:117]

[0001193125-11-239169:mdna:118]
[same as prior period, unchanged from 0001193125-11-056223:mdna:118]

[0001193125-11-239169:mdna:119]
[same as prior period, unchanged from 0001193125-11-056223:mdna:119]

[0001193125-11-239169:mdna:120]
[same as prior period, unchanged from 0001193125-11-056223:mdna:120]

[0001193125-11-239169:mdna:121]
[same as prior period, unchanged from 0001193125-11-056223:mdna:121]

[0001193125-11-239169:mdna:122]
The increase in outside services reflects additional spending on contractors and the resolution of the Sun
Microsystems litigation resulted in a decrease in legal fees.

[0001193125-11-239169:mdna:123]
[same as prior period, unchanged from 0001193125-11-056223:mdna:123]

[0001193125-11-239169:mdna:124]
[same as prior period, unchanged from 0001193125-11-056223:mdna:124]

[0001193125-11-239169:mdna:125]
[same as prior period, unchanged from 0001193125-11-056223:mdna:125]

[0001193125-11-239169:mdna:126]
[same as prior period, unchanged from 0001193125-11-056223:mdna:126]

[0001193125-11-239169:mdna:127]
[same as prior period, unchanged from 0001193125-11-056223:mdna:127]

[0001193125-11-239169:mdna:128]
[same as prior period, unchanged from 0001193125-11-056223:mdna:128]

[0001193125-11-239169:mdna:129]
[same as prior period, unchanged from 0001193125-11-056223:mdna:129]

[0001193125-11-239169:mdna:130]
[same as prior period, unchanged from 0001193125-11-056223:mdna:130]

[0001193125-11-239169:mdna:131]
[same as prior period, unchanged from 0001193125-11-056223:mdna:131]

[0001193125-11-239169:mdna:132]
[same as prior period, unchanged from 0001193125-11-056223:mdna:132]

[0001193125-11-239169:mdna:133]
[same as prior period, unchanged from 0001193125-11-056223:mdna:133]

[0001193125-11-239169:mdna:134]
[same as prior period, unchanged from 0001193125-11-056223:mdna:134]

[0001193125-11-239169:mdna:135]
[same as prior period, unchanged from 0001193125-11-056223:mdna:135]

[0001193125-11-239169:mdna:136]
[same as prior period, unchanged from 0001193125-11-056223:mdna:136]

[0001193125-11-239169:mdna:137]
[same as prior period, unchanged from 0001193125-11-056223:mdna:137]

[0001193125-11-239169:mdna:138]
[same as prior period, unchanged from 0001193125-11-056223:mdna:138]

[0001193125-11-239169:mdna:139]
[same as prior period, unchanged from 0001193125-11-056223:mdna:139]

[0001193125-11-239169:mdna:140]
[same as prior period, unchanged from 0001193125-11-056223:mdna:140]

[0001193125-11-239169:mdna:141]
[same as prior period, unchanged from 0001193125-11-056223:mdna:141]

[0001193125-11-239169:mdna:142]
[same as prior period, unchanged from 0001193125-11-056223:mdna:142]

[0001193125-11-239169:mdna:143]
[same as prior period, unchanged from 0001193125-11-056223:mdna:143]

[0001193125-11-239169:mdna:144]
[same as prior period, unchanged from 0001193125-11-056223:mdna:144]

[0001193125-11-239169:mdna:145]
[same as prior period, unchanged from 0001193125-11-056223:mdna:145]

[0001193125-11-239169:mdna:146]
[same as prior period, unchanged from 0001193125-11-056223:mdna:146]

[0001193125-11-239169:mdna:147]
[same as prior period, unchanged from 0001193125-11-056223:mdna:147]

[0001193125-11-239169:mdna:148]
[same as prior period, unchanged from 0001193125-11-056223:mdna:148]

[0001193125-11-239169:mdna:149]
[same as prior period, unchanged from 0001193125-11-056223:mdna:149]

[0001193125-11-239169:mdna:150]
[same as prior period, unchanged from 0001193125-11-056223:mdna:150]

[0001193125-11-239169:mdna:151]
[same as prior period, unchanged from 0001193125-11-056223:mdna:151]

[0001193125-11-239169:mdna:152]
[same as prior period, unchanged from 0001193125-11-056223:mdna:152]

[0001193125-11-239169:mdna:153]
[same as prior period, unchanged from 0001193125-11-056223:mdna:153]

[0001193125-11-239169:mdna:154]
[same as prior period, unchanged from 0001193125-11-056223:mdna:154]

[0001193125-11-239169:mdna:155]
[same as prior period, unchanged from 0001193125-11-056223:mdna:155]

[0001193125-11-239169:mdna:156]
[same as prior period, unchanged from 0001193125-11-056223:mdna:156]

[0001193125-11-239169:mdna:157]
[same as prior period, unchanged from 0001193125-11-056223:mdna:157]

[0001193125-11-239169:mdna:158]
[same as prior period, unchanged from 0001193125-11-056223:mdna:158]

[0001193125-11-239169:mdna:159]
[same as prior period, unchanged from 0001193125-11-056223:mdna:159]

[0001193125-11-239169:mdna:160]
[same as prior period, unchanged from 0001193125-11-056223:mdna:160]

[0001193125-11-239169:mdna:161]
[same as prior period, unchanged from 0001193125-11-056223:mdna:161]

[0001193125-11-239169:mdna:162]
[same as prior period, unchanged from 0001193125-11-056223:mdna:162]

[0001193125-11-239169:mdna:163]
[same as prior period, unchanged from 0001193125-11-056223:mdna:163]

[0001193125-11-239169:mdna:164]
[same as prior period, unchanged from 0001193125-11-056223:mdna:164]

[0001193125-11-239169:mdna:165]
[same as prior period, unchanged from 0001193125-11-056223:mdna:165]

[0001193125-11-239169:mdna:166]
[same as prior period, unchanged from 0001193125-11-056223:mdna:166]

[0001193125-11-239169:mdna:167]
[same as prior period, unchanged from 0001193125-11-056223:mdna:167]

[0001193125-11-239169:mdna:168]
[same as prior period, unchanged from 0001193125-11-056223:mdna:168]

[0001193125-11-239169:mdna:169]
[same as prior period, unchanged from 0001193125-11-056223:mdna:169]

[0001193125-11-239169:mdna:170]
[same as prior period, unchanged from 0001193125-11-056223:mdna:170]

[0001193125-11-239169:mdna:171]
[same as prior period, unchanged from 0001193125-11-056223:mdna:171]

[0001193125-11-239169:mdna:172]
[same as prior period, unchanged from 0001193125-11-056223:mdna:172]

[0001193125-11-239169:mdna:173]
[same as prior period, unchanged from 0001193125-11-056223:mdna:173]

[0001193125-11-239169:mdna:174]
As of January 28, 2011, we had $1.265 billion principal amount of 1.75% Convertible Senior Notes due 2013 (the Notes). The Notes will mature on June 1, 2013, unless earlier repurchased or
converted. As of January 28, 2011, the Notes have not been repurchased or converted. We also have not received any shares under the related Note hedges or delivered cash or shares of common stock under the related warrants.

[0001193125-11-239169:mdna:175]
[same as prior period, unchanged from 0001193125-11-056223:mdna:175]

[0001193125-11-239169:mdna:176]
[same as prior period, unchanged from 0001193125-11-056223:mdna:176]

[0001193125-11-239169:mdna:177]
[same as prior period, unchanged from 0001193125-11-056223:mdna:177]

[0001193125-11-239169:mdna:178]
[same as prior period, unchanged from 0001193125-11-056223:mdna:178]

[0001193125-11-239169:mdna:179]
[same as prior period, unchanged from 0001193125-11-056223:mdna:179]

[0001193125-11-239169:mdna:180]
[same as prior period, unchanged from 0001193125-11-056223:mdna:180]

[0001193125-11-239169:mdna:181]
[same as prior period, unchanged from 0001193125-11-056223:mdna:181]

[0001193125-11-239169:mdna:182]
[same as prior period, unchanged from 0001193125-11-056223:mdna:182]

[0001193125-11-239169:mdna:183]
[same as prior period, unchanged from 0001193125-11-056223:mdna:183]

[0001193125-11-239169:mdna:184]
[same as prior period, unchanged from 0001193125-11-056223:mdna:184]

[0001193125-11-239169:mdna:185]
[same as prior period, unchanged from 0001193125-11-056223:mdna:185]

[0001193125-11-239169:mdna:186]
[same as prior period, unchanged from 0001193125-11-056223:mdna:186]

[0001193125-11-239169:mdna:187]
[same as prior period, unchanged from 0001193125-11-056223:mdna:187]

[0001193125-11-239169:mdna:188]
[same as prior period, unchanged from 0001193125-11-056223:mdna:188]

[0001193125-11-239169:mdna:189]
[same as prior period, unchanged from 0001193125-11-056223:mdna:189]

[0001193125-11-239169:mdna:190]
Legal Contingencies

[0001193125-11-239169:mdna:191]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as of January 28, 2011, as the outcome of these legal matters is
currently not determinable.

[0001193125-11-239169:mdna:192]
[same as prior period, unchanged from 0001193125-11-056223:mdna:192]

[0001193125-11-239169:mdna:193]
[same as prior period, unchanged from 0001193125-11-056223:mdna:193]

[0001193125-11-239169:mdna:194]
[same as prior period, unchanged from 0001193125-11-056223:mdna:194]

[0001193125-11-239169:mdna:195]
[same as prior period, unchanged from 0001193125-11-056223:mdna:195]

[0001193125-11-239169:mdna:196]
[same as prior period, unchanged from 0001193125-11-056223:mdna:196]

[0001193125-11-239169:mdna:197]
[same as prior period, unchanged from 0001193125-11-056223:mdna:197]

[0001193125-11-239169:mdna:198]
[same as prior period, unchanged from 0001193125-11-056223:mdna:198]

[0001193125-11-239169:mdna:199]
[same as prior period, unchanged from 0001193125-11-056223:mdna:199]

[0001193125-11-239169:mdna:200]
[same as prior period, unchanged from 0001193125-11-056223:mdna:200]

[0001193125-11-239169:mdna:201]
[same as prior period, unchanged from 0001193125-11-056223:mdna:201]
