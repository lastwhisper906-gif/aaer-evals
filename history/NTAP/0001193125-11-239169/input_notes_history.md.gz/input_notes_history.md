# NTAP note change history — 0001193125-11-056223 → 0001193125-11-239169


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2011-09-01):
[0001193125-11-239169:note_history:1]
| 15. | Commitments and Contingencies |
  (was, 2011-03-04, similarity 0.9118):
[0001193125-11-056223:note_history:1]
15. Commitments and Contingencies

- changed (2011-09-01):
[0001193125-11-239169:note_history:2]
Future annual minimum lease payments under all non-cancelable facilities and equipment operating leases with an initial term in excess of one year as of July 29, 2011 totaled $312.3 million.
  (was, 2011-03-04, similarity 0.9863):
[0001193125-11-056223:note_history:2]
Future annual minimum lease payments under all non-cancelable facilities and equipment operating leases with an initial term in excess of one year as of January 28, 2011 totaled $257.7 million.

- added (2011-09-01):
[0001193125-11-239169:note_history:3]
As of July 29, 2011, we have four leasing arrangements (Leasing Arrangements 1, 2, 3 and 4) with BNP Paribas LLC (BNPPLC) some of which require us to lease certain of our land to BNPPLC for a period of 99 years and to lease approximately 0.6 million square feet of office space for our headquarters in Sunnyvale, which had an original cost of $149.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on LIBOR plus a spread or a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of the leases for two consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of the lease terms, we must elect one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received from the third-party and BNPPLC's cost up to 85% of cost (residual guarantee); or (iii) pay BNPPLC supplemental payments for an amount equal to the difference between the residual guarantee and fair value, in which event we may recoup some or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period.

- added (2011-09-01):
[0001193125-11-239169:note_history:4]
These leases require us to maintain specified financial covenants with which we were in compliance as of July 29, 2011.

- added (2011-09-01):
[0001193125-11-239169:note_history:5]
As of July 29, 2011, we estimated that the fair value of the properties under synthetic lease was $51.0 million below the residual guarantee. We are accruing for this deficiency over the remaining terms of the respective leases. As of July 29, 2011, a deficiency reserve of $21.6 million was included in other long-term liabilities

- changed (2011-09-01):
[0001193125-11-239169:note_history:6]
In the normal course of business we make commitments to our third-party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. We had $191.8 million in non-cancelable purchase commitments with our contract manufacturers as of July 29, 2011. In addition, we recorded a liability for firm non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to product cost of sales. As of July 29, 2011 and April 29, 2011, such liability amounted to $4.5 million for both periods and is included in other current liabilities in the condensed consolidated balance sheets.
  (was, 2011-03-04, similarity 0.9159):
[0001193125-11-056223:note_history:6]
In the normal course of business we make commitments to our third party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. We had $165 million in non-cancelable purchase commitments with our contract manufacturers as of January 28, 2011. In addition, we recorded a liability for firm non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to product cost of sales. As of January 28, 2011 and April 30, 2010, such liability amounted to $7.2 million and $3.8 million, respectively, and is included in other current liabilities in the consolidated balance sheets.

- changed (2011-09-01):
[0001193125-11-239169:note_history:7]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course business for which we have not received goods or services. We had $25.0 million in capital purchase commitments and $249.2 million in other purchase commitments as of July 29, 2011.
  (was, 2011-03-04, similarity 0.9898):
[0001193125-11-056223:note_history:7]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course business for which we have not received goods or services. We had $33.4 million in capital purchase commitments and $317.1 million in other purchase commitments as of January 28, 2011.

- added (2011-09-01):
[0001193125-11-239169:note_history:8]
.

- changed (2011-09-01):
[0001193125-11-239169:note_history:9]
We provide customers a warranty on software of ninety days to five years and a warranty on hardware of one to five years. The following table summarizes our warranty reserves (in millions):
  (was, 2011-03-04, similarity 0.9274):
[0001193125-11-056223:note_history:9]
We provide customers a warranty on software of ninety days and a warranty on hardware of three years. The following table summarizes our warranty reserves (in millions):

- changed (2011-09-01):
[0001193125-11-239169:note_history:10]
|  |  | Three Months Ended |  |
|  |  | July 29,2011 |  |  | July 30,2010 |  |
| Beginning balance |  | $ | 40.5 |  |  | $ | 31.9 |  |
| Liability assumed in acquisition |  |  | 17.5 |  |  |  | 0.0 |  |
| Expense accrued during the period |  |  | 11.7 |  |  |  | 5.9 |  |
| Warranty costs incurred |  |  | (10.2 | ) |  |  | (5.7 | ) |
| Ending balance |  | $ | 59.5 |  |  | $ | 32.1 |  |
  (was, 2011-03-04, similarity 0.6759):
[0001193125-11-056223:note_history:10]
|  |  | Nine Months Ended |  |
|  |  | January 28,2011 |  |  | January 29,2010 |  |
| Beginning balance |  | $ | 31.9 |  |  | $ | 42.3 |  |
| Expense accrued during the period |  |  | 20.9 |  |  |  | 12.9 |  |
| Warranty costs incurred |  |  | (17.1 | ) |  |  | (20.5 | ) |
| Ending balance |  | $ | 35.7 |  |  | $ | 34.7 |  |

- changed (2011-09-01):
[0001193125-11-239169:note_history:11]
We have both nonrecourse and recourse lease financing arrangements with third-party leasing companies through new and preexisting relationships with customers. In addition, from time to time we provide guarantees for a portion of other financing arrangements under which we could be called upon to make payments to our third-party funding companies in the event of nonpayment by end-user customers. Under the terms of the nonrecourse leases, we do not have any continuing obligations or liabilities to the third-party leasing companies. Under the terms of the recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee, we defer the revenues associated with the end-user financing arrangement in accordance with our revenue recognition policies. As of July 29, 2011, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $97.9 million, and the related deferred revenue and cost of revenues totaled approximately $102.0 million and $9.3 million, respectively. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.
  (was, 2011-03-04, similarity 0.9975):
[0001193125-11-056223:note_history:11]
We have both nonrecourse and recourse lease financing arrangements with third-party leasing companies through new and preexisting relationships with customers. In addition, from time to time we provide guarantees for a portion of other financing arrangements under which we could be called upon to make payments to our third-party funding companies in the event of nonpayment by end-user customers. Under the terms of the nonrecourse leases, we do not have any continuing obligations or liabilities to the third-party leasing companies. Under the terms of the recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee, we defer the revenues associated with the end-user financing arrangement in accordance with our revenue recognition policies. As of January 28, 2011, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $75.6 million, and the related deferred revenue and cost of revenues totaled approximately $76.8 million and $8.3 million, respectively. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

- changed (2011-09-01):
[0001193125-11-239169:note_history:12]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as of July 29, 2011, as the outcome of these legal matters is currently not determinable.
  (was, 2011-03-04, similarity 0.984):
[0001193125-11-056223:note_history:12]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as of January 28, 2011, as the outcome of these legal matters is currently not determinable.

- added (2011-09-01):
[0001193125-11-239169:note_history:13]
On October 13, 2010, Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of California, Santa Clara County. The lawsuit named 15 of our current and former directors as defendants. On February 3, 2011, the plaintiff filed an amended complaint in response to motions to dismiss that we and the individual defendants had filed. Like the original complaint, the amended complaint includes claims of breach of fiduciary duty and waste of corporate assets and alleges that the defendants failed to monitor internal controls to ensure that we complied with legal requirements in our General Services Administration (GSA) contracting activities, resulting in us incurring defense and settlement costs. The amended complaint seeks disgorgement of salaries and other compensation from the defendants and additional unspecified damages. We and the individual defendants filed motions to dismiss the amended complaint in early March 2011, and the hearing on these motions was held on July 15, 2011. The Court granted the motions to dismiss and dismissed the plaintiff's complaint, but permitted plaintiff leave to amend the complaint on or before September 16, 2011. On August 10, 2011, Amalgamated Bank filed a complaint in Delaware Chancery Court against NetApp, Inc. for the purpose of obtaining, in a summary proceeding, books and records to be used in the California lawsuit. We will respond to this Complaint on or before August 30, 2011.

- removed (2011-09-01):
[0001193125-11-056223:note_history:14]
On October 13, 2010, Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of California, Santa Clara County. The lawsuit named 15 current and former directors of the Company as defendants. On February 3, 2011, in response to motions to dismiss that we and the individual defendants filed, the plaintiff filed an amended complaint. Like the original complaint, the amended complaint includes claims of breach of fiduciary duty and waste of corporate assets and alleges that the defendants failed to monitor internal controls to ensure that the Company complied with legal requirements in our General Services Administration (GSA) contracting activities, resulting in the Company incurring defense and settlement costs. The amended complaint seeks disgorgement of salaries and other compensation from the defendants and additional unspecified damages. The Company and the individual defendants will file motions to dismiss the amended complaint in early March 2011.


## ntap:UseOfEstimatesTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2011-09-01):
[0001193125-11-056223:note_history:15]
Use of Estimates — The preparation of the consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; self-insurance; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ from those estimates.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2011-09-01):
[0001193125-11-239169:note_history:16]
| 2. | Condensed Consolidated Financial Statements |

- added (2011-09-01):
[0001193125-11-239169:note_history:17]
Fiscal Year — We operate on a 52-week or 53-week year ending on the last Friday in April. The first quarters of fiscal 2012 and 2011 were both 13-week periods.

- added (2011-09-01):
[0001193125-11-239169:note_history:18]
Basis of Presentation — The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments that are, in the opinion of management, necessary for a fair presentation of our financial position, results of operations, and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, the statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with the Company's audited consolidated financial statements as of and for the fiscal year ended April 29, 2011 contained in the Company's Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 23, 2011. The results of operations for the three month period ended July 29, 2011 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- added (2011-09-01):
[0001193125-11-239169:note_history:19]
Financial Statements Presentation — Certain prior period amounts have been reclassified in the accompanying condensed consolidated financial statements to conform to current year presentation.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2011-09-01):
[0001193125-11-239169:note_history:20]
| 3. | Significant Accounting Policies |
  (was, 2011-03-04, similarity 0.9167):
[0001193125-11-056223:note_history:20]
3. Significant Accounting Policies

- changed (2011-09-01):
[0001193125-11-239169:note_history:21]
There have been no significant changes in our significant accounting policies for the three month period ended July 29, 2011, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2011.
  (was, 2011-03-04, similarity 0.972):
[0001193125-11-056223:note_history:21]
There have been no significant changes in our significant accounting policies for the nine month period ended January 28, 2011, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 30, 2010.

- added (2011-09-01):
[0001193125-11-239169:note_history:22]
Accounting Standards Recently Adopted

- added (2011-09-01):
[0001193125-11-239169:note_history:23]
Revenue Recognition

- added (2011-09-01):
[0001193125-11-239169:note_history:24]
In October 2009, the Financial Accounting Standards Board (FASB) amended the accounting standards for revenue recognition to exclude tangible products containing software components and non-software components that function together to deliver the tangible product's essential functionality from the scope of the software revenue recognition guidance. Concurrently, the FASB also amended the accounting standards for multiple deliverable revenue arrangements to:

- changed (2011-09-01):
[0001193125-11-239169:note_history:25]
|  | • |  | provide updated guidance on whether multiple deliverables exist, how the deliverables in an arrangement should be separated, and how the arrangement consideration should be allocated among its elements; |
  (was, 2011-03-04, similarity 0.7944):
[0001193125-11-056223:note_history:25]
|  | (i) | provide updated guidance on how the deliverables in an arrangement should be separated, and how the consideration should be allocated; |

- added (2011-09-01):
[0001193125-11-239169:note_history:26]
|  | • |  | require an entity to allocate revenue in an arrangement that has separate units of accounting using best estimated selling prices (BESP) of deliverables if a vendor does not have vendor-specific objective evidence (VSOE) of fair value or third-party evidence of selling price (TPE); and |

- changed (2011-09-01):
[0001193125-11-239169:note_history:27]
|  | • |  | eliminate the use of the residual method and require an entity to allocate revenue using the relative selling price method to the separate units of accounting. |
  (was, 2011-03-04, similarity 0.859):
[0001193125-11-056223:note_history:27]
|  | (iii) | eliminate the use of the residual method and require an entity to allocate revenue using the relative selling price method; and |

- added (2011-09-01):
[0001193125-11-239169:note_history:28]
We elected to early adopt these standards in the fourth quarter of fiscal 2011, and the standards were applied retrospectively from the beginning of fiscal 2011 for new and materially modified revenue arrangements originating after April 30, 2010. Previously reported quarterly results have been adjusted to reflect the adoption of these standards and differ from the originally reported results.

- added (2011-09-01):
[0001193125-11-239169:note_history:29]
The majority of our products are hardware systems containing software components that function together to provide the essential functionality of the product. Therefore, our hardware systems and software components essential to the functionality of the hardware systems are considered non-software deliverables and therefore are not subject to industry-specific software revenue recognition guidance.

- added (2011-09-01):
[0001193125-11-239169:note_history:30]
Our product revenue also includes revenue from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer negotiated refunds or return rights for the delivered elements.

- added (2011-09-01):
[0001193125-11-239169:note_history:31]
For transactions entered into or materially modified after April 30, 2010, we recognize revenue in accordance with the new accounting standards when applicable. Certain arrangements with multiple deliverables may continue to have software deliverables that are subject to the existing software revenue recognition guidance along with non-software deliverables that are subject to the new standards. The revenue for these multiple element arrangements is allocated to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement using the selling price hierarchy set forth in the standards.

- added (2011-09-01):
[0001193125-11-239169:note_history:32]
For our non-software deliverables, we recognize revenue based on the new standards and allocate the arrangement consideration based on the relative selling price of the deliverables. For our non-software deliverables, we use BESP as our selling price. For our software entitlements and support services, we generally use VSOE as our selling price. When we are unable to establish selling price using VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement consideration.

- added (2011-09-01):
[0001193125-11-239169:note_history:33]
VSOE of fair value for elements of an arrangement is based upon the normal pricing and discounting practices for those services when sold separately. In determining VSOE, we require that a substantial majority of the selling prices for an element fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer classifications, and other variables in determining VSOE.

- added (2011-09-01):
[0001193125-11-239169:note_history:34]
When VSOE cannot be established, the Company attempts to establish selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE for our products or services.

- added (2011-09-01):
[0001193125-11-239169:note_history:35]
When we are unable to establish selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

- added (2011-09-01):
[0001193125-11-239169:note_history:36]
We regularly review VSOE, TPE, and BESP and maintain internal controls over the establishment and updates of these estimates.

- added (2011-09-01):
[0001193125-11-239169:note_history:37]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal year 2011, we recognize revenue based on software revenue recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be delivered at a future date and VSOE of fair value of all undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is software entitlements and maintenance (SEM) and/or service. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the contract fee is recognized as product revenue. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire arrangement is recognized ratably over the maintenance period.

- added (2011-09-01):
[0001193125-11-239169:note_history:38]
In June 2011, the FASB issued new guidance on the presentation of comprehensive income. Specifically, the new guidance requires an entity to present components of net income and other comprehensive income in one continuous statement, referred to as the statement of comprehensive income, or in two separate, but consecutive statements. The new guidance eliminates the current option to report other comprehensive income and its components in the statement of stockholders' equity. While the new guidance changes the presentation of comprehensive income, there are no changes to the components that are recognized in net income or other comprehensive income under current accounting guidance. This new guidance is effective for us beginning in our first quarter of fiscal 2013 and is required to be applied retrospectively. There will be no impact to the Company's results as the guidance relates only to financial statement presentation.

- added (2011-09-01):
[0001193125-11-239169:note_history:39]
In May 2011, the FASB issued new guidance for fair value measurements to provide a consistent definition of fair value and ensure that the fair value measurement and disclosure requirements are similar between GAAP and International Financial Reporting Standards. The guidance changes certain fair value measurement principles and enhances the disclosure requirements particularly for level 3 fair value measurements. The guidance is effective for us prospectively beginning in the fourth quarter of fiscal 2012, and we are currently evaluating the impact of adoption on our financial statements.

- added (2011-09-01):
[0001193125-11-239169:note_history:40]
Use of Estimates

- changed (2011-09-01):
[0001193125-11-239169:note_history:41]
The preparation of the consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; self-insurance; stock-based compensation; loss contingencies; investment impairments; income taxes, and fair value measurements. Actual results could differ from those estimates.
  (was, 2011-03-04, similarity 0.9871):
[0001193125-11-056223:note_history:41]
Use of Estimates — The preparation of the consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; self-insurance; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ from those estimates.

- removed (2011-09-01):
[0001193125-11-056223:note_history:42]
In October 2009, the FASB amended the accounting standards for multiple deliverable revenue arrangements to:

- removed (2011-09-01):
[0001193125-11-056223:note_history:43]
|  | (ii) | require an entity to allocate revenue in an arrangement using best estimate of selling prices (BESP) of deliverables if a vendor does not have vendor-specific objective evidence of selling price (VSOE) or third-party evidence of selling price (TPE); |

- removed (2011-09-01):
[0001193125-11-056223:note_history:44]
|  | (iv) | expand the disclosure requirements to provide both qualitative and quantitative information about the significant judgments made in applying the revised guidance and subsequent changes in those judgments that may significantly affect the timing or amount of revenue recognition. |

- removed (2011-09-01):
[0001193125-11-056223:note_history:45]
In addition, in October 2009, the FASB amended the accounting standards for revenue recognition to exclude tangible products containing software components and non-software components that function together to deliver the tangible product's essential functionality from the scope of the software revenue recognition guidance. The revised revenue recognition accounting standards are effective for revenue arrangements entered into or materially modified in fiscal years beginning on or after June 15, 2010 and shall be applied on a prospective basis. Earlier application is permitted. We are required to adopt this standard no later than the beginning of fiscal 2012, which begins on April 30, 2011. We are assessing the impact of the new accounting standards on our financial position and results of operations.


## ntap:ContractualMaturitiesOfDebtInvestmentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2011-09-01):
[0001193125-11-056223:note_history:46]
| Debt Investment Maturities |  | Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 912.3 |  |  | $ | 914.8 |  |
| Due in one through five years |  |  | 1,961.8 |  |  |  | 1,966.4 |  |
| Due in five through ten years |  |  | 0.0 |  |  |  | 0.0 |  |
| Due after ten years* |  |  | 69.6 |  |  |  | 65.1 |  |
|  |  | $ | 2,943.7 |  |  | $ | 2,946.3 |  |

- removed (2011-09-01):
[0001193125-11-056223:note_history:47]
| * | Consists of auction rate securities which have contractual maturities of greater than 10 years. |


## ntap:DebtDiscountAndIssuanceCostTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2011-09-01):
[0001193125-11-239169:note_history:48]
| Remaining debt discount |  | $ | 101.9 |  |
| Remaining issuance costs |  |  | 8.8 |  |
| Remaining life of the Notes (years) |  |  | 1.8 |  |
  (was, 2011-03-04, similarity 0.9922):
[0001193125-11-056223:note_history:48]
| Remaining debt discount |  | $ | 127.3 |  |
| Remaining issuance costs |  | $ | 11.1 |  |
| Remaining life of the Notes (years) |  |  | 2.3 |  |


## ntap:LongTermDebtByCurrentAndNonCurrentTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2011-09-01):
[0001193125-11-239169:note_history:49]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.4 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.4 |  |  |  | 6.0 |  |
|  |  | $ | 11.8 |  |  | $ | 11.5 |  |

- removed (2011-09-01):
[0001193125-11-056223:note_history:50]
|  |  | January 28, 2011 |  |  | April 30, 2010 |  |
| Current portion of other long-term financing arrangements |  | $ | 5.5 |  |  | $ | 0.0 |  |
| Non-current portion of other long-term financing arrangements |  |  | 7.4 |  |  |  | 0.0 |  |
|  |  | $ | 12.9 |  |  | $ | 0.0 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2011-09-01):
[0001193125-11-239169:note_history:51]
| 9. | Financing Arrangements |
  (was, 2011-03-04, similarity 0.8889):
[0001193125-11-056223:note_history:51]
9. Financing Arrangements

- changed (2011-09-01):
[0001193125-11-239169:note_history:52]
On June 10, 2008, we issued $1,265.0 million aggregate principal amount of 1.75% Convertible Senior Notes due 2013 (the Notes). The Notes are unsecured, unsubordinated obligations of the Company. Interest is payable in cash semi-annually at a rate of 1.75% per annum. The Notes will mature on June 1, 2013 unless repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified below, based on an initial conversion rate of 31.40 shares of common stock per $1,000 principal amount of Notes (which represents an initial effective conversion price of the Notes of approximately $31.85 per share), subject to adjustment as described in the indenture governing the Notes.
  (was, 2011-03-04, similarity 0.6791):
[0001193125-11-056223:note_history:52]
On June 10, 2008, we issued $1,265.0 million aggregate principal amount of 1.75% Convertible Senior Notes due 2013 (the Notes). The Notes are unsecured, unsubordinated obligations of the Company. Interest is payable in cash semi-annually at a rate of 1.75% per annum. The Notes will mature on June 1, 2013 unless repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified in the indenture governing the Notes, based on an initial conversion rate of approximately 31.40 shares of common stock per $1,000 principal amount of Notes (which represents an initial effective conversion price of the Notes of approximately $31.85 per share), subject to adjustment as described in the indenture governing the Notes. For at least 20 trading days during the 30 consecutive trading days ended December 31, 2010, our common stock price exceeded the conversion threshold price of $41.41 per share set forth for these Notes. Accordingly, the notes are convertible at the holder's option through March 31, 2011. Upon conversion of any Notes, we will deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal amount of the Notes, shares of our common stock.

- added (2011-09-01):
[0001193125-11-239169:note_history:53]
The Notes are not redeemable by us prior to the maturity date. In the event of a fundamental change (as defined in the indenture for the Notes), holders of the Notes may require us to repurchase all or a portion of their Notes at a repurchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid interest, if any, to, but excluding, the fundamental change repurchase date.

- added (2011-09-01):
[0001193125-11-239169:note_history:54]
The holders of the Notes may convert their Notes until the close of business on the scheduled trading day immediately preceding the maturity date if any of the following conditions are met: (1) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price of the Notes for each day in the measurement period was less than 98% of an amount equal to (i) the last reported sale price of our common stock multiplied by (ii) the conversion rate for the Notes on each such day; (2) during any calendar quarter (and only during such calendar quarter) if the last reported sale price of our common stock for 20 or more trading days in a period of 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter exceeds 130% of the applicable conversion price in effect for the Notes on the last trading day of such immediately preceding calendar quarter; or (3) upon the occurrence of specified corporate transactions set forth in the indenture for the Notes. On or after March 1, 2013, until the scheduled trading day immediately preceding the maturity date, holders of the Notes may convert their Notes regardless of the foregoing conditions. Upon conversion, a holder will receive cash in an amount equal to the lesser of the conversion value and the principal amount of the Notes, and any shares of our common stock for any conversion value in excess of the principal amount of the Notes, if any. Holders of the Notes who convert their Notes in connection with a fundamental change will, under certain circumstances, be entitled to a make-whole premium in the form of an increase in the conversion rate.

- added (2011-09-01):
[0001193125-11-239169:note_history:55]
For at least 20 trading days during the 30 consecutive trading days ended June 30, 2011 and March 31, 2011, respectively, our common stock price exceeded the conversion threshold price of $41.41 per share set forth for these Notes. Accordingly, the Notes are convertible at the holder's option through September 30, 2011 and were convertible at the holder's option through June 30, 2011, respectively. As such, the carrying value of the Notes was classified as a current liability as of July 29, 2011 and April 29, 2011. Since the Notes are convertible at the option of the holder and the principal amount is required to be paid in cash, the difference between the principal amount and the carrying value of the Notes is reflected as convertible debt in mezzanine on our condensed consolidated balance sheets as of July 29, 2011 and April 29, 2011. The determination of whether or not the Notes are convertible must continue to be performed quarterly. Consequently, the Notes may not be convertible in future quarters, and therefore may be classified as long-term debt, if the contingent conversion thresholds are not met in such quarters.

- added (2011-09-01):
[0001193125-11-239169:note_history:56]
Upon conversion of any Notes, we deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal amount of the Notes, shares of our common stock. As of July 29, 2011, shares issued related to the Notes were minimal. Based on the closing price of our common stock of $47.52 on July 29, 2011, the if-converted value of our Notes exceeded their principal amount by approximately $649.4 million.

- changed (2011-09-01):
[0001193125-11-239169:note_history:57]
The following table reflects the carrying value of our convertible debt as of July 29, 2011 and April 29, 2011, respectively (in millions):
  (was, 2011-03-04, similarity 0.8037):
[0001193125-11-056223:note_history:57]
The following table reflects the carrying value of our convertible debt (in millions):

- changed (2011-09-01):
[0001193125-11-239169:note_history:58]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (101.9 | ) |  |  | (114.6 | ) |
| Net current carrying amount of Notes |  | $ | 1,163.1 |  |  | $ | 1,150.4 |  |
  (was, 2011-03-04, similarity 0.9633):
[0001193125-11-056223:note_history:58]
|  |  | January 28,2011 |  |  | April 30,2010 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (127.3 | ) |  |  | (163.5 | ) |
| Net carrying amount of Notes |  | $ | 1,137.7 |  |  | $ | 1,101.5 |  |

- changed (2011-09-01):
[0001193125-11-239169:note_history:59]
The following table presents the amount of interest cost recognized relating to both the contractual interest coupon and the amortization of the discount and issuance costs (in millions):
  (was, 2011-03-04, similarity 0.8862):
[0001193125-11-056223:note_history:59]
The following table presents the amount of interest expense recognized at an effective interest rate of 6.31% relating to both the contractual interest coupon and the amortization of the discount and issuance costs (in millions):

- changed (2011-09-01):
[0001193125-11-239169:note_history:60]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |
| Amortization of debt discount |  |  | 12.6 |  |  |  | 11.9 |  |
| Amortization of issuance costs |  |  | 1.1 |  |  |  | 1.0 |  |
| Total interest expense recognized |  | $ | 19.2 |  |  | $ | 18.4 |  |
  (was, 2011-03-04, similarity 0.7834):
[0001193125-11-056223:note_history:60]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2011 |  |  | January 29, 2010 |  |  | January 28, 2011 |  |  | January 29, 2010 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 16.5 |  |  | $ | 16.9 |  |
| Amortization of debt discount |  |  | 12.2 |  |  |  | 11.4 |  |  |  | 36.1 |  |  |  | 34.8 |  |
| Amortization of issuance costs |  |  | 1.1 |  |  |  | 1.0 |  |  |  | 3.1 |  |  |  | 3.0 |  |
| Total interest expense recognized |  | $ | 18.8 |  |  | $ | 17.9 |  |  | $ | 55.7 |  |  | $ | 54.7 |  |

- changed (2011-09-01):
[0001193125-11-239169:note_history:61]
The following table reflects the remaining debt discount and issuance costs as of July 29, 2011 (in millions):
  (was, 2011-03-04, similarity 0.9717):
[0001193125-11-056223:note_history:61]
The following table reflects the remaining debt discount and issuance cost as of January 28, 2011 (in millions):

- changed (2011-09-01):
[0001193125-11-239169:note_history:62]
| Remaining debt discount |  | $ | 101.9 |  |
| Remaining issuance costs |  |  | 8.8 |  |
| Remaining life of the Notes (years) |  |  | 1.8 |  |
  (was, 2011-03-04, similarity 0.9922):
[0001193125-11-056223:note_history:62]
| Remaining debt discount |  | $ | 127.3 |  |
| Remaining issuance costs |  | $ | 11.1 |  |
| Remaining life of the Notes (years) |  |  | 2.3 |  |

- changed (2011-09-01):
[0001193125-11-239169:note_history:63]
| • |  | Note Hedges. As of July 29, 2011 and April 29, 2011, we have arrangements with counterparties to buy up to approximately 31.8 million shares, subject to anti-dilution adjustments, of our common stock at a price of $31.85 per share, subject to adjustment. The Note hedge transactions will expire at the earlier of (1) the last day on which any Notes remain outstanding and (2) the scheduled trading day immediately preceding the maturity date of the Notes. Upon exercise of the Note hedges, we have the option to receive cash or shares of our common stock equal to the difference between the then market price and the strike price of the hedges. |
  (was, 2011-03-04, similarity 0.9757):
[0001193125-11-056223:note_history:63]
|  | • |  | Note Hedges. As of January 28, 2011 and April 30, 2010, we have transactions with counterparties to buy up to approximately 31.8 million shares, subject to anti-dilution adjustments, of our common stock at a price of $31.85 per share, subject to adjustment. The Note hedge transactions will expire at the earlier of (1) the last day on which any Notes remain outstanding and (2) the scheduled trading day immediately preceding the maturity date of the Notes. Upon exercise of the note hedges, we have the option to receive cash or shares of our common stock equal to the difference between the then market price and the strike price of the hedges. |

- changed (2011-09-01):
[0001193125-11-239169:note_history:64]
|  | • |  | Warrants. As of July 29, 2011 and April 29, 2011, we have outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |
  (was, 2011-03-04, similarity 0.9926):
[0001193125-11-056223:note_history:64]
|  | • |  | Warrants. As of January 28, 2011 and April 30, 2010, we have outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |

- changed (2011-09-01):
[0001193125-11-239169:note_history:65]
As of July 29, 2011, we are subject to potential dilution on the approximately 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of approximately $31.85.
  (was, 2011-03-04, similarity 0.986):
[0001193125-11-056223:note_history:65]
As of January 28, 2011, we are subject to potential dilution on the approximately 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of approximately $31.85.

- added (2011-09-01):
[0001193125-11-239169:note_history:66]
As of July 29, 2011, receipts of shares related to the Note hedge transactions were minimal and no cash or shares were delivered related to the warrant transactions.

- changed (2011-09-01):
[0001193125-11-239169:note_history:67]
As of July 29, 2011, the approximate fair value of the principal amount of our Notes, which includes the debt and equity components, was approximately $1,977.8 million, or 156% of the face value of the Notes, based upon quoted market information.
  (was, 2011-03-04, similarity 0.9807):
[0001193125-11-056223:note_history:67]
As of January 28, 2011, the approximate fair value of the principal amount of our Notes, which includes the debt and equity components, was approximately $2.3 billion, or 179% of the face value of the Notes, based upon quoted market information.

- added (2011-09-01):
[0001193125-11-239169:note_history:68]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.4 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.4 |  |  |  | 6.0 |  |
|  |  | $ | 11.8 |  |  | $ | 11.5 |  |

- removed (2011-09-01):
[0001193125-11-056223:note_history:69]
As of January 28, 2011, we had not issued any shares related to the Notes. Based on the closing price of our common stock of $54.03 on January 28, 2011, the if-converted value of our Notes exceeded their principal amount by approximately $911.6 million.

- removed (2011-09-01):
[0001193125-11-056223:note_history:70]
|  |  | January 28, 2011 |  |  | April 30, 2010 |  |
| Current portion of other long-term financing arrangements |  | $ | 5.5 |  |  | $ | 0.0 |  |
| Non-current portion of other long-term financing arrangements |  |  | 7.4 |  |  |  | 0.0 |  |
|  |  | $ | 12.9 |  |  | $ | 0.0 |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2011-09-01):
[0001193125-11-056223:note_history:71]
|  |  | January 28,2011 |  |  | April 30,2010 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (127.3 | ) |  |  | (163.5 | ) |
| Net carrying amount of Notes |  | $ | 1,137.7 |  |  | $ | 1,101.5 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2011-09-01):
[0001193125-11-239169:note_history:72]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (101.9 | ) |  |  | (114.6 | ) |
| Net current carrying amount of Notes |  | $ | 1,163.1 |  |  | $ | 1,150.4 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2011-09-01):
[0001193125-11-239169:note_history:73]
Revenue Recognition

- added (2011-09-01):
[0001193125-11-239169:note_history:74]
In October 2009, the Financial Accounting Standards Board (FASB) amended the accounting standards for revenue recognition to exclude tangible products containing software components and non-software components that function together to deliver the tangible product's essential functionality from the scope of the software revenue recognition guidance. Concurrently, the FASB also amended the accounting standards for multiple deliverable revenue arrangements to:

- added (2011-09-01):
[0001193125-11-239169:note_history:75]
|  | • |  | provide updated guidance on whether multiple deliverables exist, how the deliverables in an arrangement should be separated, and how the arrangement consideration should be allocated among its elements; |

- added (2011-09-01):
[0001193125-11-239169:note_history:76]
|  | • |  | require an entity to allocate revenue in an arrangement that has separate units of accounting using best estimated selling prices (BESP) of deliverables if a vendor does not have vendor-specific objective evidence (VSOE) of fair value or third-party evidence of selling price (TPE); and |

- added (2011-09-01):
[0001193125-11-239169:note_history:77]
|  | • |  | eliminate the use of the residual method and require an entity to allocate revenue using the relative selling price method to the separate units of accounting. |

- added (2011-09-01):
[0001193125-11-239169:note_history:78]
We elected to early adopt these standards in the fourth quarter of fiscal 2011, and the standards were applied retrospectively from the beginning of fiscal 2011 for new and materially modified revenue arrangements originating after April 30, 2010. Previously reported quarterly results have been adjusted to reflect the adoption of these standards and differ from the originally reported results.

- added (2011-09-01):
[0001193125-11-239169:note_history:79]
The majority of our products are hardware systems containing software components that function together to provide the essential functionality of the product. Therefore, our hardware systems and software components essential to the functionality of the hardware systems are considered non-software deliverables and therefore are not subject to industry-specific software revenue recognition guidance.

- added (2011-09-01):
[0001193125-11-239169:note_history:80]
Our product revenue also includes revenue from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer negotiated refunds or return rights for the delivered elements.

- added (2011-09-01):
[0001193125-11-239169:note_history:81]
For transactions entered into or materially modified after April 30, 2010, we recognize revenue in accordance with the new accounting standards when applicable. Certain arrangements with multiple deliverables may continue to have software deliverables that are subject to the existing software revenue recognition guidance along with non-software deliverables that are subject to the new standards. The revenue for these multiple element arrangements is allocated to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement using the selling price hierarchy set forth in the standards.

- added (2011-09-01):
[0001193125-11-239169:note_history:82]
For our non-software deliverables, we recognize revenue based on the new standards and allocate the arrangement consideration based on the relative selling price of the deliverables. For our non-software deliverables, we use BESP as our selling price. For our software entitlements and support services, we generally use VSOE as our selling price. When we are unable to establish selling price using VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement consideration.

- added (2011-09-01):
[0001193125-11-239169:note_history:83]
VSOE of fair value for elements of an arrangement is based upon the normal pricing and discounting practices for those services when sold separately. In determining VSOE, we require that a substantial majority of the selling prices for an element fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer classifications, and other variables in determining VSOE.

- added (2011-09-01):
[0001193125-11-239169:note_history:84]
When VSOE cannot be established, the Company attempts to establish selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE for our products or services.

- added (2011-09-01):
[0001193125-11-239169:note_history:85]
When we are unable to establish selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

- added (2011-09-01):
[0001193125-11-239169:note_history:86]
We regularly review VSOE, TPE, and BESP and maintain internal controls over the establishment and updates of these estimates.

- added (2011-09-01):
[0001193125-11-239169:note_history:87]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal year 2011, we recognize revenue based on software revenue recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be delivered at a future date and VSOE of fair value of all undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is software entitlements and maintenance (SEM) and/or service. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the contract fee is recognized as product revenue. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire arrangement is recognized ratably over the maintenance period.


## us-gaap:ScheduleOfSubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2011-09-01):
[0001193125-11-239169:note_history:88]
| 16. | Subsequent Event |
  (was, 2011-03-04, similarity 0.8571):
[0001193125-11-056223:note_history:88]
16. Subsequent Event

- added (2011-09-01):
[0001193125-11-239169:note_history:89]
On August 19, 2011, we entered into a new ASR with Wells Fargo Bank, National Association (Wells Fargo). Pursuant to the terms of the ASR, we provided Wells Fargo a prepayment of $400.0 million to purchase shares of our common stock. The aggregate number of shares ultimately purchased will be determined based on the volume weighted average share price of our common stock over a specified period of time, subject to certain collar provisions that establish a minimum and maximum number of shares that may be repurchased. The actual number of shares repurchased will be determined at the completion of the ASR contract. Shares will be delivered over the term of the ASR contract, which is expected to end no later than December 30, 2011, although the completion date may be accelerated at Wells Fargo's option.

- removed (2011-09-01):
[0001193125-11-056223:note_history:90]
On January 31, 2011, we completed the acquisition of Akorri Networks, Inc., a privately held company headquartered in Massachusetts, for approximately $60 million in cash. Akorri is a provider of data center management software focused on performance and capacity analytics for virtualized, shared information technology infrastructures. As of January 28, 2011, we had incurred $0.6 million in related expenses which are included in acquisition related income, net, in our condensed consolidated statements of operations.
