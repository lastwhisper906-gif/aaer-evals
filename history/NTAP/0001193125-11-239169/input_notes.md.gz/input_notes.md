# NTAP notes — 0001193125-11-239169


## ntap:AmortizationFiniteLivedIntangibleAssetsTextBlock

[0001193125-11-239169:notes:1]
|  |  | Three Months Ended |  |  | Statements of Operations Classifications |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |  |
| Developed technology |  | $ | 13.9 |  |  | $ | 4.4 |  |  | Cost of product revenues |
| Customer contracts/relationships |  |  | 9.0 |  |  |  | 0.8 |  |  | Sales and marketing |
| Trademarks and trade names |  |  | 1.2 |  |  |  | 0.3 |  |  | Sales and marketing |
| Covenants not to compete |  |  | 0.2 |  |  |  | 0.0 |  |  | Sales and marketing / Research and development |
|  |  | $ | 24.3 |  |  | $ | 5.5 |  |  |  |


## ntap:AssetsByGeographicAreasTextBlock

[0001193125-11-239169:notes:2]
|  |  | July 29, 2011 |  |  | April 29, 2011 |  |
| United States |  | $ | 910.0 |  |  | $ | 840.2 |  |
| International |  |  | 83.3 |  |  |  | 71.4 |  |
| Total property and equipment |  | $ | 993.3 |  |  | $ | 911.6 |  |


## ntap:CashAndCashEquivalentsAndInvestmentsTableTextBlock

[0001193125-11-239169:notes:3]
|  |  | July 29, 2011 |  |  | April 29, 2011 |  |
| United States |  | $ | 2,394.0 |  |  | $ | 3,037.5 |  |
| International |  |  | 2,386.3 |  |  |  | 2,211.8 |  |
| Total cash, cash equivalents, restricted cash and investments |  | $ | 4,780.3 |  |  | $ | 5,249.3 |  |


## ntap:DebtDiscountAndIssuanceCostTextBlock

[0001193125-11-239169:notes:4]
| Remaining debt discount |  | $ | 101.9 |  |
| Remaining issuance costs |  |  | 8.8 |  |
| Remaining life of the Notes (years) |  |  | 1.8 |  |


## ntap:DisclosureOfShareBasedCompensationAdditionalInformationRelatedToStockOptionsTextBlock

[0001193125-11-239169:notes:5]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Weighted-average fair value per share granted |  | $ | 17.24 |  |  | $ | 13.36 |  |
| Weighted-average fair value per share of options assumed in acquisition |  |  | N/A |  |  | $ | 21.15 |  |
| Intrinsic value of options exercised |  | $ | 43.8 |  |  | $ | 110.5 |  |
| Proceeds received from the exercise of stock options |  | $ | 35.0 |  |  | $ | 127.6 |  |
| Fair value of options vested |  | $ | 18.4 |  |  | $ | 28.0 |  |


## ntap:FairValueOfFinancialInstrumentsPolicyTextBlock

[0001193125-11-239169:notes:6]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the hierarchical levels of inputs to measure fair value:

[0001193125-11-239169:notes:7]
[same as prior period, unchanged from 0001193125-11-056223:notes:34]

[0001193125-11-239169:notes:8]
Level 2: Inputs reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0001193125-11-239169:notes:9]
[same as prior period, unchanged from 0001193125-11-056223:notes:36]

[0001193125-11-239169:notes:10]
[same as prior period, unchanged from 0001193125-11-056223:notes:37]


## ntap:InterestCostIncurredTextBlock

[0001193125-11-239169:notes:11]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |
| Amortization of debt discount |  |  | 12.6 |  |  |  | 11.9 |  |
| Amortization of issuance costs |  |  | 1.1 |  |  |  | 1.0 |  |
| Total interest expense recognized |  | $ | 19.2 |  |  | $ | 18.4 |  |


## ntap:InternationalSalesToSingleForeignCountriesTextBlock

[0001193125-11-239169:notes:12]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Germany |  | $ | 147.8 |  |  | $ | 140.6 |  |


## ntap:LongTermDebtByCurrentAndNonCurrentTextBlock

[0001193125-11-239169:notes:13]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.4 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.4 |  |  |  | 6.0 |  |
|  |  | $ | 11.8 |  |  | $ | 11.5 |  |


## ntap:LongTermInvestmentsAndRestrictedCashTableTextBlock

[0001193125-11-239169:notes:14]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| Auction rate securities |  | $ | 56.3 |  |  | $ | 65.1 |  |
| Restricted cash |  |  | 2.8 |  |  |  | 2.8 |  |
| Private equity fund |  |  | 1.0 |  |  |  | 1.3 |  |
|  |  | $ | 60.1 |  |  | $ | 69.2 |  |


## ntap:MarketableSecuritiesAvailableForSaleSecuritiesPolicyTextBlock

[0001193125-11-239169:notes:15]
The unrealized losses on our available-for-sale investments in corporate bonds were caused by market value declines as a result of the economic environment, as well as fluctuations in market interest rates. Because the decline in market value is attributable to changes in market conditions and not credit quality, and because we neither intend to sell nor are likely to be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of July 29, 2011.


## ntap:OtherCurrentAssetsTextBlock

[0001193125-11-239169:notes:16]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| Net deferred tax assets |  | $ | 179.0 |  |  | $ | 145.7 |  |
| Prepaid expenses and other current assets |  |  | 203.2 |  |  |  | 188.4 |  |
| Short-term restricted cash |  |  | 6.1 |  |  |  | 5.3 |  |
|  |  | $ | 388.3 |  |  | $ | 339.4 |  |


## ntap:RevenuesByGeographicRegionTextBlock

[0001193125-11-239169:notes:17]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Americas (United States, Canada and Latin America)* |  | $ | 813.4 |  |  | $ | 639.3 |  |
| Europe, Middle East and Africa |  |  | 456.7 |  |  |  | 393.0 |  |
| Asia Pacific and Japan |  |  | 188.1 |  |  |  | 121.4 |  |
| Net revenues |  | $ | 1,458.2 |  |  | $ | 1,153.7 |  |

[0001193125-11-239169:notes:18]
| * | Sales to the United States accounted for $689.3 million and $570.6 million in the three months periods ended July 29, 2011 and July 30, 2010, respectively. |


## ntap:ScheduleOfAcquisitionRelatedExpensesTableTextBlock

[0001193125-11-239169:notes:19]
|  |  | Three MonthsEnded |  |
|  |  | July 29,2011 |  |
| Acquisition related expense |  | $ | 2.2 |  |


## ntap:ScheduleOfComputerSoftwareTableTextBlock

[0001193125-11-239169:notes:20]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| Computer software |  | $ | 82.7 |  |  | $ | 88.3 |  |


## ntap:ScheduleOfIncomeTaxEffectsAllocatedDirectlyToEquityEmployeeStockOptionsTextBlock

[0001193125-11-239169:notes:21]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Income tax benefits (charges) associated with employee stock transactions |  | $ | 28.7 |  |  | $ | (12.0 | ) |


## ntap:ScheduleOfNotionalValueOfOutstandingCurrencyForwardContractsTextBlock

[0001193125-11-239169:notes:22]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Euro |  | $ | 122.5 |  |  | $ | 104.0 |  |
| British Pound Sterling |  |  | 27.0 |  |  |  | 20.9 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Euro |  |  | 131.7 |  |  |  | 253.7 |  |
| British Pound Sterling |  |  | 55.8 |  |  |  | 70.8 |  |
| Australian Dollar |  |  | 55.6 |  |  |  | 34.4 |  |
| Canadian Dollar |  |  | 33.4 |  |  |  | 56.0 |  |
| Other |  |  | 60.6 |  |  |  | 52.6 |  |


## ntap:SegmentGeographicAndSignificantCustomerInformationDisclosureTextBlock

[0001193125-11-239169:notes:23]
| 14. | Segment, Geographic, and Significant Customer Information |

[0001193125-11-239169:notes:24]
We operate in one reportable industry segment: the design, manufacturing, marketing, and technical support of high-performance networked storage solutions. Our company conducts business globally and our sales and support activities are managed on a geographic basis. Our management reviews financial information presented on a consolidated basis, accompanied by disaggregated information it receives from its internal management system about revenues by geographic region, based on the location from which the customer relationship is managed, for purposes of allocating resources and evaluating financial performance. We do not allocate costs of revenues, research and development, sales and marketing, or general and administrative expenses to our geographic regions in this internal management system because management does not review operations or operating results, or make planning decisions, below the consolidated entity level.

[0001193125-11-239169:notes:25]
Summarized revenues by geographic region based on the our internal management system and as utilized by our Chief Executive Officer, who is considered our Chief Operating Decision Maker (CODM), was as follows (in millions):

[0001193125-11-239169:notes:26]
The majority of our assets, excluding cash, cash equivalents, restricted cash, investments and accounts receivable, as of July 29, 2011 and April 29, 2011 were attributable to our U.S. operations. The following table presents total cash, cash equivalents, restricted cash and investments held in the United States and outside of the United States in various foreign subsidiaries (in millions):

[0001193125-11-239169:notes:27]
[same as prior period, unchanged from 0001193125-11-056223:notes:54]

[0001193125-11-239169:notes:28]
No more than ten percent of property and equipment was located in any single foreign country.

[0001193125-11-239169:notes:29]
[same as prior period, unchanged from 0001193125-11-056223:notes:56]

[0001193125-11-239169:notes:30]
Sales to customers, who are distributors, which accounted for ten percent or more of net revenues were as follows (in millions):

[0001193125-11-239169:notes:31]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Arrow Electronics, Inc. |  | $ | 212.9 |  |  | $ | 182.0 |  |
| Avnet, Inc. |  |  | 159.1 |  |  |  | 124.7 |  |

[0001193125-11-239169:notes:32]
As of July 29, 2011, no customers accounted for ten percent or more of net accounts receivable. As of April 29, 2011, two customers, Arrow Electronics, Inc, and Avnet, Inc., accounted for ten percent or more of net accounts receivable with balances of $101.4 million and $107.5 million, respectively.


## ntap:ShareBasedCompensationArrangementByShareBasedPaymentAwardFairValueAssumptionsMethodUsedTextBlock

[0001193125-11-239169:notes:33]
|  |  | Stock OptionsThree Months Ended |  |  | ESPPThree Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Expected term in years |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 1.60 | % |  |  | 2.09 | % |  |  | 0.25 | % |  |  | 0.46 | % |
| Volatility |  |  | 35 | % |  |  | 38 | % |  |  | 35 | % |  |  | 39 | % |


## ntap:ShareBasedCompensationArrangementByShareBasedPaymentAwardOptionsOutstandingRollForwardTextBlock

[0001193125-11-239169:notes:34]
|  |  | Numbers ofShares |  |  | WeightedAverageGrant DateFair Value |  |
| Outstanding at April 29, 2011 |  |  | 10.1 |  |  | $ | 35.79 |  |
| RSUs granted |  |  | 4.4 |  |  |  | 50.98 |  |
| RSUs vested |  |  | (1.4 | ) |  |  | 22.01 |  |
| RSUs forfeitures and cancellations |  |  | (0.2 | ) |  |  | 39.56 |  |
| Outstanding at July 29, 2011 |  |  | 12.9 |  |  | $ | 42.47 |  |


## ntap:SharesWithheldForEmployeeTaxesTextBlock

[0001193125-11-239169:notes:35]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Shares withheld for taxes |  |  | 0.5 |  |  |  | 0.5 |  |
| Fair value of shares withheld |  | $ | 25.3 |  |  | $ | 18.5 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-11-239169:notes:36]
|  |  | July 29, 2011 |  |  | April 29, 2011 |  |
|  |  |  |  |  | Gross Unrealized |  |  | Estimated |  |  |  |  |  | Gross Unrealized |  |  | Estimated |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Fair Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Fair Value |  |
| Corporate bonds |  | $ | 2,038.5 |  |  | $ | 9.7 |  |  | $ | (1.0 | ) |  | $ | 2,047.2 |  |  | $ | 1,643.2 |  |  | $ | 10.2 |  |  | $ | (0.6 | ) |  | $ | 1,652.8 |  |
| Auction rate securities |  |  | 59.5 |  |  |  | 0.3 |  |  |  | (3.5 | ) |  |  | 56.3 |  |  |  | 69.2 |  |  |  | 0.4 |  |  |  | (4.5 | ) |  |  | 65.1 |  |
| U.S. treasury and government debt securities |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 661.9 |  |  |  | 0.6 |  |  |  | (0.7 | ) |  |  | 661.8 |  |
| Commercial paper |  |  | 131.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 131.6 |  |  |  | 5.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 5.0 |  |
| Municipal bonds |  |  | 1.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.5 |  |  |  | 1.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.5 |  |
| Certificates of deposit |  |  | 111.4 |  |  |  | 0.4 |  |  |  | 0.0 |  |  |  | 111.8 |  |  |  | 96.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 96.3 |  |
| Money market funds |  |  | 1,524.7 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,524.7 |  |  |  | 1,539.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,539.6 |  |
| Equity funds |  |  | 23.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 23.6 |  |  |  | 20.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 20.2 |  |
| Private equity fund |  |  | 1.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.0 |  |  |  | 1.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.3 |  |
| Total debt and equity securities |  | $ | 3,891.8 |  |  | $ | 10.4 |  |  | $ | (4.5 | ) |  | $ | 3,897.7 |  |  | $ | 4,038.2 |  |  | $ | 11.2 |  |  | $ | (5.8 | ) |  | $ | 4,043.6 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001193125-11-239169:notes:37]
|  |  | Three Months Ended |  |
|  |  | July 29,2011 |  |  | July 30,2010 |  |
| Net revenues |  | $ | 1,466.8 |  |  | $ | 1,322.7 |  |
| Net income |  | $ | 145.9 |  |  | $ | 138.4 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-11-239169:notes:38]
| 5. | Business Combinations |

[0001193125-11-239169:notes:39]
Fiscal 2012 Acquisition

[0001193125-11-239169:notes:40]
On May 6, 2011, we completed the acquisition of certain assets related to the Engenio external storage systems business (Engenio) of LSI Corporation (LSI). We paid LSI $480 million in cash and also assumed certain liabilities related to Engenio. During the three years following the acquisition, LSI will pay us a total of $13.0 million to service certain LSI customer warranties. This acquisition will enable us to address growing customer requirements in the areas of high bandwidth and intensive analytics workloads such as video, including full-motion video capture and digital video surveillance, as well as high-performance computing applications, such as genomics sequencing and scientific research.

[0001193125-11-239169:notes:41]
The purchase price was allocated to Engenio's net tangible and intangible assets as of the date of acquisition based on various fair value estimates and analyses, including work performed by third-party valuation specialists.

[0001193125-11-239169:notes:42]
The following are the preliminary estimated fair value of assets acquired and liabilities assumed as of the closing date (in millions):

[0001193125-11-239169:notes:43]
| Current assets |  | $ | 49.8 |  |
| Property and equipment |  |  | 33.3 |  |
| Identified intangible assets |  |  | 272.1 |  |
| Goodwill |  |  | 143.7 |  |
| Other assets |  |  | 9.3 |  |
| Total assets acquired |  |  | 508.2 |  |
| Current liabilities |  |  | (20.9 | ) |
| Other liabilities |  |  | (7.3 | ) |
| Total purchase price |  | $ | 480.0 |  |

[0001193125-11-239169:notes:44]
As this was an asset acquisition, U.S. goodwill is deductible for income tax purposes. The goodwill is comprised of expected synergies in utilizing Engenio's technology in the Company's products and channels (and vice versa), reduction in future combined research and development expenses, and intangible assets, such as acquired workforce, that do not qualify for separate recognition.

[0001193125-11-239169:notes:45]
Adjustments may be made to the allocation of the purchase price during the measurement period to reflect adjustments related to facts existing at the time of the acquisition.

[0001193125-11-239169:notes:46]
The identified intangible assets as of the date of acquisition, which are amortized on a straight-line basis over their estimated useful lives, consisted of the following (in millions, except useful life):

[0001193125-11-239169:notes:47]
|  |  | FairValue |  |  | Useful Life(Years) |  |
| Developed technology |  | $ | 216.0 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 45.0 |  |  |  | 2 |  |
| Trademarks and trade names |  |  | 7.0 |  |  |  | 2 |  |
| Order backlog |  |  | 2.5 |  |  |  | 0 |  |
| Covenant not to compete |  |  | 1.6 |  |  |  | 3 |  |
| Total identified intangible assets |  | $ | 272.1 |  |  |  |  |  |

[0001193125-11-239169:notes:48]
Our consolidated net revenues for the three months ended July 29, 2011 include $157.1 million attributable to Engenio since the acquisition. Due to continued integration of the combined businesses since the date of acquisition, it is impractical to determine the earnings contributed by Engenio.

[0001193125-11-239169:notes:49]
The following unaudited pro forma condensed combined financial information gives effect to the acquisition of Engenio as if it were consummated on May 1, 2010 (the beginning of the comparable prior annual reporting period). Due to historically differing fiscal year ends of the Company and Engenio, the unaudited pro forma condensed combined financial information for the fiscal quarter ended July 30, 2010 is based on the historical results of the Company for the fiscal quarter ended July 30, 2010 and the historical results of Engenio for the three months ended July 4, 2010.

[0001193125-11-239169:notes:50]
The unaudited pro forma condensed combined financial information is presented for informational purposes only and is not intended to represent or be indicative of the results of operations of the Company that would have been reported had the acquisition occurred on May 1, 2010 and should not be taken as representative of future consolidated results of operations of the combined company (in millions).

[0001193125-11-239169:notes:51]
A nonrecurring adjustment of $5.6 million has been reflected in the unaudited pro forma condensed combined information with the effect of increasing net income for the three month period ended July 29, 2011 and decreasing net income for the three month period ended July 30, 2010 to present the impact on cost of sales from the step-up in inventory as if the acquisition occurred on May 1, 2010.

[0001193125-11-239169:notes:52]
The following acquisition related expenses consisted primarily of due diligence, legal and other one-time integration charges and are included in acquisition related expense in our condensed consolidated statements of operations:

[0001193125-11-239169:notes:53]
Fiscal 2011 Acquisitions

[0001193125-11-239169:notes:54]
During fiscal 2011, we acquired two privately held companies, Akorri Networks, Inc. (Akorri), and Bycast Inc. (Bycast). Akorri, headquartered in Massachusetts, is a provider of data center management software focused on performance and capacity analytics for virtualized, shared information technology infrastructures. The Akorri acquisition extends our offering by adding performance capacity analytics to provide customers greater visibility across the entire IT stack, resulting in further improvement in IT efficiency and flexibility through functions that help control, automate, and analyze their shared IT infrastructure. Bycast, headquartered in Vancouver, Canada, develops and sells software designed to manage petabyte-scale, globally distributed repositories of images, video and records for enterprises and service providers. The Bycast acquisition extends our position in unified storage by adding an object-based storage software offering, which simplifies the task of large-scale storage and improves the ability to search and locate data objects.

[0001193125-11-239169:notes:55]
The following table summarizes the purchase price components and equity interests acquired (in millions):

[0001193125-11-239169:notes:56]
|  |  | Akorri |  |  | Bycast |  |
| Acquisition date |  | January 31,2011 |  |  | May 13,2010 |  |
| Percentage of equity interest acquired |  |  | 100 | % |  |  | 100 | % |
| Total purchase price |  | $ | 62.3 |  |  | $ | 83.8 |  |
| Cash component of purchase price |  | $ | 62.3 |  |  | $ | 80.5 |  |
| Fair value of vested options assumed |  | $ | 0.0 |  |  | $ | 3.3 |  |
| Purchase price held in escrow to secure obligations of acquired entity |  | $ | 7.9 |  |  | $ | 13.1 |  |
| Release of escrow (number of years subsequent to acquisition date) |  |  | 1.5 |  |  |  | 1.5 |  |

[0001193125-11-239169:notes:57]
A summary of the purchase price allocation as of the respective acquisition dates is as follows (in millions):

[0001193125-11-239169:notes:58]
|  |  | Akorri |  |  | Bycast |  |
| Cash |  | $ | 0.7 |  |  | $ | 5.7 |  |
| Identified intangible assets |  |  | 22.0 |  |  |  | 23.6 |  |
| Goodwill |  |  | 23.3 |  |  |  | 56.0 |  |
| Deferred income taxes |  |  | 9.9 |  |  |  | (3.9 | ) |
| Other assets, net |  |  | 6.4 |  |  |  | 2.4 |  |
| Total purchase price |  | $ | 62.3 |  |  | $ | 83.8 |  |

[0001193125-11-239169:notes:59]
Due to continued integration of the combined businesses since the date of acquisition, it is impractical to determine the revenue and earnings contributed by Akorri and Bycast. As Akorri and Bycast were stock acquisitions, goodwill is not deductible for income tax purposes.

[0001193125-11-239169:notes:60]
The results of operations of the acquired entities are included in our condensed consolidated statements of operations from their respective acquisition dates. Pro forma results of operations have not been presented because the acquisitions were not material to our results of operations.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001193125-11-239169:notes:61]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| Cash |  | $ | 897.3 |  |  | $ | 1,169.1 |  |
| Cash equivalents |  |  | 1,645.9 |  |  |  | 1,588.2 |  |
|  |  | $ | 2,543.2 |  |  | $ | 2,757.3 |  |


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-11-239169:notes:62]
| 4. | Statements of Cash Flows |

[0001193125-11-239169:notes:63]
[same as prior period, unchanged from 0001193125-11-056223:notes:80]

[0001193125-11-239169:notes:64]
|  |  | Three Months Ended |  |
|  |  | July 29,2011 |  |  | July 30,2010 |  |
| Noncash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Acquisition of property and equipment on account |  | $ | 33.7 |  |  | $ | 20.3 |  |
| Acquisition of property and equipment through long-term financing |  | $ | 0.0 |  |  | $ | 12.6 |  |
| Options assumed from acquired business |  | $ | 0.0 |  |  | $ | 3.3 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 13.1 |  |  | $ | 8.0 |  |
| Interest paid |  | $ | 11.2 |  |  | $ | 11.1 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-11-239169:notes:65]
| 15. | Commitments and Contingencies |

[0001193125-11-239169:notes:66]
Lease Commitments

[0001193125-11-239169:notes:67]
Future annual minimum lease payments under all non-cancelable facilities and equipment operating leases with an initial term in excess of one year as of July 29, 2011 totaled $312.3 million.

[0001193125-11-239169:notes:68]
As of July 29, 2011, we have four leasing arrangements (Leasing Arrangements 1, 2, 3 and 4) with BNP Paribas LLC (BNPPLC) some of which require us to lease certain of our land to BNPPLC for a period of 99 years and to lease approximately 0.6 million square feet of office space for our headquarters in Sunnyvale, which had an original cost of $149.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on LIBOR plus a spread or a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of the leases for two consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of the lease terms, we must elect one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received from the third-party and BNPPLC's cost up to 85% of cost (residual guarantee); or (iii) pay BNPPLC supplemental payments for an amount equal to the difference between the residual guarantee and fair value, in which event we may recoup some or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period.

[0001193125-11-239169:notes:69]
These leases require us to maintain specified financial covenants with which we were in compliance as of July 29, 2011.

[0001193125-11-239169:notes:70]
As of July 29, 2011, we estimated that the fair value of the properties under synthetic lease was $51.0 million below the residual guarantee. We are accruing for this deficiency over the remaining terms of the respective leases. As of July 29, 2011, a deficiency reserve of $21.6 million was included in other long-term liabilities

[0001193125-11-239169:notes:71]
Purchase Orders and Other Commitments

[0001193125-11-239169:notes:72]
In the normal course of business we make commitments to our third-party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. We had $191.8 million in non-cancelable purchase commitments with our contract manufacturers as of July 29, 2011. In addition, we recorded a liability for firm non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to product cost of sales. As of July 29, 2011 and April 29, 2011, such liability amounted to $4.5 million for both periods and is included in other current liabilities in the condensed consolidated balance sheets.

[0001193125-11-239169:notes:73]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course business for which we have not received goods or services. We had $25.0 million in capital purchase commitments and $249.2 million in other purchase commitments as of July 29, 2011.

[0001193125-11-239169:notes:74]
.

[0001193125-11-239169:notes:75]
Product Warranties

[0001193125-11-239169:notes:76]
We provide customers a warranty on software of ninety days to five years and a warranty on hardware of one to five years. The following table summarizes our warranty reserves (in millions):

[0001193125-11-239169:notes:77]
|  |  | Three Months Ended |  |
|  |  | July 29,2011 |  |  | July 30,2010 |  |
| Beginning balance |  | $ | 40.5 |  |  | $ | 31.9 |  |
| Liability assumed in acquisition |  |  | 17.5 |  |  |  | 0.0 |  |
| Expense accrued during the period |  |  | 11.7 |  |  |  | 5.9 |  |
| Warranty costs incurred |  |  | (10.2 | ) |  |  | (5.7 | ) |
| Ending balance |  | $ | 59.5 |  |  | $ | 32.1 |  |

[0001193125-11-239169:notes:78]
Financing Guarantees

[0001193125-11-239169:notes:79]
We have both nonrecourse and recourse lease financing arrangements with third-party leasing companies through new and preexisting relationships with customers. In addition, from time to time we provide guarantees for a portion of other financing arrangements under which we could be called upon to make payments to our third-party funding companies in the event of nonpayment by end-user customers. Under the terms of the nonrecourse leases, we do not have any continuing obligations or liabilities to the third-party leasing companies. Under the terms of the recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee, we defer the revenues associated with the end-user financing arrangement in accordance with our revenue recognition policies. As of July 29, 2011, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $97.9 million, and the related deferred revenue and cost of revenues totaled approximately $102.0 million and $9.3 million, respectively. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001193125-11-239169:notes:80]
Legal Contingencies

[0001193125-11-239169:notes:81]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as of July 29, 2011, as the outcome of these legal matters is currently not determinable.

[0001193125-11-239169:notes:82]
On October 13, 2010, Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of California, Santa Clara County. The lawsuit named 15 of our current and former directors as defendants. On February 3, 2011, the plaintiff filed an amended complaint in response to motions to dismiss that we and the individual defendants had filed. Like the original complaint, the amended complaint includes claims of breach of fiduciary duty and waste of corporate assets and alleges that the defendants failed to monitor internal controls to ensure that we complied with legal requirements in our General Services Administration (GSA) contracting activities, resulting in us incurring defense and settlement costs. The amended complaint seeks disgorgement of salaries and other compensation from the defendants and additional unspecified damages. We and the individual defendants filed motions to dismiss the amended complaint in early March 2011, and the hearing on these motions was held on July 15, 2011. The Court granted the motions to dismiss and dismissed the plaintiff's complaint, but permitted plaintiff leave to amend the complaint on or before September 16, 2011. On August 10, 2011, Amalgamated Bank filed a complaint in Delaware Chancery Court against NetApp, Inc. for the purpose of obtaining, in a summary proceeding, books and records to be used in the California lawsuit. We will respond to this Complaint on or before August 30, 2011.


## us-gaap:DebtDisclosureTextBlock

[0001193125-11-239169:notes:83]
| 9. | Financing Arrangements |

[0001193125-11-239169:notes:84]
1.75% Convertible Senior Notes Due 2013

[0001193125-11-239169:notes:85]
On June 10, 2008, we issued $1,265.0 million aggregate principal amount of 1.75% Convertible Senior Notes due 2013 (the Notes). The Notes are unsecured, unsubordinated obligations of the Company. Interest is payable in cash semi-annually at a rate of 1.75% per annum. The Notes will mature on June 1, 2013 unless repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified below, based on an initial conversion rate of 31.40 shares of common stock per $1,000 principal amount of Notes (which represents an initial effective conversion price of the Notes of approximately $31.85 per share), subject to adjustment as described in the indenture governing the Notes.

[0001193125-11-239169:notes:86]
The Notes are not redeemable by us prior to the maturity date. In the event of a fundamental change (as defined in the indenture for the Notes), holders of the Notes may require us to repurchase all or a portion of their Notes at a repurchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid interest, if any, to, but excluding, the fundamental change repurchase date.

[0001193125-11-239169:notes:87]
The holders of the Notes may convert their Notes until the close of business on the scheduled trading day immediately preceding the maturity date if any of the following conditions are met: (1) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price of the Notes for each day in the measurement period was less than 98% of an amount equal to (i) the last reported sale price of our common stock multiplied by (ii) the conversion rate for the Notes on each such day; (2) during any calendar quarter (and only during such calendar quarter) if the last reported sale price of our common stock for 20 or more trading days in a period of 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter exceeds 130% of the applicable conversion price in effect for the Notes on the last trading day of such immediately preceding calendar quarter; or (3) upon the occurrence of specified corporate transactions set forth in the indenture for the Notes. On or after March 1, 2013, until the scheduled trading day immediately preceding the maturity date, holders of the Notes may convert their Notes regardless of the foregoing conditions. Upon conversion, a holder will receive cash in an amount equal to the lesser of the conversion value and the principal amount of the Notes, and any shares of our common stock for any conversion value in excess of the principal amount of the Notes, if any. Holders of the Notes who convert their Notes in connection with a fundamental change will, under certain circumstances, be entitled to a make-whole premium in the form of an increase in the conversion rate.

[0001193125-11-239169:notes:88]
For at least 20 trading days during the 30 consecutive trading days ended June 30, 2011 and March 31, 2011, respectively, our common stock price exceeded the conversion threshold price of $41.41 per share set forth for these Notes. Accordingly, the Notes are convertible at the holder's option through September 30, 2011 and were convertible at the holder's option through June 30, 2011, respectively. As such, the carrying value of the Notes was classified as a current liability as of July 29, 2011 and April 29, 2011. Since the Notes are convertible at the option of the holder and the principal amount is required to be paid in cash, the difference between the principal amount and the carrying value of the Notes is reflected as convertible debt in mezzanine on our condensed consolidated balance sheets as of July 29, 2011 and April 29, 2011. The determination of whether or not the Notes are convertible must continue to be performed quarterly. Consequently, the Notes may not be convertible in future quarters, and therefore may be classified as long-term debt, if the contingent conversion thresholds are not met in such quarters.

[0001193125-11-239169:notes:89]
Upon conversion of any Notes, we deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal amount of the Notes, shares of our common stock. As of July 29, 2011, shares issued related to the Notes were minimal. Based on the closing price of our common stock of $47.52 on July 29, 2011, the if-converted value of our Notes exceeded their principal amount by approximately $649.4 million.

[0001193125-11-239169:notes:90]
The following table reflects the carrying value of our convertible debt as of July 29, 2011 and April 29, 2011, respectively (in millions):

[0001193125-11-239169:notes:91]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (101.9 | ) |  |  | (114.6 | ) |
| Net current carrying amount of Notes |  | $ | 1,163.1 |  |  | $ | 1,150.4 |  |

[0001193125-11-239169:notes:92]
The following table presents the amount of interest cost recognized relating to both the contractual interest coupon and the amortization of the discount and issuance costs (in millions):

[0001193125-11-239169:notes:93]
The following table reflects the remaining debt discount and issuance costs as of July 29, 2011 (in millions):

[0001193125-11-239169:notes:94]
Note Hedges and Warrants

[0001193125-11-239169:notes:95]
Concurrent with the issuance of the Notes, we purchased Note hedges and sold warrants. The separate Note hedge and warrants transactions are structured to reduce the potential future economic dilution associated with the conversion of the Notes.

[0001193125-11-239169:notes:96]
| • |  | Note Hedges. As of July 29, 2011 and April 29, 2011, we have arrangements with counterparties to buy up to approximately 31.8 million shares, subject to anti-dilution adjustments, of our common stock at a price of $31.85 per share, subject to adjustment. The Note hedge transactions will expire at the earlier of (1) the last day on which any Notes remain outstanding and (2) the scheduled trading day immediately preceding the maturity date of the Notes. Upon exercise of the Note hedges, we have the option to receive cash or shares of our common stock equal to the difference between the then market price and the strike price of the hedges. |

[0001193125-11-239169:notes:97]
|  | • |  | Warrants. As of July 29, 2011 and April 29, 2011, we have outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |

[0001193125-11-239169:notes:98]
As of July 29, 2011, we are subject to potential dilution on the approximately 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of approximately $31.85.

[0001193125-11-239169:notes:99]
As of July 29, 2011, receipts of shares related to the Note hedge transactions were minimal and no cash or shares were delivered related to the warrant transactions.

[0001193125-11-239169:notes:100]
Fair Value of Notes

[0001193125-11-239169:notes:101]
As of July 29, 2011, the approximate fair value of the principal amount of our Notes, which includes the debt and equity components, was approximately $1,977.8 million, or 156% of the face value of the Notes, based upon quoted market information.

[0001193125-11-239169:notes:102]
Other Long-Term Financing Arrangements

[0001193125-11-239169:notes:103]
The following presents the amounts due under other long-term financing arrangements (in millions):


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001193125-11-239169:notes:104]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| Product |  | $ | 44.2 |  |  | $ | 106.2 |  |
| SEM and service |  |  | 2,338.3 |  |  |  | 2,208.7 |  |
| Total |  | $ | 2,382.5 |  |  | $ | 2,314.9 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,240.8 |  |  | $ | 1,226.6 |  |
| Long-term |  |  | 1,141.7 |  |  |  | 1,088.3 |  |
| Total |  | $ | 2,382.5 |  |  | $ | 2,314.9 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-11-239169:notes:105]
| 11. | Derivatives and Hedging Activities |

[0001193125-11-239169:notes:106]
We use derivative instruments to manage exposures to foreign currency risk. The maximum length of time over which forecasted foreign denominated revenues are hedged is six months. The notional value of our outstanding currency forward contracts that were entered into to hedge forecasted foreign denominated sales and our foreign currency denominated balance sheet monetary asset and liability exposures consisted of the following (in millions):

[0001193125-11-239169:notes:107]
As of July 29, 2011 and April 29, 2011, the fair value of our short-term foreign currency contracts was not material. Certain of these contracts are designed to hedge our exposure to foreign currency denominated monetary assets and liabilities and are not designated as hedging instruments. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change. Gains on derivatives not designated as hedging instruments were not material for each of the three months ended July 29, 2011 and July 30, 2010. Net deferred gains and losses recognized into AOCI related to changes in the fair value of our foreign currency contracts that are accounted for as cash flow hedges were not material for any period presented. We did not recognize any gains and losses in earnings due to hedge ineffectiveness for any period presented. The amount of gains reclassified from AOCI into income was not material for any period presented.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0001193125-11-239169:notes:108]
|  |  | Numbersof Shares |  |  | WeightedAverageExercisePrice |  |  | WeightedAverageRemainingContractual Term(Years) |  |  | AggregateIntrinsicValue |  |
| Outstanding at April 29, 2011 |  |  | 24.5 |  |  | $ | 26.62 |  |  |  |  |  |  |  |  |  |
| Options granted |  |  | 1.8 |  |  |  | 52.93 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (1.5 | ) |  |  | 23.41 |  |  |  |  |  |  |  |  |  |
| Options forfeitures and cancellations |  |  | (0.1 | ) |  |  | 29.87 |  |  |  |  |  |  |  |  |  |
| Outstanding at July 29, 2011 |  |  | 24.7 |  |  | $ | 28.76 |  |  |  | 4.33 |  |  | $ | 483.0 |  |
| Options vested and expected to vest as of July 29, 2011 |  |  | 23.5 |  |  | $ | 28.22 |  |  |  | 4.25 |  |  | $ | 470.1 |  |
| Exercisable at July 29, 2011 |  |  | 13.8 |  |  | $ | 24.11 |  |  |  | 3.41 |  |  | $ | 323.4 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-11-239169:notes:109]
13. Net Income per Share

[0001193125-11-239169:notes:110]
[same as prior period, unchanged from 0001193125-11-056223:notes:118]

[0001193125-11-239169:notes:111]
|  |  | Three Months Ended |  |
|  |  | July 29,2011 |  |  | July 30,2010 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 139.5 |  |  | $ | 150.7 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Shares used in basic computation (weighted average common shares outstanding) |  |  | 370.3 |  |  |  | 352.4 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 11.8 |  |  |  | 15.5 |  |
| Dilutive impact of assumed conversion of Notes |  |  | 15.4 |  |  |  | 6.4 |  |
| Dilutive impact of warrants |  |  | 8.0 |  |  |  | 0.0 |  |
| Shares used in diluted computation |  |  | 405.5 |  |  |  | 374.3 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.38 |  |  | $ | 0.43 |  |
| Diluted |  | $ | 0.34 |  |  | $ | 0.40 |  |

[0001193125-11-239169:notes:112]
The following potential weighted average common shares have been excluded from the diluted net income per share calculations, as their effect would have been anti-dilutive (in millions):

[0001193125-11-239169:notes:113]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Options and RSUs |  |  | 3.6 |  |  |  | 5.3 |  |

[0001193125-11-239169:notes:114]
Dilutive shares outstanding for the three month period ended July 30, 2010 do not include any effect resulting from warrants, as their impact would have been anti-dilutive. The Note hedges (as described in Note 9) are not included for purposes of calculating earnings per share as their effect would have been anti-dilutive. The Note hedges, if exercised upon conversion of the Notes, are expected to reduce approximately 80% of the dilutive effect of the Notes when our stock price is above $31.85 per share.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001193125-11-239169:notes:115]
|  |  | Auction RateSecurities |  |  | Private EquityFund |  |
| Balance at April 29, 2011 |  | $ | 65.1 |  |  | $ | 1.3 |  |
| Total unrealized gains included in other comprehensive income |  |  | 0.9 |  |  |  | 0.0 |  |
| Settlements |  |  | (9.7 | ) |  |  | (0.3 | ) |
| Balance at July 29, 2011 |  | $ | 56.3 |  |  | $ | 1.0 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-11-239169:notes:116]
|  |  | Total |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 1,645.9 |  |  | $ | 1,524.7 |  |  | $ | 121.2 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 2,170.9 |  |  |  | 0.0 |  |  |  | 2,170.9 |  |  |  | 0.0 |  |
| Other current assets |  |  | 5.3 |  |  |  | 3.7 |  |  |  | 1.6 |  |  |  | 0.0 |  |
| Long-term investments |  |  | 56.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 56.3 |  |
| Other non-current assets |  |  | 20.9 |  |  |  | 19.9 |  |  |  | 0.0 |  |  |  | 1.0 |  |
| Total |  | $ | 3,899.3 |  |  | $ | 1,548.3 |  |  | $ | 2,293.7 |  |  | $ | 57.3 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 4.2 |  |  | $ | 0.0 |  |  | $ | 4.2 |  |  | $ | 0.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-11-239169:notes:117]
| 8. | Financial Instruments and Fair Value |

[0001193125-11-239169:notes:118]
[same as prior period, unchanged from 0001193125-11-056223:notes:126]

[0001193125-11-239169:notes:119]
The following is a summary of our investments at July 29, 2011 and April 29, 2011, respectively (in millions):

[0001193125-11-239169:notes:120]
The following table presents the contractual maturities of our debt investments as of July 29, 2011 (in millions):

[0001193125-11-239169:notes:121]
|  |  | Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 748.5 |  |  | $ | 750.0 |  |
| Due in one through five years |  |  | 1,413.2 |  |  |  | 1,420.9 |  |
| Due after ten years* |  |  | 59.5 |  |  |  | 56.3 |  |
|  |  | $ | 2,221.2 |  |  | $ | 2,227.2 |  |

[0001193125-11-239169:notes:122]
| * | Consists of auction rate securities which have contractual maturities of greater than 10 years. |

[0001193125-11-239169:notes:123]
[same as prior period, unchanged from 0001193125-11-056223:notes:129]

[0001193125-11-239169:notes:124]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis as of July 29, 2011 (in millions):

[0001193125-11-239169:notes:125]
|  |  | Total |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservable Inputs(Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,047.2 |  |  | $ | 0.0 |  |  | $ | 2,047.2 |  |  | $ | 0.0 |  |
| Municipal bonds |  |  | 1.5 |  |  |  | 0.0 |  |  |  | 1.5 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 131.6 |  |  |  | 0.0 |  |  |  | 131.6 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 111.8 |  |  |  | 0.0 |  |  |  | 111.8 |  |  |  | 0.0 |  |
| Money market funds |  |  | 1,524.7 |  |  |  | 1,524.7 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 56.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 56.3 |  |
| Equity funds |  |  | 23.6 |  |  |  | 23.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Private equity fund |  |  | 1.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.0 |  |
| Foreign currency contracts |  |  | 1.6 |  |  |  | 0.0 |  |  |  | 1.6 |  |  |  | 0.0 |  |
| Total |  | $ | 3,899.3 |  |  | $ | 1,548.3 |  |  | $ | 2,293.7 |  |  | $ | 57.3 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | 4.2 |  |  | $ | 0.0 |  |  | $ | 4.2 |  |  | $ | 0.0 |  |

[0001193125-11-239169:notes:126]
[same as prior period, unchanged from 0001193125-11-056223:notes:132]

[0001193125-11-239169:notes:127]
The table below provides a reconciliation of the beginning and ending balance of our Level 3 financial assets measured at fair value on a recurring basis using significant unobservable inputs as of July 29, 2011 (in millions).

[0001193125-11-239169:notes:128]
All of our auction rate securities (ARSs) are classified as long-term investments and are backed by pools of student loans guaranteed by the U.S. Department of Education. As of July 29, 2011, we recorded cumulative net temporary impairment charges of $3.2 million within accumulated other comprehensive income (AOCI). We estimated the fair value for each individual ARS using an income (discounted cash flow) approach that incorporates both observable and unobservable inputs to discount the expected future cash flows. Key inputs into the discounted cash flow analysis include managements' expectation of when the principal amount will be recovered either through redemption at par, or some other refinancing event by the issuer; and marketability adjustments. Based on our ability to access our cash and other short-term investments, our expected operating cash flows, and our other sources of cash, we do not intend to sell these investments prior to recovery of value. We will continue to monitor our ARS investments in light of the current debt market environment and evaluate our accounting for these investments.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-11-239169:notes:129]
| 6. | Goodwill and Purchased Intangible Assets |

[0001193125-11-239169:notes:130]
[same as prior period, unchanged from 0001193125-11-056223:notes:136]

[0001193125-11-239169:notes:131]
| Goodwill: |  |  |  |  |
| April 29, 2011 |  | $ | 760.3 |  |
| Additions |  |  | 143.7 |  |
| July 29, 2011 |  | $ | 904.0 |  |

[0001193125-11-239169:notes:132]
|  |  | July 29, 2011 |  |  | April 29, 2011 |  |
|  |  | GrossAssets |  |  | AccumulatedAmortization |  |  | NetAssets |  |  | GrossAssets |  |  | AccumulatedAmortization |  |  | NetAssets |  |
| Identified Intangible Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | $ | 282.1 |  |  | $ | (37.1 | ) |  | $ | 245.0 |  |  | $ | 66.1 |  |  | $ | (23.2 | ) |  | $ | 42.9 |  |
| Customer contracts/relationships |  |  | 59.5 |  |  |  | (13.6 | ) |  |  | 45.9 |  |  |  | 12.0 |  |  |  | (4.6 | ) |  |  | 7.4 |  |
| Trademarks and trade names |  |  | 14.7 |  |  |  | (6.7 | ) |  |  | 8.0 |  |  |  | 7.7 |  |  |  | (5.5 | ) |  |  | 2.2 |  |
| Covenants not to compete |  |  | 2.2 |  |  |  | (0.3 | ) |  |  | 1.9 |  |  |  | 0.6 |  |  |  | (0.1 | ) |  |  | 0.5 |  |
| Total identified intangible assets |  | $ | 358.5 |  |  | $ | (57.7 | ) |  | $ | 300.8 |  |  | $ | 86.4 |  |  | $ | (33.4 | ) |  | $ | 53.0 |  |

[0001193125-11-239169:notes:133]
[same as prior period, unchanged from 0001193125-11-056223:notes:138]

[0001193125-11-239169:notes:134]
As of July 29, 2011, future amortization expense related to identifiable intangible assets is as follows (in millions):

[0001193125-11-239169:notes:135]
| Fiscal Year |  | Amount |  |
| Remainder of 2012 |  | $ | 64.7 |  |
| 2013 |  |  | 84.2 |  |
| 2014 |  |  | 52.0 |  |
| 2015 |  |  | 50.7 |  |
| 2016 |  |  | 46.9 |  |
| 2017 |  |  | 2.3 |  |
| Total |  | $ | 300.8 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-11-239169:notes:136]
| 12. | Income Taxes |

[0001193125-11-239169:notes:137]
[same as prior period, unchanged from 0001193125-11-056223:notes:141]

[0001193125-11-239169:notes:138]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Effective tax rate |  |  | 16.5 | % |  |  | 11.9 | % |

[0001193125-11-239169:notes:139]
Our effective tax rate reflects the impact of a significant amount of our earnings being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. As of July 29, 2011, we had $136.6 million of unrecognized tax benefits. We have recorded $107.0 million in other long-term liabilities, of which $95.9 million, if recognized, would affect our provision for income taxes.

[0001193125-11-239169:notes:140]
We are currently undergoing income tax audits in the United States and several foreign tax jurisdictions. The rights to some of our intellectual property (IP) are owned by certain of our foreign subsidiaries, and payments are made between U.S. and foreign tax jurisdictions relating to the use of this IP in a qualified cost sharing arrangement. In recent years, several other U.S. companies have had their foreign IP arrangements challenged as part of Internal Revenue Service (IRS) examinations, which has resulted in material proposed assessments and/or litigation with respect to those companies.

[0001193125-11-239169:notes:141]
During fiscal year 2010, the IRS commenced the examination of our fiscal 2005 through 2007 federal income tax returns, and, in addition, the California Franchise Tax Board began the examination of our fiscal 2007 and 2008 California income tax returns. These audits are currently in progress.

[0001193125-11-239169:notes:142]
On September 17, 2010, the Danish tax authorities issued a decision concluding that distributions declared in 2005 and 2006 from the Company's Danish subsidiary, for which the Company has not paid or accrued any taxes, are subject to Danish at-source dividend withholding tax. The Company believes the assessment is without merit and has appealed this assessment decision with the Danish National Tax Tribunal.

[0001193125-11-239169:notes:143]
If the ultimate determination of income taxes or at-source withholding taxes assessed under the current IRS audits or under audits being conducted in any of the other tax jurisdictions in which we operate results in an amount in excess of the tax provision we have recorded or reserved for, our operating results, cash flows and financial condition could be adversely affected.

[0001193125-11-239169:notes:144]
In April 2010, our Dutch subsidiary received a favorable tax ruling from the Dutch tax authorities effective May 1, 2010 that replaces the previous Dutch tax ruling that expired on April 30, 2010. This ruling results in both a lower level of earnings subject to tax in the Netherlands and an extension of the expiration date to April 30, 2015.

[0001193125-11-239169:notes:145]
On December 17, 2010, the Tax Relief Unemployment Insurance Reauthorization, and Job Creation Act of 2010 (the Act) was signed into law. Under the Act, the federal research credit was retroactively extended for amounts paid or incurred after December 31, 2009, and before January 1, 2012. Unless extended again, the federal research credit will expire on December 31, 2011.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-11-239169:notes:146]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| Purchased components |  | $ | 17.2 |  |  | $ | 7.5 |  |
| Work-in-process |  |  | 0.4 |  |  |  | 0.1 |  |
| Finished goods |  |  | 120.6 |  |  |  | 100.9 |  |
|  |  | $ | 138.2 |  |  | $ | 108.5 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-11-239169:notes:147]
| 2. | Condensed Consolidated Financial Statements |

[0001193125-11-239169:notes:148]
Fiscal Year — We operate on a 52-week or 53-week year ending on the last Friday in April. The first quarters of fiscal 2012 and 2011 were both 13-week periods.

[0001193125-11-239169:notes:149]
Basis of Presentation — The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments that are, in the opinion of management, necessary for a fair presentation of our financial position, results of operations, and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, the statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with the Company's audited consolidated financial statements as of and for the fiscal year ended April 29, 2011 contained in the Company's Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 23, 2011. The results of operations for the three month period ended July 29, 2011 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001193125-11-239169:notes:150]
Financial Statements Presentation — Certain prior period amounts have been reclassified in the accompanying condensed consolidated financial statements to conform to current year presentation.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-11-239169:notes:151]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| Land |  | $ | 206.1 |  |  | $ | 204.7 |  |
| Buildings and building improvements |  |  | 417.0 |  |  |  | 406.2 |  |
| Leasehold improvements |  |  | 83.4 |  |  |  | 79.3 |  |
| Computers, production, engineering and other equipment |  |  | 532.1 |  |  |  | 475.5 |  |
| Software |  |  | 275.7 |  |  |  | 270.4 |  |
| Furniture and fixtures |  |  | 68.3 |  |  |  | 61.5 |  |
| Construction-in-progress |  |  | 132.1 |  |  |  | 91.9 |  |
|  |  |  | 1,714.7 |  |  |  | 1,589.5 |  |
| Accumulated depreciation and amortization |  |  | (721.4 | ) |  |  | (677.9 | ) |
|  |  | $ | 993.3 |  |  | $ | 911.6 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001193125-11-239169:notes:152]
Revenue Recognition

[0001193125-11-239169:notes:153]
In October 2009, the Financial Accounting Standards Board (FASB) amended the accounting standards for revenue recognition to exclude tangible products containing software components and non-software components that function together to deliver the tangible product's essential functionality from the scope of the software revenue recognition guidance. Concurrently, the FASB also amended the accounting standards for multiple deliverable revenue arrangements to:

[0001193125-11-239169:notes:154]
|  | • |  | provide updated guidance on whether multiple deliverables exist, how the deliverables in an arrangement should be separated, and how the arrangement consideration should be allocated among its elements; |

[0001193125-11-239169:notes:155]
|  | • |  | require an entity to allocate revenue in an arrangement that has separate units of accounting using best estimated selling prices (BESP) of deliverables if a vendor does not have vendor-specific objective evidence (VSOE) of fair value or third-party evidence of selling price (TPE); and |

[0001193125-11-239169:notes:156]
|  | • |  | eliminate the use of the residual method and require an entity to allocate revenue using the relative selling price method to the separate units of accounting. |

[0001193125-11-239169:notes:157]
We elected to early adopt these standards in the fourth quarter of fiscal 2011, and the standards were applied retrospectively from the beginning of fiscal 2011 for new and materially modified revenue arrangements originating after April 30, 2010. Previously reported quarterly results have been adjusted to reflect the adoption of these standards and differ from the originally reported results.

[0001193125-11-239169:notes:158]
The majority of our products are hardware systems containing software components that function together to provide the essential functionality of the product. Therefore, our hardware systems and software components essential to the functionality of the hardware systems are considered non-software deliverables and therefore are not subject to industry-specific software revenue recognition guidance.

[0001193125-11-239169:notes:159]
Our product revenue also includes revenue from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer negotiated refunds or return rights for the delivered elements.

[0001193125-11-239169:notes:160]
For transactions entered into or materially modified after April 30, 2010, we recognize revenue in accordance with the new accounting standards when applicable. Certain arrangements with multiple deliverables may continue to have software deliverables that are subject to the existing software revenue recognition guidance along with non-software deliverables that are subject to the new standards. The revenue for these multiple element arrangements is allocated to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement using the selling price hierarchy set forth in the standards.

[0001193125-11-239169:notes:161]
For our non-software deliverables, we recognize revenue based on the new standards and allocate the arrangement consideration based on the relative selling price of the deliverables. For our non-software deliverables, we use BESP as our selling price. For our software entitlements and support services, we generally use VSOE as our selling price. When we are unable to establish selling price using VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement consideration.

[0001193125-11-239169:notes:162]
VSOE of fair value for elements of an arrangement is based upon the normal pricing and discounting practices for those services when sold separately. In determining VSOE, we require that a substantial majority of the selling prices for an element fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer classifications, and other variables in determining VSOE.

[0001193125-11-239169:notes:163]
When VSOE cannot be established, the Company attempts to establish selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE for our products or services.

[0001193125-11-239169:notes:164]
When we are unable to establish selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

[0001193125-11-239169:notes:165]
We regularly review VSOE, TPE, and BESP and maintain internal controls over the establishment and updates of these estimates.

[0001193125-11-239169:notes:166]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal year 2011, we recognize revenue based on software revenue recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be delivered at a future date and VSOE of fair value of all undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is software entitlements and maintenance (SEM) and/or service. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the contract fee is recognized as product revenue. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire arrangement is recognized ratably over the maintenance period.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-11-239169:notes:167]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| Accumulated translation adjustments |  | $ | 10.6 |  |  | $ | 11.6 |  |
| Accumulated unrealized gain on available-for-sale investments |  |  | 4.2 |  |  |  | 3.4 |  |
| Accumulated unrealized gain (loss) on derivatives qualifying as cash flow hedges |  |  | 0.4 |  |  |  | (2.2 | ) |
| Total accumulated other comprehensive income |  | $ | 15.2 |  |  | $ | 12.8 |  |


## us-gaap:ScheduleOfCompensationCostForShareBasedPaymentArrangementsAllocationOfShareBasedCompensationCostsByPlanTableTextBlock

[0001193125-11-239169:notes:168]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Employee stock options |  | $ | 14.5 |  |  | $ | 12.9 |  |
| RSUs and restricted stock awards |  |  | 34.4 |  |  |  | 19.8 |  |
| ESPP |  |  | 9.2 |  |  |  | 11.6 |  |
| Total stock-based compensation expense |  | $ | 58.1 |  |  | $ | 44.3 |  |


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0001193125-11-239169:notes:169]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Net income |  | $ | 139.5 |  |  | $ | 150.7 |  |
| Change in currency translation adjustments |  |  | (1.0 | ) |  |  | 0.5 |  |
| Change in unrealized gain on available-for-sale investments |  |  | 0.8 |  |  |  | 2.1 |  |
| Change in unrealized gain (loss) on derivatives qualifying as cash flow hedges |  |  | 2.6 |  |  |  | (0.6 | ) |
| Comprehensive income |  | $ | 141.9 |  |  | $ | 152.7 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-11-239169:notes:170]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Cost of product revenues |  | $ | 1.1 |  |  | $ | 0.9 |  |
| Cost of service revenues |  |  | 3.9 |  |  |  | 3.9 |  |
| Sales and marketing |  |  | 28.6 |  |  |  | 20.6 |  |
| Research and development |  |  | 16.0 |  |  |  | 11.1 |  |
| General and administrative |  |  | 8.5 |  |  |  | 7.8 |  |
| Total stock-based compensation expense |  | $ | 58.1 |  |  | $ | 44.3 |  |


## us-gaap:ScheduleOfShareBasedCompensationEmployeeStockPurchasePlanActivityTableTextBlock

[0001193125-11-239169:notes:171]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Weighted-average fair value per right granted |  | $ | 15.88 |  |  | $ | 11.79 |  |
| Shares issued under the ESPP |  |  | 1.1 |  |  |  | 2.8 |  |
| Weighted average price of shares issued |  | $ | 39.17 |  |  | $ | 11.08 |  |


## us-gaap:ScheduleOfSubsequentEventsTextBlock

[0001193125-11-239169:notes:172]
| 16. | Subsequent Event |

[0001193125-11-239169:notes:173]
On August 19, 2011, we entered into a new ASR with Wells Fargo Bank, National Association (Wells Fargo). Pursuant to the terms of the ASR, we provided Wells Fargo a prepayment of $400.0 million to purchase shares of our common stock. The aggregate number of shares ultimately purchased will be determined based on the volume weighted average share price of our common stock over a specified period of time, subject to certain collar provisions that establish a minimum and maximum number of shares that may be repurchased. The actual number of shares repurchased will be determined at the completion of the ASR contract. Shares will be delivered over the term of the ASR contract, which is expected to end no later than December 30, 2011, although the completion date may be accelerated at Wells Fargo's option.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-11-239169:notes:174]
| 3. | Significant Accounting Policies |

[0001193125-11-239169:notes:175]
There have been no significant changes in our significant accounting policies for the three month period ended July 29, 2011, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2011.

[0001193125-11-239169:notes:176]
Accounting Standards Recently Adopted

[0001193125-11-239169:notes:177]
Recent Accounting Standards Not Yet Effective

[0001193125-11-239169:notes:178]
In June 2011, the FASB issued new guidance on the presentation of comprehensive income. Specifically, the new guidance requires an entity to present components of net income and other comprehensive income in one continuous statement, referred to as the statement of comprehensive income, or in two separate, but consecutive statements. The new guidance eliminates the current option to report other comprehensive income and its components in the statement of stockholders' equity. While the new guidance changes the presentation of comprehensive income, there are no changes to the components that are recognized in net income or other comprehensive income under current accounting guidance. This new guidance is effective for us beginning in our first quarter of fiscal 2013 and is required to be applied retrospectively. There will be no impact to the Company's results as the guidance relates only to financial statement presentation.

[0001193125-11-239169:notes:179]
In May 2011, the FASB issued new guidance for fair value measurements to provide a consistent definition of fair value and ensure that the fair value measurement and disclosure requirements are similar between GAAP and International Financial Reporting Standards. The guidance changes certain fair value measurement principles and enhances the disclosure requirements particularly for level 3 fair value measurements. The guidance is effective for us prospectively beginning in the fourth quarter of fiscal 2012, and we are currently evaluating the impact of adoption on our financial statements.

[0001193125-11-239169:notes:180]
Use of Estimates

[0001193125-11-239169:notes:181]
The preparation of the consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; self-insurance; stock-based compensation; loss contingencies; investment impairments; income taxes, and fair value measurements. Actual results could differ from those estimates.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-11-239169:notes:182]
| 10. | Stockholders' Equity |

[0001193125-11-239169:notes:183]
[same as prior period, unchanged from 0001193125-11-056223:notes:156]

[0001193125-11-239169:notes:184]
[same as prior period, unchanged from 0001193125-11-056223:notes:157]

[0001193125-11-239169:notes:185]
The intrinsic value of stock options represents the difference between the exercise price of stock options and the market price of our stock on that day for all in-the-money options. Additional information related to our stock options is summarized below (in millions except per share information):

[0001193125-11-239169:notes:186]
There was $105.1 million of total unrecognized compensation expense as of July 29, 2011 related to options. The unrecognized compensation expense will be amortized on a straight-line basis over a weighted-average remaining period of 2.4 years.

[0001193125-11-239169:notes:187]
The following table summarizes activity related to our restricted stock units (RSUs) (in millions, except the fair value):

[0001193125-11-239169:notes:188]
RSUs are converted into common stock upon vesting. Upon the vesting of restricted stock, we primarily use the net share settlement approach, which withholds a portion of the shares to cover the applicable taxes and decreases the shares issued to the employee by a corresponding value. The number and the value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001193125-11-239169:notes:189]
As of July 29, 2011, there was $390.1 million of total unrecognized compensation expense related to RSUs. The unrecognized compensation expense will be amortized on a straight-line basis over a weighted-average remaining vesting period of 3.0 years.

[0001193125-11-239169:notes:190]
Employee Stock Purchase Plan — Under the Employee Stock Purchase Plan (ESPP), employees are entitled to purchase shares of our common stock at 85% of the fair market value at certain specified dates over a two-year period. Additional information related to our purchase rights issued under the ESPP is summarized below (in millions, except per share information):

[0001193125-11-239169:notes:191]
[same as prior period, unchanged from 0001193125-11-056223:notes:164]

[0001193125-11-239169:notes:192]
Stock-based compensation expenses included in the condensed consolidated statements of operations for the three month periods ended July 29, 2011 and July 30, 2010, respectively, are as follows (in millions):

[0001193125-11-239169:notes:193]
The following table summarizes stock-based compensation associated with each type of award (in millions):

[0001193125-11-239169:notes:194]
Total income tax benefits (charges) associated with employee stock transactions and recognized in stockholders' equity were as follows (in millions):

[0001193125-11-239169:notes:195]
[same as prior period, unchanged from 0001193125-11-056223:notes:168]

[0001193125-11-239169:notes:196]
[same as prior period, unchanged from 0001193125-11-056223:notes:169]

[0001193125-11-239169:notes:197]
[same as prior period, unchanged from 0001193125-11-056223:notes:170]

[0001193125-11-239169:notes:198]
During the three months ended July 29, 2011, 3.6 million shares of our common stock were repurchased as described below. Since the May 13, 2003 inception of our stock repurchase program through July 29, 2011, we repurchased a total of 108.0 million shares of our common stock at an average price of $28.70 per share, for an aggregate purchase price of $3.1 billion. As of July 29, 2011, our Board of Directors had authorized the repurchase of up to $4.0 billion of common stock under this stock repurchase program, and $0.9 billion remains available under these authorizations. The stock repurchase program may be suspended or discontinued at any time.

[0001193125-11-239169:notes:199]
Accelerated Share Repurchase Agreement

[0001193125-11-239169:notes:200]
On July 8, 2011, we entered into a collared accelerated share repurchase agreement (ASR) with Bank of America, N.A (the dealer), under which we prepaid $200.0 million to purchase shares of our common stock. The aggregate number of shares ultimately purchased was determined based on the volume weighted average share price of our common stock over a specified period of time, subject to certain provisions that established a minimum and maximum number of shares that may be repurchased. On July 11, 2011, the dealer delivered 3.6 million minimum shares, which were retired immediately. The contract was terminated and settled on August 9, 2011 for which we received an additional 0.5 million shares on August 12, 2011. The total number of shares repurchased under this ASR was 4.1 million shares at a volume adjusted weighted average price of $48.30. Under the terms of the ASR, there was no requirement for the dealer to return any portion of the prepayment.

[0001193125-11-239169:notes:201]
The contract value was allocated to the cost of the shares repurchased and to the value of the ASR forward contract as follows for the three month period ended July 29, 2011 (in millions):

[0001193125-11-239169:notes:202]
|  |  | Shares ofCommonStock |  |  | AdditionalPaid-inCapital |  |  | RetainedEarnings |  |  | TotalRepurchaseActivity |  |
| Repurchase and retirement of common stock |  |  | (3.6 | ) |  | $ | (30.6 | ) |  | $ | (161.1 | ) |  | $ | (191.7 | ) |
| Value of ASR forward contract |  |  |  |  |  |  | (8.3 | ) |  |  |  |  |  |  | (8.3 | ) |
| Total cash payment |  |  | (3.6 | ) |  | $ | (38.9 | ) |  | $ | (161.1 | ) |  | $ | (200.0 | ) |

[0001193125-11-239169:notes:203]
Comprehensive Income (Loss)

[0001193125-11-239169:notes:204]
[same as prior period, unchanged from 0001193125-11-056223:notes:174]

[0001193125-11-239169:notes:205]
The components of comprehensive income, net of related tax effects, were as follows (in millions):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-11-239169:notes:206]
| 7. | Balance Sheet Detail |

[0001193125-11-239169:notes:207]
Cash and cash equivalents (in millions):

[0001193125-11-239169:notes:208]
Inventories (in millions):

[0001193125-11-239169:notes:209]
Other current assets (in millions):

[0001193125-11-239169:notes:210]
Property and equipment (in millions):

[0001193125-11-239169:notes:211]
Software includes capitalized internal-use software development costs. The net book value of computer software is as follows:

[0001193125-11-239169:notes:212]
Long-term investments and restricted cash (in millions):

[0001193125-11-239169:notes:213]
Short-term and long-term deferred revenue (in millions):
