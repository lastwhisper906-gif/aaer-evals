# NTAP notes — 0000950170-23-027948


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000950170-23-027948:notes:1]
The information called for by Part III of this Form 10-K is hereby incorporated by reference from the definitive Proxy Statement for our annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after April 28, 2023.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000950170-23-027948:notes:2]
1. Description of Business and Significant Accounting Policies

[0000950170-23-027948:notes:3]
Description of Business — NetApp, Inc. (we, us, or the Company) is a global cloud-led, data-centric software company that provides organizations the ability to manage and share their data across on-premises, private and public clouds. We provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.

[0000950170-23-027948:notes:4]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal 2023, which ended on April 28, 2023, and fiscal 2022, which ended on April 29, 2022 were both 52-week years. Fiscal 2021, ending on April 30, 2021 was a 53-week year, with 14 weeks included in its first quarter and 13 weeks in each subsequent quarter. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended on the last Friday of April and the associated quarters, months and periods of those fiscal years.

[0000950170-23-027948:notes:5]
Principles of Consolidation — The consolidated financial statements include the Company and its subsidiaries. Intercompany accounts and transactions are eliminated in consolidation.

[0000950170-23-027948:notes:6]
Use of Estimates — The preparation of the consolidated financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, the anticipated effects of which have been incorporated, as applicable, into management’s estimates as of and for the year ended April 28, 2023.

[0000950170-23-027948:notes:7]
Cash Equivalents — We consider all highly liquid debt investments with original maturities of three months or less at the time of purchase to be cash equivalents.

[0000950170-23-027948:notes:8]
Available-for-Sale Investments — We classify our investments in debt securities as available-for-sale investments. Debt securities primarily consist of corporate bonds, U.S. Treasury and government debt securities and certificates of deposit. These investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of debt securities sold. These investments are recorded in the consolidated balance sheets at fair value.

[0000950170-23-027948:notes:9]
Unrealized gains and temporary losses, net of related taxes, are included in accumulated other comprehensive income (loss) (AOCI). Upon realization, those amounts are reclassified from AOCI to earnings. The amortization of premiums and discounts on the investments are included in our results of operations. Realized gains and losses are calculated based on the specific identification method.

[0000950170-23-027948:notes:10]
We classify our investments as current or noncurrent based on the nature of the investments and their availability for use in current operations.

[0000950170-23-027948:notes:11]
Other-than-Temporary Impairments on Investments — All of our available-for-sale investments are subject to periodic impairment review. When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and we assess whether the impairment is other-than-temporary. An impairment is considered other-than-temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of the entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost basis of the security. If impairment is considered other-than-temporary based on condition (i) or (ii) described above, the entire difference between the amortized cost and the fair value of the debt security is recognized in the results of operations. If an impairment is considered other-than-temporary based on condition (iii) described above, the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in earnings, and the amount relating to all other factors is recognized in other comprehensive income (OCI).

[0000950170-23-027948:notes:12]
Inventories — Inventories are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. We write down excess and obsolete inventory based on the difference between the cost of inventory and the estimated net realizable value. Net realizable value is estimated using management’s best estimate of forecasts for future demand and expectations regarding market conditions. At the point of a loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts or circumstances do not result in the restoration or increase in that newly established basis. In addition, we record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0000950170-23-027948:notes:13]
Property and Equipment — Property and equipment are recorded at cost.

[0000950170-23-027948:notes:14]
Depreciation and amortization is computed using the straight-line method, generally over the following periods:

[0000950170-23-027948:notes:15]
|  |  | Depreciation Life |
| Buildings and improvements |  | 10 to 40 years |
| Furniture and fixtures |  | 5 years |
| Computer, production, engineering and other equipment |  | 2 to 3 years |
| Computer software |  | 3 to 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |

[0000950170-23-027948:notes:16]
Construction in progress will be depreciated over the estimated useful lives of the respective assets when they are ready for use. We capitalize interest on significant facility assets under construction and on significant software development projects. Interest capitalized during the periods presented was not material.

[0000950170-23-027948:notes:17]
Software Development Costs — The costs for the development of new software products and substantial enhancements to existing software products are expensed as incurred until technological feasibility has been established, at which time any additional costs would be capitalized in accordance with the accounting guidance for software. Because our current process for developing software is essentially completed concurrently with the establishment of technological feasibility, which occurs upon the completion of a working model, no costs have been capitalized for any of the periods presented.

[0000950170-23-027948:notes:18]
Internal-Use Software Development Costs — We capitalize qualifying costs, which are incurred during the application development stage, for computer software developed or obtained for internal-use and amortize them over the software’s estimated useful life.

[0000950170-23-027948:notes:19]
Business Combinations — We recognize identifiable assets acquired and liabilities assumed at their acquisition date fair values, with the exception of contract assets and liabilities, which beginning in fiscal 2022, we recognize in accordance with our revenue recognition policy as if we had originally executed the customer contract. Goodwill as of the acquisition date is measured as the excess of consideration transferred over the net of the acquisition date values of the assets acquired and liabilities assumed. While we use our best estimates and assumptions as a part of the purchase price allocation process to accurately value assets acquired and liabilities assumed at the acquisition date, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of income.

[0000950170-23-027948:notes:20]
Goodwill and Purchased Intangible Assets — Goodwill is recorded when the consideration paid for an acquisition exceeds the value of net tangible and intangible assets acquired. Purchased intangible assets with finite lives are generally amortized on a straight-line basis over their economic lives of three to five years for developed technology, two to five years for customer contracts/relationships, two to three years for covenants not to compete and two to five years for trademarks and trade names as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. In-process research and development is accounted for as an indefinite lived intangible asset and is assessed for potential impairment annually until development is complete or when events or circumstances indicate that their carrying amounts might be impaired. Upon completion of development, in-process research and development is accounted for as a finite-lived intangible asset.

[0000950170-23-027948:notes:21]
The carrying value of goodwill is tested for impairment on an annual basis in the fourth quarter of our fiscal year, or more frequently if we believe indicators of impairment exist. Triggering events for impairment reviews may be indicators such as adverse industry or economic trends, restructuring actions, lower projections of profitability, or a sustained decline in our market capitalization. For the purpose of impairment testing, we have two reporting units, which are the same as our two reportable segments. We initially conduct a qualitative assessment to determine whether it is necessary to perform a quantitative goodwill impairment test. The performance of the quantitative impairment test requires comparing the fair value of each reporting unit to its carrying amount, including goodwill. The fair value of each reporting unit is based on a combination of the income approach and the market approach.

[0000950170-23-027948:notes:22]
Under the income approach, we estimate the fair value of a reporting unit based on the present value of estimated future cash flows. Cash flow projections are based on discrete forecast periods as well as terminal value determinations, and are derived based on forecasted revenue growth rates and operating margins. These cash flow projections are discounted to arrive at the fair value of each reporting unit. The discount rate used is based on the weighted-average cost of capital of comparable public companies adjusted for the relevant risk associated with business specific characteristics and the uncertainty related to the reporting unit's ability to execute on the projected cash flows. Under the market approach, we estimate the fair value based on market multiples of revenue and earnings derived from comparable publicly traded companies with operating and investment characteristics similar to the reporting unit. In addition, we make certain judgments and assumptions in allocating shared assets and liabilities to individual reporting units to determine the carrying amount of each reporting unit. An impairment exists if the fair value of a reporting unit is lower than its carrying amount. The impairment loss is measured based on the amount by which the carrying amount of the reporting unit exceeds its fair value, with the recognized loss not to exceed the total amount of allocated goodwill. The fair value of each reporting unit has substantially exceeded its carrying amount in all periods presented.

[0000950170-23-027948:notes:23]
Impairment of Long-Lived Assets — We review the carrying values of long-lived assets whenever events and circumstances, such as reductions in demand, lower projections of profitability, significant changes in the manner of our use of acquired assets, or significant negative industry or economic trends, indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. If this review indicates that there is an impairment, the impaired asset is written down to its fair value, which is typically calculated using: (i) quoted market prices and/or (ii) expected future cash flows utilizing a discount rate. Our estimates regarding future anticipated cash flows, the remaining economic life of the products and technologies, or both, may differ materially from actual cash flows and remaining economic life. In that event, impairment charges or shortened useful lives of certain long-lived assets may be required, resulting in charges to our consolidated statements of income when such determinations are made.

[0000950170-23-027948:notes:24]
Derivative Instruments — Our derivative instruments, which are carried at fair value in our consolidated balance sheets, consist of foreign currency exchange contracts as described below:

[0000950170-23-027948:notes:25]
Balance Sheet Hedges — We utilize foreign currency exchange forward and option contracts to hedge against the short-term impact of foreign currency exchange rate fluctuations related to certain foreign currency denominated monetary assets and liabilities, primarily intercompany receivables and payables. These derivative instruments are not designated as hedging instruments and do not subject us to material balance sheet risk due to exchange rate movements because the gains and losses on these contracts are intended to offset the gains and losses in the underlying foreign currency denominated monetary assets and liabilities being hedged, and the net amount is included in earnings.

[0000950170-23-027948:notes:26]
Cash Flow Hedges — We utilize foreign currency exchange forward contracts to hedge foreign currency exchange exposures related to forecasted sales transactions denominated in certain foreign currencies. These derivative instruments are designated and qualify as cash flow hedges and, in general, closely match the underlying forecasted transactions in duration. The effective portion of the contracts’ gains and losses resulting from changes in fair value is recorded in AOCI until the forecasted transaction is recognized in the consolidated statements of income. When the forecasted transactions occur, we reclassify the related gains or losses on the cash flow hedges into net revenues. If the underlying forecasted transactions do not occur, or it becomes probable that they will not occur within the defined hedge period, the gains or losses on the related cash flow hedges are reclassified from AOCI and recognized immediately in earnings. We measure the effectiveness of hedges of forecasted transactions on a monthly basis by comparing the fair values of the designated foreign currency exchange forward purchase contracts with the fair values of the forecasted transactions.

[0000950170-23-027948:notes:27]
Factors that could have an impact on the effectiveness of our hedging programs include the accuracy of forecasts and the volatility of foreign currency markets. These programs reduce, but do not entirely eliminate, the impact of currency exchange movements. Currently, we do not enter into any foreign currency exchange forward contracts to hedge exposures related to firm commitments. Cash flows from our derivative programs are included under operating activities in the consolidated statements of cash flows.

[0000950170-23-027948:notes:28]
Revenue Recognition — We recognize revenue by applying the following five step approach.

[0000950170-23-027948:notes:29]
•
Identification of the contract, or contracts, with a customer — A contract with a customer is within the scope of ASC 606 when it meets all the following criteria:

[0000950170-23-027948:notes:30]
-
It is enforceable

[0000950170-23-027948:notes:31]
-
It defines each party’s rights

[0000950170-23-027948:notes:32]
-
It identifies the payment terms

[0000950170-23-027948:notes:33]
-
It has commercial substance, and

[0000950170-23-027948:notes:34]
-
We determine that collection of substantially all consideration for goods or services that will be transferred is probable based on the customer’s intent and ability to pay

[0000950170-23-027948:notes:35]
•
Identification of the performance obligations in the contract — Performance obligations promised in a contract are identified based on the goods or services (or a bundle of goods and services) that will be transferred to the customer that are distinct.

[0000950170-23-027948:notes:36]
•
Determination of the transaction price — The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer.

[0000950170-23-027948:notes:37]
•
Allocation of the transaction price to the performance obligations in the contract — Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation.

[0000950170-23-027948:notes:38]
•
Recognition of revenue when, or as, we satisfy a performance obligation — We satisfy performance obligations either over time or at a point in time.

[0000950170-23-027948:notes:39]
Customarily we have a purchase order from or executed contract with our customers that establishes the goods and services to be transferred and the consideration to be received.

[0000950170-23-027948:notes:40]
We combine two or more contracts entered into at or near the same time with the same customer as a single contract if the contracts are negotiated as one package with a single commercial objective, if the amount of consideration to be paid on one contract depends on the price or performance of the other contract or if the goods and services promised in each of the contracts are a single performance obligation.

[0000950170-23-027948:notes:41]
Our contracts with customers may include hardware systems, software licenses, software support, hardware support, public cloud services and other services. Software support contracts entitle our customers to receive unspecified upgrades and enhancements on a when-and-if-available basis, and patch releases. Hardware support services include contracts for extended warranty and technical support with minimum response times. Other services include professional services and customer education and training services.

[0000950170-23-027948:notes:42]
We identify performance obligations in our contracts to be those goods and services that are distinct. A good or service is distinct where the customer can benefit from the good or service either on its own or together with other resources that are readily available from third parties or from us, and is distinct in the context of the contract, where the transfer of the good or service is separately identifiable from other promises in the contract.

[0000950170-23-027948:notes:43]
If a contract includes multiple promised goods or services, we apply judgment to determine whether promised goods or services are distinct. If they are not, we combine the goods and services until we have a distinct performance obligation. For example, a configured storage system inclusive of the operating system (OS) software essential to its functionality is considered a single performance obligation, while optional add-on software is a separate performance obligation. In general, hardware support, software support, and different types of professional services are each separate performance obligations.

[0000950170-23-027948:notes:44]
We determine the transaction price of our contracts with customers based on the consideration to which we will be entitled in exchange for transferring goods or services. Consideration promised may include fixed amounts, variable amounts or both. We sell public cloud services either on a subscription basis or a consumption basis. We sell professional services either on a time and materials basis or under fixed price projects.

[0000950170-23-027948:notes:45]
We evaluate variable consideration in arrangements with contract terms such as rights of return, potential penalties and acceptance clauses. We generally use the expected value method, primarily relying on our history, to estimate variable consideration. However, when we believe it to provide a better estimate, we use the most likely amount method. In either case, we consider variable consideration only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recognized will not occur. Reassessments of our variable consideration may occur as historical information changes. Transaction prices are also adjusted for the effects of time value of money if the timing of payments provides either the customer or us a significant benefit of financing.

[0000950170-23-027948:notes:46]
Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation on a relative standalone selling price basis. We determine standalone selling price based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price by maximizing the use of observable inputs including pricing strategy, market data, internally-approved pricing guidelines related to the performance obligations and other observable inputs. We regularly review standalone selling prices and maintain internal controls over the establishment and updates of these estimates. Variable consideration is also allocated to the performance obligations. If the terms of variable consideration relate to one performance obligation, it is entirely allocated to that obligation. Otherwise, it is allocated to all the performance obligations in the contract.

[0000950170-23-027948:notes:47]
We typically recognize revenue at a point in time upon the transfer of goods to a customer. Products we transfer at a point in time include our configured hardware systems, OS software licenses, optional add-on software licenses and add-on hardware. Services are typically transferred over time and revenue is recognized based on an appropriate method for measuring our progress toward

[0000950170-23-027948:notes:48]
completion of the performance obligation. Our stand-ready services, including both hardware and software support, are transferred ratably over the period of the contract. Our public cloud services are transferred either 1) for subscription arrangements, ratably over the subscription period or 2) for consumption-based arrangements, as actually consumed by the customer. For other services such as our fixed professional services contracts, we use an input method to determine the percentage of completion. That is, we estimate the effort to date versus the expected effort required over the life of the contract.

[0000950170-23-027948:notes:49]
Deferred Commissions — We capitalize sales commissions that are incremental direct costs of obtaining customer contracts for which revenue is not immediately recognized and classify them as current or non-current based on the terms of the related contracts. Capitalized commissions are amortized based on the transfer of goods or services to which they relate, typically over one to three years, and are also periodically reviewed for impairment. Amortization expense is recorded to sales and marketing expense in our consolidated statements of income.

[0000950170-23-027948:notes:50]
Leases — We determine if an arrangement is or contains a lease at inception, and we classify leases as operating or finance leases at commencement. In our consolidated balance sheets, operating lease right-of-use (ROU) assets are included in other non-current assets, while finance lease ROU assets are included in property and equipment, net. Lease liabilities for both types of leases are included in accrued expenses and other long-term liabilities. ROU assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over that term.

[0000950170-23-027948:notes:51]
Operating and finance lease ROU assets and liabilities are recognized at commencement based on the present value of lease payments over the lease term. ROU assets also include any lease payments made prior to lease commencement and exclude lease incentives. The lease term is the noncancelable period of the lease and includes options to extend or terminate the lease when it is reasonably certain that an option will be exercised. As the rate implicit in our leases is typically not readily determinable, in computing the present value of lease payments we generally use our incremental borrowing rate based on information available at the commencement date. Variable lease payments not dependent on an index or rate are expensed as incurred and not included within the calculation of ROU assets and lease liabilities. Lease expense for operating lease payments is recognized on a straight-line basis over the lease term.

[0000950170-23-027948:notes:52]
We do not separate non-lease components from lease components for any class of leases, and we do not recognize ROU assets and lease liabilities for leases with a lease term of twelve months or less.

[0000950170-23-027948:notes:53]
Foreign Currency Translation — For international subsidiaries whose functional currency is the local currency, gains and losses resulting from translation of these foreign currency financial statements into U.S. dollars are recorded in AOCI. For international subsidiaries where the functional currency is the U.S. dollar, gains and losses resulting from the process of remeasuring foreign currency financial statements into U.S. dollars are included in other (expense) income, net.

[0000950170-23-027948:notes:54]
Benefit Plans — We record actuarial gains and losses associated with defined benefit plans within AOCI and amortize net gains or losses in excess of 10 percent of the greater of the market value of plan assets or the plans' projected benefit obligation on a straight-line basis over the remaining estimated service life of plan participants. The measurement date for all defined benefit plans is our fiscal year end.

[0000950170-23-027948:notes:55]
Stock-Based Compensation — We measure and recognize stock-based compensation for all stock-based awards, including employee stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and rights to purchase shares under our employee stock purchase plan (ESPP), based on their estimated fair value, and recognize the costs in our financial statements using the straight-line attribution approach over the requisite service period for the entire award.

[0000950170-23-027948:notes:56]
The fair value of employee time-based RSUs, and PBRSUs that include a performance condition, is equal to the market value of our common stock on the grant date of the award, less the present value of expected dividends during the vesting period, discounted at a risk-free interest rate. The fair value of PBRSUs that include a market condition is measured using a Monte Carlo simulation model on the date of grant.

[0000950170-23-027948:notes:57]
The fair value of time-based RSUs, and PBRSUs that include a market condition, is not remeasured as a result of subsequent stock price fluctuations. When there is a change in management’s estimate of expected achievement relative to the performance target for PBRSUs that include a performance condition, such as our achievement against a billings result average target, the change in estimate results in the recognition of a cumulative adjustment of stock-based compensation expense.

[0000950170-23-027948:notes:58]
Our expected term assumption is based primarily on historical exercise and post-vesting forfeiture experience. Our stock price volatility assumption is based on a combination of our historical and implied volatility. The risk-free interest rates are based upon United States (U.S.) Treasury bills with equivalent expected terms, and the expected dividends are based on our history and expected dividend payouts.

[0000950170-23-027948:notes:59]
We account for forfeitures of stock-based awards as they occur.

[0000950170-23-027948:notes:60]
Income Taxes — Deferred income tax assets and liabilities are provided for temporary differences that will result in tax deductions or income in future periods, as well as the future benefit of tax credit carryforwards. A valuation allowance reduces tax assets to their estimated realizable value.

[0000950170-23-027948:notes:61]
We recognize the tax liability for uncertain income tax positions on the income tax return based on the two-step process prescribed in the interpretation. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. We recognize interest and penalties related to unrecognized tax benefits within the provision for income taxes line on the accompanying consolidated statements of income.

[0000950170-23-027948:notes:62]
Net Income per Share — Basic net income per share is computed by dividing net income by the weighted-average number of common shares outstanding. Diluted net income per share is computed giving effect to the weighted-average number of dilutive potential shares that were outstanding during the period using the treasury stock method. Potential dilutive common shares consist primarily of outstanding stock options, shares to be purchased under our employee stock purchase plan and unvested RSUs.

[0000950170-23-027948:notes:63]
Treasury Stock — We account for treasury stock under the cost method. Upon the retirement of treasury stock, we allocate the value of treasury shares between common stock, additional paid-in capital and retained earnings.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000950170-23-027948:notes:64]
2. Recent Accounting Pronouncements

[0000950170-23-027948:notes:65]
Although there are new accounting pronouncements issued or proposed by the FASB that we have adopted or will adopt, as applicable, we do not believe any of these accounting pronouncements had or will have a material impact on our consolidated financial position, operating results, cash flows or disclosures.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-23-027948:notes:66]
3. Concentration of Risk

[0000950170-23-027948:notes:67]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, investments, foreign currency exchange contracts and accounts receivable. We maintain the majority of our cash and cash equivalents with several major financial institutions where the deposits exceed federally insured limits. Cash equivalents and short-term investments consist primarily of money market funds, U.S. Treasury and government debt securities and certificates of deposit, all of which are considered high investment grade. Our policy is to limit the amount of credit exposure through diversification and investment in highly rated securities. We further mitigate concentrations of credit risk in our investments by limiting our investments in the debt securities of a single issuer and by diversifying risk across geographies and type of issuer. General macroeconomic uncertainty has led to an increase in market volatility, however, management believes that the financial institutions that hold our cash, cash equivalents and investments are financially sound and, accordingly, are subject to minimal credit risk.

[0000950170-23-027948:notes:68]
By entering into foreign currency exchange contracts, we have assumed the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and we do not expect any losses as a result of counterparty defaults.

[0000950170-23-027948:notes:69]
We sell our products primarily to large organizations in different industries and geographies. We do not require collateral or other security to support accounts receivable. In addition, we maintain an allowance for potential credit losses. To reduce credit risk, we perform ongoing credit evaluations on our customers’ financial condition. We establish an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information, including the expected impact of macroeconomic disruptions, and, to date, such losses have been within management’s expectations. Concentrations of credit risk with respect to trade accounts receivable are limited due to the wide variety of customers who are dispersed across many geographic regions.

[0000950170-23-027948:notes:70]
There are no concentrations of business transacted with a particular market that would severely impact our business in the near term. However, we rely on a limited number of suppliers for certain key components and a few key contract manufacturers to manufacture most of our products; any disruption, or termination of these arrangements could materially adversely affect our operating results.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-23-027948:notes:71]
4. Business Combinations

[0000950170-23-027948:notes:72]
Fiscal 2023 Acquisition

[0000950170-23-027948:notes:73]
Instaclustr Acquisition

[0000950170-23-027948:notes:74]
On May 20, 2022, we acquired all the outstanding shares of privately-held Instaclustr US Holding, Inc. (Instaclustr) for approximately $498 million. Instaclustr is a leading platform provider of fully managed open-source database, pipeline and workflow applications delivered as-a-service.

[0000950170-23-027948:notes:75]
The acquisition-date values of the assets acquired and liabilities assumed are as follows (in millions):

[0000950170-23-027948:notes:76]
|  |  | Amount |  |
| Cash |  | $ | 4 |  |
| Intangible assets |  |  | 107 |  |
| Goodwill |  |  | 413 |  |
| Other assets |  |  | 19 |  |
| Total assets acquired |  |  | 543 |  |
| Liabilities assumed |  |  | (45 | ) |
| Total purchase price |  | $ | 498 |  |

[0000950170-23-027948:notes:77]
The components of the intangible assets acquired were as follows (in millions, except useful life):

[0000950170-23-027948:notes:78]
|  |  | Amount |  |  | Estimated useful life(years) |  |
| Developed technology |  | $ | 55 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 50 |  |  |  | 5 |  |
| Trade name |  |  | 2 |  |  |  | 3 |  |
| Total intangible assets |  | $ | 107 |  |  |  |  |

[0000950170-23-027948:notes:79]
The acquired net assets and assumed debt of Instaclustr were recorded at their estimated values. We determined the estimated values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expect to realize revenue synergies and anticipate opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated fair value of its identifiable net assets acquired, and as a result, we have recorded goodwill in connection with the acquisition. The goodwill is not deductible for income tax purposes.

[0000950170-23-027948:notes:80]
The results of operations related to the acquisition of Instaclustr have been included in our consolidated statements of income from the acquisition date. Pro forma results of operations have not been presented because the impact from the acquisition was not material to our consolidated results of operations.

[0000950170-23-027948:notes:81]
Fiscal 2022 Acquisitions

[0000950170-23-027948:notes:82]
Fylamynt Acquisition

[0000950170-23-027948:notes:83]
On February 18, 2022, we acquired all the outstanding shares of privately-held NeurOps Inc. (which operated under the name "Fylamynt") for approximately $27 million in cash, of which $22 million was paid at closing. The purchase price includes $5 million related to an indemnity holdback provision, of which $4 million was paid in the fourth quarter of fiscal 2023. Fylamynt is an innovative CloudOps automation technology company that enables customers to build, run, manage and analyze workflows securely in any cloud with little to no code.

[0000950170-23-027948:notes:84]
The acquisition-date values of the assets acquired are as follows (in millions):

[0000950170-23-027948:notes:85]
|  |  | Amount |  |
| Cash |  | $ | 1 |  |
| Developed technology |  |  | 6 |  |
| Goodwill |  |  | 20 |  |
| Total assets acquired |  |  | 27 |  |
| Total purchase price |  | $ | 27 |  |

[0000950170-23-027948:notes:86]
CloudCheckr Acquisition

[0000950170-23-027948:notes:87]
On November 5, 2021, we acquired all the outstanding shares of privately-held CloudCheckr Inc., (CloudCheckr) for approximately $347 million in cash. CloudCheckr is a leading cloud optimization platform that provides cloud visibility and insights to lower costs, maintain security and compliance, and optimize cloud resources.

[0000950170-23-027948:notes:88]
|  |  | Amount |  |
| Cash |  | $ | 2 |  |
| Intangible assets |  |  | 76 |  |
| Goodwill |  |  | 276 |  |
| Other assets |  |  | 6 |  |
| Total assets acquired |  |  | 360 |  |
| Liabilities assumed |  |  | (13 | ) |
| Total purchase price |  | $ | 347 |  |

[0000950170-23-027948:notes:89]
|  |  | Amount |  |  | Estimated useful life(years) |  |
| Developed technology |  | $ | 45 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 30 |  |  |  | 5 |  |
| Trade name |  |  | 1 |  |  |  | 3 |  |
| Total intangible assets |  | $ | 76 |  |  |  |  |

[0000950170-23-027948:notes:90]
Data Mechanics Acquisition

[0000950170-23-027948:notes:91]
On June 18, 2021, we acquired all the outstanding shares of privately-held Data Mechanics Inc. (Data Mechanics), a provider of managed platforms for big data processing and cloud analytics headquartered in Paris, France, for approximately $15 million in cash.

[0000950170-23-027948:notes:92]
|  |  | Amount |  |
| Cash |  | $ | 1 |  |
| Developed technology |  |  | 5 |  |
| Goodwill |  |  | 11 |  |
| Total assets acquired |  |  | 17 |  |
| Liabilities assumed |  |  | (2 | ) |
| Total purchase price |  | $ | 15 |  |

[0000950170-23-027948:notes:93]
The acquired assets and assumed liabilities of Fylamynt, CloudCheckr and Data Mechanics were recorded at their estimated values. We determined the estimated values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expect to realize incremental revenue by offering continuous cost optimization and managed services from our existing capabilities to help customers improve their cloud resources and realize the benefits of cloud faster and at scale. We also anticipate opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated fair value of their identifiable net assets acquired, and as a result, we have recorded goodwill in connection with these acquisitions. The goodwill is not deductible for income tax purposes.

[0000950170-23-027948:notes:94]
The results of operations related to the acquisitions of Fylamynt, CloudCheckr and Data Mechanics have been included in our consolidated statements of income from their respective acquisition dates. Pro forma results of operations have not been presented because the impact from these acquisitions was not material to our consolidated results of operations.

[0000950170-23-027948:notes:95]
Fiscal 2021 Acquisitions

[0000950170-23-027948:notes:96]
Spot, Inc. Acquisition

[0000950170-23-027948:notes:97]
On July 9, 2020, we acquired all the outstanding shares of privately-held Spot, Inc. (Spot), a provider of compute management cost optimization services on the public clouds based in Israel, for $340 million in cash.

[0000950170-23-027948:notes:98]
|  |  | Amount |  |
| Cash |  | $ | 24 |  |
| Intangible assets |  |  | 84 |  |
| Goodwill |  |  | 249 |  |
| Other assets |  |  | 6 |  |
| Total assets acquired |  |  | 363 |  |
| Liabilities assumed |  |  | (23 | ) |
| Total purchase price |  | $ | 340 |  |

[0000950170-23-027948:notes:99]
The components of the Spot intangible assets acquired were as follows (in millions, except useful life):

[0000950170-23-027948:notes:100]
|  |  | Amount |  |  | Estimated useful life(years) |  |
| Developed technology |  | $ | 53 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 28 |  |  |  | 5 |  |
| Trade name |  |  | 3 |  |  |  | 3 |  |
| Total intangible assets |  | $ | 84 |  |  |  |  |

[0000950170-23-027948:notes:101]
Cloud Jumper Corporation Acquisition

[0000950170-23-027948:notes:102]
On April 28, 2020, we acquired all the outstanding shares of privately-held Cloud Jumper Corporation (Cloud Jumper), a provider of virtual desktop infrastructure and remote desktop services solutions based in North Carolina, for $34 million in cash.

[0000950170-23-027948:notes:103]
|  |  | Amount |  |
| Developed technology |  | $ | 16 |  |
| Customer contracts/relationships |  |  | 6 |  |
| Goodwill |  |  | 12 |  |
| Other assets |  |  | 1 |  |
| Total assets acquired |  |  | 35 |  |
| Liabilities assumed |  |  | (1 | ) |
| Total purchase price |  | $ | 34 |  |

[0000950170-23-027948:notes:104]
The acquired assets and assumed liabilities of Spot and Cloud Jumper were recorded at their estimated values. We determined the estimated values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expect to realize revenue synergies, leverage and expand the existing Spot and Cloud Jumper sales channels and product development resources, and utilize their existing workforces. We also anticipate opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated fair value of their identifiable net assets acquired, and as a result, we have recorded goodwill in connection with both of these acquisitions. The goodwill is not deductible for income tax purposes.

[0000950170-23-027948:notes:105]
The results of operations related to the acquisition of both Spot and Cloud Jumper have been included in our consolidated statements of income from their respective acquisition dates. Pro forma results of operations have not been presented because the impact from these acquisitions would not have been material to our consolidated results of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-23-027948:notes:106]
5. Goodwill and Purchased Intangible Assets, Net

[0000950170-23-027948:notes:107]
Goodwill activity is summarized as follows (in millions):

[0000950170-23-027948:notes:108]
|  |  | Amount |  |
| Balance as of April 30, 2021 |  | $ | 2,039 |  |
| Additions |  |  | 307 |  |
| Balance as of April 29, 2022 |  |  | 2,346 |  |
| Additions |  |  | 413 |  |
| Balance as of April 28, 2023 |  | $ | 2,759 |  |

[0000950170-23-027948:notes:109]
The $413 million addition to goodwill in fiscal 2023 was from the Instaclustr acquisition and was allocated to our Public Cloud segment.

[0000950170-23-027948:notes:110]
Goodwill by reportable segment as of April 28, 2023 is as follows (in millions):

[0000950170-23-027948:notes:111]
|  |  | Amount |  |
| Hybrid Cloud |  | $ | 1,714 |  |
| Public Cloud |  |  | 1,045 |  |
| Total goodwill |  | $ | 2,759 |  |

[0000950170-23-027948:notes:112]
Purchased intangible assets, net are summarized below (in millions):

[0000950170-23-027948:notes:113]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 212 |  |  | $ | (107 | ) |  | $ | 105 |  |  | $ | 157 |  |  | $ | (65 | ) |  | $ | 92 |  |
| Customer contracts/relationships |  |  | 118 |  |  |  | (44 | ) |  |  | 74 |  |  |  | 68 |  |  |  | (20 | ) |  |  | 48 |  |
| Other purchased intangibles |  |  | 6 |  |  |  | (4 | ) |  |  | 2 |  |  |  | 4 |  |  |  | (2 | ) |  |  | 2 |  |
| Total purchased intangible assets |  | $ | 336 |  |  | $ | (155 | ) |  | $ | 181 |  |  | $ | 229 |  |  | $ | (87 | ) |  | $ | 142 |  |

[0000950170-23-027948:notes:114]
Amortization expense for purchased intangible assets is summarized below (in millions):

[0000950170-23-027948:notes:115]
|  |  | Year Ended |  |  | Statements of |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | IncomeClassifications |
| Developed technology |  | $ | 42 |  |  | $ | 33 |  |  | $ | 41 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 24 |  |  |  | 11 |  |  |  | 8 |  |  | Operating expenses |
| Other purchased intangibles |  |  | 2 |  |  |  | 2 |  |  |  | — |  |  | Operating expenses |
| Total |  | $ | 68 |  |  | $ | 46 |  |  | $ | 49 |  |  |  |

[0000950170-23-027948:notes:116]
As of April 28, 2023, future amortization expense related to purchased intangible assets is as follows (in millions):

[0000950170-23-027948:notes:117]
| Fiscal Year |  | Amount |  |
| 2024 |  | $ | 57 |  |
| 2025 |  |  | 55 |  |
| 2026 |  |  | 39 |  |
| 2027 |  |  | 29 |  |
| 2028 |  |  | 1 |  |
| Total |  | $ | 181 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000950170-23-027948:notes:118]
The
Goodwill by reportable segment as of April 28, 2023 is as follows (in millions):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-23-027948:notes:119]
6. Supplemental Financial Information

[0000950170-23-027948:notes:120]
Cash and cash equivalents (in millions):

[0000950170-23-027948:notes:121]
The following table presents cash and cash equivalents as reported in our consolidated balance sheets, as well as the sum of cash, cash equivalents and restricted cash as reported on our consolidated statements of cash flows:

[0000950170-23-027948:notes:122]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Cash and cash equivalents |  | $ | 2,316 |  |  | $ | 4,112 |  |
| Restricted cash |  |  | 6 |  |  |  | 7 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,322 |  |  | $ | 4,119 |  |

[0000950170-23-027948:notes:123]
Inventories (in millions):

[0000950170-23-027948:notes:124]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Purchased components |  | $ | 65 |  |  | $ | 131 |  |
| Finished goods |  |  | 102 |  |  |  | 73 |  |
| Inventories |  | $ | 167 |  |  | $ | 204 |  |

[0000950170-23-027948:notes:125]
Property and equipment, net (in millions):

[0000950170-23-027948:notes:126]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 359 |  |  |  | 353 |  |
| Leasehold improvements |  |  | 91 |  |  |  | 92 |  |
| Computer, production, engineering and other equipment |  |  | 1,053 |  |  |  | 904 |  |
| Computer software |  |  | 325 |  |  |  | 316 |  |
| Furniture and fixtures |  |  | 84 |  |  |  | 76 |  |
| Construction-in-progress |  |  | 55 |  |  |  | 65 |  |
|  |  |  | 2,013 |  |  |  | 1,852 |  |
| Accumulated depreciation and amortization |  |  | (1,363 | ) |  |  | (1,250 | ) |
| Property and equipment, net |  | $ | 650 |  |  | $ | 602 |  |

[0000950170-23-027948:notes:127]
Depreciation and amortization expense related to property and equipment, net is summarized below (in millions):

[0000950170-23-027948:notes:128]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30,2021 |  |
| Depreciation and amortization expense |  | $ | 181 |  |  | $ | 148 |  |  | $ | 158 |  |

[0000950170-23-027948:notes:129]
Other non-current assets (in millions):

[0000950170-23-027948:notes:130]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Deferred tax assets |  | $ | 948 |  |  | $ | 362 |  |
| Operating lease ROU assets |  |  | 281 |  |  |  | 294 |  |
| Other assets |  |  | 319 |  |  |  | 335 |  |
| Other non-current assets |  | $ | 1,548 |  |  | $ | 991 |  |

[0000950170-23-027948:notes:131]
Other non-current assets as of April 28, 2023 and April 29, 2022 include $80 million and $73 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies. Our sales to LNTL are conducted on terms equivalent to those prevailing in an arm’s length transaction.

[0000950170-23-027948:notes:132]
Accrued expenses (in millions):

[0000950170-23-027948:notes:133]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Accrued compensation and benefits |  | $ | 363 |  |  | $ | 462 |  |
| Product warranty liabilities |  |  | 17 |  |  |  | 17 |  |
| Operating lease liabilities |  |  | 47 |  |  |  | 47 |  |
| Other current liabilities |  |  | 430 |  |  |  | 399 |  |
| Accrued expenses |  | $ | 857 |  |  | $ | 925 |  |

[0000950170-23-027948:notes:134]
Other long-term liabilities (in millions):

[0000950170-23-027948:notes:135]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Liability for uncertain tax positions |  | $ | 144 |  |  | $ | 131 |  |
| Income taxes payable |  |  | 215 |  |  |  | 303 |  |
| Product warranty liabilities |  |  | 8 |  |  |  | 9 |  |
| Operating lease liabilities |  |  | 248 |  |  |  | 257 |  |
| Other liabilities |  |  | 93 |  |  |  | 88 |  |
| Other long-term liabilities |  | $ | 708 |  |  | $ | 788 |  |

[0000950170-23-027948:notes:136]
Deferred revenue and financed unearned services revenue

[0000950170-23-027948:notes:137]
The following table summarizes the components of our deferred revenue and financed unearned services balance as reported in our  consolidated balance sheets (in millions):

[0000950170-23-027948:notes:138]
|  | April 28, 2023 |  |  | April 29, 2022 |  |
| Deferred product revenue | $ | 18 |  |  | $ | 31 |  |
| Deferred services revenue |  | 4,247 |  |  |  | 4,140 |  |
| Financed unearned services revenue |  | 48 |  |  |  | 61 |  |
| Total | $ | 4,313 |  |  | $ | 4,232 |  |
| Reported as: |  |  |  |  |  |
| Short-term | $ | 2,218 |  |  | $ | 2,171 |  |
| Long-term |  | 2,095 |  |  |  | 2,061 |  |
| Total | $ | 4,313 |  |  | $ | 4,232 |  |

[0000950170-23-027948:notes:139]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 17 – Commitments and Contingencies for additional information related to these arrangements.

[0000950170-23-027948:notes:140]
During the years ended April 28, 2023 and April 29, 2022, we recognized revenue of $2,171 million and $2,062 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0000950170-23-027948:notes:141]
As of April 28, 2023, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied approximated our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 51% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 24% in the next 13 to 24 months, and the remainder thereafter.

[0000950170-23-027948:notes:142]
Deferred commissions

[0000950170-23-027948:notes:143]
The following table summarizes deferred commissions balances as reported in our consolidated balance sheets (in millions):

[0000950170-23-027948:notes:144]
|  | April 28, 2023 |  |  | April 29, 2022 |  |
| Other current assets | $ | 64 |  |  | $ | 80 |  |
| Other non-current assets |  | 99 |  |  |  | 117 |  |
| Total deferred commissions | $ | 163 |  |  | $ | 197 |  |

[0000950170-23-027948:notes:145]
During the years ended April 28, 2023 and April 29, 2022, we recognized amortization expense from deferred commissions of $116 million and $146 million, respectively, and there were no impairment charges recognized.

[0000950170-23-027948:notes:146]
Other income (expense), net (in millions):

[0000950170-23-027948:notes:147]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Interest income |  | $ | 69 |  |  | $ | 7 |  |  | $ | 9 |  |
| Interest expense |  |  | (67 | ) |  |  | (73 | ) |  |  | (74 | ) |
| Other, net |  |  | 46 |  |  |  | 4 |  |  |  | (4 | ) |
| Other income (expense), net |  | $ | 48 |  |  | $ | (62 | ) |  | $ | (69 | ) |

[0000950170-23-027948:notes:148]
Other, net for fiscal 2023 includes $22 million of other income for non-refundable, up-front payments from customers in Russia for support contracts, which we were not able to fulfill due to imposed sanctions and for which we have no remaining legal obligation to perform. Other, net for fiscal 2023 also includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million.

[0000950170-23-027948:notes:149]
Statements of cash flows additional information (in millions):

[0000950170-23-027948:notes:150]
Supplemental cash flow information related to our operating leases is included in Note 9 – Leases. Non-cash investing and other supplemental cash flow information are presented below:

[0000950170-23-027948:notes:151]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 12 |  |  | $ | 22 |  |  | $ | 15 |  |
| Liabilities incurred to former owners of acquired business |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 386 |  |  | $ | 398 |  |  | $ | 338 |  |
| Interest paid |  | $ | 65 |  |  | $ | 67 |  |  | $ | 57 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-23-027948:notes:152]
7. Financial Instruments and Fair Value Measurements

[0000950170-23-027948:notes:153]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis, whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the three levels of inputs to measure fair value:

[0000950170-23-027948:notes:154]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0000950170-23-027948:notes:155]
Level 2: Inputs that reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; benchmark yields, reported trades, broker/dealer quotes, inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0000950170-23-027948:notes:156]
Level 3: Unobservable inputs that reflect our own assumptions incorporated in valuation techniques used to measure fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0000950170-23-027948:notes:157]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and consider an inactive market to be one in which there are infrequent or few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty’s non-performance risk is considered in measuring the fair values of liabilities and assets, respectively.

[0000950170-23-027948:notes:158]
Investments

[0000950170-23-027948:notes:159]
The following is a summary of our investments at their cost or amortized cost for the years ended April 28, 2023 and April 29, 2022 (in millions):

[0000950170-23-027948:notes:160]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Corporate bonds |  | $ | — |  |  | $ | 9 |  |
| U.S. Treasury and government debt securities |  |  | 754 |  |  |  | 13 |  |
| Money market funds |  |  | 794 |  |  |  | 2,166 |  |
| Certificates of deposit |  |  | 59 |  |  |  | 71 |  |
| Mutual funds |  |  | 36 |  |  |  | 36 |  |
| Total debt and equity securities |  | $ | 1,643 |  |  | $ | 2,295 |  |

[0000950170-23-027948:notes:161]
The fair value of our investments approximates their cost or amortized cost for both periods presented. Investments in mutual funds relate to the non-qualified deferred compensation plan offered to certain employees.

[0000950170-23-027948:notes:162]
As of April 28, 2023, all our debt investments are due to mature in one year or less.

[0000950170-23-027948:notes:163]
Fair Value of Financial Instruments

[0000950170-23-027948:notes:164]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis (in millions):

[0000950170-23-027948:notes:165]
|  |  | April 28, 2023 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 1,463 |  |  | $ | 1,463 |  |  | $ | — |  |
| Money market funds |  |  | 794 |  |  |  | 794 |  |  |  | — |  |
| Certificates of deposit |  |  | 59 |  |  |  | — |  |  |  | 59 |  |
| Total cash and cash equivalents |  |  | 2,316 |  |  |  | 2,257 |  |  |  | 59 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 754 |  |  |  | 754 |  |  |  | — |  |
| Total short-term investments |  |  | 754 |  |  |  | 754 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,070 |  |  | $ | 3,011 |  |  | $ | 59 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 29 |  |  | $ | 29 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |

[0000950170-23-027948:notes:166]
|  |  | April 29, 2022 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 1,875 |  |  | $ | 1,875 |  |  | $ | — |  |
| Money market funds |  |  | 2,166 |  |  |  | 2,166 |  |  |  | — |  |
| Certificates of deposit |  |  | 71 |  |  |  | — |  |  |  | 71 |  |
| Total cash and cash equivalents |  |  | 4,112 |  |  |  | 4,041 |  |  |  | 71 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9 |  |  |  | — |  |  |  | 9 |  |
| U.S. Treasury and government debt securities |  |  | 13 |  |  |  | 13 |  |  |  | — |  |
| Total short-term investments |  |  | 22 |  |  |  | 13 |  |  |  | 9 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,134 |  |  | $ | 4,054 |  |  | $ | 80 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 30 |  |  | $ | 30 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (29 | ) |  | $ | — |  |  | $ | (29 | ) |

[0000950170-23-027948:notes:167]
(1)
Reported as other current assets in the consolidated balance sheets

[0000950170-23-027948:notes:168]
(2)
Reported as other non-current assets in the consolidated balance sheets

[0000950170-23-027948:notes:169]
(3)
Reported as accrued expenses in the consolidated balance sheets

[0000950170-23-027948:notes:170]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of April 28, 2023 and April 29, 2022, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0000950170-23-027948:notes:171]
Fair Value of Debt

[0000950170-23-027948:notes:172]
As of April 28, 2023 and April 29, 2022, the fair value of our long-term debt was approximately $2,206 million and $2,491 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0000950170-23-027948:notes:173]
8. Financing Arrangements

[0000950170-23-027948:notes:174]
Long-Term Debt

[0000950170-23-027948:notes:175]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0000950170-23-027948:notes:176]
|  |  | Effective Interest Rate |  | April 28, 2023 |  |  | April 29, 2022 |  |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | — |  |  | $ | 250 |  |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |  |
| Total principal amount |  |  |  |  | 2,400 |  |  |  | 2,650 |  |  |
| Unamortized discount and issuance costs |  |  |  |  | (11 | ) |  |  | (14 | ) |  |
| Total senior notes |  |  |  |  | 2,389 |  |  |  | 2,636 |  |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (250 | ) |  |
| Total long-term debt |  |  |  | $ | 2,389 |  |  | $ | 2,386 |  |  |

[0000950170-23-027948:notes:177]
Senior Notes

[0000950170-23-027948:notes:178]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were each issued in June 2020. Interest on each of these Senior Notes is payable semi-annually in June and December. Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September.

[0000950170-23-027948:notes:179]
On September 15, 2022, we extinguished our 3.25% Senior Notes due December 2022 for an aggregate cash redemption price of $252 million, comprised of the principal and unpaid interest.

[0000950170-23-027948:notes:180]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0000950170-23-027948:notes:181]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of April 28, 2023, we were in compliance with all covenants associated with the Senior Notes.

[0000950170-23-027948:notes:182]
As of April 28, 2023, our aggregate future principal debt maturities are as follows (in millions):

[0000950170-23-027948:notes:183]
| Fiscal Year |  | Amount |  |
| 2024 |  | $ | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| 2027 |  |  | — |  |
| 2028 |  |  | 550 |  |
| Thereafter |  |  | 700 |  |
| Total |  | $ | 2,400 |  |

[0000950170-23-027948:notes:184]
Commercial Paper Program and Credit Facility

[0000950170-23-027948:notes:185]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of April 28, 2023 or April 29, 2022.

[0000950170-23-027948:notes:186]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023 primarily to replace the London Interbank Offered Rate (LIBOR) with the Secured Overnight Financing Rate (SOFR) as the basis for establishing the interest rate applicable to certain borrowings under the agreement, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of April 28, 2023, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0000950170-23-027948:notes:187]
9. Leases

[0000950170-23-027948:notes:188]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of April 28, 2023, have remaining lease terms not exceeding 19 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of April 28, 2023, have remaining lease terms not exceeding 4 years. As of April 28, 2023, our automobile leases have remaining lease terms not exceeding 4 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0000950170-23-027948:notes:189]
In April 2021, we entered into a lease for our new corporate headquarters located in San Jose, California, which is comprised of approximately three hundred thousand square feet of office space and requires future minimum undiscounted payments of approximately $180 million over the initial 11-year lease term. The lease agreement also provides us two successive renewal options, each for five years. The lease commenced during the first quarter of fiscal 2022.

[0000950170-23-027948:notes:190]
The components of lease cost related to our operating leases were as follows (in millions):

[0000950170-23-027948:notes:191]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Operating lease cost |  | $ | 61 |  |  | $ | 61 |  |
| Variable lease cost |  |  | 16 |  |  |  | 15 |  |
| Total lease cost |  | $ | 77 |  |  | $ | 76 |  |

[0000950170-23-027948:notes:192]
Variable lease cost is primarily attributable to amounts paid to lessors for common area maintenance and utility charges under our real estate leases.

[0000950170-23-027948:notes:193]
The supplemental cash flow information related to our operating leases is as follows (in millions):

[0000950170-23-027948:notes:194]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 55 |  |  | $ | 56 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  | $ | 38 |  |  | $ | 236 |  |

[0000950170-23-027948:notes:195]
The supplemental balance sheet information related to our operating leases is as follows (in millions, except lease term and discount rate):

[0000950170-23-027948:notes:196]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Other non-current assets |  | $ | 281 |  |  | $ | 294 |  |
| Total operating lease ROU assets |  | $ | 281 |  |  | $ | 294 |  |
| Accrued expenses |  | $ | 47 |  |  | $ | 47 |  |
| Other long-term liabilities |  |  | 248 |  |  |  | 257 |  |
| Total operating lease liabilities |  | $ | 295 |  |  | $ | 304 |  |
| Weighted Average Remaining Lease Term |  | 9.4 years |  |  | 9.6 years |  |
| Weighted Average Discount Rate |  |  | 3.0 | % |  |  | 2.8 | % |

[0000950170-23-027948:notes:197]
Future minimum operating lease payments as of April 28, 2023 are as follows (in millions):

[0000950170-23-027948:notes:198]
| Fiscal Year |  |  |  | Amount |  |
| 2024 |  |  |  | $ | 53 |  |
| 2025 |  |  |  |  | 44 |  |
| 2026 |  |  |  |  | 38 |  |
| 2027 |  |  |  |  | 32 |  |
| 2028 |  |  |  |  | 27 |  |
| Thereafter |  |  |  |  | 149 |  |
| Total lease payments |  |  |  |  | 343 |  |
| Less: Interest |  |  |  |  | (48 | ) |
| Total |  |  |  | $ | 295 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000950170-23-027948:notes:199]
10. Stockholders’ Equity

[0000950170-23-027948:notes:200]
Equity Incentive Programs

[0000950170-23-027948:notes:201]
The 2021 Plan — The 2021 Equity Incentive Plan (the 2021 Plan) was adopted by our Board of Directors and approved by the stockholders on September 10, 2021. The 2021 Plan replaced the 1999 Stock Option Plan (the 1999 Plan), and the 1999 Plan terminated effective as of September 11, 2021, except that the 1999 Plan will continue to govern awards outstanding thereunder as of the date of such plan’s termination and such awards will continue in force and effect until terminated pursuant to their terms. The 2021 Plan provides for the granting of incentive stock options, nonstatutory stock options, stock appreciation rights, restricted stock, restricted stock units, and performance awards to our employees, directors, and consultants.

[0000950170-23-027948:notes:202]
Under the 2021 Plan, the Board of Directors may grant to employees, nonemployee directors, consultants and independent advisors options to purchase shares of our common stock during their period of service. The exercise price for an incentive stock option and a nonstatutory option cannot be less than 100% of the fair market value of the common stock on the grant date. The 2021 Plan prohibits the repricing of any outstanding stock option or stock appreciation right after it has been granted or to cancel any outstanding stock option or stock appreciation right and immediately replace it with a new stock option or stock appreciation right with a lower exercise price unless approved by stockholders. RSUs granted under the 2021 Plan include time-based RSUs that generally vest over a four-year period with 25% vesting on the first anniversary of the grant date and 6.25% vesting quarterly thereafter. The Compensation Committee of the Board of Directors (the Compensation Committee) has the discretion to use different vesting schedules. In addition, performance-based RSUs may be granted under the 2021 Plan and are subject to performance criteria and vesting terms specified by the Compensation Committee.

[0000950170-23-027948:notes:203]
As of April 28, 2023, 1 million shares were available for grant under the 2021 Plan.

[0000950170-23-027948:notes:204]
Stock Options

[0000950170-23-027948:notes:205]
Less than 1 million stock options were outstanding as of April 28, 2023 and April 29, 2022.

[0000950170-23-027948:notes:206]
Additional information related to our stock options is summarized below (in millions):

[0000950170-23-027948:notes:207]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Intrinsic value of exercises |  | $ | 7 |  |  | $ | 14 |  |  | $ | 11 |  |
| Proceeds received from exercises |  | $ | 1 |  |  | $ | 1 |  |  | $ | 8 |  |
| Fair value of options vested |  | $ | 4 |  |  | $ | 5 |  |  | $ | 5 |  |

[0000950170-23-027948:notes:208]
Restricted Stock Units

[0000950170-23-027948:notes:209]
In fiscal 2023, 2022 and 2021, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSU cliff-vests at the end of either an approximate one, two or three year performance period, which began on the date specified in the grant agreement and typically ends on the last day of the first, second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle most of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in fiscal 2023 and most of the PBRSUs granted in fiscal 2022 and fiscal 2021, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. The fair values of these awards were fixed at grant date using a Monte Carlo simulation model. For the remaining PBRSUs granted in fiscal 2023, the number of shares issued will depend upon the Company's billings result average over the three-year performance period as compared to a predetermined billings target. Billings for purposes of measuring the performance of these PBRSUs means the total obtained by adding net revenues as reported on the Company's Consolidated Statements of Income to the amount reported as the change in deferred revenue and financed unearned services revenue on the Consolidated Statements of Cash Flows for the applicable measurement period, excluding the impact of fluctuations in foreign currency exchange rates. The fair values of these billings PBRSUs were established consistent with our methodology for valuing time-based RSUs, while compensation cost was recognized based on the probable outcome of the performance condition. The aggregate grant date fair value of all PBRSUs granted in fiscal 2023, 2022 and 2021 was $28 million, $59 million and $27 million, respectively, and these amounts are being recognized to expense over the shorter of the remaining applicable performance or service periods.

[0000950170-23-027948:notes:210]
As of April 28, 2023, April 29, 2022 and April 30, 2021, there were approximately 1 million PBRSUs outstanding.

[0000950170-23-027948:notes:211]
The following table summarizes information related to RSUs, including PBRSUs, (in millions, except for fair value):

[0000950170-23-027948:notes:212]
|  |  | Number ofShares |  |  | Weighted-AverageGrant Date Fair Value |  |
| Outstanding as of April 24, 2020 |  |  | 7 |  |  | $ | 51.40 |  |
| Granted |  |  | 6 |  |  | $ | 42.46 |  |
| Vested |  |  | (3 | ) |  | $ | 44.74 |  |
| Forfeited |  |  | (1 | ) |  | $ | 51.20 |  |
| Outstanding as of April 30, 2021 |  |  | 9 |  |  | $ | 47.75 |  |
| Granted |  |  | 5 |  |  | $ | 80.40 |  |
| Vested |  |  | (3 | ) |  | $ | 48.91 |  |
| Forfeited |  |  | (1 | ) |  | $ | 57.46 |  |
| Outstanding as of April 29, 2022 |  |  | 10 |  |  | $ | 64.09 |  |
| Granted |  |  | 8 |  |  | $ | 59.87 |  |
| Vested |  |  | (4 | ) |  | $ | 62.85 |  |
| Forfeited |  |  | (2 | ) |  | $ | 61.99 |  |
| Outstanding as of April 28, 2023 |  |  | 12 |  |  | $ | 62.08 |  |

[0000950170-23-027948:notes:213]
We primarily use the net share settlement approach upon vesting, where a portion of the shares are withheld as settlement of employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0000950170-23-027948:notes:214]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 84 |  |  | $ | 74 |  |  | $ | 42 |  |

[0000950170-23-027948:notes:215]
Employee Stock Purchase Plan

[0000950170-23-027948:notes:216]
Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. On September 10, 2021, the ESPP was amended to increase the shares reserved for issuance by 3 million shares of common stock. As of April 28, 2023, 2 million shares were available for issuance. The following table summarizes activity related to the purchase rights issued under the ESPP (in millions):

[0000950170-23-027948:notes:217]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Shares issued under the ESPP |  |  | 2 |  |  |  | 3 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 107 |  |  | $ | 104 |  |  | $ | 90 |  |

[0000950170-23-027948:notes:218]
Stock-Based Compensation Expense

[0000950170-23-027948:notes:219]
Stock-based compensation expense is included in the consolidated statements of income as follows (in millions):

[0000950170-23-027948:notes:220]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Cost of product revenues |  | $ | 5 |  |  | $ | 4 |  |  | $ | 4 |  |
| Cost of hardware support and other services revenues |  |  | 19 |  |  |  | 13 |  |  |  | 10 |  |
| Sales and marketing |  |  | 135 |  |  |  | 115 |  |  |  | 92 |  |
| Research and development |  |  | 111 |  |  |  | 75 |  |  |  | 64 |  |
| General and administrative |  |  | 42 |  |  |  | 38 |  |  |  | 27 |  |
| Total stock-based compensation expense |  | $ | 312 |  |  | $ | 245 |  |  | $ | 197 |  |

[0000950170-23-027948:notes:221]
As of April 28, 2023, total unrecognized compensation expense related to our equity awards was $606 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.2 years.

[0000950170-23-027948:notes:222]
Valuation Assumptions

[0000950170-23-027948:notes:223]
The valuation of RSUs and ESPP purchase rights and the underlying weighted-average assumptions are summarized as follows:

[0000950170-23-027948:notes:224]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| RSUs: |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 3.1 | % |  |  | 0.5 | % |  |  | 0.2 | % |
| Expected dividend yield |  |  | 2.9 | % |  |  | 2.4 | % |  |  | 4.4 | % |
| Weighted-average fair value per share granted |  | $ | 59.87 |  |  | $ | 80.40 |  |  | $ | 42.46 |  |
| ESPP: |  |  |  |  |  |  |  |  |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 3.9 | % |  |  | 0.2 | % |  |  | 0.2 | % |
| Expected volatility |  |  | 36 | % |  |  | 37 | % |  |  | 47 | % |
| Expected dividend yield |  |  | 2.9 | % |  |  | 2.4 | % |  |  | 4.4 | % |
| Weighted-average fair value per right granted |  | $ | 21.28 |  |  | $ | 24.75 |  |  | $ | 10.08 |  |

[0000950170-23-027948:notes:225]
Stock Repurchase Program

[0000950170-23-027948:notes:226]
As of April 28, 2023, our Board of Directors has authorized the repurchase of up to $15.1 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management.

[0000950170-23-027948:notes:227]
The following table summarizes activity related to this program (in millions, except per share amounts):

[0000950170-23-027948:notes:228]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Number of shares repurchased |  |  | 13 |  |  |  | 7 |  |  |  | 2 |  |
| Average price per share |  | $ | 66.42 |  |  | $ | 84.49 |  |  | $ | 67.61 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 45 |  |  | $ | 20 |  |  | $ | 3 |  |
| Stock repurchases allocated to retained earnings |  | $ | 805 |  |  | $ | 580 |  |  | $ | 122 |  |
| Remaining authorization at end of period |  | $ | 402 |  |  | $ | 1,252 |  |  | $ | 352 |  |

[0000950170-23-027948:notes:229]
Since the May 13, 2003 inception of our stock repurchase program through April 28, 2023, we repurchased a total of 360 million shares of our common stock at an average price of $40.89 per share, for an aggregate purchase price of $14.7 billion. On May 26, 2023 our Board of Directors authorized the repurchase of an additional $1.0 billion of our common stock.

[0000950170-23-027948:notes:230]
Preferred Stock

[0000950170-23-027948:notes:231]
Our Board of Directors has the authority to issue up to 5 million shares of preferred stock and to determine the price, rights, preferences, privileges, and restrictions, including voting rights, of those shares without any further vote or action by the stockholders. No shares of preferred stock were issued or outstanding in any period presented.

[0000950170-23-027948:notes:232]
Dividends

[0000950170-23-027948:notes:233]
The following is a summary of our fiscal 2023, 2022 and 2021 activities related to dividends on our common stock (in millions, except per share amounts).

[0000950170-23-027948:notes:234]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Dividends per share declared |  | $ | 2.00 |  |  | $ | 2.00 |  |  | $ | 1.92 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 106 |  |  | $ | — |  |  | $ | 30 |  |
| Dividend payments allocated to retained earnings |  | $ | 326 |  |  | $ | 446 |  |  | $ | 397 |  |

[0000950170-23-027948:notes:235]
On May 26, 2023, we declared a cash dividend of $0.50 per share of common stock, payable on July 26, 2023 to shareholders of record as of the close of business on July 7, 2023. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by the Company to be legally authorized under the laws of the state in which we are incorporated.

[0000950170-23-027948:notes:236]
Accumulated Other Comprehensive Income (Loss)

[0000950170-23-027948:notes:237]
Changes in accumulated other comprehensive income (loss) (AOCI) by component, net of tax, are summarized below (in millions):

[0000950170-23-027948:notes:238]
|  |  | ForeignCurrencyTranslationAdjustments |  |  | DefinedBenefitObligationAdjustments |  |  | UnrealizedGains(Losses) on Available-for-SaleSecurities |  |  | UnrealizedGains(Losses) onCash Flow Hedges |  |  | Total |  |
| Balance as of April 24, 2020 |  | $ | (42 | ) |  | $ | (1 | ) |  | $ | 1 |  |  | $ | — |  |  | $ | (42 | ) |
| OCI before reclassifications, net of tax |  |  | 15 |  |  |  | (3 | ) |  |  | — |  |  |  | (11 | ) |  |  | 1 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 11 |  |  |  | 11 |  |
| Total OCI |  |  | 15 |  |  |  | (3 | ) |  |  | — |  |  |  | — |  |  |  | 12 |  |
| Balance as of April 30, 2021 |  |  | (27 | ) |  |  | (4 | ) |  |  | 1 |  |  |  | — |  |  |  | (30 | ) |
| OCI before reclassifications, net of tax |  |  | (17 | ) |  |  | 3 |  |  |  | (1 | ) |  |  | 8 |  |  |  | (7 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (7 | ) |  |  | (7 | ) |
| Total OCI |  |  | (17 | ) |  |  | 3 |  |  |  | (1 | ) |  |  | 1 |  |  |  | (14 | ) |
| Balance as of April 29, 2022 |  |  | (44 | ) |  |  | (1 | ) |  |  | — |  |  |  | 1 |  |  |  | (44 | ) |
| OCI before reclassifications, net of tax |  |  | (4 | ) |  |  | (2 | ) |  |  | — |  |  |  | (6 | ) |  |  | (12 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | 5 |  |
| Total OCI |  |  | (4 | ) |  |  | (2 | ) |  |  | — |  |  |  | (1 | ) |  |  | (7 | ) |
| Balance as of April 28, 2023 |  | $ | (48 | ) |  | $ | (3 | ) |  | $ | — |  |  | $ | — |  |  | $ | (51 | ) |

[0000950170-23-027948:notes:239]
The amounts reclassified out of AOCI are as follows (in millions):

[0000950170-23-027948:notes:240]
|  |  | Year Ended |  |  | Statements of Income |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | Classification |
| Realized losses (gains) on cash flow hedges |  | $ | 5 |  |  | $ | (7 | ) |  | $ | 11 |  |  | Net revenues |
| Total reclassifications |  | $ | 5 |  |  | $ | (7 | ) |  | $ | 11 |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-23-027948:notes:241]
11. Derivatives and Hedging Activities

[0000950170-23-027948:notes:242]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of April 28, 2023 or April 29, 2022. All contracts have a maturity of less than 12 months.

[0000950170-23-027948:notes:243]
The notional amount of our outstanding U.S. dollar equivalent foreign currency exchange forward contracts consisted of the following (in millions):

[0000950170-23-027948:notes:244]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 95 |  |  | $ | 78 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 965 |  |  | $ | 841 |  |
| Forward contracts purchased |  | $ | 96 |  |  | $ | 129 |  |

[0000950170-23-027948:notes:245]
The effect of cash flow hedges recognized in net revenues is presented in the consolidated statements of comprehensive income and Note 10 – Stockholders’ Equity.

[0000950170-23-027948:notes:246]
The effect of derivative instruments not designated as hedging instruments recognized in other expense, net on our consolidated statements of income was as follows (in millions):

[0000950170-23-027948:notes:247]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
|  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 4 |  |  | $ | (91 | ) |  | $ | 20 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-23-027948:notes:248]
12. Restructuring Charges

[0000950170-23-027948:notes:249]
During the third quarter of fiscal 2023, management approved a restructuring plan to redirect resources to highest return activities and reduce costs. As a result, we recorded restructuring charges in the third quarter comprised of employee severance-related expenses. This plan reduced our global workforce by approximately 8% and activities under this plan are substantially complete.

[0000950170-23-027948:notes:250]
In the first quarter of fiscal 2023, we executed a restructuring plan to redirect resources to highest return activities, which included a reduction in our global workforce of approximately 1% and resulted in restructuring charges comprised primarily of employee severance-related costs. Activities under this plan are substantially complete.

[0000950170-23-027948:notes:251]
In fiscal 2023, we also continued activities related to the establishment of an international headquarters in Cork, Ireland, which was initiated in the fourth quarter of fiscal 2022, and incurred restructuring charges consisting primarily of severance-related costs and legal and tax-related professional fees. Substantially all activities under this plan are complete.

[0000950170-23-027948:notes:252]
In the first quarter of fiscal 2022, we executed a restructuring plan to reduce the amount of office space we occupied as we allow more employees to work remotely. In connection with the plan, we also reduced our global workforce by approximately 1%. Charges related to the plan consisted primarily of office relocation costs, lease termination fees, and employee severance-related costs. Substantially all activities under the plan had been completed by the end of fiscal 2022.

[0000950170-23-027948:notes:253]
Management has previously approved several restructuring actions in fiscal 2021, under which we reduced our global workforce by approximately 6%. Charges related to these restructuring plans consisted primarily of employee severance-related costs. Substantially all activities under these plans were completed as of the end of fiscal 2021.

[0000950170-23-027948:notes:254]
Activities related to our restructuring plans are summarized as follows (in millions):

[0000950170-23-027948:notes:255]
|  |  | Total |  |
| Balance as of April 24, 2020 |  | $ | 1 |  |
| Net charges |  |  | 42 |  |
| Cash payments |  |  | (42 | ) |
| Balance as of April 30, 2021 |  |  | 1 |  |
| Net charges |  |  | 33 |  |
| Cash payments |  |  | (31 | ) |
| Balance as of April 29, 2022 |  |  | 3 |  |
| Net charges |  |  | 120 |  |
| Cash payments |  |  | (87 | ) |
| Balance as of April 28, 2023 |  | $ | 36 |  |

[0000950170-23-027948:notes:256]
Liabilities for our restructuring activities are included in accrued expenses in our consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-027948:notes:257]
13. Income Taxes

[0000950170-23-027948:notes:258]
Income before income taxes is as follows (in millions):

[0000950170-23-027948:notes:259]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Domestic |  | $ | 420 |  |  | $ | 546 |  |  | $ | 433 |  |
| Foreign |  |  | 646 |  |  |  | 549 |  |  |  | 529 |  |
| Total |  | $ | 1,066 |  |  | $ | 1,095 |  |  | $ | 962 |  |

[0000950170-23-027948:notes:260]
The (benefit) provision for income taxes consists of the following (in millions):

[0000950170-23-027948:notes:261]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Current: |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 209 |  |  | $ | 187 |  |  | $ | 82 |  |
| State |  |  | 39 |  |  |  | 55 |  |  |  | 22 |  |
| Foreign |  |  | 150 |  |  |  | 60 |  |  |  | 134 |  |
| Total current |  |  | 398 |  |  |  | 302 |  |  |  | 238 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (44 | ) |  |  | (125 | ) |  |  | 6 |  |
| State |  |  | (3 | ) |  |  | (27 | ) |  |  | 2 |  |
| Foreign |  |  | (559 | ) |  |  | 8 |  |  |  | (14 | ) |
| Total deferred |  |  | (606 | ) |  |  | (144 | ) |  |  | (6 | ) |
| (Benefit) provision for income taxes |  | $ | (208 | ) |  | $ | 158 |  |  | $ | 232 |  |

[0000950170-23-027948:notes:262]
During the second quarter of fiscal 2023, we completed an intra-entity asset transfer of certain IP to our international headquarters (the “IP Transfer”). The transaction resulted in a step-up of tax-deductible basis in the transferred assets, and accordingly, created a temporary difference where the tax basis exceeded the financial statement basis of such intangible assets, which resulted in the recognition of a discrete tax benefit and related deferred tax asset of $524 million during the second quarter of fiscal 2023.  Management applied significant judgment when determining the fair value of the IP, which serves as the tax basis of the deferred tax asset. With the assistance of third-party valuation specialists, the fair value of the IP was determined principally based on the present value of projected cash flows related to the IP which reflects management’s assumptions regarding projected revenues, earnings before interest and taxes, and a discount rate. The tax-deductible amortization related to the transferred IP rights will be recognized in future periods and any amortization that is unused in a particular year can be carried forward indefinitely. The deferred tax asset and the tax benefit were measured based on the enacted tax rates expected to apply in the years the asset is expected to be realized. We expect to realize the deferred tax asset resulting from the IP Transfer and will assess the realizability of the deferred tax asset quarterly. Any Organisation for Economic Co-operation and Development’s (“OECD”) actions adopted internationally could impact our financial results in future periods.

[0000950170-23-027948:notes:263]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We did not believe that our Danish subsidiary was liable for such withholding tax and filed an appeal with the Danish Tax Tribunal. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012. In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). In March 2018, the Advocate General issued an opinion which was largely in favor of NetApp. The CJEU was not bound by the opinion of the Advocate General and issued its preliminary ruling in February 2019. On May 3, 2021, the DHC reached a decision resulting in NetApp prevailing on the predominate distribution made in 2005. The smaller distribution made in 2006 was ruled in favor of the Danish Tax Authorities. On May 28, 2021, the Danish Tax Authorities appealed the DHC decision to the Danish Supreme Court. On January 9, 2023, the Danish Supreme Court reversed the lower court's decision and ruled the 2005 dividend was subject to withholding tax while the smaller 2006 distribution would not be subject to withholding tax. The Danish Supreme Court ruling on the distributions declared in 2005 and 2006 is non-appealable. During the third quarter of fiscal 2023, we recorded $69 million of discrete tax expense, which includes $23 million of withholding tax and $46 million of interest, associated with the Danish Supreme Court ruling.

[0000950170-23-027948:notes:264]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0000950170-23-027948:notes:265]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Tax computed at federal statutory rate |  | $ | 224 |  |  | $ | 230 |  |  | $ | 202 |  |
| State income taxes, net of federal benefit |  |  | 24 |  |  |  | 15 |  |  |  | 23 |  |
| Foreign earnings in lower tax jurisdictions |  |  | (43 | ) |  |  | (46 | ) |  |  | (26 | ) |
| Stock-based compensation |  |  | 25 |  |  |  | (8 | ) |  |  | 6 |  |
| Research and development credits |  |  | (24 | ) |  |  | (18 | ) |  |  | (13 | ) |
| Benefit for foreign derived intangible income |  |  | — |  |  |  | (49 | ) |  |  | (2 | ) |
| Global minimum tax on intangible income |  |  | 61 |  |  |  | 1 |  |  |  | 19 |  |
| Transition tax and related reserves |  |  | — |  |  |  | 1 |  |  |  | 1 |  |
| Tax (benefits) charges from integration of acquired companies |  |  | (27 | ) |  |  | 23 |  |  |  | 35 |  |
| Tax benefit due to IP Transfer |  |  | (524 | ) |  |  | — |  |  |  | — |  |
| Resolution of income tax matters (1) |  |  | 71 |  |  |  | (3 | ) |  |  | (6 | ) |
| Other |  |  | 5 |  |  |  | 12 |  |  |  | (7 | ) |
| (Benefit) provision for income taxes |  | $ | (208 | ) |  | $ | 158 |  |  | $ | 232 |  |

[0000950170-23-027948:notes:266]
(1)
During fiscal 2023, we recognized tax expense related to a Danish Supreme Court decision related to withholding tax on a 2005 distribution as well as tax expense related to the currently in progress IRS audit of our fiscal 2018 and 2019 U.S. tax returns. During fiscal 2022, we recognized a tax benefit related to the lapse of statute of limitations for certain issues in our fiscal 2012 and 2013 state income tax returns. During fiscal 2021, we recognized a tax benefit related to the lapse of statutes of limitations for certain issues on our fiscal 2016 and 2017 federal income tax returns.

[0000950170-23-027948:notes:267]
The components of our deferred tax assets and liabilities are as follows (in millions):

[0000950170-23-027948:notes:268]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Deferred tax assets: |  |  |  |  |  |  |
| Reserves and accruals |  | $ | 189 |  |  | $ | 267 |  |
| Net operating loss and credit carryforwards |  |  | 124 |  |  |  | 121 |  |
| Stock-based compensation |  |  | 23 |  |  |  | 23 |  |
| Deferred revenue and financed unearned services revenue |  |  | 264 |  |  |  | 235 |  |
| Acquired intangibles |  |  | 523 |  |  |  | — |  |
| Capitalized research and development (1) |  |  | 111 |  |  |  | — |  |
| Other |  |  | 10 |  |  |  | 6 |  |
| Gross deferred tax assets |  |  | 1,244 |  |  |  | 652 |  |
| Valuation allowance |  |  | (113 | ) |  |  | (111 | ) |
| Deferred tax assets, net of valuation allowance |  |  | 1,131 |  |  |  | 541 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Prepaids and accruals |  |  | 94 |  |  |  | 108 |  |
| Acquired intangibles |  |  | 66 |  |  |  | 48 |  |
| Property and equipment |  |  | 50 |  |  |  | 39 |  |
| Other |  |  | 2 |  |  |  | 7 |  |
| Total deferred tax liabilities |  |  | 212 |  |  |  | 202 |  |
| Deferred tax assets, net of valuation allowance and deferred tax liabilities |  | $ | 919 |  |  | $ | 339 |  |

[0000950170-23-027948:notes:269]
(1)
As required under the Tax Cuts and Jobs Act of 2017, research and development expenditures are capitalized and amortized beginning in our fiscal 2023.

[0000950170-23-027948:notes:270]
The valuation allowance increased by $2 million in fiscal 2023. The increase is mainly attributable to corresponding changes in deferred tax assets, primarily certain state tax credit carryforwards.

[0000950170-23-027948:notes:271]
As of April 28, 2023, we have federal net operating loss carryforwards of approximately $17 million. In addition, we have gross state net operating loss and tax credit carryforwards of $13 million and $135 million, respectively. The majority of the state credit carryforwards are California research credits which are offset by a valuation allowance as we believe it is more likely than not that these credits will not be utilized. We also have $8 million of foreign net operating losses and $30 million of foreign tax credit carryforwards of which the majority were generated by our Dutch subsidiary and are fully offset by a valuation allowance. Certain acquired net operating loss carryforwards are subject to an annual limitation under Internal Revenue Code Section 382, but are expected to be realized with the exception of those which have a valuation allowance. The state and foreign net operating loss

[0000950170-23-027948:notes:272]
carryforwards and credits will expire in various years from fiscal 2024 through 2042. The federal net operating loss carryforwards, the California research credit, and the Dutch foreign tax credit carryforwards do not expire.

[0000950170-23-027948:notes:273]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0000950170-23-027948:notes:274]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Balance at beginning of period |  | $ | 220 |  |  | $ | 221 |  |  | $ | 211 |  |
| Additions based on tax positions related to the current year |  |  | 9 |  |  |  | 11 |  |  |  | 7 |  |
| Additions for tax positions of prior years |  |  | 1 |  |  |  | — |  |  |  | 11 |  |
| Decreases for tax positions of prior years |  |  | (5 | ) |  |  | (2 | ) |  |  | — |  |
| Settlements |  |  | (3 | ) |  |  | (10 | ) |  |  | (8 | ) |
| Balance at end of period |  | $ | 222 |  |  | $ | 220 |  |  | $ | 221 |  |

[0000950170-23-027948:notes:275]
As of April 28, 2023, we had $222 million of gross unrecognized tax benefits, of which $144 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $144 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0000950170-23-027948:notes:276]
We recognized expense for increases to accrued interest and penalties related to unrecognized tax benefits in the income tax provision of approximately $7 million, $4 million and $1 million, respectively, in fiscal 2023, fiscal 2022 and fiscal  2021. Accrued interest and penalties of $22 million and $15 million were recorded in the consolidated balance sheets as of April 28, 2023 and April 29, 2022, respectively.

[0000950170-23-027948:notes:277]
The tax years that remain subject to examination for our major tax jurisdictions are shown below:

[0000950170-23-027948:notes:278]
Fiscal Years Subject to Examination for Major Tax Jurisdictions at April 28, 2023

[0000950170-23-027948:notes:279]
| 2016 — 2023 |  | United States — federal income tax |
| 2018 — 2023 |  | United States — state and local income tax |
| 2020 — 2023 |  | Australia |
| 2018 — 2023 |  | Germany |
| 2007 — 2023 |  | India |
| 2017 — 2023 |  | The Netherlands |
| 2016 — 2023 |  | Canada |

[0000950170-23-027948:notes:280]
We are currently undergoing various income tax audits in the U.S. and several foreign tax jurisdictions. Transfer pricing calculations are key topics under these audits and are often subject to dispute and appeals. We are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal 2001, in that we have carryforward attributes from these years that could be subject to adjustment in the tax years of utilization.

[0000950170-23-027948:notes:281]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. As a result of uncertainties regarding tax audits and their possible outcomes, an estimate of the range of possible impacts to unrecognized tax benefits in the next twelve months cannot be made at this time.

[0000950170-23-027948:notes:282]
As of April 28, 2023, we continue to record a deferred tax liability related to state taxes on unremitted earnings of certain foreign entities. We estimate the unrecognized deferred tax liability related to the earnings we expect to be indefinitely reinvested to be immaterial. We will continue to monitor our plans to indefinitely reinvest undistributed earnings of foreign subsidiaries and will assess the related unrecognized deferred tax liability considering our ongoing projected global cash requirements, tax consequences associated with repatriation and any U.S. or foreign government programs designed to influence remittances.


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-027948:notes:283]
14. Net Income per Share

[0000950170-23-027948:notes:284]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0000950170-23-027948:notes:285]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,274 |  |  | $ | 937 |  |  | $ | 730 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 217 |  |  |  | 223 |  |  |  | 222 |  |
| Dilutive impact of employee equity award plans |  |  | 3 |  |  |  | 6 |  |  |  | 4 |  |
| Shares used in diluted computation |  |  | 220 |  |  |  | 229 |  |  |  | 226 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 5.87 |  |  | $ | 4.20 |  |  | $ | 3.29 |  |
| Diluted |  | $ | 5.79 |  |  | $ | 4.09 |  |  | $ | 3.23 |  |

[0000950170-23-027948:notes:286]
Six and four million shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for fiscal 2023 and fiscal 2021, respectively, as their inclusion would have been anti-dilutive. No potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculation for fiscal 2022.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-027948:notes:287]
15. Segment, Geographic, and Significant Customer Information

[0000950170-23-027948:notes:288]
We have two operating segments and two reportable segments for financial reporting purposes: Hybrid Cloud and Public Cloud. Our Chief Operating Decision Maker (CODM), who is our Chief Executive Officer, reviews certain financial information for components of our business, organized based on category of product/solution, to evaluate performance and allocate resources. The CODM measures performance of each segment based on segment revenue and segment gross profit. We do not allocate to our segments certain cost of revenues which we manage at the corporate level. These unallocated costs include stock-based compensation and amortization of intangible assets. We do not allocate assets to our segments.

[0000950170-23-027948:notes:289]
Hybrid Cloud offers a portfolio of storage management and infrastructure solutions that help customers recast their traditional data centers with the power of cloud. This portfolio is designed to operate with public clouds to unlock the potential of hybrid, multi-cloud operations. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.

[0000950170-23-027948:notes:290]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage and data services and cloud operations services. Public Cloud includes certain reseller arrangements in which the timing of our consideration follows the end user consumption of the reseller services.

[0000950170-23-027948:notes:291]
Segment Revenues and Gross Profit

[0000950170-23-027948:notes:292]
Financial information by segment is as follows (in millions, except percentages):

[0000950170-23-027948:notes:293]
|  | Year Ended April 28, 2023 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 3,049 |  |  | $ | — |  |  | $ | 3,049 |  |
| Support revenues |  | 2,419 |  |  |  | — |  |  |  | 2,419 |  |
| Professional and other services revenues |  | 319 |  |  |  | — |  |  |  | 319 |  |
| Public cloud revenues |  | — |  |  |  | 575 |  |  |  | 575 |  |
| Net revenues |  | 5,787 |  |  |  | 575 |  |  |  | 6,362 |  |
| Cost of product revenues |  | 1,511 |  |  |  | — |  |  |  | 1,511 |  |
| Cost of support revenues |  | 181 |  |  |  | — |  |  |  | 181 |  |
| Cost of professional and other services revenues |  | 211 |  |  |  | — |  |  |  | 211 |  |
| Cost of public cloud revenues |  | — |  |  |  | 184 |  |  |  | 184 |  |
| Segment cost of revenues |  | 1,903 |  |  |  | 184 |  |  |  | 2,087 |  |
| Segment gross profit | $ | 3,884 |  |  | $ | 391 |  |  | $ | 4,275 |  |
| Segment gross margin |  | 67.1 | % |  |  | 68.0 | % |  |  | 67.2 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 66 |  |
| Total gross profit |  |  |  |  |  |  | $ | 4,209 |  |
| Total gross margin |  |  |  |  |  |  |  | 66.2 | % |
| 1 Unallocated cost of revenues are composed of $24 million of stock-based compensation expense and $42 million of amortization of intangible assets. |  |

[0000950170-23-027948:notes:294]
|  | Year Ended April 29, 2022 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 3,284 |  |  | $ | — |  |  | $ | 3,284 |  |
| Support revenues |  | 2,344 |  |  |  | — |  |  |  | 2,344 |  |
| Professional and other services revenues |  | 294 |  |  |  | — |  |  |  | 294 |  |
| Public cloud revenues |  | — |  |  |  | 396 |  |  |  | 396 |  |
| Net revenues |  | 5,922 |  |  |  | 396 |  |  |  | 6,318 |  |
| Cost of product revenues |  | 1,541 |  |  |  | — |  |  |  | 1,541 |  |
| Cost of support revenues |  | 184 |  |  |  | — |  |  |  | 184 |  |
| Cost of professional and other services revenues |  | 205 |  |  |  | — |  |  |  | 205 |  |
| Cost of public cloud revenues |  | — |  |  |  | 118 |  |  |  | 118 |  |
| Segment cost of revenues |  | 1,930 |  |  |  | 118 |  |  |  | 2,048 |  |
| Segment gross profit | $ | 3,992 |  |  | $ | 278 |  |  | $ | 4,270 |  |
| Segment gross margin |  | 67.4 | % |  |  | 70.2 | % |  |  | 67.6 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 50 |  |
| Total gross profit |  |  |  |  |  |  | $ | 4,220 |  |
| Total gross margin |  |  |  |  |  |  |  | 66.8 | % |
| 1 Unallocated cost of revenues are composed of $17 million of stock-based compensation expense and $33 million of amortization of intangible assets. |  |

[0000950170-23-027948:notes:295]
|  | Year Ended April 30, 2021 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 2,991 |  |  | $ | — |  |  | $ | 2,991 |  |
| Support revenues |  | 2,277 |  |  |  | — |  |  |  | 2,277 |  |
| Professional and other services revenues |  | 277 |  |  |  | — |  |  |  | 277 |  |
| Public cloud revenues |  | — |  |  |  | 199 |  |  |  | 199 |  |
| Net revenues |  | 5,545 |  |  |  | 199 |  |  |  | 5,744 |  |
| Cost of product revenues |  | 1,402 |  |  |  | — |  |  |  | 1,402 |  |
| Cost of support revenues |  | 201 |  |  |  | — |  |  |  | 201 |  |
| Cost of professional and other services revenues |  | 206 |  |  |  | — |  |  |  | 206 |  |
| Cost of public cloud revenues |  | — |  |  |  | 65 |  |  |  | 65 |  |
| Segment cost of revenues |  | 1,809 |  |  |  | 65 |  |  |  | 1,874 |  |
| Segment gross profit | $ | 3,736 |  |  | $ | 134 |  |  | $ | 3,870 |  |
| Segment gross margin |  | 67.4 | % |  |  | 67.3 | % |  |  | 67.4 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 55 |  |
| Total gross profit |  |  |  |  |  |  | $ | 3,815 |  |
| Total gross margin |  |  |  |  |  |  |  | 66.4 | % |
| 1 Unallocated cost of revenues are composed of $14 million of stock-based compensation expense and $41 million of amortization of intangible assets. |  |

[0000950170-23-027948:notes:296]
Geographical Revenues and Certain Assets

[0000950170-23-027948:notes:297]
Revenues summarized by geographic region are as follows (in millions):

[0000950170-23-027948:notes:298]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| United States, Canada and Latin America (Americas) |  | $ | 3,390 |  |  | $ | 3,460 |  |  | $ | 3,097 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 2,063 |  |  |  | 1,979 |  |  |  | 1,775 |  |
| Asia Pacific (APAC) |  |  | 909 |  |  |  | 879 |  |  |  | 872 |  |
| Net revenues |  | $ | 6,362 |  |  | $ | 6,318 |  |  | $ | 5,744 |  |

[0000950170-23-027948:notes:299]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $2,973 million, $3,041 million and $2,784 million during fiscal 2023, 2022 and 2021, respectively.

[0000950170-23-027948:notes:300]
The majority of our assets, excluding cash, cash equivalents, short-term investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents and short-term investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0000950170-23-027948:notes:301]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| U.S. |  | $ | 887 |  |  | $ | 1,820 |  |
| International |  |  | 2,183 |  |  |  | 2,314 |  |
| Total |  | $ | 3,070 |  |  | $ | 4,134 |  |

[0000950170-23-027948:notes:302]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment information for geographic areas based on the physical location of the assets (in millions):

[0000950170-23-027948:notes:303]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| U.S. |  | $ | 413 |  |  | $ | 392 |  |
| International |  |  | 237 |  |  |  | 210 |  |
| Total |  | $ | 650 |  |  | $ | 602 |  |

[0000950170-23-027948:notes:304]
Significant Customers

[0000950170-23-027948:notes:305]
The following customers, each of which is a distributor, accounted for 10% or more of our net revenues:

[0000950170-23-027948:notes:306]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 24 | % |  |  | 24 | % |
| Tech Data Corporation |  |  | 21 | % |  |  | 21 | % |  |  | 20 | % |

[0000950170-23-027948:notes:307]
The following customers accounted for 10% or more of accounts receivable:

[0000950170-23-027948:notes:308]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Arrow Electronics, Inc. |  |  | 15 | % |  |  | 10 | % |
| Tech Data Corporation |  |  | 19 | % |  |  | 19 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-23-027948:notes:309]
16. Employee Benefits and Deferred Compensation

[0000950170-23-027948:notes:310]
Employee 401(k) Plan

[0000950170-23-027948:notes:311]
Our 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit. We match 100% of the first 2% of eligible earnings an employee contributes to the 401(k) Plan, and then match 50% of the next 4% of eligible earnings an employee contributes. An employee receives the full 4% match when he/she contributes at least 6% of his/her eligible earnings, up to a maximum calendar year matching contribution of $6,000. Our employer matching contributions to the 401(k) Plan were as follows (in millions):

[0000950170-23-027948:notes:312]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| 401(k) matching contributions |  | $ | 33 |  |  | $ | 31 |  |  | $ | 29 |  |

[0000950170-23-027948:notes:313]
Deferred Compensation Plan

[0000950170-23-027948:notes:314]
We have a non-qualified deferred compensation plan that allows a group of employees within the U.S. to contribute base salary and commissions or incentive compensation on a tax deferred basis in excess of the IRS limits imposed on 401(k) plans. The marketable

[0000950170-23-027948:notes:315]
securities related to these investments are held in a Rabbi Trust. The related deferred compensation plan assets and liabilities under the non-qualified deferred compensation plan were as follows (in millions):

[0000950170-23-027948:notes:316]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Deferred compensation plan assets |  | $ | 36 |  |  | $ | 36 |  |
| Deferred compensation liabilities reported as: |  |  |  |  |  |  |
| Accrued expenses |  | $ | 7 |  |  | $ | 6 |  |
| Other long-term liabilities |  | $ | 29 |  |  | $ | 30 |  |

[0000950170-23-027948:notes:317]
Defined Benefit Plans

[0000950170-23-027948:notes:318]
We maintain various defined benefit plans to provide termination and postretirement benefits to certain eligible employees outside of the U.S. We also provide disability benefits to certain eligible employees in the U.S. Eligibility is determined based on the terms of our plans and local statutory requirements.

[0000950170-23-027948:notes:319]
The funded status of our defined benefit plans, which is recognized in other long-term liabilities in our consolidated balance sheets, was as follows (in millions):

[0000950170-23-027948:notes:320]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Fair value of plan assets |  | $ | 44 |  |  | $ | 39 |  |
| Benefit obligations |  |  | (75 | ) |  |  | (69 | ) |
| Unfunded obligations |  | $ | (31 | ) |  | $ | (30 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-027948:notes:321]
17. Commitments and Contingencies

[0000950170-23-027948:notes:322]
Purchase Orders and Other Commitments

[0000950170-23-027948:notes:323]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of April 28, 2023, we had $0.4 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 28, 2023 and April 29, 2022, such liability amounted to $15 million and $18 million, respectively, and is included in accrued expenses in our consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0000950170-23-027948:notes:324]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of April 28, 2023, we had $0.3 billion in other purchase obligations.

[0000950170-23-027948:notes:325]
Of the total $0.7 billion in purchase commitments, $0.5 billion is due in fiscal 2024, with the remainder due thereafter.

[0000950170-23-027948:notes:326]
Financing Guarantees

[0000950170-23-027948:notes:327]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $38 million, $59 million and $102 million of receivables during fiscal 2023, 2022 and 2021, respectively.

[0000950170-23-027948:notes:328]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0000950170-23-027948:notes:329]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of April 28, 2023 and April 29, 2022, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-23-027948:notes:330]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of April 28, 2023, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0000950170-23-027948:notes:331]
Legal Contingencies

[0000950170-23-027948:notes:332]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0000950170-23-027948:notes:333]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleged that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019, and further alleged unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. On July 30, 2021, the parties entered into a memorandum of understanding providing for the settlement of the class action, pursuant to which NetApp agreed to pay approximately $2.0 million in connection with the settlement, which was accrued during the three months ended July 30, 2021. On September 1, 2022, the court held a final approval hearing, approved the stipulation of settlement (which contained no admission of liability, wrongdoing or responsibility by any of the parties and provided for the mutual release by all parties), and dismissed the case with prejudice.

[0000950170-23-027948:notes:334]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0000950170-23-027948:notes:335]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of April 28, 2023 related to such matters.
