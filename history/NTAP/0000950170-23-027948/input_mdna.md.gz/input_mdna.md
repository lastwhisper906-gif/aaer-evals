# NTAP MD&A — 0000950170-23-027948


## mdna

[0000950170-23-027948:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000950170-23-027948:mdna:2]
The following discussion of our financial condition and results of operations should be read together with the financial statements and the accompanying notes set forth under Item 8. – Financial Statements and Supplementary Data. The following discussion also contains trend information and other forward-looking statements that involve a number of risks and uncertainties. The Risk Factors set forth in Item 1A. – Risk Factors are hereby incorporated into the discussion by reference.

[0000950170-23-027948:mdna:3]
Executive Overview

[0000950170-23-027948:mdna:4]
Our Company

[0000950170-23-027948:mdna:5]
NetApp is a global cloud-led, data-centric software company that empowers customers with hybrid multicloud solutions built for a better future. Building on more than three decades of innovation, we give customers the freedom to manage applications and data across hybrid multicloud environments. NetApp delivers value in simplicity, security, savings, and sustainability with automation and optimization for IT teams to thrive on premises, in the clouds, and everywhere in between. We are a proven leader in all-flash storage with the only storage OS natively available on the biggest clouds, and we believe we provide industry-leading protection and security, and innovative CloudOps services.

[0000950170-23-027948:mdna:6]
In a world of hybrid multicloud complexity, we envision a better IT experience—an evolved cloud state where on-premises and cloud environments are united as one. We build solutions that drive faster innovation wherever our customers’ data and applications live, with unified management and AI-driven optimization, giving organizations the freedom to do what’s best for today’s business and the flexibility to adapt for tomorrow. Our infrastructure, data, and application services are hybrid multicloud by design to deliver a unified experience that is integrated with the rich services of our cloud partners.

[0000950170-23-027948:mdna:7]
Our operations are organized into two segments: Hybrid Cloud and Public Cloud.

[0000950170-23-027948:mdna:8]
Hybrid Cloud offers a portfolio of storage management and infrastructure solutions that help customers recast their traditional data centers into modern data centers with the power of the cloud. Our hybrid cloud portfolio is designed to operate with public clouds to unlock the potential of hybrid, multi-cloud operations. We offer a broad portfolio of cloud-connected all-flash, hybrid-flash, and object storage systems, powered by intelligent data management software. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.

[0000950170-23-027948:mdna:9]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage and data services and cloud operations services. Our enterprise-class solutions and services enable customers to control and manage storage in the cloud, consume high-performance storage services for primary workloads, and optimize cloud environments for cost and efficiency. These solutions and services are generally available on the leading public clouds, including Amazon AWS, Microsoft Azure, and Google Cloud Platform.

[0000950170-23-027948:mdna:10]
Global Business Environment

[0000950170-23-027948:mdna:11]
Macroeconomic Conditions

[0000950170-23-027948:mdna:12]
Continuing global economic uncertainty, political conditions and fiscal challenges in the U.S. and abroad have resulted and may continue to result in adverse macroeconomic conditions, including inflation, rising interest rates, foreign exchange volatility, slower growth and possibly a recession. In particular, in fiscal 2023, we experienced a weakened demand environment, characterized by cloud optimizations and increased budget scrutiny, which resulted in smaller deal sizes, longer selling cycles, and delays of some deals.

[0000950170-23-027948:mdna:13]
If these macroeconomic uncertainties persist or worsen in fiscal 2024, we may observe a further reduction in customer demand for our offerings, which could impact our operating results.

[0000950170-23-027948:mdna:14]
33

[0000950170-23-027948:mdna:15]
Supply Chain

[0000950170-23-027948:mdna:16]
Supply chain constraints, particularly in the first half of fiscal 2023, led to higher product component and freight costs in fiscal 2023 compared to fiscal 2022. Supply chain constraints also delayed our ability to fulfill certain customer orders during the first half of fiscal 2023.

[0000950170-23-027948:mdna:17]
Financial Results and Key Performance Metrics Overview

[0000950170-23-027948:mdna:18]
The following table provides an overview of key financial metrics for each of the last three fiscal years (in millions, except per share amounts and percentages):

[0000950170-23-027948:mdna:19]
|  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Net revenues |  | $ | 6,362 |  |  | $ | 6,318 |  |  | $ | 5,744 |  |
| Gross profit |  | $ | 4,209 |  |  | $ | 4,220 |  |  | $ | 3,815 |  |
| Gross profit margin percentage |  |  | 66 | % |  |  | 67 | % |  |  | 66 | % |
| Income from operations |  | $ | 1,018 |  |  | $ | 1,157 |  |  | $ | 1,031 |  |
| Income from operations as a percentage of net revenues |  |  | 16 | % |  |  | 18 | % |  |  | 18 | % |
| (Benefit) provision for income taxes |  | $ | (208 | ) |  | $ | 158 |  |  | $ | 232 |  |
| Net income |  | $ | 1,274 |  |  | $ | 937 |  |  | $ | 730 |  |
| Diluted net income per share |  | $ | 5.79 |  |  | $ | 4.09 |  |  | $ | 3.23 |  |
| Net cash provided by operating activities |  | $ | 1,107 |  |  | $ | 1,211 |  |  | $ | 1,333 |  |

[0000950170-23-027948:mdna:20]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 4,313 |  |  | $ | 4,232 |  |

[0000950170-23-027948:mdna:21]
•
Net revenues: Our net revenues increased approximately 1% in fiscal 2023 compared to fiscal 2022, due to an increase in services revenues, primarily driven by an increase in public cloud revenues.

[0000950170-23-027948:mdna:22]
•
Gross profit margin percentage: Our gross profit margin as a percentage of net revenues decreased less than one percentage point in fiscal 2023 compared to fiscal 2022 primarily due to the decrease in gross profit margins on product revenues.

[0000950170-23-027948:mdna:23]
•
Income from operations as a percentage of net revenues: Our income from operations as a percentage of net revenues decreased by two percentage points in fiscal 2023 compared to fiscal 2022, primarily due to a slightly lower gross profit margin percentage and an increase in restructuring charges.

[0000950170-23-027948:mdna:24]
•
(Benefit) provision for income taxes: We had a benefit from income taxes in fiscal 2023, compared to a provision for income taxes in fiscal 2022, due to a discrete tax benefit of $524 million that resulted from an intra-entity asset transfer of certain intellectual property.

[0000950170-23-027948:mdna:25]
•
Net income and Diluted net income per share: The increase in both net income and diluted net income per share in fiscal 2023 compared to fiscal 2022 reflect the factors discussed above. Higher net income and increased share repurchases in fiscal 2023 compared to fiscal 2022 favorably impacted diluted net income per share.

[0000950170-23-027948:mdna:26]
Stock Repurchase Program and Dividend Activity

[0000950170-23-027948:mdna:27]
During fiscal 2023, we repurchased approximately 13 million shares of our common stock at an average price of $66.42 per share, for an aggregate purchase price of $850 million. We also declared aggregate cash dividends of $2.00 per share in fiscal 2023, for which we paid a total of $432 million.

[0000950170-23-027948:mdna:28]
Acquisition

[0000950170-23-027948:mdna:29]
On May 20, 2022, we acquired all the outstanding shares of privately-held Instaclustr US Holding, Inc. (Instaclustr), a leading platform provider of fully managed open-source database, pipeline and workflow applications delivered as a service, for approximately $498 million.

[0000950170-23-027948:mdna:30]
Restructuring Events

[0000950170-23-027948:mdna:31]
During fiscal 2023, we executed several restructuring plans and recognized expenses totaling $120 million consisting primarily of employee severance-related costs.

[0000950170-23-027948:mdna:32]
Results of Operations

[0000950170-23-027948:mdna:33]
Our fiscal year is reported on a 52- or 53-week year that ends on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal 2023, which ended on April 28, 2023, and fiscal 2022, which ended on April 29, 2022 were both 52-week years. Fiscal 2021, which ended on April 30, 2021 was a 53-week year, with 14 weeks included in its first quarter and 13 weeks in each subsequent quarter. Unless otherwise stated, references to particular years, quarters, months and periods refer to our fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0000950170-23-027948:mdna:34]
The following table sets forth certain Consolidated Statements of Income data as a percentage of net revenues for the periods indicated:

[0000950170-23-027948:mdna:35]
|  |  | Fiscal Year |  |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 48 | % |  |  | 52 | % |  |  | 52 | % |  |
| Services |  |  | 52 |  |  |  | 48 |  |  |  | 48 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 24 |  |  |  | 25 |  |  |  | 25 |  |  |
| Cost of services |  |  | 10 |  |  |  | 9 |  |  |  | 9 |  |  |
| Gross profit |  |  | 66 |  |  |  | 67 |  |  |  | 66 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 29 |  |  |  | 29 |  |  |  | 30 |  |  |
| Research and development |  |  | 15 |  |  |  | 14 |  |  |  | 15 |  |  |
| General and administrative |  |  | 4 |  |  |  | 4 |  |  |  | 4 |  |  |
| Restructuring charges |  |  | 2 |  |  |  | 1 |  |  |  | 1 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | (3 | ) |  |
| Total operating expenses |  |  | 50 |  |  |  | 48 |  |  |  | 48 |  |  |
| Income from operations |  |  | 16 |  |  |  | 18 |  |  |  | 18 |  |  |
| Other income (expense), net |  |  | 1 |  |  |  | (1 | ) |  |  | (1 | ) |  |
| Income before income taxes |  |  | 17 |  |  |  | 17 |  |  |  | 17 |  |  |
| (Benefit) provision for income taxes |  |  | (3 | ) |  |  | 3 |  |  |  | 4 |  |  |
| Net income |  |  | 20 | % |  |  | 15 | % |  |  | 13 | % |  |

[0000950170-23-027948:mdna:36]
Percentages may not add due to rounding

[0000950170-23-027948:mdna:37]
Discussion and Analysis of Results of Operations

[0000950170-23-027948:mdna:38]
Net Revenues (in millions, except percentages):

[0000950170-23-027948:mdna:39]
|  |  |  | Fiscal Year |  |
|  |  |  | 2023 |  |  | 2022 |  |  | % Change |  |  | 2021 |  |  | % Change |  |
| Net revenues |  |  | $ | 6,362 |  |  | $ | 6,318 |  |  |  | 1 | % |  | $ | 5,744 |  |  |  | 10 | % |

[0000950170-23-027948:mdna:40]
The increase in net revenues for fiscal 2023 compared to fiscal 2022 was due to an increase in services revenue partially offset by a decrease in product revenues. Product revenues as a percentage of net revenues decreased by approximately four percentage points in fiscal 2023 compared to fiscal 2022, while services revenues as a percentage of net revenues increased by approximately four percentage points. Fluctuations in foreign currency exchange rates adversely impacted net revenues percent growth by approximately four percentage points in fiscal 2023 compared to fiscal 2022.

[0000950170-23-027948:mdna:41]
The increase in net revenues for fiscal 2022 compared to fiscal 2021 was due to an increase in both product revenues and services revenues, with revenues increasing despite the additional week in fiscal 2021. Product revenues and services revenues as a percentage of net revenues both remained relatively consistent in fiscal 2022 compared to fiscal 2021.

[0000950170-23-027948:mdna:42]
Sales through our indirect channels represented 78%, 77% and 77% of net revenues in fiscal 2023, 2022 and 2021, respectively.

[0000950170-23-027948:mdna:43]
The following customers, each of which is a distributor, accounted for 10% or more of net revenues:

[0000950170-23-027948:mdna:44]
|  |  | Fiscal Year |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 24 | % |  |  | 24 | % |
| Tech Data Corporation |  |  | 21 | % |  |  | 21 | % |  |  | 20 | % |

[0000950170-23-027948:mdna:45]
Product Revenues (in millions, except percentages):

[0000950170-23-027948:mdna:46]
|  |  |  | Fiscal Year |  |
|  |  |  | 2023 |  |  | 2022 |  |  | % Change |  |  | 2021 |  |  | % Change |  |
| Product revenues |  |  | $ | 3,049 |  |  | $ | 3,284 |  |  |  | (7 | )% |  | $ | 2,991 |  |  |  | 10 | % |
| Hardware (Non-GAAP) |  |  |  | 1,251 |  |  |  | 1,358 |  |  |  | (8 | )% |  |  | 1,355 |  |  |  | — | % |
| Software (Non-GAAP) |  |  |  | 1,798 |  |  |  | 1,926 |  |  |  | (7 | )% |  |  | 1,636 |  |  |  | 18 | % |

[0000950170-23-027948:mdna:47]
Hybrid Cloud

[0000950170-23-027948:mdna:48]
Product revenues are derived through the sale of our Hybrid Cloud solutions and consist of sales of configured all-flash array systems (including All-Flash FAS and QLC-Flash FAS) and hybrid systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, StorageGrid, OEM products, NetApp HCI and add-on optional software.

[0000950170-23-027948:mdna:49]
In order to provide visibility into the value created by our software innovation and R&D investment, we disclose the software and hardware components of our product revenues. Software product revenues includes the OS software and optional add-on software solutions attached to our systems across our entire product set, while hardware product revenues include the non-software component of our systems across the entire set. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, the hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0000950170-23-027948:mdna:50]
Total product revenues decreased in fiscal 2023 compared to fiscal 2022, primarily due to lower sales of all flash array systems, as a result of softening customer demand. Product revenues were also unfavorably impacted by foreign exchange rate fluctuations. These decreases were partially offset by an increase in sales of hybrid systems.

[0000950170-23-027948:mdna:51]
Total product revenues increased in fiscal 2022 compared to fiscal 2021, primarily driven by an increase in sales of all-flash array systems and, to a lesser extent, an increase in sales of StorageGrid, partially offset by a decrease in sales of NetApp HCI. Supply chain challenges related to the COVID-19 pandemic impeded our ability to fulfill certain customer orders in fiscal 2022, particularly in the fourth quarter.

[0000950170-23-027948:mdna:52]
Revenues from the hardware component of product revenues represented 41%, 41% and 45% of product revenues in fiscal 2023, 2022 and 2021, respectively. The software component of product revenues represented 59%, 59% and 55% of product revenues in fiscal 2023, 2022 and 2021, respectively. The software component percentage of product revenues remained relatively flat in fiscal 2023 as compared to fiscal 2022 despite the decrease in sales of all-flash array systems, which contain a higher proportion of software components than other Hybrid Cloud products, primarily due to the mix of other Hybrid Cloud products sold. The increase in the software component percentage of product revenues in fiscal 2022 is primarily due to a higher mix of all-flash array systems sales.

[0000950170-23-027948:mdna:53]
Services Revenues (in millions, except percentages):

[0000950170-23-027948:mdna:54]
|  |  |  | Fiscal Year |  |
|  |  |  | 2023 |  |  | 2022 |  |  | % Change |  |  | 2021 |  |  | % Change |  |
| Services revenues |  |  | $ | 3,313 |  |  | $ | 3,034 |  |  |  | 9 | % |  | $ | 2,753 |  |  |  | 10 | % |
| Support |  |  |  | 2,419 |  |  |  | 2,344 |  |  |  | 3 | % |  |  | 2,277 |  |  |  | 3 | % |
| Professional and other services |  |  |  | 319 |  |  |  | 294 |  |  |  | 9 | % |  |  | 277 |  |  |  | 6 | % |
| Public cloud |  |  |  | 575 |  |  |  | 396 |  |  |  | 45 | % |  |  | 199 |  |  |  | 99 | % |

[0000950170-23-027948:mdna:55]
Hybrid Cloud

[0000950170-23-027948:mdna:56]
Hybrid Cloud services revenues are derived from the sale of: (1) support, which includes both hardware and software support contracts (the latter of which entitle customers to receive unspecified product upgrades and enhancements, bug fixes and patch releases), and (2) professional and other services, which include customer education and training.

[0000950170-23-027948:mdna:57]
Support revenues increased in fiscal 2023 compared to fiscal 2022, despite the unfavorable impact from foreign exchange rate fluctuations, primarily due to a higher aggregate support contract value for our installed base in the current year.

[0000950170-23-027948:mdna:58]
Support revenues increased in fiscal 2022 compared to fiscal 2021, despite an extra week in the first quarter of fiscal 2021 that contributed approximately $40 million of additional revenues in that period, primarily due to a higher aggregate support contract value for our installed base in fiscal 2022 compared to fiscal 2021.

[0000950170-23-027948:mdna:59]
Professional and other services revenues increased in fiscal 2023 compared to fiscal 2022 primarily due to an increase in other services revenues. The increase in fiscal 2022 compared to fiscal 2021 was primarily due to an increase in demand from increased product sales.

[0000950170-23-027948:mdna:60]
Public Cloud

[0000950170-23-027948:mdna:61]
Public Cloud revenues are derived from the sale of public cloud offerings delivered primarily as-a-service, which include cloud storage and data services, and cloud operations services.

[0000950170-23-027948:mdna:62]
Public Cloud revenues increased in fiscal 2023 and fiscal 2022 compared to the respective prior years primarily due to growing customer demand for NetApp's diversified cloud offerings, coupled with overall growth in the cloud market, and the acquisitions of Instaclustr early in the first quarter of fiscal 2023 and CloudCheckr, Inc. (CloudCheckr) in the third quarter of fiscal 2022. The acquisition of Spot, Inc. (Spot) late in the first quarter of fiscal 2021 also contributed to the increase in Public Cloud revenues in fiscal 2022 compared to fiscal 2021.

[0000950170-23-027948:mdna:63]
Revenues by Geographic Area:

[0000950170-23-027948:mdna:64]
|  |  | Fiscal Year |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| United States, Canada and Latin America (Americas) |  |  | 53 | % |  |  | 55 | % |  |  | 54 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 33 | % |  |  | 31 | % |  |  | 31 | % |
| Asia Pacific (APAC) |  |  | 14 | % |  |  | 14 | % |  |  | 15 | % |

[0000950170-23-027948:mdna:65]
Percentages may not add due to rounding

[0000950170-23-027948:mdna:66]
Americas revenues consist of sales to Americas commercial and United States (U.S.) public sector markets. During fiscal 2023, Americas revenues were negatively impacted by adverse macroeconomic conditions which resulted in a weakened demand environment. Demand across geographies was relatively consistent in fiscal 2022 compared to fiscal 2021.

[0000950170-23-027948:mdna:67]
Cost of Revenues

[0000950170-23-027948:mdna:68]
Our cost of revenues consists of:

[0000950170-23-027948:mdna:69]
(1) cost of product revenues, composed of (a) cost of Hybrid Cloud product revenues, which includes the costs of manufacturing and shipping our products, inventory write-downs, and warranty costs, and (b) unallocated cost of product revenues, which includes stock-based compensation and amortization of intangibles, and;

[0000950170-23-027948:mdna:70]
(2) cost of services revenues, composed of (a) cost of support revenues, which includes the costs of providing support activities for hardware and software support, global support partnership programs, and third party royalty costs, (b) cost of professional and other services revenues, (c) cost of public cloud revenues, constituting the cost of providing our Public Cloud offerings which includes depreciation and amortization expense and third party datacenter fees, and (d) unallocated cost of services revenues, which includes stock-based compensation and amortization of intangibles.

[0000950170-23-027948:mdna:71]
Cost of Product Revenues (in millions, except percentages):

[0000950170-23-027948:mdna:72]
|  |  |  | Fiscal Year |  |
|  |  |  | 2023 |  |  | 2022 |  |  | % Change |  |  | 2021 |  |  | % Change |  |
| Cost of product revenues |  |  | $ | 1,517 |  |  | $ | 1,554 |  |  |  | (2 | )% |  | $ | 1,432 |  |  |  | 9 | % |
| Hybrid Cloud |  |  |  | 1,511 |  |  |  | 1,541 |  |  |  | (2 | )% |  |  | 1,402 |  |  |  | 10 | % |
| Unallocated |  |  |  | 6 |  |  |  | 13 |  |  |  | (54 | )% |  |  | 30 |  |  |  | (57 | )% |

[0000950170-23-027948:mdna:73]
Hybrid Cloud

[0000950170-23-027948:mdna:74]
37

[0000950170-23-027948:mdna:75]
Cost of Hybrid Cloud product revenues represented 50%, 47% and 47% of Hybrid Cloud product revenues in fiscal 2023, 2022 and 2021, respectively. Materials costs represented 94%, 93% and 91% of cost of Hybrid Cloud product revenues in fiscal 2023, 2022 and 2021, respectively.

[0000950170-23-027948:mdna:76]
Materials costs were approximately flat in fiscal 2023 compared to fiscal 2022 reflecting the decrease in product revenues, offset by higher component and freight costs as a result of supply chain challenges.

[0000950170-23-027948:mdna:77]
Hybrid Cloud product gross margins decreased by approximately three percentage points in fiscal 2023 compared to fiscal 2022 primarily due to higher component and freight costs and the adverse impacts of fluctuations in foreign currency exchange rates.

[0000950170-23-027948:mdna:78]
Materials costs increased by approximately $156 million in fiscal 2022 compared to fiscal 2021 reflecting the increase in product revenues in fiscal 2022, the mix of systems sold, and higher component and freight costs as a result of COVID-19 related supply chain challenges. Excess and obsolete inventory reserves were lower in fiscal 2022 compared to fiscal 2021.

[0000950170-23-027948:mdna:79]
Hybrid Cloud product gross margins remained relatively flat in fiscal 2022 compared to fiscal 2021 despite the increase in component and freight costs, which were offset primarily by a higher mix of all-flash array systems sales, which have higher margins than hybrid systems.

[0000950170-23-027948:mdna:80]
Unallocated

[0000950170-23-027948:mdna:81]
Unallocated cost of product revenues decreased in fiscal 2023 and fiscal 2022 compared to the respective prior year periods due to certain intangible assets becoming fully amortized.

[0000950170-23-027948:mdna:82]
Cost of Services Revenues (in millions, except percentages):

[0000950170-23-027948:mdna:83]
|  |  |  | Fiscal Year |  |
|  |  |  | 2023 |  |  | 2022 |  |  | % Change |  |  | 2021 |  |  | % Change |  |
| Cost of services revenues |  |  | $ | 636 |  |  | $ | 544 |  |  |  | 17 | % |  | $ | 497 |  |  |  | 9 | % |
| Support |  |  |  | 181 |  |  |  | 184 |  |  |  | (2 | )% |  |  | 201 |  |  |  | (8 | )% |
| Professional and other services |  |  |  | 211 |  |  |  | 205 |  |  |  | 3 | % |  |  | 206 |  |  |  | — | % |
| Public cloud |  |  |  | 184 |  |  |  | 118 |  |  |  | 56 | % |  |  | 65 |  |  |  | 82 | % |
| Unallocated |  |  |  | 60 |  |  |  | 37 |  |  |  | 62 | % |  |  | 25 |  |  |  | 48 | % |

[0000950170-23-027948:mdna:84]
Hybrid Cloud

[0000950170-23-027948:mdna:85]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, increased slightly in fiscal 2023 compared to fiscal 2022 and decreased in fiscal 2022 compared to fiscal 2021. Cost of Hybrid Cloud services revenues represented 14%, 15% and 16% of Hybrid Cloud services revenues in fiscal 2023, 2022 and 2021, respectively.

[0000950170-23-027948:mdna:86]
Hybrid Cloud support gross margins were relatively consistent in fiscal 2023 compared to fiscal 2022, while they increased by one percentage point in fiscal 2022 compared to fiscal 2021 due to growth in support revenues achieved with a consistent cost base.

[0000950170-23-027948:mdna:87]
Public Cloud

[0000950170-23-027948:mdna:88]
Cost of Public Cloud revenues increased in fiscal 2023 and in fiscal 2022 compared to the respective prior years, reflecting the ongoing growth in Public Cloud revenues in each period. Public Cloud gross margins decreased by two percentage points in fiscal 2023 compared to fiscal 2022, primarily due to the mix of offerings provided. Public Cloud gross margins increased by three percentage points in fiscal 2022 compared to fiscal 2021, reflecting efficiencies from scaling our Public Cloud segment.

[0000950170-23-027948:mdna:89]
Unallocated

[0000950170-23-027948:mdna:90]
Unallocated cost of services revenues increased in fiscal 2023 and in fiscal 2022 compared to the respective prior years, due to our acquisitions of Instaclustr early in the first quarter of fiscal 2023 and CloudCheckr in the third quarter of fiscal 2022, which resulted in higher amortization expense from acquired intangible assets.

[0000950170-23-027948:mdna:91]
Operating Expenses

[0000950170-23-027948:mdna:92]
Sales and Marketing, Research and Development and General and Administrative Expenses

[0000950170-23-027948:mdna:93]
Sales and marketing, research and development, and general and administrative expenses for fiscal 2023 totaled $3,050 million, or 48% of net revenues, relatively consistent with fiscal 2022. While fluctuations in foreign currency exchange rates adversely impacted net revenues in fiscal 2023 compared to fiscal 2022, they favorably impacted sales and marketing, research and development and general and administrative expenses by approximately 3% in fiscal 2023.

[0000950170-23-027948:mdna:94]
Sales and marketing, research and development, and general and administrative expenses for fiscal 2022 totaled $3,017 million, or 48% of net revenues, representing a decrease of two percentage points compared to fiscal 2021.

[0000950170-23-027948:mdna:95]
Compensation costs represent the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0000950170-23-027948:mdna:96]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses increased by $101 million, or 6%, during fiscal 2023 compared to fiscal 2022, primarily due to higher salaries, benefits and stock-based compensation expense, reflecting an increase in average headcount of 8%. The increase was partially offset by lower incentive compensation expense.

[0000950170-23-027948:mdna:97]
Total compensation costs included in operating expenses increased by $74 million, or 4%, during fiscal 2022 compared to fiscal 2021, primarily due to higher salaries, benefits and stock-based compensation expenses, reflecting a 3% increase in average headcount. This increase was partially offset by lower incentive compensation expense. Total compensation costs for fiscal 2021 includes the impact of an additional week in the first quarter of fiscal 2021.

[0000950170-23-027948:mdna:98]
Sales and Marketing (in millions, except percentages):

[0000950170-23-027948:mdna:99]
|  |  |  | Fiscal Year |  |
|  |  |  | 2023 |  |  | 2022 |  |  | % Change |  |  | 2021 |  |  | % Change |  |
| Sales and marketing expenses |  |  | $ | 1,829 |  |  | $ | 1,857 |  |  |  | (2 | )% |  | $ | 1,744 |  |  |  | 6 | % |

[0000950170-23-027948:mdna:100]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, facilities and IT support costs, advertising and marketing promotional expense and travel and entertainment expense. The changes in sales and marketing expenses consisted of the following (in percentage points of the total change):

[0000950170-23-027948:mdna:101]
|  |  | Fiscal 2023 to Fiscal 2022 |  |  | Fiscal 2022 to Fiscal 2021 |  |
| Compensation costs |  |  | 2 |  |  |  | 4 |  |
| Commissions |  |  | (3 | ) |  |  | 1 |  |
| Advertising and marketing promotional expense |  |  | (2 | ) |  |  | — |  |
| Travel and entertainment |  |  | 1 |  |  |  | 1 |  |
| Total change |  |  | (2 | ) |  |  | 6 |  |

[0000950170-23-027948:mdna:102]
The increase in compensation costs for fiscal 2023 compared to fiscal 2022 reflected an increase in average headcount of approximately 6%. The impact of the increase in headcount was partially offset by lower incentive compensation expense and the impact of foreign exchange rate fluctuations.

[0000950170-23-027948:mdna:103]
The increase in compensation costs in fiscal 2022 compared to fiscal 2021 reflected an increase in average headcount of approximately 5%, partially offset by the impact of one less week in fiscal 2022.

[0000950170-23-027948:mdna:104]
The decrease in commissions expense for fiscal 2023 compared to fiscal 2022 was primarily due to lower performance against sales goals. The increase in commissions expense in fiscal 2022 primarily reflected the increase in the average headcount of our sales team compared to fiscal 2021, partially offset by slightly lower attainment against sales goals than in fiscal 2021.

[0000950170-23-027948:mdna:105]
Advertising and marketing promotional expense decreased in fiscal 2023 compared to fiscal 2022, primarily due to lower spending on certain marketing programs.

[0000950170-23-027948:mdna:106]
Travel and entertainment expense increased in fiscal 2023 and fiscal 2022 compared to the respective prior years, as COVID-19 related travel restrictions eased.

[0000950170-23-027948:mdna:107]
Research and Development (in millions, except percentages):

[0000950170-23-027948:mdna:108]
|  |  |  | Fiscal Year |  |
|  |  |  | 2023 |  |  | 2022 |  |  | % Change |  |  | 2021 |  |  | % Change |  |
| Research and development expenses |  |  | $ | 956 |  |  | $ | 881 |  |  |  | 9 | % |  | $ | 881 |  |  |  | — | % |

[0000950170-23-027948:mdna:109]
Research and development expenses consist primarily of compensation costs, facilities and IT support costs, depreciation, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs. Changes in research and development expense consisted of the following (in percentage points of the total change):

[0000950170-23-027948:mdna:110]
|  |  | Fiscal 2023 to Fiscal 2022 |  |  | Fiscal 2022 to Fiscal 2021 |  |
| Compensation costs |  |  | 8 |  |  |  | (1 | ) |
| Development projects and outside services |  |  | 1 |  |  |  | 1 |  |
| Total change |  |  | 9 |  |  |  | — |  |

[0000950170-23-027948:mdna:111]
The increase in compensation costs for fiscal 2023 compared to fiscal 2022 was primarily attributable to an increase in average headcount of 11%. The impact of the increase in headcount was partially offset by lower incentive compensation expense and the impact of foreign exchange rate fluctuations. The increase in development projects and outside services for fiscal 2023 compared to fiscal 2022 was primarily due to the higher spending on certain engineering projects.

[0000950170-23-027948:mdna:112]
The decrease in compensation costs for fiscal 2022 compared to fiscal 2021 was primarily due to lower incentive compensation expense, while average headcount was relatively consistent in each period. Compensation costs for fiscal 2022 also reflected the impact of one less week in fiscal 2022. The increase in development projects and outside services during fiscal 2022 compared to fiscal 2021 was primarily due to the higher spending on certain engineering projects.

[0000950170-23-027948:mdna:113]
General and Administrative (in millions, except percentages):

[0000950170-23-027948:mdna:114]
|  |  |  | Fiscal Year |  |
|  |  |  | 2023 |  |  | 2022 |  |  | % Change |  |  | 2021 |  |  | % Change |  |
| General and administrative expenses |  |  | $ | 265 |  |  | $ | 279 |  |  |  | (5 | )% |  | $ | 257 |  |  |  | 9 | % |

[0000950170-23-027948:mdna:115]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and facilities and IT support costs. Changes in general and administrative expense consisted of the following (in percentage points of the total change):

[0000950170-23-027948:mdna:116]
|  |  | Fiscal 2023 to Fiscal 2022 |  |  | Fiscal 2022 to Fiscal 2021 |  |
| Compensation costs |  |  | (1 | ) |  |  | 4 |  |
| Professional and legal fees and outside services |  |  | 1 |  |  |  | 4 |  |
| Facilities and IT support costs |  |  | (5 | ) |  |  | (1 | ) |
| Other |  |  | — |  |  |  | 2 |  |
| Total change |  |  | (5 | ) |  |  | 9 |  |

[0000950170-23-027948:mdna:117]
The decrease in compensation costs in fiscal 2023 compared to fiscal 2022 was primarily attributable to lower incentive compensation expense, partially offset by the increase in salaries and stock-based compensation expenses. The increases in professional and legal fees and outside services expense in fiscal 2023 were primarily due to higher spending on certain business transformation projects. The decrease in facilities and IT support costs in fiscal 2023 was primarily related to lower spending for certain IT projects.

[0000950170-23-027948:mdna:118]
The increase in compensation costs in fiscal 2022 compared to fiscal 2021 were primarily attributable to a 4% increase in average headcount and higher stock-based compensation expense, which was partially offset by lower incentive compensation expense and the impact of one less week in fiscal 2022. The increases in professional and legal fees and outside services expense in fiscal 2022 were primarily due to higher spending on business transformation projects and an increase in legal fees. The decreases in facilities and IT support costs were primarily due to lower spending levels on IT projects.

[0000950170-23-027948:mdna:119]
Restructuring Charges (in millions, except percentages):

[0000950170-23-027948:mdna:120]
|  |  |  | Fiscal Year |  |
|  |  |  | 2023 |  |  | 2022 |  |  | % Change |  |  | 2021 |  |  | % Change |  |
| Restructuring charges |  |  | $ | 120 |  |  | $ | 33 |  |  |  | 264 | % |  | $ | 42 |  |  |  | (21 | )% |

[0000950170-23-027948:mdna:121]
In an effort to reduce our cost structure and redirect resources to our highest return activities, in fiscal 2023, 2022 and 2021, we initiated a number of business realignment plans designed to streamline our business and focus on key strategic opportunities. These plans resulted in aggregate reductions of our global workforce of approximately 9% in fiscal 2023, 1% in fiscal 2022, and 6% in fiscal 2021, and aggregate charges of $120 million, $33 million and $42 million, respectively, consisting primarily of employee severance costs. The aggregate charges in fiscal 2023 and fiscal 2022 also included legal and tax-related consulting fees associated with the establishment of an international headquarters in Cork, Ireland. See Note 12 – Restructuring Charges of the Notes to Consolidated Financial Statements for more details regarding our restructuring plans.

[0000950170-23-027948:mdna:122]
Acquisition-related Expense (in millions, except percentages):

[0000950170-23-027948:mdna:123]
|  |  |  | Fiscal Year |  |
|  |  |  | 2023 |  |  | 2022 |  |  | % Change |  |  | 2021 |  |  | % Change |  |
| Acquisition-related expense |  |  | $ | 21 |  |  | $ | 13 |  |  |  | 62 | % |  | $ | 16 |  |  |  | (19 | )% |

[0000950170-23-027948:mdna:124]
We incurred $21 million, $13 million and $16 million of acquisition-related expenses, primarily consisting of legal and consulting fees, in fiscal 2023, fiscal 2022 and fiscal 2021, respectively, associated with our acquisition and subsequent integration of Instaclustr, CloudCheckr and Spot, respectively.

[0000950170-23-027948:mdna:125]
Gain on Sale or Derecognition of Assets (in millions, except percentages):

[0000950170-23-027948:mdna:126]
|  |  |  | Fiscal Year |  |
|  |  |  | 2023 |  |  | 2022 |  |  | % Change |  |  | 2021 |  |  | % Change |  |
| Gain on sale or derecognition of assets |  |  | $ | — |  |  | $ | — |  |  |  | — |  |  | $ | (156 | ) |  |  | (100 | )% |

[0000950170-23-027948:mdna:127]
In April 2021, we sold certain land and buildings located in Sunnyvale, California with an aggregate net book value of $210 million and received cash proceeds of $365 million, resulting in a gain, net of direct selling cost, and adjusted for below-market rent,  of $156 million.

[0000950170-23-027948:mdna:128]
Other Income (Expense), Net (in millions, except percentages)

[0000950170-23-027948:mdna:129]
The components of other income (expense), net were as follows:

[0000950170-23-027948:mdna:130]
|  |  |  | Fiscal Year |  |
|  |  |  | 2023 |  |  | 2022 |  |  | % Change |  |  | 2021 |  |  | % Change |  |
| Interest income |  |  | $ | 69 |  |  | $ | 7 |  |  |  | 886 | % |  | $ | 9 |  |  |  | (22 | )% |
| Interest expense |  |  |  | (67 | ) |  |  | (73 | ) |  |  | (8 | )% |  |  | (74 | ) |  |  | (1 | )% |
| Other, net |  |  |  | 46 |  |  |  | 4 |  |  | NM |  |  |  | (4 | ) |  | NM |  |
| Total |  |  | $ | 48 |  |  | $ | (62 | ) |  | NM |  |  | $ | (69 | ) |  | NM |  |

[0000950170-23-027948:mdna:131]
NM - Not Meaningful

[0000950170-23-027948:mdna:132]
Interest income increased in fiscal 2023 compared to fiscal 2022 primarily due to higher yields earned on our cash and investments.  Interest income decreased during fiscal 2022 and fiscal 2021 compared to the respective prior years due to both a reduction in the size of our investment portfolio and lower yields earned on the investments.

[0000950170-23-027948:mdna:133]
Interest expense decreased in fiscal 2023 compared to fiscal 2022 due to the extinguishment of certain senior notes in the second quarter of fiscal 2023. Interest expense remained flat in fiscal 2022 compared to fiscal 2021 as the aggregate principal amount of our outstanding Senior Notes remained consistent.

[0000950170-23-027948:mdna:134]
Other, net for fiscal 2023 includes $22 million of other income for non-refundable, up-front payments from customers in Russia for support contracts, which we were not able to fulfill due to imposed sanctions and for which we have no remaining legal obligation to perform. Other, net for fiscal 2023 also includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million. The remaining differences in Other, net for fiscal 2023 as compared to fiscal 2022 are primarily due to foreign exchange gains and losses year-over-year. The differences in Other, net during fiscal 2022 as compared to fiscal 2021 are partially due to foreign exchange gains and losses year-over-year. In fiscal 2021, other, net includes a $6 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of

[0000950170-23-027948:mdna:135]
approximately $8 million. This benefit was more than offset by a $14 million loss recognized from the extinguishment of our Senior Notes due June 2021 in the first quarter of fiscal 2021.

[0000950170-23-027948:mdna:136]
Provision for Income Taxes (in millions, except percentages):

[0000950170-23-027948:mdna:137]
|  |  |  | Fiscal Year |  |
|  |  |  | 2023 |  |  | 2022 |  |  | % Change |  |  | 2021 |  |  | % Change |  |
| Provision for income taxes |  |  | $ | (208 | ) |  | $ | 158 |  |  |  | (232 | )% |  | $ | 232 |  |  |  | (32 | )% |

[0000950170-23-027948:mdna:138]
Our effective tax rate for fiscal 2023 was (19.5)% compared to 14.4% in fiscal 2022, primarily due to benefits resulting from an intra-entity asset transfer of certain IP, offset by discrete tax expense recorded as a result of the Danish Supreme Court ruling received January 9, 2023.

[0000950170-23-027948:mdna:139]
During the second quarter of fiscal 2023, we completed an intra-entity asset transfer of certain IP to our international headquarters (the “IP Transfer”). The transaction resulted in a step-up of tax-deductible basis in the transferred assets, and accordingly, created a temporary difference where the tax basis exceeded the financial statement basis of such intangible assets, which resulted in the recognition of a discrete tax benefit and related deferred tax asset of $524 million during the second quarter of fiscal 2023. Management applied significant judgment when determining the fair value of the IP, which serves as the tax basis of the deferred tax asset. With the assistance of third-party valuation specialists, the fair value of the IP was determined principally based on the present value of projected cash flows related to the IP which reflects management’s assumptions regarding projected revenues, earnings before interest and taxes, and a discount rate. The tax-deductible amortization related to the transferred IP rights will be recognized in future periods and any amortization that is unused in a particular year can be carried forward indefinitely. The deferred tax asset and the tax benefit were measured based on the enacted tax rates expected to apply in the years the asset is expected to be realized. We expect to realize the deferred tax asset resulting from the IP Transfer and will assess the realizability of the deferred tax asset quarterly. Any Organisation for Economic Co-operation and Development’s (“OECD”) actions adopted internationally could impact our financial results in future periods. The impact of the transaction to net cash provided by or used in operating, investing and financing activities on the condensed consolidated statements of cash flows during fiscal 2023 was not material.

[0000950170-23-027948:mdna:140]
During the third quarter of fiscal 2023, the Danish Supreme Court issued a non-appealable ruling on the distributions declared in 2005 and 2006. The Danish Supreme Court reversed the lower court's decision and ruled the 2005 dividend was subject to at-source dividend withholding tax while the smaller 2006 distribution would not be subject to withholding tax. We recorded $69 million of tax expense, which includes $23 million of withholding tax (which we paid in fiscal 2023) and $46 million of interest (which is included in accrued expenses in our consolidated balance sheet as of the end of fiscal 2023), associated with the Danish Supreme Court ruling as a discrete item during the third quarter of fiscal 2023.

[0000950170-23-027948:mdna:141]
Our effective tax rate for fiscal 2022 was lower than the prior year primarily due to the inclusion of one-time benefits related to the prepayment of certain intercompany expenses. Additionally, the fiscal 2021 tax provision included the impact of taxes resulting from the integration of certain acquired companies.

[0000950170-23-027948:mdna:142]
Liquidity, Capital Resources and Cash Requirements

[0000950170-23-027948:mdna:143]
| (In millions, except percentages) |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,070 |  |  | $ | 4,134 |  |
| Principal amount of debt |  | $ | 2,400 |  |  | $ | 2,650 |  |

[0000950170-23-027948:mdna:144]
The following is a summary of our cash flow activities:

[0000950170-23-027948:mdna:145]
|  |  | Fiscal Year |  |
| (In millions) |  | 2023 |  |  | 2022 |  |
| Net cash provided by operating activities |  | $ | 1,107 |  |  | $ | 1,211 |  |
| Net cash used in investing activities |  |  | (1,390 | ) |  |  | (561 | ) |
| Net cash used in financing activities |  |  | (1,513 | ) |  |  | (1,017 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (1 | ) |  |  | (49 | ) |
| Net change in cash, cash equivalents and restricted cash |  | $ | (1,797 | ) |  | $ | (416 | ) |

[0000950170-23-027948:mdna:146]
42

[0000950170-23-027948:mdna:147]
As of April 28, 2023, our cash, cash equivalents and short-term investments totaled $3.1 billion, reflecting a decrease of $1.1 billion from April 29, 2022. The decrease was primarily due to $850 million used to repurchase shares of our common stock, $432 million used for the payment of dividends, $239 million in purchases of property and equipment, a $250 million repayment of our Senior Notes due December 2022, and $491 million, net of cash acquired, used for the acquisition of a privately-held company, partially offset by $1.1 billion of cash from operating activities. Net working capital was $1.2 billion as of April 28, 2023, a reduction of $779 million when compared to April 29, 2022, primarily due to the decrease in cash, cash equivalents and short-term investments discussed above.

[0000950170-23-027948:mdna:148]
Cash Flows from Operating Activities

[0000950170-23-027948:mdna:149]
During fiscal 2023, we generated cash from operating activities of $1.1 billion, reflecting net income of $1.3 billion which was reduced by $606 million for non-cash deferred tax benefits and increased for non-cash depreciation and amortization expense of $248 million and non-cash stock-based compensation expense of $312 million.

[0000950170-23-027948:mdna:150]
Significant changes in assets and liabilities during fiscal 2023 included the following:

[0000950170-23-027948:mdna:151]
•
Accounts receivable decreased $260 million, reflecting lower billing in the fourth quarter of fiscal 2023 compared to the fourth quarter of fiscal 2022.

[0000950170-23-027948:mdna:152]
•
Accounts payable decreased by $207 million, primarily reflecting lower inventory purchases, and the timing of those purchases from, and payments to, our contract manufacturers.

[0000950170-23-027948:mdna:153]
•
Accrued expenses decreased by $103 million, primarily due to employee compensation payments related to fiscal 2022 incentive compensation and commissions plans.

[0000950170-23-027948:mdna:154]
During fiscal 2022, we generated cash from operating activities of $1.2 billion, reflecting net income of $937 million, adjusted by non-cash depreciation and amortization of $194 million and non-cash stock-based compensation expense of $245 million.

[0000950170-23-027948:mdna:155]
Significant changes in assets and liabilities during fiscal 2022 included the following:

[0000950170-23-027948:mdna:156]
•
Accounts receivable increased $313 million, primarily reflecting less favorable shipping linearity in the fourth quarter of fiscal 2022 compared to the fourth quarter of fiscal 2021.

[0000950170-23-027948:mdna:157]
•
Deferred revenue and financed unearned services increased by $384 million, due to an increase in the aggregate contract value under software and hardware support contracts, primarily reflecting a higher mix of all-flash systems which carry a higher support dollar content than our other products.

[0000950170-23-027948:mdna:158]
•
Accounts payable increased by $181 million, primarily due to higher inventory purchase levels in fiscal 2022, and the timing of inventory purchases during the fourth quarter of each year.

[0000950170-23-027948:mdna:159]
•
Accrued expenses decreased by $111 million, primarily reflecting a reduction of income tax liabilities, and a decrease in accruals for incentive compensation and commissions plans.

[0000950170-23-027948:mdna:160]
We expect that cash provided by operating activities may materially fluctuate in future periods due to a number of factors, including fluctuations in our operating results, shipping linearity, accounts receivable collections performance, inventory and supply chain management, vendor payment initiatives, and the timing and amount of compensation, income taxes and other payments.

[0000950170-23-027948:mdna:161]
Cash Flows from Investing Activities

[0000950170-23-027948:mdna:162]
During fiscal 2023, we used $719 million for the purchases of investments, net of maturities and sales, paid $491 million, net of cash acquired, for a privately-held company and $239 million for capital expenditures. Additionally, we received proceeds of $59 million from the sale of one of our minority investments in fiscal 2023.

[0000950170-23-027948:mdna:163]
During fiscal 2022, we generated $45 million primarily from maturities of investments in available-for-sale securities, net of purchases, and paid $226 million for capital expenditures. We paid $380 million, net of cash acquired, for three privately-held companies.

[0000950170-23-027948:mdna:164]
Cash Flows from Financing Activities

[0000950170-23-027948:mdna:165]
During fiscal 2023, cash flows used in financing activities totaled $1.5 billion and include $850 million for the repurchase of approximately 13 million shares of common stock, $432 million for the payment of dividends and $250 million to redeem our Senior Notes due in December 2022.

[0000950170-23-027948:mdna:166]
During fiscal 2022, cash flows used in financing activities totaled $1.0 billion and included $600 million for the repurchase of approximately seven million shares of common stock and $446 million for the payment of dividends.

[0000950170-23-027948:mdna:167]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including cash, cash equivalents and short-term investments, cash generated from operations, and our ability to access capital markets and committed credit lines will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all. For further discussion of factors that could affect our cash flows and liquidity requirements, see Item 1A. Risk Factors.

[0000950170-23-027948:mdna:168]
Liquidity

[0000950170-23-027948:mdna:169]
Our principal sources of liquidity as of April 28, 2023 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-23-027948:mdna:170]
Cash, cash equivalents and short-term investments consisted of the following (in millions):

[0000950170-23-027948:mdna:171]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Cash and cash equivalents |  | $ | 2,316 |  |  | $ | 4,112 |  |
| Short-term investments |  |  | 754 |  |  |  | 22 |  |
| Total |  | $ | 3,070 |  |  | $ | 4,134 |  |

[0000950170-23-027948:mdna:172]
As of April 28, 2023 and April 29, 2022, $2.2 billion and $2.3 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.9 billion and $1.8 billion, respectively, were available in the U.S.

[0000950170-23-027948:mdna:173]
Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies through asset purchases and/or business acquisitions, service interest and principal payments on our debt, fund our stock repurchase program, and pay dividends, as and if declared. In the ordinary course of business, we engage in periodic reviews of opportunities to invest in or acquire companies or units in companies to expand our total addressable market, leverage technological synergies and establish new streams of revenue, particularly in our Public Cloud segment.

[0000950170-23-027948:mdna:174]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of April 28, 2023.

[0000950170-23-027948:mdna:175]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. We also have an automatic shelf registration statement on file with the Securities and Exchange Commission (SEC). We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0000950170-23-027948:mdna:176]
Senior Notes

[0000950170-23-027948:mdna:177]
The following table summarizes the principal amount of our Senior Notes as of April 28, 2023 (in millions):

[0000950170-23-027948:mdna:178]
|  |  | Amount |  |
| 3.30% Senior Notes Due September 2024 |  | $ | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,400 |  |

[0000950170-23-027948:mdna:179]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 8 – Financing Arrangements of the Notes to Consolidated Financial Statements.

[0000950170-23-027948:mdna:180]
On September 15, 2022, we extinguished our 3.25% Senior Notes due December 2022 for an aggregate cash redemption price of $252 million, comprised of the principal and unpaid interest.

[0000950170-23-027948:mdna:181]
Commercial Paper Program and Credit Facility

[0000950170-23-027948:mdna:182]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of April 28, 2023.

[0000950170-23-027948:mdna:183]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023 primarily to replace the London Interbank Offered Rate (LIBOR) with the Secured Overnight Financing Rate (SOFR) as the basis for establishing the interest rate applicable to certain borrowings under the agreement, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of April 28, 2023, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-23-027948:mdna:184]
Capital Expenditure Requirements

[0000950170-23-027948:mdna:185]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for fiscal 2024 to be between $175 million and $225 million.

[0000950170-23-027948:mdna:186]
Transition Tax Payments

[0000950170-23-027948:mdna:187]
The Tax Cuts and Jobs Act of 2017 imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits that had not previously been subject to U.S. income tax. As of April 28, 2023, outstanding payments related to the transition tax are estimated to be approximately $303 million of which $88 million, $115 million and $100 million are expected to be paid during fiscal 2024, fiscal 2025 and fiscal 2026, respectively. During fiscal 2023, transition tax payments totaled $48 million. Our estimates for future transition tax payments, however, could change with further guidance or review from U.S. federal and state tax authorities or other regulatory bodies.

[0000950170-23-027948:mdna:188]
Dividends and Stock Repurchase Program

[0000950170-23-027948:mdna:189]
On May 26, 2023, we declared a cash dividend of $0.50 per share of common stock, payable on July 26, 2023 to holders of record as of the close of business on July 7, 2023.

[0000950170-23-027948:mdna:190]
45

[0000950170-23-027948:mdna:191]
As of April 28, 2023, our Board of Directors had authorized the repurchase of up to $15.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through April 28, 2023, we repurchased a total of 360 million shares of our common stock at an average price of $40.89 per share, for an aggregate purchase price of $14.7 billion. As of April 28, 2023, the remaining authorized amount for stock repurchases under this program was $0.4 billion. On May 26, 2023 our Board of Directors authorized the repurchase of an additional $1.0 billion of our common stock.

[0000950170-23-027948:mdna:192]
Purchase Commitments

[0000950170-23-027948:mdna:193]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled $0.7 billion at April 28, 2023, of which $0.5 billion is due in fiscal 2024, with the remainder due thereafter.

[0000950170-23-027948:mdna:194]
Financing Guarantees

[0000950170-23-027948:mdna:195]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $38 million and $59 million of receivables during fiscal 2023 and 2022, respectively.

[0000950170-23-027948:mdna:196]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user.

[0000950170-23-027948:mdna:197]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of April 28, 2023 and April 29, 2022, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-23-027948:mdna:198]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of April 28, 2023, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0000950170-23-027948:mdna:199]
Legal Contingencies

[0000950170-23-027948:mdna:200]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 17 – Commitments and Contingencies of the Notes to Consolidated Financial Statements.

[0000950170-23-027948:mdna:201]
Critical Accounting Policies and Estimates

[0000950170-23-027948:mdna:202]
Our consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (GAAP), which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and liabilities. Our estimates are based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0000950170-23-027948:mdna:203]
46

[0000950170-23-027948:mdna:204]
The summary of significant accounting policies is included in Note 1 – Description of Business and Significant Accounting Policies of the Notes to Consolidated Financial Statements. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. The accounting policies described below reflect the significant judgments, estimates and assumptions used in the preparation of the consolidated financial statements.

[0000950170-23-027948:mdna:205]
Revenue Recognition

[0000950170-23-027948:mdna:206]
Our contracts with customers often include the transfer of multiple products and services to the customer. In determining the amount and timing of revenue recognition, we assess which products and services are distinct performance obligations and allocate the transaction price, which may include fixed and/or variable amounts, among each performance obligation on a relative standalone selling price (SSP) basis. The following are the key estimates and assumptions and corresponding uncertainties included in this approach:

[0000950170-23-027948:mdna:207]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | We evaluate whether products and services promised in our contracts with customers are distinct performance obligations that should be accounted for separately versus together. |  |  | In certain contracts, the determination of our distinct performance obligations requires significant judgment. As our business and offerings to customers change over time, the products and services we determine to be distinct performance obligations may change. Such changes may adversely impact the amount of revenue and gross margin we report in a particular period. |
|  | In determining the transaction price of our contracts, we estimate variable consideration based on the expected value, primarily relying on our history. In certain situations, we may also use the most likely amount as the basis of our estimate. |  |  | We may have insufficient relevant historical data or other information to arrive at an accurate estimate of variable consideration using either the “expected value” or “most likely amount” method. Additionally, changes in business practices, such as those related to sales returns or marketing programs, may introduce new forms of variable consideration, as well as more complexity and uncertainty in the estimation process. |
|  | In contracts with multiple performance obligations, we establish SSPs based on the price at which products and services are sold separately. If SSPs are not observable through past transactions, we estimate them by maximizing the use of observable inputs including pricing strategy, market data, internally-approved pricing guidelines related to the performance obligations and other observable inputs. |  |  | As our business and offerings evolve over time, modifications to our pricing and discounting methodologies, changes in the scope and nature of product and service offerings and/or changes in customer segmentation may result in a lack of consistency, making it difficult to establish and/or maintain SSPs. Changes in SSPs could result in different and unanticipated allocations of revenue in contracts with multiple performance obligations. These factors, among others, may adversely impact the amount of revenue and gross margin we report in a particular period. |

[0000950170-23-027948:mdna:208]
Inventory Valuation and Purchase Order Accruals

[0000950170-23-027948:mdna:209]
Inventories consist primarily of purchased components and finished goods and are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. A provision is recorded when inventory is determined to be in excess of anticipated demand or obsolete in order to adjust inventory to its estimated realizable value. The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our inventories:

[0000950170-23-027948:mdna:210]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | We periodically perform an excess and obsolete analysis of our inventory. Inventories are written down based on excess and obsolete reserves determined primarily on assumptions about future demand forecasts and market conditions. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances |  |  | Although we use our best estimates to forecast future product demand, any significant unanticipated changes in demand, including due to macroeconomic uncertainties, or obsolescence related to technological developments, new product introductions, customer requirements, competition or other factors could have a significant impact on the valuation of our inventory. If actual market conditions are less favorable than |

[0000950170-23-027948:mdna:211]
47

[0000950170-23-027948:mdna:212]
|  | do not result in the restoration or increase in that newly established cost basis. |  |  | those projected, additional write-downs and other charges against earnings that adversely impact gross margins may be required. If actual market conditions are more favorable, we may realize higher gross profits in the period when the written-down inventory is sold.We are subject to a variety of environmental laws relating to the manufacture of our products. If there are changes to the current regulations, we may be required to make product design changes which may result in excess or obsolete inventory, which could adversely impact our operating results. |
|  | We make commitments to our third-party contract manufacturers and other suppliers to manage lead times and meet product forecasts and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on non-cancelable purchase commitments when we believe it is probable that the components will not be utilized in future operations. |  |  | If the actual materials demand is significantly lower than our forecast, we may be required to increase our recorded liabilities for estimated losses on non-cancelable purchase commitments, including incremental commitments made in response to recent developments in the broader technology supply chain, which would adversely impact our operating results. |

[0000950170-23-027948:mdna:213]
Goodwill and Purchased Intangible Assets

[0000950170-23-027948:mdna:214]
We allocate the purchase price of acquisitions to identifiable assets acquired and liabilities assumed at their acquisition date fair values based on established valuation techniques. Goodwill represents the residual value as of the acquisition date, which in most cases is measured as the excess of the purchase consideration transferred over the net of the acquisition date fair values of the assets acquired and liabilities assumed.

[0000950170-23-027948:mdna:215]
The carrying values of purchased intangible assets are reviewed whenever events and circumstances indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. We periodically review the estimated remaining useful lives of our intangible assets. This review may result in impairment charges or shortened useful lives, resulting in charges to our consolidated statements of income.

[0000950170-23-027948:mdna:216]
We review goodwill for impairment annually and whenever events or changes in circumstances indicate the carrying amount of one of our reporting units may exceed its fair value. The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. For our annual goodwill impairment test in the fourth quarter of fiscal 2023, we performed a quantitative test and determined the fair value of each of our reporting units substantially exceeded its carrying amount, therefore, there was no impairment of goodwill.

[0000950170-23-027948:mdna:217]
48

[0000950170-23-027948:mdna:218]
The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our goodwill and purchased intangible assets:

[0000950170-23-027948:mdna:219]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the accounting guidance for the fair value measurement of nonfinancial assets.The valuation of purchased intangible assets is principally based on estimates of the future performance and cash flows expected to be generated by the acquired assets from the acquired business. |  |  | While we employ experts to determine the acquisition date fair value of acquired intangibles, the fair values of assets acquired and liabilities assumed are based on significant management assumptions and estimates, which are inherently uncertain and highly subjective and as a result, actual results may differ from estimates. If different assumptions were to be used, it could materially impact the purchase price allocation. Volatile macroeconomic and market conditions have increased the level of uncertainty and subjectivity of certain management assumptions and estimates. |
|  | Evaluations of possible goodwill and purchased intangible asset impairment require us to make judgments and assumptions related to the allocation of our balance sheet and income statement amounts and estimate future cash flows and fair market values of our reporting units and assets. |  |  | In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill or purchased intangible assets. Assumptions and estimates about expected future cash flows and the fair values of our reporting units and purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as the adverse impact of unanticipated changes in macroeconomic conditions, and technological changes or new product introductions from competitors. They can also be affected by internal factors such as changes in business strategy or in forecasted product life cycles and roadmaps. Our ongoing consideration of these and other factors could result in future impairment charges or accelerated amortization expense, which could adversely affect our operating results. |

[0000950170-23-027948:mdna:220]
Income Taxes

[0000950170-23-027948:mdna:221]
We are subject to income taxes in the United States and numerous foreign jurisdictions. We compute our provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets or liabilities are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0000950170-23-027948:mdna:222]
The following are the key estimates and assumptions and corresponding uncertainties for our income taxes, including those specifically related to the intra-entity asset transfer of the IP to our international headquarters during fiscal 2023:

[0000950170-23-027948:mdna:223]
49

[0000950170-23-027948:mdna:224]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | Our income tax provision is based on existing tax law and advanced pricing agreements or letter rulings we have with various tax authorities. |  |  | Our provision for income taxes is subject to volatility and could be adversely impacted by future changes in existing tax laws, such as a change in tax rate, possible U.S. changes to the taxation of earnings of our foreign subsidiaries, and uncertainties as to future renewals of favorable tax agreements and rulings. |
|  | The determination of whether we should record or adjust a valuation allowance against our deferred tax assets is based on assumptions regarding our future profitability. |  |  | Our future profits could differ from current expectations resulting in a change to our determination as to the amount of deferred tax assets that are more likely than not to be realized. We could adjust our valuation allowance with a corresponding impact to the tax provision in the period in which such determination is made. |
|  | The estimates for our uncertain tax positions are based primarily on company specific circumstances, applicable tax laws, tax opinions from outside firms and past results from examinations of our income tax returns. |  |  | Significant judgment is required in evaluating our uncertain tax positions. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome or tax court rulings of these matters will not be different from that which is reflected in our historical tax provisions and accruals. |
|  | The assessment of the fair value of the IP transferred to our international headquarters is based on factors that market participants would use in an orderly transaction in accordance with the accounting guidance for the fair value measurement of nonfinancial assets and transfer pricing principles from the Organisation for Economic Co-operation and Development. The valuation of our IP is principally based on the present value of projected cash flows related to the IP which reflects management’s assumptions regarding projected revenues, earnings before interest and taxes, and a discount rate. |  |  | While we employ experts to assist with the determination of the fair value of IP, its fair value is based on significant management assumptions and estimates, which are inherently uncertain and highly subjective, and as a result, actual results may differ from estimates. If different assumptions were to be used, it could materially impact the IP valuation. Volatile macroeconomic and market conditions have increased the level of uncertainty and subjectivity of certain management assumptions and estimates. |
