# NTAP 8-K — 0000950170-23-025324 filed 2023-05-31

## item codes, every 8-K on or before 2023-06-14

- 2023-05-31 0000950170-23-025324 — 1.01, 2.02, 8.01, 9.01
- 2023-02-22 0000950170-23-003745 — 2.02, 9.01
- 2023-01-31 0001193125-23-019739 — 2.05, 7.01, 9.01
- 2022-11-29 0000950170-22-025793 — 2.02, 9.01
- 2022-11-16 0000950170-22-025317 — 5.02
- 2022-09-14 0000950170-22-018490 — 5.07
- 2022-08-24 0000950170-22-017731 — 2.02, 9.01
- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2023-06-14

- none on or before 2023-06-14

## item 2.02 — earnings release, exhibit 99.1

[0000950170-23-025324:8k_2_02:1]
EX-99.1
3
ntap-ex99_1.htm
EX-99.1

[0000950170-23-025324:8k_2_02:2]
EX-99.1

[0000950170-23-025324:8k_2_02:3]
Exhibit 99.1

[0000950170-23-025324:8k_2_02:4]
NetApp reports fourth quarter and fiscal year 2023 results

[0000950170-23-025324:8k_2_02:5]
Net revenues of $1.58 billion for the fourth quarter;

[0000950170-23-025324:8k_2_02:6]
Net revenues of $6.36 billion for fiscal year 2023

[0000950170-23-025324:8k_2_02:7]
•
Introduced significant innovation, including C-series, a new family of capacity all-flash storage systems, and NetAppTM Advance, a new portfolio of storage programs and guarantees to help customers cost-effectively future proof their on-premises environments

[0000950170-23-025324:8k_2_02:8]
•
Recognized with three Outperformer placements in GigaOm’s annual Radar reports for storage for the second consecutive year

[0000950170-23-025324:8k_2_02:9]
•
Fiscal year 2023 GAAP net income per share of $5.79 increased 42% year over year; fiscal year 2023 non-GAAP net income per share of $5.59 increased 6% year over year

[0000950170-23-025324:8k_2_02:10]
•
$1.28 billion returned to shareholders in fiscal year 2023; representing 116% of cash from operations and 148% of free cash flow2

[0000950170-23-025324:8k_2_02:11]
•
NetApp announced a new share repurchase authorization of an additional $1 billion

[0000950170-23-025324:8k_2_02:12]
SAN JOSE, Calif.—May 31, 2023—NetApp (NASDAQ: NTAP) today reported financial results for the fourth quarter and fiscal year 2023, which ended on April 28, 2023.

[0000950170-23-025324:8k_2_02:13]
“Our sharpened focus and disciplined execution yielded solid Q4 results in a dynamic environment. Digital transformation projects involving business analytics, AI, data security, and application modernization, both on premises and in the cloud, remain top IT priorities,” said George Kurian, chief executive officer. “We deliver significant value to customers on their transformation journeys with a modern approach to hybrid, multicloud infrastructure and data management. We are entering FY24 with substantial new innovations and a more focused operating model to better address the areas of priority spending. I am confident in our ability to drive long-term growth, extend our leadership position, and deliver increasing value for customers, partners, and shareholders."

[0000950170-23-025324:8k_2_02:14]
Fourth quarter of fiscal year 2023 financial results

[0000950170-23-025324:8k_2_02:15]
•
Net revenues: $1.58 billion, compared to $1.68 billion in the fourth quarter of fiscal year 2022; a year-over-year decrease of 6%, or 4% in constant currency1.

[0000950170-23-025324:8k_2_02:16]
o
Hybrid Cloud segment revenue: $1.43 billion, compared to $1.56 billion in the fourth quarter of fiscal year 2022

[0000950170-23-025324:8k_2_02:17]
o
Public Cloud segment revenue: $151 million, compared to $120 million in the fourth quarter of fiscal year 2022

[0000950170-23-025324:8k_2_02:18]
•
Billings2: $1.67 billion, compared to $2.02 billion in the fourth quarter of fiscal year 2022; a year-over-year decrease of 17%, or 15% in constant currency.

[0000950170-23-025324:8k_2_02:19]
•
NetApp Public Cloud annualized revenue run rate (ARR)3 $620 million, compared to $505 million in the fourth quarter of fiscal year 2022; a year-over-year increase of 23%.

[0000950170-23-025324:8k_2_02:20]
•
All-flash array ARR4 $3.1 billion, compared to $3.2 billion in the fourth quarter of fiscal year 2022; a year-over-year decrease of 4%.

[0000950170-23-025324:8k_2_02:21]
•
Net income: GAAP net income of $245 million, compared to $259 million in the fourth quarter of fiscal year 2022; non-GAAP net income5 of $334 million, compared to $324 million in the fourth quarter of fiscal year 2022. The year-over-year fluctuations in GAAP and Non-GAAP net income each include an unfavorable impact of approximately $18 million from foreign currency exchange rate changes.

[0000950170-23-025324:8k_2_02:22]
•
Earnings per share: GAAP net income per share6 of $1.13 compared to $1.14 in the fourth quarter of fiscal year 2022; non-GAAP net income per share of $1.54 compared to $1.42 in the fourth quarter of fiscal year 2022. The year-over-year fluctuations in GAAP and Non-GAAP net income per share each include an unfavorable impact of approximately $0.08 from foreign currency exchange rate changes.

[0000950170-23-025324:8k_2_02:23]
•
Cash, cash equivalents and investments: $3.07 billion at the end of the fourth quarter of fiscal year 2023.

[0000950170-23-025324:8k_2_02:24]
•
Cash provided by operations: $235 million, compared to $411 million in the fourth quarter of fiscal year 2022.

[0000950170-23-025324:8k_2_02:25]
•
Share repurchase and dividends: Returned $256 million to shareholders through share repurchases and cash dividends.

[0000950170-23-025324:8k_2_02:26]
Fiscal year 2023 financial results

[0000950170-23-025324:8k_2_02:27]
•
Net revenues: $6.36 billion, compared to $6.32 billion in fiscal year 2022; a year-over-year increase of 1%, or 4% in constant currency.

[0000950170-23-025324:8k_2_02:28]
o
Hybrid Cloud segment revenue: $5.79 billion, compared to $5.92 billion in fiscal year 2022

[0000950170-23-025324:8k_2_02:29]
o
Public Cloud segment revenue: $575 million, compared to $396 million in fiscal year 2022

[0000950170-23-025324:8k_2_02:30]
•
Billings: $6.41 billion, compared to $6.70 billion in fiscal year 2022, a year-over-year decrease of 4%, or 1% in constant currency.

[0000950170-23-025324:8k_2_02:31]
•
Net income: GAAP net income of $1.27 billion, compared to $937 million in fiscal year 2022; non-GAAP net income of $1.23 billion, compared to $1.21 billion in fiscal year 2022. The year-over-year fluctuations in GAAP and Non-GAAP net income each include an unfavorable impact of approximately $126 million from foreign currency exchange rate changes.

[0000950170-23-025324:8k_2_02:32]
•
Earnings per share: GAAP net income per share of $5.79 compared to $4.09 in fiscal year 2022; non-GAAP net income per share of $5.59 compared to $5.28 in fiscal year 2022. The year-over-year fluctuations in GAAP and Non-GAAP net income per share each include an unfavorable impact of approximately $0.57 from foreign currency exchange rate changes.

[0000950170-23-025324:8k_2_02:33]
•
Cash provided by operations: $1.11 billion compared to $1.21 billion in fiscal year 2022.

[0000950170-23-025324:8k_2_02:34]
•
Share repurchase and dividends: Returned $1.28 billion to shareholders through share repurchases and cash dividends.

[0000950170-23-025324:8k_2_02:35]
First quarter of fiscal year 2024 financial outlook

[0000950170-23-025324:8k_2_02:36]
The Company provided the following financial guidance for the first quarter of fiscal year 2024:

[0000950170-23-025324:8k_2_02:37]
| Net revenues are expected to be in the range of: | $1.325 billion to $1.475 billion |

[0000950170-23-025324:8k_2_02:38]
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $0.62 - $0.72 | $1.00 - $1.10 |

[0000950170-23-025324:8k_2_02:39]
Full fiscal year 2024 financial outlook

[0000950170-23-025324:8k_2_02:40]
The Company provided the following financial guidance for the full fiscal year 2024:

[0000950170-23-025324:8k_2_02:41]
| Net revenues are expected to be down year-over-year in the low-to-mid single digits on a percentage basis |  |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be: | ~69% | ~70% |
| Operating margins are expected to be: | ~18% | ~25% |
| Earnings per share is expected to be: | $3.98 - $4.18 | $5.65 - $5.85 |

[0000950170-23-025324:8k_2_02:42]
Dividend

[0000950170-23-025324:8k_2_02:43]
The next cash dividend of $0.50 per share is to be paid on July 26, 2023, to shareholders of record as of the close of business on July 7, 2023.

[0000950170-23-025324:8k_2_02:44]
Fourth quarter of fiscal year 2023 business highlights

[0000950170-23-025324:8k_2_02:45]
Leading product innovation

[0000950170-23-025324:8k_2_02:46]
•
NetApp strengthens its industry-leading flash portfolio with the announcement of the availability of the NetApp AFF C-Series, a new family of capacity flash storage options that delivers lower-cost all-flash storage, and the NetApp AFF A150, a new entry-level storage system in the AFF A-Series family of all-flash systems.

[0000950170-23-025324:8k_2_02:47]
•
NetApp launched ONTAPTM One, the industry’s most comprehensive data management suite, giving customers access to comprehensive NetApp ONTAP software for NetApp AFF C-series, including anti-ransomware, data protection, and security/compliance functionality.

[0000950170-23-025324:8k_2_02:48]
•
NetApp launched NetApp Advance, a new portfolio of storage programs and guarantees to help customers cost-effectively future proof on-premises environments, including the NetApp Storage Lifecycle Program, which offers customers enterprise storage that includes non-disruptive controller refresh, at no additional cost, with the option to flexibly scale to Keystone Storage-as-a-Service and/or public cloud.

[0000950170-23-025324:8k_2_02:49]
•
NetApp announced the preview of a new sustainability SLA for NetApp KeystoneTM, which will provide a standard watts/TB for each SLA-based performance level, with service credits available if those targets aren’t met.

[0000950170-23-025324:8k_2_02:50]
•
NetApp announced that it is now previewing the BlueXPTMSustainability Dashboard, which will help customers understand their data center’s carbon footprint across environments.

[0000950170-23-025324:8k_2_02:51]
•
Spot by NetApp announced that Ocean for Apache Spark is now available to all customers within the Spot console.

[0000950170-23-025324:8k_2_02:52]
•
To address new cloud product silos, ad hoc scripting for optimization and scale, and manual maintenance of cloud operations, Fylamynt (acquired by NetApp in 2022) has been revamped to become Spot Connect, available for private preview.

[0000950170-23-025324:8k_2_02:53]
•
Spot by NetApp announced its latest innovation for Spot Security, a machine learning model that detects anomalous events.

[0000950170-23-025324:8k_2_02:54]
Customer and partner momentum

[0000950170-23-025324:8k_2_02:55]
•
NetApp announced the general availability of NetApp Cloud Volumes Service as datastores for Google Cloud VMware Engine, giving customers the ability to easily scale and protect virtual machine (VM) data by using NetApp ONTAP data management software with a fully managed service in Google Cloud.

[0000950170-23-025324:8k_2_02:56]
•
Spot by NetApp announced the general availability of Azure Stateful Node. With Azure Stateful Node, Spot by NetApp customers can now run their stateful compute workloads on Azure with up to 90% immediate cost reduction and maximum availability.

[0000950170-23-025324:8k_2_02:57]
•
SAS, a global analytics leader, chose NetApp AstraTM to provide a disaster recovery solution for its SAS Viya offerings deployed as a hosted managed service in the SAS Cloud on Microsoft Azure.

[0000950170-23-025324:8k_2_02:58]
•
NetApp CloudCheckr has achieved the AWS Cloud Operations Competency in the categories of Cloud Financial Management and Compliance and Auditing.

[0000950170-23-025324:8k_2_02:59]
Corporate news and events

[0000950170-23-025324:8k_2_02:60]
•
NetApp released the 2023 Cloud Complexity Report, a global survey exploring how technology decision makers are navigating cloud requirements coming from digital transformation and AI initiatives and the complexity of multicloud environments.

[0000950170-23-025324:8k_2_02:61]
•
Spot by NetApp published the report DevOps Revealed: Insights and trends driving DevOps productivity and job satisfaction.

[0000950170-23-025324:8k_2_02:62]
NetApp awards and recognition

[0000950170-23-025324:8k_2_02:63]
•
NetApp was recognized by GigaOm for three Outperformer placements in their annual GigaOm Radar reports for storage.

[0000950170-23-025324:8k_2_02:64]
•
NetApp was listed as one of CRN’s 50 Coolest Data Center Companies of 2023.

[0000950170-23-025324:8k_2_02:65]
•
NetApp was listed as one of CRN’s Coolest Software-Defined Storage Vendors of the 2023 Storage 100.

[0000950170-23-025324:8k_2_02:66]
•
NetApp was listed as one of CRN’s Coolest Big Data System and Cloud Platform Companies of the 2023 Big Data 100.

[0000950170-23-025324:8k_2_02:67]
•
NetApp’s Jenni Flinders, SVP of NetApp Partner Programs, was listed as one of 50 of CRN’s 2023 Most Influential Channel Chiefs.

[0000950170-23-025324:8k_2_02:68]
•
NetApp’s Maya Zakhour, Director of Channel Sales Eastern Europe, META, Iberia, & Latin America, won the Woman Executive of the Year Award at CPI and Tahawultech’s Women in Technology Forum and Awards.

[0000950170-23-025324:8k_2_02:69]
Executive leadership announcements

[0000950170-23-025324:8k_2_02:70]
•
NetApp hired Haiyan Song as Executive Vice President and General Manager of CloudOps Business.

[0000950170-23-025324:8k_2_02:71]
•
NetApp hired Jim Lambe as Vice President and General Manager of NetApp Canada.

[0000950170-23-025324:8k_2_02:72]
Webcast and conference call information

[0000950170-23-025324:8k_2_02:73]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today.

[0000950170-23-025324:8k_2_02:74]
###

[0000950170-23-025324:8k_2_02:75]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0000950170-23-025324:8k_2_02:76]
Footnotes

[0000950170-23-025324:8k_2_02:77]
1Refer to the Constant Currency section below for an explanation of constant currency growth rates and the impact of foreign currency exchange rate changes on year-over-year fluctuations in earnings.

[0000950170-23-025324:8k_2_02:78]
2Refer to the NetApp Usage of Non-GAAP Financial Information section below for explanations of free cash flow and billings.

[0000950170-23-025324:8k_2_02:79]
3Public Cloud annualized revenue run rate (ARR) is calculated as the annualized value of all Public Cloud customer commitments with the assumption that any commitment expiring during the next 12 months will be renewed with its existing terms.

[0000950170-23-025324:8k_2_02:80]
4All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0000950170-23-025324:8k_2_02:81]
5Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) gains/losses on the sale of investments in equity securities, (i) debt extinguishment costs, and (j) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes that the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0000950170-23-025324:8k_2_02:82]
6GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0000950170-23-025324:8k_2_02:83]
NetApp usage of non-GAAP financial information

[0000950170-23-025324:8k_2_02:84]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share. NetApp also presents the hardware and software components of our GAAP product revenues. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and

[0000950170-23-025324:8k_2_02:85]
software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0000950170-23-025324:8k_2_02:86]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations.

[0000950170-23-025324:8k_2_02:87]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0000950170-23-025324:8k_2_02:88]
NetApp believes that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0000950170-23-025324:8k_2_02:89]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0000950170-23-025324:8k_2_02:90]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0000950170-23-025324:8k_2_02:91]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0000950170-23-025324:8k_2_02:92]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0000950170-23-025324:8k_2_02:93]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0000950170-23-025324:8k_2_02:94]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0000950170-23-025324:8k_2_02:95]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0000950170-23-025324:8k_2_02:96]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0000950170-23-025324:8k_2_02:97]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0000950170-23-025324:8k_2_02:98]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-23-025324:8k_2_02:99]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of

[0000950170-23-025324:8k_2_02:100]
the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-23-025324:8k_2_02:101]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-23-025324:8k_2_02:102]
J. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges or benefits resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0000950170-23-025324:8k_2_02:103]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0000950170-23-025324:8k_2_02:104]
Constant Currency

[0000950170-23-025324:8k_2_02:105]
NetApp presents certain constant currency growth rates or quantifies the impact of foreign currency exchange rate changes on year-over-year fluctuations, including for net revenues, billings, and earnings. This constant currency information assumes the same foreign currency exchange rates that were in effect for the comparable prior-year period were used in translation of the current period results.

[0000950170-23-025324:8k_2_02:106]
About NetApp

[0000950170-23-025324:8k_2_02:107]
NetApp is a global, cloud-led, data-centric software company that empowers organizations to lead with data in the age of accelerated digital transformation. The company provides systems, software, and cloud services that enable them to run their applications optimally from data center to cloud, whether they are developing in the cloud, moving to the cloud, or creating their own cloudlike experiences on premises. With solutions that perform across diverse environments, NetApp helps organizations build their own data fabric and securely deliver the right data, services, and applications to the right people—anytime, anywhere. Learn more at www.netapp.com or follow us on Twitter, LinkedIn, Facebook, and Instagram.

[0000950170-23-025324:8k_2_02:108]
NETAPP, INC.

[0000950170-23-025324:8k_2_02:109]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-23-025324:8k_2_02:110]
(In millions)

[0000950170-23-025324:8k_2_02:111]
(Unaudited)

[0000950170-23-025324:8k_2_02:112]
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,070 |  |  | $ | 4,134 |  |
| Accounts receivable |  |  | 987 |  |  |  | 1,230 |  |
| Inventories |  |  | 167 |  |  |  | 204 |  |
| Other current assets |  |  | 456 |  |  |  | 377 |  |
| Total current assets |  |  | 4,680 |  |  |  | 5,945 |  |
| Property and equipment, net |  |  | 650 |  |  |  | 602 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,940 |  |  |  | 2,488 |  |
| Other non-current assets |  |  | 1,548 |  |  |  | 991 |  |
| Total assets |  | $ | 9,818 |  |  | $ | 10,026 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 392 |  |  | $ | 607 |  |
| Accrued expenses |  |  | 857 |  |  |  | 925 |  |
| Current portion of long-term debt |  |  | — |  |  |  | 250 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 2,218 |  |  |  | 2,171 |  |
| Total current liabilities |  |  | 3,467 |  |  |  | 3,953 |  |
| Long-term debt |  |  | 2,389 |  |  |  | 2,386 |  |
| Other long-term liabilities |  |  | 708 |  |  |  | 788 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 2,095 |  |  |  | 2,061 |  |
| Total liabilities |  |  | 8,659 |  |  |  | 9,188 |  |
| Stockholders' equity |  |  | 1,159 |  |  |  | 838 |  |
| Total liabilities and stockholders' equity |  | $ | 9,818 |  |  | $ | 10,026 |  |

[0000950170-23-025324:8k_2_02:113]
NETAPP, INC.

[0000950170-23-025324:8k_2_02:114]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-23-025324:8k_2_02:115]
(In millions, except per share amounts)

[0000950170-23-025324:8k_2_02:116]
(Unaudited)

[0000950170-23-025324:8k_2_02:117]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 744 |  |  | $ | 894 |  |  | $ | 3,049 |  |  | $ | 3,284 |  |
| Services |  |  | 837 |  |  |  | 786 |  |  |  | 3,313 |  |  |  | 3,034 |  |
| Net revenues |  |  | 1,581 |  |  |  | 1,680 |  |  |  | 6,362 |  |  |  | 6,318 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 335 |  |  |  | 446 |  |  |  | 1,517 |  |  |  | 1,554 |  |
| Cost of services |  |  | 171 |  |  |  | 145 |  |  |  | 636 |  |  |  | 544 |  |
| Total cost of revenues |  |  | 506 |  |  |  | 591 |  |  |  | 2,153 |  |  |  | 2,098 |  |
| Gross profit |  |  | 1,075 |  |  |  | 1,089 |  |  |  | 4,209 |  |  |  | 4,220 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 442 |  |  |  | 480 |  |  |  | 1,829 |  |  |  | 1,857 |  |
| Research and development |  |  | 243 |  |  |  | 235 |  |  |  | 956 |  |  |  | 881 |  |
| General and administrative |  |  | 67 |  |  |  | 72 |  |  |  | 265 |  |  |  | 279 |  |
| Restructuring charges |  |  | 11 |  |  |  | 4 |  |  |  | 120 |  |  |  | 33 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 5 |  |  |  | 21 |  |  |  | 13 |  |
| Total operating expenses |  |  | 766 |  |  |  | 796 |  |  |  | 3,191 |  |  |  | 3,063 |  |
| Income from operations |  |  | 309 |  |  |  | 293 |  |  |  | 1,018 |  |  |  | 1,157 |  |
| Other income (expense), net |  |  | 5 |  |  |  | (21 | ) |  |  | 48 |  |  |  | (62 | ) |
| Income before income taxes |  |  | 314 |  |  |  | 272 |  |  |  | 1,066 |  |  |  | 1,095 |  |
| Provision (benefit) for income taxes |  |  | 69 |  |  |  | 13 |  |  |  | (208 | ) |  |  | 158 |  |
| Net income |  | $ | 245 |  |  | $ | 259 |  |  | $ | 1,274 |  |  | $ | 937 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.15 |  |  | $ | 1.17 |  |  | $ | 5.87 |  |  | $ | 4.20 |  |
| Diluted |  | $ | 1.13 |  |  | $ | 1.14 |  |  | $ | 5.79 |  |  | $ | 4.09 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 213 |  |  |  | 222 |  |  |  | 217 |  |  |  | 223 |  |
| Diluted |  |  | 217 |  |  |  | 228 |  |  |  | 220 |  |  |  | 229 |  |

[0000950170-23-025324:8k_2_02:118]
NETAPP, INC.

[0000950170-23-025324:8k_2_02:119]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-23-025324:8k_2_02:120]
(In millions)

[0000950170-23-025324:8k_2_02:121]
(Unaudited)

[0000950170-23-025324:8k_2_02:122]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 28, 2023 |  |  | April 29, 2022 |  |  | April 28, 2023 |  |  | April 29, 2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 245 |  |  | $ | 259 |  |  | $ | 1,274 |  |  | $ | 937 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 66 |  |  |  | 51 |  |  |  | 248 |  |  |  | 194 |  |
| Non-cash operating lease cost |  |  | 12 |  |  |  | 15 |  |  |  | 52 |  |  |  | 55 |  |
| Stock-based compensation |  |  | 74 |  |  |  | 66 |  |  |  | 312 |  |  |  | 245 |  |
| Deferred income taxes |  |  | (29 | ) |  |  | (78 | ) |  |  | (606 | ) |  |  | (144 | ) |
| Other items, net |  |  | 2 |  |  |  | (19 | ) |  |  | (67 | ) |  |  | (54 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (165 | ) |  |  | (450 | ) |  |  | 260 |  |  |  | (313 | ) |
| Inventories |  |  | 8 |  |  |  | (37 | ) |  |  | 37 |  |  |  | (90 | ) |
| Accounts payable |  |  | (34 | ) |  |  | 171 |  |  |  | (207 | ) |  |  | 181 |  |
| Accrued expenses |  |  | 14 |  |  |  | 96 |  |  |  | (103 | ) |  |  | (111 | ) |
| Deferred revenue and financed unearned services revenue |  |  | 93 |  |  |  | 338 |  |  |  | 46 |  |  |  | 384 |  |
| Long-term taxes payable |  |  | 6 |  |  |  | 21 |  |  |  | (76 | ) |  |  | (45 | ) |
| Changes in other operating assets and liabilities, net |  |  | (57 | ) |  |  | (22 | ) |  |  | (63 | ) |  |  | (28 | ) |
| Net cash provided by operating activities |  |  | 235 |  |  |  | 411 |  |  |  | 1,107 |  |  |  | 1,211 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| (Purchases) redemptions of investments, net |  |  | (245 | ) |  |  | 9 |  |  |  | (719 | ) |  |  | 45 |  |
| Purchases of property and equipment |  |  | (39 | ) |  |  | (68 | ) |  |  | (239 | ) |  |  | (226 | ) |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | (21 | ) |  |  | (491 | ) |  |  | (380 | ) |
| Other investing activities, net |  |  | (1 | ) |  |  | — |  |  |  | 59 |  |  |  | — |  |
| Net cash used in investing activities |  |  | (285 | ) |  |  | (80 | ) |  |  | (1,390 | ) |  |  | (561 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | — |  |  |  | — |  |  |  | 108 |  |  |  | 105 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (10 | ) |  |  | (5 | ) |  |  | (84 | ) |  |  | (74 | ) |
| Repurchase of common stock |  |  | (150 | ) |  |  | (250 | ) |  |  | (850 | ) |  |  | (600 | ) |
| Repayments and extinguishment of debt |  |  | — |  |  |  | — |  |  |  | (250 | ) |  |  | — |  |
| Dividends paid |  |  | (106 | ) |  |  | (111 | ) |  |  | (432 | ) |  |  | (446 | ) |
| Other financing activities, net |  |  | (3 | ) |  |  | — |  |  |  | (5 | ) |  |  | (2 | ) |
| Net cash used in financing activities |  |  | (269 | ) |  |  | (366 | ) |  |  | (1,513 | ) |  |  | (1,017 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (5 | ) |  |  | (23 | ) |  |  | (1 | ) |  |  | (49 | ) |
| Net change in cash, cash equivalents and restricted cash |  |  | (324 | ) |  |  | (58 | ) |  |  | (1,797 | ) |  |  | (416 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,646 |  |  |  | 4,177 |  |  |  | 4,119 |  |  |  | 4,535 |  |
| End of period |  | $ | 2,322 |  |  | $ | 4,119 |  |  | $ | 2,322 |  |  | $ | 4,119 |  |

[0000950170-23-025324:8k_2_02:123]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| Product |  | $ | 744 |  |  | $ | 682 |  |  | $ | 894 |  |  | $ | 3,049 |  |  | $ | 3,284 |  |
| Support |  |  | 598 |  |  |  | 616 |  |  |  | 590 |  |  |  | 2,419 |  |  |  | 2,344 |  |
| Professional and Other Services |  |  | 88 |  |  |  | 78 |  |  |  | 76 |  |  |  | 319 |  |  |  | 294 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,430 |  |  |  | 1,376 |  |  |  | 1,560 |  |  |  | 5,787 |  |  |  | 5,922 |  |
| Public Cloud Segment Net Revenues |  |  | 151 |  |  |  | 150 |  |  |  | 120 |  |  |  | 575 |  |  |  | 396 |  |
| Net Revenues |  | $ | 1,581 |  |  | $ | 1,526 |  |  | $ | 1,680 |  |  | $ | 6,362 |  |  | $ | 6,318 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| Product |  | $ | 410 |  |  | $ | 317 |  |  | $ | 452 |  |  | $ | 1,538 |  |  | $ | 1,743 |  |
| Support |  |  | 549 |  |  |  | 572 |  |  |  | 547 |  |  |  | 2,238 |  |  |  | 2,160 |  |
| Professional and Other Services |  |  | 33 |  |  |  | 28 |  |  |  | 22 |  |  |  | 108 |  |  |  | 89 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 992 |  |  |  | 917 |  |  |  | 1,021 |  |  |  | 3,884 |  |  |  | 3,992 |  |
| Public Cloud Segment Gross Profit |  |  | 99 |  |  |  | 103 |  |  |  | 82 |  |  |  | 391 |  |  |  | 278 |  |
| Total Segments Gross Profit |  |  | 1,091 |  |  |  | 1,020 |  |  |  | 1,103 |  |  |  | 4,275 |  |  |  | 4,270 |  |
| Amortization of Intangible Assets |  |  | (10 | ) |  |  | (11 | ) |  |  | (10 | ) |  |  | (42 | ) |  |  | (33 | ) |
| Stock-based Compensation |  |  | (6 | ) |  |  | (8 | ) |  |  | (4 | ) |  |  | (24 | ) |  |  | (17 | ) |
| Unallocated Cost of Revenues |  |  | (16 | ) |  |  | (19 | ) |  |  | (14 | ) |  |  | (66 | ) |  |  | (50 | ) |
| Gross Profit |  | $ | 1,075 |  |  | $ | 1,001 |  |  | $ | 1,089 |  |  | $ | 4,209 |  |  | $ | 4,220 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| Product |  |  | 55.1 | % |  |  | 46.5 | % |  |  | 50.6 | % |  |  | 50.4 | % |  |  | 53.1 | % |
| Support |  |  | 91.8 | % |  |  | 92.9 | % |  |  | 92.7 | % |  |  | 92.5 | % |  |  | 92.2 | % |
| Professional and Other Services |  |  | 37.5 | % |  |  | 35.9 | % |  |  | 28.9 | % |  |  | 33.9 | % |  |  | 30.3 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 69.4 | % |  |  | 66.6 | % |  |  | 65.4 | % |  |  | 67.1 | % |  |  | 67.4 | % |
| Public Cloud Segment Gross Margin |  |  | 65.6 | % |  |  | 68.7 | % |  |  | 68.3 | % |  |  | 68.0 | % |  |  | 70.2 | % |
| Product Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| Total |  | $ | 744 |  |  | $ | 682 |  |  | $ | 894 |  |  | $ | 3,049 |  |  | $ | 3,284 |  |
| Software* |  | $ | 437 |  |  | $ | 390 |  |  | $ | 530 |  |  | $ | 1,798 |  |  | $ | 1,926 |  |
| Hardware* |  | $ | 307 |  |  | $ | 292 |  |  | $ | 364 |  |  | $ | 1,251 |  |  | $ | 1,358 |  |
| Software and recurring support and public cloud revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| Product - Software |  | $ | 437 |  |  | $ | 390 |  |  | $ | 530 |  |  | $ | 1,798 |  |  | $ | 1,926 |  |
| Support |  |  | 598 |  |  |  | 616 |  |  |  | 590 |  |  |  | 2,419 |  |  |  | 2,344 |  |
| Public Cloud |  |  | 151 |  |  |  | 150 |  |  |  | 120 |  |  |  | 575 |  |  |  | 396 |  |
| Software and recurring support and public cloud revenue* |  | $ | 1,186 |  |  | $ | 1,156 |  |  | $ | 1,240 |  |  | $ | 4,792 |  |  | $ | 4,666 |  |
| Software and recurring support and public cloud revenue as a percentage of net revenues |  |  | 75 | % |  |  | 76 | % |  |  | 74 | % |  |  | 75 | % |  |  | 74 | % |
| * Our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation. We have provided a breakdown of our GAAP product revenues into the software and hardware components, which are considered non-GAAP measures, to display the significance of software included in total product revenues. Software and recurring support and public cloud revenue is a non-GAAP measure because it includes the software component of our product revenues, but not the hardware component. |  |

[0000950170-23-025324:8k_2_02:124]
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'23 |  |  | % of Q3 FY'23 |  |  | % of Q4 FY'22 |  |  | % of FY 2023 |  |  | % of FY 2022 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 52 | % |  |  | 54 | % |  |  | 54 | % |  |  | 53 | % |  |  | 55 | % |
| Americas Commercial |  |  | 42 | % |  |  | 44 | % |  |  | 45 | % |  |  | 42 | % |  |  | 45 | % |
| U.S. Public Sector |  |  | 10 | % |  |  | 10 | % |  |  | 9 | % |  |  | 11 | % |  |  | 10 | % |
| EMEA |  |  | 34 | % |  |  | 32 | % |  |  | 32 | % |  |  | 33 | % |  |  | 31 | % |
| Asia Pacific |  |  | 14 | % |  |  | 14 | % |  |  | 14 | % |  |  | 14 | % |  |  | 14 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'23 |  |  | % of Q3 FY'23 |  |  | % of Q4 FY'22 |  |  | % of FY 2023 |  |  | % of FY 2022 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 22 | % |  |  | 22 | % |  |  | 24 | % |  |  | 22 | % |  |  | 23 | % |
| Indirect |  |  | 78 | % |  |  | 78 | % |  |  | 76 | % |  |  | 78 | % |  |  | 77 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| Non-GAAP Income from Operations |  | $ | 414 |  |  | $ | 372 |  |  | $ | 382 |  |  | $ | 1,539 |  |  | $ | 1,496 |  |
| % of Net Revenues |  |  | 26.2 | % |  |  | 24.4 | % |  |  | 22.7 | % |  |  | 24.2 | % |  |  | 23.7 | % |
| Non-GAAP Income before Income Taxes |  | $ | 419 |  |  | $ | 377 |  |  | $ | 361 |  |  | $ | 1,555 |  |  | $ | 1,434 |  |
| Non-GAAP Effective Tax Rate |  |  | 20.3 | % |  |  | 20.2 | % |  |  | 10.2 | % |  |  | 20.9 | % |  |  | 15.7 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| Non-GAAP Net Income |  | $ | 334 |  |  | $ | 301 |  |  | $ | 324 |  |  | $ | 1,230 |  |  | $ | 1,209 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 217 |  |  |  | 219 |  |  |  | 228 |  |  |  | 220 |  |  |  | 229 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.54 |  |  | $ | 1.37 |  |  | $ | 1.42 |  |  | $ | 5.59 |  |  | $ | 5.28 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  |  |  |  |  |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 4,313 |  |  | $ | 4,216 |  |  | $ | 4,232 |  |  |  |  |  |  |  |
| DSO (days) |  |  | 57 |  |  |  | 49 |  |  |  | 67 |  |  |  |  |  |  |  |
| DPO (days) |  |  | 70 |  |  |  | 75 |  |  |  | 93 |  |  |  |  |  |  |  |
| Inventory Turns |  |  | 12 |  |  |  | 12 |  |  |  | 12 |  |  |  |  |  |  |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| Net Cash Provided by Operating Activities |  | $ | 235 |  |  | $ | 377 |  |  | $ | 411 |  |  | $ | 1,107 |  |  | $ | 1,211 |  |
| Purchases of Property and Equipment |  | $ | 39 |  |  | $ | 58 |  |  | $ | 68 |  |  | $ | 239 |  |  | $ | 226 |  |
| Free Cash Flow |  | $ | 196 |  |  | $ | 319 |  |  | $ | 343 |  |  | $ | 868 |  |  | $ | 985 |  |
| Free Cash Flow as % of Net Revenues |  |  | 12.4 | % |  |  | 20.9 | % |  |  | 20.4 | % |  |  | 13.6 | % |  |  | 15.6 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |

[0000950170-23-025324:8k_2_02:125]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| NET INCOME |  | $ | 245 |  |  | $ | 65 |  |  | $ | 259 |  |  | $ | 1,274 |  |  | $ | 937 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 17 |  |  |  | 17 |  |  |  | 14 |  |  |  | 68 |  |  |  | 46 |  |
| Stock-based compensation |  |  | 74 |  |  |  | 93 |  |  |  | 66 |  |  |  | 312 |  |  |  | 245 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2 |  |
| Restructuring charges |  |  | 11 |  |  |  | 87 |  |  |  | 4 |  |  |  | 120 |  |  |  | 33 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 3 |  |  |  | 5 |  |  |  | 21 |  |  |  | 13 |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (32 | ) |  |  | — |  |
| Income tax effects |  |  | 11 |  |  |  | (33 | ) |  |  | (24 | ) |  |  | (51 | ) |  |  | (68 | ) |
| Income tax (benefits) expenses from integration of acquired companies |  |  | (27 | ) |  |  | — |  |  |  | — |  |  |  | (27 | ) |  |  | 1 |  |
| Resolution of income tax matters |  |  | — |  |  |  | 69 |  |  |  | — |  |  |  | 69 |  |  |  | — |  |
| Income tax benefit from intra-entity intellectual property transfer |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (524 | ) |  |  | — |  |
| NON-GAAP NET INCOME |  | $ | 334 |  |  | $ | 301 |  |  | $ | 324 |  |  | $ | 1,230 |  |  | $ | 1,209 |  |
| COST OF REVENUES |  | $ | 506 |  |  | $ | 525 |  |  | $ | 591 |  |  | $ | 2,153 |  |  | $ | 2,098 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (11 | ) |  |  | (10 | ) |  |  | (42 | ) |  |  | (33 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (8 | ) |  |  | (4 | ) |  |  | (24 | ) |  |  | (17 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 490 |  |  | $ | 506 |  |  | $ | 577 |  |  | $ | 2,087 |  |  | $ | 2,048 |  |
| COST OF PRODUCT REVENUES |  | $ | 335 |  |  | $ | 367 |  |  | $ | 446 |  |  | $ | 1,517 |  |  | $ | 1,554 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | — |  |  |  | (3 | ) |  |  | (1 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (2 | ) |  |  | (1 | ) |  |  | (5 | ) |  |  | (4 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 334 |  |  | $ | 365 |  |  | $ | 442 |  |  | $ | 1,511 |  |  | $ | 1,541 |  |
| COST OF SERVICES REVENUES |  | $ | 171 |  |  | $ | 158 |  |  | $ | 145 |  |  | $ | 636 |  |  | $ | 544 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (11 | ) |  |  | (7 | ) |  |  | (41 | ) |  |  | (24 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (6 | ) |  |  | (3 | ) |  |  | (19 | ) |  |  | (13 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 156 |  |  | $ | 141 |  |  | $ | 135 |  |  | $ | 576 |  |  | $ | 507 |  |
| GROSS PROFIT |  | $ | 1,075 |  |  | $ | 1,001 |  |  | $ | 1,089 |  |  | $ | 4,209 |  |  | $ | 4,220 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 10 |  |  |  | 11 |  |  |  | 10 |  |  |  | 42 |  |  |  | 33 |  |
| Stock-based compensation |  |  | 6 |  |  |  | 8 |  |  |  | 4 |  |  |  | 24 |  |  |  | 17 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,091 |  |  | $ | 1,020 |  |  | $ | 1,103 |  |  | $ | 4,275 |  |  | $ | 4,270 |  |

[0000950170-23-025324:8k_2_02:126]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| SALES AND MARKETING EXPENSES |  | $ | 442 |  |  | $ | 450 |  |  | $ | 480 |  |  | $ | 1,829 |  |  | $ | 1,857 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (6 | ) |  |  | (4 | ) |  |  | (26 | ) |  |  | (13 | ) |
| Stock-based compensation |  |  | (32 | ) |  |  | (40 | ) |  |  | (30 | ) |  |  | (135 | ) |  |  | (115 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 403 |  |  | $ | 404 |  |  | $ | 446 |  |  | $ | 1,668 |  |  | $ | 1,729 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 243 |  |  | $ | 230 |  |  | $ | 235 |  |  | $ | 956 |  |  | $ | 881 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (29 | ) |  |  | (32 | ) |  |  | (22 | ) |  |  | (111 | ) |  |  | (75 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 214 |  |  | $ | 198 |  |  | $ | 213 |  |  | $ | 845 |  |  | $ | 806 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 67 |  |  | $ | 59 |  |  | $ | 72 |  |  | $ | 265 |  |  | $ | 279 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (7 | ) |  |  | (13 | ) |  |  | (10 | ) |  |  | (42 | ) |  |  | (38 | ) |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 60 |  |  | $ | 46 |  |  | $ | 62 |  |  | $ | 223 |  |  | $ | 239 |  |
| RESTRUCTURING CHARGES |  | $ | 11 |  |  | $ | 87 |  |  | $ | 4 |  |  | $ | 120 |  |  | $ | 33 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (11 | ) |  |  | (87 | ) |  |  | (4 | ) |  |  | (120 | ) |  |  | (33 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 3 |  |  | $ | 3 |  |  | $ | 5 |  |  | $ | 21 |  |  | $ | 13 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (3 | ) |  |  | (3 | ) |  |  | (5 | ) |  |  | (21 | ) |  |  | (13 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 766 |  |  | $ | 829 |  |  | $ | 796 |  |  | $ | 3,191 |  |  | $ | 3,063 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (6 | ) |  |  | (4 | ) |  |  | (26 | ) |  |  | (13 | ) |
| Stock-based compensation |  |  | (68 | ) |  |  | (85 | ) |  |  | (62 | ) |  |  | (288 | ) |  |  | (228 | ) |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2 | ) |
| Restructuring charges |  |  | (11 | ) |  |  | (87 | ) |  |  | (4 | ) |  |  | (120 | ) |  |  | (33 | ) |
| Acquisition-related expense |  |  | (3 | ) |  |  | (3 | ) |  |  | (5 | ) |  |  | (21 | ) |  |  | (13 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 677 |  |  | $ | 648 |  |  | $ | 721 |  |  | $ | 2,736 |  |  | $ | 2,774 |  |

[0000950170-23-025324:8k_2_02:127]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| INCOME FROM OPERATIONS |  | $ | 309 |  |  | $ | 172 |  |  | $ | 293 |  |  | $ | 1,018 |  |  | $ | 1,157 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 17 |  |  |  | 17 |  |  |  | 14 |  |  |  | 68 |  |  |  | 46 |  |
| Stock-based compensation |  |  | 74 |  |  |  | 93 |  |  |  | 66 |  |  |  | 312 |  |  |  | 245 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2 |  |
| Restructuring charges |  |  | 11 |  |  |  | 87 |  |  |  | 4 |  |  |  | 120 |  |  |  | 33 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 3 |  |  |  | 5 |  |  |  | 21 |  |  |  | 13 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 414 |  |  | $ | 372 |  |  | $ | 382 |  |  | $ | 1,539 |  |  | $ | 1,496 |  |
| OTHER INCOME (EXPENSE), NET |  | $ | 5 |  |  | $ | 5 |  |  | $ | (21 | ) |  | $ | 48 |  |  | $ | (62 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (32 | ) |  |  | — |  |
| NON-GAAP OTHER INCOME (EXPENSE), NET |  | $ | 5 |  |  | $ | 5 |  |  | $ | (21 | ) |  | $ | 16 |  |  | $ | (62 | ) |
| INCOME BEFORE INCOME TAXES |  | $ | 314 |  |  | $ | 177 |  |  | $ | 272 |  |  | $ | 1,066 |  |  | $ | 1,095 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 17 |  |  |  | 17 |  |  |  | 14 |  |  |  | 68 |  |  |  | 46 |  |
| Stock-based compensation |  |  | 74 |  |  |  | 93 |  |  |  | 66 |  |  |  | 312 |  |  |  | 245 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2 |  |
| Restructuring charges |  |  | 11 |  |  |  | 87 |  |  |  | 4 |  |  |  | 120 |  |  |  | 33 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 3 |  |  |  | 5 |  |  |  | 21 |  |  |  | 13 |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (32 | ) |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 419 |  |  | $ | 377 |  |  | $ | 361 |  |  | $ | 1,555 |  |  | $ | 1,434 |  |
| PROVISION (BENEFIT) FOR INCOME TAXES |  | $ | 69 |  |  | $ | 112 |  |  | $ | 13 |  |  | $ | (208 | ) |  | $ | 158 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | (11 | ) |  |  | 33 |  |  |  | 24 |  |  |  | 51 |  |  |  | 68 |  |
| Income tax benefits (expenses) from integration of acquired companies |  |  | 27 |  |  |  | — |  |  |  | — |  |  |  | 27 |  |  |  | (1 | ) |
| Resolution of income tax matters |  |  | — |  |  |  | (69 | ) |  |  | — |  |  |  | (69 | ) |  |  | — |  |
| Income tax benefit from intra-entity intellectual property transfer |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 524 |  |  |  | — |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 85 |  |  | $ | 76 |  |  | $ | 37 |  |  | $ | 325 |  |  | $ | 225 |  |
| NET INCOME PER SHARE |  | $ | 1.13 |  |  | $ | 0.30 |  |  | $ | 1.14 |  |  | $ | 5.79 |  |  | $ | 4.09 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.08 |  |  |  | 0.08 |  |  |  | 0.06 |  |  |  | 0.31 |  |  |  | 0.20 |  |
| Stock-based compensation |  |  | 0.34 |  |  |  | 0.42 |  |  |  | 0.29 |  |  |  | 1.42 |  |  |  | 1.07 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.01 |  |
| Restructuring charges |  |  | 0.05 |  |  |  | 0.40 |  |  |  | 0.02 |  |  |  | 0.55 |  |  |  | 0.14 |  |
| Acquisition-related expense |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.02 |  |  |  | 0.10 |  |  |  | 0.06 |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.15 | ) |  |  | — |  |
| Income tax effects |  |  | 0.05 |  |  |  | (0.15 | ) |  |  | (0.11 | ) |  |  | (0.23 | ) |  |  | (0.30 | ) |
| Income tax (benefits) expenses from integration of acquired companies |  |  | (0.12 | ) |  |  | — |  |  |  | — |  |  |  | (0.12 | ) |  |  | — |  |
| Resolution of income tax matters |  |  | — |  |  |  | 0.32 |  |  |  | — |  |  |  | 0.31 |  |  |  | — |  |
| Income tax benefit from intra-entity intellectual property transfer |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2.38 | ) |  |  | — |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.54 |  |  | $ | 1.37 |  |  | $ | 1.42 |  |  | $ | 5.59 |  |  | $ | 5.28 |  |

[0000950170-23-025324:8k_2_02:128]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| Gross margin-GAAP |  |  | 68.0 | % |  |  | 65.6 | % |  |  | 64.8 | % |  |  | 66.2 | % |  |  | 66.8 | % |
| Cost of revenues adjustments |  |  | 1.0 | % |  |  | 1.2 | % |  |  | 0.8 | % |  |  | 1.0 | % |  |  | 0.8 | % |
| Gross margin-Non-GAAP |  |  | 69.0 | % |  |  | 66.8 | % |  |  | 65.7 | % |  |  | 67.2 | % |  |  | 67.6 | % |
| GAAP cost of revenues |  | $ | 506 |  |  | $ | 525 |  |  | $ | 591 |  |  | $ | 2,153 |  |  | $ | 2,098 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (11 | ) |  |  | (10 | ) |  |  | (42 | ) |  |  | (33 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (8 | ) |  |  | (4 | ) |  |  | (24 | ) |  |  | (17 | ) |
| Non-GAAP cost of revenues |  | $ | 490 |  |  | $ | 506 |  |  | $ | 577 |  |  | $ | 2,087 |  |  | $ | 2,048 |  |
| Net revenues |  | $ | 1,581 |  |  | $ | 1,526 |  |  | $ | 1,680 |  |  | $ | 6,362 |  |  | $ | 6,318 |  |

[0000950170-23-025324:8k_2_02:129]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| Product gross margin-GAAP |  |  | 55.0 | % |  |  | 46.2 | % |  |  | 50.1 | % |  |  | 50.2 | % |  |  | 52.7 | % |
| Cost of product revenues adjustments |  |  | 0.1 | % |  |  | 0.3 | % |  |  | 0.4 | % |  |  | 0.2 | % |  |  | 0.4 | % |
| Product gross margin-Non-GAAP |  |  | 55.1 | % |  |  | 46.5 | % |  |  | 50.6 | % |  |  | 50.4 | % |  |  | 53.1 | % |
| GAAP cost of product revenues |  | $ | 335 |  |  | $ | 367 |  |  | $ | 446 |  |  | $ | 1,517 |  |  | $ | 1,554 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | — |  |  |  | (3 | ) |  |  | (1 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (2 | ) |  |  | (1 | ) |  |  | (5 | ) |  |  | (4 | ) |
| Non-GAAP cost of product revenues |  | $ | 334 |  |  | $ | 365 |  |  | $ | 442 |  |  | $ | 1,511 |  |  | $ | 1,541 |  |
| Product revenues |  | $ | 744 |  |  | $ | 682 |  |  | $ | 894 |  |  | $ | 3,049 |  |  | $ | 3,284 |  |

[0000950170-23-025324:8k_2_02:130]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| Services gross margin-GAAP |  |  | 79.6 | % |  |  | 81.3 | % |  |  | 81.6 | % |  |  | 80.8 | % |  |  | 82.1 | % |
| Cost of services revenues adjustments |  |  | 1.8 | % |  |  | 2.0 | % |  |  | 1.3 | % |  |  | 1.8 | % |  |  | 1.2 | % |
| Services gross margin-Non-GAAP |  |  | 81.4 | % |  |  | 83.3 | % |  |  | 82.8 | % |  |  | 82.6 | % |  |  | 83.3 | % |
| GAAP cost of services revenues |  | $ | 171 |  |  | $ | 158 |  |  | $ | 145 |  |  | $ | 636 |  |  | $ | 544 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (11 | ) |  |  | (7 | ) |  |  | (41 | ) |  |  | (24 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (6 | ) |  |  | (3 | ) |  |  | (19 | ) |  |  | (13 | ) |
| Non-GAAP cost of services revenues |  | $ | 156 |  |  | $ | 141 |  |  | $ | 135 |  |  | $ | 576 |  |  | $ | 507 |  |
| Services revenues |  | $ | 837 |  |  | $ | 844 |  |  | $ | 786 |  |  | $ | 3,313 |  |  | $ | 3,034 |  |

[0000950170-23-025324:8k_2_02:131]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| GAAP effective tax rate |  |  | 22.0 | % |  |  | 63.3 | % |  |  | 4.8 | % |  |  | (19.5 | )% |  |  | 14.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | (10.3 | )% |  |  | (4.1 | )% |  |  | 5.5 | % |  |  | (4.8 | )% |  |  | 1.4 | % |
| Income tax benefits (expenses) from integration of acquired companies |  |  | 8.6 | % |  |  | — | % |  |  | — | % |  |  | 2.5 | % |  |  | (0.1 | )% |
| Resolution of income tax matters |  |  | — | % |  |  | (39.0 | )% |  |  | — | % |  |  | (6.5 | )% |  |  | — | % |
| Income tax benefit from intra-entity intellectual property transfer |  |  | — | % |  |  | — | % |  |  | — | % |  |  | 49.2 | % |  |  | — | % |
| Non-GAAP effective tax rate |  |  | 20.3 | % |  |  | 20.2 | % |  |  | 10.2 | % |  |  | 20.9 | % |  |  | 15.7 | % |

[0000950170-23-025324:8k_2_02:132]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| Net cash provided by operating activities |  | $ | 235 |  |  | $ | 377 |  |  | $ | 411 |  |  | $ | 1,107 |  |  | $ | 1,211 |  |
| Purchases of property and equipment |  |  | (39 | ) |  |  | (58 | ) |  |  | (68 | ) |  |  | (239 | ) |  |  | (226 | ) |
| Free cash flow |  | $ | 196 |  |  | $ | 319 |  |  | $ | 343 |  |  | $ | 868 |  |  | $ | 985 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q4'FY23 |  |  | Q3'FY23 |  |  | Q4'FY22 |  |  | FY2023 |  |  | FY2022 |  |
| Net revenues |  | $ | 1,581 |  |  | $ | 1,526 |  |  | $ | 1,680 |  |  | $ | 6,362 |  |  | $ | 6,318 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | 93 |  |  |  | 46 |  |  |  | 338 |  |  |  | 46 |  |  |  | 384 |  |
| Billings |  | $ | 1,674 |  |  | $ | 1,572 |  |  | $ | 2,018 |  |  | $ | 6,408 |  |  | $ | 6,702 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0000950170-23-025324:8k_2_02:133]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FIRST QUARTER FISCAL 2024 |
|  |  | First Quarter |
|  |  | Fiscal 2024 |
| Non-GAAP Guidance - Net Income Per Share |  | $1.00-$1.10 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the First Quarter Fiscal 2024: |  |  |
| Amortization of intangible assets |  | ($0.07) |
| Stock-based compensation expense |  | ($0.39) |
| Income tax effects |  | $0.08 |
| Total Adjustments |  | ($0.38) |
| GAAP Guidance - Net Income Per Share |  | $0.62-$0.72 |

[0000950170-23-025324:8k_2_02:134]
Some items may not add or recalculate due to rounding.

[0000950170-23-025324:8k_2_02:135]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| Fiscal 2024 |
|  |  | Fiscal 2024 |
| Gross Margin - Non-GAAP Guidance |  | ~70% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | (1)% |
| Gross Margin - GAAP Guidance |  | ~69% |
|  |  | Fiscal 2024 |
| Operating Margin - Non-GAAP Guidance |  | ~25% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | (1)% |
| Stock-based compensation expense |  | (6)% |
| Operating Margin - GAAP Guidance |  | ~18% |

[0000950170-23-025324:8k_2_02:136]
Some items may not add or recalculate due to rounding.

[0000950170-23-025324:8k_2_02:137]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| Fiscal 2024 |
|  |  | Fiscal 2024 |
| Non-GAAP Guidance - Net Income Per Share |  | $5.65-$5.85 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2024: |  |  |
| Amortization of intangible assets |  | ($0.27) |
| Stock-based compensation expense |  | ($1.70) |
| Income tax effects |  | $0.30 |
| Total Adjustments |  | ($1.67) |
| GAAP Guidance - Net Income Per Share |  | $3.98-$4.18 |

[0000950170-23-025324:8k_2_02:138]
Some items may not add or recalculate due to rounding.

[0000950170-23-025324:8k_2_02:139]
Contacts:

[0000950170-23-025324:8k_2_02:140]
(Press)

[0000950170-23-025324:8k_2_02:141]
Chris Drago

[0000950170-23-025324:8k_2_02:142]
1 831 900 8889

[0000950170-23-025324:8k_2_02:143]
chris.drago@netapp.com

[0000950170-23-025324:8k_2_02:144]
(Investors)

[0000950170-23-025324:8k_2_02:145]
Kris Newton

[0000950170-23-025324:8k_2_02:146]
1 408 822 3312

[0000950170-23-025324:8k_2_02:147]
kris.newton@netapp.com

## item 1.01 — body, verbatim

[0000950170-23-025324:8k_body:1]
Item 1.01 Entry into a Material Definitive Agreement.

[0000950170-23-025324:8k_body:2]
The Board of Directors (the “Board”) of NetApp, Inc. (“NetApp” or the “Company”) approved a revised form indemnification agreement (the “Indemnification Agreement”) to be entered into between the Company and each of its directors and officers, effective May 26, 2023. The Indemnification Agreement supersedes the Company’s previous form of indemnification agreement.

[0000950170-23-025324:8k_body:3]
The Indemnification Agreement provides, among other things, that the Company will indemnify the director or officer (the “Indemnitee”) to the fullest extent permitted by law against all expenses and, in the case of proceedings other than those brought by or in the right of the Company, expenses, judgments, fines and amounts paid in settlement actually and reasonably incurred by or on the Indemnitee’s behalf, in each case, in connection with proceedings in which the Indemnitee is involved by reason of any action taken or failure to act while serving as a director or officer of the Company, or of another enterprise at the request of the Company, provided that the Indemnitee acted in good faith and in a manner he or she reasonably believed to be in or not opposed to the best interests of the Company. The Company will also indemnify the Indemnitee to the fullest extent permitted by law against all expenses actually and reasonably incurred by or on the Indemnitee’s behalf in connection with any such proceeding or defense, in whole or in part, to which the Indemnitee is a party or participant and in which the Indemnitee is successful.

[0000950170-23-025324:8k_body:4]
In addition, and subject to certain limitations, the Indemnification Agreement provides for the advancement of expenses incurred by the Indemnitee in connection with any proceeding not initiated by the Indemnitee (subject to limited exceptions), and the reimbursement to the Company of the amounts advanced (without interest) to the extent that it is ultimately determined that the Indemnitee is not entitled to be indemnified by the Company.

[0000950170-23-025324:8k_body:5]
The Indemnification Agreement does not exclude any other rights to indemnification or advancement of expenses to which the Indemnitee may be entitled, including any rights arising under applicable law, the Company’s Certificate of Incorporation or Bylaws, a vote of stockholders or a resolution of directors or otherwise. The Company’s indemnification obligations do not extend to payments that would be prohibited under Section 304 of the Sarbanes-Oxley Act of 2022, and Sections 954 and 306 of the Dodd-Frank Wall Street Reform and Consumer Protection Act.

[0000950170-23-025324:8k_body:6]
The foregoing description of the Indemnification Agreement does not purport to be complete and is qualified in its entirety by reference to the full text of the form of Indemnification Agreement, which is attached hereto as Exhibit 10.1 to this Current Report on Form 8-K and incorporated herein by reference.
