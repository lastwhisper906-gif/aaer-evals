# NTAP notes — 0000950170-25-029066


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000950170-25-029066:notes:1]
[same as prior period, unchanged from 0000950170-24-130551:notes:1]

[0000950170-25-029066:notes:2]
[same as prior period, unchanged from 0000950170-24-130551:notes:2]

[0000950170-25-029066:notes:3]
[same as prior period, unchanged from 0000950170-24-130551:notes:3]

[0000950170-25-029066:notes:4]
[same as prior period, unchanged from 0000950170-24-130551:notes:4]

[0000950170-25-029066:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 26, 2024 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 24, 2025 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0000950170-25-029066:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, the anticipated effects of which have been incorporated, as applicable, into management's estimates as of January 24, 2025.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000950170-25-029066:notes:7]
2. Recent Accounting Pronouncements

[0000950170-25-029066:notes:8]
In November 2024, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update ("ASU") 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires additional disclosure of the nature of expenses included in the income statement. The standard requires disclosures about specific types of expenses included in the expense captions presented in the income statement as well as disclosures about selling expenses. This ASU is effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027, with early adoption permitted. The requirements should be applied on a prospective basis while retrospective application is permitted. We are currently evaluating the effect of this pronouncement on our disclosures.

[0000950170-25-029066:notes:9]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which expands the disclosures required for income taxes. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The amendment should be applied on a prospective basis while retrospective application is permitted. We are currently evaluating the effect of this pronouncement on our income tax disclosures.

[0000950170-25-029066:notes:10]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires disclosure of incremental segment information on an annual and interim basis. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024 on a retrospective basis. We will adopt the new requirements for our annual periods starting in fiscal 2025 (and interim periods thereafter). We expect this pronouncement to result in enhanced financial statement disclosures only.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-25-029066:notes:11]
[same as prior period, unchanged from 0000950170-24-130551:notes:11]

[0000950170-25-029066:notes:12]
Goodwill by reportable segment as of January 24, 2025 is as follows (in millions):

[0000950170-25-029066:notes:13]
|  |  | Amount |  |
| Hybrid Cloud |  | $ | 1,714 |  |
| Public Cloud |  |  | 1,009 |  |
| Total goodwill |  | $ | 2,723 |  |

[0000950170-25-029066:notes:14]
During the third quarter of fiscal year 2025, we allocated a portion of the Public Cloud goodwill to the disposal group classified as held for sale. See section entitled "Assets and liabilities held for sale" contained in Note 4 – Supplemental Financial Information, for additional information related to this reclassification.

[0000950170-25-029066:notes:15]
[same as prior period, unchanged from 0000950170-24-130551:notes:14]

[0000950170-25-029066:notes:16]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 55 |  |  | $ | (30 | ) |  | $ | 25 |  |  | $ | 179 |  |  | $ | (108 | ) |  | $ | 71 |  |
| Customer contracts/relationships |  |  | 50 |  |  |  | (26 | ) |  |  | 24 |  |  |  | 114 |  |  |  | (62 | ) |  |  | 52 |  |
| Other purchased intangibles |  |  | 2 |  |  |  | (2 | ) |  |  | — |  |  |  | 6 |  |  |  | (5 | ) |  |  | 1 |  |
| Total purchased intangible assets |  | $ | 107 |  |  | $ | (58 | ) |  | $ | 49 |  |  | $ | 299 |  |  | $ | (175 | ) |  | $ | 124 |  |

[0000950170-25-029066:notes:17]
During the first nine months of fiscal 2025, we retired approximately $25 million of fully amortized intangible assets. During the third quarter of fiscal year 2025, we also reclassified certain intangible assets as held for sale. See section entitled "Assets and liabilities held for sale" contained in Note 4 – Supplemental Financial Information, for additional information related to this reclassification.

[0000950170-25-029066:notes:18]
[same as prior period, unchanged from 0000950170-24-130551:notes:17]

[0000950170-25-029066:notes:19]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Statements of |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | IncomeClassification |
| Developed technology |  | $ | 8 |  |  | $ | 9 |  |  | $ | 25 |  |  | $ | 26 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 5 |  |  |  | 5 |  |  |  | 16 |  |  |  | 16 |  |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1 |  |  | Operating expenses |
| Total |  | $ | 13 |  |  | $ | 14 |  |  | $ | 41 |  |  | $ | 43 |  |  |  |

[0000950170-25-029066:notes:20]
As of January 24, 2025, future amortization expense related to purchased intangible assets is as follows (in millions):

[0000950170-25-029066:notes:21]
| Fiscal Year |  | Amount |  |
| 2025 (remainder) |  | $ | 6 |  |
| 2026 |  |  | 21 |  |
| 2027 |  |  | 21 |  |
| 2028 |  |  | 1 |  |
| Total |  | $ | 49 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-25-029066:notes:22]
[same as prior period, unchanged from 0000950170-24-130551:notes:21]

[0000950170-25-029066:notes:23]
[same as prior period, unchanged from 0000950170-24-130551:notes:22]

[0000950170-25-029066:notes:24]
[same as prior period, unchanged from 0000950170-24-130551:notes:23]

[0000950170-25-029066:notes:25]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| Cash and cash equivalents |  | $ | 1,511 |  |  | $ | 1,903 |  |
| Restricted cash |  |  | 7 |  |  |  | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 1,518 |  |  | $ | 1,909 |  |

[0000950170-25-029066:notes:26]
[same as prior period, unchanged from 0000950170-24-130551:notes:25]

[0000950170-25-029066:notes:27]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| Purchased components |  | $ | 210 |  |  | $ | 116 |  |
| Finished goods |  |  | 58 |  |  |  | 70 |  |
| Inventories |  | $ | 268 |  |  | $ | 186 |  |

[0000950170-25-029066:notes:28]
[same as prior period, unchanged from 0000950170-24-130551:notes:27]

[0000950170-25-029066:notes:29]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 371 |  |  |  | 367 |  |
| Leasehold improvements |  |  | 101 |  |  |  | 81 |  |
| Computer, production, engineering and other equipment |  |  | 1,160 |  |  |  | 1,101 |  |
| Computer software |  |  | 326 |  |  |  | 340 |  |
| Furniture and fixtures |  |  | 67 |  |  |  | 77 |  |
| Construction-in-progress |  |  | 48 |  |  |  | 70 |  |
|  |  |  | 2,119 |  |  |  | 2,082 |  |
| Accumulated depreciation and amortization |  |  | (1,552 | ) |  |  | (1,478 | ) |
| Property and equipment, net |  | $ | 567 |  |  | $ | 604 |  |

[0000950170-25-029066:notes:30]
During the third quarter of fiscal year 2025, we reclassified certain property and equipment as held for sale. See section entitled “Assets and liabilities held for sale” contained in Note 4 – Supplemental Financial Information, for additional information related to this reclassification.

[0000950170-25-029066:notes:31]
[same as prior period, unchanged from 0000950170-24-130551:notes:29]

[0000950170-25-029066:notes:32]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| Deferred tax assets |  | $ | 1,005 |  |  | $ | 896 |  |
| Operating lease right-of-use (ROU) assets |  |  | 242 |  |  |  | 247 |  |
| Other assets |  |  | 411 |  |  |  | 360 |  |
| Other assets held for sale |  |  | 84 |  |  |  | — |  |
| Other non-current assets |  | $ | 1,742 |  |  | $ | 1,503 |  |

[0000950170-25-029066:notes:33]
Other non-current assets as of January 24, 2025 and April 26, 2024 include $89 million and $85 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies.

[0000950170-25-029066:notes:34]
[same as prior period, unchanged from 0000950170-24-130551:notes:32]

[0000950170-25-029066:notes:35]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| Accrued compensation and benefits |  | $ | 366 |  |  | $ | 538 |  |
| Product warranty liabilities |  |  | 19 |  |  |  | 18 |  |
| Operating lease liabilities |  |  | 41 |  |  |  | 40 |  |
| Other current liabilities |  |  | 505 |  |  |  | 417 |  |
| Other current liabilities held for sale |  |  | 10 |  |  |  | — |  |
| Accrued expenses |  | $ | 941 |  |  | $ | 1,013 |  |

[0000950170-25-029066:notes:36]
[same as prior period, unchanged from 0000950170-24-130551:notes:34]

[0000950170-25-029066:notes:37]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| Liability for uncertain tax positions |  | $ | 169 |  |  | $ | 153 |  |
| Income taxes payable |  |  | — |  |  |  | 100 |  |
| Product warranty liabilities |  |  | 9 |  |  |  | 9 |  |
| Operating lease liabilities |  |  | 215 |  |  |  | 220 |  |
| Other liabilities |  |  | 110 |  |  |  | 103 |  |
| Other long-term liabilities |  | $ | 503 |  |  | $ | 585 |  |

[0000950170-25-029066:notes:38]
[same as prior period, unchanged from 0000950170-24-130551:notes:36]

[0000950170-25-029066:notes:39]
[same as prior period, unchanged from 0000950170-24-130551:notes:37]

[0000950170-25-029066:notes:40]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| Deferred product revenue |  | $ | 54 |  |  | $ | 59 |  |
| Deferred services revenue |  |  | 4,028 |  |  |  | 4,123 |  |
| Financed unearned services revenue |  |  | 40 |  |  |  | 52 |  |
| Total |  | $ | 4,122 |  |  | $ | 4,234 |  |
| Reported as: |  |  |  |  |  |  |
| Short-term |  | $ | 2,070 |  |  | $ | 2,176 |  |
| Long-term |  |  | 2,052 |  |  |  | 2,058 |  |
| Total |  | $ | 4,122 |  |  | $ | 4,234 |  |

[0000950170-25-029066:notes:41]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 14 – Commitments and Contingencies for additional information related to these arrangements.

[0000950170-25-029066:notes:42]
During the nine months ended January 24, 2025 and January 26, 2024, we recognized revenue of $1,737 million and $1,725 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0000950170-25-029066:notes:43]
[same as prior period, unchanged from 0000950170-24-130551:notes:41]

[0000950170-25-029066:notes:44]
As of January 24, 2025, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $4.5 billion. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 49% of our remaining performance obligations in the next 12 months and the remainder thereafter.

[0000950170-25-029066:notes:45]
[same as prior period, unchanged from 0000950170-24-130551:notes:43]

[0000950170-25-029066:notes:46]
[same as prior period, unchanged from 0000950170-24-130551:notes:44]

[0000950170-25-029066:notes:47]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| Other current assets |  | $ | 66 |  |  | $ | 69 |  |
| Other non-current assets |  |  | 102 |  |  |  | 100 |  |
| Total deferred commissions |  | $ | 168 |  |  | $ | 169 |  |

[0000950170-25-029066:notes:48]
[same as prior period, unchanged from 0000950170-24-130551:notes:46]

[0000950170-25-029066:notes:49]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | January 24, 2025 |  |  | January 26, 2024 |  |
| Interest income |  | $ | 20 |  |  | $ | 27 |  |  | $ | 83 |  |  | $ | 80 |  |
| Interest expense |  |  | (12 | ) |  |  | (17 | ) |  |  | (43 | ) |  |  | (48 | ) |
| Other, net |  |  | — |  |  |  | 6 |  |  |  | — |  |  |  | 3 |  |
| Total other income, net |  | $ | 8 |  |  | $ | 16 |  |  | $ | 40 |  |  | $ | 35 |  |

[0000950170-25-029066:notes:50]
[same as prior period, unchanged from 0000950170-24-130551:notes:48]

[0000950170-25-029066:notes:51]
[same as prior period, unchanged from 0000950170-24-130551:notes:49]

[0000950170-25-029066:notes:52]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 10 |  |  | $ | 14 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 287 |  |  | $ | 294 |  |
| Interest paid |  | $ | 53 |  |  | $ | 53 |  |

[0000950170-25-029066:notes:53]
Assets and liabilities held for sale

[0000950170-25-029066:notes:54]
In January 2025, we and Flexera Software LLC (“Flexera”), entered a definitive agreement for the sale of our cloud optimization and management software business known as Spot by NetApp, which forms part of our Public Cloud reportable segment. Total sale consideration consists of (i) $70 million in up-front cash consideration; and (ii) up to $49 million in cash consideration contingent upon the achievement of certain financial performance metrics during the period from January 1, 2025 through December 31, 2025. We expect to close on the sale in the fourth quarter of fiscal 2025, subject to customary regulatory approvals and other closing conditions being met. Accordingly, as of January 24, 2025, the assets and liabilities to be conveyed to Flexera as part of the sale of the business have been classified as held for sale, presented within other non-current assets and accrued expenses, respectively, on the condensed consolidated balance sheets. We expect that any gain or loss recorded upon the closing of the transaction will be immaterial to the consolidated financial statements. The major classes of assets and liabilities included as part of the disposal group classified as held for sale as of January 24, 2025 are (in millions):

[0000950170-25-029066:notes:55]
|  |  | Amount |  |
| Assets: |  |  |  |
| Property and equipment, net |  | $ | 14 |  |
| Goodwill |  |  | 36 |  |
| Purchased intangible assets, net |  |  | 34 |  |
| Total Assets |  |  | 84 |  |
| Liabilities: |  |  |  |
| Accrued compensation and benefits |  |  | 8 |  |
| Short-term deferred revenue and financed unearned service revenue |  |  | 2 |  |
| Total Liabilities |  | $ | 10 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-25-029066:notes:56]
[same as prior period, unchanged from 0000950170-24-130551:notes:51]

[0000950170-25-029066:notes:57]
[same as prior period, unchanged from 0000950170-24-130551:notes:52]

[0000950170-25-029066:notes:58]
[same as prior period, unchanged from 0000950170-24-130551:notes:53]

[0000950170-25-029066:notes:59]
[same as prior period, unchanged from 0000950170-24-130551:notes:54]

[0000950170-25-029066:notes:60]
[same as prior period, unchanged from 0000950170-24-130551:notes:55]

[0000950170-25-029066:notes:61]
[same as prior period, unchanged from 0000950170-24-130551:notes:56]

[0000950170-25-029066:notes:62]
[same as prior period, unchanged from 0000950170-24-130551:notes:57]

[0000950170-25-029066:notes:63]
The following is a summary of our investments at their cost or amortized cost as of January 24, 2025 and April 26, 2024 (in millions):

[0000950170-25-029066:notes:64]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| U.S. Treasury and government debt securities |  | $ | 750 |  |  | $ | 1,349 |  |
| Money market funds |  |  | 780 |  |  |  | 1,161 |  |
| Certificates of deposit |  |  | 28 |  |  |  | 12 |  |
| Mutual funds |  |  | 44 |  |  |  | 38 |  |
| Total debt and equity securities |  | $ | 1,602 |  |  | $ | 2,560 |  |

[0000950170-25-029066:notes:65]
[same as prior period, unchanged from 0000950170-24-130551:notes:60]

[0000950170-25-029066:notes:66]
As of January 24, 2025, all our debt investments are due to mature in one year or less.

[0000950170-25-029066:notes:67]
[same as prior period, unchanged from 0000950170-24-130551:notes:62]

[0000950170-25-029066:notes:68]
[same as prior period, unchanged from 0000950170-24-130551:notes:63]

[0000950170-25-029066:notes:69]
|  |  | January 24, 2025 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 703 |  |  | $ | 703 |  |  | $ | — |  |
| Money market funds |  |  | 780 |  |  |  | 780 |  |  |  | — |  |
| Certificates of deposit |  |  | 28 |  |  |  | — |  |  |  | 28 |  |
| Total cash and cash equivalents |  |  | 1,511 |  |  |  | 1,483 |  |  |  | 28 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 750 |  |  |  | 750 |  |  |  | — |  |
| Total short-term investments |  |  | 750 |  |  |  | 750 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 2,261 |  |  | $ | 2,233 |  |  | $ | 28 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 37 |  |  | $ | 37 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000950170-25-029066:notes:70]
[same as prior period, unchanged from 0000950170-24-130551:notes:65]

[0000950170-25-029066:notes:71]
[same as prior period, unchanged from 0000950170-24-130551:notes:66]

[0000950170-25-029066:notes:72]
[same as prior period, unchanged from 0000950170-24-130551:notes:67]

[0000950170-25-029066:notes:73]
[same as prior period, unchanged from 0000950170-24-130551:notes:68]

[0000950170-25-029066:notes:74]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of January 24, 2025 and April 26, 2024, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0000950170-25-029066:notes:75]
[same as prior period, unchanged from 0000950170-24-130551:notes:70]

[0000950170-25-029066:notes:76]
As of January 24, 2025 and April 26, 2024, the fair value of our long-term debt, which includes the current portion of long-term debt, was approximately $1,877 million and $2,209 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0000950170-25-029066:notes:77]
6. Financing Arrangements

[0000950170-25-029066:notes:78]
Long-Term Debt

[0000950170-25-029066:notes:79]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0000950170-25-029066:notes:80]
|  |  | Effective Interest Rate |  | January 24, 2025 |  |  | April 26, 2024 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  | $ | — |  |  | $ | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,000 |  |  |  | 2,400 |  |
| Unamortized discount and issuance costs |  |  |  |  | (6 | ) |  |  | (8 | ) |
| Total senior notes |  |  |  |  | 1,994 |  |  |  | 2,392 |  |
| Less: Current portion of long-term debt |  |  |  |  | (750 | ) |  |  | (400 | ) |
| Total long-term debt |  |  |  | $ | 1,244 |  |  | $ | 1,992 |  |

[0000950170-25-029066:notes:81]
Senior Notes

[0000950170-25-029066:notes:82]
On September 30, 2024, upon maturity, we repaid the 3.30% Senior Notes due September 2024 for an aggregate amount of $407 million, comprised of the principal and unpaid interest. Interest on our outstanding Senior Notes is payable semi-annually in June and December.

[0000950170-25-029066:notes:83]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0000950170-25-029066:notes:84]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 24, 2025, we were in compliance with all covenants associated with the Senior Notes.

[0000950170-25-029066:notes:85]
As of January 24, 2025, our aggregate future principal debt maturities are as follows (in millions):

[0000950170-25-029066:notes:86]
| Fiscal Year |  | Amount |  |
| 2025 (remainder) |  | $ | — |  |
| 2026 |  |  | 750 |  |
| 2027 |  |  | — |  |
| 2028 |  |  | 550 |  |
| 2029 |  |  | — |  |
| Thereafter |  |  | 700 |  |
| Total |  | $ | 2,000 |  |

[0000950170-25-029066:notes:87]
Commercial Paper Program and Credit Facility

[0000950170-25-029066:notes:88]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of January 24, 2025 or April 26, 2024.

[0000950170-25-029066:notes:89]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 24, 2025, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0000950170-25-029066:notes:90]
[same as prior period, unchanged from 0000950170-24-130551:notes:85]

[0000950170-25-029066:notes:91]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of January 24, 2025, have remaining lease terms not exceeding 17 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of January 24, 2025, have remaining lease terms not exceeding 4 years. As of January 24, 2025, our automobile leases have remaining lease terms not exceeding 5 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0000950170-25-029066:notes:92]
[same as prior period, unchanged from 0000950170-24-130551:notes:87]

[0000950170-25-029066:notes:93]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | January 24, 2025 |  |  | January 26, 2024 |  |
| Operating lease cost |  | $ | 13 |  |  | $ | 13 |  |  | $ | 38 |  |  | $ | 41 |  |
| Variable lease cost |  |  | 3 |  |  |  | 3 |  |  |  | 11 |  |  |  | 11 |  |
| Total lease cost |  | $ | 16 |  |  | $ | 16 |  |  | $ | 49 |  |  | $ | 52 |  |

[0000950170-25-029066:notes:94]
[same as prior period, unchanged from 0000950170-24-130551:notes:89]

[0000950170-25-029066:notes:95]
[same as prior period, unchanged from 0000950170-24-130551:notes:90]

[0000950170-25-029066:notes:96]
|  |  |  |  | Nine Months Ended |  |
|  |  |  |  |  |  | January 24, 2025 |  |  | January 26, 2024 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  |  |  |  |  | $ | 36 |  |  | $ | 38 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  |  |  |  |  | $ | 18 |  |  | $ | 15 |  |

[0000950170-25-029066:notes:97]
[same as prior period, unchanged from 0000950170-24-130551:notes:92]

[0000950170-25-029066:notes:98]
|  |  |  |  |  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| Other non-current assets |  |  |  |  |  | $ | 242 |  |  | $ | 247 |  |
| Total operating lease ROU assets |  |  |  |  |  | $ | 242 |  |  | $ | 247 |  |
| Accrued expenses |  |  |  |  |  | $ | 41 |  |  | $ | 40 |  |
| Other long-term liabilities |  |  |  |  |  |  | 215 |  |  |  | 220 |  |
| Total operating lease liabilities |  |  |  |  |  | $ | 256 |  |  | $ | 260 |  |
| Weighted Average Remaining Lease Term |  |  |  |  |  | 8.5 years |  |  | 9.2 years |  |
| Weighted Average Discount Rate |  |  |  |  |  |  | 3.3 | % |  |  | 3.1 | % |

[0000950170-25-029066:notes:99]
Future minimum operating lease payments as of January 24, 2025, are as follows (in millions):

[0000950170-25-029066:notes:100]
| Fiscal Year |  |  |  |  |  | Amount |  |
| 2025 (remainder) |  |  |  |  |  | $ | 13 |  |
| 2026 |  |  |  |  |  |  | 47 |  |
| 2027 |  |  |  |  |  |  | 41 |  |
| 2028 |  |  |  |  |  |  | 34 |  |
| 2029 |  |  |  |  |  |  | 29 |  |
| Thereafter |  |  |  |  |  |  | 131 |  |
| Total lease payments |  |  |  |  |  |  | 295 |  |
| Less: Interest |  |  |  |  |  |  | (39 | ) |
| Total |  |  |  |  |  | $ | 256 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000950170-25-029066:notes:101]
[same as prior period, unchanged from 0000950170-24-130551:notes:96]

[0000950170-25-029066:notes:102]
[same as prior period, unchanged from 0000950170-24-130551:notes:97]

[0000950170-25-029066:notes:103]
We granted approximately 3 million restricted stock units (RSUs), including performance-based RSUs (PBRSUs), with a weighted average grant date fair value of $126.96 per share during the nine months ended January 24, 2025.

[0000950170-25-029066:notes:104]
In the nine months ended January 24, 2025, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSUs cliff-vest at the end of a three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the third fiscal year, following the grant date. The number of shares that will be used to calculate the settlement amount for all of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the nine months ended January 24, 2025, the number of shares used to calculate the settlement amount will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. For the remaining half of the PBRSUs granted in the nine months ended January 24, 2025, the number of shares used to calculate the settlement amount will depend upon the Company's billings result average over the three-year performance period. The billings result average is computed based on achievement against annual billings targets, with each target set at the beginning of the respective fiscal year, during the

[0000950170-25-029066:notes:105]
[same as prior period, unchanged from 0000950170-24-130551:notes:100]

[0000950170-25-029066:notes:106]
[same as prior period, unchanged from 0000950170-24-130551:notes:101]

[0000950170-25-029066:notes:107]
[same as prior period, unchanged from 0000950170-24-130551:notes:102]

[0000950170-25-029066:notes:108]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | January 24, 2025 |  |  | January 26, 2024 |  |
| Cost of product revenues |  | $ | 2 |  |  | $ | 2 |  |  | $ | 5 |  |  | $ | 4 |  |
| Cost of services revenues |  |  | 6 |  |  |  | 5 |  |  |  | 18 |  |  |  | 17 |  |
| Sales and marketing |  |  | 44 |  |  |  | 36 |  |  |  | 122 |  |  |  | 109 |  |
| Research and development |  |  | 36 |  |  |  | 32 |  |  |  | 104 |  |  |  | 99 |  |
| General and administrative |  |  | 15 |  |  |  | 14 |  |  |  | 42 |  |  |  | 40 |  |
| Total stock-based compensation expense |  | $ | 103 |  |  | $ | 89 |  |  | $ | 291 |  |  | $ | 269 |  |

[0000950170-25-029066:notes:109]
As of January 24, 2025, total unrecognized compensation expense related to equity awards was $672 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.0 years.

[0000950170-25-029066:notes:110]
[same as prior period, unchanged from 0000950170-24-130551:notes:105]

[0000950170-25-029066:notes:111]
In the first quarter of fiscal 2025, our Board of Directors authorized the repurchase of an additional $1.0 billion of our common stock. As of January 24, 2025, our Board of Directors has authorized cumulative repurchases of up to $17.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time.

[0000950170-25-029066:notes:112]
The following table summarizes activity related to the stock repurchase program for the nine months ended January 24, 2025 (in millions, except for per share amounts):

[0000950170-25-029066:notes:113]
| Number of shares repurchased |  |  | 7.4 |  |
| Average price per share |  | $ | 121.46 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 35 |  |
| Stock repurchases allocated to retained earnings |  | $ | 865 |  |
| Remaining authorization at end of period |  | $ | 602 |  |

[0000950170-25-029066:notes:114]
Since the May 13, 2003 inception of our stock repurchase program through January 24, 2025, we repurchased a total of 379 million shares of our common stock at an average price of $43.59 per share, for an aggregate purchase price of $16.5 billion.

[0000950170-25-029066:notes:115]
[same as prior period, unchanged from 0000950170-24-130551:notes:110]

[0000950170-25-029066:notes:116]
[same as prior period, unchanged from 0000950170-24-130551:notes:111]

[0000950170-25-029066:notes:117]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |
| Dividends per share declared |  | $ | 1.56 |  |  | $ | 1.50 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 130 |  |  | $ | 171 |  |
| Dividend payments allocated to retained earnings |  | $ | 189 |  |  | $ | 141 |  |

[0000950170-25-029066:notes:118]
On February 20, 2025, we declared a cash dividend of $0.52 per share of common stock, payable on April 23, 2025 to holders of record as of the close of business on April 4, 2025. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0000950170-25-029066:notes:119]
[same as prior period, unchanged from 0000950170-24-130551:notes:114]

[0000950170-25-029066:notes:120]
[same as prior period, unchanged from 0000950170-24-130551:notes:115]

[0000950170-25-029066:notes:121]
|  |  | ForeignCurrencyTranslationAdjustments |  |  | DefinedBenefitObligationAdjustments |  |  | UnrealizedGains(Losses) on Available-for-SaleSecurities |  |  | UnrealizedGains(Losses) onDerivativeInstruments |  |  | Total |  |
| Balance as of April 26, 2024 |  | $ | (53 | ) |  | $ | (7 | ) |  | $ | — |  |  | $ | 1 |  |  | $ | (59 | ) |
| Other comprehensive income (loss), net of tax |  |  | (7 | ) |  |  | — |  |  |  | 1 |  |  |  | 2 |  |  |  | (4 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  | (2 | ) |
| Total other comprehensive income (loss) |  |  | (7 | ) |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | (6 | ) |
| Balance as of January 24, 2025 |  | $ | (60 | ) |  | $ | (7 | ) |  | $ | 1 |  |  | $ | 1 |  |  | $ | (65 | ) |

[0000950170-25-029066:notes:122]
[same as prior period, unchanged from 0000950170-24-130551:notes:117]

[0000950170-25-029066:notes:123]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | Statements ofIncome Classification |
| Realized losses (gains) on cash flow hedges |  | $ | (4 | ) |  | $ | 2 |  |  | $ | (2 | ) |  | $ | (2 | ) |  | Net revenues |
| Total reclassifications |  | $ | (4 | ) |  | $ | 2 |  |  | $ | (2 | ) |  | $ | (2 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-25-029066:notes:124]
[same as prior period, unchanged from 0000950170-24-130551:notes:119]

[0000950170-25-029066:notes:125]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of January 24, 2025 or April 26, 2024. All contracts have a maturity of less than 12 months.

[0000950170-25-029066:notes:126]
[same as prior period, unchanged from 0000950170-24-130551:notes:121]

[0000950170-25-029066:notes:127]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 109 |  |  | $ | 71 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 553 |  |  | $ | 881 |  |
| Forward contracts purchased |  | $ | 12 |  |  | $ | 11 |  |

[0000950170-25-029066:notes:128]
[same as prior period, unchanged from 0000950170-24-130551:notes:123]

[0000950170-25-029066:notes:129]
[same as prior period, unchanged from 0000950170-24-130551:notes:124]

[0000950170-25-029066:notes:130]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | January 24, 2025 |  |  | January 26, 2024 |  |
|  |  | Gain (Loss) Recognized into Income |  |  | Loss Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | (36 | ) |  | $ | 20 |  |  | $ | (22 | ) |  | $ | (29 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-25-029066:notes:131]
[same as prior period, unchanged from 0000950170-24-130551:notes:126]

[0000950170-25-029066:notes:132]
In the first nine months of fiscal 2025, management approved restructuring plans to redirect resources to highest return activities and reduce costs, which included a reduction of our global workforce by approximately 4%. This includes, in the third quarter of fiscal 2025, a plan approved related to the sale of our cloud optimization and management software business known as Spot by NetApp, resulting in the elimination of certain roles. Charges related to the plans consisted primarily of employee severance-related costs. The activities under the plans are expected to be substantially complete by the end of fiscal 2025.

[0000950170-25-029066:notes:133]
In the first nine months of fiscal 2024, management executed restructuring plans to redirect resources to highest return activities, and to optimize our global office space for our hybrid work model. In connection with these plans, we reduced our global workforce by approximately 2% and terminated certain real estate leases in various countries, resulting in restructuring charges comprised primarily of employee severance related expenses and lease termination charges. The activities under these plans were substantially completed by the end of fiscal 2024.

[0000950170-25-029066:notes:134]
[same as prior period, unchanged from 0000950170-24-130551:notes:129]

[0000950170-25-029066:notes:135]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |
| Balance at beginning of period |  | $ | 10 |  |  | $ | 36 |  |
| Net charges |  |  | 38 |  |  |  | 44 |  |
| Cash payments |  |  | (29 | ) |  |  | (60 | ) |
| Balance at end of period |  | $ | 19 |  |  | $ | 20 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-25-029066:notes:136]
[same as prior period, unchanged from 0000950170-24-130551:notes:131]

[0000950170-25-029066:notes:137]
[same as prior period, unchanged from 0000950170-24-130551:notes:132]

[0000950170-25-029066:notes:138]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |
| Effective tax rates |  |  | 17.8 | % |  |  | 21.3 | % |

[0000950170-25-029066:notes:139]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. Our effective tax rate for the nine months ended January 24, 2025 includes an increase in discrete tax benefits related to stock compensation compared to the corresponding period of the prior year. Our effective tax rate for the nine months ended January 26, 2024 included benefits for fiscal 2024 foreign tax credits resulting from legislative guidance for that period, partially offset by an increase in stock compensation for which no tax benefit is recorded.

[0000950170-25-029066:notes:140]
The Organisation for Economic Co-operation and Development (“OECD”) recently enacted model rules for a new global minimum tax framework known as Pillar Two. These rules have been agreed to by most OECD members. The OECD has since issued administrative guidance providing transition and safe harbor rules around the implementation of Pillar Two rules. On February 1, 2023, the FASB indicated that they believe taxes imposed under Pillar Two is an alternative minimum tax. Accordingly, deferred tax assets and liabilities associated with the minimum tax would not be recognized or adjusted for the estimated future effects of the minimum tax but would be recognized in the period incurred. We are currently subject to Pillar Two rules starting in our fiscal year 2025. As of January 24, 2025, Pillar Two taxes do not have a significant impact on our financial statements, particularly due to the safe harbor relief during the transition period, but we are still closely monitoring developments.

[0000950170-25-029066:notes:141]
[same as prior period, unchanged from 0000950170-24-130551:notes:137]

[0000950170-25-029066:notes:142]
[same as prior period, unchanged from 0000950170-24-130551:notes:138]

[0000950170-25-029066:notes:143]
As of January 24, 2025, we had $228 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $169 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $169 million have been recorded in other long-term liabilities.


## us-gaap:EarningsPerShareTextBlock

[0000950170-25-029066:notes:144]
[same as prior period, unchanged from 0000950170-24-130551:notes:140]

[0000950170-25-029066:notes:145]
[same as prior period, unchanged from 0000950170-24-130551:notes:141]

[0000950170-25-029066:notes:146]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | January 24, 2025 |  |  | January 26, 2024 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 299 |  |  | $ | 313 |  |  | $ | 846 |  |  | $ | 695 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 204 |  |  |  | 206 |  |  |  | 205 |  |  |  | 209 |  |
| Dilutive impact of employee equity award plans |  |  | 4 |  |  |  | 5 |  |  |  | 5 |  |  |  | 4 |  |
| Shares used in diluted computation |  |  | 208 |  |  |  | 211 |  |  |  | 210 |  |  |  | 213 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.47 |  |  | $ | 1.52 |  |  | $ | 4.13 |  |  | $ | 3.33 |  |
| Diluted |  | $ | 1.44 |  |  | $ | 1.48 |  |  | $ | 4.03 |  |  | $ | 3.26 |  |

[0000950170-25-029066:notes:147]
The following table presents the numbers of potential shares of common stock from outstanding employee equity awards that have been excluded from the computation of diluted net income per share, as their inclusion would have had an anti-dilutive effect, for the periods presented (in millions):

[0000950170-25-029066:notes:148]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | January 24, 2025 |  |  | January 26, 2024 |  |
| Employee equity award plans |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-25-029066:notes:149]
[same as prior period, unchanged from 0000950170-24-130551:notes:144]

[0000950170-25-029066:notes:150]
[same as prior period, unchanged from 0000950170-24-130551:notes:145]

[0000950170-25-029066:notes:151]
[same as prior period, unchanged from 0000950170-24-130551:notes:146]

[0000950170-25-029066:notes:152]
[same as prior period, unchanged from 0000950170-24-130551:notes:147]

[0000950170-25-029066:notes:153]
[same as prior period, unchanged from 0000950170-24-130551:notes:148]

[0000950170-25-029066:notes:154]
[same as prior period, unchanged from 0000950170-24-130551:notes:149]

[0000950170-25-029066:notes:155]
|  | Three Months Ended January 24, 2025 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 758 |  |  | $ | — |  |  | $ | 758 |  |
| Support revenues |  | 621 |  |  |  | — |  |  |  | 621 |  |
| Professional and other services revenues |  | 88 |  |  |  | — |  |  |  | 88 |  |
| Public cloud revenues |  | — |  |  |  | 174 |  |  |  | 174 |  |
| Net revenues |  | 1,467 |  |  |  | 174 |  |  |  | 1,641 |  |
| Cost of product revenues |  | 328 |  |  |  | — |  |  |  | 328 |  |
| Cost of support revenues |  | 48 |  |  |  | — |  |  |  | 48 |  |
| Cost of professional and other services revenues |  | 63 |  |  |  | — |  |  |  | 63 |  |
| Cost of public cloud revenues |  | — |  |  |  | 41 |  |  |  | 41 |  |
| Segment cost of revenues |  | 439 |  |  |  | 41 |  |  |  | 480 |  |
| Segment gross profit | $ | 1,028 |  |  | $ | 133 |  |  | $ | 1,161 |  |
| Segment gross margin |  | 70.1 | % |  |  | 76.4 | % |  |  | 70.7 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 16 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,145 |  |
| Total gross margin |  |  |  |  |  |  |  | 69.8 | % |
| 1 Unallocated cost of revenues are composed of $8 million of stock-based compensation expense and $8 million of amortization of intangible assets. |  |

[0000950170-25-029066:notes:156]
|  | Three Months Ended January 26, 2024 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 747 |  |  | $ | — |  |  | $ | 747 |  |
| Support revenues |  | 631 |  |  |  | — |  |  |  | 631 |  |
| Professional and other services revenues |  | 77 |  |  |  | — |  |  |  | 77 |  |
| Public cloud revenues |  | — |  |  |  | 151 |  |  |  | 151 |  |
| Net revenues |  | 1,455 |  |  |  | 151 |  |  |  | 1,606 |  |
| Cost of product revenues |  | 280 |  |  |  | — |  |  |  | 280 |  |
| Cost of support revenues |  | 49 |  |  |  | — |  |  |  | 49 |  |
| Cost of professional and other services revenues |  | 58 |  |  |  | — |  |  |  | 58 |  |
| Cost of public cloud revenues |  | — |  |  |  | 52 |  |  |  | 52 |  |
| Segment cost of revenues |  | 387 |  |  |  | 52 |  |  |  | 439 |  |
| Segment gross profit | $ | 1,068 |  |  | $ | 99 |  |  | $ | 1,167 |  |
| Segment gross margin |  | 73.4 | % |  |  | 65.6 | % |  |  | 72.7 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 16 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,151 |  |
| Total gross margin |  |  |  |  |  |  |  | 71.7 | % |
| 1 Unallocated cost of revenues are composed of $7 million of stock-based compensation expense and $9 million of amortization of intangible assets. |  |

[0000950170-25-029066:notes:157]
|  | Nine Months Ended January 24, 2025 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 2,195 |  |  | $ | — |  |  | $ | 2,195 |  |
| Support revenues |  | 1,887 |  |  |  | — |  |  |  | 1,887 |  |
| Professional and other services revenues |  | 257 |  |  |  | — |  |  |  | 257 |  |
| Public cloud revenues |  | — |  |  |  | 501 |  |  |  | 501 |  |
| Net revenues |  | 4,339 |  |  |  | 501 |  |  |  | 4,840 |  |
| Cost of product revenues |  | 901 |  |  |  | — |  |  |  | 901 |  |
| Cost of support revenues |  | 149 |  |  |  | — |  |  |  | 149 |  |
| Cost of professional and other services revenues |  | 191 |  |  |  | — |  |  |  | 191 |  |
| Cost of public cloud revenues |  | — |  |  |  | 131 |  |  |  | 131 |  |
| Segment cost of revenues |  | 1,241 |  |  |  | 131 |  |  |  | 1,372 |  |
| Segment gross profit | $ | 3,098 |  |  | $ | 370 |  |  | $ | 3,468 |  |
| Segment gross margin |  | 71.4 | % |  |  | 73.9 | % |  |  | 71.7 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 48 |  |
| Total gross profit |  |  |  |  |  |  | $ | 3,420 |  |
| Total gross margin |  |  |  |  |  |  |  | 70.7 | % |
| 1 Unallocated cost of revenues are composed of $23 million of stock-based compensation expense and $25 million of amortization of intangible assets. |  |

[0000950170-25-029066:notes:158]
|  | Nine Months Ended January 26, 2024 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 2,043 |  |  | $ | — |  |  | $ | 2,043 |  |
| Support revenues |  | 1,865 |  |  |  | — |  |  |  | 1,865 |  |
| Professional and other services revenues |  | 233 |  |  |  | — |  |  |  | 233 |  |
| Public cloud revenues |  | — |  |  |  | 459 |  |  |  | 459 |  |
| Net revenues |  | 4,141 |  |  |  | 459 |  |  |  | 4,600 |  |
| Cost of product revenues |  | 819 |  |  |  | — |  |  |  | 819 |  |
| Cost of support revenues |  | 146 |  |  |  | — |  |  |  | 146 |  |
| Cost of professional and other services revenues |  | 176 |  |  |  | — |  |  |  | 176 |  |
| Cost of public cloud revenues |  | — |  |  |  | 155 |  |  |  | 155 |  |
| Segment cost of revenues |  | 1,141 |  |  |  | 155 |  |  |  | 1,296 |  |
| Segment gross profit | $ | 3,000 |  |  | $ | 304 |  |  | $ | 3,304 |  |
| Segment gross margin |  | 72.4 | % |  |  | 66.2 | % |  |  | 71.8 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 47 |  |
| Total gross profit |  |  |  |  |  |  | $ | 3,257 |  |
| Total gross margin |  |  |  |  |  |  |  | 70.8 | % |
| 1 Unallocated cost of revenues are composed of $21 million of stock-based compensation expense and $26 million of amortization of intangible assets. |  |

[0000950170-25-029066:notes:159]
[same as prior period, unchanged from 0000950170-24-130551:notes:154]

[0000950170-25-029066:notes:160]
[same as prior period, unchanged from 0000950170-24-130551:notes:155]

[0000950170-25-029066:notes:161]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | January 24, 2025 |  |  | January 26, 2024 |  |
| United States, Canada and Latin America (Americas) |  | $ | 833 |  |  | $ | 802 |  |  | $ | 2,458 |  |  | $ | 2,345 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 559 |  |  |  | 567 |  |  |  | 1,615 |  |  |  | 1,538 |  |
| Asia Pacific (APAC) |  |  | 249 |  |  |  | 237 |  |  |  | 767 |  |  |  | 717 |  |
| Net revenues |  | $ | 1,641 |  |  | $ | 1,606 |  |  | $ | 4,840 |  |  | $ | 4,600 |  |

[0000950170-25-029066:notes:162]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $768 million and $744 million during the three months ended January 24, 2025 and January 26, 2024, respectively, and were $2,273 million and $2,172 million during the nine months ended January 24, 2025 and January 26, 2024, respectively.

[0000950170-25-029066:notes:163]
[same as prior period, unchanged from 0000950170-24-130551:notes:158]

[0000950170-25-029066:notes:164]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| U.S. |  | $ | 230 |  |  | $ | 1,142 |  |
| International |  |  | 2,031 |  |  |  | 2,110 |  |
| Total |  | $ | 2,261 |  |  | $ | 3,252 |  |

[0000950170-25-029066:notes:165]
[same as prior period, unchanged from 0000950170-24-130551:notes:160]

[0000950170-25-029066:notes:166]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| U.S. |  | $ | 348 |  |  | $ | 378 |  |
| International |  |  | 219 |  |  |  | 226 |  |
| Total |  | $ | 567 |  |  | $ | 604 |  |

[0000950170-25-029066:notes:167]
[same as prior period, unchanged from 0000950170-24-130551:notes:162]

[0000950170-25-029066:notes:168]
[same as prior period, unchanged from 0000950170-24-130551:notes:163]

[0000950170-25-029066:notes:169]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | January 24, 2025 |  |  | January 26, 2024 |  |
| Arrow Electronics, Inc. |  |  | 20 | % |  |  | 21 | % |  |  | 21 | % |  |  | 22 | % |
| TD Synnex Corporation |  |  | 26 | % |  |  | 21 | % |  |  | 24 | % |  |  | 21 | % |

[0000950170-25-029066:notes:170]
[same as prior period, unchanged from 0000950170-24-130551:notes:165]

[0000950170-25-029066:notes:171]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| Arrow Electronics, Inc. |  |  | 6 | % |  |  | 10 | % |
| TD Synnex Corporation |  |  | 27 | % |  |  | 26 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-25-029066:notes:172]
14. Commitments and Contingencies

[0000950170-25-029066:notes:173]
Purchase Orders and Other Commitments

[0000950170-25-029066:notes:174]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of January 24, 2025, we had approximately $0.5 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 24, 2025 and April 26, 2024, such liability amounted to $17 million and $20 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0000950170-25-029066:notes:175]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 24, 2025, we had approximately $0.6 billion in other purchase obligations.

[0000950170-25-029066:notes:176]
Financing Guarantees

[0000950170-25-029066:notes:177]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $42 million and $58 million of receivables during the nine months ended January 24, 2025 and January 26, 2024, respectively.

[0000950170-25-029066:notes:178]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0000950170-25-029066:notes:179]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of January 24, 2025 and April 26, 2024, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-25-029066:notes:180]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the

[0000950170-25-029066:notes:181]
service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 24, 2025, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make material payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-25-029066:notes:182]
Legal Contingencies

[0000950170-25-029066:notes:183]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0000950170-25-029066:notes:184]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigation brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0000950170-25-029066:notes:185]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of January 24, 2025 related to such matters.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000950170-25-029066:notes:186]
[same as prior period, unchanged from 0000950170-24-130551:notes:180]

[0000950170-25-029066:notes:187]
[same as prior period, unchanged from 0000950170-24-130551:notes:181]

[0000950170-25-029066:notes:188]
On November 29, 2024, Elizabeth O'Callahan, EVP, Chief Legal Officer of the Company, entered into a 10b5-1 trading arrangement intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) promulgated under the Exchange Act. The trading arrangement will expire on June 26, 2026, and may be terminated earlier in the limited circumstances defined in the trading arrangement. An aggregate of up to 12,000 shares may be sold pursuant to the trading arrangement.

[0000950170-25-029066:notes:189]
[same as prior period, unchanged from 0000950170-24-130551:notes:183]
