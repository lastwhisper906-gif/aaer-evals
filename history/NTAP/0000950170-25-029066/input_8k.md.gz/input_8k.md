# NTAP 8-K — 0000950170-25-029022 filed 2025-02-27

## item codes, every 8-K on or before 2025-02-27

- 2025-02-27 0000950170-25-029022 — 2.02, 9.01
- 2025-02-26 0001193125-25-036882 — 5.02, 9.01
- 2025-01-28 0001193125-25-014441 — 5.02, 9.01
- 2024-11-21 0000950170-24-129714 — 2.02, 9.01
- 2024-09-12 0000950170-24-105928 — 5.02, 5.07, 9.01
- 2024-08-28 0000950170-24-101383 — 2.02, 5.02, 9.01
- 2024-05-30 0000950170-24-066567 — 2.02, 8.01, 9.01
- 2024-04-09 0000950170-24-042957 — 5.02
- 2024-02-29 0000950170-24-023060 — 2.02, 9.01
- 2023-11-28 0000950170-23-066400 — 2.02, 9.01
- 2023-11-16 0000950170-23-064506 — 5.02, 5.03, 9.01
- 2023-09-15 0000950170-23-048229 — 5.02, 5.07, 9.01
- 2023-08-23 0000950170-23-044130 — 2.02, 9.01
- 2023-08-10 0000950170-23-041348 — 5.02
- 2023-05-31 0000950170-23-025324 — 1.01, 2.02, 8.01, 9.01
- 2023-02-22 0000950170-23-003745 — 2.02, 9.01
- 2023-01-31 0001193125-23-019739 — 2.05, 7.01, 9.01
- 2022-11-29 0000950170-22-025793 — 2.02, 9.01
- 2022-11-16 0000950170-22-025317 — 5.02
- 2022-09-14 0000950170-22-018490 — 5.07
- 2022-08-24 0000950170-22-017731 — 2.02, 9.01
- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2025-02-27

- none on or before 2025-02-27

## item 2.02 — earnings release, exhibit 99.1

[0000950170-25-029022:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0000950170-25-029022:8k_2_02:2]
EX-99.1

[0000950170-25-029022:8k_2_02:3]
Exhibit 99.1

[0000950170-25-029022:8k_2_02:4]
NetApp Reports Third Quarter of Fiscal Year 2025 Results

[0000950170-25-029022:8k_2_02:5]
Net revenues of $1.64 billion for the third quarter

[0000950170-25-029022:8k_2_02:6]
•
All-flash array annualized net revenue run rate1 of $3.8 billion, an increase of 10% year-over-year

[0000950170-25-029022:8k_2_02:7]
•
First-party and marketplace cloud storage services revenue again grew more than 40% year-over-year

[0000950170-25-029022:8k_2_02:8]
•
Continued to deliver significant intelligent data infrastructure innovation with the launch of new all-flash NetApp™ AFF A-Series and C-Series systems, enhanced StorageGRID™ object storage capabilities, and expanded cloud storage offerings

[0000950170-25-029022:8k_2_02:9]
•
Third quarter GAAP operating margin of 22%; third quarter non-GAAP operating margin2 of 30%

[0000950170-25-029022:8k_2_02:10]
•
Third quarter GAAP net income per share3 of $1.44; third quarter non-GAAP net income per share2 of $1.91

[0000950170-25-029022:8k_2_02:11]
•
Returned $306 million to stockholders through share repurchases and cash dividends

[0000950170-25-029022:8k_2_02:12]
SAN JOSE, Calif.—February 27, 2025—NetApp (NASDAQ: NTAP), the intelligent data infrastructure company, today reported financial results for the third quarter of fiscal year 2025, which ended on January 24, 2025.

[0000950170-25-029022:8k_2_02:13]
“The strength of our business model yielded operating margin ahead of and EPS in-line with expectations, despite Q3 top line performance below our standards,” said George Kurian, chief executive officer. “We are taking action to enhance our execution and improve our momentum. I remain confident in our position as the supplier of choice for AI and other data-driven workloads and our ability to achieve our long-term financial goals and deliver increasing shareholder value. Our portfolio has never been stronger, delivering a modern approach to hybrid, multicloud infrastructure and data management and giving customers the ability to leverage the power of their entire data estate simply, securely, and sustainably.”

[0000950170-25-029022:8k_2_02:14]
Third Quarter of Fiscal Year 2025 Financial Results

[0000950170-25-029022:8k_2_02:15]
•
Net revenues: $1.64 billion, compared to $1.61 billion in the third quarter of fiscal year 2024; a year-over-year increase of 2%.

[0000950170-25-029022:8k_2_02:16]
o
Hybrid Cloud segment revenue: $1.47 billion, compared to $1.46 billion in the third quarter of fiscal year 2024.

[0000950170-25-029022:8k_2_02:17]
o
Public Cloud segment revenue: $174 million, compared to $151 million in the third quarter of fiscal year 2024.

[0000950170-25-029022:8k_2_02:18]
•
Billings2: $1.71 billion, compared to $1.69 billion in the third quarter of fiscal year 2024; a year-over-year increase of 2%.

[0000950170-25-029022:8k_2_02:19]
•
All-flash array ARR: $3.8 billion, compared to $3.4 billion in the third quarter of fiscal year 2024; a year-over-year increase of 10%.

[0000950170-25-029022:8k_2_02:20]
•
Net income: GAAP net income of $299 million, compared to $313 million in the third quarter of fiscal year 2024; non-GAAP net income of $397 million, compared to $410 million in the third quarter of fiscal year 2024.

[0000950170-25-029022:8k_2_02:21]
•
Earnings per share: GAAP net income per share of $1.44, compared to $1.48 in the third quarter of fiscal year 2024; non-GAAP net income per share of $1.91, compared to $1.94 in the third quarter of fiscal year 2024.

[0000950170-25-029022:8k_2_02:22]
•
Cash, cash equivalents and investments: $2.26 billion at the end of the third quarter of fiscal year 2025.

[0000950170-25-029022:8k_2_02:23]
•
Cash provided by operations: $385 million, compared to $484 million in the third quarter of fiscal year 2024.

[0000950170-25-029022:8k_2_02:24]
•
Share repurchases and dividends: Returned $306 million to stockholders through share repurchases and cash dividends.

[0000950170-25-029022:8k_2_02:25]
Fourth Quarter of Fiscal Year 2025 Financial Outlook

[0000950170-25-029022:8k_2_02:26]
The Company provided the following financial guidance for the fourth quarter of fiscal year 2025:

[0000950170-25-029022:8k_2_02:27]
| Net revenues are expected to be in the range of: | $1.65 billion - $1.80 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $1.45 - $1.55 | $1.84 - $1.94 |

[0000950170-25-029022:8k_2_02:28]
Full Fiscal Year 2025 Financial Outlook

[0000950170-25-029022:8k_2_02:29]
The Company provided the following update to financial guidance for the full fiscal year 2025:

[0000950170-25-029022:8k_2_02:30]
| Net revenues are expected to be in the range of: | $6.49 billion - $6.64 billion |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be approximately: | 70% | 71% |
| Operating margins are expected to be in the range of: | 20% - 20.5% | 28% - 28.5% |
| Earnings per share is expected to be in the range of: | $5.49 - $5.59 | $7.17 - $7.27 |

[0000950170-25-029022:8k_2_02:31]
Dividend

[0000950170-25-029022:8k_2_02:32]
The next cash dividend of $0.52 per share is to be paid on April 23, 2025, to stockholders of record as of the close of business on April 4, 2025.

[0000950170-25-029022:8k_2_02:33]
Third Quarter of Fiscal Year 2025 Business Highlights

[0000950170-25-029022:8k_2_02:34]
Leading Product Innovation

[0000950170-25-029022:8k_2_02:35]
•
NetApp introduced additional high-performance, unified data storage AFF A-Series entry and midrange platforms, which deliver advanced features for mission-critical workloads at affordable price points.

[0000950170-25-029022:8k_2_02:36]
•
NetApp introduced new AFF C-Series systems aimed at providing greater value for general-purpose workloads and consolidating workloads across unified file, block, and object storage protocols while delivering industry-leading density and efficiency.

[0000950170-25-029022:8k_2_02:37]
•
NetApp extended the StorageGRID SFG6112 system with support 60TB capacity flash drives, doubling the density of object deployments, reducing rack space, and lowering power and cooling costs.

[0000950170-25-029022:8k_2_02:38]
•
NetApp updated StorageGRID software with improved scalability and flexibility for increased performance with small object workloads and mixed-media grids.

[0000950170-25-029022:8k_2_02:39]
•
NetApp expanded the E-Series product family with the E4000 systems, providing simple high-performance SAN storage for backup, video surveillance, HPC, and AI-driven applications.

[0000950170-25-029022:8k_2_02:40]
•
NetApp announced the general availability of NetApp Trident™ 24.10 software, enabling Kubernetes workloads to benefit from the scale, performance, availability, and advanced data protection features of NetApp ONTAP technology for both on-premises and cloud environments.

[0000950170-25-029022:8k_2_02:41]
•
NetApp BlueXP™ adds ransomware integration with Microsoft Sentinel and new workload management features.

[0000950170-25-029022:8k_2_02:42]
•
NetApp continues to simplify data estate operations by enabling automated ONTAP and anti-ransomware updates through BlueXP.

[0000950170-25-029022:8k_2_02:43]
Customer and Partner Momentum

[0000950170-25-029022:8k_2_02:44]
•
The San Francisco 49ers and NetApp announced a multiyear strategic partnership, designating NetApp as the Official Intelligent Data Infrastructure Partner. The partnership is helping the 49ers leverage intelligent data infrastructure to enhance business operations, beginning with a reimagined fan experience at Levi’s Stadium.

[0000950170-25-029022:8k_2_02:45]
•
NetApp and Red Hat expanded their partnership to integrate NetApp’s intelligent data infrastructure with Red Hat OpenShift, enhancing flexibility for managing virtualized environments across on-premises and hybrid multicloud.

[0000950170-25-029022:8k_2_02:46]
•
NetApp introduced on-premises enterprise storage arrays for AWS Outposts, enabling customers to manage external block data volumes directly through the AWS Management Console.

[0000950170-25-029022:8k_2_02:47]
•
NetApp announced that Amazon FSx for NetApp ONTAP™ was certified for Siemens Teamcenter on AWS, bringing enhanced performance, scalability, and data management capabilities to product lifecycle management workloads in the cloud.

[0000950170-25-029022:8k_2_02:48]
•
Microsoft Azure introduced Azure NetApp Files cool access support for large volumes, which significantly improves the effective price of storage by moving infrequently accessed data to a lower-cost tier.

[0000950170-25-029022:8k_2_02:49]
•
Microsoft Azure updated Cloud Backup for Virtual Machines to integrate with Azure NetApp Files backup, enhancing data protection with a managed backup solution.

[0000950170-25-029022:8k_2_02:50]
•
NetApp announced the availability of NetApp Data Infrastructure Insights on the Azure Marketplace, offering streamlined infrastructure observability, automation, and real-time telemetry data to customers migrating to Azure.

[0000950170-25-029022:8k_2_02:51]
•
NetApp received the Google Cloud Ready – Regulated & Sovereignty Solutions Designation for the Google Cloud NetApp Volumes and Cloud Volumes ONTAP™ solutions.

[0000950170-25-029022:8k_2_02:52]
Corporate News and Events

[0000950170-25-029022:8k_2_02:53]
•
NetApp announced it had entered into an agreement for the sale of its Spot by NetApp FinOps business to Flexera, reflecting NetApp’s focus and commitment to intelligent data infrastructure and long-term growth opportunities.

[0000950170-25-029022:8k_2_02:54]
•
NetApp announced that it approved new near-term science-based emissions reduction targets verified by the Science-Based Targets initiative (SBTi), demonstrating the company’s commitment to making sustainability a crucial component of its business resilience strategy.

[0000950170-25-029022:8k_2_02:55]
•
NetApp released its second annual Data Complexity Report, which explores AI’s impact on organizations in 2025 and beyond, offering insights for harnessing its potential while addressing associated complexities and risks.

[0000950170-25-029022:8k_2_02:56]
•
NetApp and The Futurum Group released a report, “Cloud, Complexity, AI: The Triple Threat Demanding New Cyber Resilience Strategies,” analyzing the state of cybersecurity, evolving cyberthreats, and resilience strategies.

[0000950170-25-029022:8k_2_02:57]
Executive Leadership Announcements

[0000950170-25-029022:8k_2_02:58]
•
NetApp announced the appointment of Wissam Jabre as executive vice president and chief financial officer, effective March 10, 2025. Wissam brings over 20 years of experience leading finance organizations and a strong track record of value creation and disciplined operational management.

[0000950170-25-029022:8k_2_02:59]
•
NetApp appointed Suhail Hasanain as the new regional director for the Middle East and Africa region, where he will be responsible for driving business growth and fostering strategic collaborations.

[0000950170-25-029022:8k_2_02:60]
Awards and Recognition

[0000950170-25-029022:8k_2_02:61]
•
CRN named NetApp hybrid cloud an overall winner in the Hybrid Cloud Infrastructure category and NetApp AFF C-Series an overall winner in the Enterprise Storage category for its 2024 Products of the Year awards.

[0000950170-25-029022:8k_2_02:62]
•
CEO George Kurian was named to the Silicon Valley Power 100 List by the Silicon Valley Business Journal, reflecting his impact on and influence in the region.

[0000950170-25-029022:8k_2_02:63]
•
NetApp was listed in U.S. News’ Best Companies to Work For in the “Semiconductors, Electronics and Equipment,” “Region,” and “Supporting Family Caregiving” categories, reflecting the company's commitment to fostering a beneficial workplace.

[0000950170-25-029022:8k_2_02:64]
•
NetApp ranked in Forbes’ 300 Most Trusted Companies in America list, which evaluates companies based on employee, customer and investor trust, and media sentiment.

[0000950170-25-029022:8k_2_02:65]
•
NetApp was named one of the 50 Hottest Edge Hardware, Software and Services Companies by CRN as part of its 2024 Edge Computing 100 awards.

[0000950170-25-029022:8k_2_02:66]
•
In its 2024 Scale-Out File Storage Radar, GigaOm listed NetApp ONTAP as a mature platform leader and fast mover.

[0000950170-25-029022:8k_2_02:67]
•
NetApp was listed as a finalist for the 2025 Sustainability in Tech awards for the Sustainability Champion – Vendor category by CRN UK.

[0000950170-25-029022:8k_2_02:68]
•
NetApp was named one of the 20 Coolest Cloud Storage Companies as part of CRN’s 2025 Cloud 100 awards, highlighting the company’s silo-free approach to storage, which combines unified data storage with enterprise-grade storage services natively embedded in the top cloud hyperscalers.

[0000950170-25-029022:8k_2_02:69]
•
CRN named NetApp Senior GMT Program Manager Monica Scaglia to its 2024 Channel Women on the Rise list.

[0000950170-25-029022:8k_2_02:70]
Webcast and Conference Call Information

[0000950170-25-029022:8k_2_02:71]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today.

[0000950170-25-029022:8k_2_02:72]
###

[0000950170-25-029022:8k_2_02:73]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0000950170-25-029022:8k_2_02:74]
Footnotes

[0000950170-25-029022:8k_2_02:75]
1All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0000950170-25-029022:8k_2_02:76]
2Refer to “NetApp Usage of Non-GAAP Financial Information” section below for explanations of consolidated non-GAAP gross margins, non-GAAP operating margins, non-GAAP net income, non-GAAP net income per share, free cash flow, and billings.

[0000950170-25-029022:8k_2_02:77]
3GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0000950170-25-029022:8k_2_02:78]
NetApp Usage of Non-GAAP Financial Information

[0000950170-25-029022:8k_2_02:79]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share.

[0000950170-25-029022:8k_2_02:80]
In prior periods, NetApp presented the hardware and software components of our GAAP product revenues to illustrate the significance and value of the Company’s software. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures.

[0000950170-25-029022:8k_2_02:81]
Effective in fiscal year 2025, NetApp no longer presents the non-GAAP hardware and software components of our product revenues, as management no longer considers them to be key financial measures. The Company’s current strategy is expected to deliver investor value through growth in total revenues, including product revenues, while maintaining operational discipline to drive earnings leverage. While software continues to be the primary value driver of our products, NetApp is primarily focused on driving growth in total product revenues, through the sale of configured storage systems comprised of both hardware and software, with less focus on the pricing of each component.

[0000950170-25-029022:8k_2_02:82]
Additionally, the Company is considering potential opportunities to simplify pricing for certain products in the future, which may eliminate the existence of separate prices for hardware and software components and/or impact our ability to allocate between them.

[0000950170-25-029022:8k_2_02:83]
NetApp believes that the presentation of its non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp’s management uses non-GAAP measures in making operating decisions because it believes that the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0000950170-25-029022:8k_2_02:84]
NetApp believes that the presentation of non-GAAP gross margins, non-GAAP operating margin, non-GAAP effective tax rate, non-GAAP net income, and non-GAAP earnings per share data, provides investors with supplemental metrics that assist in understanding current results and future prospects, earnings and profitability that are complementary to GAAP metrics. Each of these Non-GAAP metrics is defined as the applicable GAAP metric adjusted to exclude the items defined in A through I below, as applicable, while our Non-GAAP effective tax rate and Non-GAAP net income also reflect a non-GAAP tax provision, as described in item J below, instead of our GAAP tax provision. Non-GAAP net income per share is computed as Non-GAAP net income divided by the diluted number of shares for the applicable period.

[0000950170-25-029022:8k_2_02:85]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0000950170-25-029022:8k_2_02:86]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0000950170-25-029022:8k_2_02:87]
Non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0000950170-25-029022:8k_2_02:88]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0000950170-25-029022:8k_2_02:89]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0000950170-25-029022:8k_2_02:90]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0000950170-25-029022:8k_2_02:91]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0000950170-25-029022:8k_2_02:92]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0000950170-25-029022:8k_2_02:93]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0000950170-25-029022:8k_2_02:94]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0000950170-25-029022:8k_2_02:95]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer and/or lose control of assets to a third party. This is inclusive of third-party advisory, legal and other costs that result directly from and are essential to a sale transaction and that would not have been incurred had the decision to sell not been made. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0000950170-25-029022:8k_2_02:96]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0000950170-25-029022:8k_2_02:97]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such non-recurring costs do not reflect the results of its underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0000950170-25-029022:8k_2_02:98]
J. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges or benefits that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges or benefits resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0000950170-25-029022:8k_2_02:99]
Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures. A detailed reconciliation of our non-GAAP to GAAP results can be found herein.

[0000950170-25-029022:8k_2_02:100]
Constant Currency

[0000950170-25-029022:8k_2_02:101]
In periods in which the impacts of foreign currency exchange rate changes are significant, NetApp presents certain constant currency growth rates or quantifies the impact of foreign currency exchange rate changes on year-over-year fluctuations, including for net revenues, billings, and earnings. This constant currency information assumes the same foreign currency exchange rates that were in effect for the comparable prior-year period were used in translation of the current period results.

[0000950170-25-029022:8k_2_02:102]
About NetApp

[0000950170-25-029022:8k_2_02:103]
NetApp is the intelligent data infrastructure company, combining unified data storage, integrated data services, and CloudOps solutions to turn a world of disruption into opportunity for every customer. NetApp creates silo-free infrastructure, harnessing observability and AI to enable the industry’s best data management. As the only enterprise-grade storage service natively embedded in the world’s biggest clouds, our data storage delivers seamless flexibility. In addition, our data services create a data advantage through superior cyber resilience, governance, and application agility. Our CloudOps solutions provide continuous optimization of performance and efficiency through observability and AI. No matter the data type, workload, or environment, with NetApp you can transform your data infrastructure to realize your business possibilities.

[0000950170-25-029022:8k_2_02:104]
Learn more at www.netapp.com or follow us on X, LinkedIn, Facebook, and Instagram.

[0000950170-25-029022:8k_2_02:105]
NETAPP, INC.

[0000950170-25-029022:8k_2_02:106]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-25-029022:8k_2_02:107]
(In millions)

[0000950170-25-029022:8k_2_02:108]
(Unaudited)

[0000950170-25-029022:8k_2_02:109]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 2,261 |  |  | $ | 3,252 |  |
| Accounts receivable |  |  | 898 |  |  |  | 1,007 |  |
| Inventories |  |  | 268 |  |  |  | 186 |  |
| Other current assets |  |  | 481 |  |  |  | 452 |  |
| Total current assets |  |  | 3,908 |  |  |  | 4,897 |  |
| Property and equipment, net |  |  | 567 |  |  |  | 604 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,772 |  |  |  | 2,883 |  |
| Other non-current assets |  |  | 1,742 |  |  |  | 1,503 |  |
| Total assets |  | $ | 8,989 |  |  | $ | 9,887 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 434 |  |  | $ | 517 |  |
| Accrued expenses |  |  | 941 |  |  |  | 1,013 |  |
| Current portion of long-term debt |  |  | 750 |  |  |  | 400 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 2,070 |  |  |  | 2,176 |  |
| Total current liabilities |  |  | 4,195 |  |  |  | 4,106 |  |
| Long-term debt |  |  | 1,244 |  |  |  | 1,992 |  |
| Other long-term liabilities |  |  | 503 |  |  |  | 585 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 2,052 |  |  |  | 2,058 |  |
| Total liabilities |  |  | 7,994 |  |  |  | 8,741 |  |
| Stockholders' equity |  |  | 995 |  |  |  | 1,146 |  |
| Total liabilities and stockholders' equity |  | $ | 8,989 |  |  | $ | 9,887 |  |

[0000950170-25-029022:8k_2_02:110]
NETAPP, INC.

[0000950170-25-029022:8k_2_02:111]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-25-029022:8k_2_02:112]
(In millions, except per share amounts)

[0000950170-25-029022:8k_2_02:113]
(Unaudited)

[0000950170-25-029022:8k_2_02:114]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 758 |  |  | $ | 747 |  |  | $ | 2,195 |  |  | $ | 2,043 |  |  |
| Services |  |  | 883 |  |  |  | 859 |  |  |  | 2,645 |  |  |  | 2,557 |  |  |
| Net revenues |  |  | 1,641 |  |  |  | 1,606 |  |  |  | 4,840 |  |  |  | 4,600 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 330 |  |  |  | 282 |  |  |  | 906 |  |  |  | 823 |  |  |
| Cost of services |  |  | 166 |  |  |  | 173 |  |  |  | 514 |  |  |  | 520 |  |  |
| Total cost of revenues |  |  | 496 |  |  |  | 455 |  |  |  | 1,420 |  |  |  | 1,343 |  |  |
| Gross profit |  |  | 1,145 |  |  |  | 1,151 |  |  |  | 3,420 |  |  |  | 3,257 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 451 |  |  |  | 439 |  |  |  | 1,407 |  |  |  | 1,368 |  |  |
| Research and development |  |  | 247 |  |  |  | 249 |  |  |  | 756 |  |  |  | 758 |  |  |
| General and administrative |  |  | 74 |  |  |  | 81 |  |  |  | 226 |  |  |  | 230 |  |  |
| Restructuring charges |  |  | 9 |  |  |  | 13 |  |  |  | 38 |  |  |  | 44 |  |  |
| Acquisition-related expense |  |  | 2 |  |  |  | 3 |  |  |  | 4 |  |  |  | 9 |  |  |
| Total operating expenses |  |  | 783 |  |  |  | 785 |  |  |  | 2,431 |  |  |  | 2,409 |  |  |
| Income from operations |  |  | 362 |  |  |  | 366 |  |  |  | 989 |  |  |  | 848 |  |  |
| Other income, net |  |  | 8 |  |  |  | 16 |  |  |  | 40 |  |  |  | 35 |  |  |
| Income before income taxes |  |  | 370 |  |  |  | 382 |  |  |  | 1,029 |  |  |  | 883 |  |  |
| Provision for income taxes |  |  | 71 |  |  |  | 69 |  |  |  | 183 |  |  |  | 188 |  |  |
| Net income |  | $ | 299 |  |  | $ | 313 |  |  | $ | 846 |  |  | $ | 695 |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.47 |  |  | $ | 1.52 |  |  | $ | 4.13 |  |  | $ | 3.33 |  |  |
| Diluted |  | $ | 1.44 |  |  | $ | 1.48 |  |  | $ | 4.03 |  |  | $ | 3.26 |  |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 204 |  |  |  | 206 |  |  |  | 205 |  |  |  | 209 |  |  |
| Diluted |  |  | 208 |  |  |  | 211 |  |  |  | 210 |  |  |  | 213 |  |  |

[0000950170-25-029022:8k_2_02:115]
NETAPP, INC.

[0000950170-25-029022:8k_2_02:116]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-25-029022:8k_2_02:117]
(In millions)

[0000950170-25-029022:8k_2_02:118]
(Unaudited)

[0000950170-25-029022:8k_2_02:119]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | January 24, 2025 |  |  | January 26, 2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 299 |  |  | $ | 313 |  |  | $ | 846 |  |  | $ | 695 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 64 |  |  |  | 63 |  |  |  | 190 |  |  |  | 191 |  |
| Non-cash operating lease cost |  |  | 10 |  |  |  | 11 |  |  |  | 31 |  |  |  | 34 |  |
| Stock-based compensation |  |  | 103 |  |  |  | 89 |  |  |  | 291 |  |  |  | 269 |  |
| Deferred income taxes |  |  | (41 | ) |  |  | 11 |  |  |  | (110 | ) |  |  | (2 | ) |
| Other items, net |  |  | (60 | ) |  |  | 31 |  |  |  | (25 | ) |  |  | 4 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (34 | ) |  |  | 10 |  |  |  | 104 |  |  |  | 195 |  |
| Inventories |  |  | 50 |  |  |  | (9 | ) |  |  | (82 | ) |  |  | 37 |  |
| Accounts payable |  |  | (113 | ) |  |  | (11 | ) |  |  | (77 | ) |  |  | 3 |  |
| Accrued expenses |  |  | (10 | ) |  |  | (64 | ) |  |  | (94 | ) |  |  | (16 | ) |
| Deferred revenue and financed unearned services revenue |  |  | 72 |  |  |  | 81 |  |  |  | (92 | ) |  |  | (160 | ) |
| Long-term taxes payable |  |  | 7 |  |  |  | 3 |  |  |  | (84 | ) |  |  | (107 | ) |
| Changes in other operating assets and liabilities, net |  |  | 38 |  |  |  | (44 | ) |  |  | (67 | ) |  |  | (71 | ) |
| Net cash provided by operating activities |  |  | 385 |  |  |  | 484 |  |  |  | 831 |  |  |  | 1,072 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | (7 | ) |  |  | (401 | ) |  |  | 590 |  |  |  | (329 | ) |
| Purchases of property and equipment |  |  | (47 | ) |  |  | (36 | ) |  |  | (133 | ) |  |  | (109 | ) |
| Other investing activities, net |  |  | 1 |  |  |  | — |  |  |  | 3 |  |  |  | — |  |
| Net cash (used in) provided by investing activities |  |  | (53 | ) |  |  | (437 | ) |  |  | 460 |  |  |  | (438 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 53 |  |  |  | 48 |  |  |  | 108 |  |  |  | 100 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (36 | ) |  |  | (23 | ) |  |  | (168 | ) |  |  | (108 | ) |
| Repurchase of common stock |  |  | (200 | ) |  |  | (100 | ) |  |  | (900 | ) |  |  | (800 | ) |
| Repayments and extinguishment of debt |  |  | — |  |  |  | — |  |  |  | (400 | ) |  |  | — |  |
| Dividends paid |  |  | (106 | ) |  |  | (103 | ) |  |  | (319 | ) |  |  | (312 | ) |
| Net cash used in financing activities |  |  | (289 | ) |  |  | (178 | ) |  |  | (1,679 | ) |  |  | (1,120 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (12 | ) |  |  | 16 |  |  |  | (3 | ) |  |  | (10 | ) |
| Net change in cash, cash equivalents and restricted cash |  |  | 31 |  |  |  | (115 | ) |  |  | (391 | ) |  |  | (496 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 1,487 |  |  |  | 1,941 |  |  |  | 1,909 |  |  |  | 2,322 |  |
| End of period |  | $ | 1,518 |  |  | $ | 1,826 |  |  | $ | 1,518 |  |  | $ | 1,826 |  |

[0000950170-25-029022:8k_2_02:120]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| Product |  | $ | 758 |  |  | $ | 768 |  |  | $ | 747 |  |
| Support |  |  | 621 |  |  |  | 635 |  |  |  | 631 |  |
| Professional and Other Services |  |  | 88 |  |  |  | 87 |  |  |  | 77 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,467 |  |  |  | 1,490 |  |  |  | 1,455 |  |
| Public Cloud Segment Net Revenues |  |  | 174 |  |  |  | 168 |  |  |  | 151 |  |
| Net Revenues |  | $ | 1,641 |  |  | $ | 1,658 |  |  | $ | 1,606 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| Product |  | $ | 430 |  |  | $ | 463 |  |  | $ | 467 |  |
| Support |  |  | 573 |  |  |  | 584 |  |  |  | 582 |  |
| Professional and Other Services |  |  | 25 |  |  |  | 23 |  |  |  | 19 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 1,028 |  |  |  | 1,070 |  |  |  | 1,068 |  |
| Public Cloud Segment Gross Profit |  |  | 133 |  |  |  | 124 |  |  |  | 99 |  |
| Total Segments Gross Profit |  |  | 1,161 |  |  |  | 1,194 |  |  |  | 1,167 |  |
| Amortization of Intangible Assets |  |  | (8 | ) |  |  | (9 | ) |  |  | (9 | ) |
| Stock-based Compensation |  |  | (8 | ) |  |  | (8 | ) |  |  | (7 | ) |
| Unallocated Cost of Revenues |  |  | (16 | ) |  |  | (17 | ) |  |  | (16 | ) |
| Gross Profit |  | $ | 1,145 |  |  | $ | 1,177 |  |  | $ | 1,151 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| Product |  |  | 56.7 | % |  |  | 60.3 | % |  |  | 62.5 | % |
| Support |  |  | 92.3 | % |  |  | 92.0 | % |  |  | 92.2 | % |
| Professional and Other Services |  |  | 28.4 | % |  |  | 26.4 | % |  |  | 24.7 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 70.1 | % |  |  | 71.8 | % |  |  | 73.4 | % |
| Public Cloud Segment Gross Margin |  |  | 76.4 | % |  |  | 73.8 | % |  |  | 65.6 | % |
| Geographic Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'25 |  |  | % of Q2 FY'25 |  |  | % of Q3 FY'24 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 51 | % |  |  | 52 | % |  |  | 50 | % |
| Americas Commercial |  |  | 41 | % |  |  | 38 | % |  |  | 41 | % |
| U.S. Public Sector |  |  | 10 | % |  |  | 14 | % |  |  | 9 | % |
| EMEA |  |  | 34 | % |  |  | 33 | % |  |  | 35 | % |
| Asia Pacific |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'25 |  |  | % of Q2 FY'25 |  |  | % of Q3 FY'24 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 21 | % |  |  | 23 | % |  |  | 26 | % |
| Indirect |  |  | 79 | % |  |  | 77 | % |  |  | 74 | % |

[0000950170-25-029022:8k_2_02:121]
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| Non-GAAP Income from Operations |  | $ | 492 |  |  | $ | 475 |  |  | $ | 485 |  |
| % of Net Revenues |  |  | 30.0 | % |  |  | 28.6 | % |  |  | 30.2 | % |
| Non-GAAP Income before Income Taxes |  | $ | 500 |  |  | $ | 493 |  |  | $ | 501 |  |
| Non-GAAP Effective Tax Rate |  |  | 20.6 | % |  |  | 20.5 | % |  |  | 18.2 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| Non-GAAP Net Income |  | $ | 397 |  |  | $ | 392 |  |  | $ | 410 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 208 |  |  |  | 210 |  |  |  | 211 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.91 |  |  | $ | 1.87 |  |  | $ | 1.94 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 4,122 |  |  | $ | 4,100 |  |  | $ | 4,127 |  |
| DSO (days) |  |  | 50 |  |  |  | 48 |  |  |  | 45 |  |
| DPO (days) |  |  | 80 |  |  |  | 105 |  |  |  | 79 |  |
| Inventory Turns |  |  | 7 |  |  |  | 6 |  |  |  | 14 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| Net Cash Provided by Operating Activities |  | $ | 385 |  |  | $ | 105 |  |  | $ | 484 |  |
| Purchases of Property and Equipment |  | $ | 47 |  |  | $ | 45 |  |  | $ | 36 |  |
| Free Cash Flow |  | $ | 338 |  |  | $ | 60 |  |  | $ | 448 |  |
| Free Cash Flow as % of Net Revenues |  |  | 20.6 | % |  |  | 3.6 | % |  |  | 27.9 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0000950170-25-029022:8k_2_02:122]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| NET INCOME |  | $ | 299 |  |  | $ | 299 |  |  | $ | 313 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 14 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 103 |  |  |  | 103 |  |  |  | 89 |  |
| Restructuring charges |  |  | 9 |  |  |  | 12 |  |  |  | 13 |  |
| Acquisition-related expense |  |  | 2 |  |  |  | 1 |  |  |  | 3 |  |
| Gains/losses on the sale or derecognition of assets |  |  | 3 |  |  |  | 3 |  |  |  | — |  |
| Income tax effects |  |  | (32 | ) |  |  | (40 | ) |  |  | (22 | ) |
| NON-GAAP NET INCOME |  | $ | 397 |  |  | $ | 392 |  |  | $ | 410 |  |
| COST OF REVENUES |  | $ | 496 |  |  | $ | 481 |  |  | $ | 455 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (9 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (8 | ) |  |  | (8 | ) |  |  | (7 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 480 |  |  | $ | 464 |  |  | $ | 439 |  |
| COST OF PRODUCT REVENUES |  | $ | 330 |  |  | $ | 307 |  |  | $ | 282 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (2 | ) |  |  | (2 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 328 |  |  | $ | 305 |  |  | $ | 280 |  |
| COST OF SERVICES REVENUES |  | $ | 166 |  |  | $ | 174 |  |  | $ | 173 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (9 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (6 | ) |  |  | (5 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 152 |  |  | $ | 159 |  |  | $ | 159 |  |
| GROSS PROFIT |  | $ | 1,145 |  |  | $ | 1,177 |  |  | $ | 1,151 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 8 |  |  |  | 9 |  |  |  | 9 |  |
| Stock-based compensation |  |  | 8 |  |  |  | 8 |  |  |  | 7 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,161 |  |  | $ | 1,194 |  |  | $ | 1,167 |  |

[0000950170-25-029022:8k_2_02:123]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| SALES AND MARKETING EXPENSES |  | $ | 451 |  |  | $ | 485 |  |  | $ | 439 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (44 | ) |  |  | (43 | ) |  |  | (36 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 402 |  |  | $ | 437 |  |  | $ | 398 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 247 |  |  | $ | 257 |  |  | $ | 249 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (36 | ) |  |  | (37 | ) |  |  | (32 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 211 |  |  | $ | 220 |  |  | $ | 217 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 74 |  |  | $ | 77 |  |  | $ | 81 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (15 | ) |  |  | (15 | ) |  |  | (14 | ) |
| Gains/losses on the sale or derecognition of assets |  |  | (3 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 56 |  |  | $ | 62 |  |  | $ | 67 |  |
| RESTRUCTURING CHARGES |  | $ | 9 |  |  | $ | 12 |  |  | $ | 13 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (9 | ) |  |  | (12 | ) |  |  | (13 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 2 |  |  | $ | 1 |  |  | $ | 3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (2 | ) |  |  | (1 | ) |  |  | (3 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 783 |  |  | $ | 832 |  |  | $ | 785 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (95 | ) |  |  | (95 | ) |  |  | (82 | ) |
| Restructuring charges |  |  | (9 | ) |  |  | (12 | ) |  |  | (13 | ) |
| Acquisition-related expense |  |  | (2 | ) |  |  | (1 | ) |  |  | (3 | ) |
| Gains/losses on the sale or derecognition of assets |  |  | (3 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 669 |  |  | $ | 719 |  |  | $ | 682 |  |

[0000950170-25-029022:8k_2_02:124]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| INCOME FROM OPERATIONS |  | $ | 362 |  |  | $ | 345 |  |  | $ | 366 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 14 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 103 |  |  |  | 103 |  |  |  | 89 |  |
| Restructuring charges |  |  | 9 |  |  |  | 12 |  |  |  | 13 |  |
| Acquisition-related expense |  |  | 2 |  |  |  | 1 |  |  |  | 3 |  |
| Gains/losses on the sale or derecognition of assets |  |  | 3 |  |  |  | — |  |  |  | — |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 492 |  |  | $ | 475 |  |  | $ | 485 |  |
| OTHER INCOME, NET |  | $ | 8 |  |  | $ | 15 |  |  | $ | 16 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  | 3 |  |  |  | — |  |
| NON-GAAP OTHER INCOME, NET |  | $ | 8 |  |  | $ | 18 |  |  | $ | 16 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 370 |  |  | $ | 360 |  |  | $ | 382 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 14 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 103 |  |  |  | 103 |  |  |  | 89 |  |
| Restructuring charges |  |  | 9 |  |  |  | 12 |  |  |  | 13 |  |
| Acquisition-related expense |  |  | 2 |  |  |  | 1 |  |  |  | 3 |  |
| Gains/losses on the sale or derecognition of assets |  |  | 3 |  |  |  | 3 |  |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 500 |  |  | $ | 493 |  |  | $ | 501 |  |
| PROVISION FOR INCOME TAXES |  | $ | 71 |  |  | $ | 61 |  |  | $ | 69 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 32 |  |  |  | 40 |  |  |  | 22 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 103 |  |  | $ | 101 |  |  | $ | 91 |  |
| NET INCOME PER SHARE |  | $ | 1.44 |  |  | $ | 1.42 |  |  | $ | 1.48 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.06 |  |  |  | 0.07 |  |  |  | 0.07 |  |
| Stock-based compensation |  |  | 0.50 |  |  |  | 0.49 |  |  |  | 0.42 |  |
| Restructuring charges |  |  | 0.04 |  |  |  | 0.06 |  |  |  | 0.06 |  |
| Acquisition-related expense |  |  | 0.01 |  |  |  | — |  |  |  | 0.01 |  |
| Gains/losses on the sale or derecognition of assets |  |  | 0.01 |  |  |  | 0.01 |  |  |  | — |  |
| Income tax effects |  |  | (0.15 | ) |  |  | (0.19 | ) |  |  | (0.10 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.91 |  |  | $ | 1.87 |  |  | $ | 1.94 |  |

[0000950170-25-029022:8k_2_02:125]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| Gross margin-GAAP |  |  | 69.8 | % |  |  | 71.0 | % |  |  | 71.7 | % |
| Cost of revenues adjustments |  |  | 0.9 | % |  |  | 1.0 | % |  |  | 1.0 | % |
| Gross margin-Non-GAAP |  |  | 70.7 | % |  |  | 72.0 | % |  |  | 72.7 | % |
| GAAP cost of revenues |  | $ | 496 |  |  | $ | 481 |  |  | $ | 455 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (9 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (8 | ) |  |  | (8 | ) |  |  | (7 | ) |
| Non-GAAP cost of revenues |  | $ | 480 |  |  | $ | 464 |  |  | $ | 439 |  |
| Net revenues |  | $ | 1,641 |  |  | $ | 1,658 |  |  | $ | 1,606 |  |

[0000950170-25-029022:8k_2_02:126]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| Product gross margin-GAAP |  |  | 56.5 | % |  |  | 60.0 | % |  |  | 62.2 | % |
| Cost of product revenues adjustments |  |  | 0.2 | % |  |  | 0.3 | % |  |  | 0.3 | % |
| Product gross margin-Non-GAAP |  |  | 56.7 | % |  |  | 60.3 | % |  |  | 62.5 | % |
| GAAP cost of product revenues |  | $ | 330 |  |  | $ | 307 |  |  | $ | 282 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (2 | ) |  |  | (2 | ) |
| Non-GAAP cost of product revenues |  | $ | 328 |  |  | $ | 305 |  |  | $ | 280 |  |
| Product revenues |  | $ | 758 |  |  | $ | 768 |  |  | $ | 747 |  |

[0000950170-25-029022:8k_2_02:127]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| Services gross margin-GAAP |  |  | 81.2 | % |  |  | 80.4 | % |  |  | 79.9 | % |
| Cost of services revenues adjustments |  |  | 1.6 | % |  |  | 1.7 | % |  |  | 1.6 | % |
| Services gross margin-Non-GAAP |  |  | 82.8 | % |  |  | 82.1 | % |  |  | 81.5 | % |
| GAAP cost of services revenues |  | $ | 166 |  |  | $ | 174 |  |  | $ | 173 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (9 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (6 | ) |  |  | (5 | ) |
| Non-GAAP cost of services revenues |  | $ | 152 |  |  | $ | 159 |  |  | $ | 159 |  |
| Services revenues |  | $ | 883 |  |  | $ | 890 |  |  | $ | 859 |  |

[0000950170-25-029022:8k_2_02:128]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| OPERATING MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| Operating margin-GAAP |  |  | 22.1 | % |  |  | 20.8 | % |  |  | 22.8 | % |
| Adjustments: |  |  | 7.9 | % |  |  | 7.8 | % |  |  | 7.4 | % |
| Operating margin-Non-GAAP |  |  | 30.0 | % |  |  | 28.6 | % |  |  | 30.2 | % |
| GAAP income from operations |  | $ | 362 |  |  | $ | 345 |  |  | $ | 366 |  |
| Income from operations adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 14 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 103 |  |  |  | 103 |  |  |  | 89 |  |
| Restructuring charges |  |  | 9 |  |  |  | 12 |  |  |  | 13 |  |
| Acquisition-related expense |  |  | 2 |  |  |  | 1 |  |  |  | 3 |  |
| Gains/losses on the sale or derecognition of assets |  |  | 3 |  |  |  | — |  |  |  | — |  |
| Non-GAAP income from operations |  | $ | 492 |  |  | $ | 475 |  |  | $ | 485 |  |
| Net revenues |  | $ | 1,641 |  |  | $ | 1,658 |  |  | $ | 1,606 |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| GAAP effective tax rate |  |  | 19.2 | % |  |  | 16.9 | % |  |  | 18.1 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 1.4 | % |  |  | 3.6 | % |  |  | 0.1 | % |
| Non-GAAP effective tax rate |  |  | 20.6 | % |  |  | 20.5 | % |  |  | 18.2 | % |

[0000950170-25-029022:8k_2_02:129]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| Net cash provided by operating activities |  | $ | 385 |  |  | $ | 105 |  |  | $ | 484 |  |
| Purchases of property and equipment |  |  | (47 | ) |  |  | (45 | ) |  |  | (36 | ) |
| Free cash flow |  | $ | 338 |  |  | $ | 60 |  |  | $ | 448 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q3'FY25 |  |  | Q2'FY25 |  |  | Q3'FY24 |  |
| Net revenues |  | $ | 1,641 |  |  | $ | 1,658 |  |  | $ | 1,606 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | 72 |  |  |  | (72 | ) |  |  | 81 |  |
| Billings |  | $ | 1,713 |  |  | $ | 1,586 |  |  | $ | 1,687 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0000950170-25-029022:8k_2_02:130]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FOURTH QUARTER FISCAL 2025 |
|  |  | Fourth Quarter |
|  |  | Fiscal 2025 |
| GAAP Guidance - Net Income Per Share |  | $1.45 - $1.55 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the Fourth Quarter Fiscal 2025: |  |  |
| Amortization of intangible assets |  | $0.03 |
| Stock-based compensation expense |  | $0.48 |
| Income tax effects |  | ($0.12) |
| Total Adjustments |  | $0.39 |
| Non-GAAP Guidance - Net Income Per Share |  | $1.84 - $1.94 |

[0000950170-25-029022:8k_2_02:131]
Some items may not add or recalculate due to rounding.

[0000950170-25-029022:8k_2_02:132]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| Fiscal 2025 |
|  |  | Fiscal 2025 |
| Gross Margin - GAAP Guidance |  | ~70% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | 1% |
| Gross Margin - Non-GAAP Guidance |  | ~71% |
|  |  | Fiscal 2025 |
| Operating Margin - GAAP Guidance |  | 20% - 20.5% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | 1% |
| Stock-based compensation expense |  | 6% |
| Restructuring charges |  | 1% |
| Operating Margin - Non-GAAP Guidance |  | 28% - 28.5% |

[0000950170-25-029022:8k_2_02:133]
Some items may not add or recalculate due to rounding.

[0000950170-25-029022:8k_2_02:134]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| Fiscal 2025 |
|  |  | Fiscal 2025 |
| GAAP Guidance - Net Income Per Share |  | $5.49 - $5.59 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2025: |  |  |
| Amortization of intangible assets |  | $0.22 |
| Stock-based compensation expense |  | $1.86 |
| Restructuring charges |  | $0.18 |
| Acquisition-related expenses |  | $0.02 |
| Gains/losses on the sale or derecognition of assets |  | $0.03 |
| Income tax effects |  | ($0.63) |
| Total Adjustments |  | $1.68 |
| Non-GAAP Guidance - Net Income Per Share |  | $7.17 - $7.27 |

[0000950170-25-029022:8k_2_02:135]
Some items may not add or recalculate due to rounding.

[0000950170-25-029022:8k_2_02:136]
Contacts:

[0000950170-25-029022:8k_2_02:137]
(Press)

[0000950170-25-029022:8k_2_02:138]
Kenya Hayes

[0000950170-25-029022:8k_2_02:139]
1 703 589 7595

[0000950170-25-029022:8k_2_02:140]
kenya.hayes@netapp.com

[0000950170-25-029022:8k_2_02:141]
(Investors)

[0000950170-25-029022:8k_2_02:142]
Kris Newton

[0000950170-25-029022:8k_2_02:143]
1 408 822 3312

[0000950170-25-029022:8k_2_02:144]
kris.newton@netapp.com
