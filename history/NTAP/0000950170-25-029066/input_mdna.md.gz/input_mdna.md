# NTAP MD&A — 0000950170-25-029066


## mdna

[0000950170-25-029066:mdna:1]
[same as prior period, unchanged from 0000950170-24-130551:mdna:1]

[0000950170-25-029066:mdna:2]
[same as prior period, unchanged from 0000950170-24-130551:mdna:2]

[0000950170-25-029066:mdna:3]
[same as prior period, unchanged from 0000950170-24-130551:mdna:3]

[0000950170-25-029066:mdna:4]
[same as prior period, unchanged from 0000950170-24-130551:mdna:4]

[0000950170-25-029066:mdna:5]
[same as prior period, unchanged from 0000950170-24-130551:mdna:5]

[0000950170-25-029066:mdna:6]
[same as prior period, unchanged from 0000950170-24-130551:mdna:6]

[0000950170-25-029066:mdna:7]
[same as prior period, unchanged from 0000950170-24-130551:mdna:7]

[0000950170-25-029066:mdna:8]
[same as prior period, unchanged from 0000950170-24-130551:mdna:8]

[0000950170-25-029066:mdna:9]
[same as prior period, unchanged from 0000950170-24-130551:mdna:9]

[0000950170-25-029066:mdna:10]
During the first nine months of fiscal 2025, we repurchased approximately 7.4 million shares of our common stock at an average price of $121.46 per share, for an aggregate purchase price of $900 million. We also declared aggregate cash dividends of $1.56 per share in that period, for which we paid $319 million.

[0000950170-25-029066:mdna:11]
[same as prior period, unchanged from 0000950170-24-130551:mdna:11]

[0000950170-25-029066:mdna:12]
In the first nine months of fiscal 2025, we approved restructuring plans to redirect resources to highest return activities and reduce costs. Aggregate charges recorded from the restructuring plans during the third quarter and first nine months of fiscal 2025 totaled $9 million and $38 million, respectively.

[0000950170-25-029066:mdna:13]
[same as prior period, unchanged from 0000950170-24-130551:mdna:13]

[0000950170-25-029066:mdna:14]
[same as prior period, unchanged from 0000950170-24-130551:mdna:14]

[0000950170-25-029066:mdna:15]
[same as prior period, unchanged from 0000950170-24-130551:mdna:15]

[0000950170-25-029066:mdna:16]
[same as prior period, unchanged from 0000950170-24-130551:mdna:16]

[0000950170-25-029066:mdna:17]
|  |  | Three Months Ended |  |  | Nine Months Ended |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 46 | % |  |  | 47 | % |  |  | 45 | % |  |  | 44 | % |  |
| Services |  |  | 54 |  |  |  | 53 |  |  |  | 55 |  |  |  | 56 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 20 |  |  |  | 18 |  |  |  | 19 |  |  |  | 18 |  |  |
| Cost of services |  |  | 10 |  |  |  | 11 |  |  |  | 11 |  |  |  | 11 |  |  |
| Gross profit |  |  | 70 |  |  |  | 72 |  |  |  | 71 |  |  |  | 71 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 27 |  |  |  | 27 |  |  |  | 29 |  |  |  | 30 |  |  |
| Research and development |  |  | 15 |  |  |  | 16 |  |  |  | 16 |  |  |  | 16 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Total operating expenses |  |  | 48 |  |  |  | 49 |  |  |  | 50 |  |  |  | 52 |  |  |
| Income from operations |  |  | 22 |  |  |  | 23 |  |  |  | 20 |  |  |  | 18 |  |  |
| Other income, net |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |
| Income before income taxes |  |  | 23 |  |  |  | 24 |  |  |  | 21 |  |  |  | 19 |  |  |
| Provision for income taxes |  |  | 4 |  |  |  | 4 |  |  |  | 4 |  |  |  | 4 |  |  |
| Net income |  |  | 18 | % |  |  | 19 | % |  |  | 17 | % |  |  | 15 | % |  |

[0000950170-25-029066:mdna:18]
[same as prior period, unchanged from 0000950170-24-130551:mdna:18]

[0000950170-25-029066:mdna:19]
[same as prior period, unchanged from 0000950170-24-130551:mdna:19]

[0000950170-25-029066:mdna:20]
[same as prior period, unchanged from 0000950170-24-130551:mdna:20]

[0000950170-25-029066:mdna:21]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |
| Net revenues |  | $ | 1,641 |  |  | $ | 1,606 |  |  |  | 2 | % |  | $ | 4,840 |  |  | $ | 4,600 |  |  |  | 5 | % |

[0000950170-25-029066:mdna:22]
The increase in net revenues for the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of fiscal 2024 was due to an increase in both product revenues and services revenues. Product revenues as a percentage of net revenues decreased by one percentage point during the three months ended January 24, 2025 and increased by one percentage point during the nine months ended January 24, 2025, as compared to the corresponding periods of fiscal 2024.

[0000950170-25-029066:mdna:23]
[same as prior period, unchanged from 0000950170-24-130551:mdna:23]

[0000950170-25-029066:mdna:24]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |
| Product revenues |  | $ | 758 |  |  | $ | 747 |  |  |  | 1 | % |  | $ | 2,195 |  |  | $ | 2,043 |  |  |  | 7 | % |

[0000950170-25-029066:mdna:25]
[same as prior period, unchanged from 0000950170-24-130551:mdna:25]

[0000950170-25-029066:mdna:26]
In prior periods, we presented the hardware and software components of our GAAP product revenues to illustrate the significance and value of the Company’s software. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. Effective in fiscal 2025, we are no longer presenting the non-GAAP hardware and software components of our product revenues, as management no longer considers them to be key financial measures. The Company’s current strategy is expected to deliver investor value through growth in total revenues, including product revenues, while maintaining operational discipline to drive earnings leverage. While software continues to be the primary value driver of our products, NetApp is primarily focused on driving growth in total product revenues, through the sale of configured storage

[0000950170-25-029066:mdna:27]
systems comprised of both hardware and software, with less focus on the pricing of each component. Additionally, the Company is considering potential opportunities to simplify pricing for certain products in the future, which may eliminate the existence of separate prices for hardware and software components and/or impact our ability to allocate between them.

[0000950170-25-029066:mdna:28]
[same as prior period, unchanged from 0000950170-24-130551:mdna:27]

[0000950170-25-029066:mdna:29]
Total product revenues increased in the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of the prior year due to higher sales of C-Series all-flash array systems.

[0000950170-25-029066:mdna:30]
[same as prior period, unchanged from 0000950170-24-130551:mdna:29]

[0000950170-25-029066:mdna:31]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |
| Services revenues |  | $ | 883 |  |  | $ | 859 |  |  |  | 3 | % |  | $ | 2,645 |  |  | $ | 2,557 |  |  |  | 3 | % |
| Support |  |  | 621 |  |  |  | 631 |  |  |  | (2 | )% |  |  | 1,887 |  |  |  | 1,865 |  |  |  | 1 | % |
| Professional and other services |  |  | 88 |  |  |  | 77 |  |  |  | 14 | % |  |  | 257 |  |  |  | 233 |  |  |  | 10 | % |
| Public cloud |  |  | 174 |  |  |  | 151 |  |  |  | 15 | % |  |  | 501 |  |  |  | 459 |  |  |  | 9 | % |

[0000950170-25-029066:mdna:32]
[same as prior period, unchanged from 0000950170-24-130551:mdna:31]

[0000950170-25-029066:mdna:33]
[same as prior period, unchanged from 0000950170-24-130551:mdna:32]

[0000950170-25-029066:mdna:34]
Support revenues decreased marginally in the third quarter of fiscal 2025 and increased marginally in the first nine months of fiscal 2025, compared to the corresponding periods of the prior year.

[0000950170-25-029066:mdna:35]
Professional and other services revenues increased by $11 million and $24 million in the third quarter and first nine months of fiscal 2025, respectively, compared to the corresponding periods of the prior year.

[0000950170-25-029066:mdna:36]
[same as prior period, unchanged from 0000950170-24-130551:mdna:35]

[0000950170-25-029066:mdna:37]
[same as prior period, unchanged from 0000950170-24-130551:mdna:36]

[0000950170-25-029066:mdna:38]
Public Cloud revenues increased in the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of the prior year, due to higher customer demand, driven by NetApp’s diversified cloud offerings and an overall growth in the cloud market.

[0000950170-25-029066:mdna:39]
[same as prior period, unchanged from 0000950170-24-130551:mdna:38]

[0000950170-25-029066:mdna:40]
[same as prior period, unchanged from 0000950170-24-130551:mdna:39]

[0000950170-25-029066:mdna:41]
(1) cost of product revenues, composed of (a) cost of Hybrid Cloud product revenues, which includes the costs of manufacturing and shipping our products, inventory write-downs, and warranty costs, and (b) unallocated cost of product revenues, which includes stock-based compensation; and

[0000950170-25-029066:mdna:42]
[same as prior period, unchanged from 0000950170-24-130551:mdna:41]

[0000950170-25-029066:mdna:43]
[same as prior period, unchanged from 0000950170-24-130551:mdna:44]

[0000950170-25-029066:mdna:44]
[same as prior period, unchanged from 0000950170-24-130551:mdna:42]

[0000950170-25-029066:mdna:45]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |
| Cost of product revenues |  | $ | 330 |  |  | $ | 282 |  |  |  | 17 | % |  | $ | 906 |  |  | $ | 823 |  |  |  | 10 | % |
| Hybrid Cloud |  |  | 328 |  |  |  | 280 |  |  |  | 17 | % |  |  | 901 |  |  |  | 819 |  |  |  | 10 | % |
| Unallocated |  |  | 2 |  |  |  | 2 |  |  |  | — | % |  |  | 5 |  |  |  | 4 |  |  |  | 25 | % |

[0000950170-25-029066:mdna:46]
[same as prior period, unchanged from 0000950170-24-130551:mdna:45]

[0000950170-25-029066:mdna:47]
Cost of Hybrid Cloud product revenues represented approximately 43% and 41% of product revenues for the third quarter and first nine months of fiscal 2025, respectively, compared to 37% and 40%, respectively, for the corresponding periods of fiscal 2024. Materials costs represented 89% of cost of Hybrid Cloud product revenues for the third quarter and first nine months of fiscal 2025, compared to 89% and 88%, respectively, for the corresponding periods of fiscal 2024.

[0000950170-25-029066:mdna:48]
Materials costs increased by $42 million and $80 million, respectively, in the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of the prior year.

[0000950170-25-029066:mdna:49]
Hybrid Cloud product gross margins decreased by approximately six percentage points and one percentage point in the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of the prior year due to higher component and freight costs.

[0000950170-25-029066:mdna:50]
[same as prior period, unchanged from 0000950170-24-130551:mdna:49]

[0000950170-25-029066:mdna:51]
Unallocated cost of product revenues were relatively flat in the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of the prior year.

[0000950170-25-029066:mdna:52]
[same as prior period, unchanged from 0000950170-24-130551:mdna:51]

[0000950170-25-029066:mdna:53]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |
| Cost of services revenues |  | $ | 166 |  |  | $ | 173 |  |  |  | (4 | )% |  | $ | 514 |  |  | $ | 520 |  |  |  | (1 | )% |
| Support |  |  | 48 |  |  |  | 49 |  |  |  | (2 | )% |  |  | 149 |  |  |  | 146 |  |  |  | 2 | % |
| Professional and other services |  |  | 63 |  |  |  | 58 |  |  |  | 9 | % |  |  | 191 |  |  |  | 176 |  |  |  | 9 | % |
| Public cloud |  |  | 41 |  |  |  | 52 |  |  |  | (21 | )% |  |  | 131 |  |  |  | 155 |  |  |  | (15 | )% |
| Unallocated |  |  | 14 |  |  |  | 14 |  |  |  | — | % |  |  | 43 |  |  |  | 43 |  |  |  | — | % |

[0000950170-25-029066:mdna:54]
[same as prior period, unchanged from 0000950170-24-130551:mdna:53]

[0000950170-25-029066:mdna:55]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, increased in the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of fiscal 2024. Cost of Hybrid Cloud services revenues represented approximately 16% of Hybrid Cloud services revenues for the third quarter and first nine months of fiscal 2025 compared to 15% for the corresponding periods of fiscal 2024.

[0000950170-25-029066:mdna:56]
Hybrid Cloud support gross margins were relatively flat in the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of the prior year. Hybrid Cloud professional and other services gross margins increased by approximately four percentage points and one percentage point, respectively, in the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of fiscal 2024 due to the mix of services provided.

[0000950170-25-029066:mdna:57]
[same as prior period, unchanged from 0000950170-24-130551:mdna:56]

[0000950170-25-029066:mdna:58]
Cost of Public Cloud revenues decreased in each the third quarter and first nine months of fiscal 2025. Public Cloud gross margins increased by eleven percentage points and eight percentage points, respectively, in the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of fiscal 2024. The decrease in cost of Public Cloud revenues and improved gross margins was due to cost optimization that included a decrease in fixed assets depreciation, and the mix of offerings provided.

[0000950170-25-029066:mdna:59]
[same as prior period, unchanged from 0000950170-24-130551:mdna:58]

[0000950170-25-029066:mdna:60]
[same as prior period, unchanged from 0000950170-24-130551:mdna:60]

[0000950170-25-029066:mdna:61]
Unallocated cost of services revenues were relatively flat in the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of the prior year.

[0000950170-25-029066:mdna:62]
[same as prior period, unchanged from 0000950170-24-130551:mdna:61]

[0000950170-25-029066:mdna:63]
[same as prior period, unchanged from 0000950170-24-130551:mdna:62]

[0000950170-25-029066:mdna:64]
Sales and marketing, research and development, and general and administrative expenses for the third quarter and first nine months of fiscal 2025 totaled $772 million, or 47% of net revenues, and $2,389 million, or 49% of net revenues, respectively, reflecting a decrease of one and two percentage points, respectively, compared to the corresponding periods of fiscal 2024, primarily due to the increase in net revenues.

[0000950170-25-029066:mdna:65]
[same as prior period, unchanged from 0000950170-24-130551:mdna:64]

[0000950170-25-029066:mdna:66]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses in the third quarter and first nine months of fiscal 2025, were relatively flat compared to the corresponding periods of the prior year.

[0000950170-25-029066:mdna:67]
[same as prior period, unchanged from 0000950170-24-130551:mdna:66]

[0000950170-25-029066:mdna:68]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 451 |  |  | $ | 439 |  |  |  | 3 | % |  | $ | 1,407 |  |  | $ | 1,368 |  |  |  | 3 | % |

[0000950170-25-029066:mdna:69]
[same as prior period, unchanged from 0000950170-24-130551:mdna:68]

[0000950170-25-029066:mdna:70]
The increase in sales and marketing expenses in the third quarter of fiscal 2025 compared to the corresponding period of the prior year were primarily due to higher compensation costs and higher spend on outside services.

[0000950170-25-029066:mdna:71]
The increase in sales and marketing expenses in the first nine months of fiscal 2025 compared to the corresponding period of the prior year were primarily due to an increase in sales commissions expenses.

[0000950170-25-029066:mdna:72]
[same as prior period, unchanged from 0000950170-24-130551:mdna:70]

[0000950170-25-029066:mdna:73]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |
| Research and development expenses |  | $ | 247 |  |  | $ | 249 |  |  |  | (1 | )% |  | $ | 756 |  |  | $ | 758 |  |  |  | — | % |

[0000950170-25-029066:mdna:74]
[same as prior period, unchanged from 0000950170-24-130551:mdna:72]

[0000950170-25-029066:mdna:75]
Research and development expenses remained relatively flat in the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of the prior year.

[0000950170-25-029066:mdna:76]
[same as prior period, unchanged from 0000950170-24-130551:mdna:75]

[0000950170-25-029066:mdna:77]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |
| General and administrative expenses |  | $ | 74 |  |  | $ | 81 |  |  |  | (9 | )% |  | $ | 226 |  |  | $ | 230 |  |  |  | (2 | )% |

[0000950170-25-029066:mdna:78]
[same as prior period, unchanged from 0000950170-24-130551:mdna:77]

[0000950170-25-029066:mdna:79]
General and administrative expenses decreased in the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of the prior year, primarily attributable to lower spend on certain business transformation projects.

[0000950170-25-029066:mdna:80]
[same as prior period, unchanged from 0000950170-24-130551:mdna:79]

[0000950170-25-029066:mdna:81]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |
| Restructuring charges |  | $ | 9 |  |  | $ | 13 |  |  |  | (31 | )% |  | $ | 38 |  |  | $ | 44 |  |  |  | (14 | )% |

[0000950170-25-029066:mdna:82]
In the first nine months of fiscal 2025, management approved restructuring plans to redirect resources to highest return activities and reduce costs, which included a reduction of our global workforce by approximately 4%. This includes, in the third quarter of fiscal 2025, a plan approved related to the anticipated sale of our cloud optimization and management software business known as Spot by NetApp, resulting in the elimination of certain roles. Charges related to the plans consisted primarily of employee severance-related costs. The activities under the plans are expected to be substantially complete by the end of fiscal 2025.

[0000950170-25-029066:mdna:83]
In the first nine months of fiscal 2024, management executed restructuring plans to redirect resources to highest return activities, and to optimize our global office space for our hybrid work model. In connection with these plans, we reduced our global workforce by approximately 2% and terminated certain real estate leases in various countries, resulting in restructuring charges comprised primarily of employee severance-related expenses and lease termination charges. The activities under these plans were substantially complete by the end of fiscal 2024.

[0000950170-25-029066:mdna:84]
[same as prior period, unchanged from 0000950170-24-130551:mdna:84]

[0000950170-25-029066:mdna:85]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |
| Acquisition-related expense |  | $ | 2 |  |  | $ | 3 |  |  |  | (33 | )% |  | $ | 4 |  |  | $ | 9 |  |  |  | (56 | )% |

[0000950170-25-029066:mdna:86]
Acquisition-related expenses decreased by $1 million and $5 million, respectively, in the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of the prior year.

[0000950170-25-029066:mdna:87]
[same as prior period, unchanged from 0000950170-24-130551:mdna:87]

[0000950170-25-029066:mdna:88]
[same as prior period, unchanged from 0000950170-24-130551:mdna:88]

[0000950170-25-029066:mdna:89]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |
| Interest income |  | $ | 20 |  |  | $ | 27 |  |  |  | (26 | )% |  | $ | 83 |  |  | $ | 80 |  |  |  | 4 | % |
| Interest expense |  |  | (12 | ) |  |  | (17 | ) |  |  | (29 | )% |  |  | (43 | ) |  |  | (48 | ) |  |  | (10 | )% |
| Other, net |  |  | — |  |  |  | 6 |  |  | NM |  |  |  | — |  |  |  | 3 |  |  | NM |  |
| Total |  | $ | 8 |  |  | $ | 16 |  |  | NM |  |  | $ | 40 |  |  | $ | 35 |  |  | NM |  |

[0000950170-25-029066:mdna:90]
[same as prior period, unchanged from 0000950170-24-130551:mdna:90]

[0000950170-25-029066:mdna:91]
Interest income decreased in the third quarter of fiscal 2025 primarily due to the lower average outstanding balances of our cash and investments and lower yields thereon, compared to the corresponding period of the prior year. Interest income increased in the first nine months of fiscal 2025 compared to the corresponding period of the prior year, primarily due to higher yields earned.

[0000950170-25-029066:mdna:92]
Interest expense decreased in the third quarter and first nine months of fiscal 2025 compared to the corresponding periods of fiscal 2024, due to the repayment of our 3.30% Senior Notes in September 2024.

[0000950170-25-029066:mdna:93]
[same as prior period, unchanged from 0000950170-24-130551:mdna:92]

[0000950170-25-029066:mdna:94]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |  | January 24, 2025 |  |  | January 26, 2024 |  |  | % Change |  |
| Provision for income taxes |  | $ | 71 |  |  | $ | 69 |  |  |  | 3 | % |  | $ | 183 |  |  | $ | 188 |  |  |  | (3 | )% |

[0000950170-25-029066:mdna:95]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. Our effective tax rate for the three and nine months ended January 24, 2025 includes an increase in discrete tax benefits related to stock compensation compared to the corresponding periods of the prior year. Our effective tax rate for the three months ended January 24, 2025 also includes an increase in discrete tax expense related to prior period adjustments compared to the corresponding period of the prior year. Our effective tax rate for the three and nine months ended January 26, 2024 included a benefit for increased fiscal 2024 foreign tax credits resulting from legislative guidance for those periods partially offset by an increase in stock compensation for which no tax benefit is recorded.

[0000950170-25-029066:mdna:96]
As of January 24, 2025, we had $228 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $169 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $169 million have been recorded in other long-term liabilities.

[0000950170-25-029066:mdna:97]
[same as prior period, unchanged from 0000950170-24-130551:mdna:96]

[0000950170-25-029066:mdna:98]
| (In millions) |  | January 24, 2025 |  |  | April 26, 2024 |  |
| Cash, cash equivalents and short-term investments |  | $ | 2,261 |  |  | $ | 3,252 |  |
| Principal amount of debt |  | $ | 2,000 |  |  | $ | 2,400 |  |

[0000950170-25-029066:mdna:99]
[same as prior period, unchanged from 0000950170-24-130551:mdna:99]

[0000950170-25-029066:mdna:100]
|  |  | Nine Months Ended |  |
| (In millions) |  | January 24, 2025 |  |  | January 26, 2024 |  |
| Net cash provided by operating activities |  | $ | 831 |  |  | $ | 1,072 |  |
| Net cash provided by (used in) investing activities |  |  | 460 |  |  |  | (438 | ) |
| Net cash used in financing activities |  |  | (1,679 | ) |  |  | (1,120 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (3 | ) |  |  | (10 | ) |
| Net change in cash, cash equivalents and restricted cash |  | $ | (391 | ) |  | $ | (496 | ) |

[0000950170-25-029066:mdna:101]
[same as prior period, unchanged from 0000950170-24-130551:mdna:101]

[0000950170-25-029066:mdna:102]
As of January 24, 2025, our cash, cash equivalents and short-term investments were $2.3 billion, which represents a decrease of $1.0 billion during the first nine months of fiscal 2025. The decrease was primarily due to $900 million used for the repurchase of our common stock, a $400 million principal repayment of our 3.30% Senior Notes due September 2024, $319 million used for the payment of dividends, $168 million used for payment of taxes related to net share settlement of stock awards and $133 million used for purchases of property and equipment, offset by $831 million provided by operating activities and $108 million in proceeds from the issuance of common stock under employee stock award plans. Our net working capital deficit was $287 million as of January 24, 2025, a reduction of $1.1 billion when compared to April 26, 2024, primarily due to the decrease in cash, cash equivalents and short-term investments discussed above and the net increase in the current portion of long-term debt after the repayment of our 3.30% Senior Notes and the reclassification of $750 million principal amount of our Senior Notes from long-term to current liabilities.

[0000950170-25-029066:mdna:103]
[same as prior period, unchanged from 0000950170-24-130551:mdna:103]

[0000950170-25-029066:mdna:104]
During the first nine months of fiscal 2025, we generated cash from operating activities of $831 million, reflecting net income of $846 million which was adjusted for non-cash depreciation and amortization expense of $190 million and non-cash stock-based compensation expense of $291 million, compared to $1.1 billion of cash generated from operating activities during the first nine months of fiscal 2024.

[0000950170-25-029066:mdna:105]
Significant changes in assets and liabilities in the first nine months of fiscal 2025 included the following:

[0000950170-25-029066:mdna:106]
•
Accounts receivable decreased $104 million, reflecting more favorable invoicing linearity in the first nine months of fiscal 2025 compared to the last nine months of fiscal 2024.

[0000950170-25-029066:mdna:107]
•
Inventory increased by $82 million, primarily due to higher raw materials purchases.

[0000950170-25-029066:mdna:108]
•
Accrued expenses decreased by $94 million, primarily due to employee compensation payments related to our fiscal 2024 incentive compensation plan accrual.

[0000950170-25-029066:mdna:109]
•
Deferred revenue and financed unearned services revenue decreased by $92 million, due to a decrease in deferred revenue for software and hardware support contracts.

[0000950170-25-029066:mdna:110]
[same as prior period, unchanged from 0000950170-24-130551:mdna:109]

[0000950170-25-029066:mdna:111]
[same as prior period, unchanged from 0000950170-24-130551:mdna:110]

[0000950170-25-029066:mdna:112]
During the first nine months of fiscal 2025, we generated $590 million from maturities and sales of investments, net of purchases and paid $133 million for capital expenditures, as compared to the same period of fiscal 2024, in which we used $329 million for the purchases of investments, net of maturities and sales, and paid $109 million for capital expenditures.

[0000950170-25-029066:mdna:113]
We expect the sale of our Spot by NetApp business to close in the fourth quarter of fiscal 2025 resulting in estimated up-front cash proceeds of approximately $70 million before certain transaction costs and customary closing adjustments.

[0000950170-25-029066:mdna:114]
[same as prior period, unchanged from 0000950170-24-130551:mdna:112]

[0000950170-25-029066:mdna:115]
During the first nine months of fiscal 2025, cash flows used in financing activities totaled $1.7 billion and included $900 million for the repurchase of approximately 7.4 million shares of common stock, $400 million principal repayment upon maturity of our 3.30% Senior Notes due in September 2024 and $319 million for the payment of dividends. During the first nine months of fiscal 2024, cash flows used in financing activities totaled $1.1 billion and included $800 million for the repurchase of approximately 11 million shares of common stock and $312 million for the payment of dividends.

[0000950170-25-029066:mdna:116]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including cash, cash equivalents and short-term investments, cash generated from operations, and our ability to access capital markets and committed credit lines will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months and thereafter for the foreseeable future. We may choose to periodically raise additional debt capital based on certain conditions, including the refinancing of upcoming maturities and/or for potential strategic acquisitions and investments. Our ability to obtain this or any additional financing that we may pursue or need, will depend on, among other things, our business plans, operating performance and the condition of the capital markets at the time we seek financing. We may not be able to obtain such financing on terms acceptable to us or at all. In the event our liquidity is insufficient and we are unable to enter into new financing arrangements, we may be required to curtail spending and implement additional cost saving measures and restructuring actions. We cannot be certain that we will continue to generate cash flows at or above current levels. For further discussion of factors that could affect our cash flows and liquidity requirements, see Item 1A. Risk Factors.

[0000950170-25-029066:mdna:117]
[same as prior period, unchanged from 0000950170-24-130551:mdna:115]

[0000950170-25-029066:mdna:118]
Our principal sources of liquidity as of January 24, 2025 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-25-029066:mdna:119]
[same as prior period, unchanged from 0000950170-24-130551:mdna:117]

[0000950170-25-029066:mdna:120]
|  |  | January 24, 2025 |  |  | April 26, 2024 |  |
| Cash and cash equivalents |  | $ | 1,511 |  |  | $ | 1,903 |  |
| Short-term investments |  |  | 750 |  |  |  | 1,349 |  |
| Total |  | $ | 2,261 |  |  | $ | 3,252 |  |

[0000950170-25-029066:mdna:121]
As of January 24, 2025 and April 26, 2024, $2.0 billion and $2.1 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.3 billion and $1.2 billion, respectively, were available in the U.S.

[0000950170-25-029066:mdna:122]
[same as prior period, unchanged from 0000950170-24-130551:mdna:120]

[0000950170-25-029066:mdna:123]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of January 24, 2025.

[0000950170-25-029066:mdna:124]
[same as prior period, unchanged from 0000950170-24-130551:mdna:122]

[0000950170-25-029066:mdna:125]
[same as prior period, unchanged from 0000950170-24-130551:mdna:123]

[0000950170-25-029066:mdna:126]
The following table summarizes the principal amount of our Senior Notes as of January 24, 2025 (in millions):

[0000950170-25-029066:mdna:127]
|  |  | Amount |  |
| 1.875% Senior Notes Due June 2025 |  | $ | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,000 |  |

[0000950170-25-029066:mdna:128]
[same as prior period, unchanged from 0000950170-24-130551:mdna:126]

[0000950170-25-029066:mdna:129]
On September 30, 2024, upon maturity, we repaid our 3.30% Senior Notes due September 2024 for an aggregate amount of $407 million, comprised of the principal and unpaid interest.

[0000950170-25-029066:mdna:130]
Commercial Paper Program and Credit Facility

[0000950170-25-029066:mdna:131]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of January 24, 2025.

[0000950170-25-029066:mdna:132]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 24, 2025, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-25-029066:mdna:133]
35

[0000950170-25-029066:mdna:134]
[same as prior period, unchanged from 0000950170-24-130551:mdna:131]

[0000950170-25-029066:mdna:135]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2025 to be between approximately $30 million and $60 million.

[0000950170-25-029066:mdna:136]
[same as prior period, unchanged from 0000950170-24-130551:mdna:133]

[0000950170-25-029066:mdna:137]
The Tax Cuts and Jobs Act of 2017 imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits that had not previously been subject to U.S. income tax. As of January 24, 2025, the outstanding payment related to the transition tax is estimated to be approximately $100 million which is expected to be paid during fiscal 2026. Our estimates for future transition tax payments, however, could change with further guidance or review from U.S. federal and state tax authorities or other regulatory bodies.

[0000950170-25-029066:mdna:138]
[same as prior period, unchanged from 0000950170-24-130551:mdna:135]

[0000950170-25-029066:mdna:139]
On February 20, 2025, we declared a cash dividend of $0.52 per share of common stock, payable on April 23, 2025, to holders of record as of the close of business on April 4, 2025.

[0000950170-25-029066:mdna:140]
In the first quarter of fiscal 2025, our Board of Directors authorized the repurchase of an additional $1.0 billion of our common stock. As of January 24, 2025, our Board of Directors had authorized cumulative repurchases of up to $17.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through January 24, 2025, we repurchased a total of 379 million shares of our common stock at an average price of $43.59 per share, for an aggregate purchase price of $16.5 billion. As of January 24, 2025, the remaining authorized amount for stock repurchases under this program was $0.6 billion.

[0000950170-25-029066:mdna:141]
[same as prior period, unchanged from 0000950170-24-130551:mdna:138]

[0000950170-25-029066:mdna:142]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled approximately $1.1 billion at January 24, 2025.

[0000950170-25-029066:mdna:143]
[same as prior period, unchanged from 0000950170-24-130551:mdna:140]

[0000950170-25-029066:mdna:144]
We have and continue to enter into financing and leasing contracts through the ordinary course of business. These arrangements and related financing guarantees are described in Note 14 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1. There has been no material change in our financing guarantees as described in our 2024 Annual Report on Form 10-K.

[0000950170-25-029066:mdna:145]
Legal Contingencies

[0000950170-25-029066:mdna:146]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 14 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1.

[0000950170-25-029066:mdna:147]
[same as prior period, unchanged from 0000950170-24-130551:mdna:144]

[0000950170-25-029066:mdna:148]
[same as prior period, unchanged from 0000950170-24-130551:mdna:145]
