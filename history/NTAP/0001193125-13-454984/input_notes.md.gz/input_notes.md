# NTAP notes — 0001193125-13-454984


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-13-454984:notes:1]
Property and equipment, net (in
 millions):

[0001193125-13-454984:notes:2]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Land and land improvements |  | $ | 265.7 |  |  | $ | 265.5 |  |
| Buildings and building improvements |  |  | 540.8 |  |  |  | 534.8 |  |
| Leasehold improvements |  |  | 101.8 |  |  |  | 100.3 |  |
| Computer, production, engineering and other equipment |  |  | 747.8 |  |  |  | 714.0 |  |
| Software |  |  | 430.1 |  |  |  | 422.6 |  |
| Furniture and fixtures |  |  | 84.9 |  |  |  | 82.2 |  |
| Construction-in-progress |  |  | 39.6 |  |  |  | 19.9 |  |
|  |  |  | 2,210.7 |  |  |  | 2,139.3 |  |
| Accumulated depreciation and amortization |  |  | (1,067.8 | ) |  |  | (968.4 | ) |
| Property and equipment, net |  | $ | 1,142.9 |  |  | $ | 1,170.9 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-13-454984:notes:3]
As of
 October 25, 2013, future amortization expense related to
 purchased intangible assets is as follows (in millions):

[0001193125-13-454984:notes:4]
| Fiscal Year |  | Amount |  |
| Remainder of 2014 |  | $ | 29.5 |  |
| 2015 |  |  | 57.8 |  |
| 2016 |  |  | 53.6 |  |
| 2017 |  |  | 6.7 |  |
| 2018 |  |  | 3.3 |  |
| Total |  | $ | 150.9 |  |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001193125-13-454984:notes:5]
contracts have a maturity of less than six months. The notional
 amount of our outstanding U.S. dollar equivalent foreign currency
 exchange forward contracts consisted of the following (in
 millions):

[0001193125-13-454984:notes:6]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 181.3 |  |  | $ | 108.4 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  |  | 180.3 |  |  |  | 158.2 |  |
| Forward contracts purchased |  |  | 258.7 |  |  |  | 358.4 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-13-454984:notes:7]
[same as prior period, unchanged from 0001193125-13-352036:notes:118]

[0001193125-13-454984:notes:8]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Arrow Electronics, Inc.(1) |  |  | 23 | % |  |  | 21 | % |  |  | 22 | % |  |  | 19 | % |
| Avnet, Inc.(1) |  |  | 16 | % |  |  | 15 | % |  |  | 16 | % |  |  | 15 | % |

[0001193125-13-454984:notes:9]
| (1) | Net revenues for Arrow Electronics, Inc. for the three and six months ended October 26, 2012 have been corrected from 20% and 18%, respectively, previously disclosed to 21% and 19%, respectively. Net revenues for Avnet, Inc. for the six months ended October 26, 2012 have been corrected from 14% previously disclosed to 15%. |


## us-gaap:ScheduleOfAntidilutiveSecuritiesExcludedFromComputationOfEarningsPerShareTextBlock

[0001193125-13-454984:notes:10]
The following potential weighted-average shares of common stock
 have been excluded from the diluted net income per share
 calculations, as their effect would have been anti-dilutive (in
 millions):

[0001193125-13-454984:notes:11]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Employee equity award plans |  |  | 7.2 |  |  |  | 16.3 |  |  |  | 6.9 |  |  |  | 17.1 |  |


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-13-454984:notes:12]
The effect of derivative instruments not designated as hedging
 instruments recognized in other income (expense), net on our
 condensed consolidated statements of operations was as follows (in
 millions):

[0001193125-13-454984:notes:13]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
|  |  | Gain (Loss) Recognized into Income |  |  | Gain Recognized into Income |  |
| Foreign currency exchange forward contracts |  | $ | 0.6 |  |  | $ | (9.7 | ) |  | $ | 0.8 |  |  | $ | 6.2 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-13-454984:notes:14]
8.  Financing
 Arrangements

[0001193125-13-454984:notes:15]
Long-term Debt

[0001193125-13-454984:notes:16]
The following table summarizes the carrying value of our
 long-term debt (in millions):

[0001193125-13-454984:notes:17]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total principal amount |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.0 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total debt |  |  | 995.0 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term portion |  | $ | 995.0 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |

[0001193125-13-454984:notes:18]
N/A - Not
 Applicable

[0001193125-13-454984:notes:19]
Senior Notes

[0001193125-13-454984:notes:20]
Our Senior Notes, issued in December 2012, are unsecured,
 unsubordinated obligations, which pay interest semi-annually on
 June 15 and December 15 and rank equally in right of
 payment with any future senior unsecured indebtedness. Interest
 expense associated with the Senior Notes was $6.2 million and $12.5
 million for the three and six months ended October 25, 2013,
 respectively.

[0001193125-13-454984:notes:21]
We may redeem the Senior Notes in whole or in part, at any time
 at our option at specified redemption prices. In addition, upon the
 occurrence of certain change of control triggering events, we may
 be required to repurchase the Senior Notes at 101% of their
 aggregate principal amount, plus accrued and unpaid interest to the
 date of repurchase. The Senior Notes also include covenants that
 limit our ability to incur debt secured by liens on assets or on
 shares of stock or indebtedness of our subsidiaries; to engage in
 sale and lease-back transactions; and to consolidate, merge or sell
 all or substantially all of our assets. As of October 25,
 2013, we were in compliance with all covenants associated with the
 Senior Notes.

[0001193125-13-454984:notes:22]
1.75% Convertible Senior Notes due 2013

[0001193125-13-454984:notes:23]
On June 10, 2008, we issued $1,265.0 million
 aggregate principal amount of 1.75% Convertible Senior Notes
 (the Convertible Notes) with a maturity date of June 1, 2013.
 The Convertible Notes were unsecured, unsubordinated obligations of
 the Company and paid interest in cash semi-annually at a rate of
 1.75% per annum. Upon maturity, the Convertible Notes were
 converted into shares of common stock at a conversion rate of 31.40
 shares of common stock per $1,000 principal amount of the
 Convertible Notes (which represented the effective conversion price
 of $31.85 per share). Upon conversion in June 2013, the holders
 received cash for the principal amount of the Convertible Notes and
 an aggregate of 4.9 million shares of common stock for the
 $178.9 million excess of the conversion value over the principal
 amount.

[0001193125-13-454984:notes:24]
We separately accounted for the liability and equity components
 of the Convertible Notes. The initial debt component of the
 Convertible Notes was valued at $1,017.0 million based on the
 contractual cash flows discounted at an appropriate comparable
 market non-convertible debt borrowing rate at the date of issuance
 of 6.31%, with the equity component representing the residual
 amount of the proceeds of $248.0 million which was recorded as
 a debt discount. Issuance costs were allocated pro-rata based on
 the relative initial carrying amounts of the debt and equity
 components. As a result, $5.2 million of the issuance costs
 was allocated to the equity component of the Convertible Notes, and
 $21.4 million of the issuance costs remained classified as
 other non-current assets. The debt discount and the issuance costs
 allocated to the debt component were amortized as additional
 interest expense over the term of the Convertible Notes using the
 effective interest method.

[0001193125-13-454984:notes:25]
Convertible Note Hedges and Warrants

[0001193125-13-454984:notes:26]
Concurrent with the issuance of the Convertible Notes, we
 purchased Convertible Note hedges and sold warrants. The separate
 Convertible Note hedge and warrant transactions were structured to
 reduce the potential future economic dilution associated with the
 conversion of the Convertible Notes.

[0001193125-13-454984:notes:27]
• Convertible Note Hedges: As of April 26, 2013, we
 had arrangements with counterparties to buy up to approximately
 31.8 million shares of our common stock, at a price of $31.85
 per share. In June 2013, concurrent with the repayment and
 conversion of the Convertible Notes, we exercised the Convertible
 Note hedges that were net settled for an aggregate of
 3.9 million shares from the counterparties.

[0001193125-13-454984:notes:28]
• Warrants: As of April 26, 2013, we had outstanding
 warrants for certain counterparties to acquire 39.7 million
 shares of our common stock at an exercise price of $41.28 per
 share. The warrants were exercisable on a series of days commencing
 on September 3, 2013 and ending on October 28, 2013. The
 number of warrants and exercise price were adjusted in July 2013 to
 39.9 million and $41.12 per share, respectively, to reflect
 our July 2013 dividend. On October 17, 2013, the exercise
 price of the warrants then outstanding was further adjusted to
 $40.97 per share to reflect our October 2013 dividend. Through
 October 25, 2013, 31.9 million warrants were exercised
 and net settled with 1.1 million shares of our common stock
 equal to the difference between the market price on the date of
 exercise and the exercise price of the warrants on the respective
 exercise dates. The remaining warrants had an exercise price
 greater than the market price and expired unexercised by
 October 28, 2013.

[0001193125-13-454984:notes:29]
Interest Expense on Convertible Notes

[0001193125-13-454984:notes:30]
The following table presents the amount of interest expense
 related to the Convertible Notes (in millions):

[0001193125-13-454984:notes:31]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 2.5 |  |  | $ | 11.0 |  |
| Amortization of debt discount |  |  | 13.6 |  |  |  | 7.1 |  |  |  | 27.1 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 0.6 |  |  |  | 2.4 |  |
| Less capitalized interest |  |  | (0.6 | ) |  |  | 0.0 |  |  |  | (1.1 | ) |
| Total interest expense related to Convertible Notes |  | $ | 19.7 |  |  | $ | 10.2 |  |  | $ | 39.4 |  |

[0001193125-13-454984:notes:32]
No interest expense related to the Convertible Notes was
 recognized in the three months ended October 25, 2013 due to
 their maturity.

[0001193125-13-454984:notes:33]
Debt Maturities

[0001193125-13-454984:notes:34]
As of October 25, 2013, our aggregate future principal
 debt maturities are as follows (in millions):

[0001193125-13-454984:notes:35]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750.0 |  |
| Thereafter |  |  | 250.0 |  |
| Total |  | $ | 1,000.0 |  |

[0001193125-13-454984:notes:36]
Credit Facility

[0001193125-13-454984:notes:37]
In December 2012, we entered into a credit agreement with a
 syndicated group of lenders that provides for an unsecured $250.0
 million revolving credit facility that is comprised of revolving
 loans, Eurocurrency loans and/or swingline loans. The credit
 facility includes a $100.0 million foreign currency sub-facility, a
 $50.0 million letter of credit sub-facility and a $10.0 million
 swingline sub-facility available on same-day notice. Available
 borrowings under the credit facility are reduced by the amount of
 any outstanding borrowings on the sub-facilities. We may also,
 subject to certain requirements, request an increase in the
 facility up to an additional $100.0 million and request two
 additional one-year extensions, subject to certain conditions. The
 proceeds from the facility may be used by us for general corporate
 purposes.

[0001193125-13-454984:notes:38]
Borrowings under the facility, except for swingline loans,
 accrue interest in arrears at an alternate base rate as defined in
 the credit agreement or, at our option, an adjusted London
 Interbank Offered Rate (LIBOR) plus in each case, a spread (based
 on our public debt ratings and the type of loan) ranging from 0.2%
 to 1.2%. Swingline borrowings accrue interest at an alternate base
 rate. In addition, we are required to pay fees to maintain the
 credit facility, whether or not we have outstanding borrowings. The
 facility terminates on December 21, 2017 if no extensions have
 been requested and contains financial covenants requiring us to
 maintain a maximum leverage ratio of not more than 3.0:1.0 and a
 minimum interest coverage ratio of not less than 3.5:1.0. The
 facility contains customary affirmative and negative covenants,
 including covenants that limit our ability to incur debt secured by
 liens on assets or indebtedness of our subsidiaries and to
 consolidate, merge or sell all or substantially all of our assets.
 As of October 25, 2013, no borrowings were outstanding under
 the facility and we were in compliance with all covenants
 associated with the facility.

[0001193125-13-454984:notes:39]
Other Long-Term Financing Arrangements

[0001193125-13-454984:notes:40]
The following presents the amounts due under other long-term
 financing arrangements (in millions):

[0001193125-13-454984:notes:41]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Current portion of other long-term financing arrangements |  | $ | 7.1 |  |  | $ | 5.2 |  |
| Non-current portion of other long-term financing arrangements |  |  | 9.5 |  |  |  | 5.6 |  |
| Total |  | $ | 16.6 |  |  | $ | 10.8 |  |


## us-gaap:ScheduleOfShareBasedCompensationArrangementByShareBasedPaymentAwardOptionsGrantsInPeriodGrantDateIntrinsicValueTableTextBlock

[0001193125-13-454984:notes:42]
Additional information related to our stock options is
 summarized below (in millions, except per share
 information):

[0001193125-13-454984:notes:43]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Weighted-average fair value per share granted |  | $ | 10.49 |  |  | $ | 12.40 |  |  | $ | 9.86 |  |  | $ | 10.86 |  |
| Intrinsic value of exercises |  | $ | 33.0 |  |  | $ | 10.4 |  |  | $ | 60.4 |  |  | $ | 15.8 |  |
| Proceeds received from exercises |  | $ | 56.4 |  |  | $ | 12.8 |  |  | $ | 113.2 |  |  | $ | 19.5 |  |
| Fair value of options vested |  | $ | 13.4 |  |  | $ | 15.1 |  |  | $ | 25.4 |  |  | $ | 29.5 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001193125-13-454984:notes:44]
[same as prior period, unchanged from 0001193125-13-352036:notes:105]

[0001193125-13-454984:notes:45]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Arrow Electronics, Inc. |  |  | 15 | % |  |  | 16 | % |
| Avnet, Inc. |  |  | 10 | % |  |  | 14 | % |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-13-454984:notes:46]
Changes in accumulated other comprehensive income (AOCI) by
 component, net of tax, are summarized below (in
 millions):

[0001193125-13-454984:notes:47]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 26, 2013 |  | $ | 2.0 |  |  | $ | (5.7 | ) |  | $ | 11.4 |  |  | $ | 1.0 |  |  | $ | 8.7 |  |
| Other comprehensive income (loss) (OCI) before reclassifications |  |  | 3.6 |  |  |  | 0.2 |  |  |  | (3.0 | ) |  |  | (3.5 | ) |  |  | (2.7 | ) |
| Amounts reclassified from AOCI |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (1.1 | ) |  |  | 1.4 |  |  |  | 0.3 |  |
| Net OCI |  |  | 3.6 |  |  |  | 0.2 |  |  |  | (4.1 | ) |  |  | (2.1 | ) |  |  | (2.4 | ) |
| Balance as of October 25, 2013 |  | $ | 5.6 |  |  | $ | (5.5 | ) |  | $ | 7.3 |  |  | $ | (1.1 | ) |  | $ | 6.3 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-13-454984:notes:48]
The following table summarizes activity related to our stock
 options (in millions, except for exercise price and contractual
 term):

[0001193125-13-454984:notes:49]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 26, 2013 |  |  | 19.2 |  |  | $ | 31.27 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2.7 |  |  |  | 38.14 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (4.4 | ) |  |  | 25.90 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (0.7 | ) |  |  | 40.85 |  |  |  |  |  |  |  |  |  |
| Outstanding as of October 25, 2013 |  |  | 16.8 |  |  |  | 33.37 |  |  |  | 3.64 |  |  | $ | 139.5 |  |
| Vested and expected to vest as of October 25, 2013 |  |  | 16.2 |  |  |  | 33.23 |  |  |  | 3.55 |  |  |  | 137.4 |  |
| Exercisable as of October 25, 2013 |  |  | 11.8 |  |  |  | 31.18 |  |  |  | 2.73 |  |  |  | 121.6 |  |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-13-454984:notes:50]
The following table summarizes our financial assets and
 liabilities measured at fair value on a recurring basis as of
 October 25, 2013 (in millions):

[0001193125-13-454984:notes:51]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,568.5 |  |  | $ | 0.0 |  |  | $ | 2,568.5 |  |  | $ | 0.0 |  |
| U.S. Treasury and government debt securities |  |  | 278.6 |  |  |  | 176.4 |  |  |  | 102.2 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 151.7 |  |  |  | 0.0 |  |  |  | 151.7 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 185.1 |  |  |  | 0.0 |  |  |  | 185.1 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 39.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 39.5 |  |
| Equity funds |  |  | 31.6 |  |  |  | 31.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign currency contracts |  |  | 1.2 |  |  |  | 0.0 |  |  |  | 1.2 |  |  |  | 0.0 |  |
| Total |  | $ | 3,256.2 |  |  | $ | 208.0 |  |  | $ | 3,008.7 |  |  | $ | 39.5 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | 4.4 |  |  | $ | 0.0 |  |  | $ | 4.4 |  |  | $ | 0.0 |  |


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001193125-13-454984:notes:52]
Amortization expense for purchased intangible assets is
 summarized below (in millions):

[0001193125-13-454984:notes:53]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | Statements of Operations Classifications |
| Developed technology |  | $ | 14.3 |  |  | $ | 14.0 |  |  | $ | 28.6 |  |  | $ | 27.9 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 0.3 |  |  |  | 6.3 |  |  |  | 0.7 |  |  |  | 12.6 |  |  | Operating expenses |
| Trademarks and trade names |  |  | 0.1 |  |  |  | 1.0 |  |  |  | 0.2 |  |  |  | 2.0 |  |  | Operating expenses |
| Covenants not to compete |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.4 |  |  | Operating expenses |
|  |  | $ | 14.9 |  |  | $ | 21.5 |  |  | $ | 29.8 |  |  | $ | 42.9 |  |  |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-13-454984:notes:54]
Inventories (in millions):

[0001193125-13-454984:notes:55]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Purchased components |  | $ | 10.8 |  |  | $ | 16.3 |  |
| Finished goods |  |  | 105.1 |  |  |  | 123.2 |  |
| Inventories |  | $ | 115.9 |  |  | $ | 139.5 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-13-454984:notes:56]
The following table presents the contractual maturities of our
 debt investments as of October 25, 2013 (in
 millions):

[0001193125-13-454984:notes:57]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,130.1 |  |  | $ | 1,131.9 |  |
| Due in one through five years |  |  | 1,871.7 |  |  |  | 1,880.3 |  |
| Due after ten years* |  |  | 41.9 |  |  |  | 39.5 |  |
|  |  | $ | 3,043.7 |  |  | $ | 3,051.7 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-13-454984:notes:58]
[same as prior period, unchanged from 0001193125-13-352036:notes:184]

[0001193125-13-454984:notes:59]
[same as prior period, unchanged from 0001193125-13-352036:notes:185]

[0001193125-13-454984:notes:60]
We have master netting arrangements in place to mitigate the
 credit risk of our counterparties and to potentially reduce our
 losses due to counterparty nonperformance. We present our
 derivative instruments as net amounts in our condensed consolidated
 balance sheets. The gross and net fair value amounts of such
 instruments were not material as of October 25, 2013 and
 April 26, 2013. We did not recognize any gains and losses in
 earnings due to hedge ineffectiveness for any period
 presented.

[0001193125-13-454984:notes:61]
[same as prior period, unchanged from 0001193125-13-352036:notes:187]


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001193125-13-454984:notes:62]
[same as prior period, unchanged from 0001193125-13-352036:notes:66]

[0001193125-13-454984:notes:63]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Cash |  | $ | 2,088.8 |  |  | $ | 1,634.7 |  |
| Cash equivalents |  |  | 171.7 |  |  |  | 1,642.4 |  |
| Cash and cash equivalents |  | $ | 2,260.5 |  |  | $ | 3,277.1 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001193125-13-454984:notes:64]
Other non-current assets (in
 millions):

[0001193125-13-454984:notes:65]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Auction rate securities |  | $ | 39.5 |  |  | $ | 42.0 |  |
| Deferred tax assets |  |  | 211.8 |  |  |  | 200.4 |  |
| Other assets |  |  | 244.2 |  |  |  | 242.2 |  |
| Other non-current assets |  | $ | 495.5 |  |  | $ | 484.6 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-13-454984:notes:66]
7.  Financial
 Instruments and Fair Value Measurements

[0001193125-13-454984:notes:67]
The accounting guidance for fair value measurements provides a
 framework for measuring fair value on either a recurring or
 nonrecurring basis whereby the inputs used in our valuation
 techniques are assigned a hierarchical level. The following are the
 three levels of inputs to measure fair value:

[0001193125-13-454984:notes:68]
Level 1: Observable inputs that reflect quoted prices
 (unadjusted) for identical assets or liabilities in active
 markets.

[0001193125-13-454984:notes:69]
Level 2: Inputs that reflect quoted prices for identical
 assets or liabilities in less active markets; quoted prices for
 similar assets or liabilities in active markets; benchmark yields,
 reported trades, broker/dealer quotes, inputs other than quoted
 prices that are observable for the assets or liabilities; or inputs
 that are derived principally from or corroborated by observable
 market data by correlation or other means.

[0001193125-13-454984:notes:70]
Level 3: Unobservable inputs that reflect our own
 assumptions incorporated in valuation techniques used to measure
 fair value. These assumptions are required to be consistent with
 market participant assumptions that are reasonably
 available.

[0001193125-13-454984:notes:71]
We consider an active market to be one in which transactions
 for the asset or liability occur with sufficient frequency and
 volume to provide pricing information on an ongoing basis, and
 consider an inactive market to be one in which there are infrequent
 or few transactions for the asset or liability, the prices are not
 current, or price quotations vary substantially either over time or
 among market makers. Where appropriate, our own or the
 counterparty’s non-performance risk is considered in
 measuring the fair values of liabilities and assets,
 respectively.

[0001193125-13-454984:notes:72]
Investments

[0001193125-13-454984:notes:73]
The following is a summary of our investments (in
 millions):

[0001193125-13-454984:notes:74]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
|  |  |  |  |  | Gross Unrealized |  |  |  |  |  |  |  |  | Gross Unrealized |  |  |  |  |
|  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |
| Corporate bonds |  | $ | 2,558.6 |  |  | $ | 10.8 |  |  | $ | (0.9 | ) |  | $ | 2,568.5 |  |  | $ | 3,132.8 |  |  | $ | 14.9 |  |  | $ | (0.6 | ) |  | $ | 3,147.1 |  |
| U.S. Treasury and government debt securities |  |  | 278.2 |  |  |  | 0.4 |  |  |  | 0.0 |  |  |  | 278.6 |  |  |  | 392.8 |  |  |  | 0.9 |  |  |  | 0.0 |  |  |  | 393.7 |  |
| Commercial paper |  |  | 151.7 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 151.7 |  |  |  | 178.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 178.5 |  |
| Certificates of deposit |  |  | 185.0 |  |  |  | 0.1 |  |  |  | 0.0 |  |  |  | 185.1 |  |  |  | 135.4 |  |  |  | 0.1 |  |  |  | 0.0 |  |  |  | 135.5 |  |
| Money market funds |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,463.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,463.1 |  |
| Auction rate securities |  |  | 41.9 |  |  |  | 0.0 |  |  |  | (2.4 | ) |  |  | 39.5 |  |  |  | 44.2 |  |  |  | 0.5 |  |  |  | (2.7 | ) |  |  | 42.0 |  |
| Equity funds |  |  | 31.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 31.6 |  |  |  | 28.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 28.3 |  |
| Total debt and equity securities |  | $ | 3,247.0 |  |  | $ | 11.3 |  |  | $ | (3.3 | ) |  | $ | 3,255.0 |  |  | $ | 5,375.1 |  |  | $ | 16.4 |  |  | $ | (3.3 | ) |  | $ | 5,388.2 |  |

[0001193125-13-454984:notes:75]
The unrealized losses on our available-for-sale investments
 were caused by market value declines as a result of the economic
 environment, as well as fluctuations in market interest rates.
 Because the declines in market value are attributable to changes in
 market conditions and not credit quality, and because we have
 currently concluded that we neither intend to sell nor is it more
 likely than not that we will be required to sell these investments
 prior to a recovery of par value, we do not consider these
 investments to be other-than temporarily impaired as of
 October 25, 2013.

[0001193125-13-454984:notes:76]
| * | Consists of auction rate securities (ARS) which have contractual maturities of greater than 10 years. |

[0001193125-13-454984:notes:77]
Fair Value of Financial Instruments

[0001193125-13-454984:notes:78]
The following table summarizes the balance sheet
 classifications of our financial assets and liabilities measured at
 fair value on a recurring basis as of October 25, 2013 (in
 millions):

[0001193125-13-454984:notes:79]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 171.7 |  |  | $ | 0.0 |  |  | $ | 171.7 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 3,012.2 |  |  |  | 176.4 |  |  |  | 2,835.8 |  |  |  | 0.0 |  |
| Other current assets |  |  | 5.1 |  |  |  | 3.9 |  |  |  | 1.2 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 67.2 |  |  |  | 27.7 |  |  |  | 0.0 |  |  |  | 39.5 |  |
| Total |  | $ | 3,256.2 |  |  | $ | 208.0 |  |  | $ | 3,008.7 |  |  | $ | 39.5 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 4.4 |  |  | $ | 0.0 |  |  | $ | 4.4 |  |  | $ | 0.0 |  |

[0001193125-13-454984:notes:80]
Level 2 investments are held by a custodian who prices some of
 the investments using standard inputs in various asset price models
 or obtains investment prices from a third-party pricing provider
 that incorporates standard inputs in various asset price models. We
 review Level 2 inputs and fair value for reasonableness and the
 values may be further validated by comparison to multiple
 independent pricing sources. In addition, we review third-party
 pricing providers’ models, key inputs and assumptions and
 understand the pricing processes at our third-party providers in
 determining the overall reasonableness of the fair value of our
 Level 2 financial instruments. As of October 25, 2013, we have
 not made any adjustments to the prices obtained from our
 third-party pricing providers.

[0001193125-13-454984:notes:81]
Quantitative information about our Level 3 fair value
 measurements is as follows (fair value in millions):

[0001193125-13-454984:notes:82]
|  |  | Estimated Fair Value as of October 25, 2013 |  |  | Valuation Techniques |  | Unobservable Inputs |  | Range (Weighted average) |
| ARS |  | $ | 39.5 |  |  | Discounted cash flow |  | Time-to-economic maturity |  | 6.7 yrs. – 10.9 yrs. (8.3 yrs.) |
|  |  |  |  |  |  |  |  | Liquidity risk premium, market credit spread and other factors |  | 1.7% - 3.6% (2.5%) |
|  |  |  |  |  |  |  |  | Coupon rate |  | 1.1% - 2.7% (1.9%) |
|  |  |  |  |  |  | Market comparable securities |  | Discount rate |  | 2.2% - 9.2% (5.4%) |

[0001193125-13-454984:notes:83]
All of our ARS are classified as other non-current assets and
 are backed by pools of student loans guaranteed by the U.S.
 Department of Education. We estimate the fair value of each
 individual ARS using an income (discounted cash flow) and market
 approach that incorporate both observable and unobservable inputs.
 Key inputs into the discounted cash flow analysis include the
 time-to-economic maturity, liquidity risk premium, market credit
 spread and other factors and a coupon rate. The key input into the
 market approach is a discount rate. A significant increase
 (decrease) in the time-to-economic maturity, liquidity risk
 premium, market credit spread and other factors, coupon rate or
 discount rate could result in a significantly lower (higher) fair
 value estimate. We review the fair value of our Level 3 financial
 instruments for overall reasonableness by reviewing service
 provider pricing methodologies, key inputs and assumptions and by
 understanding the processes used by our third-party service
 provider. We will continue to monitor our ARS investments in light
 of the debt market environment and evaluate these investments for
 impairment and classification.

[0001193125-13-454984:notes:84]
The table below provides a reconciliation of the beginning and
 ending balance of our Level 3 ARS measured at fair value on a
 recurring basis using significant unobservable inputs (in
 millions):

[0001193125-13-454984:notes:85]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Balance at beginning of period |  | $ | 42.2 |  |  | $ | 46.3 |  |  | $ | 42.0 |  |  | $ | 51.0 |  |
| Total unrealized gains (losses), net included in other comprehensive income (loss) |  |  | (0.4 | ) |  |  | 0.2 |  |  |  | (0.2 | ) |  |  | 0.5 |  |
| Total realized gains included in earnings |  |  | 0.7 |  |  |  | 0.0 |  |  |  | 0.7 |  |  |  | 0.0 |  |
| Sales |  |  | (3.0 | ) |  |  | 0.0 |  |  |  | (3.0 | ) |  |  | 0.0 |  |
| Settlements |  |  | (0.0 | ) |  |  | (0.0 | ) |  |  | (0.0 | ) |  |  | (5.0 | ) |
| Balance at end of period |  | $ | 39.5 |  |  | $ | 46.5 |  |  | $ | 39.5 |  |  | $ | 46.5 |  |

[0001193125-13-454984:notes:86]
Fair Value of Debt

[0001193125-13-454984:notes:87]
As of October 25, 2013, the fair value of our 2.00% Senior
 Notes and 3.25% Senior Notes (collectively referred to as Senior
 Notes) was approximately $989.6 million. The fair value of our debt
 was based on observable market prices in a less active market and
 discounted cash flow models that take into consideration variables
 such as credit-rating and interest rate changes. All of our debt
 obligations are categorized as Level 2 instruments.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-13-454984:notes:88]
6.  Balance
 Sheet Details

[0001193125-13-454984:notes:89]
[same as prior period, unchanged from 0001193125-13-352036:notes:95]

[0001193125-13-454984:notes:90]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Prepaid expenses and other current assets |  | $ | 192.3 |  |  | $ | 262.6 |  |
| Short-term restricted cash |  |  | 7.7 |  |  |  | 8.9 |  |
| Deferred tax assets |  |  | 241.0 |  |  |  | 253.7 |  |
| Other current assets |  | $ | 441.0 |  |  | $ | 525.2 |  |

[0001193125-13-454984:notes:91]
[same as prior period, unchanged from 0001193125-13-352036:notes:99]

[0001193125-13-454984:notes:92]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Computer software |  | $ | 138.6 |  |  | $ | 162.5 |  |

[0001193125-13-454984:notes:93]
[same as prior period, unchanged from 0001193125-13-352036:notes:103]

[0001193125-13-454984:notes:94]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Product |  | $ | 26.9 |  |  | $ | 15.7 |  |
| Software entitlements and maintenance and service |  |  | 2,905.0 |  |  |  | 2,993.8 |  |
| Total |  | $ | 2,931.9 |  |  | $ | 3,009.5 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,525.8 |  |  | $ | 1,563.3 |  |
| Long-term |  |  | 1,406.1 |  |  |  | 1,446.2 |  |
| Total |  | $ | 2,931.9 |  |  | $ | 3,009.5 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0001193125-13-454984:notes:95]
|  |  | ESPP |  |
|  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 0.2 | % |  |  | 0.2 | % |
| Volatility |  |  | 32 | % |  |  | 38 | % |
| Dividend yield |  |  | 1.6 | % |  |  | 0.0 | % |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001193125-13-454984:notes:96]
A reconciliation of retained earnings for the six months ended
 October 25, 2013 is as follows (in millions):

[0001193125-13-454984:notes:97]
| Balance as of April 26, 2013 |  | $ | 2,896.8 |  |
| Net income |  |  | 248.4 |  |
| Repurchases of common stock |  |  | (613.7 | ) |
| Retirement of treasury stock |  |  | (2,313.3 | ) |
| Dividends |  |  | (102.7 | ) |
| Balance as of October 25, 2013 |  | $ | 115.5 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0001193125-13-454984:notes:98]
Activities related to this plan for the six months ended
 October 25, 2013 were as follows (in millions):

[0001193125-13-454984:notes:99]
|  |  | Total |  |
| Net charges |  | $ | 49.5 |  |
| Cash payments |  |  | (45.4 | ) |
| Balance as of October 25, 2013 |  | $ | 4.1 |  |


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-13-454984:notes:100]
[same as prior period, unchanged from 0001193125-13-352036:notes:8]

[0001193125-13-454984:notes:101]
[same as prior period, unchanged from 0001193125-13-352036:notes:9]

[0001193125-13-454984:notes:102]
|  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Reclassification of equity component of Convertible Notes |  | $ | 0.0 |  |  | $ | 62.6 |  |
| Acquisition of property and equipment outstanding in accounts payable |  | $ | 27.1 |  |  | $ | 20.0 |  |
| Acquisition of software through long-term financing |  | $ | 11.4 |  |  | $ | 0.8 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 26.5 |  |  | $ | 26.5 |  |
| Interest paid, net of capitalized interest |  | $ | 23.2 |  |  | $ | 11.3 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-13-454984:notes:103]
The following is a calculation of basic and diluted net income
 per share (in millions, except per share amounts):

[0001193125-13-454984:notes:104]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 166.8 |  |  | $ | 109.6 |  |  | $ | 248.4 |  |  | $ | 173.4 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 340.7 |  |  |  | 362.0 |  |  |  | 345.8 |  |  |  | 364.1 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 7.5 |  |  |  | 5.2 |  |  |  | 7.2 |  |  |  | 5.1 |  |
| Dilutive impact of assumed conversion of Convertible Notes |  |  | 0.0 |  |  |  | 1.0 |  |  |  | 1.1 |  |  |  | 0.5 |  |
| Dilutive impact of warrants |  |  | 0.9 |  |  |  | 0.0 |  |  |  | 0.4 |  |  |  | 0.0 |  |
| Shares used in diluted computation |  |  | 349.1 |  |  |  | 368.2 |  |  |  | 354.5 |  |  |  | 369.7 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.49 |  |  | $ | 0.30 |  |  | $ | 0.72 |  |  | $ | 0.48 |  |
| Diluted |  | $ | 0.48 |  |  | $ | 0.30 |  |  | $ | 0.70 |  |  | $ | 0.47 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-13-454984:notes:105]
[same as prior period, unchanged from 0001193125-13-352036:notes:3]

[0001193125-13-454984:notes:106]
In May
 2013, we initiated a business restructuring plan under which we
 realigned internal resources, resulting in a reduction of our
 global workforce of approximately 7%. Restructuring and other
 charges during the six months ended October 25, 2013 consisted
 primarily of employee severance-related costs.

[0001193125-13-454984:notes:107]
The
 reserve balance as of October 25, 2013 is included in accrued
 compensation and related benefits in our condensed consolidated
 balance sheet.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001193125-13-454984:notes:108]
[same as prior period, unchanged from 0001193125-13-352036:notes:56]

[0001193125-13-454984:notes:109]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| United States |  | $ | 1,414.1 |  |  | $ | 3,419.3 |  |
| International |  |  | 3,908.2 |  |  |  | 3,586.8 |  |
| Total |  | $ | 5,322.3 |  |  | $ | 7,006.1 |  |


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001193125-13-454984:notes:110]
The amounts reclassified out of AOCI are as follows (in
 millions):

[0001193125-13-454984:notes:111]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |  |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |  |  |  |
| OCI Components |  | Amounts Reclassified from AOCI |  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |  |
| Realized gains on available-for-sale securities |  | $ | (1.0 | ) |  | $ | (0.5 | ) |  | $ | (1.1 | ) |  | $ | (0.6 | ) |  |  | Other income (expense), net |  |
| Realized losses (gains) on cash flow hedges |  |  | 2.4 |  |  |  | 2.6 |  |  |  | 1.4 |  |  |  | (1.9 | ) |  |  | Net revenues |  |
| Total reclassifications |  | $ | 1.4 |  |  | $ | 2.1 |  |  | $ | 0.3 |  |  | $ | (2.5 | ) |  |  |  |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001193125-13-454984:notes:112]
[same as prior period, unchanged from 0001193125-13-352036:notes:60]

[0001193125-13-454984:notes:113]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| United States |  | $ | 1,053.1 |  |  | $ | 1,076.3 |  |
| International |  |  | 89.8 |  |  |  | 94.6 |  |
| Total |  | $ | 1,142.9 |  |  | $ | 1,170.9 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001193125-13-454984:notes:114]
[same as prior period, unchanged from 0001193125-13-352036:notes:123]

[0001193125-13-454984:notes:115]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Beginning balance |  | $ | 119.8 |  |  | $ | 96.5 |  |  | $ | 117.2 |  |  | $ | 83.1 |  |
| Expense accrued during the period |  |  | 14.3 |  |  |  | 27.1 |  |  |  | 38.3 |  |  |  | 50.8 |  |
| Warranty costs incurred |  |  | (18.1 | ) |  |  | (11.8 | ) |  |  | (39.5 | ) |  |  | (22.1 | ) |
| Ending balance |  | $ | 116.0 |  |  | $ | 111.8 |  |  | $ | 116.0 |  |  | $ | 111.8 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-13-454984:notes:116]
[same as prior period, unchanged from 0001193125-13-352036:notes:62]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-13-454984:notes:117]
[same as prior period, unchanged from 0001193125-13-352036:notes:107]

[0001193125-13-454984:notes:118]
[same as prior period, unchanged from 0001193125-13-352036:notes:108]

[0001193125-13-454984:notes:119]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
|  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |
| Developed technology |  | $ | 283.0 |  |  | $ | (134.0 | ) |  | $ | 149.0 |  |  | $ | 312.4 |  |  | $ | (134.9 | ) |  | $ | 177.5 |  |
| Customer contracts/relationships |  |  | 9.6 |  |  |  | (8.7 | ) |  |  | 0.9 |  |  |  | 54.7 |  |  |  | (53.1 | ) |  |  | 1.6 |  |
| Trademarks and trade names |  |  | 2.9 |  |  |  | (2.2 | ) |  |  | 0.7 |  |  |  | 9.9 |  |  |  | (8.9 | ) |  |  | 1.0 |  |
| Covenants not to compete |  |  | 1.6 |  |  |  | (1.3 | ) |  |  | 0.3 |  |  |  | 2.2 |  |  |  | (1.7 | ) |  |  | 0.5 |  |
| Total purchased intangible assets |  | $ | 297.1 |  |  | $ | (146.2 | ) |  | $ | 150.9 |  |  | $ | 379.2 |  |  | $ | (198.6 | ) |  | $ | 180.6 |  |

[0001193125-13-454984:notes:120]
As of October 25, 2013, future amortization expense
 related to purchased intangible assets is as follows (in
 millions):


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001193125-13-454984:notes:121]
9.  Stockholders’ Equity

[0001193125-13-454984:notes:122]
Stock Options

[0001193125-13-454984:notes:123]
The aggregate intrinsic value represents the pre-tax difference
 between the exercise price of stock options and the quoted market
 price of our stock on that day for all in-the-money
 options.

[0001193125-13-454984:notes:124]
Restricted Stock Units

[0001193125-13-454984:notes:125]
The following table summarizes activity related to our
 restricted stock units (RSUs) (in millions, except for fair
 value):

[0001193125-13-454984:notes:126]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 26, 2013 |  |  | 12.8 |  |  | $ | 38.36 |  |
| Granted |  |  | 5.9 |  |  |  | 38.58 |  |
| Vested |  |  | (3.0 | ) |  |  | 36.74 |  |
| Forfeited |  |  | (1.1 | ) |  |  | 39.39 |  |
| Outstanding as of October 25, 2013 |  |  | 14.6 |  |  |  | 38.70 |  |

[0001193125-13-454984:notes:127]
RSUs are converted into common stock upon vesting. We primarily
 use the net share settlement approach upon vesting, where a portion
 of the shares are withheld as settlement of statutory employee
 withholding taxes, which decreases the shares issued to the
 employee by a corresponding value. The number and value of the
 shares netted for employee taxes are summarized in the table below
 (in millions):

[0001193125-13-454984:notes:128]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Shares withheld for taxes |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 1.0 |  |  |  | 0.7 |  |
| Fair value of shares withheld |  | $ | 4.0 |  |  | $ | 2.8 |  |  | $ | 39.3 |  |  | $ | 22.6 |  |

[0001193125-13-454984:notes:129]
Employee Stock Purchase Plan

[0001193125-13-454984:notes:130]
Under the Employee Stock Purchase Plan (ESPP), employees who
 elect to participate are granted purchase rights that include a
 purchase price adjustment provision under which the employees may
 purchase common stock at a 15% discount from the market value of
 the common stock at certain specified dates within a two-year
 offering period. Information related to the purchase rights issued
 under the ESPP is provided below (in millions, except per right
 information):

[0001193125-13-454984:notes:131]
|  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Weighted-average fair value per right granted |  | $ | 10.53 |  |  | $ | 10.25 |  |
| Shares issued under the ESPP |  |  | 2.0 |  |  |  | 1.9 |  |
| Proceeds from issuance of shares |  | $ | 49.9 |  |  | $ | 48.2 |  |

[0001193125-13-454984:notes:132]
Stock-Based Compensation Expense

[0001193125-13-454984:notes:133]
Stock-based compensation expense is included in the condensed
 consolidated statements of operations as follows (in
 millions):

[0001193125-13-454984:notes:134]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Cost of product revenues |  | $ | 1.4 |  |  | $ | 1.5 |  |  | $ | 2.7 |  |  | $ | 3.3 |  |
| Cost of service revenues |  |  | 4.2 |  |  |  | 4.6 |  |  |  | 8.2 |  |  |  | 10.2 |  |
| Sales and marketing |  |  | 31.1 |  |  |  | 30.9 |  |  |  | 61.6 |  |  |  | 69.9 |  |
| Research and development |  |  | 21.6 |  |  |  | 19.3 |  |  |  | 43.0 |  |  |  | 43.0 |  |
| General and administrative |  |  | 9.3 |  |  |  | 8.7 |  |  |  | 18.4 |  |  |  | 17.8 |  |
| Total stock-based compensation expense |  | $ | 67.6 |  |  | $ | 65.0 |  |  | $ | 133.9 |  |  | $ | 144.2 |  |

[0001193125-13-454984:notes:135]
As of October 25, 2013, total unrecognized compensation
 expense related to our equity awards was $500.1 million, which is
 expected to be recognized on a straight-line basis over a
 weighted-average remaining service period of
 2.6 years.

[0001193125-13-454984:notes:136]
Total income tax benefit associated with employee stock
 transactions and recognized in stockholders’ equity were as
 follows (in millions):

[0001193125-13-454984:notes:137]
|  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Income tax benefit associated with employee stock transactions |  | $ | 1.8 |  |  | $ | 28.2 |  |

[0001193125-13-454984:notes:138]
Valuation Assumptions

[0001193125-13-454984:notes:139]
The fair value of each stock option and ESPP purchase right is
 estimated on the grant date using the Black-Scholes option pricing
 model and the following weighted-average assumptions:

[0001193125-13-454984:notes:140]
|  |  | Stock Options |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Expected term in years |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 4.8 |  |
| Risk-free interest rate |  |  | 1.6 | % |  |  | 0.6 | % |  |  | 1.1 | % |  |  | 0.6 | % |
| Volatility |  |  | 32 | % |  |  | 43 | % |  |  | 34 | % |  |  | 41 | % |
| Dividend yield |  |  | 1.6 | % |  |  | 0.0 | % |  |  | 1.6 | % |  |  | 0.0 | % |

[0001193125-13-454984:notes:141]
The weighted-average assumptions used to value RSUs are
 summarized as follows:

[0001193125-13-454984:notes:142]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Grant date fair value per share |  | $ | 40.13 |  |  | $ | 31.91 |  |  | $ | 38.58 |  |  | $ | 29.31 |  |
| Expected dividend |  |  | 1.6 | % |  |  | 0.0 | % |  |  | 1.6 | % |  |  | 0.0 | % |

[0001193125-13-454984:notes:143]
Prior to the initial declaration of a quarterly cash dividend
 on May 21, 2013, the fair value of RSUs was measured based on
 the grant date share price, as we did not historically pay cash
 dividends on our common stock. For awards granted on or subsequent
 to May 21, 2013, the fair value of RSUs was measured based on
 the grant date share price, less the present value of expected
 dividends during the vesting period, discounted at a risk-free
 interest rate.

[0001193125-13-454984:notes:144]
Stock Repurchase Program

[0001193125-13-454984:notes:145]
As of October 25, 2013, our Board of Directors has
 authorized the repurchase of up to $7.1 billion of our common
 stock. Under this program, which may be suspended or discontinued
 at any time, we may purchase shares of our outstanding common stock
 through open market and privately negotiated transactions at prices
 deemed appropriate by our management.

[0001193125-13-454984:notes:146]
The following table summarizes activity related to this program
 for the six months ended October 25, 2013 (in millions, except
 per share information):

[0001193125-13-454984:notes:147]
| Number of shares repurchased |  |  | 25.3 |  |
| Average price per share |  | $ | 39.57 |  |
| Aggregate purchase price |  | $ | 1,000.0 |  |
| Remaining authorization at end of period |  | $ | 2,006.3 |  |

[0001193125-13-454984:notes:148]
The aggregate purchase price of our share repurchases for the
 six months ended October 25, 2013 consisted of $750.0 million
 under an accelerated share repurchase agreement (ASR) and $250.0
 million of open market purchases, for which collectively $386.3
 million and $613.7 million was allocated to additional paid-in
 capital and retained earnings, respectively.

[0001193125-13-454984:notes:149]
During the six months ended October 25, 2013, we retired
 104.3 million shares of common stock repurchased in prior
 years and previously reported as treasury stock, resulting in
 reductions of $0.1 million in common stock (par value), $614.0
 million in additional paid-in capital and $2,313.3 million in
 retained earnings.

[0001193125-13-454984:notes:150]
Accelerated Share Repurchase Agreement

[0001193125-13-454984:notes:151]
On June 5, 2013, we entered into a collared ASR with a
 counterparty under which we prepaid $750.0 million to purchase
 shares of our common stock. The aggregate number of shares
 ultimately purchased was determined based on the volume
 weighted-average share price of our common stock over a specified
 period of time. The contract was settled in July 2013. The total
 number of shares repurchased under this ASR was 19.2 million
 shares, at an average price per share of $39.13. The value of the
 ASR forward contract was determined to be $13.9 million, which has
 been recorded as additional paid-in capital.

[0001193125-13-454984:notes:152]
Dividends

[0001193125-13-454984:notes:153]
During the six months ended October 25, 2013, we declared
 and paid quarterly cash dividends of $0.15 per share of outstanding
 common stock, or an aggregate of $102.7 million. On
 November 13, 2013, we declared a cash dividend of $0.15 per
 share of common stock, payable on January 22, 2014 to holders
 of record on January 9, 2014. No dividends were declared or
 paid during the six months ended October 26, 2012. The timing
 and amount of future dividends will depend on market conditions,
 corporate business and financial considerations and regulatory
 requirements.

[0001193125-13-454984:notes:154]
Retained Earnings

[0001193125-13-454984:notes:155]
Accumulated Other Comprehensive Income


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001193125-13-454984:notes:156]
[same as prior period, unchanged from 0001193125-13-352036:notes:114]

[0001193125-13-454984:notes:157]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Americas (United States, Canada and Latin America) |  | $ | 899.2 |  |  | $ | 897.3 |  |  | $ | 1,757.7 |  |  | $ | 1,698.4 |  |
| Europe, Middle East and Africa |  |  | 445.0 |  |  |  | 437.7 |  |  |  | 893.0 |  |  |  | 877.0 |  |
| Asia Pacific |  |  | 205.7 |  |  |  | 206.2 |  |  |  | 415.4 |  |  |  | 410.4 |  |
| Net revenues |  | $ | 1,549.9 |  |  | $ | 1,541.2 |  |  | $ | 3,066.1 |  |  | $ | 2,985.8 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-13-454984:notes:158]
3.  Significant
 Accounting Policies

[0001193125-13-454984:notes:159]
There
 have been no significant changes in our significant accounting
 policies as of and for the six months ended October 25, 2013,
 as compared to the significant accounting policies described in our
 Annual Report on Form 10-K for the fiscal year ended April 26,
 2013.

[0001193125-13-454984:notes:160]
Recent Accounting Standards Not Yet Effective — In
 July 2013, the Financial Accounting Standards Board issued an
 accounting standard update providing presentation requirements for
 unrecognized tax benefit when a net operating loss carryforward, a
 similar tax loss, or a similar tax credit carryforward exists. This
 accounting standard update will be effective for us beginning in
 our first quarter of fiscal 2015 and is not expected to have a
 significant impact on our consolidated financial
 statements.

[0001193125-13-454984:notes:161]
Use
 of Estimates — The preparation of the condensed
 consolidated financial statements in conformity with GAAP requires
 management to make estimates and assumptions that affect the
 reported amounts of assets and liabilities and disclosure of
 contingent assets and liabilities at the date of the financial
 statements and the reported amounts of revenues and expenses during
 the reporting periods. Such estimates include, but are not limited
 to, revenue recognition, reserves and allowances; inventory
 valuation and purchase order accruals; valuation of goodwill and
 intangibles; restructuring reserves; product warranties; employee
 benefit accruals; stock-based compensation; loss contingencies;
 investment impairments; income taxes and fair value measurements.
 Actual results could differ materially from those
 estimates.


## us-gaap:ScheduleOfGuaranteeObligationsTextBlock

[0001193125-13-454984:notes:162]
[same as prior period, unchanged from 0001193125-13-352036:notes:121]

[0001193125-13-454984:notes:163]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Maximum guaranteed payment contingencies |  | $ | 215.6 |  |  | $ | 182.4 |  |
| Deferred revenue associated with financing guarantees |  |  | (199.0 | ) |  |  | (168.6 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 16.6 |  |  | $ | 13.8 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-13-454984:notes:164]
[same as prior period, unchanged from 0001193125-13-352036:notes:127]

[0001193125-13-454984:notes:165]
[same as prior period, unchanged from 0001193125-13-352036:notes:128]

[0001193125-13-454984:notes:166]
|  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Effective tax rates |  |  | 12.7 | % |  |  | 14.1 | % |

[0001193125-13-454984:notes:167]
[same as prior period, unchanged from 0001193125-13-352036:notes:130]

[0001193125-13-454984:notes:168]
As of October 25, 2013, we had $199.8 million of
 unrecognized tax benefits, of which $142.7 million has been
 recorded in other long-term liabilities. Unrecognized tax benefits
 of $129.0 million, including penalties and interest, would affect
 our provision for income taxes if recognized. During the six months
 ended October 25, 2013, there was a gross increase in our
 unrecognized tax benefits of $13.6 million for tax positions
 related to the current year, and a gross increase of $1.0 million
 and gross decrease, including settlements and statute lapses, of
 $4.4 million for tax positions related to prior years.

[0001193125-13-454984:notes:169]
[same as prior period, unchanged from 0001193125-13-352036:notes:132]

[0001193125-13-454984:notes:170]
[same as prior period, unchanged from 0001193125-13-352036:notes:133]

[0001193125-13-454984:notes:171]
[same as prior period, unchanged from 0001193125-13-352036:notes:134]

[0001193125-13-454984:notes:172]
[same as prior period, unchanged from 0001193125-13-352036:notes:135]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-13-454984:notes:173]
[same as prior period, unchanged from 0001193125-13-352036:notes:179]

[0001193125-13-454984:notes:174]
[same as prior period, unchanged from 0001193125-13-352036:notes:180]

[0001193125-13-454984:notes:175]
Americas revenues consist of Americas commercial and U.S.
 public sector revenues. Sales to customers inside the United States
 comprised $800.7 million and $797.6 million of Americas net
 revenues during the three months ended October 25, 2013 and
 October 26, 2012, respectively, and $1,573.5 million and
 $1,509.0 million of Americas net revenues during the six months
 ended October 25, 2013 and October 26, 2012,
 respectively. No single foreign country accounted for 10% or more
 of our net revenues for any period presented.

[0001193125-13-454984:notes:176]
[same as prior period, unchanged from 0001193125-13-352036:notes:182]

[0001193125-13-454984:notes:177]
[same as prior period, unchanged from 0001193125-13-352036:notes:183]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-13-454984:notes:178]
15.  Commitments and Contingencies

[0001193125-13-454984:notes:179]
Operating Lease Commitments

[0001193125-13-454984:notes:180]
As of October 25, 2013, future annual minimum lease
 payments under non-cancelable operating leases with an initial term
 in excess of one year totaled $215.7 million.

[0001193125-13-454984:notes:181]
Purchase Orders and Other Commitments

[0001193125-13-454984:notes:182]
In the normal course of business we make commitments to our
 third-party contract manufacturers, to manage manufacturer lead
 times and meet product forecasts, and to other parties, to purchase
 various key components used in the manufacture of our products. We
 establish accruals for estimated losses on purchased components to
 the extent we believe it is probable that such components will not
 be utilized in future operations. To the extent that such forecasts
 are not achieved, our commitments and associated accruals may
 change. As of October 25, 2013, we had $306.8 million in
 non-cancelable purchase commitments with our contract
 manufacturers. In addition, we recorded a liability for firm,
 non-cancelable and unconditional purchase commitments with contract
 manufacturers for quantities in excess of our future demand
 forecasts through a charge to cost of product sales. As of
 October 25, 2013 and April 26, 2013, such liability
 amounted to $10.9 million and $9.5 million, respectively, and is
 included in other current liabilities in our condensed consolidated
 balance sheets.

[0001193125-13-454984:notes:183]
In addition to commitments with contract manufacturers and
 component suppliers, we have open purchase orders and contractual
 obligations associated with our ordinary course business for which
 we have not received goods or services. As of October 25,
 2013, we had $33.6 million in capital purchase commitments and
 $202.4 million in other purchase commitments.

[0001193125-13-454984:notes:184]
Product Warranties

[0001193125-13-454984:notes:185]
We provide customers a warranty on software of ninety days to
 five years and a warranty on hardware of one to five years. The
 following table summarizes our warranty reserves (in
 millions):

[0001193125-13-454984:notes:186]
Our warranty reserves were reported in our condensed
 consolidated balance sheets as follows (in millions):

[0001193125-13-454984:notes:187]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Other current liabilities |  | $ | 78.1 |  |  | $ | 81.6 |  |
| Other long-term liabilities |  |  | 37.9 |  |  |  | 35.6 |  |
| Total |  | $ | 116.0 |  |  | $ | 117.2 |  |

[0001193125-13-454984:notes:188]
Financing Guarantees

[0001193125-13-454984:notes:189]
Some of our customers have entered into recourse and
 non-recourse financing leasing arrangements using third-party
 financing companies, and in some situations, we enter into customer
 financing arrangements for our products and services that are
 contemporaneously sold on a recourse or non-recourse basis to
 third-party financing companies. Under the terms of recourse
 leases, which are generally three years or less, we remain liable
 for the aggregate unpaid remaining lease payments to the
 third-party leasing companies in the event of end-user customer
 default. These arrangements are generally collateralized by a
 security interest in the underlying assets. Under the terms of the
 nonrecourse leases, we do not have any continuing obligations or
 liabilities to the third-party financing companies. Where we
 provide a guarantee for recourse leases, we defer revenues subject
 to the industry-specific software revenue recognition guidance, and
 recognize revenues for non-software deliverables in accordance with
 our multiple deliverable revenue arrangement policy. In connection
 with certain recourse financing arrangements, we receive advance
 payments associated with undelivered elements that are subject to
 customer refund rights. We defer revenue associated with these
 advance payments until the related refund rights expire and we
 perform the services.

[0001193125-13-454984:notes:190]
To date, we have not experienced material losses under our
 lease financing programs or other financing
 arrangements.

[0001193125-13-454984:notes:191]
Legal Contingencies

[0001193125-13-454984:notes:192]
When a loss is considered probable and reasonably estimable, we
 record a liability in the amount of our best estimate for the
 ultimate loss. However, the likelihood of a loss with respect to a
 particular contingency is often difficult to predict and
 determining a meaningful estimate of the loss or a range of loss
 may not be practicable based on the information available and the
 potential effect of future events and decisions by third parties
 that will determine the ultimate resolution of the
 contingency.

[0001193125-13-454984:notes:193]
We are subject to various legal proceedings and claims that
 arise in the normal course of business. No accrual has been
 recorded as of October 25, 2013 related to such matters as
 they are not probable and/or reasonably estimable.
