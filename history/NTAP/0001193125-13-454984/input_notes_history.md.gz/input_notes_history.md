# NTAP note change history — 0001193125-13-352036 → 0001193125-13-454984


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-11-26):
[0001193125-13-454984:note_history:1]
As of October 25, 2013, future annual minimum lease
 payments under non-cancelable operating leases with an initial term
 in excess of one year totaled $215.7 million.
  (was, 2013-08-29, similarity 0.9642):
[0001193125-13-352036:note_history:1]
As of July 26, 2013, future annual minimum lease payments
 under non-cancelable operating leases with an initial term in
 excess of one year totaled $217.1 million.

- changed (2013-11-26):
[0001193125-13-454984:note_history:2]
In the normal course of business we make commitments to our
 third-party contract manufacturers, to manage manufacturer lead
 times and meet product forecasts, and to other parties, to purchase
 various key components used in the manufacture of our products. We
 establish accruals for estimated losses on purchased components to
 the extent we believe it is probable that such components will not
 be utilized in future operations. To the extent that such forecasts
 are not achieved, our commitments and associated accruals may
 change. As of October 25, 2013, we had $306.8 million in
 non-cancelable purchase commitments with our contract
 manufacturers. In addition, we recorded a liability for firm,
 non-cancelable and unconditional purchase commitments with contract
 manufacturers for quantities in excess of our future demand
 forecasts through a charge to cost of product sales. As of
 October 25, 2013 and April 26, 2013, such liability
 amounted to $10.9 million and $9.5 million, respectively, and is
 included in other current liabilities in our condensed consolidated
 balance sheets.
  (was, 2013-08-29, similarity 0.9896):
[0001193125-13-352036:note_history:2]
In the normal course of business we make commitments to our
 third-party contract manufacturers, to manage manufacturer lead
 times and meet product forecasts, and to other parties, to purchase
 various key components used in the manufacture of our products. We
 establish accruals for estimated losses on purchased components to
 the extent we believe it is probable that such components will not
 be utilized in future operations. To the extent that such forecasts
 are not achieved, our commitments and associated accruals may
 change. As of July 26, 2013, we had $336.3 million in
 non-cancelable purchase commitments with our contract
 manufacturers. In addition, we recorded a liability for firm,
 non-cancelable and unconditional purchase commitments with contract
 manufacturers for quantities in excess of our future demand
 forecasts through a charge to cost of product sales. As of
 July 26, 2013 and April 26, 2013, such liability amounted
 to $9.3 million and $9.5 million, respectively, and is included in
 other current liabilities in our condensed consolidated balance
 sheets.

- changed (2013-11-26):
[0001193125-13-454984:note_history:3]
In addition to commitments with contract manufacturers and
 component suppliers, we have open purchase orders and contractual
 obligations associated with our ordinary course business for which
 we have not received goods or services. As of October 25,
 2013, we had $33.6 million in capital purchase commitments and
 $202.4 million in other purchase commitments.
  (was, 2013-08-29, similarity 0.984):
[0001193125-13-352036:note_history:3]
In addition to commitments with contract manufacturers and
 component suppliers, we have open purchase orders and contractual
 obligations associated with our ordinary course business for which
 we have not received goods or services. As of July 26, 2013,
 we had $71.5 million in capital purchase commitments and $181.2
 million in other purchase commitments.

- changed (2013-11-26):
[0001193125-13-454984:note_history:4]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Beginning balance |  | $ | 119.8 |  |  | $ | 96.5 |  |  | $ | 117.2 |  |  | $ | 83.1 |  |
| Expense accrued during the period |  |  | 14.3 |  |  |  | 27.1 |  |  |  | 38.3 |  |  |  | 50.8 |  |
| Warranty costs incurred |  |  | (18.1 | ) |  |  | (11.8 | ) |  |  | (39.5 | ) |  |  | (22.1 | ) |
| Ending balance |  | $ | 116.0 |  |  | $ | 111.8 |  |  | $ | 116.0 |  |  | $ | 111.8 |  |
  (was, 2013-08-29, similarity 0.6277):
[0001193125-13-352036:note_history:4]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Beginning balance |  | $ | 117.2 |  |  | $ | 83.1 |  |
| Expense accrued during the period |  |  | 24.0 |  |  |  | 23.7 |  |
| Warranty costs incurred |  |  | (21.4 | ) |  |  | (10.3 | ) |
| Ending balance |  | $ | 119.8 |  |  | $ | 96.5 |  |

- changed (2013-11-26):
[0001193125-13-454984:note_history:5]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Other current liabilities |  | $ | 78.1 |  |  | $ | 81.6 |  |
| Other long-term liabilities |  |  | 37.9 |  |  |  | 35.6 |  |
| Total |  | $ | 116.0 |  |  | $ | 117.2 |  |
  (was, 2013-08-29, similarity 0.9687):
[0001193125-13-352036:note_history:5]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Other current liabilities |  | $ | 81.8 |  |  | $ | 81.6 |  |
| Other long-term liabilities |  |  | 38.0 |  |  |  | 35.6 |  |
| Total |  | $ | 119.8 |  |  | $ | 117.2 |  |

- changed (2013-11-26):
[0001193125-13-454984:note_history:6]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Maximum guaranteed payment contingencies |  | $ | 215.6 |  |  | $ | 182.4 |  |
| Deferred revenue associated with financing guarantees |  |  | (199.0 | ) |  |  | (168.6 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 16.6 |  |  | $ | 13.8 |  |
  (was, 2013-08-29, similarity 0.9828):
[0001193125-13-352036:note_history:6]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Maximum guaranteed payment contingencies |  | $ | 196.1 |  |  | $ | 182.4 |  |
| Deferred revenue associated with financing guarantees |  |  | (180.8 | ) |  |  | (168.6 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 15.3 |  |  | $ | 13.8 |  |

- changed (2013-11-26):
[0001193125-13-454984:note_history:7]
We are subject to various legal proceedings and claims that
 arise in the normal course of business. No accrual has been
 recorded as of October 25, 2013 related to such matters as
 they are not probable and/or reasonably estimable.
  (was, 2013-08-29, similarity 0.9753):
[0001193125-13-352036:note_history:7]
We are subject to various legal proceedings and claims that
 arise in the normal course of business. No accrual has been
 recorded as of July 26, 2013 related to such matters as they
 are not probable and/or reasonably estimable.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2013-11-26):
[0001193125-13-352036:note_history:8]
2.  Condensed
 Consolidated Financial Statements

- removed (2013-11-26):
[0001193125-13-352036:note_history:9]
Fiscal Year — Our fiscal year is reported on
 a 52- or 53-week year ending on the last Friday in April. The first
 quarters of fiscal 2014 and 2013 were each 13-week
 periods.

- removed (2013-11-26):
[0001193125-13-352036:note_history:10]
Basis of Presentation — The accompanying unaudited
 condensed consolidated financial statements have been prepared by
 the Company, and reflect all adjustments, consisting only of normal
 recurring adjustments, that are, in the opinion of management,
 necessary for the fair presentation of our financial position,
 results of operations, comprehensive income and cash flows for the
 interim periods presented. The statements have been prepared in
 accordance with accounting principles generally accepted in the
 United States of America (GAAP) for interim financial information
 and in accordance with the instructions to Form 10-Q and Rule 10-01
 of Regulation S-X. Accordingly, these statements do not include all
 information and footnotes required by GAAP for annual consolidated
 financial statements, and should be read in conjunction with our
 audited consolidated financial statements as of and for the fiscal
 year ended April 26, 2013 contained in our Annual Report on
 Form 10-K filed with the Securities and Exchange Commission on
 June 17, 2013. The results of operations for the three months
 ended July 26, 2013 are not necessarily indicative of the
 operating results to be expected for the full fiscal year or future
 operating periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-11-26):
[0001193125-13-454984:note_history:11]
There
 have been no significant changes in our significant accounting
 policies as of and for the six months ended October 25, 2013,
 as compared to the significant accounting policies described in our
 Annual Report on Form 10-K for the fiscal year ended April 26,
 2013.
  (was, 2013-08-29, similarity 0.9625):
[0001193125-13-352036:note_history:11]
There have been no significant changes in our significant
 accounting policies as of and for the three months ended
 July 26, 2013, as compared to the significant accounting
 policies described in our Annual Report on Form 10-K for the fiscal
 year ended April 26, 2013.

- changed (2013-11-26):
[0001193125-13-454984:note_history:12]
Recent Accounting Standards Not Yet Effective — In
 July 2013, the Financial Accounting Standards Board issued an
 accounting standard update providing presentation requirements for
 unrecognized tax benefit when a net operating loss carryforward, a
 similar tax loss, or a similar tax credit carryforward exists. This
 accounting standard update will be effective for us beginning in
 our first quarter of fiscal 2015 and is not expected to have a
 significant impact on our consolidated financial
 statements.
  (was, 2013-08-29, similarity 0.9492):
[0001193125-13-352036:note_history:12]
In July 2013, the Financial Accounting Standards Board issued
 an accounting standard update providing presentation requirements
 for unrecognized tax benefit when a net operating loss
 carryforward, a similar tax loss, or a similar tax credit
 carryforward exists. This accounting standard update will be
 effective for us beginning in our first quarter of fiscal 2015 and
 is not expected to have a significant impact on our consolidated
 financial statements.

- removed (2013-11-26):
[0001193125-13-352036:note_history:13]
Recent Accounting Standards Not Yet Effective


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-11-26):
[0001193125-13-454984:note_history:14]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total principal amount |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.0 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total debt |  |  | 995.0 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term portion |  | $ | 995.0 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |
  (was, 2013-08-29, similarity 0.8733):
[0001193125-13-352036:note_history:14]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.2 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total |  |  | 994.8 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 994.8 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |

- changed (2013-11-26):
[0001193125-13-454984:note_history:15]
Our Senior Notes, issued in December 2012, are unsecured,
 unsubordinated obligations, which pay interest semi-annually on
 June 15 and December 15 and rank equally in right of
 payment with any future senior unsecured indebtedness. Interest
 expense associated with the Senior Notes was $6.2 million and $12.5
 million for the three and six months ended October 25, 2013,
 respectively.
  (was, 2013-08-29, similarity 0.8438):
[0001193125-13-352036:note_history:15]
Our Senior Notes are unsecured, unsubordinated obligations,
 which pay interest semi-annually on June 15 and
 December 15 and rank equally in right of payment with any
 future senior unsecured indebtedness. Interest expense associated
 with the Senior Notes was $6.3 million for the three months ended
 July 26, 2013.

- changed (2013-11-26):
[0001193125-13-454984:note_history:16]
We may redeem the Senior Notes in whole or in part, at any time
 at our option at specified redemption prices. In addition, upon the
 occurrence of certain change of control triggering events, we may
 be required to repurchase the Senior Notes at 101% of their
 aggregate principal amount, plus accrued and unpaid interest to the
 date of repurchase. The Senior Notes also include covenants that
 limit our ability to incur debt secured by liens on assets or on
 shares of stock or indebtedness of our subsidiaries; to engage in
 sale and lease-back transactions; and to consolidate, merge or sell
 all or substantially all of our assets. As of October 25,
 2013, we were in compliance with all covenants associated with the
 Senior Notes.
  (was, 2013-08-29, similarity 0.9923):
[0001193125-13-352036:note_history:16]
We may redeem the Senior Notes in whole or in part, at any time
 at our option at specified redemption prices. In addition, upon the
 occurrence of certain change of control triggering events, we may
 be required to repurchase the Senior Notes at 101% of their
 aggregate principal amount, plus accrued and unpaid interest to the
 date of repurchase. The Senior Notes also include covenants that
 limit our ability to incur debt secured by liens on assets or on
 shares of stock or indebtedness of our subsidiaries; to engage in
 sale and lease-back transactions; and to consolidate, merge or sell
 all or substantially all of our assets. As of July 26, 2013,
 we were in compliance with all covenants associated with the Senior
 Notes.

- changed (2013-11-26):
[0001193125-13-454984:note_history:17]
On June 10, 2008, we issued $1,265.0 million
 aggregate principal amount of 1.75% Convertible Senior Notes
 (the Convertible Notes) with a maturity date of June 1, 2013.
 The Convertible Notes were unsecured, unsubordinated obligations of
 the Company and paid interest in cash semi-annually at a rate of
 1.75% per annum. Upon maturity, the Convertible Notes were
 converted into shares of common stock at a conversion rate of 31.40
 shares of common stock per $1,000 principal amount of the
 Convertible Notes (which represented the effective conversion price
 of $31.85 per share). Upon conversion in June 2013, the holders
 received cash for the principal amount of the Convertible Notes and
 an aggregate of 4.9 million shares of common stock for the
 $178.9 million excess of the conversion value over the principal
 amount.
  (was, 2013-08-29, similarity 0.975):
[0001193125-13-352036:note_history:17]
On June 10, 2008, we issued $1,265.0 million
 aggregate principal amount of 1.75% Convertible Senior Notes
 (the Convertible Notes) with a maturity date of June 1, 2013.
 The Convertible Notes were unsecured, unsubordinated obligations of
 the Company and paid interest in cash semi-annually at a rate of
 1.75% per annum. Upon maturity, the Convertible Notes were
 converted based on a conversion rate of 31.40 shares of common
 stock per $1,000 principal amount of the Convertible Notes (which
 represented the effective conversion price of $31.85 per share).
 Upon conversion in June 2013, the holders received cash for the
 principal amount of the Convertible Notes and an aggregate of
 4.9 million shares of common stock for the $178.9 million
 excess of the conversion value over the principal
 amount.

- changed (2013-11-26):
[0001193125-13-454984:note_history:18]
• Convertible Note Hedges: As of April 26, 2013, we
 had arrangements with counterparties to buy up to approximately
 31.8 million shares of our common stock, at a price of $31.85
 per share. In June 2013, concurrent with the repayment and
 conversion of the Convertible Notes, we exercised the Convertible
 Note hedges that were net settled for an aggregate of
 3.9 million shares from the counterparties.
  (was, 2013-08-29, similarity 0.9354):
[0001193125-13-352036:note_history:18]
• Convertible Note Hedges: As of April 26, 2013, we
 had arrangements with counterparties to buy up to approximately
 31.8 million shares of our common stock, at a price of $31.85
 per share. In June 2013, concurrent with the repayment and
 conversion of the Convertible Notes, we exercised the Convertible
 Note hedges, for which we received an aggregate of 3.9 million
 shares from the counterparties.

- added (2013-11-26):
[0001193125-13-454984:note_history:19]
• Warrants: As of April 26, 2013, we had outstanding
 warrants for certain counterparties to acquire 39.7 million
 shares of our common stock at an exercise price of $41.28 per
 share. The warrants were exercisable on a series of days commencing
 on September 3, 2013 and ending on October 28, 2013. The
 number of warrants and exercise price were adjusted in July 2013 to
 39.9 million and $41.12 per share, respectively, to reflect
 our July 2013 dividend. On October 17, 2013, the exercise
 price of the warrants then outstanding was further adjusted to
 $40.97 per share to reflect our October 2013 dividend. Through
 October 25, 2013, 31.9 million warrants were exercised
 and net settled with 1.1 million shares of our common stock
 equal to the difference between the market price on the date of
 exercise and the exercise price of the warrants on the respective
 exercise dates. The remaining warrants had an exercise price
 greater than the market price and expired unexercised by
 October 28, 2013.

- changed (2013-11-26):
[0001193125-13-454984:note_history:20]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 2.5 |  |  | $ | 11.0 |  |
| Amortization of debt discount |  |  | 13.6 |  |  |  | 7.1 |  |  |  | 27.1 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 0.6 |  |  |  | 2.4 |  |
| Less capitalized interest |  |  | (0.6 | ) |  |  | 0.0 |  |  |  | (1.1 | ) |
| Total interest expense related to Convertible Notes |  | $ | 19.7 |  |  | $ | 10.2 |  |  | $ | 39.4 |  |
  (was, 2013-08-29, similarity 0.8235):
[0001193125-13-352036:note_history:20]
|  |  | Three Months Ended |  |
|  |  | July 26, 2013 |  |  | July 27, 2012 |  |
| Contractual coupon interest expense |  | $ | 2.5 |  |  | $ | 5.5 |  |
| Amortization of debt discount |  |  | 7.1 |  |  |  | 13.5 |  |
| Amortization of debt issuance costs |  |  | 0.6 |  |  |  | 1.2 |  |
| Less capitalized interest |  |  | 0.0 |  |  |  | (0.5 | ) |
| Total interest expense related to Convertible Notes |  | $ | 10.2 |  |  | $ | 19.7 |  |

- added (2013-11-26):
[0001193125-13-454984:note_history:21]
No interest expense related to the Convertible Notes was
 recognized in the three months ended October 25, 2013 due to
 their maturity.

- changed (2013-11-26):
[0001193125-13-454984:note_history:22]
As of October 25, 2013, our aggregate future principal
 debt maturities are as follows (in millions):
  (was, 2013-08-29, similarity 0.9405):
[0001193125-13-352036:note_history:22]
As of July 26, 2013, our aggregate future principal debt
 maturities are as follows (in millions):

- changed (2013-11-26):
[0001193125-13-454984:note_history:23]
In December 2012, we entered into a credit agreement with a
 syndicated group of lenders that provides for an unsecured $250.0
 million revolving credit facility that is comprised of revolving
 loans, Eurocurrency loans and/or swingline loans. The credit
 facility includes a $100.0 million foreign currency sub-facility, a
 $50.0 million letter of credit sub-facility and a $10.0 million
 swingline sub-facility available on same-day notice. Available
 borrowings under the credit facility are reduced by the amount of
 any outstanding borrowings on the sub-facilities. We may also,
 subject to certain requirements, request an increase in the
 facility up to an additional $100.0 million and request two
 additional one-year extensions, subject to certain conditions. The
 proceeds from the facility may be used by us for general corporate
 purposes.
  (was, 2013-08-29, similarity 0.9939):
[0001193125-13-352036:note_history:23]
In December 2012, we entered into a credit agreement with a
 syndicated group of lenders that provides for an unsecured $250.0
 million five-year revolving credit facility that is comprised of
 revolving loans, Eurocurrency loans and/or swingline loans. The
 credit facility includes a $100.0 million foreign currency
 sub-facility, a $50.0 million letter of credit sub-facility and a
 $10.0 million swingline sub-facility available on same-day notice.
 Available borrowings under the credit facility are reduced by the
 amount of any outstanding borrowings on the sub-facilities. We may
 also, subject to certain requirements, request an increase in the
 facility up to an additional $100.0 million and request two
 additional one-year extensions, subject to certain conditions. The
 proceeds from the facility may be used by us for general corporate
 purposes.

- changed (2013-11-26):
[0001193125-13-454984:note_history:24]
Borrowings under the facility, except for swingline loans,
 accrue interest in arrears at an alternate base rate as defined in
 the credit agreement or, at our option, an adjusted London
 Interbank Offered Rate (LIBOR) plus in each case, a spread (based
 on our public debt ratings and the type of loan) ranging from 0.2%
 to 1.2%. Swingline borrowings accrue interest at an alternate base
 rate. In addition, we are required to pay fees to maintain the
 credit facility, whether or not we have outstanding borrowings. The
 facility terminates on December 21, 2017 if no extensions have
 been requested and contains financial covenants requiring us to
 maintain a maximum leverage ratio of not more than 3.0:1.0 and a
 minimum interest coverage ratio of not less than 3.5:1.0. The
 facility contains customary affirmative and negative covenants,
 including covenants that limit our ability to incur debt secured by
 liens on assets or indebtedness of our subsidiaries and to
 consolidate, merge or sell all or substantially all of our assets.
 As of October 25, 2013, no borrowings were outstanding under
 the facility and we were in compliance with all covenants
 associated with the facility.
  (was, 2013-08-29, similarity 0.9952):
[0001193125-13-352036:note_history:24]
Borrowings under the facility, except for swingline loans,
 accrue interest in arrears at an alternate base rate as defined in
 the credit agreement or, at our option, an adjusted London
 Interbank Offered Rate (LIBOR) plus in each case, a spread (based
 on our public debt ratings and the type of loan) ranging from 0.2%
 to 1.2%. Swingline borrowings accrue interest at an alternate base
 rate. In addition, we are required to pay fees to maintain the
 credit facility, whether or not we have outstanding borrowings. The
 facility terminates on December 21, 2017 if no extensions have
 been requested and contains financial covenants requiring us to
 maintain a maximum leverage ratio of not more than 3.0:1.0 and a
 minimum interest coverage ratio of not less than 3.5:1.0. The
 facility contains customary affirmative and negative covenants,
 including covenants that limit our ability to incur debt secured by
 liens on assets or indebtedness of our subsidiaries and to
 consolidate, merge or sell all or substantially all of our assets.
 As of July 26, 2013, no borrowings were outstanding under the
 facility and we were in compliance with all covenants associated
 with the facility.

- changed (2013-11-26):
[0001193125-13-454984:note_history:25]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Current portion of other long-term financing arrangements |  | $ | 7.1 |  |  | $ | 5.2 |  |
| Non-current portion of other long-term financing arrangements |  |  | 9.5 |  |  |  | 5.6 |  |
| Total |  | $ | 16.6 |  |  | $ | 10.8 |  |
  (was, 2013-08-29, similarity 0.9772):
[0001193125-13-352036:note_history:25]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Current portion of other long-term financing arrangements |  | $ | 9.3 |  |  | $ | 5.2 |  |
| Non-current portion of other long-term financing arrangements |  |  | 11.0 |  |  |  | 5.6 |  |
| Total |  | $ | 20.3 |  |  | $ | 10.8 |  |

- removed (2013-11-26):
[0001193125-13-352036:note_history:26]
• Warrants: As of July 26, 2013, we had outstanding
 warrants for certain counterparties to acquire, subject to
 anti-dilution adjustments, 39.9 million shares of our common
 stock at an exercise price of $41.12 per share as adjusted to
 reflect our July 2013 dividend. Prior to the dividend, we had
 39.7 million outstanding warrants at an exercise price of
 $41.28 per share. The number of warrants and the exercise price are
 subject to additional adjustments for specified conditions,
 including future dividend declarations. The warrants are
 exercisable on a series of days commencing on September 3,
 2013 and ending on October 28, 2013. Upon exercise of the
 warrants, we have the option to deliver cash or shares of our
 common stock equal to the difference between the then market price
 and the strike price of the warrants.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2013-11-26):
[0001193125-13-454984:note_history:27]
Other Long-Term Financing Arrangements

- changed (2013-11-26):
[0001193125-13-454984:note_history:28]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| Current portion of other long-term financing arrangements |  | $ | 7.1 |  |  | $ | 5.2 |  |
| Non-current portion of other long-term financing arrangements |  |  | 9.5 |  |  |  | 5.6 |  |
| Total |  | $ | 16.6 |  |  | $ | 10.8 |  |
  (was, 2013-08-29, similarity 0.9772):
[0001193125-13-352036:note_history:28]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
| Current portion of other long-term financing arrangements |  | $ | 9.3 |  |  | $ | 5.2 |  |
| Non-current portion of other long-term financing arrangements |  |  | 11.0 |  |  |  | 5.6 |  |
| Total |  | $ | 20.3 |  |  | $ | 10.8 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-11-26):
[0001193125-13-454984:note_history:29]
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total principal amount |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.0 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total debt |  |  | 995.0 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term portion |  | $ | 995.0 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |
  (was, 2013-08-29, similarity 0.8733):
[0001193125-13-352036:note_history:29]
|  |  | July 26, 2013 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.2 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total |  |  | 994.8 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 994.8 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |

- removed (2013-11-26):
[0001193125-13-352036:note_history:30]
N/A - Not
 Applicable


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-11-26):
[0001193125-13-454984:note_history:31]
As of October 25, 2013, our aggregate future principal
 debt maturities are as follows (in millions):
  (was, 2013-08-29, similarity 0.9405):
[0001193125-13-352036:note_history:31]
As of July 26, 2013, our aggregate future principal debt
 maturities are as follows (in millions):
