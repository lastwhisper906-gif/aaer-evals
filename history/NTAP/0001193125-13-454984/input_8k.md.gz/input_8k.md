# NTAP 8-K — 0001102624-13-001387 filed 2013-11-13

## item codes, every 8-K on or before 2013-11-26

- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2013-11-26

- none on or before 2013-11-26

## item 2.02 — earnings release, exhibit 99.1

[0001102624-13-001387:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-13-001387:8k_2_02:2]
exh99_1.htm

[0001102624-13-001387:8k_2_02:3]
Exhibit 99.1

[0001102624-13-001387:8k_2_02:4]
| Press Contact: | Investor Contact: |
| Ryan Lowry | Kris Newton |
| NetApp | NetApp |
| 408-822-7544 | 408-822-3312 |
| ryanl@netapp.com | kris.newton@netapp.com |

[0001102624-13-001387:8k_2_02:5]
NETAPP REPORTS SECOND QUARTER FISCAL YEAR 2014 RESULTS

[0001102624-13-001387:8k_2_02:6]
Non-GAAP Earnings Per Share of $0.66, Up 29% Year over Year

[0001102624-13-001387:8k_2_02:7]
| · | Revenue of $1.550 billion |

[0001102624-13-001387:8k_2_02:8]
| · | Branded revenue up 5% year over year |

[0001102624-13-001387:8k_2_02:9]
| · | Cash from operations of $363 million; free cash flow 21% of revenue |

[0001102624-13-001387:8k_2_02:10]
| · | Over 1,900 Clustered Data ONTAP® nodes shipped, up almost 300% year over year |

[0001102624-13-001387:8k_2_02:11]
Sunnyvale, Calif.—November 13, 2013—NetApp (NASDAQ: NTAP) today reported financial results for the second quarter of fiscal year 2014, ended October 25, 2013.

[0001102624-13-001387:8k_2_02:12]
Second Quarter Financial Results

[0001102624-13-001387:8k_2_02:13]
Total revenues for the second quarter of fiscal year 2014 were $1.550 billion, an increase of 1% from the comparable period of the prior year. GAAP net income for the second quarter of fiscal year 2014 was $167 million, or $0.48 per share,1 compared to GAAP net income of $110 million, or $0.30 per share, for the comparable period of the prior year. Non-GAAP net income for the second quarter of fiscal year 2014 was $232 million, or $0.66 per share,2 compared to non-GAAP net income of $189 million, or $0.51 per share, for the comparable period of the prior year.

[0001102624-13-001387:8k_2_02:14]
Cash, Cash Equivalents and Investments

[0001102624-13-001387:8k_2_02:15]
NetApp ended the second quarter of 2014 with $5.273 billion of total cash, cash equivalents and investments and during the quarter generated approximately $363 million in cash from operations. The company returned $202 million to shareholders during the quarter through share repurchases and a cash dividend. The next dividend in the amount of $0.15 per share will be paid on January 22, 2014 to shareholders of record as of the close of business on January 9, 2014.

[0001102624-13-001387:8k_2_02:16]
“NetApp is at the forefront of a changing IT landscape, creating opportunity from perceived threats,” said Tom Georgens, president and CEO. “Though we face an ongoing uncertain macro environment, our solid branded revenue growth and share gains are evidence of the value customers place on our innovative, best-of-breed solutions.”

[0001102624-13-001387:8k_2_02:17]
6

[0001102624-13-001387:8k_2_02:18]
Q3 Fiscal Year 2014 Outlook

[0001102624-13-001387:8k_2_02:19]
The Company is providing the following financial guidance for the third quarter of fiscal year 2014:

[0001102624-13-001387:8k_2_02:20]
| · | Total revenue is expected to be in the range of $1.575 billion to $1.675 billion |

[0001102624-13-001387:8k_2_02:21]
| · | GAAP earnings per share is expected to be in the range of $0.50 to $0.55 per share |

[0001102624-13-001387:8k_2_02:22]
| · | Non-GAAP earnings per share is expected to be in the range of $0.68 to $0.73 per share |

[0001102624-13-001387:8k_2_02:23]
Business Highlights

[0001102624-13-001387:8k_2_02:24]
In its second quarter of fiscal year 2014, NetApp delivered technology innovation focused on helping customers capitalize on cloud and software-defined data center trends, and once again was recognized as one of the world’s best workplaces. Highlights include:

[0001102624-13-001387:8k_2_02:25]
| · | NetApp Outlines Strategy to Enable Hybrid Cloud Architectures. NetApp’s strategy is to use the world’s number-one branded storage operating system, Data ONTAP, as a universal data platform to provide seamless cloud management across any blend of private and public cloud resources. |

[0001102624-13-001387:8k_2_02:26]
| · | NetApp and Verizon Team on Software-Defined Storage Solutions for New Verizon Cloud. The two companies will collaborate to rearchitect traditional cloud-based storage models to deliver NetApp Data ONTAP as a virtual storage appliance for Verizon Cloud clients. The software will deliver on the promise of software-defined storage, providing additional deployment and management flexibility for clients implementing Verizon Cloud Compute and Verizon Cloud Storage. |

[0001102624-13-001387:8k_2_02:27]
| · | NetApp and VMware Help Customers Move to Software-Defined Data Centers. New integrations with VMware vCloud Suite and NetApp clustered Data ONTAP enable nondisruptive migration of data for hundreds of virtual machines at a time, and streamlines provisioning, analysis, data protection, and disaster recovery for virtualized environments, simplifying and accelerating the deployment of software-defined storage in software-defined data center environments. |

[0001102624-13-001387:8k_2_02:28]
| · | NetApp Deepens Integration with Oracle’s Cloud-Enabling Software. The integration can deliver enhanced features for Oracle Database 12c and Oracle Enterprise Manager 12c, allowing customers to centrally manage and maintain control of their data across private, public, and hybrid clouds. |

[0001102624-13-001387:8k_2_02:29]
| · | NetApp Helps Orange Business Services Deliver Cloud Solutions. Orange Business Services developed its Flexible Computing solution with NetApp Data ONTAP at its core. As a result, Orange Business Services is able to provide enterprise customers with high-level data availability, helping to establish itself as a leading global IT infrastructure provider with more than 600 Flexible Computing customers worldwide. |

[0001102624-13-001387:8k_2_02:30]
| · | NetApp Earns #3 Ranking as Best Place to Work in the World. NetApp placed in the top five on the “World’s Best Multinational Workplaces” list for the third consecutive year due to its employee-driven culture. NetApp believes that its culture is a sustainable differentiator and is committed to being a model company that empowers great outcomes for its partners, customers, and investors. |

[0001102624-13-001387:8k_2_02:31]
7

[0001102624-13-001387:8k_2_02:32]
Editor’s Note

[0001102624-13-001387:8k_2_02:33]
| · | Financial information previously found in the Supplemental Commentary document is now included in the accompanying Supplemental Data tables of the quarterly financial press release. |

[0001102624-13-001387:8k_2_02:34]
| · | In addition, historical supplemental data tables, providing historical multi-period financial information, are available on our investor relations website at investors.netapp.com. |

[0001102624-13-001387:8k_2_02:35]
Webcast and Conference Call Information

[0001102624-13-001387:8k_2_02:36]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release and any other information related to the call will be posted on the Investor Relations website. An audio replay will also be available after 4:30 p.m. Pacific Time today on the website.

[0001102624-13-001387:8k_2_02:37]
About NetApp

[0001102624-13-001387:8k_2_02:38]
NetApp creates innovative storage and data management solutions that deliver outstanding cost efficiency and accelerate business breakthroughs. Our commitment to living our core values and consistently being recognized as a great place to work around the world are fundamental to our long-term growth and success, as well as the success of our pathway partners and customers. Discover our passion for helping companies around the world go further, faster at www.netapp.com.

[0001102624-13-001387:8k_2_02:39]
###

[0001102624-13-001387:8k_2_02:40]
NetApp, the NetApp logo, Go further, faster, and Data ONTAP are trademarks or registered trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001102624-13-001387:8k_2_02:41]
8

[0001102624-13-001387:8k_2_02:42]
1GAAP earnings per share is calculated using the diluted number of shares for all periods presented.

[0001102624-13-001387:8k_2_02:43]
2Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com.

[0001102624-13-001387:8k_2_02:44]
NetApp Usage of Non-GAAP Financials

[0001102624-13-001387:8k_2_02:45]
The Company refers to the non-GAAP financial measures in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-13-001387:8k_2_02:46]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation. We have historically reported similar non-GAAP financial measures to our investors and believe that the inclusion of comparative numbers provides consistency in our financial reporting at this time.

[0001102624-13-001387:8k_2_02:47]
9

[0001102624-13-001387:8k_2_02:48]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | October 25, 2013 |  |  | April 26, 2013 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,272.7 |  |  | $ | 6,952.6 |  |
| Accounts receivable, net |  |  | 590.4 |  |  |  | 800.9 |  |
| Inventories |  |  | 115.9 |  |  |  | 139.5 |  |
| Other current assets |  |  | 441.0 |  |  |  | 525.2 |  |
| Total current assets |  |  | 6,420.0 |  |  |  | 8,418.2 |  |
| Property and equipment, net |  |  | 1,142.9 |  |  |  | 1,170.9 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,139.0 |  |  |  | 1,168.7 |  |
| Other non-current assets |  |  | 495.5 |  |  |  | 484.6 |  |
| Total assets |  | $ | 9,197.4 |  |  | $ | 11,242.4 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 223.8 |  |  | $ | 259.7 |  |
| Accrued compensation and other current liabilities |  |  | 659.1 |  |  |  | 749.8 |  |
| Current portion of long-term debt |  |  | - |  |  |  | 1,257.8 |  |
| Short-term deferred revenue |  |  | 1,525.8 |  |  |  | 1,563.3 |  |
| Total current liabilities |  |  | 2,408.7 |  |  |  | 3,830.6 |  |
| Long-term debt |  |  | 995.0 |  |  |  | 994.6 |  |
| Other long-term liabilities |  |  | 267.2 |  |  |  | 253.5 |  |
| Long-term deferred revenue |  |  | 1,406.1 |  |  |  | 1,446.2 |  |
| Total liabilities |  |  | 5,077.0 |  |  |  | 6,524.9 |  |
| Stockholders' equity |  |  | 4,120.4 |  |  |  | 4,717.5 |  |
| Total liabilities and stockholders' equity |  | $ | 9,197.4 |  |  | $ | 11,242.4 |  |

[0001102624-13-001387:8k_2_02:49]
10

[0001102624-13-001387:8k_2_02:50]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 955.3 |  |  | $ | 995.8 |  |  | $ | 1,886.1 |  |  | $ | 1,893.8 |  |
| Software entitlements and maintenance |  |  | 231.8 |  |  |  | 219.4 |  |  |  | 460.3 |  |  |  | 437.9 |  |
| Service |  |  | 362.8 |  |  |  | 326.0 |  |  |  | 719.7 |  |  |  | 654.1 |  |
| Net revenues |  |  | 1,549.9 |  |  |  | 1,541.2 |  |  |  | 3,066.1 |  |  |  | 2,985.8 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 423.3 |  |  |  | 477.3 |  |  |  | 873.2 |  |  |  | 929.5 |  |
| Cost of software entitlements and maintenance |  |  | 7.5 |  |  |  | 7.0 |  |  |  | 15.0 |  |  |  | 13.6 |  |
| Cost of service |  |  | 153.9 |  |  |  | 143.0 |  |  |  | 303.1 |  |  |  | 278.7 |  |
| Total cost of revenues |  |  | 584.7 |  |  |  | 627.3 |  |  |  | 1,191.3 |  |  |  | 1,221.8 |  |
| Gross profit |  |  | 965.2 |  |  |  | 913.9 |  |  |  | 1,874.8 |  |  |  | 1,764.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 479.5 |  |  |  | 488.2 |  |  |  | 947.3 |  |  |  | 971.1 |  |
| Research and development |  |  | 228.2 |  |  |  | 223.8 |  |  |  | 456.3 |  |  |  | 445.2 |  |
| General and administrative |  |  | 69.5 |  |  |  | 66.6 |  |  |  | 137.9 |  |  |  | 132.2 |  |
| Restructuring and other charges |  |  | 1.1 |  |  |  | - |  |  |  | 49.5 |  |  |  | - |  |
| Total operating expenses |  |  | 778.3 |  |  |  | 778.6 |  |  |  | 1,591.0 |  |  |  | 1,548.5 |  |
| Income from operations |  |  | 186.9 |  |  |  | 135.3 |  |  |  | 283.8 |  |  |  | 215.5 |  |
| Other income/(expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 8.5 |  |  |  | 11.0 |  |  |  | 18.5 |  |  |  | 21.8 |  |
| Interest expense |  |  | (6.5 | ) |  |  | (19.8 | ) |  |  | (23.0 | ) |  |  | (39.7 | ) |
| Other income, net |  |  | 3.3 |  |  |  | 1.2 |  |  |  | 5.2 |  |  |  | 4.3 |  |
| Total other income/(expense), net |  |  | 5.3 |  |  |  | (7.6 | ) |  |  | 0.7 |  |  |  | (13.6 | ) |
| Income before income taxes |  |  | 192.2 |  |  |  | 127.7 |  |  |  | 284.5 |  |  |  | 201.9 |  |
| Provision for income taxes |  |  | 25.4 |  |  |  | 18.1 |  |  |  | 36.1 |  |  |  | 28.5 |  |
| Net income |  | $ | 166.8 |  |  | $ | 109.6 |  |  | $ | 248.4 |  |  | $ | 173.4 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.49 |  |  | $ | 0.30 |  |  | $ | 0.72 |  |  | $ | 0.48 |  |
| Diluted |  | $ | 0.48 |  |  | $ | 0.30 |  |  | $ | 0.70 |  |  | $ | 0.47 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 340.7 |  |  |  | 362.0 |  |  |  | 345.8 |  |  |  | 364.1 |  |
| Diluted |  |  | 349.1 |  |  |  | 368.2 |  |  |  | 354.5 |  |  |  | 369.7 |  |
| Cash dividends declared per share |  | $ | 0.15 |  |  | $ | - |  |  | $ | 0.30 |  |  | $ | - |  |

[0001102624-13-001387:8k_2_02:51]
11

[0001102624-13-001387:8k_2_02:52]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOW |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2013 |  |  | October 26, 2012 |  |  | October 25, 2013 |  |  | October 26, 2012 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 166.8 |  |  | $ | 109.6 |  |  | $ | 248.4 |  |  | $ | 173.4 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 82.5 |  |  |  | 86.7 |  |  |  | 168.4 |  |  |  | 169.1 |  |
| Stock-based compensation |  |  | 67.6 |  |  |  | 65.0 |  |  |  | 133.9 |  |  |  | 144.2 |  |
| Accretion of discount and issuance costs on debt |  |  | 0.6 |  |  |  | 14.4 |  |  |  | 8.8 |  |  |  | 28.7 |  |
| Excess tax benefit from stock-based compensation |  |  | (9.4 | ) |  |  | (38.7 | ) |  |  | (9.5 | ) |  |  | (43.6 | ) |
| Other, net |  |  | 10.5 |  |  |  | 21.1 |  |  |  | (24.9 | ) |  |  | (11.7 | ) |
| Changes in assets and liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (55.9 | ) |  |  | (31.3 | ) |  |  | 209.3 |  |  |  | 212.9 |  |
| Inventories |  |  | 0.7 |  |  |  | (9.5 | ) |  |  | 23.6 |  |  |  | (51.7 | ) |
| Accounts payable |  |  | (2.9 | ) |  |  | (28.0 | ) |  |  | (40.8 | ) |  |  | 13.9 |  |
| Accrued compensation and other current liabilities |  |  | 73.0 |  |  |  | 130.8 |  |  |  | (102.4 | ) |  |  | (15.9 | ) |
| Deferred revenue |  |  | (13.3 | ) |  |  | 4.4 |  |  |  | (67.6 | ) |  |  | (42.6 | ) |
| Changes in other operating assets and liabilities, net |  |  | 42.3 |  |  |  | 11.9 |  |  |  | 101.1 |  |  |  | (11.1 | ) |
| Net cash provided by operating activities |  |  | 362.5 |  |  |  | 336.4 |  |  |  | 648.3 |  |  |  | 565.6 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 282.1 |  |  |  | 159.5 |  |  |  | 672.1 |  |  |  | 93.4 |  |
| Purchases of property and equipment |  |  | (42.2 | ) |  |  | (67.1 | ) |  |  | (107.5 | ) |  |  | (129.0 | ) |
| Other investing activities, net |  |  | 2.2 |  |  |  | 1.5 |  |  |  | 3.4 |  |  |  | 2.8 |  |
| Net cash provided by (used in) investing activities |  |  | 242.1 |  |  |  | 93.9 |  |  |  | 568.0 |  |  |  | (32.8 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock under employee stock plans |  |  | 52.4 |  |  |  | 10.1 |  |  |  | 123.9 |  |  |  | 45.1 |  |
| Repurchase of common stock |  |  | (150.5 | ) |  |  | (198.3 | ) |  |  | (1,000.0 | ) |  |  | (348.3 | ) |
| Excess tax benefit from stock-based compensation |  |  | 9.4 |  |  |  | 38.7 |  |  |  | 9.5 |  |  |  | 43.6 |  |
| Repayment of debt |  |  | - |  |  |  | - |  |  |  | (1,264.9 | ) |  |  | - |  |
| Dividends paid |  |  | (51.3 | ) |  |  | - |  |  |  | (102.7 | ) |  |  | - |  |
| Other financing activities, net |  |  | (15.2 | ) |  |  | 1.7 |  |  |  | (5.7 | ) |  |  | (0.3 | ) |
| Net cash used in financing activities |  |  | (155.2 | ) |  |  | (147.8 | ) |  |  | (2,239.9 | ) |  |  | (259.9 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 14.3 |  |  |  | 4.9 |  |  |  | 7.0 |  |  |  | (5.9 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 463.7 |  |  |  | 287.4 |  |  |  | (1,016.6 | ) |  |  | 267.0 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 1,796.8 |  |  |  | 1,529.4 |  |  |  | 3,277.1 |  |  |  | 1,549.8 |  |
| End of period |  | $ | 2,260.5 |  |  | $ | 1,816.8 |  |  | $ | 2,260.5 |  |  | $ | 1,816.8 |  |

[0001102624-13-001387:8k_2_02:53]
12

[0001102624-13-001387:8k_2_02:54]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except percentages, DSO and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q2 FY’14 |  |  | Q1 FY’14 |  |  | Q2 FY’13 |  |
| Revenues |  |  |  |  |  |  |  |  |  |
| Product Revenue |  | $ | 955.3 |  |  | $ | 930.8 |  |  | $ | 995.8 |  |
| Software Entitlements & Maintenance Revenue (SEM) |  |  | 231.8 |  |  |  | 228.5 |  |  |  | 219.4 |  |
| Service Revenue: |  |  | 362.8 |  |  |  | 356.9 |  |  |  | 326.0 |  |
| Hardware Maintenance Support Contracts Revenue |  |  | 276.4 |  |  |  | 273.6 |  |  |  | 239.9 |  |
| Professional & Other Services Revenue |  |  | 86.4 |  |  |  | 83.2 |  |  |  | 86.1 |  |
| Net Revenue |  | $ | 1,549.9 |  |  | $ | 1,516.2 |  |  | $ | 1,541.2 |  |
| Branded and OEM Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY’14 |  |  | Q1 FY’14 |  |  | Q2 FY’13 |  |
| Branded Revenue |  | $ | 1,398.8 |  |  | $ | 1,349.7 |  |  | $ | 1,331.6 |  |
| OEM Revenue |  |  | 151.1 |  |  |  | 166.5 |  |  |  | 209.6 |  |
| Net Revenue |  | $ | 1,549.9 |  |  | $ | 1,516.2 |  |  | $ | 1,541.2 |  |
| Branded revenue includes revenue from all products and services sold directly by us or our partners under the NetApp brand, including NetApp branded E-Series products and solutions. |  |
| OEM revenue comprises revenue from the sale of our products by other companies under their brands and includes revenue from IBM, Fujitsu, and other E-Series OEM relationships. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY’14 Revenue |  |  | % of Q1 FY’14 Revenue |  |  | % of Q2 FY’13 Revenue |  |
| Americas* |  |  | 58 | % |  |  | 57 | % |  |  | 58 | % |
| Americas Commercial |  |  | 42 | % |  |  | 44 | % |  |  | 41 | % |
| U.S. Public Sector |  |  | 16 | % |  |  | 12 | % |  |  | 17 | % |
| EMEA |  |  | 29 | % |  |  | 30 | % |  |  | 28 | % |
| Asia Pacific |  |  | 13 | % |  |  | 14 | % |  |  | 13 | % |
| * Americas Commercial and USPS revenue for Q2FY'13 is recast as a result of reporting certain healthcare revenue in Americas Commercial revenue that was previously included |  |
| in U.S. Public Sector revenue. A reconciliation of this change is posted to our website at investors.netapp.com. |  |  |  |  |  |  |
| Pathways Mix |  |
|  |  | % of Q2 FY’14 Revenue |  |  | % of Q1 FY’14 Revenue |  |  | % of Q2 FY’13 Revenue |  |
| Direct |  |  | 17 | % |  |  | 20 | % |  |  | 18 | % |
| Indirect |  |  | 83 | % |  |  | 80 | % |  |  | 82 | % |
| Indirect revenues include those sold through value-added resellers, system integrators, OEM's and distributors. |  |  |  |  |  |  |  |  |  |  |  |  |
| Direct revenues are those sold through our direct sales force. The Direct / Indirect revenue mix reflects order fulfillment, not who owns the customer relationship. |  |  |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY’14 |  |  | Q1 FY’14 |  |  | Q2 FY’13 |  |
| Non-GAAP Gross Margin |  |  | 63.6 | % |  |  | 61.3 | % |  |  | 60.6 | % |
| Product |  |  | 57.3 | % |  |  | 53.3 | % |  |  | 53.6 | % |
| Software Entitlements & Maintenance (SEM) |  |  | 96.8 | % |  |  | 96.7 | % |  |  | 96.8 | % |
| Service |  |  | 58.9 | % |  |  | 59.5 | % |  |  | 57.5 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY’14 |  |  | Q1 FY’14 |  |  | Q2 FY’13 |  |
| Non-GAAP Income from Operations |  | $ | 270.5 |  |  | $ | 226.5 |  |  | $ | 221.8 |  |
| % of Net Revenue |  |  | 17.5 | % |  |  | 14.9 | % |  |  | 14.4 | % |
| Non-GAAP Income before Income Taxes |  | $ | 275.8 |  |  | $ | 230.1 |  |  | $ | 228.6 |  |
| Non-GAAP Effective Tax Rate |  |  | 16.1 | % |  |  | 16.6 | % |  |  | 17.3 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY’14 |  |  | Q1 FY’14 |  |  | Q2 FY’13 |  |
| Non-GAAP Net Income |  | $ | 231.5 |  |  | $ | 191.9 |  |  | $ | 189.0 |  |
| Weighted Average Common Shares Outstanding, Diluted |  |  | 349.1 |  |  |  | 359.9 |  |  |  | 368.2 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 0.66 |  |  | $ | 0.53 |  |  | $ | 0.51 |  |
| Included in the diluted weighted average common shares outstanding are none, 2.6 million and 1.0 million shares in Q2 FY'14, Q1 FY'14 and Q2 FY'13 respectively, |  |
| related to the impact of our convertible notes. |  |  |  |  |  |  |  |  |  |  |  |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY’14 |  |  | Q1 FY’14 |  |  | Q2 FY’13 |  |
| Deferred Revenue |  | $ | 2,931.9 |  |  | $ | 2,941.3 |  |  | $ | 2,770.2 |  |
| DSO (days) |  |  | 35 |  |  |  | 32 |  |  |  | 36 |  |
| Inventory Turns |  |  | 20 |  |  |  | 20 |  |  |  | 11 |  |
| Days sales outstanding are defined as accounts receivable net divided by net revenue, multiplied by the number of days in the quarter. |  |  |  |  |  |
| Inventory turns are defined as annualized non-GAAP cost of revenues divided by net inventories. |  |  |  |  |  |  |  |  |  |  |  |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY’14 |  |  | Q1 FY’14 |  |  | Q2 FY’13 |  |
| Net Cash Provided by Operating Activities |  | $ | 362.5 |  |  | $ | 285.8 |  |  | $ | 336.4 |  |
| Purchases of Property and Equipment |  | $ | 42.2 |  |  | $ | 65.3 |  |  | $ | 67.1 |  |
| Free Cash Flow |  | $ | 320.3 |  |  | $ | 220.5 |  |  | $ | 269.3 |  |
| Free Cash Flow as % of Total Revenue |  |  | 20.7 | % |  |  | 14.5 | % |  |  | 17.5 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |  |  |  |  |
| Some items may not add or recalculate due to rounding |  |  |  |  |  |  |  |  |  |  |  |  |

[0001102624-13-001387:8k_2_02:55]
13

[0001102624-13-001387:8k_2_02:56]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| FINANCIAL STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |
|  |  | October 25, 2013 |  |  | July 26, 2013 |  |  | October 26, 2012 |  |
| NET INCOME |  | $ | 166.8 |  |  | $ | 81.6 |  |  | $ | 109.6 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.9 |  |  |  | 14.9 |  |  |  | 21.5 |  |
| Stock-based compensation |  |  | 67.6 |  |  |  | 66.3 |  |  |  | 65.0 |  |
| Restructuring and other charges |  |  | 1.1 |  |  |  | 48.4 |  |  |  | - |  |
| Non-cash interest expense |  |  | - |  |  |  | 8.2 |  |  |  | 14.4 |  |
| Income tax effect of Non-GAAP adjustments |  |  | (18.9 | ) |  |  | (27.5 | ) |  |  | (21.5 | ) |
| NON-GAAP NET INCOME |  | $ | 231.5 |  |  | $ | 191.9 |  |  | $ | 189.0 |  |
| COST OF REVENUES |  | $ | 584.7 |  |  | $ | 606.6 |  |  | $ | 627.3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14.3 | ) |  |  | (14.3 | ) |  |  | (13.9 | ) |
| Stock-based compensation |  |  | (5.6 | ) |  |  | (5.3 | ) |  |  | (6.1 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 564.8 |  |  | $ | 587.0 |  |  | $ | 607.3 |  |
| COST OF PRODUCT REVENUES |  | $ | 423.3 |  |  | $ | 449.9 |  |  | $ | 477.3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (13.8 | ) |  |  | (13.7 | ) |  |  | (13.9 | ) |
| Stock-based compensation |  |  | (1.4 | ) |  |  | (1.3 | ) |  |  | (1.5 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 408.1 |  |  | $ | 434.9 |  |  | $ | 461.9 |  |
| COST OF SERVICE REVENUES |  | $ | 153.9 |  |  | $ | 149.2 |  |  | $ | 143.0 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.5 | ) |  |  | (0.6 | ) |  |  | - |  |
| Stock-based compensation |  |  | (4.2 | ) |  |  | (4.0 | ) |  |  | (4.6 | ) |
| NON-GAAP COST OF SERVICE REVENUES |  | $ | 149.2 |  |  | $ | 144.6 |  |  | $ | 138.4 |  |
| GROSS PROFIT |  | $ | 965.2 |  |  | $ | 909.6 |  |  | $ | 913.9 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.3 |  |  |  | 14.3 |  |  |  | 13.9 |  |
| Stock-based compensation |  |  | 5.6 |  |  |  | 5.3 |  |  |  | 6.1 |  |
| NON-GAAP GROSS PROFIT |  | $ | 985.1 |  |  | $ | 929.2 |  |  | $ | 933.9 |  |
| SALES AND MARKETING EXPENSES |  | $ | 479.5 |  |  | $ | 467.8 |  |  | $ | 488.2 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | (7.6 | ) |
| Stock-based compensation |  |  | (31.1 | ) |  |  | (30.5 | ) |  |  | (30.9 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 447.8 |  |  | $ | 436.7 |  |  | $ | 449.7 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 228.2 |  |  | $ | 228.1 |  |  | $ | 223.8 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (21.6 | ) |  |  | (21.4 | ) |  |  | (19.3 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 206.6 |  |  | $ | 206.7 |  |  | $ | 204.5 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 69.5 |  |  | $ | 68.4 |  |  | $ | 66.6 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (9.3 | ) |  |  | (9.1 | ) |  |  | (8.7 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 60.2 |  |  | $ | 59.3 |  |  | $ | 57.9 |  |

[0001102624-13-001387:8k_2_02:57]
14

[0001102624-13-001387:8k_2_02:58]
| RESTRUCTURING AND OTHER CHARGES |  | $ | 1.1 |  |  | $ | 48.4 |  |  | $ | - |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  |  | (1.1 | ) |  |  | (48.4 | ) |  |  | - |  |
| NON-GAAP RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| OPERATING EXPENSES |  | $ | 778.3 |  |  | $ | 812.7 |  |  | $ | 778.6 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | (7.6 | ) |
| Stock-based compensation |  |  | (62.0 | ) |  |  | (61.0 | ) |  |  | (58.9 | ) |
| Restructuring and other charges |  |  | (1.1 | ) |  |  | (48.4 | ) |  |  | - |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 714.6 |  |  | $ | 702.7 |  |  | $ | 712.1 |  |
| INCOME FROM OPERATIONS |  | $ | 186.9 |  |  | $ | 96.9 |  |  | $ | 135.3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.9 |  |  |  | 14.9 |  |  |  | 21.5 |  |
| Stock-based compensation |  |  | 67.6 |  |  |  | 66.3 |  |  |  | 65.0 |  |
| Restructuring and other charges |  |  | 1.1 |  |  |  | 48.4 |  |  |  | - |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 270.5 |  |  | $ | 226.5 |  |  | $ | 221.8 |  |
| TOTAL OTHER INCOME (EXPENSE), NET |  | $ | 5.3 |  |  | $ | (4.6 | ) |  | $ | (7.6 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-cash interest expense |  |  | - |  |  |  | 8.2 |  |  |  | 14.4 |  |
| NON-GAAP TOTAL OTHER INCOME, NET |  | $ | 5.3 |  |  | $ | 3.6 |  |  | $ | 6.8 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 192.2 |  |  | $ | 92.3 |  |  | $ | 127.7 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.9 |  |  |  | 14.9 |  |  |  | 21.5 |  |
| Stock-based compensation |  |  | 67.6 |  |  |  | 66.3 |  |  |  | 65.0 |  |
| Restructuring and other charges |  |  | 1.1 |  |  |  | 48.4 |  |  |  | - |  |
| Non-cash interest expense |  |  | - |  |  |  | 8.2 |  |  |  | 14.4 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 275.8 |  |  | $ | 230.1 |  |  | $ | 228.6 |  |
| PROVISION FOR INCOME TAXES |  | $ | 25.4 |  |  | $ | 10.7 |  |  | $ | 18.1 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of Non-GAAP adjustments |  |  | 18.9 |  |  |  | 27.5 |  |  |  | 21.5 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 44.3 |  |  | $ | 38.2 |  |  | $ | 39.6 |  |
| NET INCOME PER SHARE |  | $ | 0.478 |  |  | $ | 0.227 |  |  | $ | 0.298 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.043 |  |  |  | 0.041 |  |  |  | 0.058 |  |
| Stock-based compensation |  |  | 0.194 |  |  |  | 0.184 |  |  |  | 0.176 |  |
| Restructuring and other charges |  |  | 0.002 |  |  |  | 0.134 |  |  |  | - |  |
| Non-cash interest expense |  |  | - |  |  |  | 0.023 |  |  |  | 0.039 |  |
| Income tax effect of Non-GAAP adjustments |  |  | (0.054 | ) |  |  | (0.076 | ) |  |  | (0.058 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.663 |  |  | $ | 0.533 |  |  | $ | 0.513 |  |

[0001102624-13-001387:8k_2_02:59]
15

[0001102624-13-001387:8k_2_02:60]
|  | NETAPP, INC. |
|  | RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
|  | EXPRESSED AS EARNINGS PER SHARE |
|  | THIRD QUARTER 2014 |
|  | (Unaudited) |
|  | Third Quarter |
|  | 2014 |
| Non-GAAP Guidance - Net Income Per Share | $0.68 - $0.73 |
| Adjustments of Specific Items to |  |
| Net Income Per Share for the Third |  |
| Quarter 2014: |  |
| Amortization of intangible assets | (0.04) |
| Stock-based compensation expense | (0.20) |
| Income tax effect | 0.06 |
| Total Adjustments | (0.18) |
| GAAP Guidance - Net Income Per Share | $0.50 - $0.55 |

[0001102624-13-001387:8k_2_02:61]
16
