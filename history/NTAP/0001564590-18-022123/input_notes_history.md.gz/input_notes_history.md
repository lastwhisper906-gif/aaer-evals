# NTAP note change history — 0001564590-18-002876 → 0001564590-18-022123


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-08-21):
[0001564590-18-022123:note_history:1]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $184 million as of July 27, 2018.
  (was, 2018-02-22, similarity 0.9854):
[0001564590-18-002876:note_history:1]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $198 million as of January 26, 2018.

- changed (2018-08-21):
[0001564590-18-022123:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 27, 2018, we had $382 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 27, 2018 and April 27, 2018, such liability amounted to $22 million and $14 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2018-02-22, similarity 0.9929):
[0001564590-18-002876:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 26, 2018, we had $387 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 26, 2018 and April 28, 2017, such liability amounted to $11 million and $10 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2018-08-21):
[0001564590-18-022123:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 27, 2018, we had $5 million in construction related obligations and $195 million in other purchase obligations.
  (was, 2018-02-22, similarity 0.9904):
[0001564590-18-002876:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 26, 2018, we had $15 million in construction related obligations and $222 million in other purchase obligations.

- changed (2018-08-21):
[0001564590-18-022123:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $30 million and $31 million of receivables during the three months ended July 27, 2018 and July 28, 2017, respectively.
  (was, 2018-02-22, similarity 0.9896):
[0001564590-18-002876:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $62 million and $142 million of receivables during the nine months ended January 26, 2018 and January 27, 2017, respectively.

- changed (2018-08-21):
[0001564590-18-022123:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of July 27, 2018 and April 27, 2018, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2018-02-22, similarity 0.7362):
[0001564590-18-002876:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of January 26, 2018 and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- changed (2018-08-21):
[0001564590-18-022123:note_history:6]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 27, 2018, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.
  (was, 2018-02-22, similarity 0.9961):
[0001564590-18-002876:note_history:6]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 26, 2018, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- changed (2018-08-21):
[0001564590-18-022123:note_history:7]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.
  (was, 2018-02-22, similarity 0.999):
[0001564590-18-002876:note_history:7]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict, and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

- changed (2018-08-21):
[0001564590-18-022123:note_history:8]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of July 27, 2018 related to such matters.
  (was, 2018-02-22, similarity 0.9961):
[0001564590-18-002876:note_history:8]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of January 26, 2018 related to such matters.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-08-21):
[0001564590-18-022123:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 27, 2018 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 27, 2018 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2018-02-22, similarity 0.9924):
[0001564590-18-002876:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 28, 2017 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 26, 2018 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- added (2018-08-21):
[0001564590-18-022123:note_history:10]
Accounting Changes

- added (2018-08-21):
[0001564590-18-022123:note_history:11]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard, Revenue from Contracts with Customers (ASC 606), which establishes a comprehensive new revenue recognition model designed to depict the transfer of goods or services to a customer in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In the three months ended July 27, 2018, we adopted this new standard using the full retrospective method of adoption. Accordingly, our prior period condensed consolidated financial statements and information, as presented herein, have been restated to conform to the new rules. Refer to Note 6 – Revenue for a summary of the impacts of adopting this standard, and a discussion of our updated policies related to revenue recognition.

- added (2018-08-21):
[0001564590-18-022123:note_history:12]
In October 2016, the FASB issued an accounting standards update (ASU) which eliminates the deferred tax effects of intra-entity asset transfers other than inventory. As a result, tax expense from the sale of an asset in the seller’s tax jurisdiction is recognized when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. In the three months ended July 27, 2018, we adopted this ASU using a modified retrospective transition approach and recorded a cumulative-effect adjustment to decrease retained earnings by $51 million, with a corresponding reduction of prepaid taxes, which were classified as other non-current assets on our condensed consolidated balance sheets, as of the beginning of the period.

- added (2018-08-21):
[0001564590-18-022123:note_history:13]
In November 2016, the FASB issued an ASU that requires a statement of cash flows to explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. In the three months ended July 27, 2018, we adopted this ASU using a retrospective transition method. Accordingly, our condensed consolidated statement of cash flows for the three months ended July 28, 2017, as presented herein, has been restated to comply with the new requirements. Refer to Note 5 – Supplemental Financial Information for a detail of the components of our cash, cash equivalents and restricted cash balances.

- changed (2018-08-21):
[0001564590-18-022123:note_history:14]
There have been no other significant changes in our significant accounting policies as of and for the three months ended July 27, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 27, 2018.
  (was, 2018-02-22, similarity 0.6615):
[0001564590-18-002876:note_history:14]
There have been no significant changes in our significant accounting policies as of and for the nine months ended January 26, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 28, 2017.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-21):
[0001564590-18-022123:note_history:15]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  |  | 400 |  |  |  | 2.32 | % |  |  | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (8 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,542 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |
  (was, 2018-02-22, similarity 0.6189):
[0001564590-18-002876:note_history:15]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | — |  |  | N/A |  |  | $ | 750 |  |  |  | 2.25 | % |
| 2.00% Senior Notes Due September 2019 |  |  | 400 |  |  |  | 2.32 | % |  |  | — |  |  | N/A |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | — |  |  | N/A |  |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (10 | ) |  |  |  |  |  |  | (7 | ) |  |  |  |  |
| Total senior notes |  |  | 1,540 |  |  |  |  |  |  |  | 1,493 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | — |  |  |  |  |  |  |  | (749 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,540 |  |  |  |  |  |  | $ | 744 |  |  |  |  |  |

- added (2018-08-21):
[0001564590-18-022123:note_history:16]
Our 2.00% Senior Notes and 3.30% Senior Notes, each with a principal amount of $400 million, were issued in September 2017. Interest on these Senior Notes is paid semi-annually in March and September. Our 3.375% Senior Notes and 3.25% Senior Notes, with principal amounts of $500 million and $250 million, respectively, were issued in June 2014 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

- changed (2018-08-21):
[0001564590-18-022123:note_history:17]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 27, 2018, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2018-02-22, similarity 0.9946):
[0001564590-18-002876:note_history:17]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 26, 2018, we were in compliance with all covenants associated with the Senior Notes.

- changed (2018-08-21):
[0001564590-18-022123:note_history:18]
As of July 27, 2018, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2018-02-22, similarity 0.973):
[0001564590-18-002876:note_history:18]
As of January 26, 2018, our aggregate future principal debt maturities are as follows (in millions):

- changed (2018-08-21):
[0001564590-18-022123:note_history:19]
| Fiscal Year |  | Amount |  |
| 2020 |  | $ | 400 |  |
| 2022 |  |  | 500 |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| Total |  | $ | 1,550 |  |
  (was, 2018-02-22, similarity 0.88):
[0001564590-18-002876:note_history:19]
| Fiscal Year |  | Amount |  |
| 2020 |  | $ | 400 |  |
| 2022 |  |  | 500 |  |
| Thereafter |  |  | 650 |  |
| Total |  | $ | 1,550 |  |

- changed (2018-08-21):
[0001564590-18-022123:note_history:20]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of July 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $200 million, a weighted-average interest rate of 2.28% and maturities ranging from 14 days to 31 days. As of April 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $385 million, a weighted-average interest rate of 2.29% and maturities ranging from 19 days to 32 days.
  (was, 2018-02-22, similarity 0.9951):
[0001564590-18-002876:note_history:20]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended on July 17, 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of January 26, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $632 million, a weighted-average interest rate of 1.81% and maturities ranging from 17 days to 46 days. As of April 28, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $500 million, a weighted-average interest rate of 1.26% and maturities ranging from 7 days to 38 days.

- changed (2018-08-21):
[0001564590-18-022123:note_history:21]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of July 27, 2018 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.
  (was, 2018-02-22, similarity 0.9939):
[0001564590-18-002876:note_history:21]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended on July 17, 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of January 26, 2018 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

- removed (2018-08-21):
[0001564590-18-002876:note_history:22]
__________________

- removed (2018-08-21):
[0001564590-18-002876:note_history:23]
N/A - Not applicable

- removed (2018-08-21):
[0001564590-18-002876:note_history:24]
In September 2017, we issued $400 million aggregate principal amount of 2.00% Senior Notes due on September 27, 2019 and $400 million aggregate principal amount of 3.30% Senior Notes due on September 29, 2024, for which we received total proceeds of approximately $795 million, net of discount and issuance costs. On November 3, 2017, we extinguished our 2.00% Senior Notes due December 2017 for an aggregate redemption price of $751 million, plus accrued and unpaid interest.

- removed (2018-08-21):
[0001564590-18-002876:note_history:25]
Interest on our Senior Notes issued in September 2017 is payable semi-annually in March and September. Our 3.375% Senior Notes and 3.25% Senior Notes, with principal amounts of $500 million and $250 million, respectively, were issued in June 2014 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

- removed (2018-08-21):
[0001564590-18-002876:note_history:26]
Sale-leaseback Transactions

- removed (2018-08-21):
[0001564590-18-002876:note_history:27]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates through December 31, 2017. These properties did not qualify for sale-leaseback accounting and as a result they were accounted for as financing transactions. In December 2017, we terminated the leases and recorded a non-cash sale of properties with a net book value of $54 million, the extinguishment of $130 million in financing obligations, and a gain of $76 million. As of January 26, 2018, there are no balances remaining on our condensed consolidated balance sheets associated with this sale-leaseback arrangement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-21):
[0001564590-18-022123:note_history:28]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  |  | 400 |  |  |  | 2.32 | % |  |  | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (8 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,542 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |
  (was, 2018-02-22, similarity 0.6189):
[0001564590-18-002876:note_history:28]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | — |  |  | N/A |  |  | $ | 750 |  |  |  | 2.25 | % |
| 2.00% Senior Notes Due September 2019 |  |  | 400 |  |  |  | 2.32 | % |  |  | — |  |  | N/A |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | — |  |  | N/A |  |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (10 | ) |  |  |  |  |  |  | (7 | ) |  |  |  |  |
| Total senior notes |  |  | 1,540 |  |  |  |  |  |  |  | 1,493 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | — |  |  |  |  |  |  |  | (749 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,540 |  |  |  |  |  |  | $ | 744 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-21):
[0001564590-18-022123:note_history:29]
As of July 27, 2018, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2018-02-22, similarity 0.973):
[0001564590-18-002876:note_history:29]
As of January 26, 2018, our aggregate future principal debt maturities are as follows (in millions):

- changed (2018-08-21):
[0001564590-18-022123:note_history:30]
| Fiscal Year |  | Amount |  |
| 2020 |  | $ | 400 |  |
| 2022 |  |  | 500 |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| Total |  | $ | 1,550 |  |
  (was, 2018-02-22, similarity 0.88):
[0001564590-18-002876:note_history:30]
| Fiscal Year |  | Amount |  |
| 2020 |  | $ | 400 |  |
| 2022 |  |  | 500 |  |
| Thereafter |  |  | 650 |  |
| Total |  | $ | 1,550 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-08-21):
[0001564590-18-022123:note_history:31]
The following table depicts the disaggregation of revenue by our products and services (in millions):

- added (2018-08-21):
[0001564590-18-022123:note_history:32]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Product revenues |  | $ | 875 |  |  | $ | 727 |  |
| Strategic |  |  | 612 |  |  |  | 498 |  |
| Mature |  |  | 263 |  |  |  | 229 |  |
| Software maintenance revenues |  | 229 |  |  | 223 |  |
| Hardware maintenance and other services revenues |  | 370 |  |  | 371 |  |
| Hardware maintenance support contracts |  |  | 303 |  |  |  | 298 |  |
| Professional and other services |  |  | 67 |  |  |  | 73 |  |
| Net revenues |  | $ | 1,474 |  |  | $ | 1,321 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-08-21):
[0001564590-18-022123:note_history:33]
6. Revenue

- added (2018-08-21):
[0001564590-18-022123:note_history:34]
Effective our first quarter of fiscal 2019, we adopted ASC 606 using the full retrospective method and have restated each prior reporting period presented to conform to the new rules. The most significant impact of the new standard relates to our accounting for arrangements containing software. For our enterprise software license agreements (ELAs), we now recognize the license fee component of such arrangements up front. Under the prior rules, the software license fee was recognized over the term of the enterprise license based on our inability to establish vendor specific objective evidence of fair value for the undelivered software support element of these arrangements. In addition, for other software arrangements, revenue deferred for the undelivered elements that was previously allocated based on the residual method is now allocated based on relative fair value, which generally results in more software arrangement revenue being recognized earlier. The new standard also impacts our estimation of variable consideration for certain arrangements with contract terms such as rights of return, potential penalties and acceptance clauses.

- added (2018-08-21):
[0001564590-18-022123:note_history:35]
The following table presents the impacts of adoption of ASC 606 to select line items of our condensed consolidated balance sheet as of the end of fiscal 2018:

- added (2018-08-21):
[0001564590-18-022123:note_history:36]
|  |  | As of April 27, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  | As Adjusted |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 1,009 |  |  | $ | 38 |  |  | (1 | ) | $ | 1,047 |  |
| Inventories |  |  | 126 |  |  |  | (4 | ) |  |  |  |  | 122 |  |
| Other current assets |  |  | 330 |  |  |  | 62 |  |  | (2 | ) |  | 392 |  |
| Other non-current assets |  |  | 420 |  |  |  | 30 |  |  | (2 | ) |  | 450 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term deferred revenue and financed unearned services revenue |  | $ | 1,804 |  |  | $ | (92 | ) |  | (3 | ) | $ | 1,712 |  |
| Other long-term liabilities |  |  | 961 |  |  |  | 31 |  |  | (4 | ) |  | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,673 |  |  |  | (22 | ) |  | (3 | ) |  | 1,651 |  |
| Accumulated deficit |  |  | (218 | ) |  |  | 209 |  |  | (5 | ) |  | (9 | ) |

- added (2018-08-21):
[0001564590-18-022123:note_history:37]
|  | (1) | Netting of accounts receivable and deferred revenue balances for certain customer arrangements has been updated to reflect the impact of adoption |

- added (2018-08-21):
[0001564590-18-022123:note_history:38]
|  | (2) | Reflects capitalization of commissions and reduction of long-term deferred tax assets |

- added (2018-08-21):
[0001564590-18-022123:note_history:39]
|  | (3) | Reflects cumulative change in revenue and the impact of adoption to the netting of accounts receivable and deferred revenue balances for certain customer arrangements |

- added (2018-08-21):
[0001564590-18-022123:note_history:40]
|  | (4) | Reflects increase in long-term deferred tax liabilities |

- added (2018-08-21):
[0001564590-18-022123:note_history:41]
|  | (5) | Reflects cumulative impact to net income (loss) |

- added (2018-08-21):
[0001564590-18-022123:note_history:42]
The following table presents the impacts of adoption of ASC 606 to our statement of operations for the first quarter of fiscal 2018:

- added (2018-08-21):
[0001564590-18-022123:note_history:43]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 723 |  |  | $ | 4 |  |  | $ | 727 |  |
| Software maintenance |  |  | 234 |  |  |  | (11 | ) |  |  | 223 |  |
| Hardware maintenance and other services |  |  | 368 |  |  |  | 3 |  |  |  | 371 |  |
| Net revenues |  |  | 1,325 |  |  |  | (4 | ) |  |  | 1,321 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 371 |  |  |  | 5 |  |  |  | 376 |  |
| Cost of software maintenance |  |  | 7 |  |  |  | — |  |  |  | 7 |  |
| Cost of hardware maintenance and other services |  |  | 113 |  |  |  | 1 |  |  |  | 114 |  |
| Total cost of revenues |  |  | 491 |  |  |  | 6 |  |  |  | 497 |  |
| Gross profit |  |  | 834 |  |  |  | (10 | ) |  |  | 824 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 425 |  |  |  | (2 | ) |  |  | 423 |  |
| Research and development |  |  | 193 |  |  |  | — |  |  |  | 193 |  |
| General and administrative |  |  | 68 |  |  |  | — |  |  |  | 68 |  |
| Total operating expenses |  |  | 686 |  |  |  | (2 | ) |  |  | 684 |  |
| Income from operations |  |  | 148 |  |  |  | (8 | ) |  |  | 140 |  |
| Other income, net |  |  | 5 |  |  |  | — |  |  |  | 5 |  |
| Income before income taxes |  |  | 153 |  |  |  | (8 | ) |  |  | 145 |  |
| Provision for income taxes |  |  | 17 |  |  |  | (3 | ) |  |  | 14 |  |
| Net income |  | $ | 136 |  |  | $ | (5 | ) |  | $ | 131 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.50 |  |  | $ | (0.01 | ) |  | $ | 0.49 |  |
| Diluted |  | $ | 0.49 |  |  | $ | (0.02 | ) |  | $ | 0.47 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 270 |  |  |  | 270 |  |  |  | 270 |  |
| Diluted |  |  | 278 |  |  |  | 278 |  |  |  | 278 |  |

- added (2018-08-21):
[0001564590-18-022123:note_history:44]
The adoption of ASC 606 had no impact to cash provided by or used in operating, investing or financing activities as presented on our condensed consolidated statement of cash flows.

- added (2018-08-21):
[0001564590-18-022123:note_history:45]
The core principle of ASC 606 is to recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled in exchange for those goods or services. This principle is achieved through applying the following five-step approach.

- added (2018-08-21):
[0001564590-18-022123:note_history:46]
|  | • | Identification of the contract, or contracts, with a customer — A contract with a customer exists when (i) we enter into an enforceable contract with a customer that (ii) defines each party’s rights regarding the goods or services to be transferred and (iii) identifies the payment terms related to these goods or services. Additionally, (iv) the contract has commercial substance and, (v) we determine that collection of substantially all consideration for goods or services that are transferred is probable based on the customer’s intent and ability to pay the promised consideration. We apply judgment in determining the customer’s ability and intention to pay, which is based on a variety of factors including the customer’s historical payment experience or, in the case of a new customer, published credit and financial information pertaining to the customer. We also combine two or more contracts entered into at or near the same time with the same customer as a single contract if the contracts are negotiated as one package with a single commercial objective, the amount of consideration to be paid on one contract depends on the price or performance of the other contract or if the goods and services promised in each of the contracts are a single performance obligation. |

- added (2018-08-21):
[0001564590-18-022123:note_history:47]
|  | • | Identification of the performance obligations in the contract — Performance obligations promised in a contract are identified based on the goods or services (or a bundle of goods and services) that will be transferred to the customer that are distinct. A good or service is distinct if it is capable of being distinct, where the customer can benefit from the goods or service either on its own or together with other resources that are readily available from third parties or from us, and is distinct in the context of the contract, meaning the transfer of the goods or services is separately identifiable from other promises in the contract. To the extent a contract includes multiple promised goods or services, we apply judgment to determine whether promised goods or services are capable of being distinct and distinct in the context of the contract. If these criteria are not met, we combine the goods and services until we have a distinct performance obligation. |

- added (2018-08-21):
[0001564590-18-022123:note_history:48]
|  | • | Determination of the transaction price — The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer. Consideration promised may include fixed amounts, variable amounts or both. We use judgment in determining variable consideration, particularly if consideration is contingent on the occurrence or nonoccurrence of a future event. We use the expected value, primarily relying on our history, to estimate variable consideration. We may also use, in certain situations, the most likely amount as the basis of our estimate. In either case, we consider variable consideration only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recognized will not occur. Reassessments of our variable consideration may occur as historical information changes. Transaction prices should also be adjusted for the effects of time value of money if the timing of payments provides either the customer or ourselves a significant benefit of financing. |

- added (2018-08-21):
[0001564590-18-022123:note_history:49]
|  | • | Allocation of the transaction price to the performance obligations in the contract — If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation based on a relative standalone selling price basis. We determine standalone selling price based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price taking into account available information such as market conditions and internally approved pricing guidelines related to the performance obligations. Variable consideration is also allocated to the performance obligations. If the terms of variable consideration relate to one performance obligation, it is entirely allocated to that obligation. Otherwise, it is allocated to all the performance obligations in the contract. |

- added (2018-08-21):
[0001564590-18-022123:note_history:50]
|  | • | Recognition of revenue when, or as, we satisfy a performance obligation — We satisfy performance obligations either over time or at a point in time. We typically recognize revenue at a point in time for promises to transfer goods to a customer. Services are typically transferred over time based on an appropriate method for measuring our progress toward completion of that performance obligation. Our stand-ready services, including both hardware and software maintenance support, are transferred ratably over the period of the contract. For other services such as our fixed professional services contract, we use an input method to determine the percentage of completion. That is, we estimate the effort to date versus the expected effort required over the life of the contract. |

- added (2018-08-21):
[0001564590-18-022123:note_history:51]
Disaggregation of revenue

- added (2018-08-21):
[0001564590-18-022123:note_history:52]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. Strategic solutions include Clustered ONTAP, branded E-Series, SolidFire, converged and hyper-converged infrastructure, ELAs and other optional add-on software products. Mature solutions include 7-mode ONTAP, add-on hardware and related operating system (OS) software and original equipment manufacturers (OEM) products. Both our Mature and Strategic product lines include a mix of disk, hybrid and all flash storage media. Additionally, we provide a variety of services including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training.

- added (2018-08-21):
[0001564590-18-022123:note_history:53]
The following table depicts the disaggregation of revenue by our products and services (in millions):

- added (2018-08-21):
[0001564590-18-022123:note_history:54]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Product revenues |  | $ | 875 |  |  | $ | 727 |  |
| Strategic |  |  | 612 |  |  |  | 498 |  |
| Mature |  |  | 263 |  |  |  | 229 |  |
| Software maintenance revenues |  | 229 |  |  | 223 |  |
| Hardware maintenance and other services revenues |  | 370 |  |  | 371 |  |
| Hardware maintenance support contracts |  |  | 303 |  |  |  | 298 |  |
| Professional and other services |  |  | 67 |  |  |  | 73 |  |
| Net revenues |  | $ | 1,474 |  |  | $ | 1,321 |  |

- added (2018-08-21):
[0001564590-18-022123:note_history:55]
Revenues by geographic region are presented in Note 15 – Segment, Geographic, and Significant Customer Information.

- added (2018-08-21):
[0001564590-18-022123:note_history:56]
Deferred revenue and financed unearned services revenue

- added (2018-08-21):
[0001564590-18-022123:note_history:57]
The following table summarizes the components of our deferred revenue and financed unearned services balance as reported in our condensed consolidated balance sheets (in millions):

- added (2018-08-21):
[0001564590-18-022123:note_history:58]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Deferred product revenue |  | $ | 102 |  |  | $ | 107 |  |
| Deferred services revenue |  |  | 3,046 |  |  |  | 3,134 |  |
| Financed unearned services revenue |  |  | 112 |  |  |  | 122 |  |
| Total |  | $ | 3,260 |  |  | $ | 3,363 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,623 |  |  | $ | 1,712 |  |
| Long-term |  |  | 1,637 |  |  |  | 1,651 |  |
| Total |  | $ | 3,260 |  |  | $ | 3,363 |  |

- added (2018-08-21):
[0001564590-18-022123:note_history:59]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 16 – Commitments and Contingencies for additional information related to these arrangements.

- added (2018-08-21):
[0001564590-18-022123:note_history:60]
The following tables summarize the activity related to deferred revenue and financed unearned services revenue (in millions):

- added (2018-08-21):
[0001564590-18-022123:note_history:61]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Balance at beginning of period |  | $ | 3,363 |  |  | $ | 3,213 |  |
| Additions |  |  | 511 |  |  |  | 497 |  |
| Revenue recognized during the period |  |  | (614 | ) |  |  | (583 | ) |
| Balance at end of period |  | $ | 3,260 |  |  | $ | 3,127 |  |

- added (2018-08-21):
[0001564590-18-022123:note_history:62]
During the three months ended July 27, 2018 and July 28, 2017, we recognized $561 million and $528 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

- added (2018-08-21):
[0001564590-18-022123:note_history:63]
As of July 27, 2018, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,260 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 26% in the next 13 to 24 months, and the remainder thereafter.

- added (2018-08-21):
[0001564590-18-022123:note_history:64]
Deferred commissions

- added (2018-08-21):
[0001564590-18-022123:note_history:65]
As a result of our adoption of ASC 606 in the first quarter of fiscal 2019, we capitalize sales commissions that are incremental direct costs of obtaining customer contracts for which revenue is not immediately recognized and classify them as current or non-current based on the terms of the related contracts. Capitalized commissions are amortized based on the transfer of goods or services to which they relate, typically over one to three years, and are also periodically reviewed for impairment. Amortization expense is recorded to sales and marketing expense in our condensed consolidated statements of operations. The following tables summarize the activity related to deferred commissions and their balances as reported in our condensed consolidated balance sheets (in millions):

- added (2018-08-21):
[0001564590-18-022123:note_history:66]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Balance at beginning of period |  | $ | 137 |  |  | $ | 113 |  |
| Additions |  |  | 19 |  |  |  | 18 |  |
| Expense recognized during the period |  |  | (21 | ) |  |  | (15 | ) |
| Balance at end of period |  | $ | 135 |  |  | $ | 116 |  |

- added (2018-08-21):
[0001564590-18-022123:note_history:67]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Other current assets |  | $ | 64 |  |  | $ | 66 |  |
| Other non-current assets |  |  | 71 |  |  |  | 71 |  |
| Total deferred commissions |  | $ | 135 |  |  | $ | 137 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2018-08-21):
[0001564590-18-022123:note_history:68]
Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights.

- removed (2018-08-21):
[0001564590-18-002876:note_history:69]
Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights.
