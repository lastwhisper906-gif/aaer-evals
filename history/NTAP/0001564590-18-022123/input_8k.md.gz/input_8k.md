# NTAP 8-K — 0001564590-18-021828 filed 2018-08-15

## item codes, every 8-K on or before 2018-08-21

- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2018-08-21

- none on or before 2018-08-21

## item 2.02 — earnings release, exhibit 99.1

[0001564590-18-021828:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-18-021828:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-18-021828:8k_2_02:3]
Exhibit 99.1

[0001564590-18-021828:8k_2_02:4]
NetApp Reports First Quarter Fiscal Year 2019 Results

[0001564590-18-021828:8k_2_02:5]
Net Revenues of $1.47 Billion Grew 12% Year-over-Year

[0001564590-18-021828:8k_2_02:6]
| • | Product revenue grew 20% year-over-year |  |

[0001564590-18-021828:8k_2_02:7]
| • | All-flash array annualized net revenue run rate of $2.2 billion increased 50% year-over-year |  |

[0001564590-18-021828:8k_2_02:8]
| • | Free cash flow was 18% of revenue and increased 22% year-over-year |  |

[0001564590-18-021828:8k_2_02:9]
| • | $605 million returned to shareholders in share repurchases and cash dividends |  |

[0001564590-18-021828:8k_2_02:10]
Sunnyvale, Calif.—August 15, 2018—NetApp (NASDAQ: NTAP) today reported financial results for the first quarter of fiscal year 2019, which ended July 27, 2018.

[0001564590-18-021828:8k_2_02:11]
“We delivered a very strong first quarter with revenue, gross margin, operating margin, and earnings per share all above our guidance. In Q1, we introduced substantial innovation across our portfolio, expanding our industry-leading cloud data services and introducing new partnerships, products and solutions to help data-driven organizations thrive,” said George Kurian, chief executive officer. “Enterprises are signaling strong confidence in NetApp by making long-term investments to enable the NetAppTM Data Fabric across their entire enterprise.”

[0001564590-18-021828:8k_2_02:12]
First Quarter Fiscal Year 2019 Financial Results

[0001564590-18-021828:8k_2_02:13]
| • | Net Revenues: $1.47 billion, increased 12% year-over-year from $1.32 billion* in the first quarter of fiscal 2018 |  |

[0001564590-18-021828:8k_2_02:14]
| • | Net Income: GAAP net income of $283 million, compared to GAAP net income of $131 million* in the first quarter of fiscal 2018; non-GAAP net income1 of $281 million, compared to non-GAAP net income of $166 million* in the first quarter of fiscal 2018 |  |

[0001564590-18-021828:8k_2_02:15]
| • | Earnings per Share: GAAP earnings per share2 of $1.05 compared to GAAP earnings per share of $0.47* in the first quarter of fiscal 2018; non-GAAP earnings per share of $1.04, compared to non-GAAP earnings per share of $0.60* in the first quarter of fiscal 2018 |  |

[0001564590-18-021828:8k_2_02:16]
| • | Cash, Cash Equivalents and Investments: $4.8 billion at the end of the first quarter of fiscal 2019 |  |

[0001564590-18-021828:8k_2_02:17]
| • | Cash from Operations: $326 million, compared to $250 million in the first quarter of fiscal 2018 |  |

[0001564590-18-021828:8k_2_02:18]
| • | Share Repurchase and Dividend: Returned $605 million to shareholders through share repurchases and cash dividends |  |

[0001564590-18-021828:8k_2_02:19]
* In the first quarter of fiscal 2019, NetApp adopted Revenue from Contracts with Customers (ASC 606), a new accounting standard which establishes a comprehensive new revenue recognition model designed to depict the transfer of goods or services to a customer in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. The full retrospective method of adoption was employed. Accordingly, NetApp’s condensed consolidated balance sheet as of April 27, 2018, condensed consolidated statements of operations and cash flows for all prior periods presented, and all related financial statement metrics included herein, have been restated to conform to the new rules. The adoption of the standard had no impact to cash provided by or used in operating, investing or financing activities as presented on the condensed consolidated statement of cash flows.

[0001564590-18-021828:8k_2_02:20]
Second Quarter Fiscal Year 2019 Financial Outlook

[0001564590-18-021828:8k_2_02:21]
The Company provided the following financial guidance for the second quarter of fiscal year 2019:

[0001564590-18-021828:8k_2_02:22]
| • | Net revenues are expected to be in the range of $1.450 billion to $1.550 billion |  |

[0001564590-18-021828:8k_2_02:23]
|  | GAAP | Non-GAAP |
| •Earnings per share is expected to be in the range of: | $0.79-$0.85 | $0.94-$1.00 |

[0001564590-18-021828:8k_2_02:24]
Dividend

[0001564590-18-021828:8k_2_02:25]
Next cash dividend of $0.40 per share to be paid on October 24, 2018, to shareholders of record as of the close of business on October 5, 2018.

[0001564590-18-021828:8k_2_02:26]
First Quarter Fiscal Year 2019 Business Highlights

[0001564590-18-021828:8k_2_02:27]
NetApp Expands the Industry's Most Complete Cloud Data Services

[0001564590-18-021828:8k_2_02:28]
| - | Azure NetApp Files is now available in public preview. Jointly developed by Microsoft and NetApp, Azure NetApp Files is a native Azure service powered by NetApp’s leading ONTAP technology and storage expertise. |

[0001564590-18-021828:8k_2_02:29]
| - | NetApp announced NetApp Cloud Volumes Services for Google Cloud Platform offering customers a fully-managed, cloud-native file storage service that is integrated with Google Cloud Platform. |

[0001564590-18-021828:8k_2_02:30]
New Products and Solutions that will Help Data-Driven Organizations Thrive

[0001564590-18-021828:8k_2_02:31]
| - | NetApp introduced the AFF A800 array, a high performance, cloud-connected flash system to power artificial intelligence and compute-intensive applications. The NetApp AFF A800 is the first available end-to-end NVMe enterprise grade all flash array and boasts the industry’s first support of 30TB solid state drives. |

[0001564590-18-021828:8k_2_02:32]
| - | The latest update to our flagship NetApp ONTAPTM 9 software includes enhancements to FabricPool and improves hybrid cloud data tiering and adds support for Microsoft Azure. ONTAP will automatically move inactive data to a lower-cost storage tier to save money and bring data back when needed. |

[0001564590-18-021828:8k_2_02:33]
| - | NetApp Active IQTM technology provides new cloud-based analytics for all NetApp systems that predicts future performance needs and identifies unprotected data to optimize operations. |

[0001564590-18-021828:8k_2_02:34]
| - | NetApp StorageGRID object-based storage solution now provides superior next-generation, cloud-architected infrastructure for financial and personal data retention compliance as one integrated resource across public and private clouds. |

[0001564590-18-021828:8k_2_02:35]
Cisco and NetApp Simplify the Delivery of Cloud Infrastructure and Industry-Specific Applications

[0001564590-18-021828:8k_2_02:36]
| - | The new Managed Private Cloud solution built on FlexPodTM enables customers to realize a cloud-like, As-a-Service model for their on-premises IT with remote management, securing critical customer data and advancing cloud-capabilities for both partners and their customers. |

[0001564590-18-021828:8k_2_02:37]
| - | New FlexPod industry solutions provide a proven platform to quickly deploy key applications across industries that are challenged by the increasingly diverse, dynamic and distributed nature of data. The initial industry solution, FlexPod Datacenter for Epic HER, simplifies IT infrastructure for healthcare customers, helping them move faster and improve patient care. |

[0001564590-18-021828:8k_2_02:38]
Recognition for Industry Leading Products

[0001564590-18-021828:8k_2_02:39]
| - | NetApp all-flash array technology was recognized as a Leader in Gartner’s 2018 Magic Quadrant for Solid-State Arrays.3 NetApp has improved its position in the Leaders Quadrant with a higher rating for its ability to execute. |

[0001564590-18-021828:8k_2_02:40]
| - | NetApp StorageGRID named a Leader in IDC’s MarketScape for Object-Based Storage.4 IDC recognizes the strength of applying StorageGRID capabilities across our broader NetApp portfolio, and specifically praises a few capabilities in the report, including integration with NetApp FabricPool technology. |

[0001564590-18-021828:8k_2_02:41]
| - | According to a new Storage Performance Council SPC-1 Result,5 tests of the AFF A800 system places it as number 1 overall in terms of SPC-1 Response Time and makes it the top-performing enterprise all-flash array among the industry’s leading storage providers. The AFF A800 is also in the top 4 on the SPC-1 Performance list. The SPC-1 tests of the AFF A800 were conducted with compression and deduplication enabled, just as they would be under real-world conditions. |

[0001564590-18-021828:8k_2_02:42]
Webcast and Conference Call Information

[0001564590-18-021828:8k_2_02:43]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:00 p.m. Pacific Time today.

[0001564590-18-021828:8k_2_02:44]
About NetApp

[0001564590-18-021828:8k_2_02:45]
NetApp is the data authority for hybrid cloud. We provide a full range of hybrid cloud data services that simplify management of applications and data across cloud and on-premises environments to accelerate digital transformation. Together with our partners, we empower global organizations to unleash the full potential of their data to expand customer touchpoints, foster greater innovation, and optimize their operations. For more information, visit www.netapp.com. #DataDriven

[0001564590-18-021828:8k_2_02:46]
###

[0001564590-18-021828:8k_2_02:47]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-18-021828:8k_2_02:48]
Footnotes

[0001564590-18-021828:8k_2_02:49]
1Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale of properties, and (h) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-18-021828:8k_2_02:50]
2GAAP earnings per share and non-GAAP earnings per share are calculated using the diluted number of shares.

[0001564590-18-021828:8k_2_02:51]
3Leader in Gartner’s 2018 Magic Quadrant for Solid-State Arrays, Gartner Magic Quadrant for Solid-State Arrays, by Valdis Filks, John Monroe, Joseph Unsworth, Santhosh Rao, July 23, 2018

[0001564590-18-021828:8k_2_02:52]
4Leader in IDC’s MarketScape for Object-Based Storage, “IDC MarketScape: Worldwide Object-Based Storage 2016 Vendor Assessment,” by Amita Potnis, June 2018. IDC #US42665518

[0001564590-18-021828:8k_2_02:53]
5Storage Performance Council SPC-1 Result, http://spcresults.org/benchmarks/results/spc1-spc1e#A32007

[0001564590-18-021828:8k_2_02:54]
NetApp Usage of Non-GAAP Financial Information

[0001564590-18-021828:8k_2_02:55]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-18-021828:8k_2_02:56]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-18-021828:8k_2_02:57]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-18-021828:8k_2_02:58]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-18-021828:8k_2_02:59]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-18-021828:8k_2_02:60]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-18-021828:8k_2_02:61]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-18-021828:8k_2_02:62]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-18-021828:8k_2_02:63]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-18-021828:8k_2_02:64]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-18-021828:8k_2_02:65]
G. Gains/losses on the sale of properties. These are gains/losses from the sale of our properties. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-18-021828:8k_2_02:66]
H. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also

[0001564590-18-021828:8k_2_02:67]
excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual properties from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-18-021828:8k_2_02:68]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-18-021828:8k_2_02:69]
NETAPP, INC.

[0001564590-18-021828:8k_2_02:70]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-18-021828:8k_2_02:71]
(In millions)

[0001564590-18-021828:8k_2_02:72]
(Unaudited)

[0001564590-18-021828:8k_2_02:73]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,811 |  |  | $ | 5,391 |  |
| Accounts receivable |  |  | 616 |  |  |  | 1,047 |  |
| Inventories |  |  | 97 |  |  |  | 122 |  |
| Other current assets |  |  | 329 |  |  |  | 392 |  |
| Total current assets |  |  | 5,853 |  |  |  | 6,952 |  |
| Property and equipment, net |  |  | 768 |  |  |  | 756 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,820 |  |  |  | 1,833 |  |
| Other non-current assets |  |  | 464 |  |  |  | 450 |  |
| Total assets |  | $ | 8,905 |  |  | $ | 9,991 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 425 |  |  | $ | 609 |  |
| Accrued expenses |  |  | 592 |  |  |  | 825 |  |
| Commercial paper notes |  |  | 200 |  |  |  | 385 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,623 |  |  |  | 1,712 |  |
| Total current liabilities |  |  | 2,840 |  |  |  | 3,531 |  |
| Long-term debt |  |  | 1,542 |  |  |  | 1,541 |  |
| Other long-term liabilities |  |  | 964 |  |  |  | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,637 |  |  |  | 1,651 |  |
| Total liabilities |  |  | 6,983 |  |  |  | 7,715 |  |
| Stockholders' equity |  |  | 1,922 |  |  |  | 2,276 |  |
| Total liabilities and stockholders' equity |  | $ | 8,905 |  |  | $ | 9,991 |  |

[0001564590-18-021828:8k_2_02:74]
NETAPP, INC.

[0001564590-18-021828:8k_2_02:75]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-18-021828:8k_2_02:76]
(In millions, except per share amounts)

[0001564590-18-021828:8k_2_02:77]
(Unaudited)

[0001564590-18-021828:8k_2_02:78]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Product |  | $ | 875 |  |  | $ | 727 |  |
| Software maintenance |  |  | 229 |  |  |  | 223 |  |
| Hardware maintenance and other services |  |  | 370 |  |  |  | 371 |  |
| Net revenues |  |  | 1,474 |  |  |  | 1,321 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 398 |  |  |  | 376 |  |
| Cost of software maintenance |  |  | 7 |  |  |  | 7 |  |
| Cost of hardware maintenance and other services |  |  | 106 |  |  |  | 114 |  |
| Total cost of revenues |  |  | 511 |  |  |  | 497 |  |
| Gross profit |  |  | 963 |  |  |  | 824 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 409 |  |  |  | 423 |  |
| Research and development |  |  | 208 |  |  |  | 193 |  |
| General and administrative |  |  | 73 |  |  |  | 68 |  |
| Restructuring charges |  |  | 19 |  |  |  | — |  |
| Total operating expenses |  |  | 709 |  |  |  | 684 |  |
| Income from operations |  |  | 254 |  |  |  | 140 |  |
| Other income, net |  |  | 18 |  |  |  | 5 |  |
| Income before income taxes |  |  | 272 |  |  |  | 145 |  |
| Provision (benefit) for income taxes |  |  | (11 | ) |  |  | 14 |  |
| Net income |  | $ | 283 |  |  | $ | 131 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.08 |  |  | $ | 0.49 |  |
| Diluted |  | $ | 1.05 |  |  | $ | 0.47 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |
| Basic |  |  | 262 |  |  |  | 270 |  |
| Diluted |  |  | 269 |  |  |  | 278 |  |
| Cash dividends declared per share |  | $ | 0.40 |  |  | $ | 0.20 |  |

[0001564590-18-021828:8k_2_02:79]
NETAPP, INC.

[0001564590-18-021828:8k_2_02:80]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-18-021828:8k_2_02:81]
(In millions)

[0001564590-18-021828:8k_2_02:82]
(Unaudited)

[0001564590-18-021828:8k_2_02:83]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 283 |  |  | $ | 131 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 49 |  |  |  | 51 |  |
| Stock-based compensation |  |  | 40 |  |  |  | 48 |  |
| Deferred income taxes |  |  | (26 | ) |  |  | — |  |
| Other items, net |  |  | 8 |  |  |  | 5 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 423 |  |  |  | 226 |  |
| Inventories |  |  | 25 |  |  |  | 24 |  |
| Accounts payable |  |  | (177 | ) |  |  | (58 | ) |
| Accrued expenses |  |  | (221 | ) |  |  | (135 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (87 | ) |  |  | (102 | ) |
| Long-term taxes payable |  |  | 5 |  |  |  | — |  |
| Changes in other operating assets and liabilities, net |  |  | 4 |  |  |  | 60 |  |
| Net cash provided by operating activities |  |  | 326 |  |  |  | 250 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 248 |  |  |  | 112 |  |
| Purchases of property and equipment |  |  | (64 | ) |  |  | (36 | ) |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | (24 | ) |
| Other investing activities, net |  |  | 2 |  |  |  | 1 |  |
| Net cash provided by investing activities |  |  | 186 |  |  |  | 53 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 63 |  |  |  | 48 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (84 | ) |  |  | (57 | ) |
| Repurchase of common stock |  |  | (500 | ) |  |  | (150 | ) |
| Proceeds from (repayments of) commercial paper notes, net |  |  | (185 | ) |  |  | 394 |  |
| Dividends paid |  |  | (105 | ) |  |  | (54 | ) |
| Other financing activities, net |  |  | (1 | ) |  |  | — |  |
| Net cash provided by (used in) financing activities |  |  | (812 | ) |  |  | 181 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (14 | ) |  |  | 19 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | (314 | ) |  |  | 503 |  |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,947 |  |  |  | 2,450 |  |
| End of period |  | $ | 2,633 |  |  | $ | 2,953 |  |

[0001564590-18-021828:8k_2_02:84]
SELECTED CONDENSED CONSOLIDATED BALANCE SHEET LINE ITEMS

[0001564590-18-021828:8k_2_02:85]
(In millions)

[0001564590-18-021828:8k_2_02:86]
(Unaudited)

[0001564590-18-021828:8k_2_02:87]
|  |  | As of April 27, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  |  | As Adjusted |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 1,009 |  |  | $ | 38 |  |  | $ | 1,047 |  |
| Inventories |  |  | 126 |  |  |  | (4 | ) |  |  | 122 |  |
| Other current assets |  |  | 330 |  |  |  | 62 |  |  |  | 392 |  |
| Other non-current assets |  |  | 420 |  |  |  | 30 |  |  |  | 450 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |
| Short-term deferred revenue and financed unearned services revenue |  | $ | 1,804 |  |  | $ | (92 | ) |  | $ | 1,712 |  |
| Other long-term liabilities |  |  | 961 |  |  |  | 31 |  |  |  | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,673 |  |  |  | (22 | ) |  |  | 1,651 |  |
| Total stockholders' equity |  |  | 2,067 |  |  |  | 209 |  |  |  | 2,276 |  |

[0001564590-18-021828:8k_2_02:88]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended July 28, 2017 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  |  | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 723 |  |  | $ | 4 |  |  | $ | 727 |  |
| Software maintenance |  |  | 234 |  |  |  | (11 | ) |  |  | 223 |  |
| Hardware maintenance and other services |  |  | 368 |  |  |  | 3 |  |  |  | 371 |  |
| Net revenues |  |  | 1,325 |  |  |  | (4 | ) |  |  | 1,321 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 371 |  |  |  | 5 |  |  |  | 376 |  |
| Cost of software maintenance |  |  | 7 |  |  |  | — |  |  |  | 7 |  |
| Cost of hardware maintenance and other services |  |  | 113 |  |  |  | 1 |  |  |  | 114 |  |
| Total cost of revenues |  |  | 491 |  |  |  | 6 |  |  |  | 497 |  |
| Gross profit |  |  | 834 |  |  |  | (10 | ) |  |  | 824 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 425 |  |  |  | (2 | ) |  |  | 423 |  |
| Research and development |  |  | 193 |  |  |  | — |  |  |  | 193 |  |
| General and administrative |  |  | 68 |  |  |  | — |  |  |  | 68 |  |
| Total operating expenses |  |  | 686 |  |  |  | (2 | ) |  |  | 684 |  |
| Income from operations |  |  | 148 |  |  |  | (8 | ) |  |  | 140 |  |
| Other income, net |  |  | 5 |  |  |  | — |  |  |  | 5 |  |
| Income before income taxes |  |  | 153 |  |  |  | (8 | ) |  |  | 145 |  |
| Provision for income taxes |  |  | 17 |  |  |  | (3 | ) |  |  | 14 |  |
| Net income |  | $ | 136 |  |  | $ | (5 | ) |  | $ | 131 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.50 |  |  | $ | (0.01 | ) |  | $ | 0.49 |  |
| Diluted |  | $ | 0.49 |  |  | $ | (0.02 | ) |  | $ | 0.47 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 270 |  |  |  | 270 |  |  |  | 270 |  |
| Diluted |  |  | 278 |  |  |  | 278 |  |  |  | 278 |  |

[0001564590-18-021828:8k_2_02:89]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended October 27, 2017 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  |  | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 807 |  |  | $ | 12 |  |  | $ | 819 |  |
| Software maintenance |  |  | 240 |  |  |  | (16 | ) |  |  | 224 |  |
| Hardware maintenance and other services |  |  | 375 |  |  |  | (3 | ) |  |  | 372 |  |
| Net revenues |  |  | 1,422 |  |  |  | (7 | ) |  |  | 1,415 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 399 |  |  |  | (2 | ) |  |  | 397 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | — |  |  |  | 6 |  |
| Cost of hardware maintenance and other services |  |  | 115 |  |  |  | (3 | ) |  |  | 112 |  |
| Total cost of revenues |  |  | 520 |  |  |  | (5 | ) |  |  | 515 |  |
| Gross profit |  |  | 902 |  |  |  | (2 | ) |  |  | 900 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 420 |  |  |  | 1 |  |  |  | 421 |  |
| Research and development |  |  | 194 |  |  |  | — |  |  |  | 194 |  |
| General and administrative |  |  | 69 |  |  |  | — |  |  |  | 69 |  |
| Total operating expenses |  |  | 683 |  |  |  | 1 |  |  |  | 684 |  |
| Income from operations |  |  | 219 |  |  |  | (3 | ) |  |  | 216 |  |
| Other income, net |  |  | 6 |  |  |  | — |  |  |  | 6 |  |
| Income before income taxes |  |  | 225 |  |  |  | (3 | ) |  |  | 222 |  |
| Provision for income taxes |  |  | 50 |  |  |  | (2 | ) |  |  | 48 |  |
| Net income |  | $ | 175 |  |  | $ | (1 | ) |  | $ | 174 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.65 |  |  | $ | — |  |  | $ | 0.65 |  |
| Diluted |  | $ | 0.64 |  |  | $ | (0.01 | ) |  | $ | 0.63 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 269 |  |  |  | 269 |  |  |  | 269 |  |
| Diluted |  |  | 275 |  |  |  | 275 |  |  |  | 275 |  |

[0001564590-18-021828:8k_2_02:90]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended January 26, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  |  | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 920 |  |  | $ | 32 |  |  | $ | 952 |  |
| Software maintenance |  |  | 237 |  |  |  | (16 | ) |  |  | 221 |  |
| Hardware maintenance and other services |  |  | 366 |  |  |  | — |  |  |  | 366 |  |
| Net revenues |  |  | 1,523 |  |  |  | 16 |  |  |  | 1,539 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 468 |  |  |  | 1 |  |  |  | 469 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | — |  |  |  | 6 |  |
| Cost of hardware maintenance and other services |  |  | 108 |  |  |  | — |  |  |  | 108 |  |
| Total cost of revenues |  |  | 582 |  |  |  | 1 |  |  |  | 583 |  |
| Gross profit |  |  | 941 |  |  |  | 15 |  |  |  | 956 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 423 |  |  |  | (4 | ) |  |  | 419 |  |
| Research and development |  |  | 193 |  |  |  | — |  |  |  | 193 |  |
| General and administrative |  |  | 72 |  |  |  | — |  |  |  | 72 |  |
| Gain on sale of properties |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |
| Total operating expenses |  |  | 470 |  |  |  | (4 | ) |  |  | 466 |  |
| Income from operations |  |  | 471 |  |  |  | 19 |  |  |  | 490 |  |
| Other income, net |  |  | 14 |  |  |  | — |  |  |  | 14 |  |
| Income before income taxes |  |  | 485 |  |  |  | 19 |  |  |  | 504 |  |
| Provision for income taxes |  |  | 991 |  |  |  | (8 | ) |  |  | 983 |  |
| Net loss |  | $ | (506 | ) |  | $ | 27 |  |  | $ | (479 | ) |
| Net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (1.89 | ) |  | $ | 0.10 |  |  | $ | (1.79 | ) |
| Diluted |  | $ | (1.89 | ) |  | $ | 0.10 |  |  | $ | (1.79 | ) |
| Shares used in net loss per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 268 |  |  |  | 268 |  |  |  | 268 |  |
| Diluted |  |  | 268 |  |  |  | 268 |  |  |  | 268 |  |

[0001564590-18-021828:8k_2_02:91]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended April 27, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  |  | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,011 |  |  | $ | 16 |  |  | $ | 1,027 |  |
| Software maintenance |  |  | 247 |  |  |  | (13 | ) |  |  | 234 |  |
| Hardware maintenance and other services |  |  | 383 |  |  |  | — |  |  |  | 383 |  |
| Net revenues |  |  | 1,641 |  |  |  | 3 |  |  |  | 1,644 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 500 |  |  |  | (4 | ) |  |  | 496 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | — |  |  |  | 6 |  |
| Cost of hardware maintenance and other services |  |  | 113 |  |  |  | — |  |  |  | 113 |  |
| Total cost of revenues |  |  | 619 |  |  |  | (4 | ) |  |  | 615 |  |
| Gross profit |  |  | 1,022 |  |  |  | 7 |  |  |  | 1,029 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 461 |  |  |  | (18 | ) |  |  | 443 |  |
| Research and development |  |  | 203 |  |  |  | — |  |  |  | 203 |  |
| General and administrative |  |  | 71 |  |  |  | — |  |  |  | 71 |  |
| Total operating expenses |  |  | 735 |  |  |  | (18 | ) |  |  | 717 |  |
| Income from operations |  |  | 287 |  |  |  | 25 |  |  |  | 312 |  |
| Other income, net |  |  | 16 |  |  |  | — |  |  |  | 16 |  |
| Income before income taxes |  |  | 303 |  |  |  | 25 |  |  |  | 328 |  |
| Provision for income taxes |  |  | 32 |  |  |  | 6 |  |  |  | 38 |  |
| Net income |  | $ | 271 |  |  | $ | 19 |  |  | $ | 290 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.02 |  |  | $ | 0.07 |  |  | $ | 1.09 |  |
| Diluted |  | $ | 0.99 |  |  | $ | 0.07 |  |  | $ | 1.06 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 265 |  |  |  | 265 |  |  |  | 265 |  |
| Diluted |  |  | 273 |  |  |  | 273 |  |  |  | 273 |  |

[0001564590-18-021828:8k_2_02:92]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Year Ended April 27, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  |  | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,461 |  |  | $ | 64 |  |  | $ | 3,525 |  |
| Software maintenance |  |  | 958 |  |  |  | (56 | ) |  |  | 902 |  |
| Hardware maintenance and other services |  |  | 1,492 |  |  |  | — |  |  |  | 1,492 |  |
| Net revenues |  |  | 5,911 |  |  |  | 8 |  |  |  | 5,919 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 1,738 |  |  |  | — |  |  |  | 1,738 |  |
| Cost of software maintenance |  |  | 25 |  |  |  | — |  |  |  | 25 |  |
| Cost of hardware maintenance and other services |  |  | 449 |  |  |  | (2 | ) |  |  | 447 |  |
| Total cost of revenues |  |  | 2,212 |  |  |  | (2 | ) |  |  | 2,210 |  |
| Gross profit |  |  | 3,699 |  |  |  | 10 |  |  |  | 3,709 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 1,729 |  |  |  | (23 | ) |  |  | 1,706 |  |
| Research and development |  |  | 783 |  |  |  | — |  |  |  | 783 |  |
| General and administrative |  |  | 280 |  |  |  | — |  |  |  | 280 |  |
| Gain on sale of properties |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |
| Total operating expenses |  |  | 2,574 |  |  |  | (23 | ) |  |  | 2,551 |  |
| Income from operations |  |  | 1,125 |  |  |  | 33 |  |  |  | 1,158 |  |
| Other income (expense), net |  |  | 41 |  |  |  | — |  |  |  | 41 |  |
| Income before income taxes |  |  | 1,166 |  |  |  | 33 |  |  |  | 1,199 |  |
| Provision for income taxes |  |  | 1,090 |  |  |  | (7 | ) |  |  | 1,083 |  |
| Net income |  | $ | 76 |  |  | $ | 40 |  |  | $ | 116 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.28 |  |  | $ | 0.15 |  |  | $ | 0.43 |  |
| Diluted |  | $ | 0.28 |  |  | $ | 0.14 |  |  | $ | 0.42 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 268 |  |  |  | 268 |  |  |  | 268 |  |
| Diluted |  |  | 276 |  |  |  | 276 |  |  |  | 276 |  |

[0001564590-18-021828:8k_2_02:93]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Year Ended April 28, 2017 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  |  | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,006 |  |  | $ | 54 |  |  | $ | 3,060 |  |
| Software maintenance |  |  | 965 |  |  |  | (60 | ) |  |  | 905 |  |
| Hardware maintenance and other services |  |  | 1,548 |  |  |  | (22 | ) |  |  | 1,526 |  |
| Net revenues |  |  | 5,519 |  |  |  | (28 | ) |  |  | 5,491 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 1,614 |  |  |  | (2 | ) |  |  | 1,612 |  |
| Cost of software maintenance |  |  | 28 |  |  |  | — |  |  |  | 28 |  |
| Cost of hardware maintenance and other services |  |  | 487 |  |  |  | — |  |  |  | 487 |  |
| Total cost of revenues |  |  | 2,129 |  |  |  | (2 | ) |  |  | 2,127 |  |
| Gross profit |  |  | 3,390 |  |  |  | (26 | ) |  |  | 3,364 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 1,633 |  |  |  | 18 |  |  |  | 1,651 |  |
| Research and development |  |  | 779 |  |  |  | — |  |  |  | 779 |  |
| General and administrative |  |  | 271 |  |  |  | — |  |  |  | 271 |  |
| Restructuring charges |  |  | 52 |  |  |  | — |  |  |  | 52 |  |
| Gain on sale of properties |  |  | (10 | ) |  |  | — |  |  |  | (10 | ) |
| Total operating expenses |  |  | 2,725 |  |  |  | 18 |  |  |  | 2,743 |  |
| Income from operations |  |  | 665 |  |  |  | (44 | ) |  |  | 621 |  |
| Other income (expense), net |  |  | — |  |  |  | — |  |  |  | — |  |
| Income before income taxes |  |  | 665 |  |  |  | (44 | ) |  |  | 621 |  |
| Provision for income taxes |  |  | 156 |  |  |  | (16 | ) |  |  | 140 |  |
| Net income |  | $ | 509 |  |  | $ | (28 | ) |  | $ | 481 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.85 |  |  | $ | (0.10 | ) |  | $ | 1.75 |  |
| Diluted |  | $ | 1.81 |  |  | $ | (0.10 | ) |  | $ | 1.71 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 275 |  |  |  | 275 |  |  |  | 275 |  |
| Diluted |  |  | 281 |  |  |  | 281 |  |  |  | 281 |  |

[0001564590-18-021828:8k_2_02:94]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q1 FY'19 |  |  | Q4 FY'18 |  |  | Q3 FY'18 |  |  | Q2 FY'18 |  |  | Q1 FY'18 |  |  | FY 2018 |  |  | FY 2017 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 875 |  |  | $ | 1,027 |  |  | $ | 952 |  |  | $ | 819 |  |  | $ | 727 |  |  | $ | 3,525 |  |  | $ | 3,060 |  |
| Strategic |  | $ | 612 |  |  | $ | 747 |  |  | $ | 657 |  |  | $ | 566 |  |  | $ | 498 |  |  | $ | 2,468 |  |  | $ | 2,000 |  |
| Mature |  | $ | 263 |  |  | $ | 280 |  |  | $ | 295 |  |  | $ | 253 |  |  | $ | 229 |  |  | $ | 1,057 |  |  | $ | 1,060 |  |
| Software Maintenance |  | $ | 229 |  |  | $ | 234 |  |  | $ | 221 |  |  | $ | 224 |  |  | $ | 223 |  |  | $ | 902 |  |  | $ | 905 |  |
| Hardware Maintenance and Other Services |  | $ | 370 |  |  | $ | 383 |  |  | $ | 366 |  |  | $ | 372 |  |  | $ | 371 |  |  | $ | 1,492 |  |  | $ | 1,526 |  |
| Hardware Maintenance Support Contracts |  | $ | 303 |  |  | $ | 310 |  |  | $ | 300 |  |  | $ | 306 |  |  | $ | 298 |  |  | $ | 1,214 |  |  | $ | 1,258 |  |
| Professional and Other Services |  | $ | 67 |  |  | $ | 73 |  |  | $ | 66 |  |  | $ | 66 |  |  | $ | 73 |  |  | $ | 278 |  |  | $ | 268 |  |
| Net Revenues |  | $ | 1,474 |  |  | $ | 1,644 |  |  | $ | 1,539 |  |  | $ | 1,415 |  |  | $ | 1,321 |  |  | $ | 5,919 |  |  | $ | 5,491 |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'19 Revenue |  |  | % of Q4 FY'18 Revenue |  |  | % of Q3 FY'18 Revenue |  |  | % of Q2 FY'18 Revenue |  |  | % of Q1 FY'18 Revenue |  |  | % of FY 2018 Revenue |  |  | % of FY 2017 Revenue |  |
| Americas |  |  | 57 | % |  |  | 54 | % |  |  | 53 | % |  |  | 56 | % |  |  | 55 | % |  |  | 54 | % |  |  | 55 | % |
| Americas Commercial |  |  | 46 | % |  |  | 42 | % |  |  | 43 | % |  |  | 40 | % |  |  | 42 | % |  |  | 41 | % |  |  | 42 | % |
| U.S. Public Sector |  |  | 11 | % |  |  | 12 | % |  |  | 10 | % |  |  | 16 | % |  |  | 13 | % |  |  | 13 | % |  |  | 13 | % |
| EMEA |  |  | 29 | % |  |  | 33 | % |  |  | 33 | % |  |  | 30 | % |  |  | 30 | % |  |  | 32 | % |  |  | 32 | % |
| Asia Pacific |  |  | 14 | % |  |  | 13 | % |  |  | 14 | % |  |  | 14 | % |  |  | 15 | % |  |  | 14 | % |  |  | 13 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'19 Revenue |  |  | % of Q4 FY'18 Revenue |  |  | % of Q3 FY'18 Revenue |  |  | % of Q2 FY'18 Revenue |  |  | % of Q1 FY'18 Revenue |  |  | % of FY 2018 Revenue |  |  | % of FY 2017 Revenue |  |
| Direct |  |  | 29 | % |  |  | 21 | % |  |  | 22 | % |  |  | 22 | % |  |  | 20 | % |  |  | 21 | % |  |  | 22 | % |
| Indirect |  |  | 71 | % |  |  | 79 | % |  |  | 78 | % |  |  | 78 | % |  |  | 80 | % |  |  | 79 | % |  |  | 78 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'19 |  |  | Q4 FY'18 |  |  | Q3 FY'18 |  |  | Q2 FY'18 |  |  | Q1 FY'18 |  |  | FY 2018 |  |  | FY 2017 |  |
| Non-GAAP Gross Margin |  |  | 66.2 | % |  |  | 63.3 | % |  |  | 63.0 | % |  |  | 64.5 | % |  |  | 63.3 | % |  |  | 63.5 | % |  |  | 62.1 | % |
| Product |  |  | 55.7 | % |  |  | 52.7 | % |  |  | 51.8 | % |  |  | 52.7 | % |  |  | 49.5 | % |  |  | 51.8 | % |  |  | 48.4 | % |
| Software Maintenance |  |  | 96.9 | % |  |  | 97.4 | % |  |  | 97.3 | % |  |  | 97.3 | % |  |  | 96.9 | % |  |  | 97.2 | % |  |  | 96.9 | % |
| Hardware Maintenance and Other Services |  |  | 72.2 | % |  |  | 71.0 | % |  |  | 71.3 | % |  |  | 70.4 | % |  |  | 70.1 | % |  |  | 70.7 | % |  |  | 68.9 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'19 |  |  | Q4 FY'18 |  |  | Q3 FY'18 |  |  | Q2 FY'18 |  |  | Q1 FY'18 |  |  | FY 2018 |  |  | FY 2017 |  |
| Non-GAAP Income from Operations |  | $ | 326 |  |  | $ | 360 |  |  | $ | 329 |  |  | $ | 269 |  |  | $ | 201 |  |  | $ | 1,159 |  |  | $ | 906 |  |
| % of Net Revenues |  |  | 22.1 | % |  |  | 21.9 | % |  |  | 21.4 | % |  |  | 19.0 | % |  |  | 15.2 | % |  |  | 19.6 | % |  |  | 16.5 | % |
| Non-GAAP Income before Income Taxes |  | $ | 344 |  |  | $ | 376 |  |  | $ | 343 |  |  | $ | 275 |  |  | $ | 206 |  |  | $ | 1,200 |  |  | $ | 906 |  |
| Non-GAAP Effective Tax Rate |  |  | 18.3 | % |  |  | 18.4 | % |  |  | 15.7 | % |  |  | 19.6 | % |  |  | 19.4 | % |  |  | 18.1 | % |  |  | 18.4 | % |

[0001564590-18-021828:8k_2_02:95]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'19 |  |  | Q4 FY'18 |  |  | Q3 FY'18 |  |  | Q2 FY'18 |  |  | Q1 FY'18 |  |  | FY 2018 |  |  | FY 2017 |  |
| Non-GAAP Net Income |  | $ | 281 |  |  | $ | 307 |  |  | $ | 289 |  |  | $ | 221 |  |  | $ | 166 |  |  | $ | 983 |  |  | $ | 739 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 269 |  |  |  | 273 |  |  |  | 276 |  |  |  | 275 |  |  |  | 278 |  |  |  | 276 |  |  |  | 281 |  |
| Non-GAAP Income per Share, Diluted |  | $ | 1.04 |  |  | $ | 1.12 |  |  | $ | 1.05 |  |  | $ | 0.80 |  |  | $ | 0.60 |  |  | $ | 3.56 |  |  | $ | 2.63 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'19 |  |  | Q4 FY'18 |  |  | Q3 FY'18 |  |  | Q2 FY'18 |  |  | Q1 FY'18 |  |  |  |  |  |  |  |  |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,260 |  |  | $ | 3,363 |  |  | $ | 3,143 |  |  | $ | 3,059 |  |  | $ | 3,127 |  |  |  |  |  |  |  |  |  |
| DSO (days) |  |  | 38 |  |  |  | 58 |  |  |  | 46 |  |  |  | 39 |  |  |  | 37 |  |  |  |  |  |  |  |  |  |
| DIO (days) |  |  | 17 |  |  |  | 18 |  |  |  | 14 |  |  |  | 18 |  |  |  | 25 |  |  |  |  |  |  |  |  |  |
| DPO (days) |  |  | 76 |  |  |  | 90 |  |  |  | 71 |  |  |  | 67 |  |  |  | 53 |  |  |  |  |  |  |  |  |  |
| CCC (days) |  |  | (20 | ) |  |  | (14 | ) |  |  | (12 | ) |  |  | (10 | ) |  |  | 8 |  |  |  |  |  |  |  |  |  |
| Inventory Turns |  |  | 21 |  |  |  | 20 |  |  |  | 26 |  |  |  | 21 |  |  |  | 15 |  |  |  |  |  |  |  |  |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |  |  |  |  |  |  |  |  |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |  |  |  |  |  |  |  |  |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |  |  |  |  |  |  |  |  |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |  |  |  |  |  |  |  |  |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'19 |  |  | Q4 FY'18 |  |  | Q3 FY'18 |  |  | Q2 FY'18 |  |  | Q1 FY'18 |  |  | FY 2018 |  |  | FY 2017 |  |
| Net Cash Provided by Operating Activities |  | $ | 326 |  |  | $ | 494 |  |  | $ | 420 |  |  | $ | 314 |  |  | $ | 250 |  |  | $ | 1,478 |  |  | $ | 986 |  |
| Purchases of Property and Equipment |  | $ | 64 |  |  | $ | 48 |  |  | $ | 32 |  |  | $ | 29 |  |  | $ | 36 |  |  | $ | 145 |  |  | $ | 175 |  |
| Free Cash Flow |  | $ | 262 |  |  | $ | 446 |  |  | $ | 388 |  |  | $ | 285 |  |  | $ | 214 |  |  | $ | 1,333 |  |  | $ | 811 |  |
| Free Cash Flow as a % of Net Revenues |  |  | 17.8 | % |  |  | 27.1 | % |  |  | 25.2 | % |  |  | 20.1 | % |  |  | 16.2 | % |  |  | 22.5 | % |  |  | 14.8 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |

[0001564590-18-021828:8k_2_02:96]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income (loss) per share amounts) |  |
|  |  | Q1'FY19 |  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | FY2018 |  |  | FY2017 |  |
| NET INCOME (LOSS) |  | $ | 283 |  |  | $ | 290 |  |  | $ | (479 | ) |  | $ | 174 |  |  |  | 131 |  |  | $ | 116 |  |  | $ | 481 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 12 |  |  |  | 14 |  |  |  | 14 |  |  |  | 13 |  |  |  | 53 |  |  |  | 48 |  |
| Stock-based compensation |  |  | 40 |  |  |  | 36 |  |  |  | 38 |  |  |  | 39 |  |  |  | 48 |  |  |  | 161 |  |  |  | 195 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | — |  |
| Restructuring charges |  |  | 19 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 52 |  |
| Gain on sale of properties |  |  | — |  |  |  | — |  |  |  | (218 | ) |  |  | — |  |  |  | — |  |  |  | (218 | ) |  |  | (10 | ) |
| Income tax effects |  |  | (40 | ) |  |  | (31 | ) |  |  | 73 |  |  |  | (6 | ) |  |  | (26 | ) |  |  | 10 |  |  |  | (27 | ) |
| Income tax benefit of ASC 606 adoption |  |  | (34 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Tax reform |  |  | — |  |  |  | — |  |  |  | 856 |  |  |  | — |  |  |  | — |  |  |  | 856 |  |  |  | — |  |
| NON-GAAP NET INCOME |  | $ | 281 |  |  | $ | 307 |  |  | $ | 289 |  |  | $ | 221 |  |  | $ | 166 |  |  | $ | 983 |  |  | $ | 739 |  |
| COST OF REVENUES |  | $ | 511 |  |  | $ | 615 |  |  | $ | 583 |  |  | $ | 515 |  |  | $ | 497 |  |  | $ | 2,210 |  |  | $ | 2,127 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (9 | ) |  |  | (10 | ) |  |  | (9 | ) |  |  | (8 | ) |  |  | (36 | ) |  |  | (29 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (3 | ) |  |  | (3 | ) |  |  | (3 | ) |  |  | (4 | ) |  |  | (13 | ) |  |  | (17 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 498 |  |  | $ | 603 |  |  | $ | 570 |  |  | $ | 503 |  |  | $ | 485 |  |  | $ | 2,161 |  |  | $ | 2,081 |  |
| COST OF PRODUCT REVENUES |  | $ | 398 |  |  | $ | 496 |  |  | $ | 469 |  |  | $ | 397 |  |  | $ | 376 |  |  | $ | 1,738 |  |  | $ | 1,612 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (9 | ) |  |  | (10 | ) |  |  | (9 | ) |  |  | (8 | ) |  |  | (36 | ) |  |  | (29 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |  |  | (3 | ) |  |  | (4 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 388 |  |  | $ | 486 |  |  | $ | 459 |  |  | $ | 387 |  |  | $ | 367 |  |  | $ | 1,699 |  |  | $ | 1,579 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 106 |  |  | $ | 113 |  |  | $ | 108 |  |  | $ | 112 |  |  | $ | 114 |  |  | $ | 447 |  |  | $ | 487 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (2 | ) |  |  | (3 | ) |  |  | (2 | ) |  |  | (3 | ) |  |  | (10 | ) |  |  | (13 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 103 |  |  | $ | 111 |  |  | $ | 105 |  |  | $ | 110 |  |  | $ | 111 |  |  | $ | 437 |  |  | $ | 474 |  |
| GROSS PROFIT |  | $ | 963 |  |  | $ | 1,029 |  |  | $ | 956 |  |  | $ | 900 |  |  | $ | 824 |  |  | $ | 3,709 |  |  | $ | 3,364 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 9 |  |  |  | 10 |  |  |  | 9 |  |  |  | 8 |  |  |  | 36 |  |  |  | 29 |  |
| Stock-based compensation |  |  | 4 |  |  |  | 3 |  |  |  | 3 |  |  |  | 3 |  |  |  | 4 |  |  |  | 13 |  |  |  | 17 |  |
| NON-GAAP GROSS PROFIT |  | $ | 976 |  |  | $ | 1,041 |  |  | $ | 969 |  |  | $ | 912 |  |  | $ | 836 |  |  | $ | 3,758 |  |  | $ | 3,410 |  |

[0001564590-18-021828:8k_2_02:97]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income (loss) per share amounts) |  |
|  |  | Q1'FY19 |  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | FY2018 |  |  | FY2017 |  |
| SALES AND MARKETING EXPENSES |  | $ | 409 |  |  | $ | 443 |  |  | $ | 419 |  |  | $ | 421 |  |  | $ | 423 |  |  | $ | 1,706 |  |  | $ | 1,651 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (4 | ) |  |  | (3 | ) |  |  | (4 | ) |  |  | (5 | ) |  |  | (5 | ) |  |  | (17 | ) |  |  | (19 | ) |
| Stock-based compensation |  |  | (17 | ) |  |  | (15 | ) |  |  | (16 | ) |  |  | (16 | ) |  |  | (21 | ) |  |  | (68 | ) |  |  | (84 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 388 |  |  | $ | 425 |  |  | $ | 399 |  |  | $ | 400 |  |  | $ | 397 |  |  | $ | 1,621 |  |  | $ | 1,548 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 208 |  |  | $ | 203 |  |  | $ | 193 |  |  | $ | 194 |  |  | $ | 193 |  |  | $ | 783 |  |  | $ | 779 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (12 | ) |  |  | (11 | ) |  |  | (11 | ) |  |  | (12 | ) |  |  | (15 | ) |  |  | (49 | ) |  |  | (59 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 196 |  |  | $ | 192 |  |  | $ | 182 |  |  | $ | 182 |  |  | $ | 178 |  |  | $ | 734 |  |  | $ | 720 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 73 |  |  | $ | 71 |  |  | $ | 72 |  |  | $ | 69 |  |  | $ | 68 |  |  | $ | 280 |  |  | $ | 271 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (7 | ) |  |  | (7 | ) |  |  | (8 | ) |  |  | (8 | ) |  |  | (8 | ) |  |  | (31 | ) |  |  | (35 | ) |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | (5 | ) |  |  | — |  |  |  | — |  |  |  | (5 | ) |  |  | — |  |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 66 |  |  | $ | 64 |  |  | $ | 59 |  |  | $ | 61 |  |  | $ | 60 |  |  | $ | 244 |  |  | $ | 236 |  |
| RESTRUCTURING CHARGES |  | $ | 19 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 52 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (19 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (52 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| GAIN ON SALE OF PROPERTIES |  | $ | — |  |  | $ | — |  |  | $ | (218 | ) |  | $ | — |  |  | $ | — |  |  | $ | (218 | ) |  | $ | (10 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale of properties |  |  | — |  |  |  | — |  |  |  | 218 |  |  |  | — |  |  |  | — |  |  |  | 218 |  |  |  | 10 |  |
| NON-GAAP GAIN ON SALE OF PROPERTIES |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 709 |  |  | $ | 717 |  |  | $ | 466 |  |  | $ | 684 |  |  | $ | 684 |  |  | $ | 2,551 |  |  | $ | 2,743 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (4 | ) |  |  | (3 | ) |  |  | (4 | ) |  |  | (5 | ) |  |  | (5 | ) |  |  | (17 | ) |  |  | (19 | ) |
| Stock-based compensation |  |  | (36 | ) |  |  | (33 | ) |  |  | (35 | ) |  |  | (36 | ) |  |  | (44 | ) |  |  | (148 | ) |  |  | (178 | ) |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | (5 | ) |  |  | — |  |  |  | — |  |  |  | (5 | ) |  |  | — |  |
| Restructuring charges |  |  | (19 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (52 | ) |
| Gain on sale of properties |  |  | — |  |  |  | — |  |  |  | 218 |  |  |  | — |  |  |  | — |  |  |  | 218 |  |  |  | 10 |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 650 |  |  | $ | 681 |  |  | $ | 640 |  |  | $ | 643 |  |  | $ | 635 |  |  | $ | 2,599 |  |  | $ | 2,504 |  |

[0001564590-18-021828:8k_2_02:98]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income (loss) per share amounts) |  |
|  |  | Q1'FY19 |  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | FY2018 |  |  | FY2017 |  |
| INCOME FROM OPERATIONS |  | $ | 254 |  |  | $ | 312 |  |  | $ | 490 |  |  | $ | 216 |  |  | $ | 140 |  |  | $ | 1,158 |  |  | $ | 621 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 12 |  |  |  | 14 |  |  |  | 14 |  |  |  | 13 |  |  |  | 53 |  |  |  | 48 |  |
| Stock-based compensation |  |  | 40 |  |  |  | 36 |  |  |  | 38 |  |  |  | 39 |  |  |  | 48 |  |  |  | 161 |  |  |  | 195 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | — |  |
| Restructuring charges |  |  | 19 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 52 |  |
| Gain on sale of properties |  |  | — |  |  |  | — |  |  |  | (218 | ) |  |  | — |  |  |  | — |  |  |  | (218 | ) |  |  | (10 | ) |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 326 |  |  | $ | 360 |  |  | $ | 329 |  |  | $ | 269 |  |  | $ | 201 |  |  | $ | 1,159 |  |  | $ | 906 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 272 |  |  | $ | 328 |  |  | $ | 504 |  |  | $ | 222 |  |  | $ | 145 |  |  | $ | 1,199 |  |  | $ | 621 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 12 |  |  |  | 14 |  |  |  | 14 |  |  |  | 13 |  |  |  | 53 |  |  |  | 48 |  |
| Stock-based compensation |  |  | 40 |  |  |  | 36 |  |  |  | 38 |  |  |  | 39 |  |  |  | 48 |  |  |  | 161 |  |  |  | 195 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | — |  |
| Restructuring charges |  |  | 19 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 52 |  |
| Gain on sale of properties |  |  | — |  |  |  | — |  |  |  | (218 | ) |  |  | — |  |  |  | — |  |  |  | (218 | ) |  |  | (10 | ) |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 344 |  |  | $ | 376 |  |  | $ | 343 |  |  | $ | 275 |  |  | $ | 206 |  |  | $ | 1,200 |  |  | $ | 906 |  |
| PROVISION FOR INCOME TAXES |  | $ | (11 | ) |  | $ | 38 |  |  | $ | 983 |  |  | $ | 48 |  |  | $ | 14 |  |  | $ | 1,083 |  |  | $ | 140 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 40 |  |  |  | 31 |  |  |  | (73 | ) |  |  | 6 |  |  |  | 26 |  |  |  | (10 | ) |  |  | 27 |  |
| Income tax benefit of ASC 606 adoption |  |  | 34 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Tax reform |  |  | — |  |  |  | — |  |  |  | (856 | ) |  |  | — |  |  |  | — |  |  |  | (856 | ) |  |  | — |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 63 |  |  | $ | 69 |  |  | $ | 54 |  |  | $ | 54 |  |  | $ | 40 |  |  | $ | 217 |  |  | $ | 167 |  |
| NET INCOME (LOSS) PER SHARE |  | $ | 1.05 |  |  | $ | 1.06 |  |  | $ | (1.79 | ) |  | $ | 0.63 |  |  | $ | 0.47 |  |  | $ | 0.42 |  |  | $ | 1.71 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  |  | 0.04 |  |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.19 |  |  |  | 0.17 |  |
| Stock-based compensation |  |  | 0.15 |  |  |  | 0.13 |  |  |  | 0.14 |  |  |  | 0.14 |  |  |  | 0.17 |  |  |  | 0.58 |  |  |  | 0.69 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |  |  | 0.02 |  |  |  | — |  |
| Restructuring charges |  |  | 0.07 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.19 |  |
| Gain on sale of properties |  |  | — |  |  |  | — |  |  |  | (0.81 | ) |  |  | — |  |  |  | — |  |  |  | (0.79 | ) |  |  | (0.04 | ) |
| Income tax effects |  |  | (0.15 | ) |  |  | (0.11 | ) |  |  | 0.27 |  |  |  | (0.02 | ) |  |  | (0.09 | ) |  |  | 0.04 |  |  |  | (0.10 | ) |
| Income tax benefit of ASC 606 adoption |  |  | (0.13 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Tax reform |  |  | — |  |  |  | — |  |  |  | 3.19 |  |  |  | — |  |  |  | — |  |  |  | 3.10 |  |  |  | — |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.04 |  |  | $ | 1.12 |  |  | $ | 1.05 |  |  | $ | 0.80 |  |  | $ | 0.60 |  |  | $ | 3.56 |  |  | $ | 2.63 |  |
| In Q3'FY18, our GAAP net loss per share was calculated using basic shares of 268 million, as the impact of common stock equivalents would have been anti-dilutive. Additionally, each adjustment presented in the reconciliation was computed using basic shares. However, because we reported net income on a non-GAAP basis, non-GAAP net income per share was computed using diluted shares of 276 million. As a result of the difference in the number of shares, the summation of GAAP net loss per share and the adjustments does not equal non-GAAP net income per share. |  |

[0001564590-18-021828:8k_2_02:99]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY19 |  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | FY2018 |  |  | FY2017 |  |
| Gross margin-GAAP |  |  | 65.3 | % |  |  | 62.6 | % |  |  | 62.1 | % |  |  | 63.6 | % |  |  | 62.4 | % |  |  | 62.7 | % |  |  | 61.3 | % |
| Cost of revenues adjustments |  |  | 0.9 | % |  |  | 0.7 | % |  |  | 0.8 | % |  |  | 0.8 | % |  |  | 0.9 | % |  |  | 0.8 | % |  |  | 0.8 | % |
| Gross margin-Non-GAAP |  |  | 66.2 | % |  |  | 63.3 | % |  |  | 63.0 | % |  |  | 64.5 | % |  |  | 63.3 | % |  |  | 63.5 | % |  |  | 62.1 | % |
| GAAP cost of revenues |  | $ | 511 |  |  | $ | 615 |  |  | $ | 583 |  |  | $ | 515 |  |  | $ | 497 |  |  | $ | 2,210 |  |  | $ | 2,127 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (9 | ) |  |  | (10 | ) |  |  | (9 | ) |  |  | (8 | ) |  |  | (36 | ) |  |  | (29 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (3 | ) |  |  | (3 | ) |  |  | (3 | ) |  |  | (4 | ) |  |  | (13 | ) |  |  | (17 | ) |
| Non-GAAP cost of revenues |  | $ | 498 |  |  | $ | 603 |  |  | $ | 570 |  |  | $ | 503 |  |  | $ | 485 |  |  | $ | 2,161 |  |  | $ | 2,081 |  |
| Net revenues |  | $ | 1,474 |  |  | $ | 1,644 |  |  | $ | 1,539 |  |  | $ | 1,415 |  |  | $ | 1,321 |  |  | $ | 5,919 |  |  | $ | 5,491 |  |

[0001564590-18-021828:8k_2_02:100]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY19 |  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | FY2018 |  |  | FY2017 |  |
| Product gross margin-GAAP |  |  | 54.5 | % |  |  | 51.7 | % |  |  | 50.7 | % |  |  | 51.5 | % |  |  | 48.3 | % |  |  | 50.7 | % |  |  | 47.3 | % |
| Cost of product revenues adjustments |  |  | 1.1 | % |  |  | 1.0 | % |  |  | 1.1 | % |  |  | 1.2 | % |  |  | 1.2 | % |  |  | 1.1 | % |  |  | 1.1 | % |
| Product gross margin-Non-GAAP |  |  | 55.7 | % |  |  | 52.7 | % |  |  | 51.8 | % |  |  | 52.7 | % |  |  | 49.5 | % |  |  | 51.8 | % |  |  | 48.4 | % |
| GAAP cost of product revenues |  | $ | 398 |  |  | $ | 496 |  |  | $ | 469 |  |  | $ | 397 |  |  | $ | 376 |  |  | $ | 1,738 |  |  | $ | 1,612 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (9 | ) |  |  | (10 | ) |  |  | (9 | ) |  |  | (8 | ) |  |  | (36 | ) |  |  | (29 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |  |  | (3 | ) |  |  | (4 | ) |
| Non-GAAP cost of product revenues |  | $ | 388 |  |  | $ | 486 |  |  | $ | 459 |  |  | $ | 387 |  |  | $ | 367 |  |  | $ | 1,699 |  |  | $ | 1,579 |  |
| Product revenues |  | $ | 875 |  |  | $ | 1,027 |  |  | $ | 952 |  |  | $ | 819 |  |  | $ | 727 |  |  | $ | 3,525 |  |  | $ | 3,060 |  |

[0001564590-18-021828:8k_2_02:101]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY19 |  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | FY2018 |  |  | FY2017 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 71.4 | % |  |  | 70.5 | % |  |  | 70.5 | % |  |  | 69.9 | % |  |  | 69.3 | % |  |  | 70.0 | % |  |  | 68.1 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.8 | % |  |  | 0.5 | % |  |  | 0.8 | % |  |  | 0.5 | % |  |  | 0.8 | % |  |  | 0.7 | % |  |  | 0.9 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 72.2 | % |  |  | 71.0 | % |  |  | 71.3 | % |  |  | 70.4 | % |  |  | 70.1 | % |  |  | 70.7 | % |  |  | 68.9 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 106 |  |  | $ | 113 |  |  | $ | 108 |  |  | $ | 112 |  |  | $ | 114 |  |  | $ | 447 |  |  | $ | 487 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (2 | ) |  |  | (3 | ) |  |  | (2 | ) |  |  | (3 | ) |  |  | (10 | ) |  |  | (13 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 103 |  |  | $ | 111 |  |  | $ | 105 |  |  | $ | 110 |  |  | $ | 111 |  |  | $ | 437 |  |  | $ | 474 |  |
| Hardware maintenance and other services revenues |  | $ | 370 |  |  | $ | 383 |  |  | $ | 366 |  |  | $ | 372 |  |  | $ | 371 |  |  | $ | 1,492 |  |  | $ | 1,526 |  |

[0001564590-18-021828:8k_2_02:102]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q1'FY19 |  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | FY2018 |  |  | FY2017 |  |
| GAAP effective tax rate |  |  | (4.0 | )% |  |  | 11.6 | % |  |  | 195.0 | % |  |  | 21.6 | % |  |  | 9.7 | % |  |  | 90.3 | % |  |  | 22.5 | % |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 9.8 | % |  |  | 6.8 | % |  |  | (9.5 | )% |  |  | (2.0 | )% |  |  | 9.8 | % |  |  | (0.8 | )% |  |  | (4.1 | )% |
| Income tax benefit of ASC 606 adoption |  |  | 12.5 | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |
| Tax reform |  |  | — | % |  |  | — | % |  |  | (169.8 | )% |  |  | — | % |  |  | — | % |  |  | (71.4 | )% |  |  | — | % |
| Non-GAAP effective tax rate |  |  | 18.3 | % |  |  | 18.4 | % |  |  | 15.7 | % |  |  | 19.6 | % |  |  | 19.4 | % |  |  | 18.1 | % |  |  | 18.4 | % |

[0001564590-18-021828:8k_2_02:103]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY19 |  |  | Q4'FY18 |  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | FY2018 |  |  | FY2017 |  |
| Net cash provided by operating activities |  | $ | 326 |  |  | $ | 494 |  |  | $ | 420 |  |  | $ | 314 |  |  | $ | 250 |  |  | $ | 1,478 |  |  | $ | 986 |  |
| Purchases of property and equipment |  |  | (64 | ) |  |  | (48 | ) |  |  | (32 | ) |  |  | (29 | ) |  |  | (36 | ) |  |  | (145 | ) |  |  | (175 | ) |
| Free cash flow |  | $ | 262 |  |  | $ | 446 |  |  | $ | 388 |  |  | $ | 285 |  |  | $ | 214 |  |  | $ | 1,333 |  |  | $ | 811 |  |

[0001564590-18-021828:8k_2_02:104]
Some items may not add or recalculate due to rounding.

[0001564590-18-021828:8k_2_02:105]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| SECOND QUARTER FISCAL 2019 |  |
|  |  | Second Quarter |  |
|  |  | Fiscal 2019 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $0.94 - $1.00 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Second Quarter Fiscal 2019: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.05 | ) |
| Stock-based compensation expense |  |  | (0.14 | ) |
| Income tax effects |  |  | 0.04 |  |
| Total Adjustments |  |  | (0.15 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.79 - $0.85 |  |

[0001564590-18-021828:8k_2_02:106]
Press Contact:

[0001564590-18-021828:8k_2_02:107]
Madge Miller

[0001564590-18-021828:8k_2_02:108]
NetApp

[0001564590-18-021828:8k_2_02:109]
1 408 419 5263

[0001564590-18-021828:8k_2_02:110]
madge.miller@netapp.com

[0001564590-18-021828:8k_2_02:111]
Investor Contact:

[0001564590-18-021828:8k_2_02:112]
Kris Newton

[0001564590-18-021828:8k_2_02:113]
NetApp

[0001564590-18-021828:8k_2_02:114]
1 408 822 3312

[0001564590-18-021828:8k_2_02:115]
kris.newton@netapp.com
