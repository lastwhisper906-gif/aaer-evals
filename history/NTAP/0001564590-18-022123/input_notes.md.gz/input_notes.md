# NTAP notes — 0001564590-18-022123


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-18-022123:notes:1]
[same as prior period, unchanged from 0001564590-18-002876:notes:1]

[0001564590-18-022123:notes:2]
[same as prior period, unchanged from 0001564590-18-002876:notes:2]

[0001564590-18-022123:notes:3]
[same as prior period, unchanged from 0001564590-18-002876:notes:3]

[0001564590-18-022123:notes:4]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal years 2019 and 2018, ending on April 26, 2019, and April 27, 2018, respectively, are each 52-week years, with 13 weeks in each of their quarters.

[0001564590-18-022123:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 27, 2018 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 27, 2018 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-18-022123:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; valuation of investment securities; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-18-022123:notes:7]
Accounting Changes

[0001564590-18-022123:notes:8]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard, Revenue from Contracts with Customers (ASC 606), which establishes a comprehensive new revenue recognition model designed to depict the transfer of goods or services to a customer in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In the three months ended July 27, 2018, we adopted this new standard using the full retrospective method of adoption. Accordingly, our prior period condensed consolidated financial statements and information, as presented herein, have been restated to conform to the new rules. Refer to Note 6 – Revenue for a summary of the impacts of adopting this standard, and a discussion of our updated policies related to revenue recognition.

[0001564590-18-022123:notes:9]
In October 2016, the FASB issued an accounting standards update (ASU) which eliminates the deferred tax effects of intra-entity asset transfers other than inventory. As a result, tax expense from the sale of an asset in the seller’s tax jurisdiction is recognized when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. In the three months ended July 27, 2018, we adopted this ASU using a modified retrospective transition approach and recorded a cumulative-effect adjustment to decrease retained earnings by $51 million, with a corresponding reduction of prepaid taxes, which were classified as other non-current assets on our condensed consolidated balance sheets, as of the beginning of the period.

[0001564590-18-022123:notes:10]
In November 2016, the FASB issued an ASU that requires a statement of cash flows to explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. In the three months ended July 27, 2018, we adopted this ASU using a retrospective transition method. Accordingly, our condensed consolidated statement of cash flows for the three months ended July 28, 2017, as presented herein, has been restated to comply with the new requirements. Refer to Note 5 – Supplemental Financial Information for a detail of the components of our cash, cash equivalents and restricted cash balances.

[0001564590-18-022123:notes:11]
There have been no other significant changes in our significant accounting policies as of and for the three months ended July 27, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 27, 2018.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-18-022123:notes:12]
[same as prior period, unchanged from 0001564590-18-002876:notes:8]

[0001564590-18-022123:notes:13]
Non-cash investing and supplemental cash flow information are as follows (in millions):

[0001564590-18-022123:notes:14]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 10 |  |  | $ | 18 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 22 |  |  | $ | 22 |  |
| Interest paid |  | $ | 14 |  |  | $ | 21 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-18-022123:notes:15]
4. Purchased Intangible Assets, Net

[0001564590-18-022123:notes:16]
[same as prior period, unchanged from 0001564590-18-002876:notes:17]

[0001564590-18-022123:notes:17]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 160 |  |  | $ | (86 | ) |  | $ | 74 |  |  | $ | 164 |  |  | $ | (80 | ) |  | $ | 84 |  |
| Customer contracts/relationships |  |  | 41 |  |  |  | (34 | ) |  |  | 7 |  |  |  | 43 |  |  |  | (33 | ) |  |  | 10 |  |
| Other purchased intangibles |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 9 |  |  |  | (9 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 201 |  |  | $ | (120 | ) |  | $ | 81 |  |  | $ | 216 |  |  | $ | (122 | ) |  | $ | 94 |  |

[0001564590-18-022123:notes:18]
[same as prior period, unchanged from 0001564590-18-002876:notes:19]

[0001564590-18-022123:notes:19]
|  |  | Three Months Ended |  |  | Statements of |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |  | Operations Classification |
| Developed technology |  | $ | 9 |  |  | $ | 8 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 4 |  |  |  | 4 |  |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | 1 |  |  | Operating expenses |
| Total |  | $ | 13 |  |  | $ | 13 |  |  |  |

[0001564590-18-022123:notes:20]
As of July 27, 2018, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-18-022123:notes:21]
| Fiscal Year |  | Amount |  |
| Remainder of 2019 |  | $ | 34 |  |
| 2020 |  |  | 31 |  |
| 2021 |  |  | 16 |  |
| Total |  | $ | 81 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-18-022123:notes:22]
5. Supplemental Financial Information

[0001564590-18-022123:notes:23]
Cash, cash equivalents and restricted cash (in millions):

[0001564590-18-022123:notes:24]
The following table presents cash and cash equivalents as reported in our condensed consolidated balance sheets, as well as the sum of cash, cash equivalents and restricted cash as reported on our condensed consolidated statement of cash flows in accordance with our adoption of the ASU discussed in Note 1 – Description of Business and Significant Accounting Policies:

[0001564590-18-022123:notes:25]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Cash |  | $ | 2,519 |  |  | $ | 2,727 |  |
| Cash equivalents |  |  | 108 |  |  |  | 214 |  |
| Cash and cash equivalents |  | $ | 2,627 |  |  | $ | 2,941 |  |
| Short-term restricted cash |  |  | 5 |  |  |  | 5 |  |
| Long-term restricted cash |  |  | 1 |  |  |  | 1 |  |
| Restricted cash |  | $ | 6 |  |  | $ | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,633 |  |  | $ | 2,947 |  |

[0001564590-18-022123:notes:26]
[same as prior period, unchanged from 0001564590-18-002876:notes:26]

[0001564590-18-022123:notes:27]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Purchased components |  | $ | 17 |  |  | $ | 12 |  |
| Finished goods |  |  | 80 |  |  |  | 110 |  |
| Inventories |  | $ | 97 |  |  | $ | 122 |  |

[0001564590-18-022123:notes:28]
[same as prior period, unchanged from 0001564590-18-002876:notes:28]

[0001564590-18-022123:notes:29]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Land |  | $ | 106 |  |  | $ | 106 |  |
| Buildings and improvements |  |  | 605 |  |  |  | 594 |  |
| Leasehold improvements |  |  | 87 |  |  |  | 88 |  |
| Computer, production, engineering and other equipment |  |  | 765 |  |  |  | 733 |  |
| Computer software |  |  | 358 |  |  |  | 357 |  |
| Furniture and fixtures |  |  | 104 |  |  |  | 99 |  |
| Construction-in-progress |  |  | 4 |  |  |  | 27 |  |
|  |  |  | 2,029 |  |  |  | 2,004 |  |
| Accumulated depreciation and amortization |  |  | (1,261 | ) |  |  | (1,248 | ) |
| Property and equipment, net |  | $ | 768 |  |  | $ | 756 |  |

[0001564590-18-022123:notes:30]
In September 2017, we entered into an agreement to sell certain land and buildings located in Sunnyvale, California, through two separate and independent closings, the first of which was completed in the third quarter of fiscal 2018. The remaining properties, consisting of land with a net book value of $52 million, were classified as assets held for sale, and included as other current assets in our condensed consolidated balance sheets as of July 27, 2018 and April 27, 2018. We will consummate the sale of these properties, and receive cash proceeds of $96 million, upon the completion of the second closing, which is expected to occur within the next 12 months. That closing is subject to due diligence, certain termination rights and customary closing conditions, including local governmental approval of the subdivision of a land parcel.

[0001564590-18-022123:notes:31]
[same as prior period, unchanged from 0001564590-18-002876:notes:32]

[0001564590-18-022123:notes:32]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Deferred tax assets |  | $ | 225 |  |  | $ | 229 |  |
| Other assets |  |  | 239 |  |  |  | 221 |  |
| Other non-current assets |  | $ | 464 |  |  | $ | 450 |  |

[0001564590-18-022123:notes:33]
[same as prior period, unchanged from 0001564590-18-002876:notes:34]

[0001564590-18-022123:notes:34]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Accrued compensation and benefits |  | $ | 268 |  |  | $ | 441 |  |
| Product warranty liabilities |  |  | 25 |  |  |  | 25 |  |
| Other current liabilities |  |  | 299 |  |  |  | 359 |  |
| Accrued expenses |  | $ | 592 |  |  | $ | 825 |  |

[0001564590-18-022123:notes:35]
[same as prior period, unchanged from 0001564590-18-002876:notes:36]

[0001564590-18-022123:notes:36]
[same as prior period, unchanged from 0001564590-18-002876:notes:37]

[0001564590-18-022123:notes:37]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Balance at beginning of period |  | $ | 40 |  |  | $ | 50 |  |
| Expense accrued during the period |  |  | 4 |  |  |  | 1 |  |
| Warranty costs incurred |  |  | (6 | ) |  |  | (7 | ) |
| Balance at end of period |  | $ | 38 |  |  | $ | 44 |  |

[0001564590-18-022123:notes:38]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Accrued expenses |  | $ | 25 |  |  | $ | 25 |  |
| Other long-term liabilities |  |  | 13 |  |  |  | 15 |  |
| Total warranty liabilities |  | $ | 38 |  |  | $ | 40 |  |

[0001564590-18-022123:notes:39]
[same as prior period, unchanged from 0001564590-18-002876:notes:40]

[0001564590-18-022123:notes:40]
[same as prior period, unchanged from 0001564590-18-002876:notes:41]

[0001564590-18-022123:notes:41]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Liability for uncertain tax positions |  | $ | 319 |  |  | $ | 314 |  |
| Income taxes payable |  |  | 549 |  |  |  | 549 |  |
| Product warranty liabilities |  |  | 13 |  |  |  | 15 |  |
| Other liabilities |  |  | 83 |  |  |  | 114 |  |
| Other long-term liabilities |  | $ | 964 |  |  | $ | 992 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-18-022123:notes:42]
6. Revenue

[0001564590-18-022123:notes:43]
Effective our first quarter of fiscal 2019, we adopted ASC 606 using the full retrospective method and have restated each prior reporting period presented to conform to the new rules. The most significant impact of the new standard relates to our accounting for arrangements containing software. For our enterprise software license agreements (ELAs), we now recognize the license fee component of such arrangements up front. Under the prior rules, the software license fee was recognized over the term of the enterprise license based on our inability to establish vendor specific objective evidence of fair value for the undelivered software support element of these arrangements. In addition, for other software arrangements, revenue deferred for the undelivered elements that was previously allocated based on the residual method is now allocated based on relative fair value, which generally results in more software arrangement revenue being recognized earlier. The new standard also impacts our estimation of variable consideration for certain arrangements with contract terms such as rights of return, potential penalties and acceptance clauses.

[0001564590-18-022123:notes:44]
The following table presents the impacts of adoption of ASC 606 to select line items of our condensed consolidated balance sheet as of the end of fiscal 2018:

[0001564590-18-022123:notes:45]
|  |  | As of April 27, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  | As Adjusted |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 1,009 |  |  | $ | 38 |  |  | (1 | ) | $ | 1,047 |  |
| Inventories |  |  | 126 |  |  |  | (4 | ) |  |  |  |  | 122 |  |
| Other current assets |  |  | 330 |  |  |  | 62 |  |  | (2 | ) |  | 392 |  |
| Other non-current assets |  |  | 420 |  |  |  | 30 |  |  | (2 | ) |  | 450 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term deferred revenue and financed unearned services revenue |  | $ | 1,804 |  |  | $ | (92 | ) |  | (3 | ) | $ | 1,712 |  |
| Other long-term liabilities |  |  | 961 |  |  |  | 31 |  |  | (4 | ) |  | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,673 |  |  |  | (22 | ) |  | (3 | ) |  | 1,651 |  |
| Accumulated deficit |  |  | (218 | ) |  |  | 209 |  |  | (5 | ) |  | (9 | ) |

[0001564590-18-022123:notes:46]
|  | (1) | Netting of accounts receivable and deferred revenue balances for certain customer arrangements has been updated to reflect the impact of adoption |

[0001564590-18-022123:notes:47]
|  | (2) | Reflects capitalization of commissions and reduction of long-term deferred tax assets |

[0001564590-18-022123:notes:48]
|  | (3) | Reflects cumulative change in revenue and the impact of adoption to the netting of accounts receivable and deferred revenue balances for certain customer arrangements |

[0001564590-18-022123:notes:49]
|  | (4) | Reflects increase in long-term deferred tax liabilities |

[0001564590-18-022123:notes:50]
|  | (5) | Reflects cumulative impact to net income (loss) |

[0001564590-18-022123:notes:51]
The following table presents the impacts of adoption of ASC 606 to our statement of operations for the first quarter of fiscal 2018:

[0001564590-18-022123:notes:52]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 723 |  |  | $ | 4 |  |  | $ | 727 |  |
| Software maintenance |  |  | 234 |  |  |  | (11 | ) |  |  | 223 |  |
| Hardware maintenance and other services |  |  | 368 |  |  |  | 3 |  |  |  | 371 |  |
| Net revenues |  |  | 1,325 |  |  |  | (4 | ) |  |  | 1,321 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 371 |  |  |  | 5 |  |  |  | 376 |  |
| Cost of software maintenance |  |  | 7 |  |  |  | — |  |  |  | 7 |  |
| Cost of hardware maintenance and other services |  |  | 113 |  |  |  | 1 |  |  |  | 114 |  |
| Total cost of revenues |  |  | 491 |  |  |  | 6 |  |  |  | 497 |  |
| Gross profit |  |  | 834 |  |  |  | (10 | ) |  |  | 824 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 425 |  |  |  | (2 | ) |  |  | 423 |  |
| Research and development |  |  | 193 |  |  |  | — |  |  |  | 193 |  |
| General and administrative |  |  | 68 |  |  |  | — |  |  |  | 68 |  |
| Total operating expenses |  |  | 686 |  |  |  | (2 | ) |  |  | 684 |  |
| Income from operations |  |  | 148 |  |  |  | (8 | ) |  |  | 140 |  |
| Other income, net |  |  | 5 |  |  |  | — |  |  |  | 5 |  |
| Income before income taxes |  |  | 153 |  |  |  | (8 | ) |  |  | 145 |  |
| Provision for income taxes |  |  | 17 |  |  |  | (3 | ) |  |  | 14 |  |
| Net income |  | $ | 136 |  |  | $ | (5 | ) |  | $ | 131 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.50 |  |  | $ | (0.01 | ) |  | $ | 0.49 |  |
| Diluted |  | $ | 0.49 |  |  | $ | (0.02 | ) |  | $ | 0.47 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 270 |  |  |  | 270 |  |  |  | 270 |  |
| Diluted |  |  | 278 |  |  |  | 278 |  |  |  | 278 |  |

[0001564590-18-022123:notes:53]
The adoption of ASC 606 had no impact to cash provided by or used in operating, investing or financing activities as presented on our condensed consolidated statement of cash flows.

[0001564590-18-022123:notes:54]
The core principle of ASC 606 is to recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled in exchange for those goods or services. This principle is achieved through applying the following five-step approach.

[0001564590-18-022123:notes:55]
|  | • | Identification of the contract, or contracts, with a customer — A contract with a customer exists when (i) we enter into an enforceable contract with a customer that (ii) defines each party’s rights regarding the goods or services to be transferred and (iii) identifies the payment terms related to these goods or services. Additionally, (iv) the contract has commercial substance and, (v) we determine that collection of substantially all consideration for goods or services that are transferred is probable based on the customer’s intent and ability to pay the promised consideration. We apply judgment in determining the customer’s ability and intention to pay, which is based on a variety of factors including the customer’s historical payment experience or, in the case of a new customer, published credit and financial information pertaining to the customer. We also combine two or more contracts entered into at or near the same time with the same customer as a single contract if the contracts are negotiated as one package with a single commercial objective, the amount of consideration to be paid on one contract depends on the price or performance of the other contract or if the goods and services promised in each of the contracts are a single performance obligation. |

[0001564590-18-022123:notes:56]
|  | • | Identification of the performance obligations in the contract — Performance obligations promised in a contract are identified based on the goods or services (or a bundle of goods and services) that will be transferred to the customer that are distinct. A good or service is distinct if it is capable of being distinct, where the customer can benefit from the goods or service either on its own or together with other resources that are readily available from third parties or from us, and is distinct in the context of the contract, meaning the transfer of the goods or services is separately identifiable from other promises in the contract. To the extent a contract includes multiple promised goods or services, we apply judgment to determine whether promised goods or services are capable of being distinct and distinct in the context of the contract. If these criteria are not met, we combine the goods and services until we have a distinct performance obligation. |

[0001564590-18-022123:notes:57]
|  | • | Determination of the transaction price — The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer. Consideration promised may include fixed amounts, variable amounts or both. We use judgment in determining variable consideration, particularly if consideration is contingent on the occurrence or nonoccurrence of a future event. We use the expected value, primarily relying on our history, to estimate variable consideration. We may also use, in certain situations, the most likely amount as the basis of our estimate. In either case, we consider variable consideration only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recognized will not occur. Reassessments of our variable consideration may occur as historical information changes. Transaction prices should also be adjusted for the effects of time value of money if the timing of payments provides either the customer or ourselves a significant benefit of financing. |

[0001564590-18-022123:notes:58]
|  | • | Allocation of the transaction price to the performance obligations in the contract — If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation based on a relative standalone selling price basis. We determine standalone selling price based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price taking into account available information such as market conditions and internally approved pricing guidelines related to the performance obligations. Variable consideration is also allocated to the performance obligations. If the terms of variable consideration relate to one performance obligation, it is entirely allocated to that obligation. Otherwise, it is allocated to all the performance obligations in the contract. |

[0001564590-18-022123:notes:59]
|  | • | Recognition of revenue when, or as, we satisfy a performance obligation — We satisfy performance obligations either over time or at a point in time. We typically recognize revenue at a point in time for promises to transfer goods to a customer. Services are typically transferred over time based on an appropriate method for measuring our progress toward completion of that performance obligation. Our stand-ready services, including both hardware and software maintenance support, are transferred ratably over the period of the contract. For other services such as our fixed professional services contract, we use an input method to determine the percentage of completion. That is, we estimate the effort to date versus the expected effort required over the life of the contract. |

[0001564590-18-022123:notes:60]
Disaggregation of revenue

[0001564590-18-022123:notes:61]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. Strategic solutions include Clustered ONTAP, branded E-Series, SolidFire, converged and hyper-converged infrastructure, ELAs and other optional add-on software products. Mature solutions include 7-mode ONTAP, add-on hardware and related operating system (OS) software and original equipment manufacturers (OEM) products. Both our Mature and Strategic product lines include a mix of disk, hybrid and all flash storage media. Additionally, we provide a variety of services including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training.

[0001564590-18-022123:notes:62]
The following table depicts the disaggregation of revenue by our products and services (in millions):

[0001564590-18-022123:notes:63]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Product revenues |  | $ | 875 |  |  | $ | 727 |  |
| Strategic |  |  | 612 |  |  |  | 498 |  |
| Mature |  |  | 263 |  |  |  | 229 |  |
| Software maintenance revenues |  | 229 |  |  | 223 |  |
| Hardware maintenance and other services revenues |  | 370 |  |  | 371 |  |
| Hardware maintenance support contracts |  |  | 303 |  |  |  | 298 |  |
| Professional and other services |  |  | 67 |  |  |  | 73 |  |
| Net revenues |  | $ | 1,474 |  |  | $ | 1,321 |  |

[0001564590-18-022123:notes:64]
Revenues by geographic region are presented in Note 15 – Segment, Geographic, and Significant Customer Information.

[0001564590-18-022123:notes:65]
Deferred revenue and financed unearned services revenue

[0001564590-18-022123:notes:66]
The following table summarizes the components of our deferred revenue and financed unearned services balance as reported in our condensed consolidated balance sheets (in millions):

[0001564590-18-022123:notes:67]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Deferred product revenue |  | $ | 102 |  |  | $ | 107 |  |
| Deferred services revenue |  |  | 3,046 |  |  |  | 3,134 |  |
| Financed unearned services revenue |  |  | 112 |  |  |  | 122 |  |
| Total |  | $ | 3,260 |  |  | $ | 3,363 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,623 |  |  | $ | 1,712 |  |
| Long-term |  |  | 1,637 |  |  |  | 1,651 |  |
| Total |  | $ | 3,260 |  |  | $ | 3,363 |  |

[0001564590-18-022123:notes:68]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 16 – Commitments and Contingencies for additional information related to these arrangements.

[0001564590-18-022123:notes:69]
The following tables summarize the activity related to deferred revenue and financed unearned services revenue (in millions):

[0001564590-18-022123:notes:70]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Balance at beginning of period |  | $ | 3,363 |  |  | $ | 3,213 |  |
| Additions |  |  | 511 |  |  |  | 497 |  |
| Revenue recognized during the period |  |  | (614 | ) |  |  | (583 | ) |
| Balance at end of period |  | $ | 3,260 |  |  | $ | 3,127 |  |

[0001564590-18-022123:notes:71]
During the three months ended July 27, 2018 and July 28, 2017, we recognized $561 million and $528 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001564590-18-022123:notes:72]
As of July 27, 2018, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,260 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 26% in the next 13 to 24 months, and the remainder thereafter.

[0001564590-18-022123:notes:73]
Deferred commissions

[0001564590-18-022123:notes:74]
As a result of our adoption of ASC 606 in the first quarter of fiscal 2019, we capitalize sales commissions that are incremental direct costs of obtaining customer contracts for which revenue is not immediately recognized and classify them as current or non-current based on the terms of the related contracts. Capitalized commissions are amortized based on the transfer of goods or services to which they relate, typically over one to three years, and are also periodically reviewed for impairment. Amortization expense is recorded to sales and marketing expense in our condensed consolidated statements of operations. The following tables summarize the activity related to deferred commissions and their balances as reported in our condensed consolidated balance sheets (in millions):

[0001564590-18-022123:notes:75]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Balance at beginning of period |  | $ | 137 |  |  | $ | 113 |  |
| Additions |  |  | 19 |  |  |  | 18 |  |
| Expense recognized during the period |  |  | (21 | ) |  |  | (15 | ) |
| Balance at end of period |  | $ | 135 |  |  | $ | 116 |  |

[0001564590-18-022123:notes:76]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Other current assets |  | $ | 64 |  |  | $ | 66 |  |
| Other non-current assets |  |  | 71 |  |  |  | 71 |  |
| Total deferred commissions |  | $ | 135 |  |  | $ | 137 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-18-022123:notes:77]
7. Other income, net

[0001564590-18-022123:notes:78]
Other income, net consists of the following (in millions):

[0001564590-18-022123:notes:79]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Interest income |  | $ | 25 |  |  | $ | 16 |  |
| Interest expense |  |  | (14 | ) |  |  | (13 | ) |
| Other income, net |  |  | 7 |  |  |  | 2 |  |
| Total other income, net |  | $ | 18 |  |  | $ | 5 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-18-022123:notes:80]
[same as prior period, unchanged from 0001564590-18-002876:notes:49]

[0001564590-18-022123:notes:81]
[same as prior period, unchanged from 0001564590-18-002876:notes:50]

[0001564590-18-022123:notes:82]
[same as prior period, unchanged from 0001564590-18-002876:notes:51]

[0001564590-18-022123:notes:83]
[same as prior period, unchanged from 0001564590-18-002876:notes:52]

[0001564590-18-022123:notes:84]
[same as prior period, unchanged from 0001564590-18-002876:notes:53]

[0001564590-18-022123:notes:85]
[same as prior period, unchanged from 0001564590-18-002876:notes:54]

[0001564590-18-022123:notes:86]
[same as prior period, unchanged from 0001564590-18-002876:notes:55]

[0001564590-18-022123:notes:87]
[same as prior period, unchanged from 0001564590-18-002876:notes:56]

[0001564590-18-022123:notes:88]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,740 |  |  | $ | 1 |  |  | $ | (39 | ) |  | $ | 1,702 |  |  | $ | 1,865 |  |  | $ | 1 |  |  | $ | (39 | ) |  | $ | 1,827 |  |
| U.S. Treasury and government debt securities |  |  | 441 |  |  |  | — |  |  |  | (5 | ) |  |  | 436 |  |  |  | 497 |  |  |  | — |  |  |  | (5 | ) |  |  | 492 |  |
| Commercial paper |  |  | 38 |  |  |  | — |  |  |  | — |  |  |  | 38 |  |  |  | 230 |  |  |  | — |  |  |  | — |  |  |  | 230 |  |
| Certificates of deposit |  |  | 116 |  |  |  | — |  |  |  | — |  |  |  | 116 |  |  |  | 115 |  |  |  | — |  |  |  | — |  |  |  | 115 |  |
| Mutual funds |  |  | 34 |  |  |  | — |  |  |  | — |  |  |  | 34 |  |  |  | 31 |  |  |  | — |  |  |  | — |  |  |  | 31 |  |
| Total debt and equity securities |  | $ | 2,369 |  |  | $ | 1 |  |  | $ | (44 | ) |  | $ | 2,326 |  |  | $ | 2,738 |  |  | $ | 1 |  |  | $ | (44 | ) |  | $ | 2,695 |  |

[0001564590-18-022123:notes:89]
As of July 27, 2018 and April 27, 2018, the unrealized losses on our available-for-sale investments were caused by market value declines as a result of increasing market interest rates. Because the declines in market value are attributable to changes in market conditions and not credit quality, and because we have determined that (i) we do not have the intent to sell any of these investments and (ii) it is not more likely than not that we will be required to sell any of these investments before recovery of the entire amortized cost basis, we have determined that no other-than-temporary impairments were required to be recognized on these investments as of July 27, 2018 and April 27, 2018.

[0001564590-18-022123:notes:90]
The following table presents the contractual maturities of our debt investments as of July 27, 2018 (in millions):

[0001564590-18-022123:notes:91]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 687 |  |  | $ | 685 |  |
| Due after one year through five years |  |  | 1,040 |  |  |  | 1,024 |  |
| Due after five years through ten years |  |  | 608 |  |  |  | 583 |  |
|  |  | $ | 2,335 |  |  | $ | 2,292 |  |

[0001564590-18-022123:notes:92]
[same as prior period, unchanged from 0001564590-18-002876:notes:61]

[0001564590-18-022123:notes:93]
[same as prior period, unchanged from 0001564590-18-002876:notes:62]

[0001564590-18-022123:notes:94]
[same as prior period, unchanged from 0001564590-18-002876:notes:63]

[0001564590-18-022123:notes:95]
|  |  | July 27, 2018 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,519 |  |  | $ | 2,519 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,702 |  |  |  | — |  |  |  | 1,702 |  |
| U.S. Treasury and government debt securities |  |  | 436 |  |  |  | 234 |  |  |  | 202 |  |
| Commercial paper |  |  | 38 |  |  |  | — |  |  |  | 38 |  |
| Certificates of deposit |  |  | 116 |  |  |  | — |  |  |  | 116 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,811 |  |  | $ | 2,753 |  |  | $ | 2,058 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 28 |  |  | $ | 28 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0001564590-18-022123:notes:96]
[same as prior period, unchanged from 0001564590-18-002876:notes:65]

[0001564590-18-022123:notes:97]
[same as prior period, unchanged from 0001564590-18-002876:notes:66]

[0001564590-18-022123:notes:98]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of July 27, 2018 and April 27, 2018, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-18-022123:notes:99]
[same as prior period, unchanged from 0001564590-18-002876:notes:69]

[0001564590-18-022123:notes:100]
As of July 27, 2018 and April 27, 2018, the fair value of our long-term debt was approximately $1,518 million and $1,523 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-18-022123:notes:101]
9. Financing Arrangements

[0001564590-18-022123:notes:102]
Long-Term Debt

[0001564590-18-022123:notes:103]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-18-022123:notes:104]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  |  | 400 |  |  |  | 2.32 | % |  |  | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (8 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,542 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |

[0001564590-18-022123:notes:105]
Senior Notes

[0001564590-18-022123:notes:106]
Our 2.00% Senior Notes and 3.30% Senior Notes, each with a principal amount of $400 million, were issued in September 2017. Interest on these Senior Notes is paid semi-annually in March and September. Our 3.375% Senior Notes and 3.25% Senior Notes, with principal amounts of $500 million and $250 million, respectively, were issued in June 2014 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-18-022123:notes:107]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 27, 2018, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-18-022123:notes:108]
As of July 27, 2018, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-18-022123:notes:109]
| Fiscal Year |  | Amount |  |
| 2020 |  | $ | 400 |  |
| 2022 |  |  | 500 |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| Total |  | $ | 1,550 |  |

[0001564590-18-022123:notes:110]
Commercial Paper Program and Credit Facility

[0001564590-18-022123:notes:111]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of July 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $200 million, a weighted-average interest rate of 2.28% and maturities ranging from 14 days to 31 days. As of April 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $385 million, a weighted-average interest rate of 2.29% and maturities ranging from 19 days to 32 days.

[0001564590-18-022123:notes:112]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of July 27, 2018 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-18-022123:notes:113]
[same as prior period, unchanged from 0001564590-18-002876:notes:88]

[0001564590-18-022123:notes:114]
[same as prior period, unchanged from 0001564590-18-002876:notes:89]

[0001564590-18-022123:notes:115]
As of July 27, 2018, we have certain equity incentive awards (awards) outstanding, which include stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and Employee Stock Purchase Plan (ESPP) awards.

[0001564590-18-022123:notes:116]
[same as prior period, unchanged from 0001564590-18-002876:notes:91]

[0001564590-18-022123:notes:117]
[same as prior period, unchanged from 0001564590-18-002876:notes:92]

[0001564590-18-022123:notes:118]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 27, 2018 |  |  | 1 |  |  | $ | 31.19 |  |  |  |  |  |  |  |  |  |
| Outstanding as of July 27, 2018 |  |  | 1 |  |  | $ | 29.86 |  |  |  | 3.50 |  |  | $ | 40 |  |
| Exercisable as of July 27, 2018 |  |  | 1 |  |  | $ | 32.23 |  |  |  | 3.05 |  |  | $ | 34 |  |

[0001564590-18-022123:notes:119]
[same as prior period, unchanged from 0001564590-18-002876:notes:94]

[0001564590-18-022123:notes:120]
[same as prior period, unchanged from 0001564590-18-002876:notes:95]

[0001564590-18-022123:notes:121]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Intrinsic value of exercises |  | $ | 15 |  |  | $ | 5 |  |
| Proceeds received from exercises |  | $ | 13 |  |  | $ | 6 |  |
| Fair value of options vested |  | $ | 1 |  |  | $ | 3 |  |

[0001564590-18-022123:notes:122]
[same as prior period, unchanged from 0001564590-18-002876:notes:97]

[0001564590-18-022123:notes:123]
In the three months ended July 27, 2018, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria, in addition to the service based vesting criteria, such that the PBRSUs cliff-vest at the end of an approximate three year performance period, which began on the date specified in the grant agreements and ends the last day of fiscal 2021. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the current quarter, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of fiscal 2021. The fair values of these awards were fixed at grant date using a Monte Carlo simulation model. For the remaining PBRSUs granted, the number of shares issued will depend upon our achievement against a cumulative Adjusted Operating Income (AOI) target, as defined in the grant agreements, for the three year period from fiscal 2019 through 2021. The fair values of these awards were established consistent with our methodology for valuing time-based RSUs, while compensation cost is being recognized based on the probable outcome of the performance condition. The aggregate compensation cost associated with all PBRSUs granted in the current quarter was $22 million, which is being recognized over the remaining applicable performance / service periods.

[0001564590-18-022123:notes:124]
[same as prior period, unchanged from 0001564590-18-002876:notes:99]

[0001564590-18-022123:notes:125]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 27, 2018 |  |  | 9 |  |  | $ | 32.91 |  |
| Granted |  |  | 3 |  |  | $ | 62.42 |  |
| Vested |  |  | (3 | ) |  | $ | 31.34 |  |
| Forfeited |  |  | (1 | ) |  | $ | 31.62 |  |
| Outstanding as of July 27, 2018 |  |  | 8 |  |  | $ | 43.43 |  |

[0001564590-18-022123:notes:126]
[same as prior period, unchanged from 0001564590-18-002876:notes:101]

[0001564590-18-022123:notes:127]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 84 |  |  | $ | 57 |  |

[0001564590-18-022123:notes:128]
[same as prior period, unchanged from 0001564590-18-002876:notes:103]

[0001564590-18-022123:notes:129]
[same as prior period, unchanged from 0001564590-18-002876:notes:104]

[0001564590-18-022123:notes:130]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Shares issued under the ESPP |  |  | 2 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 49 |  |  | $ | 42 |  |

[0001564590-18-022123:notes:131]
[same as prior period, unchanged from 0001564590-18-002876:notes:106]

[0001564590-18-022123:notes:132]
[same as prior period, unchanged from 0001564590-18-002876:notes:107]

[0001564590-18-022123:notes:133]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |
| Cost of hardware maintenance and other services revenues |  |  | 3 |  |  |  | 3 |  |
| Sales and marketing |  |  | 17 |  |  |  | 21 |  |
| Research and development |  |  | 12 |  |  |  | 15 |  |
| General and administrative |  |  | 7 |  |  |  | 8 |  |
| Total stock-based compensation expense |  | $ | 40 |  |  | $ | 48 |  |
| Income tax benefit for stock-based compensation expense |  | $ | 5 |  |  | $ | 9 |  |

[0001564590-18-022123:notes:134]
As of July 27, 2018, total unrecognized compensation expense related to our equity awards was $362 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.5 years.

[0001564590-18-022123:notes:135]
[same as prior period, unchanged from 0001564590-18-002876:notes:110]

[0001564590-18-022123:notes:136]
Our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management.

[0001564590-18-022123:notes:137]
The following table summarizes activity related to this program for the three months ended July 27, 2018 (in millions, except per share amounts):

[0001564590-18-022123:notes:138]
| Number of shares repurchased |  |  | 7 |  |
| Average price per share |  | $ | 74.37 |  |
| Aggregate purchase price |  | $ | 500 |  |
| Remaining authorization at end of period |  | $ | 3,500 |  |

[0001564590-18-022123:notes:139]
The aggregate purchase price of our stock repurchases for the three months ended July 27, 2018 consisted of $500 million of open market purchases, of which $277 million and $223 million were allocated to additional paid-in capital and retained earnings (accumulated deficit), respectively.

[0001564590-18-022123:notes:140]
Since the May 13, 2003 inception of our stock repurchase program through July 27, 2018, we repurchased a total of 291 million shares of our common stock at an average price of $34.79 per share, for an aggregate purchase price of $10.1 billion.

[0001564590-18-022123:notes:141]
[same as prior period, unchanged from 0001564590-18-002876:notes:116]

[0001564590-18-022123:notes:142]
[same as prior period, unchanged from 0001564590-18-002876:notes:117]

[0001564590-18-022123:notes:143]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Dividends per share declared |  | $ | 0.40 |  |  | $ | 0.20 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 105 |  |  | $ | — |  |
| Dividend payments allocated to retained earnings (accumulated deficit) |  | $ | — |  |  | $ | 54 |  |

[0001564590-18-022123:notes:144]
On August 15, 2018, we declared a cash dividend of $0.40 per share of common stock, payable on October 24, 2018 to holders of record as of the close of business on October 5, 2018. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-18-022123:notes:145]
[same as prior period, unchanged from 0001564590-18-002876:notes:120]

[0001564590-18-022123:notes:146]
[same as prior period, unchanged from 0001564590-18-002876:notes:121]

[0001564590-18-022123:notes:147]
| Balance as of April 27, 2018 |  | $ | (9 | ) |
| Cumulative-effect of new accounting principle |  |  | (51 | ) |
| Net income |  |  | 283 |  |
| Repurchases of common stock |  |  | (223 | ) |
| Balance as of July 27, 2018 |  | $ | — |  |

[0001564590-18-022123:notes:148]
In the three months ended July 27, 2018, we adopted an ASU that eliminates the deferred tax effects of intra-entity asset transfers other than inventory and recorded the cumulative-effect of adoption to retained earnings (accumulated deficit). Refer to Note 1 – Description of Business and Significant Accounting Policies for details.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-18-022123:notes:149]
[same as prior period, unchanged from 0001564590-18-002876:notes:128]

[0001564590-18-022123:notes:150]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of our agreements with them. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of July 27, 2018 or April 27, 2018. We did not recognize any gains or losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-18-022123:notes:151]
[same as prior period, unchanged from 0001564590-18-002876:notes:130]

[0001564590-18-022123:notes:152]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Forward contracts sold |  | $ | 129 |  |  | $ | 115 |  |
| Forward contracts purchased |  | $ | 119 |  |  | $ | 412 |  |

[0001564590-18-022123:notes:153]
As of July 27, 2018 and April 27, 2018, there were no instruments designated as cash flow hedges outstanding.

[0001564590-18-022123:notes:154]
The effect of derivative instruments not designated as hedging instruments recognized in other income, net on our condensed consolidated statements of operations was as follows (in millions):

[0001564590-18-022123:notes:155]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
|  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 10 |  |  | $ | (2 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-18-022123:notes:156]
[same as prior period, unchanged from 0001564590-18-002876:notes:136]

[0001564590-18-022123:notes:157]
During the three months ended July 27, 2018, we announced a restructuring plan (the May 2018 Plan) to reduce costs and redirect resources to our highest return activities, which included a reduction in our global workforce of less than 2%. Charges related to the plan consisted primarily of employee severance-related costs. We expect to complete the May 2018 Plan by the second quarter of fiscal 2019 with no significant additional charges incurred.

[0001564590-18-022123:notes:158]
Management previously approved the November 2016 Plan, under which we reduced our global workforce by approximately 6%. We completed all workforce related activities under this plan as of the end of fiscal 2017. The remaining balance as of July 27, 2018 principally relates to lease obligations that will be paid over their remaining terms.

[0001564590-18-022123:notes:159]
[same as prior period, unchanged from 0001564590-18-002876:notes:138]

[0001564590-18-022123:notes:160]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
|  |  | May 2018 Plan |  |  | November 2016 Plan |  |  | Total |  |  | November 2016 Plan |  |
| Balance at beginning of period |  | $ | — |  |  | $ | 6 |  |  | $ | 6 |  |  | $ | 13 |  |
| Net charges |  |  | 19 |  |  |  | — |  |  |  | 19 |  |  |  | — |  |
| Cash payments |  |  | (9 | ) |  |  | (1 | ) |  |  | (10 | ) |  |  | (4 | ) |
| Balance at end of period |  | $ | 10 |  |  | $ | 5 |  |  | $ | 15 |  |  | $ | 9 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-022123:notes:161]
[same as prior period, unchanged from 0001564590-18-002876:notes:140]

[0001564590-18-022123:notes:162]
[same as prior period, unchanged from 0001564590-18-002876:notes:141]

[0001564590-18-022123:notes:163]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Effective tax rates |  |  | (4.0 | )% |  |  | 9.7 | % |

[0001564590-18-022123:notes:164]
Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations which are headquartered in the Netherlands, being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory tax rate. The differences in effective tax rates for the three months ended July 27, 2018 and July 28, 2017 were primarily related to the adoption of the new revenue standard and differences in discrete benefits for stock-based compensation.

[0001564590-18-022123:notes:165]
The effective tax rate for the three months ended July 28, 2017 has been restated to reflect the retrospective application of the new revenue standard. During the three months ended July 27, 2018, we recognized a $34 million discrete tax benefit for adjustments to certain intercompany transactions resulting from the retrospective application of the new standard. See Note 6 – Revenue for additional details.

[0001564590-18-022123:notes:166]
On December 22, 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, the imposition of a one-time transition tax on deferred foreign earnings, and the creation of new taxes on certain foreign-sourced earnings. As of July 27, 2018, we have not fully completed the accounting for the tax impacts of the TCJA. No significant adjustments to prior period estimates or positions have been made in the current period. The provisional amounts recorded are based on reasonable estimates and our current interpretation and understanding of the TCJA. The final impacts of U.S. tax reform may differ, possibly materially, due to factors such as the issuance of further regulatory guidance, changes in interpretations, and the collection and analysis of additional information. The Company is also still evaluating the effects of the TCJA’s global minimum tax on intangible low-taxed income (“GMT”) and has not yet made an accounting policy election to either account for the tax under a period cost method or a deferred method. For the first quarter of fiscal 2019, we have accounted for the GMT under a period cost method as we continue to evaluate potential impacts. In accordance with Staff Accounting Bulletin 118, we will complete the accounting of the tax effects of the TCJA within the measurement period not to extend beyond one year from the enactment date.

[0001564590-18-022123:notes:167]
As of July 27, 2018, we had $351 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $301 million would affect our provision for income taxes if recognized, and $319 million has been recorded in other long-term liabilities.

[0001564590-18-022123:notes:168]
[same as prior period, unchanged from 0001564590-18-002876:notes:152]

[0001564590-18-022123:notes:169]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for such withholding tax and filed an appeal with the Danish Tax Tribunal. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012. In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). Parties were heard before the court in October 2017. During March 2018, the Advocate General issued an opinion which was largely in favor of NetApp, however, the CJEU is not bound by the opinion of the Advocate General. It is expected that the preliminary ruling will be issued during our fiscal year 2019. Once a ruling has been issued by the CJEU, it will be reviewed and may be subjected to additional briefing by the DHC. Once complete, the DHC will issue its final decision.  We expect this decision to be complete during our fiscal year 2019 or 2020.

[0001564590-18-022123:notes:170]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. As a result of uncertainties regarding tax audits and their possible outcomes, an estimate of the range of possible impacts to unrecognized tax benefits in the next twelve months cannot be made at this time.


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-022123:notes:171]
14. Net Income per Share

[0001564590-18-022123:notes:172]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0001564590-18-022123:notes:173]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 283 |  |  | $ | 131 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 262 |  |  |  | 270 |  |
| Dilutive impact of employee equity award plans |  |  | 7 |  |  |  | 8 |  |
| Shares used in diluted computation |  |  | 269 |  |  |  | 278 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.08 |  |  | $ | 0.49 |  |
| Diluted |  | $ | 1.05 |  |  | $ | 0.47 |  |

[0001564590-18-022123:notes:174]
No potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculation for the three months ended July 27, 2018. For the three months ended July 28, 2017, 2 million potential shares from outstanding awards were excluded from the calculation as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-022123:notes:175]
[same as prior period, unchanged from 0001564590-18-002876:notes:159]

[0001564590-18-022123:notes:176]
[same as prior period, unchanged from 0001564590-18-002876:notes:160]

[0001564590-18-022123:notes:177]
[same as prior period, unchanged from 0001564590-18-002876:notes:161]

[0001564590-18-022123:notes:178]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| United States, Canada and Latin America (Americas) |  | $ | 843 |  |  | $ | 721 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 430 |  |  |  | 401 |  |
| Asia Pacific (APAC) |  |  | 201 |  |  |  | 199 |  |
| Net revenues |  | $ | 1,474 |  |  | $ | 1,321 |  |

[0001564590-18-022123:notes:179]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $761 million and $639 million during the three months ended July 27, 2018 and July 28, 2017, respectively.

[0001564590-18-022123:notes:180]
[same as prior period, unchanged from 0001564590-18-002876:notes:164]

[0001564590-18-022123:notes:181]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| U.S. |  | $ | 553 |  |  | $ | 853 |  |
| International |  |  | 4,258 |  |  |  | 4,538 |  |
| Total |  | $ | 4,811 |  |  | $ | 5,391 |  |

[0001564590-18-022123:notes:182]
[same as prior period, unchanged from 0001564590-18-002876:notes:166]

[0001564590-18-022123:notes:183]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| U.S. |  | $ | 581 |  |  | $ | 566 |  |
| International |  |  | 187 |  |  |  | 190 |  |
| Total |  | $ | 768 |  |  | $ | 756 |  |

[0001564590-18-022123:notes:184]
[same as prior period, unchanged from 0001564590-18-002876:notes:168]

[0001564590-18-022123:notes:185]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 23 | % |
| Tech Data Corporation |  |  | 17 | % |  |  | 20 | % |

[0001564590-18-022123:notes:186]
The following customers accounted for 10% or more of accounts receivable in at least one of the periods presented:

[0001564590-18-022123:notes:187]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Arrow Electronics, Inc. |  |  | 16 | % |  |  | 17 | % |
| Tech Data Corporation |  |  | 9 | % |  |  | 17 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-022123:notes:188]
16. Commitments and Contingencies

[0001564590-18-022123:notes:189]
Operating Leases

[0001564590-18-022123:notes:190]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $184 million as of July 27, 2018.

[0001564590-18-022123:notes:191]
Purchase Orders and Other Commitments

[0001564590-18-022123:notes:192]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 27, 2018, we had $382 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 27, 2018 and April 27, 2018, such liability amounted to $22 million and $14 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-18-022123:notes:193]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 27, 2018, we had $5 million in construction related obligations and $195 million in other purchase obligations.

[0001564590-18-022123:notes:194]
Financing Guarantees

[0001564590-18-022123:notes:195]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $30 million and $31 million of receivables during the three months ended July 27, 2018 and July 28, 2017, respectively.

[0001564590-18-022123:notes:196]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-18-022123:notes:197]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of July 27, 2018 and April 27, 2018, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-18-022123:notes:198]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 27, 2018, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-18-022123:notes:199]
Legal Contingencies

[0001564590-18-022123:notes:200]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-18-022123:notes:201]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-18-022123:notes:202]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of July 27, 2018 related to such matters.
