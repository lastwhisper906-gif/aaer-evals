# NTAP MD&A — 0001564590-18-022123


## mdna

[0001564590-18-022123:mdna:1]
[same as prior period, unchanged from 0001564590-18-002876:mdna:1]

[0001564590-18-022123:mdna:2]
[same as prior period, unchanged from 0001564590-18-002876:mdna:3]

[0001564590-18-022123:mdna:3]
[same as prior period, unchanged from 0001564590-18-002876:mdna:4]

[0001564590-18-022123:mdna:4]
We are the data authority for the hybrid cloud. Digital transformation remains top of mind for executives. In order to successfully digitally transform, data must become the lifeblood of an organization and be used as a business accelerator. Data-driven digital transformations accelerate business outcomes. Together with our partners, we empower global organizations to unleash the full potential of their data to enable new customer touchpoints, create innovative business opportunities and optimize operations.

[0001564590-18-022123:mdna:5]
NetApp delivers a Data Fabric built for the data-driven world. Our Data Fabric simplifies and integrates data management across clouds and on-premises to accelerate digital transformation, enabling our customers to manage, secure and protect their data at the scale needed to accommodate the exponential data growth of the digital world. It delivers integrated data management services and applications for data visibility and insights, data access and control, and data protection and security.

[0001564590-18-022123:mdna:6]
We focus on delivering an exceptional customer experience to become our customers’ preferred data partner. NetApp’s unique approach to managing data holistically enables organizations to inspire innovation with the cloud, build clouds to accelerate new services, and modernize IT architecture with cloud-connected flash.

[0001564590-18-022123:mdna:7]
With NetApp products and solutions, customers can:

[0001564590-18-022123:mdna:8]
|  | • | Continually fuel business growth by delivering data-rich customer experiences through new application deployments that easily use data and services regardless of where they reside or in what form. |

[0001564590-18-022123:mdna:9]
|  | • | Accelerate digital transformation by developing a next-generation, cloud-architected infrastructure that manages data and services as one integrated resource supporting both public and private clouds. |

[0001564590-18-022123:mdna:10]
|  | • | Free the resources necessary to fund transformation by deploying the industry’s leading flash storage solution, which is highly efficient and scales from the edge to the core to the cloud. |

[0001564590-18-022123:mdna:11]
Customers are attracted by the speed and scale benefits of the public cloud but need new data management capabilities to keep control of data as it moves beyond the walls of the enterprise. NetApp believes the hybrid cloud is fast becoming the dominant model for enterprise IT. Whether an organization is targeting an all-cloud, hybrid cloud, or multi-cloud strategy, NetApp Cloud Data Services accelerate the time it takes to deploy or develop an application by making the data requirements seamless to the application layer.

[0001564590-18-022123:mdna:12]
Budget constraints and skill imbalances lead our customers to seek help in integrating, deploying and managing the solutions they need to stay competitive. This drives demand for converged and hyper-converged infrastructure solutions. FlexPod is the converged infrastructure of choice for many of the largest enterprises around the globe. Customers can break free from the limits of first-generation HCI with NetApp HCI and attain guaranteed performance with high levels flexibility, scale, automation, and integration with the Data Fabric.

[0001564590-18-022123:mdna:13]
Flash plays a key role in customers’ digital transformation efforts as they seek to gain advantage through greater speed, responsiveness and value from key business applications - all while lowering total cost of ownership. All-flash array technology is the de facto choice for primary application workloads as customers seek performance and economic benefits from replacing hard disk installations. With a highly differentiated and broad portfolio of all-flash and hybrid array offerings, NetApp is well positioned to enable customers to accomplish this transition.

[0001564590-18-022123:mdna:14]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. Strategic solutions include Clustered ONTAP, branded E-Series, SolidFire, converged and hyper-converged infrastructure, enterprise software license agreements (ELAs) and other optional add-on software products. Mature solutions include 7-mode ONTAP, add-on hardware and related operating system (OS) software and original equipment manufacturers (OEM) products. Both our Mature and Strategic product lines include a mix of disk, hybrid and all flash storage media.

[0001564590-18-022123:mdna:15]
Additionally, we provide a variety of services including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training to help customers most effectively manage their data. Revenues generated by our Cloud Data Services offerings are included in software maintenance revenues.

[0001564590-18-022123:mdna:16]
[same as prior period, unchanged from 0001564590-18-002876:mdna:41]

[0001564590-18-022123:mdna:17]
[same as prior period, unchanged from 0001564590-18-002876:mdna:14]

[0001564590-18-022123:mdna:18]
[same as prior period, unchanged from 0001564590-18-002876:mdna:15]

[0001564590-18-022123:mdna:19]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Net revenues |  | $ | 1,474 |  |  | $ | 1,321 |  |
| Gross profit |  | $ | 963 |  |  | $ | 824 |  |
| Gross profit margin percentage |  |  | 65 | % |  |  | 62 | % |
| Income from operations |  | $ | 254 |  |  | $ | 140 |  |
| Income from operations as a percentage of net revenues |  |  | 17 | % |  |  | 11 | % |
| Net income |  | $ | 283 |  |  | $ | 131 |  |
| Diluted net income per share |  | $ | 1.05 |  |  | $ | 0.47 |  |
| Operating cash flows |  | $ | 326 |  |  | $ | 250 |  |

[0001564590-18-022123:mdna:20]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,260 |  |  | $ | 3,363 |  |
| Cash conversion cycle (days) |  |  | (20 | ) |  |  | (14 | ) |

[0001564590-18-022123:mdna:21]
[same as prior period, unchanged from 0001564590-18-002876:mdna:18]

[0001564590-18-022123:mdna:22]
During the first quarter of fiscal 2019, we repurchased 7 million shares of our common stock at an average price of $74.37 per share, for an aggregate of $500 million. We also declared cash dividends of $0.40 per share in that period, for which we paid an aggregate of $105 million.

[0001564590-18-022123:mdna:23]
Adoption of Revenue Accounting Standard

[0001564590-18-022123:mdna:24]
As of the beginning of fiscal 2019, we adopted the new accounting standard Revenue from Contracts with Customers (ASC 606) using the full retrospective method of adoption. Accordingly, our prior period condensed consolidated financial statements and supplementary data, as presented herein, have been restated to conform to the new rules. As illustrated in Note 6 – Revenue of the Notes to Condensed Consolidated Financial Statements, the overall impact of adoption was not significant to prior periods. However, application of the new rules to our ELAs resulted in approximately $90 million of product revenues for such arrangements in the first three months of fiscal 2019 that are incremental to the amount we would have recognized under the old standard. Under ASC 606, we recognize the software license fee component of our ELAs up-front, whereas under the prior rules the software license fee was recognized over the term of the ELA.

[0001564590-18-022123:mdna:25]
Restructuring Event

[0001564590-18-022123:mdna:26]
During the first quarter of fiscal 2019, we announced a restructuring and reduction in workforce to reduce costs and redirect resources to our highest return activities. In connection with this action, we reduced our worldwide headcount by less than 2%, and incurred aggregate charges of approximately $19 million, consisting primarily of employee severance costs.

[0001564590-18-022123:mdna:27]
[same as prior period, unchanged from 0001564590-18-002876:mdna:27]

[0001564590-18-022123:mdna:28]
[same as prior period, unchanged from 0001564590-18-002876:mdna:28]

[0001564590-18-022123:mdna:29]
The summary of our significant accounting policies is included under Item 7 – Management’s Discussion and Analysis of Financial Condition and Results of Operations of our fiscal 2018 Form 10-K. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. There have been no material changes to the critical accounting policies and estimates as filed in such report, except with respect to revenue recognition as a result of the adoption of ASC 606 in the first quarter of fiscal 2019. Refer to Note 6 – Revenue of the Notes to Condensed Consolidated Financial Statements for details.

[0001564590-18-022123:mdna:30]
[same as prior period, unchanged from 0001564590-18-002876:mdna:55]

[0001564590-18-022123:mdna:31]
[same as prior period, unchanged from 0001564590-18-002876:mdna:31]

[0001564590-18-022123:mdna:32]
[same as prior period, unchanged from 0001564590-18-002876:mdna:32]

[0001564590-18-022123:mdna:33]
[same as prior period, unchanged from 0001564590-18-002876:mdna:33]

[0001564590-18-022123:mdna:34]
Our fiscal year is reported as a 52- or 53-week year that ends on the last Friday in April. Fiscal years 2019 and 2018 are each 52-week years, with 13 weeks in each of their quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0001564590-18-022123:mdna:35]
[same as prior period, unchanged from 0001564590-18-002876:mdna:35]

[0001564590-18-022123:mdna:36]
|  |  | Three Months Ended |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product |  |  | 59 |  | % |  | 55 |  | % |
| Software maintenance |  |  | 16 |  |  |  | 17 |  |  |
| Hardware maintenance and other services |  |  | 25 |  |  |  | 28 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 27 |  |  |  | 28 |  |  |
| Cost of software maintenance |  |  | — |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 7 |  |  |  | 9 |  |  |
| Gross profit |  |  | 65 |  |  |  | 62 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 28 |  |  |  | 32 |  |  |
| Research and development |  |  | 14 |  |  |  | 15 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | 1 |  |  |  | — |  |  |
| Total operating expenses |  |  | 48 |  |  |  | 52 |  |  |
| Income from operations |  |  | 17 |  |  |  | 11 |  |  |
| Other income, net |  |  | 1 |  |  |  | — |  |  |
| Income before income taxes |  |  | 18 |  |  |  | 11 |  |  |
| Provision (benefit) for income taxes |  |  | (1 | ) |  |  | 1 |  |  |
| Net income |  |  | 19 |  | % |  | 10 |  | % |

[0001564590-18-022123:mdna:37]
[same as prior period, unchanged from 0001564590-18-002876:mdna:37]

[0001564590-18-022123:mdna:38]
[same as prior period, unchanged from 0001564590-18-002876:mdna:38]

[0001564590-18-022123:mdna:39]
[same as prior period, unchanged from 0001564590-18-002876:mdna:39]

[0001564590-18-022123:mdna:40]
Net revenues for the first quarter fiscal 2019 were $1,474 million, reflecting an increase of $153 million, or 12%, compared to the corresponding period of the prior year, primarily reflecting higher product revenues.

[0001564590-18-022123:mdna:41]
Gross profit as a percentage of net revenues for the first quarter of fiscal 2019 increased by three percentage points, compared to the corresponding period in fiscal 2018, reflecting higher margins on product revenues. Gross profit margins on product revenues increased six percentage points in the first quarter of fiscal 2019 compared to the first quarter of fiscal 2018, primarily reflecting high margins on revenue recognized during the current quarter related to the software license components of several ELAs, and, to a lesser extent, higher average selling prices (ASPs).

[0001564590-18-022123:mdna:42]
Sales and marketing, research and development, and general and administrative expenses for the first quarter of fiscal 2019 totaled $690 million. This represented 47% of net revenues, a decrease of five percentage points compared to the first quarter of fiscal 2018, primarily due to higher net revenues in the current quarter.

[0001564590-18-022123:mdna:43]
[same as prior period, unchanged from 0001564590-18-002876:mdna:74]

[0001564590-18-022123:mdna:44]
[same as prior period, unchanged from 0001564590-18-002876:mdna:44]

[0001564590-18-022123:mdna:45]
|  |  |  | Three Months Ended |  |
|  |  |  | July 27, 2018 |  |  | July 28, 2017 |  |  | % Change |  |
| Net revenues |  |  | $ | 1,474 |  |  | $ | 1,321 |  |  |  | 12 | % |

[0001564590-18-022123:mdna:46]
The increase in net revenues for the first quarter of fiscal 2019 compared to the corresponding period of fiscal 2018 was primarily due to an increase in product revenues of $148 million. Product revenues as a percentage of net revenues increased four percentage points in the first quarter of fiscal 2019 compared to the corresponding period of fiscal 2018.

[0001564590-18-022123:mdna:47]
[same as prior period, unchanged from 0001564590-18-002876:mdna:47]

[0001564590-18-022123:mdna:48]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 23 | % |
| Tech Data Corporation |  |  | 17 | % |  |  | 20 | % |

[0001564590-18-022123:mdna:49]
[same as prior period, unchanged from 0001564590-18-002876:mdna:49]

[0001564590-18-022123:mdna:50]
|  |  |  | Three Months Ended |  |
|  |  |  | July 27, 2018 |  |  | July 28, 2017 |  |  | % Change |  |
| Product revenues |  |  | $ | 875 |  |  | $ | 727 |  |  |  | 20 | % |

[0001564590-18-022123:mdna:51]
Product revenues are derived through the sale of our strategic and mature solutions, and consist of sales of configured systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, OEM products, ELAs and add-on hardware and software.

[0001564590-18-022123:mdna:52]
Product revenues from strategic solutions represented 70% of product revenues in the first quarter of fiscal 2019, compared to 69% in the corresponding period of the prior year. Product revenues from mature solutions represented 30% of product revenues in the first quarter of fiscal 2019, compared to 31% in the corresponding period of the prior year.

[0001564590-18-022123:mdna:53]
Total product revenues from strategic solutions totaled $612 million in the first quarter of fiscal 2019 reflecting a 23% increase from $498 million in the first quarter of fiscal 2018. This increase was primarily due to over $90 million of current quarter revenues from the software license component of several ELAs, which, under ASC 606, were recognized up-front. There were no comparable ELAs in the first quarter of fiscal 2018. An increase in ASP, driven by the sales of our All-Flash FAS products, also contributed to the increase in revenues in the current quarter.

[0001564590-18-022123:mdna:54]
Total product revenue from mature solutions totaled $263 million in the first quarter of fiscal 2019, an increase of 15% from $229 million in in the first quarter of fiscal 2018, attributable to a 17% increase in add-on hardware, storage and related OS revenues and a 49% increase in OEM revenues. As of the first quarter of fiscal 2019, we are no longer selling 7-mode systems, reflecting the movement of customers to our newer products.

[0001564590-18-022123:mdna:55]
[same as prior period, unchanged from 0001564590-18-002876:mdna:57]

[0001564590-18-022123:mdna:56]
|  |  |  | Three Months Ended |  |
|  |  |  | July 27, 2018 |  |  | July 28, 2017 |  |  | % Change |  |
| Software maintenance revenues |  |  | $ | 229 |  |  | $ | 223 |  |  |  | 3 | % |

[0001564590-18-022123:mdna:57]
[same as prior period, unchanged from 0001564590-18-002876:mdna:59]

[0001564590-18-022123:mdna:58]
[same as prior period, unchanged from 0001564590-18-002876:mdna:60]

[0001564590-18-022123:mdna:59]
[same as prior period, unchanged from 0001564590-18-002876:mdna:91]

[0001564590-18-022123:mdna:60]
[same as prior period, unchanged from 0001564590-18-002876:mdna:61]

[0001564590-18-022123:mdna:61]
|  |  |  | Three Months Ended |  |
|  |  |  | July 27, 2018 |  |  | July 28, 2017 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  |  | $ | 370 |  |  | $ | 371 |  |  |  | — | % |

[0001564590-18-022123:mdna:62]
[same as prior period, unchanged from 0001564590-18-002876:mdna:63]

[0001564590-18-022123:mdna:63]
Hardware maintenance contract revenues were relatively flat year over year, at $303 million for the first quarter of fiscal 2019, compared to $298 million for the corresponding period of the prior year.

[0001564590-18-022123:mdna:64]
Professional services and educational and training services revenues were $67 million for the first quarter of fiscal 2019, compared to $73 million for the corresponding period of the prior year.

[0001564590-18-022123:mdna:65]
[same as prior period, unchanged from 0001564590-18-002876:mdna:66]

[0001564590-18-022123:mdna:66]
|  |  | Three Months Ended |  |
|  |  | July 27, 2018 |  |  | July 28, 2017 |  |
| United States, Canada and Latin America (Americas) |  |  | 57 | % |  |  | 55 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 29 | % |  |  | 30 | % |
| Asia Pacific (APAC) |  |  | 14 | % |  |  | 15 | % |

[0001564590-18-022123:mdna:67]
[same as prior period, unchanged from 0001564590-18-002876:mdna:68]

[0001564590-18-022123:mdna:68]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Our geographic distribution of revenues as a percentage of net revenues was relatively consistent in the first quarter of fiscal 2019 compared to the first quarter of fiscal 2018.

[0001564590-18-022123:mdna:69]
[same as prior period, unchanged from 0001564590-18-002876:mdna:70]

[0001564590-18-022123:mdna:70]
[same as prior period, unchanged from 0001564590-18-002876:mdna:71]

[0001564590-18-022123:mdna:71]
[same as prior period, unchanged from 0001564590-18-002876:mdna:72]

[0001564590-18-022123:mdna:72]
|  |  |  | Three Months Ended |  |
|  |  |  | July 27, 2018 |  |  | July 28, 2017 |  |  | % Change |  |
| Cost of product revenues |  |  | $ | 398 |  |  | $ | 376 |  |  |  | 6 | % |

[0001564590-18-022123:mdna:73]
[same as prior period, unchanged from 0001564590-18-002876:mdna:75]

[0001564590-18-022123:mdna:74]
|  |  |  | Three Months Ended |  |
|  |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  |  | Percentage Change Points |  |
| Materials costs |  |  |  | 4 |  |
| Excess and obsolete inventory |  |  |  | 1 |  |
| Other |  |  |  | 1 |  |
| Total change |  |  |  | 6 |  |

[0001564590-18-022123:mdna:75]
Cost of product revenues represented 45% of product revenues for the first quarter of fiscal 2019, compared to 52% for the first quarter of fiscal 2018. Materials costs represented 87% of product costs for the first quarter of fiscal 2019, compared to 88% in the first quarter of fiscal 2018.

[0001564590-18-022123:mdna:76]
Materials costs increased $16 million in the first quarter of fiscal 2019, compared to the corresponding period of the prior year, primarily due to higher unit volumes of All-Flash FAS products.

[0001564590-18-022123:mdna:77]
Average unit materials costs for Clustered ONTAP systems increased by 15% in the first quarter of fiscal 2019 compared to the corresponding period of the prior year.

[0001564590-18-022123:mdna:78]
The benefit of high margins on revenue recognized during the current quarter related to the software license components of several ELAs, and an increase in ASP for strategic systems, resulting in higher margins for strategic solutions in the first quarter of fiscal 2019 compared to the first quarter of fiscal 2018. Margins for mature products were relatively consistent in the first quarter of fiscal 2019 compared to the corresponding period of the prior year.

[0001564590-18-022123:mdna:79]
[same as prior period, unchanged from 0001564590-18-002876:mdna:82]

[0001564590-18-022123:mdna:80]
|  |  |  | Three Months Ended |  |
|  |  |  | July 27, 2018 |  |  | July 28, 2017 |  |  | % Change |  |
| Cost of software maintenance revenues |  |  | $ | 7 |  |  | $ | 7 |  |  |  | — | % |

[0001564590-18-022123:mdna:81]
Cost of software maintenance revenues was relatively flat in the first quarter of fiscal 2019 compared to the corresponding period of fiscal 2018 and represented 3% of software maintenance revenues for both periods.

[0001564590-18-022123:mdna:82]
[same as prior period, unchanged from 0001564590-18-002876:mdna:85]

[0001564590-18-022123:mdna:83]
|  |  |  | Three Months Ended |  |
|  |  |  | July 27, 2018 |  |  | July 28, 2017 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  |  | $ | 106 |  |  | $ | 114 |  |  |  | (7 | )% |

[0001564590-18-022123:mdna:84]
Cost of hardware maintenance and other services revenues decreased by $8 million, or 7%, for the first quarter of fiscal 2019 compared to the first quarter of fiscal 2018, primarily due to the favorable impact of cost savings initiatives. Costs represented 29% of hardware maintenance and other services revenues in the first quarter of fiscal 2019, compared to 31% in the first quarter of fiscal 2018.

[0001564590-18-022123:mdna:85]
[same as prior period, unchanged from 0001564590-18-002876:mdna:88]

[0001564590-18-022123:mdna:86]
[same as prior period, unchanged from 0001564590-18-002876:mdna:89]

[0001564590-18-022123:mdna:87]
[same as prior period, unchanged from 0001564590-18-002876:mdna:90]

[0001564590-18-022123:mdna:88]
Total compensation costs included in operating expenses increased by $5 million, or 1% in the first quarter of fiscal 2019 compared to the corresponding period in the prior year, primarily reflecting higher salaries as a result of merit increases, partially offset by lower stock-based compensation expense. Average headcount was relatively consistent in both periods.

[0001564590-18-022123:mdna:89]
[same as prior period, unchanged from 0001564590-18-002876:mdna:94]

[0001564590-18-022123:mdna:90]
|  |  |  | Three Months Ended |  |
|  |  |  | July 27, 2018 |  |  | July 28, 2017 |  |  | % Change |  |
| Sales and marketing expenses |  |  | $ | 409 |  |  | $ | 423 |  |  |  | (3 | )% |

[0001564590-18-022123:mdna:91]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, allocated facilities and information technology (IT) costs, advertising and marketing promotional expense and travel and entertainment expense.  The changes in sales and marketing expenses consisted of the following:

[0001564590-18-022123:mdna:92]
|  |  |  | Three Months Ended |  |
|  |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  |  | Percentage Change Points |  |
| Compensation costs |  |  |  | (1 | ) |
| Facilities and IT support costs |  |  |  | (2 | ) |
| Total change |  |  |  | (3 | ) |

[0001564590-18-022123:mdna:93]
The decrease in compensation costs for the first quarter of fiscal 2019 compared to the corresponding period in the prior year reflects a 2% decrease in average headcount and lower stock-based compensation expense, partially offset by higher average salaries, reflecting merit increases. Facilities and IT support costs decreased during the first quarter of fiscal 2019 compared to the corresponding period in the prior year primarily due to cost containment efforts. Commissions expense was relatively consistent in both quarters.

[0001564590-18-022123:mdna:94]
[same as prior period, unchanged from 0001564590-18-002876:mdna:118]

[0001564590-18-022123:mdna:95]
[same as prior period, unchanged from 0001564590-18-002876:mdna:99]

[0001564590-18-022123:mdna:96]
|  |  |  | Three Months Ended |  |
|  |  |  | July 27, 2018 |  |  | July 28, 2017 |  |  | % Change |  |
| Research and development expenses |  |  | $ | 208 |  |  | $ | 193 |  |  |  | 8 | % |

[0001564590-18-022123:mdna:97]
[same as prior period, unchanged from 0001564590-18-002876:mdna:101]

[0001564590-18-022123:mdna:98]
|  |  |  | Three Months Ended |  |
|  |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  |  | Percentage Change Points |  |
| Compensation costs |  |  |  | 6 |  |
| Development projects and outside services |  |  |  | 3 |  |
| Depreciation |  |  |  | (1 | ) |
| Total change |  |  |  | 8 |  |

[0001564590-18-022123:mdna:99]
The increase in compensation costs for the first quarter of fiscal 2019 compared to the corresponding period in the prior year was attributable to an 8% increase in average headcount and higher average salaries, reflecting merit increases, partially offset by lower stock-based compensation expense. Development projects and outside services increased as a result of higher spending on materials and services associated with engineering activities to develop new products and enhance existing products. Depreciation expense decreased primarily due to certain equipment becoming fully depreciated.

[0001564590-18-022123:mdna:100]
[same as prior period, unchanged from 0001564590-18-002876:mdna:105]

[0001564590-18-022123:mdna:101]
|  |  |  | Three Months Ended |  |
|  |  |  | July 27, 2018 |  |  | July 28, 2017 |  |  | % Change |  |
| General and administrative expenses |  |  | $ | 73 |  |  | $ | 68 |  |  |  | 7 | % |

[0001564590-18-022123:mdna:102]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and allocated facilities and IT support costs. The increase in the first quarter of fiscal 2019 compared to the same period in the prior year was primarily due higher spending levels on projects and outside services, and an increase in spending on IT projects.  Compensation costs were relatively consistent in both quarters.

[0001564590-18-022123:mdna:103]
[same as prior period, unchanged from 0001564590-18-002876:mdna:110]

[0001564590-18-022123:mdna:104]
|  |  |  | Three Months Ended |
|  |  |  | July 27, 2018 |  |  | July 28, 2017 |  |  | % Change |
| Restructuring charges |  |  | $ | 19 |  |  | $ | — |  |  | NM |

[0001564590-18-022123:mdna:105]
[same as prior period, unchanged from 0001564590-18-002876:mdna:112]

[0001564590-18-022123:mdna:106]
During the three months ended July 27, 2018, we announced a restructuring plan (the May 2018 Plan) to reduce costs and redirect resources to our highest return activities, which included a reduction in our global workforce of less than 2%. Charges related to the plan consisted primarily of employee severance-related costs. We expect to complete the May 2018 Plan by the second quarter of fiscal 2019 with no significant additional charges incurred. See Note 12 – Restructuring Charges of the Notes to Condensed Consolidated Financial Statements for more details.

[0001564590-18-022123:mdna:107]
Other Income, Net (in millions, except percentages)

[0001564590-18-022123:mdna:108]
The components of other income, net were as follows:

[0001564590-18-022123:mdna:109]
|  |  |  | Three Months Ended |  |
|  |  |  | July 27, 2018 |  |  | July 28, 2017 |  |  | % Change |  |
| Interest income |  |  | $ | 25 |  |  | $ | 16 |  |  |  | 56 | % |
| Interest expense |  |  |  | (14 | ) |  |  | (13 | ) |  |  | 8 | % |
| Other income, net |  |  |  | 7 |  |  |  | 2 |  |  |  | 250 | % |
| Total |  |  | $ | 18 |  |  | $ | 5 |  |  |  | 260 | % |

[0001564590-18-022123:mdna:110]
Interest income increased in the first quarter of fiscal 2019 compared to the corresponding period of the prior year, primarily due to a shift in our investment portfolio to higher-yielding investments.

[0001564590-18-022123:mdna:111]
Provision (Benefit) for Income Taxes (in millions, except percentages):

[0001564590-18-022123:mdna:112]
|  |  |  | Three Months Ended |
|  |  |  | July 27, 2018 |  |  | July 28, 2017 |  |  | % Change |
| Provision (benefit) for income taxes |  |  | $ | (11 | ) |  | $ | 14 |  |  | NM |

[0001564590-18-022123:mdna:113]
Our effective tax rate for the first quarter of fiscal 2019 was -4.0% compared to an effective tax rate of 9.7% for the first quarter of fiscal 2018. Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations which are headquartered in the Netherlands, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rate decreased for the first quarter of fiscal 2019 compared to the corresponding period in the prior year primarily due to the recognition of a $34 million discrete tax benefit for adjustments to certain intercompany transactions resulting from the retrospective application of the new revenue standard, and increased discrete benefits for stock-based compensation.

[0001564590-18-022123:mdna:114]
On December 22, 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, the imposition of a one-time transition tax on deferred foreign earnings, and the creation of new taxes on certain foreign-sourced earnings. As of July 27, 2018, we have not fully completed the accounting for the tax impacts of the TCJA. No significant adjustments to prior period estimates or positions have been made in the current period. The provisional amounts recorded are based on reasonable estimates and our current interpretation and understanding of the TCJA. The final impacts of U.S. tax reform may differ, possibly materially, due to factors such as the issuance of further regulatory guidance, changes in interpretations, and the collection and analysis of additional information. The Company is also still evaluating the effects of the TCJA’s global minimum tax on intangible low-taxed income (“GMT”) and has not yet made an accounting policy election to either account for the tax under a period cost method or a deferred method. For the first quarter of fiscal 2019, we have accounted for the GMT under a period cost method as we continue to evaluate potential impacts. In accordance with Staff Accounting Bulletin 118, we will complete the accounting of the tax effects of the TCJA within the measurement period not to extend beyond one year from the enactment date.

[0001564590-18-022123:mdna:115]
As of July 27, 2018, we had $351 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $301 million would affect our provision for income taxes if recognized, and $319 million has been recorded in other long-term liabilities.

[0001564590-18-022123:mdna:116]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. As a result of uncertainties regarding tax audits and their possible outcomes, an estimate of the range of possible impacts to unrecognized tax benefits in the next twelve months cannot be made at this time.

[0001564590-18-022123:mdna:117]
[same as prior period, unchanged from 0001564590-18-002876:mdna:131]

[0001564590-18-022123:mdna:118]
| (In millions, except percentages) |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Cash, cash equivalents and short-term investments |  | $ | 4,811 |  |  | $ | 5,391 |  |
| Principal amount of debt |  | $ | 1,750 |  |  | $ | 1,935 |  |

[0001564590-18-022123:mdna:119]
[same as prior period, unchanged from 0001564590-18-002876:mdna:134]

[0001564590-18-022123:mdna:120]
|  |  | Three Months Ended |  |
| (In millions) |  | July 27, 2018 |  |  | July 28, 2017 |  |
| Net cash provided by operating activities |  | $ | 326 |  |  | $ | 250 |  |
| Net cash provided by investing activities |  |  | 186 |  |  |  | 53 |  |
| Net cash provided by (used in) financing activities |  |  | (812 | ) |  |  | 181 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (14 | ) |  |  | 19 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | (314 | ) |  | $ | 503 |  |

[0001564590-18-022123:mdna:121]
[same as prior period, unchanged from 0001564590-18-002876:mdna:136]

[0001564590-18-022123:mdna:122]
As of July 27, 2018, our cash, cash equivalents and short-term investments were $4.8 billion, a decrease of $0.6 billion from April 27, 2018. The decrease was primarily due to $500 million paid for the repurchase of our common stock, $105 million used for the payment of dividends, $185 million used for the net repayment of commercial paper notes, and $64 million in purchases of property and equipment, partially offset by $326 million of cash provided by operating activities. Working capital decreased by $0.4 billion to $3.0 billion as of July 27, 2018 compared to April 27, 2018 primarily due to a decrease in accounts receivable, and decreases in cash, cash equivalents and short-term investments as discussed above, partially offset by decreases in accounts payable and accrued expenses.

[0001564590-18-022123:mdna:123]
[same as prior period, unchanged from 0001564590-18-002876:mdna:138]

[0001564590-18-022123:mdna:124]
[same as prior period, unchanged from 0001564590-18-002876:mdna:139]

[0001564590-18-022123:mdna:125]
|  |  | Three Months Ended |  |
| (In days) |  | July 27, 2018 |  |  | April 27, 2018 |  |  | July 28, 2017 |  |
| Days sales outstanding (1) |  |  | 38 |  |  |  | 58 |  |  |  | 37 |  |
| Days inventory outstanding (2) |  |  | 17 |  |  |  | 18 |  |  |  | 25 |  |
| Days payables outstanding (3) |  |  | (76 | ) |  |  | (90 | ) |  |  | (53 | ) |
| Cash conversion cycle (4) |  |  | (20 | ) |  |  | (14 | ) |  |  | 8 |  |

[0001564590-18-022123:mdna:126]
[same as prior period, unchanged from 0001564590-18-002876:mdna:141]

[0001564590-18-022123:mdna:127]
| (1) | Days sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on ending accounts receivable and net revenue for each period. DSO is calculated by dividing accounts receivable by average net revenue per day for the current quarter (91 days for each of the quarters presented above). DSO for the first quarter of fiscal 2019 was relatively consistent with the corresponding period of fiscal 2018, while it decreased compared to the fourth quarter of fiscal 2018 due to lower seasonal invoicing levels and more favorable shipping linearity. |

[0001564590-18-022123:mdna:128]
| (2) | Days inventory outstanding, referred to as DIO, measures the average number of days from procurement to sale of our products. DIO is based on ending inventory and cost of revenues for each period. DIO is calculated by dividing ending inventory by average cost of revenues per day for the current quarter. DIO for the first quarter of fiscal 2019 was relatively consistent with the fourth quarter of 2018, while it decreased compared to the corresponding period of fiscal 2018, primarily due to lower levels of purchased components on hand at the end of the current quarter. |

[0001564590-18-022123:mdna:129]
| (3) | Days payables outstanding, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and cost of revenues for each period. DPO is calculated by dividing accounts payable by average cost of revenues per day for the current quarter. DPO for the first quarter of fiscal 2019 increased compared to the corresponding period of fiscal 2018, primarily as a result of improved vendor payables management and an extension of payment terms with our suppliers. DPO for the first quarter of fiscal 2019 decreased compared to the fourth quarter of 2018, primarily due to the timing of purchases from contract manufacturers. |

[0001564590-18-022123:mdna:130]
[same as prior period, unchanged from 0001564590-18-002876:mdna:145]

[0001564590-18-022123:mdna:131]
[same as prior period, unchanged from 0001564590-18-002876:mdna:146]

[0001564590-18-022123:mdna:132]
During the first quarter of fiscal 2019, we generated cash from operating activities of $326 million, reflecting net income of $283 million, adjusted by non-cash depreciation and amortization of $49 million, and stock-based compensation of $40 million, compared to $250 million of cash generated from operating activities during the first quarter of fiscal 2018.

[0001564590-18-022123:mdna:133]
Changes in assets and liabilities in the first quarter of fiscal 2019 included the following:

[0001564590-18-022123:mdna:134]
|  | • | Accounts receivable decreased $423 million, reflecting lower DSO. |

[0001564590-18-022123:mdna:135]
|  | • | Accounts payable decreased $117 million, reflecting lower DPO. |

[0001564590-18-022123:mdna:136]
|  | • | Accrued expenses decreased $221 million, primarily due to employee compensation payouts related to fiscal year 2018 commissions and incentive compensation plans |

[0001564590-18-022123:mdna:137]
[same as prior period, unchanged from 0001564590-18-002876:mdna:152]

[0001564590-18-022123:mdna:138]
[same as prior period, unchanged from 0001564590-18-002876:mdna:153]

[0001564590-18-022123:mdna:139]
During the first quarter of fiscal 2019, we generated $248 million from maturities and sales of investments, net of purchases, and paid $64 million for capital expenditures, compared to $112 million and $36 million, respectively, during the first quarter of fiscal 2018.

[0001564590-18-022123:mdna:140]
[same as prior period, unchanged from 0001564590-18-002876:mdna:155]

[0001564590-18-022123:mdna:141]
During the first quarter of fiscal 2019, we used $500 million for the repurchase of seven million shares of our common stock, $105 million for the payment of dividends, and $185 million for the repayment of commercial paper notes, net, compared to $150 million used for the repurchase of four million shares of common stock, $54 million used for the payment of dividends, and $394 million generated from issuances of commercial paper notes, net, during the first quarter of fiscal 2018.

[0001564590-18-022123:mdna:142]
[same as prior period, unchanged from 0001564590-18-002876:mdna:157]

[0001564590-18-022123:mdna:143]
[same as prior period, unchanged from 0001564590-18-002876:mdna:158]

[0001564590-18-022123:mdna:144]
Our principal sources of liquidity as of July 27, 2018 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001564590-18-022123:mdna:145]
[same as prior period, unchanged from 0001564590-18-002876:mdna:160]

[0001564590-18-022123:mdna:146]
|  |  | July 27, 2018 |  |  | April 27, 2018 |  |
| Cash and cash equivalents |  | $ | 2,627 |  |  | $ | 2,941 |  |
| Short-term investments |  |  | 2,184 |  |  |  | 2,450 |  |
| Total |  | $ | 4,811 |  |  | $ | 5,391 |  |

[0001564590-18-022123:mdna:147]
As of July 27, 2018 and April 27, 2018, $4.3 billion and $4.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.5 billion and $0.9 billion, respectively, were available in the U.S. at the end of each period. The TCJA imposes a one-time transition tax on substantially all accumulated foreign earnings through December 31, 2017, and generally allows companies to make distributions of foreign earnings without incurring additional federal taxes. As a part of the provisional estimates recorded for the impacts of the TCJA, we have reviewed our projected global cash requirements and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested.

[0001564590-18-022123:mdna:148]
Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies, service interest and principal payments on our debt, fund our stock repurchase program, and pay dividends, as and if declared.

[0001564590-18-022123:mdna:149]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of July 27, 2018.

[0001564590-18-022123:mdna:150]
[same as prior period, unchanged from 0001564590-18-002876:mdna:165]

[0001564590-18-022123:mdna:151]
[same as prior period, unchanged from 0001564590-18-002876:mdna:166]

[0001564590-18-022123:mdna:152]
The following table summarizes the principal amount of our Senior Notes as of July 27, 2018 (in millions):

[0001564590-18-022123:mdna:153]
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| Total |  | $ | 1,550 |  |

[0001564590-18-022123:mdna:154]
[same as prior period, unchanged from 0001564590-18-002876:mdna:169]

[0001564590-18-022123:mdna:155]
Commercial Paper Program and Credit Facility

[0001564590-18-022123:mdna:156]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of July 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $200 million, a weighted-average interest rate of 2.28% and maturities ranging from 14 days to 31 days.

[0001564590-18-022123:mdna:157]
In connection with the Program, we have a senior unsecured credit agreement that expires on December 10, 2021. The credit agreement provides a $1.0 billion revolving unsecured credit facility that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes, providing another potential source of liquidity to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement also includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of July 27, 2018, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-18-022123:mdna:158]
[same as prior period, unchanged from 0001564590-18-002876:mdna:173]

[0001564590-18-022123:mdna:159]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2019 to be between $100 million and $150 million.

[0001564590-18-022123:mdna:160]
[same as prior period, unchanged from 0001564590-18-002876:mdna:175]

[0001564590-18-022123:mdna:161]
On August 15, 2018, we declared a cash dividend of $0.40 per share of common stock, payable on October 24, 2018 to holders of record as of the close of business on October 5, 2018.

[0001564590-18-022123:mdna:162]
Our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through July 27, 2018, we repurchased a total of 291 million shares of our common stock at an average price of $34.79 per share, for an aggregate purchase price of $10.1 billion. As of July 27, 2018, the remaining authorized amount for stock repurchases under this program was $3.5 billion.

[0001564590-18-022123:mdna:163]
[same as prior period, unchanged from 0001564590-18-002876:mdna:178]

[0001564590-18-022123:mdna:164]
[same as prior period, unchanged from 0001564590-18-002876:mdna:179]

[0001564590-18-022123:mdna:165]
[same as prior period, unchanged from 0001564590-18-002876:mdna:180]

[0001564590-18-022123:mdna:166]
As of July 27, 2018, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $184 million.

[0001564590-18-022123:mdna:167]
[same as prior period, unchanged from 0001564590-18-002876:mdna:191]

[0001564590-18-022123:mdna:168]
[same as prior period, unchanged from 0001564590-18-002876:mdna:182]

[0001564590-18-022123:mdna:169]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 27, 2018, we had $382 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-18-022123:mdna:170]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of July 27, 2018, we had $5 million in construction related obligations and $195 million in other purchase obligations.

[0001564590-18-022123:mdna:171]
[same as prior period, unchanged from 0001564590-18-002876:mdna:185]

[0001564590-18-022123:mdna:172]
As of July 27, 2018, our liability for uncertain tax positions was $319 million, including interest, penalties and offsetting indirect benefits. Due to uncertainties regarding tax audits and their possible outcomes, we are unable to make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-18-022123:mdna:173]
[same as prior period, unchanged from 0001564590-18-002876:mdna:189]

[0001564590-18-022123:mdna:174]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $30 million and $31 million of receivables during the first quarter of fiscal 2018 and fiscal 2017, respectively.

[0001564590-18-022123:mdna:175]
[same as prior period, unchanged from 0001564590-18-002876:mdna:192]

[0001564590-18-022123:mdna:176]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of July 27, 2018 and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-18-022123:mdna:177]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of July 27, 2018, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-18-022123:mdna:178]
[same as prior period, unchanged from 0001564590-18-002876:mdna:195]

[0001564590-18-022123:mdna:179]
[same as prior period, unchanged from 0001564590-18-002876:mdna:196]

[0001564590-18-022123:mdna:180]
Legal Contingencies

[0001564590-18-022123:mdna:181]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 16 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0001564590-18-022123:mdna:182]
38
