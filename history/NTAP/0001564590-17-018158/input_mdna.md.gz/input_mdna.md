# NTAP MD&A — 0001564590-17-018158


## mdna

[0001564590-17-018158:mdna:1]
[same as prior period, unchanged from 0001564590-17-002845:mdna:1]

[0001564590-17-018158:mdna:2]
[same as prior period, unchanged from 0001564590-17-002845:mdna:2]

[0001564590-17-018158:mdna:3]
[same as prior period, unchanged from 0001564590-17-002845:mdna:3]

[0001564590-17-018158:mdna:4]
We are the data authority for hybrid cloud environments. We provide a full range of hybrid cloud data services that simplify management of applications and data across cloud and on-premises environments to accelerate digital transformations. Together with our partners, we empower global organizations to unleash the full potential of their data to expand customer touchpoints, foster greater innovation, and optimize their operations.

[0001564590-17-018158:mdna:5]
Our Data Fabric approach simplifies and integrates data management across cloud and on-premises to accelerate digital transformation, enabling our customers to manage, secure and protect their data from on-premises to public to hybrid clouds, all at the scale needed to accommodate the exponential data growth of the digital world. It delivers consistent and integrated data management services and applications for data visibility and insights, data access and control, and data protection and security.

[0001564590-17-018158:mdna:6]
We focus on delivering an exceptional customer experience to become their preferred data partner. Our products and solutions portfolio empowers customers to harness the power of the hybrid cloud, build a next-generation data center, and modernize storage through data management. We will continue to extend our cloud integration and hybrid cloud leadership by expanding our product offerings and services to match customer needs across the cloud and on-premises.

[0001564590-17-018158:mdna:7]
Our unified scale-out fabric-attached storage (FAS) platform is designed to meet the demanding requirements of shared infrastructures and cloud environments. Our FAS storage platform uses the NetApp Data ONTAP storage operating system to deliver integrated data protection, comprehensive data management, and built-in efficiency software for virtualized, shared infrastructures, cloud computing, and mixed workload business applications. Our E-Series high-performance storage area network platform is designed to meet demanding performance and capacity requirements of dedicated workloads, while retaining simplicity and an optimized price to performance ratio. Our SolidFire All-Flash Arrays deliver fully automated agility and guaranteed application performance at web scale so customers can achieve the next-generation data center.

[0001564590-17-018158:mdna:8]
Flash plays a key role in customers’ digital transformation efforts as they seek to gain advantage through greater speed, responsiveness and value from key business applications, while lowering total cost of ownership. All-flash array technology is the de facto choice for primary application workloads as customers seek performance and economic benefits by replacing hard disk installations. With our all-flash array portfolio, including our AFF-Series, EF-Series and SolidFire SF-Series products, we enable customers to modernize storage and data management to boost performance in their traditional data centers, while mapping out their move to a hybrid cloud.

[0001564590-17-018158:mdna:9]
Our hybrid flash storage serves customers who want the option to deploy the speed of flash storage where they need it while using more affordable hard disk drives to address capacity requirements. Our hybrid arrays include the FAS series of unified storage systems and the E-Series of block storage offerings.

[0001564590-17-018158:mdna:10]
We group our products by “Strategic” and “Mature” solutions. Strategic solutions include Clustered ONTAP, branded E-Series, SolidFire, AltaVault and optional add-on software products. Mature solutions include 7-mode OnTap, add-on hardware and related operating system (OS) software and original equipment manufacturers (OEM) products. Both our Mature and Strategic product lines include a mix of disk, hybrid and all flash storage media.

[0001564590-17-018158:mdna:11]
In addition to our products, we provide a variety of services including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training to help customers most effectively manage their data.

[0001564590-17-018158:mdna:12]
[same as prior period, unchanged from 0001564590-17-002845:mdna:7]

[0001564590-17-018158:mdna:13]
The following table provides an overview of some of our key financial metrics (in millions, except per share amounts, percentages and cash conversion cycle):

[0001564590-17-018158:mdna:14]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Net revenues |  | $ | 1,325 |  |  | $ | 1,294 |  |
| Gross profit |  | $ | 834 |  |  | $ | 797 |  |
| Gross profit margin percentage |  |  | 63 | % |  |  | 62 | % |
| Income from operations |  | $ | 148 |  |  | $ | 93 |  |
| Income from operations as a percentage of net revenues |  |  | 11 | % |  |  | 7 | % |
| Net income |  | $ | 136 |  |  | $ | 64 |  |
| Diluted net income per share |  | $ | 0.49 |  |  | $ | 0.23 |  |
| Operating cash flows |  | $ | 250 |  |  | $ | 228 |  |

[0001564590-17-018158:mdna:15]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,251 |  |  | $ | 3,342 |  |
| Cash conversion cycle (days) |  |  | 9 |  |  |  | 15 |  |

[0001564590-17-018158:mdna:16]
Stock Repurchase Program and Dividend Activity

[0001564590-17-018158:mdna:17]
During the first quarter of fiscal 2018, we repurchased 4 million shares of our common stock at an average price of $40.56 per share, for an aggregate of $150 million. We also declared cash dividends of $0.20 per share in that period, for which we paid an aggregate of $54 million.

[0001564590-17-018158:mdna:18]
[same as prior period, unchanged from 0001564590-17-002845:mdna:16]

[0001564590-17-018158:mdna:19]
[same as prior period, unchanged from 0001564590-17-002845:mdna:17]

[0001564590-17-018158:mdna:20]
The summary of our significant accounting policies is included under Item 7 – Management’s Discussion and Analysis of Financial Condition and Results of Operations of our fiscal 2017 Form 10-K. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. There have been no material changes to the critical accounting policies and estimates as filed in such report.

[0001564590-17-018158:mdna:21]
[same as prior period, unchanged from 0001564590-17-002845:mdna:19]

[0001564590-17-018158:mdna:22]
[same as prior period, unchanged from 0001564590-17-002845:mdna:20]

[0001564590-17-018158:mdna:23]
[same as prior period, unchanged from 0001564590-17-002845:mdna:21]

[0001564590-17-018158:mdna:24]
Our fiscal year is reported as a 52- or 53-week year that ends on the last Friday in April. Fiscal years 2018 and 2017, ending April 27, 2018 and April 28, 2017, are each 52-week years, with 13 weeks in each of their quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0001564590-17-018158:mdna:25]
24

[0001564590-17-018158:mdna:26]
[same as prior period, unchanged from 0001564590-17-002845:mdna:23]

[0001564590-17-018158:mdna:27]
|  |  | Three Months Ended |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product |  |  | 55 |  | % |  | 51 |  | % |
| Software maintenance |  |  | 18 |  |  |  | 19 |  |  |
| Hardware maintenance and other services |  |  | 28 |  |  |  | 30 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 28 |  |  |  | 28 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 9 |  |  |  | 10 |  |  |
| Gross profit |  |  | 63 |  |  |  | 62 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 32 |  |  |  | 33 |  |  |
| Research and development |  |  | 15 |  |  |  | 16 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |
| Total operating expenses |  |  | 52 |  |  |  | 54 |  |  |
| Income from operations |  |  | 11 |  |  |  | 7 |  |  |
| Other income (expense), net |  |  | — |  |  |  | — |  |  |
| Income before income taxes |  |  | 12 |  |  |  | 7 |  |  |
| Provision for income taxes |  |  | 1 |  |  |  | 2 |  |  |
| Net income |  |  | 10 |  | % |  | 5 |  | % |

[0001564590-17-018158:mdna:28]
[same as prior period, unchanged from 0001564590-17-002845:mdna:25]

[0001564590-17-018158:mdna:29]
[same as prior period, unchanged from 0001564590-17-002845:mdna:26]

[0001564590-17-018158:mdna:30]
[same as prior period, unchanged from 0001564590-17-002845:mdna:27]

[0001564590-17-018158:mdna:31]
Net revenues for the first quarter of fiscal 2018 were $1,325 million, an increase of $31 million, or 2% compared to the corresponding period of the prior year, reflecting higher product revenues, partially offset by lower hardware maintenance and other services revenues.

[0001564590-17-018158:mdna:32]
Gross profit as a percentage of net revenues for the first quarter of fiscal 2018 increased one percentage point compared to the first quarter of fiscal 2017, reflecting higher margins on product revenues, substantially offset by lower margins on software maintenance and hardware maintenance and other services revenues. Gross profit margins on product revenues in the first quarter of fiscal 2018 increased four percentage points compared to the first quarter of fiscal 2017, primarily due to an increase in average selling price (ASP), partially offset by higher overall average unit materials costs.

[0001564590-17-018158:mdna:33]
Sales and marketing, research and development, and general and administrative expenses for the first quarter of fiscal 2018 totaled $686 million, or 52% of net revenues, a decrease of two percentage points compared to the first quarter of fiscal 2017, primarily due to a lower average headcount as a result of our restructuring plans and other cost reduction initiatives.

[0001564590-17-018158:mdna:34]
[same as prior period, unchanged from 0001564590-17-002845:mdna:31]

[0001564590-17-018158:mdna:35]
|  |  |  | Three Months Ended |  |
|  |  |  | July 28, 2017 |  |  | July 29, 2016 |  |  | % Change |  |
| Net revenues |  |  | $ | 1,325 |  |  | $ | 1,294 |  |  |  | 2 | % |

[0001564590-17-018158:mdna:36]
The increase in net revenues for the first quarter of fiscal 2018 compared to the first quarter of fiscal 2017 was primarily due to an increase of $63 million in product revenues, partially offset by a decrease of $25 million in hardware maintenance and other services revenues. Product revenues as a percentage of net revenues increased four percentage points in the first quarter of fiscal 2018 compared to the first quarter of fiscal 2017.

[0001564590-17-018158:mdna:37]
[same as prior period, unchanged from 0001564590-17-002845:mdna:35]

[0001564590-17-018158:mdna:38]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 20 | % |
| Tech Data Corporation (previously presented as Avnet, Inc.) |  |  | 20 | % |  |  | 19 | % |

[0001564590-17-018158:mdna:39]
[same as prior period, unchanged from 0001564590-17-002845:mdna:37]

[0001564590-17-018158:mdna:40]
|  |  |  | Three Months Ended |  |
|  |  |  | July 28, 2017 |  |  | July 29, 2016 |  |  | % Change |  |
| Product revenues |  |  | $ | 723 |  |  | $ | 660 |  |  |  | 10 | % |

[0001564590-17-018158:mdna:41]
[same as prior period, unchanged from 0001564590-17-002845:mdna:39]

[0001564590-17-018158:mdna:42]
Product revenues from strategic solutions represented 69% of product revenues in the first quarter of fiscal 2018 compared to 62% in the first quarter of the prior year. Product revenues from mature solutions represented 31% of product revenues in the first quarter of fiscal 2018 compared to 38% in the first quarter of the prior year.

[0001564590-17-018158:mdna:43]
Total product revenues from strategic solutions totaled $500 million in the first quarter of fiscal 2018 reflecting a 22% increase from $411 million in the first quarter of fiscal 2017. This increase was primarily due to an 8% increase in unit volume of Clustered ONTAP systems and an increase in ASP resulting from a mix shift towards All-Flash FAS products. Total product revenue from mature solutions totaled $223 million in the first quarter of fiscal 2018 reflecting a 10% decrease from $249 million in the first quarter of fiscal 2017. This decrease was primarily due to a 62% decrease in unit volume of 7-mode systems reflecting the movement of customer demand from older products to our newer products, and a 27% decrease in OEM revenues, partially offset by an 11% increase in add-on hardware, storage and related OS revenues.

[0001564590-17-018158:mdna:44]
[same as prior period, unchanged from 0001564590-17-002845:mdna:43]

[0001564590-17-018158:mdna:45]
|  |  |  | Three Months Ended |  |
|  |  |  | July 28, 2017 |  |  | July 29, 2016 |  |  | % Change |  |
| Software maintenance revenues |  |  | $ | 234 |  |  | $ | 241 |  |  |  | (3 | )% |

[0001564590-17-018158:mdna:46]
[same as prior period, unchanged from 0001564590-17-002845:mdna:45]

[0001564590-17-018158:mdna:47]
[same as prior period, unchanged from 0001564590-17-002845:mdna:46]

[0001564590-17-018158:mdna:48]
[same as prior period, unchanged from 0001564590-17-002845:mdna:47]

[0001564590-17-018158:mdna:49]
|  |  |  | Three Months Ended |  |
|  |  |  | July 28, 2017 |  |  | July 29, 2016 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  |  | $ | 368 |  |  | $ | 393 |  |  |  | (6 | )% |

[0001564590-17-018158:mdna:50]
[same as prior period, unchanged from 0001564590-17-002845:mdna:49]

[0001564590-17-018158:mdna:51]
Hardware maintenance contract revenues were $298 million for the first quarter of fiscal 2018 compared to $323 million for the corresponding period of the prior year. The decrease in the first quarter of fiscal 2018 was primarily due to lower contract renewal rates, and a decline in ASP on executed contracts.

[0001564590-17-018158:mdna:52]
Professional services and educational and training services revenues were $70 million in each of the first quarters of fiscal 2018 and 2017.

[0001564590-17-018158:mdna:53]
26

[0001564590-17-018158:mdna:54]
[same as prior period, unchanged from 0001564590-17-002845:mdna:52]

[0001564590-17-018158:mdna:55]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| United States, Canada and Latin America (Americas) |  |  | 55 | % |  |  | 57 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 30 | % |  |  | 30 | % |
| Asia Pacific (APAC) |  |  | 15 | % |  |  | 13 | % |

[0001564590-17-018158:mdna:56]
[same as prior period, unchanged from 0001564590-17-002845:mdna:54]

[0001564590-17-018158:mdna:57]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Our percentage of net revenues from the Americas decreased in the first quarter of fiscal 2018 compared to the first quarter of fiscal 2017 due to a decrease in revenues from the Americas commercial market.

[0001564590-17-018158:mdna:58]
[same as prior period, unchanged from 0001564590-17-002845:mdna:57]

[0001564590-17-018158:mdna:59]
[same as prior period, unchanged from 0001564590-17-002845:mdna:58]

[0001564590-17-018158:mdna:60]
[same as prior period, unchanged from 0001564590-17-002845:mdna:59]

[0001564590-17-018158:mdna:61]
|  |  |  | Three Months Ended |  |
|  |  |  | July 28, 2017 |  |  | July 29, 2016 |  |  | % Change |  |
| Cost of product revenues |  |  | $ | 371 |  |  | $ | 359 |  |  |  | 3 | % |

[0001564590-17-018158:mdna:62]
[same as prior period, unchanged from 0001564590-17-002845:mdna:61]

[0001564590-17-018158:mdna:63]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2018 to Fiscal 2017 |  |  |
|  |  | Percentage Change Points |  |  |
| Materials costs |  |  | 1 |  |  |
| Excess and obsolete inventory |  |  | 3 |  |  |
| Other |  |  | (1 | ) |  |
| Total change |  |  | 3 |  |  |

[0001564590-17-018158:mdna:64]
Cost of product revenues represented 51% of product revenues for the first quarter of fiscal 2018 compared to 54% for the first quarter of fiscal 2017. Materials costs represented 88% of product costs for the first quarter of fiscal 2018 compared to 90% in the first quarter of fiscal 2017.

[0001564590-17-018158:mdna:65]
Materials costs increased $2 million in the first quarter of fiscal 2018 compared to the first quarter of fiscal 2017, reflecting a 12% increase in materials costs related to strategic products primarily due to higher unit volume for configured Clustered ONTAP systems, particularly for All-Flash FAS products. This was partially offset by a 19% decrease in materials costs for mature products, reflecting lower volume in 7-Mode systems. Average unit materials costs for Clustered ONTAP systems increased primarily due to changes in product and configuration mix, including a higher percentage of systems sold with solid state (flash) drives in the first quarter of fiscal 2018.

[0001564590-17-018158:mdna:66]
An increase in ASP for strategic systems was only partially offset by an increase in unit materials costs, resulting in higher margins for strategic products in the first quarter of fiscal 2018 compared to the first quarter of fiscal 2017. Average unit materials costs for 7-mode systems decreased, while ASP was relatively flat, resulting in slightly higher margins for mature products in the first quarter of fiscal 2018.

[0001564590-17-018158:mdna:67]
Cost of product revenues in the first quarter of fiscal 2018 compared to the first quarter of fiscal 2017 were unfavorably impacted by a $9 million increase in charges for excess and obsolete inventory, primarily as a result of our transition to new product platforms.

[0001564590-17-018158:mdna:68]
[same as prior period, unchanged from 0001564590-17-002845:mdna:69]

[0001564590-17-018158:mdna:69]
|  |  |  | Three Months Ended |  |
|  |  |  | July 28, 2017 |  |  | July 29, 2016 |  |  | % Change |  |
| Cost of software maintenance revenues |  |  | $ | 7 |  |  | $ | 8 |  |  |  | (13 | )% |

[0001564590-17-018158:mdna:70]
[same as prior period, unchanged from 0001564590-17-002845:mdna:55]

[0001564590-17-018158:mdna:71]
Cost of software maintenance revenues was relatively flat in the first quarter of fiscal 2018 compared to the first quarter of fiscal 2017 and represented 3% of software maintenance revenues for each of those quarters.

[0001564590-17-018158:mdna:72]
[same as prior period, unchanged from 0001564590-17-002845:mdna:72]

[0001564590-17-018158:mdna:73]
|  |  |  | Three Months Ended |  |
|  |  |  | July 28, 2017 |  |  | July 29, 2016 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  |  | $ | 113 |  |  | $ | 130 |  |  |  | (13 | )% |

[0001564590-17-018158:mdna:74]
Cost of hardware maintenance and other services revenues decreased $17 million, or 13% for the first quarter of fiscal 2018 compared to the first quarter of fiscal 2017, primarily due to the favorable impact of cost savings initiatives. Costs represented 31% of hardware maintenance and other services revenues in the first quarter of fiscal 2018 compared to 33% in the first quarter of fiscal 2017.

[0001564590-17-018158:mdna:75]
[same as prior period, unchanged from 0001564590-17-002845:mdna:75]

[0001564590-17-018158:mdna:76]
[same as prior period, unchanged from 0001564590-17-002845:mdna:76]

[0001564590-17-018158:mdna:77]
[same as prior period, unchanged from 0001564590-17-002845:mdna:77]

[0001564590-17-018158:mdna:78]
Total compensation costs included in operating expenses decreased by $19 million, or 5% in the first quarter of fiscal 2018 compared to the corresponding period in the prior year primarily due to lower salaries, benefits, incentive compensation and stock-based compensation expenses, reflecting a 6% decrease in average headcount as a result of cost reduction initiatives.

[0001564590-17-018158:mdna:79]
[same as prior period, unchanged from 0001564590-17-002845:mdna:79]

[0001564590-17-018158:mdna:80]
|  |  |  | Three Months Ended |  |
|  |  |  | July 28, 2017 |  |  | July 29, 2016 |  |  | % Change |  |
| Sales and marketing expenses |  |  | $ | 425 |  |  | $ | 429 |  |  |  | (1 | )% |

[0001564590-17-018158:mdna:81]
[same as prior period, unchanged from 0001564590-17-002845:mdna:81]

[0001564590-17-018158:mdna:82]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2018 to Fiscal 2017 |  |  |
|  |  | Percentage Change Points |  |  |
| Compensation costs |  |  | (1 | ) |  |
| Advertising and marketing promotional expense |  |  | 1 |  |  |
| Facilities and IT support costs |  |  | (2 | ) |  |
| Other |  |  | 1 |  |  |
| Total change |  |  | (1 | ) |  |

[0001564590-17-018158:mdna:83]
The decrease in compensation costs for the first quarter of fiscal 2018 reflects a 2% decrease in average headcount from the corresponding period in the prior year. The increase in advertising and marketing promotional expense was primarily due to higher spending levels on marketing activities for new products in the first quarter of fiscal 2018. Facilities and IT support costs decreased during the first quarter of fiscal 2018 primarily due to cost containment efforts and certain internal-use software becoming fully amortized by the end of fiscal 2017.

[0001564590-17-018158:mdna:84]
[same as prior period, unchanged from 0001564590-17-002845:mdna:85]

[0001564590-17-018158:mdna:85]
|  |  |  | Three Months Ended |  |
|  |  |  | July 28, 2017 |  |  | July 29, 2016 |  |  | % Change |  |
| Research and development expenses |  |  | $ | 193 |  |  | $ | 207 |  |  |  | (7 | )% |

[0001564590-17-018158:mdna:86]
[same as prior period, unchanged from 0001564590-17-002845:mdna:68]

[0001564590-17-018158:mdna:87]
[same as prior period, unchanged from 0001564590-17-002845:mdna:87]

[0001564590-17-018158:mdna:88]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2018 to Fiscal 2017 |  |  |
|  |  | Percentage Change Points |  |  |
| Compensation costs |  |  | (5 | ) |  |
| Depreciation |  |  | (1 | ) |  |
| Facilities and IT support costs |  |  | (1 | ) |  |
| Total change |  |  | (7 | ) |  |

[0001564590-17-018158:mdna:89]
Compensation costs for the first quarter of fiscal 2018 were favorably impacted by lower salaries, benefits costs and incentive compensation expense compared to the corresponding period of the prior year due to a decrease of 10% in average headcount. Depreciation expense decreased primarily due to certain equipment becoming fully depreciated by the end of fiscal 2017. Facilities and IT support costs decreased primarily due to cost containment efforts.

[0001564590-17-018158:mdna:90]
[same as prior period, unchanged from 0001564590-17-002845:mdna:90]

[0001564590-17-018158:mdna:91]
|  |  |  | Three Months Ended |  |
|  |  |  | July 28, 2017 |  |  | July 29, 2016 |  |  | % Change |  |
| General and administrative expenses |  |  | $ | 68 |  |  | $ | 68 |  |  |  | — | % |

[0001564590-17-018158:mdna:92]
[same as prior period, unchanged from 0001564590-17-002845:mdna:92]

[0001564590-17-018158:mdna:93]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2018 to Fiscal 2017 |  |  |
|  |  | Percentage Change Points |  |  |
| Compensation costs |  |  | (9 | ) |  |
| Professional and legal fees and outside services |  |  | 4 |  |  |
| Facilities and IT support costs |  |  | 4 |  |  |
| Other |  |  | 1 |  |  |
| Total change |  |  | — |  |  |

[0001564590-17-018158:mdna:94]
Compensation costs for the first quarter of fiscal 2018 were favorably impacted by lower salaries, benefits and stock-based compensation expenses compared to the first quarter of fiscal 2017 due to a 15% decrease in average headcount. The increase in professional and legal fees and outside services expense in the first quarter of fiscal 2018 was primarily due to higher spending levels on projects and consulting fees, while the increase in facilities and IT support costs was primarily due to an increase in spending on IT projects.

[0001564590-17-018158:mdna:95]
[same as prior period, unchanged from 0001564590-17-002845:mdna:107]

[0001564590-17-018158:mdna:96]
[same as prior period, unchanged from 0001564590-17-002845:mdna:108]

[0001564590-17-018158:mdna:97]
|  |  |  | Three Months Ended |  |
|  |  |  | July 28, 2017 |  |  | July 29, 2016 |  |  | % Change |  |
| Interest income |  |  | $ | 16 |  |  | $ | 11 |  |  |  | 45 | % |
| Interest expense |  |  |  | (13 | ) |  |  | (15 | ) |  |  | (13 | )% |
| Other income, net |  |  |  | 2 |  |  |  | 3 |  |  |  | (33 | )% |
| Total |  |  | $ | 5 |  |  | $ | (1 | ) |  | NM |  |

[0001564590-17-018158:mdna:98]
[same as prior period, unchanged from 0001564590-17-002845:mdna:110]

[0001564590-17-018158:mdna:99]
Interest income increased in the first quarter of fiscal 2018 compared to the corresponding period of the prior year, primarily due to a shift in our investment portfolio to higher-yielding investments.

[0001564590-17-018158:mdna:100]
Interest expense is primarily related to our senior notes, and in the first quarter of fiscal 2017 to interest on the short-term loan that we repaid during that quarter.

[0001564590-17-018158:mdna:101]
[same as prior period, unchanged from 0001564590-17-002845:mdna:113]

[0001564590-17-018158:mdna:102]
|  |  |  | Three Months Ended |  |
|  |  |  | July 28, 2017 |  |  | July 29, 2016 |  |  | % Change |  |
| Provision for income taxes |  |  | $ | 17 |  |  | $ | 28 |  |  |  | (39 | )% |

[0001564590-17-018158:mdna:103]
Our effective tax rate for the first quarter of fiscal 2018 was 11.1% compared to an effective tax rate of 30.4% for the first quarter of fiscal 2017. Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations which are headquartered in the Netherlands, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rate decreased for the first quarter of fiscal 2018 compared to the corresponding period in the prior year, primarily as a result of differences in discrete impacts related to stock-based compensation and differences in the respective periods’ income before taxes.

[0001564590-17-018158:mdna:104]
As of July 28, 2017, we had $220 million of gross unrecognized tax benefits, of which $156 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $161 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-17-018158:mdna:105]
[same as prior period, unchanged from 0001564590-17-002845:mdna:120]

[0001564590-17-018158:mdna:106]
[same as prior period, unchanged from 0001564590-17-002845:mdna:121]

[0001564590-17-018158:mdna:107]
| (In millions, except percentages) |  | July 28, 2017 |  |  | April 28, 2017 |  |
| Cash, cash equivalents and short-term investments |  | $ | 5,321 |  |  | $ | 4,921 |  |
| Principal amount of debt |  | $ | 2,395 |  |  | $ | 2,000 |  |
| Debt as a percentage of stockholders' equity |  |  | 87 | % |  |  | 72 | % |

[0001564590-17-018158:mdna:108]
The following is a summary of our cash flow activities:

[0001564590-17-018158:mdna:109]
|  |  | Three Months Ended |  |
| (In millions) |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Net cash provided by operating activities |  | $ | 250 |  |  | $ | 228 |  |
| Net cash provided by investing activities |  |  | 57 |  |  |  | 276 |  |
| Net cash provided by (used in) financing activities |  |  | 181 |  |  |  | (1,071 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 19 |  |  |  | (7 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 507 |  |  | $ | (574 | ) |

[0001564590-17-018158:mdna:110]
[same as prior period, unchanged from 0001564590-17-002845:mdna:125]

[0001564590-17-018158:mdna:111]
As of July 28, 2017, our cash, cash equivalents and short-term investments were $5.3 billion, an increase of $0.4 billion from April 28, 2017. The increase was primarily due to $394 million in proceeds from the issuance of commercial paper notes, net of repayments, and $250 million of cash provided by operating activities, partially offset by $150 million paid for the repurchase of our common stock and $54 million used for the payment of dividends. Working capital decreased by $65 million to $2.0 billion as of July 28, 2017 compared to April 28, 2017 primarily due to the issuance of commercial paper notes and a decrease in accounts receivable, partially offset by an increase in cash and cash equivalents.

[0001564590-17-018158:mdna:112]
Cash Conversion Cycle

[0001564590-17-018158:mdna:113]
The following table presents the components of our cash conversion cycle:

[0001564590-17-018158:mdna:114]
|  |  | Three Months Ended |  |
| (In days) |  | July 28, 2017 |  |  | April 28, 2017 |  |  | July 29, 2016 |  |
| Days sales outstanding (1) |  |  | 36 |  |  |  | 45 |  |  |  | 35 |  |
| Days inventory outstanding (2) |  |  | 27 |  |  |  | 26 |  |  |  | 15 |  |
| Days payables outstanding (3) |  |  | (54 | ) |  |  | (56 | ) |  |  | (44 | ) |
| Cash conversion cycle (4) |  |  | 9 |  |  |  | 15 |  |  |  | 6 |  |

[0001564590-17-018158:mdna:115]
Days may not add due to rounding

[0001564590-17-018158:mdna:116]
[same as prior period, unchanged from 0001564590-17-002845:mdna:98]

[0001564590-17-018158:mdna:117]
| (1) | Days sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on ending accounts receivable and net revenue for each period. DSO is calculated by dividing accounts receivable by average net revenue per day for the current quarter (91 days for each of the quarters presented above). The decrease in DSO for the first quarter of fiscal 2018 compared to the fourth quarter of fiscal 2017 was due to seasonal patterns of shipping linearity. |

[0001564590-17-018158:mdna:118]
| (2) | Days inventory outstanding, referred to as DIO, measures the average number of days from procurement to sale of our products. DIO is based on ending inventory and cost of revenues for each period. DIO is calculated by dividing ending inventory by average cost of revenues per day for the current quarter. DIO for the first quarter of fiscal 2018 was relatively consistent with the fourth quarter of 2017, while it increased compared to the first quarter of fiscal 2017 due to higher levels of purchased components, primarily solid state drives, on hand at the end of the current quarter. |

[0001564590-17-018158:mdna:119]
| (3) | Days payables outstanding, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and cost of revenues for each period. DPO is calculated by dividing accounts payable by average cost of revenues per day for the current quarter. DPO for the first quarter of fiscal 2018 was relatively unchanged compared to the fourth quarter of 2017, while it increased compared to the corresponding period in fiscal 2017, primarily as a result of improved vendor payables management and an extension of payment terms with our suppliers. |

[0001564590-17-018158:mdna:120]
| (4) | The cash conversion cycle is the sum of DSO and DIO less DPO. Items which may cause the cash conversion cycle in a particular period to differ include, but are not limited to, changes in business mix, changes in payment terms (including extended payment terms from suppliers), the extent of shipment linearity, seasonal trends and the timing of revenue recognition and inventory purchases within the period. |

[0001564590-17-018158:mdna:121]
[same as prior period, unchanged from 0001564590-17-002845:mdna:127]

[0001564590-17-018158:mdna:122]
During the first quarter of fiscal 2018, we generated cash from operating activities of $250 million, reflecting net income of $136 million, adjusted by non-cash depreciation and amortization of $51 million and stock-based compensation of $48 million, compared to $228 million of cash generated from operating activities during the first quarter of fiscal 2017.

[0001564590-17-018158:mdna:123]
Changes in assets and liabilities in the first quarter of fiscal 2018 included the following:

[0001564590-17-018158:mdna:124]
|  | • | Accounts receivable decreased $218 million, primarily due to lower seasonal invoicing levels in the first quarter of fiscal 2018 compared to the fourth quarter of fiscal 2017. |

[0001564590-17-018158:mdna:125]
|  | • | Accrued compensation and benefits decreased $100 million, primarily due to employee compensation payouts related to fiscal year 2017 commissions and incentive compensation plans. |

[0001564590-17-018158:mdna:126]
|  | • | Deferred revenue and financed unearned services revenue decreased $107 million, primarily due to a decrease in deferred software and hardware maintenance contract revenues reflecting lower contract renewal rates and a decline in ASP on executed contracts. |

[0001564590-17-018158:mdna:127]
[same as prior period, unchanged from 0001564590-17-002845:mdna:133]

[0001564590-17-018158:mdna:128]
[same as prior period, unchanged from 0001564590-17-002845:mdna:134]

[0001564590-17-018158:mdna:129]
During the first quarter of fiscal 2018, we generated $112 million from maturities and sales of investments, net of purchases, and paid $36 million for capital expenditures compared to $313 million and $36 million, respectively, during the first quarter of fiscal 2017.

[0001564590-17-018158:mdna:130]
[same as prior period, unchanged from 0001564590-17-002845:mdna:136]

[0001564590-17-018158:mdna:131]
During the first quarter of fiscal 2018, we generated $394 million in cash from issuances of commercial paper notes, net of repayments, and used $150 million for the repurchase of four million shares of our common stock and $54 million for the payment of dividends, compared to $850 million used to repay our short-term loan, $175 million used for the repurchase of common stock and $53 million for the payment of dividends during the first quarter of fiscal 2017.

[0001564590-17-018158:mdna:132]
[same as prior period, unchanged from 0001564590-17-002845:mdna:138]

[0001564590-17-018158:mdna:133]
[same as prior period, unchanged from 0001564590-17-002845:mdna:139]

[0001564590-17-018158:mdna:134]
Our principal sources of liquidity as of July 28, 2017 consisted of cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001564590-17-018158:mdna:135]
[same as prior period, unchanged from 0001564590-17-002845:mdna:141]

[0001564590-17-018158:mdna:136]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
| Cash and cash equivalents |  | $ | 2,951 |  |  | $ | 2,444 |  |
| Short-term investments |  |  | 2,370 |  |  |  | 2,477 |  |
| Total |  | $ | 5,321 |  |  | $ | 4,921 |  |

[0001564590-17-018158:mdna:137]
As of July 28, 2017 and April 28, 2017, $4.9 billion and $4.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.4 billion were available in the U.S. at the end of each period. Most of the amounts held outside the U.S. can be repatriated to the U.S. but, under current law, would be subject to U.S. federal, state income and foreign withholding taxes. If we were to repatriate foreign earnings to fund cash requirements in the U.S., we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state tax credit carryforwards. However, our intent is to keep these funds indefinitely reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, and invest in critical or complementary technologies, and service interest and principal payments on our debt.

[0001564590-17-018158:mdna:138]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of July 28, 2017.

[0001564590-17-018158:mdna:139]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, and other liquidity requirements associated with our operations. We also have an automatic shelf registration statement on file with the Securities and Exchange Commission. We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001564590-17-018158:mdna:140]
[same as prior period, unchanged from 0001564590-17-002845:mdna:148]

[0001564590-17-018158:mdna:141]
The following table summarizes the principal amount of our Senior Notes as of July 28, 2017 (in millions):

[0001564590-17-018158:mdna:142]
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |
| Total |  | $ | 1,500 |  |

[0001564590-17-018158:mdna:143]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 9 – Financing Arrangements of the Notes to Condensed Consolidated Financial Statements.

[0001564590-17-018158:mdna:144]
Commercial Paper Program and Credit Facility

[0001564590-17-018158:mdna:145]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. On July 17, 2017 we amended the Program to increase the maximum amounts available that may be borrowed, repaid and re-borrowed to an aggregate face or principal amount of the notes outstanding of $1.0 billion, as compared to $600 million prior to the amendment. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of July 28, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $895 million, a weighted-average interest rate of 1.45% and maturities ranging from 13 days to 56 days.

[0001564590-17-018158:mdna:146]
In connection with the Program, we have a senior unsecured credit agreement that expires on December 10, 2021. The credit agreement, which was amended on July 17, 2017 provides a $1.0 billion revolving unsecured credit facility that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes, providing another potential source of

[0001564590-17-018158:mdna:147]
32

[0001564590-17-018158:mdna:148]
liquidity to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement also includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of July 28, 2017, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-17-018158:mdna:149]
[same as prior period, unchanged from 0001564590-17-002845:mdna:155]

[0001564590-17-018158:mdna:150]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2018 to be between $125 million and $175 million.

[0001564590-17-018158:mdna:151]
[same as prior period, unchanged from 0001564590-17-002845:mdna:157]

[0001564590-17-018158:mdna:152]
On August 16, 2017, we declared a cash dividend of $0.20 per share of common stock, payable on October 25, 2017 to holders of record as of the close of business on October 6, 2017.

[0001564590-17-018158:mdna:153]
As of July 28, 2017, our Board of Directors had authorized the repurchase of up to $9.6 billion of our common stock under our stock repurchase program. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through July 28, 2017, we repurchased a total of 273 million shares of our common stock at an average price of $32.94 per share, for an aggregate purchase price of $9.0 billion. As of July 28, 2017, the remaining authorized amount for stock repurchases under this program was $0.6 billion, with no termination date, which we plan to complete by May 2018.

[0001564590-17-018158:mdna:154]
[same as prior period, unchanged from 0001564590-17-002845:mdna:160]

[0001564590-17-018158:mdna:155]
[same as prior period, unchanged from 0001564590-17-002845:mdna:161]

[0001564590-17-018158:mdna:156]
[same as prior period, unchanged from 0001564590-17-002845:mdna:162]

[0001564590-17-018158:mdna:157]
As of July 28, 2017, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $212 million.

[0001564590-17-018158:mdna:158]
[same as prior period, unchanged from 0001564590-17-002845:mdna:164]

[0001564590-17-018158:mdna:159]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 28, 2017, we had $295 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-17-018158:mdna:160]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of July 28, 2017, we had $29 million in construction related obligations and $235 million in other purchase obligations.

[0001564590-17-018158:mdna:161]
[same as prior period, unchanged from 0001564590-17-002845:mdna:167]

[0001564590-17-018158:mdna:162]
As of July 28, 2017, our liability for uncertain tax positions was $149 million, including interest, penalties and offsetting indirect benefits. Due to the uncertainty of the timing of future cash payments, we cannot make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-17-018158:mdna:163]
[same as prior period, unchanged from 0001564590-17-002845:mdna:169]

[0001564590-17-018158:mdna:164]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, until such time as the related leases are terminated, the assets will remain on our condensed consolidated balance sheets, and proceeds received by us from these transactions are reported as financing obligations. As of July 28, 2017, the

[0001564590-17-018158:mdna:165]
[same as prior period, unchanged from 0001564590-17-002845:mdna:145]

[0001564590-17-018158:mdna:166]
balance of the remaining financing obligations, which relate to properties whose leases we expect to terminate in December 2017, was $130 million. At the end of the leaseback period, or when our continuing involvement under the leaseback agreement ends, this transaction will be reported as a non-cash sale and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain.

[0001564590-17-018158:mdna:167]
[same as prior period, unchanged from 0001564590-17-002845:mdna:171]

[0001564590-17-018158:mdna:168]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $31 million and $76 million of receivables during the first quarter of fiscal 2018 and fiscal 2017, respectively.

[0001564590-17-018158:mdna:169]
[same as prior period, unchanged from 0001564590-17-002845:mdna:174]

[0001564590-17-018158:mdna:170]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of July 28, 2017 and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-17-018158:mdna:171]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of July 28, 2017, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-17-018158:mdna:172]
[same as prior period, unchanged from 0001564590-17-002845:mdna:177]

[0001564590-17-018158:mdna:173]
[same as prior period, unchanged from 0001564590-17-002845:mdna:178]

[0001564590-17-018158:mdna:174]
Legal Contingencies

[0001564590-17-018158:mdna:175]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 16 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.
