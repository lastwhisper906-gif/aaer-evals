# NTAP note change history — 0001564590-17-002845 → 0001564590-17-018158


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-08-29):
[0001564590-17-018158:note_history:1]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $212 million as of July 28, 2017.
  (was, 2017-02-28, similarity 0.9854):
[0001564590-17-002845:note_history:1]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $227 million as of January 27, 2017.

- changed (2017-08-29):
[0001564590-17-018158:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 28, 2017, we had $295 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 28, 2017 and April 28, 2017, such liability amounted to $13 million and $10 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2017-02-28, similarity 0.9924):
[0001564590-17-002845:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of January 27, 2017, we had $313 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 27, 2017 and April 29, 2016, such liability amounted to $11 million and $7 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2017-08-29):
[0001564590-17-018158:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 28, 2017, we had $29 million in construction related obligations and $235 million in other purchase obligations.
  (was, 2017-02-28, similarity 0.9904):
[0001564590-17-002845:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 27, 2017, we had $20 million in construction related obligations and $220 million in other purchase obligations.

- changed (2017-08-29):
[0001564590-17-018158:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $31 million and $76 million of receivables during the three months ended July 28, 2017 and July 29, 2016, respectively.
  (was, 2017-02-28, similarity 0.9896):
[0001564590-17-002845:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $142 million and $153 million of receivables during the nine months ended January 27, 2017 and January 29, 2016, respectively.

- changed (2017-08-29):
[0001564590-17-018158:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of July 28, 2017 and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2017-02-28, similarity 0.7445):
[0001564590-17-002845:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of January 27, 2017 and April 29, 2016, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- changed (2017-08-29):
[0001564590-17-018158:note_history:6]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 28, 2017, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.
  (was, 2017-02-28, similarity 0.9895):
[0001564590-17-002845:note_history:6]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 27, 2017, we have not been required to make any significant payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- added (2017-08-29):
[0001564590-17-018158:note_history:7]
We are subject to various legal proceedings and claims that arise in the normal course of business. Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends.

- added (2017-08-29):
[0001564590-17-018158:note_history:8]
No accrual has been recorded as of July 28, 2017 related to such matters as they are not probable and reasonably estimable.

- removed (2017-08-29):
[0001564590-17-002845:note_history:9]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of January 27, 2017 related to such matters as they are not probable and/or reasonably estimable.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-08-29):
[0001564590-17-018158:note_history:10]
NetApp, Inc. (we, us, or the Company) provides global organizations the ability to manage and share their data across on-premises, private and public clouds. Together with our partners, we provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.

- changed (2017-08-29):
[0001564590-17-018158:note_history:11]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal years 2018 and 2017, ending on April 27, 2018, and April 28, 2017, respectively, are each 52-week years, with 13 weeks in each of their quarters.
  (was, 2017-02-28, similarity 0.7469):
[0001564590-17-002845:note_history:11]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2017, ending on April 28, 2017, is a 52-week year, with 13 weeks in each of its quarters. Fiscal year 2016, which ended on April 29, 2016, was a 53-week year, with 14 weeks in its first quarter and 13 weeks in each subsequent quarter.

- changed (2017-08-29):
[0001564590-17-018158:note_history:12]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 28, 2017 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 28, 2017 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2017-02-28, similarity 0.9924):
[0001564590-17-002845:note_history:12]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2016 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 27, 2017 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- changed (2017-08-29):
[0001564590-17-018158:note_history:13]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; valuation of investment securities; income taxes and fair value measurements. Actual results could differ materially from those estimates.
  (was, 2017-02-28, similarity 0.927):
[0001564590-17-002845:note_history:13]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

- changed (2017-08-29):
[0001564590-17-018158:note_history:14]
There have been no significant changes in our significant accounting policies as of and for the three months ended July 28, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 28, 2017.
  (was, 2017-02-28, similarity 0.6615):
[0001564590-17-002845:note_history:14]
There have been no other significant changes in our significant accounting policies as of and for the nine months ended January 27, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2016.

- removed (2017-08-29):
[0001564590-17-002845:note_history:15]
NetApp, Inc. (we, us, or the Company) provides software, systems and services to manage and store computer data. We enable enterprises, service providers, governmental organizations, and partners to envision, deploy and evolve their information technology environments and to reduce costs and risk while driving growth and success for their organizations.

- removed (2017-08-29):
[0001564590-17-002845:note_history:16]
Accounting Change – In the first quarter of fiscal 2017, we early adopted a new accounting standards update that the Financial Accounting Standards Board (FASB) issued in March 2016 that simplifies the accounting for certain aspects of stock-based payments to employees. The new standard requires that certain amendments relevant to us be applied using a modified-retrospective transition method by means of a cumulative-effect adjustment to retained earnings as of the beginning of the period in which the guidance is adopted.

- removed (2017-08-29):
[0001564590-17-002845:note_history:17]
In connection with the adoption, we elected to account for forfeitures as they occur and the cumulative-effect impact of that change in accounting policy was a $7 million increase in retained earnings and a corresponding decrease in additional paid-in capital as of April 30, 2016. We also recorded a $3 million cumulative-effect adjustment decrease to retained earnings and a related decrease in deferred tax assets related to the forfeiture rate policy change on outstanding stock-based awards as of April 30, 2016. The standard also eliminates the requirement that excess tax benefits be realized before companies can recognize them. Accordingly, we recorded a $17 million cumulative-effect adjustment increase in retained earnings and an offsetting increase in deferred tax assets for previously unrecognized excess tax benefits as of April 30, 2016.

- removed (2017-08-29):
[0001564590-17-002845:note_history:18]
The new standard eliminated the requirement to report excess tax benefits and certain tax deficiencies related to share-based payment transactions as additional paid-in capital. As a result, we recognized $18 million of tax deficiencies in our provision for income taxes, rather than additional paid–in capital, for the nine months ended January 27, 2017.

- removed (2017-08-29):
[0001564590-17-002845:note_history:19]
We elected to report cash flows related to excess tax benefits on a prospective basis. The presentation requirements for cash flows related to employee taxes paid for withheld shares had no impact to our statements of cash flows since such cash flows have historically been presented as a financing activity.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-29):
[0001564590-17-018158:note_history:20]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (6 | ) |  |  |  |  |  |  | (7 | ) |  |  |  |  |
| Total senior notes |  |  | 1,494 |  |  |  |  |  |  |  | 1,493 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (749 | ) |  |  |  |  |  |  | (749 | ) |  |  |  |  |
| Total long-term debt |  | $ | 745 |  |  |  |  |  |  | $ | 744 |  |  |  |  |  |
  (was, 2017-02-28, similarity 0.9894):
[0001564590-17-002845:note_history:20]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (8 | ) |  |  |  |  |  |  | (10 | ) |  |  |  |  |
| Total senior notes |  |  | 1,492 |  |  |  |  |  |  |  | 1,490 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (748 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 744 |  |  |  |  |  |  | $ | 1,490 |  |  |  |  |  |

- changed (2017-08-29):
[0001564590-17-018158:note_history:21]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 28, 2017, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2017-02-28, similarity 0.9946):
[0001564590-17-002845:note_history:21]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 27, 2017, we were in compliance with all covenants associated with the Senior Notes.

- changed (2017-08-29):
[0001564590-17-018158:note_history:22]
As of July 28, 2017, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2017-02-28, similarity 0.973):
[0001564590-17-002845:note_history:22]
As of January 27, 2017, our aggregate future principal debt maturities are as follows (in millions):

- changed (2017-08-29):
[0001564590-17-018158:note_history:23]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| 2022 |  |  | 500 |  |
| Thereafter |  |  | 250 |  |
| Total |  | $ | 1,500 |  |
  (was, 2017-02-28, similarity 0.9208):
[0001564590-17-002845:note_history:23]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| Thereafter |  |  | 750 |  |
| Total |  | $ | 1,500 |  |

- changed (2017-08-29):
[0001564590-17-018158:note_history:24]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended on July 17, 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of July 28, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $895 million, a weighted-average interest rate of 1.45% and maturities ranging from 13 days to 56 days. As of April 28, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $500 million, a weighted-average interest rate of 1.26% and maturities ranging from 7 days to 38 days.
  (was, 2017-02-28, similarity 0.8727):
[0001564590-17-002845:note_history:24]
In December 2016, we entered into a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $600 million. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes will be used for general corporate purposes. As of January 27, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $392 million, a weighted-average interest rate of 1.10% and maturities ranging from 20 days to 36 days.

- changed (2017-08-29):
[0001564590-17-018158:note_history:25]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended on July 17, 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of July 28, 2017 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.
  (was, 2017-02-28, similarity 0.7413):
[0001564590-17-002845:note_history:25]
In connection with the Program, we entered into a new senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021, and we terminated our existing credit agreement that had been scheduled to expire on December 21, 2017. The new credit agreement provides a $600 million revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of January 27, 2017, no borrowings or letters of credit were outstanding under this facility, and we were in compliance with all associated covenants.

- changed (2017-08-29):
[0001564590-17-018158:note_history:26]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, until such time as the related leases are terminated, the assets will remain on our condensed consolidated balance sheets and proceeds received by us from these transactions are reported as financing obligations. As of July 28, 2017, the balance of the remaining financing obligations, which relate to properties whose leases we expect to terminate in December 2017, was $130 million. At the end of the leaseback period, or when our continuing involvement under the leaseback agreement ends, this transaction will be reported as a non-cash sale and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain.
  (was, 2017-02-28, similarity 0.7913):
[0001564590-17-002845:note_history:26]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, until such time as the related leases are terminated, the assets will remain on our condensed consolidated balance sheets, and proceeds received by us from these transactions are reported as financing obligations. During the three months ended January 27, 2017, we terminated one of the leases, ending our continuing involvement with the related properties. As a result, we recorded a non-cash sale of properties having a net book value of $9 million, the extinguishment of $19 million of associated financing obligations, and a gain of $10 million. As of January 27, 2017, the balance of the remaining financing obligations, which relate to properties whose leases we expect to terminate in December 2017, was $130 million. At the end of the leaseback period, or when our continuing involvement under the leaseback agreement ends, this transaction will be reported as a non-cash sale and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain.

- removed (2017-08-29):
[0001564590-17-002845:note_history:27]
Short-Term Loan

- removed (2017-08-29):
[0001564590-17-002845:note_history:28]
In February 2016, in connection with the SolidFire acquisition, we entered into a short-term loan of $870 million with a maturity of November 2, 2016. As of January 27, 2017, we have repaid the loan in full and have terminated the related loan agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-29):
[0001564590-17-018158:note_history:29]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (6 | ) |  |  |  |  |  |  | (7 | ) |  |  |  |  |
| Total senior notes |  |  | 1,494 |  |  |  |  |  |  |  | 1,493 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (749 | ) |  |  |  |  |  |  | (749 | ) |  |  |  |  |
| Total long-term debt |  | $ | 745 |  |  |  |  |  |  | $ | 744 |  |  |  |  |  |
  (was, 2017-02-28, similarity 0.9894):
[0001564590-17-002845:note_history:29]
|  |  | January 27, 2017 |  |  | April 29, 2016 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (8 | ) |  |  |  |  |  |  | (10 | ) |  |  |  |  |
| Total senior notes |  |  | 1,492 |  |  |  |  |  |  |  | 1,490 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (748 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 744 |  |  |  |  |  |  | $ | 1,490 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-29):
[0001564590-17-018158:note_history:30]
As of July 28, 2017, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2017-02-28, similarity 0.973):
[0001564590-17-002845:note_history:30]
As of January 27, 2017, our aggregate future principal debt maturities are as follows (in millions):

- changed (2017-08-29):
[0001564590-17-018158:note_history:31]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| 2022 |  |  | 500 |  |
| Thereafter |  |  | 250 |  |
| Total |  | $ | 1,500 |  |
  (was, 2017-02-28, similarity 0.9208):
[0001564590-17-002845:note_history:31]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| Thereafter |  |  | 750 |  |
| Total |  | $ | 1,500 |  |
