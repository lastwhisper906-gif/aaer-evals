# NTAP 8-K — 0001564590-17-017768 filed 2017-08-16

## item codes, every 8-K on or before 2017-08-29

- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2017-08-29

- none on or before 2017-08-29

## item 2.02 — earnings release, exhibit 99.1

[0001564590-17-017768:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-17-017768:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-17-017768:8k_2_02:3]
Exhibit 99.1

[0001564590-17-017768:8k_2_02:4]
NETAPP REPORTS FIRST QUARTER FISCAL YEAR 2018 RESULTS

[0001564590-17-017768:8k_2_02:5]
Net Revenues of $1.33 Billion; Up 2% Year-over-Year

[0001564590-17-017768:8k_2_02:6]
| • | Product revenue increased 10% year-over-year |

[0001564590-17-017768:8k_2_02:7]
| • | All-flash array annualized net revenue run rate grew 95% year-over-year |

[0001564590-17-017768:8k_2_02:8]
| • | GAAP EPS of $0.49 and non-GAAP EPS of $0.62; up year-over-year 113% and 35%, respectively |

[0001564590-17-017768:8k_2_02:9]
Sunnyvale, Calif.—August 16, 2017—NetApp (NASDAQ: NTAP) today reported financial results for the first quarter fiscal year 2018, ended July 28, 2017.

[0001564590-17-017768:8k_2_02:10]
First Quarter Financial Results

[0001564590-17-017768:8k_2_02:11]
Net revenues for the first quarter of fiscal year 2018 were $1.33 billion, compared to net revenues of $1.29 billion for the comparable period of the prior year. GAAP net income for the first quarter of fiscal year 2018 was $136 million, or $0.49 per share,1 compared to GAAP net income of $64 million, or $0.23 per share, for the comparable period of the prior year. Non-GAAP net income for the first quarter of fiscal year 2018 was $173 million, or $0.62 per share,2 compared to non-GAAP net income of $129 million, or $0.46 per share, for the comparable period of the prior year.

[0001564590-17-017768:8k_2_02:12]
Cash, Cash Equivalents and Investments

[0001564590-17-017768:8k_2_02:13]
NetApp ended the first quarter of fiscal year 2018 with $5.3 billion in total cash, cash equivalents and investments. During the first quarter of fiscal year 2018, the Company generated $250 million in cash from operations and returned $204 million to shareholders through share repurchases and a cash dividend.

[0001564590-17-017768:8k_2_02:14]
The Company announced the next cash dividend of $0.20 per share. The quarterly dividend will be paid on October 25, 2017, to shareholders of record as of the close of business on October 6, 2017.

[0001564590-17-017768:8k_2_02:15]
“We delivered strong Q1 results across the board and continued to introduce substantial innovation. We are strengthening our leadership position by enhancing our all flash array and converged infrastructure offerings, and augmenting our Data Fabric strategy,” said George Kurian, chief executive officer. “Customers and industry leaders are excited by our strategic direction and are choosing NetApp as their partner for data-driven digital transformations. We are building on a strong foundation and are, without question, the best positioned and the best executing company in the industry.”

[0001564590-17-017768:8k_2_02:16]
Q2 Fiscal Year 2018 Outlook

[0001564590-17-017768:8k_2_02:17]
The Company provided the following financial guidance for the second quarter of fiscal year 2018:

[0001564590-17-017768:8k_2_02:18]
| • | Net revenues are expected to be in the range of $1.31 billion to $1.46 billion |

[0001564590-17-017768:8k_2_02:19]
|  | GAAP | Non-GAAP |
| •Earnings per share is expected to be in the range of: | $0.47 - $0.55 | $0.64 - $0.72 |

[0001564590-17-017768:8k_2_02:20]
Business Highlights

[0001564590-17-017768:8k_2_02:21]
NetApp Expands Service Provider Programs and Alliances, Leads a New IT Category, and Delivers New Innovations

[0001564590-17-017768:8k_2_02:22]
| • | Expanded Fueled by NetApp Program helps service providers gain access to new consulting and incubator programs, as well as new efficiency guarantees and increased training. |

[0001564590-17-017768:8k_2_02:23]
| • | NetApp recognized as a Leader in Gartner Magic Quadrant for Solid-State Arrays. |

[0001564590-17-017768:8k_2_02:24]
| • | New FlexPod™ SF converged infrastructure solution offers ideal infrastructure for the data-intensive scale-out workloads that are critical to digital transformation. |

[0001564590-17-017768:8k_2_02:25]
| • | NetApp positioned to capture digital transformation opportunity with leadership in new IDC category of hybrid cloud data services. |

[0001564590-17-017768:8k_2_02:26]
| • | NetApp expands collaboration with Microsoft Azure in hybrid cloud data services to deliver enterprise-grade visibility and insights, data access and control, as well as data protection and security for customers moving to Microsoft Azure. |

[0001564590-17-017768:8k_2_02:27]
| • | NetApp has provided early access to the innovations of NetApp™ HCI, planned to be generally available in the second half of calendar 2017, to a number of technology partners that are integrating with the solution. |

[0001564590-17-017768:8k_2_02:28]
| • | ONTAP™ select software-defined storage is optimized for new use cases, including a new remote office/branch office solution and enterprise NAS services in more diverse storage environments. |

[0001564590-17-017768:8k_2_02:29]
| • | OnCommand™ Insight (OCI) adds new functions to ease hybrid cloud migration and optimize hybrid cloud resources with accurate workload placement and resizing. |

[0001564590-17-017768:8k_2_02:30]
| • | ONTAP enhancements include the new FabricPool feature for automatic and transparent tiering of inactive data to the cloud; expanded inline deduplication across multiple pools of storage to increase storage efficiency; and new performance controls, including quality of service minimum and intelligent data placement. |

[0001564590-17-017768:8k_2_02:31]
| • | With NextCredit, NetApp introduces the industry’s most flexible future credit program, allowing customers to upgrade or build out their Data Fabric with new technologies and capabilities as they become available. |

[0001564590-17-017768:8k_2_02:32]
| • | StorageGRID™ Webscale next-generation object storage software simplifies OpenStack storage deployments and supports Docker container deployment on bare-metal servers. |

[0001564590-17-017768:8k_2_02:33]
| • | NetApp SnapCenter™ 3.0 enables customers to restore and recover SAP HANA multitenant database containers. |

[0001564590-17-017768:8k_2_02:34]
Webcast and Conference Call Information

[0001564590-17-017768:8k_2_02:35]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:30 p.m. Pacific Time today.

[0001564590-17-017768:8k_2_02:36]
About NetApp

[0001564590-17-017768:8k_2_02:37]
NetApp is the data authority for hybrid cloud. We provide a full range of hybrid cloud data services that simplify management of applications and data across cloud and on-premises environments to accelerate digital transformation. Together with our partners, we empower global organizations to unleash the full potential of their data to expand customer touchpoints, foster greater innovation and optimize their operations. For more information, visit www.netapp.com. #DataDriven

[0001564590-17-017768:8k_2_02:38]
###

[0001564590-17-017768:8k_2_02:39]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-17-017768:8k_2_02:40]
1GAAP earnings per share is calculated using the diluted number of shares.

[0001564590-17-017768:8k_2_02:41]
2Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) acquisition-related expenses, (d) restructuring charges, (e) asset impairments, (f) gains/losses on the sale of properties, and (g) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-17-017768:8k_2_02:42]
NetApp Usage of Non-GAAP Financial Information

[0001564590-17-017768:8k_2_02:43]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-17-017768:8k_2_02:44]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-17-017768:8k_2_02:45]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s

[0001564590-17-017768:8k_2_02:46]
ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-17-017768:8k_2_02:47]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-17-017768:8k_2_02:48]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-17-017768:8k_2_02:49]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-17-017768:8k_2_02:50]
C. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-17-017768:8k_2_02:51]
D. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-17-017768:8k_2_02:52]
E. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-17-017768:8k_2_02:53]
F. Gains/losses on the sale of properties. These are gains/losses from the sale of our properties. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-17-017768:8k_2_02:54]
G. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual properties from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-17-017768:8k_2_02:55]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-17-017768:8k_2_02:56]
NETAPP, INC.

[0001564590-17-017768:8k_2_02:57]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-17-017768:8k_2_02:58]
(In millions)

[0001564590-17-017768:8k_2_02:59]
(Unaudited)

[0001564590-17-017768:8k_2_02:60]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,321 |  |  | $ | 4,921 |  |
| Accounts receivable |  |  | 518 |  |  |  | 731 |  |
| Inventories |  |  | 143 |  |  |  | 163 |  |
| Other current assets |  |  | 316 |  |  |  | 383 |  |
| Total current assets |  |  | 6,298 |  |  |  | 6,198 |  |
| Property and equipment, net |  |  | 799 |  |  |  | 799 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,825 |  |  |  | 1,815 |  |
| Other non-current assets |  |  | 677 |  |  |  | 681 |  |
| Total assets |  | $ | 9,599 |  |  | $ | 9,493 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 289 |  |  | $ | 347 |  |
| Accrued expenses |  |  | 653 |  |  |  | 782 |  |
| Commercial paper notes |  |  | 894 |  |  |  | 500 |  |
| Current portion of long-term debt |  |  | 749 |  |  |  | 749 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,702 |  |  |  | 1,744 |  |
| Total current liabilities |  |  | 4,287 |  |  |  | 4,122 |  |
| Long-term debt |  |  | 745 |  |  |  | 744 |  |
| Other long-term liabilities |  |  | 250 |  |  |  | 249 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,549 |  |  |  | 1,598 |  |
| Total liabilities |  |  | 6,831 |  |  |  | 6,713 |  |
| Stockholders' equity |  |  | 2,768 |  |  |  | 2,780 |  |
| Total liabilities and stockholders' equity |  | $ | 9,599 |  |  | $ | 9,493 |  |

[0001564590-17-017768:8k_2_02:61]
NETAPP, INC.

[0001564590-17-017768:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-17-017768:8k_2_02:63]
(In millions, except per share amounts)

[0001564590-17-017768:8k_2_02:64]
(Unaudited)

[0001564590-17-017768:8k_2_02:65]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Product |  | $ | 723 |  |  | $ | 660 |  |
| Software maintenance |  |  | 234 |  |  |  | 241 |  |
| Hardware maintenance and other services |  |  | 368 |  |  |  | 393 |  |
| Net revenues |  |  | 1,325 |  |  |  | 1,294 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 371 |  |  |  | 359 |  |
| Cost of software maintenance |  |  | 7 |  |  |  | 8 |  |
| Cost of hardware maintenance and other services |  |  | 113 |  |  |  | 130 |  |
| Total cost of revenues |  |  | 491 |  |  |  | 497 |  |
| Gross profit |  |  | 834 |  |  |  | 797 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 425 |  |  |  | 429 |  |
| Research and development |  |  | 193 |  |  |  | 207 |  |
| General and administrative |  |  | 68 |  |  |  | 68 |  |
| Total operating expenses |  |  | 686 |  |  |  | 704 |  |
| Income from operations |  |  | 148 |  |  |  | 93 |  |
| Other income (expense), net |  |  | 5 |  |  |  | (1 | ) |
| Income before income taxes |  |  | 153 |  |  |  | 92 |  |
| Provision for income taxes |  |  | 17 |  |  |  | 28 |  |
| Net income |  | $ | 136 |  |  | $ | 64 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.50 |  |  | $ | 0.23 |  |
| Diluted |  | $ | 0.49 |  |  | $ | 0.23 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |
| Basic |  |  | 270 |  |  |  | 279 |  |
| Diluted |  |  | 278 |  |  |  | 282 |  |
| Cash dividends declared per share |  | $ | 0.200 |  |  | $ | 0.190 |  |

[0001564590-17-017768:8k_2_02:66]
NETAPP, INC.

[0001564590-17-017768:8k_2_02:67]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-17-017768:8k_2_02:68]
(In millions)

[0001564590-17-017768:8k_2_02:69]
(Unaudited)

[0001564590-17-017768:8k_2_02:70]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 136 |  |  | $ | 64 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 51 |  |  |  | 60 |  |
| Stock-based compensation |  |  | 48 |  |  |  | 52 |  |
| Other items, net |  |  | 7 |  |  |  | 12 |  |
| Changes in assets and liabilities, net of acquisition of business: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 218 |  |  |  | 311 |  |
| Inventories |  |  | 20 |  |  |  | 17 |  |
| Accounts payable |  |  | (58 | ) |  |  | (30 | ) |
| Accrued expenses |  |  | (135 | ) |  |  | (198 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (107 | ) |  |  | (83 | ) |
| Changes in other operating assets and liabilities, net |  |  | 70 |  |  |  | 23 |  |
| Net cash provided by operating activities |  |  | 250 |  |  |  | 228 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 112 |  |  |  | 313 |  |
| Purchases of property and equipment |  |  | (36 | ) |  |  | (36 | ) |
| Acquisition of business, net of cash acquired |  |  | (24 | ) |  |  | — |  |
| Other investing activities, net |  |  | 5 |  |  |  | (1 | ) |
| Net cash provided by investing activities |  |  | 57 |  |  |  | 276 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 48 |  |  |  | 42 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (57 | ) |  |  | (33 | ) |
| Repurchase of common stock |  |  | (150 | ) |  |  | (175 | ) |
| Proceeds from issuance of commercial paper notes, net |  |  | 394 |  |  |  | — |  |
| Repayment of short-term loan |  |  | — |  |  |  | (850 | ) |
| Dividends paid |  |  | (54 | ) |  |  | (53 | ) |
| Other financing activities, net |  |  | — |  |  |  | (2 | ) |
| Net cash provided by (used in) financing activities |  |  | 181 |  |  |  | (1,071 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 19 |  |  |  | (7 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 507 |  |  |  | (574 | ) |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,444 |  |  |  | 2,868 |  |
| End of period |  | $ | 2,951 |  |  | $ | 2,294 |  |

[0001564590-17-017768:8k_2_02:71]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q1 FY'18 |  |  | Q4 FY'17 |  |  | Q1 FY'17 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (1) |  | $ | 723 |  |  | $ | 852 |  |  | $ | 660 |  |
| Strategic |  | $ | 500 |  |  | $ | 596 |  |  | $ | 411 |  |
| Mature |  | $ | 223 |  |  | $ | 256 |  |  | $ | 249 |  |
| Software Maintenance |  | $ | 234 |  |  | $ | 242 |  |  | $ | 241 |  |
| Hardware Maintenance and Other Services |  | $ | 368 |  |  | $ | 387 |  |  | $ | 393 |  |
| Hardware Maintenance Support Contracts |  | $ | 298 |  |  | $ | 313 |  |  | $ | 323 |  |
| Professional and Other Services |  | $ | 70 |  |  | $ | 74 |  |  | $ | 70 |  |
| Net Revenues |  | $ | 1,325 |  |  | $ | 1,481 |  |  | $ | 1,294 |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'18 Revenue |  |  | % of Q4 FY'17 Revenue |  |  | % of Q1 FY'17 Revenue |  |
| Americas |  |  | 55 | % |  |  | 54 | % |  |  | 57 | % |
| Americas Commercial |  |  | 42 | % |  |  | 42 | % |  |  | 44 | % |
| U.S. Public Sector |  |  | 13 | % |  |  | 12 | % |  |  | 13 | % |
| EMEA |  |  | 30 | % |  |  | 32 | % |  |  | 30 | % |
| Asia Pacific |  |  | 15 | % |  |  | 14 | % |  |  | 13 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'18 Revenue |  |  | % of Q4 FY'17 Revenue |  |  | % of Q1 FY'17 Revenue |  |
| Direct |  |  | 20 | % |  |  | 22 | % |  |  | 23 | % |
| Indirect |  |  | 80 | % |  |  | 78 | % |  |  | 77 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'18 |  |  | Q4 FY'17 |  |  | Q1 FY'17 |  |
| Non-GAAP Gross Margin |  |  | 63.8 | % |  |  | 62.5 | % |  |  | 62.4 | % |
| Product |  |  | 49.9 | % |  |  | 48.9 | % |  |  | 46.7 | % |
| Software Maintenance |  |  | 97.0 | % |  |  | 97.5 | % |  |  | 96.7 | % |
| Hardware Maintenance and Other Services |  |  | 70.1 | % |  |  | 70.3 | % |  |  | 67.9 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'18 |  |  | Q4 FY'17 |  |  | Q1 FY'17 |  |
| Non-GAAP Income from Operations |  | $ | 209 |  |  | $ | 306 |  |  | $ | 156 |  |
| % of Net Revenues |  |  | 15.8 | % |  |  | 20.7 | % |  |  | 12.1 | % |
| Non-GAAP Income before Income Taxes |  | $ | 214 |  |  | $ | 307 |  |  | $ | 155 |  |
| Non-GAAP Effective Tax Rate |  |  | 19.4 | % |  |  | 22.1 | % |  |  | 16.6 | % |

[0001564590-17-017768:8k_2_02:72]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'18 |  |  | Q4 FY'17 |  |  | Q1 FY'17 |  |
| Non-GAAP Net Income |  | $ | 173 |  |  | $ | 239 |  |  | $ | 129 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 278 |  |  |  | 278 |  |  |  | 282 |  |
| Non-GAAP Income per Share, Diluted |  | $ | 0.62 |  |  | $ | 0.86 |  |  | $ | 0.46 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'18 |  |  | Q4 FY'17 |  |  | Q1 FY'17 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,251 |  |  | $ | 3,342 |  |  | $ | 3,300 |  |
| DSO (days) |  |  | 36 |  |  |  | 45 |  |  |  | 35 |  |
| DIO (days) |  |  | 27 |  |  |  | 26 |  |  |  | 15 |  |
| DPO (days) |  |  | 54 |  |  |  | 56 |  |  |  | 44 |  |
| CCC (days) |  |  | 9 |  |  |  | 15 |  |  |  | 6 |  |
| Inventory Turns |  |  | 14 |  |  |  | 14 |  |  |  | 25 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'18 |  |  | Q4 FY'17 |  |  | Q1 FY'17 |  |
| Net Cash Provided by Operating Activities |  | $ | 250 |  |  | $ | 365 |  |  | $ | 228 |  |
| Purchases of Property and Equipment |  | $ | 36 |  |  | $ | 38 |  |  | $ | 36 |  |
| Free Cash Flow |  | $ | 214 |  |  | $ | 327 |  |  | $ | 192 |  |
| Free Cash Flow as a % of Net Revenues |  |  | 16.2 | % |  |  | 22.1 | % |  |  | 14.8 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| (1) Sales of certain products which should have been reported as strategic products were improperly reported as mature product revenues in Q1 FY'17. That period has been recast to reflect the appropriate classification. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001564590-17-017768:8k_2_02:73]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY18 |  |  | Q4'FY17 |  |  | Q1'FY17 |  |
| NET INCOME |  | $ | 136 |  |  | $ | 190 |  |  | $ | 64 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 13 |  |  |  | 11 |  |
| Stock-based compensation |  |  | 48 |  |  |  | 46 |  |  |  | 52 |  |
| Income tax effect of non-GAAP adjustments |  |  | (24 | ) |  |  | (10 | ) |  |  | 2 |  |
| NON-GAAP NET INCOME |  | $ | 173 |  |  | $ | 239 |  |  | $ | 129 |  |
| COST OF REVENUES |  | $ | 491 |  |  | $ | 568 |  |  | $ | 497 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (8 | ) |  |  | (6 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (5 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 479 |  |  | $ | 556 |  |  | $ | 486 |  |
| COST OF PRODUCT REVENUES |  | $ | 371 |  |  | $ | 444 |  |  | $ | 359 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (8 | ) |  |  | (6 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 362 |  |  | $ | 435 |  |  | $ | 352 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 113 |  |  | $ | 118 |  |  | $ | 130 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (4 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 110 |  |  | $ | 115 |  |  | $ | 126 |  |
| GROSS PROFIT |  | $ | 834 |  |  | $ | 913 |  |  | $ | 797 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 8 |  |  |  | 8 |  |  |  | 6 |  |
| Stock-based compensation |  |  | 4 |  |  |  | 4 |  |  |  | 5 |  |
| NON-GAAP GROSS PROFIT |  | $ | 846 |  |  | $ | 925 |  |  | $ | 808 |  |

[0001564590-17-017768:8k_2_02:74]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY18 |  |  | Q4'FY17 |  |  | Q1'FY17 |  |
| SALES AND MARKETING EXPENSES |  | $ | 425 |  |  | $ | 405 |  |  | $ | 429 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (21 | ) |  |  | (20 | ) |  |  | (23 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 399 |  |  | $ | 380 |  |  | $ | 401 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 193 |  |  | $ | 191 |  |  | $ | 207 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (15 | ) |  |  | (13 | ) |  |  | (15 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 178 |  |  | $ | 178 |  |  | $ | 192 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 68 |  |  | $ | 70 |  |  | $ | 68 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (8 | ) |  |  | (9 | ) |  |  | (9 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 60 |  |  | $ | 61 |  |  | $ | 59 |  |
| OPERATING EXPENSES |  | $ | 686 |  |  | $ | 666 |  |  | $ | 704 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (44 | ) |  |  | (42 | ) |  |  | (47 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 637 |  |  | $ | 619 |  |  | $ | 652 |  |

[0001564590-17-017768:8k_2_02:75]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY18 |  |  | Q4'FY17 |  |  | Q1'FY17 |  |
| INCOME FROM OPERATIONS |  | $ | 148 |  |  | $ | 247 |  |  | $ | 93 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 13 |  |  |  | 11 |  |
| Stock-based compensation |  |  | 48 |  |  |  | 46 |  |  |  | 52 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 209 |  |  | $ | 306 |  |  | $ | 156 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 153 |  |  | $ | 248 |  |  | $ | 92 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 13 |  |  |  | 11 |  |
| Stock-based compensation |  |  | 48 |  |  |  | 46 |  |  |  | 52 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 214 |  |  | $ | 307 |  |  | $ | 155 |  |
| PROVISION FOR INCOME TAXES |  | $ | 17 |  |  | $ | 58 |  |  | $ | 28 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | 24 |  |  |  | 10 |  |  |  | (2 | ) |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 41 |  |  | $ | 68 |  |  | $ | 26 |  |
| NET INCOME PER SHARE |  | $ | 0.49 |  |  | $ | 0.68 |  |  | $ | 0.23 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.04 |  |
| Stock-based compensation |  |  | 0.17 |  |  |  | 0.17 |  |  |  | 0.18 |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.09 | ) |  |  | (0.04 | ) |  |  | 0.01 |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.62 |  |  | $ | 0.86 |  |  | $ | 0.46 |  |

[0001564590-17-017768:8k_2_02:76]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY18 |  |  | Q4'FY17 |  |  | Q1'FY17 |  |
| Gross margin-GAAP |  |  | 62.9 | % |  |  | 61.6 | % |  |  | 61.6 | % |
| Cost of revenues adjustments |  |  | 0.9 | % |  |  | 0.8 | % |  |  | 0.9 | % |
| Gross margin-Non-GAAP |  |  | 63.8 | % |  |  | 62.5 | % |  |  | 62.4 | % |
| GAAP cost of revenues |  | $ | 491 |  |  | $ | 568 |  |  | $ | 497 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (8 | ) |  |  | (6 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (5 | ) |
| Non-GAAP cost of revenues |  | $ | 479 |  |  | $ | 556 |  |  | $ | 486 |  |
| Net revenues |  | $ | 1,325 |  |  | $ | 1,481 |  |  | $ | 1,294 |  |

[0001564590-17-017768:8k_2_02:77]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY18 |  |  | Q4'FY17 |  |  | Q1'FY17 |  |
| Product gross margin-GAAP |  |  | 48.7 | % |  |  | 47.9 | % |  |  | 45.6 | % |
| Cost of product revenues adjustments |  |  | 1.2 | % |  |  | 1.1 | % |  |  | 1.1 | % |
| Product gross margin-Non-GAAP |  |  | 49.9 | % |  |  | 48.9 | % |  |  | 46.7 | % |
| GAAP cost of product revenues |  | $ | 371 |  |  | $ | 444 |  |  | $ | 359 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (8 | ) |  |  | (6 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 362 |  |  | $ | 435 |  |  | $ | 352 |  |
| Product revenues |  | $ | 723 |  |  | $ | 852 |  |  | $ | 660 |  |

[0001564590-17-017768:8k_2_02:78]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY18 |  |  | Q4'FY17 |  |  | Q1'FY17 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 69.3 | % |  |  | 69.5 | % |  |  | 66.9 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.8 | % |  |  | 0.8 | % |  |  | 1.0 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 70.1 | % |  |  | 70.3 | % |  |  | 67.9 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 113 |  |  | $ | 118 |  |  | $ | 130 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (4 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 110 |  |  | $ | 115 |  |  | $ | 126 |  |
| Hardware maintenance and other services revenues |  | $ | 368 |  |  | $ | 387 |  |  | $ | 393 |  |

[0001564590-17-017768:8k_2_02:79]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q1'FY18 |  |  | Q4'FY17 |  |  | Q1'FY17 |  |
| GAAP effective tax rate |  |  | 11.1 | % |  |  | 23.4 | % |  |  | 30.4 | % |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | 8.3 | % |  |  | (1.3 | )% |  |  | (13.8 | )% |
| Non-GAAP effective tax rate |  |  | 19.4 | % |  |  | 22.1 | % |  |  | 16.6 | % |

[0001564590-17-017768:8k_2_02:80]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY18 |  |  | Q4'FY17 |  |  | Q1'FY17 |  |
| Net cash provided by operating activities |  | $ | 250 |  |  | $ | 365 |  |  | $ | 228 |  |
| Purchases of property and equipment |  |  | (36 | ) |  |  | (38 | ) |  |  | (36 | ) |
| Free cash flow |  | $ | 214 |  |  | $ | 327 |  |  | $ | 192 |  |

[0001564590-17-017768:8k_2_02:81]
Some items may not add or recalculate due to rounding.

[0001564590-17-017768:8k_2_02:82]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| SECOND QUARTER FISCAL 2018 |  |
|  |  | Second Quarter |  |
|  |  | Fiscal 2018 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $0.64 - $0.72 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Second Quarter Fiscal 2018: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.05 | ) |
| Stock-based compensation expense |  |  | (0.14 | ) |
| Income tax effect of non-GAAP adjustments |  |  | 0.02 |  |
| Total Adjustments |  |  | (0.17 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.47 - $0.55 |  |

[0001564590-17-017768:8k_2_02:83]
Press Contact:

[0001564590-17-017768:8k_2_02:84]
Madge Miller

[0001564590-17-017768:8k_2_02:85]
NetApp

[0001564590-17-017768:8k_2_02:86]
1 408 419 5263

[0001564590-17-017768:8k_2_02:87]
madge.miller@netapp.com

[0001564590-17-017768:8k_2_02:88]
Investor Contact:

[0001564590-17-017768:8k_2_02:89]
Kris Newton

[0001564590-17-017768:8k_2_02:90]
NetApp

[0001564590-17-017768:8k_2_02:91]
1 408 822 3312

[0001564590-17-017768:8k_2_02:92]
kris.newton@netapp.com
