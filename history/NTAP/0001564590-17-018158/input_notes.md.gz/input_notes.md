# NTAP notes — 0001564590-17-018158


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-17-018158:notes:1]
[same as prior period, unchanged from 0001564590-17-002845:notes:1]

[0001564590-17-018158:notes:2]
NetApp, Inc. (we, us, or the Company) provides global organizations the ability to manage and share their data across on-premises, private and public clouds. Together with our partners, we provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.

[0001564590-17-018158:notes:3]
[same as prior period, unchanged from 0001564590-17-002845:notes:3]

[0001564590-17-018158:notes:4]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal years 2018 and 2017, ending on April 27, 2018, and April 28, 2017, respectively, are each 52-week years, with 13 weeks in each of their quarters.

[0001564590-17-018158:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 28, 2017 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 28, 2017 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-17-018158:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; valuation of investment securities; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-17-018158:notes:7]
There have been no significant changes in our significant accounting policies as of and for the three months ended July 28, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 28, 2017.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-17-018158:notes:8]
[same as prior period, unchanged from 0001564590-17-002845:notes:12]

[0001564590-17-018158:notes:9]
Non-cash investing activities and supplemental cash flow information are as follows (in millions):

[0001564590-17-018158:notes:10]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 18 |  |  | $ | 38 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 22 |  |  | $ | 62 |  |
| Interest paid |  | $ | 21 |  |  | $ | 23 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-17-018158:notes:11]
4. Business Combination

[0001564590-17-018158:notes:12]
On June 15, 2017, we acquired all of the outstanding shares of Plexistor Ltd., a privately-held provider of software defined memory architecture based in Israel, for $24 million in cash, of which we allocated $6 million to developed technology, $17 million to goodwill, and the remainder to other assets.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-17-018158:notes:13]
5. Goodwill and Purchased Intangible Assets, Net

[0001564590-17-018158:notes:14]
Goodwill activity is summarized as follows (in millions):

[0001564590-17-018158:notes:15]
| Balance as of April 28, 2017 |  | $ | 1,684 |  |
| Additions |  |  | 17 |  |
| Balance as of July 28, 2017 |  | $ | 1,701 |  |

[0001564590-17-018158:notes:16]
Purchased intangible assets, net are summarized below (in millions):

[0001564590-17-018158:notes:17]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 154 |  |  | $ | (52 | ) |  | $ | 102 |  |  | $ | 148 |  |  | $ | (44 | ) |  | $ | 104 |  |
| Customer contracts/relationships |  |  | 43 |  |  |  | (23 | ) |  |  | 20 |  |  |  | 43 |  |  |  | (19 | ) |  |  | 24 |  |
| Other purchased intangibles |  |  | 9 |  |  |  | (7 | ) |  |  | 2 |  |  |  | 9 |  |  |  | (6 | ) |  |  | 3 |  |
| Total purchased intangible assets |  | $ | 206 |  |  | $ | (82 | ) |  | $ | 124 |  |  | $ | 200 |  |  | $ | (69 | ) |  | $ | 131 |  |

[0001564590-17-018158:notes:18]
Amortization expense for purchased intangible assets is summarized below (in millions):

[0001564590-17-018158:notes:19]
|  |  | Three Months Ended |  |  | Statements of |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |  | Operations Classification |
| Developed technology |  | $ | 8 |  |  | $ | 6 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 4 |  |  |  | 4 |  |  | Operating expenses |
| Other purchased intangibles |  |  | 1 |  |  |  | 1 |  |  | Operating expenses |
| Total |  | $ | 13 |  |  | $ | 11 |  |  |  |

[0001564590-17-018158:notes:20]
As of July 28, 2017, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-17-018158:notes:21]
| Fiscal Year |  | Amount |  |
| Remainder of 2018 |  | $ | 38 |  |
| 2019 |  |  | 44 |  |
| 2020 |  |  | 27 |  |
| 2021 |  |  | 15 |  |
| Total |  | $ | 124 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-17-018158:notes:22]
6. Balance Sheet Details

[0001564590-17-018158:notes:23]
[same as prior period, unchanged from 0001564590-17-002845:notes:24]

[0001564590-17-018158:notes:24]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
| Cash |  | $ | 2,630 |  |  | $ | 2,275 |  |
| Cash equivalents |  |  | 321 |  |  |  | 169 |  |
| Cash and cash equivalents |  | $ | 2,951 |  |  | $ | 2,444 |  |

[0001564590-17-018158:notes:25]
[same as prior period, unchanged from 0001564590-17-002845:notes:26]

[0001564590-17-018158:notes:26]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
| Purchased components |  | $ | 59 |  |  | $ | 28 |  |
| Finished goods |  |  | 84 |  |  |  | 135 |  |
| Inventories |  | $ | 143 |  |  | $ | 163 |  |

[0001564590-17-018158:notes:27]
[same as prior period, unchanged from 0001564590-17-002845:notes:28]

[0001564590-17-018158:notes:28]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
| Land |  | $ | 132 |  |  | $ | 132 |  |
| Buildings and improvements |  |  | 643 |  |  |  | 612 |  |
| Leasehold improvements |  |  | 95 |  |  |  | 93 |  |
| Computer, production, engineering and other equipment |  |  | 751 |  |  |  | 741 |  |
| Computer software |  |  | 352 |  |  |  | 353 |  |
| Furniture and fixtures |  |  | 94 |  |  |  | 90 |  |
| Construction-in-progress |  |  | 2 |  |  |  | 26 |  |
|  |  |  | 2,069 |  |  |  | 2,047 |  |
| Accumulated depreciation and amortization |  |  | (1,270 | ) |  |  | (1,248 | ) |
| Property and equipment, net |  | $ | 799 |  |  | $ | 799 |  |

[0001564590-17-018158:notes:29]
We have classified certain land and buildings previously reported as property and equipment as assets held-for-sale. The book value of these assets is $118 million and is included in other current assets in the condensed consolidated balance sheets.

[0001564590-17-018158:notes:30]
[same as prior period, unchanged from 0001564590-17-002845:notes:32]

[0001564590-17-018158:notes:31]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
| Deferred tax assets |  | $ | 523 |  |  | $ | 525 |  |
| Other assets |  |  | 154 |  |  |  | 156 |  |
| Other non-current assets |  | $ | 677 |  |  | $ | 681 |  |

[0001564590-17-018158:notes:32]
[same as prior period, unchanged from 0001564590-17-002845:notes:34]

[0001564590-17-018158:notes:33]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
| Accrued compensation and benefits |  | $ | 240 |  |  | $ | 340 |  |
| Sale-leaseback financing obligations |  |  | 130 |  |  |  | 130 |  |
| Product warranty liabilities |  |  | 29 |  |  |  | 33 |  |
| Other current liabilities |  |  | 254 |  |  |  | 279 |  |
| Accrued expenses |  | $ | 653 |  |  | $ | 782 |  |

[0001564590-17-018158:notes:34]
[same as prior period, unchanged from 0001564590-17-002845:notes:36]

[0001564590-17-018158:notes:35]
[same as prior period, unchanged from 0001564590-17-002845:notes:37]

[0001564590-17-018158:notes:36]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Balance at beginning of period |  | $ | 50 |  |  | $ | 70 |  |
| Expense accrued during the period |  |  | 1 |  |  |  | 4 |  |
| Warranty costs incurred |  |  | (7 | ) |  |  | (13 | ) |
| Balance at end of period |  | $ | 44 |  |  | $ | 61 |  |

[0001564590-17-018158:notes:37]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
| Accrued expenses |  | $ | 29 |  |  | $ | 33 |  |
| Other long-term liabilities |  |  | 15 |  |  |  | 17 |  |
| Total warranty liabilities |  | $ | 44 |  |  | $ | 50 |  |

[0001564590-17-018158:notes:38]
[same as prior period, unchanged from 0001564590-17-002845:notes:40]

[0001564590-17-018158:notes:39]
[same as prior period, unchanged from 0001564590-17-002845:notes:41]

[0001564590-17-018158:notes:40]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
| Deferred product revenue |  | $ | 123 |  |  | $ | 124 |  |
| Deferred services revenue |  |  | 2,942 |  |  |  | 2,999 |  |
| Financed unearned services revenue |  |  | 186 |  |  |  | 219 |  |
| Total |  | $ | 3,251 |  |  | $ | 3,342 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,702 |  |  | $ | 1,744 |  |
| Long-term |  |  | 1,549 |  |  |  | 1,598 |  |
| Total |  | $ | 3,251 |  |  | $ | 3,342 |  |

[0001564590-17-018158:notes:41]
[same as prior period, unchanged from 0001564590-17-002845:notes:43]


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-17-018158:notes:42]
7. Other income (expense), net

[0001564590-17-018158:notes:43]
[same as prior period, unchanged from 0001564590-17-002845:notes:45]

[0001564590-17-018158:notes:44]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Interest income |  | $ | 16 |  |  | $ | 11 |  |
| Interest expense |  |  | (13 | ) |  |  | (15 | ) |
| Other income, net |  |  | 2 |  |  |  | 3 |  |
| Total other income (expense), net |  | $ | 5 |  |  | $ | (1 | ) |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-17-018158:notes:45]
8. Financial Instruments and Fair Value Measurements

[0001564590-17-018158:notes:46]
[same as prior period, unchanged from 0001564590-17-002845:notes:48]

[0001564590-17-018158:notes:47]
[same as prior period, unchanged from 0001564590-17-002845:notes:49]

[0001564590-17-018158:notes:48]
[same as prior period, unchanged from 0001564590-17-002845:notes:50]

[0001564590-17-018158:notes:49]
[same as prior period, unchanged from 0001564590-17-002845:notes:51]

[0001564590-17-018158:notes:50]
[same as prior period, unchanged from 0001564590-17-002845:notes:52]

[0001564590-17-018158:notes:51]
[same as prior period, unchanged from 0001564590-17-002845:notes:53]

[0001564590-17-018158:notes:52]
[same as prior period, unchanged from 0001564590-17-002845:notes:54]

[0001564590-17-018158:notes:53]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,600 |  |  | $ | 8 |  |  | $ | (1 | ) |  | $ | 1,607 |  |  | $ | 1,535 |  |  | $ | 3 |  |  | $ | (2 | ) |  | $ | 1,536 |  |
| U.S. Treasury and government debt securities |  |  | 557 |  |  |  | — |  |  |  | (2 | ) |  |  | 555 |  |  |  | 629 |  |  |  | 1 |  |  |  | (2 | ) |  |  | 628 |  |
| Foreign government debt securities |  |  | 21 |  |  |  | — |  |  |  | — |  |  |  | 21 |  |  |  | 21 |  |  |  | — |  |  |  | — |  |  |  | 21 |  |
| Commercial paper |  |  | 409 |  |  |  | — |  |  |  | — |  |  |  | 409 |  |  |  | 362 |  |  |  | — |  |  |  | — |  |  |  | 362 |  |
| Certificates of deposit |  |  | 99 |  |  |  | — |  |  |  | — |  |  |  | 99 |  |  |  | 99 |  |  |  | — |  |  |  | — |  |  |  | 99 |  |
| Mutual funds |  |  | 32 |  |  |  | — |  |  |  | — |  |  |  | 32 |  |  |  | 31 |  |  |  | — |  |  |  | — |  |  |  | 31 |  |
| Total debt and equity securities |  | $ | 2,718 |  |  | $ | 8 |  |  | $ | (3 | ) |  | $ | 2,723 |  |  | $ | 2,677 |  |  | $ | 4 |  |  | $ | (4 | ) |  | $ | 2,677 |  |

[0001564590-17-018158:notes:54]
As of July 28, 2017 and April 28, 2017, gross unrealized losses related to individual securities were not significant.

[0001564590-17-018158:notes:55]
The following table presents the contractual maturities of our debt investments as of July 28, 2017 (in millions):

[0001564590-17-018158:notes:56]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,227 |  |  | $ | 1,226 |  |
| Due after one year through five years |  |  | 1,157 |  |  |  | 1,159 |  |
| Due after five years through ten years |  |  | 297 |  |  |  | 301 |  |
| Due after ten years |  |  | 5 |  |  |  | 5 |  |
|  |  | $ | 2,686 |  |  | $ | 2,691 |  |

[0001564590-17-018158:notes:57]
[same as prior period, unchanged from 0001564590-17-002845:notes:59]

[0001564590-17-018158:notes:58]
[same as prior period, unchanged from 0001564590-17-002845:notes:60]

[0001564590-17-018158:notes:59]
[same as prior period, unchanged from 0001564590-17-002845:notes:61]

[0001564590-17-018158:notes:60]
|  |  | July 28, 2017 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,630 |  |  | $ | 2,630 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,607 |  |  |  | — |  |  |  | 1,607 |  |
| U.S. Treasury and government debt securities |  |  | 555 |  |  |  | 216 |  |  |  | 339 |  |
| Foreign government debt securities |  |  | 21 |  |  |  | — |  |  |  | 21 |  |
| Commercial paper |  |  | 409 |  |  |  | — |  |  |  | 409 |  |
| Certificates of deposit |  |  | 99 |  |  |  | — |  |  |  | 99 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 5,321 |  |  | $ | 2,846 |  |  | $ | 2,475 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 26 |  |  | $ | 26 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |

[0001564590-17-018158:notes:61]
[same as prior period, unchanged from 0001564590-17-002845:notes:63]

[0001564590-17-018158:notes:62]
[same as prior period, unchanged from 0001564590-17-002845:notes:64]

[0001564590-17-018158:notes:63]
[same as prior period, unchanged from 0001564590-17-002845:notes:65]

[0001564590-17-018158:notes:64]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of July 28, 2017 and April 28, 2017, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-17-018158:notes:65]
[same as prior period, unchanged from 0001564590-17-002845:notes:67]

[0001564590-17-018158:notes:66]
As of July 28, 2017 and April 28, 2017, the fair value of our long-term debt was approximately $1,523 million and $1,520 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-17-018158:notes:67]
9. Financing Arrangements

[0001564590-17-018158:notes:68]
Long-Term Debt

[0001564590-17-018158:notes:69]
The following table summarizes information relating to our long-term debt (in millions, except interest rates):

[0001564590-17-018158:notes:70]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (6 | ) |  |  |  |  |  |  | (7 | ) |  |  |  |  |
| Total senior notes |  |  | 1,494 |  |  |  |  |  |  |  | 1,493 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (749 | ) |  |  |  |  |  |  | (749 | ) |  |  |  |  |
| Total long-term debt |  | $ | 745 |  |  |  |  |  |  | $ | 744 |  |  |  |  |  |

[0001564590-17-018158:notes:71]
Senior Notes

[0001564590-17-018158:notes:72]
Our 3.375% Senior Notes, 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $500 million, $750 million and $250 million, respectively, were issued in June 2014, December 2012 and December 2012, respectively. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-17-018158:notes:73]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 28, 2017, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-17-018158:notes:74]
As of July 28, 2017, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-17-018158:notes:75]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| 2022 |  |  | 500 |  |
| Thereafter |  |  | 250 |  |
| Total |  | $ | 1,500 |  |

[0001564590-17-018158:notes:76]
Commercial Paper Program and Credit Facility

[0001564590-17-018158:notes:77]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended on July 17, 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of July 28, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $895 million, a weighted-average interest rate of 1.45% and maturities ranging from 13 days to 56 days. As of April 28, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $500 million, a weighted-average interest rate of 1.26% and maturities ranging from 7 days to 38 days.

[0001564590-17-018158:notes:78]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended on July 17, 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of July 28, 2017 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-17-018158:notes:79]
Sale-leaseback Transactions

[0001564590-17-018158:notes:80]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, until such time as the related leases are terminated, the assets will remain on our condensed consolidated balance sheets and proceeds received by us from these transactions are reported as financing obligations. As of July 28, 2017, the balance of the remaining financing obligations, which relate to properties whose leases we expect to terminate in December 2017, was $130 million. At the end of the leaseback period, or when our continuing involvement under the leaseback agreement ends, this transaction will be reported as a non-cash sale and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-17-018158:notes:81]
10. Stockholders’ Equity

[0001564590-17-018158:notes:82]
[same as prior period, unchanged from 0001564590-17-002845:notes:86]

[0001564590-17-018158:notes:83]
As of July 28, 2017, we have certain equity incentive awards (awards) outstanding, which include stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and Employee Stock Purchase Plan (ESPP) awards.

[0001564590-17-018158:notes:84]
[same as prior period, unchanged from 0001564590-17-002845:notes:88]

[0001564590-17-018158:notes:85]
[same as prior period, unchanged from 0001564590-17-002845:notes:89]

[0001564590-17-018158:notes:86]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 28, 2017 |  |  | 4 |  |  | $ | 35.76 |  |  |  |  |  |  |  |  |  |
| Outstanding as of July 28, 2017 |  |  | 4 |  |  | $ | 36.87 |  |  |  | 2.91 |  |  | $ | 34 |  |
| Exercisable as of July 28, 2017 |  |  | 3 |  |  | $ | 41.07 |  |  |  | 2.18 |  |  | $ | 17 |  |

[0001564590-17-018158:notes:87]
[same as prior period, unchanged from 0001564590-17-002845:notes:91]

[0001564590-17-018158:notes:88]
[same as prior period, unchanged from 0001564590-17-002845:notes:92]

[0001564590-17-018158:notes:89]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Intrinsic value of exercises |  | $ | 5 |  |  | $ | 3 |  |
| Proceeds received from exercises |  | $ | 6 |  |  | $ | 1 |  |
| Fair value of options vested |  | $ | 3 |  |  | $ | 5 |  |

[0001564590-17-018158:notes:90]
[same as prior period, unchanged from 0001564590-17-002845:notes:94]

[0001564590-17-018158:notes:91]
In the three months ended July 28, 2017, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service based vesting criteria) such that the PBRSU cliff-vests at the end of either an approximate two year or three year performance period, which began on the date specified in the grant agreement and ends the last day of the second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted, and will depend upon our Total Stockholder Return (TSR) as compared to an index TSR (each expressed as a growth rate percentage) calculated as of the applicable period end date. The fair values of the PBRSUs were fixed at grant date using a Monte Carlo simulation model and the related aggregate compensation cost of $20 million is being recognized over the shorter of the remaining applicable performance or service periods.

[0001564590-17-018158:notes:92]
The following table summarizes information related to our RSUs, including PBRSUs, (in millions, except for fair value):

[0001564590-17-018158:notes:93]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 28, 2017 |  |  | 11 |  |  | $ | 28.81 |  |
| Granted |  |  | 4 |  |  | $ | 38.42 |  |
| Vested |  |  | (4 | ) |  | $ | 31.06 |  |
| Forfeited |  |  | (1 | ) |  | $ | 26.96 |  |
| Outstanding as of July 28, 2017 |  |  | 10 |  |  | $ | 31.52 |  |

[0001564590-17-018158:notes:94]
[same as prior period, unchanged from 0001564590-17-002845:notes:98]

[0001564590-17-018158:notes:95]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 57 |  |  | $ | 33 |  |

[0001564590-17-018158:notes:96]
[same as prior period, unchanged from 0001564590-17-002845:notes:100]

[0001564590-17-018158:notes:97]
[same as prior period, unchanged from 0001564590-17-002845:notes:101]

[0001564590-17-018158:notes:98]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Shares issued under the ESPP |  |  | 2 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 42 |  |  | $ | 42 |  |

[0001564590-17-018158:notes:99]
[same as prior period, unchanged from 0001564590-17-002845:notes:103]

[0001564590-17-018158:notes:100]
[same as prior period, unchanged from 0001564590-17-002845:notes:104]

[0001564590-17-018158:notes:101]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |
| Cost of hardware maintenance and other services revenues |  |  | 3 |  |  |  | 4 |  |
| Sales and marketing |  |  | 21 |  |  |  | 23 |  |
| Research and development |  |  | 15 |  |  |  | 15 |  |
| General and administrative |  |  | 8 |  |  |  | 9 |  |
| Total stock-based compensation expense |  | $ | 48 |  |  | $ | 52 |  |
| Income tax benefit for stock-based compensation |  | $ | 9 |  |  | $ | 9 |  |

[0001564590-17-018158:notes:102]
As of July 28, 2017, total unrecognized compensation expense related to our equity awards was $304 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.5 years.

[0001564590-17-018158:notes:103]
[same as prior period, unchanged from 0001564590-17-002845:notes:107]

[0001564590-17-018158:notes:104]
As of July 28, 2017, our Board of Directors has authorized the repurchase of up to $9.6 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management.

[0001564590-17-018158:notes:105]
The following table summarizes activity related to this program for the three months ended July 28, 2017 (in millions, except per share amounts):

[0001564590-17-018158:notes:106]
| Number of shares repurchased |  |  | 4 |  |
| Average price per share |  | $ | 40.56 |  |
| Aggregate purchase price |  | $ | 150 |  |
| Remaining authorization at end of period |  | $ | 644 |  |

[0001564590-17-018158:notes:107]
The aggregate purchase price of our stock repurchases for the three months ended July 28, 2017 consisted of $150 million of open market purchases, of which $38 million and $112 million were allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-17-018158:notes:108]
Since the May 13, 2003 inception of our stock repurchase program through July 28, 2017, we repurchased a total of 273 million shares of our common stock at an average price of $32.94 per share, for an aggregate purchase price of $9.0 billion.

[0001564590-17-018158:notes:109]
[same as prior period, unchanged from 0001564590-17-002845:notes:113]

[0001564590-17-018158:notes:110]
[same as prior period, unchanged from 0001564590-17-002845:notes:114]

[0001564590-17-018158:notes:111]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Dividends per share declared |  | $ | 0.20 |  |  | $ | 0.19 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | — |  |  | $ | 50 |  |
| Dividend payments allocated to retained earnings |  | $ | 54 |  |  | $ | 3 |  |

[0001564590-17-018158:notes:112]
On August 16, 2017, we declared a cash dividend of $0.20 per share of common stock, payable on October 25, 2017 to holders of record as of the close of business on October 6, 2017. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-17-018158:notes:113]
[same as prior period, unchanged from 0001564590-17-002845:notes:117]

[0001564590-17-018158:notes:114]
[same as prior period, unchanged from 0001564590-17-002845:notes:118]

[0001564590-17-018158:notes:115]
| Balance as of April 28, 2017 |  | $ | 40 |  |
| Net income |  |  | 136 |  |
| Repurchases of common stock |  |  | (112 | ) |
| Dividends |  |  | (54 | ) |
| Balance as of July 28, 2017 |  | $ | 10 |  |

[0001564590-17-018158:notes:116]
[same as prior period, unchanged from 0001564590-17-002845:notes:120]

[0001564590-17-018158:notes:117]
Changes in accumulated other comprehensive income (loss) by component, net of tax, are summarized below (in millions):

[0001564590-17-018158:notes:118]
|  |  | Foreign Currency Translation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Total |  |
| Balance as of April 28, 2017 |  | $ | (29 | ) |  | $ | — |  |  | $ | (29 | ) |
| Other comprehensive income, net of tax |  |  | 10 |  |  |  | 6 |  |  |  | 16 |  |
| Balance as of July 28, 2017 |  | $ | (19 | ) |  | $ | 6 |  |  | $ | (13 | ) |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-17-018158:notes:119]
11. Derivatives and Hedging Activities

[0001564590-17-018158:notes:120]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is six months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of July 28, 2017 or April 28, 2017. We did not recognize any gains or losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-17-018158:notes:121]
[same as prior period, unchanged from 0001564590-17-002845:notes:128]

[0001564590-17-018158:notes:122]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 102 |  |  | $ | 165 |  |
| Forward contracts purchased |  | $ | 293 |  |  | $ | 257 |  |

[0001564590-17-018158:notes:123]
As of July 28, 2017 and April 28, 2017, there were no instruments designated as cash flow hedges outstanding.

[0001564590-17-018158:notes:124]
[same as prior period, unchanged from 0001564590-17-002845:notes:131]

[0001564590-17-018158:notes:125]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
|  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | (2 | ) |  | $ | 4 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-17-018158:notes:126]
12. Restructuring Charges

[0001564590-17-018158:notes:127]
Management has previously approved several restructuring actions to streamline our business, eliminate costs and redirect resources to our highest return activities, including the March 2016 Plan and the November 2016 Plan, under which we reduced our global workforce by approximately 11%, and 6%, respectively. We completed all workforce related activities under these plans as of the end of fiscal 2017. Charges related to our restructuring plans consisted primarily of employee severance-related costs.

[0001564590-17-018158:notes:128]
[same as prior period, unchanged from 0001564590-17-002845:notes:137]

[0001564590-17-018158:notes:129]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
|  |  | November 2016 Plan |  |  | March 2016 Plan |  |
| Balance at beginning of period |  | $ | 13 |  |  | $ | 45 |  |
| Cash payments |  |  | (4 | ) |  |  | (36 | ) |
| Balance at end of period |  | $ | 9 |  |  | $ | 9 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-17-018158:notes:130]
13. Income Taxes

[0001564590-17-018158:notes:131]
[same as prior period, unchanged from 0001564590-17-002845:notes:140]

[0001564590-17-018158:notes:132]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Effective tax rates |  |  | 11.1 | % |  |  | 30.4 | % |

[0001564590-17-018158:notes:133]
Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations which are headquartered in the Netherlands, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The differences in effective tax rates for the three months ended July 28, 2017 and July 29, 2016 were primarily a result of differences in discrete impacts related to stock-based compensation and differences in year-to-date profits before tax.

[0001564590-17-018158:notes:134]
As of July 28, 2017, we had $220 million of gross unrecognized tax benefits, of which $156 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $161 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-17-018158:notes:135]
We are currently undergoing federal income tax audits in the United States (U.S.) and several foreign tax jurisdictions. Transfer pricing calculations are key issues under audits in various jurisdictions, and are often subject to dispute and appeals. The IRS has concluded the examination of our tax returns for our fiscal years through 2010. The IRS commenced the examination of our federal income tax returns for our fiscal years 2012 and 2013 in August 2016.

[0001564590-17-018158:notes:136]
[same as prior period, unchanged from 0001564590-17-002845:notes:149]

[0001564590-17-018158:notes:137]
[same as prior period, unchanged from 0001564590-17-002845:notes:150]


## us-gaap:EarningsPerShareTextBlock

[0001564590-17-018158:notes:138]
14. Net Income per Share

[0001564590-17-018158:notes:139]
[same as prior period, unchanged from 0001564590-17-002845:notes:152]

[0001564590-17-018158:notes:140]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 136 |  |  | $ | 64 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 270 |  |  |  | 279 |  |
| Dilutive impact of employee equity award plans |  |  | 8 |  |  |  | 3 |  |
| Shares used in diluted computation |  |  | 278 |  |  |  | 282 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.50 |  |  | $ | 0.23 |  |
| Diluted |  | $ | 0.49 |  |  | $ | 0.23 |  |

[0001564590-17-018158:notes:141]
Potential shares from outstanding employee equity awards totaling 2 million and 15 million for the three months ended July 28, 2017 and July 29, 2016, respectively, were excluded from the diluted net income per share calculations as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-17-018158:notes:142]
15. Segment, Geographic, and Significant Customer Information

[0001564590-17-018158:notes:143]
[same as prior period, unchanged from 0001564590-17-002845:notes:156]

[0001564590-17-018158:notes:144]
[same as prior period, unchanged from 0001564590-17-002845:notes:157]

[0001564590-17-018158:notes:145]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| United States, Canada and Latin America (Americas) |  | $ | 726 |  |  | $ | 736 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 401 |  |  |  | 387 |  |
| Asia Pacific (APAC) |  |  | 198 |  |  |  | 171 |  |
| Net revenues |  | $ | 1,325 |  |  | $ | 1,294 |  |

[0001564590-17-018158:notes:146]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $650 million and $666 million during the three months ended July 28, 2017 and July 29, 2016, respectively.

[0001564590-17-018158:notes:147]
[same as prior period, unchanged from 0001564590-17-002845:notes:160]

[0001564590-17-018158:notes:148]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
| U.S. |  | $ | 427 |  |  | $ | 425 |  |
| International |  |  | 4,894 |  |  |  | 4,496 |  |
| Total |  | $ | 5,321 |  |  | $ | 4,921 |  |

[0001564590-17-018158:notes:149]
[same as prior period, unchanged from 0001564590-17-002845:notes:162]

[0001564590-17-018158:notes:150]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
| U.S. |  | $ | 592 |  |  | $ | 593 |  |
| International |  |  | 207 |  |  |  | 206 |  |
| Total |  | $ | 799 |  |  | $ | 799 |  |

[0001564590-17-018158:notes:151]
[same as prior period, unchanged from 0001564590-17-002845:notes:164]

[0001564590-17-018158:notes:152]
|  |  | Three Months Ended |  |
|  |  | July 28, 2017 |  |  | July 29, 2016 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 20 | % |
| Tech Data Corporation (previously presented as Avnet, Inc.) |  |  | 20 | % |  |  | 19 | % |

[0001564590-17-018158:notes:153]
[same as prior period, unchanged from 0001564590-17-002845:notes:166]

[0001564590-17-018158:notes:154]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
| Arrow Electronics, Inc. |  |  | 12 | % |  |  | 15 | % |
| Tech Data Corporation (previously presented as Avnet, Inc.) |  |  | 15 | % |  |  | 14 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-17-018158:notes:155]
16. Commitments and Contingencies

[0001564590-17-018158:notes:156]
Operating Leases

[0001564590-17-018158:notes:157]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $212 million as of July 28, 2017.

[0001564590-17-018158:notes:158]
Purchase Orders and Other Commitments

[0001564590-17-018158:notes:159]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 28, 2017, we had $295 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 28, 2017 and April 28, 2017, such liability amounted to $13 million and $10 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-17-018158:notes:160]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 28, 2017, we had $29 million in construction related obligations and $235 million in other purchase obligations.

[0001564590-17-018158:notes:161]
Financing Guarantees

[0001564590-17-018158:notes:162]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $31 million and $76 million of receivables during the three months ended July 28, 2017 and July 29, 2016, respectively.

[0001564590-17-018158:notes:163]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-17-018158:notes:164]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of July 28, 2017 and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-17-018158:notes:165]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 28, 2017, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-17-018158:notes:166]
Legal Contingencies

[0001564590-17-018158:notes:167]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict, and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-17-018158:notes:168]
We are subject to various legal proceedings and claims that arise in the normal course of business. Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends.

[0001564590-17-018158:notes:169]
No accrual has been recorded as of July 28, 2017 related to such matters as they are not probable and reasonably estimable.
