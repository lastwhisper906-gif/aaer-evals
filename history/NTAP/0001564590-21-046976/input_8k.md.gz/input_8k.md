# NTAP 8-K — 0001564590-21-045712 filed 2021-08-25

## item codes, every 8-K on or before 2021-09-02

- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2021-09-02

- none on or before 2021-09-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-21-045712:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-21-045712:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-21-045712:8k_2_02:3]
Exhibit 99.1

[0001564590-21-045712:8k_2_02:4]
NetApp reports first quarter of fiscal year 2022 results

[0001564590-21-045712:8k_2_02:5]
Net revenues for the first quarter grew 12% year-over-year to $1.46 billion;

[0001564590-21-045712:8k_2_02:6]
Delivered strong start to fiscal year 2022 with double digit revenue and billings growth

[0001564590-21-045712:8k_2_02:7]
| • | NetApp™ Public Cloud revenue increased 155% year-over-year |  |

[0001564590-21-045712:8k_2_02:8]
| • | All-flash array annualized net revenue run rate1 increased 23% year-over-year to $2.8 billion |  |

[0001564590-21-045712:8k_2_02:9]
| • | Product revenue grew 16% year-over-year to $730 million |  |

[0001564590-21-045712:8k_2_02:10]
| • | Billings2 increased 20% year-over-year to $1.38 billion |  |

[0001564590-21-045712:8k_2_02:11]
| • | $242 million in cash provided by operations; $191 million in free cash flow2 |  |

[0001564590-21-045712:8k_2_02:12]
| • | Increased financial guidance for the full fiscal year 2022 |  |

[0001564590-21-045712:8k_2_02:13]
SAN JOSE, Calif.—August 25, 2021—NetApp (NASDAQ: NTAP) today reported financial results for the first quarter of fiscal year 2022, which ended on July 30, 2021.

[0001564590-21-045712:8k_2_02:14]
“Building on our accelerating momentum through last year, we are off to a great start to fiscal 2022, with strong revenue, gross margin, and operating leverage across the entire business,” said George Kurian, chief executive officer. “Cloud and digital transformation initiatives remain top customer priorities and our results underscore the value we bring to customers in a hybrid, multi-cloud, data-driven world. With focused execution and demonstrated leadership, we are reshaping the industry. We made a number of innovation announcements this quarter, and we will continue to bring industry-leading capabilities to market, further enhancing our differentiated position in cloud and software.”

[0001564590-21-045712:8k_2_02:15]
Segments update

[0001564590-21-045712:8k_2_02:16]
In the first quarter of fiscal year 2022, the Company introduced two segments for financial reporting purposes: Hybrid Cloud and Public Cloud. A summary description of each segment follows.

[0001564590-21-045712:8k_2_02:17]
|  | • | Hybrid Cloud offers a portfolio of storage and data management solutions that help customers build and integrate on-premises and private cloud environments. This portfolio is designed to operate with public clouds to unlock the potential of hybrid, multi-cloud operations. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services. |

[0001564590-21-045712:8k_2_02:18]
|  | • | Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support, and made available on the world’s leading clouds. This portfolio includes storage services, cloud automation and optimization services, and cloud infrastructure monitoring services. |

[0001564590-21-045712:8k_2_02:19]
Revenue and gross profit information has been disclosed for each segment, and prior period disclosures have also been revised for comparability. Stock-based compensation and amortization of intangible assets are not allocated to the segments.

[0001564590-21-045712:8k_2_02:20]
First quarter of fiscal year 2022 financial results

[0001564590-21-045712:8k_2_02:21]
| • | Net revenues: $1.46 billion, compared to $1.30 billion in the first quarter of fiscal year 2021 |  |

[0001564590-21-045712:8k_2_02:22]
|  | o | Hybrid Cloud revenue: $1.38 billion, compared to $1.27 billion in the first quarter of fiscal year 2021 |  |

[0001564590-21-045712:8k_2_02:23]
|  | o | Public Cloud revenue: $79 million, compared to $31 million in the first quarter of fiscal year 2021 |  |

[0001564590-21-045712:8k_2_02:24]
| • | Net income: GAAP net income of $202 million, compared to $77 million in the first quarter of fiscal year 2021; non-GAAP net income3 of $263 million, compared to $163 million in the first quarter of fiscal year 2021 |  |

[0001564590-21-045712:8k_2_02:25]
| • | Earnings per share: GAAP net income per share4 of $0.88, compared to $0.35 in the first quarter of fiscal year 2021; non-GAAP net income per share of $1.15, compared to $0.73 in the first quarter of fiscal year 2021 |  |

[0001564590-21-045712:8k_2_02:26]
| • | Cash, cash equivalents and investments: $4.55 billion at the end of the first quarter of fiscal year 2022 |  |

[0001564590-21-045712:8k_2_02:27]
| • | Cash provided by operations: $242 million, compared to $240 million in the first quarter of fiscal year 2021 |  |

[0001564590-21-045712:8k_2_02:28]
| • | Share repurchase and dividends: Returned $212 million to shareholders through share repurchases and cash dividends |  |

[0001564590-21-045712:8k_2_02:29]
Second quarter of fiscal year 2022 financial outlook

[0001564590-21-045712:8k_2_02:30]
The Company provided the following financial guidance for the second quarter of fiscal year 2022:

[0001564590-21-045712:8k_2_02:31]
| Net revenues are expected to be in the range of: | $1.49 billion to $1.59 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $0.88 - $0.98 | $1.14 - $1.24 |

[0001564590-21-045712:8k_2_02:32]
Full fiscal year 2022 financial outlook

[0001564590-21-045712:8k_2_02:33]
The Company provided an update to their financial guidance for the full fiscal year 2022:

[0001564590-21-045712:8k_2_02:34]
| Net revenues are expected to grow in the range of: | 8% to 9% |
| Public Cloud ARR5 is expected to exit the fiscal year in the range of: | $450 million to $500 million |

[0001564590-21-045712:8k_2_02:35]
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be: | ~67% | ~68% |
| Operating margins are expected to be: | 18% - 19% | 23% - 24% |
| Effective tax rate is expected to be: | ~21% | ~19% |
| Earnings per share is expected to be in the range of: | $3.83 - $4.03 | $4.85 - $5.05 |

[0001564590-21-045712:8k_2_02:36]
Dividend

[0001564590-21-045712:8k_2_02:37]
The next cash dividend of $0.50 per share is to be paid on October 27, 2021, to shareholders of record as of the close of business on October 8, 2021.

[0001564590-21-045712:8k_2_02:38]
First quarter of fiscal year 2022 business highlights

[0001564590-21-045712:8k_2_02:39]
Leading product innovation

[0001564590-21-045712:8k_2_02:40]
| • | NetApp introduced new FlexPod™ capabilities, including intelligent application placement across on-premises and cloud, automated hybrid cloud data workflows, and the ability to consume FlexPod as a fully managed, cloudlike service. |  |

[0001564590-21-045712:8k_2_02:41]
| • | NetApp released StorageGRID™ 11.5 with support for data encryption using external key management, compliance, and ransomware protection with S3 object locks, and increased performance with intelligent load balancing. |  |

[0001564590-21-045712:8k_2_02:42]
| • | NetApp announced ONTAP™ 9.9 software with security enhancements, new integrated data protection capabilities, and improved SAN performance. |  |

[0001564590-21-045712:8k_2_02:43]
| • | NetApp extended Astra™ Control to support on-premises data centers, giving customers the choice to use Astra Control Service, a fully managed cloud service operated by NetApp for the public cloud, or to run Astra Control Center software for their on-premises data centers. |  |

[0001564590-21-045712:8k_2_02:44]
| • | NetApp announced availability of SnapCenter™ 4.5, offering new security and automation features, as well as functionalities developed for VMware, Oracle, and SAP HANA plug-ins. |  |

[0001564590-21-045712:8k_2_02:45]
| • | NetApp announced Keystone™ Flex Subscription 2.1 with new features for service providers, a partner-delivered FlexPod as-a-service solution, additional cloud support, and integration with Equinix colocation services. |  |

[0001564590-21-045712:8k_2_02:46]
| • | Spot by NetApp™ introduced Ocean Insights, a new analytical tool that gives users a full view of their clusters and then previews the potential savings from Ocean. |  |

[0001564590-21-045712:8k_2_02:47]
| • | Spot by NetApp extends Ocean’s coverage of Kubernetes to application delivery with Ocean for Continuous Delivery (CD). Ocean CD provides complete deployment and verification automation in one fully managed solution. |  |

[0001564590-21-045712:8k_2_02:48]
| • | NetApp acquired Data Mechanics to accelerate delivery of the roadmap for Spot Wave, an infrastructure and operation optimization platform for high-growth data analytics and machine learning workloads in the cloud. |  |

[0001564590-21-045712:8k_2_02:49]
| • | Spot by NetApp announced Spot PC, a fully managed, continuously optimized cloud desktop as a service for Azure Virtual Desktop and Windows 365. |  |

[0001564590-21-045712:8k_2_02:50]
| • | Spot by NetApp joined AWS CloudFormation Public Registry, enabling customers to use CloudFormation easily and instantly to provision cloud infrastructure through Spot Elastigroup, saving time and optimizing cloud spend and utilization. |  |

[0001564590-21-045712:8k_2_02:51]
Growing partnerships with customers in mind

[0001564590-21-045712:8k_2_02:52]
| • | Development hub for the world’s most demanding AI enterprises, NVIDIA Base Command Platform is a premium monthly subscription jointly offered by NVIDIA and NetApp and includes access to the record-breaking performance of NVIDIA DGX SuperPOD AI supercomputers and NetApp data management. |  |

[0001564590-21-045712:8k_2_02:53]
| • | NetApp and Splunk announced official certification for multisite architectures based on Splunk SmartStore and NetApp StorageGRID object storage, helping more customers transition from Splunk classic to take advantage of more compute/storage elasticity and cost efficiencies to achieve longer data retention at scale. |  |

[0001564590-21-045712:8k_2_02:54]
| • | NetApp celebrated the successful 10-year partnership with Cisco by further enhancing the FlexPod customer experience with the new Intersight and ONTAP integrated management solution. NetApp and executive leadership continue to be recognized |  |

[0001564590-21-045712:8k_2_02:55]
| • | NetApp President César Cernuda was honored by the Spanish monarchy with the prestigious Officer's Cross in the Order of Civil Merit. |  |

[0001564590-21-045712:8k_2_02:56]
| • | NetApp won Microsoft’s Global Customer Experience Partner of the Year award. |  |

[0001564590-21-045712:8k_2_02:57]
| • | NetApp won Microsoft’s SAP on Azure US Partner of the Year award. |  |

[0001564590-21-045712:8k_2_02:58]
Webcast and conference call information

[0001564590-21-045712:8k_2_02:59]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today.

[0001564590-21-045712:8k_2_02:60]
###

[0001564590-21-045712:8k_2_02:61]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001564590-21-045712:8k_2_02:62]
Footnotes

[0001564590-21-045712:8k_2_02:63]
1All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0001564590-21-045712:8k_2_02:64]
2Refer to the NetApp Usage of Non-GAAP Financial Information section below for an explanation of billings and free cash flow.

[0001564590-21-045712:8k_2_02:65]
3Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) gains/losses on the sale of investments in equity securities, (i) debt extinguishment costs, (j) COVID-19 charges and (k) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-21-045712:8k_2_02:66]
4GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0001564590-21-045712:8k_2_02:67]
5Public Cloud annualized revenue run rate (ARR) is calculated as the annualized value of all Public Cloud customer commitments with the assumption that any commitment expiring during the next 12 months will be renewed with its existing terms.

[0001564590-21-045712:8k_2_02:68]
NetApp usage of non-GAAP financial information

[0001564590-21-045712:8k_2_02:69]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share. NetApp also presents the hardware and software components of our GAAP product revenues. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0001564590-21-045712:8k_2_02:70]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations.

[0001564590-21-045712:8k_2_02:71]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-21-045712:8k_2_02:72]
NetApp believes that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0001564590-21-045712:8k_2_02:73]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0001564590-21-045712:8k_2_02:74]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-21-045712:8k_2_02:75]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-21-045712:8k_2_02:76]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-21-045712:8k_2_02:77]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-21-045712:8k_2_02:78]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-21-045712:8k_2_02:79]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0001564590-21-045712:8k_2_02:80]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-21-045712:8k_2_02:81]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-21-045712:8k_2_02:82]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0001564590-21-045712:8k_2_02:83]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0001564590-21-045712:8k_2_02:84]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0001564590-21-045712:8k_2_02:85]
J. COVID-19 charges. NetApp has excluded certain non-recurring expenses incurred as a direct result of the COVID-19 pandemic. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0001564590-21-045712:8k_2_02:86]
K. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-21-045712:8k_2_02:87]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-21-045712:8k_2_02:88]
About NetApp

[0001564590-21-045712:8k_2_02:89]
In a world full of generalists, NetApp is a specialist. We’re focused on one thing, helping your business get the most out of your data. NetApp brings the enterprise-grade data services you rely on into the cloud, and the simple flexibility of cloud into the data center. Our industry-leading solutions work across diverse customer environments and the world’s biggest public clouds. As a cloud-led, data-centric software company, only NetApp can help build your unique data fabric, simplify and connect your cloud, and securely deliver the right data, services, and applications to the right people—anytime, anywhere.

[0001564590-21-045712:8k_2_02:90]
NETAPP, INC.

[0001564590-21-045712:8k_2_02:91]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-21-045712:8k_2_02:92]
(In millions)

[0001564590-21-045712:8k_2_02:93]
(Unaudited)

[0001564590-21-045712:8k_2_02:94]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,547 |  |  | $ | 4,596 |  |
| Accounts receivable |  |  | 655 |  |  |  | 945 |  |
| Inventories |  |  | 108 |  |  |  | 114 |  |
| Other current assets |  |  | 321 |  |  |  | 346 |  |
| Total current assets |  |  | 5,631 |  |  |  | 6,001 |  |
| Property and equipment, net |  |  | 533 |  |  |  | 525 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,147 |  |  |  | 2,140 |  |
| Other non-current assets |  |  | 845 |  |  |  | 694 |  |
| Total assets |  | $ | 9,156 |  |  | $ | 9,360 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 368 |  |  | $ | 420 |  |
| Accrued expenses |  |  | 747 |  |  |  | 970 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,988 |  |  |  | 2,062 |  |
| Total current liabilities |  |  | 3,103 |  |  |  | 3,452 |  |
| Long-term debt |  |  | 2,633 |  |  |  | 2,632 |  |
| Other long-term liabilities |  |  | 784 |  |  |  | 650 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,916 |  |  |  | 1,941 |  |
| Total liabilities |  |  | 8,436 |  |  |  | 8,675 |  |
| Stockholders' equity |  |  | 720 |  |  |  | 685 |  |
| Total liabilities and stockholders' equity |  | $ | 9,156 |  |  | $ | 9,360 |  |

[0001564590-21-045712:8k_2_02:95]
NETAPP, INC.

[0001564590-21-045712:8k_2_02:96]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-21-045712:8k_2_02:97]
(In millions, except per share amounts)

[0001564590-21-045712:8k_2_02:98]
(Unaudited)

[0001564590-21-045712:8k_2_02:99]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Net revenues: |  |  |  |  |  |  |  |  |
| Product |  | $ | 730 |  |  | $ | 627 |  |
| Services |  |  | 728 |  |  |  | 676 |  |
| Net revenues |  |  | 1,458 |  |  |  | 1,303 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 329 |  |  |  | 316 |  |
| Cost of services |  |  | 130 |  |  |  | 115 |  |
| Total cost of revenues |  |  | 459 |  |  |  | 431 |  |
| Gross profit |  |  | 999 |  |  |  | 872 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 451 |  |  |  | 429 |  |
| Research and development |  |  | 210 |  |  |  | 233 |  |
| General and administrative |  |  | 66 |  |  |  | 61 |  |
| Restructuring charges |  |  | 22 |  |  |  | 5 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 8 |  |
| Total operating expenses |  |  | 750 |  |  |  | 736 |  |
| Income from operations |  |  | 249 |  |  |  | 136 |  |
| Other expense, net |  |  | (12 | ) |  |  | (32 | ) |
| Income before income taxes |  |  | 237 |  |  |  | 104 |  |
| Provision for income taxes |  |  | 35 |  |  |  | 27 |  |
| Net income |  | $ | 202 |  |  | $ | 77 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.91 |  |  | $ | 0.35 |  |
| Diluted |  | $ | 0.88 |  |  | $ | 0.35 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |
| Basic |  |  | 223 |  |  |  | 221 |  |
| Diluted |  |  | 229 |  |  |  | 222 |  |

[0001564590-21-045712:8k_2_02:100]
NETAPP, INC.

[0001564590-21-045712:8k_2_02:101]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-21-045712:8k_2_02:102]
(In millions)

[0001564590-21-045712:8k_2_02:103]
(Unaudited)

[0001564590-21-045712:8k_2_02:104]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 202 |  |  | $ | 77 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 46 |  |  |  | 49 |  |
| Non-cash operating lease cost |  |  | 13 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 53 |  |  |  | 54 |  |
| Deferred income taxes |  |  | (15 | ) |  |  | — |  |
| Other items, net |  |  | 4 |  |  |  | 25 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 287 |  |  |  | 391 |  |
| Inventories |  |  | 6 |  |  |  | 9 |  |
| Accounts payable |  |  | (51 | ) |  |  | (29 | ) |
| Accrued expenses |  |  | (242 | ) |  |  | (186 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (82 | ) |  |  | (158 | ) |
| Long-term taxes payable |  |  | (8 | ) |  |  | 6 |  |
| Changes in other operating assets and liabilities, net |  |  | 29 |  |  |  | (11 | ) |
| Net cash provided by operating activities |  |  | 242 |  |  |  | 240 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 11 |  |  |  | 85 |  |
| Purchases of property and equipment |  |  | (51 | ) |  |  | (52 | ) |
| Proceeds from sale of properties |  |  | — |  |  |  | 6 |  |
| Acquisitions of businesses, net of cash acquired |  |  | (14 | ) |  |  | (350 | ) |
| Net cash used in investing activities |  |  | (54 | ) |  |  | (311 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 53 |  |  |  | 48 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (57 | ) |  |  | (33 | ) |
| Repurchase of common stock |  |  | (100 | ) |  |  | — |  |
| Repayments of commercial paper notes, original maturities of three months or less, net |  |  | — |  |  |  | (370 | ) |
| Issuance of debt, net of issuance costs |  |  | — |  |  |  | 2,057 |  |
| Repayments and extinguishment of debt |  |  | — |  |  |  | (589 | ) |
| Dividends paid |  |  | (112 | ) |  |  | (107 | ) |
| Other financing activities, net |  |  | (2 | ) |  |  | (3 | ) |
| Net cash (used in) provided by financing activities |  |  | (218 | ) |  |  | 1,003 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (5 | ) |  |  | 43 |  |
| Net change in cash, cash equivalents and restricted cash |  |  | (35 | ) |  |  | 975 |  |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 4,535 |  |  |  | 2,666 |  |
| End of period |  | $ | 4,500 |  |  | $ | 3,641 |  |

[0001564590-21-045712:8k_2_02:105]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| Product |  | $ | 730 |  |  | $ | 840 |  |  | $ | 627 |  |
| Support |  |  | 578 |  |  |  | 576 |  |  |  | 577 |  |
| Professional and Other Services |  |  | 71 |  |  |  | 73 |  |  |  | 68 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,379 |  |  |  | 1,489 |  |  |  | 1,272 |  |
| Public Cloud Segment Net Revenues |  |  | 79 |  |  |  | 66 |  |  |  | 31 |  |
| Net Revenues |  | $ | 1,458 |  |  | $ | 1,555 |  |  | $ | 1,303 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| Product |  | $ | 404 |  |  | $ | 456 |  |  | $ | 322 |  |
| Support |  |  | 530 |  |  |  | 525 |  |  |  | 526 |  |
| Professional and Other Services |  |  | 20 |  |  |  | 18 |  |  |  | 20 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 954 |  |  |  | 999 |  |  |  | 868 |  |
| Public Cloud Segment Gross Profit |  |  | 56 |  |  |  | 47 |  |  |  | 18 |  |
| Total Segments Gross Profit |  |  | 1,010 |  |  |  | 1,046 |  |  |  | 886 |  |
| Amortization of Intangible Assets |  |  | (7 | ) |  |  | (7 | ) |  |  | (10 | ) |
| Stock-based Compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (4 | ) |
| Unallocated Cost of Revenues |  |  | (11 | ) |  |  | (11 | ) |  |  | (14 | ) |
| Gross Profit |  | $ | 999 |  |  | $ | 1,035 |  |  | $ | 872 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| Product |  |  | 55.3 | % |  |  | 54.3 | % |  |  | 51.4 | % |
| Support |  |  | 91.7 | % |  |  | 91.1 | % |  |  | 91.2 | % |
| Professional and Other Services |  |  | 28.2 | % |  |  | 24.7 | % |  |  | 29.4 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 69.2 | % |  |  | 67.1 | % |  |  | 68.2 | % |
| Public Cloud Segment Gross Margin |  |  | 70.9 | % |  |  | 71.2 | % |  |  | 58.1 | % |
| Product Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| Total |  | $ | 730 |  |  | $ | 840 |  |  | $ | 627 |  |
| Software* |  | $ | 414 |  |  | $ | 480 |  |  | $ | 311 |  |
| Hardware* |  | $ | 316 |  |  | $ | 360 |  |  | $ | 316 |  |
| * Our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation. We have provided a breakdown of our GAAP product revenues into the software and hardware components to display the significance of software included in total product revenues. |  |
| Software and recurring support and public cloud revenue |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| Product - Software |  | $ | 414 |  |  | $ | 480 |  |  | $ | 311 |  |
| Support |  |  | 578 |  |  |  | 576 |  |  |  | 577 |  |
| Public Cloud |  |  | 79 |  |  |  | 66 |  |  |  | 31 |  |
| Software and recurring support and public cloud revenue* |  | $ | 1,071 |  |  | $ | 1,122 |  |  | $ | 919 |  |
| Software and recurring support and public cloud revenue as a percentage of net revenues |  |  | 73 | % |  |  | 72 | % |  |  | 71 | % |

[0001564590-21-045712:8k_2_02:106]
| *Software and recurring support and public cloud revenue is a non-GAAP measure because it includes the software component of our product revenues, but not the hardware component. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'22 |  |  | % of Q4 FY'21 |  |  | % of Q1 FY'21 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 54 | % |  |  | 53 | % |  |  | 54 | % |
| Americas Commercial |  |  | 43 | % |  |  | 44 | % |  |  | 43 | % |
| U.S. Public Sector |  |  | 11 | % |  |  | 9 | % |  |  | 12 | % |
| EMEA |  |  | 31 | % |  |  | 32 | % |  |  | 29 | % |
| Asia Pacific |  |  | 15 | % |  |  | 15 | % |  |  | 16 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'22 |  |  | % of Q4 FY'21 |  |  | % of Q1 FY'21 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 23 | % |  |  | 23 | % |  |  | 22 | % |
| Indirect |  |  | 77 | % |  |  | 77 | % |  |  | 78 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| Non-GAAP Income from Operations |  | $ | 336 |  |  | $ | 358 |  |  | $ | 213 |  |
| % of Net Revenues |  |  | 23.0 | % |  |  | 23.0 | % |  |  | 16.3 | % |
| Non-GAAP Income before Income Taxes |  | $ | 324 |  |  | $ | 339 |  |  | $ | 195 |  |
| Non-GAAP Effective Tax Rate |  |  | 18.8 | % |  |  | 20.9 | % |  |  | 16.4 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| Non-GAAP Net Income |  | $ | 263 |  |  | $ | 268 |  |  | $ | 163 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 229 |  |  |  | 229 |  |  |  | 222 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.15 |  |  | $ | 1.17 |  |  | $ | 0.73 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,904 |  |  | $ | 4,003 |  |  | $ | 3,620 |  |
| DSO (days) |  |  | 41 |  |  |  | 55 |  |  |  | 45 |  |
| DPO (days) |  |  | 73 |  |  |  | 74 |  |  |  | 90 |  |
| Inventory Turns |  |  | 17 |  |  |  | 18 |  |  |  | 13 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| Net Cash Provided by Operating Activities |  | $ | 242 |  |  | $ | 559 |  |  | $ | 240 |  |
| Purchases of Property and Equipment |  | $ | 51 |  |  | $ | 38 |  |  | $ | 52 |  |
| Free Cash Flow |  | $ | 191 |  |  | $ | 521 |  |  | $ | 188 |  |
| Free Cash Flow as % of Net Revenues |  |  | 13.1 | % |  |  | 33.5 | % |  |  | 14.4 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |

[0001564590-21-045712:8k_2_02:107]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| NET INCOME |  | $ | 202 |  |  | $ | 334 |  |  | $ | 77 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 9 |  |  |  | 10 |  |
| Stock-based compensation |  |  | 53 |  |  |  | 48 |  |  |  | 54 |  |
| Litigation settlements |  |  | 2 |  |  |  | — |  |  |  | — |  |
| Restructuring charges |  |  | 22 |  |  |  | — |  |  |  | 5 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 2 |  |  |  | 8 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (156 | ) |  |  | — |  |
| Debt extinguishment costs |  |  | — |  |  |  | — |  |  |  | 14 |  |
| Income tax effects |  |  | (26 | ) |  |  | 18 |  |  |  | (16 | ) |
| Income tax expenses from integration of acquired companies |  |  | — |  |  |  | 13 |  |  |  | 11 |  |
| NON-GAAP NET INCOME |  | $ | 263 |  |  | $ | 268 |  |  | $ | 163 |  |
| COST OF REVENUES |  | $ | 459 |  |  | $ | 520 |  |  | $ | 431 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (7 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (4 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 448 |  |  | $ | 509 |  |  | $ | 417 |  |
| COST OF PRODUCT REVENUES |  | $ | 329 |  |  | $ | 387 |  |  | $ | 316 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  | (2 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 326 |  |  | $ | 384 |  |  | $ | 305 |  |
| COST OF SERVICES REVENUES |  | $ | 130 |  |  | $ | 133 |  |  | $ | 115 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | — |  |
| Stock-based compensation |  | $ | (3 | ) |  | $ | (3 | ) |  | $ | (3 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 122 |  |  | $ | 125 |  |  | $ | 112 |  |
| GROSS PROFIT |  | $ | 999 |  |  | $ | 1,035 |  |  | $ | 872 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 7 |  |  |  | 7 |  |  |  | 10 |  |
| Stock-based compensation |  |  | 4 |  |  |  | 4 |  |  |  | 4 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,010 |  |  | $ | 1,046 |  |  | $ | 886 |  |

[0001564590-21-045712:8k_2_02:108]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| SALES AND MARKETING EXPENSES |  | $ | 451 |  |  | $ | 447 |  |  | $ | 429 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  | (2 | ) |  |  | — |  |
| Stock-based compensation |  |  | (26 | ) |  |  | (22 | ) |  |  | (25 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 423 |  |  | $ | 423 |  |  | $ | 404 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 210 |  |  | $ | 221 |  |  | $ | 233 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (15 | ) |  |  | (15 | ) |  |  | (19 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 195 |  |  | $ | 206 |  |  | $ | 214 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 66 |  |  | $ | 66 |  |  | $ | 61 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (8 | ) |  |  | (7 | ) |  |  | (6 | ) |
| Litigation settlements |  |  | (2 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 56 |  |  | $ | 59 |  |  | $ | 55 |  |
| RESTRUCTURING CHARGES |  | $ | 22 |  |  | $ | — |  |  | $ | 5 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (22 | ) |  |  | — |  |  |  | (5 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  |  | $ | (156 | ) |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | 156 |  |  |  | — |  |
| NON-GAAP GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 1 |  |  | $ | 2 |  |  | $ | 8 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (1 | ) |  |  | (2 | ) |  |  | (8 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 750 |  |  | $ | 580 |  |  | $ | 736 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  | (2 | ) |  |  | — |  |
| Stock-based compensation |  |  | (49 | ) |  |  | (44 | ) |  |  | (50 | ) |
| Litigation settlements |  |  | (2 | ) |  |  | — |  |  |  | — |  |
| Restructuring charges |  |  | (22 | ) |  |  | — |  |  |  | (5 | ) |
| Acquisition-related expense |  |  | (1 | ) |  |  | (2 | ) |  |  | (8 | ) |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | 156 |  |  |  | — |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 674 |  |  | $ | 688 |  |  | $ | 673 |  |

[0001564590-21-045712:8k_2_02:109]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| INCOME FROM OPERATIONS |  | $ | 249 |  |  | $ | 455 |  |  | $ | 136 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 9 |  |  |  | 10 |  |
| Stock-based compensation |  |  | 53 |  |  |  | 48 |  |  |  | 54 |  |
| Litigation settlements |  |  | 2 |  |  |  | — |  |  |  | — |  |
| Restructuring charges |  |  | 22 |  |  |  | — |  |  |  | 5 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 2 |  |  |  | 8 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (156 | ) |  |  | — |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 336 |  |  | $ | 358 |  |  | $ | 213 |  |
| OTHER EXPENSE, NET |  | $ | (12 | ) |  | $ | (19 | ) |  | $ | (32 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt extinguishment costs |  |  | — |  |  |  | — |  |  |  | 14 |  |
| NON-GAAP OTHER EXPENSE, NET |  | $ | (12 | ) |  | $ | (19 | ) |  | $ | (18 | ) |
| INCOME BEFORE INCOME TAXES |  | $ | 237 |  |  | $ | 436 |  |  | $ | 104 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 9 |  |  |  | 10 |  |
| Stock-based compensation |  |  | 53 |  |  |  | 48 |  |  |  | 54 |  |
| Litigation settlements |  |  | 2 |  |  |  | — |  |  |  | — |  |
| Restructuring charges |  |  | 22 |  |  |  | — |  |  |  | 5 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 2 |  |  |  | 8 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (156 | ) |  |  | — |  |
| Debt extinguishment costs |  |  | — |  |  |  | — |  |  |  | 14 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 324 |  |  | $ | 339 |  |  | $ | 195 |  |
| PROVISION FOR INCOME TAXES |  | $ | 35 |  |  | $ | 102 |  |  | $ | 27 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 26 |  |  |  | (18 | ) |  |  | 16 |  |
| Income tax expenses from integration of acquired companies |  |  | — |  |  |  | (13 | ) |  |  | (11 | ) |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 61 |  |  | $ | 71 |  |  | $ | 32 |  |
| NET INCOME PER SHARE |  | $ | 0.88 |  |  | $ | 1.46 |  |  | $ | 0.35 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.04 |  |  |  | 0.04 |  |  |  | 0.05 |  |
| Stock-based compensation |  |  | 0.23 |  |  |  | 0.21 |  |  |  | 0.24 |  |
| Litigation settlements |  |  | 0.01 |  |  |  | — |  |  |  | — |  |
| Restructuring charges |  |  | 0.10 |  |  |  | — |  |  |  | 0.02 |  |
| Acquisition-related expense |  |  | — |  |  |  | 0.01 |  |  |  | 0.04 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (0.68 | ) |  |  | — |  |
| Debt extinguishment costs |  | — |  |  | — |  |  |  | 0.06 |  |
| Income tax effects |  |  | (0.11 | ) |  |  | 0.08 |  |  |  | (0.07 | ) |
| Income tax expenses from integration of acquired companies |  | — |  |  |  | 0.06 |  |  |  | 0.05 |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.15 |  |  | $ | 1.17 |  |  | $ | 0.73 |  |

[0001564590-21-045712:8k_2_02:110]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| Gross margin-GAAP |  |  | 68.5 | % |  |  | 66.6 | % |  |  | 66.9 | % |
| Cost of revenues adjustments |  |  | 0.8 | % |  |  | 0.7 | % |  |  | 1.1 | % |
| Gross margin-Non-GAAP |  |  | 69.3 | % |  |  | 67.3 | % |  |  | 68.0 | % |
| GAAP cost of revenues |  | $ | 459 |  |  | $ | 520 |  |  | $ | 431 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (7 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (4 | ) |
| Non-GAAP cost of revenues |  | $ | 448 |  |  | $ | 509 |  |  | $ | 417 |  |
| Net revenues |  | $ | 1,458 |  |  | $ | 1,555 |  |  | $ | 1,303 |  |

[0001564590-21-045712:8k_2_02:111]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| Product gross margin-GAAP |  |  | 54.9 | % |  |  | 53.9 | % |  |  | 49.6 | % |
| Cost of product revenues adjustments |  |  | 0.4 | % |  |  | 0.4 | % |  |  | 1.8 | % |
| Product gross margin-Non-GAAP |  |  | 55.3 | % |  |  | 54.3 | % |  |  | 51.4 | % |
| GAAP cost of product revenues |  | $ | 329 |  |  | $ | 387 |  |  | $ | 316 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  | (2 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 326 |  |  | $ | 384 |  |  | $ | 305 |  |
| Product revenues |  | $ | 730 |  |  | $ | 840 |  |  | $ | 627 |  |

[0001564590-21-045712:8k_2_02:112]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| Services gross margin-GAAP |  |  | 82.1 | % |  |  | 81.4 | % |  |  | 83.0 | % |
| Cost of services revenues adjustment |  |  | 1.1 | % |  |  | 1.1 | % |  |  | 0.4 | % |
| Services gross margin-Non-GAAP |  |  | 83.2 | % |  |  | 82.5 | % |  |  | 83.4 | % |
| GAAP cost of services revenues |  | $ | 130 |  |  | $ | 133 |  |  | $ | 115 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | — |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (3 | ) |
| Non-GAAP cost of services revenues |  | $ | 122 |  |  | $ | 125 |  |  | $ | 112 |  |
| Services revenues |  | $ | 728 |  |  | $ | 715 |  |  | $ | 676 |  |

[0001564590-21-045712:8k_2_02:113]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| GAAP effective tax rate |  |  | 14.8 | % |  |  | 23.4 | % |  |  | 26.0 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 4.1 | % |  |  | 0.5 | % |  |  | 1.0 | % |
| Income tax expenses from integration of acquired companies |  |  | — | % |  |  | (3.0 | )% |  |  | (10.6 | )% |
| Non-GAAP effective tax rate |  |  | 18.8 | % |  |  | 20.9 | % |  |  | 16.4 | % |

[0001564590-21-045712:8k_2_02:114]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| Net cash provided by operating activities |  | $ | 242 |  |  | $ | 559 |  |  | $ | 240 |  |
| Purchases of property and equipment |  |  | (51 | ) |  |  | (38 | ) |  |  | (52 | ) |
| Free cash flow |  | $ | 191 |  |  | $ | 521 |  |  | $ | 188 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY22 |  |  | Q4'FY21 |  |  | Q1'FY21 |  |
| Net revenues |  | $ | 1,458 |  |  | $ | 1,555 |  |  | $ | 1,303 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | (82 | ) |  |  | 183 |  |  |  | (158 | ) |
| Billings |  | $ | 1,376 |  |  | $ | 1,738 |  |  | $ | 1,145 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0001564590-21-045712:8k_2_02:115]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| SECOND QUARTER FISCAL 2022 |
|  |  | Second Quarter |
|  |  | Fiscal 2022 |
| Non-GAAP Guidance - Net Income Per Share |  | $1.14 - $1.24 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the Second Quarter Fiscal 2022: |  |  |
| Amortization of intangible assets |  | ($0.04) |
| Stock-based compensation expense |  | ($0.25) |
| Income tax effects |  | $0.03 |
| Total Adjustments |  | ($0.26) |
| GAAP Guidance - Net Income Per Share |  | $0.88 - $0.98 |

[0001564590-21-045712:8k_2_02:116]
Some items may not add or recalculate due to rounding.

[0001564590-21-045712:8k_2_02:117]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| FISCAL 2022 |  |
| (Unaudited) |  |
|  |  | GROSS MARGIN |  |
| Gross Margin - Non-GAAP Guidance |  | ~68% |  |
| Adjustment: |  |  |  |  |
| Cost of revenues adjustments |  | (1)% |  |
| Gross Margin - GAAP Guidance |  | ~67% |  |
|  |  | OPERATING MARGIN |  |
| Operating Margin - Non-GAAP Guidance |  | 23% - 24% |  |
| Adjustments: |  |  |  |  |
| Amortization of intangible assets |  | (1)% |  |
| Stock-based compensation expense |  | (4)% |  |
| Operating Margin - GAAP Guidance |  | 18% - 19% |  |
|  |  | EFFECTIVE TAX RATE |  |
| Effective Tax Rate - Non-GAAP Guidance |  | ~19% |  |
| Adjustment: |  |  |  |  |
| Income tax effects |  | 2% |  |
| Effective Tax Rate - GAAP Guidance |  | ~21% |  |

[0001564590-21-045712:8k_2_02:118]
Some items may not add or recalculate due to rounding.

[0001564590-21-045712:8k_2_02:119]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FISCAL 2022 |
|  |  | Fiscal 2022 |
| Non-GAAP Guidance - Net Income Per Share |  | $4.85 - $5.05 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2022: |  |  |
| Amortization of intangible assets |  | ($0.16) |
| Stock-based compensation expense |  | ($0.98) |
| Income tax effects |  | $0.12 |
| Total Adjustments |  | ($1.02) |
| GAAP Guidance - Net Income Per Share |  | $3.83 - $4.03 |

[0001564590-21-045712:8k_2_02:120]
Some items may not add or recalculate due to rounding.

[0001564590-21-045712:8k_2_02:121]
Contacts:

[0001564590-21-045712:8k_2_02:122]
(Press)

[0001564590-21-045712:8k_2_02:123]
Chris Drago

[0001564590-21-045712:8k_2_02:124]
1 831 900 888

[0001564590-21-045712:8k_2_02:125]
chris.drago@netapp.com

[0001564590-21-045712:8k_2_02:126]
(Investors)

[0001564590-21-045712:8k_2_02:127]
Lance Berger

[0001564590-21-045712:8k_2_02:128]
1 408 822 6628

[0001564590-21-045712:8k_2_02:129]
lance.berger@netapp.com
