# NTAP note change history — 0001564590-21-009843 → 0001564590-21-046976


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-09-02):
[0001564590-21-046976:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 30, 2021, we had $614 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 30, 2021 and April 30, 2021, such liability amounted to $13 million and $15 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2021-03-01, similarity 0.9928):
[0001564590-21-009843:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 29, 2021, we had $602 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 29, 2021 and April 24, 2020, such liability amounted to $8 million and $6 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2021-09-02):
[0001564590-21-046976:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 30, 2021, we had $340 million in other purchase obligations.
  (was, 2021-03-01, similarity 0.9888):
[0001564590-21-009843:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 29, 2021, we had $181 million in other purchase obligations.

- changed (2021-09-02):
[0001564590-21-046976:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $17 million and $13 million of receivables during the three months ended July 30, 2021 and July 31, 2020, respectively.
  (was, 2021-03-01, similarity 0.9896):
[0001564590-21-009843:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $61 million and $49 million of receivables during the nine months ended January 29, 2021 and January 24, 2020, respectively.

- changed (2021-09-02):
[0001564590-21-046976:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of July 30, 2021 and April 30, 2021, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2021-03-01, similarity 0.9969):
[0001564590-21-009843:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of January 29, 2021 and April 24, 2020, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- changed (2021-09-02):
[0001564590-21-046976:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 30, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.
  (was, 2021-03-01, similarity 0.9961):
[0001564590-21-009843:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 29, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- added (2021-09-02):
[0001564590-21-046976:note_history:6]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. NetApp’s Motion to Dismiss was granted and on February 26, 2021 and the judge entered judgment in favor of NetApp. On March 26, 2021, Plaintiffs filed a notice of appeal. The parties subsequently engaged in settlement discussions, and on July 30, 2021 entered into a Memorandum of Understanding (“MOU”) providing for the settlement of the class action.  Pursuant to the terms of MOU, NetApp has agreed to pay approximately $2.0 million in connection with the settlement, and this amount was accrued during the three months ended July 30, 2021. The parties further agreed to negotiate in good faith to execute definitive stipulations of settlement and related documents to be filed with the court, which will not contain any admission of liability, wrongdoing or responsibility by any of the parties and will provide that upon final approval of the settlement, the class action will be dismissed with prejudice, with mutual releases by all parties. The settlement is subject to court approval.

- changed (2021-09-02):
[0001564590-21-046976:note_history:7]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.
  (was, 2021-03-01, similarity 0.9928):
[0001564590-21-009843:note_history:7]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

- changed (2021-09-02):
[0001564590-21-046976:note_history:8]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of July 30, 2021 related to such matters.
  (was, 2021-03-01, similarity 0.9961):
[0001564590-21-009843:note_history:8]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of January 29, 2021 related to such matters.

- removed (2021-09-02):
[0001564590-21-009843:note_history:9]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised

- removed (2021-09-02):
[0001564590-21-009843:note_history:10]
financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. On February 1, 2021, the District Court issued an order granting our motion to dismiss plaintiff’s amended class action complaint, and provided plaintiff leave to amend the complaint within 21 days. On February 22, 2021, plaintiff filed a notice of intent not to file a second amended complaint, but reserved his right to appeal the order granting our motion to dismiss. We believe the complaint is without merit and intend to defend the case vigorously.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-09-02):
[0001564590-21-046976:note_history:11]
NetApp, Inc. (we, us, or the Company) is a global cloud-led, data-centric software company that provides organizations the ability to manage and share their data across on-premises, private and public clouds. We provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.
  (was, 2021-03-01, similarity 0.6391):
[0001564590-21-009843:note_history:11]
NetApp, Inc. (we, us, or the Company) provides global organizations the ability to manage and share their data across on-premises, private and public clouds. Together with our partners, we provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.

- changed (2021-09-02):
[0001564590-21-046976:note_history:12]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2022, ending on April 29, 2022, is a 52-week year, with 13 weeks in each of its quarters. Fiscal year 2021, ended on April 30, 2021 was a 53-week year, with 14 weeks included in its first quarter and 13 weeks in each subsequent quarter.
  (was, 2021-03-01, similarity 0.8356):
[0001564590-21-009843:note_history:12]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2021, ending on April 30, 2021 is a 53-week year, with 14 weeks included in its first quarter and 13 weeks in each subsequent quarter. Fiscal year 2020, which ended on April 24, 2020, was a 52-week year, with 13 weeks in each of its quarters.

- changed (2021-09-02):
[0001564590-21-046976:note_history:13]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 30, 2021 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 30, 2021 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2021-03-01, similarity 0.9926):
[0001564590-21-009843:note_history:13]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2020 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 29, 2021 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- added (2021-09-02):
[0001564590-21-046976:note_history:14]
Segment Change

- added (2021-09-02):
[0001564590-21-046976:note_history:15]
Effective July 30, 2021, our Chief Operating Decision Maker, who is our Chief Executive Officer, realigned internal reporting and began using financial information for components of our business, organized based on category of product/solution, to evaluate performance and allocate resources. This resulted in the creation of two operating segments and two reportable segments for financial reporting purposes: Public Cloud and Hybrid Cloud.

- added (2021-09-02):
[0001564590-21-046976:note_history:16]
Public Cloud

- added (2021-09-02):
[0001564590-21-046976:note_history:17]
NetApp's Public Cloud segment offers a portfolio of products delivered primarily as-a-service, including related support, and made available on the world’s leading clouds. This portfolio includes storage services, cloud automation and optimization services, and cloud infrastructure monitoring services. Public Cloud includes certain reseller arrangements in which the timing of our consideration follows the end user consumption of the reseller services.

- added (2021-09-02):
[0001564590-21-046976:note_history:18]
Hybrid Cloud

- added (2021-09-02):
[0001564590-21-046976:note_history:19]
NetApp’s Hybrid Cloud segment offers a portfolio of storage and data management solutions that help customers build and integrate on-premises and private cloud environments. This portfolio is designed to operate with public clouds to unlock the potential of hybrid, multi-cloud operations. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-02):
[0001564590-21-046976:note_history:20]
|  |  | Effective Interest Rate |  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  | $ | 250 |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (17 | ) |  |  | (18 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,633 |  |  | $ | 2,632 |  |
  (was, 2021-03-01, similarity 0.8872):
[0001564590-21-009843:note_history:20]
|  |  | Effective Interest Rate |  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  | $ | — |  |  | $ | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | — |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | — |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | — |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 1,150 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (18 | ) |  |  | (4 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,632 |  |  | $ | 1,146 |  |

- added (2021-09-02):
[0001564590-21-046976:note_history:21]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were issued in June 2020. Interest on these Senior Notes is payable semi-annually in June and December.

- changed (2021-09-02):
[0001564590-21-046976:note_history:22]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September. Our 3.25% Senior Notes, with a principal amount of $250 million, were issued in December 2012 with interest paid semi-annually in June and December.
  (was, 2021-03-01, similarity 0.7802):
[0001564590-21-009843:note_history:22]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September. Our 3.25% Senior Notes, with a principal amount of $250 million, were issued in December 2012 with interest paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

- added (2021-09-02):
[0001564590-21-046976:note_history:23]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

- changed (2021-09-02):
[0001564590-21-046976:note_history:24]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 30, 2021, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2021-03-01, similarity 0.9946):
[0001564590-21-009843:note_history:24]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 29, 2021, we were in compliance with all covenants associated with the Senior Notes.

- changed (2021-09-02):
[0001564590-21-046976:note_history:25]
As of July 30, 2021, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2021-03-01, similarity 0.973):
[0001564590-21-009843:note_history:25]
As of January 29, 2021, our aggregate future principal debt maturities are as follows (in millions):

- changed (2021-09-02):
[0001564590-21-046976:note_history:26]
| Fiscal Year |  | Amount |  |
| 2022 |  | $ | — |  |
| 2023 |  |  | 250 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |
  (was, 2021-03-01, similarity 0.8865):
[0001564590-21-009843:note_history:26]
| Fiscal Year |  | Amount |  |
| 2023 |  | $ | 250 |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |

- changed (2021-09-02):
[0001564590-21-046976:note_history:27]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. While no commercial paper notes were outstanding as of July 30, 2021, we had commercial paper notes outstanding with an aggregate principal amount of $150 million, a weighted-average interest rate of 1.29%, and maturities primarily less than three months as of July 31, 2020. During the first three months of fiscal 2021, we received proceeds of $75 million from the issuance, and made repayments of $76 million for the settlement, of commercial paper notes with original maturities greater than three months.
  (was, 2021-03-01, similarity 0.9907):
[0001564590-21-009843:note_history:27]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. While no commercial paper notes were outstanding as of January 29, 2021, we had commercial paper notes outstanding with an aggregate principal amount of $523 million, a weighted-average interest rate of  2.01%, and maturities primarily less than three months as of April 24, 2020. During the first nine months of fiscal 2021, we received proceeds of $75 million from the issuance, and made repayments of $176 million for the settlement, of commercial paper notes with original maturities greater than three months.

- changed (2021-09-02):
[0001564590-21-046976:note_history:28]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of July 30, 2021, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.
  (was, 2021-03-01, similarity 0.9956):
[0001564590-21-009843:note_history:28]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 29, 2021, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.

- removed (2021-09-02):
[0001564590-21-009843:note_history:29]
In June 2020, we issued $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, for which we received total proceeds of approximately $2.0 billion, net of discount and issuance costs. Interest on these Senior Notes is payable semi-annually in June and December. On July 27, 2020, we extinguished our 3.375% Senior Notes due June 2021 for an aggregate cash redemption price of $513 million, plus accrued and unpaid interest. As part of the debt extinguishment, we recognized a loss of $14 million during the first quarter of fiscal 2021, which includes a cash redemption premium of $13 million and the write-off of unamortized discount and issuance costs totaling $1 million. The loss on extinguishment of debt is included in other income (expense), net in our condensed consolidated statement of operations for the nine months ended January 29, 2021.


## us-gaap:DebtPolicyTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-02):
[0001564590-21-046976:note_history:30]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 30, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.
  (was, 2021-03-01, similarity 0.9961):
[0001564590-21-009843:note_history:30]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 29, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-02):
[0001564590-21-046976:note_history:31]
|  |  | Effective Interest Rate |  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  | $ | 250 |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (17 | ) |  |  | (18 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,633 |  |  | $ | 2,632 |  |
  (was, 2021-03-01, similarity 0.8872):
[0001564590-21-009843:note_history:31]
|  |  | Effective Interest Rate |  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  | $ | — |  |  | $ | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | — |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | — |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | — |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 1,150 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (18 | ) |  |  | (4 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,632 |  |  | $ | 1,146 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-02):
[0001564590-21-046976:note_history:32]
As of July 30, 2021, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2021-03-01, similarity 0.973):
[0001564590-21-009843:note_history:32]
As of January 29, 2021, our aggregate future principal debt maturities are as follows (in millions):

- changed (2021-09-02):
[0001564590-21-046976:note_history:33]
| Fiscal Year |  | Amount |  |
| 2022 |  | $ | — |  |
| 2023 |  |  | 250 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |
  (was, 2021-03-01, similarity 0.8865):
[0001564590-21-009843:note_history:33]
| Fiscal Year |  | Amount |  |
| 2023 |  | $ | 250 |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2021-09-02):
[0001564590-21-009843:note_history:34]
The following table depicts the disaggregation of revenue by our products and services (in millions):

- removed (2021-09-02):
[0001564590-21-009843:note_history:35]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Product revenues |  | $ | 775 |  |  | $ | 787 |  |  | $ | 2,151 |  |  | $ | 2,202 |  |
| Software maintenance revenues |  | 334 |  |  | 263 |  |  | 938 |  |  | 767 |  |
| Hardware maintenance and other services revenues |  | 361 |  |  | 354 |  |  |  | 1,100 |  |  |  | 1,042 |  |
| Hardware maintenance support contracts |  | 293 |  |  | 293 |  |  | 896 |  |  |  | 863 |  |
| Professional and other services |  | 68 |  |  | 61 |  |  | 204 |  |  |  | 179 |  |
| Net revenues |  | $ | 1,470 |  |  | $ | 1,404 |  |  | $ | 4,189 |  |  | $ | 4,011 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2021-09-02):
[0001564590-21-009843:note_history:36]
6. Revenue

- removed (2021-09-02):
[0001564590-21-009843:note_history:37]
Disaggregation of revenue

- removed (2021-09-02):
[0001564590-21-009843:note_history:38]
The following table depicts the disaggregation of revenue by our products and services (in millions):

- removed (2021-09-02):
[0001564590-21-009843:note_history:39]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Product revenues |  | $ | 775 |  |  | $ | 787 |  |  | $ | 2,151 |  |  | $ | 2,202 |  |
| Software maintenance revenues |  | 334 |  |  | 263 |  |  | 938 |  |  | 767 |  |
| Hardware maintenance and other services revenues |  | 361 |  |  | 354 |  |  |  | 1,100 |  |  |  | 1,042 |  |
| Hardware maintenance support contracts |  | 293 |  |  | 293 |  |  | 896 |  |  |  | 863 |  |
| Professional and other services |  | 68 |  |  | 61 |  |  | 204 |  |  |  | 179 |  |
| Net revenues |  | $ | 1,470 |  |  | $ | 1,404 |  |  | $ | 4,189 |  |  | $ | 4,011 |  |

- removed (2021-09-02):
[0001564590-21-009843:note_history:40]
Revenues by geographic region are presented in Note 15 – Segment, Geographic, and Significant Customer Information.

- removed (2021-09-02):
[0001564590-21-009843:note_history:41]
Deferred revenue and financed unearned services revenue

- removed (2021-09-02):
[0001564590-21-009843:note_history:42]
The following table summarizes the components of our deferred revenue and financed unearned services balance as reported in our condensed consolidated balance sheets (in millions):

- removed (2021-09-02):
[0001564590-21-009843:note_history:43]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Deferred product revenue |  | $ | 68 |  |  | $ | 75 |  |
| Deferred services revenue |  |  | 3,690 |  |  |  | 3,567 |  |
| Financed unearned services revenue |  |  | 70 |  |  |  | 56 |  |
| Total |  | $ | 3,828 |  |  | $ | 3,698 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,953 |  |  | $ | 1,894 |  |
| Long-term |  |  | 1,875 |  |  |  | 1,804 |  |
| Total |  | $ | 3,828 |  |  | $ | 3,698 |  |

- removed (2021-09-02):
[0001564590-21-009843:note_history:44]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 16 – Commitments and Contingencies for additional information related to these arrangements.

- removed (2021-09-02):
[0001564590-21-009843:note_history:45]
The following tables summarize the activity related to deferred revenue and financed unearned services revenue (in millions):

- removed (2021-09-02):
[0001564590-21-009843:note_history:46]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Balance at beginning of period |  | $ | 3,698 |  |  | $ | 3,668 |  |
| Additions |  |  | 2,269 |  |  |  | 1,759 |  |
| Revenue recognized during the period |  |  | (2,139 | ) |  |  | (1,854 | ) |
| Balance at end of period |  | $ | 3,828 |  |  | $ | 3,573 |  |

- removed (2021-09-02):
[0001564590-21-009843:note_history:47]
During the nine months ended January 29, 2021 and January 24, 2020, we recognized $1,687 million and $1,504 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

- removed (2021-09-02):
[0001564590-21-009843:note_history:48]
As of January 29, 2021, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,828 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this

- removed (2021-09-02):
[0001564590-21-009843:note_history:49]
amount. We expect to recognize as revenue approximately 51% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 25% in the next 13 to 24 months, and the remainder thereafter.

- removed (2021-09-02):
[0001564590-21-009843:note_history:50]
Deferred commissions

- removed (2021-09-02):
[0001564590-21-009843:note_history:51]
The following tables summarize the activity related to deferred commissions and their balances as reported in our condensed consolidated balance sheets (in millions):

- removed (2021-09-02):
[0001564590-21-009843:note_history:52]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Balance at beginning of period |  | $ | 156 |  |  | $ | 172 |  |
| Additions |  |  | 89 |  |  |  | 52 |  |
| Expense recognized during the period |  |  | (73 | ) |  |  | (72 | ) |
| Balance at end of period |  | $ | 172 |  |  | $ | 152 |  |

- removed (2021-09-02):
[0001564590-21-009843:note_history:53]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Other current assets |  | $ | 71 |  |  | $ | 67 |  |
| Other non-current assets |  |  | 101 |  |  |  | 89 |  |
| Total deferred commissions |  | $ | 172 |  |  | $ | 156 |  |
