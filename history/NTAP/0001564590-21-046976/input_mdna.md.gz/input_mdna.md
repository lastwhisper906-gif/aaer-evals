# NTAP MD&A — 0001564590-21-046976


## mdna

[0001564590-21-046976:mdna:1]
[same as prior period, unchanged from 0001564590-21-009843:mdna:1]

[0001564590-21-046976:mdna:2]
[same as prior period, unchanged from 0001564590-21-009843:mdna:2]

[0001564590-21-046976:mdna:3]
[same as prior period, unchanged from 0001564590-21-009843:mdna:3]

[0001564590-21-046976:mdna:4]
[same as prior period, unchanged from 0001564590-21-009843:mdna:4]

[0001564590-21-046976:mdna:5]
NetApp is a global cloud-led, data-centric software company that gives organizations the freedom to put data to work in the applications that elevate their business. We help our customers get the most out of their data with industry-leading cloud data services, storage systems, and software. Throughout our history, we have kept our focus on one thing – the data, continuously improving how data are managed, stored, analyzed, protected, and moved. Our strategy has been shaped around helping our customers embrace the full potential of new technologies – from the rise of the internet, to helping large enterprise customers in vertical markets, to bringing new systems to market. Today, we are focused on unlocking the best of cloud.

[0001564590-21-046976:mdna:6]
As our products and solutions portfolios evolve, market dynamics change, and management continues to assess our largest opportunities, we periodically change how we manage our business. As of the end of our first quarter of fiscal 2022, our Chief Operating Decision Maker (CODM), who is our Chief Executive Officer, realigned internal reporting and began using financial information for components of our business, organized based on category of product/solution, to evaluate performance and allocate resources. This resulted in the creation of two reportable segments for financial reporting purposes: Public Cloud and Hybrid Cloud. Our CODM measures the performance of each segment based on segment revenue and segment gross profit. We do not allocate to our segments certain cost of revenues which we manage at the corporate level. These unallocated costs include stock-based compensation and amortization of intangible assets.

[0001564590-21-046976:mdna:7]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support, and made available on the world’s leading clouds. This portfolio includes storage services, cloud automation and optimization services, and cloud infrastructure monitoring services.

[0001564590-21-046976:mdna:8]
Hybrid Cloud offers a portfolio of storage and data management solutions that help customers build and integrate on-premises and private cloud environments. This portfolio is designed to operate with public clouds to unlock the potential of hybrid, multi-cloud operations. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.

[0001564590-21-046976:mdna:9]
[same as prior period, unchanged from 0001564590-21-009843:mdna:16]

[0001564590-21-046976:mdna:10]
The novel coronavirus, or COVID-19, pandemic and efforts to control its spread have significantly curtailed the movement of people, goods and services worldwide, including in most or all of the regions in which we sell our products and services and conduct our business operations. We have taken precautionary measures intended to minimize the risk of the virus to our employees, our customers, and the communities in which we operate. Since March 2020, the vast majority of our employees have been working remotely and we have limited business travel.

[0001564590-21-046976:mdna:11]
During the first three months of fiscal 2022, due to the macroeconomic uncertainty caused by COVID-19, we continue to observe certain customers delaying purchases of our products and services, while other customers accelerate or place new orders to address the demands of remote working and digital business. We also experienced certain logistical challenges in delivering our products and services to customers in certain regions, and minor supply chain constraints. Given uncertainties that exist in the broader technology supply chain, we have begun to invest in inventory and certain longer-term commitments to help mitigate the risk of supply shortages. If supply chain challenges continue it could result in an increase in our cost of revenues.

[0001564590-21-046976:mdna:12]
[same as prior period, unchanged from 0001564590-21-009843:mdna:19]

[0001564590-21-046976:mdna:13]
The magnitude and duration of the disruption to our business, and impact to our operational and financial performance, caused by COVID-19 pandemic remain uncertain. Refer to Part II, Item 1A. – Risk Factors for the significant risks we have identified as a result of the COVID-19 pandemic.

[0001564590-21-046976:mdna:14]
[same as prior period, unchanged from 0001564590-21-009843:mdna:26]

[0001564590-21-046976:mdna:15]
During the first quarter of fiscal 2022, we repurchased 1.2 million shares of our common stock at an average price of $80.08 per share, for an aggregate of $100 million. We also declared aggregate cash dividends of $0.50 per share in that period, for which we paid $112 million.

[0001564590-21-046976:mdna:16]
Acquisition

[0001564590-21-046976:mdna:17]
On June 18, 2021, we acquired all the outstanding shares of privately-held Data Mechanics Inc., a provider of managed platform-for-big-data processing and cloud analytics headquartered in Paris, France, for $15 million in cash.

[0001564590-21-046976:mdna:18]
Restructuring Event

[0001564590-21-046976:mdna:19]
During the first quarter of fiscal 2022, we executed a restructuring plan and recognized expenses totaling $22 million, consisting primarily of office relocation costs, lease termination fees, and employee severance-related costs.

[0001564590-21-046976:mdna:20]
[same as prior period, unchanged from 0001564590-21-009843:mdna:33]

[0001564590-21-046976:mdna:21]
Our fiscal year is reported as a 52- or 53-week year that ends on the last Friday in April. Fiscal year 2022, ending on April 29, 2022, is a 52-week year, with 13 weeks in each of its quarters. Fiscal year 2021, which ended on April 30, 2021 was a 53-week year, with 14 weeks included in its first quarter and 13 weeks in each subsequent quarter. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0001564590-21-046976:mdna:22]
The following table sets forth certain condensed consolidated statements of income data as a percentage of net revenues for the periods indicated:

[0001564590-21-046976:mdna:23]
|  |  | Three Months Ended |  |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |
| Product |  |  | 50 | % |  |  | 48 | % |  |
| Services |  |  | 50 |  |  |  | 52 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 23 |  |  |  | 24 |  |  |
| Cost of services |  |  | 9 |  |  |  | 9 |  |  |
| Gross profit |  |  | 69 |  |  |  | 67 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 31 |  |  |  | 33 |  |  |
| Research and development |  |  | 14 |  |  |  | 18 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | 2 |  |  |  | — |  |  |
| Acquisition-related expense |  |  | — |  |  |  | 1 |  |  |
| Total operating expenses |  |  | 51 |  |  |  | 56 |  |  |
| Income from operations |  |  | 17 |  |  |  | 10 |  |  |
| Other expense, net |  |  | (1 | ) |  |  | (2 | ) |  |
| Income before income taxes |  |  | 16 |  |  |  | 8 |  |  |
| Provision for income taxes |  |  | 2 |  |  |  | 2 |  |  |
| Net income |  |  | 14 | % |  |  | 6 | % |  |

[0001564590-21-046976:mdna:24]
[same as prior period, unchanged from 0001564590-21-009843:mdna:38]

[0001564590-21-046976:mdna:25]
[same as prior period, unchanged from 0001564590-21-009843:mdna:39]

[0001564590-21-046976:mdna:26]
[same as prior period, unchanged from 0001564590-21-009843:mdna:44]

[0001564590-21-046976:mdna:27]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |  | % Change |  |
| Net revenues |  | $ | 1,458 |  |  | $ | 1,303 |  |  |  | 12 | % |

[0001564590-21-046976:mdna:28]
The increase in net revenues for the first quarter of fiscal 2022 compared to the corresponding period of fiscal 2021 was primarily due to an increase in product revenues and, to a lesser degree, an increase in services revenues. Product revenues as a percentage of net revenues increased by approximately two percentage points in the first quarter of fiscal 2022, compared to the corresponding period of fiscal 2021.

[0001564590-21-046976:mdna:29]
[same as prior period, unchanged from 0001564590-21-009843:mdna:50]

[0001564590-21-046976:mdna:30]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |  | % Change |  |
| Product revenues |  | $ | 730 |  |  | $ | 627 |  |  |  | 16 | % |
| Hardware (Non-GAAP) |  |  | 316 |  |  |  | 316 |  |  |  | — | % |
| Software (Non-GAAP) |  |  | 414 |  |  |  | 311 |  |  |  | 33 | % |

[0001564590-21-046976:mdna:31]
Hybrid Cloud

[0001564590-21-046976:mdna:32]
Product revenues are derived through the sale of our Hybrid Cloud solutions and consist of sales of configured all-flash array and hybrid systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, NetApp HCI, StorageGrid, OEM products and add-on optional software.

[0001564590-21-046976:mdna:33]
In order to provide visibility into the value created by our software innovation and R&D investment, we disclose the software and hardware components of our product revenues. Software product revenue includes the OS software and optional add-on software solutions attached to our systems across our entire product set, while hardware product revenues include the non-software component of our systems across the entire set. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, the hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0001564590-21-046976:mdna:34]
Total product revenues increased in the first quarter of fiscal 2022 compared to the corresponding period of the prior year, primarily driven by an increase in sales of all-flash array systems.

[0001564590-21-046976:mdna:35]
Revenues from the hardware component of product revenues represented 43% of product revenues, in the first quarter of fiscal 2022, compared to 50% of product revenues, in the corresponding period of the prior year. The software component of product revenues represented 57% of product revenues in the first quarter of fiscal 2022, compared to 50% of product revenues in the corresponding period of the prior year. The increase in the software component percentage of product revenues in the first quarter of fiscal 2022 is primarily due to the mix of systems sold, including a higher mix of all-flash array systems, which contain a higher proportion of software components than other Hybrid Cloud products.

[0001564590-21-046976:mdna:36]
Services Revenues (in millions, except percentages):

[0001564590-21-046976:mdna:37]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |  | % Change |  |
| Services revenues |  | $ | 728 |  |  | $ | 676 |  |  |  | 8 | % |
| Support |  |  | 578 |  |  |  | 577 |  |  |  | — | % |
| Professional and other services |  |  | 71 |  |  |  | 68 |  |  |  | 4 | % |
| Public cloud |  |  | 79 |  |  |  | 31 |  |  |  | 155 | % |

[0001564590-21-046976:mdna:38]
Hybrid Cloud

[0001564590-21-046976:mdna:39]
Hybrid Cloud services revenues are derived from the sale of: (1) support, which includes both hardware and software support contracts (the latter of which entitle customers to receive unspecified product upgrades and enhancements, bug fixes and patch releases), and (2) professional and other services, which include customer education and training.

[0001564590-21-046976:mdna:40]
Support revenues were flat in the first quarter of fiscal 2022, despite an extra week in the first quarter of fiscal 2021 that contributed approximately $40 million of revenues in that period, primarily due to an increase in our installed base and a higher mix of all-flash systems (which carry a higher support dollar content than our other products) in the current year. Professional and other services revenues were relatively consistent in both periods.

[0001564590-21-046976:mdna:41]
Public Cloud

[0001564590-21-046976:mdna:42]
Public Cloud revenues are derived from the sale of public cloud offerings primarily delivered as-a-service, which include storage services, cloud automation and optimization services, and cloud infrastructure monitoring services.

[0001564590-21-046976:mdna:43]
The increase in Public Cloud revenues was attributable to strong customer demand for NetApp’s diversified cloud offerings, coupled with overall growth in the cloud market and our acquisition of Spot, Inc. late in the first quarter of fiscal year 2021.

[0001564590-21-046976:mdna:44]
[same as prior period, unchanged from 0001564590-21-009843:mdna:46]

[0001564590-21-046976:mdna:45]
[same as prior period, unchanged from 0001564590-21-009843:mdna:70]

[0001564590-21-046976:mdna:46]
Our cost of revenues consists of:

[0001564590-21-046976:mdna:47]
(1) cost of product revenues, composed of (a) cost of Hybrid Cloud product revenues, which includes the costs of manufacturing and shipping our products, inventory write-downs, and warranty costs, and (b) unallocated cost of product revenues, which includes stock-based compensation and amortization of intangibles, and;

[0001564590-21-046976:mdna:48]
(2) cost of services revenues, composed of (a) cost of support revenues, which includes the costs of providing support activities for hardware and software support, global support partnership programs, and third party royalty costs, (b) cost of professional and other services revenues, (c) cost of public cloud revenues, constituting the cost of providing our Public Cloud offerings which includes depreciation and amortization expense and third party datacenter fees, and (d) unallocated cost of services revenues, which includes stock-based compensation and amortization of intangibles.

[0001564590-21-046976:mdna:49]
[same as prior period, unchanged from 0001564590-21-009843:mdna:73]

[0001564590-21-046976:mdna:50]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |  | % Change |  |
| Cost of product revenues |  | $ | 329 |  |  | $ | 316 |  |  |  | 4 | % |
| Hybrid Cloud |  |  | 326 |  |  |  | 305 |  |  |  | 7 | % |
| Unallocated |  |  | 3 |  |  |  | 11 |  |  |  | (73 | )% |

[0001564590-21-046976:mdna:51]
Hybrid Cloud

[0001564590-21-046976:mdna:52]
Cost of Hybrid Cloud product revenues represented 45% of product revenues for the first quarter of fiscal 2022, compared to 50% for the first quarter of fiscal 2021. Materials costs represented 91% of cost of Hybrid Cloud product revenues for both the first quarter of fiscal 2022, and the corresponding period of fiscal 2021.

[0001564590-21-046976:mdna:53]
Total materials costs increased by approximately $17 million, or 5% in the first quarter of fiscal 2022, compared to the corresponding period of the prior year, which reflects the increase in product revenues and the mix of systems sold.

[0001564590-21-046976:mdna:54]
Hybrid Cloud product gross margins increased by four percentage points in the first quarter of fiscal 2022 compared to the corresponding period of the prior year primarily due to the mix of systems sold, including a higher mix of all-flash array systems which have higher margins than hybrid systems, and, to a lesser extent, a decrease in the average unit materials costs of our all-flash array products due to a slight decrease in the price of certain product components.

[0001564590-21-046976:mdna:55]
Unallocated

[0001564590-21-046976:mdna:56]
Unallocated cost of product revenues decreased in the first quarter of fiscal 2022 compared to the corresponding period of the prior year due to certain intangible assets becoming fully amortized in the second half of fiscal 2021.

[0001564590-21-046976:mdna:57]
Cost of Services Revenues (in millions, except percentages):

[0001564590-21-046976:mdna:58]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |  | % Change |  |
| Cost of services revenues |  | $ | 130 |  |  | $ | 115 |  |  |  | 13 | % |
| Support |  |  | 48 |  |  |  | 51 |  |  |  | (6 | )% |
| Professional and other services |  |  | 51 |  |  |  | 48 |  |  |  | 6 | % |
| Public cloud |  |  | 23 |  |  |  | 13 |  |  |  | 77 | % |
| Unallocated |  |  | 8 |  |  |  | 3 |  |  |  | 167 | % |

[0001564590-21-046976:mdna:59]
Hybrid Cloud

[0001564590-21-046976:mdna:60]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, was relatively flat in the first quarter of fiscal 2022 compared to the corresponding period of fiscal 2021 and represented 15% of Hybrid Cloud services revenues in both quarters. Both support and professional services gross margins were relatively consistent in each period.

[0001564590-21-046976:mdna:61]
Public Cloud

[0001564590-21-046976:mdna:62]
[same as prior period, unchanged from 0001564590-21-009843:mdna:56]

[0001564590-21-046976:mdna:63]
Cost of Public Cloud revenues increased in the first quarter of fiscal 2022 compared to the corresponding period of fiscal 2021 reflecting the increase in Public Cloud revenues. Public Cloud gross margin increased to 71% in the first quarter of fiscal 2022, compared to 58% in the first quarter of fiscal 2021, reflecting efficiencies from scaling our Public Cloud segment.

[0001564590-21-046976:mdna:64]
Unallocated

[0001564590-21-046976:mdna:65]
Unallocated cost of services revenues increased in the first quarter of fiscal 2022 compared to the corresponding period of the prior year due to our acquisition of Spot, Inc. in the first quarter of fiscal 2021, which resulted in higher amortization expense for certain intangible assets.

[0001564590-21-046976:mdna:66]
[same as prior period, unchanged from 0001564590-21-009843:mdna:87]

[0001564590-21-046976:mdna:67]
[same as prior period, unchanged from 0001564590-21-009843:mdna:88]

[0001564590-21-046976:mdna:68]
Sales and marketing, research and development, and general and administrative expenses for the first quarter of fiscal 2022 totaled $727 million, or 50% of net revenues, reflecting a decrease of five percentage points as compared to 55% of net revenues for the corresponding period of fiscal 2021.

[0001564590-21-046976:mdna:69]
[same as prior period, unchanged from 0001564590-21-009843:mdna:89]

[0001564590-21-046976:mdna:70]
Total compensation costs included in operating expenses decreased by $21 million, or 5%, in the first quarter of fiscal 2022 compared to the corresponding period of the prior year, primarily due to lower salaries and incentive compensation expenses reflecting the impact of the additional week in the first quarter of fiscal 2021.

[0001564590-21-046976:mdna:71]
[same as prior period, unchanged from 0001564590-21-009843:mdna:92]

[0001564590-21-046976:mdna:72]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 451 |  |  | $ | 429 |  |  |  | 5 | % |

[0001564590-21-046976:mdna:73]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, facilities and information technology (IT) costs, advertising and marketing promotional expense and travel and entertainment expense. Changes in sales and marketing expense consisted of the following (in percentage points of the total change):

[0001564590-21-046976:mdna:74]
|  |  |  | Three Months Ended |  |
|  |  |  | Fiscal 2022 to Fiscal 2021 |  |
| Compensation costs |  |  |  | 1 |  |
| Commissions |  |  |  | 1 |  |
| Advertising and marketing promotional expense |  |  |  | 2 |  |
| Other |  |  |  | 1 |  |
| Total change |  |  |  | 5 |  |

[0001564590-21-046976:mdna:75]
The increase in compensation costs for the first quarter of fiscal 2022 compared to the corresponding period of the prior year reflected an increase in average headcount of approximately 5%, with this expansion of our sales and marketing teams supporting our ability to execute on key market opportunities, partially offset by lower incentive compensation expense. Compensation costs for the first three months of fiscal 2021 reflected the impact of one additional week in that quarter.

[0001564590-21-046976:mdna:76]
The increase in commissions expense for the first quarter of fiscal 2022 is primarily due to higher performance against sales goals. Advertising and marketing promotional expense increased in the first quarter of fiscal 2022 compared to the corresponding period of the prior year, primarily due to higher spending levels on certain projects.

[0001564590-21-046976:mdna:77]
[same as prior period, unchanged from 0001564590-21-009843:mdna:98]

[0001564590-21-046976:mdna:78]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |  | % Change |  |
| Research and development expenses |  | $ | 210 |  |  | $ | 233 |  |  |  | (10 | )% |

[0001564590-21-046976:mdna:79]
Research and development expenses consist primarily of compensation costs, facilities and IT costs, depreciation, equipment and software-related costs, prototypes, non-recurring engineering charges and other outside services costs. Changes in research and development expense consisted of the following (in percentage points of the total change):

[0001564590-21-046976:mdna:80]
|  |  |  | Three Months Ended |  |
|  |  |  | Fiscal 2022 to Fiscal 2021 |  |
| Compensation costs |  |  |  | (11 | ) |
| Development projects and outside services |  |  |  | 1 |  |
| Total change |  |  |  | (10 | ) |

[0001564590-21-046976:mdna:81]
The decrease in compensation costs for the first quarter of fiscal 2022 compared to the corresponding period in the prior year was attributable to a decrease in average headcount of 8%, primarily resulting from the restructuring plans we implemented in fiscal 2020 which were completed during the first half of fiscal 2021, and lower incentive compensation expense. Also contributing to the decrease is the impact of the additional week in the first quarter of fiscal 2021. The increase in development projects and outside services were primarily due to the higher spending on certain engineering projects.

[0001564590-21-046976:mdna:82]
[same as prior period, unchanged from 0001564590-21-009843:mdna:104]

[0001564590-21-046976:mdna:83]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |  | % Change |  |
| General and administrative expenses |  | $ | 66 |  |  | $ | 61 |  |  |  | 8 | % |

[0001564590-21-046976:mdna:84]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and facilities and IT support costs. Changes in general and administrative expense consisted of the following (in percentage points of the total change):

[0001564590-21-046976:mdna:85]
|  |  |  | Three Months Ended |  |
|  |  |  | Fiscal 2022 to Fiscal 2021 |  |
| Compensation costs |  |  |  | (1 | ) |
| Professional and legal fees and outside services |  |  |  | 9 |  |
| Total change |  |  |  | 8 |  |

[0001564590-21-046976:mdna:86]
The decrease in compensation costs in the first quarter of fiscal 2022 compared to the corresponding period of the prior year was primarily attributable to lower incentive compensation expense in the current year and the impact of the additional week in the first quarter of fiscal 2021. The increase in professional and legal fees and outside services expense in the first quarter of fiscal 2022 was primarily due to higher spending on business transformation projects and an increase in legal fees.

[0001564590-21-046976:mdna:87]
[same as prior period, unchanged from 0001564590-21-009843:mdna:109]

[0001564590-21-046976:mdna:88]
|  |  | Three Months Ended |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |  | % Change |
| Restructuring charges |  | $ | 22 |  |  | $ | 5 |  |  | NM |

[0001564590-21-046976:mdna:89]
[same as prior period, unchanged from 0001564590-21-009843:mdna:111]

[0001564590-21-046976:mdna:90]
In the first quarter of fiscal 2022, we executed a restructuring plan primarily to reduce the amount of office space we currently occupy as we allow more employees to continue to work remotely. In connection with the plan, we reduced our global workforce by approximately 1%. Charges related to the plan consisted primarily of office relocation costs, lease termination fees, and employee severance related costs. We may incur additional restructuring charges over the remainder of the fiscal year as we continue to assess our real estate footprint and global resource requirements.

[0001564590-21-046976:mdna:91]
[same as prior period, unchanged from 0001564590-21-009843:mdna:113]

[0001564590-21-046976:mdna:92]
|  |  | Three Months Ended |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |  | % Change |
| Acquisition-related expense |  | $ | 1 |  |  | $ | 8 |  |  | NM |

[0001564590-21-046976:mdna:93]
[same as prior period, unchanged from 0001564590-21-009843:mdna:115]

[0001564590-21-046976:mdna:94]
In the first quarter of fiscal 2022, we incurred $1 million of acquisition-related costs, primarily legal and consulting fees.

[0001564590-21-046976:mdna:95]
[same as prior period, unchanged from 0001564590-21-009843:mdna:86]

[0001564590-21-046976:mdna:96]
Other Expense, Net (in millions, except percentages)

[0001564590-21-046976:mdna:97]
The components of other expense, net were as follows:

[0001564590-21-046976:mdna:98]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |  | % Change |  |
| Interest income |  | $ | 2 |  |  | $ | 3 |  |  |  | (33 | )% |
| Interest expense |  |  | (18 | ) |  |  | (18 | ) |  |  | — | % |
| Other income (expense), net |  |  | 4 |  |  |  | (17 | ) |  |  | (124 | )% |
| Total |  | $ | (12 | ) |  | $ | (32 | ) |  |  | (63 | )% |

[0001564590-21-046976:mdna:99]
Interest income decreased in the first quarter of fiscal 2022 compared to the corresponding period of the prior year due to both a reduction in the size of our investment portfolio and lower yields earned on the investments. Interest expense remained flat in the first quarter of fiscal 2022 compared to the corresponding period of fiscal 2021.

[0001564590-21-046976:mdna:100]
The differences in other income (expense), net for the first three months of fiscal 2021 as compared to the corresponding period of the prior year are partially due to foreign exchange gains and losses year-over-year. In the first three months of fiscal 2021, other income (expense), net includes a $14 million loss recognized from the extinguishment of our Senior Notes due June 2021.

[0001564590-21-046976:mdna:101]
[same as prior period, unchanged from 0001564590-21-009843:mdna:128]

[0001564590-21-046976:mdna:102]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |  | % Change |  |
| Provision for income taxes |  | $ | 35 |  |  | $ | 27 |  |  |  | 30 | % |

[0001564590-21-046976:mdna:103]
Our effective tax rate for the first quarter of fiscal 2022 was 14.8% compared to 26.0% for the first quarter of fiscal 2021. Our effective tax rates reflect the impact of a significant amount of our earnings being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rate for the first three months of fiscal 2022 decreased compared to the corresponding period of the prior year due to discrete tax benefits for lapses of statute of limitations as well as increased benefits related to stock-based compensation. Additionally, the corresponding period of the prior year included tax charges for the integration of acquired companies.

[0001564590-21-046976:mdna:104]
As of July 30, 2021, we had $214 million of gross unrecognized tax benefits, of which $120 million has been recorded in other long-term liabilities. Inclusive of penalties, interest and certain income tax benefits, $117 million would affect our provision for income taxes if recognized.

[0001564590-21-046976:mdna:105]
[same as prior period, unchanged from 0001564590-21-009843:mdna:134]

[0001564590-21-046976:mdna:106]
[same as prior period, unchanged from 0001564590-21-009843:mdna:135]

[0001564590-21-046976:mdna:107]
| (In millions, except percentages) |  | July 30, 2021 |  |  | April 30, 2021 |  |
| Cash, cash equivalents and short-term investments |  | $ | 4,547 |  |  | $ | 4,596 |  |
| Principal amount of debt |  | $ | 2,650 |  |  | $ | 2,650 |  |

[0001564590-21-046976:mdna:108]
[same as prior period, unchanged from 0001564590-21-009843:mdna:137]

[0001564590-21-046976:mdna:109]
|  |  | Three Months Ended |  |
| (In millions) |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Net cash provided by operating activities |  | $ | 242 |  |  | $ | 240 |  |
| Net cash used in investing activities |  |  | (54 | ) |  |  | (311 | ) |
| Net cash (used in) provided by financing activities |  |  | (218 | ) |  |  | 1,003 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (5 | ) |  |  | 43 |  |
| Net change in cash, cash equivalents and restricted cash |  | $ | (35 | ) |  | $ | 975 |  |

[0001564590-21-046976:mdna:110]
[same as prior period, unchanged from 0001564590-21-009843:mdna:139]

[0001564590-21-046976:mdna:111]
As of July 30, 2021, our cash, cash equivalents and short-term investments were $4.5 billion, which represents a decrease of $49 million for the first quarter of fiscal 2022. During the first quarter of fiscal 2022, we generated $242 million of cash from operating activities, offset by $112 million used for the payment of dividends, $100 million used to repurchase shares of our common stock, $51 million in purchases of property and equipment, and $14 million used for the acquisition of a privately-held company, net of cash acquired. Working capital was $2.5 billion as of July 30, 2021, approximately flat when compared to April 30, 2021.

[0001564590-21-046976:mdna:112]
[same as prior period, unchanged from 0001564590-21-009843:mdna:141]

[0001564590-21-046976:mdna:113]
During the first three months of fiscal 2022, we generated cash from operating activities of $242 million, reflecting net income of $202 million, adjusted by non-cash depreciation and amortization of $46 million and non-cash stock-based compensation expense of $53 million, compared to $240 million of cash generated from operating activities during the first three months of fiscal 2021.

[0001564590-21-046976:mdna:114]
Significant changes in assets and liabilities in the first three months of fiscal 2022 included the following:

[0001564590-21-046976:mdna:115]
|  | • | Accounts receivable decreased $287 million, reflecting more favorable shipping linearity and typical lower billings for the first quarter of fiscal 2022 compared to the fourth quarter of fiscal 2021. |

[0001564590-21-046976:mdna:116]
|  | • | Accrued expenses decreased by $242 million, primarily due to employee compensation payouts related to fiscal year 2021 commissions and incentive compensation plans. |

[0001564590-21-046976:mdna:117]
We expect that cash provided by operating activities may materially fluctuate in future periods due to various factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, vendor payment initiatives, tax benefits or charges from stock-based compensation, and the timing and amount of compensation and other payments.

[0001564590-21-046976:mdna:118]
[same as prior period, unchanged from 0001564590-21-009843:mdna:147]

[0001564590-21-046976:mdna:119]
During the first three months of fiscal 2022, we generated $11 million from maturities of investments, net of purchases, and paid $51 million for capital expenditures. Additionally, during the first three months of fiscal 2022, we paid $14 million, net of cash acquired for a privately-held company. During the same period of fiscal 2021, we paid $350 million, net of cash acquired for two privately-held companies.

[0001564590-21-046976:mdna:120]
[same as prior period, unchanged from 0001564590-21-009843:mdna:149]

[0001564590-21-046976:mdna:121]
During the first three months of fiscal 2022, cash flows used in financing activities totaled $218 million and include $100 million for the repurchase of 1.2 million shares of common stock and $112 million for the payment of dividends. During the first three months of fiscal 2021, cash flows provided by financing activities totaled $1.0 billion and were primarily due to net cash proceeds of $2.0 billion from the issuance of Senior Notes, partially offset by the use of $513 million for the extinguishment of Senior Notes due June 2021 and $370 million for the net repayment of commercial paper notes with original maturities of three months or less.

[0001564590-21-046976:mdna:122]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including cash generated from operations, and our ability to access capital markets and committed credit lines will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all. For further discussion of factors that could affect our cash flows and liquidity requirements, including the impact of the COVID-19 pandemic, see Part II, Item 1A. Risk Factors.

[0001564590-21-046976:mdna:123]
[same as prior period, unchanged from 0001564590-21-009843:mdna:152]

[0001564590-21-046976:mdna:124]
Our principal sources of liquidity as of July 30, 2021 consisted of cash and cash equivalents, short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001564590-21-046976:mdna:125]
[same as prior period, unchanged from 0001564590-21-009843:mdna:116]

[0001564590-21-046976:mdna:126]
[same as prior period, unchanged from 0001564590-21-009843:mdna:154]

[0001564590-21-046976:mdna:127]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| Cash and cash equivalents |  | $ | 4,492 |  |  | $ | 4,529 |  |
| Short-term investments |  |  | 55 |  |  |  | 67 |  |
| Total |  | $ | 4,547 |  |  | $ | 4,596 |  |

[0001564590-21-046976:mdna:128]
As of July 30, 2021 and April 30, 2021, $2.4 billion and $2.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $2.1 billion was available in the U.S as of each period-end.

[0001564590-21-046976:mdna:129]
Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies through asset purchases and/or business acquisitions, service interest and principal payments on our debt, fund our stock repurchase program, and pay dividends, as and if declared.

[0001564590-21-046976:mdna:130]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of July 30, 2021.

[0001564590-21-046976:mdna:131]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. We also have an automatic shelf registration statement on file with the Securities and Exchange Commission (SEC). We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001564590-21-046976:mdna:132]
[same as prior period, unchanged from 0001564590-21-009843:mdna:160]

[0001564590-21-046976:mdna:133]
The following table summarizes the principal amount of our Senior Notes as of July 30, 2021 (in millions):

[0001564590-21-046976:mdna:134]
| 3.25% Senior Notes Due December 2022 |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,650 |  |

[0001564590-21-046976:mdna:135]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 7 – Financing Arrangements of the Notes to Condensed Consolidated Financial Statements.

[0001564590-21-046976:mdna:136]
Commercial Paper Program and Credit Facility

[0001564590-21-046976:mdna:137]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of July 30, 2021.

[0001564590-21-046976:mdna:138]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of July 30, 2021, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0001564590-21-046976:mdna:139]
[same as prior period, unchanged from 0001564590-21-009843:mdna:167]

[0001564590-21-046976:mdna:140]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2022 to be between $150 million and $200 million.

[0001564590-21-046976:mdna:141]
[same as prior period, unchanged from 0001564590-21-009843:mdna:169]

[0001564590-21-046976:mdna:142]
On August 23, 2021, we declared a cash dividend of $0.50 per share of common stock, payable on October 27, 2021 to holders of record as of the close of business on October 8, 2021.

[0001564590-21-046976:mdna:143]
As of July 30, 2021, our Board of Directors has authorized the repurchase of up to $14.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through July 30, 2021, we repurchased a total of 341 million shares of our common stock at an average price of $39.17 per share, for an aggregate purchase price of $13.4 billion. As of July 30, 2021, the remaining authorized amount for stock repurchases under this program was $0.8 billion.

[0001564590-21-046976:mdna:144]
Purchase Commitments

[0001564590-21-046976:mdna:145]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled $954 million at July 30, 2021.

[0001564590-21-046976:mdna:146]
[same as prior period, unchanged from 0001564590-21-009843:mdna:179]

[0001564590-21-046976:mdna:147]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $17 million and $13 million of receivables during the first three months of fiscal 2022 and fiscal 2021, respectively.

[0001564590-21-046976:mdna:148]
[same as prior period, unchanged from 0001564590-21-009843:mdna:181]

[0001564590-21-046976:mdna:149]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of July 30, 2021 and April 30, 2021, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-21-046976:mdna:150]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of July 30, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-21-046976:mdna:151]
Legal Contingencies

[0001564590-21-046976:mdna:152]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0001564590-21-046976:mdna:153]
[same as prior period, unchanged from 0001564590-21-009843:mdna:28]

[0001564590-21-046976:mdna:154]
[same as prior period, unchanged from 0001564590-21-009843:mdna:29]

[0001564590-21-046976:mdna:155]
The summary of our significant accounting policies is included under Item 7 – Management’s Discussion and Analysis of Financial Condition and Results of Operations of our fiscal 2021 Form 10-K. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. There have been no material changes to the critical accounting policies and estimates as filed in such report.

[0001564590-21-046976:mdna:156]
38
