# NTAP notes — 0001564590-21-046976


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-21-046976:notes:1]
[same as prior period, unchanged from 0001564590-21-009843:notes:1]

[0001564590-21-046976:notes:2]
NetApp, Inc. (we, us, or the Company) is a global cloud-led, data-centric software company that provides organizations the ability to manage and share their data across on-premises, private and public clouds. We provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.

[0001564590-21-046976:notes:3]
[same as prior period, unchanged from 0001564590-21-009843:notes:3]

[0001564590-21-046976:notes:4]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2022, ending on April 29, 2022, is a 52-week year, with 13 weeks in each of its quarters. Fiscal year 2021, ended on April 30, 2021 was a 53-week year, with 14 weeks included in its first quarter and 13 weeks in each subsequent quarter.

[0001564590-21-046976:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 30, 2021 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 30, 2021 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-21-046976:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates. Management’s estimates include, as applicable, the anticipated impacts of the COVID-19 pandemic.

[0001564590-21-046976:notes:7]
Segment Change

[0001564590-21-046976:notes:8]
Effective July 30, 2021, our Chief Operating Decision Maker, who is our Chief Executive Officer, realigned internal reporting and began using financial information for components of our business, organized based on category of product/solution, to evaluate performance and allocate resources. This resulted in the creation of two operating segments and two reportable segments for financial reporting purposes: Public Cloud and Hybrid Cloud.

[0001564590-21-046976:notes:9]
Public Cloud

[0001564590-21-046976:notes:10]
NetApp's Public Cloud segment offers a portfolio of products delivered primarily as-a-service, including related support, and made available on the world’s leading clouds. This portfolio includes storage services, cloud automation and optimization services, and cloud infrastructure monitoring services. Public Cloud includes certain reseller arrangements in which the timing of our consideration follows the end user consumption of the reseller services.

[0001564590-21-046976:notes:11]
Hybrid Cloud

[0001564590-21-046976:notes:12]
NetApp’s Hybrid Cloud segment offers a portfolio of storage and data management solutions that help customers build and integrate on-premises and private cloud environments. This portfolio is designed to operate with public clouds to unlock the potential of hybrid, multi-cloud operations. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-21-046976:notes:13]
2. Recent Accounting Pronouncements

[0001564590-21-046976:notes:14]
Although there are several new accounting pronouncements issued or proposed by the FASB that we have adopted or will adopt, as applicable, we do not believe any of these accounting pronouncements had or will have a material impact on our consolidated financial position, results of operations, cash flows or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-21-046976:notes:15]
3. Business Combinations

[0001564590-21-046976:notes:16]
Data Mechanics Inc. Acquisition

[0001564590-21-046976:notes:17]
On June 18, 2021, we acquired all the outstanding shares of privately-held Data Mechanics Inc., a provider of managed platforms for big data processing and cloud analytics headquartered in Paris, France, for approximately $15 million in cash.

[0001564590-21-046976:notes:18]
[same as prior period, unchanged from 0001564590-21-009843:notes:14]

[0001564590-21-046976:notes:19]
|  |  | Amount |  |
| Cash |  | $ | 1 |  |
| Developed technology |  |  | 5 |  |
| Goodwill |  |  | 11 |  |
| Total assets acquired |  |  | 17 |  |
| Liabilities assumed |  |  | (2 | ) |
| Total purchase price |  | $ | 15 |  |

[0001564590-21-046976:notes:20]
The results of operations related to this acquisition have been included in our condensed consolidated statements of income from the acquisition date. Pro forma results of operations have not been presented because the impact from the acquisition would not have been material to our consolidated results of operations for each of the three months ended July 30, 2021 and July 31, 2020.

[0001564590-21-046976:notes:21]
[same as prior period, unchanged from 0001564590-21-009843:notes:12]

[0001564590-21-046976:notes:22]
On April 28, 2020, we acquired all the outstanding shares of privately-held Cloud Jumper Corporation (Cloud Jumper), a provider of virtual desktop infrastructure and remote desktop services solutions based in North Carolina, for $34 million in cash.

[0001564590-21-046976:notes:23]
The acquisition date fair values of the assets acquired and liabilities assumed are as follows (in millions):

[0001564590-21-046976:notes:24]
[same as prior period, unchanged from 0001564590-21-009843:notes:15]

[0001564590-21-046976:notes:25]
[same as prior period, unchanged from 0001564590-21-009843:notes:16]

[0001564590-21-046976:notes:26]
On July 9, 2020, we acquired all the outstanding shares of privately-held Spot, Inc. (Spot), a provider of compute management cost optimization services on the public clouds based in Israel, for $340 million in cash.

[0001564590-21-046976:notes:27]
[same as prior period, unchanged from 0001564590-21-009843:notes:18]

[0001564590-21-046976:notes:28]
[same as prior period, unchanged from 0001564590-21-009843:notes:19]

[0001564590-21-046976:notes:29]
[same as prior period, unchanged from 0001564590-21-009843:notes:20]

[0001564590-21-046976:notes:30]
[same as prior period, unchanged from 0001564590-21-009843:notes:21]

[0001564590-21-046976:notes:31]
The results of operations related to the acquisition of both Spot and Cloud Jumper have been included in our consolidated statements of income from their respective acquisition dates. Pro forma results of operations have not been presented because the impact from these acquisitions would not have been material to our consolidated results of operations for the fiscal quarter ended July 31, 2020.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-21-046976:notes:32]
[same as prior period, unchanged from 0001564590-21-009843:notes:23]

[0001564590-21-046976:notes:33]
[same as prior period, unchanged from 0001564590-21-009843:notes:24]

[0001564590-21-046976:notes:34]
|  |  | Amount |  |
| Balance as of April 30, 2021 |  | $ | 2,039 |  |
| Additions |  |  | 11 |  |
| Balance as of July 30, 2021 |  | $ | 2,050 |  |

[0001564590-21-046976:notes:35]
Beginning with the first quarter of fiscal 2022, the Company has two reportable segments: Public Cloud and Hybrid Cloud. As a result, goodwill was allocated to the segments using a relative fair value approach.

[0001564590-21-046976:notes:36]
Goodwill by reportable segment as of July 30, 2021 is as follows (in millions):

[0001564590-21-046976:notes:37]
|  |  | Amount |  |
| Public Cloud |  | $ | 336 |  |
| Hybrid Cloud |  |  | 1,714 |  |
| Total goodwill |  | $ | 2,050 |  |

[0001564590-21-046976:notes:38]
As a result of the realignment, the Company performed an interim quantitative goodwill impairment test for its reporting units as of July 30, 2021, which did not result in any goodwill impairment charges. The Company will continue to evaluate the recoverability of goodwill on an annual basis in the fourth fiscal quarter and whenever events or changes in circumstances indicate there may be a potential impairment.

[0001564590-21-046976:notes:39]
[same as prior period, unchanged from 0001564590-21-009843:notes:26]

[0001564590-21-046976:notes:40]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 106 |  |  | $ | (40 | ) |  | $ | 66 |  |  | $ | 215 |  |  | $ | (147 | ) |  | $ | 68 |  |
| Customer contracts/relationships |  |  | 38 |  |  |  | (9 | ) |  |  | 29 |  |  |  | 38 |  |  |  | (8 | ) |  |  | 30 |  |
| Other purchased intangibles |  |  | 3 |  |  |  | (1 | ) |  |  | 2 |  |  |  | 3 |  |  |  | — |  |  |  | 3 |  |
| Total purchased intangible assets |  | $ | 147 |  |  | $ | (50 | ) |  | $ | 97 |  |  | $ | 256 |  |  | $ | (155 | ) |  | $ | 101 |  |

[0001564590-21-046976:notes:41]
[same as prior period, unchanged from 0001564590-21-009843:notes:28]

[0001564590-21-046976:notes:42]
|  |  | Three Months Ended |  | Statements of |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  | Income Classification |
| Developed technology |  | $ | 7 |  |  | $ | 10 |  | Cost of revenues |
| Customer contracts/relationships |  |  | 1 |  |  |  | — |  | Operating expenses |
| Other purchased intangibles |  |  | 1 |  |  |  | — |  | Operating expenses |
| Total |  | $ | 9 |  |  | $ | 10 |  |  |

[0001564590-21-046976:notes:43]
As of July 30, 2021, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-21-046976:notes:44]
| Fiscal Year |  | Amount |  |
| Remainder of 2022 |  | $ | 29 |  |
| 2023 |  |  | 30 |  |
| 2024 |  |  | 19 |  |
| 2025 |  |  | 16 |  |
| 2026 |  |  | 3 |  |
| Total |  | $ | 97 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-21-046976:notes:45]
[same as prior period, unchanged from 0001564590-21-009843:notes:32]

[0001564590-21-046976:notes:46]
[same as prior period, unchanged from 0001564590-21-009843:notes:33]

[0001564590-21-046976:notes:47]
[same as prior period, unchanged from 0001564590-21-009843:notes:34]

[0001564590-21-046976:notes:48]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| Cash and cash equivalents |  | $ | 4,492 |  |  | $ | 4,529 |  |
| Restricted cash |  |  | 8 |  |  |  | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 4,500 |  |  | $ | 4,535 |  |

[0001564590-21-046976:notes:49]
[same as prior period, unchanged from 0001564590-21-009843:notes:36]

[0001564590-21-046976:notes:50]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| Purchased components |  | $ | 36 |  |  | $ | 22 |  |
| Finished goods |  |  | 72 |  |  |  | 92 |  |
| Inventories |  | $ | 108 |  |  | $ | 114 |  |

[0001564590-21-046976:notes:51]
[same as prior period, unchanged from 0001564590-21-009843:notes:38]

[0001564590-21-046976:notes:52]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 350 |  |  |  | 356 |  |
| Leasehold improvements |  |  | 78 |  |  |  | 83 |  |
| Computer, production, engineering and other equipment |  |  | 871 |  |  |  | 869 |  |
| Computer software |  |  | 290 |  |  |  | 305 |  |
| Furniture and fixtures |  |  | 77 |  |  |  | 93 |  |
| Construction-in-progress |  |  | 62 |  |  |  | 46 |  |
|  |  |  | 1,774 |  |  |  | 1,798 |  |
| Accumulated depreciation and amortization |  |  | (1,241 | ) |  |  | (1,273 | ) |
| Property and equipment, net |  | $ | 533 |  |  | $ | 525 |  |

[0001564590-21-046976:notes:53]
[same as prior period, unchanged from 0001564590-21-009843:notes:40]

[0001564590-21-046976:notes:54]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| Deferred tax assets |  | $ | 233 |  |  | $ | 219 |  |
| Operating lease ROU assets |  |  | 259 |  |  |  | 114 |  |
| Other assets |  |  | 353 |  |  |  | 361 |  |
| Other non-current assets |  | $ | 845 |  |  | $ | 694 |  |

[0001564590-21-046976:notes:55]
Other non-current assets as of July 30, 2021 and April 30, 2021 include $72 million and $71 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited, a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019.

[0001564590-21-046976:notes:56]
[same as prior period, unchanged from 0001564590-21-009843:notes:43]

[0001564590-21-046976:notes:57]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| Accrued compensation and benefits |  | $ | 282 |  |  | $ | 505 |  |
| Product warranty liabilities |  |  | 21 |  |  |  | 21 |  |
| Operating lease liabilities |  |  | 53 |  |  |  | 49 |  |
| Other current liabilities |  |  | 391 |  |  |  | 395 |  |
| Accrued expenses |  | $ | 747 |  |  | $ | 970 |  |

[0001564590-21-046976:notes:58]
[same as prior period, unchanged from 0001564590-21-009843:notes:45]

[0001564590-21-046976:notes:59]
Equipment and software systems sales include a standard product warranty. Estimated future hardware and software warranty costs are recorded as a cost of product revenues at the time of product shipment, based on historical and projected warranty claim rates, historical and projected cost-per-claim and knowledge of specific product failures that are outside our typical experience.

[0001564590-21-046976:notes:60]
The following tables summarize the activity related to product warranty liabilities and their balances as reported in our condensed consolidated balance sheets (in millions):

[0001564590-21-046976:notes:61]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Balance at beginning of period |  | $ | 32 |  |  | $ | 41 |  |
| Expense accrued during the period |  |  | 4 |  |  |  | 1 |  |
| Warranty costs incurred |  |  | (5 | ) |  |  | (5 | ) |
| Balance at end of period |  | $ | 31 |  |  | $ | 37 |  |

[0001564590-21-046976:notes:62]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| Accrued expenses |  | $ | 21 |  |  | $ | 21 |  |
| Other long-term liabilities |  |  | 10 |  |  |  | 11 |  |
| Total warranty liabilities |  | $ | 31 |  |  | $ | 32 |  |

[0001564590-21-046976:notes:63]
[same as prior period, unchanged from 0001564590-21-009843:notes:49]

[0001564590-21-046976:notes:64]
[same as prior period, unchanged from 0001564590-21-009843:notes:50]

[0001564590-21-046976:notes:65]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| Liability for uncertain tax positions |  | $ | 120 |  |  | $ | 127 |  |
| Income taxes payable |  |  | 351 |  |  |  | 351 |  |
| Product warranty liabilities |  |  | 10 |  |  |  | 11 |  |
| Operating lease liabilities |  |  | 211 |  |  |  | 71 |  |
| Other liabilities |  |  | 92 |  |  |  | 90 |  |
| Other long-term liabilities |  | $ | 784 |  |  | $ | 650 |  |

[0001564590-21-046976:notes:66]
Deferred revenue and financed unearned services revenue

[0001564590-21-046976:notes:67]
The following table summarizes the components of our deferred revenue and financed unearned services balance as reported in our condensed consolidated balance sheets (in millions):

[0001564590-21-046976:notes:68]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| Deferred product revenue |  | $ | 47 |  |  | $ | 59 |  |
| Deferred services revenue |  |  | 3,792 |  |  |  | 3,873 |  |
| Financed unearned services revenue |  |  | 65 |  |  |  | 71 |  |
| Total |  | $ | 3,904 |  |  | $ | 4,003 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,988 |  |  | $ | 2,062 |  |
| Long-term |  |  | 1,916 |  |  |  | 1,941 |  |
| Total |  | $ | 3,904 |  |  | $ | 4,003 |  |

[0001564590-21-046976:notes:69]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 15 – Commitments and Contingencies for additional information related to these arrangements.

[0001564590-21-046976:notes:70]
The following tables summarize the activity related to deferred revenue and financed unearned services revenue (in millions):

[0001564590-21-046976:notes:71]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Balance at beginning of period |  | $ | 4,003 |  |  | $ | 3,698 |  |
| Additions |  |  | 638 |  |  |  | 644 |  |
| Revenue recognized during the period |  |  | (737 | ) |  |  | (722 | ) |
| Balance at end of period |  | $ | 3,904 |  |  | $ | 3,620 |  |

[0001564590-21-046976:notes:72]
During the three months ended July 30, 2021 and July 31, 2020, we recognized $617 million and $661 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001564590-21-046976:notes:73]
As of July 30, 2021, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,904 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 51% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 24% in the next 13 to 24 months, and the remainder thereafter.

[0001564590-21-046976:notes:74]
Deferred commissions

[0001564590-21-046976:notes:75]
The following tables summarize the activity related to deferred commissions and their balances as reported in our condensed consolidated balance sheets (in millions):

[0001564590-21-046976:notes:76]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Balance at beginning of period |  | $ | 197 |  |  | $ | 156 |  |
| Additions |  |  | 26 |  |  |  | 21 |  |
| Expense recognized during the period |  |  | (34 | ) |  |  | (25 | ) |
| Balance at end of period |  | $ | 189 |  |  | $ | 152 |  |

[0001564590-21-046976:notes:77]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| Other current assets |  | $ | 80 |  |  | $ | 86 |  |
| Other non-current assets |  |  | 109 |  |  |  | 111 |  |
| Total deferred commissions |  | $ | 189 |  |  | $ | 197 |  |

[0001564590-21-046976:notes:78]
Other expense, net (in millions):

[0001564590-21-046976:notes:79]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Interest income |  | $ | 2 |  |  | $ | 3 |  |
| Interest expense |  |  | (18 | ) |  |  | (18 | ) |
| Other income (expense), net |  |  | 4 |  |  |  | (17 | ) |
| Total other expense, net |  | $ | (12 | ) |  | $ | (32 | ) |

[0001564590-21-046976:notes:80]
[same as prior period, unchanged from 0001564590-21-009843:notes:54]

[0001564590-21-046976:notes:81]
Supplemental cash flow information related to our operating leases is included in Note 8 ─ Leases. Non-cash investing activities and other supplemental cash flow information are presented below:

[0001564590-21-046976:notes:82]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 15 |  |  | $ | 10 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 17 |  |  | $ | 136 |  |
| Interest paid |  | $ | 27 |  |  | $ | 16 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-21-046976:notes:83]
6. Financial Instruments and Fair Value Measurements

[0001564590-21-046976:notes:84]
[same as prior period, unchanged from 0001564590-21-009843:notes:76]

[0001564590-21-046976:notes:85]
[same as prior period, unchanged from 0001564590-21-009843:notes:77]

[0001564590-21-046976:notes:86]
[same as prior period, unchanged from 0001564590-21-009843:notes:78]

[0001564590-21-046976:notes:87]
[same as prior period, unchanged from 0001564590-21-009843:notes:79]

[0001564590-21-046976:notes:88]
[same as prior period, unchanged from 0001564590-21-009843:notes:80]

[0001564590-21-046976:notes:89]
[same as prior period, unchanged from 0001564590-21-009843:notes:81]

[0001564590-21-046976:notes:90]
The following is a summary of our investments at their cost or amortized cost for the periods ended July 30, 2021 and April 30, 2021 (in millions):

[0001564590-21-046976:notes:91]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |  |
| Corporate bonds |  | $ | 46 |  |  | $ | 58 |  |  |
| U.S. Treasury and government debt securities |  |  | 7 |  |  |  | 8 |  |  |
| Certificates of deposit |  |  | 55 |  |  |  | 61 |  |  |
| Mutual funds |  |  | 42 |  |  |  | 40 |  |  |
| Total debt and equity securities |  | $ | 150 |  |  | $ | 167 |  |  |

[0001564590-21-046976:notes:92]
The fair value of our investments approximates their cost or amortized cost for both periods presented. Investments in mutual funds relate to the non-qualified deferred compensation plan offered to certain employees.

[0001564590-21-046976:notes:93]
The following table presents the contractual maturities of our debt investments as of July 30, 2021 (in millions):

[0001564590-21-046976:notes:94]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 96 |  |  | $ | 97 |  |
| Due after one year through five years |  |  | 12 |  |  |  | 13 |  |
|  |  | $ | 108 |  |  | $ | 110 |  |

[0001564590-21-046976:notes:95]
[same as prior period, unchanged from 0001564590-21-009843:notes:86]

[0001564590-21-046976:notes:96]
[same as prior period, unchanged from 0001564590-21-009843:notes:87]

[0001564590-21-046976:notes:97]
[same as prior period, unchanged from 0001564590-21-009843:notes:88]

[0001564590-21-046976:notes:98]
|  |  | July 30. 2021 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 4,437 |  |  | $ | 4,437 |  |  | $ | — |  |
| Corporate bonds |  |  | 47 |  |  |  | — |  |  |  | 47 |  |
| U.S. Treasury and government debt securities |  |  | 8 |  |  |  | 4 |  |  |  | 4 |  |
| Certificates of deposit |  |  | 55 |  |  |  | — |  |  |  | 55 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,547 |  |  | $ | 4,441 |  |  | $ | 106 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 35 |  |  | $ | 35 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |

[0001564590-21-046976:notes:99]
|  |  | April 30, 2021 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 4,468 |  |  | $ | 4,468 |  |  | $ | — |  |
| Corporate bonds |  |  | 59 |  |  |  | — |  |  |  | 59 |  |
| U.S. Treasury and government debt securities |  |  | 8 |  |  |  | 4 |  |  |  | 4 |  |
| Certificates of deposit |  |  | 61 |  |  |  | — |  |  |  | 61 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,596 |  |  | $ | 4,472 |  |  | $ | 124 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 8 |  |  | $ | 8 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 32 |  |  | $ | 32 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0001564590-21-046976:notes:100]
[same as prior period, unchanged from 0001564590-21-009843:notes:90]

[0001564590-21-046976:notes:101]
[same as prior period, unchanged from 0001564590-21-009843:notes:91]

[0001564590-21-046976:notes:102]
[same as prior period, unchanged from 0001564590-21-009843:notes:92]

[0001564590-21-046976:notes:103]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of July 30, 2021 and April 30, 2021, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-21-046976:notes:104]
[same as prior period, unchanged from 0001564590-21-009843:notes:94]

[0001564590-21-046976:notes:105]
As of July 30, 2021 and April 30, 2021, the fair value of our long-term debt was approximately $2,782 million and $2,736 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-21-046976:notes:106]
7. Financing Arrangements

[0001564590-21-046976:notes:107]
Long-Term Debt

[0001564590-21-046976:notes:108]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-21-046976:notes:109]
|  |  | Effective Interest Rate |  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  | $ | 250 |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (17 | ) |  |  | (18 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,633 |  |  | $ | 2,632 |  |

[0001564590-21-046976:notes:110]
Senior Notes

[0001564590-21-046976:notes:111]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were issued in June 2020. Interest on these Senior Notes is payable semi-annually in June and December.

[0001564590-21-046976:notes:112]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September. Our 3.25% Senior Notes, with a principal amount of $250 million, were issued in December 2012 with interest paid semi-annually in June and December.

[0001564590-21-046976:notes:113]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-21-046976:notes:114]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 30, 2021, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-21-046976:notes:115]
As of July 30, 2021, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-21-046976:notes:116]
| Fiscal Year |  | Amount |  |
| 2022 |  | $ | — |  |
| 2023 |  |  | 250 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |

[0001564590-21-046976:notes:117]
Commercial Paper Program and Credit Facility

[0001564590-21-046976:notes:118]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. While no commercial paper notes were outstanding as of July 30, 2021, we had commercial paper notes outstanding with an aggregate principal amount of $150 million, a weighted-average interest rate of 1.29%, and maturities primarily less than three months as of July 31, 2020. During the first three months of fiscal 2021, we received proceeds of $75 million from the issuance, and made repayments of $76 million for the settlement, of commercial paper notes with original maturities greater than three months.

[0001564590-21-046976:notes:119]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of July 30, 2021, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0001564590-21-046976:notes:120]
8. Leases

[0001564590-21-046976:notes:121]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of July 30, 2021, have remaining lease terms of up to 15 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of July 30, 2021, have remaining lease terms of up to 4 years. As of July 30, 2021, our automobile leases have remaining lease terms of up to 5 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0001564590-21-046976:notes:122]
In June 2020, we entered into a build-to-suit lease agreement for an office building located in Wichita, Kansas, with future undiscounted payments of approximately $67 million. Because the Company does not control the underlying asset during the construction period, the Company is not considered the owner of the asset under construction for accounting purposes. The lease will commence upon completion of the construction of the office building which is expected to be in the third quarter of fiscal 2022. The initial term of the lease is twenty years with options to renew the lease during the lease term. A ROU asset and related lease liability will be measured and recognized in our financial statements in the period the lease commences.

[0001564590-21-046976:notes:123]
In April 2021, we entered into a lease for our new corporate headquarters located in San Jose, California, which is comprised of approximately three hundred thousand square feet of office space and requires future minimum undiscounted payments of approximately $180 million over the initial 11-year lease term. The lease agreement also provides us two successive renewal options, each for five years. The lease commenced during the first quarter of fiscal 2022.

[0001564590-21-046976:notes:124]
[same as prior period, unchanged from 0001564590-21-009843:notes:112]

[0001564590-21-046976:notes:125]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Operating lease cost |  | $ | 15 |  |  | $ | 14 |  |
| Variable lease cost |  |  | 4 |  |  |  | 3 |  |
| Total lease cost |  | $ | 19 |  |  | $ | 17 |  |

[0001564590-21-046976:notes:126]
[same as prior period, unchanged from 0001564590-21-009843:notes:114]

[0001564590-21-046976:notes:127]
[same as prior period, unchanged from 0001564590-21-009843:notes:115]

[0001564590-21-046976:notes:128]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 13 |  |  | $ | 14 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  | $ | 159 |  |  | $ | 10 |  |

[0001564590-21-046976:notes:129]
[same as prior period, unchanged from 0001564590-21-009843:notes:117]

[0001564590-21-046976:notes:130]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| Other non-current assets |  | $ | 259 |  |  | $ | 114 |  |
| Total operating lease ROU assets |  | $ | 259 |  |  | $ | 114 |  |
| Accrued expenses |  | $ | 53 |  |  | $ | 49 |  |
| Other long-term liabilities |  |  | 211 |  |  |  | 71 |  |
| Total operating lease liabilities |  | $ | 264 |  |  | $ | 120 |  |
| Weighted Average Remaining Lease Term |  | 8.0 years |  |  | 3.4 years |  |
| Weighted Average Discount Rate |  |  | 2.8 | % |  |  | 2.9 | % |

[0001564590-21-046976:notes:131]
Future minimum operating lease payments as of July 30, 2021, which exclude the undiscounted payments for the build-to-suit lease located in Wichita, Kansas, expected to commence in the third quarter of fiscal year 2022, are as follows (in millions):

[0001564590-21-046976:notes:132]
| Fiscal Year |  | Operating Leases |  |
| 2022 (remainder) |  | $ | 46 |  |
| 2023 |  |  | 46 |  |
| 2024 |  |  | 36 |  |
| 2025 |  |  | 27 |  |
| 2026 |  |  | 24 |  |
| Thereafter |  |  | 116 |  |
| Total lease payments |  |  | 295 |  |
| Less: Interest |  |  | (31 | ) |
| Total |  | $ | 264 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-21-046976:notes:133]
9. Stockholders’ Equity

[0001564590-21-046976:notes:134]
[same as prior period, unchanged from 0001564590-21-009843:notes:122]

[0001564590-21-046976:notes:135]
As of July 30, 2021, we have certain equity incentive awards (awards) outstanding, which include stock options and restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs). Also outstanding are purchase rights under our Employee Stock Purchase Plan (ESPP).

[0001564590-21-046976:notes:136]
[same as prior period, unchanged from 0001564590-21-009843:notes:124]

[0001564590-21-046976:notes:137]
Less than 1 million options were outstanding as of July 30, 2021 and April 30, 2021.

[0001564590-21-046976:notes:138]
[same as prior period, unchanged from 0001564590-21-009843:notes:126]

[0001564590-21-046976:notes:139]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Intrinsic value of exercises |  | $ | 5 |  |  | $ | — |  |
| Fair value of options vested |  | $ | 1 |  |  | $ | — |  |

[0001564590-21-046976:notes:140]
[same as prior period, unchanged from 0001564590-21-009843:notes:128]

[0001564590-21-046976:notes:141]
In the three months ended July 30, 2021, we granted PBRSUs to certain of our executives. Each PBRSUs has performance-based vesting criteria, in addition to the service-based vesting criteria, such that the PBRSUs cliff-vest at the end of an approximate one, two or three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the first, second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle most of these PBRSUs at the end of the performance and service period will range from 0% to 200% of a target number of shares originally granted. For most of the PBRSUs granted in the three months ended July 30, 2021, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. The fair values of these TSR performance-based awards were fixed at grant date using a Monte Carlo simulation model. The aggregate grant date fair value of all PBRSUs granted in the current year was $41 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0001564590-21-046976:notes:142]
[same as prior period, unchanged from 0001564590-21-009843:notes:131]

[0001564590-21-046976:notes:143]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 30, 2021 |  |  | 9 |  |  | $ | 47.75 |  |
| Granted |  |  | 4 |  |  | $ | 81.15 |  |
| Vested |  |  | (2 | ) |  | $ | 48.37 |  |
| Forfeited |  |  | (1 | ) |  | $ | 53.83 |  |
| Outstanding as of July 30, 2021 |  |  | 10 |  |  | $ | 59.95 |  |

[0001564590-21-046976:notes:144]
[same as prior period, unchanged from 0001564590-21-009843:notes:133]

[0001564590-21-046976:notes:145]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 57 |  |  | $ | 33 |  |

[0001564590-21-046976:notes:146]
[same as prior period, unchanged from 0001564590-21-009843:notes:135]

[0001564590-21-046976:notes:147]
[same as prior period, unchanged from 0001564590-21-009843:notes:136]

[0001564590-21-046976:notes:148]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Shares issued under the ESPP |  |  | 1 |  |  |  | 1 |  |
| Proceeds from issuance of shares |  | $ | 52 |  |  | $ | 48 |  |

[0001564590-21-046976:notes:149]
[same as prior period, unchanged from 0001564590-21-009843:notes:138]

[0001564590-21-046976:notes:150]
Stock-based compensation expense is included in the condensed consolidated statements of income as follows (in millions):

[0001564590-21-046976:notes:151]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |
| Cost of services revenues |  |  | 2 |  |  |  | 3 |  |
| Sales and marketing |  |  | 26 |  |  |  | 25 |  |
| Research and development |  |  | 16 |  |  |  | 19 |  |
| General and administrative |  |  | 8 |  |  |  | 6 |  |
| Total stock-based compensation expense |  | $ | 53 |  |  | $ | 54 |  |
| Income tax benefit for stock-based compensation expense |  | $ | 5 |  |  | $ | 4 |  |

[0001564590-21-046976:notes:152]
As of July 30, 2021, total unrecognized compensation expense related to our equity awards was $567 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.7 years.

[0001564590-21-046976:notes:153]
[same as prior period, unchanged from 0001564590-21-009843:notes:142]

[0001564590-21-046976:notes:154]
As of July 30, 2021, our Board of Directors has authorized the repurchase of up to $14.1 billion of our common stock. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time.

[0001564590-21-046976:notes:155]
The following table summarized activity related to the stock repurchase program for the three months ended July 30, 2021 (in millions, except for per share amounts):

[0001564590-21-046976:notes:156]
| Number of shares repurchased |  |  | 1 |  |
| Average price per share |  | $ | 80.08 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 3 |  |
| Stock repurchases allocated to retained earnings |  | $ | 97 |  |
| Remaining authorization at end of period |  | $ | 752 |  |

[0001564590-21-046976:notes:157]
Since the May 13, 2003 inception of our stock repurchase program through July 30, 2021, we repurchased a total of 341 million shares of our common stock at an average price of $39.17 per share, for an aggregate purchase price of $13.4 billion.

[0001564590-21-046976:notes:158]
[same as prior period, unchanged from 0001564590-21-009843:notes:147]

[0001564590-21-046976:notes:159]
[same as prior period, unchanged from 0001564590-21-009843:notes:148]

[0001564590-21-046976:notes:160]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Dividends per share declared |  | $ | 0.50 |  |  | $ | 0.48 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | — |  |  | $ | 30 |  |
| Dividend payments allocated to retained earnings |  | $ | 112 |  |  | $ | 77 |  |

[0001564590-21-046976:notes:161]
On August 23, 2021, we declared a cash dividend of $0.50 per share of common stock, payable on October 27, 2021 to holders of record as of the close of business on October 8, 2021. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-21-046976:notes:162]
[same as prior period, unchanged from 0001564590-21-009843:notes:151]

[0001564590-21-046976:notes:163]
[same as prior period, unchanged from 0001564590-21-009843:notes:152]

[0001564590-21-046976:notes:164]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 30, 2021 |  | $ | (27 | ) |  | $ | (4 | ) |  | $ | 1 |  |  | $ | — |  |  | $ | (30 | ) |
| Other comprehensive income (loss), net of tax |  |  | (4 | ) |  |  | — |  |  |  | (1 | ) |  |  | 1 |  |  |  | (4 | ) |
| Total other comprehensive income (loss) |  |  | (4 | ) |  |  | — |  |  |  | (1 | ) |  |  | 1 |  |  |  | (4 | ) |
| Balance as of July 30, 2021 |  | $ | (31 | ) |  | $ | (4 | ) |  | $ | — |  |  | $ | 1 |  |  | $ | (34 | ) |

[0001564590-21-046976:notes:165]
[same as prior period, unchanged from 0001564590-21-009843:notes:154]

[0001564590-21-046976:notes:166]
|  |  | Three Months Ended |  |  |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |  | Statements of Income Classification |
| Realized losses on cash flow hedges |  |  | — |  |  |  | 1 |  |  | Net revenues |
| Total reclassifications |  | $ | — |  |  | $ | 1 |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-21-046976:notes:167]
10. Derivatives and Hedging Activities

[0001564590-21-046976:notes:168]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of July 30, 2021 or April 30, 2021. All contracts have a maturity of less than 12 months.

[0001564590-21-046976:notes:169]
[same as prior period, unchanged from 0001564590-21-009843:notes:158]

[0001564590-21-046976:notes:170]
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 10 |  |  | $ | — |  |
| Forward contracts purchased |  | $ | 144 |  |  | $ | 123 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 632 |  |  | $ | 339 |  |
| Forward contracts purchased |  | $ | 82 |  |  | $ | 94 |  |

[0001564590-21-046976:notes:171]
The gain (loss) of cash flow hedges recognized in net revenues is presented in the condensed consolidated statements of comprehensive income and Note 9 – Stockholders’ Equity.

[0001564590-21-046976:notes:172]
The effect of derivative instruments not designated as hedging instruments recognized in other income (expense), net on our condensed consolidated statements of income was as follows (in millions):

[0001564590-21-046976:notes:173]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Foreign currency exchange contracts |  | $ | 9 |  |  | $ | 24 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-21-046976:notes:174]
11. Restructuring Charges

[0001564590-21-046976:notes:175]
In the first quarter of fiscal 2022, we executed a restructuring plan to reduce the amount of office space we currently occupy as we allow more employees to continue to work remotely. In connection with the plan, we reduced our global workforce by approximately

[0001564590-21-046976:notes:176]
1%. Charges related to the plan consisted primarily of office relocation costs, lease termination fees, and employee severance related costs. Substantially all workforce related activities under the plan have been completed.

[0001564590-21-046976:notes:177]
Management has previously approved several restructuring actions, including the August 2020 Plan and May 2020 Plan, under which we reduced our global workforce by approximately 6%. Charges related to these restructuring plans consisted primarily of employee severance-related costs. Substantially all activities under these plans were completed as of the end of fiscal 2021.

[0001564590-21-046976:notes:178]
[same as prior period, unchanged from 0001564590-21-009843:notes:167]

[0001564590-21-046976:notes:179]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Balance at beginning of period |  | $ | 1 |  |  | $ | 1 |  |
| Net charges |  |  | 22 |  |  |  | 5 |  |
| Cash payments |  |  | (17 | ) |  |  | (5 | ) |
| Balance at end of period |  | $ | 6 |  |  | $ | 1 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-21-046976:notes:180]
12. Income Taxes

[0001564590-21-046976:notes:181]
[same as prior period, unchanged from 0001564590-21-009843:notes:171]

[0001564590-21-046976:notes:182]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Effective tax rates |  |  | 14.8 | % |  |  | 26.0 | % |

[0001564590-21-046976:notes:183]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. Our effective tax rate for the three months ended July 30, 2021 includes the impact of discrete tax benefits for lapses of statute of limitations as well as benefits related to stock-based compensation. The effective tax rate for the three months ended July 31, 2020 reflects the impact of taxes resulting from the integration of acquired companies and smaller benefits for stock-based compensation as compared to the current year.

[0001564590-21-046976:notes:184]
As of July 30, 2021, we had $214 million of gross unrecognized tax benefits, of which $120 million has been recorded in other long-term liabilities. Inclusive of penalties, interest and certain income tax benefits, $117 million would affect our provision for income taxes if recognized.

[0001564590-21-046976:notes:185]
[same as prior period, unchanged from 0001564590-21-009843:notes:175]

[0001564590-21-046976:notes:186]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for such withholding tax and filed an appeal with the Danish Tax Tribunal. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012. In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). In March 2018, the Advocate General issued an opinion which was largely in favor of NetApp. The CJEU was not bound by the opinion of the Advocate General and issued its preliminary ruling in February 2019. The CJEU ruling did not preclude the Danish Tax Authorities from imposing withholding tax on distributions based on the benefits of certain European Union directives. On May 3, 2021, the DHC reached a decision resulting in NetApp prevailing on the predominate distribution made in 2005. The smaller distribution made in 2006 was ruled in favor of the Danish Tax Authorities. On May 28, 2021, the Danish Tax Authorities appealed the DHC decision to the Danish Supreme Court. We believe it is more likely than not that our distributions were not subject to withholding tax and we will continue to support our position in the appeals process with the Danish Supreme Court.

[0001564590-21-046976:notes:187]
[same as prior period, unchanged from 0001564590-21-009843:notes:176]


## us-gaap:EarningsPerShareTextBlock

[0001564590-21-046976:notes:188]
13. Net Income per Share

[0001564590-21-046976:notes:189]
[same as prior period, unchanged from 0001564590-21-009843:notes:178]

[0001564590-21-046976:notes:190]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 202 |  |  | $ | 77 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 223 |  |  |  | 221 |  |
| Dilutive impact of employee equity award plans |  |  | 6 |  |  |  | 1 |  |
| Shares used in diluted computation |  |  | 229 |  |  |  | 222 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.91 |  |  | $ | 0.35 |  |
| Diluted |  | $ | 0.88 |  |  | $ | 0.35 |  |

[0001564590-21-046976:notes:191]
No potential shares from outstanding employee awards were excluded from the diluted net income per share calculation for the three months ended July 30, 2021. Six million potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for the three months ended July 31, 2020, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-21-046976:notes:192]
14. Segment, Geographic, and Significant Customer Information

[0001564590-21-046976:notes:193]
Our operations are now organized into two segments for financial reporting purposes: Public Cloud and Hybrid Cloud. The two segments are based on the information reviewed by our Chief Operating Decision Maker (“CODM”), who is the Chief Executive Officer, to evaluate results and allocate resources. The CODM measures performance of each segment based on segment revenue and segment gross profit. We do not allocate to our segments certain cost of revenues which we manage at the corporate level. These unallocated costs include stock-based compensation and amortization of intangible assets. We do not allocate assets to our segments.

[0001564590-21-046976:notes:194]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support, and made available on the world’s leading clouds. This portfolio includes storage services, cloud automation and optimization services, and cloud infrastructure monitoring services.

[0001564590-21-046976:notes:195]
Hybrid Cloud offers a portfolio of storage and data management solutions that help customers build and integrate on-premises and private cloud environments. This portfolio is designed to operate with public clouds to unlock the potential of hybrid, multi-cloud operations. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.

[0001564590-21-046976:notes:196]
Financial information for the prior period has been updated to conform to the current year presentation of two segments.

[0001564590-21-046976:notes:197]
Segment Revenues and Gross Profit

[0001564590-21-046976:notes:198]
Financial information by segment is as follows (in millions):

[0001564590-21-046976:notes:199]
|  | Three Months Ended July 30, 2021 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 730 |  |  | $ | — |  |  | $ | 730 |  |
| Support revenues |  | 578 |  |  |  | — |  |  |  | 578 |  |
| Professional and other services revenues |  | 71 |  |  |  | — |  |  |  | 71 |  |
| Public cloud revenues |  | — |  |  |  | 79 |  |  |  | 79 |  |
| Net revenues |  | 1,379 |  |  |  | 79 |  |  |  | 1,458 |  |
| Cost of product revenues |  | 326 |  |  |  | — |  |  |  | 326 |  |
| Cost of support revenues |  | 48 |  |  |  | — |  |  |  | 48 |  |
| Cost of professional and other services revenues |  | 51 |  |  |  | — |  |  |  | 51 |  |
| Cost of public cloud revenues |  | — |  |  |  | 23 |  |  |  | 23 |  |
| Segment cost of revenues |  | 425 |  |  |  | 23 |  |  |  | 448 |  |
| Segment gross profit | $ | 954 |  |  | $ | 56 |  |  | $ | 1,010 |  |
| Segment gross margin |  | 69.2 | % |  |  | 70.9 | % |  |  | 69.3 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  |  |  | 11 |  |
| Total gross profit |  |  |  |  |  |  |  |  | $ | 999 |  |
| Total gross margin |  |  |  |  |  |  |  |  |  | 68.5 | % |
| 1 Unallocated cost of revenues are composed of $4 million of stock-based compensation expense and $7 million of amortization of intangible assets. |  |

[0001564590-21-046976:notes:200]
|  | Three Months Ended July 31, 2020 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 627 |  |  | $ | — |  |  | $ | 627 |  |
| Support revenues |  | 577 |  |  |  | — |  |  |  | 577 |  |
| Professional and other services revenues |  | 68 |  |  |  | — |  |  |  | 68 |  |
| Public cloud revenues |  | — |  |  |  | 31 |  |  |  | 31 |  |
| Net revenues |  | 1,272 |  |  |  | 31 |  |  |  | 1,303 |  |
| Cost of product revenues |  | 305 |  |  |  | — |  |  |  | 305 |  |
| Cost of support revenues |  | 51 |  |  |  | — |  |  |  | 51 |  |
| Cost of professional and other services revenues |  | 48 |  |  |  | — |  |  |  | 48 |  |
| Cost of public cloud revenues |  | — |  |  |  | 13 |  |  |  | 13 |  |
| Segment cost of revenues |  | 404 |  |  |  | 13 |  |  |  | 417 |  |
| Segment gross profit | $ | 868 |  |  | $ | 18 |  |  | $ | 886 |  |
| Segment gross margin |  | 68.2 | % |  |  | 58.1 | % |  |  | 68.0 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  |  |  | 14 |  |
| Total gross profit |  |  |  |  |  |  |  |  | $ | 872 |  |
| Total gross margin |  |  |  |  |  |  |  |  |  | 66.9 | % |
| 1 Unallocated cost of revenues are composed of $4 million of stock-based compensation expense and $10 million of amortization of intangible assets. |  |

[0001564590-21-046976:notes:201]
Revenues summarized by geographic region are as follows (in millions):

[0001564590-21-046976:notes:202]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| United States, Canada and Latin America (Americas) |  | $ | 786 |  |  | $ | 709 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 454 |  |  |  | 383 |  |
| Asia Pacific (APAC) |  |  | 218 |  |  |  | 211 |  |
| Net revenues |  | $ | 1,458 |  |  | $ | 1,303 |  |

[0001564590-21-046976:notes:203]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $696 million and $637 million during the three months ended July 30, 2021 and July 31, 2020, respectively.

[0001564590-21-046976:notes:204]
[same as prior period, unchanged from 0001564590-21-009843:notes:186]

[0001564590-21-046976:notes:205]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| U.S. |  | $ | 2,136 |  |  | $ | 2,098 |  |
| International |  |  | 2,411 |  |  |  | 2,498 |  |
| Total |  | $ | 4,547 |  |  | $ | 4,596 |  |

[0001564590-21-046976:notes:206]
[same as prior period, unchanged from 0001564590-21-009843:notes:188]

[0001564590-21-046976:notes:207]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| U.S. |  | $ | 343 |  |  | $ | 340 |  |
| International |  |  | 190 |  |  |  | 185 |  |
| Total |  | $ | 533 |  |  | $ | 525 |  |

[0001564590-21-046976:notes:208]
[same as prior period, unchanged from 0001564590-21-009843:notes:190]

[0001564590-21-046976:notes:209]
|  |  | Three Months Ended |  |
|  |  | July 30, 2021 |  |  | July 31, 2020 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 23 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 20 | % |

[0001564590-21-046976:notes:210]
The following customers accounted for 10% or more of accounts receivable:

[0001564590-21-046976:notes:211]
|  |  | July 30, 2021 |  |  | April 30, 2021 |  |
| Arrow Electronics, Inc. |  |  | 10 | % |  |  | 10 | % |
| Tech Data Corporation |  |  | 19 | % |  |  | 21 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-21-046976:notes:212]
15. Commitments and Contingencies

[0001564590-21-046976:notes:213]
Purchase Orders and Other Commitments

[0001564590-21-046976:notes:214]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 30, 2021, we had $614 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 30, 2021 and April 30, 2021, such liability amounted to $13 million and $15 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-21-046976:notes:215]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 30, 2021, we had $340 million in other purchase obligations.

[0001564590-21-046976:notes:216]
Financing Guarantees

[0001564590-21-046976:notes:217]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $17 million and $13 million of receivables during the three months ended July 30, 2021 and July 31, 2020, respectively.

[0001564590-21-046976:notes:218]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-21-046976:notes:219]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of July 30, 2021 and April 30, 2021, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-21-046976:notes:220]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 30, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-21-046976:notes:221]
Legal Contingencies

[0001564590-21-046976:notes:222]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-21-046976:notes:223]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. NetApp’s Motion to Dismiss was granted and on February 26, 2021 and the judge entered judgment in favor of NetApp. On March 26, 2021, Plaintiffs filed a notice of appeal. The parties subsequently engaged in settlement discussions, and on July 30, 2021 entered into a Memorandum of Understanding (“MOU”) providing for the settlement of the class action.  Pursuant to the terms of MOU, NetApp has agreed to pay approximately $2.0 million in connection with the settlement, and this amount was accrued during the three months ended July 30, 2021. The parties further agreed to negotiate in good faith to execute definitive stipulations of settlement and related documents to be filed with the court, which will not contain any admission of liability, wrongdoing or responsibility by any of the parties and will provide that upon final approval of the settlement, the class action will be dismissed with prejudice, with mutual releases by all parties. The settlement is subject to court approval.

[0001564590-21-046976:notes:224]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-21-046976:notes:225]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of July 30, 2021 related to such matters.
