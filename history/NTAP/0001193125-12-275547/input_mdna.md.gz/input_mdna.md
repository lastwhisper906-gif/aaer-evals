# NTAP MD&A — 0001193125-12-275547


## mdna

[0001193125-12-275547:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001193125-12-275547:mdna:2]
The following discussion of our financial condition and results of operations should be read together with the financial statements and
the accompanying notes set forth under “Item 8. Financial Statements and Supplementary Data”. The following discussion also contains trend information and other forward-looking statements that involve a number of risks and
uncertainties. The Risk Factors set forth in “Item 1A. Risk Factors” are hereby incorporated into the discussion by reference.

[0001193125-12-275547:mdna:3]
Executive Overview

[0001193125-12-275547:mdna:4]
Our Company

[0001193125-12-275547:mdna:5]
We are a leading provider of innovative storage systems and data management solutions that form the foundation for efficient and flexible IT infrastructures. Our storage systems help customers streamline
operations and lower the cost associated with storing and managing their data. Our unified fabric-attached storage (FAS) platform offers a storage platform for business applications, shared infrastructures, and cloud environments. We are a leading
original equipment manufacturer (OEM) storage provider enabling OEMs to offer market-leading IT and storage solutions that serve specific markets and customer requirements. Our E-Series platform, provides a storage platform for value-added
customization and big data workloads. In addition, we provide professional services, global support solutions, and customer education and training to help customers most effectively manage their data. We employ a multichannel distribution strategy,
selling products and services to end users and service providers through a direct sales force and through channel partners, including value-added resellers, system integrators, OEMs and distributors.

[0001193125-12-275547:mdna:6]
Acquisition

[0001193125-12-275547:mdna:7]
On May 6, 2011, we completed the acquisition of certain assets related to the Engenio external storage systems business (Engenio) of LSI Corporation (LSI). We paid LSI $480.0 million in cash and
also assumed certain liabilities related to Engenio. This acquisition enabled us to address growing customer requirements in the areas of high bandwidth and intensive analytics workloads such as video, including full-motion video capture and digital
video surveillance, as well as high-performance computing applications, such as genomics sequencing and scientific research. Our consolidated net revenues for fiscal 2012 include $665.9 million attributable to Engenio since the acquisition.

[0001193125-12-275547:mdna:8]
Financial Results and Key Performance Metrics Overview

[0001193125-12-275547:mdna:9]
The following table provides an overview of some of our key financial metrics for each of the last three fiscal years (in millions, except
per share amounts, percentages and days sales outstanding):

[0001193125-12-275547:mdna:10]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Net revenues |  | $ | 6,233.2 |  |  | $ | 5,122.6 |  |  | $ | 3,931.4 |  |
| Gross profit |  | $ | 3,713.4 |  |  | $ | 3,328.7 |  |  | $ | 2,519.2 |  |
| Gross profit margin percentage |  |  | 59.6 | % |  |  | 65.0 | % |  |  | 64.1 | % |
| Income from operations |  | $ | 746.5 |  |  | $ | 824.3 |  |  | $ | 488.4 |  |
| Income from operations as a percentage of net revenues |  |  | 12.0 | % |  |  | 16.1 | % |  |  | 12.4 | % |
| Net income |  | $ | 605.4 |  |  | $ | 673.1 |  |  | $ | 400.4 |  |
| Diluted income per share |  | $ | 1.58 |  |  | $ | 1.71 |  |  | $ | 1.13 |  |
| Operating cash flows |  | $ | 1,462.6 |  |  | $ | 1,346.3 |  |  | $ | 975.0 |  |
| Deferred revenue |  | $ | 2,815.9 |  |  | $ | 2,314.9 |  |  | $ | 1,914.6 |  |
| Days sales outstanding (DSO) |  |  | 44 |  |  |  | 47 |  |  |  | 37 |  |

[0001193125-12-275547:mdna:11]
|  | • |  | Net revenues: Our net revenues increased across all three geographic regions in fiscal 2012 compared to the prior year. This increase was primarily due to the increase in product sales, reflecting continued |

[0001193125-12-275547:mdna:12]
|  | demand for our storage efficiency and data management solutions and $656.6 million of E-Series OEM sales attributable to our acquisition of Engenio. |

[0001193125-12-275547:mdna:13]
|  | • |  | Gross profit: Our gross profit margin percentage of net revenues decreased in fiscal 2012 compared to the prior year primarily due to the inclusion of lower gross margin E-Series OEM products in the revenue mix. |

[0001193125-12-275547:mdna:14]
|  | • |  | Income from operations: Our income from operations as a percentage of sales decreased in fiscal 2012 compared to the prior year primarily due to the decrease in our gross profit margin as discussed above, as well as increases in our headcount and the average cost per headcount. |

[0001193125-12-275547:mdna:15]
|  | • |  | Net Income and Diluted Income Per Share: The decrease in net income in fiscal 2012 compared to the prior year reflects the lower operating income as discussed above. |

[0001193125-12-275547:mdna:16]
|  | • |  | Operating cash flows: Operating cash flows increased 9% in fiscal 2012, reflecting our focus on managing our working capital and cash-based operating expenses. |

[0001193125-12-275547:mdna:17]
|  | • |  | Deferred revenue: Total deferred revenue increased $501.0 million in fiscal 2012 compared to the prior year primarily due to an increase in deferred software entitlements and maintenance (SEM) and service revenue driven by service contract sales and renewals. |

[0001193125-12-275547:mdna:18]
|  | • |  | DSO: Our DSO decreased in fiscal 2012 compared to the prior year primarily due to higher accounts receivables collections, despite a decrease in shipment linearity. |

[0001193125-12-275547:mdna:19]
Stock Repurchase Program Activity

[0001193125-12-275547:mdna:20]
During fiscal 2012, we repurchased approximately 14.6 million shares of our common stock at an average price of $40.97 per share.

[0001193125-12-275547:mdna:21]
Critical Accounting Estimates and Policies

[0001193125-12-275547:mdna:22]
Our discussion and analysis of financial condition and results of operations are based upon our consolidated financial statements, which have been prepared in accordance with accounting principles
generally accepted in the United States of America. The preparation of such statements requires us to make estimates and assumptions that affect the reported amounts of revenues and expenses during the reporting period and the reported amounts of
assets and liabilities as of the date of the financial statements. Our estimates are based on historical experience and other assumptions that we consider to be appropriate in the circumstances. However, actual future results may vary from our
estimates.

[0001193125-12-275547:mdna:23]
We believe that the following accounting policies are significantly affected by critical accounting estimates and
that they are both highly important to the portrayal of our financial condition and results and require difficult management judgments and assumptions about matters that are inherently uncertain. Note 2 of the accompanying consolidated
financial statements describes the significant accounting policies used in the preparation of the consolidated financial statements. Certain of these significant accounting policies are considered to be critical accounting policies.

[0001193125-12-275547:mdna:24]
We believe the accounting policies described below are those that most frequently require us to make estimates and judgments and
therefore are critical to the understanding of our results of operations.

[0001193125-12-275547:mdna:25]
Revenue Recognition, Reserves and Allowances

[0001193125-12-275547:mdna:26]
Revenue Recognition — We recognize revenue when:

[0001193125-12-275547:mdna:27]
|  | • |  | Persuasive evidence of an arrangement exists: It is our customary practice to have a purchase order and/or contract prior to recognizing revenue on an arrangement from our end users, customers, value-added resellers or distributors. |

[0001193125-12-275547:mdna:28]
|  | • |  | Delivery has occurred: Our product is physically delivered to our customers, generally with standard transfer terms such as FOB origin. We typically do not allow for restocking rights with any of our value-added resellers or distributors. Products shipped with acceptance criteria or return rights are not recognized as revenue until all criteria are achieved. If undelivered products or services exist that are essential to the functionality of the delivered product in an arrangement, delivery is not considered to have occurred. |

[0001193125-12-275547:mdna:29]
|  | • |  | The fee is fixed or determinable: Arrangements with payment terms extending beyond our standard terms, conditions and practices are not considered to be fixed or determinable. Revenue from such arrangements is recognized at the earlier of customer payment or when the fees become due and payable. We typically do not allow for price-protection rights with any of our value-added resellers or distributors. |

[0001193125-12-275547:mdna:30]
|  | • |  | Collection is reasonably assured: If there is considerable doubt surrounding the credit worthiness of a customer at the outset of an arrangement, the associated revenue is deferred and recognized upon cash receipt. |

[0001193125-12-275547:mdna:31]
Our multiple element
arrangements include our systems and one or more of the following undelivered elements: SEM and premium hardware maintenance. Our SEM entitle our customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis,
bug fixes, and patch releases. Premium hardware maintenance services include contracts for technical support and minimum response times. Revenues from SEM and premium hardware maintenance services are recognized ratably over the contractual term,
generally from one to five years. We also offer extended service contracts (which extend our standard parts warranty and may include premium hardware maintenance) at the end of the warranty term; revenues from these contracts are recognized ratably
over the contract term. We also sell professional services either on a time and materials basis or under fixed price standard projects; we recognize revenue for these services as they are performed. Revenue from hardware installation services is
recognized in the period the services are delivered.

[0001193125-12-275547:mdna:32]
In October 2009, the Financial Accounting Standards Board (FASB) amended
the accounting standards for revenue recognition to exclude tangible products containing software components and non-software components that function together to deliver the tangible product’s essential functionality from the scope of the
software revenue recognition guidance. Concurrently, the FASB also amended the accounting standards for multiple deliverable revenue arrangements to:

[0001193125-12-275547:mdna:33]
|  | • |  | provide updated guidance on whether multiple deliverables exist, how the deliverables in an arrangement should be separated, and how the arrangement consideration should be allocated among its elements; |

[0001193125-12-275547:mdna:34]
|  | • |  | require an entity to allocate revenue in an arrangement that has separate units of accounting using best estimated selling prices (BESP) of deliverables if a vendor does not have vendor-specific objective evidence (VSOE) of fair value or third-party evidence of selling price (TPE); and |

[0001193125-12-275547:mdna:35]
|  | • |  | eliminate the use of the residual method and require an entity to allocate revenue using the relative selling price method to the separate units of accounting. |

[0001193125-12-275547:mdna:36]
We adopted these standards in fiscal 2011 for new and materially modified revenue arrangements
originating after April 30, 2010.

[0001193125-12-275547:mdna:37]
The majority of our products are hardware systems containing software components that
function together to provide the essential functionality of the product. Therefore, our hardware systems and software components essential to the functionality of the hardware systems are considered non-software deliverables and therefore are not
subject to industry-specific software revenue recognition guidance.

[0001193125-12-275547:mdna:38]
Our product revenues also include revenues from the sale
of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our
software. Non-essential

[0001193125-12-275547:mdna:39]
44

[0001193125-12-275547:mdna:40]
software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the guidance, a delivered item is accounted for as a
separate unit if the delivered item has standalone value and if the customer (i) has a general right of return relative to the delivered item and (ii) delivery or performance of the undelivered item is probable and substantially within our
control. Both of the separation criteria must be met in order for a delivered item to be accounted for as a separate unit.

[0001193125-12-275547:mdna:41]
For transactions entered into or materially modified after April 30, 2010, we recognize revenue in accordance with the current
accounting standards when applicable. Certain arrangements with multiple deliverables may continue to have software deliverables that are subject to the existing software revenue recognition guidance along with non-software deliverables that are
subject to the standards. The revenue for these multiple element arrangements is allocated to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement
using the selling price hierarchy set forth in the standards.

[0001193125-12-275547:mdna:42]
For our non-software deliverables, we allocate the arrangement
consideration based on the relative selling price of the deliverables. For our non-software deliverables, we use BESP as our selling price. For our software entitlements and support services, we generally use VSOE as our selling price. When we are
unable to establish selling prices using VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement consideration.

[0001193125-12-275547:mdna:43]
VSOE of fair value for elements of an arrangement is based upon the normal pricing and discounting practices for those services when sold separately. In determining VSOE, we require that a substantial
majority of the selling prices for an element fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider
major service type, customer classifications, and other variables in determining VSOE.

[0001193125-12-275547:mdna:44]
When VSOE cannot be established, we
attempt to establish the selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings
contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products’ selling prices are on
a stand-alone basis. Therefore, we typically are not able to determine TPE for our products or services.

[0001193125-12-275547:mdna:45]
When we are unable
to establish the selling price of our non-software deliverables using VSOE or TPE, we use BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or
service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and
distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

[0001193125-12-275547:mdna:46]
We regularly review VSOE, TPE, and BESP and maintain internal controls over the establishment and updates of these estimates.

[0001193125-12-275547:mdna:47]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal
year 2011, we recognize revenue based on software revenue recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be
delivered at a future date and VSOE of fair value of all undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is SEM and/or service. Under the residual
method, the fair value of the undelivered elements is deferred and the remaining portion of the contract fee is recognized as product revenues. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is
generally deferred

[0001193125-12-275547:mdna:48]
until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire
arrangement is recognized ratably over the maintenance period.

[0001193125-12-275547:mdna:49]
We record reductions to revenue for estimated sales returns at
the time of shipment. Sales returns are estimated based on historical sales returns, current trends, and our expectations regarding future experience. We monitor and analyze the accuracy of sales returns estimates by reviewing actual returns and
adjust them for future expectations to determine the adequacy of our current and future reserve needs. If actual future returns and allowances differ from past experience, additional allowances may be required.

[0001193125-12-275547:mdna:50]
We also maintain a separate allowance for doubtful accounts for estimated losses based on our assessment of the collectability of
specific customer accounts and the aging of the accounts receivable. We analyze accounts receivable and historical bad debts, customer concentrations, customer solvency, current economic and geographic trends, and changes in customer payment terms
and practices when evaluating the adequacy of our current and future allowance. Our reserve levels have generally been sufficient to cover credit losses. If the financial condition of our customers were to deteriorate, resulting in an impairment of
their ability to make payments, additional allowances may be required.

[0001193125-12-275547:mdna:51]
Inventory Valuation and Purchase Order Accruals

[0001193125-12-275547:mdna:52]
Inventories are stated at the lower of cost or market, which approximates actual cost on a first-in, first-out basis.
We perform an excess and obsolete analysis of our inventory based upon assumptions about future demand forecasts and market conditions. We adjust the inventory value based on estimated excess and obsolete inventories determined primarily by future
demand forecasts. Although we use our best estimates in our forecasts of future product demand, any significant unanticipated changes in demand or technological developments could have a significant impact on the value of our inventory commitments
and on our reported results. If actual market conditions are less favorable than those projected, additional write-downs and other charges against earnings may be required. If actual market conditions are more favorable, we may realize higher gross
profits in the period when the written-down inventory is sold. Historically, our inventory valuation adjustments have been sufficient to cover any excess and obsolete exposure and have not required material adjustments in subsequent periods.

[0001193125-12-275547:mdna:53]
In the normal course of business we make commitments to our third-party contract manufacturers to manage lead times and meet
product forecasts, and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased commitments when we believe it is probable that the components will not be
utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001193125-12-275547:mdna:54]
We are subject to a variety of federal, state, local, and foreign environmental regulations relating to the use, storage, discharge, and disposal of hazardous chemicals used in the manufacture of our
products, which may require design changes or recycling of products we manufacture. We will continue to monitor our compliance with these regulations, which may require us to incur higher costs, and adversely impact our operating results.

[0001193125-12-275547:mdna:55]
Business Combinations

[0001193125-12-275547:mdna:56]
We allocate the purchase price of acquired companies to identifiable assets acquired and liabilities assumed at their acquisition date fair values. Goodwill as of the acquisition date is measured as the
excess of consideration transferred over the net of the acquisition date fair values of the assets acquired and the liabilities assumed. Significant management judgments and assumptions are required in determining the fair value of assets acquired
and liabilities assumed, particularly acquired intangible assets which typically comprise developed technology, trademarks and trade names, customer contracts/relationships and covenants not to compete.

[0001193125-12-275547:mdna:57]
The valuation of purchased intangible assets is principally based upon estimates of the
future performance and cash flows from the acquired business. If different assumptions are used, it could materially impact the purchase price allocation and our financial position and results of operations. Management’s estimates of fair value
are based upon assumptions believed to be reasonable, but which are inherently uncertain and unpredictable. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets
acquired and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation.

[0001193125-12-275547:mdna:58]
Valuation of Goodwill and Intangibles

[0001193125-12-275547:mdna:59]
Purchased intangible assets
are amortized over their useful lives unless these lives are determined to be indefinite. In-process research and development is capitalized at fair value and classified as an indefinite-lived asset until completion or abandonment and is subject to
periodic review for impairment. Accordingly, the allocation of acquisition cost to identifiable intangible assets has a significant impact on our future operating results. The allocation process requires extensive use of estimates and assumptions,
including estimates of future cash flows expected to be generated by the acquired assets. Should conditions be different than management’s assessment, material impairments of the fair value of intangible assets may be required. We periodically
review the estimated remaining useful lives of our intangible assets. A reduction in the estimated remaining useful life could result in accelerated amortization expense or an impairment in future periods. As such, any future impairments of these
assets would adversely affect our operating results.

[0001193125-12-275547:mdna:60]
We perform an annual review of the valuation of goodwill in the fourth
quarter of each fiscal year, or more often if indicators of impairment exist. Triggering events for impairment reviews may be indicators such as adverse industry or economic trends, restructuring actions, lower projections of profitability, or a
sustained decline in our market capitalization. Evaluations of possible impairment and, if applicable, adjustments to carrying values require us to estimate, among other factors, future cash flows, useful lives, and fair market values of our
reporting units and assets. When we conduct our evaluation of goodwill, the fair value of goodwill is assessed using valuation techniques that require significant management estimates and judgment. Should conditions be different from
management’s last assessment, significant impairments of goodwill may be required, which would adversely affect our operating results. In fiscal 2012, we performed such evaluation and determined the fair value substantially exceeded the
carrying value and therefore, found no impairment of goodwill.

[0001193125-12-275547:mdna:61]
Product Warranties

[0001193125-12-275547:mdna:62]
Estimated future hardware and software warranty costs are recorded as a cost of product revenues when the related revenue is recognized,
based on historical and projected warranty claim rates, historical and projected cost-per-claim and knowledge of specific project failures that are outside our typical experience. Factors that affect our warranty liability include the number of
installed units subject to warranty protections, product failure rates, estimated material costs, estimated distribution costs and estimated labor costs. We assess the adequacy of our warranty accrual each quarter and adjust the amount as considered
necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liability would be required and could materially affect our results of operations.

[0001193125-12-275547:mdna:63]
Stock-Based Compensation

[0001193125-12-275547:mdna:64]
We account for stock-based compensation using the Black-Scholes option pricing model to estimate the fair value of each award grant on the date of grant. Our option pricing model requires the input of
highly subjective assumptions, including the expected term of awards and the expected stock price volatility of the stock underlying such awards. In addition, we estimate the number of stock-based awards that will be forfeited due to employee
turnover based on historical experience. Any changes in these highly subjective estimates and assumptions may significantly impact stock-based compensation expense.

[0001193125-12-275547:mdna:65]
47

[0001193125-12-275547:mdna:66]
Loss Contingencies

[0001193125-12-275547:mdna:67]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We consider the likelihood of
the loss or impairment of an asset or the incurrence of a liability as well as our ability to reasonably estimate the amount of loss in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has
been incurred or an asset has been impaired and the amount of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted.

[0001193125-12-275547:mdna:68]
Fair Value Measurements and Impairments of Marketable Securities

[0001193125-12-275547:mdna:69]
All of our available-for-sale investments are reported at fair value and are subject to periodic impairment review. Unrealized gains and
losses related to changes in the fair value of securities are recognized in accumulated other comprehensive income, net of tax. Changes in the fair value of available-for-sale securities impact our net income only when such securities are sold or an
other-than-temporary impairment is recognized. We actively review current investment ratings, company-specific events, and general economic conditions in managing our investments and determining whether there is a significant decline in fair value
that is other-than-temporary.

[0001193125-12-275547:mdna:70]
Investments are considered to be impaired when a decline in fair value is judged to be
other-than-temporary. This determination requires significant judgment. For publicly traded investments, impairment is determined based upon the specific facts and circumstances present at the time, including factors such as current economic and
market conditions, the credit rating of the security’s issuer, the length of time an investment’s fair value has been below its carrying value, the extent to which fair value is below cost, and our ability and intent to hold investments
for a period of time sufficient to allow for any anticipated recovery in value. If an investment’s decline in fair value, caused by factors other than changes in interest rates, is deemed to be other-than-temporary, we reduce its carrying value
to its estimated fair value, as determined based on quoted market prices, liquidation values or other metrics. For investments in publicly held companies, we recognize an impairment charge when the decline in the fair value of our investment is
below its cost basis and is judged to be other-than-temporary. The ultimate value realized on these investments is subject to market price volatility until they are sold.

[0001193125-12-275547:mdna:71]
We are also exposed to market risk relating to our available-for-sale investments due to uncertainties in the credit and capital markets. The fair value of our investments may change significantly due to
events and conditions in the credit and capital markets. These securities/issuers could be subject to review for possible downgrade. Any downgrade in these credit ratings may result in a decline in the estimated fair value of our investments. We
monitor our investment portfolio on a quarterly basis for other-than-temporary impairment charges.

[0001193125-12-275547:mdna:72]
We hold investments in
Auction Rate Securities (ARS), which we classify as long-term investments as we believe our ability to liquidate these investments in the next twelve months is uncertain. The valuation models used to estimate the fair value of our ARS included
numerous assumptions such as assessments of the underlying structure of each security, expected cash flows, discount rates, trading activity in the secondary market for similar securities, credit ratings, workout periods, and overall capital market
liquidity. These assumptions, assessments and the interpretations of relevant market data are subject to uncertainties, are difficult to predict and require significant judgment. The use of different assumptions, or applying different judgments to
inherently subjective matters and changes in future market conditions could result in significantly different estimates of fair value. The fair value of our ARS could change significantly based on market conditions and continued uncertainties in the
credit markets. If these uncertainties continue or if these securities experience credit rating downgrades, we may incur additional temporary impairment related to our auction rate securities portfolio. We actively monitor the fair value of our ARS
and relevant market conditions and will record additional temporary or other-than-temporary impairments if future circumstances warrant such charges.

[0001193125-12-275547:mdna:73]
48

[0001193125-12-275547:mdna:74]
Income Taxes

[0001193125-12-275547:mdna:75]
The determination of our tax provision is subject to judgments and estimates due to the complexity of the tax law that we are subject to
in several tax jurisdictions. Earnings derived from our international business are generally taxed at rates that are lower than U.S. rates, resulting in a lower effective tax rate than the U.S. statutory tax rate of 35.0%. The ability to
maintain our current effective tax rate is contingent on existing tax laws in both the United States and the respective countries in which our international subsidiaries are located. Future changes in domestic or international tax laws could
affect the continued realization of the tax benefits we are currently receiving. In addition, a decrease in the percentage of our total earnings from international business or a change in the mix of international business among particular tax
jurisdictions could increase our overall effective tax rate.

[0001193125-12-275547:mdna:76]
We account for income taxes by recognizing deferred tax assets
and liabilities for the effect of temporary differences between the carrying amounts of assets and liabilities for financial reporting purposes and the amounts used for income tax purposes. We reduce deferred tax assets by a valuation allowance if
it is more likely than not that some or all of the deferred tax asset will not be realized. Tax attributes related to the exercise of employee stock options are not realized until they result in a reduction of taxes payable. We do not include
unrealized stock option attributes as components of our gross deferred tax assets and corresponding valuation allowance disclosures.

[0001193125-12-275547:mdna:77]
Deferred income taxes have not been provided on the undistributed earnings of foreign subsidiaries because these earnings have been indefinitely reinvested and we do not plan to initiate any action that
would precipitate the payment of income taxes thereon. We consider the following matters, among others, in evaluating our plans for indefinite reinvestment: the forecasts, budgets and financial requirements of the parent and subsidiaries for both
the long and short term; the tax consequences of a decision to reinvest; and any U.S. and foreign government programs designed to influence remittances. If factors change and as a result we are unable to indefinitely reinvest the foreign earnings,
the income tax expense and payments may differ significantly from the current period and could materially adversely affect our results of operations.

[0001193125-12-275547:mdna:78]
We recognize tax liabilities for uncertain tax positions by applying a recognition threshold and measurement attribute for the financial statement recognition and measurement of a tax position taken or
expected to be taken in a tax return. We recognize the tax liability for uncertain income tax positions on income tax returns based on a two-step process. The first step is to determine whether it is more likely than not that each income tax
position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts
requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances,
changes in applicable tax law, settlement of issues under audit and new exposures. If we later determine that our exposure is lower or that the liability is not sufficient to cover our revised expectations, we adjust the liability and effect a
related change in our tax provision during the period in which we make such determination.

[0001193125-12-275547:mdna:79]
New Accounting Standards

[0001193125-12-275547:mdna:80]
See Note 4 of the accompanying consolidated financial statements for a full description of new accounting pronouncements, including
the respective expected dates of adoption and effects on results of operations and financial condition.

[0001193125-12-275547:mdna:81]
Results of Operations

[0001193125-12-275547:mdna:82]
The following table sets forth certain consolidated statements of operations data as a percentage of net revenues for the periods indicated:

[0001193125-12-275547:mdna:83]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 67.6 | % |  |  | 65.7 | % |  |  | 60.6 | % |
| Software entitlements and maintenance |  |  | 13.0 |  |  |  | 14.1 |  |  |  | 17.3 |  |
| Service |  |  | 19.4 |  |  |  | 20.2 |  |  |  | 22.1 |  |
| Net revenues |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 31.7 |  |  |  | 26.2 |  |  |  | 24.8 |  |
| Cost of software entitlements and maintenance |  |  | 0.4 |  |  |  | 0.3 |  |  |  | 0.3 |  |
| Cost of service |  |  | 8.3 |  |  |  | 8.5 |  |  |  | 10.8 |  |
| Gross profit |  |  | 59.6 |  |  |  | 65.0 |  |  |  | 64.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 29.9 |  |  |  | 31.2 |  |  |  | 32.9 |  |
| Research and development |  |  | 13.3 |  |  |  | 12.7 |  |  |  | 13.6 |  |
| General and administrative |  |  | 4.2 |  |  |  | 4.9 |  |  |  | 6.1 |  |
| Restructuring and other charges |  |  | — |  |  |  | — |  |  |  | 0.1 |  |
| Acquisition-related expense (income), net |  |  | 0.2 |  |  |  | 0.1 |  |  |  | (1.0 | ) |
| Total operating expenses |  |  | 47.6 |  |  |  | 48.9 |  |  |  | 51.7 |  |
| Income from operations |  |  | 12.0 |  |  |  | 16.1 |  |  |  | 12.4 |  |
| Other expense, net |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | (1.0 | ) |
| Income before income taxes |  |  | 11.4 |  |  |  | 15.5 |  |  |  | 11.4 |  |
| Provision for income taxes |  |  | 1.7 |  |  |  | 2.4 |  |  |  | 1.2 |  |
| Net income |  |  | 9.7 | % |  |  | 13.1 | % |  |  | 10.2 | % |

[0001193125-12-275547:mdna:84]
Discussion and Analysis of Results of Operations for the Three Years Ended April 27, 2012

[0001193125-12-275547:mdna:85]
Overview — Net revenues for fiscal 2012 were $6,233.2 million, up $1,110.6 million, or 22%, from fiscal 2011.
The revenue growth was primarily due to $656.6 million of E-Series OEM revenues, continued demand for our storage efficiency and data management solutions, and an increase in hardware maintenance contract revenues. Net revenues for fiscal 2011 were
$5,122.6 million, up $1,191.2 million, or 30%, from fiscal 2010. The revenue growth in fiscal 2011 was primarily due to strong demand for our storage efficiency and data management solutions, including new products launched in November
2010. Additionally, net revenues for fiscal 2011 include a favorable impact of $129.2 million, or 3% of fiscal 2011 revenues, from the adoption of new accounting standards related to revenue recognition.

[0001193125-12-275547:mdna:86]
Gross profit as a percentage of net revenues decreased in fiscal 2012 compared to fiscal 2011, primarily due to the inclusion of lower
gross margin E-Series OEM products in the revenue mix and the impact of higher discounting. These decreases were partially offset by manufacturing cost reductions. Gross profit as a percentage of net revenues increased in fiscal 2011 compared to
fiscal 2010, primarily due to higher product and service revenues at improved margins.

[0001193125-12-275547:mdna:87]
Sales and marketing, research and
development and general and administrative expenses for fiscal 2012 totaled $2,957.1 million, up 18% from fiscal 2011. These increases were primarily due to a 26% increase in average headcount in fiscal 2012 compared to fiscal 2011. The May 2011
acquisition of Engenio represented approximately 10% of the average headcount for fiscal 2012. Sales and marketing, research and development and

[0001193125-12-275547:mdna:88]
general and administrative expenses for fiscal 2011 totaled $2,496.9 million, up 21% from fiscal 2010. This increase is primarily due to a 17% increase in average headcount in fiscal 2011 and
higher levels of incentive compensation and commission expense due to higher revenues and operating profits. Salary and related expenses during fiscal 2011 were favorably impacted by having 52 weeks in fiscal 2011 compared to 53 weeks in fiscal
2010.

[0001193125-12-275547:mdna:89]
Net Revenues — Net revenues were as follows (in millions, except percentages):

[0001193125-12-275547:mdna:90]
|  |  | Year Ended |  |
|  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Net revenues |  | $ | 6,233.2 |  |  | $ | 5,122.6 |  |  |  | 22 | % |  | $ | 3,931.4 |  |  |  | 30 | % |

[0001193125-12-275547:mdna:91]
Net revenues increased by $1,110.6 million, or 22% in fiscal 2012 compared to fiscal 2011. The increase
in net revenues for fiscal 2012 was primarily due to an increase in product revenues, which comprised 68% of net revenues in fiscal 2012 compared to 66% of net revenues in fiscal 2011.

[0001193125-12-275547:mdna:92]
Net revenues increased by $1,191.2 million, or 30%, in fiscal 2011 compared to fiscal 2010. The increase in net revenues for fiscal 2011
was primarily due to an increase in product revenues, which comprised 66% of net revenues in fiscal 2011 compared to 61% of net revenues in fiscal 2010. Additionally, net revenues in fiscal 2011 include a favorable impact of $129.2 million, or 3%
from the adoption of new accounting standards related to revenue recognition.

[0001193125-12-275547:mdna:93]
Sales through our indirect channels represented
78%, 73% and 69% of net revenues in fiscal 2012, 2011 and 2010, respectively.

[0001193125-12-275547:mdna:94]
The following customers, each of which is a
distributor, accounted for 10% or more of net revenues (in millions, except percentages):

[0001193125-12-275547:mdna:95]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | % of NetRevenues |  |  | April 29,2011 |  |  | % of NetRevenues |  |  | April 30,2010 |  |  | % of NetRevenues |  |
| Arrow Electronics, Inc. |  | $ | 1,035.7 |  |  |  | 17 | % |  | $ | 903.0 |  |  |  | 18 | % |  | $ | 550.7 |  |  |  | 14 | % |
| Avnet, Inc. |  |  | 753.6 |  |  |  | 12 | % |  |  | 639.0 |  |  |  | 12 | % |  |  | 444.0 |  |  |  | 11 | % |

[0001193125-12-275547:mdna:96]
The increase in our indirect channels in fiscal 2012 reflects $656.6 million of E-Series OEM revenue.

[0001193125-12-275547:mdna:97]
Product Revenues (in millions, except percentages):

[0001193125-12-275547:mdna:98]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Product revenues |  | $ | 4,209.7 |  |  | $ | 3,367.1 |  |  |  | 25 | % |  | $ | 2,381.1 |  |  |  | 41 | % |

[0001193125-12-275547:mdna:99]
Product revenues increased by $842.6 million, or 25% in fiscal 2012 compared to fiscal 2011, and by
$986.0 million, or 41%, in fiscal 2011 compared to fiscal 2010. Product revenues for fiscal 2011 included a 4% favorable impact from the adoption of new revenue recognition standards. Product revenues consist of configured systems, which are
comprised of bundled hardware and software products, and non-configured products, which consist primarily of add-on hardware, storage, and software products, as well as OEM products.

[0001193125-12-275547:mdna:100]
Total configured system revenues of $2,219.7 million increased by $163.2 million, or 8%, in fiscal 2012, compared to fiscal 2011, with
the largest increase in the 6000 series systems, partially offset by decreases in the 2000 series systems. Configured systems unit volume increased by 6% for fiscal 2012, compared to fiscal 2011, with increases in both the 6000 and 3000 series
systems, offset by a decrease in the 2000 series systems. The

[0001193125-12-275547:mdna:101]
increases in the unit volume of the 6000 and 3000 series were due to customer demand for newer products within these series. The decrease in the 2000 series unit volume was primarily due to a
decrease in demand for the older products within this series, as well as a shift in demand to the newer 3000 series systems. The average selling prices (ASPs) of total configured systems slightly increased during fiscal 2012, compared to fiscal 2011
due to a shift in system revenue mix from the lower ASP 2000 series to the higher ASP 3000 and 6000 series. However, ASP’s across each series decreased in fiscal 2012 compared to fiscal 2011 primarily due to higher discounting. Non-configured
product revenues of $1,990.0 million increased $679.4 million, or 52%, during fiscal 2012, compared to fiscal 2011. This increase was primarily due to E-Series OEM product revenues of $650.7 million during fiscal 2012.

[0001193125-12-275547:mdna:102]
Total configured system revenues of $2,056.5 million increased by $687.9 million, or 50%, for fiscal 2011, compared to fiscal 2010, with
the largest increase in the 3000 series systems. Configured systems revenues increased primarily from a unit volume increase of 46% for fiscal 2011 compared to fiscal 2010, with the largest increases occurring in the 2000 and 3000 series systems.
The increases in the unit volumes of the 2000 and 3000 series were due to customer demand for storage efficiency and data management solutions as well as new products within these series. In fiscal 2011, ASPs of the 3000 and 2000 series systems
increased, while the ASP decreased on the 6000 series systems. Non-configured product revenues of $1,310.6 million increased $298.0 million, or 29%, during fiscal 2011, compared to fiscal 2010. This increase was primarily due to a 32% increase in
sales of our add-on storage products during fiscal 2011 compared to fiscal 2010 due to customers increasing the capacity and/or functionality of their storage systems.

[0001193125-12-275547:mdna:103]
Our systems are highly configurable to respond to customer requirements in the open systems storage markets that we serve. This can cause a wide variation in product configurations that can significantly
impact revenues, cost of revenues and gross profit performance. Pricing changes, discounting practices, product competition, foreign currency, unit volumes, customer mix, natural disasters and product material costs can also impact revenues, cost of
revenues and/or gross profit performance. Disks are a significant component of our storage systems. Industry disk pricing has fallen every year; however, when supplies are constrained as they recently were due to the flooding in Thailand, disk
prices have increased and may continue to do so. To the extent that disk prices increase or decrease, we intend to pass along those price increases or decreases to our customers while working to maintain relatively constant profit margins on our
disk drives. As our sales price per terabyte continues to decline, improved system performance, increased capacity and software to manage this increased capacity have an offsetting impact on product revenues.

[0001193125-12-275547:mdna:104]
Software Entitlements and Maintenance Revenues (in millions, except percentages):

[0001193125-12-275547:mdna:105]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Software entitlements and maintenance revenues |  | $ | 812.2 |  |  | $ | 720.6 |  |  |  | 13 | % |  | $ | 679.8 |  |  |  | 6 | % |

[0001193125-12-275547:mdna:106]
Software entitlements and maintenance (SEM) revenues increased by $91.6 million, or 13%, in fiscal 2012
compared to fiscal 2011 and increased $40.8 million, or 6%, in fiscal 2011 compared to fiscal 2010. These increases were due to an increase in the aggregate contract value of the installed base under SEM contracts, which is recognized as revenue
ratably over the terms of the underlying contracts.

[0001193125-12-275547:mdna:107]
Service Revenues (in millions, except percentages):

[0001193125-12-275547:mdna:108]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Service revenues |  | $ | 1,211.3 |  |  | $ | 1,034.9 |  |  |  | 17 | % |  | $ | 870.5 |  |  |  | 19 | % |

[0001193125-12-275547:mdna:109]
52

[0001193125-12-275547:mdna:110]
Service revenues include hardware maintenance, professional services and educational and
training services. Service revenues increased by $176.4 million, or 17%, in fiscal 2012, compared to fiscal 2011 and by $164.4 million, or 19%, in fiscal 2011, compared to fiscal 2010.

[0001193125-12-275547:mdna:111]
Hardware maintenance contract revenues constituted approximately 70%, 66% and 64%, of our service revenues in fiscal 2012, 2011 and 2010,
respectively. Such revenues increased $166.5 million, or 24% in fiscal 2012 compared to fiscal 2011 and increased $128.9 million, or 23% in fiscal 2011 compared to fiscal 2010. The increases in each year are a result of increases in the installed
base under service contracts. Professional services and educational and training services constituted approximately 30%, 34% and 36% of our service revenues in fiscal 2012, 2011 and 2010, respectively.

[0001193125-12-275547:mdna:112]
Revenues by Geographic Area (in millions, except percentages):

[0001193125-12-275547:mdna:113]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Americas (United States, Canada and Latin America) |  | $ | 3,529.7 |  |  | $ | 2,899.0 |  |  |  | 22 | % |  | $ | 2,208.1 |  |  |  | 31 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 1,936.5 |  |  |  | 1,719.1 |  |  |  | 13 | % |  |  | 1,329.1 |  |  |  | 29 | % |
| Asia Pacific and Japan (APAC) |  |  | 767.0 |  |  |  | 504.5 |  |  |  | 52 | % |  |  | 394.2 |  |  |  | 28 | % |
| Net revenues |  | $ | 6,233.2 |  |  | $ | 5,122.6 |  |  |  |  |  |  | $ | 3,931.4 |  |  |  |  |  |

[0001193125-12-275547:mdna:114]
Americas revenues consist of Americas commercial and U.S. public sector markets. Sales to customers
inside the United States comprised 86%, 89% and 89% of America’s net revenues in fiscal 2012, 2011 and 2010, respectively. Sales to Germany accounted for 10%, 12% and 11% of net revenues in fiscal 2012, 2011 and 2010, respectively. No other
single foreign country accounted for 10% or more of net revenues in any of the periods presented.

[0001193125-12-275547:mdna:115]
Cost of Revenues

[0001193125-12-275547:mdna:116]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of
manufacturing and shipping of our storage products, amortization of purchased intangible assets, inventory write-downs, and warranty costs, (2) cost of SEM, which includes the costs of providing SEM and third-party royalty costs and
(3) cost of service revenues, which reflects costs associated with providing support activities for hardware, global support partnership programs, professional services and educational and training services.

[0001193125-12-275547:mdna:117]
Our gross profit is impacted by a variety of factors, including pricing changes, discounting practices, foreign currency, product
configuration, unit volumes, customer mix, revenue mix, natural disasters and product material costs. Service gross profit is typically impacted by factors such as changes in the size of our installed base of products, as well as the timing of
support service initiations and renewals, and incremental investments in our customer support infrastructure. If any of these factors that impact our gross profit are adversely affected, whether by economic uncertainties or for other reasons, our
gross profit could decline.

[0001193125-12-275547:mdna:118]
Cost of Product Revenues (in millions, except percentages):

[0001193125-12-275547:mdna:119]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Cost of product revenues |  | $ | 1,979.9 |  |  | $ | 1,342.0 |  |  |  | 48 | % |  | $ | 976.4 |  |  |  | 37 | % |

[0001193125-12-275547:mdna:120]
Cost of product revenues increased by $637.9 million, or 48% in fiscal 2012 compared to 2011
and by $365.6 million, or 37%, in fiscal 2011 compared to fiscal 2010. The changes were comprised of the following elements (in percentage points of the total change):

[0001193125-12-275547:mdna:121]
|  |  | Year EndedFiscal 2012 toFiscal 2011PercentageChangePoints |  |  | Year EndedFiscal 2011 toFiscal 2010PercentageChangePoints |  |
| Materials costs |  |  | 37 |  |  |  | 34 |  |
| Amortization expense |  |  | 3 |  |  |  | — |  |
| Excess and obsolete inventory |  |  | 1 |  |  |  | — |  |
| Warranty |  |  | 3 |  |  |  | 1 |  |
| Manufacturing overhead |  |  | 2 |  |  |  | 1 |  |
| Other |  |  | 2 |  |  |  | 1 |  |
| Total change |  |  | 48 |  |  |  | 37 |  |

[0001193125-12-275547:mdna:122]
Material costs increased $503.0 million in fiscal 2012 compared to fiscal 2011, primarily as a result of
a $368.6 million in materials cost relating to the sales of E-Series OEM products. Materials costs increased on configured products due to a 6% volume increase, partially offset by average unit materials cost reductions. In addition, cost of product
revenues in fiscal 2012 also included an increase in the amortization expense of $42.5 million related to the amortization of developed technology identified intangible assets related to the Engenio acquisition, a $36.1 million increase in warranty
expense, primarily due to E-Series OEM products, and a $29.9 million increase in manufacturing overhead.

[0001193125-12-275547:mdna:123]
Material costs
increased $222.7 million during fiscal 2011 compared to fiscal 2010, primarily as a result of a 46% unit volume increase in configured systems, a $127.1 million increase in costs of hardware add-ons and other product costs and a $31.8 million
increase in costs resulting from the adoption of the new accounting standard in fiscal 2011. The average cost per unit of configured systems did not change significantly in fiscal 2011 compared to fiscal 2010. In addition, cost of product revenues
increased in fiscal 2011 as a result of a $15.8 million increase in warranty expense.

[0001193125-12-275547:mdna:124]
Cost of product revenues represented
47% of product revenue for fiscal 2012 compared to 40% for fiscal 2011 and 41% for fiscal 2010. The overall increase in costs as a percentage of revenues for fiscal 2012, as compared to fiscal 2011, was primarily the result of E-Series OEM products,
which have lower material margins than configured systems and add-on products as well as lower materials margins on configured systems. The overall decrease in costs as a percentage of revenues for fiscal 2011, as compared to fiscal 2010 was
primarily the result of decreases in materials cost per unit.

[0001193125-12-275547:mdna:125]
Cost of Software Entitlements and Maintenance Revenues
(in millions, except percentages):

[0001193125-12-275547:mdna:126]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Cost of software entitlements and maintenance revenues |  | $ | 23.9 |  |  | $ | 15.7 |  |  |  | 52 | % |  | $ | 12.3 |  |  |  | 28 | % |

[0001193125-12-275547:mdna:127]
Cost of SEM revenues increased by $8.2 million, or 52% in fiscal 2012 compared to fiscal 2011 and by $3.4
million, or 28% in fiscal 2011 compared to fiscal 2010 primarily due to an increase in volume-related software support costs. Cost of SEM revenues represented 3% of SEM revenues in fiscal 2012 and 2% of SEM revenues for both fiscal 2011 and fiscal
2010.

[0001193125-12-275547:mdna:128]
Cost of Service Revenues (in millions, except percentages):

[0001193125-12-275547:mdna:129]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Cost of service revenues |  | $ | 516.0 |  |  | $ | 436.2 |  |  |  | 18 | % |  | $ | 423.5 |  |  |  | 3 | % |

[0001193125-12-275547:mdna:130]
Cost of service revenues increased $79.8 million, or 18%, in fiscal 2012 compared to fiscal 2011 and
increased $12.7 million, or 3%, in fiscal 2011 compared to fiscal 2010, primarily due to the costs associated with servicing a larger installed base and an increase in logistics and materials costs. Costs represented 43%, 42% and 49% of service
revenues in fiscal 2012, 2011 and 2010, respectively. The decrease in cost of service revenues as a percentage of service revenue in fiscal 2011 compared to fiscal 2010 was primarily due to improved productivity.

[0001193125-12-275547:mdna:131]
Operating Expenses

[0001193125-12-275547:mdna:132]
Sales and Marketing, Research and Development, and General and Administrative Expenses

[0001193125-12-275547:mdna:133]
Compensation costs comprise the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation costs and
employee incentive compensation plan costs. Compensation costs included in operating expenses increased approximately $273.6 million, or 21%, during fiscal 2012 compared to fiscal 2011, primarily due to:

[0001193125-12-275547:mdna:134]
(i) an increase in salaries, benefits and other compensation-related costs of $273.1 million due to an increase in average headcount,
which included the impact of the Engenio acquisition;

[0001193125-12-275547:mdna:135]
(ii) an increase in stock-based compensation of $77.2 million, which
includes $10.9 million of expense related to the reset of the employee stock purchase plan (ESPP) offering triggered by the decline in our stock price below the grant date prices of the offerings that vested in December 2011;

[0001193125-12-275547:mdna:136]
(iii) partially offset by a decrease in incentive compensation expense of $76.6 million due to lower performance against plan operating
targets in fiscal 2012.

[0001193125-12-275547:mdna:137]
In addition, despite the increase in revenues, sales and marketing expenses reflected a decrease in
commissions expense of $12.2 million during fiscal 2012 due to lower individual attainment and commission rates.

[0001193125-12-275547:mdna:138]
Compensation
costs included in operating expenses increased approximately $202.3 million, or 18%, during fiscal 2011 compared to fiscal 2010, primarily due to:

[0001193125-12-275547:mdna:139]
(i) an increase in salaries, benefits and other compensation-related costs of $169.9 million due to an increase in average headcount, primarily in sales, marketing and engineering functions;

[0001193125-12-275547:mdna:140]
(ii) an increase in incentive compensation expense of $16.7 million reflecting stronger operating performance and increased headcount;
and

[0001193125-12-275547:mdna:141]
(iii) an increase in stock-based compensation of $15.7 million.

[0001193125-12-275547:mdna:142]
In addition, sales and marketing expenses reflected an increase in commissions expense of $30.2 million during fiscal 2011,
reflecting stronger sales performance compared to fiscal 2010.

[0001193125-12-275547:mdna:143]
Sales and Marketing (in millions, except percentages):

[0001193125-12-275547:mdna:144]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 1,864.0 |  |  | $ | 1,597.0 |  |  |  | 17 | % |  | $ | 1,293.7 |  |  |  | 23 | % |

[0001193125-12-275547:mdna:145]
Sales and marketing expense consists primarily of compensation costs, commissions, outside services,
allocated facilities and IT costs, advertising and marketing promotional expense, and travel and entertainment expense. Sales and marketing expenses increased due to the following:

[0001193125-12-275547:mdna:146]
|  |  | Year EndedFiscal 2012 toFiscal 2011PercentageChangePoints |  |  | Year EndedFiscal 2011 toFiscal 2010PercentageChangePoints |  |
| Salaries |  |  | 8 |  |  |  | 6 |  |
| Incentive plan compensation |  |  | (2 | ) |  |  | 1 |  |
| Stock-based compensation |  |  | 3 |  |  |  | 1 |  |
| Other compensation and benefit costs |  |  | 2 |  |  |  | 3 |  |
| Total compensation costs |  |  | 11 |  |  |  | 11 |  |
| Commissions |  |  | (1 | ) |  |  | 2 |  |
| Amortization expense |  |  | 2 |  |  |  | — |  |
| Advertising and marketing promotional expense |  |  | 1 |  |  |  | 1 |  |
| Outside services |  |  | 1 |  |  |  | 5 |  |
| Facilities and IT support costs |  |  | 2 |  |  |  | 2 |  |
| Travel and entertainment expense |  |  | — |  |  |  | 1 |  |
| Other |  |  | 1 |  |  |  | 1 |  |
| Total change |  |  | 17 |  |  |  | 23 |  |

[0001193125-12-275547:mdna:147]
The increase in total compensation costs in fiscal 2012 reflects a 20% increase in average sales and
marketing headcount compared to fiscal 2011. This increase was partially offset by a decrease in incentive compensation expense. Amortization expense in fiscal 2012 increased due to the addition of intangible assets as a result of the Engenio
acquisition. The increase in facilities and IT support costs in fiscal 2012 reflects our investment in sales systems and infrastructure.

[0001193125-12-275547:mdna:148]
The increase in total compensation costs in fiscal 2011 reflects a 20% increase in average sales and marketing headcount compared to fiscal 2010. Outside services increased in fiscal 2011 compared to
fiscal 2010 primarily to support sales and marketing initiatives. The increase in facilities and IT support costs in fiscal 2011 reflects our investment in sales systems and infrastructure.

[0001193125-12-275547:mdna:149]
56

[0001193125-12-275547:mdna:150]
Research and Development (in millions, except percentages):

[0001193125-12-275547:mdna:151]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Research and development expenses |  | $ | 828.2 |  |  | $ | 648.6 |  |  |  | 28 | % |  | $ | 535.7 |  |  |  | 21 | % |

[0001193125-12-275547:mdna:152]
Research and development expense consists primarily of compensation costs, allocated facilities and IT
costs, depreciation and amortization, equipment and software related costs, prototypes, non-recurring engineering (NRE) charges and other outside services costs. Research and development expenses increased due to the following:

[0001193125-12-275547:mdna:153]
|  |  | Year EndedFiscal 2012 toFiscal 2011PercentageChangePoints |  |  | Year EndedFiscal 2011 toFiscal 2010PercentageChangePoints |  |
| Salaries |  |  | 12 |  |  |  | 8 |  |
| Incentive plan compensation |  |  | (4 | ) |  |  | 1 |  |
| Stock-based compensation |  |  | 5 |  |  |  | 1 |  |
| Other compensation and benefit costs |  |  | 4 |  |  |  | 2 |  |
| Total compensation costs |  |  | 17 |  |  |  | 12 |  |
| Facilities and IT support costs |  |  | 5 |  |  |  | 4 |  |
| Depreciation and amortization expense |  |  | 3 |  |  |  | 1 |  |
| NRE charges |  |  | 1 |  |  |  | (1 | ) |
| Outside services |  |  | 1 |  |  |  | 1 |  |
| Travel and entertainment expense |  |  | — |  |  |  | 1 |  |
| Equipment and software related costs |  |  | — |  |  |  | 1 |  |
| Other |  |  | 1 |  |  |  | 2 |  |
| Total change |  |  | 28 |  |  |  | 21 |  |

[0001193125-12-275547:mdna:154]
The increase in total compensation costs in fiscal 2012 reflects a 36% increase in average engineering
headcount. This increase was partially offset by a decrease in incentive compensation expense. The increase in facilities and IT support costs in fiscal 2012 reflects the Engenio acquisition. Depreciation and amortization expense in fiscal 2012
increased due to higher levels of investment in engineering equipment. The increase in total compensation costs in fiscal 2011 reflects a 28% increase in average engineering headcount.

[0001193125-12-275547:mdna:155]
We believe that our future performance will depend in large part on our ability to maintain and enhance our current product line, develop
new products that achieve market acceptance, maintain technological competitiveness and meet an expanding range of customer requirements. We expect to continue to spend on current and future product development efforts, broaden our existing product
offerings and introduce new products that expand our solutions portfolio.

[0001193125-12-275547:mdna:156]
General and Administrative (in millions, except percentages):

[0001193125-12-275547:mdna:157]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| General and administrative expenses |  | $ | 264.9 |  |  | $ | 251.3 |  |  |  | 5 | % |  | $ | 238.8 |  |  |  | 5 | % |

[0001193125-12-275547:mdna:158]
General and administrative expense consists primarily of compensation costs, professional and corporate
legal fees, outside services and allocated facilities and IT support costs. General and administrative expenses increased due to the following:

[0001193125-12-275547:mdna:159]
|  |  | Year EndedFiscal 2012 toFiscal 2011PercentageChangePoints |  |  | Year EndedFiscal 2011 toFiscal 2010PercentageChangePoints |  |
| Salaries |  |  | 4 |  |  |  | 3 |  |
| Incentive plan compensation |  |  | (7 | ) |  |  | 1 |  |
| Stock-based compensation |  |  | 1 |  |  |  | 1 |  |
| Other compensation and benefit costs |  |  | — |  |  |  | (1 | ) |
| Total compensation costs |  |  | (2 | ) |  |  | 4 |  |
| Outside services |  |  | 2 |  |  |  | 3 |  |
| Professional and corporate legal fees |  |  | 3 |  |  |  | (5 | ) |
| IT support costs |  |  | 1 |  |  |  | 1 |  |
| Other |  |  | 1 |  |  |  | 2 |  |
| Total change |  |  | 5 |  |  |  | 5 |  |

[0001193125-12-275547:mdna:160]
The decrease in total compensation costs in fiscal 2012 was driven by a decrease in incentive plan
compensation expense. This decrease was partially offset by the impact of a 13% increase in average general and administrative headcount during fiscal 2012. Professional and corporate legal fees were higher in fiscal 2012 as a result of a legal fee
settlement during fiscal 2011 associated with the resolution of the Sun Microsystems litigation. The increase in outside services in fiscal 2012 reflects additional spending on contractors and costs associated with the Engenio integration activities
and various on-going operational projects.

[0001193125-12-275547:mdna:161]
The increase in total compensation costs in fiscal 2011 reflects a 10% increase in
average general and administrative headcount. The increase in outside services in fiscal 2011 reflects additional spending on contractors. Partially offsetting this increase was a decrease in professional and corporate legal fees as a result of a
legal fee settlement during fiscal 2011 associated with the resolution of the Sun Microsystems litigation.

[0001193125-12-275547:mdna:162]
Restructuring
and Other Charges:

[0001193125-12-275547:mdna:163]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Restructuring and other charges |  | $ | — |  |  | $ | 1.8 |  |  |  | NM |  |  | $ | 2.5 |  |  |  | (28 | )% |

[0001193125-12-275547:mdna:164]
NM — Not meaningful.

[0001193125-12-275547:mdna:165]
In fiscal 2011, we recorded severance-related restructuring charges of $2.4 million relating to the acquisition of Akorri Networks, Inc.
(Akorri), partially offset by a reversal of $0.6 million related to certain of our restructuring plans.

[0001193125-12-275547:mdna:166]
In fiscal 2010, we
incurred $2.5 million of charges primarily from facilities and severance-related activities in certain of our restructuring plans.

[0001193125-12-275547:mdna:167]
Acquisition-related Expense (Income), Net (in millions, except percentages):

[0001193125-12-275547:mdna:168]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Acquisition-related expense (income), net |  | $ | 9.8 |  |  | $ | 5.7 |  |  |  | 72 | % |  | $ | (39.9 | ) |  |  | NM |  |

[0001193125-12-275547:mdna:169]
NM — Not meaningful.

[0001193125-12-275547:mdna:170]
During fiscal 2012, we incurred $9.8 million of due diligence, legal and other integration charges associated with our acquisition of
Engenio. During fiscal 2011, we incurred $5.7 million of due diligence, legal and other integration charges associated with our acquisitions of Bycast Inc. (Bycast), Akorri and Engenio.

[0001193125-12-275547:mdna:171]
On May 20, 2009, we announced that we had entered into a merger agreement with Data Domain, Inc. (Data Domain) under which we would
acquire Data Domain in a stock and cash transaction. On July 8, 2009, Data Domain’s Board of Directors terminated the merger agreement and pursuant to the terms of the agreement, Data Domain paid us a $57.0 million termination fee. We
incurred $15.9 million of incremental third-party costs relating to the terminated merger transaction during the same period, resulting in net proceeds of $41.1 million recorded in the consolidated statement of operations during fiscal
2010. In addition, during fiscal 2010, we paid $1.2 million of acquisition-related expenses related to the acquisition of Bycast.

[0001193125-12-275547:mdna:172]
Other Expense, Net

[0001193125-12-275547:mdna:173]
Interest Income (in millions, except
percentages):

[0001193125-12-275547:mdna:174]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Interest income |  | $ | 38.2 |  |  | $ | 39.9 |  |  |  | (4 | )% |  | $ | 31.2 |  |  |  | 28 | % |

[0001193125-12-275547:mdna:175]
The decrease in interest income for fiscal 2012 compared to fiscal 2011 was primarily due to lower yields
on new investments. The increase in interest income for fiscal 2011 compared to fiscal 2010 was primarily due to higher levels of cash equivalent and investment balances in fiscal 2011.

[0001193125-12-275547:mdna:176]
Interest Expense (in millions, except percentages):

[0001193125-12-275547:mdna:177]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Interest expense |  | $ | (74.7 | ) |  | $ | (75.9 | ) |  |  | (2 | )% |  | $ | (74.1 | ) |  |  | 2 | % |

[0001193125-12-275547:mdna:178]
Interest expense was relatively flat for fiscal 2012 compared to fiscal 2011 and for fiscal 2011 compared
to fiscal 2010.

[0001193125-12-275547:mdna:179]
During fiscal 2012, 2011 and 2010, we recognized incremental non-cash interest expense from the amortization
of debt discount and issuance costs relating to our Notes, net of capitalized interest, of $52.9 million, $53.1 million and $50.8 million, respectively. The coupon interest expense related to the Notes, net of capitalized interest,
was $20.6 million, $22.1 million and $22.5 million for fiscal 2012, 2011 and 2010, respectively. During fiscal 2012, we capitalized interest of $5.0 million on facility assets under construction and on significant software development projects. We
did not capitalize interest in either fiscal 2011 or fiscal 2010.

[0001193125-12-275547:mdna:180]
Other Income, net (in millions, except percentages):

[0001193125-12-275547:mdna:181]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Other income, net |  | $ | 2.4 |  |  | $ | 5.8 |  |  |  | (59 | )% |  | $ | 1.5 |  |  |  | 287 | % |

[0001193125-12-275547:mdna:182]
The decrease in other income, net was due to lower gains on investments in fiscal 2012 compared to fiscal
2011 and higher gains on investments in fiscal 2011 compared to fiscal 2010.

[0001193125-12-275547:mdna:183]
Provision for Income Taxes (in millions,
except percentages):

[0001193125-12-275547:mdna:184]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | % Change |  |  | April 30, 2010 |  |  | % Change |  |
| Provision for income taxes |  | $ | 107.0 |  |  | $ | 121.0 |  |  |  | (12 | )% |  | $ | 46.6 |  |  |  | 160 | % |

[0001193125-12-275547:mdna:185]
Our effective tax rate for fiscal 2012 was 15.0% compared to an effective tax rate of 15.2% for fiscal
2011, and an effective tax rate of 10.4% for fiscal 2010. Our effective tax rate reflects our corporate legal entity structure and the global nature of our business with a significant amount of our profits generated and taxed in foreign
jurisdictions at rates below the U.S. statutory tax rate. The effective tax rates for fiscal 2010 through fiscal 2012 were favorably impacted by the geographic mix of profits.

[0001193125-12-275547:mdna:186]
The effective tax rate of 15.0% in fiscal 2012 included a benefit of $162.2 million, or 22.8 percentage points, from foreign profits
taxed at effective tax rates lower than the U.S. federal statutory rate of 35%. Other key components of our effective tax rate for the year include a benefit of $10.9 million, or 1.5 percentage points, related to research and development credits, an
expense of $14.4 million, or 2.0 percentage points, attributable to stock-based compensation, an expense of $6.4 million, or 0.9 percentage points, on state tax expense and an expense of $7.3 million, or 1.0 percentage point, in connection with
income tax audits.

[0001193125-12-275547:mdna:187]
The effective tax rate of 15.2% in fiscal 2011 included a benefit of $146.9 million, or
18.5 percentage points, related to foreign income tax rates that are lower than the U.S. federal statutory rate of 35%. Other key components of our effective tax rate for the year include a benefit of $17.8 million, or 2.2 percentage
points, related to research and development tax credits, a benefit of $1.3 million, or 0.2 percentage points, related to stock-based compensation and an IRS audit settlement benefit of $21.1 million, or 2.7 percentage points, partially
offset by the unfavorable impact of $31.1 million, or 3.9 percentage points, related to state income taxes.

[0001193125-12-275547:mdna:188]
The
effective tax rate of 10.4% in fiscal 2010 included a benefit of $105.2 million, or 23.5 percentage points, related to foreign income tax rates that are lower than the U.S. federal statutory rate of 35%. Other key components of our
effective tax rate for the year include a benefit of $7.8 million, or 1.7 percentage points, related to research and development tax credits, a benefit of $2.6 million, or 0.6 percentages points, related to stock-based
compensation, partially offset by the unfavorable impact of $2.6 million, or 0.6 percentage points, related to state income taxes.

[0001193125-12-275547:mdna:189]
On March 26, 2012, we received a Revenue Agent’s Report from the IRS for our fiscal 2005 through 2007 tax returns. On April 25, 2012, we filed a protest related to transfer pricing matters
comparable to the one that was resolved in our favor in our last audit cycle. Our fiscal 2008 through 2010 returns are currently under audit by the IRS.

[0001193125-12-275547:mdna:190]
On September 17, 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 from our Danish subsidiary were subject to Danish at-source dividend
withholding tax. We do not believe that our Danish subsidiary is liable for withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. On December 19, 2011, the Danish Tax Tribunal issued a ruling that our Danish

[0001193125-12-275547:mdna:191]
subsidiary was not liable for Danish withholding tax. The Danish tax examination agency appealed the ruling to the Danish High Court in March 2012.

[0001193125-12-275547:mdna:192]
We continue to monitor the progress of ongoing tax controversies and the impact, if any, of the expected tolling of the statute of
limitations in various taxing jurisdictions.

[0001193125-12-275547:mdna:193]
Liquidity and Capital Resources

[0001193125-12-275547:mdna:194]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash flows on our liquidity and
capital resources. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to
maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash
equivalents or investments from the values reported as of April 27, 2012.

[0001193125-12-275547:mdna:195]
Liquidity Sources and Cash Requirements

[0001193125-12-275547:mdna:196]
Our principal sources of liquidity as of April 27, 2012 consisted of approximately $5.4 billion in cash,
cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001193125-12-275547:mdna:197]
Cash, cash equivalents
and short-term investments consist of the following (in millions):

[0001193125-12-275547:mdna:198]
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Cash and cash equivalents |  | $ | 1,549.8 |  |  | $ | 2,757.3 |  |
| Short-term investments |  |  | 3,848.7 |  |  |  | 2,417.4 |  |
| Total |  | $ | 5,398.5 |  |  | $ | 5,174.7 |  |

[0001193125-12-275547:mdna:199]
As of April 27, 2012, $2.7 billion of cash, cash equivalents and short-term investments were held in
the United States, while $2.7 billion were held in foreign countries. Most of the amounts held outside the United States can be repatriated to the United States but, under current law, would be subject to U.S. federal and state income taxes. If we
were to repatriate foreign earnings for cash requirements in the United States, we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state net operating loss and tax credit carry forwards. However,
our intent is to keep these funds permanently reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working
capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies, and service our debt and synthetic leases. Our contractual obligations as of
April 27, 2012 are summarized below in the Contractual Obligations table.

[0001193125-12-275547:mdna:200]
Key factors that could affect our cash flows
include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable and inventories, our ability to effectively integrate acquired products, businesses and technologies and
conversions of our Notes by holders. Based on our current business outlook, we believe that our sources of cash will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, contractual obligations,
commitments, interest payments on our Notes and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to
curtail spending and implement additional cost saving measures and restructuring actions. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if
necessary, on satisfactory terms, if at all.

[0001193125-12-275547:mdna:201]
Our investment portfolio, including auction rate securities, has been and will
continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and

[0001193125-12-275547:mdna:202]
market events to minimize our market risk on our investment portfolio. Based on our ability to access our cash and short-term investments, our expected operating cash flows, and our other
potential sources of cash, we do not anticipate that the lack of liquidity of these investments will impact our ability to fund working capital needs, capital expenditures, acquisitions or other cash requirements. We intend to and believe that we
have the ability to hold these investments until the market recovers. If current market conditions deteriorate, we may be required to record additional charges to earnings in future periods. We routinely monitor our financial exposure to both
sovereign and non-sovereign borrowers and counterparties. Our gross exposures to our investments in Greece, Italy, Portugal, and Spain are individually and collectively not material.

[0001193125-12-275547:mdna:203]
Capital Expenditure Requirements

[0001193125-12-275547:mdna:204]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through
existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes
in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We expect that our existing facilities and those being developed in Sunnyvale, California; Research Triangle Park,
North Carolina; and other locations worldwide are adequate for our requirements over at least the next two years and that additional space will be available as needed. Our capital expenditures were $407.1 million during fiscal 2012. We anticipate
capital expenditures for fiscal 2013 to be between $250.0 million and $300.0 million.

[0001193125-12-275547:mdna:205]
Cash Flows

[0001193125-12-275547:mdna:206]
As of April 27, 2012, our cash, cash equivalents and short-term and long-term investments increased by $208.9 million from
April 29, 2011, to $5.5 billion. The increase was primarily a result of $1.5 billion of cash provided by operating activities and $142.1 million from issuances of common stock related to employee stock option exercises and purchases under
the ESPP, partially offset by $600.0 million in cash paid for the repurchase of common stock, $480.0 million, net cash paid in connection with the acquisition of Engenio and $407.1 million in capital expenditures. We derive our liquidity and capital
resources primarily from our operating cash flows and from working capital. Accounts receivable days sales outstanding as of April 27, 2012 decreased to 44 days, compared to 47 days as of April 29, 2011, primarily due to higher
collections. Working capital increased by $314.3 million to $3.3 billion as of April 27, 2012, primarily due to a net increase in cash, cash equivalents and short-term investments of $223.8 million and accounts receivable of
$88.3 million and a decrease in accrued compensation and related benefits of $96.9 million, partially offset by an increase in short-term deferred revenue of $139.9 million.

[0001193125-12-275547:mdna:207]
Cash Flows from Operating Activities

[0001193125-12-275547:mdna:208]
During fiscal 2012 and 2011, we generated cash from operating activities of $1.5 billion and $1.3 billion, respectively. The primary sources of cash from operating activities in fiscal 2012 consisted
of net income of $605.4 million, adjusted by depreciation and amortization of $293.1 million, stock-based compensation of $257.6 million and deferred income taxes of $60.9 million. Significant changes in assets and liabilities impacting
operating cash flows in fiscal 2012 included an increase in deferred revenue of $506.4 million and a decrease in accounts receivable of $90.4 million. The primary sources of cash from operating activities in fiscal 2011 consisted of net income of
$673.1 million, adjusted by stock-based compensation of $175.2 million and depreciation and amortization of $165.6 million. Significant changes in assets and liabilities impacting operating cash flows in fiscal 2011 included an
increase in accounts receivable of $262.7 million, an increase in deferred revenue of $382.9 million and an increase in accrued compensation and other current liabilities of $118.8 million.

[0001193125-12-275547:mdna:209]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including
fluctuations in our operating results, shipment linearity, accounts receivable collections

[0001193125-12-275547:mdna:210]
performance, inventory and supply chain management, tax benefits from stock-based compensation, and the timing and amount of compensation and other payments.

[0001193125-12-275547:mdna:211]
Cash Flows from Investing Activities

[0001193125-12-275547:mdna:212]
During fiscal 2012, we completed our acquisition of Engenio for a total net cash payment of $480.0 million, paid $1.4 billion, net for investments and purchased $407.1 million of capital expenditures,
including $44.3 million of buildings and land associated with the buyout of one of our synthetic leases. During fiscal 2011, we purchased $222.7 million of capital expenditures, paid $418.5 million, net for investments and made net cash payments of
$136.5 million for acquisitions.

[0001193125-12-275547:mdna:213]
Cash Flows from Financing Activities

[0001193125-12-275547:mdna:214]
During fiscal 2012, we used $343.6 million in financing activities, which primarily consisted of $600.0 million for the repurchase of
common stock, partially offset by $113.3 million of excess tax benefit from stock-based compensation and $142.1 million of proceeds from employee equity award plans, net of shares withheld for taxes. During fiscal 2011, we generated $450.9 million
from financing activities, which primarily consisted of $324.2 million of proceeds from employee equity award plans, net of shares withheld for taxes and $127.7 million of excess tax benefit from stock-based compensation.

[0001193125-12-275547:mdna:215]
Net proceeds from the issuance of common stock related to employee participation in employee equity award programs have historically been
a significant component of our liquidity. The extent to which our employees exercise stock options generally increases or decreases based upon changes in the market price of our common stock. As a result, our cash flow resulting from the issuance of
common stock in connection with these programs and related tax benefits will vary.

[0001193125-12-275547:mdna:216]
Stock Repurchase Program

[0001193125-12-275547:mdna:217]
Since the May 13, 2003 inception of our stock repurchase program through April 27, 2012, we have repurchased
a total of 119.0 million shares of our common stock at an average price of $29.65 per share, for an aggregate purchase price of $3.5 billion. As of April 27, 2012, our Board of Directors had authorized the repurchase of up to $4.0 billion
of our common stock under this stock repurchase program. As of April 27, 2012, the remaining authorized amount for stock repurchases under this program was $0.5 billion with no termination date. The stock repurchase program may be suspended or
discontinued at any time.

[0001193125-12-275547:mdna:218]
Convertible Notes

[0001193125-12-275547:mdna:219]
As of April 27, 2012, we had $1.265 billion principal amount of 1.75% Convertible Senior Notes due 2013 (See Note 10
of the accompanying consolidated financial statements). The Notes will mature on June 1, 2013, unless earlier repurchased or converted. Our common stock price exceeded the conversion threshold for the Notes for at least 20 trading days during
the 30 consecutive trading days ended March 31, 2012. Accordingly, as of April 27, 2012, the Notes were convertible at the option of the holder and, therefore, the carrying value of the Notes was classified as short-term debt. Since the
Notes were convertible at the option of the holder and the principal amount would have been required to be paid in cash, the difference between the principal amount and the carrying value of the Notes was reflected as convertible debt in mezzanine
on our consolidated balance sheet as of April 27, 2012.

[0001193125-12-275547:mdna:220]
Contractual Obligations

[0001193125-12-275547:mdna:221]
The following summarizes our contractual obligations at April 27, 2012 and the effect such obligations are expected to have on our
liquidity and cash flows in future periods (in millions):

[0001193125-12-275547:mdna:222]
|  |  | 2013 |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | Thereafter |  |  | Total |  |
| Off-balance sheet commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Office operating lease payments |  | $ | 36.7 |  |  | $ | 39.5 |  |  | $ | 39.7 |  |  | $ | 32.9 |  |  | $ | 18.7 |  |  | $ | 53.8 |  |  | $ | 221.3 |  |
| Real estate lease payments(1) |  |  | 60.8 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 60.8 |  |
| Less: sublease income |  |  | (1.6 | ) |  |  | (0.4 | ) |  |  | (0.5 | ) |  |  | (0.4 | ) |  |  | — |  |  |  | — |  |  |  | (2.9 | ) |
| Equipment operating lease payments |  |  | 24.3 |  |  |  | 17.2 |  |  |  | 7.7 |  |  |  | 2.8 |  |  |  | 0.6 |  |  |  | — |  |  |  | 52.6 |  |
| Purchase commitments with contract manufacturers(2) |  |  | 248.7 |  |  |  | 1.2 |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 250.1 |  |
| Capital expenditures |  |  | 22.1 |  |  |  | 23.9 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 46.0 |  |
| Other purchase obligations(3) |  |  | 103.1 |  |  |  | 27.9 |  |  |  | 17.0 |  |  |  | 10.1 |  |  |  | 5.4 |  |  |  | — |  |  |  | 163.5 |  |
| Total off balance-sheet commitments |  |  | 494.1 |  |  |  | 109.3 |  |  |  | 64.1 |  |  |  | 45.4 |  |  |  | 24.7 |  |  |  | 53.8 |  |  |  | 791.4 |  |
| 1.75% Convertible Notes(4) |  |  | 1,298.1 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,298.1 |  |
| Long-term financing arrangements |  |  | 10.9 |  |  |  | 4.7 |  |  |  | 2.1 |  |  |  | 1.6 |  |  |  | 0.8 |  |  |  | — |  |  |  | 20.1 |  |
| Uncertain tax positions(5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 107.6 |  |
| Total |  | $ | 1,803.1 |  |  | $ | 114.0 |  |  | $ | 66.2 |  |  | $ | 47.0 |  |  | $ | 25.5 |  |  | $ | 53.8 |  |  | $ | 2,217.2 |  |
| Other Commercial Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit |  | $ | 9.7 |  |  | $ | 0.1 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 1.8 |  |  | $ | 0.8 |  |  | $ | 13.1 |  |

[0001193125-12-275547:mdna:223]
| (1) | Included in real estate lease payments pursuant to three financing arrangements with BNP Paribas LLC (BNPPLC) are (i) lease commitments of $1.7 million, which are based on a fixed rate for terms of five years and (ii) at the expiration or termination of the leasing arrangements, a supplemental payment obligation equal to our minimum guarantee of $59.1 million in the event that we elect not to purchase or arrange for sale of the buildings. |

[0001193125-12-275547:mdna:224]
| (2) | Contract manufacturer commitments consist of obligations for on-hand inventories and non-cancelable purchase orders with our contract manufacturers. As of April 27, 2012, we recorded accruals of $3.3 million for firm, non-cancelable purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts, which is consistent with the valuation of our excess and obsolete inventory. |

[0001193125-12-275547:mdna:225]
| (3) | Purchase obligations represent an estimate of all open purchase orders and contractual obligations in the ordinary course of business, other than commitments with contract manufacturers and suppliers, for which we have not received the goods or services. Purchase obligations do not include contracts that may be cancelled without penalty. Although open purchase orders are considered enforceable and legally binding, the terms generally allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services. |

[0001193125-12-275547:mdna:226]
| (4) | Included in these amounts are obligations related to the $1.265 billion principal amount of 1.75% Notes due 2013 (see Note 10 of the accompanying consolidated financial statements). Estimated interest payments for the Notes are $33.2 million for fiscal 2013. |

[0001193125-12-275547:mdna:227]
| (5) | As of April 27, 2012, our liability for uncertain tax positions was $107.6 million, including interest and penalties, which due to the uncertainty of the timing of future payments, are presented in the total column on a separate line in this table. |

[0001193125-12-275547:mdna:228]
Some of the
amounts in the table above are based on management’s estimates and assumptions, including the commitment duration, the possibility of renewal or termination, anticipated actions by management and third parties and other factors. Because these
estimates and assumptions are subjective, our actual future obligations may vary from those reflected in the table. We expect to fund our contractual obligations and other commitments in the table above through existing cash, cash equivalents,
investments, and cash generated from operations or obtain additional financing, if necessary.

[0001193125-12-275547:mdna:229]
64

[0001193125-12-275547:mdna:230]
As of April 27, 2012, we have three leasing arrangements with BNPPLC, one of which
require us to lease certain of our land to BNPPLC for a period of 99 years and all of which require us to lease approximately 0.3 million square feet of office space from BNPPLC for our headquarters in Sunnyvale, California, which had an
original cost of $69.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments for each of the
leases for a term of five years. We have the option to renew each of the leases for two consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of the lease terms, we must elect one of the following
options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received from the
third-party and BNPPLC’s cost, up to 85% of cost (residual guarantee); or (iii) pay BNPPLC supplemental payments for an amount equal to the difference between BNPPLC’s cost and fair value, up to the residual guarantee, in which event
we may recoup some or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period. The following table summarizes the aggregate cost, the aggregate residual guarantee, the applicable fixed rates
at April 27, 2012 and the lease commencement dates for our leasing arrangements:

[0001193125-12-275547:mdna:231]
| Cost |  | Residual Guarantee |  | Fixed Rates |  | Lease Commencement Dates |  | Term |
| $ 69.6 million |  | $ 59.1 million |  | 3.67% - 3.69% |  | December 2007 - January 2008 |  | 5 years |

[0001193125-12-275547:mdna:232]
These leasing arrangements require us to maintain specified financial covenants with which we were in
compliance as of April 27, 2012. Such financial covenants include a maximum ratio of Total Debt to Earnings before Interest, Taxes, Depreciation and Amortization of less than 3:1 and a minimum amount of Unencumbered Cash and Short-Term
Investments of $300.0 million. Our failure to comply with these financial covenants could result in a default under the leases, which, subject to our right and ability to exercise our purchase option, would give BNPPLC the right to, among other
things, (i) terminate our possession of the leased property and require us to pay lease termination damages and other amounts as set forth in the lease agreements or (ii) exercise certain foreclosure remedies.

[0001193125-12-275547:mdna:233]
In April 2012, we exercised our option under one of our synthetic leasing arrangements to early terminate the lease and purchase the
facilities, including land and buildings, for $80.0 million. The early termination did not result in a material impact to our operating results.

[0001193125-12-275547:mdna:234]
Based on a recent announcement by BNPPLC that it intends to phase out of its synthetic lease activities, we expect to exercise our option to buy out our synthetic leases when their five year terms expire
in December 2012 through January 2013.

[0001193125-12-275547:mdna:235]
Legal Contingencies

[0001193125-12-275547:mdna:236]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters
in Note 17 to our consolidated financial statements.

[0001193125-12-275547:mdna:237]
Off-Balance Sheet Arrangements

[0001193125-12-275547:mdna:238]
During the ordinary course of business, we provide standby letters of credit or other guarantee instruments to third parties as required
for certain transactions initiated either by us or our subsidiaries. As of April 27, 2012, our financial guarantees of $13.1 million that were not recorded on our consolidated balance sheet consisted of standby letters of credit related to
workers’ compensation, a customs guarantee, a corporate credit card program, foreign rent guarantees and surety bonds, which were primarily related to self-insurance.

[0001193125-12-275547:mdna:239]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in
foreign

[0001193125-12-275547:mdna:240]
currency. The program is not designated for trading or speculative purposes. Currently, we do not enter into any foreign exchange forward contracts to hedge exposures related to firm commitments
or nonmarketable investments. Our major foreign currency exchange exposures and related hedging programs are described below:

[0001193125-12-275547:mdna:241]
|  | • |  | We utilize monthly foreign currency forward and options contracts to hedge exchange rate fluctuations related to certain foreign monetary assets and liabilities. |

[0001193125-12-275547:mdna:242]
|  | • |  | We use currency forward contracts to hedge exposures related to forecasted sales denominated in certain foreign currencies. These contracts are designated as cash flow hedges and in general closely match the underlying forecasted transactions in duration. |

[0001193125-12-275547:mdna:243]
As of April 27, 2012, the notional fair value of foreign exchange forward and foreign currency option contracts totaled $641.8 million. We do not believe that these derivatives present
significant credit risks, because of the short term maturity of the outstanding contracts at any point in time, the counterparties to the derivatives consist of major financial institutions, and we manage the notional amount of contracts entered
into with any one counterparty. Other than the risk associated with the financial condition of the counterparties, our maximum exposure related to foreign currency forward and option contracts is limited to the premiums paid. See Note 12 of the
accompanying consolidated financial statements for more information related to our hedging activities.

[0001193125-12-275547:mdna:244]
In the ordinary course
of business, some of our customers have entered into recourse and nonrecourse financing leasing arrangements using third-party leasing companies. Under the terms of recourse leases, which are generally three years or less, we remain liable for the
aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. Where we provide a guarantee for recourse leases, we defer revenues in accordance with revenue recognition policies. As of
April 27, 2012, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $169.0 million, and the related deferred revenue totaled approximately $149.9 million.

[0001193125-12-275547:mdna:245]
We enter into indemnification agreements with third parties in the ordinary course of business. Generally, these indemnification
agreements require us to reimburse losses suffered by the third-parties due to various events, such as lawsuits arising from patent or copyright infringement. These indemnification obligations are considered off-balance sheet arrangements under
accounting guidance.

[0001193125-12-275547:mdna:246]
We have commitments related to three leasing arrangements with BNPPLC for approximately 0.3 million
square feet of office space for our headquarters in Sunnyvale, California (as further described above under “Contractual Obligations”). Our future minimum lease payments and residual guarantees under these real estate leases will amount to
a total of $60.8 million as discussed above in “Contractual Obligations.”

[0001193125-12-275547:mdna:247]
66
