# NTAP 8-K — 0001102624-12-000459 filed 2012-05-23

## item codes, every 8-K on or before 2012-06-19

- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2012-06-19

- none on or before 2012-06-19

## item 2.02 — earnings release, exhibit 99.1

[0001102624-12-000459:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-12-000459:8k_2_02:2]
exh99_1.htm

[0001102624-12-000459:8k_2_02:3]
Exhibit 99.1

[0001102624-12-000459:8k_2_02:4]
|  | Press Contact: | Investor Contact: |
|  | Ryan Lowry | Shauna O’Boyle |
|  | NetApp | NetApp |
|  | (408) 822-7544 | (408) 822-7655 |
|  | ryanl@netapp.com | oboyle@netapp.com |

[0001102624-12-000459:8k_2_02:5]
NETAPP ANNOUNCES RESULTS FOR FOURTH QUARTER AND FISCAL YEAR 2012

[0001102624-12-000459:8k_2_02:6]
Company Reports Q4 FY’12 Revenues of $1.70 Billion; Fiscal Year Revenues of $6.23 Billion, Up 22% Year Over Year

[0001102624-12-000459:8k_2_02:7]
Sunnyvale, Calif.—May 23, 2012—NetApp (NASDAQ: NTAP) today reported results for the fourth quarter and fiscal year 2012, which ended April 27, 2012. Revenues for the fourth quarter of fiscal year 2012 totaled $1.70 billion, up 19% compared to revenues of $1.43 billion for the same period one year ago.

[0001102624-12-000459:8k_2_02:8]
For the fourth quarter of fiscal year 2012, GAAP net income was $181 million, or $0.47 per share1, compared to GAAP net income of $161 million, or $0.40 per share, for the same period a year ago. Non-GAAP net income for the fourth quarter of fiscal year 2012 was $252 million, or $0.66 per share2, compared to non-GAAP net income of $237 million, or $0.59 per share for the same period a year ago.

[0001102624-12-000459:8k_2_02:9]
Revenues for fiscal year 2012 totaled $6.23 billion, up 22% compared to revenues of $5.12 billion for fiscal year 2011. GAAP net income for fiscal year 2012 totaled $605 million, or $1.58 per share, compared to GAAP net income of $673 million, or $1.71 per share for fiscal year 2011. Non-GAAP net income for fiscal year 2012 totaled $926 million, or $2.41 per share, compared to non-GAAP net income of $866 million, or $2.20 per share for fiscal year 2011.

[0001102624-12-000459:8k_2_02:10]
“With a strong product offering and well established partner ecosystem, NetApp delivered our ninth consecutive quarter of over 20% year-over-year product revenue growth. Our ability to generate cash remains robust as the fourth quarter was our best ever quarter in terms of cash flow from operations,” said Tom Georgens, president and CEO. “As the innovation leader in the industry, and the only company offering a unified scale out platform, we are the clear choice for enterprises as they re-architect their data centers to provide agility while reducing complexity and cost.”

[0001102624-12-000459:8k_2_02:11]
Outlook

[0001102624-12-000459:8k_2_02:12]
NetApp’s outlook for the first quarter of fiscal year 2013 reflects the normal slower seasonality of the first quarter and increasing uncertainty in the broader macro environment.

[0001102624-12-000459:8k_2_02:13]
| ● | NetApp estimates revenue for the first quarter of fiscal year 2013 to be in the range of $1.40 billion to $1.50 billion, which equates to a sequential decline of approximately 12% to 18% and a year-over-year decline of approximately 4% to an increase of 3%. |

[0001102624-12-000459:8k_2_02:14]
| ● | NetApp estimates that first quarter fiscal year 2013 GAAP earnings per share will be approximately $0.10 to $0.15 per share. NetApp estimates that first quarter fiscal year 2013 non-GAAP earnings per share will be approximately $0.34 to $0.39 per share. |

[0001102624-12-000459:8k_2_02:15]
| ● | NetApp estimates that share count for the first quarter of fiscal year 2013 will decrease to approximately 380 million shares, including an estimated 7 million shares from the Company’s outstanding convertible notes.3 Share count does not include the Company’s outstanding note hedges which are expected to offset 80% of the dilution from the convertible notes at maturity or conversion. |

[0001102624-12-000459:8k_2_02:16]
Business Highlights

[0001102624-12-000459:8k_2_02:17]
In its fourth quarter of fiscal year 2012, NetApp innovation provided customers and partners with the storage foundation that is enabling them to capitalize on data to help grow their business. During the quarter, NetApp and Cisco built on the impressive momentum of the FlexPod® design architecture by unveiling new architectures to allow customers and partners to accelerate their transition to the cloud. Additionally, customers around the world continued to use NetApp® storage efficiency technologies to leverage existing investments, significantly reduce costs, and help support growth. Highlights during the quarter include the following:

[0001102624-12-000459:8k_2_02:18]
More Than 850 Customers Build on the NetApp and Cisco FlexPod Architecture to Leverage the Cloud

[0001102624-12-000459:8k_2_02:19]
| ● | NetApp and Cisco unveil new FlexPod architecture optimized for smaller workloads. New FlexPod design architectures priced and sized for smaller workloads with 500–1,000 users allow customers to invest only in the infrastructure they require and enable simple and rapid scaling to meet growing demands as their business needs change. With the new entry-level FlexPod solution, customers are able to maximize their investments with the ability to easily scale architectures by simply adding incremental capacity as their needs grow for larger application workloads. |

[0001102624-12-000459:8k_2_02:20]
| ● | NetApp and Cisco help customers accelerate transition to Microsoft private cloud with new validated FlexPod solution. The new FlexPod design architecture for the Microsoft® private cloud is designed to meet growing demand for choice and flexibility as more customers transition to the cloud. The new design architecture helps customers reduce infrastructure and application deployment time from days to hours while helping achieve greater utilization of physical and virtual resource pools. Additionally, FlexPod is the first validated data center infrastructure to support Microsoft System Center 2012. |

[0001102624-12-000459:8k_2_02:21]
SOFTBANK Utilizes NetApp Technology to Help Transform IT Infrastructure and Contribute to Japan’s Recovery Process Following 2011 Earthquake and Tsunami

[0001102624-12-000459:8k_2_02:22]
| ● | By leveraging NetApp technology to consolidate and transform its entire IT organization, SOFTBANK Group was able to deliver a range of internal and external cloud services called White Cloud that served as a catalyst for the Company’s continued growth and success. Its newly transformed IT infrastructure also enabled the Company to deliver several of its cloud service offerings either at highly discounted rates or free of charge to businesses, public agencies, and nonprofit organizations just days after the disaster. Additionally, SOFTBANK Group was able to extend its internal virtual desktop service to 14,000 of its displaced employees in a matter of weeks rather than the originally planned one-year timeline. |

[0001102624-12-000459:8k_2_02:23]
Customers Can Harness Big Data Environments with Enhanced NetApp E-Series Platform

[0001102624-12-000459:8k_2_02:24]
| ● | New enhancements to the E-Series platform enable NetApp’s ecosystem of OEM partners to more effectively serve their customers’ growing big data requirements and serve as the platform for many of NetApp’s own big data solutions. The enhanced platform provides improved management capabilities along with new data protection technology to help customers optimize overall performance. |

[0001102624-12-000459:8k_2_02:25]
|  |  | Awards and Milestones |

[0001102624-12-000459:8k_2_02:26]
| ● | Customers, Partners and Employees Help NetApp Make Its Debut on FORTUNE 500 List NetApp was named a FORTUNE 500 company by FORTUNE Magazine, the annual ranking of America’s largest publicly and privately-held companies for which revenues are publicly available. NetApp’s inclusion was based on the Company’s fiscal year 2011 revenue of $5.1 billion. The ranking marks the latest milestone in NetApp’s history and is further testament to the value that NetApp delivers to its customers, partners, shareholders, and employees. |

[0001102624-12-000459:8k_2_02:27]
| ● | 20 Years of Innovation Drive Customer and Partner Success April 2012 marked a major milestone for NetApp as the Company celebrated its 20th anniversary. What began in 1992 with an idea sketched on a placemat has grown into an industry-leading $6B+ company with over 12,000 employees who are committed to building a model company. NetApp’s 20-year achievement is a result of the vision of NetApp’s founders, the dedication of its employees, the strength of its partnerships, and the success of all its customers. Innovation has driven NetApp’s growth throughout its history, and this spirit of innovation remains strong as the Company looks forward to continuing to help customers in the future. |

[0001102624-12-000459:8k_2_02:28]
| ● | NetApp Continues to Earn Recognition as a Great Place to Work Built on a culture of innovation committed to partner and customer success, NetApp was ranked #4 on Crain’s Chicago Business’s 2012 "Best Places to Work" list. The annual list recognized NetApp as the region’s highest-ranked technology employer. |

[0001102624-12-000459:8k_2_02:29]
| ● | NetApp Awarded 5-Star Partner Rating in CRN’s 2012 Partner Programs Guide NetApp’s commitment to its partners’ success is core to the Company’s overall growth strategy. The CRN 5-Star Partner rating is further validation that NetApp’s channel program is one of the best in the market today. |

[0001102624-12-000459:8k_2_02:30]
Webcast and Conference Call Information

[0001102624-12-000459:8k_2_02:31]
The NetApp fourth quarter and fiscal year 2012 results conference call will be broadcast live on the Internet at investors.netapp.com on Wednesday, May 23, 2012, at 2:30 p.m. Pacific Time. This press release and any other information related to the call will also be posted on the Web site at that location. An audio replay Webcast will be available after 4:30 p.m. Pacific Time on the Web site.

[0001102624-12-000459:8k_2_02:32]
NetApp uses a hybrid format for disclosing key financial information associated with our quarterly results. Concurrent with the press release, NetApp posts a supplemental commentary with financial information and statistics to our Web site at investors.netapp.com.

[0001102624-12-000459:8k_2_02:33]
About NetApp

[0001102624-12-000459:8k_2_02:34]
NetApp creates innovative storage and data management solutions that deliver outstanding cost efficiency and accelerate business breakthroughs. Discover our passion for helping companies around the world go further, faster at www.netapp.com.

[0001102624-12-000459:8k_2_02:35]
NetApp, the NetApp logo, and Go further, faster, are trademarks or registered trademarks of NetApp, Inc. All other marks are the property of their respective owners and should be treated as such.

[0001102624-12-000459:8k_2_02:36]
| 1 | GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |

[0001102624-12-000459:8k_2_02:37]
| 2 | Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our convertible debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |

[0001102624-12-000459:8k_2_02:38]
| 3 | 80% hedged on maturity or conversion of the convertible notes. |

[0001102624-12-000459:8k_2_02:39]
NetApp Usage of Non-GAAP Financials

[0001102624-12-000459:8k_2_02:40]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our convertible debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-12-000459:8k_2_02:41]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation. We have historically reported similar non-GAAP financial measures to our investors and believe that the inclusion of comparative numbers provides consistency in our financial reporting at this time.

[0001102624-12-000459:8k_2_02:42]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,398.5 |  |  | $ | 5,174.7 |  |
| Accounts receivable, net |  |  | 830.9 |  |  |  | 742.6 |  |
| Inventories |  |  | 161.5 |  |  |  | 108.5 |  |
| Other current assets |  |  | 435.6 |  |  |  | 339.4 |  |
| Total current assets |  |  | 6,826.5 |  |  |  | 6,365.2 |  |
| Property and equipment, net |  |  | 1,137.2 |  |  |  | 911.6 |  |
| Goodwill and other intangible assets, net |  |  | 1,141.2 |  |  |  | 813.3 |  |
| Other non-current assets |  |  | 427.4 |  |  |  | 408.7 |  |
| Total assets |  | $ | 9,532.3 |  |  | $ | 8,498.8 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 233.1 |  |  | $ | 232.8 |  |
| Accrued compensation and other current liabilities |  |  | 717.9 |  |  |  | 763.0 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | 1,202.3 |  |  |  | 1,150.4 |  |
| Short-term deferred revenue |  |  | 1,366.5 |  |  |  | 1,226.6 |  |
| Total current liabilities |  |  | 3,519.8 |  |  |  | 3,372.8 |  |
| Other long-term liabilities |  |  | 206.9 |  |  |  | 192.9 |  |
| Long-term deferred revenue |  |  | 1,449.4 |  |  |  | 1,088.3 |  |
| Total liabilities |  |  | 5,176.1 |  |  |  | 4,654.0 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | 62.6 |  |  |  | 114.6 |  |
| Stockholders' equity |  |  | 4,293.6 |  |  |  | 3,730.2 |  |
| Total liabilities and stockholders' equity |  | $ | 9,532.3 |  |  | $ | 8,498.8 |  |

[0001102624-12-000459:8k_2_02:43]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,165.1 |  |  | $ | 960.5 |  |  | $ | 4,209.7 |  |  | $ | 3,367.1 |  |
| Software entitlements and maintenance |  |  | 212.5 |  |  |  | 187.0 |  |  |  | 812.2 |  |  |  | 720.6 |  |
| Service |  |  | 324.9 |  |  |  | 280.8 |  |  |  | 1,211.3 |  |  |  | 1,034.9 |  |
| Net revenues |  |  | 1,702.5 |  |  |  | 1,428.3 |  |  |  | 6,233.2 |  |  |  | 5,122.6 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 564.0 |  |  |  | 379.1 |  |  |  | 1,979.9 |  |  |  | 1,342.0 |  |
| Cost of software entitlements and maintenance |  |  | 6.8 |  |  |  | 4.8 |  |  |  | 23.9 |  |  |  | 15.7 |  |
| Cost of service |  |  | 136.7 |  |  |  | 116.2 |  |  |  | 516.0 |  |  |  | 436.2 |  |
| Total cost of revenues |  |  | 707.5 |  |  |  | 500.1 |  |  |  | 2,519.8 |  |  |  | 1,793.9 |  |
| Gross profit |  |  | 995.0 |  |  |  | 928.2 |  |  |  | 3,713.4 |  |  |  | 3,328.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 478.1 |  |  |  | 462.6 |  |  |  | 1,864.0 |  |  |  | 1,597.0 |  |
| Research and development |  |  | 221.6 |  |  |  | 176.5 |  |  |  | 828.2 |  |  |  | 648.6 |  |
| General and administrative |  |  | 71.5 |  |  |  | 69.0 |  |  |  | 264.9 |  |  |  | 251.3 |  |
| Restructuring and other charges |  |  | - |  |  |  | 2.4 |  |  |  | - |  |  |  | 1.8 |  |
| Acquisition-related expense |  |  | 2.4 |  |  |  | 4.8 |  |  |  | 9.8 |  |  |  | 5.7 |  |
| Total operating expenses |  |  | 773.6 |  |  |  | 715.3 |  |  |  | 2,966.9 |  |  |  | 2,504.4 |  |
| Income from operations |  |  | 221.4 |  |  |  | 212.9 |  |  |  | 746.5 |  |  |  | 824.3 |  |
| Other expense, net |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 10.6 |  |  |  | 10.3 |  |  |  | 38.2 |  |  |  | 39.9 |  |
| Interest expense |  |  | (20.0 | ) |  |  | (19.7 | ) |  |  | (74.7 | ) |  |  | (75.9 | ) |
| Other income, net |  |  | 2.5 |  |  |  | 4.6 |  |  |  | 2.4 |  |  |  | 5.8 |  |
| Total other expense, net |  |  | (6.9 | ) |  |  | (4.8 | ) |  |  | (34.1 | ) |  |  | (30.2 | ) |
| Income before income taxes |  |  | 214.5 |  |  |  | 208.1 |  |  |  | 712.4 |  |  |  | 794.1 |  |
| Provision for income taxes |  |  | 33.8 |  |  |  | 47.5 |  |  |  | 107.0 |  |  |  | 121.0 |  |
| Net income |  | $ | 180.7 |  |  | $ | 160.6 |  |  | $ | 605.4 |  |  | $ | 673.1 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.50 |  |  | $ | 0.44 |  |  | $ | 1.66 |  |  | $ | 1.87 |  |
| Diluted |  | $ | 0.47 |  |  | $ | 0.40 |  |  | $ | 1.58 |  |  | $ | 1.71 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 363.4 |  |  |  | 368.1 |  |  |  | 363.9 |  |  |  | 360.9 |  |
| Diluted |  |  | 381.7 |  |  |  | 403.6 |  |  |  | 384.3 |  |  |  | 393.7 |  |

[0001102624-12-000459:8k_2_02:44]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOW |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 180.7 |  |  | $ | 160.6 |  |  | $ | 605.4 |  |  | $ | 673.1 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 82.6 |  |  |  | 42.3 |  |  |  | 293.1 |  |  |  | 165.6 |  |
| Stock-based compensation |  |  | 59.8 |  |  |  | 48.2 |  |  |  | 257.6 |  |  |  | 175.2 |  |
| Accretion of discount and issuance costs on notes |  |  | 14.2 |  |  |  | 13.9 |  |  |  | 52.9 |  |  |  | 53.1 |  |
| Tax benefit from stock-based compensation |  |  | 32.8 |  |  |  | 53.6 |  |  |  | 107.5 |  |  |  | 128.5 |  |
| Excess tax benefit from stock-based compensation |  |  | (32.6 | ) |  |  | (64.4 | ) |  |  | (113.3 | ) |  |  | (127.7 | ) |
| Other, net |  |  | 0.7 |  |  |  | 14.7 |  |  |  | (71.2 | ) |  |  | (11.5 | ) |
| Changes in assets and liabilities, net of acquisition of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (146.2 | ) |  |  | (185.2 | ) |  |  | (90.4 | ) |  |  | (262.7 | ) |
| Inventories |  |  | (7.7 | ) |  |  | (14.4 | ) |  |  | (16.5 | ) |  |  | 4.4 |  |
| Accounts payable |  |  | 21.8 |  |  |  | 41.0 |  |  |  | 11.4 |  |  |  | 38.7 |  |
| Accrued compensation and other current liabilities |  |  | 112.2 |  |  |  | 159.4 |  |  |  | (48.3 | ) |  |  | 118.8 |  |
| Deferred revenue |  |  | 271.9 |  |  |  | 231.4 |  |  |  | 506.4 |  |  |  | 382.9 |  |
| Changes in other operating assets and liabilities, net |  |  | (7.6 | ) |  |  | (42.3 | ) |  |  | (32.0 | ) |  |  | 7.9 |  |
| Net cash provided by operating activities |  |  | 582.6 |  |  |  | 458.8 |  |  |  | 1,462.6 |  |  |  | 1,346.3 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of investments, net |  |  | (1,403.7 | ) |  |  | 417.0 |  |  |  | (1,424.9 | ) |  |  | (418.5 | ) |
| Purchases of property and equipment |  |  | (124.2 | ) |  |  | (72.9 | ) |  |  | (407.1 | ) |  |  | (222.7 | ) |
| Acquisition of businesses, net of cash acquired |  |  | - |  |  |  | (61.6 | ) |  |  | (480.0 | ) |  |  | (136.5 | ) |
| Other investing activities, net |  |  | 1.6 |  |  |  | (0.3 | ) |  |  | 1.6 |  |  |  | 0.5 |  |
| Net cash provided by (used in) investing activities |  |  | (1,526.3 | ) |  |  | 282.2 |  |  |  | (2,310.4 | ) |  |  | (777.2 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 41.1 |  |  |  | 12.2 |  |  |  | 142.1 |  |  |  | 324.2 |  |
| Repurchase and retirement of common stock |  |  | - |  |  |  | - |  |  |  | (600.0 | ) |  |  | - |  |
| Excess tax benefit from stock-based compensation |  |  | 32.6 |  |  |  | 64.4 |  |  |  | 113.3 |  |  |  | 127.7 |  |
| Other financing activities, net |  |  | (2.1 | ) |  |  | (1.4 | ) |  |  | 1.0 |  |  |  | (1.0 | ) |
| Net cash provided by (used in) financing activities |  |  | 71.6 |  |  |  | 75.2 |  |  |  | (343.6 | ) |  |  | 450.9 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1.0 |  |  |  | 21.7 |  |  |  | (16.1 | ) |  |  | 32.3 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | (871.1 | ) |  |  | 837.9 |  |  |  | (1,207.5 | ) |  |  | 1,052.3 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,420.9 |  |  |  | 1,919.4 |  |  |  | 2,757.3 |  |  |  | 1,705.0 |  |
| End of period |  | $ | 1,549.8 |  |  | $ | 2,757.3 |  |  | $ | 1,549.8 |  |  | $ | 2,757.3 |  |

[0001102624-12-000459:8k_2_02:45]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP AND GAAP |  |
| IN THE CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | April 27, 2012 |  |  | April 29, 2011 |  |
| SUMMARY RECONCILIATION OF NET INCOME |  |  |  |  |  |  |  |  |  |  |  |  |
| NET INCOME |  | $ | 180.7 |  |  | $ | 160.6 |  |  | $ | 605.4 |  |  | $ | 673.1 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 21.4 |  |  |  | 4.3 |  |  |  | 89.0 |  |  |  | 17.7 |  |
| Stock-based compensation |  |  | 59.8 |  |  |  | 48.4 |  |  |  | 257.6 |  |  |  | 175.2 |  |
| Restructuring and other charges |  |  | - |  |  |  | 2.4 |  |  |  | - |  |  |  | 1.8 |  |
| Acquisition-related expense |  |  | 2.4 |  |  |  | 4.8 |  |  |  | 17.8 |  |  |  | 5.7 |  |
| Non-cash interest expense |  |  | 14.2 |  |  |  | 13.9 |  |  |  | 52.9 |  |  |  | 53.1 |  |
| Gain on investments |  |  | (0.6 | ) |  |  | (0.9 | ) |  |  | (1.3 | ) |  |  | (3.4 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (25.5 | ) |  |  | 3.2 |  |  |  | (95.2 | ) |  |  | (57.5 | ) |
| NON-GAAP NET INCOME |  | $ | 252.4 |  |  | $ | 236.7 |  |  | $ | 926.2 |  |  | $ | 865.7 |  |
| NET INCOME PER SHARE |  | $ | 0.473 |  |  | $ | 0.398 |  |  | $ | 1.575 |  |  | $ | 1.710 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.056 |  |  |  | 0.011 |  |  |  | 0.232 |  |  |  | 0.045 |  |
| Stock-based compensation |  |  | 0.157 |  |  |  | 0.120 |  |  |  | 0.670 |  |  |  | 0.445 |  |
| Restructuring and other charges |  |  | - |  |  |  | 0.006 |  |  |  | - |  |  |  | 0.005 |  |
| Acquisition-related expense |  |  | 0.006 |  |  |  | 0.012 |  |  |  | 0.046 |  |  |  | 0.014 |  |
| Non-cash interest expense |  |  | 0.037 |  |  |  | 0.034 |  |  |  | 0.138 |  |  |  | 0.135 |  |
| Gain on investments |  |  | (0.001 | ) |  |  | (0.002 | ) |  |  | (0.003 | ) |  |  | (0.009 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.067 | ) |  |  | 0.008 |  |  |  | (0.248 | ) |  |  | (0.146 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.661 |  |  | $ | 0.586 |  |  | $ | 2.410 |  |  | $ | 2.199 |  |

[0001102624-12-000459:8k_2_02:46]
| NETAPP, INC. |  |
| SUPPLEMENTAL INFORMATION |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended April 27, 2012 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Restructuring and Other Charges |  |  | Acquisition- related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 14.0 |  |  | $ | 1.3 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 15.3 |  |
| Cost of service revenues |  |  | - |  |  |  | 4.0 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 4.0 |  |
| Sales and marketing expense |  |  | 7.4 |  |  |  | 29.5 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 36.9 |  |
| Research and development expense |  |  | - |  |  |  | 17.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 17.1 |  |
| General and administrative expense |  |  | - |  |  |  | 7.9 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 7.9 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 2.4 |  |  |  | - |  |  |  | - |  |  |  | 2.4 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 14.2 |  |  |  | - |  |  |  | 14.2 |  |
| Other income, net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.6 | ) |  |  | (0.6 | ) |
| Effect on income before income taxes |  | $ | 21.4 |  |  | $ | 59.8 |  |  | $ | - |  |  | $ | 2.4 |  |  | $ | 14.2 |  |  | $ | (0.6 | ) |  | $ | 97.2 |  |
|  |  | Three Months Ended April 29, 2011 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Restructuring and Other Charges |  |  | Acquisition- related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 3.1 |  |  | $ | 1.0 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 4.1 |  |
| Cost of service revenues |  |  | - |  |  |  | 3.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3.8 |  |
| Sales and marketing expense |  |  | 1.1 |  |  |  | 22.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 23.5 |  |
| Research and development expense |  |  | 0.1 |  |  |  | 12.9 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 13.0 |  |
| General and administrative expense |  |  | - |  |  |  | 8.3 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 8.3 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 2.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 2.4 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 4.8 |  |  |  | - |  |  |  | - |  |  |  | 4.8 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 13.9 |  |  |  | - |  |  |  | 13.9 |  |
| Other income, net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.9 | ) |  |  | (0.9 | ) |
| Effect on income before income taxes |  | $ | 4.3 |  |  | $ | 48.4 |  |  | $ | 2.4 |  |  | $ | 4.8 |  |  | $ | 13.9 |  |  | $ | (0.9 | ) |  | $ | 72.9 |  |
|  |  | Year Ended April 27, 2012 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Restructuring and Other Charges |  |  | Acquisition- related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 55.8 |  |  | $ | 5.4 |  |  | $ | - |  |  | $ | 5.4 |  |  | $ | - |  |  | $ | - |  |  | $ | 66.6 |  |
| Cost of service revenues |  |  | - |  |  |  | 17.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 17.8 |  |
| Sales and marketing expense |  |  | 33.0 |  |  |  | 126.0 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 159.0 |  |
| Research and development expense |  |  | 0.2 |  |  |  | 74.1 |  |  |  | - |  |  |  | 2.6 |  |  |  | - |  |  |  | - |  |  |  | 76.9 |  |
| General and administrative expense |  |  | - |  |  |  | 34.3 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 34.3 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 9.8 |  |  |  | - |  |  |  | - |  |  |  | 9.8 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 52.9 |  |  |  | - |  |  |  | 52.9 |  |
| Other income, net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (1.3 | ) |  |  | (1.3 | ) |
| Effect on income before income taxes |  | $ | 89.0 |  |  | $ | 257.6 |  |  | $ | - |  |  | $ | 17.8 |  |  | $ | 52.9 |  |  | $ | (1.3 | ) |  | $ | 416.0 |  |
|  |  | Year Ended April 29, 2011 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Restructuring and Other Charges |  |  | Acquisition-related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 13.3 |  |  | $ | 3.6 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 16.9 |  |
| Cost of service revenues |  |  | - |  |  |  | 14.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 14.4 |  |
| Sales and marketing expense |  |  | 4.3 |  |  |  | 81.5 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 85.8 |  |
| Research and development expense |  |  | 0.1 |  |  |  | 44.5 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 44.6 |  |
| General and administrative expense |  |  | - |  |  |  | 31.2 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 31.2 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 1.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1.8 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 5.7 |  |  |  | - |  |  |  | - |  |  |  | 5.7 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 53.1 |  |  |  | - |  |  |  | 53.1 |  |
| Other income, net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (3.4 | ) |  |  | (3.4 | ) |
| Effect on income before income taxes |  | $ | 17.7 |  |  | $ | 175.2 |  |  | $ | 1.8 |  |  | $ | 5.7 |  |  | $ | 53.1 |  |  | $ | (3.4 | ) |  | $ | 250.1 |  |

[0001102624-12-000459:8k_2_02:47]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FIRST QUARTER 2013 |
| (Unaudited) |
|  | First Quarter |
|  | 2013 |
| Non-GAAP Guidance | $0.34 - $0.39 |
| Adjustments of Specific Items to |  |
| Net Income Per Share for the First |  |
| Quarter 2013: |  |
| Amortization of intangible assets | (0.06) |
| Stock based compensation expense | (0.20) |
| Non cash interest expense | (0.04) |
| Income tax effect | 0.06 |
| Total Adjustments | (0.24) |
| GAAP Guidance -Net Income Per Share | $0.10 - $0.15 |
