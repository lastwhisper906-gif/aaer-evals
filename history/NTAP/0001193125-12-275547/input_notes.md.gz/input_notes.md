# NTAP notes — 0001193125-12-275547


## ntap:AccountsReceivableFromSignificantCustomersTextBlock

[0001193125-12-275547:notes:1]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Arrow Electronics, Inc. |  |  | N/A |  |  | $ | 101.4 |  |
| Avnet, Inc. |  | $ | 92.5 |  |  | $ | 107.5 |  |


## ntap:AmortizationFiniteLivedIntangibleAssetsTextBlock

[0001193125-12-275547:notes:2]
|  |  | Year Ended |  |  | Statements of OperationsClassifications |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | April 30, 2010 |  |  |
| Developed technology |  | $ | 55.8 |  |  | $ | 13.3 |  |  | $ | 17.2 |  |  | Cost of product revenues |
| Customer contracts/relationships |  |  | 28.1 |  |  |  | 3.0 |  |  |  | 2.4 |  |  | Sales and marketing |
| Trademarks and trade names |  |  | 4.2 |  |  |  | 1.2 |  |  |  | 1.0 |  |  | Sales and marketing |
| Covenants not to compete |  |  | 0.9 |  |  |  | 0.2 |  |  |  | 0.0 |  |  | Sales and marketing/Research and development |
|  |  | $ | 89.0 |  |  | $ | 17.7 |  |  | $ | 20.6 |  |  |  |


## ntap:AmountContributedUnder401KPlansTableTextBlock

[0001193125-12-275547:notes:3]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| 401(k) contributions |  | $ | 20.0 |  |  | $ | 15.6 |  |  | $ | 9.2 |  |


## ntap:AssetsAndLiabilitiesMeasuredAtFairValueOnRecurringBasisTableTextBlock

[0001193125-12-275547:notes:4]
|  |  |  |  |  | Fair Value Measurements at Reporting DateUsing |  |
|  |  | Total |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 900.0 |  |  | $ | 724.8 |  |  | $ | 175.2 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 3,848.7 |  |  |  | 234.3 |  |  |  | 3,614.4 |  |  |  | 0.0 |  |
| Other current assets |  |  | 9.0 |  |  |  | 6.3 |  |  |  | 2.7 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 70.2 |  |  |  | 19.2 |  |  |  | 0.0 |  |  |  | 51.0 |  |
| Total |  | $ | 4,827.9 |  |  | $ | 984.6 |  |  | $ | 3,792.3 |  |  | $ | 51.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 2.6 |  |  | $ | 0.0 |  |  | $ | 2.6 |  |  | $ | 0.0 |  |


## ntap:CurrentAndNoncurrentNetDeferredTaxAssetsAndLiabilitiesTableTextBlock

[0001193125-12-275547:notes:5]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Current deferred tax assets, net |  | $ | 201.6 |  |  | $ | 145.7 |  |
| Non-current deferred tax assets, net |  |  | 203.8 |  |  |  | 208.0 |  |


## ntap:DebtDiscountAndIssuanceCostTextBlock

[0001193125-12-275547:notes:6]
| Remaining debt discount |  | $ | 62.6 |  |
| Remaining debt issuance costs |  |  | 5.4 |  |
| Remaining life of the Notes (years) |  |  | 1.1 |  |


## ntap:InterestCostIncurredTextBlock

[0001193125-12-275547:notes:7]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Contractual coupon interest expense |  | $ | 22.0 |  |  | $ | 22.1 |  |  | $ | 22.5 |  |
| Amortization of debt discount |  |  | 52.0 |  |  |  | 48.9 |  |  |  | 46.8 |  |
| Amortization of debt issuance costs |  |  | 4.5 |  |  |  | 4.2 |  |  |  | 4.0 |  |
| Less capitalized interest |  |  | (5.0 | ) |  |  | 0.0 |  |  |  | 0.0 |  |
| Total interest expense related to Notes |  | $ | 73.5 |  |  | $ | 75.2 |  |  | $ | 73.3 |  |


## ntap:InternationalSalesToSingleForeignCountriesTextBlock

[0001193125-12-275547:notes:8]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Germany |  | $ | 632.6 |  |  | $ | 618.0 |  |  | $ | 441.1 |  |


## ntap:ResidualGuaranteesPolicyTextBlock

[0001193125-12-275547:notes:9]
Residual Guarantees — We record liabilities for the fair value of residual guarantees relating to certain properties under our synthetic leases. In the event that the fair values of the properties, as determined by appraisals, are below the cost, we accrue for the deficiencies over the remaining term of the respective leases.


## ntap:ScheduleOfAcquisitionRelatedAndIntegrationExpensesTableTextBlock

[0001193125-12-275547:notes:10]
|  |  | YearEnded |  |
|  |  | April 27,2012 |  |
| Acquisition-related expense |  | $ | 9.8 |  |


## ntap:ScheduleOfAmortizationOfCapitalizedInternalUseSoftwareDevelopmentCostsTextBlock

[0001193125-12-275547:notes:11]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Computer software amortization expense |  | $ | 53.8 |  |  | $ | 37.9 |  |  | $ | 36.6 |  |


## ntap:ScheduleOfComputerSoftwareTableTextBlock

[0001193125-12-275547:notes:12]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Computer software |  | $ | 160.1 |  |  | $ | 88.3 |  |


## ntap:ScheduleOfDepreciationAndAmortizationExpenseTableTextBlock

[0001193125-12-275547:notes:13]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Depreciation and amortization expense |  | $ | 204.1 |  |  | $ | 147.9 |  |  | $ | 145.4 |  |


## ntap:ScheduleOfIncomeTaxEffectsAllocatedDirectlyToEquityEmployeeStockOptionsTextBlock

[0001193125-12-275547:notes:14]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Income tax benefits (charges) associated with employee stock transactions |  | $ | 107.5 |  |  | $ | 128.5 |  |  | $ | (0.9 | ) |


## ntap:ScheduleOfLeasingArrangementsTableTextBlock

[0001193125-12-275547:notes:15]
| Cost |  | Residual Guarantee |  | Fixed Rates |  | Lease Commencement Dates |  | Term |
| $ 69.6 million |  | $ 59.1 million |  | 3.67% - 3.69% |  | December 2007 - January 2008 |  | 5 years |


## ntap:ScheduleOfMaximumPotentialFuturePaymentsUnderFinancingArrangementsWithThirdPartiesTableTextBlock

[0001193125-12-275547:notes:16]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Maximum guaranteed payment contingencies |  | $ | 169.0 |  |  | $ | 89.0 |  |
| Deferred revenue associated with financing guarantees |  |  | (149.9 | ) |  |  | (87.7 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 19.1 |  |  | $ | 1.3 |  |


## ntap:ScheduleOfPropertyPlantAndEquipmentNetOfAccumulatedDepreciationAndAmortizationTableTextBlock

[0001193125-12-275547:notes:17]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Land |  | $ | 247.6 |  |  | $ | 204.7 |  |
| Buildings and building improvements |  |  | 417.9 |  |  |  | 406.2 |  |
| Leasehold improvements |  |  | 96.5 |  |  |  | 79.3 |  |
| Computer, production, engineering and other equipment |  |  | 638.1 |  |  |  | 475.5 |  |
| Software |  |  | 381.6 |  |  |  | 270.4 |  |
| Furniture and fixtures |  |  | 71.7 |  |  |  | 61.5 |  |
| Construction-in-progress |  |  | 107.1 |  |  |  | 91.9 |  |
|  |  |  | 1,960.5 |  |  |  | 1,589.5 |  |
| Accumulated depreciation and amortization |  |  | (823.3 | ) |  |  | (677.9 | ) |
| Property and equipment, net |  | $ | 1,137.2 |  |  | $ | 911.6 |  |


## ntap:ScheduleOfShareBasedPaymentAwardStockOptionsAndESPPValuationAssumptionsTableTextBlock

[0001193125-12-275547:notes:18]
|  |  | Stock OptionsYear Ended |  |  | ESPPYear Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Expected term in years |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 4.5 |  |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.3 |  |
| Risk-free interest rate |  |  | 1.50 | % |  |  | 2.01 | % |  |  | 2.27 | % |  |  | 0.19 | % |  |  | 0.37 | % |  |  | 0.39 | % |
| Volatility |  |  | 36 | % |  |  | 37 | % |  |  | 41 | % |  |  | 44 | % |  |  | 39 | % |  |  | 39 | % |


## ntap:SharesWithheldForEmployeeTaxesTextBlock

[0001193125-12-275547:notes:19]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Shares withheld for taxes |  |  | 1.2 |  |  |  | 1.0 |  |  |  | 0.7 |  |
| Fair value of shares withheld and retired |  | $ | 52.0 |  |  | $ | 45.9 |  |  | $ | 20.8 |  |


## ntap:TaxesCollectedFromCustomersPolicyTextBlock

[0001193125-12-275547:notes:20]
Sales and Value Added Taxes — Taxes collected from customers and remitted to governmental authorities are presented on a net basis in the accompanying consolidated statements of operations.


## ntap:TreasuryStockPolicyPolicyTextBlock

[0001193125-12-275547:notes:21]
Treasury Stock — We account for treasury stock under the cost method. If treasury stock is re-issued at a price higher than its cost, the difference is recorded as a component of additional paid-in-capital in our consolidated balance sheets. If treasury stock is re-issued at a price lower than its cost, the difference is recorded as a component of additional paid-in-capital to the extent that there are gains to offset the losses. If there are no treasury stock gains in additional paid-in-capital, the losses upon re-issuance of treasury stock are recorded as a component of retained earnings in our consolidated balance sheets. Upon the retirement of treasury stock, we allocate the value of treasury shares between additional paid-in capital and retained earnings.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-12-275547:notes:22]
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |
|  |  | Cost orAmortizedCost |  |  | Gross Unrealized |  |  | EstimatedFair Value |  |  | Cost orAmortizedCost |  |  | Gross Unrealized |  |  | EstimatedFair Value |  |
|  |  |  | Gains |  |  | Losses |  |  |  |  | Gains |  |  | Losses |  |  |
| Corporate bonds |  | $ | 2,665.2 |  |  | $ | 9.5 |  |  | $ | (1.4 | ) |  | $ | 2,673.3 |  |  | $ | 1,643.2 |  |  | $ | 10.2 |  |  | $ | (0.6 | ) |  | $ | 1,652.8 |  |
| U.S. treasury and government debt securities |  |  | 836.7 |  |  |  | 1.2 |  |  |  | (0.1 | ) |  |  | 837.8 |  |  |  | 661.9 |  |  |  | 0.6 |  |  |  | (0.7 | ) |  |  | 661.8 |  |
| Commercial paper |  |  | 164.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 164.6 |  |  |  | 5.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 5.0 |  |
| Certificates of deposit |  |  | 347.7 |  |  |  | 0.5 |  |  |  | 0.0 |  |  |  | 348.2 |  |  |  | 96.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 96.3 |  |
| Money market funds |  |  | 724.8 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 724.8 |  |  |  | 1,539.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,539.6 |  |
| Auction rate securities |  |  | 54.1 |  |  |  | 0.9 |  |  |  | (4.0 | ) |  |  | 51.0 |  |  |  | 69.2 |  |  |  | 0.4 |  |  |  | (4.5 | ) |  |  | 65.1 |  |
| Equity funds |  |  | 25.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 25.5 |  |  |  | 20.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 20.2 |  |
| Municipal bonds |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.5 |  |
| Total debt and equity securities |  | $ | 4,818.6 |  |  | $ | 12.1 |  |  | $ | (5.5 | ) |  | $ | 4,825.2 |  |  | $ | 4,036.9 |  |  | $ | 11.2 |  |  | $ | (5.8 | ) |  | $ | 4,042.3 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001193125-12-275547:notes:23]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Net revenues |  | $ | 6,241.6 |  |  | $ | 5,827.4 |  |
| Net income |  | $ | 611.9 |  |  | $ | 605.5 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-12-275547:notes:24]
6. Business Combinations

[0001193125-12-275547:notes:25]
Fiscal 2012 Acquisition

[0001193125-12-275547:notes:26]
On May 6, 2011, we completed the acquisition of certain assets related to the Engenio external storage systems business (Engenio) of LSI Corporation (LSI). We paid LSI $480.0 million in cash and also assumed certain liabilities related to Engenio. During the three years following the acquisition, LSI will pay us a total of $13.0 million to service certain LSI customer warranties. This acquisition enables us to address growing customer requirements in the areas of high bandwidth and intensive analytics workloads such as video, including full-motion video capture and digital video surveillance, as well as high-performance computing applications, such as genomics sequencing and scientific research.

[0001193125-12-275547:notes:27]
The purchase price was allocated to Engenio's net tangible and intangible assets as of the date of acquisition based on various fair value estimates and analyses, including work performed by third-party valuation specialists.

[0001193125-12-275547:notes:28]
The following are the estimated fair value of assets acquired and liabilities assumed as of the closing date (in millions):

[0001193125-12-275547:notes:29]
| Current assets |  | $ | 49.8 |  |
| Property and equipment |  |  | 33.3 |  |
| Identified intangible assets |  |  | 272.1 |  |
| Goodwill |  |  | 143.7 |  |
| Other assets |  |  | 9.3 |  |
| Total assets acquired |  |  | 508.2 |  |
| Current liabilities |  |  | (20.9 | ) |
| Other liabilities |  |  | (7.3 | ) |
| Total purchase price |  | $ | 480.0 |  |

[0001193125-12-275547:notes:30]
As this was an asset acquisition, U.S. goodwill is deductible for income tax purposes. The goodwill is comprised of expected synergies in utilizing Engenio's technology in our products and channels (and vice versa), reduction in future combined research and development expenses, and intangible assets, such as acquired workforce, that do not qualify for separate recognition.

[0001193125-12-275547:notes:31]
The identified intangible assets as of the date of acquisition, which are amortized on a straight-line basis over their estimated useful lives, consisted of the following (in millions):

[0001193125-12-275547:notes:32]
|  |  | Estimated FairValue |  |  | Useful Life(Years) |  |
| Developed technology |  | $ | 216.0 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 45.0 |  |  |  | 2 |  |
| Trademarks and trade names |  |  | 7.0 |  |  |  | 2 |  |
| Order backlog |  |  | 2.5 |  |  |  | 0 |  |
| Covenant not to compete |  |  | 1.6 |  |  |  | 3 |  |
| Total identified intangible assets |  | $ | 272.1 |  |  |  |  |  |

[0001193125-12-275547:notes:33]
Our consolidated net revenues for the year ended April 27, 2012 included $665.9 million attributable to Engenio since the acquisition. Due to the integration of the combined businesses since the date of acquisition, it is impracticable to determine the earnings contributed by Engenio.

[0001193125-12-275547:notes:34]
The following unaudited pro forma condensed combined financial information gives effect to the acquisition of Engenio as if it were consummated on May 1, 2010 (the beginning of the comparable prior annual reporting period). Due to historically differing fiscal year ends of the Company and Engenio, the unaudited pro forma condensed combined financial information for the year ended April 29, 2011 is based on historical results of the Company for the year ended April 29, 2011 and the historical results of Engenio for the year ended March 31, 2011.

[0001193125-12-275547:notes:35]
The unaudited pro forma condensed combined financial information is presented for informational purposes only, is not intended to represent or be indicative of the results of operations of the Company that would have been reported had the acquisition occurred on May 1, 2010 and should not be taken as representative of future condensed consolidated results of operations of the combined company (in millions):

[0001193125-12-275547:notes:36]
A nonrecurring adjustment of $5.6 million has been reflected in the unaudited pro forma condensed combined information with the effect of increasing net income for the year ended April 27, 2012 and decreasing net income for the year ended April 29, 2011 to present the impact on cost of revenues from the step-up in inventory as if the acquisition occurred on May 1, 2010.

[0001193125-12-275547:notes:37]
Acquisition-related expense included in our consolidated statements of operations was:

[0001193125-12-275547:notes:38]
Acquisition-related expense consisted of due diligence and legal charges of $0.7 million directly related to the acquisition of Engenio and $9.1 million of integration charges related to the combined business.

[0001193125-12-275547:notes:39]
Fiscal 2011 Acquisitions

[0001193125-12-275547:notes:40]
During fiscal 2011, we acquired 100% of the common stock of two privately held companies, Akorri Networks, Inc. (Akorri), and Bycast Inc. (Bycast). Akorri, headquartered in Massachusetts, is a provider of data center management software focused on performance and capacity analytics for virtualized, shared information technology infrastructures. The Akorri acquisition extends our offering by adding performance capacity analytics to provide customers greater visibility across the entire IT stack, resulting in further improvement in IT efficiency and flexibility through functions that help control, automate, and analyze their shared IT infrastructure. Bycast, headquartered in Vancouver, Canada, develops and sells software designed to manage petabyte-scale, globally distributed repositories of images, video and records for enterprises and service providers. The Bycast acquisition extends our position in unified storage by adding an object-based storage software offering, which simplifies the task of large-scale storage and improves the ability to search and locate data objects. These acquisitions were completed for total cash and equity consideration of $146.1 million. The Company recorded tangible net assets of $21.2 million, identified intangible assets of $45.6 million and goodwill, which was not deductible for tax purposes, of $80.5 million associated with these transactions. The results of operations of Akorri and Bycast have been included in our consolidated statements of operations from their respective acquisition dates. Pro forma results of operations have not been presented because the acquisitions were not material to our results of operations.

[0001193125-12-275547:notes:41]
During fiscal 2012, the escrow period for the Bycast acquisition expired and the remaining purchase price of $13.1 million was released to the former shareholders. Subject to any claims for indemnity, escrow funds of $7.9 million for Akorri will be released in July 2012.

[0001193125-12-275547:notes:42]
Fiscal 2010 Termination of Proposed Merger with Data Domain, Inc.

[0001193125-12-275547:notes:43]
In fiscal 2010, a proposed merger between us and Data Domain, Inc. (Data Domain) was terminated by Data Domain's Board of Directors and, pursuant to the terms of the agreement, Data Domain paid us a $57.0 million termination fee. We incurred $15.9 million of incremental third-party costs relating to the terminated merger transaction during the same period, resulting in a net amount of $41.1 million which is included in acquisition-related expense (income), net in our consolidated statement of operations for the fiscal year ended April 30, 2010.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-12-275547:notes:44]
Cash and Cash Equivalents — Cash equivalents consist primarily of money market funds. We consider all highly liquid debt investments with original maturities of three months or less at time of purchase to be cash equivalents and such investments are recognized at carrying value which approximates fair value.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-12-275547:notes:45]
5. Statements of Cash Flows

[0001193125-12-275547:notes:46]
Non-cash investing and financing activities and supplemental cash flow information are as follows (in millions):

[0001193125-12-275547:notes:47]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Reclassification of equity component of convertible debt |  | $ | 52.0 |  |  | $ | (114.6 | ) |  | $ | 0.0 |  |
| Acquisition of property and equipment on account |  | $ | 31.4 |  |  | $ | 39.3 |  |  | $ | 17.2 |  |
| Acquisition of property and equipment through long-term financing |  | $ | 3.6 |  |  | $ | 12.6 |  |  | $ | 0.0 |  |
| Options assumed from acquired business |  | $ | 0.0 |  |  | $ | 3.3 |  |  | $ | 0.0 |  |
| Taxes on settlement of note hedge |  | $ | 0.0 |  |  | $ | 0.0 |  |  | $ | 32.1 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 48.2 |  |  | $ | 27.9 |  |  | $ | 22.8 |  |
| Interest paid (net of capitalized interest of $1.4 million, $0.0 million and $0.0 million, respectively) |  | $ | 21.4 |  |  | $ | 22.7 |  |  | $ | 22.1 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-275547:notes:48]
17. Commitments and Contingencies

[0001193125-12-275547:notes:49]
Operating Leases — We lease office space in several U.S. locations. Outside the United States, larger leased sites include sites in The Netherlands, Australia, Belgium, France, Germany, India, Japan, and the United Kingdom. We also lease equipment and vehicles.

[0001193125-12-275547:notes:50]
As of April 27, 2012, we have three leasing arrangements with BNP Paribas LLC (BNPPLC), one of which require us to lease certain of our land to BNPPLC for a period of 99 years and all of which require us to lease approximately 0.3 million square feet of office space from BNPPLC for our headquarters in Sunnyvale, California, which had an original cost of $69.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of the leases for two consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of the lease terms, we must elect one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received from the third-party and BNPPLC's cost, up to 85% of cost (residual guarantee); or (iii) pay BNPPLC supplemental payments for an amount equal to the difference between BNPPLC's cost and fair value, up to the residual guarantee, in which event we may recoup some or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period.

[0001193125-12-275547:notes:51]
The following table summarizes the aggregate cost, the aggregate residual guarantee, and the range of applicable fixed rates at April 27, 2012 and the lease commencement dates for our leasing arrangements:

[0001193125-12-275547:notes:52]
These leasing arrangements require us to maintain specified financial covenants with which we were in compliance as of April 27, 2012. Such financial covenants include a maximum ratio of Total Debt to Earnings before Interest, Taxes, Depreciation and Amortization of less than 3:1 and a minimum amount of Unencumbered Cash and Short-Term Investments of $300.0 million.

[0001193125-12-275547:notes:53]
Future annual minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 27, 2012 are as follows (in millions):

[0001193125-12-275547:notes:54]
|  |  | 2013 |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | Thereafter |  |  | Total |  |
| Office operating lease payments |  | $ | 36.7 |  |  | $ | 39.5 |  |  | $ | 39.7 |  |  | $ | 32.9 |  |  | $ | 18.7 |  |  | $ | 53.8 |  |  | $ | 221.3 |  |
| Real estate lease payments |  |  | 60.8 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 60.8 |  |
| Equipment operating lease payments |  |  | 24.3 |  |  |  | 17.2 |  |  |  | 7.7 |  |  |  | 2.8 |  |  |  | 0.6 |  |  |  | 0.0 |  |  |  | 52.6 |  |
| Less: Sublease income |  |  | (1.6 | ) |  |  | (0.4 | ) |  |  | (0.5 | ) |  |  | (0.4 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (2.9 | ) |
| Total lease commitments |  | $ | 120.2 |  |  | $ | 56.3 |  |  | $ | 46.9 |  |  | $ | 35.3 |  |  | $ | 19.3 |  |  | $ | 53.8 |  |  | $ | 331.8 |  |

[0001193125-12-275547:notes:55]
Included in real estate lease payments pursuant to three financing arrangements with BNPPLC are: (i) lease commitments of $1.7 million, which are based on a fixed rate for terms of five years and (ii) at the expiration or termination of the leasing arrangements, a supplemental payment obligation equal to our minimum guarantee of $59.1 million in the event that we elect not to purchase or arrange for sale of the remaining properties.

[0001193125-12-275547:notes:56]
Rent expense in fiscal 2012, 2011 and 2010 was as follows (in millions):

[0001193125-12-275547:notes:57]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Facilities rent expense |  | $ | 71.0 |  |  | $ | 51.7 |  |  | $ | 43.2 |  |
| Equipment rent expense |  |  | 18.6 |  |  |  | 23.1 |  |  |  | 23.4 |  |
|  |  |  | 89.6 |  |  |  | 74.8 |  |  |  | 66.6 |  |
| Less: sublease income |  |  | (1.4 | ) |  |  | (6.3 | ) |  |  | (12.5 | ) |
| Net rent expense |  | $ | 88.2 |  |  | $ | 68.5 |  |  | $ | 54.1 |  |

[0001193125-12-275547:notes:58]
Purchase Orders and Other Commitments

[0001193125-12-275547:notes:59]
In the normal course of business we make commitments to our third-party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. We had $250.1 million in non-cancelable purchase commitments with our contract manufacturers as of April 27, 2012. In addition, we recorded a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to product cost of sales. As of April 27, 2012 and April 29, 2011, such liability amounted to $3.3 million and $4.5 million, respectively, and is included in other current liabilities in the consolidated balance sheets.

[0001193125-12-275547:notes:60]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course business for which we have not received goods or services. As of April 27, 2012, we had $46.0 million in capital purchase commitments and $163.5 million in other purchase commitments.

[0001193125-12-275547:notes:61]
During the ordinary course of business, we provide standby letters of credit or other guarantee instruments to third parties as required for certain transactions initiated either by us or our subsidiaries. As of April 27, 2012, our financial guarantees of $13.1 million that were not recorded on our consolidated balance sheet consisted of standby letters of credit related to workers' compensation, a customs guarantee, a corporate credit card program, foreign rent guarantees and surety bonds, which were primarily related to self-insurance.

[0001193125-12-275547:notes:62]
Product Warranties

[0001193125-12-275547:notes:63]
We provide customers a warranty on software of ninety days to five years and a warranty on hardware of one to five years. The following table summarizes our warranty reserves (in millions):

[0001193125-12-275547:notes:64]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Beginning balance |  | $ | 40.5 |  |  | $ | 31.9 |  |
| Liability assumed in acquisition |  |  | 17.5 |  |  |  | 0.0 |  |
| Expense accrued during the period |  |  | 67.9 |  |  |  | 31.8 |  |
| Warranty costs incurred |  |  | (42.8 | ) |  |  | (23.2 | ) |
| Ending balance |  | $ | 83.1 |  |  | $ | 40.5 |  |

[0001193125-12-275547:notes:65]
Financing Guarantees

[0001193125-12-275547:notes:66]
Some of our customers have entered into recourse and nonrecourse financing leasing arrangements using third-party financing companies. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Under the terms of the nonrecourse leases, we do not have any continuing obligations or liabilities to the third-party financing companies. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy.

[0001193125-12-275547:notes:67]
The aggregate amount of financing guarantees representing the total maximum potential future payments under financing arrangements with third parties, and the related deferred revenue are summarized as follows (in millions):

[0001193125-12-275547:notes:68]
To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001193125-12-275547:notes:69]
Indemnification Agreements

[0001193125-12-275547:notes:70]
We enter into standard indemnification agreements in the ordinary course of business. Pursuant to these agreements, we agree to defend and indemnify other parties, primarily our customers or business partners or subcontractors, for damages and reasonable costs incurred in any suit or claim brought against them alleging that our products sold to them infringe any U.S. patent, copyright, trade secret, or similar right. If a product becomes the subject of an infringement claim, we may, at our option: (i) replace the product with another non-infringing product that provides substantially similar performance; (ii) modify the infringing product so that it no longer infringes but remains functionally equivalent; (iii) obtain the right for the customer to continue using the product at our expense and for the reseller to continue selling the product; (iv) take back the infringing product and refund to customer the purchase price paid less depreciation amortized on a straight-line basis. We have not been required to make material payments pursuant to these provisions historically. We have not recorded any liability at April 27, 2012 related to these guarantees since the maximum amount of potential future payments under such guarantees, indemnities and warranties is not determinable, other than as described above.

[0001193125-12-275547:notes:71]
Legal Contingencies

[0001193125-12-275547:notes:72]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001193125-12-275547:notes:73]
On October 13, 2010, Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of California, Santa Clara County. The lawsuit named certain of our current and former directors as defendants. On February 3, 2011, the plaintiff filed an amended complaint in response to motions to dismiss that we and the individual defendants had filed. Like the original complaint, the amended complaint included claims of breach of fiduciary duty and waste of corporate assets and alleges that the defendants failed to monitor internal controls to ensure that we complied with legal requirements in our General Services Administration (GSA) contracting activities, resulting in us incurring defense and settlement costs. The amended complaint sought disgorgement of salaries and other compensation from the defendants and additional unspecified damages. We and the individual defendants filed motions to dismiss the amended complaint in early March 2011. Following a hearing on July 15, 2011, the Court granted the motions to dismiss, but permitted plaintiff leave to amend its complaint on or before September 16, 2011.

[0001193125-12-275547:notes:74]
On August 9, 2011, Amalgamated Bank filed a complaint in Delaware Chancery Court against us for the purpose of obtaining, in a summary proceeding, books and records to help Amalgamated Bank amend its complaint in the California lawsuit. Each of the parties filed cross motions for summary judgment, and a hearing was held before the Delaware Chancery Court on November 16, 2011. Following that hearing, the Court directed Amalgamated Bank to more narrowly tailor its requests. On December 5, 2011, the court allowed plaintiff to conduct a very limited document inspection. On February 6, 2012, the court denied plaintiff's motion to compel further document production.

[0001193125-12-275547:notes:75]
The plaintiff filed an amended complaint for a third time on September 15, 2011. This complaint alleged the same claims and requests for relief as the previous complaints. At a hearing held on March 23, 2012, the court granted our motion to dismiss with prejudice. The court's judgment was entered on March 26, 2012. The plaintiff had until May 25, 2012 to file an appeal of the dismissal of its lawsuit and failed to do so by such deadline.

[0001193125-12-275547:notes:76]
We are subject to various other legal proceedings and claims, not described above, that arise in the normal course of business. No material accrual has been recorded as of April 27, 2012 related to such matters.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-12-275547:notes:77]
3. Concentration of Risk

[0001193125-12-275547:notes:78]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, investments, foreign exchange contracts and accounts receivable. Cash equivalents and short-term investments consist primarily of corporate bonds, U.S. government agency securities, and money market funds, all of which are considered high investment grade. Our policy is to limit the amount of credit exposure through diversification and investment in highly rated securities. We further mitigate concentrations of credit risk in our investments by limiting our investments in the debt securities of a single issuer and by diversifying risk across geographies and type of issuer.

[0001193125-12-275547:notes:79]
Our long term investments, consisting primarily of auction rate securities, have been and will continue to be exposed to market risk due to uncertainties in the credit and capital markets.

[0001193125-12-275547:notes:80]
In entering into forward foreign exchange contracts, we have assumed the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and we do not expect any losses as a result of counterparty defaults.

[0001193125-12-275547:notes:81]
We sell our products primarily to large organizations in different industries and geographies. We do not require collateral or other security to support accounts receivable. In addition, we maintain an allowance for potential credit losses. To reduce credit risk, we perform ongoing credit evaluations on our customers' financial condition. We establish an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information and, to date, such losses have been within management's expectations. Concentrations of credit risk with respect to trade accounts receivable are limited due to the wide variety of customers who are dispersed across many geographic regions.

[0001193125-12-275547:notes:82]
There are no concentrations of business transacted with a particular market that would severely impact our business in the near term. However, we currently rely on a limited number of suppliers for certain key components and a few key contract manufacturers to manufacture most of our products; any disruption or termination of these arrangements could materially adversely affect our operating results.


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-12-275547:notes:83]
Principles of Consolidation — The consolidated financial statements include the Company and its wholly-owned subsidiaries. Intercompany accounts and transactions are eliminated in consolidation.


## us-gaap:DebtDisclosureTextBlock

[0001193125-12-275547:notes:84]
10. Financing Arrangements

[0001193125-12-275547:notes:85]
1.75% Convertible Senior Notes Due 2013

[0001193125-12-275547:notes:86]
On June 10, 2008, we issued $1,265.0 million aggregate principal amount of the Notes. The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.75% per annum. The Notes will mature on June 1, 2013 unless earlier repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified below, based on an initial conversion rate of 31.40 shares of common stock per $1,000 principal amount of Notes (which represents an initial effective conversion price of the Notes of $31.85 per share), subject to adjustment as described in the indenture governing the Notes.

[0001193125-12-275547:notes:87]
The Notes are not redeemable by us prior to the maturity date. In the event of a fundamental change (as defined in the indenture for the Notes), holders of the Notes may require us to repurchase all or a portion of their Notes at a repurchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid interest, if any, to, but excluding, the fundamental change repurchase date.

[0001193125-12-275547:notes:88]
The holders of the Notes may convert their Notes until the close of business on the scheduled trading day immediately preceding the maturity date if any of the following conditions are met: (1) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price of the Notes for each day in the measurement period was less than 98% of an amount equal to (i) the last reported sale price of our common stock multiplied by (ii) the conversion rate for the Notes on each such day; (2) during any calendar quarter (and only during such calendar quarter) if the last reported sale price of our common stock for 20 or more trading days in a period of 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter exceeds 130% of the applicable conversion price in effect for the Notes on the last trading day of such immediately preceding calendar quarter; or (3) upon the occurrence of specified corporate transactions set forth in the indenture for the Notes. On or after March 1, 2013, until the scheduled trading day immediately preceding the maturity date, holders of the Notes may convert their Notes regardless of the foregoing conditions. Upon conversion, a holder will receive cash in an amount equal to the lesser of the conversion value and the principal amount of the Notes, and any shares of our common stock for any conversion value in excess of the principal amount of the Notes, if any. Holders of the Notes who convert their Notes in connection with a fundamental change will, under certain circumstances, be entitled to a make-whole premium in the form of an increase in the conversion rate.

[0001193125-12-275547:notes:89]
Our common stock price exceeded the conversion threshold for the Notes for at least 20 trading days during the 30 consecutive trading days ended March 31, 2012 and 2011. Accordingly, as of April 27, 2012 and April 29, 2011, the Notes were convertible at the option of the holder and, therefore, the carrying value of the Notes was classified as short-term debt. Since the Notes were convertible at the option of the holder and the principal amount would have been required to be paid in cash, the difference between the principal amount and the carrying value of the Notes was reflected as convertible debt in mezzanine on our consolidated balance sheets as of April 27, 2012 and April 29, 2011.

[0001193125-12-275547:notes:90]
The determination of whether or not the Notes are convertible must continue to be performed quarterly. Consequently, the Notes may continue to be convertible in future quarters. If the Notes were to continue to be convertible at the option of the holder and the principal amount would be required to be paid in cash, the difference between the principal amount and the carrying value of the Notes would continue to be reflected as convertible debt in mezzanine on our consolidated balance sheets.

[0001193125-12-275547:notes:91]
Upon conversion of any Notes, we deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal amount of the Notes, shares of our common stock. As of April 27, 2012, shares issued related to the Notes were minimal. Based on the closing price of our common stock of $39.03 on April 27, 2012, the if-converted value of our Notes exceeded their principal amount by approximately $285.3 million.

[0001193125-12-275547:notes:92]
We separately account for the liability and equity components of the Notes. The initial debt component of the Notes was valued at $1,017.0 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 6.31%, with the equity component representing the residual amount of the proceeds of $248.0 million which was recorded as a debt discount. Issuance costs were allocated pro-rata based on the relative initial carrying amounts of the debt and equity components. As a result, $5.2 million of the issuance costs was allocated to the equity component of the Notes, and $21.4 million of the issuance costs remained classified as other non-current assets. The debt discount and the issuance costs allocated to the debt component are amortized as additional interest expense over the term of the Notes using the effective interest method and an effective interest rate of 6.31% for all periods presented.

[0001193125-12-275547:notes:93]
The following table reflects the carrying value of the Notes (in millions):

[0001193125-12-275547:notes:94]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| 1.75% Convertible Senior Notes Due 2013 |  | $ | 1,264.9 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (62.6 | ) |  |  | (114.6 | ) |
| Net carrying amount of Notes |  | $ | 1,202.3 |  |  | $ | 1,150.4 |  |

[0001193125-12-275547:notes:95]
The following table presents the amount of interest expense recognized related to the Notes (in millions):

[0001193125-12-275547:notes:96]
The following table reflects the remaining debt discount and issuance costs as of April 27, 2012 (in millions):

[0001193125-12-275547:notes:97]
Note Hedges and Warrants

[0001193125-12-275547:notes:98]
Concurrent with the issuance of the Notes, we purchased Note hedges and sold warrants. The separate Note hedge and warrant transactions are structured to reduce the potential future economic dilution associated with the conversion of the Notes.

[0001193125-12-275547:notes:99]
|  | • |  | Note Hedges: As of April 27, 2012 and April 29, 2011, we had arrangements with counterparties to buy up to approximately 31.8 million shares, subject to anti-dilution adjustments, of our common stock at a price of $31.85 per share, subject to adjustment. The Note hedge transactions will expire at the earlier of (1) the last day on which any Notes remain outstanding or (2) the scheduled trading day immediately preceding the maturity date of the Notes. Upon exercise of the Note hedges, we have the option to receive cash or shares of our common stock equal to the difference between the then market price and the strike price of the hedges. |

[0001193125-12-275547:notes:100]
|  | • |  | Warrants: As of April 27, 2012 and April 29, 2011, we had outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |

[0001193125-12-275547:notes:101]
As of April 27, 2012, we were subject to potential dilution on the approximately 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of $31.85.

[0001193125-12-275547:notes:102]
As of April 27, 2012, we received a minimal number of shares related to the Note hedge transactions and no cash or shares were delivered related to the warrant transactions.

[0001193125-12-275547:notes:103]
Lehman Brothers OTC Derivatives, Inc. (Lehman OTC) was the counterparty to 20% of our Note hedges. The bankruptcy filing by Lehman OTC on October 3, 2008 constituted an "event of default" under the hedge transaction. In April 2010, we terminated the hedge transaction with Lehman OTC in exchange for an unsecured bankruptcy claim, which we subsequently sold to a third party for $14.2 million. Because we have decided not to replace the hedge, we are subject to potential dilution on the 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of $31.85. The terms of the Notes, the rights of the holders of the Notes and other counterparties to Note hedges and warrants were not affected by the termination of this hedge.

[0001193125-12-275547:notes:104]
Fair Value of Notes

[0001193125-12-275547:notes:105]
As of April 27, 2012, the approximate fair value of the principal amount of the Notes, which includes the debt and equity components, was approximately $1,649.9 million, or 130% of the face value of the Notes, based upon quoted market information provided by third party pricing providers (Level 1).

[0001193125-12-275547:notes:106]
Other Long-Term Financing Arrangements

[0001193125-12-275547:notes:107]
The following presents the amounts due under other long-term financing arrangements (in millions):

[0001193125-12-275547:notes:108]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 9.1 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 3.5 |  |  |  | 6.0 |  |
| Total |  | $ | 12.6 |  |  | $ | 11.5 |  |


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001193125-12-275547:notes:109]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Product |  | $ | 25.7 |  |  | $ | 106.2 |  |
| SEM and service |  |  | 2,790.2 |  |  |  | 2,208.7 |  |
| Total |  | $ | 2,815.9 |  |  | $ | 2,314.9 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,366.5 |  |  | $ | 1,226.6 |  |
| Long-term |  |  | 1,449.4 |  |  |  | 1,088.3 |  |
| Total |  | $ | 2,815.9 |  |  | $ | 2,314.9 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-12-275547:notes:110]
12. Derivatives and Hedging Activities

[0001193125-12-275547:notes:111]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place a master netting arrangement to mitigate the credit risk of our counterparty and potentially to reduce our losses due to counterparty nonperformance. All contracts have a maturity of less than six months.

[0001193125-12-275547:notes:112]
Our major foreign currency exchange exposures and related hedging programs are described below:

[0001193125-12-275547:notes:113]
Balance Sheet. We utilize monthly foreign currency forward and options contracts to hedge exchange rate fluctuations related to certain foreign-currency-denominated monetary assets and liabilities, primarily intercompany receivables and payables. These foreign currency forward and option contracts are not designated as hedging instruments and do not subject us to material balance sheet risk due to exchange rate movements because the gains and losses on these contracts are intended to offset the gains and losses in the underlying foreign-currency-denominated monetary assets and liabilities being hedged and the net amount is included in earnings.

[0001193125-12-275547:notes:114]
Forecasted Transactions. We use currency forward contracts to hedge exposures related to forecasted sales denominated in certain foreign currencies. These contracts are designated and qualify as cash flow hedges and in general, closely match the underlying forecasted transactions in duration. The contracts are carried on the consolidated balance sheets at fair value, and the effective portion of the contracts' gains and losses resulting from changes in fair value is recorded in AOCI until the forecasted transaction is recognized in the consolidated statements of operations. When the forecasted transaction occurs, we reclassify the related gains or losses on the cash flow hedges into net revenues. If the underlying forecasted transactions do not occur, or it becomes probable that they will not occur, within the defined hedge period, the gains or losses on the related cash flow hedges are reclassified from AOCI and recognized immediately in earnings. We measure the effectiveness of hedges of forecasted transactions on a monthly basis by comparing the fair values of the designated currency forward contracts with the fair values of the forecasted transactions. Any ineffective portion of the derivative hedging gain or loss, as well as changes in the fair value of the derivative's time value (which are excluded from the assessment of hedge effectiveness), is recognized in current period earnings.

[0001193125-12-275547:notes:115]
Over the next 12 months, we expect an immaterial amount of derivative net losses recorded in AOCI as of April 27, 2012 will be reclassified into net revenues. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is six months.

[0001193125-12-275547:notes:116]
The notional value of our outstanding foreign currency forward purchase contracts that were entered into to hedge forecasted foreign denominated sales and our foreign-currency-denominated monetary asset and liability exposures consisted of the following (in millions):

[0001193125-12-275547:notes:117]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Euro |  | $ | 96.9 |  |  | $ | 104.0 |  |
| British Pound Sterling |  |  | 29.8 |  |  |  | 20.9 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Euro |  |  | 267.4 |  |  |  | 253.7 |  |
| British Pound Sterling |  |  | 86.4 |  |  |  | 70.8 |  |
| Australian Dollar |  |  | 54.3 |  |  |  | 34.4 |  |
| Canadian Dollar |  |  | 38.5 |  |  |  | 56.0 |  |
| Other |  |  | 68.5 |  |  |  | 52.6 |  |

[0001193125-12-275547:notes:118]
As of April 27, 2012 and April 29, 2011, the fair value of our short-term foreign currency contracts was not material. We did not recognize any gains and losses in earnings due to hedge ineffectiveness for any period presented.

[0001193125-12-275547:notes:119]
The effect of derivative instruments designated as cash flow hedges recognized in net revenues on our consolidated statements of operations was as follows (in millions):

[0001193125-12-275547:notes:120]
|  |  | Year ended April 27, 2012 |  |  | Year Ended April 29, 2011 |  |  | Year Ended April 30, 2010 |  |
| Derivatives in Cash Flow HedgingRelationships |  | GainRecognized inAOCI |  |  | GainReclassifiedfromAOCI intoIncome |  |  | GainRecognizedin AOCI |  |  | GainReclassifiedfromAOCI intoIncome |  |  | LossRecognizedin AOCI |  |  | LossReclassifiedfromAOCI intoIncome |  |
| Foreign exchange forward purchase contracts |  | $ | 20.6 |  |  | $ | 18.9 |  |  | $ | 3.2 |  |  | $ | 6.1 |  |  | $ | (0.5 | ) |  | $ | (1.7 | ) |

[0001193125-12-275547:notes:121]
The effect of derivative instruments not designated as hedges recognized in other income (expense), net on our consolidated statements of operations was as follows (in millions):

[0001193125-12-275547:notes:122]
|  |  | Year Ended |  |
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |  | April 30, 2010 |  |
| Derivatives Not Designated as Hedging Instruments |  | Gain (Loss) Recognized into Income |  |
| Foreign exchange forward contracts |  | $ | 21.0 |  |  | $ | (20.6 | ) |  | $ | 8.2 |  |


## us-gaap:DerivativesPolicyTextBlock

[0001193125-12-275547:notes:123]
Derivative Instruments — Derivatives that are not designated as hedges are adjusted to fair value through earnings. If the derivative is designated as a cash flow hedge, the effective portion of the contracts' gains and losses resulting from changes in fair value is recognized in AOCI until the forecasted transaction is recognized in earnings. The ineffective portion of the hedge is recognized in earnings immediately.

[0001193125-12-275547:notes:124]
As a result of our significant international operations, we are subject to risks associated with fluctuating exchange rates. We use derivative financial instruments, principally currency forward contracts and currency options, to attempt to minimize the impact of exchange rate movements on our balance sheet and operating results. Factors that could have an impact on the effectiveness of our hedging program include the accuracy of forecasts and the volatility of foreign currency markets. These programs reduce, but do not always entirely eliminate, the impact of currency exchange movements. The maturities of these instruments are generally less than one year.

[0001193125-12-275547:notes:125]
Currently, we do not enter into any foreign exchange forward contracts to hedge exposures related to firm commitments or nonmarketable investments. Cash flows from our derivative programs are included under operating activities in the consolidated statements of cash flows with the exception of cash flows from the derivatives used to hedge the 1.75% Convertible Senior Notes due 2013 (the Notes). The cash flows related to the Note hedges are included under financing activities.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-12-275547:notes:126]
Net Income per Share — Basic net income per share is computed by dividing income available to common stockholders by the weighted average number of common shares outstanding. Diluted net income per share is computed giving effect to all dilutive potential shares that were outstanding during the period. Dilutive potential common shares consist of common shares issuable upon exercise of stock options, RSUs, ESPP shares, warrants and assumed conversion of our Notes. Repurchased shares that are held as treasury stock are excluded from the outstanding shares.


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-275547:notes:127]
14. Net Income per Share

[0001193125-12-275547:notes:128]
The following is a calculation of basic and diluted net income per share (in millions):

[0001193125-12-275547:notes:129]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 605.4 |  |  | $ | 673.1 |  |  | $ | 400.4 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average common shares outstanding |  |  | 363.9 |  |  |  | 360.9 |  |  |  | 339.7 |  |
| Weighted average common shares outstanding subject to repurchase |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (0.1 | ) |
| Shares used in basic computation |  |  | 363.9 |  |  |  | 360.9 |  |  |  | 339.6 |  |
| Weighted average common shares outstanding subject to repurchase |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.1 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 8.8 |  |  |  | 14.6 |  |  |  | 13.2 |  |
| Dilutive impact of assumed conversion of Notes |  |  | 9.4 |  |  |  | 12.7 |  |  |  | 0.3 |  |
| Dilutive impact of warrants |  |  | 2.2 |  |  |  | 5.5 |  |  |  | 0.0 |  |
| Shares used in diluted computation |  |  | 384.3 |  |  |  | 393.7 |  |  |  | 353.2 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.66 |  |  | $ | 1.87 |  |  | $ | 1.18 |  |
| Diluted |  | $ | 1.58 |  |  | $ | 1.71 |  |  | $ | 1.13 |  |

[0001193125-12-275547:notes:130]
The following potential weighted-average shares of common stock have been excluded from the diluted net income per share calculations, as their effect would have been anti-dilutive (in millions):

[0001193125-12-275547:notes:131]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Options and RSUs |  |  | 9.9 |  |  |  | 2.6 |  |  |  | 19.3 |  |

[0001193125-12-275547:notes:132]
Dilutive shares outstanding for fiscal 2010 do not include any effect resulting from warrants, as their impact would have been anti-dilutive. The Note hedges are not included in the calculation of earnings per share as their effect would have been anti-dilutive. The Note hedges, if exercised upon conversion of the Notes, are expected to reduce approximately 80% of the dilutive effect of the Notes when our stock price is above $31.85 per share.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001193125-12-275547:notes:133]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Balance at beginning of period |  | $ | 65.1 |  |  | $ | 69.0 |  |  | $ | 66.5 |  |
| Total unrealized gains (losses), net included in other comprehensive income |  |  | 0.9 |  |  |  | (1.4 | ) |  |  | 4.2 |  |
| Total realized gains included in earnings |  |  | 0.7 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Settlements |  |  | (15.7 | ) |  |  | (2.5 | ) |  |  | (1.7 | ) |
| Balance at end of period |  | $ | 51.0 |  |  | $ | 65.1 |  |  | $ | 69.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-12-275547:notes:134]
9. Financial Instruments and Fair Value

[0001193125-12-275547:notes:135]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the three levels of inputs to measure fair value:

[0001193125-12-275547:notes:136]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001193125-12-275547:notes:137]
Level 2: Inputs that reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0001193125-12-275547:notes:138]
Level 3: Unobservable inputs that reflect our own assumptions incorporated in valuation techniques used to measure fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0001193125-12-275547:notes:139]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an on-going basis, and consider an inactive market to be one in which there are infrequent or few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty's non-performance risk is considered in measuring the fair values of liabilities and assets, respectively.

[0001193125-12-275547:notes:140]
Investments

[0001193125-12-275547:notes:141]
The following is a summary of our investments (in millions):

[0001193125-12-275547:notes:142]
We record unrealized gains or losses on available-for-sale securities in AOCI. The following table shows the gross unrealized losses and fair values of our investments, aggregated by investment category and length of time that individual securities have been in a continuous unrealized loss positions, as of April 27, 2012 (in millions):

[0001193125-12-275547:notes:143]
|  |  | Less than 12 Months |  |  | 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | UnrealizedLoss |  |  | Fair Value |  |  | UnrealizedLoss |  |  | Fair Value |  |  | UnrealizedLoss |  |
| Corporate bonds |  | $ | 771.1 |  |  | $ | (1.4 | ) |  | $ | 0.0 |  |  | $ | 0.0 |  |  | $ | 771.1 |  |  | $ | (1.4 | ) |
| Auction rate securities |  |  | 4.8 |  |  |  | (0.2 | ) |  |  | 38.8 |  |  |  | (3.8 | ) |  |  | 43.6 |  |  |  | (4.0 | ) |
| U.S. treasury and government debt securities |  |  | 89.4 |  |  |  | (0.1 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 89.4 |  |  |  | (0.1 | ) |
| Total |  | $ | 865.3 |  |  | $ | (1.7 | ) |  | $ | 38.8 |  |  | $ | (3.8 | ) |  | $ | 904.1 |  |  | $ | (5.5 | ) |

[0001193125-12-275547:notes:144]
The following table shows the gross unrealized losses and fair values of our investments, aggregated by investment category and length of time that individual securities have been in a continuous unrealized loss positions, at April 29, 2011 (in millions):

[0001193125-12-275547:notes:145]
|  |  | Less than 12 Months |  |  | 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | UnrealizedLoss |  |  | Fair Value |  |  | UnrealizedLoss |  |  | Fair Value |  |  | UnrealizedLoss |  |
| Corporate bonds |  | $ | 236.7 |  |  | $ | (0.6 | ) |  | $ | 1.1 |  |  | $ | 0.0 |  |  | $ | 237.8 |  |  | $ | (0.6 | ) |
| Auction rate securities |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 51.0 |  |  |  | (4.5 | ) |  |  | 51.0 |  |  |  | (4.5 | ) |
| U.S. treasury and government debt securities |  |  | 193.4 |  |  |  | (0.7 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 193.4 |  |  |  | (0.7 | ) |
| Total |  | $ | 430.1 |  |  | $ | (1.3 | ) |  | $ | 52.1 |  |  | $ | (4.5 | ) |  | $ | 482.2 |  |  | $ | (5.8 | ) |

[0001193125-12-275547:notes:146]
The following table presents the contractual maturities of our debt investments as of April 27, 2012 (in millions):

[0001193125-12-275547:notes:147]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,322.7 |  |  | $ | 1,326.1 |  |
| Due in one through five years |  |  | 2,516.3 |  |  |  | 2,522.6 |  |
| Due after ten years* |  |  | 54.1 |  |  |  | 51.0 |  |
|  |  | $ | 3,893.1 |  |  | $ | 3,899.7 |  |

[0001193125-12-275547:notes:148]
| * | Consists of auction rate securities which have contractual maturities of greater than 10 years. |

[0001193125-12-275547:notes:149]
Fair Value of Financial Instruments

[0001193125-12-275547:notes:150]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis as of April 27, 2012 (in millions):

[0001193125-12-275547:notes:151]
|  |  |  |  |  | Fair Value Measurements at Reporting DateUsing |  |
|  |  | Total |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,673.3 |  |  | $ | 0.0 |  |  | $ | 2,673.3 |  |  | $ | 0.0 |  |
| U.S. treasuries and government debt securities |  |  | 837.8 |  |  |  | 234.3 |  |  |  | 603.5 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 164.6 |  |  |  | 0.0 |  |  |  | 164.6 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 348.2 |  |  |  | 0.0 |  |  |  | 348.2 |  |  |  | 0.0 |  |
| Money market funds |  |  | 724.8 |  |  |  | 724.8 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 51.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 51.0 |  |
| Equity funds |  |  | 25.5 |  |  |  | 25.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign currency contracts |  |  | 2.7 |  |  |  | 0.0 |  |  |  | 2.7 |  |  |  | 0.0 |  |
| Total |  | $ | 4,827.9 |  |  | $ | 984.6 |  |  | $ | 3,792.3 |  |  | $ | 51.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | 2.6 |  |  | $ | 0.0 |  |  | $ | 2.6 |  |  | $ | 0.0 |  |

[0001193125-12-275547:notes:152]
Reported as (in millions):

[0001193125-12-275547:notes:153]
We classify investments within Level 1 if quoted prices are available in active markets.

[0001193125-12-275547:notes:154]
We classify items in Level 2 if the investments are valued using observable inputs to quoted market prices, benchmark yields, reported trades, broker/dealer quotes or alternative pricing sources with reasonable levels of price transparency. Investments are held by a custodian who prices some of the investments themselves using standard inputs in various asset price models or obtains investment prices from a third party pricing provider that incorporates standard inputs in various asset price models. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 financial instruments. As of April 27, 2012 and April 29, 2011, we have not made any adjustments to the prices obtained from our third party pricing providers.

[0001193125-12-275547:notes:155]
The unrealized losses on our available-for-sale investments in corporate bonds were caused by market value declines as a result of the economic environment, as well as fluctuations in market interest rates. Because the decline in market value is attributable to changes in market conditions and not credit quality, and because we neither intend to sell nor are likely to be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of April 27, 2012.

[0001193125-12-275547:notes:156]
Our foreign currency derivative contracts are classified within Level 2 as the valuation inputs are based on quoted market prices of similar instruments in active markets. We determine the fair value of these instruments by considering the estimated amount we would pay or receive to terminate these agreements at the reporting date. We use observable inputs, including quoted prices in active markets for similar assets or liabilities.

[0001193125-12-275547:notes:157]
We classify auction rate securities as Level 3 investments, which are valued using a pricing model, based on unobservable inputs in the market or that require us to develop our own assumptions.

[0001193125-12-275547:notes:158]
Quantitative information about our Level 3 fair value measurements is as follows (fair value in millions):

[0001193125-12-275547:notes:159]
|  |  | Fair Value atApril 27, 2012 |  | Valuation Techniques |  | Unobservable Inputs |  |  | Range (Weighted average) |
| ARSs |  | $ 51.0 |  | Discounted cash flow |  |  | Time-to-economic maturity |  |  | 6.4 yrs - 16.1 yrs (10.2 yrs) |
|  |  |  |  |  |  |  | Liquidity risk premium,market credit spread andother factors |  |  | 1.8% - 3.2% (2.2%) |
|  |  |  |  |  |  |  | Coupon rate |  |  | 1.2% - 3.2% (1.8%) |
|  |  |  |  | Market comparable securities |  |  | Discount rate |  |  | 4.7% - 12.6% (8.6%) |

[0001193125-12-275547:notes:160]
As of April 27, 2012 and April 29, 2011, we had ARSs with a par value of $55.6 million and $71.3 million, respectively, and an estimated fair value of $51.0 million and $65.1 million, respectively. All of our ARSs are classified as other non-current assets and are backed by pools of student loans guaranteed by the U.S. Department of Education. As of April 27, 2012, we recorded cumulative net temporary impairment charges of $3.1 million in AOCI and had recognized cumulative other-than-temporary impairments of $1.4 million in our results of operations. Prior to the three months ended October 28, 2011, we estimated the fair value for each individual ARS using an income (discounted cash flow) approach that incorporates both observable and unobservable inputs to discount the expected future cash flows. Key inputs into the discounted cash flow analysis include the time-to-economic maturity, liquidity risk premium, market credit spread and other factors and a coupon rate. Beginning October 28, 2011, we included the market approach to the valuation technique in order to incorporate secondary market activity into our estimated fair value for each individual ARS. This change had no material impact on the valuation of our ARS portfolio. The key input into the market approach is a discount rate. A significant increase (decrease) in the time-to-economic maturity, liquidity risk premium, market credit spread and other factors, coupon rate and discount rate could result in a significantly lower (higher) fair value estimate. We review the fair value of our Level 3 financial instruments for overall reasonableness by reviewing service provider pricing methodologies, key inputs and assumptions and by understanding the processes used by our third-party service providers. Based on our ability to access our cash and other short-term investments, our expected operating cash flows, and our other sources of cash, we do not intend to sell these investments prior to recovery of value. We will continue to monitor our ARS investments in light of the current debt market environment and evaluate these investments for impairment and classification.

[0001193125-12-275547:notes:161]
The table below provides a reconciliation of the beginning and ending balance of our Level 3 auction rate securities measured at fair value on a recurring basis using significant unobservable inputs as of April 27, 2012, April 29, 2011 and April 30, 2010, respectively (in millions).


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001193125-12-275547:notes:162]
Fair Value Measurements and Impairments — All of our available-for-sale investments are subject to periodic impairment review. Investments are considered to be impaired when a decline in fair value is judged to be other-than-temporary. This determination requires significant judgment.

[0001193125-12-275547:notes:163]
For short-term investments, impairment is determined based upon the specific facts and circumstances present at the time, including factors such as current economic and market conditions, the credit rating of the security's issuer, the length of time an investment's fair value has been below our carrying value, the extent to which fair value was below cost, and our ability and intent to hold investments for a period of time sufficient to allow for anticipated recovery in value. If an investment's decline in fair value, caused by factors other than changes in interest rates, is deemed to be other-than-temporary, we reduce its carrying value to its estimated fair value, as determined based on quoted market prices, liquidation values or other metrics. Declines in value judged to be other-than-temporary, if any, are recorded in our consolidated statements of operations as incurred.

[0001193125-12-275547:notes:164]
For long-term investments, such as auction rate securities (ARSs), impairment is determined based on fair value and marketability of these investments. The valuation models used to estimate fair value included numerous assumptions such as assessments of the underlying structure of each security, expected cash flows, discount rates, trading activity in the secondary market for similar securities, credit ratings, workout periods, and overall capital market liquidity.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001193125-12-275547:notes:165]
Foreign Currency Translation — For international subsidiaries whose functional currency is the local currency, gains and losses resulting from translation of these foreign currency financial statements into U.S. dollars are recorded in AOCI. For subsidiaries where the functional currency is the U.S. dollar, gains and losses resulting from the process of remeasuring foreign currency financial statements into U.S. dollars are included in other income (expense), net.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-12-275547:notes:166]
7. Goodwill and Other Intangible Assets, Net

[0001193125-12-275547:notes:167]
Goodwill activity is summarized as follows (in millions):

[0001193125-12-275547:notes:168]
| April 30, 2010 |  | $ | 681.0 |  |
| Additions |  |  | 79.3 |  |
| April 29, 2011 |  |  | 760.3 |  |
| Additions |  |  | 143.7 |  |
| Adjustments |  |  | 1.2 |  |
| April 27, 2012 |  | $ | 905.2 |  |

[0001193125-12-275547:notes:169]
We conducted our annual goodwill impairment test during the three months ended April 27, 2012. Based on this analysis, we determined that there was no impairment to goodwill. We will continue to monitor our recorded goodwill for indicators of impairment.

[0001193125-12-275547:notes:170]
Other intangible assets, net are summarized as follows (in millions):

[0001193125-12-275547:notes:171]
|  |  | April 27, 2012 |  |  | April 29, 2011 |  |
|  |  | GrossCarryingAmount |  |  | AccumulatedAmortization |  |  | OtherIntangibleAssets, Net |  |  | GrossCarryingAmount |  |  | AccumulatedAmortization |  |  | OtherIntangibleAssets, Net |  |
| Developed technology |  | $ | 282.1 |  |  | $ | (79.0 | ) |  | $ | 203.1 |  |  | $ | 66.1 |  |  | $ | (23.2 | ) |  | $ | 42.9 |  |
| Customer contracts/relationships |  |  | 59.4 |  |  |  | (32.7 | ) |  |  | 26.7 |  |  |  | 12.0 |  |  |  | (4.6 | ) |  |  | 7.4 |  |
| Trademarks and trade names |  |  | 14.7 |  |  |  | (9.7 | ) |  |  | 5.0 |  |  |  | 7.7 |  |  |  | (5.5 | ) |  |  | 2.2 |  |
| Covenants not to compete |  |  | 2.2 |  |  |  | (1.0 | ) |  |  | 1.2 |  |  |  | 0.6 |  |  |  | (0.1 | ) |  |  | 0.5 |  |
| Total other intangible assets |  | $ | 358.4 |  |  | $ | (122.4 | ) |  | $ | 236.0 |  |  | $ | 86.4 |  |  | $ | (33.4 | ) |  | $ | 53.0 |  |

[0001193125-12-275547:notes:172]
Amortization expense for other intangible assets is summarized below (in millions):

[0001193125-12-275547:notes:173]
As of April 27, 2012, future amortization expense related to other intangible assets is as follows (in millions):

[0001193125-12-275547:notes:174]
| Fiscal Year |  | Amount |  |
| 2013 |  | $ | 84.2 |  |
| 2014 |  |  | 52.0 |  |
| 2015 |  |  | 50.6 |  |
| 2016 |  |  | 46.9 |  |
| 2017 |  |  | 2.3 |  |
| Total |  | $ | 236.0 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001193125-12-275547:notes:175]
Goodwill and Purchased Intangible Assets — Goodwill is recorded when the consideration paid for an acquisition exceeds the fair value of net tangible and intangible assets acquired. Acquisition-related intangible assets are amortized on a straight-line basis over their economic lives of four to six years for developed technology, two to eight years for customer contracts/relationships, one to three years for covenants not to compete and two to seven years for trademarks and trade names as we believe this method would most closely reflect the pattern in which the economic benefits of the assets will be consumed.

[0001193125-12-275547:notes:176]
Goodwill is measured and tested for impairment on an annual basis in the fourth quarter of our fiscal year or more frequently if we believe indicators of impairment exist. Triggering events for impairment reviews may be indicators such as adverse industry or economic trends, restructuring actions, lower projections of profitability, or a sustained decline in our market capitalization. The performance of the test involves a two-step process. The first step requires comparing the fair value of the each of our reporting units to its net book value, including goodwill. We have three reporting units, the fair values of which are determined based on an allocation of our entity level market capitalization, as determined through quoted market prices. A potential impairment exists if the fair value of the reporting unit is lower than its net book value. The second step of the process is only performed if a potential impairment exists, and it involves determining the difference between the fair value of the reporting unit's net assets other than goodwill to the fair value of the reporting unit and if the difference is less than the net book value of goodwill, an impairment exists and is recorded. We have not been required to perform this second step of the process because the fair value of our reporting units have exceeded the net book value at every measurement date.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0001193125-12-275547:notes:177]
Impairment of Long-Lived Assets — We review the carrying values of long-lived assets whenever events and circumstances, such as reductions in demand, lower projections of profitability, significant changes in the manner of our use of acquired assets, or significant negative industry or economic trends, indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. If this review indicates that there is an impairment, the impaired asset is written down to its fair value, which is typically calculated using: (i) quoted market prices and/or (ii) expected future cash flows utilizing a discount rate. Our estimates regarding future anticipated net revenue and cash flows, the remaining economic life of the products and technologies, or both, may differ from those used to assess the recoverability of assets. In that event, impairment charges or shortened useful lives of certain long-lived assets may be required, resulting in charges to our consolidated statements of operations when such determinations are made.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-275547:notes:178]
13. Income Taxes

[0001193125-12-275547:notes:179]
Income before income taxes is as follows (in millions):

[0001193125-12-275547:notes:180]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Domestic |  | $ | 211.9 |  |  | $ | 307.6 |  |  | $ | 60.2 |  |
| Foreign |  |  | 500.5 |  |  |  | 486.5 |  |  |  | 386.8 |  |
| Total |  | $ | 712.4 |  |  | $ | 794.1 |  |  | $ | 447.0 |  |

[0001193125-12-275547:notes:181]
The provision for income taxes consists of the following (in millions):

[0001193125-12-275547:notes:182]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 114.8 |  |  | $ | 113.0 |  |  | $ | 33.6 |  |
| State |  |  | 26.2 |  |  |  | (1.3 | ) |  |  | 1.5 |  |
| Foreign |  |  | 26.9 |  |  |  | 35.6 |  |  |  | 22.8 |  |
| Total current |  |  | 167.9 |  |  |  | 147.3 |  |  |  | 57.9 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (61.5 | ) |  |  | (27.5 | ) |  |  | (4.6 | ) |
| State |  |  | (16.4 | ) |  |  | 13.7 |  |  |  | (2.9 | ) |
| Foreign |  |  | 17.0 |  |  |  | (12.5 | ) |  |  | (3.8 | ) |
| Total deferred |  |  | (60.9 | ) |  |  | (26.3 | ) |  |  | (11.3 | ) |
| Provision for income taxes |  | $ | 107.0 |  |  | $ | 121.0 |  |  | $ | 46.6 |  |

[0001193125-12-275547:notes:183]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0001193125-12-275547:notes:184]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Tax computed at federal statutory rate |  | $ | 249.4 |  |  | $ | 277.9 |  |  | $ | 156.5 |  |
| State income taxes, net of federal benefit |  |  | 6.4 |  |  |  | 31.1 |  |  |  | 2.6 |  |
| Foreign earnings in lower tax jurisdictions |  |  | (162.2 | ) |  |  | (146.9 | ) |  |  | (105.2 | ) |
| Stock-based compensation |  |  | 14.4 |  |  |  | (1.3 | ) |  |  | (2.6 | ) |
| Research and experimentation credits |  |  | (10.9 | ) |  |  | (17.8 | ) |  |  | (7.8 | ) |
| Tax impact of audits |  |  | 7.3 |  |  |  | (21.1 | ) |  |  | 0.0 |  |
| Other |  |  | 2.6 |  |  |  | (0.9 | ) |  |  | 3.1 |  |
| Provision for income taxes |  | $ | 107.0 |  |  | $ | 121.0 |  |  | $ | 46.6 |  |

[0001193125-12-275547:notes:185]
The components of our deferred tax assets and liabilities are as follows (in millions):

[0001193125-12-275547:notes:186]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Reserves and accruals |  | $ | 70.2 |  |  | $ | 56.8 |  |
| Acquisition intangibles |  |  | 6.7 |  |  |  | 0.0 |  |
| Net operating loss and credit carryforwards |  |  | 97.7 |  |  |  | 120.3 |  |
| Stock-based compensation |  |  | 78.7 |  |  |  | 74.1 |  |
| Deferred revenue |  |  | 262.0 |  |  |  | 176.2 |  |
| Other |  |  | 15.1 |  |  |  | 17.4 |  |
| Gross deferred tax assets |  |  | 530.4 |  |  |  | 444.8 |  |
| Valuation allowance |  |  | (32.4 | ) |  |  | (45.5 | ) |
| Deferred tax assets, net of valuation allowance |  |  | 498.0 |  |  |  | 399.3 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Reserves and accruals |  |  | 4.7 |  |  |  | 0.0 |  |
| Acquisition intangibles |  |  | 2.2 |  |  |  | 7.4 |  |
| Property and equipment |  |  | 67.9 |  |  |  | 11.9 |  |
| 1.75% Convertible Senior Notes Due 2013 |  |  | 15.2 |  |  |  | 28.2 |  |
| Other |  |  | 2.6 |  |  |  | (1.9 | ) |
| Total deferred tax liabilities |  |  | 92.6 |  |  |  | 45.6 |  |
| Deferred tax assets, net of valuation allowance and deferred tax liabilities |  | $ | 405.4 |  |  | $ | 353.7 |  |

[0001193125-12-275547:notes:187]
Current and non-current net deferred tax assets for fiscal 2012 and 2011 are as follows (in millions):

[0001193125-12-275547:notes:188]
The valuation allowance decreased by $13.1 million and increased by $17.2 million in fiscal 2012 and 2011, respectively. During fiscal 2012, we recorded a $7.1 million valuation allowance attributable to foreign tax credit carryforwards in a foreign jurisdiction based on our future operating plans. The remaining fiscal 2012 change in valuation allowance was primarily attributable to a corresponding change in deferred tax assets. The change in valuation allowance in fiscal 2011 was primarily related to the realizability of state credit carryforwards as a result of the expected application of the California single sales factor apportionment election.

[0001193125-12-275547:notes:189]
As of April 27, 2012, the federal and state net operating loss carryforwards were approximately $354.1 million and $196.8 million, respectively, before applying tax rates for the respective jurisdictions. The federal and state tax credit carryforwards were approximately $128.1 million and $115.4 million, respectively. The federal and state net operating loss carryforwards and credits will expire in various years from fiscal 2013 through 2032. If realized, $227.7 million, tax effected, of net operating loss and tax credit carryovers will be recognized as additional paid in capital.

[0001193125-12-275547:notes:190]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001193125-12-275547:notes:191]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Balance at beginning of period |  | $ | 133.3 |  |  | $ | 134.5 |  |  | $ | 110.1 |  |
| Additions based on tax positions related to the current year |  |  | 13.0 |  |  |  | 12.5 |  |  |  | 34.9 |  |
| Additions for tax positions of prior years |  |  | 22.1 |  |  |  | 26.3 |  |  |  | 3.7 |  |
| Decreases for tax positions of prior years |  |  | (7.4 | ) |  |  | (40.0 | ) |  |  | (14.2 | ) |
| Balance at end of period |  | $ | 161.0 |  |  | $ | 133.3 |  |  | $ | 134.5 |  |

[0001193125-12-275547:notes:192]
Of the $161.0 million of unrecognized tax benefits at April 27, 2012, $106.0 million has been recorded and included in other long-term liabilities, of which $93.9 million, if recognized, would affect our provision for income taxes.

[0001193125-12-275547:notes:193]
We recognize accrued interest and penalties related to unrecognized foreign tax benefits in the income tax provision. During the fiscal years ended 2012, 2011 and 2010, we recognized accrued interest and penalties of approximately $0.6 million, $0.2 million and $0.6 million, respectively in the statement of operations and $1.6 million and $1.0 million, respectively, were recorded on balance sheet as of April 27, 2012 and April 29, 2011.

[0001193125-12-275547:notes:194]
We are subject to taxation in the United States, various states, and several foreign jurisdictions.

[0001193125-12-275547:notes:195]
The tax years that remain subject to examination for our major tax jurisdictions are shown below:

[0001193125-12-275547:notes:196]
Tax Years Subject to Examination for Major Tax Jurisdictions at April 27, 2012

[0001193125-12-275547:notes:197]
| 2005 — 2010 |  | United States — federal income tax |
| 2005 — 2010 |  | United States — state and local income tax |
| 2007 — 2011 |  | Australia |
| 2009 — 2012 |  | Germany |
| 2005 — 2010 |  | India |
| 2006 — 2011 |  | Japan |
| 2009 — 2012 |  | The Netherlands |
| 2009 — 2012 |  | United Kingdom |
| 2006 — 2010 |  | Canada |

[0001193125-12-275547:notes:198]
In addition, we are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal year 2000, in that we have net operating loss carryforwards from these years that could be subject to adjustment, if and when utilized.

[0001193125-12-275547:notes:199]
We are currently undergoing federal income tax audits in the United States and several foreign tax jurisdictions. The rights to some of our intellectual property (IP) are owned by certain of our foreign subsidiaries, and payments are made between U.S. and foreign tax jurisdictions relating to the use of this IP in a qualified cost sharing arrangement. In recent years, several other U.S. companies have had their foreign IP arrangements challenged as part of IRS examinations, which has resulted in material proposed assessments and/or litigation with respect to those companies.

[0001193125-12-275547:notes:200]
On March 26, 2012, we received a Revenue Agent's Report from the IRS for our fiscal 2005 through 2007 tax returns. On April 25, 2012, we filed a protest related to transfer pricing matters comparable to the one that was resolved in our favor in our last audit cycle. During fiscal 2012, we recorded an income tax expense of $7.3 million in connection with income tax audits. During fiscal 2011, we recognized an income tax benefit of $21.1 million in connection with the appeals settlement of our fiscal 2003 to 2004 federal income tax audit. Our fiscal 2008 through 2010 is currently under audit by the IRS.

[0001193125-12-275547:notes:201]
We are also under audit by the California Franchise Tax Board for our fiscal 2007 and 2008 California income tax returns.

[0001193125-12-275547:notes:202]
On September 17, 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 from our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. On December 19, 2011, the Danish Tax Tribunal issued a ruling that our Danish subsidiary was not liable for Danish withholding tax. The Danish tax examination agency appealed the to the Danish High Court in March 2012.

[0001193125-12-275547:notes:203]
We are in various stages of the examination and appeals process in connection with tax audits worldwide and it is difficult to determine when these examinations will be settled. It is reasonably possible that over the next twelve-month period, we may experience an increase or decrease in unrecognized tax benefits. It is not possible to determine either the magnitude or the range of any increase or decrease at this time.

[0001193125-12-275547:notes:204]
Network Appliance Systems India Pvt. Ltd., our Indian subsidiary, received a tax holiday from the Indian tax authorities attributable to its call center and research and development activities effective June 6, 2003. These activities qualify under the Software Technology Park of India (STPI) incentive for the development and manufacture of computer software and information technology enabled services. Under this tax holiday, net taxable income derived from call center and research and development activities is exempt from Indian taxation. The income tax holiday expired on March 31, 2011. Other tax and customs benefits remain available. Notwithstanding qualification for the income tax holiday, minimum alternate tax rules in India effective for us as of fiscal 2009 overrode the full tax exemption. The tax benefit from the holiday was $6.3 million and $3.1 million, in fiscal 2011 and 2010, respectively. The impact to earnings per share was $0.02 and $0.01 in fiscal 2011 and 2010, respectively.

[0001193125-12-275547:notes:205]
In April 2010 our Dutch subsidiary received a favorable tax ruling from the Dutch tax authorities effective May 1, 2010 that replaces the previous Dutch tax ruling that expired on April 30, 2010. This ruling results in both a lower level of earnings subject to tax in the Netherlands and an extension of the expiration date to April 30, 2015.

[0001193125-12-275547:notes:206]
As of April 27, 2012, the amount of accumulated unremitted earnings from our foreign subsidiaries is approximately $1,844 million. We have not provided U.S. income taxes and foreign withholding taxes on the undistributed earnings of foreign subsidiaries because we intend to permanently reinvest such earnings outside the U.S. If these foreign earnings were to be repatriated in the future, the related U.S. tax liability may be reduced by any foreign income taxes previously paid on these earnings as well as tax attributes carryforwards. Determination of the amount of unrecognized deferred tax liability related to these earnings is not practicable.


## us-gaap:IncomeTaxPolicyTextBlock

[0001193125-12-275547:notes:207]
Income Taxes — Deferred income tax assets and liabilities are provided for temporary differences that will result in tax deductions or income in future periods, as well as the future benefit of tax credit carryforwards. A valuation allowance reduces tax assets to their estimated realizable value.

[0001193125-12-275547:notes:208]
Determining the liability for uncertain tax positions requires us to make significant estimates and judgments as to whether, and the extent to which, additional taxes may be due based on potential tax audit issues in the U.S. and other tax jurisdictions throughout the world. Our estimates are based on the outcomes of previous audits, as well as the precedents set in cases in which others have taken similar tax positions to those taken by us. If we later determine that our exposure is lower or that the liability is not sufficient to cover our revised expectations, we adjust the liability and effect a related change in our tax provision during the period in which we make such a determination.

[0001193125-12-275547:notes:209]
The accounting guidance for income taxes prescribes a comprehensive model for how a company should recognize, measure, present, and disclose in its financial statements uncertain tax positions that we have taken or expect to take on a tax return (including a decision whether to file or not to file a return in a particular jurisdiction). We recognize the tax liability for uncertain income tax positions on the income tax return based on the two-step process prescribed in the interpretation. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis.

[0001193125-12-275547:notes:210]
Significant judgment is also required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.


## us-gaap:InventoryPolicyTextBlock

[0001193125-12-275547:notes:211]
Inventories — Inventories are stated at the lower of cost or market, which approximates actual cost on a first-in, first-out basis. We write down for excess and obsolete inventory based on the difference between the cost of inventory and the estimated net realizable value based upon assumptions about future demand forecasts and market conditions. At the point of a loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts or circumstances do not result in the restoration or increase in that newly established basis. In addition, we record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-12-275547:notes:212]
16. Employee Benefits and Deferred Compensation

[0001193125-12-275547:notes:213]
Employee 401(k) Plans

[0001193125-12-275547:notes:214]
We have established a 401(k) tax-deferred savings plan. Employees meeting the eligibility requirements, as defined, may contribute specified percentages of their salaries. We match 100% of the first $1,000 of employee contributions, then 50% for additional contributions, up to a maximum match of $3,000 per employee. The matched contributions vest over 3 years. The amounts we contributed to this plan were as follows (in millions):

[0001193125-12-275547:notes:215]
Deferred Compensation Plans

[0001193125-12-275547:notes:216]
We have a non-qualified deferred compensation plan that allows a group of employees within the United States to contribute base salary and commissions or incentive compensation on a tax deferred basis in excess of the IRS limits imposed on 401(k) plans. The marketable securities related to these investments that are held in a rabbi trust under non-qualified deferred compensation plans and the related deferred compensation liability under this plan were as follows (in millions):

[0001193125-12-275547:notes:217]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Deferred compensation plan assets |  | $ | 25.5 |  |  | $ | 20.2 |  |
| Deferred compensation liabilities reported as: |  |  |  |  |  |  |  |  |
| Other current liabilities |  |  | 6.3 |  |  |  | 3.7 |  |
| Other long-term liabilities |  |  | 19.2 |  |  |  | 16.5 |  |

[0001193125-12-275547:notes:218]
Postretirement Health Care Plan

[0001193125-12-275547:notes:219]
We maintain a plan to provide postretirement health and welfare benefits to certain executives who meet certain age and service requirements. Coverage continues through the duration of the lifetime of the retiree or the retiree's spouse, whichever is longer. There is no funding requirement associated with the plan and none of the benefit obligation was funded as of April 27, 2012. Assumed health care cost trend rates have a significant effect on the amounts reported for the health care plan.

[0001193125-12-275547:notes:220]
International Defined Benefit Plans

[0001193125-12-275547:notes:221]
We maintain various defined benefit plans to provide termination and postretirement benefits to certain eligible employees outside of the United States. We also have disability benefits to certain eligible employees in the United States. Eligibility is determined based on the terms of our plans and local statutory requirements. Assumed discount rates and expected long-term returns on plan assets have significant effects on the amounts reported for the defined benefit plans.

[0001193125-12-275547:notes:222]
Funded Status

[0001193125-12-275547:notes:223]
The funded status of our postretirement health care and international defined benefit plans was as follows (in millions):

[0001193125-12-275547:notes:224]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Fair value of plan assets |  | $ | 16.1 |  |  | $ | 2.2 |  |
| Benefit obligations |  |  | (38.3 | ) |  |  | (14.6 | ) |
| Unfunded obligations |  | $ | (22.2 | ) |  | $ | (12.4 | ) |

[0001193125-12-275547:notes:225]
Amounts recognized in the consolidated balance sheets were as follows (in millions):

[0001193125-12-275547:notes:226]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Other long-term liabilities |  | $ | 22.2 |  |  | $ | 12.4 |  |
| Accumulated other comprehensive income |  | $ | (4.4 | ) |  | $ | 0.0 |  |


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001193125-12-275547:notes:227]
Property and Equipment — Property and equipment are recorded at cost. Depreciation and amortization is computed using the straight-line method, generally over the following periods:

[0001193125-12-275547:notes:228]
|  |  | Depreciation Life (years) |  |
| Buildings |  |  | 40 years |  |
| Building improvements |  |  | 10 years |  |
| Furniture and fixtures |  |  | 5 years |  |
| Computer, production, engineering and other equipment |  |  | 3 years |  |
| Software |  |  | 3 to 5 years |  |
| Leasehold improvements |  |  | Shorter of remaining lease term or useful life |  |

[0001193125-12-275547:notes:229]
Construction in progress will be depreciated over the estimated useful lives of the respective assets when they are ready for use. We capitalize interest on facility assets under construction and on significant software development projects.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-12-275547:notes:230]
18. Selected Quarterly Financial Data (Unaudited)

[0001193125-12-275547:notes:231]
Selected quarterly financial data is as follows (in millions, except per share amounts):

[0001193125-12-275547:notes:232]
|  |  | Year Ended April 27, 2012 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net revenues |  | $ | 1,458.2 |  |  | $ | 1,507.0 |  |  | $ | 1,565.5 |  |  | $ | 1,702.5 |  |
| Gross profit |  |  | 896.9 |  |  |  | 913.0 |  |  |  | 908.5 |  |  |  | 995.0 |  |
| Income before income taxes |  |  | 167.1 |  |  |  | 183.9 |  |  |  | 146.9 |  |  |  | 214.5 |  |
| Net income |  |  | 139.5 |  |  |  | 165.6 |  |  |  | 119.6 |  |  |  | 180.7 |  |
| Net income per share, basic |  |  | 0.38 |  |  |  | 0.46 |  |  |  | 0.33 |  |  |  | 0.50 |  |
| Net income per share, diluted |  |  | 0.34 |  |  |  | 0.44 |  |  |  | 0.32 |  |  |  | 0.47 |  |

[0001193125-12-275547:notes:233]
|  |  | Year Ended April 29, 2011 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net revenues |  | $ | 1,153.7 |  |  | $ | 1,251.0 |  |  | $ | 1,289.6 |  |  | $ | 1,428.3 |  |
| Gross profit |  |  | 737.8 |  |  |  | 816.5 |  |  |  | 846.2 |  |  |  | 928.2 |  |
| Income before income taxes |  |  | 171.0 |  |  |  | 202.3 |  |  |  | 212.7 |  |  |  | 208.1 |  |
| Net income |  |  | 150.7 |  |  |  | 175.4 |  |  |  | 186.4 |  |  |  | 160.6 |  |
| Net income per share, basic |  |  | 0.43 |  |  |  | 0.49 |  |  |  | 0.51 |  |  |  | 0.44 |  |
| Net income per share, diluted |  |  | 0.40 |  |  |  | 0.45 |  |  |  | 0.46 |  |  |  | 0.40 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001193125-12-275547:notes:234]
Revenue Recognition — We recognize revenue when:

[0001193125-12-275547:notes:235]
|  | • |  | Persuasive evidence of an arrangement exists: It is our customary practice to have a purchase order and/or contract prior to recognizing revenue on an arrangement from our end users, customers, value-added resellers, or distributors. |

[0001193125-12-275547:notes:236]
|  | • |  | Delivery has occurred: Our product is physically delivered to our customers, generally with standard transfer terms such as FOB origin. We typically do not allow for restocking rights with any of our value-added resellers or distributors. Products shipped with acceptance criteria or return rights are not recognized as revenue until all criteria are achieved. If undelivered products or services exist that are essential to the functionality of the delivered product in an arrangement, delivery is not considered to have occurred. |

[0001193125-12-275547:notes:237]
|  | • |  | The fee is fixed or determinable: Arrangements with payment terms extending beyond our standard terms, conditions and practices are not considered to be fixed or determinable. Revenue from such arrangements is recognized at the earlier of customer payment or when the fees become due and payable. We typically do not allow for price-protection rights with any of our value-added resellers or distributors. |

[0001193125-12-275547:notes:238]
|  | • |  | Collection is reasonably assured: If there is considerable doubt surrounding the credit worthiness of a customer at the outset of an arrangement, the associated revenue is deferred and recognized upon cash receipt. |

[0001193125-12-275547:notes:239]
Our multiple element arrangements include our systems and one or more of the following undelivered elements: software entitlements and maintenance (SEM), premium hardware maintenance, and storage review services. Our SEM entitle our customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, bug fixes, and patch releases. Premium hardware maintenance services include contracts for technical support and minimum response times. Revenues from SEM, premium hardware maintenance services and storage review services are recognized ratably over the contractual term, generally from one to five years. We also offer extended service contracts (which extend our standard parts warranty and may include premium hardware maintenance) at the end of the warranty term; revenues from these contracts are recognized ratably over the contract term. We also sell professional services either on a time and materials basis or under fixed price projects; we recognize revenue for these services as they are performed. Revenue from hardware installation services is recognized in the period the services are delivered.

[0001193125-12-275547:notes:240]
In October 2009, the Financial Accounting Standards Board (FASB) amended the accounting standards for revenue recognition to exclude tangible products containing software components and non-software components that function together to deliver the tangible product's essential functionality from the scope of the software revenue recognition guidance. Concurrently, the FASB also amended the accounting standards for multiple deliverable revenue arrangements to:

[0001193125-12-275547:notes:241]
|  | • |  | provide updated guidance on whether multiple deliverables exist, how the deliverables in an arrangement should be separated, and how the arrangement consideration should be allocated among its elements; |

[0001193125-12-275547:notes:242]
|  | • |  | require an entity to allocate revenue in an arrangement that has separate units of accounting using best estimated selling prices (BESP) of deliverables if a vendor does not have vendor-specific objective evidence (VSOE) of fair value or third-party evidence of selling price (TPE); and |

[0001193125-12-275547:notes:243]
|  | • |  | eliminate the use of the residual method and require an entity to allocate revenue using the relative selling price method to the separate units of accounting. |

[0001193125-12-275547:notes:244]
We adopted these standards in fiscal 2011 for new and materially modified revenue arrangements originating after April 30, 2010.

[0001193125-12-275547:notes:245]
The majority of our products are hardware systems containing software components that function together to provide the essential functionality of the product. Therefore, our hardware systems and software components essential to the functionality of the hardware systems are considered non-software deliverables and therefore are not subject to industry-specific software revenue recognition guidance.

[0001193125-12-275547:notes:246]
Our product revenues also include revenues from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the guidance, a delivered item is accounted for as a separate unit if the delivered item has standalone value and if the customer has a general right of return relative to the delivered item, delivery or performance of the undelivered item is probable and substantially within our control. Both of the separation criteria must be met in order for a delivered item to be accounted for as a separate unit.

[0001193125-12-275547:notes:247]
For transactions entered into or materially modified after April 30, 2010, we recognize revenue in accordance with the accounting standards when applicable. Certain arrangements with multiple deliverables may continue to have software deliverables that are subject to the existing software revenue recognition guidance along with non-software deliverables that are subject to the standards. The revenue for these multiple element arrangements is allocated to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement using the selling price hierarchy set forth in the standards.

[0001193125-12-275547:notes:248]
For our non-software deliverables, we recognize revenue based on the standards and allocate the arrangement consideration based on the relative selling price of the deliverables. For our non-software deliverables, we use BESP as our selling price. For our software entitlements and support services, we generally use VSOE as our selling price. When we are unable to establish selling prices using VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement consideration.

[0001193125-12-275547:notes:249]
VSOE of fair value for elements of an arrangement is based upon the normal pricing and discounting practices for those services when sold separately. In determining VSOE, we require that a substantial majority of the selling prices for an element fall within a reasonably narrow pricing range, generally evidenced by a substantial majority of such historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer classifications, and other variables in determining VSOE.

[0001193125-12-275547:notes:250]
When VSOE cannot be established, we attempt to establish the selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, we typically are not able to determine TPE for our products or services.

[0001193125-12-275547:notes:251]
When we are unable to establish the selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

[0001193125-12-275547:notes:252]
We regularly review VSOE, TPE, and BESP and maintain internal controls over the establishment and updates of these estimates.

[0001193125-12-275547:notes:253]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal year 2011, we recognize revenue based on software revenue recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be delivered at a future date and VSOE of fair value of all undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is SEM and/or service. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the contract fee is recognized as product revenues. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire arrangement is recognized ratably over the maintenance period.

[0001193125-12-275547:notes:254]
We record reductions to revenue for estimated sales returns at the time of shipment. Sales returns are estimated based on historical sales returns, current trends, and our expectations regarding future experience. We monitor and analyze the accuracy of sales returns estimates by reviewing actual returns and adjust them for future expectations to determine the adequacy of our current and future reserve needs. If actual future returns and allowances differ from past experience, additional allowances may be required.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-12-275547:notes:255]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Accumulated foreign currency translation adjustments |  | $ | 4.9 |  |  | $ | 11.6 |  |
| Accumulated defined benefit obligation adjustments |  |  | (4.4 | ) |  |  | 0.0 |  |
| Accumulated unrealized gains on available-for-sale securities |  |  | 4.9 |  |  |  | 3.4 |  |
| Accumulated unrealized losses on derivatives instruments |  |  | (0.5 | ) |  |  | (2.2 | ) |
| Total accumulated other comprehensive income |  | $ | 4.9 |  |  | $ | 12.8 |  |


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001193125-12-275547:notes:256]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Cash |  | $ | 649.8 |  |  | $ | 1,169.1 |  |
| Cash equivalents |  |  | 900.0 |  |  |  | 1,588.2 |  |
| Cash and cash equivalents |  | $ | 1,549.8 |  |  | $ | 2,757.3 |  |


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001193125-12-275547:notes:257]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| United States |  | $ | 2,697.6 |  |  | $ | 3,037.5 |  |
| International |  |  | 2,763.8 |  |  |  | 2,211.8 |  |
| Total |  | $ | 5,461.4 |  |  | $ | 5,249.3 |  |


## us-gaap:ScheduleOfCompensationCostForShareBasedPaymentArrangementsAllocationOfShareBasedCompensationCostsByPlanTableTextBlock

[0001193125-12-275547:notes:258]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Employee stock options |  | $ | 55.4 |  |  | $ | 53.7 |  |  | $ | 61.1 |  |
| RSU's |  |  | 153.9 |  |  |  | 88.9 |  |  |  | 64.1 |  |
| ESPP |  |  | 48.3 |  |  |  | 32.6 |  |  |  | 34.3 |  |
| Change in amounts capitalized in inventory |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.3 |  |
| Total stock-based compensation expense |  | $ | 257.6 |  |  | $ | 175.2 |  |  | $ | 159.8 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-12-275547:notes:259]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Cost of product revenues |  | $ | 5.4 |  |  | $ | 3.6 |  |  | $ | 4.0 |  |
| Cost of service revenues |  |  | 17.8 |  |  |  | 14.4 |  |  |  | 14.3 |  |
| Sales and marketing |  |  | 126.0 |  |  |  | 81.5 |  |  |  | 73.7 |  |
| Research and development |  |  | 74.1 |  |  |  | 44.5 |  |  |  | 38.5 |  |
| General and administrative |  |  | 34.3 |  |  |  | 31.2 |  |  |  | 29.3 |  |
| Total stock-based compensation expense |  | $ | 257.6 |  |  | $ | 175.2 |  |  | $ | 159.8 |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001193125-12-275547:notes:260]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| United States |  | $ | 1,038.9 |  |  | $ | 840.2 |  |
| International |  |  | 98.3 |  |  |  | 71.4 |  |
| Total |  | $ | 1,137.2 |  |  | $ | 911.6 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-12-275547:notes:261]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Purchased components |  | $ | 30.9 |  |  | $ | 7.6 |  |
| Finished goods |  |  | 130.6 |  |  |  | 100.9 |  |
| Inventories |  | $ | 161.5 |  |  | $ | 108.5 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001193125-12-275547:notes:262]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Auction rate securities |  | $ | 51.0 |  |  | $ | 65.1 |  |
| Restricted cash |  |  | 2.6 |  |  |  | 2.8 |  |
| Deferred tax assets, net |  |  | 203.8 |  |  |  | 213.2 |  |
| Other assets |  |  | 170.0 |  |  |  | 127.6 |  |
| Other non-current assets |  | $ | 427.4 |  |  | $ | 408.7 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001193125-12-275547:notes:263]
|  |  | April 27,2012 |  |  | April 29,2011 |  |
| Deferred tax assets, net |  | $ | 201.6 |  |  | $ | 145.7 |  |
| Prepaid expenses and other current assets |  |  | 225.4 |  |  |  | 188.4 |  |
| Short-term restricted cash |  |  | 8.6 |  |  |  | 5.3 |  |
| Other current assets |  | $ | 435.6 |  |  | $ | 339.4 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-12-275547:notes:264]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Arrow Electronics, Inc. |  | $ | 1,035.7 |  |  | $ | 903.0 |  |  | $ | 550.7 |  |
| Avnet, Inc. |  |  | 753.6 |  |  |  | 639.0 |  |  |  | 444.0 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001193125-12-275547:notes:265]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Americas (United States, Canada and Latin America)* |  | $ | 3,529.7 |  |  | $ | 2,899.0 |  |  | $ | 2,208.1 |  |
| Europe, Middle East and Africa |  |  | 1,936.5 |  |  |  | 1,719.1 |  |  |  | 1,329.1 |  |
| Asia Pacific and Japan |  |  | 767.0 |  |  |  | 504.5 |  |  |  | 394.2 |  |
| Net revenues |  | $ | 6,233.2 |  |  | $ | 5,122.6 |  |  | $ | 3,931.4 |  |

[0001193125-12-275547:notes:266]
| * | Americas revenues consist of Americas commercial and U.S. public sector markets. Sales to customers inside the United States comprised $3,027.8 million, $2,593.2 million and $1,971.7 million of Americas net revenues in fiscal 2012, 2011 and 2010, respectively. |


## us-gaap:ScheduleOfShareBasedCompensationArrangementByShareBasedPaymentAwardOptionsGrantsInPeriodGrantDateIntrinsicValueTableTextBlock

[0001193125-12-275547:notes:267]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Weighted-average fair value per share granted |  | $ | 16.70 |  |  | $ | 15.83 |  |  | $ | 9.74 |  |
| Weighted-average fair value per share of options assumed in acquisition |  |  | N/A |  |  | $ | 21.15 |  |  |  | N/A |  |
| Intrinsic value of options exercised |  | $ | 116.9 |  |  | $ | 325.3 |  |  | $ | 92.9 |  |
| Proceeds received from the exercise of stock options |  | $ | 111.1 |  |  | $ | 301.1 |  |  | $ | 165.1 |  |
| Fair value of options vested |  | $ | 71.8 |  |  | $ | 96.6 |  |  | $ | 165.6 |  |


## us-gaap:ScheduleOfShareBasedCompensationEmployeeStockPurchasePlanActivityTableTextBlock

[0001193125-12-275547:notes:268]
|  |  | Year Ended |  |
|  |  | April 27,2012 |  |  | April 29,2011 |  |  | April 30,2010 |  |
| Weighted-average fair value per right granted |  | $ | 12.87 |  |  | $ | 15.86 |  |  | $ | 8.86 |  |
| Shares issued under the ESPP |  |  | 2.6 |  |  |  | 6.0 |  |  |  | 5.1 |  |
| Weighted-average price per share issued |  | $ | 34.53 |  |  | $ | 11.50 |  |  | $ | 10.49 |  |


## us-gaap:ScheduleOfShareBasedCompensationRestrictedStockUnitsAwardActivityTableTextBlock

[0001193125-12-275547:notes:269]
|  |  | Number ofShares |  |  | Weighted-AverageGrant DateFair Value |  |
| Outstanding at April 24, 2009 |  |  | 5.5 |  |  | $ | 22.38 |  |
| RSUs granted |  |  | 3.1 |  |  |  | 29.32 |  |
| RSUs issued in Exchange |  |  | 3.2 |  |  |  | 21.73 |  |
| RSUs vested |  |  | (2.1 | ) |  |  | 24.64 |  |
| RSUs forfeitures and cancellations |  |  | (0.7 | ) |  |  | 23.39 |  |
| Outstanding at April 30, 2010 |  |  | 9.0 |  |  |  | 23.92 |  |
| RSUs granted |  |  | 4.7 |  |  |  | 49.13 |  |
| RSUs vested |  |  | (2.9 | ) |  |  | 22.52 |  |
| RSUs forfeitures and cancellations |  |  | (0.7 | ) |  |  | 27.57 |  |
| Outstanding at April 29, 2011 |  |  | 10.1 |  |  |  | 35.79 |  |
| RSUs granted |  |  | 6.5 |  |  |  | 47.17 |  |
| RSUs vested |  |  | (3.7 | ) |  |  | 30.35 |  |
| RSUs forfeitures and cancellations |  |  | (0.9 | ) |  |  | 40.91 |  |
| Outstanding at April 27, 2012 |  |  | 12.0 |  |  |  | 43.28 |  |


## us-gaap:ScheduleOfShareBasedCompensationSharesAuthorizedUnderStockOptionPlansByExercisePriceRangeTextBlock

[0001193125-12-275547:notes:270]
|  |  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range of Exercise Prices |  |  | Numberof Shares(in millions) |  |  | Weighted-AverageRemainingContractual Term(in years) |  |  | Weighted-AverageExercisePrice |  |  | Numberof Shares(in millions) |  |  | Weighted-AverageExercisePrice |  |
| $ | 0.55 |  |  | $ | 13.56 |  |  |  | 2.6 |  |  |  | 3.20 |  |  | $ | 12.65 |  |  |  | 2.0 |  |  | $ | 12.39 |  |
|  | 13.63 |  |  |  | 20.69 |  |  |  | 3.0 |  |  |  | 3.01 |  |  |  | 19.09 |  |  |  | 2.3 |  |  |  | 18.70 |  |
|  | 20.70 |  |  |  | 23.04 |  |  |  | 2.1 |  |  |  | 2.61 |  |  |  | 22.06 |  |  |  | 2.1 |  |  |  | 22.07 |  |
|  | 23.33 |  |  |  | 26.20 |  |  |  | 2.1 |  |  |  | 3.51 |  |  |  | 24.35 |  |  |  | 1.8 |  |  |  | 24.32 |  |
|  | 26.37 |  |  |  | 32.50 |  |  |  | 2.4 |  |  |  | 2.64 |  |  |  | 30.41 |  |  |  | 2.3 |  |  |  | 30.39 |  |
|  | 32.70 |  |  |  | 33.54 |  |  |  | 2.1 |  |  |  | 4.45 |  |  |  | 33.46 |  |  |  | 1.1 |  |  |  | 33.40 |  |
|  | 33.73 |  |  |  | 38.64 |  |  |  | 2.1 |  |  |  | 4.77 |  |  |  | 36.88 |  |  |  | 1.0 |  |  |  | 36.46 |  |
|  | 39.63 |  |  |  | 52.67 |  |  |  | 2.5 |  |  |  | 5.02 |  |  |  | 48.17 |  |  |  | 1.1 |  |  |  | 45.66 |  |
|  | 53.10 |  |  |  | 58.99 |  |  |  | 1.7 |  |  |  | 6.03 |  |  |  | 53.63 |  |  |  | 0.3 |  |  |  | 53.83 |  |
| $ | 0.55 |  |  | $ | 58.99 |  |  |  | 20.6 |  |  |  | 3.81 |  |  | $ | 29.98 |  |  |  | 14.0 |  |  | $ | 26.41 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-12-275547:notes:271]
|  |  | Numbersof Shares |  |  | Weighted-AverageExercisePrice |  |  | Weighted-AverageRemainingContractual Term(in years) |  |  | AggregateIntrinsicValue |  |
| Outstanding at April 24, 2009 |  |  | 66.1 |  |  | $ | 29.27 |  |  |  |  |  |  |  |  |  |
| Options granted |  |  | 7.1 |  |  |  | 26.95 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (8.5 | ) |  |  | 19.33 |  |  |  |  |  |  |  |  |  |
| Options cancelled in the Exchange |  |  | (24.5 | ) |  |  | 39.05 |  |  |  |  |  |  |  |  |  |
| Options forfeitures and cancellations |  |  | (5.0 | ) |  |  | 39.12 |  |  |  |  |  |  |  |  |  |
| Outstanding at April 30, 2010 |  |  | 35.2 |  |  |  | 23.02 |  |  |  |  |  |  |  |  |  |
| Options granted |  |  | 3.9 |  |  |  | 45.28 |  |  |  |  |  |  |  |  |  |
| Options assumed in acquisition |  |  | 0.2 |  |  |  | 16.56 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (13.8 | ) |  |  | 21.85 |  |  |  |  |  |  |  |  |  |
| Options forfeitures and cancellations |  |  | (1.0 | ) |  |  | 34.43 |  |  |  |  |  |  |  |  |  |
| Outstanding at April 29, 2011 |  |  | 24.5 |  |  |  | 26.62 |  |  |  |  |  |  |  |  |  |
| Options granted |  |  | 2.2 |  |  |  | 50.65 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (5.2 | ) |  |  | 21.54 |  |  |  |  |  |  |  |  |  |
| Options forfeitures and cancellations |  |  | (0.9 | ) |  |  | 37.23 |  |  |  |  |  |  |  |  |  |
| Outstanding at April 27, 2012 |  |  | 20.6 |  |  |  | 29.98 |  |  |  | 3.81 |  |  | $ | 234.2 |  |
| Options vested and expected to vest as of April 27, 2012 |  |  | 20.0 |  |  | $ | 29.58 |  |  |  | 3.76 |  |  | $ | 231.9 |  |
| Exercisable at April 27, 2012 |  |  | 14.0 |  |  | $ | 26.41 |  |  |  | 3.21 |  |  | $ | 189.7 |  |


## us-gaap:ScheduleOfUnrealizedLossOnInvestmentsTableTextBlock

[0001193125-12-275547:notes:272]
|  |  | Less than 12 Months |  |  | 12 Months or Greater |  |  | Total |  |
|  |  | FairValue |  |  | UnrealizedLoss |  |  | FairValue |  |  | UnrealizedLoss |  |  | FairValue |  |  | UnrealizedLoss |  |
| Corporate bonds |  | $ | 771.1 |  |  | $ | (1.4 | ) |  | $ | 0.0 |  |  | $ | 0.0 |  |  | $ | 771.1 |  |  | $ | (1.4 | ) |
| Auction rate securities |  |  | 4.8 |  |  |  | (0.2 | ) |  |  | 38.8 |  |  |  | (3.8 | ) |  |  | 43.6 |  |  |  | (4.0 | ) |
| U.S. treasury and government debt securities |  |  | 89.4 |  |  |  | (0.1 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 89.4 |  |  |  | (0.1 | ) |
| Total |  | $ | 865.3 |  |  | $ | (1.7 | ) |  | $ | 38.8 |  |  | $ | (3.8 | ) |  | $ | 904.1 |  |  | $ | (5.5 | ) |

[0001193125-12-275547:notes:273]
|  |  | Less than 12 Months |  |  | 12 Months or Greater |  |  | Total |  |
|  |  | FairValue |  |  | UnrealizedLoss |  |  | FairValue |  |  | UnrealizedLoss |  |  | FairValue |  |  | UnrealizedLoss |  |
| Corporate bonds |  | $ | 236.7 |  |  | $ | (0.6 | ) |  | $ | 1.1 |  |  | $ | 0.0 |  |  | $ | 237.8 |  |  | $ | (0.6 | ) |
| Auction rate securities |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 51.0 |  |  |  | (4.5 | ) |  |  | 51.0 |  |  |  | (4.5 | ) |
| U.S. treasury and government debt securities |  |  | 193.4 |  |  |  | (0.7 | ) |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 193.4 |  |  |  | (0.7 | ) |
| Total |  | $ | 430.1 |  |  | $ | (1.3 | ) |  | $ | 52.1 |  |  | $ | (4.5 | ) |  | $ | 482.2 |  |  | $ | (5.8 | ) |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001193125-12-275547:notes:274]
SCHEDULE II

[0001193125-12-275547:notes:275]
NETAPP, INC.

[0001193125-12-275547:notes:276]
VALUATION AND QUALIFYING ACCOUNTS

[0001193125-12-275547:notes:277]
Years Ended April 27, 2012, April 29, 2011 and April 30, 2010

[0001193125-12-275547:notes:278]
(In millions)

[0001193125-12-275547:notes:279]
| Description |  | Balance atBeginningof Period |  |  | AdditionsCharged(Credited) toCosts andExpenses |  |  | Reductionsand Write-offs |  |  | Balanceat End ofPeriod |  |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 2012 |  | $ | 0.5 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |
| 2011 |  | $ | 1.6 |  |  | $ | (0.8 | ) |  | $ | 0.3 |  |  | $ | 0.5 |  |
| 2010 |  | $ | 3.1 |  |  | $ | 0.0 |  |  | $ | 1.5 |  |  | $ | 1.6 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-275547:notes:280]
15. Segment, Geographic, and Significant Customer Information

[0001193125-12-275547:notes:281]
We operate in one reportable industry segment: the design, manufacturing, marketing, and technical support of high-performance networked storage solutions. We conduct business globally, and our sales and support activities are managed on a geographic basis. Our management reviews financial information presented on a consolidated basis, accompanied by disaggregated information it receives from its internal management system about revenues by geographic region, based on the location from which the customer relationship is managed, for purposes of allocating resources and evaluating financial performance. We do not allocate costs of revenues, research and development, sales and marketing, or general and administrative expenses to our geographic regions in this internal management system because management does not review operations or operating results, or make planning decisions, below the consolidated entity level.

[0001193125-12-275547:notes:282]
Summarized revenues by geographic region based on our internal management system and utilized by our Chief Executive Officer, who is considered our Chief Operating Decision Maker, is as follows (in millions):

[0001193125-12-275547:notes:283]
The majority of our assets, excluding cash, cash equivalents, restricted cash, investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents, restricted cash and investments held in the United States and internationally in various foreign subsidiaries (in millions):

[0001193125-12-275547:notes:284]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment, net for geographic areas based on the physical location of the assets (in millions):

[0001193125-12-275547:notes:285]
No more than ten percent of property and equipment was located in any single foreign country.

[0001193125-12-275547:notes:286]
International sales to a single foreign country that accounted for ten percent or more of net revenues are as follows (in millions):

[0001193125-12-275547:notes:287]
The following customers, each of which is a distributor, accounted for ten percent or more of our net revenues (in millions):

[0001193125-12-275547:notes:288]
The following customers accounted for ten percent or more of net accounts receivable (in millions):

[0001193125-12-275547:notes:289]
N/A — Not Applicable


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-12-275547:notes:290]
2. Significant Accounting Policies

[0001193125-12-275547:notes:291]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. Fiscal 2012 and 2011 contained 52 weeks and fiscal 2010 contained 53 weeks.

[0001193125-12-275547:notes:292]
Accounting Change — In our fourth quarter of fiscal 2012, we adopted amended standards that eliminate the option to present components of other comprehensive income as part of the consolidated statements stockholders' equity and require them to be presented either in a single continuous statement of comprehensive income or in two separate but consecutive statements. The adoption of these amended standards did impact the presentation of other comprehensive income, as we have presented two separate but consecutive statements, but did not have an impact on our financial position or results of operations.

[0001193125-12-275547:notes:293]
Use of Estimates — The preparation of the consolidated financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes, and fair value measurements. Actual results could differ materially from those estimates.

[0001193125-12-275547:notes:294]
Financial Instruments — For certain financial instruments, including accounts receivable, accounts payable and other long-term financing arrangements, the carrying amounts approximate their fair value due to their relatively short maturities. The following methods were used to estimate the fair value of each class of financial instruments for which it is practicable to estimate that value.

[0001193125-12-275547:notes:295]
Short-Term Investments — Short-term investments consist of marketable debt or equity securities which are classified as available-for-sale and are recognized at fair value. The determination of fair value is further detailed in Note 9 of the accompanying consolidated financial statements. We regularly review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to: the length of time and extent to which the fair value has been lower than the cost basis, the financial condition and near-term prospects of the investee, credit quality of the issuer, likelihood of recovery, and our intent and ability to hold the investment for a period of time sufficient to allow for any anticipated recovery in fair value. We classify our investments as current or noncurrent based on the nature of the investments and their availability for use in current operations.

[0001193125-12-275547:notes:296]
Unrealized gains and temporary losses, net of related taxes, are included with accumulated other comprehensive income (loss) (AOCI). Upon realization, those amounts are reclassified from AOCI to results of operations. The amortization of premiums and discounts on the investments and realized gains and losses related to investments are included in results of operations. Other-than-temporary impairments on available-for-sale debt securities are determined to be either credit losses or losses due to other factors. Credit losses are recognized in our results of operations and other losses are included in AOCI. Realized gains or losses on our short-term investments are calculated based on the specific identification method.

[0001193125-12-275547:notes:297]
Software Development Costs — The costs for the development of new software products and substantial enhancements to existing software products are expensed as incurred until technological feasibility has been established, at which time any additional costs would be capitalized in accordance with the accounting guidance for software. Because our current process for developing software is essentially completed concurrently with the establishment of technological feasibility, which occurs upon the completion of a working model, no costs have been capitalized for any of the periods presented.

[0001193125-12-275547:notes:298]
Internal-Use Software Development Costs — We capitalize qualifying costs, which are incurred during the application development stage, for computer software developed for or obtained for internal-use and amortize them over the software's estimated useful life.

[0001193125-12-275547:notes:299]
Business Combinations — We recognize identifiable assets acquired and liabilities assumed at their acquisition date fair values. Goodwill as of the acquisition date is measured as the excess of consideration transferred over the net of the acquisition date fair values of the assets acquired and the liabilities assumed. While we use our best estimates and assumptions as a part of the purchase price allocation process to accurately value assets acquired and liabilities assumed at the acquisition date, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001193125-12-275547:notes:300]
Product Warranties — Estimated future hardware and software warranty costs are recorded as a cost of product revenues when the related revenue is recognized, based on historical and projected warranty claim rates, historical and projected cost-per-claim and knowledge of specific project failures that are outside our typical experience. Factors that affect our warranty liability include the number of installed units subject to warranty protection, product failure rates, estimated material costs, estimated distribution costs and estimated labor costs. We assess the adequacy of our warranty accrual each quarter and adjust the amount as considered necessary. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liability would be required and could materially affect our results of operations.

[0001193125-12-275547:notes:301]
Benefit Plans — We have a postretirement health care plan and various international defined benefit plans for certain of our employees. We record actuarial gains and losses within AOCI and amortize net gains or losses in excess of 10 percent of the greater of the market value of plan assets or the plans' projected benefit obligation on a straight-line basis over the remaining estimated service life of plan participants. The measurement date for all defined benefit plans is our fiscal year end.

[0001193125-12-275547:notes:302]
Stock-Based Compensation — We measure and recognize stock-based compensation for all stock-based awards, including employee stock options, restricted stock units (RSUs) and rights to purchase shares under our employee stock purchase plan (ESPP), based on their estimated fair value, and recognize the costs in our financial statements using the single option straight-line approach over the requisite service period for the entire award.

[0001193125-12-275547:notes:303]
The fair value of employee RSUs is equal to the market value of our common stock on the grant date of the award. Calculating the fair value of employee stock options and the rights to purchase shares under the ESPP requires estimates and significant judgment. The fair value of each award grant is estimated on the grant date using the Black-Scholes option pricing model, and is not remeasured as a result of subsequent stock price fluctuations. Option-pricing models require the input of highly subjective assumptions, including the expected term of awards and the price volatility of the stock underlying such awards. Our expected term assumption is based primarily on historical exercise and post-vesting forfeiture experience. Our stock price volatility assumption is based on an implied volatility of call options and dealer quotes on call options, with terms closest to the expected term of the award, generally those having a term of twelve months. In addition, the Black-Scholes option pricing model requires a risk-free interest rate and expected dividends. The risk-free interest rate is based upon United States Treasury bills with equivalent expected terms, and the expected dividend is based on our history and expected dividend payouts. Changes in the subjective assumptions required in the valuation models may significantly affect the estimated value of our stock-based awards and the related stock-based compensation expense. Likewise, the shortening of the contractual life of our options could change the estimated exercise behavior in a manner other than currently expected.

[0001193125-12-275547:notes:304]
In addition, we estimate the number of stock-based awards that will be forfeited due to employee turnover. Our forfeiture assumption is primarily based on historical experience. Changes in the estimated forfeiture rate may have a significant effect on reported stock-based compensation expense, as the effect of adjusting the rate is recognized in the period the forfeiture estimate is changed.

[0001193125-12-275547:notes:305]
In the event of a modification of stock-based awards, if the requisite service period of the modified award is longer than the requisite service period of the original award and, both before and after the modification, it is probable that the awards will vest, we recognize the unrecognized compensation cost remaining from the original award plus the incremental compensation cost, if any, as a result of a modification in its entirety over the remaining portion of the requisite service period of the modified award.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-12-275547:notes:306]
11. Stockholders' Equity

[0001193125-12-275547:notes:307]
Equity Incentive Programs

[0001193125-12-275547:notes:308]
Acquisition Plans — We have assumed stock incentive plans in connection with some of our acquisitions. The options granted under these plans generally vest at a rate of 25% on the first anniversary of the vesting commencement dates and then ratably over the following 36 months.

[0001193125-12-275547:notes:309]
The 1999 Plan — As amended through August 30, 2011, the 1999 Stock Option Plan (the 1999 Plan) comprises five separate equity incentive programs: (i) the Discretionary Option Grant Program under which options may be granted to eligible individuals at a fixed price per share; (ii) the Stock Appreciation Rights Program under which eligible persons may be granted stock appreciation rights that allow individuals to receive the appreciation in fair market value of the shares; (iii) the Stock Issuance Program under which eligible individuals may be issued shares of common stock directly; (iv) the Performance Share and Performance Unit Program (also known as RSUs) under which eligible persons may be granted performance shares or performance units which result in payment to the participant only if performance goals or other vesting criteria are achieved; and (v) the Automatic Award Program under which nonemployee board members automatically receive equity grants at designated intervals over their period of board service.

[0001193125-12-275547:notes:310]
Under the 1999 Plan, the Board of Directors may grant to employees, nonemployee directors, and consultants and other independent advisors options to purchase shares of our common stock during their period of service. The exercise price for an incentive stock option and a nonstatutory option cannot be less than 100% of the fair market value of the common stock on the grant date. Options granted under the 1999 Plan generally vest over a four-year period. Options granted prior to April 29, 2006, have a term of no more than 10 years after the grant date and those granted after April 29, 2006 have a term of no more than seven years, subject to earlier termination upon the occurrence of certain events. The 1999 Plan prohibits the repricing of any outstanding stock option or stock appreciation right after it has been granted or to cancel any outstanding stock option or stock appreciation right and immediately replace it with a new stock option or stock appreciation right with a lower exercise price unless approved by stockholders. RSUs granted under the 1999 Plan generally vest over a four-year period with 25% vesting on each anniversary of the grant date. The 1999 Plan limits the number of shares issued under the Stock Issuance Program and the Performance Share and Performance Unit Program to 8.9 million shares plus the sum of (i) 50% of the awards cancelled and returned to the 1999 Plan and (ii) 50% of the number of shares added to the 1999 Plan after the 2009 Annual Meeting. The 1999 Plan limits the initial value of performance units a participant may receive of not more than $2.0 million. The 1999 Plan expires in August 2019.

[0001193125-12-275547:notes:311]
In fiscal 2012, the 1999 Plan was amended to increase the shares reserved for issuance under the plan by an additional 7.7 million shares. As of April 27, 2012, 14.8 million shares were available for grant under our equity incentive plans.

[0001193125-12-275547:notes:312]
Stock Options

[0001193125-12-275547:notes:313]
A summary of the activity under our stock option plans and agreements is as follows (in millions, except for the exercise price and contractual term):

[0001193125-12-275547:notes:314]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our stock on that day for all in-the-money options. As of April 27, 2012, the total unrecognized compensation expense related to stock options was $70.6 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.0 years.

[0001193125-12-275547:notes:315]
Additional information related to our stock options is summarized below (in millions, except per share information):

[0001193125-12-275547:notes:316]
The following table summarizes information about outstanding and exercisable stock options under all option plans as of April 27, 2012:

[0001193125-12-275547:notes:317]
Restricted Stock Units

[0001193125-12-275547:notes:318]
The following table summarizes activity related to our RSUs (in millions, except for the fair value):

[0001193125-12-275547:notes:319]
RSUs are converted into common stock upon vesting. Upon the vesting of RSUs, we primarily use the net share settlement approach, where a portion of the shares are withheld and retired as settlement of statutory employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001193125-12-275547:notes:320]
As of April 27, 2012, the total unrecognized compensation expense related to RSUs was $341.6 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.7 years.

[0001193125-12-275547:notes:321]
Stock Option Exchange

[0001193125-12-275547:notes:322]
In April 2009, our stockholders approved a stock option exchange program (the Exchange) pursuant to which eligible employees were able to exchange some or all of their outstanding options with an exercise price greater than or equal to $22.00 per share that were granted before June 20, 2008, whether vested or unvested, for new RSUs. In connection with the Exchange, we exchanged options to purchase 24.5 million shares of our common stock for a total of 3.2 million RSUs. The fair value of the RSUs issued was measured as the total of the unrecognized compensation cost of the options surrendered and the incremental value of the RSUs issued, measured as the excess of the fair value of the RSUs over the fair value of the options tendered immediately before the exchange. The incremental cost of the RSUs was $5.8 million. The value of the RSUs, totaling $70.1 million, is being amortized over the RSUs weighted-average vesting period of 3.5 years.

[0001193125-12-275547:notes:323]
Employee Stock Purchase Plan

[0001193125-12-275547:notes:324]
Under the ESPP, employees who elect to participate are granted options that include a purchase price adjustment provision under which the employees may purchase common stock at a 15% discount from the market value of the common stock at certain specified dates within a two-year offering period. In fiscal 2012, the ESPP was amended to increase the shares reserved for issuance by an additional 3.5 million shares of common stock. Of the 38.7 million shares authorized to be issued under the ESPP, 4.9 million shares were available for issuance as of April 27, 2012. Additional information related to the purchase rights issued under the ESPP is provided below (in millions, except per share information):

[0001193125-12-275547:notes:325]
As of April 27, 2012, the total unrecognized compensation expense related to the ESPP was $59.8 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 1.6 years.

[0001193125-12-275547:notes:326]
Stock-Based Compensation Expense

[0001193125-12-275547:notes:327]
Stock-based compensation expense included in the consolidated statements of operations is as follows (in millions):

[0001193125-12-275547:notes:328]
The following table summarizes stock-based compensation associated with each type of award (in millions):

[0001193125-12-275547:notes:329]
Stock-based compensation for the year ended April 27, 2012 includes a charge of $10.9 million related to the purchase price adjustment provision under the ESPP.

[0001193125-12-275547:notes:330]
Total income tax benefits (charges) associated with employee stock transactions and recognized in stockholders' equity were as follows (in millions):

[0001193125-12-275547:notes:331]
Valuation Assumptions

[0001193125-12-275547:notes:332]
The fair value of each award is estimated on the grant date using the Black-Scholes option pricing model, assuming no expected dividends and the following weighted-average assumptions:

[0001193125-12-275547:notes:333]
Stock Repurchase Program

[0001193125-12-275547:notes:334]
In fiscal year 2012, we repurchased 14.6 million shares of our common stock as described below. Since the May 13, 2003 inception of our stock repurchase program through April 27, 2012, we repurchased a total of 119.0 million shares of our common stock at an average price of $29.65 per share, for an aggregate purchase price of $3.5 billion. As of April 27, 2012, our Board of Directors had authorized the repurchase of up to $4.0 billion of our common stock under this stock repurchase program. As of April 27, 2012, the remaining authorized amount for stock repurchases under this program was $0.5 billion with no termination date. The stock repurchase program may be suspended or discontinued at any time.

[0001193125-12-275547:notes:335]
During fiscal years 2011 and 2010, we did not repurchase any shares of our common stock under the stock repurchase program.

[0001193125-12-275547:notes:336]
Accelerated Share Repurchase Agreements

[0001193125-12-275547:notes:337]
On July 8, 2011, we entered into a collared accelerated share repurchase agreement (ASR) with Bank of America, N.A, under which we prepaid $200.0 million to purchase shares of our common stock. The aggregate number of shares ultimately purchased was determined based on the volume weighted-average share price of our common stock over a specified period of time. The contract was settled in August 2011. The total number of shares repurchased and retired under this ASR was 4.1 million shares at a price of $48.30 per share.

[0001193125-12-275547:notes:338]
On August 19, 2011, we entered into an ASR with Wells Fargo Bank, National Association, under which we prepaid $400.0 million to purchase shares of our common stock. The aggregate number of shares ultimately purchased was determined based on the volume weighted-average share price of our common stock over a specified period of time. The contract was settled in November 2011. The total number of shares repurchased and retired under this ASR was 10.5 million shares at a price of $38.08 per share.

[0001193125-12-275547:notes:339]
Preferred Stock

[0001193125-12-275547:notes:340]
Our Board of Directors has the authority to issue up to 5.0 million shares of preferred stock and to determine the price, rights, preferences, privileges, and restrictions, including voting rights, of those shares without any further vote or action by the stockholders.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-12-275547:notes:341]
8. Balance Sheet Details

[0001193125-12-275547:notes:342]
Cash and cash equivalents (in millions):

[0001193125-12-275547:notes:343]
Inventories (in millions):

[0001193125-12-275547:notes:344]
Other current assets (in millions):

[0001193125-12-275547:notes:345]
Property and equipment, net (in millions):

[0001193125-12-275547:notes:346]
In April 2012, we exercised our option under one of our synthetic leasing arrangements to early terminate the lease and purchase the facilities, including land and buildings, for $80.0 million, which had a fair value of $44.3 million at the date of purchase. We had accounted for this leasing arrangement as an operating lease. The difference between the estimated fair value of the facilities and the $80.0 million lease obligation had been accrued as additional rent expense in our consolidated statement of operations and as a residual value guarantee obligation in our consolidated balance sheets. The early termination did not result in a material impact to our operating results.

[0001193125-12-275547:notes:347]
Software includes capitalized internal-use software development costs. The net book value of such is as follows (in millions):

[0001193125-12-275547:notes:348]
Depreciation and amortization expense related to property and equipment, net is summarized below (in millions):

[0001193125-12-275547:notes:349]
Included in depreciation and amortization expense above is amortization related to computer software, as summarized below (in millions):

[0001193125-12-275547:notes:350]
Other non-current assets (in millions):

[0001193125-12-275547:notes:351]
Short-term and long-term deferred revenue (in millions):

[0001193125-12-275547:notes:352]
Accumulated other comprehensive income (in millions):

[0001193125-12-275547:notes:353]
The components of accumulated other comprehensive income, net of related immaterial tax effects, were as follows:
