# NTAP 8-K — 0001102624-11-000758 filed 2011-11-16

## item codes, every 8-K on or before 2011-12-05

- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2011-12-05

- none on or before 2011-12-05

## item 2.02 — earnings release, exhibit 99.1

[0001102624-11-000758:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-11-000758:8k_2_02:2]
exh99_1.htm

[0001102624-11-000758:8k_2_02:3]
Exhibit 99.1 PRESS RELEASE

[0001102624-11-000758:8k_2_02:4]
| Press Contact: Ryan Lowry NetApp (408) 822-7544 ryanl@netapp.com | Investor Contact: Shauna O’Boyle NetApp (408) 822-7655 oboyle@netapp.com |

[0001102624-11-000758:8k_2_02:5]
NETAPP ANNOUNCES RESULTS FOR SECOND QUARTER FISCAL YEAR 2012

[0001102624-11-000758:8k_2_02:6]
Company Reports Q2 FY’12 Revenue of $1.507 Billion, Up 20% Year-over-Year

[0001102624-11-000758:8k_2_02:7]
Sunnyvale, Calif.—November 16, 2011—NetApp (NASDAQ: NTAP) today reported results for the second quarter of fiscal year 2012, which ended October 28, 2011. Revenues for the second quarter of fiscal year 2012 totaled $1.507 billion compared to revenues of $1.251 billion for the same period one year ago.

[0001102624-11-000758:8k_2_02:8]
For the second quarter of fiscal year 2012, GAAP net income was $165.6 million, or $0.44 per share1, compared to GAAP net income of $175.4 million, or $0.45 per share, for the same period a year ago. Non-GAAP net income for the second quarter of fiscal year 2012 was $235.5 million, or $0.63 per share2, compared to non-GAAP net income of $212.2 million, or $0.54 per share, for the same period a year ago.

[0001102624-11-000758:8k_2_02:9]
Revenues for the first six months of fiscal year 2012 totaled $2.965 billion compared to revenues of $2.405 billion for the first six months of the prior fiscal year, an increase of 23% year over year. GAAP net income for the first six months of fiscal year 2012 totaled $305.1 million, or $0.78 per share, compared to GAAP net income of $326.1 million, or $0.85 per share for the first six months of the prior fiscal year. Non-GAAP net income for the first six months of fiscal year 2012 totaled $457.8 million, or $1.17 per share, compared to non-GAAP net income of $403.1 million, or $1.05 per share for the first six months of the prior fiscal year.

[0001102624-11-000758:8k_2_02:10]
"NetApp produced record non-GAAP earnings per share in the second quarter. In aggregate, we saw strong revenue growth across most areas of our business, offset by some unexpected weakness in a handful of our largest accounts," said Tom Georgens, president and CEO. "NetApp achieved the highest number of net new customer wins in more than two and a half years this quarter, and in our 'Smart Decisions are Built on NetApp' campaign we just launched the new FAS2000 series platform built on our Data ONTAP® 8.1 operating system-all of which will drive market share gains going forward."

[0001102624-11-000758:8k_2_02:11]
Outlook

[0001102624-11-000758:8k_2_02:12]
| ● | NetApp estimates revenue for the third quarter of fiscal year 2012 to be in the range of $1.520 billion to $1.610 billion, which equates to approximately 1% to 7% sequential revenue growth and approximately 18 % to 25% year-over-year revenue growth. |

[0001102624-11-000758:8k_2_02:13]
| ● | NetApp estimates that third quarter fiscal year 2012 GAAP earnings per share will be approximately $0.36 to $0.40 per share. NetApp estimates that third quarter fiscal year 2012 non-GAAP earnings per share will be approximately $0.56 to $0.60 per share. |

[0001102624-11-000758:8k_2_02:14]
| ● | NetApp estimates that share count for the third quarter of fiscal year 2012 will increase to approximately 380 million shares, including an estimated 9 million shares from the company’s outstanding convertible notes3 and 0.5 million shares from outstanding warrants. Share count does not include the company’s outstanding note hedges which are expected to offset 80% of the dilution from the convertible notes at maturity or conversion. |

[0001102624-11-000758:8k_2_02:15]
Business Highlights

[0001102624-11-000758:8k_2_02:16]
During the second quarter of fiscal year 2012, NetApp once again was recognized for its unique corporate culture and demonstrated its commitment to delivering the solutions and technologies that help customers and partners accelerate their business. NetApp further cemented its position as a great place to work by ranking #3 on the inaugural "World’s Best Multinational Workplaces" list due to its culture of innovation focused on helping customers and partners thrive. Additionally, NetApp continued to provide the storage foundation for customers across all industries who want to achieve the flexibility and efficiency required in today’s challenging business and IT landscape. NetApp also expanded its existing solution portfolio to help customers transition to the cloud and address growing big-bandwidth requirements. Highlights for the quarter included the following:

[0001102624-11-000758:8k_2_02:17]
Milestones and Awards

[0001102624-11-000758:8k_2_02:18]
| ● | NetApp named one of the best workplaces in the world. Thanks to its culture of innovation focused on customer and partner success, NetApp was named the #3 best workplace in the world by the Great Place to Work® Institute, Inc. NetApp joins an elite group of 25 multinational companies on the inaugural list that have been recognized by their employees for their company culture and workplace environment. |

[0001102624-11-000758:8k_2_02:19]
| ● | NetApp continues to rank as one of the best places to work in the United States. In addition to its global recognition, NetApp was once again named a “best place to work,” ranking #1 in Research Triangle Park in the giant companies category and one of 50 best places to work in the Washington, DC, area. The honors are a testament to NetApp’s model company approach, strong culture, and talented employees. |

[0001102624-11-000758:8k_2_02:20]
Enterprise, Government, and Education Customers Build on NetApp Foundation to Dramatically Increase IT Efficiency and Flexibility

[0001102624-11-000758:8k_2_02:21]
| ● | Thomson Reuters leverages NetApp to transform how the legal industry gets information. Thomson Reuters built on a NetApp® shared storage infrastructure to create WestlawNext, an innovative and intuitive research tool that has set a new standard for online professional search. The NetApp foundation enables WestlawNext to search up to 50 times more data than before, return results 64% faster than other online search platforms, and meet or exceed a 99.9% uptime target that is critical for the legal community. Furthermore, improved storage performance helped Thomson Reuters save nearly $65 million in additional data center costs. |

[0001102624-11-000758:8k_2_02:22]
| ● | U.S. Department of Energy selects NetApp as storage foundation for one of the world’s most powerful supercomputers. The Sequoia supercomputer, which will be deployed in 2012 at Lawrence Livermore National Laboratory (LLNL), will leverage NetApp as its storage foundation. Sequoia is expected to be twice as fast as today’s most powerful system and will manage massive compute workloads in which real-time analytics, scalable performance, and secure storage are mission critical. |

[0001102624-11-000758:8k_2_02:23]
| ● | California universities manage skyrocketing data growth and dramatically reduce costs with NetApp. The University of San Diego (USD) recently turned to NetApp to help it effectively manage growing storage requirements as a result of an increase in high-bandwidth education applications and everyday administrative tasks. Building on a NetApp platform enabled USD to improve operational efficiencies and gain the flexibility necessary to meet its evolving IT needs. Art Center College of Design in Pasadena consolidated its storage resources onto a single, unified NetApp platform, allowing the school to more effectively manage its overall IT environment and save more than $135,000 in additional storage costs. |

[0001102624-11-000758:8k_2_02:24]
NetApp Helps Customers Transition to the Cloud and Manage Big-Bandwidth Requirements

[0001102624-11-000758:8k_2_02:25]
| ● | NetApp partners with VMware to help make cloud a reality. NetApp collaborated with VMware to deliver VMware cloud infrastructure and management on NetApp. The joint solution enables organizations to evolve to a secure cloud computing model at their own pace, gaining greater flexibility and efficiency without needing to rip and replace their existing infrastructure. With this new solution customers are able to invest resources back into the business to drive innovation and manage for the future. |

[0001102624-11-000758:8k_2_02:26]
| ● | NetApp media and entertainment solution delivers extreme performance and scalability. The NetApp media content management solution, which expands on NetApp’s existing big-bandwidth portfolio, is optimal for bandwidth-intensive environments and offers leaders in the media and entertainment industries high performance and always-available data access to maximize their collaborative efforts and workflow processes. |

[0001102624-11-000758:8k_2_02:27]
Webcast and Conference Call Information

[0001102624-11-000758:8k_2_02:28]
The NetApp second quarter fiscal year 2012 results conference call will be broadcast live on the Internet at investors.netapp.com on Wednesday, November 16, 2011, at 2 p.m. Pacific Time. This press release and any other information related to the call will also be posted on the Web site at that location. An audio replay Webcast will be available after 4 p.m. Pacific Time on the Web site.

[0001102624-11-000758:8k_2_02:29]
NetApp uses a hybrid format for disclosing key financial information associated with our quarterly results. Concurrent with the press release, NetApp posts a supplemental commentary with financial information and statistics to our Web site at investors.netapp.com.

[0001102624-11-000758:8k_2_02:30]
About NetApp

[0001102624-11-000758:8k_2_02:31]
NetApp creates innovative storage and data management solutions that deliver outstanding cost efficiency and accelerate business breakthroughs. Discover our passion for helping companies around the world go further, faster at www.netapp.com.

[0001102624-11-000758:8k_2_02:32]
NetApp, the NetApp logo, Go further, faster, and Data ONTAP are trademarks or registered trademarks of NetApp, Inc. All other marks are the property of their respective owners and should be treated as such.

[0001102624-11-000758:8k_2_02:33]
| 1 | GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |

[0001102624-11-000758:8k_2_02:34]
| 2 | Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our convertible debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |

[0001102624-11-000758:8k_2_02:35]
| 3 | 80% hedged on maturity or conversion of the convertible notes. |

[0001102624-11-000758:8k_2_02:36]
NetApp Usage of Non-GAAP Financials

[0001102624-11-000758:8k_2_02:37]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our convertible debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-11-000758:8k_2_02:38]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation. We have historically reported similar non-GAAP financial measures to our investors and believe that the inclusion of comparative numbers provides consistency in our financial reporting at this time.

[0001102624-11-000758:8k_2_02:39]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | October 28, 2011 |  |  | April 29, 2011 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,641.6 |  |  | $ | 5,174.7 |  |
| Accounts receivable, net |  |  | 625.2 |  |  |  | 742.6 |  |
| Inventories |  |  | 163.3 |  |  |  | 108.5 |  |
| Other current assets |  |  | 399.9 |  |  |  | 339.4 |  |
| Total current assets |  |  | 5,830.0 |  |  |  | 6,365.2 |  |
| Property and equipment, net |  |  | 1,046.1 |  |  |  | 911.6 |  |
| Goodwill and other intangible assets, net |  |  | 1,183.1 |  |  |  | 813.3 |  |
| Other non-current assets |  |  | 444.9 |  |  |  | 408.7 |  |
| Total assets |  | $ | 8,504.1 |  |  | $ | 8,498.8 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 273.2 |  |  | $ | 232.8 |  |
| Accrued compensation and other current liabilities |  |  | 602.4 |  |  |  | 763.0 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | - |  |  |  | 1,150.4 |  |
| Short-term deferred revenue |  |  | 1,246.7 |  |  |  | 1,226.6 |  |
| Total current liabilities |  |  | 2,122.3 |  |  |  | 3,372.8 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | 1,175.8 |  |  |  | - |  |
| Other long-term liabilities |  |  | 211.1 |  |  |  | 192.9 |  |
| Long-term deferred revenue |  |  | 1,191.9 |  |  |  | 1,088.3 |  |
|  |  |  | 4,701.1 |  |  |  | 4,654.0 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | - |  |  |  | 114.6 |  |
| Stockholders' equity |  |  | 3,803.0 |  |  |  | 3,730.2 |  |
| Total liabilities and stockholders' equity |  | $ | 8,504.1 |  |  | $ | 8,498.8 |  |

[0001102624-11-000758:8k_2_02:40]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2011 |  |  | October 29, 2010 |  |  | October 28, 2011 |  |  | October 29, 2010 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,016.2 |  |  | $ | 824.8 |  |  | $ | 1,981.9 |  |  | $ | 1,562.3 |  |
| Software entitlements and maintenance |  |  | 198.0 |  |  |  | 176.7 |  |  |  | 396.2 |  |  |  | 350.9 |  |
| Service |  |  | 292.8 |  |  |  | 249.5 |  |  |  | 587.1 |  |  |  | 491.5 |  |
| Net revenues |  |  | 1,507.0 |  |  |  | 1,251.0 |  |  |  | 2,965.2 |  |  |  | 2,404.7 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 460.7 |  |  |  | 324.3 |  |  |  | 898.1 |  |  |  | 634.5 |  |
| Cost of software entitlements and maintenance |  |  | 5.6 |  |  |  | 3.5 |  |  |  | 10.9 |  |  |  | 6.9 |  |
| Cost of service |  |  | 127.7 |  |  |  | 106.7 |  |  |  | 246.3 |  |  |  | 209.0 |  |
| Total cost of revenues |  |  | 594.0 |  |  |  | 434.5 |  |  |  | 1,155.3 |  |  |  | 850.4 |  |
| Gross profit |  |  | 913.0 |  |  |  | 816.5 |  |  |  | 1,809.9 |  |  |  | 1,554.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 454.1 |  |  |  | 382.8 |  |  |  | 908.9 |  |  |  | 737.0 |  |
| Research and development |  |  | 199.7 |  |  |  | 156.6 |  |  |  | 398.3 |  |  |  | 306.1 |  |
| General and administrative |  |  | 65.1 |  |  |  | 64.2 |  |  |  | 130.2 |  |  |  | 120.4 |  |
| Restructuring and other charges |  |  | - |  |  |  | 0.1 |  |  |  | - |  |  |  | 0.1 |  |
| Acquisition-related expense |  |  | 1.7 |  |  |  | - |  |  |  | 3.9 |  |  |  | 0.3 |  |
| Total operating expenses |  |  | 720.6 |  |  |  | 603.7 |  |  |  | 1,441.3 |  |  |  | 1,163.9 |  |
| Income from operations |  |  | 192.4 |  |  |  | 212.8 |  |  |  | 368.6 |  |  |  | 390.4 |  |
| Other expense, net |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 8.3 |  |  |  | 9.5 |  |  |  | 18.9 |  |  |  | 19.3 |  |
| Interest expense |  |  | (16.4 | ) |  |  | (18.6 | ) |  |  | (35.8 | ) |  |  | (37.2 | ) |
| Other income (expense), net |  |  | (0.4 | ) |  |  | (1.4 | ) |  |  | (0.7 | ) |  |  | 0.8 |  |
| Total other expense, net |  |  | (8.5 | ) |  |  | (10.5 | ) |  |  | (17.6 | ) |  |  | (17.1 | ) |
| Income before income taxes |  |  | 183.9 |  |  |  | 202.3 |  |  |  | 351.0 |  |  |  | 373.3 |  |
| Provision for income taxes |  |  | 18.3 |  |  |  | 26.9 |  |  |  | 45.9 |  |  |  | 47.2 |  |
| Net income |  | $ | 165.6 |  |  | $ | 175.4 |  |  | $ | 305.1 |  |  | $ | 326.1 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.46 |  |  | $ | 0.49 |  |  | $ | 0.83 |  |  | $ | 0.92 |  |
| Diluted |  | $ | 0.44 |  |  | $ | 0.45 |  |  | $ | 0.78 |  |  | $ | 0.85 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 361.5 |  |  |  | 359.1 |  |  |  | 365.9 |  |  |  | 355.8 |  |
| Diluted |  |  | 376.0 |  |  |  | 391.7 |  |  |  | 390.8 |  |  |  | 383.0 |  |

[0001102624-11-000758:8k_2_02:41]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOW |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2011 |  |  | October 29, 2010 |  |  | October 28, 2011 |  |  | October 29, 2010 |  |
| Cash Flows from Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 165.6 |  |  | $ | 175.4 |  |  | $ | 305.1 |  |  | $ | 326.1 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 68.4 |  |  |  | 41.6 |  |  |  | 136.9 |  |  |  | 82.3 |  |
| Stock-based compensation |  |  | 63.0 |  |  |  | 37.7 |  |  |  | 121.1 |  |  |  | 82.0 |  |
| Accretion of discount and issuance costs on notes, net of amount capitalized |  |  | 11.5 |  |  |  | 13.0 |  |  |  | 25.2 |  |  |  | 25.9 |  |
| Tax benefit from stock-based compensation |  |  | 50.4 |  |  |  | 61.8 |  |  |  | 79.1 |  |  |  | 49.8 |  |
| Excess tax benefit from stock-based compensation |  |  | (52.6 | ) |  |  | (41.6 | ) |  |  | (84.7 | ) |  |  | (41.6 | ) |
| Other, net |  |  | (43.8 | ) |  |  | (42.0 | ) |  |  | (74.4 | ) |  |  | (19.4 | ) |
| Changes in assets and liabilities, net of acquisition of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (29.4 | ) |  |  | (70.2 | ) |  |  | 115.6 |  |  |  | 21.4 |  |
| Inventories |  |  | (25.1 | ) |  |  | 6.0 |  |  |  | (18.3 | ) |  |  | 31.0 |  |
| Accounts payable |  |  | 22.8 |  |  |  | 15.8 |  |  |  | 45.6 |  |  |  | (18.6 | ) |
| Accrued compensation and other current liabilities |  |  | 75.2 |  |  |  | 125.5 |  |  |  | (173.1 | ) |  |  | (96.1 | ) |
| Deferred revenue |  |  | 60.2 |  |  |  | 2.5 |  |  |  | 126.9 |  |  |  | 28.2 |  |
| Changes in other operating assets and liabilities, net |  |  | 4.0 |  |  |  | 30.3 |  |  |  | 5.8 |  |  |  | 62.1 |  |
| Net cash provided by operating activities |  |  | 370.2 |  |  |  | 355.8 |  |  |  | 610.8 |  |  |  | 533.1 |  |
| Cash Flows from Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | (205.4 | ) |  |  | (300.9 | ) |  |  | 40.4 |  |  |  | (594.8 | ) |
| Purchases of property and equipment |  |  | (93.3 | ) |  |  | (43.3 | ) |  |  | (191.6 | ) |  |  | (83.5 | ) |
| Acquisition of businesses, net of cash acquired |  |  | - |  |  |  | - |  |  |  | (480.0 | ) |  |  | (74.9 | ) |
| Other investing activities, net |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 2.0 |  |  |  | - |  |
| Net cash used in investing activities |  |  | (298.4 | ) |  |  | (344.3 | ) |  |  | (629.2 | ) |  |  | (753.2 | ) |
| Cash Flows from Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 5.3 |  |  |  | 96.2 |  |  |  | 51.9 |  |  |  | 236.1 |  |
| Repurchase and retirement of common stock |  |  | (400.0 | ) |  |  | - |  |  |  | (600.0 | ) |  |  | - |  |
| Excess tax benefit from stock-based compensation |  |  | 52.6 |  |  |  | 41.6 |  |  |  | 84.7 |  |  |  | 41.6 |  |
| Other financing activities |  |  | 1.3 |  |  |  | (2.0 | ) |  |  | 1.6 |  |  |  | (2.0 | ) |
| Net cash provided by (used in) financing activities |  |  | (340.8 | ) |  |  | 135.8 |  |  |  | (461.8 | ) |  |  | 275.7 |  |
| Effect of Exchange Rate Changes on Cash and Cash Equivalents |  |  | (5.2 | ) |  |  | 11.8 |  |  |  | (8.1 | ) |  |  | 10.5 |  |
| Net Increase (Decrease) in Cash and Cash Equivalents |  |  | (274.2 | ) |  |  | 159.1 |  |  |  | (488.3 | ) |  |  | 66.1 |  |
| Cash and Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,543.2 |  |  |  | 1,612.0 |  |  |  | 2,757.3 |  |  |  | 1,705.0 |  |
| End of period |  | $ | 2,269.0 |  |  | $ | 1,771.1 |  |  | $ | 2,269.0 |  |  | $ | 1,771.1 |  |

[0001102624-11-000758:8k_2_02:42]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP AND GAAP |  |
| IN THE CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2011 |  |  | October 29, 2010 |  |  | October 28, 2011 |  |  | October 29, 2010 |  |
| SUMMARY RECONCILIATION OF NET INCOME |  |  |  |  |  |  |  |  |  |  |  |  |
| NET INCOME |  | $ | 165.6 |  |  | $ | 175.4 |  |  | $ | 305.1 |  |  | $ | 326.1 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 21.7 |  |  |  | 4.4 |  |  |  | 46.0 |  |  |  | 9.9 |  |
| Stock-based compensation |  |  | 63.0 |  |  |  | 37.7 |  |  |  | 121.1 |  |  |  | 82.0 |  |
| Restructuring and other charges |  |  | - |  |  |  | 0.1 |  |  |  | - |  |  |  | 0.1 |  |
| Acquisition-related expense |  |  | 1.7 |  |  |  | - |  |  |  | 11.9 |  |  |  | 0.3 |  |
| Non-cash interest expense |  |  | 11.5 |  |  |  | 13.0 |  |  |  | 25.2 |  |  |  | 25.9 |  |
| Gain on investments |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (2.5 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (28.0 | ) |  |  | (18.4 | ) |  |  | (51.5 | ) |  |  | (38.7 | ) |
| NON-GAAP NET INCOME |  | $ | 235.5 |  |  | $ | 212.2 |  |  | $ | 457.8 |  |  | $ | 403.1 |  |
| NET INCOME PER SHARE |  | $ | 0.440 |  |  | $ | 0.448 |  |  | $ | 0.781 |  |  | $ | 0.851 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.058 |  |  |  | 0.011 |  |  |  | 0.118 |  |  |  | 0.026 |  |
| Stock-based compensation |  |  | 0.168 |  |  |  | 0.096 |  |  |  | 0.310 |  |  |  | 0.214 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Acquisition-related expense |  |  | 0.004 |  |  |  | - |  |  |  | 0.030 |  |  |  | 0.001 |  |
| Non-cash interest expense |  |  | 0.031 |  |  |  | 0.033 |  |  |  | 0.064 |  |  |  | 0.068 |  |
| Gain on investments |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.007 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.075 | ) |  |  | (0.047 | ) |  |  | (0.132 | ) |  |  | (0.101 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.626 |  |  | $ | 0.541 |  |  | $ | 1.171 |  |  | $ | 1.052 |  |

[0001102624-11-000758:8k_2_02:43]
| NETAPP, INC. |  |
| SUPPLEMENTAL INFORMATION |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended October 28, 2011 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Restructuring and other charges |  |  | Acquisition- related Expense |  |  | Non-Cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 14.0 |  |  | $ | 1.4 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 15.4 |  |
| Cost of service revenues |  |  | - |  |  |  | 4.2 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 4.2 |  |
| Sales and marketing expense |  |  | 7.7 |  |  |  | 30.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 38.1 |  |
| Research and development expense |  |  | - |  |  |  | 18.2 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 18.2 |  |
| General and administrative expense |  |  | - |  |  |  | 8.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 8.8 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1.7 |  |  |  | - |  |  |  | - |  |  |  | 1.7 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 11.5 |  |  |  | - |  |  |  | 11.5 |  |
| Effect on income before income taxes |  | $ | 21.7 |  |  | $ | 63.0 |  |  | $ | - |  |  | $ | 1.7 |  |  | $ | 11.5 |  |  | $ | - |  |  | $ | 97.9 |  |
|  |  | Three Months Ended October 29, 2010 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Restructuring and other charges |  |  | Acquisition- related Expense |  |  | Non-Cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 3.3 |  |  | $ | 0.8 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 4.1 |  |
| Cost of service revenues |  |  | - |  |  |  | 3.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3.1 |  |
| Sales and marketing expense |  |  | 1.1 |  |  |  | 17.3 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 18.4 |  |
| Research and development expense |  |  | - |  |  |  | 9.2 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 9.2 |  |
| General and administrative expense |  |  | - |  |  |  | 7.3 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 7.3 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 0.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.1 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 13.0 |  |  |  | - |  |  |  | 13.0 |  |
| Effect on income before income taxes |  | $ | 4.4 |  |  | $ | 37.7 |  |  | $ | 0.1 |  |  | $ | - |  |  | $ | 13.0 |  |  | $ | - |  |  | $ | 55.2 |  |
|  |  | Six Months Ended October 28, 2011 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Restructuring and other charges |  |  | Acquisition- related Expense |  |  | Non-Cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 27.9 |  |  | $ | 2.5 |  |  | $ | - |  |  | $ | 5.4 |  |  | $ | - |  |  | $ | - |  |  | $ | 35.8 |  |
| Cost of service revenues |  |  | - |  |  |  | 8.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 8.1 |  |
| Sales and marketing expense |  |  | 18.0 |  |  |  | 59.0 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 77.0 |  |
| Research and development expense |  |  | 0.1 |  |  |  | 34.2 |  |  |  | - |  |  |  | 2.6 |  |  |  | - |  |  |  | - |  |  |  | 36.9 |  |
| General and administrative expense |  |  | - |  |  |  | 17.3 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 17.3 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3.9 |  |  |  | - |  |  |  | - |  |  |  | 3.9 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 25.2 |  |  |  | - |  |  |  | 25.2 |  |
| Effect on income before income taxes |  | $ | 46.0 |  |  | $ | 121.1 |  |  | $ | - |  |  | $ | 11.9 |  |  | $ | 25.2 |  |  | $ | - |  |  | $ | 204.2 |  |
|  |  | Six Months Ended October 29, 2010 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Restructuring and other charges |  |  | Acquisition-related Expense |  |  | Non-Cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 7.7 |  |  | $ | 1.7 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 9.4 |  |
| Cost of service revenues |  |  | - |  |  |  | 7.0 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 7.0 |  |
| Sales and marketing expense |  |  | 2.2 |  |  |  | 37.9 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 40.1 |  |
| Research and development expense |  |  | - |  |  |  | 20.3 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 20.3 |  |
| General and administrative expense |  |  | - |  |  |  | 15.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 15.1 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 0.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.1 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.3 |  |  |  | - |  |  |  | - |  |  |  | 0.3 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 25.9 |  |  |  | - |  |  |  | 25.9 |  |
| Other income (expense), net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (2.5 | ) |  |  | (2.5 | ) |
| Effect on income before income taxes |  | $ | 9.9 |  |  | $ | 82.0 |  |  | $ | 0.1 |  |  | $ | 0.3 |  |  | $ | 25.9 |  |  | $ | (2.5 | ) |  | $ | 115.7 |  |

[0001102624-11-000758:8k_2_02:44]
| NETAPP, INC. |
| RECONCILIATION OF NON GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| THIRD QUARTER 2012 |
| (Unaudited) |
|  | Third Quarter |
|  | 2012 |
| Non-GAAP Guidance | $0.56 - $0.60 |
| Adjustments of Specific Items to |  |
| Net Income Per Share for the Third |  |
| Quarter 2012: |  |
| Amortization of intangible assets | (0.06) |
| Stock-based compensation | (0.16) |
| Acquisition-related expense | (0.01) |
| Non-cash interest expense | (0.03) |
| Income tax effect | 0.06 |
| Total Adjustments | (0.20) |
| GAAP Guidance -Net Income Per Share | $0.36 - $0.40 |
