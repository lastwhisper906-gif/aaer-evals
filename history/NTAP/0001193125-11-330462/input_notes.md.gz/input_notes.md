# NTAP notes — 0001193125-11-330462


## ntap:AccountsReceivableFromSignificantCustomersTextBlock

[0001193125-11-330462:notes:1]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Arrow Electronics, Inc. |  | $ | 69.9 |  |  | $ | 101.4 |  |
| Avnet, Inc. |  | $ | 67.2 |  |  | $ | 107.5 |  |


## ntap:AmortizationFiniteLivedIntangibleAssetsTextBlock

[0001193125-11-330462:notes:2]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |  | Statements of Operations Classifications |
| Developed technology |  | $ | 14.0 |  |  | $ | 3.3 |  |  | $ | 27.9 |  |  | $ | 7.7 |  |  | Cost of product revenues |
| Customer contracts/relationships |  |  | 6.4 |  |  |  | 0.8 |  |  |  | 15.4 |  |  |  | 1.6 |  |  | Sales and marketing |
| Trademarks and trade names |  |  | 1.1 |  |  |  | 0.3 |  |  |  | 2.3 |  |  |  | 0.6 |  |  | Sales and marketing |
| Covenants not to compete |  |  | 0.2 |  |  |  | 0.0 |  |  |  | 0.4 |  |  |  | 0.0 |  |  | Sales and marketing / Research and development |
|  |  | $ | 21.7 |  |  | $ | 4.4 |  |  | $ | 46.0 |  |  | $ | 9.9 |  |  |  |


## ntap:DebtDiscountAndIssuanceCostTextBlock

[0001193125-11-330462:notes:3]
| Remaining debt discount |  | $ | 89.2 |  |
| Remaining issuance costs |  |  | 7.7 |  |
| Remaining life of the Notes (years) |  |  | 1.6 |  |


## ntap:DisclosureOfShareBasedCompensationArrangementsAdditionalInformationRelatedToStockOptionsTextBlock

[0001193125-11-330462:notes:4]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Weighted-average fair value per share granted |  | $ | 13.77 |  |  | $ | 15.21 |  |  | $ | 16.96 |  |  | $ | 13.70 |  |
| Weighted-average fair value per share of options assumed in acquisition |  |  | N/A |  |  |  | N/A |  |  |  | N/A |  |  | $ | 21.15 |  |
| Intrinsic value of options exercised |  | $ | 6.8 |  |  | $ | 104.1 |  |  | $ | 50.6 |  |  | $ | 214.6 |  |
| Proceeds received from the exercise of stock options |  | $ | 7.7 |  |  | $ | 97.3 |  |  | $ | 42.7 |  |  | $ | 224.9 |  |
| Fair value of options vested |  | $ | 20.3 |  |  | $ | 26.5 |  |  | $ | 38.7 |  |  | $ | 54.5 |  |


## ntap:FairValueOfFinancialInstrumentsPolicyTextBlock

[0001193125-11-330462:notes:5]
[same as prior period, unchanged from 0001193125-11-239169:notes:6]

[0001193125-11-330462:notes:6]
[same as prior period, unchanged from 0001193125-11-239169:notes:7]

[0001193125-11-330462:notes:7]
[same as prior period, unchanged from 0001193125-11-239169:notes:8]

[0001193125-11-330462:notes:8]
[same as prior period, unchanged from 0001193125-11-239169:notes:9]

[0001193125-11-330462:notes:9]
[same as prior period, unchanged from 0001193125-11-239169:notes:10]


## ntap:InterestCostIncurredTextBlock

[0001193125-11-330462:notes:10]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 11.0 |  |  | $ | 11.0 |  |
| Amortization of debt discount |  |  | 12.8 |  |  |  | 12.0 |  |  |  | 25.4 |  |  |  | 23.9 |  |
| Amortization of issuance costs |  |  | 1.1 |  |  |  | 1.0 |  |  |  | 2.2 |  |  |  | 2.0 |  |
| Less capitalized interest |  |  | (3.5 | ) |  |  | 0.0 |  |  |  | (3.5 | ) |  |  | 0.0 |  |
| Total interest expense recognized |  | $ | 15.9 |  |  | $ | 18.5 |  |  | $ | 35.1 |  |  | $ | 36.9 |  |


## ntap:LongTermDebtByCurrentAndNonCurrentTextBlock

[0001193125-11-330462:notes:11]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 8.1 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.2 |  |  |  | 6.0 |  |
|  |  | $ | 13.3 |  |  | $ | 11.5 |  |


## ntap:MarketableSecuritiesAvailableForSaleSecuritiesPolicyTextBlock

[0001193125-11-330462:notes:12]
The unrealized losses on our available-for-sale investments in corporate bonds were caused by market value declines as a result of the economic environment, as well as fluctuations in market interest rates. Because the decline in market value is attributable to changes in market conditions and not credit quality, and because we neither intend to sell nor are likely to be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of October 28, 2011.


## ntap:OtherCurrentAssetsTextBlock

[0001193125-11-330462:notes:13]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Deferred tax assets, net |  | $ | 205.4 |  |  | $ | 145.7 |  |
| Prepaid expenses and other current assets |  |  | 190.0 |  |  |  | 188.4 |  |
| Short-term restricted cash |  |  | 4.5 |  |  |  | 5.3 |  |
|  |  | $ | 399.9 |  |  | $ | 339.4 |  |


## ntap:ScheduleOfAcquisitionRelatedAndIntegrationExpensesTableTextBlock

[0001193125-11-330462:notes:14]
|  |  | Three MonthsEnded |  |  | Six MonthsEnded |  |
|  |  | October 28,2011 |  |  | October 28,2011 |  |
| Acquisition-related expense |  | $ | 1.7 |  |  | $ | 3.9 |  |


## ntap:ScheduleOfComputerSoftwareTableTextBlock

[0001193125-11-330462:notes:15]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Computer software |  | $ | 82.3 |  |  | $ | 88.3 |  |


## ntap:ScheduleOfIncomeTaxEffectsAllocatedDirectlyToEquityEmployeeStockOptionsTextBlock

[0001193125-11-330462:notes:16]
|  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |
| Income tax benefits associated with employee stock transactions |  | $ | 79.1 |  |  | $ | 49.8 |  |


## ntap:ScheduleOfNotionalValueOfOutstandingCurrencyForwardContractsTextBlock

[0001193125-11-330462:notes:17]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Euro |  | $ | 152.8 |  |  | $ | 104.0 |  |
| British Pound Sterling |  |  | 36.1 |  |  |  | 20.9 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Euro |  |  | 192.7 |  |  |  | 253.7 |  |
| British Pound Sterling |  |  | 39.2 |  |  |  | 70.8 |  |
| Australian Dollar |  |  | 51.3 |  |  |  | 34.4 |  |
| Canadian Dollar |  |  | 20.9 |  |  |  | 56.0 |  |
| Other |  |  | 51.3 |  |  |  | 52.6 |  |


## ntap:ShareBasedCompensationArrangementByShareBasedPaymentAwardFairValueAssumptionsMethodUsedTextBlock

[0001193125-11-330462:notes:18]
|  |  | Stock Options |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Expected term in years |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 4.8 |  |
| Risk-free interest rate |  |  | 0.97 | % |  |  | 1.40 | % |  |  | 1.55 | % |  |  | 1.95 | % |
| Volatility |  |  | 41 | % |  |  | 37 | % |  |  | 36 | % |  |  | 37 | % |

[0001193125-11-330462:notes:19]
|  |  | ESPP |  |
|  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 0.25 | % |  |  | 0.46 | % |
| Volatility |  |  | 35 | % |  |  | 39 | % |


## ntap:SharesWithheldForEmployeeTaxesTextBlock

[0001193125-11-330462:notes:20]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Shares withheld for taxes |  |  | 0.1 |  |  |  | 0.0 |  |  |  | 0.6 |  |  |  | 0.5 |  |
| Fair value of shares withheld and retired |  | $ | 2.5 |  |  | $ | 1.1 |  |  | $ | 27.8 |  |  | $ | 19.6 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0001193125-11-330462:notes:21]
|  |  | Shares ofCommonStock |  |  | AdditionalPaid-inCapital |  |  | RetainedEarnings |  |  | TotalRepurchaseActivity |  |
| Repurchase and retirement of common stock |  |  | (14.4 | ) |  | $ | (123.7 | ) |  | $ | (467.1 | ) |  | $ | (590.8 | ) |
| Value of ASR forward contracts |  |  |  |  |  |  | (9.2 | ) |  |  |  |  |  |  | (9.2 | ) |
| Total cash payment |  |  | (14.4 | ) |  | $ | (132.9 | ) |  | $ | (467.1 | ) |  | $ | (600.0 | ) |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-11-330462:notes:22]
|  |  | October 28, 2011 |  |  | April 29, 2011 |  |
|  |  |  |  |  | Gross Unrealized |  |  | Estimated |  |  |  |  |  | Gross Unrealized |  |  | Estimated |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Fair Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Fair Value |  |
| Corporate bonds |  | $ | 1,990.0 |  |  | $ | 5.1 |  |  | $ | (3.8 | ) |  | $ | 1,991.3 |  |  | $ | 1,643.2 |  |  | $ | 10.2 |  |  | $ | (0.6 | ) |  | $ | 1,652.8 |  |
| Auction rate securities |  |  | 58.8 |  |  |  | 1.0 |  |  |  | (3.8 | ) |  |  | 56.0 |  |  |  | 69.2 |  |  |  | 0.4 |  |  |  | (4.5 | ) |  |  | 65.1 |  |
| U.S. treasury and government debt securities |  |  | 237.4 |  |  |  | 0.0 |  |  |  | (0.6 | ) |  |  | 236.8 |  |  |  | 661.9 |  |  |  | 0.6 |  |  |  | (0.7 | ) |  |  | 661.8 |  |
| Commercial paper |  |  | 35.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 35.0 |  |  |  | 5.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 5.0 |  |
| Municipal bonds |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.5 |  |
| Certificates of deposit |  |  | 117.4 |  |  |  | 0.2 |  |  |  | (0.1 | ) |  |  | 117.5 |  |  |  | 96.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 96.3 |  |
| Money market funds |  |  | 1,199.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,199.3 |  |  |  | 1,539.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,539.6 |  |
| Equity funds |  |  | 23.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 23.6 |  |  |  | 20.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 20.2 |  |
| Private equity fund |  |  | 1.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.0 |  |  |  | 1.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.3 |  |
| Total debt and equity securities |  | $ | 3,662.5 |  |  | $ | 6.3 |  |  | $ | (8.3 | ) |  | $ | 3,660.5 |  |  | $ | 4,038.2 |  |  | $ | 11.2 |  |  | $ | (5.8 | ) |  | $ | 4,043.6 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001193125-11-330462:notes:23]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Net revenues |  | $ | 1,507.0 |  |  | $ | 1,431.2 |  |  | $ | 2,973.8 |  |  | $ | 2,753.9 |  |
| Net income |  | $ | 165.8 |  |  | $ | 177.8 |  |  | $ | 311.7 |  |  | $ | 316.2 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-11-330462:notes:24]
5. Business Combinations

[0001193125-11-330462:notes:25]
[same as prior period, unchanged from 0001193125-11-239169:notes:39]

[0001193125-11-330462:notes:26]
On May 6, 2011, we completed the acquisition of certain assets related to the Engenio external storage systems business (Engenio) of LSI Corporation (LSI). We paid LSI $480 million in cash and also assumed certain liabilities related to Engenio. During the three years following the acquisition, LSI will pay us a total of $13.0 million to service certain LSI customer warranties. This acquisition enables us to address growing customer requirements in the areas of high bandwidth and intensive analytics workloads such as video, including full-motion video capture and digital video surveillance, as well as high-performance computing applications, such as genomics sequencing and scientific research.

[0001193125-11-330462:notes:27]
[same as prior period, unchanged from 0001193125-11-239169:notes:41]

[0001193125-11-330462:notes:28]
[same as prior period, unchanged from 0001193125-11-239169:notes:42]

[0001193125-11-330462:notes:29]
[same as prior period, unchanged from 0001193125-11-239169:notes:43]

[0001193125-11-330462:notes:30]
As this was an asset acquisition, U.S. goodwill is deductible for income tax purposes. The goodwill is comprised of expected synergies in utilizing Engenio's technology in the Company's products and channels (and vice versa), reduction in future combined research and development expenses, and intangible assets, such as acquired workforce, that do not qualify for separate recognition.

[0001193125-11-330462:notes:31]
[same as prior period, unchanged from 0001193125-11-239169:notes:45]

[0001193125-11-330462:notes:32]
[same as prior period, unchanged from 0001193125-11-239169:notes:46]

[0001193125-11-330462:notes:33]
|  |  | FairValue |  |  | Useful Life(Years) |  |
| Developed technology |  | $ | 216.0 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 45.0 |  |  |  | 2 |  |
| Trademarks and trade names |  |  | 7.0 |  |  |  | 2 |  |
| Order backlog |  |  | 2.5 |  |  |  | 0 |  |
| Covenant not to compete |  |  | 1.6 |  |  |  | 3 |  |
| Total identified intangible assets |  | $ | 272.1 |  |  |  |  |  |

[0001193125-11-330462:notes:34]
Our consolidated net revenues for the three and six months ended October 28, 2011 included $182.4 million and $339.5 million, respectively, attributable to Engenio since the acquisition. Due to continued integration of the combined businesses since the date of acquisition, it is impracticable to determine the earnings contributed by Engenio.

[0001193125-11-330462:notes:35]
The following unaudited pro forma condensed combined financial information gives effect to the acquisition of Engenio as if it were consummated on May 1, 2010 (the beginning of the comparable prior annual reporting period). Due to historically differing fiscal year ends of the Company and Engenio, the unaudited pro forma condensed combined financial information for the three and six months ended October 29, 2010 is based on the historical results of the Company for the three and six months ended October 29, 2010 and the historical results of Engenio for the three and six months ended October 3, 2010.

[0001193125-11-330462:notes:36]
The unaudited pro forma condensed combined financial information is presented for informational purposes only, is not intended to represent or be indicative of the results of operations of the Company that would have been reported had the acquisition occurred on May 1, 2010 and should not be taken as representative of future condensed consolidated results of operations of the combined company (in millions):

[0001193125-11-330462:notes:37]
A nonrecurring adjustment of $5.6 million has been reflected in the unaudited pro forma condensed combined information with the effect of increasing net income for the six months ended October 28, 2011 and decreasing net income for the six months ended October 29, 2010 to present the impact on cost of sales from the step-up in inventory as if the acquisition occurred on May 1, 2010.

[0001193125-11-330462:notes:38]
Acquisition-related expense in our condensed consolidated statements of operations was:

[0001193125-11-330462:notes:39]
For the six months ended October 28, 2011 acquisition-related expense consisted of due diligence and legal charges of $0.7 million directly related to the acquisition of Engenio and $3.2 million of one-time integration charges related to the combined business.

[0001193125-11-330462:notes:40]
[same as prior period, unchanged from 0001193125-11-239169:notes:53]

[0001193125-11-330462:notes:41]
[same as prior period, unchanged from 0001193125-11-239169:notes:54]

[0001193125-11-330462:notes:42]
[same as prior period, unchanged from 0001193125-11-239169:notes:55]

[0001193125-11-330462:notes:43]
|  |  | Akorri |  |  | Bycast |  |
| Acquisition dates |  | January 31,2011 |  |  | May 13,2010 |  |
| Percentage of equity interest acquired |  |  | 100 | % |  |  | 100 | % |
| Total purchase price |  | $ | 62.3 |  |  | $ | 83.8 |  |
| Cash component of purchase price |  | $ | 62.3 |  |  | $ | 80.5 |  |
| Fair value of vested options assumed |  | $ | 0.0 |  |  | $ | 3.3 |  |
| Purchase price held in escrow to secure obligations of acquired entity |  | $ | 7.9 |  |  | $ | 13.1 |  |
| Release of escrow (number of years subsequent to acquisition date) |  |  | 1.5 |  |  |  | 1.5 |  |

[0001193125-11-330462:notes:44]
We paid the remaining purchase price of Bycast of $13.1 million held in escrow in November 2011.

[0001193125-11-330462:notes:45]
[same as prior period, unchanged from 0001193125-11-239169:notes:57]

[0001193125-11-330462:notes:46]
[same as prior period, unchanged from 0001193125-11-239169:notes:58]

[0001193125-11-330462:notes:47]
Due to continued integration of the combined businesses since the date of acquisition, it is impracticable to determine the revenue and earnings contributed by Akorri and Bycast. As Akorri and Bycast were acquisitions of businesses, goodwill is not deductible for income tax purposes.

[0001193125-11-330462:notes:48]
[same as prior period, unchanged from 0001193125-11-239169:notes:60]


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001193125-11-330462:notes:49]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Cash |  | $ | 1,061.7 |  |  | $ | 1,169.1 |  |
| Cash equivalents |  |  | 1,207.3 |  |  |  | 1,588.2 |  |
|  |  | $ | 2,269.0 |  |  | $ | 2,757.3 |  |


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-11-330462:notes:50]
4. Statements of Cash Flows

[0001193125-11-330462:notes:51]
Supplemental cash flows and non-cash investing and financing activities are as follows (in millions):

[0001193125-11-330462:notes:52]
|  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Reclassification of equity component of convertible debt |  | $ | 114.6 |  |  | $ | 0.0 |  |
| Acquisition of property and equipment on account |  | $ | 41.0 |  |  | $ | 36.4 |  |
| Acquisition of property and equipment through long-term financing |  | $ | 2.5 |  |  | $ | 12.6 |  |
| Options assumed from acquired business |  | $ | 0.0 |  |  | $ | 3.3 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 22.7 |  |  | $ | 11.8 |  |
| Interest paid, (net of capitalized interest of $1.0 million and $0.0 million, respectively) |  | $ | 10.3 |  |  | $ | 11.3 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-11-330462:notes:53]
15. Commitments and Contingencies

[0001193125-11-330462:notes:54]
Lease Commitments

[0001193125-11-330462:notes:55]
Future annual minimum lease payments under all non-cancelable facilities and equipment operating leases with an initial term in excess of one year as of October 28, 2011 totaled $390.7 million.

[0001193125-11-330462:notes:56]
As of October 28, 2011, we have four leasing arrangements (Leasing Arrangements 1, 2, 3 and 4) with BNP Paribas LLC (BNPPLC), some of which require us to lease certain of our land to BNPPLC for a period of 99 years and to lease approximately 0.6 million square feet of office space for our headquarters in Sunnyvale, which had an original cost of $149.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on LIBOR plus a spread or a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of the leases for two consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of the lease terms, we must elect one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received from the third-party and BNPPLC's cost up to 85% of cost (residual guarantee); or (iii) pay BNPPLC supplemental payments for an amount equal to the difference between the residual guarantee and fair value, in which event we may recoup some or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period.

[0001193125-11-330462:notes:57]
These leases require us to maintain specified financial covenants with which we were in compliance as of October 28, 2011.

[0001193125-11-330462:notes:58]
As of October 28, 2011, we estimated that the fair value of the properties under synthetic lease was $51.0 million below the residual guarantee. We are accruing for this deficiency over the remaining terms of the respective leases. As of October 28, 2011, a deficiency reserve of $27.0 million was included in other long-term liabilities.

[0001193125-11-330462:notes:59]
Purchase Orders and Other Commitments

[0001193125-11-330462:notes:60]
In the normal course of business we make commitments to our third-party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. We had $176.1 million in non-cancelable purchase commitments with our contract manufacturers as of October 28, 2011. In addition, we recorded a liability for firm non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to product cost of sales. As of October 28, 2011 and April 29, 2011, such liability amounted to $5.5 million and $4.5 million, respectively, and is included in other current liabilities in the condensed consolidated balance sheets.

[0001193125-11-330462:notes:61]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course business for which we have not received goods or services. We had $13.3 million in capital purchase commitments and $327.5 million in other purchase commitments as of October 28, 2011.

[0001193125-11-330462:notes:62]
Product Warranties

[0001193125-11-330462:notes:63]
We provide customers a warranty on software of ninety days to five years and a warranty on hardware of one to five years. The following table summarizes our warranty reserves (in millions):

[0001193125-11-330462:notes:64]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Beginning balance |  | $ | 59.5 |  |  | $ | 32.1 |  |  | $ | 40.5 |  |  | $ | 31.9 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 17.5 |  |  |  | 0.0 |  |
| Expense accrued during the period |  |  | 15.7 |  |  |  | 7.0 |  |  |  | 27.4 |  |  |  | 12.9 |  |
| Warranty costs incurred |  |  | (10.2 | ) |  |  | (5.6 | ) |  |  | (20.4 | ) |  |  | (11.3 | ) |
| Ending balance |  | $ | 65.0 |  |  | $ | 33.5 |  |  | $ | 65.0 |  |  | $ | 33.5 |  |

[0001193125-11-330462:notes:65]
Financing Guarantees

[0001193125-11-330462:notes:66]
We have both nonrecourse and recourse lease financing arrangements with third-party leasing companies through new and preexisting relationships with customers. In addition, from time to time we provide guarantees for a portion of other financing arrangements under which we could be called upon to make payments to our third-party funding companies in the event of nonpayment by end-user customers. Under the terms of the nonrecourse leases, we do not have any continuing obligations or liabilities to the third-party leasing companies. Under the terms of the recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee, we defer the revenues associated with the end-user financing arrangement in accordance with our revenue recognition policies. As of October 28, 2011, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $105.1 million, and the related deferred revenue and cost of revenues totaled approximately $107.4 million and $12.4 million, respectively. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001193125-11-330462:notes:67]
Legal Contingencies

[0001193125-11-330462:notes:68]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as of October 28, 2011, as the outcome of these legal matters is currently not determinable.

[0001193125-11-330462:notes:69]
On October 13, 2010, Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of California, Santa Clara County. The lawsuit named certain of our current and former directors as defendants. On February 3, 2011, the plaintiff filed an amended complaint in response to motions to dismiss that we and the individual defendants had filed. Like the original complaint, the amended complaint included claims of breach of fiduciary duty and waste of corporate assets and alleges that the defendants failed to monitor internal controls to ensure that we complied with legal requirements in our General Services Administration (GSA) contracting activities, resulting in us incurring defense and settlement costs. The amended complaint sought disgorgement of salaries and other compensation from the defendants and additional unspecified damages. We and the individual defendants filed motions to dismiss the amended complaint in early March 2011. Following a hearing on July 15, 2011, the Court granted the motions to dismiss, but permitted plaintiff leave to amend its complaint on or before September 16, 2011.

[0001193125-11-330462:notes:70]
On August 9, 2011, Amalgamated Bank filed a complaint in Delaware Chancery Court against us for the purpose of obtaining, in a summary proceeding, books and records to help Amalgamated Bank amend its complaint in the California lawsuit. Each of the parties filed cross motions for summary judgment, and a hearing was held before the Delaware Chancery Court on November 16, 2011. Following that hearing, the Court directed Amalgamated Bank to more narrowly tailor its requests.

[0001193125-11-330462:notes:71]
The plaintiff filed an amended complaint in the California lawsuit on September 15, 2011. We will move to dismiss this or any other further amended complaint by January 9, 2012. A hearing on our motion to dismiss the California lawsuit is scheduled for February 24, 2012.


## us-gaap:DebtDisclosureTextBlock

[0001193125-11-330462:notes:72]
9. Financing Arrangements

[0001193125-11-330462:notes:73]
1.75% Convertible Senior Notes Due 2013

[0001193125-11-330462:notes:74]
On June 10, 2008, we issued $1,265.0 million aggregate principal amount of 1.75% Convertible Senior Notes due 2013 (the Notes). The Notes are unsecured, unsubordinated obligations of the Company. Interest is payable in cash semi-annually at a rate of 1.75% per annum. The Notes will mature on June 1, 2013 unless repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified below, based on an initial conversion rate of 31.40 shares of common stock per $1,000 principal amount of Notes (which represents an initial effective conversion price of the Notes of approximately $31.85 per share), subject to adjustment as described in the indenture governing the Notes.

[0001193125-11-330462:notes:75]
The Notes are not redeemable by us prior to the maturity date. In the event of a fundamental change (as defined in the indenture for the Notes), holders of the Notes may require us to repurchase all or a portion of their Notes at a repurchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid interest, if any, to, but excluding, the fundamental change repurchase date.

[0001193125-11-330462:notes:76]
The holders of the Notes may convert their Notes until the close of business on the scheduled trading day immediately preceding the maturity date if any of the following conditions are met: (1) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price of the Notes for each day in the measurement period was less than 98% of an amount equal to (i) the last reported sale price of our common stock multiplied by (ii) the conversion rate for the Notes on each such day; (2) during any calendar quarter (and only during such calendar quarter) if the last reported sale price of our common stock for 20 or more trading days in a period of 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter exceeds 130% of the applicable conversion price in effect for the Notes on the last trading day of such immediately preceding calendar quarter; or (3) upon the occurrence of specified corporate transactions set forth in the indenture for the Notes. On or after March 1, 2013, until the scheduled trading day immediately preceding the maturity date, holders of the Notes may convert their Notes regardless of the foregoing conditions. Upon conversion, a holder will receive cash in an amount equal to the lesser of the conversion value and the principal amount of the Notes, and any shares of our common stock for any conversion value in excess of the principal amount of the Notes, if any. Holders of the Notes who convert their Notes in connection with a fundamental change will, under certain circumstances, be entitled to a make-whole premium in the form of an increase in the conversion rate.

[0001193125-11-330462:notes:77]
Our common stock price did not exceed the conversion threshold price of $41.41 per share set forth for the Notes for at least 20 trading days during the 30 consecutive trading days ended September 30, 2011. Accordingly, as of October 28, 2011, the Notes were not convertible at the option of the holder and, therefore, the carrying value of the Notes was classified as long-term debt and the difference between the principal amount and the carrying value of the Notes is reflected as equity on our condensed consolidated balance sheet.

[0001193125-11-330462:notes:78]
Our common stock price exceeded the conversion threshold for the Notes for at least 20 trading days during the 30 consecutive trading days ended March 31, 2011. Accordingly, as of April 29, 2011, the Notes were convertible at the option of the holder and, therefore, the carrying value of the Notes was classified as short-term debt. Since the Notes were convertible at the option of the holder and the principal amount would have been required to be paid in cash, the difference between the principal amount and the carrying value of the Notes was reflected as convertible debt in mezzanine on our condensed consolidated balance sheet as of April 29, 2011.

[0001193125-11-330462:notes:79]
The determination of whether or not the Notes are convertible must continue to be performed quarterly. Consequently, the Notes may be convertible in future quarters, and therefore may be classified as short-term debt, if the conversion thresholds are met in such quarters. Additionally, since the Notes would be convertible at the option of the holder and the principal amount would be required to be paid in cash, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in mezzanine on our condensed consolidated balance sheets.

[0001193125-11-330462:notes:80]
Upon conversion of any Notes, we deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal amount of the Notes, shares of our common stock. As of October 28, 2011, shares issued related to the Notes were minimal. Based on the closing price of our common stock of $41.59 on October 28, 2011, the if-converted value of our Notes exceeded their principal amount by approximately $387.0 million.

[0001193125-11-330462:notes:81]
The following table reflects the carrying value of our convertible debt as of October 28, 2011 and April 29, 2011, respectively (in millions):

[0001193125-11-330462:notes:82]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (89.2 | ) |  |  | (114.6 | ) |
| Net carrying amount of Notes |  | $ | 1,175.8 |  |  | $ | 1,150.4 |  |

[0001193125-11-330462:notes:83]
The following table presents the amount of interest cost recognized (in millions):

[0001193125-11-330462:notes:84]
We capitalize interest on facility assets under construction and on significant software development projects.

[0001193125-11-330462:notes:85]
The following table reflects the remaining debt discount and issuance costs as of October 28, 2011 (in millions):

[0001193125-11-330462:notes:86]
Note Hedges and Warrants

[0001193125-11-330462:notes:87]
Concurrent with the issuance of the Notes, we purchased Note hedges and sold warrants. The separate Note hedge and warrants transactions are structured to reduce the potential future economic dilution associated with the conversion of the Notes.

[0001193125-11-330462:notes:88]
| • |  | Note Hedges: As of October 28, 2011 and April 29, 2011, we had arrangements with counterparties to buy up to approximately 31.8 million shares, subject to anti-dilution adjustments, of our common stock at a price of $31.85 per share, subject to adjustment. The Note hedge transactions will expire at the earlier of (1) the last day on which any Notes remain outstanding or (2) the scheduled trading day immediately preceding the maturity date of the Notes. Upon exercise of the Note hedges, we have the option to receive cash or shares of our common stock equal to the difference between the then market price and the strike price of the hedges. |

[0001193125-11-330462:notes:89]
|  | • |  | Warrants: As of October 28, 2011 and April 29, 2011, we had outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |

[0001193125-11-330462:notes:90]
As of October 28, 2011, we were subject to potential dilution on the approximately 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of approximately $31.85.

[0001193125-11-330462:notes:91]
As of October 28, 2011, receipts of shares related to the Note hedge transactions were minimal and no cash or shares were delivered related to the warrant transactions.

[0001193125-11-330462:notes:92]
Fair Value of Notes

[0001193125-11-330462:notes:93]
As of October 28, 2011, the approximate fair value of the principal amount of our Notes, which includes the debt and equity components, was approximately $1,761.5 million, or 139% of the face value of the Notes, based upon quoted market information.

[0001193125-11-330462:notes:94]
Other Long-Term Financing Arrangements

[0001193125-11-330462:notes:95]
The following presents the amounts due under other long-term financing arrangements (in millions):


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001193125-11-330462:notes:96]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Product |  | $ | 51.3 |  |  | $ | 106.2 |  |
| SEM and service |  |  | 2,387.3 |  |  |  | 2,208.7 |  |
| Total |  | $ | 2,438.6 |  |  | $ | 2,314.9 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,246.7 |  |  | $ | 1,226.6 |  |
| Long-term |  |  | 1,191.9 |  |  |  | 1,088.3 |  |
| Total |  | $ | 2,438.6 |  |  | $ | 2,314.9 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-11-330462:notes:97]
11. Derivatives and Hedging Activities

[0001193125-11-330462:notes:98]
[same as prior period, unchanged from 0001193125-11-239169:notes:106]

[0001193125-11-330462:notes:99]
As of October 28, 2011 and April 29, 2011, the fair value of our short-term foreign currency contracts was not material. Certain of these contracts are designed to hedge our exposure to foreign currency denominated monetary assets and liabilities and are not designated as hedging instruments. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change. Gains on derivatives not designated as hedging instruments were not material for any period presented. Net deferred gains and losses recognized into AOCI related to changes in the fair value of our foreign currency contracts that are accounted for as cash flow hedges were not material for any period presented. We did not recognize any gains and losses in earnings due to hedge ineffectiveness for any period presented. The amount of gains reclassified from AOCI into income was not material for any period presented.


## us-gaap:EarningsPerShareTextBlock

[0001193125-11-330462:notes:100]
13. Net Income per Share

[0001193125-11-330462:notes:101]
[same as prior period, unchanged from 0001193125-11-239169:notes:110]

[0001193125-11-330462:notes:102]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 165.6 |  |  | $ | 175.4 |  |  | $ | 305.1 |  |  | $ | 326.1 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 361.5 |  |  |  | 359.1 |  |  |  | 365.9 |  |  |  | 355.8 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 7.8 |  |  |  | 15.9 |  |  |  | 9.8 |  |  |  | 15.7 |  |
| Dilutive impact of assumed conversion of Notes |  |  | 6.7 |  |  |  | 12.4 |  |  |  | 11.1 |  |  |  | 9.4 |  |
| Dilutive impact of warrants |  |  | 0.0 |  |  |  | 4.3 |  |  |  | 4.0 |  |  |  | 2.1 |  |
| Shares used in diluted computation |  |  | 376.0 |  |  |  | 391.7 |  |  |  | 390.8 |  |  |  | 383.0 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.46 |  |  | $ | 0.49 |  |  | $ | 0.83 |  |  | $ | 0.92 |  |
| Diluted |  | $ | 0.44 |  |  | $ | 0.45 |  |  | $ | 0.78 |  |  | $ | 0.85 |  |

[0001193125-11-330462:notes:103]
The following potential weighted-average shares of common stock have been excluded from the diluted net income per share calculations, as their effect would have been anti-dilutive (in millions):

[0001193125-11-330462:notes:104]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Options and RSUs |  |  | 15.6 |  |  |  | 2.1 |  |  |  | 9.6 |  |  |  | 3.7 |  |

[0001193125-11-330462:notes:105]
Dilutive shares outstanding during the three months ended October 28, 2011 do not include any effect resulting from warrants, as their impact would have been anti-dilutive. The Note hedges (as described in Note 9) are not included in the calculation of earnings per share as their effect would have been anti-dilutive. The Note hedges, if exercised upon conversion of the Notes, are expected to reduce approximately 80% of the dilutive effect of the Notes when our stock price is above $31.85 per share.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001193125-11-330462:notes:106]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Balance at beginning of period |  | $ | 56.3 |  |  | $ | 67.4 |  |  | $ | 65.1 |  |  | $ | 69.0 |  |
| Total unrealized gains (losses) included in other comprehensive income |  |  | 0.4 |  |  |  | (0.6 | ) |  |  | 1.3 |  |  |  | (1.4 | ) |
| Settlements |  |  | (0.7 | ) |  |  | (0.6 | ) |  |  | (10.4 | ) |  |  | (1.4 | ) |
| Balance at end of period |  | $ | 56.0 |  |  | $ | 66.2 |  |  | $ | 56.0 |  |  | $ | 66.2 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-11-330462:notes:107]
|  |  | Total |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 1,207.3 |  |  | $ | 1,199.3 |  |  | $ | 8.0 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 2,372.6 |  |  |  | 0.0 |  |  |  | 2,372.6 |  |  |  | 0.0 |  |
| Other current assets |  |  | 3.7 |  |  |  | 3.7 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 79.9 |  |  |  | 19.9 |  |  |  | 3.0 |  |  |  | 57.0 |  |
| Total |  | $ | 3,663.5 |  |  | $ | 1,222.9 |  |  | $ | 2,383.6 |  |  | $ | 57.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 7.2 |  |  | $ | 0.0 |  |  | $ | 7.2 |  |  | $ | 0.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-11-330462:notes:108]
8. Financial Instruments and Fair Value

[0001193125-11-330462:notes:109]
[same as prior period, unchanged from 0001193125-11-239169:notes:118]

[0001193125-11-330462:notes:110]
The following is a summary of our investments as of October 28, 2011 and April 29, 2011, respectively (in millions):

[0001193125-11-330462:notes:111]
The following table presents the contractual maturities of our debt investments as of October 28, 2011 (in millions):

[0001193125-11-330462:notes:112]
|  |  | Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 728.0 |  |  | $ | 728.6 |  |
| Due in one through five years |  |  | 1,651.8 |  |  |  | 1,652.0 |  |
| Due after ten years* |  |  | 58.8 |  |  |  | 56.0 |  |
|  |  | $ | 2,438.6 |  |  | $ | 2,436.6 |  |

[0001193125-11-330462:notes:113]
[same as prior period, unchanged from 0001193125-11-239169:notes:122]

[0001193125-11-330462:notes:114]
[same as prior period, unchanged from 0001193125-11-239169:notes:123]

[0001193125-11-330462:notes:115]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis as of October 28, 2011 (in millions):

[0001193125-11-330462:notes:116]
|  |  | Total |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 1,991.3 |  |  | $ | 0.0 |  |  | $ | 1,991.3 |  |  | $ | 0.0 |  |
| U.S. treasuries and government debt securities |  |  | 236.8 |  |  |  | 0.0 |  |  |  | 236.8 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 35.0 |  |  |  | 0.0 |  |  |  | 35.0 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 117.5 |  |  |  | 0.0 |  |  |  | 117.5 |  |  |  | 0.0 |  |
| Money market funds |  |  | 1,199.3 |  |  |  | 1,199.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 56.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 56.0 |  |
| Equity funds |  |  | 23.6 |  |  |  | 23.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Private equity fund |  |  | 1.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.0 |  |
| Foreign currency contracts |  |  | 3.0 |  |  |  | 0.0 |  |  |  | 3.0 |  |  |  | 0.0 |  |
| Total |  | $ | 3,663.5 |  |  | $ | 1,222.9 |  |  | $ | 2,383.6 |  |  | $ | 57.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | 7.2 |  |  | $ | 0.0 |  |  | $ | 7.2 |  |  | $ | 0.0 |  |

[0001193125-11-330462:notes:117]
[same as prior period, unchanged from 0001193125-11-239169:notes:126]

[0001193125-11-330462:notes:118]
The table below provides a reconciliation of the beginning and ending balance of our Level 3 auction rate securities measured at fair value on a recurring basis using significant unobservable inputs as of October 28, 2011 and October 29, 2010 (in millions):

[0001193125-11-330462:notes:119]
All of our auction rate securities (ARSs) are classified as long-term investments and are backed by pools of student loans guaranteed by the U.S. Department of Education. As of October 28, 2011, we recorded cumulative net temporary impairment charges of $2.8 million within accumulated other comprehensive income (AOCI). Prior to the three months ended October 28, 2011, we estimated the fair value for each individual ARS using an income (discounted cash flow) approach that incorporates both observable and unobservable inputs to discount the expected future cash flows. Key inputs into the discounted cash flow analysis include managements' expectation of when the principal amount will be recovered either through redemption at par, a refinancing event by the issuer and/or marketability adjustments. As of October 28, 2011, we added the market approach to the valuation technique in order to incorporate secondary market activity into our estimated fair value for each individual ARS. This change had no material impact on the valuation of our ARS portfolio. Based on our ability to access our cash and other short-term investments, our expected operating cash flows, and our other sources of cash, we do not intend to sell these investments prior to recovery of value. We will continue to monitor our ARS investments in light of the current debt market environment and evaluate our accounting for these investments.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-11-330462:notes:120]
6. Goodwill and Purchased Intangible Assets

[0001193125-11-330462:notes:121]
[same as prior period, unchanged from 0001193125-11-239169:notes:130]

[0001193125-11-330462:notes:122]
| Goodwill: |  |  |  |  |
| April 29, 2011 |  | $ | 760.3 |  |
| Additions |  |  | 143.7 |  |
| October 28, 2011 |  | $ | 904.0 |  |

[0001193125-11-330462:notes:123]
|  |  | October 28, 2011 |  |  | April 29, 2011 |  |
|  |  | GrossAssets |  |  | AccumulatedAmortization |  |  | NetAssets |  |  | GrossAssets |  |  | AccumulatedAmortization |  |  | NetAssets |  |
| Identified Intangible Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | $ | 282.1 |  |  | $ | (51.1 | ) |  | $ | 231.0 |  |  | $ | 66.1 |  |  | $ | (23.2 | ) |  | $ | 42.9 |  |
| Customer contracts/relationships |  |  | 59.5 |  |  |  | (20.0 | ) |  |  | 39.5 |  |  |  | 12.0 |  |  |  | (4.6 | ) |  |  | 7.4 |  |
| Trademarks and trade names |  |  | 14.7 |  |  |  | (7.7 | ) |  |  | 7.0 |  |  |  | 7.7 |  |  |  | (5.5 | ) |  |  | 2.2 |  |
| Covenants not to compete |  |  | 2.2 |  |  |  | (0.6 | ) |  |  | 1.6 |  |  |  | 0.6 |  |  |  | (0.1 | ) |  |  | 0.5 |  |
| Total identified intangible assets |  | $ | 358.5 |  |  | $ | (79.4 | ) |  | $ | 279.1 |  |  | $ | 86.4 |  |  | $ | (33.4 | ) |  | $ | 53.0 |  |

[0001193125-11-330462:notes:124]
[same as prior period, unchanged from 0001193125-11-239169:notes:133]

[0001193125-11-330462:notes:125]
As of October 28, 2011, future amortization expense related to identifiable intangible assets is as follows (in millions):

[0001193125-11-330462:notes:126]
| Fiscal Year |  | Amount |  |
| Remainder of 2012 |  | $ | 43.0 |  |
| 2013 |  |  | 84.2 |  |
| 2014 |  |  | 52.0 |  |
| 2015 |  |  | 50.7 |  |
| 2016 |  |  | 46.9 |  |
| 2017 |  |  | 2.3 |  |
| Total |  | $ | 279.1 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-11-330462:notes:127]
12. Income Taxes

[0001193125-11-330462:notes:128]
Our effective tax rates for the periods presented were as follows:

[0001193125-11-330462:notes:129]
|  |  | Six Months Ended |  |
|  |  | October 28, 2011 |  |  | October 29, 2010 |  |
| Effective tax rates |  |  | 13.1 | % |  |  | 12.6 | % |

[0001193125-11-330462:notes:130]
Our effective tax rates reflect the impact of a significant amount of our earnings being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. As of October 28, 2011, we had $135.5 million of unrecognized tax benefits, of which $103.9 million has been recorded in other long-term liabilities.

[0001193125-11-330462:notes:131]
We are currently undergoing income tax audits in the United States and several foreign tax jurisdictions. The rights to some of our intellectual property (IP) are owned by certain of our foreign subsidiaries, and payments are made between U.S. and foreign tax jurisdictions relating to the use of this IP in a qualified cost sharing arrangement. In recent years, several other U.S. companies have had their foreign IP arrangements challenged as part of Internal Revenue Service (IRS) examinations, which have resulted in material proposed assessments and/or litigation with respect to those companies.

[0001193125-11-330462:notes:132]
[same as prior period, unchanged from 0001193125-11-239169:notes:141]

[0001193125-11-330462:notes:133]
On September 17, 2010, the Danish tax authorities issued a decision concluding that distributions declared in 2005 and 2006 from our Danish subsidiary, for which we have not paid or accrued any taxes, are subject to Danish at-source dividend withholding tax. We believe the assessment is without merit and have appealed this assessment decision with the Danish National Tax Tribunal. An oral hearing before the Danish National Tax Tribunal will occur on December 14, 2011.

[0001193125-11-330462:notes:134]
[same as prior period, unchanged from 0001193125-11-239169:notes:143]

[0001193125-11-330462:notes:135]
In April 2010, our Dutch subsidiary received a favorable tax ruling from the Dutch tax authorities effective May 1, 2010 that replaced the previous Dutch tax ruling that expired on April 30, 2010. This ruling resulted in both a lower level of earnings subject to tax in the Netherlands and an extension of the expiration date to April 30, 2015.

[0001193125-11-330462:notes:136]
On December 17, 2010, the Tax Relief Unemployment Insurance Reauthorization, and Job Creation Act of 2010 (the Act) was signed into law. Under the Act, the federal research credit was retroactively extended for amounts paid or incurred after December 31, 2009, and before January 1, 2012. Unless extended again, the federal research credit will expire on December 31, 2011.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-11-330462:notes:137]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Purchased components |  | $ | 29.8 |  |  | $ | 7.5 |  |
| Work-in-process |  |  | 0.5 |  |  |  | 0.1 |  |
| Finished goods |  |  | 133.0 |  |  |  | 100.9 |  |
|  |  | $ | 163.3 |  |  | $ | 108.5 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-11-330462:notes:138]
2. Condensed Consolidated Financial Statements

[0001193125-11-330462:notes:139]
Fiscal Year — We operate on a 52- or 53-week year ending on the last Friday in April. The first and second quarters of fiscal 2012 and 2011 were each 13-week periods.

[0001193125-11-330462:notes:140]
Basis of Presentation — The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments that are, in the opinion of management, necessary for a fair presentation of our financial position, results of operations, and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, the statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with the Company's audited consolidated financial statements as of and for the fiscal year ended April 29, 2011 contained in the Company's Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 23, 2011. The results of operations for the three and six months ended October 28, 2011 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001193125-11-330462:notes:141]
Financial Statements Presentation — Certain prior period amounts have been reclassified in the accompanying condensed consolidated financial statements to conform to current year presentation.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-11-330462:notes:142]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Land |  | $ | 206.1 |  |  | $ | 204.7 |  |
| Buildings and building improvements |  |  | 417.3 |  |  |  | 406.2 |  |
| Leasehold improvements |  |  | 82.5 |  |  |  | 79.3 |  |
| Computers, production, engineering and other equipment |  |  | 585.5 |  |  |  | 475.5 |  |
| Software |  |  | 286.8 |  |  |  | 270.4 |  |
| Furniture and fixtures |  |  | 69.0 |  |  |  | 61.5 |  |
| Construction-in-progress |  |  | 156.3 |  |  |  | 91.9 |  |
|  |  |  | 1,803.5 |  |  |  | 1,589.5 |  |
| Accumulated depreciation and amortization |  |  | (757.4 | ) |  |  | (677.9 | ) |
|  |  | $ | 1,046.1 |  |  | $ | 911.6 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001193125-11-330462:notes:143]
Accounting Standards Recently Adopted

[0001193125-11-330462:notes:144]
[same as prior period, unchanged from 0001193125-11-239169:notes:152]

[0001193125-11-330462:notes:145]
[same as prior period, unchanged from 0001193125-11-239169:notes:153]

[0001193125-11-330462:notes:146]
[same as prior period, unchanged from 0001193125-11-239169:notes:154]

[0001193125-11-330462:notes:147]
[same as prior period, unchanged from 0001193125-11-239169:notes:155]

[0001193125-11-330462:notes:148]
[same as prior period, unchanged from 0001193125-11-239169:notes:156]

[0001193125-11-330462:notes:149]
We elected to early adopt these standards in the fourth quarter of fiscal 2011, and the standards were applied retrospectively from the beginning of fiscal 2011 for new and materially modified revenue arrangements originating after April 30, 2010. Previously reported quarterly results have been adjusted to reflect the adoption of these standards and differ from the originally reported results.

[0001193125-11-330462:notes:150]
[same as prior period, unchanged from 0001193125-11-239169:notes:158]

[0001193125-11-330462:notes:151]
Our product revenue also includes revenue from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer-negotiated refunds or return rights for the delivered elements.

[0001193125-11-330462:notes:152]
For transactions entered into or materially modified after April 30, 2010, we recognize revenue in accordance with the new accounting standards when applicable. Certain arrangements with multiple deliverables may continue to have software deliverables that are subject to the existing software revenue recognition guidance along with non-software deliverables that are subject to the new standards. The revenue for these multiple element arrangements is allocated to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement using the selling price hierarchy set forth in the standards.

[0001193125-11-330462:notes:153]
[same as prior period, unchanged from 0001193125-11-239169:notes:161]

[0001193125-11-330462:notes:154]
[same as prior period, unchanged from 0001193125-11-239169:notes:162]

[0001193125-11-330462:notes:155]
When VSOE cannot be established, the Company attempts to establish the selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE for our products or services.

[0001193125-11-330462:notes:156]
When we are unable to establish selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

[0001193125-11-330462:notes:157]
[same as prior period, unchanged from 0001193125-11-239169:notes:165]

[0001193125-11-330462:notes:158]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal year 2011, we recognize revenue based on software revenue recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be delivered at a future date and VSOE of fair value of all undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is software entitlements and maintenance (SEM) and/or service. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the contract fee is recognized as product revenue. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire arrangement is recognized ratably over the maintenance period.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-11-330462:notes:159]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Accumulated translation adjustments |  | $ | 8.5 |  |  | $ | 11.6 |  |
| Accumulated unrealized gain (loss) on available-for-sale investments |  |  | (2.0 | ) |  |  | 3.4 |  |
| Accumulated unrealized gain (loss) on derivatives qualifying as cash flow hedges |  |  | 0.5 |  |  |  | (2.2 | ) |
| Total accumulated other comprehensive income |  | $ | 7.0 |  |  | $ | 12.8 |  |


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001193125-11-330462:notes:160]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| United States |  | $ | 2,240.3 |  |  | $ | 3,037.5 |  |
| International |  |  | 2,465.5 |  |  |  | 2,211.8 |  |
| Total cash, cash equivalents, restricted cash and investments |  | $ | 4,705.8 |  |  | $ | 5,249.3 |  |


## us-gaap:ScheduleOfCompensationCostForShareBasedPaymentArrangementsAllocationOfShareBasedCompensationCostsByPlanTableTextBlock

[0001193125-11-330462:notes:161]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Employee stock options |  | $ | 14.7 |  |  | $ | 13.0 |  |  | $ | 29.2 |  |  | $ | 25.9 |  |
| RSUs and restricted stock awards |  |  | 38.9 |  |  |  | 18.0 |  |  |  | 73.3 |  |  |  | 37.8 |  |
| ESPP |  |  | 9.4 |  |  |  | 6.7 |  |  |  | 18.6 |  |  |  | 18.3 |  |
| Total stock-based compensation expense |  | $ | 63.0 |  |  | $ | 37.7 |  |  | $ | 121.1 |  |  | $ | 82.0 |  |


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0001193125-11-330462:notes:162]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Net income |  | $ | 165.6 |  |  | $ | 175.4 |  |  | $ | 305.1 |  |  | $ | 326.1 |  |
| Change in currency translation adjustments |  |  | (2.1 | ) |  |  | 3.7 |  |  |  | (3.1 | ) |  |  | 4.2 |  |
| Change in unrealized gain on available-for-sale investments |  |  | (6.2 | ) |  |  | 4.3 |  |  |  | (5.4 | ) |  |  | 6.4 |  |
| Change in unrealized gain (loss) on derivatives qualifying as cash flow hedges |  |  | 0.1 |  |  |  | (1.9 | ) |  |  | 2.7 |  |  |  | (2.4 | ) |
| Comprehensive income |  | $ | 157.4 |  |  | $ | 181.5 |  |  | $ | 299.3 |  |  | $ | 334.3 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-11-330462:notes:163]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Cost of product revenues |  | $ | 1.4 |  |  | $ | 0.8 |  |  | $ | 2.5 |  |  | $ | 1.7 |  |
| Cost of service revenues |  |  | 4.2 |  |  |  | 3.1 |  |  |  | 8.1 |  |  |  | 7.0 |  |
| Sales and marketing |  |  | 30.4 |  |  |  | 17.3 |  |  |  | 59.0 |  |  |  | 37.9 |  |
| Research and development |  |  | 18.2 |  |  |  | 9.2 |  |  |  | 34.2 |  |  |  | 20.3 |  |
| General and administrative |  |  | 8.8 |  |  |  | 7.3 |  |  |  | 17.3 |  |  |  | 15.1 |  |
| Total stock-based compensation expense |  | $ | 63.0 |  |  | $ | 37.7 |  |  | $ | 121.1 |  |  | $ | 82.0 |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001193125-11-330462:notes:164]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| United States |  | $ | 955.8 |  |  | $ | 840.2 |  |
| International |  |  | 90.3 |  |  |  | 71.4 |  |
| Total property and equipment |  | $ | 1,046.1 |  |  | $ | 911.6 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001193125-11-330462:notes:165]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Auction rate securities |  | $ | 56.0 |  |  | $ | 65.1 |  |
| Restricted cash |  |  | 2.7 |  |  |  | 2.8 |  |
| Deferred tax assets, net |  |  | 213.3 |  |  |  | 213.2 |  |
| Other non-current assets |  |  | 172.9 |  |  |  | 127.6 |  |
|  |  | $ | 444.9 |  |  | $ | 408.7 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-11-330462:notes:166]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Arrow Electronics, Inc. |  | $ | 274.2 |  |  | $ | 214.3 |  |  | $ | 487.1 |  |  | $ | 396.3 |  |
| Avnet, Inc. |  |  | 198.8 |  |  | $ | 185.9 |  |  |  | 357.9 |  |  |  | 310.6 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001193125-11-330462:notes:167]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Americas (United States, Canada and Latin America)* |  | $ | 897.1 |  |  | $ | 752.1 |  |  | $ | 1,710.5 |  |  | $ | 1,391.4 |  |
| Europe, Middle East and Africa |  |  | 428.9 |  |  |  | 382.4 |  |  |  | 885.6 |  |  |  | 775.4 |  |
| Asia Pacific and Japan |  |  | 181.0 |  |  |  | 116.5 |  |  |  | 369.1 |  |  |  | 237.9 |  |
| Net revenues |  | $ | 1,507.0 |  |  | $ | 1,251.0 |  |  | $ | 2,965.2 |  |  | $ | 2,404.7 |  |

[0001193125-11-330462:notes:168]
| * | Sales to the United States accounted for $770.4 million and $678.1 million in the three months ended October 28, 2011 and October 29, 2010, respectively, and $1,459.7 million and $1,248.7 million in the six months ended October 28, 2011 and October 29, 2010, respectively. |


## us-gaap:ScheduleOfShareBasedCompensationEmployeeStockPurchasePlanActivityTableTextBlock

[0001193125-11-330462:notes:169]
|  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |
| Weighted-average fair value per right granted |  | $ | 15.88 |  |  | $ | 11.79 |  |
| Shares issued under the ESPP |  |  | 1.1 |  |  |  | 2.8 |  |
| Weighted-average price of shares issued |  | $ | 39.17 |  |  | $ | 11.08 |  |


## us-gaap:ScheduleOfShareBasedCompensationRestrictedStockUnitsAwardActivityTableTextBlock

[0001193125-11-330462:notes:170]
|  |  | Numbers ofShares |  |  | Weighted-AverageGrant DateFair Value |  |
| Outstanding at April 29, 2011 |  |  | 10.1 |  |  | $ | 35.79 |  |
| RSUs granted |  |  | 4.9 |  |  |  | 49.85 |  |
| RSUs vested |  |  | (1.7 | ) |  |  | 24.15 |  |
| RSUs forfeitures and cancellations |  |  | (0.4 | ) |  |  | 38.99 |  |
| Outstanding at October 28, 2011 |  |  | 12.9 |  |  | $ | 42.50 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-11-330462:notes:171]
|  |  | Number ofShares |  |  | Weighted-AverageExercisePrice |  |  | Weighted-AverageRemainingContractual Term (Years) |  |  | AggregateIntrinsicValue |  |
| Outstanding at April 29, 2011 |  |  | 24.5 |  |  | $ | 26.62 |  |  |  |  |  |  |  |  |  |
| Options granted |  |  | 2.0 |  |  |  | 51.71 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (1.8 | ) |  |  | 22.86 |  |  |  |  |  |  |  |  |  |
| Options forfeitures and cancellations |  |  | (0.3 | ) |  |  | 31.44 |  |  |  |  |  |  |  |  |  |
| Outstanding at October 28, 2011 |  |  | 24.4 |  |  | $ | 28.92 |  |  |  | 4.10 |  |  | $ | 349.3 |  |
| Options vested and expected to vest as of October 28, 2011 |  |  | 23.4 |  |  | $ | 28.43 |  |  |  | 4.03 |  |  | $ | 342.8 |  |
| Exercisable at October 28, 2011 |  |  | 14.9 |  |  | $ | 24.79 |  |  |  | 3.31 |  |  | $ | 255.2 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-11-330462:notes:172]
14. Segment, Geographic, and Significant Customer Information

[0001193125-11-330462:notes:173]
We operate in one reportable industry segment: the design, manufacturing, marketing, and technical support of high-performance networked storage solutions. Our company conducts business globally, and our sales and support activities are managed on a geographic basis. Our management reviews financial information presented on a consolidated basis, accompanied by disaggregated information it receives from its internal management system about revenues by geographic region, based on the location from which the customer relationship is managed, for purposes of allocating resources and evaluating financial performance. We do not allocate costs of revenues, research and development, sales and marketing, or general and administrative expenses to our geographic regions in this internal management system because management does not review operations or operating results, or make planning decisions, below the consolidated entity level.

[0001193125-11-330462:notes:174]
Summarized revenues by geographic region based on our internal management system and as utilized by our Chief Executive Officer, who is considered our Chief Operating Decision Maker (CODM), is as follows (in millions):

[0001193125-11-330462:notes:175]
The majority of our assets, excluding cash, cash equivalents, restricted cash, investments and accounts receivable, as of October 28, 2011 and April 29, 2011 were attributable to our U.S. operations. The following table presents total cash, cash equivalents, restricted cash and investments held in the United States and outside of the United States in various foreign subsidiaries (in millions):

[0001193125-11-330462:notes:176]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment information for geographic areas based on the physical location of the assets (in millions):

[0001193125-11-330462:notes:177]
No more than ten percent of property and equipment was located in any single foreign country.

[0001193125-11-330462:notes:178]
For the three and six months ended October 28, 2011, there were no international sales to a single foreign country that accounted for ten percent or more of net revenues. For the three and six months ended October 29, 2010, international sales to Germany of $156.3 million and $296.9 million, respectively, accounted for ten percent or more of net revenues.

[0001193125-11-330462:notes:179]
The following customers, each of which is a distributor, accounted for ten percent or more of our net revenues (in millions):

[0001193125-11-330462:notes:180]
The following customers accounted for ten percent or more of net accounts receivable (in millions):


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-11-330462:notes:181]
3. Significant Accounting Policies

[0001193125-11-330462:notes:182]
There have been no significant changes in our significant accounting policies for the six months ended October 28, 2011, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2011.

[0001193125-11-330462:notes:183]
[same as prior period, unchanged from 0001193125-11-239169:notes:177]

[0001193125-11-330462:notes:184]
In September 2011, the FASB issued a revised accounting standard intended to simplify how an entity tests goodwill for impairment. The revised standard will allow an entity to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. An entity will no longer be required to calculate the fair value of a reporting unit unless it determines, based on a qualitative assessment, that it is more likely than not that its fair value is less than its carrying amount. This guidance is effective for us beginning in our first quarter of fiscal 2013. We do not expect this guidance to have a material impact on our consolidated financial statements.

[0001193125-11-330462:notes:185]
In June 2011, the FASB issued new guidance on the presentation of comprehensive income. Specifically, the new guidance requires an entity to present components of net income and other comprehensive income in one continuous statement, referred to as the statement of comprehensive income, or in two separate, but consecutive statements. The new guidance eliminates the current option to report other comprehensive income and its components in the statement of stockholders' equity. While the new guidance changes the presentation of comprehensive income, there are no changes to the components that are recognized in net income or other comprehensive income under current accounting guidance. This new guidance is effective for us beginning in our first quarter of fiscal 2013 and is required to be applied retrospectively. There will be no impact to our results as the guidance relates only to financial statement presentation.

[0001193125-11-330462:notes:186]
In May 2011, the FASB issued new guidance for fair value measurements to provide a consistent definition of fair value and ensure that the fair value measurement and disclosure requirements are similar between GAAP and International Financial Reporting Standards. The guidance changes certain fair value measurement principles and enhances the disclosure requirements, particularly for level 3 fair value measurements. The guidance is effective for us prospectively beginning in the fourth quarter of fiscal 2012, and we are currently evaluating the impact of adoption on our consolidated financial statements.

[0001193125-11-330462:notes:187]
[same as prior period, unchanged from 0001193125-11-239169:notes:180]

[0001193125-11-330462:notes:188]
The preparation of the consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; self-insurance; stock-based compensation; loss contingencies; investment impairments; income taxes, and fair value measurements. Actual results could differ from those estimates.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-11-330462:notes:189]
10. Stockholders' Equity

[0001193125-11-330462:notes:190]
[same as prior period, unchanged from 0001193125-11-239169:notes:183]

[0001193125-11-330462:notes:191]
A summary of the combined activity under our stock option plans and agreements is as follows (in millions, except for the exercise price and term):

[0001193125-11-330462:notes:192]
The aggregate intrinsic value of stock options represents the pre-tax difference between the exercise price of stock options and the market price of our stock on that day for all in-the-money options. Additional information related to our stock options is summarized below (in millions, except per share information):

[0001193125-11-330462:notes:193]
There was $93.2 million of total unrecognized compensation expense as of October 28, 2011 related to options. The unrecognized compensation expense will be amortized on a straight-line basis over a weighted-average remaining period of 2.3 years.

[0001193125-11-330462:notes:194]
The following table summarizes activity related to our restricted stock units (RSUs) (in millions, except for the fair value):

[0001193125-11-330462:notes:195]
RSUs are converted into common stock upon vesting. Upon the vesting of RSUs, we primarily use the net share settlement approach, where a portion of the shares are withheld and retired as settlement of statutory employee withholding taxes and decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001193125-11-330462:notes:196]
As of October 28, 2011, there was $366.7 million of total unrecognized compensation expense related to RSUs. The unrecognized compensation expense will be amortized on a straight-line basis over a weighted-average remaining vesting period of 2.8 years.

[0001193125-11-330462:notes:197]
Employee Stock Purchase Plan — Under the Employee Stock Purchase Plan (ESPP), employees are entitled to purchase shares of our common stock at a 15% discount from the quoted market price of our common stock at certain specified dates over a two-year period. Additional information related to our purchase rights issued under the ESPP is provided below (in millions, except per share information):

[0001193125-11-330462:notes:198]
There were no ESPP shares issued during the three months ended October 28, 2011 and October 29, 2010.

[0001193125-11-330462:notes:199]
[same as prior period, unchanged from 0001193125-11-239169:notes:191]

[0001193125-11-330462:notes:200]
Stock-based compensation expense included in the condensed consolidated statements of operations for the three and six months ended October 28, 2011 and October 29, 2010, respectively, is as follows (in millions):

[0001193125-11-330462:notes:201]
[same as prior period, unchanged from 0001193125-11-239169:notes:193]

[0001193125-11-330462:notes:202]
Total income tax benefits associated with employee stock transactions and recognized in stockholders' equity were as follows (in millions):

[0001193125-11-330462:notes:203]
[same as prior period, unchanged from 0001193125-11-239169:notes:195]

[0001193125-11-330462:notes:204]
The fair value of each award is estimated on the date of grant using the Black-Scholes option pricing model, assuming no expected dividends and the following weighted-average assumptions:

[0001193125-11-330462:notes:205]
No new employee purchase rights were granted under the ESPP during the three months ended October 28, 2011 and October 29, 2010.

[0001193125-11-330462:notes:206]
[same as prior period, unchanged from 0001193125-11-239169:notes:197]

[0001193125-11-330462:notes:207]
During the six months ended October 28, 2011, 14.4 million shares of our common stock were repurchased as described below. Since the May 13, 2003 inception of our stock repurchase program through October 28, 2011, we repurchased a total of 118.7 million shares of our common stock at an average price of $29.70 per share, for an aggregate purchase price of $3.5 billion. As of October 28, 2011, our Board of Directors had authorized the repurchase of up to $4.0 billion of common stock under this stock repurchase program, and $0.5 billion remains available under these authorizations. The stock repurchase program may be suspended or discontinued at any time.

[0001193125-11-330462:notes:208]
Accelerated Share Repurchase Agreements

[0001193125-11-330462:notes:209]
On July 8, 2011, we entered into a collared accelerated share repurchase agreement (ASR) with Bank of America, N.A, under which we prepaid $200.0 million to purchase shares of our common stock. The aggregate number of shares ultimately purchased was determined based on the volume weighted-average share price of our common stock over a specified period of time. The contract was settled in August 2011. The total number of shares repurchased and retired under this ASR was 4.1 million shares at a weighted-average price of $48.30.

[0001193125-11-330462:notes:210]
On August 19, 2011, we entered into a new ASR with Wells Fargo Bank, National Association (Wells Fargo), under which we prepaid $400.0 million to purchase shares of our common stock. The aggregate number of shares ultimately purchased was determined based on the volume weighted-average share price of our common stock over a specified period of time, subject to certain provisions that establish a minimum and maximum number of shares that may be repurchased. On August 25, 2011, Wells Fargo delivered 10.3 million minimum shares, which were retired immediately. The contract was settled on November 17, 2011, and we received an additional 0.2 million shares at this time. The total number of shares repurchased and retired under this ASR was 10.5 million shares at a weighted-average price of $38.08.

[0001193125-11-330462:notes:211]
The value of the contracts was allocated to the cost of the shares repurchased and to the value of the ASR forward contracts as follows for the six months ended October 28, 2011 (in millions):

[0001193125-11-330462:notes:212]
[same as prior period, unchanged from 0001193125-11-239169:notes:203]

[0001193125-11-330462:notes:213]
The components of accumulated other comprehensive income, net of related immaterial tax effects, were as follows (in millions):

[0001193125-11-330462:notes:214]
The components of comprehensive income, net of related immaterial tax effects, were as follows (in millions):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-11-330462:notes:215]
7. Balance Sheet Detail

[0001193125-11-330462:notes:216]
[same as prior period, unchanged from 0001193125-11-239169:notes:207]

[0001193125-11-330462:notes:217]
[same as prior period, unchanged from 0001193125-11-239169:notes:208]

[0001193125-11-330462:notes:218]
[same as prior period, unchanged from 0001193125-11-239169:notes:209]

[0001193125-11-330462:notes:219]
[same as prior period, unchanged from 0001193125-11-239169:notes:210]

[0001193125-11-330462:notes:220]
[same as prior period, unchanged from 0001193125-11-239169:notes:211]

[0001193125-11-330462:notes:221]
Other non-current assets (in millions):

[0001193125-11-330462:notes:222]
[same as prior period, unchanged from 0001193125-11-239169:notes:213]
