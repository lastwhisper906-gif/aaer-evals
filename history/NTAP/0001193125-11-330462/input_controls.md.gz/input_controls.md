# NTAP 10-Q controls and the auditor's report


## item_4_controls

[0001193125-11-330462:item_4_controls:1]
Item 4. Controls and Procedures

[0001193125-11-330462:item_4_controls:2]
Disclosure controls are controls and procedures designed to ensure that information required to be disclosed in our reports filed or
submitted under the Securities Exchange Act of 1934, as amended (the Exchange Act), such as this Quarterly Report on Form 10-Q, is recorded, processed, summarized, and reported within the time periods specified in the U.S. Securities and Exchange
Commission’s rules and forms. Disclosure controls and procedures are also designed to ensure that such information is accumulated and communicated to our management, including the CEO and CFO, as appropriate to allow timely decisions regarding
required disclosure.

[0001193125-11-330462:item_4_controls:3]
Under the supervision and with the participation of our management, including our CEO and CFO, we
conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, as of October 28, 2011, the end of the fiscal period covered
by this Quarterly Report on Form 10-Q (the Evaluation Date). Based on this evaluation, our CEO and CFO concluded as of the Evaluation Date that our disclosure controls and procedures were effective such that the information relating to NetApp,
including our consolidated subsidiaries, required to be disclosed in our Securities and Exchange Commission (SEC) reports (i) is recorded, processed, summarized, and reported within the time periods specified in SEC rules and forms, and
(ii) is accumulated and communicated to our management, including our CEO and CFO, as appropriate to allow timely decisions regarding required disclosure.

[0001193125-11-330462:item_4_controls:4]
As a result of our acquisition of the Engenio business on May 6, 2011, our internal control over financial reporting, subsequent to the date of acquisition, includes certain additional controls
relating to Engenio. Except as described above, there were no other changes in our internal control over financial reporting that occurred during the period covered by this Quarterly Report on Form 10-Q that has materially affected, or is reasonably
likely to materially affect, our internal control over financial reporting.

[0001193125-11-330462:item_4_controls:5]
42
