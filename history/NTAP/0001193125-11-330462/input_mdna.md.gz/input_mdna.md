# NTAP MD&A — 0001193125-11-330462


## mdna

[0001193125-11-330462:mdna:1]
Item 2. Management’s Discussion and Analysis of Financial Condition
and Results of Operations

[0001193125-11-330462:mdna:2]
[same as prior period, unchanged from 0001193125-11-239169:mdna:2]

[0001193125-11-330462:mdna:3]
[same as prior period, unchanged from 0001193125-11-239169:mdna:3]

[0001193125-11-330462:mdna:4]
[same as prior period, unchanged from 0001193125-11-239169:mdna:4]

[0001193125-11-330462:mdna:5]
[same as prior period, unchanged from 0001193125-11-239169:mdna:5]

[0001193125-11-330462:mdna:6]
[same as prior period, unchanged from 0001193125-11-239169:mdna:6]

[0001193125-11-330462:mdna:7]
|  | • |  | acquisitions and joint ventures, growth opportunities, investments and legal proceedings; |

[0001193125-11-330462:mdna:8]
[same as prior period, unchanged from 0001193125-11-239169:mdna:8]

[0001193125-11-330462:mdna:9]
[same as prior period, unchanged from 0001193125-11-239169:mdna:9]

[0001193125-11-330462:mdna:10]
[same as prior period, unchanged from 0001193125-11-239169:mdna:10]

[0001193125-11-330462:mdna:11]
[same as prior period, unchanged from 0001193125-11-239169:mdna:11]

[0001193125-11-330462:mdna:12]
[same as prior period, unchanged from 0001193125-11-239169:mdna:12]

[0001193125-11-330462:mdna:13]
|  | • |  | the conversion, maturation or repurchase of the Notes, |

[0001193125-11-330462:mdna:14]
|  | • |  | compliance with laws, regulations and debt covenants; |

[0001193125-11-330462:mdna:15]
[same as prior period, unchanged from 0001193125-11-239169:mdna:15]

[0001193125-11-330462:mdna:16]
[same as prior period, unchanged from 0001193125-11-239169:mdna:16]

[0001193125-11-330462:mdna:17]
[same as prior period, unchanged from 0001193125-11-239169:mdna:17]

[0001193125-11-330462:mdna:18]
[same as prior period, unchanged from 0001193125-11-239169:mdna:18]

[0001193125-11-330462:mdna:19]
|  | • |  | general economic and market conditions, particularly the continuing fiscal challenges in the U.S. and Europe; |

[0001193125-11-330462:mdna:20]
|  | • |  | the effects of the recent flooding in Thailand; |

[0001193125-11-330462:mdna:21]
[same as prior period, unchanged from 0001193125-11-239169:mdna:20]

[0001193125-11-330462:mdna:22]
[same as prior period, unchanged from 0001193125-11-239169:mdna:21]

[0001193125-11-330462:mdna:23]
[same as prior period, unchanged from 0001193125-11-239169:mdna:22]

[0001193125-11-330462:mdna:24]
[same as prior period, unchanged from 0001193125-11-239169:mdna:23]

[0001193125-11-330462:mdna:25]
[same as prior period, unchanged from 0001193125-11-239169:mdna:24]

[0001193125-11-330462:mdna:26]
[same as prior period, unchanged from 0001193125-11-239169:mdna:25]

[0001193125-11-330462:mdna:27]
[same as prior period, unchanged from 0001193125-11-239169:mdna:26]

[0001193125-11-330462:mdna:28]
[same as prior period, unchanged from 0001193125-11-239169:mdna:27]

[0001193125-11-330462:mdna:29]
[same as prior period, unchanged from 0001193125-11-239169:mdna:28]

[0001193125-11-330462:mdna:30]
[same as prior period, unchanged from 0001193125-11-239169:mdna:29]

[0001193125-11-330462:mdna:31]
[same as prior period, unchanged from 0001193125-11-239169:mdna:30]

[0001193125-11-330462:mdna:32]
[same as prior period, unchanged from 0001193125-11-239169:mdna:31]

[0001193125-11-330462:mdna:33]
[same as prior period, unchanged from 0001193125-11-239169:mdna:32]

[0001193125-11-330462:mdna:34]
[same as prior period, unchanged from 0001193125-11-239169:mdna:33]

[0001193125-11-330462:mdna:35]
[same as prior period, unchanged from 0001193125-11-239169:mdna:34]

[0001193125-11-330462:mdna:36]
[same as prior period, unchanged from 0001193125-11-239169:mdna:35]

[0001193125-11-330462:mdna:37]
[same as prior period, unchanged from 0001193125-11-239169:mdna:36]

[0001193125-11-330462:mdna:38]
[same as prior period, unchanged from 0001193125-11-239169:mdna:37]

[0001193125-11-330462:mdna:39]
[same as prior period, unchanged from 0001193125-11-239169:mdna:38]

[0001193125-11-330462:mdna:40]
[same as prior period, unchanged from 0001193125-11-239169:mdna:39]

[0001193125-11-330462:mdna:41]
[same as prior period, unchanged from 0001193125-11-239169:mdna:40]

[0001193125-11-330462:mdna:42]
[same as prior period, unchanged from 0001193125-11-239169:mdna:41]

[0001193125-11-330462:mdna:43]
|  | • |  | the results of our ongoing litigation, tax audits, government audits, inquiries and investigations; and |

[0001193125-11-330462:mdna:44]
[same as prior period, unchanged from 0001193125-11-239169:mdna:43]

[0001193125-11-330462:mdna:45]
[same as prior period, unchanged from 0001193125-11-239169:mdna:44]

[0001193125-11-330462:mdna:46]
[same as prior period, unchanged from 0001193125-11-239169:mdna:45]

[0001193125-11-330462:mdna:47]
On May 6, 2011, we completed the acquisition of certain
assets related to the Engenio external storage systems business (Engenio) of LSI Corporation (LSI). We paid LSI $480.0 million in cash and also assumed certain liabilities related to Engenio. We expect this acquisition to enable us to address
growing customer requirements in the areas of high bandwidth and intensive analytics workloads such as video, including full-motion video capture and digital video surveillance, as well as high performance computing applications, such as genomics
sequencing and scientific research. Our consolidated net revenues for the three and six months ended October 28, 2011 include $182.4 million and $339.5 million, respectively, attributable to Engenio since the acquisition.

[0001193125-11-330462:mdna:48]
[same as prior period, unchanged from 0001193125-11-239169:mdna:59]

[0001193125-11-330462:mdna:49]
Net revenues for the three and six months ended October 28, 2011 were $1,507.0 million,
up $256.0 million, or 20%, and were $2,965.2 million, up $560.5 million, or 23%, respectively, from the comparable periods in the prior year. The revenue growth in each of these periods was primarily due to our acquisition of Engenio, continued
demand for our storage efficiency and data management solutions, and an increase in hardware maintenance contract revenue. Gross profit as a percentage of net revenues decreased during the three and six months ended October 28, 2011 compared to
the same periods in the prior year, primarily due to the inclusion of lower gross margin E-Series OEM products resulting from the Engenio acquisition in the revenue mix.

[0001193125-11-330462:mdna:50]
Sales and marketing, research and development, and general and administrative expenses for the three and six months ended October 28, 2011 totaled $718.9 million, up 19% and $1,437.4 million, up 24%,
respectively, from the comparable periods in the prior year. These increases were primarily due to a 27% and 26% increase in average headcount in the three and six months ended October 28, 2011, respectively, from the comparable periods in the
prior year. Approximately half of the headcount growth in the three and six months ended October 28, 2011 is related to the May 2011 acquisition of Engenio.

[0001193125-11-330462:mdna:51]
[same as prior period, unchanged from 0001193125-11-239169:mdna:50]

[0001193125-11-330462:mdna:52]
Our discussion and analysis of
financial condition and results of operations are based upon our condensed consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP). The
preparation of such statements requires us to make estimates and assumptions that affect the reported amounts of revenues and expenses during the reporting periods and the reported amounts of assets and liabilities as of the date of the financial
statements. Our estimates are based on historical experience and other assumptions that we consider to be appropriate under the circumstances. However, future results may vary from our estimates.

[0001193125-11-330462:mdna:53]
We believe the accounting policies discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition
and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended April 29, 2011 are significantly affected by critical accounting estimates and that they are both highly important to the portrayal of our financial
condition and results and require difficult management judgments and assumptions about matters that are inherently uncertain. There have been no material changes to the critical accounting policies and estimates as filed in such report.

[0001193125-11-330462:mdna:54]
[same as prior period, unchanged from 0001193125-11-239169:mdna:53]

[0001193125-11-330462:mdna:55]
See Note 3 of the accompanying condensed consolidated financial statements for a full description of new accounting pronouncements,
including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001193125-11-330462:mdna:56]
All fiscal
year 2011 results reflect the adoption of the new accounting standards related to revenue recognition. Previously reported quarterly results for fiscal 2011 have been adjusted to reflect the adoption of these new standards and differ from the
originally reported results.

[0001193125-11-330462:mdna:57]
[same as prior period, unchanged from 0001193125-11-239169:mdna:56]

[0001193125-11-330462:mdna:58]
The following table sets forth certain Condensed Consolidated Statements of Operations data as a percentage of net revenues for the periods indicated:

[0001193125-11-330462:mdna:59]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 67.4 | % |  |  | 65.9 | % |  |  | 66.8 | % |  |  | 65.0 | % |
| Software entitlements and maintenance |  |  | 13.1 |  |  |  | 14.1 |  |  |  | 13.4 |  |  |  | 14.6 |  |
| Service |  |  | 19.5 |  |  |  | 20.0 |  |  |  | 19.8 |  |  |  | 20.4 |  |
| Net revenues |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 30.5 |  |  |  | 25.9 |  |  |  | 30.3 |  |  |  | 26.4 |  |
| Cost of software entitlements and maintenance |  |  | 0.4 |  |  |  | 0.3 |  |  |  | 0.4 |  |  |  | 0.3 |  |
| Cost of service |  |  | 8.5 |  |  |  | 8.5 |  |  |  | 8.3 |  |  |  | 8.7 |  |
| Gross profit |  |  | 60.6 |  |  |  | 65.3 |  |  |  | 61.0 |  |  |  | 64.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 30.1 |  |  |  | 30.7 |  |  |  | 30.7 |  |  |  | 30.7 |  |
| Research and development |  |  | 13.3 |  |  |  | 12.5 |  |  |  | 13.4 |  |  |  | 12.7 |  |
| General and administrative |  |  | 4.3 |  |  |  | 5.1 |  |  |  | 4.4 |  |  |  | 5.0 |  |
| Restructuring and other charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Acquisition-related expense |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |  |  | — |  |
| Total operating expenses |  |  | 47.8 |  |  |  | 48.3 |  |  |  | 48.6 |  |  |  | 48.4 |  |

[0001193125-11-330462:mdna:60]
[same as prior period, unchanged from 0001193125-11-239169:mdna:73]

[0001193125-11-330462:mdna:61]
| Income from operations |  |  | 12.8 |  |  |  | 17.0 |  |  |  | 12.4 |  |  |  | 16.2 |  |
| Other expense, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 0.5 |  |  |  | 0.8 |  |  |  | 0.6 |  |  |  | 0.8 |  |
| Interest expense |  |  | (1.1 | ) |  |  | (1.5 | ) |  |  | (1.2 | ) |  |  | (1.5 | ) |
| Other income (expense), net |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |  |  | — |  |
| Total other expense, net |  |  | (0.6 | ) |  |  | (0.8 | ) |  |  | (0.6 | ) |  |  | (0.7 | ) |
| Income before income taxes |  |  | 12.2 |  |  |  | 16.2 |  |  |  | 11.8 |  |  |  | 15.5 |  |
| Provision for income taxes |  |  | 1.2 |  |  |  | 2.2 |  |  |  | 1.5 |  |  |  | 1.9 |  |
| Net income |  |  | 11.0 | % |  |  | 14.0 | % |  |  | 10.3 | % |  |  | 13.6 | % |

[0001193125-11-330462:mdna:62]
[same as prior period, unchanged from 0001193125-11-239169:mdna:60]

[0001193125-11-330462:mdna:63]
Net Revenues — Our net revenues for the three and six months ended October 28, 2011 and October 29, 2010 were
as follows (in millions, except percentages):

[0001193125-11-330462:mdna:64]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |
| Net revenues |  | $ | 1,507.0 |  |  | $ | 1,251.0 |  |  |  | 20 | % |  | $ | 2,965.2 |  |  | $ | 2,404.7 |  |  |  | 23 | % |

[0001193125-11-330462:mdna:65]
Net revenues increased by $256.0 million, or 20%, and increased by $560.5 million, or 23%, for the three
and six months ended October 28, 2011, respectively, from the comparable periods in the prior year. The increase in our net revenues for both periods was primarily due to an increase in product revenues, which comprised 67% of net revenues in
each of the three and six months ended October 28, 2011, compared to 66% and 65% in the three and six months ended October 29, 2010, respectively.

[0001193125-11-330462:mdna:66]
Sales through our indirect channels represented 80% and 78% of net revenues for the three and six months ended October 28, 2011, respectively, and represented 72% and 71% of net revenues for the
three and six months ended October 29, 2010, respectively. The increase in our indirect channels as a percentage of net revenues reflects the acquisition of Engenio.

[0001193125-11-330462:mdna:67]
The following customers, each of which is a distributor, accounted for 10% or more of net revenues (in millions, except percentages):

[0001193125-11-330462:mdna:68]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | % of NetRevenues |  |  | October 29,2010 |  |  | % of NetRevenues |  |  | October 28,2011 |  |  | % of NetRevenues |  |  | October 29,2010 |  |  | % of NetRevenues |  |
| Arrow Electronics, Inc. |  | $ | 274.2 |  |  |  | 18 | % |  | $ | 214.3 |  |  |  | 17 | % |  | $ | 487.1 |  |  |  | 16 | % |  | $ | 396.3 |  |  |  | 16 | % |
| Avnet, Inc. |  |  | 198.8 |  |  |  | 13 | % |  |  | 185.9 |  |  |  | 15 | % |  |  | 357.9 |  |  |  | 12 | % |  |  | 310.6 |  |  |  | 13 | % |

[0001193125-11-330462:mdna:69]
[same as prior period, unchanged from 0001193125-11-239169:mdna:67]

[0001193125-11-330462:mdna:70]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |
| Product revenues |  | $ | 1,016.2 |  |  | $ | 824.8 |  |  |  | 23 | % |  | $ | 1,981.9 |  |  | $ | 1,562.3 |  |  |  | 27 | % |

[0001193125-11-330462:mdna:71]
Product revenues increased by $191.4 million, or 23%, and increased by $419.6 million, or 27%, for the
three and six months ended October 28, 2011, respectively, from the comparable periods in the prior year. Product revenues consist of configured systems, which are comprised of bundled hardware and software products, and non-configured
products, which consist primarily of add-on hardware, storage, and software products, as well as OEM products.

[0001193125-11-330462:mdna:72]
Total
configured system revenues of $521.1 million increased by $31.2 million, or 6%, for the three months ended October 28, 2011, and total configured system revenues of $1,031.1 million increased by $75.9 million, or 8%, for the six months ended
October 28, 2011, compared to the prior year, with the largest increase in each period coming from the 6000 series systems. Configured systems unit volume increased by 1% and 2% for the three and six months ended October 28, 2011,
respectively, compared to the prior year, with increases in each period in both the 6000 and 3000 series systems, offset by a decrease in each period in the 2000 series systems. The increases in the unit volume of the 6000 and 3000 series in each
period were due to strong customer demand for these newer systems. The decreases in the 2000 series unit volume in each period were primarily due to a decrease in demand for this older product, as well as a shift in business to the newer 3000 series
systems. The average selling prices (ASPs) of total configured systems increased during the three and six months ended October 28, 2011, compared to the prior year due to a shift in system revenue mix from the lower ASP 2000 series to the
higher ASP 3000 and 6000 series. However, ASP’s across each series decreased compared to the same periods in the prior year due to manufacturing cost reductions being passed along to customers as price reductions.

[0001193125-11-330462:mdna:73]
[same as prior period, unchanged from 0001193125-11-239169:mdna:88]

[0001193125-11-330462:mdna:74]
Non-configured product revenues of $495.1 million increased $160.3 million, or 48%, during
the three months ended October 28, 2011, and non-configured product revenues of $950.8 million increased $343.7 million, or 57%, during the six months ended October 28, 2011, compared to the prior year. These increases were primarily due
to E-Series OEM product revenues of $173.9 million and $329.8 million during the three and six months ended October 28, 2011, respectively, that resulted from the Engenio acquisition. Partially offsetting these increases during the three months
ended October 28, 2011 was a 9% decrease in sales of add-on storage products.

[0001193125-11-330462:mdna:75]
Our systems are highly configurable to respond
to customer requirements in the open systems storage markets that we serve. This can cause a wide variation in product configurations that can significantly impact revenues, cost of revenues and gross profit performance. Pricing changes, discounting
practices, foreign currency, unit volumes, customer mix, natural disasters and product material costs can also impact revenues, cost of revenues and/or gross profit performance. Disks are a significant component of our storage systems. Industry disk
pricing continues to fall every year; however, with the recent flooding in Thailand, disk prices may increase. To the extent that disk prices decrease, we generally pass along those price decreases to our customers while working to maintain
relatively constant profit margins on our disk drives. As our sales price per terabyte continues to decline, improved system performance, increased capacity and software to manage this increased capacity have an offsetting impact on product
revenues.

[0001193125-11-330462:mdna:76]
[same as prior period, unchanged from 0001193125-11-239169:mdna:74]

[0001193125-11-330462:mdna:77]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |
| Software entitlements and maintenance revenues |  | $ | 198.0 |  |  | $ | 176.7 |  |  |  | 12 | % |  | $ | 396.2 |  |  | $ | 350.9 |  |  |  | 13 | % |

[0001193125-11-330462:mdna:78]
Software entitlements and maintenance (SEM) revenues increased by $21.3 million, or 12%, and increased by
$45.3 million, or 13%, during the three and six months ended October 28, 2011, respectively, from the comparable periods in the prior year. The increases in each period were due to an increase in the aggregate contract value of the installed
base under SEM contracts, which is recognized as revenue ratably over the terms of the underlying contracts.

[0001193125-11-330462:mdna:79]
Service
Revenues (in millions, except percentages):

[0001193125-11-330462:mdna:80]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |
| Service revenues |  | $ | 292.8 |  |  | $ | 249.5 |  |  |  | 17 | % |  | $ | 587.1 |  |  | $ | 491.5 |  |  |  | 19 | % |

[0001193125-11-330462:mdna:81]
Service revenues include hardware maintenance, professional services and educational and training
services. Service revenues increased by $43.3 million, or 17%, and by $95.6 million, or 19%, during the three and six months ended October 28, 2011, respectively, from the comparable periods in the prior year. Hardware maintenance contract
revenues increased 27% and 29% during the three and six months ended October 28, 2011, respectively, from the comparable periods in the prior year, as a result of an increase in each period in the installed base under service contracts.
Professional services and educational and training services revenues remained flat during the three months ended October 28, 2011 and increased 2% during the six months ended October 28, 2011, compared to the prior year.

[0001193125-11-330462:mdna:82]
[same as prior period, unchanged from 0001193125-11-239169:mdna:80]

[0001193125-11-330462:mdna:83]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |
| Americas (United States, Canada and Latin America) |  | $ | 897.1 |  |  | $ | 752.1 |  |  |  | 19 | % |  | $ | 1,710.5 |  |  | $ | 1,391.4 |  |  |  | 23 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 428.9 |  |  |  | 382.4 |  |  |  | 12 | % |  |  | 885.6 |  |  |  | 775.4 |  |  |  | 14 | % |
| Asia Pacific and Japan (APAC) |  |  | 181.0 |  |  |  | 116.5 |  |  |  | 55 | % |  |  | 369.1 |  |  |  | 237.9 |  |  |  | 55 | % |
| Net revenues |  | $ | 1,507.0 |  |  | $ | 1,251.0 |  |  |  |  |  |  | $ | 2,965.2 |  |  | $ | 2,404.7 |  |  |  |  |  |

[0001193125-11-330462:mdna:84]
Sales to the United States accounted for 86% and 90% of Americas’ net revenues during
the three months ended October 28, 2011 and October 29, 2010, respectively, and 85% and 90% of America’s net revenue during the six months ended October 28, 2011 and October 29, 2010, respectively. Sales to Germany were less
than 10% of net revenues for both the three and six months ended October 28, 2011. Sales to Germany accounted for 12% of net revenues during each of the three and six months ended October 29, 2010. No other single foreign country accounted
for 10% or more of net revenues in any of the periods presented.

[0001193125-11-330462:mdna:85]
[same as prior period, unchanged from 0001193125-11-239169:mdna:83]

[0001193125-11-330462:mdna:86]
[same as prior period, unchanged from 0001193125-11-239169:mdna:84]

[0001193125-11-330462:mdna:87]
Our gross profit is impacted by a variety of factors, including pricing changes, discounting practices, foreign currency, product
configuration, unit volumes, customer mix, revenue mix, natural disasters and product material costs. Service gross profit is typically impacted by factors such as changes in the size of our installed base of products, as well as the timing of
support service initiations and renewals, and incremental investments in our customer support infrastructure. If any of these factors that impact our gross profit are adversely affected, whether by economic uncertainties or for other reasons, our
gross profit could decline.

[0001193125-11-330462:mdna:88]
[same as prior period, unchanged from 0001193125-11-239169:mdna:86]

[0001193125-11-330462:mdna:89]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 28,2011 |  | October 29,2010 |  | % Change |  | October 28,2011 |  | October 29,2010 |  | % Change |
| Cost of product revenues |  | $ 460.7 |  | $ 324.3 |  | 42% |  | $ 898.1 |  | $ 634.5 |  | 42% |

[0001193125-11-330462:mdna:90]
Cost of product revenues increased by $136.4 million, or 42%, and $263.6 million, or 42%, during the
three and six months ended October 28, 2011, from the comparable periods in the prior year. The changes were comprised of the following elements (in percentage points of the total change):

[0001193125-11-330462:mdna:91]
|  |  | Three Months EndedFiscal 2012 to Fiscal 2011Percentage ChangePoints |  |  | Six Months EndedFiscal 2012 to Fiscal 2011Percentage ChangePoints |  |
| Materials cost |  |  | 33 |  |  |  | 32 |  |
| Amortization of developed technology |  |  | 3 |  |  |  | 3 |  |
| Warranty |  |  | 3 |  |  |  | 2 |  |
| Manufacturing overhead |  |  | 2 |  |  |  | 3 |  |
| Excess and obsolete inventory |  |  | 1 |  |  |  | 2 |  |
| Total change |  |  | 42 |  |  |  | 42 |  |

[0001193125-11-330462:mdna:92]
During the three and six months ended October 28, 2011, the increase in materials cost was primarily
due to $98.5 million and $183.5 million, respectively, in our materials cost relating to the sales of E-Series OEM products resulting from the Engenio acquisition. The increase in materials cost was also impacted by the 1% and 2% unit volume
increases in configured systems during these periods; however, the average cost per unit of configured systems across all product families decreased or remained flat as a result of materials cost reductions across all units offsetting volume
increases during these reporting periods.

[0001193125-11-330462:mdna:93]
The increase in the amortization of developed technology was due to identified
intangible assets acquired from the Engenio acquisition, which are amortized on a straight-line basis over their estimated useful life.

[0001193125-11-330462:mdna:94]
Cost of product revenues represented 45% and 39% of product revenue for the three months ended October 28, 2011 and October 29, 2010, respectively, and 45% and 41% of product revenue for the six
months ended October 28, 2011 and October 29, 2010, respectively. The overall increase in costs as a percentage of revenues for the three and six months ended October 28, 2011 was primarily the result of E-Series OEM products, which
have lower materials margins than configured systems and add-on products.

[0001193125-11-330462:mdna:95]
[same as prior period, unchanged from 0001193125-11-239169:mdna:115]

[0001193125-11-330462:mdna:96]
Cost of Software Entitlements and Maintenance Revenues (in millions, except
percentages):

[0001193125-11-330462:mdna:97]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 28,2011 |  | October 29,2010 |  | % Change |  | October 28,2011 |  | October 29,2010 |  | % Change |
| Cost of software entitlements and maintenance revenues |  | $ 5.6 |  | $ 3.5 |  | 60% |  | $ 10.9 |  | $ 6.9 |  | 58% |

[0001193125-11-330462:mdna:98]
Cost of SEM revenues increased by $2.1 million, or 60%, and $4.0 million, or 58%, during the three and
six months ended October 28, 2011, respectively, from the comparable periods in the prior year, primarily due to an increase in volume-related software support costs. Cost of SEM revenues represented 3% of SEM revenues for both the three and
six months ended October 28, 2011 and 2% of SEM revenues for both the three and six months ended October 29, 2010.

[0001193125-11-330462:mdna:99]
[same as prior period, unchanged from 0001193125-11-239169:mdna:97]

[0001193125-11-330462:mdna:100]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 28,2011 |  | October 29,2010 |  | % Change |  | October 28,2011 |  | October 29,2010 |  | % Change |
| Cost of service revenues |  | $ 127.7 |  | $ 106.7 |  | 20% |  | $ 246.3 |  | $ 209.0 |  | 18% |

[0001193125-11-330462:mdna:101]
Cost of service revenues increased by $21.0 million, or 20%, and $37.3 million, or 18%, during the three
and six months ended October 28, 2011, respectively, from the comparable periods in the prior year primarily due to an increase in installed base resulting in higher service and support purchased from third parties, an increase in logistics
costs, and an accrual for a loss on a single contract. Costs represented 44% and 43% of service revenues for the three months ended October 28, 2011 and October 29, 2010, respectively, and represented 42% and 43% of service revenues for
the six months ended October 28, 2011 and October 29, 2010, respectively.

[0001193125-11-330462:mdna:102]
[same as prior period, unchanged from 0001193125-11-239169:mdna:100]

[0001193125-11-330462:mdna:103]
[same as prior period, unchanged from 0001193125-11-239169:mdna:101]

[0001193125-11-330462:mdna:104]
Compensation costs comprise the largest component of operating expenses. Included in compensation costs are salaries, benefits, other
compensation-related costs, stock-based compensation costs and employee incentive compensation plan costs. Compensation costs included in operating expenses increased approximately $62.4 million, or 20%, and $145.6 million, or 24%, for the
three and six months ended October 28, 2011, respectively, from the comparable periods in the prior year, primarily due to:

[0001193125-11-330462:mdna:105]
(i) an increase in salaries, benefits and other compensation-related costs of $68.1 million and $146.3 million for the three and six months ended October 28, 2011, respectively, due to an increase in
average headcount, which included the impact of the Engenio acquisition;

[0001193125-11-330462:mdna:106]
(ii) an increase in stock-based compensation of
$23.6 million and $37.2 million for the three and six months ended October 28, 2011, respectively, which also included the impact of the Engenio acquisition;

[0001193125-11-330462:mdna:107]
(iii) partially offset by a decrease in incentive compensation expense of $29.2 million and $37.8 million for the three and six months ended October 28, 2011, respectively, due to lower achievement
of performance against operating targets during the three and six months ended October 28, 2011.

[0001193125-11-330462:mdna:108]
Sales and Marketing
(in millions, except percentages):

[0001193125-11-330462:mdna:109]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 28,2011 |  | October 29,2010 |  | % Change |  | October 28,2011 |  | October 29,2010 |  | % Change |
| Sales and marketing expenses |  | $454.1 |  | $382.8 |  | 19% |  | $908.9 |  | $737.0 |  | 23% |

[0001193125-11-330462:mdna:110]
Sales and marketing expense consists primarily of compensation costs, commissions, outside
services, allocated facilities and IT costs, advertising and marketing promotional expense, and travel and entertainment expense. Sales and marketing expenses increased due to the following:

[0001193125-11-330462:mdna:111]
|  |  | Three Months EndedFiscal 2012 to Fiscal 2011Percentage ChangePoints |  |  | Six Months EndedFiscal 2012 to Fiscal 2011Percentage ChangePoints |  |
| Salaries |  |  | 9 |  |  |  | 9 |  |
| Stock-based compensation |  |  | 3 |  |  |  | 3 |  |
| Incentive plan compensation |  |  | (3 | ) |  |  | (2 | ) |
| Other compensation and benefit costs |  |  | 1 |  |  |  | 2 |  |
| Total compensation costs |  |  | 10 |  |  |  | 12 |  |
| Outside services |  |  | 2 |  |  |  | 3 |  |
| Amortization expense |  |  | 2 |  |  |  | 2 |  |
| Commissions |  |  | 1 |  |  |  | 2 |  |
| Facilities and IT support costs |  |  | 1 |  |  |  | 2 |  |
| Advertising and marketing promotional expense |  |  | 1 |  |  |  | 1 |  |
| Other |  |  | 2 |  |  |  | 1 |  |
| Total change |  |  | 19 |  |  |  | 23 |  |

[0001193125-11-330462:mdna:112]
The increase in total compensation costs for the three and six months ended October 28, 2011 reflects
an increase in average sales and marketing headcount of 23% for each period, as compared to the same periods in the prior year. These increases were partially offset by a decrease in incentive compensation expense. Outside services increased to
support sales and marketing initiatives and amortization expense increased due to the addition of intangible assets as a result of the acquisition of Engenio.

[0001193125-11-330462:mdna:113]
[same as prior period, unchanged from 0001193125-11-239169:mdna:111]

[0001193125-11-330462:mdna:114]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 28,2011 |  | October 29,2010 |  | % Change |  | October 28,2011 |  | October 29,2010 |  | % Change |
| Research and development expenses |  | $199.7 |  | $156.6 |  | 28% |  | $398.3 |  | $306.1 |  | 30% |

[0001193125-11-330462:mdna:115]
Research and development expense consists primarily of compensation costs, allocated facilities and IT
costs, depreciation and amortization, equipment and software related costs, prototypes, non-recurring engineering (NRE) charges and other outside services costs. Research and development expenses increased due to the following:

[0001193125-11-330462:mdna:116]
|  |  | Three Months EndedFiscal 2012 to Fiscal 2011Percentage ChangePoints |  |  | Six Months EndedFiscal 2012 to Fiscal 2011Percentage ChangePoints |  |
| Salaries |  |  | 14 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 6 |  |  |  | 4 |  |
| Incentive plan compensation |  |  | (7 | ) |  |  | (4 | ) |
| Other compensation and benefit costs |  |  | 4 |  |  |  | 5 |  |
| Total compensation costs |  |  | 17 |  |  |  | 19 |  |
| Facilities and IT support costs |  |  | 5 |  |  |  | 6 |  |
| Depreciation expense |  |  | 3 |  |  |  | 3 |  |
| NRE charges |  |  | 1 |  |  |  | 1 |  |
| Outside services |  |  | 1 |  |  |  | 1 |  |
| Other |  |  | 1 |  |  |  | — |  |
| Total change |  |  | 28 |  |  |  | 30 |  |

[0001193125-11-330462:mdna:117]
The increase in total compensation costs reflects a 44% and 41% increase in average engineering headcount
during the three and six months ended October 28, 2011, respectively, compared to the same periods in the prior year. These increases were partially offset by a decrease in incentive compensation expense. The increase in facilities and IT
support costs in each period reflects the acquisition of Engenio.

[0001193125-11-330462:mdna:118]
We believe that our future performance will depend in large
part on our ability to maintain and enhance our current product line, develop new products that achieve market acceptance, maintain technological competitiveness and meet an expanding range of customer requirements. We expect to continue to spend on
current and future product development efforts, broaden our existing product offerings and introduce new products that expand our solutions portfolio.

[0001193125-11-330462:mdna:119]
[same as prior period, unchanged from 0001193125-11-239169:mdna:118]

[0001193125-11-330462:mdna:120]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 28,2011 |  | October 29,2010 |  | % Change |  | October 28,2011 |  | October 29,2010 |  | % Change |
| General and administrative expenses |  | $65.1 |  | $64.2 |  | 1% |  | $130.2 |  | $120.4 |  | 8% |

[0001193125-11-330462:mdna:121]
32

[0001193125-11-330462:mdna:122]
General and administrative expense consists primarily of compensation costs, professional
and corporate legal fees, outside services and allocated facilities and IT costs. General and administrative expenses decreased or remained flat due to the following:

[0001193125-11-330462:mdna:123]
|  |  | Three Months EndedFiscal 2012 to Fiscal 2011 Percentage Change Points |  |  | Six Months EndedFiscal 2012 to Fiscal 2011 Percentage Change Points |  |
| Salaries |  |  | 5 |  |  |  | 5 |  |
| Stock-based compensation |  |  | 2 |  |  |  | 2 |  |
| Incentive plan compensation |  |  | (10 | ) |  |  | (7 | ) |
| Other compensation and benefit costs |  |  | (1 | ) |  |  | — |  |
| Total compensation costs |  |  | (4 | ) |  |  | — |  |
| Outside services |  |  | 5 |  |  |  | 5 |  |
| IT costs |  |  | — |  |  |  | 2 |  |
| Professional and corporate legal fees |  |  | — |  |  |  | 1 |  |
| Total change |  |  | 1 |  |  |  | 8 |  |

[0001193125-11-330462:mdna:124]
The decrease in total compensation costs was driven by a decrease in incentive compensation expense for
the three and six months ended October 28, 2011. These decreases were partially offset by the impact of a 14% and 17% increase in average general and administrative headcount during the three and six months ended October 28, 2011,
respectively, compared to the same periods in the prior year. The increase in outside services for each of the three and six months ended October 28, 2011 reflects additional spending on contractors and costs associated with the Engenio
acquisition integration and various on-going operational projects.

[0001193125-11-330462:mdna:125]
Acquisition-Related Expense (in millions, except
percentages):

[0001193125-11-330462:mdna:126]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |
| Acquisition-related expense |  | $ | 1.7 |  |  | $ | — |  |  |  | NM |  |  | $ | 3.9 |  |  | $ | 0.3 |  |  |  | NM |  |

[0001193125-11-330462:mdna:127]
| NM | — Not meaningful. |

[0001193125-11-330462:mdna:128]
During
the three and six months ended October 28, 2011, we incurred $1.7 million and $3.9 million, respectively, of due diligence, legal and other one-time integration charges associated with our acquisition of Engenio. During the six months ended
October 29, 2010, acquisition-related expense related to one-time integration charges associated with our acquisition of Bycast Inc. was $0.3 million.

[0001193125-11-330462:mdna:129]
Other Expense, Net

[0001193125-11-330462:mdna:130]
Interest Income (in millions, except
percentages):

[0001193125-11-330462:mdna:131]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |
| Interest income |  | $ | 8.3 |  |  | $ | 9.5 |  |  |  | (13 | )% |  | $ | 18.9 |  |  | $ | 19.3 |  |  |  | (2 | )% |

[0001193125-11-330462:mdna:132]
The decrease in interest income during the three and six months ended October 28, 2011, from the
comparable periods in the prior year, was primarily due to lower yields on new investments.

[0001193125-11-330462:mdna:133]
Interest Expense (in millions,
except percentages):

[0001193125-11-330462:mdna:134]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |
| Interest expense |  | $ | (16.4 | ) |  | $ | (18.6 | ) |  |  | 12 | % |  | $ | (35.8 | ) |  | $ | (37.2 | ) |  |  | 4 | % |

[0001193125-11-330462:mdna:135]
Interest expense decreased 12% and 4% during the three and six months ended October 28, 2011,
respectively, from the comparable periods in the prior year. During the three and six months ended October 28, 2011, we recognized incremental non-cash interest expense from the amortization of debt discount and issuance costs relating to our Notes
of approximately $11.5 million and $25.2 million, respectively, net of capitalized interest. During the three and six months ended October 29, 2010, we recognized incremental non-cash interest expense from the amortization of debt discount and
issuance costs relating to our Notes of

[0001193125-11-330462:mdna:136]
[same as prior period, unchanged from 0001193125-11-239169:mdna:157]

[0001193125-11-330462:mdna:137]
approximately $13.0 million and $25.9 million, respectively. The coupon interest expense related to the Notes was $4.5 million and $10.0 million during the three and six months ended October 28,
2011 and October 29, 2010, respectively, net of capitalized interest. During the three and six months ended October 28, 2011, we capitalized interest expense of $3.5 million on facility assets under construction and on significant software
development projects.

[0001193125-11-330462:mdna:138]
Provision for Income Taxes (in millions, except percentages):

[0001193125-11-330462:mdna:139]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |  | October 28,2011 |  |  | October 29,2010 |  |  | % Change |  |
| Provision for income taxes |  | $ | 18.3 |  |  | $ | 26.9 |  |  |  | (32 | )% |  | $ | 45.9 |  |  | $ | 47.2 |  |  |  | (3 | )% |

[0001193125-11-330462:mdna:140]
Our effective tax rates for the three months ended October 28, 2011 and October 29, 2010 were
10.0% and 13.3%, respectively, and 13.1% and 12.6% for the six months ended October 28, 2011 and October 29, 2010, respectively. Our effective tax rates for the three and six months ended October 28, 2011 and October 29, 2010
differ from the U.S statutory rate of 35% because our foreign earnings are taxed at rates lower than the U.S statutory rate. Our provision for income taxes decreased for the three and six months ended October 28, 2011 compared to the three and
six months ended October 29, 2010 primarily as a result of a decrease in U.S. pre-tax profits.

[0001193125-11-330462:mdna:141]
[same as prior period, unchanged from 0001193125-11-239169:mdna:141]

[0001193125-11-330462:mdna:142]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash flows on our
liquidity and capital resources. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting
the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our
cash equivalents or investments from the values reported as of October 28, 2011.

[0001193125-11-330462:mdna:143]
Liquidity Sources and Cash
Requirements

[0001193125-11-330462:mdna:144]
Our principal sources of liquidity as of October 28, 2011 consisted of approximately
$4.6 billion in cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001193125-11-330462:mdna:145]
Cash, cash equivalents and short-term investments consist of the following (in millions):

[0001193125-11-330462:mdna:146]
|  |  | October 28, 2011 |  |  | April 29, 2011 |  |
| Cash and cash equivalents |  | $ | 2,269.0 |  |  | $ | 2,757.3 |  |
| Short-term investments |  |  | 2,372.6 |  |  |  | 2,417.4 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,641.6 |  |  | $ | 5,174.7 |  |

[0001193125-11-330462:mdna:147]
As of October 28, 2011, $2.2 billion of cash, cash equivalents and short-term investments were held
in the United States, while $2.4 billion were held in foreign countries. Most of the amounts held outside the United States can be repatriated to the United States but, under current law, would be subject to U.S. federal and state income taxes. If
we were to repatriate foreign earnings for cash requirements in the United States, we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state net operating loss and tax credit carry forwards.
However, our intent is to keep these funds permanently reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our
working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies, and service our debt and synthetic leases. Our contractual obligations as of
October 28, 2011 are summarized below in the Contractual Obligations tables.

[0001193125-11-330462:mdna:148]
Key factors that could affect our cash
flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable and inventories, our ability to effectively integrate acquired products, businesses and
technologies, including Engenio, and conversions of our Notes by holders. Based on our current business outlook, we believe that our sources of cash will satisfy our working capital needs, capital expenditures, investment requirements, stock
repurchases, contractual obligations, commitments, interest payments on our Notes and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is
insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to
obtain additional financing, if necessary, on satisfactory terms, if at all.

[0001193125-11-330462:mdna:149]
Our investment portfolio, including auction rate securities, has been and will continue to
be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize our market risk on our investment portfolio. Based on our ability to access our cash and
short-term investments, our expected operating cash flows, and our other potential sources of cash, we do not anticipate that the lack of liquidity of these investments will impact our ability to fund working capital needs, capital expenditures,
acquisitions or other cash requirements. We intend to and believe that we have the ability to hold these investments until the market recovers. If current market conditions deteriorate, we may be required to record additional charges to earnings in
future periods.

[0001193125-11-330462:mdna:150]
[same as prior period, unchanged from 0001193125-11-239169:mdna:151]

[0001193125-11-330462:mdna:151]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use
software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a
number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We expect that our existing facilities and those
being developed in Sunnyvale, California; Research Triangle Park, North Carolina and other locations worldwide are adequate for our requirements over at least the next two years and that additional space will be available as needed. We anticipate
capital expenditures to be between $125.0 million and $175.0 million over the next six months.

[0001193125-11-330462:mdna:152]
Acquisition-Related
Requirements

[0001193125-11-330462:mdna:153]
On May 6, 2011, we completed the acquisition of certain assets related to the Engenio business of
LSI. We paid LSI $480.0 million in cash and also assumed certain assets and liabilities related to Engenio. As part of our efforts to integrate Engenio into our business, we expect to incur additional one-time integration charges. See Note 5 of
the accompanying condensed consolidated financial statements for more information.

[0001193125-11-330462:mdna:154]
[same as prior period, unchanged from 0001193125-11-239169:mdna:155]

[0001193125-11-330462:mdna:155]
As of October 28, 2011, our cash and cash equivalents and short-term and long-term investments decreased by $533.1 million from
April 29, 2011, to $4.7 billion. The decrease was primarily a result of $600.0 million in cash paid for the repurchase of common stock, $480.0 million net cash paid in connection with the acquisition of Engenio, and $191.6 million in
capital expenditures, partially offset by $610.8 million of cash provided by operating activities, $40.0 million of net redemptions of investments and $51.9 million from issuances of common stock related to employee stock option exercises and
purchases under the employee stock purchase plan. We derive our liquidity and capital resources primarily from our operating cash flows and from working capital. Accounts receivable days sales outstanding as of October 28, 2011 decreased to
38 days, compared to 47 days as of April 29, 2011, primarily due to improvements in shipment linearity. Working capital increased by $715.3 million to $3.7 billion as of October 28, 2011, compared to $3.0 billion
as of April 29, 2011, primarily due to the reclassification of our $1.2 billion Notes to long-term liabilities as the underlying contingent conversion threshold was not met at October 28, 2011 and a decrease in accrued compensation and
related benefits of $165.9 million, partially offset by a decrease in cash, cash equivalents, short-term investments of $533.1 million and accounts receivable of $117.4 million.

[0001193125-11-330462:mdna:156]
[same as prior period, unchanged from 0001193125-11-239169:mdna:158]

[0001193125-11-330462:mdna:157]
During the six months ended October 28, 2011, we generated cash from operating activities of $610.8 million. The primary sources of cash from operating activities consisted of net income of
$305.1 million, adjusted by depreciation and amortization of $136.9 million and non-cash stock-based compensation of $121.1 million. Significant changes in assets and liabilities impacting operating cash flows included an increase in
deferred revenue of $126.9 million and a decrease in accounts receivable of $115.6 million, partially offset by a decrease in accrued compensation and other current liabilities of $173.1 million, primarily attributable to employee payouts
related to the fiscal year 2011 commissions and incentive compensation plans.

[0001193125-11-330462:mdna:158]
We expect that cash provided by operating
activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, tax benefits from
stock-based compensation, and the timing and amount of compensation and other payments.

[0001193125-11-330462:mdna:159]
[same as prior period, unchanged from 0001193125-11-239169:mdna:161]

[0001193125-11-330462:mdna:160]
During the six months ended October 28, 2011, we completed our acquisition of Engenio for a total cash payment of $480.0 million and
made capital expenditures of $191.6 million. We received $40.4 million from net purchases and redemptions of our investments for the six months ended October 28, 2011.

[0001193125-11-330462:mdna:161]
[same as prior period, unchanged from 0001193125-11-239169:mdna:163]

[0001193125-11-330462:mdna:162]
We paid $461.8 million for financing
activities for the six months ended October 28, 2011, which primarily consisted of $600.0 million for the repurchase of common stock, partially offset by $84.7 million of excess tax benefit from stock-based compensation and $51.9 million of
proceeds from employee equity award plans, net of shares withheld for taxes.

[0001193125-11-330462:mdna:163]
Net proceeds from the issuance of common stock
related to employee participation in employee equity award programs have historically been a significant component of our liquidity. The extent to which our employees exercise stock options or participate in our Employee Stock Purchase Plan (ESPP)
program generally increases or decreases based upon changes in the market price of our common stock. As a result, our cash flow resulting from the issuance of common stock in connection with these programs and related tax benefits will vary.

[0001193125-11-330462:mdna:164]
[same as prior period, unchanged from 0001193125-11-239169:mdna:166]

[0001193125-11-330462:mdna:165]
During the six months ended October 28, 2011, 14.4 million shares of our common stock were repurchased as described below. Since the May 13, 2003 inception of our stock repurchase program
through October 28, 2011, we have repurchased a total of 118.7 million shares of our common stock at an average price of $29.70 per share, for an aggregate purchase price of $3.5 billion. As of October 28, 2011, our Board of Directors
had authorized the repurchase of up to $4.0 billion of common stock under this stock repurchase program, and $0.5 billion remains available under these authorizations. The stock repurchase program may be suspended or discontinued at any time.

[0001193125-11-330462:mdna:166]
Accelerated Share Repurchase Agreements

[0001193125-11-330462:mdna:167]
On July 8, 2011, we entered into a collared accelerated share repurchase agreement (ASR) with Bank of America, N.A, under which we
prepaid $200.0 million to purchase shares of our common stock. The aggregate number of shares ultimately purchased was determined based on the volume weighted-average share price of our common stock over a specified period of time. The contract was
settled in August 2011. The total number of shares repurchased and retired under this ASR was 4.1 million shares at a weighted-average price of $48.30.

[0001193125-11-330462:mdna:168]
On August 19, 2011, we entered into a new ASR with Wells Fargo Bank, National Association (Wells Fargo), under which we prepaid $400.0 million to purchase shares of our common stock. The aggregate
number of shares ultimately purchased was determined based on the volume weighted-average share price of our common stock over a specified period of time, subject to certain provisions that establish a minimum and maximum number of shares that may
be repurchased. On August 25, 2011, Wells Fargo delivered 10.3 million minimum shares, which were retired immediately. The contract was settled on November 17, 2011, and we received an additional 0.2 million shares at this time.
The total number of shares repurchased and retired under this ASR was 10.5 million shares at a weighted-average price of $38.08.

[0001193125-11-330462:mdna:169]
[same as prior period, unchanged from 0001193125-11-239169:mdna:171]

[0001193125-11-330462:mdna:170]
As of October 28, 2011, we had
$1.265 billion principal amount of 1.75% Convertible Senior Notes due 2013 (See Note 9 of the accompanying condensed consolidated financial statements). The Notes will mature on June 1, 2013, unless earlier repurchased or
converted. Our common stock price did not exceed the conversion threshold price of $41.41 per share set forth for these Notes for at least 20 trading days during the 30 consecutive trading days ended September 30, 2011. Accordingly, as of
October 28, 2011, the Notes were not convertible at the option of the holder and, therefore, the carrying value of the Notes was classified as long-term debt and the difference between the principal amount and the carrying value of the Notes is
reflected as equity on our condensed consolidated balance sheet.

[0001193125-11-330462:mdna:171]
The determination of whether or not the Notes are
convertible must continue to be performed quarterly. Consequently, the Notes may be convertible in future quarters, and therefore may be classified as short-term debt if the contingent conversion thresholds are met in such quarters.
Additionally, since the Notes would be convertible at the option of the holder and the principal amount would be required to be paid in cash, the difference between the principal amount and the carrying value of the Notes would be reflected as
convertible debt in mezzanine on our condensed consolidated balance sheets. As of October 28, 2011, shares issued related to conversion of the Notes were minimal. Receipts of shares related to the Note hedge transactions were minimal, and
there were no cash or shares delivered in relation to the warrant transactions as of October 28, 2011.

[0001193125-11-330462:mdna:172]
[same as prior period, unchanged from 0001193125-11-239169:mdna:173]

[0001193125-11-330462:mdna:173]
The following summarizes our contractual obligations at October 28, 2011 and the effect such obligations are expected to have on our
liquidity and cash flows in future periods (in millions):

[0001193125-11-330462:mdna:174]
|  |  | Remainderof2012 |  |  | 2013 |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | Thereafter |  |  | Total |  |
| Off-balance sheet commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Office operating lease payments |  | $ | 16.5 |  |  | $ | 34.0 |  |  | $ | 35.0 |  |  | $ | 36.4 |  |  | $ | 27.5 |  |  | $ | 73.8 |  |  | $ | 223.2 |  |
| Real estate lease payments (1) |  |  | 1.6 |  |  |  | 129.1 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 130.7 |  |
| Less: sublease income |  |  | (1.0 | ) |  |  | (1.2 | ) |  |  | (0.8 | ) |  |  | (0.8 | ) |  |  | (0.5 | ) |  |  | — |  |  |  | (4.3 | ) |
| Equipment operating lease payments |  |  | 11.7 |  |  |  | 16.5 |  |  |  | 9.9 |  |  |  | 2.6 |  |  |  | 0.3 |  |  |  | 0.1 |  |  |  | 41.1 |  |
| Purchase commitments with contract manufacturers (2) |  |  | 171.1 |  |  |  | 3.6 |  |  |  | 1.2 |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | 176.1 |  |
| Capital expenditures |  |  | 13.3 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 13.3 |  |
| Other purchase obligations (3) |  |  | 196.7 |  |  |  | 79.5 |  |  |  | 20.7 |  |  |  | 10.6 |  |  |  | 10.0 |  |  |  | 10.0 |  |  |  | 327.5 |  |
| Total off balance-sheet commitments |  |  | 409.9 |  |  |  | 261.5 |  |  |  | 66.0 |  |  |  | 49.0 |  |  |  | 37.3 |  |  |  | 83.9 |  |  |  | 907.6 |  |
| 1.75% Convertible notes (4) |  |  | 11.1 |  |  |  | 22.1 |  |  |  | 1,276.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,309.2 |  |
| Long-term financing arrangements |  |  | 5.0 |  |  |  | 8.2 |  |  |  | 0.4 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 13.6 |  |
| Uncertain tax positions (5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 103.9 |  |
| Total |  | $ | 426.0 |  |  | $ | 291.8 |  |  | $ | 1,342.4 |  |  | $ | 49.0 |  |  | $ | 37.3 |  |  | $ | 83.9 |  |  | $ | 2,334.3 |  |
| Other Commercial Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit |  | $ | 6.1 |  |  | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.5 |  |  | $ | 1.1 |  |  | $ | 8.7 |  |

[0001193125-11-330462:mdna:175]
| (1) | Included in real estate lease payments pursuant to four financing arrangements with BNP Paribas LLC (BNPPLC) are (i) lease commitments of $1.6 million in the remainder of fiscal 2012; and $2.0 million in fiscal 2013, which are based on either the LIBOR rate as of October 28, 2011 plus a spread or a fixed rate for terms of five years, and (ii) at the expiration or termination of the lease, a supplemental payment obligation equal to our minimum guarantee of $127.1 million in the event that we elect not to purchase or arrange for sale of the buildings. |

[0001193125-11-330462:mdna:176]
| (2) | Contract manufacturer commitments consist of obligations for on-hand inventories and non-cancelable purchase orders with our contract manufacturer. We record a liability for firm, non-cancelable, and nonreturnable purchase commitments for quantities in excess of our future demand forecasts, which is consistent with the valuation of our excess and obsolete inventory. As of October 28, 2011, the liability for these purchase commitments in excess of future demand was approximately $5.5 million and is recorded in other current liabilities on the condensed consolidated balance sheet. |

[0001193125-11-330462:mdna:177]
[same as prior period, unchanged from 0001193125-11-239169:mdna:180]

[0001193125-11-330462:mdna:178]
| (4) | Included in these amounts are obligations related to the $1.265 billion principal amount of 1.75% Notes due 2013 (see Note 9 of the accompanying condensed consolidated financial statements). Estimated interest payments for the Notes are $44.3 million for the remainder of fiscal 2012 through fiscal 2014. |

[0001193125-11-330462:mdna:179]
| (5) | As of October 28, 2011, our liability for uncertain tax positions was $103.9 million, which due to the uncertainty of the timing of future payments, are presented in the total column on a separate line in this table. |

[0001193125-11-330462:mdna:180]
Some of the amounts in the table above are based on management’s estimates and assumptions, including
their duration, the possibility of renewal or termination, anticipated actions by management and third parties and other factors. Because these estimates and assumptions are subjective, our actual future obligations may vary from those reflected in
the table. We expect to fund our contractual obligations and other commitments in the table above through existing cash, cash equivalents, investments, and cash generated from operations or obtain additional financing, if necessary.

[0001193125-11-330462:mdna:181]
37

[0001193125-11-330462:mdna:182]
As of October 28, 2011, we have four leasing arrangements (Leasing Arrangements 1, 2, 3
and 4) with BNPPLC, some of which require us to lease certain of our land to BNPPLC for a period of 99 years and to lease approximately 0.6 million square feet of office space for our headquarters in Sunnyvale, which had an original
cost of $149.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on LIBOR plus a spread or a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments
for each of the leases for a term of five years. We have the option to renew each of the leases for two consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of the lease terms, we must elect one of
the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received
from the third-party and BNPPLC’s cost up to 85% of cost (residual guarantee); or (iii) pay BNPPLC supplemental payments for an amount equal to the difference between the residual guarantee and fair value, in which event we may recoup some
or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period. The following table summarizes the costs, the residual guarantee, the applicable LIBOR plus spread or fixed rate at
October 28, 2011 and the date we began to make payments for each of our leasing arrangements (in millions):

[0001193125-11-330462:mdna:183]
| Leasing Arrangements |  | Cost |  |  | ResidualGuarantee |  |  | LIBORPlusSpread orFixed Rate |  |  | LeaseCommencementDate |  | Term |
| 1 |  | $ | 48.5 |  |  | $ | 41.2 |  |  |  | 3.14 | % |  | January 2008 |  | 5 years |
| 2 |  |  | 80.0 |  |  |  | 68.0 |  |  |  | 0.22 | % |  | December 2007 |  | 5 years |
| 3 |  |  | 10.5 |  |  |  | 8.9 |  |  |  | 3.12 | % |  | December 2007 |  | 5 years |
| 4 |  |  | 10.6 |  |  |  | 9.0 |  |  |  | 3.14 | % |  | December 2007 |  | 5 years |

[0001193125-11-330462:mdna:184]
All leases require us to maintain specified financial covenants with which we were in compliance as of
October 28, 2011. Such financial covenants include a maximum ratio of Total Debt to Earnings before Interest, Taxes, Depreciation and Amortization of less than 3:1 and a minimum amount of Unencumbered Cash and Short-Term Investments of $300
million. Our failure to comply with these financial covenants could result in a default under the leases, which, subject to our right and ability to exercise our purchase option, would give BNPPLC the right to, among other things, (i) terminate
our possession of the leased property and require us to pay lease termination damages and other amounts as set forth in the lease agreements, or (ii) exercise certain foreclosure remedies. If we were to exercise our purchase option, or be
required to pay lease termination damages, these payments would significantly reduce our available liquidity, which could constrain our operating flexibility.

[0001193125-11-330462:mdna:185]
As of October 28, 2011, we estimated that the fair value of the properties under synthetic lease was $51.0 million below the residual guarantee. We are accruing for this deficiency over the
remaining terms of the respective leases. As of October 28, 2011, a deficiency reserve of $27.0 million was included in other long-term liabilities.

[0001193125-11-330462:mdna:186]
[same as prior period, unchanged from 0001193125-11-239169:mdna:187]

[0001193125-11-330462:mdna:187]
Legal Contingencies

[0001193125-11-330462:mdna:188]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as of October 28, 2011, as the outcome of these legal matters is
currently not determinable.

[0001193125-11-330462:mdna:189]
On October 13, 2010, Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund
and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of California, Santa Clara County. The lawsuit named certain of our current
and former directors as defendants. On February 3, 2011, the plaintiff filed an amended complaint in response to motions to dismiss that we and the individual defendants had filed. Like the original complaint, the amended complaint included
claims of breach of fiduciary duty and waste of corporate assets and alleges that the defendants failed to monitor internal controls to ensure that we complied with legal requirements in our General Services Administration (GSA) contracting
activities, resulting in us incurring defense and settlement costs. The amended complaint sought disgorgement of salaries and other compensation from the defendants and additional unspecified damages. We and the individual defendants filed motions
to dismiss the amended complaint in early March 2011. Following a hearing on July 15, 2011, the Court granted the motions to dismiss, but permitted plaintiff leave to amend its complaint on or before September 16, 2011.

[0001193125-11-330462:mdna:190]
On August 9, 2011, Amalgamated Bank filed a complaint in Delaware Chancery Court
against us for the purpose of obtaining, in a summary proceeding, books and records to help Amalgamated Bank amend its complaint in the California lawsuit. Each of the parties filed cross motions for summary judgment, and a hearing was held before
the Delaware Chancery Court on November 16, 2011. Following that hearing, the Court directed Amalgamated Bank to more narrowly tailor its requests.

[0001193125-11-330462:mdna:191]
The plaintiff filed an amended complaint in the California lawsuit on September 15, 2011. We will move to dismiss this or any other further amended complaint by January 9, 2012. A hearing on our
motion to dismiss the California lawsuit is scheduled for February 24, 2012.

[0001193125-11-330462:mdna:192]
[same as prior period, unchanged from 0001193125-11-239169:mdna:192]

[0001193125-11-330462:mdna:193]
During the ordinary course of business, we provide standby letters of credit or other guarantee instruments to third
parties as required for certain transactions initiated either by us or our subsidiaries. As of October 28, 2011, our financial guarantees of $8.7 million that were not recorded on our condensed consolidated balance sheet consisted of
standby letters of credit related to workers’ compensation, a customs guarantee, a corporate credit card program, foreign rent guarantees and surety bonds, which were primarily related to self-insurance.

[0001193125-11-330462:mdna:194]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the
volatility of earnings and cash flows associated with changes in foreign currency. The program is not designated for trading or speculative purposes. Currently, we do not enter into any foreign exchange forward contracts to hedge exposures related
to firm commitments or nonmarketable investments. Our major foreign currency exchange exposures and related hedging programs are described below:

[0001193125-11-330462:mdna:195]
[same as prior period, unchanged from 0001193125-11-239169:mdna:195]

[0001193125-11-330462:mdna:196]
[same as prior period, unchanged from 0001193125-11-239169:mdna:196]

[0001193125-11-330462:mdna:197]
As of October 28, 2011, our notional fair value of foreign exchange forward and foreign currency option contracts totaled $544.3 million. We do not believe that these derivatives present
significant credit risks, because of the short term maturity of the outstanding contracts at any point in time, the counterparties to the derivatives consist of major financial institutions, and we manage the notional amount of contracts entered
into with any one counterparty. Other than the risk associated with the financial condition of the counterparties, our maximum exposure related to foreign currency forward and option contracts is limited to the premiums paid. See Note 11 of the
accompanying condensed consolidated financial statements for more information related to our hedging activities.

[0001193125-11-330462:mdna:198]
[same as prior period, unchanged from 0001193125-11-239169:mdna:198]

[0001193125-11-330462:mdna:199]
[same as prior period, unchanged from 0001193125-11-239169:mdna:199]

[0001193125-11-330462:mdna:200]
We have commitments related to four lease arrangements with BNPPLC for approximately
0.6 million square feet of office space for our headquarters in Sunnyvale, California (as further described above under “Contractual Obligations”). Our future minimum lease payments and residual guarantees under these real estate
leases will amount to a total of $130.7 million as discussed above in “Contractual Obligations.”

[0001193125-11-330462:mdna:201]
[same as prior period, unchanged from 0001193125-11-239169:mdna:201]

[0001193125-11-330462:mdna:202]
[same as prior period, unchanged from 0001193125-11-239169:mdna:202]

[0001193125-11-330462:mdna:203]
[same as prior period, unchanged from 0001193125-11-239169:mdna:203]

[0001193125-11-330462:mdna:204]
[same as prior period, unchanged from 0001193125-11-239169:mdna:204]
