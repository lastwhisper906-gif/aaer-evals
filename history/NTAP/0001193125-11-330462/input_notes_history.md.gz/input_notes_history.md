# NTAP note change history — 0001193125-11-239169 → 0001193125-11-330462


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2011-12-05):
[0001193125-11-330462:note_history:1]
15. Commitments and Contingencies
  (was, 2011-09-01, similarity 0.9118):
[0001193125-11-239169:note_history:1]
| 15. | Commitments and Contingencies |

- changed (2011-12-05):
[0001193125-11-330462:note_history:2]
Future annual minimum lease payments under all non-cancelable facilities and equipment operating leases with an initial term in excess of one year as of October 28, 2011 totaled $390.7 million.
  (was, 2011-09-01, similarity 0.9699):
[0001193125-11-239169:note_history:2]
Future annual minimum lease payments under all non-cancelable facilities and equipment operating leases with an initial term in excess of one year as of July 29, 2011 totaled $312.3 million.

- changed (2011-12-05):
[0001193125-11-330462:note_history:3]
As of October 28, 2011, we have four leasing arrangements (Leasing Arrangements 1, 2, 3 and 4) with BNP Paribas LLC (BNPPLC), some of which require us to lease certain of our land to BNPPLC for a period of 99 years and to lease approximately 0.6 million square feet of office space for our headquarters in Sunnyvale, which had an original cost of $149.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on LIBOR plus a spread or a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of the leases for two consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of the lease terms, we must elect one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received from the third-party and BNPPLC's cost up to 85% of cost (residual guarantee); or (iii) pay BNPPLC supplemental payments for an amount equal to the difference between the residual guarantee and fair value, in which event we may recoup some or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period.
  (was, 2011-09-01, similarity 0.9958):
[0001193125-11-239169:note_history:3]
As of July 29, 2011, we have four leasing arrangements (Leasing Arrangements 1, 2, 3 and 4) with BNP Paribas LLC (BNPPLC) some of which require us to lease certain of our land to BNPPLC for a period of 99 years and to lease approximately 0.6 million square feet of office space for our headquarters in Sunnyvale, which had an original cost of $149.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on LIBOR plus a spread or a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of the leases for two consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of the lease terms, we must elect one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received from the third-party and BNPPLC's cost up to 85% of cost (residual guarantee); or (iii) pay BNPPLC supplemental payments for an amount equal to the difference between the residual guarantee and fair value, in which event we may recoup some or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period.

- changed (2011-12-05):
[0001193125-11-330462:note_history:4]
These leases require us to maintain specified financial covenants with which we were in compliance as of October 28, 2011.
  (was, 2011-09-01, similarity 0.952):
[0001193125-11-239169:note_history:4]
These leases require us to maintain specified financial covenants with which we were in compliance as of July 29, 2011.

- added (2011-12-05):
[0001193125-11-330462:note_history:5]
As of October 28, 2011, we estimated that the fair value of the properties under synthetic lease was $51.0 million below the residual guarantee. We are accruing for this deficiency over the remaining terms of the respective leases. As of October 28, 2011, a deficiency reserve of $27.0 million was included in other long-term liabilities.

- changed (2011-12-05):
[0001193125-11-330462:note_history:6]
In the normal course of business we make commitments to our third-party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. We had $176.1 million in non-cancelable purchase commitments with our contract manufacturers as of October 28, 2011. In addition, we recorded a liability for firm non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to product cost of sales. As of October 28, 2011 and April 29, 2011, such liability amounted to $5.5 million and $4.5 million, respectively, and is included in other current liabilities in the condensed consolidated balance sheets.
  (was, 2011-09-01, similarity 0.968):
[0001193125-11-239169:note_history:6]
In the normal course of business we make commitments to our third-party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. We had $191.8 million in non-cancelable purchase commitments with our contract manufacturers as of July 29, 2011. In addition, we recorded a liability for firm non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to product cost of sales. As of July 29, 2011 and April 29, 2011, such liability amounted to $4.5 million for both periods and is included in other current liabilities in the condensed consolidated balance sheets.

- changed (2011-12-05):
[0001193125-11-330462:note_history:7]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course business for which we have not received goods or services. We had $13.3 million in capital purchase commitments and $327.5 million in other purchase commitments as of October 28, 2011.
  (was, 2011-09-01, similarity 0.9839):
[0001193125-11-239169:note_history:7]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course business for which we have not received goods or services. We had $25.0 million in capital purchase commitments and $249.2 million in other purchase commitments as of July 29, 2011.

- added (2011-12-05):
[0001193125-11-330462:note_history:8]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Beginning balance |  | $ | 59.5 |  |  | $ | 32.1 |  |  | $ | 40.5 |  |  | $ | 31.9 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 17.5 |  |  |  | 0.0 |  |
| Expense accrued during the period |  |  | 15.7 |  |  |  | 7.0 |  |  |  | 27.4 |  |  |  | 12.9 |  |
| Warranty costs incurred |  |  | (10.2 | ) |  |  | (5.6 | ) |  |  | (20.4 | ) |  |  | (11.3 | ) |
| Ending balance |  | $ | 65.0 |  |  | $ | 33.5 |  |  | $ | 65.0 |  |  | $ | 33.5 |  |

- changed (2011-12-05):
[0001193125-11-330462:note_history:9]
We have both nonrecourse and recourse lease financing arrangements with third-party leasing companies through new and preexisting relationships with customers. In addition, from time to time we provide guarantees for a portion of other financing arrangements under which we could be called upon to make payments to our third-party funding companies in the event of nonpayment by end-user customers. Under the terms of the nonrecourse leases, we do not have any continuing obligations or liabilities to the third-party leasing companies. Under the terms of the recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee, we defer the revenues associated with the end-user financing arrangement in accordance with our revenue recognition policies. As of October 28, 2011, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $105.1 million, and the related deferred revenue and cost of revenues totaled approximately $107.4 million and $12.4 million, respectively. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.
  (was, 2011-09-01, similarity 0.996):
[0001193125-11-239169:note_history:9]
We have both nonrecourse and recourse lease financing arrangements with third-party leasing companies through new and preexisting relationships with customers. In addition, from time to time we provide guarantees for a portion of other financing arrangements under which we could be called upon to make payments to our third-party funding companies in the event of nonpayment by end-user customers. Under the terms of the nonrecourse leases, we do not have any continuing obligations or liabilities to the third-party leasing companies. Under the terms of the recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee, we defer the revenues associated with the end-user financing arrangement in accordance with our revenue recognition policies. As of July 29, 2011, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $97.9 million, and the related deferred revenue and cost of revenues totaled approximately $102.0 million and $9.3 million, respectively. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

- changed (2011-12-05):
[0001193125-11-330462:note_history:10]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as of October 28, 2011, as the outcome of these legal matters is currently not determinable.
  (was, 2011-09-01, similarity 0.9748):
[0001193125-11-239169:note_history:10]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as of July 29, 2011, as the outcome of these legal matters is currently not determinable.

- changed (2011-12-05):
[0001193125-11-330462:note_history:11]
On October 13, 2010, Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of California, Santa Clara County. The lawsuit named certain of our current and former directors as defendants. On February 3, 2011, the plaintiff filed an amended complaint in response to motions to dismiss that we and the individual defendants had filed. Like the original complaint, the amended complaint included claims of breach of fiduciary duty and waste of corporate assets and alleges that the defendants failed to monitor internal controls to ensure that we complied with legal requirements in our General Services Administration (GSA) contracting activities, resulting in us incurring defense and settlement costs. The amended complaint sought disgorgement of salaries and other compensation from the defendants and additional unspecified damages. We and the individual defendants filed motions to dismiss the amended complaint in early March 2011. Following a hearing on July 15, 2011, the Court granted the motions to dismiss, but permitted plaintiff leave to amend its complaint on or before September 16, 2011.
  (was, 2011-09-01, similarity 0.8626):
[0001193125-11-239169:note_history:11]
On October 13, 2010, Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of California, Santa Clara County. The lawsuit named 15 of our current and former directors as defendants. On February 3, 2011, the plaintiff filed an amended complaint in response to motions to dismiss that we and the individual defendants had filed. Like the original complaint, the amended complaint includes claims of breach of fiduciary duty and waste of corporate assets and alleges that the defendants failed to monitor internal controls to ensure that we complied with legal requirements in our General Services Administration (GSA) contracting activities, resulting in us incurring defense and settlement costs. The amended complaint seeks disgorgement of salaries and other compensation from the defendants and additional unspecified damages. We and the individual defendants filed motions to dismiss the amended complaint in early March 2011, and the hearing on these motions was held on July 15, 2011. The Court granted the motions to dismiss and dismissed the plaintiff's complaint, but permitted plaintiff leave to amend the complaint on or before September 16, 2011. On August 10, 2011, Amalgamated Bank filed a complaint in Delaware Chancery Court against NetApp, Inc. for the purpose of obtaining, in a summary proceeding, books and records to be used in the California lawsuit. We will respond to this Complaint on or before August 30, 2011.

- added (2011-12-05):
[0001193125-11-330462:note_history:12]
On August 9, 2011, Amalgamated Bank filed a complaint in Delaware Chancery Court against us for the purpose of obtaining, in a summary proceeding, books and records to help Amalgamated Bank amend its complaint in the California lawsuit. Each of the parties filed cross motions for summary judgment, and a hearing was held before the Delaware Chancery Court on November 16, 2011. Following that hearing, the Court directed Amalgamated Bank to more narrowly tailor its requests.

- added (2011-12-05):
[0001193125-11-330462:note_history:13]
The plaintiff filed an amended complaint in the California lawsuit on September 15, 2011. We will move to dismiss this or any other further amended complaint by January 9, 2012. A hearing on our motion to dismiss the California lawsuit is scheduled for February 24, 2012.

- removed (2011-12-05):
[0001193125-11-239169:note_history:14]
As of July 29, 2011, we estimated that the fair value of the properties under synthetic lease was $51.0 million below the residual guarantee. We are accruing for this deficiency over the remaining terms of the respective leases. As of July 29, 2011, a deficiency reserve of $21.6 million was included in other long-term liabilities

- removed (2011-12-05):
[0001193125-11-239169:note_history:15]
.

- removed (2011-12-05):
[0001193125-11-239169:note_history:16]
|  |  | Three Months Ended |  |
|  |  | July 29,2011 |  |  | July 30,2010 |  |
| Beginning balance |  | $ | 40.5 |  |  | $ | 31.9 |  |
| Liability assumed in acquisition |  |  | 17.5 |  |  |  | 0.0 |  |
| Expense accrued during the period |  |  | 11.7 |  |  |  | 5.9 |  |
| Warranty costs incurred |  |  | (10.2 | ) |  |  | (5.7 | ) |
| Ending balance |  | $ | 59.5 |  |  | $ | 32.1 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2011-12-05):
[0001193125-11-330462:note_history:17]
2. Condensed Consolidated Financial Statements
  (was, 2011-09-01, similarity 0.9375):
[0001193125-11-239169:note_history:17]
| 2. | Condensed Consolidated Financial Statements |

- changed (2011-12-05):
[0001193125-11-330462:note_history:18]
Fiscal Year — We operate on a 52- or 53-week year ending on the last Friday in April. The first and second quarters of fiscal 2012 and 2011 were each 13-week periods.
  (was, 2011-09-01, similarity 0.9316):
[0001193125-11-239169:note_history:18]
Fiscal Year — We operate on a 52-week or 53-week year ending on the last Friday in April. The first quarters of fiscal 2012 and 2011 were both 13-week periods.

- changed (2011-12-05):
[0001193125-11-330462:note_history:19]
Basis of Presentation — The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments that are, in the opinion of management, necessary for a fair presentation of our financial position, results of operations, and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, the statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with the Company's audited consolidated financial statements as of and for the fiscal year ended April 29, 2011 contained in the Company's Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 23, 2011. The results of operations for the three and six months ended October 28, 2011 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2011-09-01, similarity 0.8904):
[0001193125-11-239169:note_history:19]
Basis of Presentation — The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments that are, in the opinion of management, necessary for a fair presentation of our financial position, results of operations, and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, the statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with the Company's audited consolidated financial statements as of and for the fiscal year ended April 29, 2011 contained in the Company's Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 23, 2011. The results of operations for the three month period ended July 29, 2011 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2011-12-05):
[0001193125-11-330462:note_history:20]
3. Significant Accounting Policies
  (was, 2011-09-01, similarity 0.9167):
[0001193125-11-239169:note_history:20]
| 3. | Significant Accounting Policies |

- changed (2011-12-05):
[0001193125-11-330462:note_history:21]
There have been no significant changes in our significant accounting policies for the six months ended October 28, 2011, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2011.
  (was, 2011-09-01, similarity 0.9168):
[0001193125-11-239169:note_history:21]
There have been no significant changes in our significant accounting policies for the three month period ended July 29, 2011, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2011.

- changed (2011-12-05):
[0001193125-11-330462:note_history:22]
Our product revenue also includes revenue from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer-negotiated refunds or return rights for the delivered elements.
  (was, 2011-09-01, similarity 0.9985):
[0001193125-11-239169:note_history:22]
Our product revenue also includes revenue from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer negotiated refunds or return rights for the delivered elements.

- changed (2011-12-05):
[0001193125-11-330462:note_history:23]
When VSOE cannot be established, the Company attempts to establish the selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE for our products or services.
  (was, 2011-09-01, similarity 0.9969):
[0001193125-11-239169:note_history:23]
When VSOE cannot be established, the Company attempts to establish selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE for our products or services.

- added (2011-12-05):
[0001193125-11-330462:note_history:24]
When we are unable to establish selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

- added (2011-12-05):
[0001193125-11-330462:note_history:25]
In September 2011, the FASB issued a revised accounting standard intended to simplify how an entity tests goodwill for impairment. The revised standard will allow an entity to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. An entity will no longer be required to calculate the fair value of a reporting unit unless it determines, based on a qualitative assessment, that it is more likely than not that its fair value is less than its carrying amount. This guidance is effective for us beginning in our first quarter of fiscal 2013. We do not expect this guidance to have a material impact on our consolidated financial statements.

- changed (2011-12-05):
[0001193125-11-330462:note_history:26]
In June 2011, the FASB issued new guidance on the presentation of comprehensive income. Specifically, the new guidance requires an entity to present components of net income and other comprehensive income in one continuous statement, referred to as the statement of comprehensive income, or in two separate, but consecutive statements. The new guidance eliminates the current option to report other comprehensive income and its components in the statement of stockholders' equity. While the new guidance changes the presentation of comprehensive income, there are no changes to the components that are recognized in net income or other comprehensive income under current accounting guidance. This new guidance is effective for us beginning in our first quarter of fiscal 2013 and is required to be applied retrospectively. There will be no impact to our results as the guidance relates only to financial statement presentation.
  (was, 2011-09-01, similarity 0.9524):
[0001193125-11-239169:note_history:26]
In June 2011, the FASB issued new guidance on the presentation of comprehensive income. Specifically, the new guidance requires an entity to present components of net income and other comprehensive income in one continuous statement, referred to as the statement of comprehensive income, or in two separate, but consecutive statements. The new guidance eliminates the current option to report other comprehensive income and its components in the statement of stockholders' equity. While the new guidance changes the presentation of comprehensive income, there are no changes to the components that are recognized in net income or other comprehensive income under current accounting guidance. This new guidance is effective for us beginning in our first quarter of fiscal 2013 and is required to be applied retrospectively. There will be no impact to the Company's results as the guidance relates only to financial statement presentation.

- changed (2011-12-05):
[0001193125-11-330462:note_history:27]
In May 2011, the FASB issued new guidance for fair value measurements to provide a consistent definition of fair value and ensure that the fair value measurement and disclosure requirements are similar between GAAP and International Financial Reporting Standards. The guidance changes certain fair value measurement principles and enhances the disclosure requirements, particularly for level 3 fair value measurements. The guidance is effective for us prospectively beginning in the fourth quarter of fiscal 2012, and we are currently evaluating the impact of adoption on our consolidated financial statements.
  (was, 2011-09-01, similarity 0.9882):
[0001193125-11-239169:note_history:27]
In May 2011, the FASB issued new guidance for fair value measurements to provide a consistent definition of fair value and ensure that the fair value measurement and disclosure requirements are similar between GAAP and International Financial Reporting Standards. The guidance changes certain fair value measurement principles and enhances the disclosure requirements particularly for level 3 fair value measurements. The guidance is effective for us prospectively beginning in the fourth quarter of fiscal 2012, and we are currently evaluating the impact of adoption on our financial statements.

- changed (2011-12-05):
[0001193125-11-330462:note_history:28]
The preparation of the consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; self-insurance; stock-based compensation; loss contingencies; investment impairments; income taxes, and fair value measurements. Actual results could differ from those estimates.
  (was, 2011-09-01, similarity 0.9993):
[0001193125-11-239169:note_history:28]
The preparation of the consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; self-insurance; stock-based compensation; loss contingencies; investment impairments; income taxes, and fair value measurements. Actual results could differ from those estimates.

- removed (2011-12-05):
[0001193125-11-239169:note_history:29]
When we are unable to establish selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.


## ntap:LongTermDebtByCurrentAndNonCurrentTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2011-12-05):
[0001193125-11-330462:note_history:30]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 8.1 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.2 |  |  |  | 6.0 |  |
|  |  | $ | 13.3 |  |  | $ | 11.5 |  |
  (was, 2011-09-01, similarity 0.9762):
[0001193125-11-239169:note_history:30]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.4 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.4 |  |  |  | 6.0 |  |
|  |  | $ | 11.8 |  |  | $ | 11.5 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2011-12-05):
[0001193125-11-330462:note_history:31]
9. Financing Arrangements
  (was, 2011-09-01, similarity 0.8889):
[0001193125-11-239169:note_history:31]
| 9. | Financing Arrangements |

- added (2011-12-05):
[0001193125-11-330462:note_history:32]
Our common stock price did not exceed the conversion threshold price of $41.41 per share set forth for the Notes for at least 20 trading days during the 30 consecutive trading days ended September 30, 2011. Accordingly, as of October 28, 2011, the Notes were not convertible at the option of the holder and, therefore, the carrying value of the Notes was classified as long-term debt and the difference between the principal amount and the carrying value of the Notes is reflected as equity on our condensed consolidated balance sheet.

- added (2011-12-05):
[0001193125-11-330462:note_history:33]
Our common stock price exceeded the conversion threshold for the Notes for at least 20 trading days during the 30 consecutive trading days ended March 31, 2011. Accordingly, as of April 29, 2011, the Notes were convertible at the option of the holder and, therefore, the carrying value of the Notes was classified as short-term debt. Since the Notes were convertible at the option of the holder and the principal amount would have been required to be paid in cash, the difference between the principal amount and the carrying value of the Notes was reflected as convertible debt in mezzanine on our condensed consolidated balance sheet as of April 29, 2011.

- added (2011-12-05):
[0001193125-11-330462:note_history:34]
The determination of whether or not the Notes are convertible must continue to be performed quarterly. Consequently, the Notes may be convertible in future quarters, and therefore may be classified as short-term debt, if the conversion thresholds are met in such quarters. Additionally, since the Notes would be convertible at the option of the holder and the principal amount would be required to be paid in cash, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in mezzanine on our condensed consolidated balance sheets.

- added (2011-12-05):
[0001193125-11-330462:note_history:35]
Upon conversion of any Notes, we deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal amount of the Notes, shares of our common stock. As of October 28, 2011, shares issued related to the Notes were minimal. Based on the closing price of our common stock of $41.59 on October 28, 2011, the if-converted value of our Notes exceeded their principal amount by approximately $387.0 million.

- changed (2011-12-05):
[0001193125-11-330462:note_history:36]
The following table reflects the carrying value of our convertible debt as of October 28, 2011 and April 29, 2011, respectively (in millions):
  (was, 2011-09-01, similarity 0.9575):
[0001193125-11-239169:note_history:36]
The following table reflects the carrying value of our convertible debt as of July 29, 2011 and April 29, 2011, respectively (in millions):

- changed (2011-12-05):
[0001193125-11-330462:note_history:37]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (89.2 | ) |  |  | (114.6 | ) |
| Net carrying amount of Notes |  | $ | 1,175.8 |  |  | $ | 1,150.4 |  |
  (was, 2011-09-01, similarity 0.7873):
[0001193125-11-239169:note_history:37]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (101.9 | ) |  |  | (114.6 | ) |
| Net current carrying amount of Notes |  | $ | 1,163.1 |  |  | $ | 1,150.4 |  |

- changed (2011-12-05):
[0001193125-11-330462:note_history:38]
The following table presents the amount of interest cost recognized (in millions):
  (was, 2011-09-01, similarity 0.6631):
[0001193125-11-239169:note_history:38]
The following table reflects the remaining debt discount and issuance costs as of July 29, 2011 (in millions):

- changed (2011-12-05):
[0001193125-11-330462:note_history:39]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 11.0 |  |  | $ | 11.0 |  |
| Amortization of debt discount |  |  | 12.8 |  |  |  | 12.0 |  |  |  | 25.4 |  |  |  | 23.9 |  |
| Amortization of issuance costs |  |  | 1.1 |  |  |  | 1.0 |  |  |  | 2.2 |  |  |  | 2.0 |  |
| Less capitalized interest |  |  | (3.5 | ) |  |  | 0.0 |  |  |  | (3.5 | ) |  |  | 0.0 |  |
| Total interest expense recognized |  | $ | 15.9 |  |  | $ | 18.5 |  |  | $ | 35.1 |  |  | $ | 36.9 |  |
  (was, 2011-09-01, similarity 0.6675):
[0001193125-11-239169:note_history:39]
|  |  | Three Months Ended |  |
|  |  | July 29, 2011 |  |  | July 30, 2010 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |
| Amortization of debt discount |  |  | 12.6 |  |  |  | 11.9 |  |
| Amortization of issuance costs |  |  | 1.1 |  |  |  | 1.0 |  |
| Total interest expense recognized |  | $ | 19.2 |  |  | $ | 18.4 |  |

- added (2011-12-05):
[0001193125-11-330462:note_history:40]
We capitalize interest on facility assets under construction and on significant software development projects.

- added (2011-12-05):
[0001193125-11-330462:note_history:41]
The following table reflects the remaining debt discount and issuance costs as of October 28, 2011 (in millions):

- changed (2011-12-05):
[0001193125-11-330462:note_history:42]
| • |  | Note Hedges: As of October 28, 2011 and April 29, 2011, we had arrangements with counterparties to buy up to approximately 31.8 million shares, subject to anti-dilution adjustments, of our common stock at a price of $31.85 per share, subject to adjustment. The Note hedge transactions will expire at the earlier of (1) the last day on which any Notes remain outstanding or (2) the scheduled trading day immediately preceding the maturity date of the Notes. Upon exercise of the Note hedges, we have the option to receive cash or shares of our common stock equal to the difference between the then market price and the strike price of the hedges. |
  (was, 2011-09-01, similarity 0.9725):
[0001193125-11-239169:note_history:42]
| • |  | Note Hedges. As of July 29, 2011 and April 29, 2011, we have arrangements with counterparties to buy up to approximately 31.8 million shares, subject to anti-dilution adjustments, of our common stock at a price of $31.85 per share, subject to adjustment. The Note hedge transactions will expire at the earlier of (1) the last day on which any Notes remain outstanding and (2) the scheduled trading day immediately preceding the maturity date of the Notes. Upon exercise of the Note hedges, we have the option to receive cash or shares of our common stock equal to the difference between the then market price and the strike price of the hedges. |

- changed (2011-12-05):
[0001193125-11-330462:note_history:43]
|  | • |  | Warrants: As of October 28, 2011 and April 29, 2011, we had outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |
  (was, 2011-09-01, similarity 0.9179):
[0001193125-11-239169:note_history:43]
|  | • |  | Warrants. As of July 29, 2011 and April 29, 2011, we have outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |

- changed (2011-12-05):
[0001193125-11-330462:note_history:44]
As of October 28, 2011, we were subject to potential dilution on the approximately 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of approximately $31.85.
  (was, 2011-09-01, similarity 0.972):
[0001193125-11-239169:note_history:44]
As of July 29, 2011, we are subject to potential dilution on the approximately 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of approximately $31.85.

- changed (2011-12-05):
[0001193125-11-330462:note_history:45]
As of October 28, 2011, receipts of shares related to the Note hedge transactions were minimal and no cash or shares were delivered related to the warrant transactions.
  (was, 2011-09-01, similarity 0.9657):
[0001193125-11-239169:note_history:45]
As of July 29, 2011, receipts of shares related to the Note hedge transactions were minimal and no cash or shares were delivered related to the warrant transactions.

- added (2011-12-05):
[0001193125-11-330462:note_history:46]
As of October 28, 2011, the approximate fair value of the principal amount of our Notes, which includes the debt and equity components, was approximately $1,761.5 million, or 139% of the face value of the Notes, based upon quoted market information.

- changed (2011-12-05):
[0001193125-11-330462:note_history:47]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 8.1 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.2 |  |  |  | 6.0 |  |
|  |  | $ | 13.3 |  |  | $ | 11.5 |  |
  (was, 2011-09-01, similarity 0.9762):
[0001193125-11-239169:note_history:47]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.4 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.4 |  |  |  | 6.0 |  |
|  |  | $ | 11.8 |  |  | $ | 11.5 |  |

- removed (2011-12-05):
[0001193125-11-239169:note_history:48]
For at least 20 trading days during the 30 consecutive trading days ended June 30, 2011 and March 31, 2011, respectively, our common stock price exceeded the conversion threshold price of $41.41 per share set forth for these Notes. Accordingly, the Notes are convertible at the holder's option through September 30, 2011 and were convertible at the holder's option through June 30, 2011, respectively. As such, the carrying value of the Notes was classified as a current liability as of July 29, 2011 and April 29, 2011. Since the Notes are convertible at the option of the holder and the principal amount is required to be paid in cash, the difference between the principal amount and the carrying value of the Notes is reflected as convertible debt in mezzanine on our condensed consolidated balance sheets as of July 29, 2011 and April 29, 2011. The determination of whether or not the Notes are convertible must continue to be performed quarterly. Consequently, the Notes may not be convertible in future quarters, and therefore may be classified as long-term debt, if the contingent conversion thresholds are not met in such quarters.

- removed (2011-12-05):
[0001193125-11-239169:note_history:49]
Upon conversion of any Notes, we deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal amount of the Notes, shares of our common stock. As of July 29, 2011, shares issued related to the Notes were minimal. Based on the closing price of our common stock of $47.52 on July 29, 2011, the if-converted value of our Notes exceeded their principal amount by approximately $649.4 million.

- removed (2011-12-05):
[0001193125-11-239169:note_history:50]
The following table presents the amount of interest cost recognized relating to both the contractual interest coupon and the amortization of the discount and issuance costs (in millions):

- removed (2011-12-05):
[0001193125-11-239169:note_history:51]
As of July 29, 2011, the approximate fair value of the principal amount of our Notes, which includes the debt and equity components, was approximately $1,977.8 million, or 156% of the face value of the Notes, based upon quoted market information.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2011-12-05):
[0001193125-11-330462:note_history:52]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (89.2 | ) |  |  | (114.6 | ) |
| Net carrying amount of Notes |  | $ | 1,175.8 |  |  | $ | 1,150.4 |  |
  (was, 2011-09-01, similarity 0.7873):
[0001193125-11-239169:note_history:52]
|  |  | July 29,2011 |  |  | April 29,2011 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (101.9 | ) |  |  | (114.6 | ) |
| Net current carrying amount of Notes |  | $ | 1,163.1 |  |  | $ | 1,150.4 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2011-12-05):
[0001193125-11-330462:note_history:53]
Accounting Standards Recently Adopted

- changed (2011-12-05):
[0001193125-11-330462:note_history:54]
Our product revenue also includes revenue from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer-negotiated refunds or return rights for the delivered elements.
  (was, 2011-09-01, similarity 0.9985):
[0001193125-11-239169:note_history:54]
Our product revenue also includes revenue from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer negotiated refunds or return rights for the delivered elements.

- changed (2011-12-05):
[0001193125-11-330462:note_history:55]
When VSOE cannot be established, the Company attempts to establish the selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE for our products or services.
  (was, 2011-09-01, similarity 0.9969):
[0001193125-11-239169:note_history:55]
When VSOE cannot be established, the Company attempts to establish selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE for our products or services.

- added (2011-12-05):
[0001193125-11-330462:note_history:56]
When we are unable to establish selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

- removed (2011-12-05):
[0001193125-11-239169:note_history:57]
When we are unable to establish selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.


## us-gaap:ScheduleOfSubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2011-12-05):
[0001193125-11-239169:note_history:58]
| 16. | Subsequent Event |

- removed (2011-12-05):
[0001193125-11-239169:note_history:59]
On August 19, 2011, we entered into a new ASR with Wells Fargo Bank, National Association (Wells Fargo). Pursuant to the terms of the ASR, we provided Wells Fargo a prepayment of $400.0 million to purchase shares of our common stock. The aggregate number of shares ultimately purchased will be determined based on the volume weighted average share price of our common stock over a specified period of time, subject to certain collar provisions that establish a minimum and maximum number of shares that may be repurchased. The actual number of shares repurchased will be determined at the completion of the ASR contract. Shares will be delivered over the term of the ASR contract, which is expected to end no later than December 30, 2011, although the completion date may be accelerated at Wells Fargo's option.
