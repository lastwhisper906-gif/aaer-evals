# NTAP MD&A — 0001564590-18-002876


## mdna

[0001564590-18-002876:mdna:1]
[same as prior period, unchanged from 0001564590-17-024351:mdna:1]

[0001564590-18-002876:mdna:2]
24

[0001564590-18-002876:mdna:3]
[same as prior period, unchanged from 0001564590-17-024351:mdna:3]

[0001564590-18-002876:mdna:4]
[same as prior period, unchanged from 0001564590-17-024351:mdna:4]

[0001564590-18-002876:mdna:5]
[same as prior period, unchanged from 0001564590-17-024351:mdna:5]

[0001564590-18-002876:mdna:6]
[same as prior period, unchanged from 0001564590-17-024351:mdna:6]

[0001564590-18-002876:mdna:7]
[same as prior period, unchanged from 0001564590-17-024351:mdna:7]

[0001564590-18-002876:mdna:8]
[same as prior period, unchanged from 0001564590-17-024351:mdna:8]

[0001564590-18-002876:mdna:9]
[same as prior period, unchanged from 0001564590-17-024351:mdna:9]

[0001564590-18-002876:mdna:10]
[same as prior period, unchanged from 0001564590-17-024351:mdna:10]

[0001564590-18-002876:mdna:11]
[same as prior period, unchanged from 0001564590-17-024351:mdna:11]

[0001564590-18-002876:mdna:12]
[same as prior period, unchanged from 0001564590-17-024351:mdna:12]

[0001564590-18-002876:mdna:13]
25

[0001564590-18-002876:mdna:14]
[same as prior period, unchanged from 0001564590-17-024351:mdna:13]

[0001564590-18-002876:mdna:15]
[same as prior period, unchanged from 0001564590-17-024351:mdna:14]

[0001564590-18-002876:mdna:16]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Net revenues |  | $ | 1,523 |  |  | $ | 1,404 |  |  | $ | 4,270 |  |  | $ | 4,038 |  |
| Gross profit |  | $ | 941 |  |  | $ | 851 |  |  | $ | 2,677 |  |  | $ | 2,477 |  |
| Gross profit margin percentage |  |  | 62 | % |  |  | 61 | % |  |  | 63 | % |  |  | 61 | % |
| Income from operations |  | $ | 471 |  |  | $ | 183 |  |  | $ | 838 |  |  | $ | 418 |  |
| Income from operations as a percentage of net revenues |  |  | 31 | % |  |  | 13 | % |  |  | 20 | % |  |  | 10 | % |
| Net income (loss) |  | $ | (506 | ) |  | $ | 146 |  |  | $ | (195 | ) |  | $ | 319 |  |
| Diluted net income (loss) per share |  | $ | (1.89 | ) |  | $ | 0.52 |  |  | $ | (0.72 | ) |  | $ | 1.13 |  |
| Operating cash flows |  | $ | 420 |  |  | $ | 235 |  |  | $ | 984 |  |  | $ | 621 |  |

[0001564590-18-002876:mdna:17]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,269 |  |  | $ | 3,342 |  |
| Cash conversion cycle (days) |  |  | (11 | ) |  |  | 15 |  |

[0001564590-18-002876:mdna:18]
[same as prior period, unchanged from 0001564590-17-024351:mdna:17]

[0001564590-18-002876:mdna:19]
During the first nine months of fiscal 2018, we repurchased 10 million shares of our common stock at an average price of $46.37 per share, for an aggregate of $450 million. We also declared cash dividends of an aggregate of $0.60 per share in that period, for which we paid an aggregate of $161 million.

[0001564590-18-002876:mdna:20]
Senior Notes Redemption

[0001564590-18-002876:mdna:21]
On November 3, 2017, we extinguished our 2.00% Senior Notes due December 2017 for an aggregate cash redemption price of $751 million, plus accrued and unpaid interest.

[0001564590-18-002876:mdna:22]
Real Estate Transactions

[0001564590-18-002876:mdna:23]
On September 8, 2017, we entered into an agreement to sell certain land and buildings for a total of $306 million, through two separate and independent closings. On December 7, 2017, the first closing date, we consummated the sale of properties with a net book value of $66 million for cash proceeds of $210 million, resulting in a gain, net of direct selling costs, of $142 million.

[0001564590-18-002876:mdna:24]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings. The arrangement did not qualify for sale-leaseback accounting and instead was accounted for as a financing transaction. In December 2017, we terminated the leases and recorded a non-cash sale of properties with a net book value of $54 million, the extinguishment of $130 million in financing obligations, and a gain of $76 million.

[0001564590-18-002876:mdna:25]
Tax Reform

[0001564590-18-002876:mdna:26]
On December 22, 2017, the 2017 Tax Reform Reconciliation Act, originally referred to as the Tax Cuts and Jobs Act (TCJA), was enacted into law. This tax reform legislation contains several key tax provisions that affected us, including a one-time mandatory transition tax on accumulated foreign earnings and a reduction of the U.S. corporate income tax rate to 21% effective January 1, 2018, among others. Our GAAP net loss in the third quarter and first nine months of fiscal 2018 includes a one-time tax reform-related provisional charge of $856 million.

[0001564590-18-002876:mdna:27]
[same as prior period, unchanged from 0001564590-17-024351:mdna:22]

[0001564590-18-002876:mdna:28]
[same as prior period, unchanged from 0001564590-17-024351:mdna:23]

[0001564590-18-002876:mdna:29]
[same as prior period, unchanged from 0001564590-17-024351:mdna:37]

[0001564590-18-002876:mdna:30]
The summary of our significant accounting policies is included under Item 7 – Management’s Discussion and Analysis of Financial Condition and Results of Operations of our fiscal 2017 Form 10-K. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. There have been no material changes to the critical accounting policies and estimates as filed in such report, except with respect to Income Taxes. As a part of the provisional estimates recorded during the quarter in response to the enactment of the TCJA, we considered the impacts of the act, reviewed our projected global cash requirements, and determined that certain historical and future foreign earnings will no longer be indefinitely reinvested, in contrast to our previous policy. Refer to Note 13 – Income Taxes of the Notes to Condensed Consolidated Financial Statements for additional details.

[0001564590-18-002876:mdna:31]
[same as prior period, unchanged from 0001564590-17-024351:mdna:25]

[0001564590-18-002876:mdna:32]
[same as prior period, unchanged from 0001564590-17-024351:mdna:26]

[0001564590-18-002876:mdna:33]
[same as prior period, unchanged from 0001564590-17-024351:mdna:27]

[0001564590-18-002876:mdna:34]
[same as prior period, unchanged from 0001564590-17-024351:mdna:28]

[0001564590-18-002876:mdna:35]
[same as prior period, unchanged from 0001564590-17-024351:mdna:29]

[0001564590-18-002876:mdna:36]
|  |  | Three Months Ended |  |  | Nine Months Ended |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 60 |  | % |  | 56 |  | % |  | 57 |  | % |  | 53 |  | % |
| Software maintenance |  |  | 16 |  |  |  | 17 |  |  |  | 17 |  |  |  | 18 |  |  |
| Hardware maintenance and other services |  |  | 24 |  |  |  | 27 |  |  |  | 26 |  |  |  | 29 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 31 |  |  |  | 31 |  |  |  | 29 |  |  |  | 29 |  |  |
| Cost of software maintenance |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 7 |  |  |  | 8 |  |  |  | 8 |  |  |  | 9 |  |  |
| Gross profit |  |  | 62 |  |  |  | 61 |  |  |  | 63 |  |  |  | 61 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 28 |  |  |  | 27 |  |  |  | 30 |  |  |  | 30 |  |  |
| Research and development |  |  | 13 |  |  |  | 13 |  |  |  | 14 |  |  |  | 15 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  | 1 |  |  |
| Gain on sale of properties |  |  | (14 | ) |  |  | (1 | ) |  |  | (5 | ) |  |  | — |  |  |
| Total operating expenses |  |  | 31 |  |  |  | 48 |  |  |  | 43 |  |  |  | 51 |  |  |
| Income from operations |  |  | 31 |  |  |  | 13 |  |  |  | 20 |  |  |  | 10 |  |  |
| Other income (expense), net |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | — |  |  |
| Income before income taxes |  |  | 32 |  |  |  | 13 |  |  |  | 20 |  |  |  | 10 |  |  |
| Provision for income taxes |  |  | 65 |  |  |  | 3 |  |  |  | 25 |  |  |  | 2 |  |  |
| Net income (loss) |  |  | (33 | ) | % |  | 10 |  | % |  | (5 | ) | % |  | 8 |  | % |

[0001564590-18-002876:mdna:37]
[same as prior period, unchanged from 0001564590-17-024351:mdna:31]

[0001564590-18-002876:mdna:38]
[same as prior period, unchanged from 0001564590-17-024351:mdna:32]

[0001564590-18-002876:mdna:39]
[same as prior period, unchanged from 0001564590-17-024351:mdna:33]

[0001564590-18-002876:mdna:40]
Net revenues for the third quarter and first nine months of fiscal 2018 were $1,523 million and $4,270 million, respectively, reflecting an increase of $119 million, or 8%, and $232 million, or 6%, respectively, compared to the corresponding periods of the prior year, reflecting higher product revenues, partially offset by lower hardware maintenance and other services revenues.

[0001564590-18-002876:mdna:41]
[same as prior period, unchanged from 0001564590-17-024351:mdna:52]

[0001564590-18-002876:mdna:42]
Gross profit as a percentage of net revenues for the third quarter and the first nine months of fiscal 2018 increased by one percentage point and one and a half percentage points, respectively, compared to the corresponding periods in fiscal 2017, reflecting higher margins on product revenues. Gross profit margins on product revenues increased four and a half percentage points in the third quarter of fiscal 2018 and four percentage points in the first nine months of fiscal 2018 compared to the corresponding periods of fiscal 2017, primarily due to an increase in average selling price (ASP) and, to a lesser extent, the favorable impact of foreign exchange rate fluctuations.

[0001564590-18-002876:mdna:43]
Sales and marketing, research and development, and general and administrative expenses for the third quarter of fiscal 2018 totaled $688 million. This represented 45% of net revenues, consistent with the third quarter of fiscal 2017. In the first nine months of fiscal 2018, sales and marketing, research and development, and general and administrative expenses totaled $2,057 million, or 48% of net revenues, representing a decrease of two percentage points compared to the corresponding period of fiscal 2017, primarily due to higher net revenues in the current year coupled with lower average headcount as a result of our restructuring plans and other cost reduction initiatives.

[0001564590-18-002876:mdna:44]
[same as prior period, unchanged from 0001564590-17-024351:mdna:38]

[0001564590-18-002876:mdna:45]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |
| Net revenues |  | $ | 1,523 |  |  | $ | 1,404 |  |  |  | 8 | % |  | $ | 4,270 |  |  | $ | 4,038 |  |  |  | 6 | % |

[0001564590-18-002876:mdna:46]
The increase in net revenues for the third quarter and first nine months of fiscal 2018 compared to the corresponding periods of fiscal 2017 was primarily due to an increase in product revenues of $136 million and $296 million, respectively, partially offset by a decrease in hardware maintenance and other services revenues of $14 million and $52 million, respectively. Product revenues as a percentage of net revenues increased four and a half percentage points in the third quarter of fiscal 2018 and four percentage points in the first nine months of fiscal 2018 compared to the corresponding periods of fiscal 2017.

[0001564590-18-002876:mdna:47]
[same as prior period, unchanged from 0001564590-17-024351:mdna:41]

[0001564590-18-002876:mdna:48]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 22 | % |  |  | 23 | % |  |  | 21 | % |
| Tech Data Corporation (previously presented as Avnet, Inc.) |  |  | 19 | % |  |  | 20 | % |  |  | 19 | % |  |  | 20 | % |

[0001564590-18-002876:mdna:49]
[same as prior period, unchanged from 0001564590-17-024351:mdna:43]

[0001564590-18-002876:mdna:50]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |
| Product revenues |  | $ | 920 |  |  | $ | 784 |  |  |  | 17 | % |  | $ | 2,450 |  |  | $ | 2,154 |  |  |  | 14 | % |

[0001564590-18-002876:mdna:51]
[same as prior period, unchanged from 0001564590-17-024351:mdna:45]

[0001564590-18-002876:mdna:52]
Product revenues from strategic solutions represented 70% of product revenues in the third quarter and first nine months of fiscal 2018, compared to 65% and 64% in the corresponding periods of the prior year. Product revenues from mature solutions represented 30% of product revenues in the third quarter and first nine months of fiscal 2018, compared to 35% and 36% in the corresponding periods of the prior year.

[0001564590-18-002876:mdna:53]
Total product revenues from strategic solutions totaled $647 million in the third quarter of fiscal 2018 reflecting a 26% increase from $512 million in the third quarter of fiscal 2017. This increase was primarily due to a 5% increase in unit volume of Clustered ONTAP systems and an increase in ASP driven by sales of our All-Flash FAS products. Total product revenue from mature solutions totaled $273 million in the third quarter of fiscal 2018, relatively flat compared to $272 million in the third quarter of fiscal 2017. A decrease in unit volume of 7-mode systems resulting from the movement of customer demand from older products to our newer products was offset by an 11% increase in add-on hardware, storage and related OS revenues. Product revenues from both strategic and mature solutions were favorably impacted by foreign exchange rate fluctuations in the third quarter of fiscal 2018 compared to the third quarter of fiscal 2017.

[0001564590-18-002876:mdna:54]
Total product revenues from strategic solutions totaled $1,704 million in the first nine months of fiscal 2018 reflecting a 24% increase from $1,375 million in the first nine months of fiscal 2017. This increase was primarily due to a 7% increase in unit volume of Clustered ONTAP systems and an increase in ASP driven by sales of our All-Flash FAS products. Total product revenue from

[0001564590-18-002876:mdna:55]
[same as prior period, unchanged from 0001564590-17-024351:mdna:69]

[0001564590-18-002876:mdna:56]
mature solutions totaled $746 million in the first nine months of fiscal 2018 reflecting a 4% decrease from $779 million in the first nine months of fiscal 2017. This decrease was primarily due to a 69% decrease in unit volume of 7-mode systems, and a 10% decrease in OEM revenues, partially offset by an 11% increase in add-on hardware, storage and related OS revenues.

[0001564590-18-002876:mdna:57]
[same as prior period, unchanged from 0001564590-17-024351:mdna:49]

[0001564590-18-002876:mdna:58]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 237 |  |  | $ | 240 |  |  |  | (1 | )% |  | $ | 711 |  |  | $ | 723 |  |  |  | (2 | )% |

[0001564590-18-002876:mdna:59]
[same as prior period, unchanged from 0001564590-17-024351:mdna:51]

[0001564590-18-002876:mdna:60]
[same as prior period, unchanged from 0001564590-17-024351:mdna:53]

[0001564590-18-002876:mdna:61]
[same as prior period, unchanged from 0001564590-17-024351:mdna:54]

[0001564590-18-002876:mdna:62]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 366 |  |  | $ | 380 |  |  |  | (4 | )% |  | $ | 1,109 |  |  | $ | 1,161 |  |  |  | (4 | )% |

[0001564590-18-002876:mdna:63]
[same as prior period, unchanged from 0001564590-17-024351:mdna:56]

[0001564590-18-002876:mdna:64]
Hardware maintenance contract revenues were $299 million and $903 million for the third quarter and first nine months of fiscal 2018, respectively, compared to $313 million and $952 million for the corresponding periods of the prior year. The decreases in the current year were primarily due to lower contract renewal rates, and a decline in ASP on executed contracts.

[0001564590-18-002876:mdna:65]
Professional services and educational and training services revenues were $67 million and $206 million for the third quarter and first nine months of fiscal 2018, respectively, compared to $67 million and $209 million for the corresponding periods of the prior year.

[0001564590-18-002876:mdna:66]
[same as prior period, unchanged from 0001564590-17-024351:mdna:59]

[0001564590-18-002876:mdna:67]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| United States, Canada and Latin America (Americas) |  |  | 54 | % |  |  | 55 | % |  |  | 55 | % |  |  | 56 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 32 | % |  |  | 33 | % |  |  | 31 | % |  |  | 31 | % |
| Asia Pacific (APAC) |  |  | 14 | % |  |  | 13 | % |  |  | 14 | % |  |  | 13 | % |

[0001564590-18-002876:mdna:68]
[same as prior period, unchanged from 0001564590-17-024351:mdna:61]

[0001564590-18-002876:mdna:69]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Our geographic distribution of revenues as a percentage of net revenues was relatively consistent in the third quarter and first nine months of fiscal 2018 compared to the third quarter and first nine months of fiscal 2017.

[0001564590-18-002876:mdna:70]
[same as prior period, unchanged from 0001564590-17-024351:mdna:63]

[0001564590-18-002876:mdna:71]
[same as prior period, unchanged from 0001564590-17-024351:mdna:64]

[0001564590-18-002876:mdna:72]
[same as prior period, unchanged from 0001564590-17-024351:mdna:65]

[0001564590-18-002876:mdna:73]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |
| Cost of product revenues |  | $ | 468 |  |  | $ | 435 |  |  |  | 8 | % |  | $ | 1,238 |  |  | $ | 1,170 |  |  |  | 6 | % |

[0001564590-18-002876:mdna:74]
[same as prior period, unchanged from 0001564590-17-024351:mdna:86]

[0001564590-18-002876:mdna:75]
[same as prior period, unchanged from 0001564590-17-024351:mdna:67]

[0001564590-18-002876:mdna:76]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2018 to Fiscal 2017 |  |  | Fiscal 2018 to Fiscal 2017 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | 9 |  |  |  | 5 |  |
| Excess and obsolete inventory |  |  | (1 | ) |  |  | — |  |
| Other |  |  | — |  |  |  | 1 |  |
| Total change |  |  | 8 |  |  |  | 6 |  |

[0001564590-18-002876:mdna:77]
Cost of product revenues represented 51% of product revenues for the third quarter and first nine months of fiscal 2018, compared to 55% and 54% for the third quarter and first nine months of fiscal 2017, respectively. Materials costs represented 91% and 90% of product costs for the third quarter and first nine months of fiscal 2018, respectively, compared to 90% and 91% in the third quarter and first nine months of fiscal 2017, respectively.

[0001564590-18-002876:mdna:78]
Materials costs increased $37 million and $57 million in the third quarter and first nine months of fiscal 2018, respectively, compared to the corresponding periods of the prior year, primarily due to higher unit volume of Clustered ONTAP systems.

[0001564590-18-002876:mdna:79]
Average unit materials costs for Clustered ONTAP systems increased slightly in the third quarter and first nine months of fiscal 2018 compared to the corresponding periods of the prior year.

[0001564590-18-002876:mdna:80]
An increase in ASP for strategic systems resulted in higher margins for strategic products in the third quarter and first nine months of fiscal 2018 compared to the third quarter and first nine months of fiscal 2017. Margins in the third quarter of fiscal 2018 were also favorably impacted by fluctuations in foreign exchange rates. Margins for mature products were relatively consistent in the third quarter and first nine months of fiscal 2018 compared to the corresponding periods of the prior year.

[0001564590-18-002876:mdna:81]
Cost of product revenues in the third quarter of fiscal 2018 compared to the third quarter of fiscal 2017 were favorably impacted by a $5 million decrease in charges for excess and obsolete inventory.

[0001564590-18-002876:mdna:82]
[same as prior period, unchanged from 0001564590-17-024351:mdna:75]

[0001564590-18-002876:mdna:83]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 6 |  |  | $ | 7 |  |  |  | (14 | )% |  | $ | 19 |  |  | $ | 22 |  |  |  | (14 | )% |

[0001564590-18-002876:mdna:84]
Cost of software maintenance revenues was relatively flat in the third quarter and first nine months of fiscal 2018 compared to the corresponding periods of fiscal 2017 and represented 3% of software maintenance revenues for all periods presented.

[0001564590-18-002876:mdna:85]
[same as prior period, unchanged from 0001564590-17-024351:mdna:78]

[0001564590-18-002876:mdna:86]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 108 |  |  | $ | 111 |  |  |  | (3 | )% |  | $ | 336 |  |  | $ | 369 |  |  |  | (9 | )% |

[0001564590-18-002876:mdna:87]
Cost of hardware maintenance and other services revenues decreased $3 million, or 3%, for the third quarter of fiscal 2018 compared to the third quarter of fiscal 2017, and decreased $33 million, or 9%, for the first nine months of fiscal 2018 compared to the first nine months of fiscal 2017, primarily due to the favorable impact of cost savings initiatives. Costs represented 30% of hardware maintenance and other services revenues in the third quarter and first nine months of fiscal 2018, compared to 29% and 32% in the third quarter and first nine months of fiscal 2017, respectively.

[0001564590-18-002876:mdna:88]
[same as prior period, unchanged from 0001564590-17-024351:mdna:81]

[0001564590-18-002876:mdna:89]
[same as prior period, unchanged from 0001564590-17-024351:mdna:82]

[0001564590-18-002876:mdna:90]
[same as prior period, unchanged from 0001564590-17-024351:mdna:83]

[0001564590-18-002876:mdna:91]
[same as prior period, unchanged from 0001564590-17-024351:mdna:99]

[0001564590-18-002876:mdna:92]
Total compensation costs included in operating expenses increased by $26 million, or 7% in the third quarter of fiscal 2018 compared to the corresponding period in the prior year primarily due to higher incentive compensation expense, reflecting stronger operating performance against goals, and, to a lesser extent, the unfavorable impact of foreign exchange rate fluctuations.

[0001564590-18-002876:mdna:93]
Total compensation costs included in operating expenses decreased by $6 million, or 1% in the first nine months of fiscal 2018 compared to the corresponding period in the prior year reflecting a decrease of 3% in average headcount, partially offset by higher incentive compensation expense.

[0001564590-18-002876:mdna:94]
[same as prior period, unchanged from 0001564590-17-024351:mdna:87]

[0001564590-18-002876:mdna:95]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 423 |  |  | $ | 381 |  |  |  | 11 | % |  | $ | 1,268 |  |  | $ | 1,228 |  |  |  | 3 | % |

[0001564590-18-002876:mdna:96]
[same as prior period, unchanged from 0001564590-17-024351:mdna:89]

[0001564590-18-002876:mdna:97]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2018 to Fiscal 2017 |  |  | Fiscal 2018 to Fiscal 2017 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 4 |  |  |  | 1 |  |
| Commissions |  |  | 6 |  |  |  | 2 |  |
| Other |  |  | 1 |  |  |  | — |  |
| Total change |  |  | 11 |  |  |  | 3 |  |

[0001564590-18-002876:mdna:98]
The increase in commissions expense reflects higher performance against sales goals, while the increase in compensation costs reflects a combination of higher average salaries due to merit increases, higher incentive compensation expense, and the unfavorable impact of foreign exchange rate fluctuations.

[0001564590-18-002876:mdna:99]
[same as prior period, unchanged from 0001564590-17-024351:mdna:92]

[0001564590-18-002876:mdna:100]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |
| Research and development expenses |  | $ | 193 |  |  | $ | 181 |  |  |  | 7 | % |  | $ | 580 |  |  | $ | 588 |  |  |  | (1 | )% |

[0001564590-18-002876:mdna:101]
[same as prior period, unchanged from 0001564590-17-024351:mdna:94]

[0001564590-18-002876:mdna:102]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2018 to Fiscal 2017 |  |  | Fiscal 2018 to Fiscal 2017 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 6 |  |  |  | (1 | ) |
| Development projects and outside services |  |  | 4 |  |  |  | 1 |  |
| Depreciation |  |  | (2 | ) |  |  | (1 | ) |
| Facilities and IT support costs |  |  | (1 | ) |  |  | (1 | ) |
| Other |  |  | — |  |  |  | 1 |  |
| Total change |  |  | 7 |  |  |  | (1 | ) |

[0001564590-18-002876:mdna:103]
The increase in compensation costs for the third quarter of fiscal 2018 compared to the third quarter of fiscal 2017 was attributable to a 3% increase in average headcount and stronger operating performance against goals, which resulted in higher salaries, benefits and incentive compensation expense. Compensation costs for the first nine months of fiscal 2018 decreased slightly compared to the corresponding period of fiscal 2017 due to slightly lower salaries, benefits and stock-based compensation expenses resulting from a 4% decrease in average headcount. Development projects and outside services increased as a result of higher spending on materials and services associated with engineering activities to develop new products and enhance existing products. Depreciation expense decreased primarily due to certain equipment becoming fully depreciated by the end of fiscal 2017, and facilities and IT support costs decreased primarily due to cost containment efforts.

[0001564590-18-002876:mdna:104]
[same as prior period, unchanged from 0001564590-17-024351:mdna:114]

[0001564590-18-002876:mdna:105]
[same as prior period, unchanged from 0001564590-17-024351:mdna:97]

[0001564590-18-002876:mdna:106]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |
| General and administrative expenses |  | $ | 72 |  |  | $ | 64 |  |  |  | 13 | % |  | $ | 209 |  |  | $ | 201 |  |  |  | 4 | % |

[0001564590-18-002876:mdna:107]
[same as prior period, unchanged from 0001564590-17-024351:mdna:100]

[0001564590-18-002876:mdna:108]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2018 to Fiscal 2017 |  |  | Fiscal 2018 to Fiscal 2017 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 1 |  |  |  | (5 | ) |
| Professional and legal fees and outside services |  |  | 7 |  |  |  | 5 |  |
| Facilities and IT support costs |  |  | 2 |  |  |  | 3 |  |
| Other |  |  | 3 |  |  |  | 1 |  |
| Total change |  |  | 13 |  |  |  | 4 |  |

[0001564590-18-002876:mdna:109]
Compensation costs for the third quarter of fiscal 2018 increased slightly compared to the corresponding period of fiscal 2017 as a result of higher incentive compensation expense, partially offset by a slight decrease in average headcount. Compensation costs for the first nine months of fiscal 2018 were favorably impacted by lower salaries, benefits and stock-based compensation expenses compared to the corresponding period of fiscal 2017 due to an 11% decrease in average headcount, partially offset by higher incentive compensation expense. The increase in professional and legal fees and outside services expense in the third quarter and first nine months of fiscal 2018 was primarily due to higher spending levels on projects and outside services, while the increase in facilities and IT support costs was primarily due to an increase in spending on IT projects.

[0001564590-18-002876:mdna:110]
Restructuring Charges (in millions, except percentages):

[0001564590-18-002876:mdna:111]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |
| Restructuring charges |  | $ | — |  |  | $ | 52 |  |  | NM |  | $ | — |  |  | $ | 52 |  |  | NM |

[0001564590-18-002876:mdna:112]
NM – Not Meaningful

[0001564590-18-002876:mdna:113]
Management has previously approved several restructuring actions to streamline our business, eliminate costs and redirect resources to our highest return activities, including the March 2016 Plan and the November 2016 Plan, under which we reduced our global workforce by approximately 11% and 6%, respectively. We completed all workforce related activities under these plans as of the end of fiscal 2017. See Note 12 – Restructuring Charges of the Notes to Condensed Consolidated Financial Statements for more details regarding our restructuring plans.

[0001564590-18-002876:mdna:114]
Gain on Sale of Properties (in millions, except percentages):

[0001564590-18-002876:mdna:115]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |
| Gain on sale of properties |  | $ | (218 | ) |  | $ | (10 | ) |  | NM |  | $ | (218 | ) |  | $ | (10 | ) |  | NM |

[0001564590-18-002876:mdna:116]
NM – Not Meaningful

[0001564590-18-002876:mdna:117]
On September 8, 2017, we entered into an agreement to sell certain properties previously classified as assets held-for-sale for a total of $306 million, through two separate and independent closings. On December 7, 2017, the date of the first closing, we consummated the sale of properties with a net book value of $66 million for cash proceeds of $210 million, resulting in a gain, net of direct selling costs, of $142 million.

[0001564590-18-002876:mdna:118]
[same as prior period, unchanged from 0001564590-17-024351:mdna:131]

[0001564590-18-002876:mdna:119]
During the third quarter of fiscal 2018, our continuing involvement with properties subject to a sale-leaseback arrangement entered into in fiscal 2016 ended, and as a result we recorded a non-cash sale of properties, extinguished the associated financing obligation and recognized a gain of $76 million.

[0001564590-18-002876:mdna:120]
[same as prior period, unchanged from 0001564590-17-024351:mdna:103]

[0001564590-18-002876:mdna:121]
[same as prior period, unchanged from 0001564590-17-024351:mdna:104]

[0001564590-18-002876:mdna:122]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |
| Interest income |  | $ | 20 |  |  | $ | 10 |  |  |  | 100 | % |  | $ | 55 |  |  | $ | 31 |  |  |  | 77 | % |
| Interest expense |  |  | (17 | ) |  |  | (12 | ) |  |  | 42 | % |  |  | (47 | ) |  |  | (39 | ) |  |  | 21 | % |
| Other income, net |  |  | 11 |  |  |  | 2 |  |  |  | 450 | % |  |  | 17 |  |  |  | 7 |  |  |  | 143 | % |
| Total |  | $ | 14 |  |  | $ | — |  |  | NM |  |  | $ | 25 |  |  | $ | (1 | ) |  | NM |  |

[0001564590-18-002876:mdna:123]
[same as prior period, unchanged from 0001564590-17-024351:mdna:106]

[0001564590-18-002876:mdna:124]
Interest income increased in the third quarter and the first nine months of fiscal 2018 compared to the corresponding periods of the prior year, primarily due to a shift in our investment portfolio to higher-yielding investments.

[0001564590-18-002876:mdna:125]
Interest expense increased in the third quarter and the first nine months of fiscal 2018 primarily as a result of our commercial paper program, which began in the third quarter of fiscal 2017, and the September 2017 issuance of $800 million aggregate principal amount of Senior Notes which have a higher weighted average interest rate than the $750 million aggregate principal amount of Senior Notes extinguished in November 2017.

[0001564590-18-002876:mdna:126]
[same as prior period, unchanged from 0001564590-17-024351:mdna:109]

[0001564590-18-002876:mdna:127]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | % Change |  |
| Provision for income taxes |  | $ | 991 |  |  | $ | 37 |  |  |  | 2,578 | % |  | $ | 1,058 |  |  | $ | 98 |  |  |  | 980 | % |

[0001564590-18-002876:mdna:128]
Our effective tax rate for the third quarter of fiscal 2018 was 204.3% compared to an effective tax rate of 20.2% for the third quarter of fiscal 2017. Our effective tax rate for the first nine months of fiscal 2018 was 122.6% compared to an effective tax rate of 23.5% for the corresponding period of fiscal 2017. Our effective tax rates increased for the third quarter and first nine months of fiscal 2018 compared to the corresponding periods in the prior year, primarily as a result of the impact of U.S. tax reform and the sale of certain buildings and land in Sunnyvale, California, which resulted in aggregate discrete tax charges of $856 million and $72 million, respectively. Our fiscal 2017 effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations which are headquartered in the Netherlands, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate.  See Note 13 – Income Taxes of the Notes to Condensed Consolidated Financial Statements for additional information.

[0001564590-18-002876:mdna:129]
As of January 26, 2018, we had $338 million of gross unrecognized tax benefits. Unrecognized tax benefits of $284 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized, and $303 million has been recorded in other long-term liabilities. As result of the U.S. tax reform, we recorded #113 million of associated gross unrecognized tax benefits.

[0001564590-18-002876:mdna:130]
[same as prior period, unchanged from 0001564590-17-024351:mdna:113]

[0001564590-18-002876:mdna:131]
[same as prior period, unchanged from 0001564590-17-024351:mdna:115]

[0001564590-18-002876:mdna:132]
| (In millions, except percentages) |  | January 26, 2018 |  |  | April 28, 2017 |  |
| Cash, cash equivalents and short-term investments |  | $ | 5,619 |  |  | $ | 4,921 |  |
| Principal amount of debt |  | $ | 2,182 |  |  | $ | 2,000 |  |
| Debt as a percentage of stockholders' equity |  |  | 100 | % |  |  | 72 | % |

[0001564590-18-002876:mdna:133]
[same as prior period, unchanged from 0001564590-17-024351:mdna:146]

[0001564590-18-002876:mdna:134]
[same as prior period, unchanged from 0001564590-17-024351:mdna:117]

[0001564590-18-002876:mdna:135]
|  |  | Nine Months Ended |  |
| (In millions) |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Net cash provided by operating activities |  | $ | 984 |  |  | $ | 621 |  |
| Net cash used in investing activities |  |  | (141 | ) |  |  | (133 | ) |
| Net cash used in financing activities |  |  | (350 | ) |  |  | (1,128 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 37 |  |  |  | (15 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 530 |  |  | $ | (655 | ) |

[0001564590-18-002876:mdna:136]
[same as prior period, unchanged from 0001564590-17-024351:mdna:119]

[0001564590-18-002876:mdna:137]
As of January 26, 2018, our cash, cash equivalents and short-term investments were $5.6 billion, an increase of $0.7 billion from April 28, 2017. The increase was primarily due to $795 million of net proceeds from the issuance of long-term debt, $210 million in proceeds from the sale of properties, $132 million in proceeds from the issuance of commercial paper notes, net of repayments, and $984 million of cash provided by operating activities, partially offset by $750 million paid to redeem our Senior Notes due in December 2017, $450 million paid for the repurchase of our common stock and $161 million used for the payment of dividends. Working capital increased by $1.1 billion to $3.2 billion as of January 26, 2018 compared to April 28, 2017 primarily due to an increase in cash, cash equivalents and short term investments that was primarily attributable to proceeds from the sale of properties, proceeds from the issuance of commercial paper, net of repayment, and net cash provided by operating activities.

[0001564590-18-002876:mdna:138]
[same as prior period, unchanged from 0001564590-17-024351:mdna:121]

[0001564590-18-002876:mdna:139]
[same as prior period, unchanged from 0001564590-17-024351:mdna:122]

[0001564590-18-002876:mdna:140]
|  |  | Three Months Ended |  |
| (In days) |  | January 26, 2018 |  |  | April 28, 2017 |  |  | January 27, 2017 |  |
| Days sales outstanding (1) |  |  | 45 |  |  |  | 45 |  |  |  | 39 |  |
| Days inventory outstanding (2) |  |  | 15 |  |  |  | 26 |  |  |  | 21 |  |
| Days payables outstanding (3) |  |  | (72 | ) |  |  | (56 | ) |  |  | (42 | ) |
| Cash conversion cycle (4) |  |  | (11 | ) |  |  | 15 |  |  |  | 17 |  |

[0001564590-18-002876:mdna:141]
[same as prior period, unchanged from 0001564590-17-024351:mdna:124]

[0001564590-18-002876:mdna:142]
| (1) | Days sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on ending accounts receivable and net revenue for each period. DSO is calculated by dividing accounts receivable by average net revenue per day for the current quarter (91 days for each of the quarters presented above). The increase in DSO for the third quarter of fiscal 2018 compared to the third quarter of fiscal 2017 was due to differences in the timing of shipments to certain customers. |

[0001564590-18-002876:mdna:143]
| (2) | Days inventory outstanding, referred to as DIO, measures the average number of days from procurement to sale of our products. DIO is based on ending inventory and cost of revenues for each period. DIO is calculated by dividing ending inventory by average cost of revenues per day for the current quarter. DIO for the third quarter of fiscal 2018 decreased compared to the fourth quarter of fiscal 2017 due to lower levels of purchased components, primarily solid state drives, on hand at the end of the current quarter. Additionally, it decreased compared to the third quarter of fiscal 2017 as a result of increased product sales in the third quarter of fiscal 2018. |

[0001564590-18-002876:mdna:144]
| (3) | Days payables outstanding, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and cost of revenues for each period. DPO is calculated by dividing accounts payable by average cost of revenues per day for the current quarter. DPO for the third quarter of fiscal 2018 increased compared to the fourth and third quarters of fiscal 2017, primarily as a result of improved vendor payables management and an extension of payment terms with our suppliers. |

[0001564590-18-002876:mdna:145]
[same as prior period, unchanged from 0001564590-17-024351:mdna:128]

[0001564590-18-002876:mdna:146]
[same as prior period, unchanged from 0001564590-17-024351:mdna:129]

[0001564590-18-002876:mdna:147]
During the first nine months of fiscal 2018, we generated cash from operating activities of $984 million, reflecting a net loss of $195 million, adjusted by non-cash depreciation and amortization of $150 million, stock-based compensation of $125 million, a deferred income tax provision of $258 million, and a gain on sale of properties of $218 million, compared to $621 million of cash generated from operating activities during the first nine months of fiscal 2017.

[0001564590-18-002876:mdna:148]
Changes in assets and liabilities in the first nine months of fiscal 2018 included the following:

[0001564590-18-002876:mdna:149]
|  | • | Accounts payable increased $115 million, primarily due to improved vendor payables management and an extension of payment terms with our suppliers during fiscal 2018. |

[0001564590-18-002876:mdna:150]
|  | • | Deferred revenue and financed unearned services revenue decreased $102 million, primarily due to a decrease in deferred software and hardware maintenance contract revenues reflecting lower contract renewal rates and a decline in ASP on executed contracts. |

[0001564590-18-002876:mdna:151]
|  | • | Long-term taxes payable increased $723 million primarily due to a one-time transition tax liability recorded during the third quarter of fiscal 2018 as a result of the impact of U.S. tax reform, which will be paid over a period of eight years. |

[0001564590-18-002876:mdna:152]
[same as prior period, unchanged from 0001564590-17-024351:mdna:135]

[0001564590-18-002876:mdna:153]
[same as prior period, unchanged from 0001564590-17-024351:mdna:136]

[0001564590-18-002876:mdna:154]
During the first nine months of fiscal 2018, we paid $178 million for the purchases of investments, net of maturities and sales, and paid $97 million for capital expenditures, while during the first nine months of fiscal 2017 we generated $2 million from maturities and sales of investments, net of purchases, and paid $137 million for capital expenditures. Additionally, during the first nine months of fiscal 2018, we paid $75 million to acquire two privately-held companies, and received proceeds of $210 million from the sale of properties.

[0001564590-18-002876:mdna:155]
[same as prior period, unchanged from 0001564590-17-024351:mdna:138]

[0001564590-18-002876:mdna:156]
During the first nine months of fiscal 2018, we generated $795 million in cash from the issuance of long-term debt, $132 million in cash from issuances of commercial paper notes, net of repayments, and used $450 million for the repurchase of 10 million shares of our common stock, $161 million for the payment of dividends, and $750 million to redeem our Senior Notes due in December 2017. During the first nine months of fiscal 2017, we generated $392 million in cash from issuances of commercial paper notes, net of repayments, and used $850 million to repay our short-term loan, $576 million for the repurchase of common stock, and $157 million for the payment of dividends.

[0001564590-18-002876:mdna:157]
[same as prior period, unchanged from 0001564590-17-024351:mdna:140]

[0001564590-18-002876:mdna:158]
[same as prior period, unchanged from 0001564590-17-024351:mdna:141]

[0001564590-18-002876:mdna:159]
Our principal sources of liquidity as of January 26, 2018 consisted of cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001564590-18-002876:mdna:160]
[same as prior period, unchanged from 0001564590-17-024351:mdna:143]

[0001564590-18-002876:mdna:161]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| Cash and cash equivalents |  | $ | 2,974 |  |  | $ | 2,444 |  |
| Short-term investments |  |  | 2,645 |  |  |  | 2,477 |  |
| Total |  | $ | 5,619 |  |  | $ | 4,921 |  |

[0001564590-18-002876:mdna:162]
As of January 26, 2018 and April 28, 2017, $5.0 billion and $4.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.6 billion and $0.4 billion, respectively, were available in the U.S. at the end of each period. Under the transition tax of the TCJA, we have treated all historical foreign earnings as taxable in the U.S. which resulted in a $739 million discrete tax expense in the current quarter. As a part of the provisional estimates recorded during the quarter, we considered the impacts of the TCJA and reviewed our projected global cash requirements and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested.

[0001564590-18-002876:mdna:163]
Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies, and service interest and principal payments on our debt.

[0001564590-18-002876:mdna:164]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of January 26, 2018.

[0001564590-18-002876:mdna:165]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, and other liquidity requirements associated with our operations. We also have an automatic shelf registration statement on file with the Securities and Exchange Commission (SEC). We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001564590-18-002876:mdna:166]
[same as prior period, unchanged from 0001564590-17-024351:mdna:149]

[0001564590-18-002876:mdna:167]
The following table summarizes the principal amount of our Senior Notes as of January 26, 2018 (in millions):

[0001564590-18-002876:mdna:168]
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| Total |  | $ | 1,550 |  |

[0001564590-18-002876:mdna:169]
[same as prior period, unchanged from 0001564590-17-024351:mdna:153]

[0001564590-18-002876:mdna:170]
Commercial Paper Program and Credit Facility

[0001564590-18-002876:mdna:171]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. On July 17, 2017 we amended the Program to increase the maximum amounts available that may be borrowed, repaid and re-borrowed to an aggregate face or principal amount of the notes outstanding of $1.0 billion, as compared to $600 million prior to the amendment. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of January 26, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $632 million, a weighted-average interest rate of 1.81% and maturities ranging from 17 days to 46 days.

[0001564590-18-002876:mdna:172]
In connection with the Program, we have a senior unsecured credit agreement that expires on December 10, 2021. The credit agreement, which was amended on July 17, 2017 provides a $1.0 billion revolving unsecured credit facility that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes, providing another potential source of liquidity to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement also includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of January 26, 2018, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-18-002876:mdna:173]
[same as prior period, unchanged from 0001564590-17-024351:mdna:157]

[0001564590-18-002876:mdna:174]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2018 to be between $50 million and $100 million.

[0001564590-18-002876:mdna:175]
[same as prior period, unchanged from 0001564590-17-024351:mdna:159]

[0001564590-18-002876:mdna:176]
On February 14, 2018, we declared a cash dividend of $0.20 per share of common stock, payable on April 25, 2018 to holders of record as of the close of business on April 6, 2018.

[0001564590-18-002876:mdna:177]
Our Board of Directors had authorized the repurchase of up to $9.6 billion of our common stock under our stock repurchase program. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through January 26, 2018, we repurchased a total of 279 million shares of our common stock at an average price of $33.31 per share, for an aggregate purchase price of $9.3 billion. As of January 26, 2018, the remaining authorized amount for stock repurchases under this program was $0.3 billion, with no termination date, which we plan to complete by May 2018.

[0001564590-18-002876:mdna:178]
[same as prior period, unchanged from 0001564590-17-024351:mdna:162]

[0001564590-18-002876:mdna:179]
[same as prior period, unchanged from 0001564590-17-024351:mdna:163]

[0001564590-18-002876:mdna:180]
[same as prior period, unchanged from 0001564590-17-024351:mdna:164]

[0001564590-18-002876:mdna:181]
As of January 26, 2018, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $198 million.

[0001564590-18-002876:mdna:182]
[same as prior period, unchanged from 0001564590-17-024351:mdna:166]

[0001564590-18-002876:mdna:183]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 26, 2018, we had $387 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-18-002876:mdna:184]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of January 26, 2018, we had $15 million in construction related obligations and $222 million in other purchase obligations.

[0001564590-18-002876:mdna:185]
[same as prior period, unchanged from 0001564590-17-024351:mdna:169]

[0001564590-18-002876:mdna:186]
As of January 26, 2018, our liability for uncertain tax positions was $303 million, including interest, penalties and offsetting indirect benefits. Due to the uncertainty of the timing of future cash payments, we cannot make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-18-002876:mdna:187]
[same as prior period, unchanged from 0001564590-17-024351:mdna:171]

[0001564590-18-002876:mdna:188]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates through December 31, 2017. These properties did not qualify for sale-leaseback accounting and as a result they were accounted for as financing transactions. In December 2017, we terminated the leases and recorded a non-cash sale of properties with a net book value of $54 million, the extinguishment of $130 million in financing obligations, and a gain of $76 million. As of January 26, 2018, there are no balances remaining on our condensed consolidated balance sheets associated with this sale-leaseback arrangement.

[0001564590-18-002876:mdna:189]
[same as prior period, unchanged from 0001564590-17-024351:mdna:173]

[0001564590-18-002876:mdna:190]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $62 million and $142 million of receivables during the first nine months of fiscal 2018 and fiscal 2017, respectively.

[0001564590-18-002876:mdna:191]
37

[0001564590-18-002876:mdna:192]
[same as prior period, unchanged from 0001564590-17-024351:mdna:177]

[0001564590-18-002876:mdna:193]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of January 26, 2018 and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-18-002876:mdna:194]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of January 26, 2018, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-18-002876:mdna:195]
[same as prior period, unchanged from 0001564590-17-024351:mdna:180]

[0001564590-18-002876:mdna:196]
[same as prior period, unchanged from 0001564590-17-024351:mdna:181]

[0001564590-18-002876:mdna:197]
Legal Contingencies

[0001564590-18-002876:mdna:198]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 16 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.
