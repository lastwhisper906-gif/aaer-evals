# NTAP notes — 0001564590-18-002876


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-18-002876:notes:1]
[same as prior period, unchanged from 0001564590-17-024351:notes:1]

[0001564590-18-002876:notes:2]
[same as prior period, unchanged from 0001564590-17-024351:notes:2]

[0001564590-18-002876:notes:3]
[same as prior period, unchanged from 0001564590-17-024351:notes:3]

[0001564590-18-002876:notes:4]
[same as prior period, unchanged from 0001564590-17-024351:notes:4]

[0001564590-18-002876:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 28, 2017 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 26, 2018 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-18-002876:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; valuation of investment securities; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-18-002876:notes:7]
There have been no significant changes in our significant accounting policies as of and for the nine months ended January 26, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 28, 2017.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-18-002876:notes:8]
[same as prior period, unchanged from 0001564590-17-024351:notes:8]

[0001564590-18-002876:notes:9]
Non-cash investing and financing activities and supplemental cash flow information are as follows (in millions):

[0001564590-18-002876:notes:10]
|  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 19 |  |  | $ | 13 |  |
| Non-cash extinguishment of sale-leaseback financing obligations |  | $ | 130 |  |  | $ | 19 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 51 |  |  | $ | 90 |  |
| Interest paid |  | $ | 45 |  |  | $ | 43 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-18-002876:notes:11]
[same as prior period, unchanged from 0001564590-17-024351:notes:11]

[0001564590-18-002876:notes:12]
[same as prior period, unchanged from 0001564590-17-024351:notes:12]

[0001564590-18-002876:notes:13]
[same as prior period, unchanged from 0001564590-17-024351:notes:13]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-18-002876:notes:14]
[same as prior period, unchanged from 0001564590-17-024351:notes:14]

[0001564590-18-002876:notes:15]
[same as prior period, unchanged from 0001564590-17-024351:notes:15]

[0001564590-18-002876:notes:16]
| Balance as of April 28, 2017 |  | $ | 1,684 |  |
| Additions |  |  | 55 |  |
| Balance as of January 26, 2018 |  | $ | 1,739 |  |

[0001564590-18-002876:notes:17]
[same as prior period, unchanged from 0001564590-17-024351:notes:17]

[0001564590-18-002876:notes:18]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 164 |  |  | $ | (71 | ) |  | $ | 93 |  |  | $ | 148 |  |  | $ | (44 | ) |  | $ | 104 |  |
| Customer contracts/relationships |  |  | 43 |  |  |  | (30 | ) |  |  | 13 |  |  |  | 43 |  |  |  | (19 | ) |  |  | 24 |  |
| Other purchased intangibles |  |  | 9 |  |  |  | (9 | ) |  |  | — |  |  |  | 9 |  |  |  | (6 | ) |  |  | 3 |  |
| Total purchased intangible assets |  | $ | 216 |  |  | $ | (110 | ) |  | $ | 106 |  |  | $ | 200 |  |  | $ | (69 | ) |  | $ | 131 |  |

[0001564590-18-002876:notes:19]
[same as prior period, unchanged from 0001564590-17-024351:notes:19]

[0001564590-18-002876:notes:20]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Statements of |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | Operations Classification |
| Developed technology |  | $ | 10 |  |  | $ | 8 |  |  | $ | 27 |  |  | $ | 21 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 3 |  |  |  | 4 |  |  |  | 11 |  |  |  | 11 |  |  | Operating expenses |
| Other purchased intangibles |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |  |  | 3 |  |  | Operating expenses |
| Total |  | $ | 14 |  |  | $ | 13 |  |  | $ | 41 |  |  | $ | 35 |  |  |  |

[0001564590-18-002876:notes:21]
As of January 26, 2018, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-18-002876:notes:22]
| Fiscal Year |  | Amount |  |
| Remainder of 2018 |  | $ | 12 |  |
| 2019 |  |  | 47 |  |
| 2020 |  |  | 31 |  |
| 2021 |  |  | 16 |  |
| Total |  | $ | 106 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-18-002876:notes:23]
[same as prior period, unchanged from 0001564590-17-024351:notes:23]

[0001564590-18-002876:notes:24]
[same as prior period, unchanged from 0001564590-17-024351:notes:24]

[0001564590-18-002876:notes:25]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| Cash |  | $ | 2,563 |  |  | $ | 2,275 |  |
| Cash equivalents |  |  | 411 |  |  |  | 169 |  |
| Cash and cash equivalents |  | $ | 2,974 |  |  | $ | 2,444 |  |

[0001564590-18-002876:notes:26]
[same as prior period, unchanged from 0001564590-17-024351:notes:26]

[0001564590-18-002876:notes:27]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| Purchased components |  | $ | 22 |  |  | $ | 28 |  |
| Finished goods |  |  | 76 |  |  |  | 135 |  |
| Inventories |  | $ | 98 |  |  | $ | 163 |  |

[0001564590-18-002876:notes:28]
[same as prior period, unchanged from 0001564590-17-024351:notes:28]

[0001564590-18-002876:notes:29]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| Land |  | $ | 106 |  |  | $ | 132 |  |
| Buildings and improvements |  |  | 576 |  |  |  | 612 |  |
| Leasehold improvements |  |  | 94 |  |  |  | 93 |  |
| Computer, production, engineering and other equipment |  |  | 726 |  |  |  | 741 |  |
| Computer software |  |  | 358 |  |  |  | 353 |  |
| Furniture and fixtures |  |  | 99 |  |  |  | 90 |  |
| Construction-in-progress |  |  | 26 |  |  |  | 26 |  |
|  |  |  | 1,985 |  |  |  | 2,047 |  |
| Accumulated depreciation and amortization |  |  | (1,244 | ) |  |  | (1,248 | ) |
| Property and equipment, net |  | $ | 741 |  |  | $ | 799 |  |

[0001564590-18-002876:notes:30]
As of April 28, 2017, we had classified certain land and buildings located in Sunnyvale, California, previously reported as property and equipment as assets held-for-sale and included their book value of $118 million in other current assets in the condensed consolidated balance sheets. On September 8, 2017, we entered into an agreement to sell these properties for a total of $306 million, through two separate and independent closings. On December 7, 2017, the first closing occurred and we consummated the sale of properties with a net book value of $66 million for cash proceeds of $210 million, resulting in a gain, net of direct selling costs, of $142 million.

[0001564590-18-002876:notes:31]
The remaining properties, consisting of land with a net book value of $52 million, continue to be classified as assets held-for-sale as of January 26, 2018. We will consummate the sale of these properties, and receive cash proceeds of $96 million, upon the occurrence of the second closing, which is expected to occur within the next 12 months. That closing is subject to due diligence, certain termination rights and customary closing conditions, including local governmental approval of the subdivision of a land parcel.

[0001564590-18-002876:notes:32]
[same as prior period, unchanged from 0001564590-17-024351:notes:31]

[0001564590-18-002876:notes:33]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| Deferred tax assets |  | $ | 289 |  |  | $ | 525 |  |
| Other assets |  |  | 146 |  |  |  | 156 |  |
| Other non-current assets |  | $ | 435 |  |  | $ | 681 |  |

[0001564590-18-002876:notes:34]
[same as prior period, unchanged from 0001564590-17-024351:notes:33]

[0001564590-18-002876:notes:35]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| Accrued compensation and benefits |  | $ | 347 |  |  | $ | 340 |  |
| Sale-leaseback financing obligations |  |  | — |  |  |  | 130 |  |
| Product warranty liabilities |  |  | 26 |  |  |  | 33 |  |
| Other current liabilities |  |  | 366 |  |  |  | 279 |  |
| Accrued expenses |  | $ | 739 |  |  | $ | 782 |  |

[0001564590-18-002876:notes:36]
[same as prior period, unchanged from 0001564590-17-024351:notes:35]

[0001564590-18-002876:notes:37]
[same as prior period, unchanged from 0001564590-17-024351:notes:36]

[0001564590-18-002876:notes:38]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Balance at beginning of period |  | $ | 44 |  |  | $ | 54 |  |  | $ | 50 |  |  | $ | 70 |  |
| Expense accrued during the period |  |  | 3 |  |  |  | 4 |  |  |  | 11 |  |  |  | 9 |  |
| Warranty costs incurred |  |  | (6 | ) |  |  | (8 | ) |  |  | (20 | ) |  |  | (29 | ) |
| Balance at end of period |  | $ | 41 |  |  | $ | 50 |  |  | $ | 41 |  |  | $ | 50 |  |

[0001564590-18-002876:notes:39]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| Accrued expenses |  | $ | 26 |  |  | $ | 33 |  |
| Other long-term liabilities |  |  | 15 |  |  |  | 17 |  |
| Total warranty liabilities |  | $ | 41 |  |  | $ | 50 |  |

[0001564590-18-002876:notes:40]
[same as prior period, unchanged from 0001564590-17-024351:notes:39]

[0001564590-18-002876:notes:41]
Other long-term liabilities (in millions):

[0001564590-18-002876:notes:42]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| Liability for uncertain tax positions |  | $ | 303 |  |  | $ | 148 |  |
| Income taxes payable |  |  | 569 |  |  |  | — |  |
| Product warranty liabilities |  |  | 15 |  |  |  | 17 |  |
| Other liabilities |  |  | 86 |  |  |  | 84 |  |
| Other long-term liabilities |  | $ | 973 |  |  | $ | 249 |  |

[0001564590-18-002876:notes:43]
[same as prior period, unchanged from 0001564590-17-024351:notes:40]

[0001564590-18-002876:notes:44]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| Deferred product revenue |  | $ | 113 |  |  | $ | 124 |  |
| Deferred services revenue |  |  | 3,014 |  |  |  | 2,999 |  |
| Financed unearned services revenue |  |  | 142 |  |  |  | 219 |  |
| Total |  | $ | 3,269 |  |  | $ | 3,342 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,719 |  |  | $ | 1,744 |  |
| Long-term |  |  | 1,550 |  |  |  | 1,598 |  |
| Total |  | $ | 3,269 |  |  | $ | 3,342 |  |

[0001564590-18-002876:notes:45]
[same as prior period, unchanged from 0001564590-17-024351:notes:42]


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-18-002876:notes:46]
[same as prior period, unchanged from 0001564590-17-024351:notes:43]

[0001564590-18-002876:notes:47]
[same as prior period, unchanged from 0001564590-17-024351:notes:44]

[0001564590-18-002876:notes:48]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Interest income |  | $ | 20 |  |  | $ | 10 |  |  | $ | 55 |  |  | $ | 31 |  |
| Interest expense |  |  | (17 | ) |  |  | (12 | ) |  |  | (47 | ) |  |  | (39 | ) |
| Other income, net |  |  | 11 |  |  |  | 2 |  |  |  | 17 |  |  |  | 7 |  |
| Total other income (expense), net |  | $ | 14 |  |  | $ | — |  |  | $ | 25 |  |  | $ | (1 | ) |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-18-002876:notes:49]
[same as prior period, unchanged from 0001564590-17-024351:notes:46]

[0001564590-18-002876:notes:50]
[same as prior period, unchanged from 0001564590-17-024351:notes:47]

[0001564590-18-002876:notes:51]
[same as prior period, unchanged from 0001564590-17-024351:notes:48]

[0001564590-18-002876:notes:52]
[same as prior period, unchanged from 0001564590-17-024351:notes:49]

[0001564590-18-002876:notes:53]
[same as prior period, unchanged from 0001564590-17-024351:notes:50]

[0001564590-18-002876:notes:54]
[same as prior period, unchanged from 0001564590-17-024351:notes:51]

[0001564590-18-002876:notes:55]
[same as prior period, unchanged from 0001564590-17-024351:notes:52]

[0001564590-18-002876:notes:56]
[same as prior period, unchanged from 0001564590-17-024351:notes:53]

[0001564590-18-002876:notes:57]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,888 |  |  | $ | 3 |  |  | $ | (14 | ) |  | $ | 1,877 |  |  | $ | 1,535 |  |  | $ | 3 |  |  | $ | (2 | ) |  | $ | 1,536 |  |
| U.S. Treasury and government debt securities |  |  | 520 |  |  |  | — |  |  |  | (4 | ) |  |  | 516 |  |  |  | 629 |  |  |  | 1 |  |  |  | (2 | ) |  |  | 628 |  |
| Foreign government debt securities |  |  | 12 |  |  |  | — |  |  |  | — |  |  |  | 12 |  |  |  | 21 |  |  |  | — |  |  |  | — |  |  |  | 21 |  |
| Commercial paper |  |  | 544 |  |  |  | — |  |  |  | — |  |  |  | 544 |  |  |  | 362 |  |  |  | — |  |  |  | — |  |  |  | 362 |  |
| Certificates of deposit |  |  | 107 |  |  |  | — |  |  |  | — |  |  |  | 107 |  |  |  | 99 |  |  |  | — |  |  |  | — |  |  |  | 99 |  |
| Mutual funds |  |  | 33 |  |  |  | — |  |  |  | — |  |  |  | 33 |  |  |  | 31 |  |  |  | — |  |  |  | — |  |  |  | 31 |  |
| Total debt and equity securities |  | $ | 3,104 |  |  | $ | 3 |  |  | $ | (18 | ) |  | $ | 3,089 |  |  | $ | 2,677 |  |  | $ | 4 |  |  | $ | (4 | ) |  | $ | 2,677 |  |

[0001564590-18-002876:notes:58]
As of January 26, 2018 and April 28, 2017, gross unrealized losses related to individual securities were not significant.

[0001564590-18-002876:notes:59]
The following table presents the contractual maturities of our debt investments as of January 26, 2018 (in millions):

[0001564590-18-002876:notes:60]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,215 |  |  | $ | 1,215 |  |
| Due after one year through five years |  |  | 1,195 |  |  |  | 1,185 |  |
| Due after five years through ten years |  |  | 661 |  |  |  | 656 |  |
|  |  | $ | 3,071 |  |  | $ | 3,056 |  |

[0001564590-18-002876:notes:61]
[same as prior period, unchanged from 0001564590-17-024351:notes:58]

[0001564590-18-002876:notes:62]
[same as prior period, unchanged from 0001564590-17-024351:notes:59]

[0001564590-18-002876:notes:63]
[same as prior period, unchanged from 0001564590-17-024351:notes:60]

[0001564590-18-002876:notes:64]
|  |  | January 26, 2018 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,563 |  |  | $ | 2,563 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,877 |  |  |  | — |  |  |  | 1,877 |  |
| U.S. Treasury and government debt securities |  |  | 516 |  |  |  | 260 |  |  |  | 256 |  |
| Foreign government debt securities |  |  | 12 |  |  |  | — |  |  |  | 12 |  |
| Commercial paper |  |  | 544 |  |  |  | — |  |  |  | 544 |  |
| Certificates of deposit |  |  | 107 |  |  |  | — |  |  |  | 107 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 5,619 |  |  | $ | 2,823 |  |  | $ | 2,796 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 26 |  |  | $ | 26 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (13 | ) |  | $ | — |  |  | $ | (13 | ) |

[0001564590-18-002876:notes:65]
[same as prior period, unchanged from 0001564590-17-024351:notes:62]

[0001564590-18-002876:notes:66]
[same as prior period, unchanged from 0001564590-17-024351:notes:63]

[0001564590-18-002876:notes:67]
[same as prior period, unchanged from 0001564590-17-024351:notes:64]

[0001564590-18-002876:notes:68]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of January 26, 2018 and April 28, 2017, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-18-002876:notes:69]
[same as prior period, unchanged from 0001564590-17-024351:notes:66]

[0001564590-18-002876:notes:70]
As of January 26, 2018 and April 28, 2017, the fair value of our long-term debt was approximately $1,551 million and $1,520 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-18-002876:notes:71]
9. Financing Arrangements

[0001564590-18-002876:notes:72]
Long-Term Debt

[0001564590-18-002876:notes:73]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-18-002876:notes:74]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | — |  |  | N/A |  |  | $ | 750 |  |  |  | 2.25 | % |
| 2.00% Senior Notes Due September 2019 |  |  | 400 |  |  |  | 2.32 | % |  |  | — |  |  | N/A |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | — |  |  | N/A |  |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (10 | ) |  |  |  |  |  |  | (7 | ) |  |  |  |  |
| Total senior notes |  |  | 1,540 |  |  |  |  |  |  |  | 1,493 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | — |  |  |  |  |  |  |  | (749 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,540 |  |  |  |  |  |  | $ | 744 |  |  |  |  |  |

[0001564590-18-002876:notes:75]
__________________

[0001564590-18-002876:notes:76]
N/A - Not applicable

[0001564590-18-002876:notes:77]
Senior Notes

[0001564590-18-002876:notes:78]
In September 2017, we issued $400 million aggregate principal amount of 2.00% Senior Notes due on September 27, 2019 and $400 million aggregate principal amount of 3.30% Senior Notes due on September 29, 2024, for which we received total proceeds of approximately $795 million, net of discount and issuance costs. On November 3, 2017, we extinguished our 2.00% Senior Notes due December 2017 for an aggregate redemption price of $751 million, plus accrued and unpaid interest.

[0001564590-18-002876:notes:79]
Interest on our Senior Notes issued in September 2017 is payable semi-annually in March and September. Our 3.375% Senior Notes and 3.25% Senior Notes, with principal amounts of $500 million and $250 million, respectively, were issued in June 2014 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-18-002876:notes:80]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 26, 2018, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-18-002876:notes:81]
As of January 26, 2018, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-18-002876:notes:82]
| Fiscal Year |  | Amount |  |
| 2020 |  | $ | 400 |  |
| 2022 |  |  | 500 |  |
| Thereafter |  |  | 650 |  |
| Total |  | $ | 1,550 |  |

[0001564590-18-002876:notes:83]
Commercial Paper Program and Credit Facility

[0001564590-18-002876:notes:84]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended on July 17, 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of January 26, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $632 million, a weighted-average interest rate of 1.81% and maturities ranging from 17 days to 46 days. As of April 28, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $500 million, a weighted-average interest rate of 1.26% and maturities ranging from 7 days to 38 days.

[0001564590-18-002876:notes:85]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended on July 17, 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of January 26, 2018 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-18-002876:notes:86]
Sale-leaseback Transactions

[0001564590-18-002876:notes:87]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates through December 31, 2017. These properties did not qualify for sale-leaseback accounting and as a result they were accounted for as financing transactions. In December 2017, we terminated the leases and recorded a non-cash sale of properties with a net book value of $54 million, the extinguishment of $130 million in financing obligations, and a gain of $76 million. As of January 26, 2018, there are no balances remaining on our condensed consolidated balance sheets associated with this sale-leaseback arrangement.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-18-002876:notes:88]
[same as prior period, unchanged from 0001564590-17-024351:notes:85]

[0001564590-18-002876:notes:89]
[same as prior period, unchanged from 0001564590-17-024351:notes:86]

[0001564590-18-002876:notes:90]
As of January 26, 2018, we have certain equity incentive awards (awards) outstanding, which include stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and Employee Stock Purchase Plan (ESPP) awards.

[0001564590-18-002876:notes:91]
[same as prior period, unchanged from 0001564590-17-024351:notes:88]

[0001564590-18-002876:notes:92]
[same as prior period, unchanged from 0001564590-17-024351:notes:89]

[0001564590-18-002876:notes:93]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 28, 2017 |  |  | 4 |  |  | $ | 35.76 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (2 | ) |  | $ | 36.44 |  |  |  |  |  |  |  |  |  |
| Outstanding as of January 26, 2018 |  |  | 2 |  |  | $ | 33.24 |  |  |  | 3.35 |  |  | $ | 49 |  |
| Exercisable as of January 26, 2018 |  |  | 1 |  |  | $ | 37.57 |  |  |  | 2.62 |  |  | $ | 34 |  |

[0001564590-18-002876:notes:94]
[same as prior period, unchanged from 0001564590-17-024351:notes:91]

[0001564590-18-002876:notes:95]
[same as prior period, unchanged from 0001564590-17-024351:notes:92]

[0001564590-18-002876:notes:96]
|  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Intrinsic value of exercises |  | $ | 29 |  |  | $ | 18 |  |
| Proceeds received from exercises |  | $ | 72 |  |  | $ | 33 |  |
| Fair value of options vested |  | $ | 6 |  |  | $ | 12 |  |

[0001564590-18-002876:notes:97]
[same as prior period, unchanged from 0001564590-17-024351:notes:94]

[0001564590-18-002876:notes:98]
In the nine months ended January 26, 2018, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria such that the PBRSU cliff-vests at the end of either an approximate two year or three year performance period, which began on the date specified in the grant agreement and ends the last day of the second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted, and will depend upon our Total Stockholder Return (TSR) as compared to an index TSR (each expressed as a growth rate percentage) calculated as of the applicable period end date. The fair values of the PBRSUs were fixed at grant date using a Monte Carlo simulation model and the related aggregate compensation cost of $20 million is being recognized over the shorter of the remaining applicable performance or service periods.

[0001564590-18-002876:notes:99]
[same as prior period, unchanged from 0001564590-17-024351:notes:96]

[0001564590-18-002876:notes:100]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 28, 2017 |  |  | 11 |  |  | $ | 28.81 |  |
| Granted |  |  | 4 |  |  | $ | 38.96 |  |
| Vested |  |  | (5 | ) |  | $ | 31.08 |  |
| Forfeited |  |  | (1 | ) |  | $ | 29.06 |  |
| Outstanding as of January 26, 2018 |  |  | 9 |  |  | $ | 32.10 |  |

[0001564590-18-002876:notes:101]
[same as prior period, unchanged from 0001564590-17-024351:notes:98]

[0001564590-18-002876:notes:102]
|  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Shares withheld for taxes |  |  | 2 |  |  |  | 2 |  |
| Fair value of shares withheld |  | $ | 67 |  |  | $ | 42 |  |

[0001564590-18-002876:notes:103]
[same as prior period, unchanged from 0001564590-17-024351:notes:100]

[0001564590-18-002876:notes:104]
[same as prior period, unchanged from 0001564590-17-024351:notes:101]

[0001564590-18-002876:notes:105]
|  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Shares issued under the ESPP |  |  | 4 |  |  |  | 4 |  |
| Proceeds from issuance of shares |  | $ | 85 |  |  | $ | 80 |  |

[0001564590-18-002876:notes:106]
[same as prior period, unchanged from 0001564590-17-024351:notes:103]

[0001564590-18-002876:notes:107]
[same as prior period, unchanged from 0001564590-17-024351:notes:104]

[0001564590-18-002876:notes:108]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Cost of product revenues |  | $ | — |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 3 |  |
| Cost of hardware maintenance and other services revenues |  |  | 3 |  |  |  | 3 |  |  |  | 8 |  |  |  | 10 |  |
| Sales and marketing |  |  | 16 |  |  |  | 20 |  |  |  | 53 |  |  |  | 64 |  |
| Research and development |  |  | 11 |  |  |  | 14 |  |  |  | 38 |  |  |  | 46 |  |
| General and administrative |  |  | 8 |  |  |  | 8 |  |  |  | 24 |  |  |  | 26 |  |
| Total stock-based compensation expense |  | $ | 38 |  |  | $ | 46 |  |  | $ | 125 |  |  | $ | 149 |  |
| Income tax benefit for stock-based compensation |  | $ | 5 |  |  | $ | 10 |  |  | $ | 23 |  |  | $ | 30 |  |

[0001564590-18-002876:notes:109]
As of January 26, 2018, total unrecognized compensation expense related to our equity awards was $239 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.2 years.

[0001564590-18-002876:notes:110]
[same as prior period, unchanged from 0001564590-17-024351:notes:107]

[0001564590-18-002876:notes:111]
[same as prior period, unchanged from 0001564590-17-024351:notes:108]

[0001564590-18-002876:notes:112]
The following table summarizes activity related to this program for the nine months ended January 26, 2018 (in millions, except per share amounts):

[0001564590-18-002876:notes:113]
| Number of shares repurchased |  |  | 10 |  |
| Average price per share |  | $ | 46.37 |  |
| Aggregate purchase price |  | $ | 450 |  |
| Remaining authorization at end of period |  | $ | 344 |  |

[0001564590-18-002876:notes:114]
The aggregate purchase price of our stock repurchases for the nine months ended January 26, 2018 consisted of $450 million of open market purchases, of which $224 million and $226 million were allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-18-002876:notes:115]
Since the May 13, 2003 inception of our stock repurchase program through January 26, 2018, we repurchased a total of 279 million shares of our common stock at an average price of $33.31 per share, for an aggregate purchase price of $9.3 billion.

[0001564590-18-002876:notes:116]
[same as prior period, unchanged from 0001564590-17-024351:notes:113]

[0001564590-18-002876:notes:117]
[same as prior period, unchanged from 0001564590-17-024351:notes:114]

[0001564590-18-002876:notes:118]
|  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Dividends per share declared |  | $ | 0.60 |  |  | $ | 0.57 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 53 |  |  | $ | 88 |  |
| Dividend payments allocated to retained earnings (accumulated deficit) |  | $ | 108 |  |  | $ | 69 |  |

[0001564590-18-002876:notes:119]
On February 14, 2018, we declared a cash dividend of $0.20 per share of common stock, payable on April 25, 2018 to holders of record as of the close of business on April 6, 2018. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-18-002876:notes:120]
Retained Earnings (Accumulated Deficit)

[0001564590-18-002876:notes:121]
A reconciliation of retained earnings (accumulated deficit) is as follows (in millions):

[0001564590-18-002876:notes:122]
| Balance as of April 28, 2017 |  | $ | 40 |  |
| Net loss |  |  | (195 | ) |
| Repurchases of common stock |  |  | (226 | ) |
| Dividends |  |  | (108 | ) |
| Balance as of January 26, 2018 |  | $ | (489 | ) |

[0001564590-18-002876:notes:123]
[same as prior period, unchanged from 0001564590-17-024351:notes:120]

[0001564590-18-002876:notes:124]
[same as prior period, unchanged from 0001564590-17-024351:notes:121]

[0001564590-18-002876:notes:125]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Total |  |
| Balance as of April 28, 2017 |  | $ | (29 | ) |  | $ | — |  |  | $ | — |  |  | $ | (29 | ) |
| Other comprehensive income, net of tax |  |  | 3 |  |  |  | (1 | ) |  |  | (15 | ) |  |  | (13 | ) |
| Balance as of January 26, 2018 |  | $ | (26 | ) |  | $ | (1 | ) |  | $ | (15 | ) |  | $ | (42 | ) |

[0001564590-18-002876:notes:126]
[same as prior period, unchanged from 0001564590-17-024351:notes:123]

[0001564590-18-002876:notes:127]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Classification |
| Recognized (gains) losses on defined benefit obligations |  | $ | (1 | ) |  | $ | — |  |  | $ | (2 | ) |  | $ | 1 |  |  | Operating expenses |
| Realized gains on cash flow hedges |  |  | — |  |  |  | (5 | ) |  |  | — |  |  |  | (6 | ) |  | Net revenues |
| Total reclassifications |  | $ | (1 | ) |  | $ | (5 | ) |  | $ | (2 | ) |  | $ | (5 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-18-002876:notes:128]
[same as prior period, unchanged from 0001564590-17-024351:notes:125]

[0001564590-18-002876:notes:129]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is six months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of our agreements with them. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of January 26, 2018 or April 28, 2017. We did not recognize any gains or losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-18-002876:notes:130]
[same as prior period, unchanged from 0001564590-17-024351:notes:127]

[0001564590-18-002876:notes:131]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 125 |  |  | $ | 165 |  |
| Forward contracts purchased |  | $ | 531 |  |  | $ | 257 |  |

[0001564590-18-002876:notes:132]
As of January 26, 2018 and April 28, 2017, there were no instruments designated as cash flow hedges outstanding.

[0001564590-18-002876:notes:133]
The effect of cash flow hedges recognized in net revenues is presented in the condensed consolidated statements of comprehensive income (loss) and in Note 10 – Stockholders’ Equity.

[0001564590-18-002876:notes:134]
[same as prior period, unchanged from 0001564590-17-024351:notes:131]

[0001564590-18-002876:notes:135]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |
|  |  | Gain (Loss) Recognized into Income |  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | (12 | ) |  | $ | 2 |  |  | $ | (13 | ) |  | $ | 8 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-18-002876:notes:136]
[same as prior period, unchanged from 0001564590-17-024351:notes:133]

[0001564590-18-002876:notes:137]
Management has previously approved several restructuring actions to streamline our business, eliminate costs and redirect resources to our highest return activities, including the March 2016 Plan and the November 2016 Plan, under which we reduced our global workforce by approximately 11%, and 6%, respectively. We completed all workforce related activities under these plans as of the end of fiscal 2017. Charges related to our restructuring plans consisted primarily of employee severance-related costs. The remaining balance as of January 26, 2018 principally relates to lease obligations that will be paid over their remaining terms.

[0001564590-18-002876:notes:138]
[same as prior period, unchanged from 0001564590-17-024351:notes:135]

[0001564590-18-002876:notes:139]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |
|  |  | November 2016 Plan |  |  | March 2016 Plan |  |
| Balance at beginning of period |  | $ | 13 |  |  | $ | 45 |  |
| Cash payments |  |  | (7 | ) |  |  | (45 | ) |
| Balance at end of period |  | $ | 6 |  |  | $ | — |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-002876:notes:140]
[same as prior period, unchanged from 0001564590-17-024351:notes:137]

[0001564590-18-002876:notes:141]
[same as prior period, unchanged from 0001564590-17-024351:notes:138]

[0001564590-18-002876:notes:142]
|  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Effective tax rates |  |  | 122.6 | % |  |  | 23.5 | % |

[0001564590-18-002876:notes:143]
Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations which are headquartered in the Netherlands, being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory tax rate. The differences in effective tax rates for the nine months ended January 26, 2018 and January 27, 2017 were primarily related to the impacts of recent U.S. tax reform and the sale of certain buildings and land in Sunnyvale, California.

[0001564590-18-002876:notes:144]
On December 22, 2017, the 2017 Tax Reform Reconciliation Act, originally referred to as the Tax Cuts and Jobs Act (“TCJA”) was enacted into law and is effective for the third quarter of our fiscal 2018. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate, the imposition of a one-time transition tax on deferred foreign earnings, and a shift to a modified territorial tax regime. ASC 740, Income Taxes, requires that the impact on income taxes due to a change in legislation be recognized in the period of enactment. Given the timing and pace of regulatory guidance, the Securities and Exchange Commission (SEC) issued Staff Accounting Bulletin 118, which allows for the recording of provisional amounts related to U.S. tax reform and subsequent related adjustments during a measurement period.

[0001564590-18-002876:notes:145]
As of January 26, 2018, we have not fully completed the accounting for the tax impacts of the TCJA and have recorded provisional tax charges based on reasonable estimates for the transition tax on our total post-1986 foreign earnings and profits (“E&P”), and for the remeasurement of deferred tax assets and liabilities based on the new corporate tax rate. The TCJA also includes provisions for a global minimum tax on intangible low-taxed income (“GMT”) of foreign subsidiaries, a base erosion anti-abuse tax on certain intercompany payments, and beneficial tax treatment for foreign derived intangible income. These provisions will be effective for us beginning in our fiscal 2019. We will continue to refine provisional balances and make adjustments during the measurement period based on the issuance of further regulatory guidance, changes in interpretations, and the collection and analysis of additional information; these adjustments could be material to our financial statements.  The provisional amounts recorded during the current quarter are explained below.

[0001564590-18-002876:notes:146]
The TJCA decreased the U.S. federal corporate tax rate from 35% to 21% as of January 1, 2018.  For fiscal 2018, this decrease results in a blended statutory tax rate of 30.5%. As a result of the tax rate change, we remeasured our deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future periods and recorded a $117 million discrete tax expense for the quarter. The final remeasurement impact could vary from the provisional amount if actual future activities impacting deferred tax balances differ from our estimates.

[0001564590-18-002876:notes:147]
The TCJA imposes a mandatory, one-time transition tax on accumulated foreign E&P not previously subject to U.S. income tax at a rate of 15.5% on earnings to the extent of foreign cash and other liquid assets, and 8% on the remaining earnings. During the quarter, we recorded a $739 million discrete tax expense for the estimated U.S. federal and state income tax impacts of the transition tax.  Our estimates may change with further guidance from U.S. federal and state tax authorities or other regulatory bodies, our fourth quarter activities, and additional analyses that we expect to complete during the measurement period, with respect to various components of the computations. We intend to make the election to pay the one-time transition tax over a period of eight years.

[0001564590-18-002876:notes:148]
Under the TCJA, the GMT provision taxes foreign income in excess of a deemed return on tangible assets of foreign corporations. Under U.S. GAAP, companies are allowed to make an accounting policy election to either (i) account for GMT as a component of tax expense in the period in which a company is subject to the rules (the “period cost method”), or (ii) account for GMT in a company’s measurement of deferred taxes (the “deferred method”). Because of the complexity of the new tax rules, we are continuing to evaluate this provision and the application of ASC 740 and have not yet made an accounting policy election.

[0001564590-18-002876:notes:149]
As a part of the provisional estimates recorded during the quarter, we considered the impacts of the TCJA and reviewed our projected global cash requirements, and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested.

[0001564590-18-002876:notes:150]
During the quarter ended January 26, 2018, we also recorded a $72 million discrete tax expense related to the sale of certain buildings and land in Sunnyvale, California. The expense partially relates to gains triggered by the termination of a fiscal 2016 sale-leaseback arrangement.  The remainder of the expense relates to the sale of buildings and land in the current quarter.

[0001564590-18-002876:notes:151]
As of January 26, 2018, we had $338 million of gross unrecognized tax benefits, and $303 million has been recorded in other long-term liabilities inclusive of penalties, interest and indirect benefits. Unrecognized tax benefits of $284 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized. As result of the U.S. tax reform, we recorded $113 million of gross unrecognized tax benefits.

[0001564590-18-002876:notes:152]
We are currently undergoing federal income tax audits in the U.S. and several foreign tax jurisdictions. Transfer pricing calculations are key issues under audits in various jurisdictions, and are often subject to dispute and appeals. The IRS has concluded the examination of our tax returns for our fiscal years through 2010. The IRS commenced the examination of our federal income tax returns for our fiscal years 2012 and 2013 in August 2016.

[0001564590-18-002876:notes:153]
[same as prior period, unchanged from 0001564590-17-024351:notes:143]

[0001564590-18-002876:notes:154]
[same as prior period, unchanged from 0001564590-17-024351:notes:144]


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-002876:notes:155]
14. Net Income (Loss) per Share

[0001564590-18-002876:notes:156]
The following is a calculation of basic and diluted net income (loss) per share (in millions, except per share amounts):

[0001564590-18-002876:notes:157]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (506 | ) |  | $ | 146 |  |  | $ | (195 | ) |  | $ | 319 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 268 |  |  |  | 274 |  |  |  | 269 |  |  |  | 277 |  |
| Dilutive impact of employee equity award plans |  |  | — |  |  |  | 7 |  |  |  | — |  |  |  | 5 |  |
| Shares used in diluted computation |  |  | 268 |  |  |  | 281 |  |  |  | 269 |  |  |  | 282 |  |
| Net Income (Loss) per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (1.89 | ) |  | $ | 0.53 |  |  | $ | (0.72 | ) |  | $ | 1.15 |  |
| Diluted |  | $ | (1.89 | ) |  | $ | 0.52 |  |  | $ | (0.72 | ) |  | $ | 1.13 |  |

[0001564590-18-002876:notes:158]
Potential shares from outstanding employee equity awards totaling 15 million and 4 million for the three months ended January 26, 2018 and January 27, 2017, respectively, and 17 million and 8 million for the nine months ended January 26, 2018 and January 27, 2017, respectively, were excluded from the diluted net income (loss) per share calculations as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-002876:notes:159]
[same as prior period, unchanged from 0001564590-17-024351:notes:149]

[0001564590-18-002876:notes:160]
[same as prior period, unchanged from 0001564590-17-024351:notes:150]

[0001564590-18-002876:notes:161]
[same as prior period, unchanged from 0001564590-17-024351:notes:151]

[0001564590-18-002876:notes:162]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| United States, Canada and Latin America (Americas) |  | $ | 823 |  |  | $ | 767 |  |  | $ | 2,345 |  |  | $ | 2,271 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 487 |  |  |  | 460 |  |  |  | 1,319 |  |  |  | 1,243 |  |
| Asia Pacific (APAC) |  |  | 213 |  |  |  | 177 |  |  |  | 606 |  |  |  | 524 |  |
| Net revenues |  | $ | 1,523 |  |  | $ | 1,404 |  |  | $ | 4,270 |  |  | $ | 4,038 |  |

[0001564590-18-002876:notes:163]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $739 million and $684 million during the three months ended January 26, 2018 and January 27, 2017, respectively, and were $2,115 million and $2,047 million during the nine months ended January 26, 2018 and January 27, 2017, respectively.

[0001564590-18-002876:notes:164]
[same as prior period, unchanged from 0001564590-17-024351:notes:154]

[0001564590-18-002876:notes:165]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| U.S. |  | $ | 562 |  |  | $ | 425 |  |
| International |  |  | 5,057 |  |  |  | 4,496 |  |
| Total |  | $ | 5,619 |  |  | $ | 4,921 |  |

[0001564590-18-002876:notes:166]
[same as prior period, unchanged from 0001564590-17-024351:notes:156]

[0001564590-18-002876:notes:167]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| U.S. |  | $ | 548 |  |  | $ | 593 |  |
| International |  |  | 193 |  |  |  | 206 |  |
| Total |  | $ | 741 |  |  | $ | 799 |  |

[0001564590-18-002876:notes:168]
[same as prior period, unchanged from 0001564590-17-024351:notes:158]

[0001564590-18-002876:notes:169]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 22 | % |  |  | 23 | % |  |  | 21 | % |
| Tech Data Corporation (previously presented as Avnet, Inc.) |  |  | 19 | % |  |  | 20 | % |  |  | 19 | % |  |  | 20 | % |

[0001564590-18-002876:notes:170]
[same as prior period, unchanged from 0001564590-17-024351:notes:160]

[0001564590-18-002876:notes:171]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| Arrow Electronics, Inc. |  |  | 11 | % |  |  | 15 | % |
| Tech Data Corporation (previously presented as Avnet, Inc.) |  |  | 11 | % |  |  | 14 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-002876:notes:172]
16. Commitments and Contingencies

[0001564590-18-002876:notes:173]
Operating Leases

[0001564590-18-002876:notes:174]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $198 million as of January 26, 2018.

[0001564590-18-002876:notes:175]
Purchase Orders and Other Commitments

[0001564590-18-002876:notes:176]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 26, 2018, we had $387 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 26, 2018 and April 28, 2017, such liability amounted to $11 million and $10 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-18-002876:notes:177]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 26, 2018, we had $15 million in construction related obligations and $222 million in other purchase obligations.

[0001564590-18-002876:notes:178]
Financing Guarantees

[0001564590-18-002876:notes:179]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $62 million and $142 million of receivables during the nine months ended January 26, 2018 and January 27, 2017, respectively.

[0001564590-18-002876:notes:180]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-18-002876:notes:181]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of January 26, 2018 and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-18-002876:notes:182]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 26, 2018, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-18-002876:notes:183]
Legal Contingencies

[0001564590-18-002876:notes:184]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict, and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-18-002876:notes:185]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-18-002876:notes:186]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of January 26, 2018 related to such matters.
