# NTAP 8-K — 0001564590-18-002075 filed 2018-02-14

## item codes, every 8-K on or before 2018-02-22

- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2018-02-22

- none on or before 2018-02-22

## item 2.02 — earnings release, exhibit 99.1

[0001564590-18-002075:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-18-002075:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-18-002075:8k_2_02:3]
Exhibit 99.1

[0001564590-18-002075:8k_2_02:4]
NetApp Reports Third Quarter Fiscal Year 2018 Results

[0001564590-18-002075:8k_2_02:5]
Net Revenues of $1.52 Billion Grew 8% Year-over-Year

[0001564590-18-002075:8k_2_02:6]
Third Quarter Fiscal 2018 Highlights

[0001564590-18-002075:8k_2_02:7]
| • | Product revenue increased 17% year-over-year |  |

[0001564590-18-002075:8k_2_02:8]
| • | All-flash array annualized net revenue run rate of $2.0 billion increased almost 50% year-over-year |  |

[0001564590-18-002075:8k_2_02:9]
| • | Expanded Cloud Data Services with introduction of NetApp Cloud Volumes for AWS |  |

[0001564590-18-002075:8k_2_02:10]
| • | Free cash flow was 25% of revenue and increased 104% year-over-year |  |

[0001564590-18-002075:8k_2_02:11]
Sunnyvale, Calif.—February 14, 2018—NetApp (NASDAQ: NTAP) today reported financial results for the third quarter fiscal year 2018, ended January 26, 2018.

[0001564590-18-002075:8k_2_02:12]
“NetApp again delivered strong results in the third quarter with accelerating revenue and strong cash generation. It is rewarding to see the results of our improved execution as we transform NetApp to deliver sustained and profitable growth,” said George Kurian, chief executive officer. “We saw a solid demand environment and customer momentum, landing wins and footprint expansions with leading organizations in all geographies. With our Data Fabric Strategy and industry-leading solutions, we are winning new customers and expanding our business opportunity.”

[0001564590-18-002075:8k_2_02:13]
Third Quarter Fiscal 2018 Financial Results

[0001564590-18-002075:8k_2_02:14]
| • | Net Revenues: $1.52 billion, increased 8% year-over-year from $1.40 billion in the third quarter of fiscal 2017 |  |

[0001564590-18-002075:8k_2_02:15]
| • | Net Income: GAAP net loss of $506 million*, compared to GAAP net income of $146 million in the third quarter of fiscal 2017; non-GAAP net income1 of $273 million, compared to non-GAAP net income of $231 million in the third quarter of fiscal 2017 |  |

[0001564590-18-002075:8k_2_02:16]
| • | Earnings per Share: GAAP net loss per share2 of $1.89*, compared to GAAP net income per share3 of $0.52 in the third quarter of fiscal 2017; non-GAAP net income per share4 of $0.99, compared to non-GAAP net income per share of $0.82 in the third quarter of fiscal 2017 |  |

[0001564590-18-002075:8k_2_02:17]
| • | Cash, Cash Equivalents and Investments: $5.6 billion at the end of the third quarter of fiscal 2018 |  |

[0001564590-18-002075:8k_2_02:18]
| • | Cash from Operations: $420 million, compared to $235 million in the third quarter of fiscal 2017 |  |

[0001564590-18-002075:8k_2_02:19]
| • | Share Repurchase and Dividend: Returned $203 million to shareholders through share repurchases and a cash dividend |  |

[0001564590-18-002075:8k_2_02:20]
*On December 22, 2017, The 2017 Tax Reform Reconciliation Act was enacted into law. This tax reform legislation contains several key tax provisions that affected the company, including a one-time mandatory transition tax on accumulated foreign earnings and a reduction of the U.S. corporate income tax rate to 21% effective January 1, 2018, among others. GAAP net loss in the third quarter of fiscal 2018 includes a resulting one-time charge of $856 million.

[0001564590-18-002075:8k_2_02:21]
Fourth Quarter Fiscal 2018 Financial Outlook

[0001564590-18-002075:8k_2_02:22]
The Company provided the following financial guidance for the fourth quarter of fiscal year 2018:

[0001564590-18-002075:8k_2_02:23]
| • | Net revenues are expected to be in the range of $1.525 billion to $1.675 billion |  |

[0001564590-18-002075:8k_2_02:24]
|  | GAAP | Non-GAAP |
| •Earnings per share is expected to be in the range of: | $0.75–$0.83 | $0.95–$1.03 |

[0001564590-18-002075:8k_2_02:25]
Dividend

[0001564590-18-002075:8k_2_02:26]
| • | Next cash dividend of $0.20 per share to be paid on April 25, 2018, to shareholders of record as of the close of business on April 6, 2018 |  |

[0001564590-18-002075:8k_2_02:27]
Third Quarter Fiscal 2018 Business Highlights

[0001564590-18-002075:8k_2_02:28]
New NetApp Product Updates and Offerings

[0001564590-18-002075:8k_2_02:29]
| • | New NetApp™ AltaVault™ software updates provide customers with faster ingest performance, multifactor authentication, increased security enhancements and Microsoft Azure Archive Blob Storage tier support. |

[0001564590-18-002075:8k_2_02:30]
| • | NetApp introduces SnapMirror™ for SolidFire™ Element™ OS, which supports disparate system data movement from Element OS systems to ONTAP™ 9.3 systems, allowing companies to remain agile while still protecting their data. |

[0001564590-18-002075:8k_2_02:31]
| • | NetApp Cloud Volumes for AWS enables both NFSv3 and NFSv4 with fully featured Snapshot™ copies and is available in cloud-only and hybrid cloud deployments, with integration into on-premises systems and seamless data migration and synchronization between on-premises and the cloud. |

[0001564590-18-002075:8k_2_02:32]
NetApp Enables Customers to Improve Their Business Performance

[0001564590-18-002075:8k_2_02:33]
| • | JFK Medical Center, part of the Hackensack Meridian Health Network, leverages NetApp technology to increase stability and reliability and achieve a higher performance level for its critical infrastructure. |

[0001564590-18-002075:8k_2_02:34]
| • | Safelight leverages NetApp to transform the delivery of its auto glass services, surpass competitors, and expand its customer base during one of the worst recorded hurricane seasons. |

[0001564590-18-002075:8k_2_02:35]
NetApp Strengthens Partnerships

[0001564590-18-002075:8k_2_02:36]
| • | NetApp strengthens its 20-year partnership with Fujitsu by introducing the NFLEX™ converged infrastructure, which combines Fujitsu’s server PRIMERGY CX compute platform and NetApp ONTAP. |

[0001564590-18-002075:8k_2_02:37]
| • | NetApp announces support for VMware Cloud on AWS to allow customers more flexibility when deploying ONTAP Cloud to deliver seamlessly integrated hybrid cloud architectures that extend on-premises vSphere environments to a VMware SDDC running on AWS elastic bare-metal infrastructure. |

[0001564590-18-002075:8k_2_02:38]
NetApp Strengthens Board and Leadership Team

[0001564590-18-002075:8k_2_02:39]
| • | NetApp strengthens its board of directors with two new members: |

[0001564590-18-002075:8k_2_02:40]
|  | - | Deborah Kerr, who brings insights into how customers buy, deploy, manage, and use IT to NetApp; and |

[0001564590-18-002075:8k_2_02:41]
|  | - | Scott Schenkel, CFO of eBay, who brings current C-level experience to NetApp’s board, with his understanding of the technology landscape and market forces, capital structure, and modern financial reporting |

[0001564590-18-002075:8k_2_02:42]
| • | NetApp appoints Brad Anderson as SVP and GM of the NetApp Cloud Infrastructure business unit to help customers build out their next-generation data centers. |

[0001564590-18-002075:8k_2_02:43]
Webcast and Conference Call Information

[0001564590-18-002075:8k_2_02:44]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:30 p.m. Pacific Time today.

[0001564590-18-002075:8k_2_02:45]
About NetApp

[0001564590-18-002075:8k_2_02:46]
NetApp is the data authority for hybrid cloud. We provide a full range of hybrid cloud data services that simplify management of applications and data across cloud and on-premises environments to accelerate digital transformation. Together with our partners, we empower global organizations to unleash the full potential of their data to expand customer touchpoints, foster greater innovation and optimize their operations. For more information, visit www.netapp.com. #DataDriven

[0001564590-18-002075:8k_2_02:47]
###

[0001564590-18-002075:8k_2_02:48]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-18-002075:8k_2_02:49]
Footnotes

[0001564590-18-002075:8k_2_02:50]
1Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale of properties, and (h) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-18-002075:8k_2_02:51]
2GAAP net loss per share is calculated using the basic number of shares and excludes common stock equivalents because the impact would be anti-dilutive.

[0001564590-18-002075:8k_2_02:52]
3GAAP net income per share is calculated using the diluted number of shares.

[0001564590-18-002075:8k_2_02:53]
4Non-GAAP net income per share is calculated using the diluted number of shares for all periods.

[0001564590-18-002075:8k_2_02:54]
NetApp Usage of Non-GAAP Financial Information

[0001564590-18-002075:8k_2_02:55]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-18-002075:8k_2_02:56]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-18-002075:8k_2_02:57]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-18-002075:8k_2_02:58]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-18-002075:8k_2_02:59]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-18-002075:8k_2_02:60]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based

[0001564590-18-002075:8k_2_02:61]
compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-18-002075:8k_2_02:62]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-18-002075:8k_2_02:63]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-18-002075:8k_2_02:64]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-18-002075:8k_2_02:65]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-18-002075:8k_2_02:66]
G. Gains/losses on the sale of properties. These are gains/losses from the sale of our properties. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-18-002075:8k_2_02:67]
H. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual properties from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-18-002075:8k_2_02:68]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or

[0001564590-18-002075:8k_2_02:69]
principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-18-002075:8k_2_02:70]
NETAPP, INC.

[0001564590-18-002075:8k_2_02:71]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-18-002075:8k_2_02:72]
(In millions)

[0001564590-18-002075:8k_2_02:73]
(Unaudited)

[0001564590-18-002075:8k_2_02:74]
|  |  | January 26, 2018 |  |  | April 28, 2017 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,619 |  |  | $ | 4,921 |  |
| Accounts receivable |  |  | 754 |  |  |  | 731 |  |
| Inventories |  |  | 98 |  |  |  | 163 |  |
| Other current assets |  |  | 295 |  |  |  | 383 |  |
| Total current assets |  |  | 6,766 |  |  |  | 6,198 |  |
| Property and equipment, net |  |  | 741 |  |  |  | 799 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,845 |  |  |  | 1,815 |  |
| Other non-current assets |  |  | 435 |  |  |  | 681 |  |
| Total assets |  | $ | 9,787 |  |  | $ | 9,493 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 458 |  |  | $ | 347 |  |
| Accrued expenses |  |  | 739 |  |  |  | 782 |  |
| Commercial paper notes |  |  | 632 |  |  |  | 500 |  |
| Current portion of long-term debt |  |  | — |  |  |  | 749 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,719 |  |  |  | 1,744 |  |
| Total current liabilities |  |  | 3,548 |  |  |  | 4,122 |  |
| Long-term debt |  |  | 1,540 |  |  |  | 744 |  |
| Other long-term liabilities |  |  | 973 |  |  |  | 249 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,550 |  |  |  | 1,598 |  |
| Total liabilities |  |  | 7,611 |  |  |  | 6,713 |  |
| Stockholders' equity |  |  | 2,176 |  |  |  | 2,780 |  |
| Total liabilities and stockholders' equity |  | $ | 9,787 |  |  | $ | 9,493 |  |

[0001564590-18-002075:8k_2_02:75]
NETAPP, INC.

[0001564590-18-002075:8k_2_02:76]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-18-002075:8k_2_02:77]
(In millions, except per share amounts)

[0001564590-18-002075:8k_2_02:78]
(Unaudited)

[0001564590-18-002075:8k_2_02:79]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 920 |  |  | $ | 784 |  |  | $ | 2,450 |  |  | $ | 2,154 |  |
| Software maintenance |  |  | 237 |  |  |  | 240 |  |  |  | 711 |  |  |  | 723 |  |
| Hardware maintenance and other services |  |  | 366 |  |  |  | 380 |  |  |  | 1,109 |  |  |  | 1,161 |  |
| Net revenues |  |  | 1,523 |  |  |  | 1,404 |  |  |  | 4,270 |  |  |  | 4,038 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 468 |  |  |  | 435 |  |  |  | 1,238 |  |  |  | 1,170 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | 7 |  |  |  | 19 |  |  |  | 22 |  |
| Cost of hardware maintenance and other services |  |  | 108 |  |  |  | 111 |  |  |  | 336 |  |  |  | 369 |  |
| Total cost of revenues |  |  | 582 |  |  |  | 553 |  |  |  | 1,593 |  |  |  | 1,561 |  |
| Gross profit |  |  | 941 |  |  |  | 851 |  |  |  | 2,677 |  |  |  | 2,477 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 423 |  |  |  | 381 |  |  |  | 1,268 |  |  |  | 1,228 |  |
| Research and development |  |  | 193 |  |  |  | 181 |  |  |  | 580 |  |  |  | 588 |  |
| General and administrative |  |  | 72 |  |  |  | 64 |  |  |  | 209 |  |  |  | 201 |  |
| Restructuring charges |  |  | — |  |  |  | 52 |  |  |  | — |  |  |  | 52 |  |
| Gain on sale of properties |  |  | (218 | ) |  |  | (10 | ) |  |  | (218 | ) |  |  | (10 | ) |
| Total operating expenses |  |  | 470 |  |  |  | 668 |  |  |  | 1,839 |  |  |  | 2,059 |  |
| Income from operations |  |  | 471 |  |  |  | 183 |  |  |  | 838 |  |  |  | 418 |  |
| Other income (expense), net |  |  | 14 |  |  |  | — |  |  |  | 25 |  |  |  | (1 | ) |
| Income before income taxes |  |  | 485 |  |  |  | 183 |  |  |  | 863 |  |  |  | 417 |  |
| Provision for income taxes |  |  | 991 |  |  |  | 37 |  |  |  | 1,058 |  |  |  | 98 |  |
| Net income (loss) |  | $ | (506 | ) |  | $ | 146 |  |  | $ | (195 | ) |  | $ | 319 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (1.89 | ) |  | $ | 0.53 |  |  | $ | (0.72 | ) |  | $ | 1.15 |  |
| Diluted |  | $ | (1.89 | ) |  | $ | 0.52 |  |  | $ | (0.72 | ) |  | $ | 1.13 |  |
| Shares used in net income (loss) per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 268 |  |  |  | 274 |  |  |  | 269 |  |  |  | 277 |  |
| Diluted |  |  | 268 |  |  |  | 281 |  |  |  | 269 |  |  |  | 282 |  |
| Cash dividends declared per share |  | $ | 0.20 |  |  | $ | 0.19 |  |  | $ | 0.60 |  |  | $ | 0.57 |  |

[0001564590-18-002075:8k_2_02:80]
NETAPP, INC.

[0001564590-18-002075:8k_2_02:81]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-18-002075:8k_2_02:82]
(In millions)

[0001564590-18-002075:8k_2_02:83]
(Unaudited)

[0001564590-18-002075:8k_2_02:84]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 27, 2017 |  |  | January 26, 2018 |  |  | January 27, 2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (506 | ) |  | $ | 146 |  |  | $ | (195 | ) |  | $ | 319 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 48 |  |  |  | 56 |  |  |  | 150 |  |  |  | 173 |  |
| Stock-based compensation |  |  | 38 |  |  |  | 46 |  |  |  | 125 |  |  |  | 149 |  |
| Deferred income taxes |  |  | 214 |  |  |  | 45 |  |  |  | 258 |  |  |  | 73 |  |
| Gain on sale of properties |  |  | (218 | ) |  |  | (10 | ) |  |  | (218 | ) |  |  | (10 | ) |
| Other items, net |  |  | (3 | ) |  |  | 7 |  |  |  | (8 | ) |  |  | (8 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (157 | ) |  |  | (56 | ) |  |  | (8 | ) |  |  | 208 |  |
| Inventories |  |  | 10 |  |  |  | (28 | ) |  |  | 65 |  |  |  | (27 | ) |
| Accounts payable |  |  | 81 |  |  |  | 26 |  |  |  | 115 |  |  |  | 13 |  |
| Accrued expenses |  |  | 126 |  |  |  | 17 |  |  |  | 58 |  |  |  | (121 | ) |
| Deferred revenue and financed unearned services revenue |  |  | 81 |  |  |  | 31 |  |  |  | (102 | ) |  |  | (148 | ) |
| Long-term taxes payable |  |  | 721 |  |  |  | (9 | ) |  |  | 723 |  |  |  | (16 | ) |
| Changes in other operating assets and liabilities, net |  |  | (15 | ) |  |  | (36 | ) |  |  | 21 |  |  |  | 16 |  |
| Net cash provided by operating activities |  |  | 420 |  |  |  | 235 |  |  |  | 984 |  |  |  | 621 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | (226 | ) |  |  | (188 | ) |  |  | (178 | ) |  |  | 2 |  |
| Purchases of property and equipment |  |  | (32 | ) |  |  | (45 | ) |  |  | (97 | ) |  |  | (137 | ) |
| Proceeds from sale of properties |  |  | 210 |  |  |  | — |  |  |  | 210 |  |  |  | — |  |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | — |  |  |  | (75 | ) |  |  | — |  |
| Other investing activities, net |  |  | (6 | ) |  |  | 3 |  |  |  | (1 | ) |  |  | 2 |  |
| Net cash used in investing activities |  |  | (54 | ) |  |  | (230 | ) |  |  | (141 | ) |  |  | (133 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 100 |  |  |  | 51 |  |  |  | 157 |  |  |  | 112 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (7 | ) |  |  | (6 | ) |  |  | (67 | ) |  |  | (42 | ) |
| Repurchase of common stock |  |  | (150 | ) |  |  | (284 | ) |  |  | (450 | ) |  |  | (576 | ) |
| Proceeds from (repayments of) commercial paper notes, net |  |  | (86 | ) |  |  | 392 |  |  |  | 132 |  |  |  | 392 |  |
| Issuance of long-term debt, net |  |  | — |  |  |  | — |  |  |  | 795 |  |  |  | — |  |
| Repayment of short-term loan |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (850 | ) |
| Repayment of long-term debt |  |  | (750 | ) |  |  | — |  |  |  | (750 | ) |  |  | — |  |
| Dividends paid |  |  | (53 | ) |  |  | (52 | ) |  |  | (161 | ) |  |  | (157 | ) |
| Other financing activities, net |  |  | (5 | ) |  |  | (4 | ) |  |  | (6 | ) |  |  | (7 | ) |
| Net cash provided by (used in) financing activities |  |  | (951 | ) |  |  | 97 |  |  |  | (350 | ) |  |  | (1,128 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 24 |  |  |  | (2 | ) |  |  | 37 |  |  |  | (15 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (561 | ) |  |  | 100 |  |  |  | 530 |  |  |  | (655 | ) |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 3,535 |  |  |  | 2,113 |  |  |  | 2,444 |  |  |  | 2,868 |  |
| End of period |  | $ | 2,974 |  |  | $ | 2,213 |  |  | $ | 2,974 |  |  | $ | 2,213 |  |

[0001564590-18-002075:8k_2_02:85]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q3 FY'18 |  |  | Q2 FY'18 |  |  | Q3 FY'17 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 920 |  |  | $ | 807 |  |  | $ | 784 |  |
| Strategic |  | $ | 647 |  |  | $ | 557 |  |  | $ | 512 |  |
| Mature |  | $ | 273 |  |  | $ | 250 |  |  | $ | 272 |  |
| Software Maintenance |  | $ | 237 |  |  | $ | 240 |  |  | $ | 240 |  |
| Hardware Maintenance and Other Services |  | $ | 366 |  |  | $ | 375 |  |  | $ | 380 |  |
| Hardware Maintenance Support Contracts |  | $ | 299 |  |  | $ | 306 |  |  | $ | 313 |  |
| Professional and Other Services |  | $ | 67 |  |  | $ | 69 |  |  | $ | 67 |  |
| Net Revenues |  | $ | 1,523 |  |  | $ | 1,422 |  |  | $ | 1,404 |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'18 Revenue |  |  | % of Q2 FY'18 Revenue |  |  | % of Q3 FY'17 Revenue |  |
| Americas |  |  | 54 | % |  |  | 56 | % |  |  | 55 | % |
| Americas Commercial |  |  | 44 | % |  |  | 40 | % |  |  | 44 | % |
| U.S. Public Sector |  |  | 10 | % |  |  | 16 | % |  |  | 10 | % |
| EMEA |  |  | 32 | % |  |  | 30 | % |  |  | 33 | % |
| Asia Pacific |  |  | 14 | % |  |  | 14 | % |  |  | 13 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'18 Revenue |  |  | % of Q2 FY'18 Revenue |  |  | % of Q3 FY'17 Revenue |  |
| Direct |  |  | 22 | % |  |  | 22 | % |  |  | 21 | % |
| Indirect |  |  | 78 | % |  |  | 78 | % |  |  | 79 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'18 |  |  | Q2 FY'18 |  |  | Q3 FY'17 |  |
| Non-GAAP Gross Margin |  |  | 62.6 | % |  |  | 64.3 | % |  |  | 61.5 | % |
| Product |  |  | 50.2 | % |  |  | 51.8 | % |  |  | 45.7 | % |
| Software Maintenance |  |  | 97.5 | % |  |  | 97.5 | % |  |  | 97.1 | % |
| Hardware Maintenance and Other Services |  |  | 71.3 | % |  |  | 69.9 | % |  |  | 71.6 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'18 |  |  | Q2 FY'18 |  |  | Q3 FY'17 |  |
| Non-GAAP Income from Operations |  | $ | 310 |  |  | $ | 272 |  |  | $ | 284 |  |
| % of Net Revenues |  |  | 20.4 | % |  |  | 19.1 | % |  |  | 20.2 | % |
| Non-GAAP Income before Income Taxes |  | $ | 324 |  |  | $ | 278 |  |  | $ | 284 |  |
| Non-GAAP Effective Tax Rate |  |  | 15.7 | % |  |  | 19.4 | % |  |  | 18.6 | % |

[0001564590-18-002075:8k_2_02:86]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'18 |  |  | Q2 FY'18 |  |  | Q3 FY'17 |  |
| Non-GAAP Net Income |  | $ | 273 |  |  | $ | 223 |  |  | $ | 231 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 276 |  |  |  | 275 |  |  |  | 281 |  |
| Non-GAAP Income per Share, Diluted |  | $ | 0.99 |  |  | $ | 0.81 |  |  | $ | 0.82 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'18 |  |  | Q2 FY'18 |  |  | Q3 FY'17 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,269 |  |  | $ | 3,167 |  |  | $ | 3,234 |  |
| DSO (days) |  |  | 45 |  |  |  | 37 |  |  |  | 39 |  |
| DIO (days) |  |  | 15 |  |  |  | 19 |  |  |  | 21 |  |
| DPO (days) |  |  | 72 |  |  |  | 66 |  |  |  | 42 |  |
| CCC (days) |  |  | (11 | ) |  |  | (10 | ) |  |  | 17 |  |
| Inventory Turns |  |  | 24 |  |  |  | 19 |  |  |  | 18 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'18 |  |  | Q2 FY'18 |  |  | Q3 FY'17 |  |
| Net Cash Provided by Operating Activities |  | $ | 420 |  |  | $ | 314 |  |  | $ | 235 |  |
| Purchases of Property and Equipment |  | $ | 32 |  |  | $ | 29 |  |  | $ | 45 |  |
| Free Cash Flow |  | $ | 388 |  |  | $ | 285 |  |  | $ | 190 |  |
| Free Cash Flow as a % of Net Revenues |  |  | 25.5 | % |  |  | 20.0 | % |  |  | 13.5 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001564590-18-002075:8k_2_02:87]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q3'FY17 |  |
| NET INCOME (LOSS) |  | $ | (506 | ) |  | $ | 175 |  |  | $ | 146 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 38 |  |  |  | 39 |  |  |  | 46 |  |
| Litigation settlements |  |  | 5 |  |  |  | — |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 52 |  |
| Gain on sale of properties |  |  | (218 | ) |  |  | — |  |  |  | (10 | ) |
| Income tax effect of non-GAAP adjustments |  |  | 84 |  |  |  | (5 | ) |  |  | (16 | ) |
| Tax reform |  |  | 856 |  |  |  | — |  |  |  | — |  |
| NON-GAAP NET INCOME |  | $ | 273 |  |  | $ | 223 |  |  | $ | 231 |  |
| COST OF REVENUES |  | $ | 582 |  |  | $ | 520 |  |  | $ | 553 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (9 | ) |  |  | (8 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (4 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 569 |  |  | $ | 508 |  |  | $ | 541 |  |
| COST OF PRODUCT REVENUES |  | $ | 468 |  |  | $ | 399 |  |  | $ | 435 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (9 | ) |  |  | (8 | ) |
| Stock-based compensation |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 458 |  |  | $ | 389 |  |  | $ | 426 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 108 |  |  | $ | 115 |  |  | $ | 111 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (2 | ) |  |  | (3 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 105 |  |  | $ | 113 |  |  | $ | 108 |  |
| GROSS PROFIT |  | $ | 941 |  |  | $ | 902 |  |  | $ | 851 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 10 |  |  |  | 9 |  |  |  | 8 |  |
| Stock-based compensation |  |  | 3 |  |  |  | 3 |  |  |  | 4 |  |
| NON-GAAP GROSS PROFIT |  | $ | 954 |  |  | $ | 914 |  |  | $ | 863 |  |

[0001564590-18-002075:8k_2_02:88]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q3'FY17 |  |
| SALES AND MARKETING EXPENSES |  | $ | 423 |  |  | $ | 420 |  |  | $ | 381 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (4 | ) |  |  | (5 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (16 | ) |  |  | (16 | ) |  |  | (20 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 403 |  |  | $ | 399 |  |  | $ | 356 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 193 |  |  | $ | 194 |  |  | $ | 181 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (11 | ) |  |  | (12 | ) |  |  | (14 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 182 |  |  | $ | 182 |  |  | $ | 167 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 72 |  |  | $ | 69 |  |  | $ | 64 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (8 | ) |  |  | (8 | ) |  |  | (8 | ) |
| Litigation settlements |  |  | (5 | ) |  |  | - |  |  |  | - |  |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 59 |  |  | $ | 61 |  |  | $ | 56 |  |
| RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | 52 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | (52 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| GAIN ON SALE OF PROPERTIES |  | $ | (218 | ) |  | $ | — |  |  | $ | (10 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale of properties |  |  | 218 |  |  |  | — |  |  |  | 10 |  |
| NON-GAAP GAIN ON SALE OF PROPERTIES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 470 |  |  | $ | 683 |  |  | $ | 668 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (4 | ) |  |  | (5 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (35 | ) |  |  | (36 | ) |  |  | (42 | ) |
| Litigation settlements |  |  | (5 | ) |  |  | — |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | (52 | ) |
| Gain on sale of properties |  |  | 218 |  |  |  | — |  |  |  | 10 |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 644 |  |  | $ | 642 |  |  | $ | 579 |  |

[0001564590-18-002075:8k_2_02:89]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q3'FY17 |  |
| INCOME FROM OPERATIONS |  | $ | 471 |  |  | $ | 219 |  |  | $ | 183 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 38 |  |  |  | 39 |  |  |  | 46 |  |
| Litigation settlements |  |  | 5 |  |  |  | — |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 52 |  |
| Gain on sale of properties |  |  | (218 | ) |  |  | — |  |  |  | (10 | ) |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 310 |  |  | $ | 272 |  |  | $ | 284 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 485 |  |  | $ | 225 |  |  | $ | 183 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 38 |  |  |  | 39 |  |  |  | 46 |  |
| Litigation settlements |  |  | 5 |  |  |  | — |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 52 |  |
| Gain on sale of properties |  |  | (218 | ) |  |  | — |  |  |  | (10 | ) |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 324 |  |  | $ | 278 |  |  | $ | 284 |  |
| PROVISION FOR INCOME TAXES |  | $ | 991 |  |  | $ | 50 |  |  | $ | 37 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | (84 | ) |  |  | 5 |  |  |  | 16 |  |
| Tax reform |  |  | (856 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 51 |  |  | $ | 55 |  |  | $ | 53 |  |
| NET INCOME (LOSS) PER SHARE |  | $ | (1.89 | ) |  | $ | 0.64 |  |  | $ | 0.52 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.05 |  |
| Stock-based compensation |  |  | 0.14 |  |  |  | 0.14 |  |  |  | 0.16 |  |
| Litigation settlements |  |  | 0.02 |  |  |  | — |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 0.19 |  |
| Gain on sale of properties |  |  | (0.81 | ) |  |  | — |  |  |  | (0.04 | ) |
| Income tax effect of non-GAAP adjustments |  |  | 0.31 |  |  |  | (0.02 | ) |  |  | (0.06 | ) |
| Tax reform |  |  | 3.19 |  |  |  | — |  |  |  | — |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.99 |  |  | $ | 0.81 |  |  | $ | 0.82 |  |
| In Q3'FY18, our GAAP net loss per share was calculated using basic shares of 268 million, as the impact of common stock equivalents would have been anti-dilutive. Additionally, each adjustment presented in the reconciliation was computed using basic shares. However, because we reported net income on a non-GAAP basis, non-GAAP net income per share was computed using diluted shares of 276 million. As a result of the difference in the number of shares, the summation of GAAP net loss per share and the adjustments does not equal non-GAAP net income per share. |  |

[0001564590-18-002075:8k_2_02:90]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q3'FY17 |  |
| Gross margin-GAAP |  |  | 61.8 | % |  |  | 63.4 | % |  |  | 60.6 | % |
| Cost of revenues adjustments |  |  | 0.9 | % |  |  | 0.8 | % |  |  | 0.9 | % |
| Gross margin-Non-GAAP |  |  | 62.6 | % |  |  | 64.3 | % |  |  | 61.5 | % |
| GAAP cost of revenues |  | $ | 582 |  |  | $ | 520 |  |  | $ | 553 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (9 | ) |  |  | (8 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (4 | ) |
| Non-GAAP cost of revenues |  | $ | 569 |  |  | $ | 508 |  |  | $ | 541 |  |
| Net revenues |  | $ | 1,523 |  |  | $ | 1,422 |  |  | $ | 1,404 |  |

[0001564590-18-002075:8k_2_02:91]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q3'FY17 |  |
| Product gross margin-GAAP |  |  | 49.1 | % |  |  | 50.6 | % |  |  | 44.5 | % |
| Cost of product revenues adjustments |  |  | 1.1 | % |  |  | 1.2 | % |  |  | 1.1 | % |
| Product gross margin-Non-GAAP |  |  | 50.2 | % |  |  | 51.8 | % |  |  | 45.7 | % |
| GAAP cost of product revenues |  | $ | 468 |  |  | $ | 399 |  |  | $ | 435 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (9 | ) |  |  | (8 | ) |
| Stock-based compensation |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 458 |  |  | $ | 389 |  |  | $ | 426 |  |
| Product revenues |  | $ | 920 |  |  | $ | 807 |  |  | $ | 784 |  |

[0001564590-18-002075:8k_2_02:92]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q3'FY17 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 70.5 | % |  |  | 69.3 | % |  |  | 70.8 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.8 | % |  |  | 0.5 | % |  |  | 0.8 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 71.3 | % |  |  | 69.9 | % |  |  | 71.6 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 108 |  |  | $ | 115 |  |  | $ | 111 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (2 | ) |  |  | (3 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 105 |  |  | $ | 113 |  |  | $ | 108 |  |
| Hardware maintenance and other services revenues |  | $ | 366 |  |  | $ | 375 |  |  | $ | 380 |  |

[0001564590-18-002075:8k_2_02:93]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q3'FY17 |  |
| GAAP effective tax rate |  |  | 204.3 | % |  |  | 22.2 | % |  |  | 20.2 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | (12.1 | )% |  |  | (2.8 | )% |  |  | (1.6 | )% |
| Tax reform |  |  | (176.5 | )% |  |  | — | % |  |  | — | % |
| Non-GAAP effective tax rate |  |  | 15.7 | % |  |  | 19.4 | % |  |  | 18.6 | % |

[0001564590-18-002075:8k_2_02:94]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q3'FY18 |  |  | Q2'FY18 |  |  | Q3'FY17 |  |
| Net cash provided by operating activities |  | $ | 420 |  |  | $ | 314 |  |  | $ | 235 |  |
| Purchases of property and equipment |  |  | (32 | ) |  |  | (29 | ) |  |  | (45 | ) |
| Free cash flow |  | $ | 388 |  |  | $ | 285 |  |  | $ | 190 |  |

[0001564590-18-002075:8k_2_02:95]
Some items may not add or recalculate due to rounding.

[0001564590-18-002075:8k_2_02:96]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| FOURTH QUARTER FISCAL 2018 |  |
|  |  | Fourth Quarter |  |
|  |  | Fiscal 2018 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $0.95 - $1.03 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Fourth Quarter Fiscal 2018: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.05 | ) |
| Stock-based compensation expense |  |  | (0.13 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.02 | ) |
| Total Adjustments |  |  | (0.20 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.75 - 0.83 |  |

[0001564590-18-002075:8k_2_02:97]
Press Contact:

[0001564590-18-002075:8k_2_02:98]
Madge Miller

[0001564590-18-002075:8k_2_02:99]
NetApp

[0001564590-18-002075:8k_2_02:100]
1 408 419 5263

[0001564590-18-002075:8k_2_02:101]
madge.miller@netapp.com

[0001564590-18-002075:8k_2_02:102]
Investor Contact:

[0001564590-18-002075:8k_2_02:103]
Kris Newton

[0001564590-18-002075:8k_2_02:104]
NetApp

[0001564590-18-002075:8k_2_02:105]
1 408 822 3312

[0001564590-18-002075:8k_2_02:106]
kris.newton@netapp.com
