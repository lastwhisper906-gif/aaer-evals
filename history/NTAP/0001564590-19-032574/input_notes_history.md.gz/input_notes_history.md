# NTAP note change history — 0001564590-19-003270 → 0001564590-19-032574


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-08-19):
[0001564590-19-032574:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 26, 2019, we had $392 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 26, 2019 and April 26, 2019, such liability amounted to $12 million and $16 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2019-02-19, similarity 0.9929):
[0001564590-19-003270:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 25, 2019, we had $501 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 25, 2019 and April 27, 2018, such liability amounted to $17 million and $14 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2019-08-19):
[0001564590-19-032574:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 26, 2019, we had $9 million in construction related obligations and $235 million in other purchase obligations.
  (was, 2019-02-19, similarity 0.9904):
[0001564590-19-003270:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 25, 2019, we had $4 million in construction related obligations and $220 million in other purchase obligations.

- changed (2019-08-19):
[0001564590-19-032574:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $14 million and $30 million of receivables during the three months ended July 26, 2019 and July 27, 2018, respectively.
  (was, 2019-02-19, similarity 0.9896):
[0001564590-19-003270:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $54 million and $62 million of receivables during the nine months ended January 25, 2019 and January 26, 2018, respectively.

- added (2019-08-19):
[0001564590-19-032574:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of July 26, 2019 and April 26, 2019, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- changed (2019-08-19):
[0001564590-19-032574:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 26, 2019, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.
  (was, 2019-02-19, similarity 0.9961):
[0001564590-19-003270:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 25, 2019, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- added (2019-08-19):
[0001564590-19-032574:note_history:6]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. We believe the complaint is without merit and intend to defend the case vigorously.

- changed (2019-08-19):
[0001564590-19-032574:note_history:7]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.
  (was, 2019-02-19, similarity 0.9966):
[0001564590-19-003270:note_history:7]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

- changed (2019-08-19):
[0001564590-19-032574:note_history:8]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of July 26, 2019 related to such matters.
  (was, 2019-02-19, similarity 0.9961):
[0001564590-19-003270:note_history:8]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of January 25, 2019 related to such matters.

- removed (2019-08-19):
[0001564590-19-003270:note_history:9]
Operating Leases

- removed (2019-08-19):
[0001564590-19-003270:note_history:10]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $164 million as of January 25, 2019.

- removed (2019-08-19):
[0001564590-19-003270:note_history:11]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of January 25, 2019 and April 27, 2018, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-08-19):
[0001564590-19-032574:note_history:12]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 26, 2019 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 26, 2019 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2019-02-19, similarity 0.9784):
[0001564590-19-003270:note_history:12]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 27, 2018 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 25, 2019 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- changed (2019-08-19):
[0001564590-19-032574:note_history:13]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.
  (was, 2019-02-19, similarity 0.9672):
[0001564590-19-003270:note_history:13]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; valuation of investment securities; income taxes and fair value measurements. Actual results could differ materially from those estimates.

- added (2019-08-19):
[0001564590-19-032574:note_history:14]
In February 2016, the FASB issued an accounting standards update on financial reporting for leasing arrangements, including requiring lessees to recognize an operating lease with a term greater than one year on their balance sheets as a right-of-use (ROU) asset and corresponding lease liability, measured at the present value of the lease payments. In the first quarter of fiscal 2020, we adopted this new standard using the modified retrospective approach, electing the optional transition approach of not adjusting our comparative period financial statements for the impacts of adoption. We also elected the package of practical expedients that did not require us to reassess existing leases under the new guidance, and the practical expedient to not separate lease and non-lease components for all leases. Adoption of the new standard on April 27, 2019 resulted in the recognition of approximately $149 million of operating lease ROU assets, net of deferred rent and lease restructuring liabilities, $158 million of lease liabilities, and a cumulative-effect adjustment to retained earnings of $6 million on our condensed consolidated balance sheets. Adoption of the standard did not have a material impact on our condensed consolidated statements of operations or condensed consolidated statements of cash flows. Additional information is presented below and in Note 10 – Leases.

- added (2019-08-19):
[0001564590-19-032574:note_history:15]
Leases − We determine if an arrangement is or contains a lease at inception, and we classify leases as operating or finance leases at commencement. In our condensed consolidated balance sheets, operating lease ROU assets are included in other non-current assets, while finance lease ROU assets are included in property and equipment, net. Lease liabilities for both types of leases are included in accrued expenses and other long-term liabilities. ROU assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over that term.

- added (2019-08-19):
[0001564590-19-032574:note_history:16]
Operating and finance lease ROU assets and liabilities are recognized at commencement based on the present value of lease payments over the lease term. ROU assets also include any lease payments made prior to lease commencement and exclude lease incentives. The lease term is the noncancelable period of the lease and includes options to extend or terminate the lease when it is reasonably certain that an option will be exercised. As the rate implicit in our leases is typically not readily determinable, in computing the present value of lease payments we generally use our incremental borrowing rate based on information available at the commencement date. Variable lease payments not dependent on an index or rate are expensed as incurred and not included within the calculation of ROU assets and lease liabilities. Lease expense for lease payments is recognized on a straight-line basis over the lease term.

- added (2019-08-19):
[0001564590-19-032574:note_history:17]
We do not separate non-lease components from lease components for any class of leases, and we do not recognize ROU assets and lease liabilities for leases with a lease term of twelve months or less.

- changed (2019-08-19):
[0001564590-19-032574:note_history:18]
There have been no other significant changes in our significant accounting policies as of and for the three months ended July 26, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 26, 2019.
  (was, 2019-02-19, similarity 0.9731):
[0001564590-19-003270:note_history:18]
There have been no other significant changes in our significant accounting policies as of and for the nine months ended January 25, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 27, 2018.

- removed (2019-08-19):
[0001564590-19-003270:note_history:19]
In May 2014, the Financial Accounting Standards Board (FASB) issued a new standard, Revenue from Contracts with Customers (ASC 606), which establishes a comprehensive new revenue recognition model designed to depict the transfer of goods or services to a customer in an amount that reflects the consideration the entity expects to receive in exchange for those goods or services. In the first quarter of fiscal 2019, we adopted this new standard using the full retrospective method of adoption. Accordingly, our prior period condensed consolidated financial statements and information, as presented herein, have been restated to conform to the new rules. Refer to Note 5 – Revenue for a summary of the impacts of adopting this standard, and a discussion of our updated policies related to revenue recognition.

- removed (2019-08-19):
[0001564590-19-003270:note_history:20]
In October 2016, the FASB issued an accounting standards update (ASU) which eliminates the deferred tax effects of intra-entity asset transfers other than inventory. As a result, tax expense from the sale of an asset in the seller’s tax jurisdiction is recognized when the transfer occurs, even though the pre-tax effects of that transaction are eliminated in consolidation. In the first quarter of fiscal 2019, we adopted this ASU using a modified retrospective transition approach and recorded a cumulative-effect adjustment to decrease retained earnings by $51 million, with a corresponding reduction of prepaid taxes, which were classified as other non-current assets on our condensed consolidated balance sheets.

- removed (2019-08-19):
[0001564590-19-003270:note_history:21]
In November 2016, the FASB issued an ASU that requires a statement of cash flows to explain the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. In the first quarter of fiscal 2019, we adopted this ASU using a retrospective transition method. Accordingly, our condensed consolidated statement of cash flows for the nine months ended January 26, 2018, as presented herein, has been restated to comply with the new requirements. Refer to Note 4 – Supplemental Financial Information for a detail of the components of our cash, cash equivalents and restricted cash balances.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-19):
[0001564590-19-032574:note_history:22]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |  |  | 2.32 | % |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (5 | ) |  |  |  |  |  |  | (6 | ) |  |  |  |  |
| Total senior notes |  |  | 1,545 |  |  |  |  |  |  |  | 1,544 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (400 | ) |  |  |  |  |  |  | (400 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,145 |  |  |  |  |  |  | $ | 1,144 |  |  |  |  |  |
  (was, 2019-02-19, similarity 0.9904):
[0001564590-19-003270:note_history:22]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |  |  | 2.32 | % |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total senior notes |  |  | 1,543 |  |  |  |  |  |  |  | 1,541 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (399 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 1,144 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |

- changed (2019-08-19):
[0001564590-19-032574:note_history:23]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 26, 2019, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2019-02-19, similarity 0.9946):
[0001564590-19-003270:note_history:23]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 25, 2019, we were in compliance with all covenants associated with the Senior Notes.

- changed (2019-08-19):
[0001564590-19-032574:note_history:24]
As of July 26, 2019, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2019-02-19, similarity 0.973):
[0001564590-19-003270:note_history:24]
As of January 25, 2019, our aggregate future principal debt maturities are as follows (in millions):

- changed (2019-08-19):
[0001564590-19-032574:note_history:25]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of July 26, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $30 million, a weighted-average interest rate of 2.56% and a maturity of 29 days. As of April 26, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $249 million, a weighted-average interest rate of 2.73% and maturities ranging from 27 days to 38 days.
  (was, 2019-02-19, similarity 0.9763):
[0001564590-19-003270:note_history:25]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of January 25, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $164 million, a weighted-average interest rate of 2.87% and maturities ranging from 27 days to 36 days. As of April 27, 2018, we had commercial paper notes outstanding with an aggregate principal amount of $385 million, a weighted-average interest rate of 2.29% and maturities ranging from 19 days to 32 days.

- changed (2019-08-19):
[0001564590-19-032574:note_history:26]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its
  (was, 2019-02-19, similarity 0.8337):
[0001564590-19-003270:note_history:26]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of January 25, 2019 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

- added (2019-08-19):
[0001564590-19-032574:note_history:27]
maturity date for two additional one-year periods, both subject to certain conditions. As of July 26, 2019 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-19):
[0001564590-19-032574:note_history:28]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |  |  | 2.32 | % |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (5 | ) |  |  |  |  |  |  | (6 | ) |  |  |  |  |
| Total senior notes |  |  | 1,545 |  |  |  |  |  |  |  | 1,544 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (400 | ) |  |  |  |  |  |  | (400 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,145 |  |  |  |  |  |  | $ | 1,144 |  |  |  |  |  |
  (was, 2019-02-19, similarity 0.9904):
[0001564590-19-003270:note_history:28]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |  |  | 2.32 | % |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Total senior notes |  |  | 1,543 |  |  |  |  |  |  |  | 1,541 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (399 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 1,144 |  |  |  |  |  |  | $ | 1,541 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-19):
[0001564590-19-032574:note_history:29]
As of July 26, 2019, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2019-02-19, similarity 0.973):
[0001564590-19-003270:note_history:29]
As of January 25, 2019, our aggregate future principal debt maturities are as follows (in millions):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-08-19):
[0001564590-19-032574:note_history:30]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Product revenues |  | $ | 644 |  |  | $ | 875 |  |
| Strategic |  | 337 |  |  | 475 |  |
| Mature |  | 307 |  |  | 400 |  |
| Software maintenance revenues |  | 250 |  |  | 229 |  |
| Hardware maintenance and other services revenues |  | 342 |  |  | 370 |  |
| Hardware maintenance support contracts |  | 284 |  |  | 303 |  |
| Professional and other services |  | 58 |  |  | 67 |  |
| Net revenues |  | $ | 1,236 |  |  | $ | 1,474 |  |
  (was, 2019-02-19, similarity 0.7822):
[0001564590-19-003270:note_history:30]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Product revenues |  | $ | 967 |  |  | $ | 952 |  |  | $ | 2,755 |  |  | $ | 2,498 |  |
| Strategic |  | 674 |  |  | 657 |  |  |  | 1,935 |  |  |  | 1,721 |  |
| Mature |  | 293 |  |  | 295 |  |  |  | 820 |  |  |  | 777 |  |
| Software maintenance revenues |  | 239 |  |  | 221 |  |  |  | 704 |  |  | 668 |  |
| Hardware maintenance and other services revenues |  | 357 |  |  | 366 |  |  |  | 1,095 |  |  |  | 1,109 |  |
| Hardware maintenance support contracts |  | 292 |  |  | 300 |  |  |  | 898 |  |  |  | 904 |  |
| Professional and other services |  | 65 |  |  | 66 |  |  |  | 197 |  |  |  | 205 |  |
| Net revenues |  | $ | 1,563 |  |  | $ | 1,539 |  |  | $ | 4,554 |  |  | $ | 4,275 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2019-08-19):
[0001564590-19-003270:note_history:31]
Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-08-19):
[0001564590-19-032574:note_history:32]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. As our product portfolio evolves, market dynamics change, and management continues to assess of our largest growth opportunities, we periodically change how we group certain products. Beginning in fiscal 2020, Strategic includes All-flash FAS (AFF) products, including all related add-on hardware and operating system (OS) software, private cloud solutions (including SolidFire, converged and hyper-converged infrastructure products, StorageGrid), enterprise software license agreements (ELAs) and other optional add-on software products. Mature now includes Hybrid FAS products, including all related add-on hardware and OS software, original equipment manufacturers (OEM) products, and branded E-Series. Prior to this grouping change, Hybrid FAS products and branded E-Series were included in Strategic, while all add-on hardware and OS software were included in Mature. For comparability, Strategic and Mature revenues presented for the prior year period have been recast based on the revised groupings.

- added (2019-08-19):
[0001564590-19-032574:note_history:33]
In addition to the sale of our products and solutions, we provide a variety of services to our customers, including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training.

- changed (2019-08-19):
[0001564590-19-032574:note_history:34]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Product revenues |  | $ | 644 |  |  | $ | 875 |  |
| Strategic |  | 337 |  |  | 475 |  |
| Mature |  | 307 |  |  | 400 |  |
| Software maintenance revenues |  | 250 |  |  | 229 |  |
| Hardware maintenance and other services revenues |  | 342 |  |  | 370 |  |
| Hardware maintenance support contracts |  | 284 |  |  | 303 |  |
| Professional and other services |  | 58 |  |  | 67 |  |
| Net revenues |  | $ | 1,236 |  |  | $ | 1,474 |  |
  (was, 2019-02-19, similarity 0.7822):
[0001564590-19-003270:note_history:34]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Product revenues |  | $ | 967 |  |  | $ | 952 |  |  | $ | 2,755 |  |  | $ | 2,498 |  |
| Strategic |  | 674 |  |  | 657 |  |  |  | 1,935 |  |  |  | 1,721 |  |
| Mature |  | 293 |  |  | 295 |  |  |  | 820 |  |  |  | 777 |  |
| Software maintenance revenues |  | 239 |  |  | 221 |  |  |  | 704 |  |  | 668 |  |
| Hardware maintenance and other services revenues |  | 357 |  |  | 366 |  |  |  | 1,095 |  |  |  | 1,109 |  |
| Hardware maintenance support contracts |  | 292 |  |  | 300 |  |  |  | 898 |  |  |  | 904 |  |
| Professional and other services |  | 65 |  |  | 66 |  |  |  | 197 |  |  |  | 205 |  |
| Net revenues |  | $ | 1,563 |  |  | $ | 1,539 |  |  | $ | 4,554 |  |  | $ | 4,275 |  |

- changed (2019-08-19):
[0001564590-19-032574:note_history:35]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Deferred product revenue |  | $ | 74 |  |  | $ | 84 |  |
| Deferred services revenue |  |  | 3,361 |  |  |  | 3,502 |  |
| Financed unearned services revenue |  |  | 75 |  |  |  | 82 |  |
| Total |  | $ | 3,510 |  |  | $ | 3,668 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,764 |  |  | $ | 1,825 |  |
| Long-term |  |  | 1,746 |  |  |  | 1,843 |  |
| Total |  | $ | 3,510 |  |  | $ | 3,668 |  |
  (was, 2019-02-19, similarity 0.9906):
[0001564590-19-003270:note_history:35]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Deferred product revenue |  | $ | 80 |  |  | $ | 107 |  |
| Deferred services revenue |  |  | 3,195 |  |  |  | 3,134 |  |
| Financed unearned services revenue |  |  | 82 |  |  |  | 122 |  |
| Total |  | $ | 3,357 |  |  | $ | 3,363 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,641 |  |  | $ | 1,712 |  |
| Long-term |  |  | 1,716 |  |  |  | 1,651 |  |
| Total |  | $ | 3,357 |  |  | $ | 3,363 |  |

- added (2019-08-19):
[0001564590-19-032574:note_history:36]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Balance at beginning of period |  | $ | 3,668 |  |  | $ | 3,363 |  |
| Additions |  |  | 447 |  |  |  | 511 |  |
| Revenue recognized during the period |  |  | (605 | ) |  |  | (614 | ) |
| Balance at end of period |  | $ | 3,510 |  |  | $ | 3,260 |  |

- changed (2019-08-19):
[0001564590-19-032574:note_history:37]
During the three months ended July 26, 2019 and July 27, 2018, we recognized $552 million and $561 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.
  (was, 2019-02-19, similarity 0.9565):
[0001564590-19-003270:note_history:37]
During the nine months ended January 25, 2019 and January 26, 2018, we recognized $1,410 million and $1,466 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

- changed (2019-08-19):
[0001564590-19-032574:note_history:38]
As of July 26, 2019, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,510 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 25% in the next 13 to 24 months, and the remainder thereafter.
  (was, 2019-02-19, similarity 0.9953):
[0001564590-19-003270:note_history:38]
As of January 25, 2019, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,357 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 49% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 26% in the next 13 to 24 months, and the remainder thereafter.

- added (2019-08-19):
[0001564590-19-032574:note_history:39]
The following tables summarize the activity related to deferred commissions and their balances as reported in our condensed consolidated balance sheets (in millions):

- added (2019-08-19):
[0001564590-19-032574:note_history:40]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Balance at beginning of period |  | $ | 172 |  |  | $ | 137 |  |
| Additions |  |  | 16 |  |  |  | 19 |  |
| Expense recognized during the period |  |  | (25 | ) |  |  | (21 | ) |
| Balance at end of period |  | $ | 163 |  |  | $ | 135 |  |

- changed (2019-08-19):
[0001564590-19-032574:note_history:41]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Other current assets |  | $ | 71 |  |  | $ | 75 |  |
| Other non-current assets |  |  | 92 |  |  |  | 97 |  |
| Total deferred commissions |  | $ | 163 |  |  | $ | 172 |  |
  (was, 2019-02-19, similarity 0.9867):
[0001564590-19-003270:note_history:41]
|  |  | January 25, 2019 |  |  | April 27, 2018 |  |
| Other current assets |  | $ | 64 |  |  | $ | 66 |  |
| Other non-current assets |  |  | 75 |  |  |  | 71 |  |
| Total deferred commissions |  | $ | 139 |  |  | $ | 137 |  |

- removed (2019-08-19):
[0001564590-19-003270:note_history:42]
Effective our first quarter of fiscal 2019, we adopted ASC 606 using the full retrospective method and have restated each prior reporting period presented to conform to the new rules. The most significant impact of the new standard relates to our accounting for arrangements containing software. For our enterprise software license agreements (ELAs), we now recognize the license fee component of such arrangements up front. Under the prior rules, the software license fee was recognized over the term of the enterprise license based on our inability to establish vendor specific objective evidence of fair value for the undelivered software support element of these arrangements. In addition, for other software arrangements, revenue deferred for the undelivered elements that was previously allocated based on the residual method is now allocated based on relative fair value, which generally results in more software arrangement revenue being recognized earlier. The new standard also impacts our estimation of variable consideration for certain arrangements with contract terms such as rights of return, potential penalties and acceptance clauses.

- removed (2019-08-19):
[0001564590-19-003270:note_history:43]
The following table presents the impacts of adoption of ASC 606 to select line items of our condensed consolidated balance sheet as of the end of fiscal 2018:

- removed (2019-08-19):
[0001564590-19-003270:note_history:44]
|  |  | As of April 27, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption |  | As Adjusted |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 1,009 |  |  | $ | 38 |  |  | (1 | ) | $ | 1,047 |  |
| Inventories |  | $ | 126 |  |  | $ | (4 | ) |  |  |  | $ | 122 |  |
| Other current assets |  | $ | 330 |  |  | $ | 62 |  |  | (2 | ) | $ | 392 |  |
| Other non-current assets |  | $ | 420 |  |  | $ | 30 |  |  | (2 | ) | $ | 450 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Short-term deferred revenue and financed unearned services revenue |  | $ | 1,804 |  |  | $ | (92 | ) |  | (3 | ) | $ | 1,712 |  |
| Other long-term liabilities |  | $ | 961 |  |  | $ | 31 |  |  | (4 | ) | $ | 992 |  |
| Long-term deferred revenue and financed unearned services revenue |  | $ | 1,673 |  |  | $ | (22 | ) |  | (3 | ) | $ | 1,651 |  |
| Accumulated deficit |  | $ | (218 | ) |  | $ | 209 |  |  | (5 | ) | $ | (9 | ) |

- removed (2019-08-19):
[0001564590-19-003270:note_history:45]
|  | (1) | Netting of accounts receivable and deferred revenue balances for certain customer arrangements has been updated to reflect the impact of adoption |

- removed (2019-08-19):
[0001564590-19-003270:note_history:46]
|  | (2) | Reflects capitalization of commissions and reduction of long-term deferred tax assets |

- removed (2019-08-19):
[0001564590-19-003270:note_history:47]
|  | (3) | Reflects cumulative change in revenue and the impact of adoption to the netting of accounts receivable and deferred revenue balances for certain customer arrangements |

- removed (2019-08-19):
[0001564590-19-003270:note_history:48]
|  | (4) | Reflects increase in long-term deferred tax liabilities |

- removed (2019-08-19):
[0001564590-19-003270:note_history:49]
|  | (5) | Reflects cumulative impact to net income (loss) |

- removed (2019-08-19):
[0001564590-19-003270:note_history:50]
The following table presents the impacts of adoption of ASC 606 to our statement of operations for the third quarter and first nine months of fiscal 2018:

- removed (2019-08-19):
[0001564590-19-003270:note_history:51]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2018 |  |  | January 26, 2018 |  |
|  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |  | As Previously Reported |  |  | Impact of ASC 606 Adoption | As Adjusted |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 920 |  |  | $ | 32 |  |  | $ | 952 |  |  | $ | 2,450 |  |  | $ | 48 |  |  | $ | 2,498 |  |
| Software maintenance |  |  | 237 |  |  |  | (16 | ) |  |  | 221 |  |  |  | 711 |  |  |  | (43 | ) |  |  | 668 |  |
| Hardware maintenance and other services |  |  | 366 |  |  |  | — |  |  |  | 366 |  |  |  | 1,109 |  |  |  | — |  |  |  | 1,109 |  |
| Net revenues |  |  | 1,523 |  |  |  | 16 |  |  |  | 1,539 |  |  |  | 4,270 |  |  |  | 5 |  |  |  | 4,275 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 468 |  |  |  | 1 |  |  |  | 469 |  |  |  | 1,238 |  |  |  | 4 |  |  |  | 1,242 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | — |  |  |  | 6 |  |  |  | 19 |  |  |  | — |  |  |  | 19 |  |
| Cost of hardware maintenance and other services |  |  | 108 |  |  |  | — |  |  |  | 108 |  |  |  | 336 |  |  |  | (2 | ) |  |  | 334 |  |
| Total cost of revenues |  |  | 582 |  |  |  | 1 |  |  |  | 583 |  |  |  | 1,593 |  |  |  | 2 |  |  |  | 1,595 |  |
| Gross profit |  |  | 941 |  |  |  | 15 |  |  |  | 956 |  |  |  | 2,677 |  |  |  | 3 |  |  |  | 2,680 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 423 |  |  |  | (4 | ) |  |  | 419 |  |  |  | 1,268 |  |  |  | (5 | ) |  |  | 1,263 |  |
| Research and development |  |  | 193 |  |  |  | — |  |  |  | 193 |  |  |  | 580 |  |  |  | — |  |  |  | 580 |  |
| General and administrative |  |  | 72 |  |  |  | — |  |  |  | 72 |  |  |  | 209 |  |  |  | — |  |  |  | 209 |  |
| Gain on sale of properties |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |  |  | (218 | ) |  |  | — |  |  |  | (218 | ) |
| Total operating expenses |  |  | 470 |  |  |  | (4 | ) |  |  | 466 |  |  |  | 1,839 |  |  |  | (5 | ) |  |  | 1,834 |  |
| Income from operations |  |  | 471 |  |  |  | 19 |  |  |  | 490 |  |  |  | 838 |  |  |  | 8 |  |  |  | 846 |  |
| Other income, net |  |  | 14 |  |  |  | — |  |  |  | 14 |  |  |  | 25 |  |  |  | — |  |  |  | 25 |  |
| Income before income taxes |  |  | 485 |  |  |  | 19 |  |  |  | 504 |  |  |  | 863 |  |  |  | 8 |  |  |  | 871 |  |
| Provision for income taxes |  |  | 991 |  |  |  | (8 | ) |  |  | 983 |  |  |  | 1,058 |  |  |  | (13 | ) |  |  | 1,045 |  |
| Net loss |  | $ | (506 | ) |  | $ | 27 |  |  | $ | (479 | ) |  | $ | (195 | ) |  | $ | 21 |  |  | $ | (174 | ) |
| Net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (1.89 | ) |  | $ | 0.10 |  |  | $ | (1.79 | ) |  | $ | (0.72 | ) |  | $ | 0.07 |  |  | $ | (0.65 | ) |
| Diluted |  | $ | (1.89 | ) |  | $ | 0.10 |  |  | $ | (1.79 | ) |  | $ | (0.72 | ) |  | $ | 0.07 |  |  | $ | (0.65 | ) |
| Shares used in net loss per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 268 |  |  |  | 268 |  |  |  | 268 |  |  |  | 269 |  |  |  | 269 |  |  |  | 269 |  |
| Diluted |  |  | 268 |  |  |  | 268 |  |  |  | 268 |  |  |  | 269 |  |  |  | 269 |  |  |  | 269 |  |

- removed (2019-08-19):
[0001564590-19-003270:note_history:52]
The adoption of ASC 606 had no impact to cash provided by or used in operating, investing or financing activities as presented on our condensed consolidated statement of cash flows.

- removed (2019-08-19):
[0001564590-19-003270:note_history:53]
The core principle of ASC 606 is to recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration the entity expects to be entitled in exchange for those goods or services. This principle is achieved through applying the following five-step approach.

- removed (2019-08-19):
[0001564590-19-003270:note_history:54]
|  | • | Identification of the contract, or contracts, with a customer — A contract with a customer exists when (i) we enter into an enforceable contract with a customer that (ii) defines each party’s rights regarding the goods or services to be transferred and (iii) identifies the payment terms related to these goods or services. Additionally, (iv) the contract has commercial substance and, (v) we determine that collection of substantially all consideration for goods or services that are transferred is probable based on the customer’s intent and ability to pay the promised consideration. We apply judgment in determining the customer’s ability and intention to pay, which is based on a variety of factors including the customer’s historical payment experience or, in the case of a new customer, published credit and financial information pertaining to the customer. We also combine two or more contracts entered into at or near the same time with the same customer as a single contract if the contracts are negotiated as one package with a single commercial objective, the amount of consideration to be paid on one contract depends on the price or performance of the other contract or if the goods and services promised in each of the contracts are a single performance obligation. |

- removed (2019-08-19):
[0001564590-19-003270:note_history:55]
|  | • | Identification of the performance obligations in the contract — Performance obligations promised in a contract are identified based on the goods or services (or a bundle of goods and services) that will be transferred to the customer that are distinct. A good or service is distinct if it is capable of being distinct, where the customer can benefit from the goods or service either on its own or together with other resources that are readily available from third parties or from us, and is distinct in the context of the contract, meaning the transfer of the goods or services is separately identifiable from other promises in the contract. To the extent a contract includes multiple promised goods or services, we apply judgment to determine whether promised goods or services are capable of being distinct and distinct in the context of the contract. If these criteria are not met, we combine the goods and services until we have a distinct performance obligation. |

- removed (2019-08-19):
[0001564590-19-003270:note_history:56]
|  | • | Determination of the transaction price — The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer. Consideration promised may include fixed amounts, variable amounts or both. We use judgment in determining variable consideration, particularly if consideration is contingent on the occurrence or nonoccurrence of a future event. We use the expected value, primarily relying on our history, to estimate variable consideration. We may also use, in certain situations, the most likely amount as the basis of our estimate. In either case, we consider variable consideration only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recognized will not occur. Reassessments of our variable consideration may occur as historical information changes. Transaction prices should also be adjusted for the effects of time value of money if the timing of payments provides either the customer or ourselves a significant benefit of financing. |

- removed (2019-08-19):
[0001564590-19-003270:note_history:57]
|  | • | Allocation of the transaction price to the performance obligations in the contract — If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation based on a relative standalone selling price basis. We determine standalone selling price based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price taking into account available information such as market conditions and internally approved pricing guidelines related to the performance obligations. Variable consideration is also allocated to the performance obligations. If the terms of variable consideration relate to one performance obligation, it is entirely allocated to that obligation. Otherwise, it is allocated to all the performance obligations in the contract. |

- removed (2019-08-19):
[0001564590-19-003270:note_history:58]
|  | • | Recognition of revenue when, or as, we satisfy a performance obligation — We satisfy performance obligations either over time or at a point in time. We typically recognize revenue at a point in time for promises to transfer goods to a customer. Services are typically transferred over time based on an appropriate method for measuring our progress toward completion of that performance obligation. Our stand-ready services, including both hardware and software maintenance support, are transferred ratably over the period of the contract. For other services such as our fixed professional services contract, we use an input method to determine the percentage of completion. That is, we estimate the effort to date versus the expected effort required over the life of the contract. |

- removed (2019-08-19):
[0001564590-19-003270:note_history:59]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we have historically grouped our products by “Strategic” and “Mature” solutions. Strategic solutions include Clustered ONTAP, branded E-Series, SolidFire, converged and hyper-converged infrastructure, ELAs and other optional add-on software products. Mature solutions include 7-mode ONTAP, add-on hardware and related operating system (OS) software and original equipment manufacturers (OEM) products. Both our Mature and Strategic product lines include a mix of disk, hybrid and all flash storage media. Additionally, we provide a variety of services including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training.

- removed (2019-08-19):
[0001564590-19-003270:note_history:60]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Balance at beginning of period |  | $ | 3,363 |  |  | $ | 3,213 |  |
| Additions |  |  | 1,820 |  |  |  | 1,730 |  |
| Revenue recognized during the period |  |  | (1,826 | ) |  |  | (1,800 | ) |
| Balance at end of period |  | $ | 3,357 |  |  | $ | 3,143 |  |

- removed (2019-08-19):
[0001564590-19-003270:note_history:61]
As a result of our adoption of ASC 606 in the first quarter of fiscal 2019, we capitalize sales commissions that are incremental direct costs of obtaining customer contracts for which revenue is not immediately recognized and classify them as current or non-current based on the terms of the related contracts. Capitalized commissions are amortized based on the transfer of goods or services to which they relate, typically over one to three years, and are also periodically reviewed for impairment. Amortization expense is recorded to sales and marketing expense in our condensed consolidated statements of operations. The following tables summarize the activity related to deferred commissions and their balances as reported in our condensed consolidated balance sheets (in millions):

- removed (2019-08-19):
[0001564590-19-003270:note_history:62]
|  |  | Nine Months Ended |  |
|  |  | January 25, 2019 |  |  | January 26, 2018 |  |
| Balance at beginning of period |  | $ | 137 |  |  | $ | 113 |  |
| Additions |  |  | 62 |  |  |  | 56 |  |
| Expense recognized during the period |  |  | (60 | ) |  |  | (49 | ) |
| Balance at end of period |  | $ | 139 |  |  | $ | 120 |  |
