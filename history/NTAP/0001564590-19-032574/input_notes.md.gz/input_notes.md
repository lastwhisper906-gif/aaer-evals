# NTAP notes — 0001564590-19-032574


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-19-032574:notes:1]
[same as prior period, unchanged from 0001564590-19-003270:notes:1]

[0001564590-19-032574:notes:2]
[same as prior period, unchanged from 0001564590-19-003270:notes:2]

[0001564590-19-032574:notes:3]
[same as prior period, unchanged from 0001564590-19-003270:notes:3]

[0001564590-19-032574:notes:4]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal years 2020 and 2019, ending on April 24, 2020, and April 26, 2019, respectively, are each 52-week years, with 13 weeks in each of their quarters.

[0001564590-19-032574:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 26, 2019 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 26, 2019 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-19-032574:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-19-032574:notes:7]
[same as prior period, unchanged from 0001564590-19-003270:notes:7]

[0001564590-19-032574:notes:8]
In February 2016, the FASB issued an accounting standards update on financial reporting for leasing arrangements, including requiring lessees to recognize an operating lease with a term greater than one year on their balance sheets as a right-of-use (ROU) asset and corresponding lease liability, measured at the present value of the lease payments. In the first quarter of fiscal 2020, we adopted this new standard using the modified retrospective approach, electing the optional transition approach of not adjusting our comparative period financial statements for the impacts of adoption. We also elected the package of practical expedients that did not require us to reassess existing leases under the new guidance, and the practical expedient to not separate lease and non-lease components for all leases. Adoption of the new standard on April 27, 2019 resulted in the recognition of approximately $149 million of operating lease ROU assets, net of deferred rent and lease restructuring liabilities, $158 million of lease liabilities, and a cumulative-effect adjustment to retained earnings of $6 million on our condensed consolidated balance sheets. Adoption of the standard did not have a material impact on our condensed consolidated statements of operations or condensed consolidated statements of cash flows. Additional information is presented below and in Note 10 – Leases.

[0001564590-19-032574:notes:9]
Leases − We determine if an arrangement is or contains a lease at inception, and we classify leases as operating or finance leases at commencement. In our condensed consolidated balance sheets, operating lease ROU assets are included in other non-current assets, while finance lease ROU assets are included in property and equipment, net. Lease liabilities for both types of leases are included in accrued expenses and other long-term liabilities. ROU assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over that term.

[0001564590-19-032574:notes:10]
Operating and finance lease ROU assets and liabilities are recognized at commencement based on the present value of lease payments over the lease term. ROU assets also include any lease payments made prior to lease commencement and exclude lease incentives. The lease term is the noncancelable period of the lease and includes options to extend or terminate the lease when it is reasonably certain that an option will be exercised. As the rate implicit in our leases is typically not readily determinable, in computing the present value of lease payments we generally use our incremental borrowing rate based on information available at the commencement date. Variable lease payments not dependent on an index or rate are expensed as incurred and not included within the calculation of ROU assets and lease liabilities. Lease expense for lease payments is recognized on a straight-line basis over the lease term.

[0001564590-19-032574:notes:11]
We do not separate non-lease components from lease components for any class of leases, and we do not recognize ROU assets and lease liabilities for leases with a lease term of twelve months or less.

[0001564590-19-032574:notes:12]
There have been no other significant changes in our significant accounting policies as of and for the three months ended July 26, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 26, 2019.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-19-032574:notes:13]
3. Business Combination

[0001564590-19-032574:notes:14]
On May 23, 2019, we acquired all the outstanding shares of privately-held Cognigo Research Ltd., a provider of data discovery classification software designed to manage and protect critical data, for $58 million in cash.

[0001564590-19-032574:notes:15]
The preliminary acquisition date fair values of the assets acquired and liabilities assumed are as follows (in millions):

[0001564590-19-032574:notes:16]
| Cash |  | $ | 2 |  |
| Developed technology intangible asset |  |  | 26 |  |
| Goodwill |  |  | 35 |  |
| Total assets acquired |  |  | 63 |  |
| Liabilities assumed |  |  | (5 | ) |
| Total purchase price |  | $ | 58 |  |

[0001564590-19-032574:notes:17]
The results of operations related to this acquisition have been included in our condensed consolidated statements of operations from the acquisition date. Pro forma results of operations have not been presented because the acquisition was not material to our results of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-19-032574:notes:18]
4. Goodwill and Purchased Intangible Assets, Net

[0001564590-19-032574:notes:19]
[same as prior period, unchanged from 0001564590-19-003270:notes:13]

[0001564590-19-032574:notes:20]
| Balance as of April 26, 2019 |  | $ | 1,735 |  |
| Additions |  |  | 35 |  |
| Balance as of July 26, 2019 |  | $ | 1,770 |  |

[0001564590-19-032574:notes:21]
[same as prior period, unchanged from 0001564590-19-003270:notes:16]

[0001564590-19-032574:notes:22]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 186 |  |  | $ | (124 | ) |  | $ | 62 |  |  | $ | 160 |  |  | $ | (113 | ) |  | $ | 47 |  |
| Customer contracts/relationships |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 41 |  |  |  | (41 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 186 |  |  | $ | (124 | ) |  | $ | 62 |  |  | $ | 201 |  |  | $ | (154 | ) |  | $ | 47 |  |

[0001564590-19-032574:notes:23]
[same as prior period, unchanged from 0001564590-19-003270:notes:18]

[0001564590-19-032574:notes:24]
|  |  | Three Months Ended |  |  | Statements of |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  | Operations Classification |
| Developed technology |  | $ | 11 |  |  | $ | 9 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | — |  |  |  | 4 |  |  | Operating expenses |
| Total |  | $ | 11 |  |  | $ | 13 |  |  |  |

[0001564590-19-032574:notes:25]
As of July 26, 2019, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-19-032574:notes:26]
| Fiscal Year |  | Amount |  |
| Remainder of 2020 |  | $ | 27 |  |
| 2021 |  |  | 25 |  |
| 2022 |  |  | 9 |  |
| Thereafter |  |  | 1 |  |
| Total |  | $ | 62 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-19-032574:notes:27]
5. Supplemental Financial Information

[0001564590-19-032574:notes:28]
[same as prior period, unchanged from 0001564590-19-003270:notes:23]

[0001564590-19-032574:notes:29]
The following table presents cash and cash equivalents as reported in our condensed consolidated balance sheets, as well as the sum of cash, cash equivalents and restricted cash as reported on our condensed consolidated statement of cash flows:

[0001564590-19-032574:notes:30]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Cash |  | $ | 2,858 |  |  | $ | 2,216 |  |
| Cash equivalents |  |  | 109 |  |  |  | 109 |  |
| Cash and cash equivalents |  | $ | 2,967 |  |  | $ | 2,325 |  |
| Short-term restricted cash |  |  | 5 |  |  |  | 5 |  |
| Long-term restricted cash |  |  | 1 |  |  |  | 1 |  |
| Restricted cash |  | $ | 6 |  |  | $ | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,973 |  |  | $ | 2,331 |  |

[0001564590-19-032574:notes:31]
[same as prior period, unchanged from 0001564590-19-003270:notes:26]

[0001564590-19-032574:notes:32]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Purchased components |  | $ | 21 |  |  | $ | 8 |  |
| Finished goods |  |  | 95 |  |  |  | 123 |  |
| Inventories |  | $ | 116 |  |  | $ | 131 |  |

[0001564590-19-032574:notes:33]
[same as prior period, unchanged from 0001564590-19-003270:notes:28]

[0001564590-19-032574:notes:34]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Land |  | $ | 106 |  |  | $ | 106 |  |
| Buildings and improvements |  |  | 607 |  |  |  | 605 |  |
| Leasehold improvements |  |  | 85 |  |  |  | 86 |  |
| Computer, production, engineering and other equipment |  |  | 833 |  |  |  | 817 |  |
| Computer software |  |  | 358 |  |  |  | 357 |  |
| Furniture and fixtures |  |  | 105 |  |  |  | 105 |  |
| Construction-in-progress |  |  | 12 |  |  |  | 10 |  |
|  |  |  | 2,106 |  |  |  | 2,086 |  |
| Accumulated depreciation and amortization |  |  | (1,352 | ) |  |  | (1,327 | ) |
| Property and equipment, net |  | $ | 754 |  |  | $ | 759 |  |

[0001564590-19-032574:notes:35]
In September 2017, we entered into an agreement to sell certain land and buildings located in Sunnyvale, California, through two separate and independent closings, the first of which was completed in the third quarter of fiscal 2018. The remaining properties, consisting of land with a net book value of $52 million, were classified as assets held for sale, and included as other current assets in our condensed consolidated balance sheets as of July 26, 2019 and April 26, 2019. We will consummate the sale of these properties, and receive cash proceeds of $96 million, upon the completion of the second closing, which is expected to occur within the next 12 months. That closing is subject to due diligence, certain termination rights and customary closing conditions, including local governmental approval of the subdivision of a land parcel.

[0001564590-19-032574:notes:36]
[same as prior period, unchanged from 0001564590-19-003270:notes:31]

[0001564590-19-032574:notes:37]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Deferred tax assets |  | $ | 207 |  |  | $ | 201 |  |
| Operating lease ROU assets |  |  | 142 |  |  |  | — |  |
| Other assets |  |  | 360 |  |  |  | 389 |  |
| Other non-current assets |  | $ | 709 |  |  | $ | 590 |  |

[0001564590-19-032574:notes:38]
Other non-current assets as of each July 26, 2019 and April 26, 2019 includes $78 million for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited, a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019.

[0001564590-19-032574:notes:39]
[same as prior period, unchanged from 0001564590-19-003270:notes:33]

[0001564590-19-032574:notes:40]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Accrued compensation and benefits |  | $ | 257 |  |  | $ | 433 |  |
| Product warranty liabilities |  |  | 25 |  |  |  | 25 |  |
| Operating lease liabilities |  |  | 51 |  |  |  | — |  |
| Other current liabilities |  |  | 300 |  |  |  | 393 |  |
| Accrued expenses |  | $ | 633 |  |  | $ | 851 |  |

[0001564590-19-032574:notes:41]
[same as prior period, unchanged from 0001564590-19-003270:notes:35]

[0001564590-19-032574:notes:42]
[same as prior period, unchanged from 0001564590-19-003270:notes:36]

[0001564590-19-032574:notes:43]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Balance at beginning of period |  | $ | 40 |  |  | $ | 40 |  |
| Expense accrued during the period |  |  | 5 |  |  |  | 4 |  |
| Warranty costs incurred |  |  | (6 | ) |  |  | (6 | ) |
| Balance at end of period |  | $ | 39 |  |  | $ | 38 |  |

[0001564590-19-032574:notes:44]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Accrued expenses |  | $ | 25 |  |  | $ | 25 |  |
| Other long-term liabilities |  |  | 14 |  |  |  | 15 |  |
| Total warranty liabilities |  | $ | 39 |  |  | $ | 40 |  |

[0001564590-19-032574:notes:45]
[same as prior period, unchanged from 0001564590-19-003270:notes:39]

[0001564590-19-032574:notes:46]
[same as prior period, unchanged from 0001564590-19-003270:notes:40]

[0001564590-19-032574:notes:47]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Liability for uncertain tax positions |  | $ | 249 |  |  | $ | 252 |  |
| Income taxes payable |  |  | 447 |  |  |  | 447 |  |
| Product warranty liabilities |  |  | 14 |  |  |  | 15 |  |
| Operating lease liabilities |  |  | 100 |  |  |  | — |  |
| Other liabilities |  |  | 72 |  |  |  | 83 |  |
| Other long-term liabilities |  | $ | 882 |  |  | $ | 797 |  |

[0001564590-19-032574:notes:48]
[same as prior period, unchanged from 0001564590-19-003270:notes:42]

[0001564590-19-032574:notes:49]
Supplemental cash flow information related to our operating leases is included in Note 10 ─ Leases. Non-cash investing activities and other supplemental cash flow information are presented below:

[0001564590-19-032574:notes:50]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 10 |  |  | $ | 10 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 55 |  |  | $ | 22 |  |
| Interest paid |  | $ | 14 |  |  | $ | 14 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-032574:notes:51]
6. Revenue

[0001564590-19-032574:notes:52]
[same as prior period, unchanged from 0001564590-19-003270:notes:63]

[0001564590-19-032574:notes:53]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. As our product portfolio evolves, market dynamics change, and management continues to assess of our largest growth opportunities, we periodically change how we group certain products. Beginning in fiscal 2020, Strategic includes All-flash FAS (AFF) products, including all related add-on hardware and operating system (OS) software, private cloud solutions (including SolidFire, converged and hyper-converged infrastructure products, StorageGrid), enterprise software license agreements (ELAs) and other optional add-on software products. Mature now includes Hybrid FAS products, including all related add-on hardware and OS software, original equipment manufacturers (OEM) products, and branded E-Series. Prior to this grouping change, Hybrid FAS products and branded E-Series were included in Strategic, while all add-on hardware and OS software were included in Mature. For comparability, Strategic and Mature revenues presented for the prior year period have been recast based on the revised groupings.

[0001564590-19-032574:notes:54]
In addition to the sale of our products and solutions, we provide a variety of services to our customers, including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training.

[0001564590-19-032574:notes:55]
[same as prior period, unchanged from 0001564590-19-003270:notes:65]

[0001564590-19-032574:notes:56]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Product revenues |  | $ | 644 |  |  | $ | 875 |  |
| Strategic |  | 337 |  |  | 475 |  |
| Mature |  | 307 |  |  | 400 |  |
| Software maintenance revenues |  | 250 |  |  | 229 |  |
| Hardware maintenance and other services revenues |  | 342 |  |  | 370 |  |
| Hardware maintenance support contracts |  | 284 |  |  | 303 |  |
| Professional and other services |  | 58 |  |  | 67 |  |
| Net revenues |  | $ | 1,236 |  |  | $ | 1,474 |  |

[0001564590-19-032574:notes:57]
Revenues by geographic region are presented in Note 16 – Segment, Geographic, and Significant Customer Information.

[0001564590-19-032574:notes:58]
[same as prior period, unchanged from 0001564590-19-003270:notes:68]

[0001564590-19-032574:notes:59]
[same as prior period, unchanged from 0001564590-19-003270:notes:69]

[0001564590-19-032574:notes:60]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Deferred product revenue |  | $ | 74 |  |  | $ | 84 |  |
| Deferred services revenue |  |  | 3,361 |  |  |  | 3,502 |  |
| Financed unearned services revenue |  |  | 75 |  |  |  | 82 |  |
| Total |  | $ | 3,510 |  |  | $ | 3,668 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,764 |  |  | $ | 1,825 |  |
| Long-term |  |  | 1,746 |  |  |  | 1,843 |  |
| Total |  | $ | 3,510 |  |  | $ | 3,668 |  |

[0001564590-19-032574:notes:61]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 17 – Commitments and Contingencies for additional information related to these arrangements.

[0001564590-19-032574:notes:62]
[same as prior period, unchanged from 0001564590-19-003270:notes:72]

[0001564590-19-032574:notes:63]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Balance at beginning of period |  | $ | 3,668 |  |  | $ | 3,363 |  |
| Additions |  |  | 447 |  |  |  | 511 |  |
| Revenue recognized during the period |  |  | (605 | ) |  |  | (614 | ) |
| Balance at end of period |  | $ | 3,510 |  |  | $ | 3,260 |  |

[0001564590-19-032574:notes:64]
During the three months ended July 26, 2019 and July 27, 2018, we recognized $552 million and $561 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001564590-19-032574:notes:65]
As of July 26, 2019, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,510 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 25% in the next 13 to 24 months, and the remainder thereafter.

[0001564590-19-032574:notes:66]
[same as prior period, unchanged from 0001564590-19-003270:notes:76]

[0001564590-19-032574:notes:67]
The following tables summarize the activity related to deferred commissions and their balances as reported in our condensed consolidated balance sheets (in millions):

[0001564590-19-032574:notes:68]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Balance at beginning of period |  | $ | 172 |  |  | $ | 137 |  |
| Additions |  |  | 16 |  |  |  | 19 |  |
| Expense recognized during the period |  |  | (25 | ) |  |  | (21 | ) |
| Balance at end of period |  | $ | 163 |  |  | $ | 135 |  |

[0001564590-19-032574:notes:69]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Other current assets |  | $ | 71 |  |  | $ | 75 |  |
| Other non-current assets |  |  | 92 |  |  |  | 97 |  |
| Total deferred commissions |  | $ | 163 |  |  | $ | 172 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-19-032574:notes:70]
7. Other income, net

[0001564590-19-032574:notes:71]
[same as prior period, unchanged from 0001564590-19-003270:notes:81]

[0001564590-19-032574:notes:72]
|  |  | Three Months Ended |  |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  |
| Interest income |  | $ | 19 |  |  | $ | 25 |  |  |
| Interest expense |  |  | (15 | ) |  |  | (14 | ) |  |
| Other income (expense), net |  |  | 11 |  |  |  | 7 |  |  |
| Total other income, net |  | $ | 15 |  |  | $ | 18 |  |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-19-032574:notes:73]
8. Financial Instruments and Fair Value Measurements

[0001564590-19-032574:notes:74]
[same as prior period, unchanged from 0001564590-19-003270:notes:84]

[0001564590-19-032574:notes:75]
[same as prior period, unchanged from 0001564590-19-003270:notes:85]

[0001564590-19-032574:notes:76]
[same as prior period, unchanged from 0001564590-19-003270:notes:86]

[0001564590-19-032574:notes:77]
[same as prior period, unchanged from 0001564590-19-003270:notes:87]

[0001564590-19-032574:notes:78]
[same as prior period, unchanged from 0001564590-19-003270:notes:88]

[0001564590-19-032574:notes:79]
[same as prior period, unchanged from 0001564590-19-003270:notes:89]

[0001564590-19-032574:notes:80]
[same as prior period, unchanged from 0001564590-19-003270:notes:90]

[0001564590-19-032574:notes:81]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 363 |  |  | $ | — |  |  | $ | — |  |  | $ | 363 |  |  | $ | 1,359 |  |  | $ | 2 |  |  | $ | (8 | ) |  | $ | 1,353 |  |
| U.S. Treasury and government debt securities |  |  | 195 |  |  |  | — |  |  |  | (1 | ) |  |  | 194 |  |  |  | 214 |  |  |  | — |  |  |  | (1 | ) |  |  | 213 |  |
| Certificates of deposit |  |  | 117 |  |  |  | — |  |  |  | — |  |  |  | 117 |  |  |  | 117 |  |  |  | — |  |  |  | — |  |  |  | 117 |  |
| Mutual funds |  |  | 39 |  |  |  | — |  |  |  | — |  |  |  | 39 |  |  |  | 35 |  |  |  | — |  |  |  | — |  |  |  | 35 |  |
| Total debt and equity securities |  | $ | 714 |  |  | $ | — |  |  | $ | (1 | ) |  | $ | 713 |  |  | $ | 1,725 |  |  | $ | 2 |  |  | $ | (9 | ) |  | $ | 1,718 |  |

[0001564590-19-032574:notes:82]
During the three months ended July 26, 2019, we sold approximately $1.0 billion of corporate bonds held by foreign subsidiaries and recognized a gain on sale of $14 million, which is presented in other income, net on our condensed consolidated statement of operations.

[0001564590-19-032574:notes:83]
The unrealized losses on our available-for-sale investments were caused by market value declines as a result of increasing market interest rates. Because the declines in market value are attributable to changes in market conditions and not credit quality, and because we have determined that (i) we do not have the intent to sell any of these investments held as of July 26, 2019 and (ii) it is not more likely than not that we will be required to sell any of these investments before recovery of the entire amortized cost basis, we have determined that no other-than-temporary impairments were required to be recognized on these investments.

[0001564590-19-032574:notes:84]
The following table presents the contractual maturities of our debt investments as of July 26, 2019 (in millions):

[0001564590-19-032574:notes:85]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 524 |  |  | $ | 523 |  |
| Due after one year through five years |  |  | 146 |  |  |  | 146 |  |
| Due after five years through ten years |  |  | 5 |  |  |  | 5 |  |
|  |  | $ | 675 |  |  | $ | 674 |  |

[0001564590-19-032574:notes:86]
[same as prior period, unchanged from 0001564590-19-003270:notes:95]

[0001564590-19-032574:notes:87]
[same as prior period, unchanged from 0001564590-19-003270:notes:96]

[0001564590-19-032574:notes:88]
[same as prior period, unchanged from 0001564590-19-003270:notes:97]

[0001564590-19-032574:notes:89]
|  |  | July 26, 2019 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,858 |  |  | $ | 2,858 |  |  | $ | — |  |
| Corporate bonds |  |  | 363 |  |  |  | — |  |  |  | 363 |  |
| U.S. Treasury and government debt securities |  |  | 194 |  |  |  | 131 |  |  |  | 63 |  |
| Certificates of deposit |  |  | 117 |  |  |  | — |  |  |  | 117 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,532 |  |  | $ | 2,989 |  |  | $ | 543 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 8 |  |  | $ | 8 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 31 |  |  | $ | 31 |  |  | $ | — |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |

[0001564590-19-032574:notes:90]
[same as prior period, unchanged from 0001564590-19-003270:notes:99]

[0001564590-19-032574:notes:91]
[same as prior period, unchanged from 0001564590-19-003270:notes:100]

[0001564590-19-032574:notes:92]
[same as prior period, unchanged from 0001564590-19-003270:notes:101]

[0001564590-19-032574:notes:93]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of July 26, 2019 and April 26, 2019, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-19-032574:notes:94]
[same as prior period, unchanged from 0001564590-19-003270:notes:103]

[0001564590-19-032574:notes:95]
As of July 26, 2019 and April 26, 2019, the fair value of our long-term debt was approximately $1,569 million and $1,553 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-19-032574:notes:96]
9. Financing Arrangements

[0001564590-19-032574:notes:97]
Long-Term Debt

[0001564590-19-032574:notes:98]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-19-032574:notes:99]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |  |  | 2.32 | % |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,550 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (5 | ) |  |  |  |  |  |  | (6 | ) |  |  |  |  |
| Total senior notes |  |  | 1,545 |  |  |  |  |  |  |  | 1,544 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (400 | ) |  |  |  |  |  |  | (400 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,145 |  |  |  |  |  |  | $ | 1,144 |  |  |  |  |  |

[0001564590-19-032574:notes:100]
Senior Notes

[0001564590-19-032574:notes:101]
Our 2.00% Senior Notes and 3.30% Senior Notes, each with a principal amount of $400 million, were issued in September 2017. Interest on these Senior Notes is paid semi-annually in March and September. Our 3.375% Senior Notes and 3.25% Senior Notes, with principal amounts of $500 million and $250 million, respectively, were issued in June 2014 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-19-032574:notes:102]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 26, 2019, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-19-032574:notes:103]
As of July 26, 2019, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-19-032574:notes:104]
| Fiscal Year |  | Amount |  |
| 2020 |  | $ | 400 |  |
| 2022 |  |  | 500 |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| Total |  | $ | 1,550 |  |

[0001564590-19-032574:notes:105]
Commercial Paper Program and Credit Facility

[0001564590-19-032574:notes:106]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of July 26, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $30 million, a weighted-average interest rate of 2.56% and a maturity of 29 days. As of April 26, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $249 million, a weighted-average interest rate of 2.73% and maturities ranging from 27 days to 38 days.

[0001564590-19-032574:notes:107]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its

[0001564590-19-032574:notes:108]
maturity date for two additional one-year periods, both subject to certain conditions. As of July 26, 2019 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0001564590-19-032574:notes:109]
10. Leases

[0001564590-19-032574:notes:110]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and have remaining lease terms of up to 15 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and have remaining lease terms of up to 4 years, while our automobile leases have remaining lease terms of up to 5 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0001564590-19-032574:notes:111]
The components of lease cost related to our operating leases were as follows (in millions):

[0001564590-19-032574:notes:112]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |
| Operating lease cost |  | $ | 14 |  |
| Variable lease cost |  |  | 4 |  |
| Total lease cost |  | $ | 18 |  |

[0001564590-19-032574:notes:113]
Variable lease cost is primarily attributable to amounts paid to lessors for common area maintenance and utility charges under our real estate leases.

[0001564590-19-032574:notes:114]
The supplemental cash flow information related to our operating leases is as follows (in millions):

[0001564590-19-032574:notes:115]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 13 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  | $ | 6 |  |

[0001564590-19-032574:notes:116]
The supplemental balance sheet information related to our operating leases is as follows (in millions, except lease term and discount rate):

[0001564590-19-032574:notes:117]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |
| Other non-current assets |  | $ | 142 |  |
| Total operating lease ROU assets |  | $ | 142 |  |
| Accrued expenses |  | $ | 51 |  |
| Other long-term liabilities |  |  | 100 |  |
| Total operating lease liabilities |  | $ | 151 |  |
| Weighted Average Remaining Lease Term |  | 4.0 years |  |
| Weighted Average Discount Rate |  |  | 2.7 | % |

[0001564590-19-032574:notes:118]
Future minimum operating lease payments as of July 26, 2019 are as follows (in millions):

[0001564590-19-032574:notes:119]
|  |  | Operating Leases |  |
| Fiscal 2020 (remainder) |  | $ | 46 |  |
| Fiscal 2021 |  |  | 44 |  |
| Fiscal 2022 |  |  | 31 |  |
| Fiscal 2023 |  |  | 17 |  |
| Fiscal 2024 |  |  | 11 |  |
| Thereafter |  |  | 16 |  |
| Total lease payments |  | $ | 165 |  |
| Less: Interest |  |  | (14 | ) |
| Total |  | $ | 151 |  |

[0001564590-19-032574:notes:120]
Prior to our adoption of the new lease standard, future minimum operating lease payments as of April 26, 2019, which were undiscounted and excluded non-lease components, were as follows (in millions):

[0001564590-19-032574:notes:121]
|  |  | Operating Leases |  |
| Fiscal 2020 |  | $ | 47 |  |
| Fiscal 2021 |  |  | 38 |  |
| Fiscal 2022 |  |  | 26 |  |
| Fiscal 2023 |  |  | 14 |  |
| Fiscal 2024 |  |  | 10 |  |
| Thereafter |  |  | 16 |  |
| Total lease payments |  | $ | 151 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-19-032574:notes:122]
11. Stockholders’ Equity

[0001564590-19-032574:notes:123]
[same as prior period, unchanged from 0001564590-19-003270:notes:118]

[0001564590-19-032574:notes:124]
As of July 26, 2019, we have certain equity incentive awards (awards) outstanding, which include stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and Employee Stock Purchase Plan (ESPP) awards.

[0001564590-19-032574:notes:125]
[same as prior period, unchanged from 0001564590-19-003270:notes:120]

[0001564590-19-032574:notes:126]
Less than 1 million options were outstanding as of July 26, 2019 and April 26, 2019.

[0001564590-19-032574:notes:127]
Information related to our stock options is summarized below (in millions):

[0001564590-19-032574:notes:128]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Intrinsic value of exercises |  | $ | 1 |  |  | $ | 15 |  |
| Proceeds received from exercises |  | $ | 1 |  |  | $ | 13 |  |
| Fair value of options vested |  | $ | 2 |  |  | $ | 1 |  |

[0001564590-19-032574:notes:129]
[same as prior period, unchanged from 0001564590-19-003270:notes:123]

[0001564590-19-032574:notes:130]
[same as prior period, unchanged from 0001564590-19-003270:notes:126]

[0001564590-19-032574:notes:131]
In the three months ended July 26, 2019, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria, in addition to the service based vesting criteria, such that the PBRSUs cliff-vest at the end of an approximate three year performance period, which began on the date specified in the grant agreements and ends the last day of fiscal 2022. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the current year, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of fiscal 2022. The fair values of these awards were fixed at grant date using a Monte Carlo simulation model. For the remaining PBRSUs granted, the number of shares issued will depend upon our achievement against a cumulative Adjusted Operating Income (AOI) target, as defined in the grant agreements, for the three year period from fiscal 2020 through 2022. The fair values of these awards were established consistent with our methodology for valuing time-based RSUs, while compensation cost is being recognized based on the probable outcome of the

[0001564590-19-032574:notes:132]
performance condition. The aggregate grant date fair value of all PBRSUs granted in the current year was $18 million, which is being recognized to compensation expense over the remaining applicable performance / service periods.

[0001564590-19-032574:notes:133]
[same as prior period, unchanged from 0001564590-19-003270:notes:128]

[0001564590-19-032574:notes:134]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 26, 2019 |  |  | 8 |  |  | $ | 45.68 |  |
| Granted |  |  | 3 |  |  | $ | 52.21 |  |
| Vested |  |  | (2 | ) |  | $ | 37.88 |  |
| Forfeited |  |  | (1 | ) |  | $ | 47.64 |  |
| Outstanding as of July 26, 2019 |  |  | 8 |  |  | $ | 51.25 |  |

[0001564590-19-032574:notes:135]
[same as prior period, unchanged from 0001564590-19-003270:notes:130]

[0001564590-19-032574:notes:136]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 71 |  |  | $ | 84 |  |

[0001564590-19-032574:notes:137]
[same as prior period, unchanged from 0001564590-19-003270:notes:132]

[0001564590-19-032574:notes:138]
[same as prior period, unchanged from 0001564590-19-003270:notes:133]

[0001564590-19-032574:notes:139]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Shares issued under the ESPP |  |  | 1 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 54 |  |  | $ | 49 |  |

[0001564590-19-032574:notes:140]
[same as prior period, unchanged from 0001564590-19-003270:notes:135]

[0001564590-19-032574:notes:141]
[same as prior period, unchanged from 0001564590-19-003270:notes:136]

[0001564590-19-032574:notes:142]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |
| Cost of hardware maintenance and other services revenues |  |  | 2 |  |  |  | 3 |  |
| Sales and marketing |  |  | 18 |  |  |  | 17 |  |
| Research and development |  |  | 15 |  |  |  | 12 |  |
| General and administrative |  |  | 6 |  |  |  | 7 |  |
| Total stock-based compensation expense |  | $ | 42 |  |  | $ | 40 |  |
| Income tax benefit for stock-based compensation expense |  | $ | 4 |  |  | $ | 5 |  |

[0001564590-19-032574:notes:143]
As of July 26, 2019, total unrecognized compensation expense related to our equity awards was $383 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.5 years.

[0001564590-19-032574:notes:144]
[same as prior period, unchanged from 0001564590-19-003270:notes:139]

[0001564590-19-032574:notes:145]
[same as prior period, unchanged from 0001564590-19-003270:notes:140]

[0001564590-19-032574:notes:146]
The following table summarizes activity related to this program for the three months ended July 26, 2019 (in millions, except per share amounts):

[0001564590-19-032574:notes:147]
| Number of shares repurchased |  |  | 4 |  |
| Average price per share |  | $ | 64.87 |  |
| Aggregate purchase price |  | $ | 250 |  |
| Remaining authorization at end of period |  | $ | 1,639 |  |

[0001564590-19-032574:notes:148]
The aggregate purchase price of our stock repurchases for the three months ended July 26, 2019 consisted of $250 million of open market purchases, of which $141 million and $109 million were allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-19-032574:notes:149]
Since the May 13, 2003 inception of our stock repurchase program through July 26, 2019, we repurchased a total of 317 million shares of our common stock at an average price of $37.80 per share, for an aggregate purchase price of $12.0 billion.

[0001564590-19-032574:notes:150]
[same as prior period, unchanged from 0001564590-19-003270:notes:145]

[0001564590-19-032574:notes:151]
[same as prior period, unchanged from 0001564590-19-003270:notes:146]

[0001564590-19-032574:notes:152]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Dividends per share declared |  | $ | 0.48 |  |  | $ | 0.40 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 115 |  |  | $ | 105 |  |
| Dividend payments allocated to retained earnings |  | $ | — |  |  | $ | — |  |

[0001564590-19-032574:notes:153]
On August 14, 2019, we declared a cash dividend of $0.48 per share of common stock, payable on October 23, 2019 to holders of record as of the close of business on October 4, 2019. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-19-032574:notes:154]
[same as prior period, unchanged from 0001564590-19-003270:notes:153]

[0001564590-19-032574:notes:155]
[same as prior period, unchanged from 0001564590-19-003270:notes:154]

[0001564590-19-032574:notes:156]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 26, 2019 |  | $ | (34 | ) |  | $ | (3 | ) |  | $ | (7 | ) |  | $ | 1 |  |  | $ | (43 | ) |
| Other comprehensive income (loss), net of tax |  |  | (1 | ) |  |  | — |  |  |  | 20 |  |  |  | (1 | ) |  |  | 18 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | (14 | ) |  |  | — |  |  |  | (14 | ) |
| Total other comprehensive income |  |  | (1 | ) |  |  | — |  |  |  | 6 |  |  |  | (1 | ) |  |  | 4 |  |
| Balance as of July 26, 2019 |  | $ | (35 | ) |  | $ | (3 | ) |  | $ | (1 | ) |  | $ | — |  |  | $ | (39 | ) |

[0001564590-19-032574:notes:157]
During the first quarter of fiscal 2020, realized gains of $14 million from the sale of available-for-sale securities were recorded in Other income, net on our condensed consolidated statements of operations.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-19-032574:notes:158]
12. Derivatives and Hedging Activities

[0001564590-19-032574:notes:159]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of our agreements with them. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of July 26, 2019 or April 26, 2019. All contracts have a maturity of less than 12 months.

[0001564590-19-032574:notes:160]
[same as prior period, unchanged from 0001564590-19-003270:notes:158]

[0001564590-19-032574:notes:161]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 301 |  |  | $ | 103 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 153 |  |  | $ | 121 |  |
| Forward contracts purchased |  | $ | 139 |  |  | $ | 363 |  |

[0001564590-19-032574:notes:162]
[same as prior period, unchanged from 0001564590-19-003270:notes:160]

[0001564590-19-032574:notes:163]
[same as prior period, unchanged from 0001564590-19-003270:notes:161]

[0001564590-19-032574:notes:164]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
|  |  | Gain (Loss) Recognized in Income |  |
| Foreign currency exchange contracts |  | $ | (3 | ) |  | $ | 10 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-19-032574:notes:165]
13. Restructuring Charges `

[0001564590-19-032574:notes:166]
In the first quarter of fiscal 2020, we announced a restructuring plan (the May 2019 Plan) to reduce costs and redirect resources to our highest return activities, which included a reduction in our global workforce by approximately 2%. Charges related to the plan consisted primarily of employee severance-related costs. We expect to complete all activities associated with the May 2019 plan by the end of the second quarter of fiscal 2020 with no significant additional charges.

[0001564590-19-032574:notes:167]
Management has previously approved several restructuring actions, including the May 2018 Plan and April 2019 Plan, under which we reduced our global workforce by less than 2%, and approximately 1%, respectively. Charges related to our restructuring plans consisted primarily of employee severance-related costs. Substantially all activities under the May 2018 Plan were completed as of the end of fiscal 2019. We expect to complete all activities associated with the April 2019 plan by the end of the third quarter of fiscal 2020 with no significant additional charges.

[0001564590-19-032574:notes:168]
[same as prior period, unchanged from 0001564590-19-003270:notes:166]

[0001564590-19-032574:notes:169]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
|  |  | May 2019 Plan |  |  | April 2019 Plan |  |  | May 2018 Plan |  |  | November 2016 Plan |  |  | Total |  |  | May 2018 Plan |  |  | November 2016 Plan |  |  | Total |  |
| Balance at beginning of period |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 19 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 6 |  |
| Net charges |  |  | 21 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 21 |  |  |  | 19 |  |  |  | — |  |  |  | 19 |  |
| Cash payments |  |  | (11 | ) |  |  | (9 | ) |  |  | — |  |  |  | — |  |  |  | (20 | ) |  |  | (9 | ) |  |  | (1 | ) |  |  | (10 | ) |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (4 | ) |  |  | (4 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Balance at end of period |  | $ | 10 |  |  | $ | 6 |  |  | $ | — |  |  | $ | — |  |  | $ | 16 |  |  | $ | 10 |  |  | $ | 5 |  |  | $ | 15 |  |

[0001564590-19-032574:notes:170]
Upon adoption of the new lease accounting standard in the first quarter of fiscal 2020, the remaining lease-related liabilities associated with the November 2016 Plan were recognized as a reduction to the lease right-of-use asset recorded at transition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-032574:notes:171]
14. Income Taxes

[0001564590-19-032574:notes:172]
[same as prior period, unchanged from 0001564590-19-003270:notes:169]

[0001564590-19-032574:notes:173]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Effective tax rates |  |  | 13.4 | % |  |  | (4.0 | )% |

[0001564590-19-032574:notes:174]
Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations, being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory tax rate. The differences in effective tax rates for

[0001564590-19-032574:notes:175]
the three months ended July 26, 2019 and July 27, 2018 were primarily due to discrete tax benefits related to the adoption of the new revenue standard in fiscal 2019 and the differences in discrete benefits for stock-based compensation.

[0001564590-19-032574:notes:176]
On December 22, 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, the imposition of a one-time transition tax on deferred foreign earnings, and the creation of new taxes on certain foreign-sourced earnings. As of April 26, 2019, we had completed the accounting for the tax impacts of the TCJA, however, we will continue to assess the impact of further guidance from federal and state tax authorities on our business and consolidated financial statements, and recognize any adjustments in the period in which they are determined.

[0001564590-19-032574:notes:177]
During fiscal 2019, we adopted the new revenue accounting standard and for the three months ended July 27, 2018, we recognized a $34 million discrete tax benefit for adjustments to certain intercompany transactions resulting from the retrospective application of the new revenue accounting standard.

[0001564590-19-032574:notes:178]
As of July 26, 2019, we had $293 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $244 million would affect our provision for income taxes if recognized, and $249 million has been recorded in other long-term liabilities.

[0001564590-19-032574:notes:179]
We are currently undergoing state income tax audits in the U.S. and audits in several foreign tax jurisdictions. Transfer pricing calculations are key issues under audits in various jurisdictions, and are often subject to dispute and appeals. The IRS has concluded the examination of our tax returns for our fiscal years through 2013.

[0001564590-19-032574:notes:180]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for such withholding tax and filed an appeal with the Danish Tax Tribunal. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012. In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). Parties were heard before the court in October 2017. In March 2018, the Advocate General issued an opinion which was largely in favor of NetApp. The CJEU was not bound by the opinion of the Advocate General and issued its preliminary ruling in February 2019. The CJEU ruling did not preclude the Danish Tax Authorities from imposing withholding tax on distributions based on the benefits of certain European Union directives. The preliminary ruling will be reviewed and may be subjected to additional briefing by the DHC. Once complete, the DHC will then issue its final decision. While the timing and outcome of a final decision on this matter is uncertain, we believe it is more likely than not that our distributions were not subject to withholding tax and we intend to vigorously defend any withholding tax claims by the Danish Tax Authorities.

[0001564590-19-032574:notes:181]
[same as prior period, unchanged from 0001564590-19-003270:notes:181]


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-032574:notes:182]
15. Net Income per Share

[0001564590-19-032574:notes:183]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0001564590-19-032574:notes:184]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 103 |  |  | $ | 283 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 239 |  |  |  | 262 |  |
| Dilutive impact of employee equity award plans |  |  | 4 |  |  |  | 7 |  |
| Shares used in diluted computation |  |  | 243 |  |  |  | 269 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.43 |  |  | $ | 1.08 |  |
| Diluted |  | $ | 0.42 |  |  | $ | 1.05 |  |

[0001564590-19-032574:notes:185]
Less than 1 million potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculation for the three months ended July 26, 2019, while no potential shares were excluded from the calculation for the three months ended July 27, 2018.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-032574:notes:186]
16. Segment, Geographic, and Significant Customer Information

[0001564590-19-032574:notes:187]
[same as prior period, unchanged from 0001564590-19-003270:notes:187]

[0001564590-19-032574:notes:188]
[same as prior period, unchanged from 0001564590-19-003270:notes:188]

[0001564590-19-032574:notes:189]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| United States, Canada and Latin America (Americas) |  | $ | 635 |  |  | $ | 843 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 402 |  |  |  | 430 |  |
| Asia Pacific (APAC) |  |  | 199 |  |  |  | 201 |  |
| Net revenues |  | $ | 1,236 |  |  | $ | 1,474 |  |

[0001564590-19-032574:notes:190]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $574 million and $761 million during the three months ended July 26, 2019 and July 27, 2018, respectively.

[0001564590-19-032574:notes:191]
[same as prior period, unchanged from 0001564590-19-003270:notes:191]

[0001564590-19-032574:notes:192]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| U.S. |  | $ | 790 |  |  | $ | 159 |  |
| International |  |  | 2,742 |  |  |  | 3,740 |  |
| Total |  | $ | 3,532 |  |  | $ | 3,899 |  |

[0001564590-19-032574:notes:193]
[same as prior period, unchanged from 0001564590-19-003270:notes:193]

[0001564590-19-032574:notes:194]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| U.S. |  | $ | 567 |  |  | $ | 572 |  |
| International |  |  | 187 |  |  |  | 187 |  |
| Total |  | $ | 754 |  |  | $ | 759 |  |

[0001564590-19-032574:notes:195]
[same as prior period, unchanged from 0001564590-19-003270:notes:195]

[0001564590-19-032574:notes:196]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Arrow Electronics, Inc. |  |  | 25 | % |  |  | 22 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 17 | % |

[0001564590-19-032574:notes:197]
[same as prior period, unchanged from 0001564590-19-003270:notes:197]

[0001564590-19-032574:notes:198]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Arrow Electronics, Inc. |  |  | 11 | % |  |  | 11 | % |
| Tech Data Corporation |  |  | 18 | % |  |  | 24 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-032574:notes:199]
17. Commitments and Contingencies

[0001564590-19-032574:notes:200]
Purchase Orders and Other Commitments

[0001564590-19-032574:notes:201]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 26, 2019, we had $392 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 26, 2019 and April 26, 2019, such liability amounted to $12 million and $16 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-19-032574:notes:202]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 26, 2019, we had $9 million in construction related obligations and $235 million in other purchase obligations.

[0001564590-19-032574:notes:203]
Financing Guarantees

[0001564590-19-032574:notes:204]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $14 million and $30 million of receivables during the three months ended July 26, 2019 and July 27, 2018, respectively.

[0001564590-19-032574:notes:205]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-19-032574:notes:206]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of July 26, 2019 and April 26, 2019, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-19-032574:notes:207]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 26, 2019, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-19-032574:notes:208]
Legal Contingencies

[0001564590-19-032574:notes:209]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-19-032574:notes:210]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. We believe the complaint is without merit and intend to defend the case vigorously.

[0001564590-19-032574:notes:211]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-19-032574:notes:212]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of July 26, 2019 related to such matters.
