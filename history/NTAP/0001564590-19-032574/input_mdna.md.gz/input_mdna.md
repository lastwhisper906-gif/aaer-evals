# NTAP MD&A — 0001564590-19-032574


## mdna

[0001564590-19-032574:mdna:1]
[same as prior period, unchanged from 0001564590-19-003270:mdna:1]

[0001564590-19-032574:mdna:2]
[same as prior period, unchanged from 0001564590-19-003270:mdna:3]

[0001564590-19-032574:mdna:3]
[same as prior period, unchanged from 0001564590-19-003270:mdna:4]

[0001564590-19-032574:mdna:4]
NetApp is the data authority for hybrid cloud. We provide a full range of hybrid cloud data services that simplify management of applications and data across cloud and on-premises environments to accelerate digital transformation. Together with our partners, we empower global organizations to unleash the full potential of their data to expand customer touchpoints, foster greater innovation and optimize their operations.

[0001564590-19-032574:mdna:5]
NetApp delivers a Data Fabric built for the data-driven world. Our Data Fabric simplifies the integration and orchestration of data for applications and analytics in clouds, across clouds and on-premises to accelerate digital transformation. We deliver a Data Fabric with consistent data services for data visibility and insights, data access and control, and data protection and security, that unleashes the power of data to achieve a new competitive advantage.

[0001564590-19-032574:mdna:6]
We focus on delivering an exceptional customer experience to become our customers’ preferred data partner. NetApp’s unique approach to data services enables organizations to inspire innovation with the cloud, build clouds to accelerate new services, and modernize IT architecture with cloud-connected flash.

[0001564590-19-032574:mdna:7]
[same as prior period, unchanged from 0001564590-19-003270:mdna:8]

[0001564590-19-032574:mdna:8]
[same as prior period, unchanged from 0001564590-19-003270:mdna:9]

[0001564590-19-032574:mdna:9]
[same as prior period, unchanged from 0001564590-19-003270:mdna:10]

[0001564590-19-032574:mdna:10]
[same as prior period, unchanged from 0001564590-19-003270:mdna:11]

[0001564590-19-032574:mdna:11]
Customers are attracted by the speed and scale benefits of the public cloud but need new data management capabilities to keep control of data as it moves beyond the walls of the enterprise. NetApp believes the hybrid cloud is fast becoming the dominant model for enterprise IT. Our Data Fabric approach enables our customers to manage, secure and protect their data from on-premises to public to hybrid clouds, all at the scale needed to accommodate the exponential data growth of the digital world.

[0001564590-19-032574:mdna:12]
Budget constraints and skill imbalances lead our customers to seek help in integrating, deploying and managing the solutions they need to stay competitive. This drives demand for converged and hyper-converged infrastructure solutions. FlexPod is the converged infrastructure of choice for many of the largest enterprises around the globe. Customers can break free from the limits of first-generation HCI with NetApp HCI and attain guaranteed performance with high levels of flexibility, scale, automation, and integration with the Data Fabric.

[0001564590-19-032574:mdna:13]
Flash plays a key role in customers’ digital transformation efforts as they seek to gain advantage through greater speed, responsiveness and value from key business applications - all while lowering total cost of ownership. All-flash array technology is the de facto choice as customers seek performance and economic benefits from replacing hard disk installations. With a highly differentiated and broad portfolio of all-flash and hybrid array offerings, NetApp is well positioned to enable customers to accomplish this transition.

[0001564590-19-032574:mdna:14]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. As our product portfolio evolves, market dynamics change, and management continues to assess our largest growth opportunities, we periodically change how we group certain products. Beginning in fiscal 2020, Strategic includes All-flash FAS (AFF) products, including all related add-on hardware and operating system (OS) software, private cloud solutions (including SolidFire, converged and hyper-converged infrastructure products, StorageGrid), enterprise software license agreements (ELAs) and other optional add-on software products. Mature now includes Hybrid FAS products, including all related add-on hardware and OS software, original equipment manufacturers (OEM) products, and branded E-Series. Prior to this grouping change, Hybrid FAS products and branded E-Series were included in Strategic, while all add-on hardware and OS software were included in Mature. For comparability, Strategic and Mature revenues presented for the prior year period have been recast based on the revised groupings.

[0001564590-19-032574:mdna:15]
In addition to our products and solutions, we provide a variety of services to our customers, including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training. Revenues generated by our Cloud Data Services offerings are included in software maintenance revenues.

[0001564590-19-032574:mdna:16]
[same as prior period, unchanged from 0001564590-19-003270:mdna:2]

[0001564590-19-032574:mdna:17]
[same as prior period, unchanged from 0001564590-19-003270:mdna:18]

[0001564590-19-032574:mdna:18]
[same as prior period, unchanged from 0001564590-19-003270:mdna:19]

[0001564590-19-032574:mdna:19]
|  | Three Months Ended |  |
|  | July 26, 2019 |  |  | July 27, 2018 |  |
| Net revenues | $ | 1,236 |  |  | $ | 1,474 |  |
| Gross profit | $ | 816 |  |  | $ | 963 |  |
| Gross profit margin percentage |  | 66 | % |  |  | 65 | % |
| Income from operations | $ | 104 |  |  | $ | 254 |  |
| Income from operations as a percentage of net revenues |  | 8 | % |  |  | 17 | % |
| Net income | $ | 103 |  |  | $ | 283 |  |
| Diluted net income per share | $ | 0.42 |  |  | $ | 1.05 |  |
| Operating cash flows | $ | 310 |  |  | $ | 326 |  |

[0001564590-19-032574:mdna:20]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,510 |  |  | $ | 3,668 |  |
| Cash conversion cycle (days) |  |  | (10 | ) |  |  | 3 |  |

[0001564590-19-032574:mdna:21]
[same as prior period, unchanged from 0001564590-19-003270:mdna:22]

[0001564590-19-032574:mdna:22]
During the first three months of fiscal 2020, we repurchased four million shares of our common stock at an average price of $64.87 per share, for an aggregate of $250 million. We also declared aggregate cash dividends of $0.48 per share in that period, for which we paid an aggregate of $115 million.

[0001564590-19-032574:mdna:23]
Cognigo Acquisition

[0001564590-19-032574:mdna:24]
On May 23, 2019, we acquired all the outstanding shares of privately-held Cognigo Research Ltd., a provider of data discovery classification software designed to manage and protect critical data, for $58 million in cash.

[0001564590-19-032574:mdna:25]
Restructuring Event

[0001564590-19-032574:mdna:26]
In the first quarter of fiscal 2020, we announced a restructuring plan to reduce costs and redirect resources to our highest return activities, which included a reduction in our global workforce by approximately 2%, and incurred charges of approximately $21 million, consisting primarily of employee severance costs. See Note 13 – Restructuring Charges for additional information.

[0001564590-19-032574:mdna:27]
Adoption of Lease Accounting Standard

[0001564590-19-032574:mdna:28]
In the first quarter of fiscal 2020, we adopted the new accounting standard Leases (ASC 842) using the modified retrospective approach, electing the optional transition method of not adjusting our comparative period financial statements. Adoption of the new standard resulted in the recognition of approximately $149 million of operating lease right-of-use assets, net of deferred rent and restructuring liabilities, and $158 million of lease liabilities on our condensed consolidated balance sheets as of the beginning of fiscal 2020. See Note 10 – Leases in the Notes to Condensed Consolidated Financial Statements for additional information.

[0001564590-19-032574:mdna:29]
[same as prior period, unchanged from 0001564590-19-003270:mdna:26]

[0001564590-19-032574:mdna:30]
[same as prior period, unchanged from 0001564590-19-003270:mdna:27]

[0001564590-19-032574:mdna:31]
The summary of our significant accounting policies is included under Item 7 – Management’s Discussion and Analysis of Financial Condition and Results of Operations of our fiscal 2019 Form 10-K. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. There have been no material changes to the critical accounting policies and estimates as filed in such report.

[0001564590-19-032574:mdna:32]
[same as prior period, unchanged from 0001564590-19-003270:mdna:17]

[0001564590-19-032574:mdna:33]
[same as prior period, unchanged from 0001564590-19-003270:mdna:29]

[0001564590-19-032574:mdna:34]
[same as prior period, unchanged from 0001564590-19-003270:mdna:30]

[0001564590-19-032574:mdna:35]
[same as prior period, unchanged from 0001564590-19-003270:mdna:32]

[0001564590-19-032574:mdna:36]
Our fiscal year is reported as a 52- or 53-week year that ends on the last Friday in April. Fiscal years 2020 and 2019 are each 52-week years, with 13 weeks in each of their quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0001564590-19-032574:mdna:37]
[same as prior period, unchanged from 0001564590-19-003270:mdna:34]

[0001564590-19-032574:mdna:38]
|  |  | Three Months Ended |  |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product |  |  | 52 |  | % |  | 59 |  | % |
| Software maintenance |  |  | 20 |  |  |  | 16 |  |  |
| Hardware maintenance and other services |  |  | 28 |  |  |  | 25 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 25 |  |  |  | 27 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | — |  |  |
| Cost of hardware maintenance and other services |  |  | 8 |  |  |  | 7 |  |  |
| Gross profit |  |  | 66 |  |  |  | 65 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 33 |  |  |  | 28 |  |  |
| Research and development |  |  | 17 |  |  |  | 14 |  |  |
| General and administrative |  |  | 6 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | 2 |  |  |  | 1 |  |  |
| Total operating expenses |  |  | 58 |  |  |  | 48 |  |  |
| Income from operations |  |  | 8 |  |  |  | 17 |  |  |
| Other income, net |  |  | 1 |  |  |  | 1 |  |  |
| Income before income taxes |  |  | 10 |  |  |  | 18 |  |  |
| Provision (benefit) for income taxes |  |  | 1 |  |  |  | (1 | ) |  |
| Net income |  |  | 8 |  | % |  | 19 |  | % |

[0001564590-19-032574:mdna:39]
[same as prior period, unchanged from 0001564590-19-003270:mdna:36]

[0001564590-19-032574:mdna:40]
[same as prior period, unchanged from 0001564590-19-003270:mdna:37]

[0001564590-19-032574:mdna:41]
[same as prior period, unchanged from 0001564590-19-003270:mdna:38]

[0001564590-19-032574:mdna:42]
Net revenues for the first quarter of fiscal 2020 were $1,236 million, reflecting a decrease of $238 million, or 16%, compared to the corresponding period of the prior year, primarily reflecting lower product revenues, and to a lesser extent, the unfavorable impact of foreign exchange rate fluctuations in the quarter. Hardware maintenance and other services revenues also decreased compared to the corresponding period of the prior year, offset by an increase in software maintenance revenues.

[0001564590-19-032574:mdna:43]
Gross profit as a percentage of net revenues for the first quarter increased by one percentage point compared to the corresponding period in fiscal 2019. Gross profit margins on product revenues decreased by three percentage points in the first quarter of fiscal 2020 compared to the corresponding period of fiscal 2019, primarily due to high margins on revenue recognized related to the software license components of several ELAs in the first quarter of fiscal quarter of 2019, which did not repeat in fiscal 2020.

[0001564590-19-032574:mdna:44]
Sales and marketing, research and development, and general and administrative expenses for the first quarter of fiscal 2020 totaled $691 million, or 56% of net revenues, representing an increase of nine percentage points when compared to the first quarter of fiscal 2019, primarily due to lower net revenues in the current fiscal period.

[0001564590-19-032574:mdna:45]
[same as prior period, unchanged from 0001564590-19-003270:mdna:31]

[0001564590-19-032574:mdna:46]
[same as prior period, unchanged from 0001564590-19-003270:mdna:43]

[0001564590-19-032574:mdna:47]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  | % Change |  |
| Net revenues |  | $ | 1,236 |  |  | $ | 1,474 |  |  |  | (16 | )% |

[0001564590-19-032574:mdna:48]
The decrease in net revenues for the first quarter of fiscal 2020 compared to the corresponding period of fiscal 2019 was primarily due to a decrease in product revenues of $231 million. Product revenues as a percentage of net revenues decreased by seven percentage points in the first quarter of fiscal 2020 compared to the first quarter of fiscal 2019.

[0001564590-19-032574:mdna:49]
[same as prior period, unchanged from 0001564590-19-003270:mdna:46]

[0001564590-19-032574:mdna:50]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Arrow Electronics, Inc. |  |  | 25 | % |  |  | 22 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 17 | % |

[0001564590-19-032574:mdna:51]
[same as prior period, unchanged from 0001564590-19-003270:mdna:48]

[0001564590-19-032574:mdna:52]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  | % Change |  |
| Product revenues |  | $ | 644 |  |  | $ | 875 |  |  |  | (26 | )% |

[0001564590-19-032574:mdna:53]
Product revenues are derived through the sale of our strategic and mature solutions, and consist of sales of configured AFF and Hybrid systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, private cloud solutions (including SolidFire, converged and hyper-converged infrastructure products, StorageGrid), original equipment manufacturer (OEM) products and add-on optional software.

[0001564590-19-032574:mdna:54]
Under the revised Strategic and Mature product groupings, as described in the Overview section above, product revenues from strategic solutions represented 52% of product revenues in the first quarter of fiscal 2020, compared to 54% in the corresponding period of the prior year. Product revenues from mature solutions represented 48% of product revenues in the first quarter of fiscal 2020, compared to 46% in the corresponding period of the prior year.

[0001564590-19-032574:mdna:55]
Product revenues declined in the first quarter of fiscal 2020 compared to the corresponding period of the prior year due a combination of less favorable macroeconomic conditions and go-to-market execution issues experienced with some of our largest global customer accounts.

[0001564590-19-032574:mdna:56]
Total product revenues from strategic solutions totaled $337 million in the first quarter of fiscal 2020 reflecting a 29% decrease from $475 million in the first quarter of fiscal 2019, primarily due to decreased sales of All-Flash FAS products in the current year period and a substantial amount of revenue recognized in the prior year period related to the software license components of several ELAs which did not repeat, partially offset by an increase in revenues from private cloud solutions.

[0001564590-19-032574:mdna:57]
Total product revenue from mature solutions totaled $307 million in the first quarter of fiscal 2020 reflecting a 23% decrease from $400 million in the first quarter of fiscal 2019, primarily due to decreased sales of FAS Hybrid and OEM products in the current year period.

[0001564590-19-032574:mdna:58]
[same as prior period, unchanged from 0001564590-19-003270:mdna:54]

[0001564590-19-032574:mdna:59]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 250 |  |  | $ | 229 |  |  |  | 9 | % |

[0001564590-19-032574:mdna:60]
[same as prior period, unchanged from 0001564590-19-003270:mdna:57]

[0001564590-19-032574:mdna:61]
[same as prior period, unchanged from 0001564590-19-003270:mdna:58]

[0001564590-19-032574:mdna:62]
[same as prior period, unchanged from 0001564590-19-003270:mdna:59]

[0001564590-19-032574:mdna:63]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 342 |  |  | $ | 370 |  |  |  | (8 | )% |

[0001564590-19-032574:mdna:64]
[same as prior period, unchanged from 0001564590-19-003270:mdna:61]

[0001564590-19-032574:mdna:65]
Hardware maintenance contract revenues decreased year over year, at $284 million for the first quarter of fiscal 2020, compared to $303 million for the corresponding period of the prior year. The decrease was primarily attributable to a decline in average selling price on contracts executed recently, as well as lower contract renewal rates.

[0001564590-19-032574:mdna:66]
Professional services and educational and training services revenues were $58 million for the first quarter of fiscal 2020, compared to $67 million for the corresponding period of the prior year.

[0001564590-19-032574:mdna:67]
[same as prior period, unchanged from 0001564590-19-003270:mdna:64]

[0001564590-19-032574:mdna:68]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| United States, Canada and Latin America (Americas) |  |  | 51 | % |  |  | 57 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 33 | % |  |  | 29 | % |
| Asia Pacific (APAC) |  |  | 16 | % |  |  | 14 | % |

[0001564590-19-032574:mdna:69]
[same as prior period, unchanged from 0001564590-19-003270:mdna:66]

[0001564590-19-032574:mdna:70]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. During the first quarter of fiscal 2020, Americas revenues were negatively impacted by general macroeconomic conditions in the region and go-to-market execution issues with some of our largest customer accounts, which was reflected in the geographic distribution of revenues as a percentage of net revenues in the first quarter of fiscal 2020 compared to the corresponding period of fiscal 2019.

[0001564590-19-032574:mdna:71]
[same as prior period, unchanged from 0001564590-19-003270:mdna:68]

[0001564590-19-032574:mdna:72]
[same as prior period, unchanged from 0001564590-19-003270:mdna:69]

[0001564590-19-032574:mdna:73]
[same as prior period, unchanged from 0001564590-19-003270:mdna:70]

[0001564590-19-032574:mdna:74]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  | % Change |  |
| Cost of product revenues |  | $ | 312 |  |  | $ | 398 |  |  |  | (22 | )% |

[0001564590-19-032574:mdna:75]
[same as prior period, unchanged from 0001564590-19-003270:mdna:72]

[0001564590-19-032574:mdna:76]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2020 to Fiscal 2019 |  |  |
|  |  | Percentage Change Points |  |  |
| Materials costs |  |  | (23 | ) |  |
| Other |  |  | 1 |  |  |
| Total change |  |  | (22 | ) |  |

[0001564590-19-032574:mdna:77]
Cost of product revenues represented 48% of product revenues for the first quarter of fiscal 2020, compared to 45% for the corresponding period of fiscal 2019. Materials costs represented 82% of product costs for the first quarter of fiscal 2020, compared to 87% in the corresponding period of fiscal 2019.

[0001564590-19-032574:mdna:78]
Materials costs decreased $92 million in the first quarter of fiscal 2020 compared to the corresponding period of the prior year, primarily due to a decline in product revenue and, to a lesser extent, a decline in the price of certain product components. The average unit materials costs of both All-Flash FAS and FAS Hybrid systems decreased in the first quarter of fiscal 2020 compared to the first quarter of fiscal 2019.

[0001564590-19-032574:mdna:79]
Margins on revenue recognized for strategic solutions increased slightly during the first quarter of fiscal 2020 compared to the first quarter of fiscal 2019, while margins for mature solutions decreased slightly.

[0001564590-19-032574:mdna:80]
[same as prior period, unchanged from 0001564590-19-003270:mdna:79]

[0001564590-19-032574:mdna:81]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 10 |  |  | $ | 7 |  |  |  | 43 | % |

[0001564590-19-032574:mdna:82]
Cost of software maintenance revenues in dollars were relatively flat in the first quarter of fiscal 2020 compared to the corresponding period of fiscal 2019 and represented 4% and 3% of software maintenance revenues in the current year and prior year periods, respectively.

[0001564590-19-032574:mdna:83]
[same as prior period, unchanged from 0001564590-19-003270:mdna:82]

[0001564590-19-032574:mdna:84]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 98 |  |  | $ | 106 |  |  |  | (8 | )% |

[0001564590-19-032574:mdna:85]
Cost of hardware maintenance and other services revenues decreased by $8 million, or 8%, for the first quarter of fiscal 2020 compared to the corresponding period of fiscal 2019, in line with the decrease in hardware maintenance and other services revenues. Costs represented 29% of hardware maintenance and other services revenues in both periods.

[0001564590-19-032574:mdna:86]
[same as prior period, unchanged from 0001564590-19-003270:mdna:85]

[0001564590-19-032574:mdna:87]
[same as prior period, unchanged from 0001564590-19-003270:mdna:86]

[0001564590-19-032574:mdna:88]
[same as prior period, unchanged from 0001564590-19-003270:mdna:87]

[0001564590-19-032574:mdna:89]
Total compensation costs included in operating expenses decreased by $4 million, or 1% in the first quarter of fiscal 2020, compared to the corresponding period of the prior year primarily due to lower incentive compensation expense and, to a lesser extent, the favorable impact of foreign exchange rate fluctuations, partially offset by higher salaries expense, reflecting a 2% increase in average headcount.

[0001564590-19-032574:mdna:90]
[same as prior period, unchanged from 0001564590-19-003270:mdna:91]

[0001564590-19-032574:mdna:91]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 405 |  |  | $ | 409 |  |  |  | (1 | )% |

[0001564590-19-032574:mdna:92]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, allocated facilities and information technology (IT) costs, advertising and marketing promotional expense and travel and entertainment expense.

[0001564590-19-032574:mdna:93]
Sales and marketing expenses were relatively flat in the first quarter of fiscal 2020 compared to the corresponding period of the prior year. Compensation costs decreased slightly, reflecting a 2% decrease in average headcount. Sales and marketing expenses in the first quarter of fiscal 2020 also benefitted slightly from foreign exchange rate fluctuations.

[0001564590-19-032574:mdna:94]
[same as prior period, unchanged from 0001564590-19-003270:mdna:96]

[0001564590-19-032574:mdna:95]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  | % Change |  |
| Research and development expenses |  | $ | 215 |  |  | $ | 208 |  |  |  | 3 | % |

[0001564590-19-032574:mdna:96]
[same as prior period, unchanged from 0001564590-19-003270:mdna:98]

[0001564590-19-032574:mdna:97]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2020 to Fiscal 2019 |  |  |
|  |  | Percentage Change Points |  |  |
| Compensation costs |  |  | 3 |  |  |
| Development projects and outside services |  |  | (1 | ) |  |
| Other |  |  | 1 |  |  |
| Total change |  |  | 3 |  |  |

[0001564590-19-032574:mdna:98]
The increase in compensation costs for the first quarter of fiscal 2020 compared to the corresponding period in the prior year was attributable to an increase in average headcount of 8%, resulting in higher salaries, benefits and stock-based compensation expense, partially offset by lower incentive compensation expense and, to a lesser extent, the favorable impact of foreign exchange rate fluctuations. The increase in headcount reflects our investment in additional engineering resources to support the expansion and enhancement of products and solutions targeted at our most important customer and market opportunities. Development projects and outside services expense for the first three months of fiscal 2020 decreased slightly as a result of lower spending on materials and services associated with engineering activities to develop new and enhanced products, due to the timing of new product introductions.

[0001564590-19-032574:mdna:99]
[same as prior period, unchanged from 0001564590-19-003270:mdna:101]

[0001564590-19-032574:mdna:100]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  | % Change |  |
| General and administrative expenses |  | $ | 71 |  |  | $ | 73 |  |  |  | (3 | )% |

[0001564590-19-032574:mdna:101]
[same as prior period, unchanged from 0001564590-19-003270:mdna:103]

[0001564590-19-032574:mdna:102]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2020 to Fiscal 2019 |  |  |
|  |  | Percentage Change Points |  |  |
| Compensation costs |  |  | (7 | ) |  |
| Professional and legal fees and outside services |  |  | 9 |  |  |
| Facilities and IT support costs |  |  | (4 | ) |  |
| Other |  |  | (1 | ) |  |
| Total change |  |  | (3 | ) |  |

[0001564590-19-032574:mdna:103]
All components of compensation costs decreased for the first quarter of fiscal 2020 compared to the corresponding period of the prior year. While average headcount increased in the current year period, compensation costs decreased because a greater percentage of employees were located in lower cost geographies. The increase in professional and legal fees and outside services expense in the first quarter of fiscal 2020 was primarily due to the higher spending levels on business transformation projects. The decrease in facilities and IT support costs for the first quarter of fiscal 2020 compared to the corresponding period of the prior year was primarily due to lower spending levels on IT projects.

[0001564590-19-032574:mdna:104]
[same as prior period, unchanged from 0001564590-19-003270:mdna:106]

[0001564590-19-032574:mdna:105]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  | % Change |  |
| Restructuring charges |  | $ | 21 |  |  | $ | 19 |  |  |  | 11 | % |

[0001564590-19-032574:mdna:106]
In the first quarter of fiscal 2020, we announced a restructuring plan (the May 2019 Plan) to reduce costs and redirect resources to our highest return activities, which included a reduction in our global workforce of approximately 2%. Charges related to the plan consisted primarily of employee severance-related costs. We expect to complete all activities associated with the May 2019 plan by the end of second quarter of fiscal 2020 with no significant additional charges. See Note 13 – Restructuring Charges of the Notes to Condensed Consolidated Financial Statements for more details.

[0001564590-19-032574:mdna:107]
[same as prior period, unchanged from 0001564590-19-003270:mdna:115]

[0001564590-19-032574:mdna:108]
[same as prior period, unchanged from 0001564590-19-003270:mdna:90]

[0001564590-19-032574:mdna:109]
[same as prior period, unchanged from 0001564590-19-003270:mdna:116]

[0001564590-19-032574:mdna:110]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  | % Change |  |
| Interest income |  | $ | 19 |  |  | $ | 25 |  |  |  | (24 | )% |
| Interest expense |  |  | (15 | ) |  |  | (14 | ) |  |  | 7 | % |
| Other income (expense), net |  |  | 11 |  |  |  | 7 |  |  |  | 57 | % |
| Total |  | $ | 15 |  |  | $ | 18 |  |  |  | (17 | )% |

[0001564590-19-032574:mdna:111]
Interest income decreased in the first quarter of fiscal 2020 compared to the corresponding period of the prior year due to a reduction in size of our investment portfolio as a result of our sale of approximately $1.0 billion of available-for-sale debt securities in the second half of the quarter. Other income, net increased in the first quarter of fiscal 2020 as a result of the $14 million gain we realized from the sale of these securities, partially offset by differences in foreign exchange gains and losses year-over-year. Interest expense remained relatively flat in the first quarter of fiscal 2020 compared to the corresponding period of the prior year.

[0001564590-19-032574:mdna:112]
Provision (Benefit) for Income Taxes (in millions, except percentages):

[0001564590-19-032574:mdna:113]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |  | % Change |  |
| Provision (benefit) for income taxes |  | $ | 16 |  |  | $ | (11 | ) |  |  | (245 | )% |

[0001564590-19-032574:mdna:114]
Our effective tax rate for the first quarter of fiscal 2020 was 13.4% compared to an effective tax rate of (4.0)% for the first quarter of fiscal 2019. Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rate increased for the first quarter of fiscal 2020 compared to the corresponding period of the prior year primarily due to discrete tax benefits related to the adoption of the new revenue standard in fiscal 2019 and differences in discrete benefits for stock-based compensation.

[0001564590-19-032574:mdna:115]
On December 22, 2017, the Tax Cuts and Jobs Act (“TCJA”) was enacted into law. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, the imposition of a one-time transition tax on deferred foreign earnings, and the creation of new taxes on certain foreign-sourced earnings. As of April 26, 2019, we had completed the accounting for the tax impacts of the TCJA, however, we will continue to assess the impact of further guidance from federal and state tax authorities on our business and consolidated financial statements, and recognize any adjustments in the period in which they are determined.

[0001564590-19-032574:mdna:116]
During fiscal 2019, we adopted the new revenue accounting standard and, for the three months ended July 27, 2018, we recognized a $34 million discrete tax benefit for adjustments to certain intercompany transactions resulting from the retrospective application of the new revenue accounting standard.

[0001564590-19-032574:mdna:117]
As of July 26, 2019, we had $293 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $244 million would affect our provision for income taxes if recognized, and $249 million has been recorded in other long-term liabilities.

[0001564590-19-032574:mdna:118]
[same as prior period, unchanged from 0001564590-19-003270:mdna:128]

[0001564590-19-032574:mdna:119]
[same as prior period, unchanged from 0001564590-19-003270:mdna:129]

[0001564590-19-032574:mdna:120]
| (In millions, except percentages) |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,532 |  |  | $ | 3,899 |  |
| Principal amount of debt |  | $ | 1,580 |  |  | $ | 1,799 |  |

[0001564590-19-032574:mdna:121]
[same as prior period, unchanged from 0001564590-19-003270:mdna:131]

[0001564590-19-032574:mdna:122]
|  |  | Three Months Ended |  |
| (In millions) |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Net cash provided by operating activities |  | $ | 310 |  |  | $ | 326 |  |
| Net cash provided by investing activities |  |  | 938 |  |  |  | 186 |  |
| Net cash used in financing activities |  |  | (603 | ) |  |  | (812 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (3 | ) |  |  | (14 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 642 |  |  | $ | (314 | ) |

[0001564590-19-032574:mdna:123]
[same as prior period, unchanged from 0001564590-19-003270:mdna:133]

[0001564590-19-032574:mdna:124]
As of July 26, 2019, our cash, cash equivalents and short-term investments were $3.5 billion, a decrease of $0.4 billion from April 26, 2019. The decrease was primarily due to $250 million paid for the repurchase of our common stock, $115 million used for the payment of dividends, $219 million used for the net repayment of commercial paper notes, and $32 million in purchases of property and equipment, partially offset by $310 million of cash provided by operating activities. Working capital decreased by $0.4 billion to $1.3 billion as of July 26, 2019 compared to April 26, 2019 primarily due to the decreases in cash, cash equivalents and short-term investments discussed above.

[0001564590-19-032574:mdna:125]
[same as prior period, unchanged from 0001564590-19-003270:mdna:135]

[0001564590-19-032574:mdna:126]
[same as prior period, unchanged from 0001564590-19-003270:mdna:136]

[0001564590-19-032574:mdna:127]
|  |  | Three Months Ended |  |
| (In days) |  | July 26, 2019 |  |  | April 26, 2019 |  |  | July 27, 2018 |  |
| Days sales outstanding (1) |  |  | 40 |  |  |  | 70 |  |  |  | 38 |  |
| Days inventory outstanding (2) |  |  | 25 |  |  |  | 21 |  |  |  | 17 |  |
| Days payables outstanding (3) |  |  | (75 | ) |  |  | (87 | ) |  |  | (76 | ) |
| Cash conversion cycle (4) |  |  | (10 | ) |  |  | 3 |  |  |  | (20 | ) |

[0001564590-19-032574:mdna:128]
[same as prior period, unchanged from 0001564590-19-003270:mdna:138]

[0001564590-19-032574:mdna:129]
| (1) | Days sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on ending accounts receivable and net revenue for each period. DSO is calculated by dividing accounts receivable by average net revenue per day for the current quarter (91 days for each of the quarters presented above). DSO for the first quarter of fiscal 2020 was relatively consistent with the corresponding period of fiscal 2019, while it decreased compared to the fourth quarter of fiscal 2019 due to lower seasonal invoicing levels and more favorable shipping linearity. |

[0001564590-19-032574:mdna:130]
| (2) | Days inventory outstanding, referred to as DIO, measures the average number of days from procurement to sale of our products. DIO is based on ending inventory and cost of revenues for each period. DIO is calculated by dividing ending inventory by average cost of revenues per day for the current quarter. DIO for the first quarter of fiscal 2020 increased compared to the fourth quarter of fiscal 2019 and the corresponding period of fiscal 2019, primarily due to higher levels of inventory on hand at the end of the current quarter resulting from a decline in sales towards the end of the period. |

[0001564590-19-032574:mdna:131]
| (3) | Days payables outstanding, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and cost of revenues for each period. DPO is calculated by dividing accounts payable by average cost of revenues per day for the current quarter. DPO for the first quarter of fiscal 2020 was relatively consistent with the corresponding period of fiscal 2019, while it decreased compared to the fourth quarter of 2019, primarily due to the timing of purchases from contract manufacturers. |

[0001564590-19-032574:mdna:132]
[same as prior period, unchanged from 0001564590-19-003270:mdna:142]

[0001564590-19-032574:mdna:133]
[same as prior period, unchanged from 0001564590-19-003270:mdna:143]

[0001564590-19-032574:mdna:134]
During the first three months of fiscal 2020, we generated cash from operating activities of $310 million, reflecting net income of $103 million, adjusted by non-cash depreciation and amortization of $49 million, and stock-based compensation of $42 million, compared to $326 million of cash generated from operating activities during the first three months of fiscal 2019.

[0001564590-19-032574:mdna:135]
Changes in assets and liabilities in the first three months of fiscal 2020 included the following:

[0001564590-19-032574:mdna:136]
|  | • | Accounts receivable decreased $672 million, reflecting lower DSO. |

[0001564590-19-032574:mdna:137]
|  | • | Accounts payable decreased $195 million, reflecting lower DPO. |

[0001564590-19-032574:mdna:138]
|  | • | Accrued expenses decreased $277 million, primarily due to employee compensation payouts related to fiscal year 2019 commissions and incentive compensation plans. |

[0001564590-19-032574:mdna:139]
|  | • | Deferred revenue and financed unearned services revenue decreased $154 million, primarily due to a decrease in deferred software and hardware maintenance contract revenues reflecting the seasonality of maintenance contract renewal activities. |

[0001564590-19-032574:mdna:140]
[same as prior period, unchanged from 0001564590-19-003270:mdna:151]

[0001564590-19-032574:mdna:141]
[same as prior period, unchanged from 0001564590-19-003270:mdna:152]

[0001564590-19-032574:mdna:142]
During the first three months of fiscal 2020, we generated $1.0 billion from maturities and sales of investments, net of purchases, and paid $32 million for capital expenditures, while during the first three months of fiscal 2019, we generated $248 million from maturities and sales of investments, net of purchases, and paid $64 million for capital expenditures. Additionally, during the first three months of fiscal 2020, we paid $56 million net to acquire a privately-held company.

[0001564590-19-032574:mdna:143]
[same as prior period, unchanged from 0001564590-19-003270:mdna:154]

[0001564590-19-032574:mdna:144]
During the first three months of fiscal 2020, we used $250 million for the repurchase of four million shares of our common stock, $115 million for the payment of dividends, and $219 million for the repayment of commercial paper notes, net, compared to $500 million used for the repurchase of seven million shares of common stock, $105 million used for the payment of dividends, and $185 million for the repayment of commercial paper notes, net, during the first three months of fiscal 2019.

[0001564590-19-032574:mdna:145]
[same as prior period, unchanged from 0001564590-19-003270:mdna:156]

[0001564590-19-032574:mdna:146]
[same as prior period, unchanged from 0001564590-19-003270:mdna:157]

[0001564590-19-032574:mdna:147]
Our principal sources of liquidity as of July 26, 2019 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001564590-19-032574:mdna:148]
[same as prior period, unchanged from 0001564590-19-003270:mdna:159]

[0001564590-19-032574:mdna:149]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| Cash and cash equivalents |  | $ | 2,967 |  |  | $ | 2,325 |  |
| Short-term investments |  |  | 565 |  |  |  | 1,574 |  |
| Total |  | $ | 3,532 |  |  | $ | 3,899 |  |

[0001564590-19-032574:mdna:150]
As of July 26, 2019 and April 26, 2019, $2.7 billion and $3.7 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.8 billion and $0.2 billion, respectively, were available in the U.S. at the end of each period. The TCJA imposed a one-time transition tax on substantially all accumulated foreign earnings through December 31, 2017, and generally allows companies to make distributions of foreign earnings without incurring additional federal taxes. As a part of the recognition of the impacts of the TCJA, we have reviewed our projected global cash requirements and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested.

[0001564590-19-032574:mdna:151]
[same as prior period, unchanged from 0001564590-19-003270:mdna:162]

[0001564590-19-032574:mdna:152]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of July 26, 2019.

[0001564590-19-032574:mdna:153]
[same as prior period, unchanged from 0001564590-19-003270:mdna:164]

[0001564590-19-032574:mdna:154]
[same as prior period, unchanged from 0001564590-19-003270:mdna:165]

[0001564590-19-032574:mdna:155]
The following table summarizes the principal amount of our Senior Notes as of July 26, 2019 (in millions):

[0001564590-19-032574:mdna:156]
| 2.00% Senior Notes Due September 2019 |  | $ | 400 |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| Total |  | $ | 1,550 |  |

[0001564590-19-032574:mdna:157]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 9 – Financing Arrangements of the Notes to Condensed Consolidated Financial Statements.

[0001564590-19-032574:mdna:158]
Commercial Paper Program and Credit Facility

[0001564590-19-032574:mdna:159]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of July 26, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $30 million, a weighted-average interest rate of 2.56% and a maturity of 29 days.

[0001564590-19-032574:mdna:160]
In connection with the Program, we have a senior unsecured credit agreement that expires on December 10, 2021. The credit agreement provides a $1.0 billion revolving unsecured credit facility that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes, providing another potential source of liquidity to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement also includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of July 26, 2019, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-19-032574:mdna:161]
[same as prior period, unchanged from 0001564590-19-003270:mdna:172]

[0001564590-19-032574:mdna:162]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2020 to be between $125 million and $175 million.

[0001564590-19-032574:mdna:163]
[same as prior period, unchanged from 0001564590-19-003270:mdna:174]

[0001564590-19-032574:mdna:164]
On August 14, 2019, we declared a cash dividend of $0.48 per share of common stock, payable on October 23, 2019 to holders of record as of the close of business on October 4, 2019.

[0001564590-19-032574:mdna:165]
Our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through July 26, 2019, we repurchased a total of 317 million shares of our common stock at an average price of $37.80 per share, for an aggregate purchase price of $12.0 billion. As of July 26, 2019, the remaining authorized amount for stock repurchases under this program was $1.6 billion.

[0001564590-19-032574:mdna:166]
[same as prior period, unchanged from 0001564590-19-003270:mdna:177]

[0001564590-19-032574:mdna:167]
[same as prior period, unchanged from 0001564590-19-003270:mdna:178]

[0001564590-19-032574:mdna:168]
[same as prior period, unchanged from 0001564590-19-003270:mdna:181]

[0001564590-19-032574:mdna:169]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 26, 2019, we had $392 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-19-032574:mdna:170]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of July 26, 2019, we had $9 million in construction related obligations and $235 million in other purchase obligations.

[0001564590-19-032574:mdna:171]
[same as prior period, unchanged from 0001564590-19-003270:mdna:184]

[0001564590-19-032574:mdna:172]
As of July 26, 2019, our liability for uncertain tax positions was $249 million, including interest, penalties and certain income tax benefits. Due to uncertainties regarding tax audits and their possible outcomes, we are unable to make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-19-032574:mdna:173]
[same as prior period, unchanged from 0001564590-19-003270:mdna:186]

[0001564590-19-032574:mdna:174]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $14 million and $30 million of receivables during first quarter of fiscal 2020 and fiscal 2019, respectively.

[0001564590-19-032574:mdna:175]
[same as prior period, unchanged from 0001564590-19-003270:mdna:188]

[0001564590-19-032574:mdna:176]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of July 26, 2019 and April 26, 2019, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-19-032574:mdna:177]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of July 26, 2019, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-19-032574:mdna:178]
[same as prior period, unchanged from 0001564590-19-003270:mdna:191]

[0001564590-19-032574:mdna:179]
[same as prior period, unchanged from 0001564590-19-003270:mdna:192]

[0001564590-19-032574:mdna:180]
38

[0001564590-19-032574:mdna:181]
Legal Contingencies

[0001564590-19-032574:mdna:182]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 17 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0001564590-19-032574:mdna:183]
39
