# NTAP 8-K — 0001564590-19-032131 filed 2019-08-14

## item codes, every 8-K on or before 2019-08-19

- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2019-08-19

- none on or before 2019-08-19

## item 2.02 — earnings release, exhibit 99.1

[0001564590-19-032131:8k_2_02:1]
EX-99.1
2
ntap-ex991_7.htm
EX-99.1

[0001564590-19-032131:8k_2_02:2]
ntap-ex991_7.htm

[0001564590-19-032131:8k_2_02:3]
Exhibit 99.1

[0001564590-19-032131:8k_2_02:4]
NetApp Reports First Quarter of Fiscal Year 2020 Results

[0001564590-19-032131:8k_2_02:5]
| • | NetApp Cloud Data Services annualized recurring revenue of approximately $61 million, an increase of 189% year-over-year |  |

[0001564590-19-032131:8k_2_02:6]
| • | Consolidated GAAP gross margin of 66.0%, non-GAAP gross margin of 67.2% |  |

[0001564590-19-032131:8k_2_02:7]
| • | $365 million returned to shareholders, representing 131% of free cash flow |  |

[0001564590-19-032131:8k_2_02:8]
Sunnyvale, Calif.—August 14, 2019—NetApp (NASDAQ: NTAP) today reported financial results for the first quarter of fiscal year 2020, which ended on July 26, 2019.

[0001564590-19-032131:8k_2_02:9]
“I am clearly disappointed with our Q1 top line results but remain confident in our strategy and the fundamentals of our business model. The gross margin and cost structure improvements we’ve made provide support for our free cash flow generation and enable us to navigate the ongoing macroeconomic headwinds while making the strategic moves that position us well to return to growth,” said George Kurian, chief executive officer. “We consistently receive positive feedback from our customers and partners on the value of our Data Fabric strategy and the strong performance of our best teams demonstrates our ability to capitalize on this strength.”

[0001564590-19-032131:8k_2_02:10]
First Quarter of Fiscal Year 2020 Financial Results

[0001564590-19-032131:8k_2_02:11]
| • | Net Revenues: $1.24 billion, compared to $1.47 billion* in the first quarter of fiscal 2019 |  |

[0001564590-19-032131:8k_2_02:12]
| • | Net Income: GAAP net income of $103 million, compared to GAAP net income of $283 million in the first quarter of fiscal 2019; non-GAAP net income1 of $157 million, compared to non-GAAP net income of $281 million in the first quarter of fiscal 2019 |  |

[0001564590-19-032131:8k_2_02:13]
| • | Earnings per Share: GAAP net income per share2 of $0.42 compared to GAAP net income per share of $1.05 in the first quarter of fiscal 2019; non-GAAP net income per share of $0.65, compared to non-GAAP net income per share of $1.04 in the first quarter of fiscal 2019 |  |

[0001564590-19-032131:8k_2_02:14]
| • | Cash, Cash Equivalents and Investments: $3.5 billion at the end of the first quarter of fiscal 2020 |  |

[0001564590-19-032131:8k_2_02:15]
| • | Cash from Operations: $310 million, compared to $326 million in the first quarter of fiscal 2019 |  |

[0001564590-19-032131:8k_2_02:16]
| • | Share Repurchase and Dividend: Returned $365 million to shareholders through share repurchases and cash dividends |  |

[0001564590-19-032131:8k_2_02:17]
*Net revenues in the first quarter of fiscal year 2019 included $90 million from enterprise software license agreements which did not repeat in the first quarter of fiscal year 2020.

[0001564590-19-032131:8k_2_02:18]
Second Quarter of Fiscal Year 2020 Financial Outlook

[0001564590-19-032131:8k_2_02:19]
The Company provided the following financial guidance for the second quarter of fiscal year 2020:

[0001564590-19-032131:8k_2_02:20]
| •Net revenues are expected to be in the range of: | $1.325 billion to $1.475 billion |
|  | GAAP | Non-GAAP |
| •Earnings per share is expected to be in the range of: | $0.86 - $0.94 | $0.91 - $0.99 |

[0001564590-19-032131:8k_2_02:21]
Full Fiscal Year 2020 Financial Outlook

[0001564590-19-032131:8k_2_02:22]
The Company updated the following financial guidance for the full fiscal year 2020:

[0001564590-19-032131:8k_2_02:23]
| •Net revenues are expected to decline 5% - 10% year-over-year |
|  | GAAP | Non-GAAP |
| •Consolidated gross margins are expected to be: | 65% - 66% | 66% - 67% |
| •Operating margins are expected to be in the range of: | 16% - 19% | 19% - 22% |
| •Effective tax rate is expected to be: | 19% - 20% | 18% - 19% |

[0001564590-19-032131:8k_2_02:24]
Dividend

[0001564590-19-032131:8k_2_02:25]
The next cash dividend of $0.48 per share will be paid on October 23, 2019, to shareholders of record as of the close of business on October 4, 2019.

[0001564590-19-032131:8k_2_02:26]
First Quarter of Fiscal Year 2020 Business Highlights

[0001564590-19-032131:8k_2_02:27]
Spearheading Innovation

[0001564590-19-032131:8k_2_02:28]
| • | NetApp presented a bold vision for a hybrid multicloud world, with a range of new and updated offerings: NetApp™ Kubernetes Service on NetApp HCI, Cloud Volumes on NetApp HCI, a beta release of Cloud Volumes Service for Google Cloud Platform, Cloud Volumes ONTAP™ for Google Cloud Platform, Fabric Orchestrator, new pay-per-use offerings for Cloud Consumption for NetApp HCI and Cloud Volumes Service On-Premises, NetApp Cloud Insights as a “freemium” offering, and NetApp Professional Services for the Data Fabric. |

[0001564590-19-032131:8k_2_02:29]
| • | NetApp released the NetApp AFF C190 system, a simple, smart, and secure all-flash storage solution that enables channel partners to expand their market share by helping smaller organizations modernize their IT infrastructure. |

[0001564590-19-032131:8k_2_02:30]
| • | The NetApp Cloud Tiering service is generally available now on AWS and Azure. With this service, customers can leverage the benefits of cloud economics while making space available on high-performance NetApp AFF and FAS solid-state drive systems. |

[0001564590-19-032131:8k_2_02:31]
| • | NetApp announced a new update to its growing data management software series, NetApp ONTAP 9.6. The Company also announced the new midrange, end-to-end-NVMe NetApp AFF A320 all-flash storage system and an expanded portfolio of services to help businesses maximize the value of their data and drive efficiency. |

[0001564590-19-032131:8k_2_02:32]
Expanding Partnerships

[0001564590-19-032131:8k_2_02:33]
| • | NetApp completed support for Cloud Volumes across public clouds and hybrid environments with Cloud Volumes ONTAP for Google Cloud Platform and with the general availability of Azure NetApp Files. |

[0001564590-19-032131:8k_2_02:34]
| • | NetApp announced NetApp HCI for Private Cloud with Red Hat at the Red Hat Summit, offering a modern, open-source-based, true cloud solution that works in conjunction with the Red Hat OpenStack Platform. |

[0001564590-19-032131:8k_2_02:35]
Earning Prestigious Awards

[0001564590-19-032131:8k_2_02:36]
| • | NetApp continues to grow its reputation as a data authority, receiving the AIconics award for Corporate Innovation in AI and earning the AI Breakthrough award for the Best AI Solution for Big Data. |

[0001564590-19-032131:8k_2_02:37]
Webcast and Conference Call Information

[0001564590-19-032131:8k_2_02:38]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today.

[0001564590-19-032131:8k_2_02:39]
About NetApp

[0001564590-19-032131:8k_2_02:40]
NetApp is the data authority for hybrid cloud. We provide a full range of hybrid cloud data services that simplify management of applications and data across cloud and on-premises environments to accelerate digital transformation. Together with our partners, we empower global organizations to unleash the full potential of their data to expand customer touchpoints, foster greater innovation, and optimize their operations. For more information, visit www.netapp.com. #DataDriven

[0001564590-19-032131:8k_2_02:41]
“Risk Factors” in our most recently submitted annual report on Form 10-K. We disclaim any obligation to update information contained in this press release whether as a result of new information, future events, or otherwise.

[0001564590-19-032131:8k_2_02:42]
###

[0001564590-19-032131:8k_2_02:43]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-19-032131:8k_2_02:44]
Footnotes

[0001564590-19-032131:8k_2_02:45]
1Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, and (h) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-19-032131:8k_2_02:46]
2GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0001564590-19-032131:8k_2_02:47]
NetApp Usage of Non-GAAP Financial Information

[0001564590-19-032131:8k_2_02:48]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-19-032131:8k_2_02:49]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-19-032131:8k_2_02:50]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2)

[0001564590-19-032131:8k_2_02:51]
facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-19-032131:8k_2_02:52]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-19-032131:8k_2_02:53]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-19-032131:8k_2_02:54]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-19-032131:8k_2_02:55]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-19-032131:8k_2_02:56]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-19-032131:8k_2_02:57]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-19-032131:8k_2_02:58]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-19-032131:8k_2_02:59]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-19-032131:8k_2_02:60]
H. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a

[0001564590-19-032131:8k_2_02:61]
non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual properties from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-19-032131:8k_2_02:62]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-19-032131:8k_2_02:63]
NETAPP, INC.

[0001564590-19-032131:8k_2_02:64]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-19-032131:8k_2_02:65]
(In millions)

[0001564590-19-032131:8k_2_02:66]
(Unaudited)

[0001564590-19-032131:8k_2_02:67]
|  |  | July 26, 2019 |  |  | April 26, 2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,532 |  |  | $ | 3,899 |  |
| Accounts receivable |  |  | 542 |  |  |  | 1,216 |  |
| Inventories |  |  | 116 |  |  |  | 131 |  |
| Other current assets |  |  | 326 |  |  |  | 364 |  |
| Total current assets |  |  | 4,516 |  |  |  | 5,610 |  |
| Property and equipment, net |  |  | 754 |  |  |  | 759 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,832 |  |  |  | 1,782 |  |
| Other non-current assets |  |  | 709 |  |  |  | 590 |  |
| Total assets |  | $ | 7,811 |  |  | $ | 8,741 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 348 |  |  | $ | 542 |  |
| Accrued expenses |  |  | 633 |  |  |  | 851 |  |
| Commercial paper notes |  |  | 30 |  |  |  | 249 |  |
| Current portion of long-term debt |  |  | 400 |  |  |  | 400 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,764 |  |  |  | 1,825 |  |
| Total current liabilities |  |  | 3,175 |  |  |  | 3,867 |  |
| Long-term debt |  |  | 1,145 |  |  |  | 1,144 |  |
| Other long-term liabilities |  |  | 882 |  |  |  | 797 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,746 |  |  |  | 1,843 |  |
| Total liabilities |  |  | 6,948 |  |  |  | 7,651 |  |
| Stockholders' equity |  |  | 863 |  |  |  | 1,090 |  |
| Total liabilities and stockholders' equity |  | $ | 7,811 |  |  | $ | 8,741 |  |

[0001564590-19-032131:8k_2_02:68]
NETAPP, INC.

[0001564590-19-032131:8k_2_02:69]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-19-032131:8k_2_02:70]
(In millions, except per share amounts)

[0001564590-19-032131:8k_2_02:71]
(Unaudited)

[0001564590-19-032131:8k_2_02:72]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Product |  | $ | 644 |  |  | $ | 875 |  |
| Software maintenance |  |  | 250 |  |  |  | 229 |  |
| Hardware maintenance and other services |  |  | 342 |  |  |  | 370 |  |
| Net revenues |  |  | 1,236 |  |  |  | 1,474 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 312 |  |  |  | 398 |  |
| Cost of software maintenance |  |  | 10 |  |  |  | 7 |  |
| Cost of hardware maintenance and other services |  |  | 98 |  |  |  | 106 |  |
| Total cost of revenues |  |  | 420 |  |  |  | 511 |  |
| Gross profit |  |  | 816 |  |  |  | 963 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 405 |  |  |  | 409 |  |
| Research and development |  |  | 215 |  |  |  | 208 |  |
| General and administrative |  |  | 71 |  |  |  | 73 |  |
| Restructuring charges |  |  | 21 |  |  |  | 19 |  |
| Total operating expenses |  |  | 712 |  |  |  | 709 |  |
| Income from operations |  |  | 104 |  |  |  | 254 |  |
| Other income, net |  |  | 15 |  |  |  | 18 |  |
| Income before income taxes |  |  | 119 |  |  |  | 272 |  |
| Provision (benefit) for income taxes |  |  | 16 |  |  |  | (11 | ) |
| Net income |  | $ | 103 |  |  | $ | 283 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.43 |  |  | $ | 1.08 |  |
| Diluted |  | $ | 0.42 |  |  | $ | 1.05 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |
| Basic |  |  | 239 |  |  |  | 262 |  |
| Diluted |  |  | 243 |  |  |  | 269 |  |
| Cash dividends declared per share |  | $ | 0.48 |  |  | $ | 0.40 |  |

[0001564590-19-032131:8k_2_02:73]
NETAPP, INC.

[0001564590-19-032131:8k_2_02:74]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-19-032131:8k_2_02:75]
(In millions)

[0001564590-19-032131:8k_2_02:76]
|  |  | Three Months Ended |  |
|  |  | July 26, 2019 |  |  | July 27, 2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 103 |  |  | $ | 283 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 49 |  |  |  | 49 |  |
| Stock-based compensation |  |  | 42 |  |  |  | 40 |  |
| Deferred income taxes |  |  | (7 | ) |  |  | (26 | ) |
| Other items, net |  |  | 6 |  |  |  | 8 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 672 |  |  |  | 423 |  |
| Inventories |  |  | 15 |  |  |  | 25 |  |
| Accounts payable |  |  | (195 | ) |  |  | (177 | ) |
| Accrued expenses |  |  | (277 | ) |  |  | (221 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (154 | ) |  |  | (87 | ) |
| Long-term taxes payable |  |  | (3 | ) |  |  | 5 |  |
| Changes in other operating assets and liabilities, net |  |  | 59 |  |  |  | 4 |  |
| Net cash provided by operating activities |  |  | 310 |  |  |  | 326 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 1,027 |  |  |  | 248 |  |
| Purchases of property and equipment |  |  | (32 | ) |  |  | (64 | ) |
| Acquisitions of businesses, net of cash acquired |  |  | (56 | ) |  |  | — |  |
| Other investing activities, net |  |  | (1 | ) |  |  | 2 |  |
| Net cash provided by investing activities |  |  | 938 |  |  |  | 186 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 54 |  |  |  | 63 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (71 | ) |  |  | (84 | ) |
| Repurchase of common stock |  |  | (250 | ) |  |  | (500 | ) |
| Repayments of commercial paper notes, net |  |  | (219 | ) |  |  | (185 | ) |
| Dividends paid |  |  | (115 | ) |  |  | (105 | ) |
| Other financing activities, net |  |  | (2 | ) |  |  | (1 | ) |
| Net cash used in financing activities |  |  | (603 | ) |  |  | (812 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (3 | ) |  |  | (14 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | 642 |  |  |  | (314 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,331 |  |  |  | 2,947 |  |
| End of period |  | $ | 2,973 |  |  | $ | 2,633 |  |

[0001564590-19-032131:8k_2_02:77]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q1 FY'20 |  |  | Q4 FY'19 |  |  | Q1 FY'19 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 644 |  |  | $ | 1,000 |  |  | $ | 875 |  |
| Strategic* |  | $ | 337 |  |  | $ | 623 |  |  | $ | 475 |  |
| Mature* |  | $ | 307 |  |  | $ | 377 |  |  | $ | 400 |  |
| Software Maintenance |  | $ | 250 |  |  | $ | 242 |  |  | $ | 229 |  |
| Hardware Maintenance and Other Services |  | $ | 342 |  |  | $ | 350 |  |  | $ | 370 |  |
| Hardware Maintenance Support Contracts |  | $ | 284 |  |  | $ | 284 |  |  | $ | 303 |  |
| Professional and Other Services |  | $ | 58 |  |  | $ | 66 |  |  | $ | 67 |  |
| Net Revenues |  | $ | 1,236 |  |  | $ | 1,592 |  |  | $ | 1,474 |  |
| * In Q1 FY’20 we made changes to the products and solutions contained in each of the Strategic and Mature product groupings. Mature now includes OEM and all products related to disk and hybrid arrays. Strategic now includes add-on software, private cloud solutions, and all products related to All-Flash Arrays. Revenues for previous quarters have been recast in accordance with the revised product grouping methodology for comparability. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'20 Revenue |  |  | % of Q4 FY'19 Revenue |  |  | % of Q1 FY'19 Revenue |  |
| Americas |  |  | 51 | % |  |  | 57 | % |  |  | 57 | % |
| Americas Commercial |  |  | 38 | % |  |  | 45 | % |  |  | 46 | % |
| U.S. Public Sector |  |  | 13 | % |  |  | 11 | % |  |  | 11 | % |
| EMEA |  |  | 33 | % |  |  | 29 | % |  |  | 29 | % |
| Asia Pacific |  |  | 16 | % |  |  | 14 | % |  |  | 14 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'20 Revenue |  |  | % of Q4 FY'19 Revenue |  |  | % of Q1 FY'19 Revenue |  |
| Direct |  |  | 19 | % |  |  | 24 | % |  |  | 29 | % |
| Indirect |  |  | 81 | % |  |  | 76 | % |  |  | 71 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'20 |  |  | Q4 FY'19 |  |  | Q1 FY'19 |  |
| Non-GAAP Gross Margin |  |  | 67.2 | % |  |  | 65.2 | % |  |  | 66.2 | % |
| Product |  |  | 53.4 | % |  |  | 55.3 | % |  |  | 55.7 | % |
| Software Maintenance |  |  | 96.0 | % |  |  | 95.9 | % |  |  | 96.9 | % |
| Hardware Maintenance and Other Services |  |  | 71.9 | % |  |  | 72.3 | % |  |  | 72.2 | % |

[0001564590-19-032131:8k_2_02:78]
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'20 |  |  | Q4 FY'19 |  |  | Q1 FY'19 |  |
| Non-GAAP Income from Operations |  | $ | 178 |  |  | $ | 358 |  |  | $ | 326 |  |
| % of Net Revenues |  |  | 14.4 | % |  |  | 22.5 | % |  |  | 22.1 | % |
| Non-GAAP Income before Income Taxes |  | $ | 193 |  |  | $ | 372 |  |  | $ | 344 |  |
| Non-GAAP Effective Tax Rate |  |  | 18.7 | % |  |  | 18.1 | % |  |  | 18.3 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'20 |  |  | Q4 FY'19 |  |  | Q1 FY'19 |  |
| Non-GAAP Net Income |  | $ | 157 |  |  | $ | 305 |  |  | $ | 281 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 243 |  |  |  | 249 |  |  |  | 269 |  |
| Non-GAAP Income per Share, Diluted |  | $ | 0.65 |  |  | $ | 1.22 |  |  | $ | 1.04 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'20 |  |  | Q4 FY'19 |  |  | Q1 FY'19 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,510 |  |  | $ | 3,668 |  |  | $ | 3,260 |  |
| DSO (days) |  |  | 40 |  |  |  | 70 |  |  |  | 38 |  |
| DIO (days) |  |  | 25 |  |  |  | 21 |  |  |  | 17 |  |
| DPO (days) |  |  | 75 |  |  |  | 87 |  |  |  | 76 |  |
| CCC (days) |  |  | (10 | ) |  |  | 3 |  |  |  | (20 | ) |
| Inventory Turns |  |  | 14 |  |  |  | 17 |  |  |  | 21 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'20 |  |  | Q4 FY'19 |  |  | Q1 FY'19 |  |
| Net Cash Provided by Operating Activities |  | $ | 310 |  |  | $ | 399 |  |  | $ | 326 |  |
| Purchases of Property and Equipment |  | $ | 32 |  |  | $ | 35 |  |  | $ | 64 |  |
| Free Cash Flow |  | $ | 278 |  |  | $ | 364 |  |  | $ | 262 |  |
| Free Cash Flow as a % of Net Revenues |  |  | 22.5 | % |  |  | 22.9 | % |  |  | 17.8 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001564590-19-032131:8k_2_02:79]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY20 |  |  | Q4'FY19 |  |  | Q1'FY19 |  |
| NET INCOME |  | $ | 103 |  |  | $ | 396 |  |  | $ | 283 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 8 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 42 |  |  |  | 37 |  |  |  | 40 |  |
| Restructuring charges |  |  | 21 |  |  |  | 16 |  |  |  | 19 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (73 | ) |  |  | — |  |
| Income tax effects |  |  | (20 | ) |  |  | (31 | ) |  |  | (40 | ) |
| Resolution of income tax examinations |  |  | — |  |  |  | (48 | ) |  |  | — |  |
| Income tax benefit of ASC 606 adoption |  |  | — |  |  |  | — |  |  |  | (34 | ) |
| NON-GAAP NET INCOME |  | $ | 157 |  |  | $ | 305 |  |  | $ | 281 |  |
| COST OF REVENUES |  | $ | 420 |  |  | $ | 566 |  |  | $ | 511 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (11 | ) |  |  | (8 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (4 | ) |  |  | (4 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 406 |  |  | $ | 554 |  |  | $ | 498 |  |
| COST OF PRODUCT REVENUES |  | $ | 312 |  |  | $ | 457 |  |  | $ | 398 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (11 | ) |  |  | (8 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (2 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 300 |  |  | $ | 447 |  |  | $ | 388 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 98 |  |  | $ | 99 |  |  | $ | 106 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (2 | ) |  |  | (3 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 96 |  |  | $ | 97 |  |  | $ | 103 |  |
| GROSS PROFIT |  | $ | 816 |  |  | $ | 1,026 |  |  | $ | 963 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 8 |  |  |  | 9 |  |
| Stock-based compensation |  |  | 3 |  |  |  | 4 |  |  |  | 4 |  |
| NON-GAAP GROSS PROFIT |  | $ | 830 |  |  | $ | 1,038 |  |  | $ | 976 |  |

[0001564590-19-032131:8k_2_02:80]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY20 |  |  | Q4'FY19 |  |  | Q1'FY19 |  |
| SALES AND MARKETING EXPENSES |  | $ | 405 |  |  | $ | 439 |  |  | $ | 409 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | — |  |  |  | (4 | ) |
| Stock-based compensation |  |  | (18 | ) |  |  | (15 | ) |  |  | (17 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 387 |  |  | $ | 424 |  |  | $ | 388 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 215 |  |  | $ | 205 |  |  | $ | 208 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (15 | ) |  |  | (11 | ) |  |  | (12 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 200 |  |  | $ | 194 |  |  | $ | 196 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 71 |  |  | $ | 69 |  |  | $ | 73 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (6 | ) |  |  | (7 | ) |  |  | (7 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 65 |  |  | $ | 62 |  |  | $ | 66 |  |
| RESTRUCTURING CHARGES |  | $ | 21 |  |  | $ | 16 |  |  | $ | 19 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (21 | ) |  |  | (16 | ) |  |  | (19 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  |  | $ | (73 | ) |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | 73 |  |  |  | — |  |
| NON-GAAP GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 712 |  |  | $ | 656 |  |  | $ | 709 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | — |  |  |  | (4 | ) |
| Stock-based compensation |  |  | (39 | ) |  |  | (33 | ) |  |  | (36 | ) |
| Restructuring charges |  |  | (21 | ) |  |  | (16 | ) |  |  | (19 | ) |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | 73 |  |  |  | — |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 652 |  |  | $ | 680 |  |  | $ | 650 |  |

[0001564590-19-032131:8k_2_02:81]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY20 |  |  | Q4'FY19 |  |  | Q1'FY19 |  |
| INCOME FROM OPERATIONS |  | $ | 104 |  |  | $ | 370 |  |  | $ | 254 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 8 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 42 |  |  |  | 37 |  |  |  | 40 |  |
| Restructuring charges |  |  | 21 |  |  |  | 16 |  |  |  | 19 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (73 | ) |  |  | — |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 178 |  |  | $ | 358 |  |  | $ | 326 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 119 |  |  | $ | 384 |  |  | $ | 272 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 8 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 42 |  |  |  | 37 |  |  |  | 40 |  |
| Restructuring charges |  |  | 21 |  |  |  | 16 |  |  |  | 19 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (73 | ) |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 193 |  |  | $ | 372 |  |  | $ | 344 |  |
| PROVISION (BENEFIT) FOR INCOME TAXES |  | $ | 16 |  |  | $ | (12 | ) |  | $ | (11 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 20 |  |  |  | 31 |  |  |  | 40 |  |
| Resolution of income tax examinations |  |  | — |  |  |  | 48 |  |  |  | — |  |
| Income tax benefit of ASC 606 adoption |  |  | — |  |  |  | — |  |  |  | 34 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 36 |  |  | $ | 67 |  |  | $ | 63 |  |
| NET INCOME PER SHARE |  | $ | 0.42 |  |  | $ | 1.59 |  |  | $ | 1.05 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  |  | 0.03 |  |  |  | 0.05 |  |
| Stock-based compensation |  |  | 0.17 |  |  |  | 0.15 |  |  |  | 0.15 |  |
| Restructuring charges |  |  | 0.09 |  |  |  | 0.06 |  |  |  | 0.07 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (0.29 | ) |  |  | — |  |
| Income tax effects |  |  | (0.08 | ) |  |  | (0.12 | ) |  |  | (0.15 | ) |
| Resolution of income tax examinations |  |  | — |  |  |  | (0.19 | ) |  |  | — |  |
| Income tax benefit of ASC 606 adoption |  |  | — |  |  |  | — |  |  |  | (0.13 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.65 |  |  | $ | 1.22 |  |  | $ | 1.04 |  |

[0001564590-19-032131:8k_2_02:82]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY20 |  |  | Q4'FY19 |  |  | Q1'FY19 |  |
| Gross margin-GAAP |  |  | 66.0 | % |  |  | 64.4 | % |  |  | 65.3 | % |
| Cost of revenues adjustments |  |  | 1.1 | % |  |  | 0.8 | % |  |  | 0.9 | % |
| Gross margin-Non-GAAP |  |  | 67.2 | % |  |  | 65.2 | % |  |  | 66.2 | % |
| GAAP cost of revenues |  | $ | 420 |  |  | $ | 566 |  |  | $ | 511 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (11 | ) |  |  | (8 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (4 | ) |  |  | (4 | ) |
| Non-GAAP cost of revenues |  | $ | 406 |  |  | $ | 554 |  |  | $ | 498 |  |
| Net revenues |  | $ | 1,236 |  |  | $ | 1,592 |  |  | $ | 1,474 |  |

[0001564590-19-032131:8k_2_02:83]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY20 |  |  | Q4'FY19 |  |  | Q1'FY19 |  |
| Product gross margin-GAAP |  |  | 51.6 | % |  |  | 54.3 | % |  |  | 54.5 | % |
| Cost of product revenues adjustments |  |  | 1.9 | % |  |  | 1.0 | % |  |  | 1.1 | % |
| Product gross margin-Non-GAAP |  |  | 53.4 | % |  |  | 55.3 | % |  |  | 55.7 | % |
| GAAP cost of product revenues |  | $ | 312 |  |  | $ | 457 |  |  | $ | 398 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (11 | ) |  |  | (8 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (2 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 300 |  |  | $ | 447 |  |  | $ | 388 |  |
| Product revenues |  | $ | 644 |  |  | $ | 1,000 |  |  | $ | 875 |  |

[0001564590-19-032131:8k_2_02:84]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY20 |  |  | Q4'FY19 |  |  | Q1'FY19 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 71.3 | % |  |  | 71.7 | % |  |  | 71.4 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.6 | % |  |  | 0.6 | % |  |  | 0.8 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 71.9 | % |  |  | 72.3 | % |  |  | 72.2 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 98 |  |  | $ | 99 |  |  | $ | 106 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (2 | ) |  |  | (3 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 96 |  |  | $ | 97 |  |  | $ | 103 |  |
| Hardware maintenance and other services revenues |  | $ | 342 |  |  | $ | 350 |  |  | $ | 370 |  |

[0001564590-19-032131:8k_2_02:85]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q1'FY20 |  |  | Q4'FY19 |  |  | Q1'FY19 |  |
| GAAP effective tax rate |  |  | 13.4 | % |  |  | (3.1 | )% |  |  | (4.0 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 5.3 | % |  |  | 8.3 | % |  |  | 9.8 | % |
| Resolution of income tax examinations |  |  | — | % |  |  | 12.9 | % |  |  | — | % |
| Income tax benefit of ASC 606 adoption |  |  | — | % |  |  | — | % |  |  | 12.5 | % |
| Non-GAAP effective tax rate |  |  | 18.7 | % |  |  | 18.1 | % |  |  | 18.3 | % |

[0001564590-19-032131:8k_2_02:86]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY20 |  |  | Q4'FY19 |  |  | Q1'FY19 |  |
| Net cash provided by operating activities |  | $ | 310 |  |  | $ | 399 |  |  | $ | 326 |  |
| Purchases of property and equipment |  |  | (32 | ) |  |  | (35 | ) |  |  | (64 | ) |
| Free cash flow |  | $ | 278 |  |  | $ | 364 |  |  | $ | 262 |  |

[0001564590-19-032131:8k_2_02:87]
Some items may not add or recalculate due to rounding.

[0001564590-19-032131:8k_2_02:88]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| SECOND QUARTER FISCAL 2020 |  |
|  |  | Second Quarter |  |
|  |  | Fiscal 2020 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $0.91 - $0.99 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Second Quarter Fiscal 2020: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.05 | ) |
| Stock-based compensation expense |  |  | (0.17 | ) |
| Gain on sale or derecognition of assets |  |  | 0.17 |  |
| Total Adjustments |  |  | (0.05 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.86 - $0.94 |  |

[0001564590-19-032131:8k_2_02:89]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| FISCAL 2020 |  |
| (Unaudited) |  |
|  |  | GROSS MARGIN |  |
| Gross Margin - Non-GAAP Guidance |  | 66% - 67% |  |
| Adjustment: |  |  |  |  |
| Cost of revenues adjustments |  | (1)% |  |
| Gross Margin - GAAP Guidance |  | 65% - 66% |  |
|  |  | OPERATING MARGIN |  |
| Operating Margin - Non-GAAP Guidance |  | 19% - 22% |  |
| Adjustments: |  |  |  |  |
| Amortization of intangible assets |  | (1)% |  |
| Stock-based compensation expense |  | (3)% |  |
| Gain on sale or derecognition of assets |  | 1% |  |
| Operating Margin - GAAP Guidance |  | 16% - 19% |  |
|  |  | EFFECTIVE TAX RATE |  |
| Effective Tax Rate - Non-GAAP Guidance |  | 18% - 19% |  |
| Adjustment: |  |  |  |  |
| Income tax effects |  | 1% |  |
| Effective Tax Rate - GAAP Guidance |  | 19% - 20% |  |
| Some items may not add or recalculate due to rounding |  |  |  |  |

[0001564590-19-032131:8k_2_02:90]
Press Contact:

[0001564590-19-032131:8k_2_02:91]
Amelia Vierra

[0001564590-19-032131:8k_2_02:92]
NetApp

[0001564590-19-032131:8k_2_02:93]
1 408 822 6403

[0001564590-19-032131:8k_2_02:94]
amelia.vierra@netapp.com

[0001564590-19-032131:8k_2_02:95]
Investor Contact:

[0001564590-19-032131:8k_2_02:96]
Lance Berger

[0001564590-19-032131:8k_2_02:97]
NetApp

[0001564590-19-032131:8k_2_02:98]
1 408 822 6628

[0001564590-19-032131:8k_2_02:99]
lance.berger@netapp.com

## item 5.02 — body, verbatim

[0001564590-19-032131:8k_body:1]
Item 5.02     Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001564590-19-032131:8k_body:2]
(b), (c), (e)

[0001564590-19-032131:8k_body:3]
Retirement of Named Executive Officer

[0001564590-19-032131:8k_body:4]
On August 14, 2019, NetApp, Inc. (the “Company”) announced Joel Reich’s retirement from his position as Executive Vice President and General Manager, NetApp Storage Systems and Software Business Unit, effective immediately. Mr. Reich will remain an employee of the Company until August 16, 2019.

[0001564590-19-032131:8k_body:5]
On August 8, 2019, the Compensation Committee (the “Committee”) of the Board of Directors (the “Board”) of the Company approved the terms of a separation and release agreement with Mr. Reich (the “Separation Agreement”). The Separation Agreement, upon becoming effective, provides for (i) release of all claims by Mr. Reich in favor of the Company; (ii) a payment to Mr. Reich of $262,000 and (iii) assumption by the Company of the lease for property in Sunnyvale, California for which the Company previously reimbursed Mr. Reich for the rental payments and expenses. Mr. Reich is eligible for pro rata vesting of his outstanding performance-based restricted stock units in accordance with the terms of the applicable grant agreements. He is also eligible to participate in the Company’s Executive Retiree Health Plan in accordance with the terms and conditions of the plan.

[0001564590-19-032131:8k_body:6]
The foregoing summary of the Separation Agreement does not purport to be complete and is qualified in its entirety by the full text of the Separation Agreement, a copy of which will be filed with the Company’s Quarterly Report on Form 10-Q for the quarter ending October 25, 2019.

[0001564590-19-032131:8k_body:7]
Appointment of Named Executive Officers

[0001564590-19-032131:8k_body:8]
On August 14, 2019, the Company announced the promotions, effective August 14, 2019, of Brad R. Anderson as Executive Vice President, Storage Systems and Software Business Unit and Cloud Infrastructure Business Unit and Scott R. Allen, as Senior Vice President, Chief Accounting Officer. Effective August 14, 2019, Mr. Allen will be the principal accounting officer of the Company.

[0001564590-19-032131:8k_body:9]
Mr. Anderson, 60, served as Senior Vice President and General Manager, NetApp Cloud Infrastructure Business Unit prior to his promotion. Before joining the Company, Mr. Anderson served as president and chief operating office of Gravitant, a cloud service brokerage platform company. Mr. Anderson also spent seven years as president and general manager of Dell’s Enterprise Solution Group, leading servers, storage, networking and software businesses. Prior to Dell, he spent nine years at HP Compaq as the senior vice president and GM of Industry Standard Servers. Mr. Anderson holds a Bachelor of Science degree in petroleum engineering from Texas A&M University and an MBA from Harvard Business School.

[0001564590-19-032131:8k_body:10]
Prior to his promotion, Mr. Allen, 51, served as Vice President, Tax & Treasury and Vice President, Corporate Controller. Mr. Allen was previously employed by Ryder System, Inc., where he served as chief accounting officer and vice president, controller. Mr. Allen was previously employed by Altera Corporation where he most recently served as vice president, business finance and financial planning & analysis. Prior to Altera, Mr. Allen served in a variety of finance roles at GE, KB Toys and Dominion. He was also senior audit manager with Ernst & Young LLP. Mr. Allen holds a BBA degree in accounting from Siena College.

[0001564590-19-032131:8k_body:11]
Neither Mr. Anderson nor Mr. Allen have a family relationship with any of the officers or directors of the Company.

[0001564590-19-032131:8k_body:12]
There were no understandings or arrangements between Mr. Anderson or Mr. Allen and any other person pursuant to which they were selected as an officer of the Company. There are no related party transactions reportable under Item 5.02 of Current Report on Form 8-K and Item 404(a) of Regulation S-K.

[0001564590-19-032131:8k_body:13]
Compensatory Arrangements

[0001564590-19-032131:8k_body:14]
The material terms of the compensation, as approved by the Committee, for each of Mr. Anderson and Mr. Allen in connection with their respective promotions, are as follows:

[0001564590-19-032131:8k_body:15]
Named Executive Officer

[0001564590-19-032131:8k_body:16]
Salary

[0001564590-19-032131:8k_body:17]
Target Incentive Compensation Award(1)

[0001564590-19-032131:8k_body:18]
Promotion Equity Award

[0001564590-19-032131:8k_body:19]
Brad R. Anderson

[0001564590-19-032131:8k_body:20]
$550,000

[0001564590-19-032131:8k_body:21]
110%

[0001564590-19-032131:8k_body:22]
Restricted stock units (“RSUs”) equal to $400,000 in value, based on the 60-day trailing average on or about the grant date, vesting 25% annually over 4 years. The RSUs will be granted pursuant to the form of RSU Agreement previously approved by the Committee.

[0001564590-19-032131:8k_body:23]
Performance based restricted stock units (“PBRSUs”) equal to $600,000 in value, based on the 60-day trailing average on or about the grant date and a vesting commencement date of June 1, 2019.  The PBRSUs vest in accordance with the terms and conditions of the two form PBRSU Agreements (50% based on one form and 50% based on the other form) previously approved by the Committee.

[0001564590-19-032131:8k_body:24]
Scott R. Allen

[0001564590-19-032131:8k_body:25]
$455,000

[0001564590-19-032131:8k_body:26]
80%

[0001564590-19-032131:8k_body:27]
RSUs equal to $263,000 in value, based on the 60-day trailing average on or about the grant date, vesting 25% annually over 4 years. The RSUs will be granted pursuant to the form of RSU Agreement previously approved by the Committee.

[0001564590-19-032131:8k_body:28]
(1)

[0001564590-19-032131:8k_body:29]
Expressed as a target percentage of base salary.  Incentive compensation for the Company’s named executive officers will be

[0001564590-19-032131:8k_body:30]
established pursuant and subject to the terms of the Company’s Executive Compensation Plan.

[0001564590-19-032131:8k_body:31]
Messrs. Anderson and Allen will also be eligible to participate in certain compensation and benefit programs available to the Company’s executive officers.
