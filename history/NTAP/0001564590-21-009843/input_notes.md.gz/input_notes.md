# NTAP notes — 0001564590-21-009843


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-21-009843:notes:1]
[same as prior period, unchanged from 0001564590-20-056069:notes:1]

[0001564590-21-009843:notes:2]
[same as prior period, unchanged from 0001564590-20-056069:notes:2]

[0001564590-21-009843:notes:3]
[same as prior period, unchanged from 0001564590-20-056069:notes:3]

[0001564590-21-009843:notes:4]
[same as prior period, unchanged from 0001564590-20-056069:notes:4]

[0001564590-21-009843:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2020 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 29, 2021 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-21-009843:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates. Management’s estimates include, as applicable, the anticipated impacts of the COVID-19 pandemic.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-21-009843:notes:7]
2. Recently Adopted Accounting Standards

[0001564590-21-009843:notes:8]
In June 2016, the FASB issued an accounting standards update on the measurement of credit losses on financial instruments. The standard introduces a new model for measuring and recognizing credit losses on financial instruments, requiring financial assets measured at amortized cost basis to be presented at the net amount expected to be collected. It also requires that credit losses be recorded through an allowance for credit losses. On April 25, 2020, we adopted the standard with no material impact to our condensed consolidated financial statements.

[0001564590-21-009843:notes:9]
There have been no other significant changes in our significant accounting policies as of and for the nine months ended January 29, 2021, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 24, 2020.

[0001564590-21-009843:notes:10]
Recent accounting pronouncements pending adoption not discussed are either not applicable or will not have or are not expected to have a material impact on our consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-21-009843:notes:11]
[same as prior period, unchanged from 0001564590-20-056069:notes:11]

[0001564590-21-009843:notes:12]
[same as prior period, unchanged from 0001564590-20-056069:notes:12]

[0001564590-21-009843:notes:13]
[same as prior period, unchanged from 0001564590-20-056069:notes:13]

[0001564590-21-009843:notes:14]
[same as prior period, unchanged from 0001564590-20-056069:notes:14]

[0001564590-21-009843:notes:15]
|  |  | Amount |  |
| Developed technology |  | $ | 16 |  |
| Customer contracts/relationships |  |  | 6 |  |
| Goodwill |  |  | 12 |  |
| Other assets |  |  | 1 |  |
| Total assets acquired |  |  | 35 |  |
| Liabilities assumed |  |  | (1 | ) |
| Total purchase price |  | $ | 34 |  |

[0001564590-21-009843:notes:16]
[same as prior period, unchanged from 0001564590-20-056069:notes:16]

[0001564590-21-009843:notes:17]
[same as prior period, unchanged from 0001564590-20-056069:notes:17]

[0001564590-21-009843:notes:18]
|  |  | Amount |  |
| Cash |  | $ | 24 |  |
| Intangible assets |  |  | 84 |  |
| Goodwill |  |  | 249 |  |
| Other assets |  |  | 6 |  |
| Total assets acquired |  |  | 363 |  |
| Liabilities assumed |  |  | (23 | ) |
| Total purchase price |  | $ | 340 |  |

[0001564590-21-009843:notes:19]
[same as prior period, unchanged from 0001564590-20-056069:notes:19]

[0001564590-21-009843:notes:20]
|  |  | Amount |  |  | Estimated useful life (years) |
| Developed technology |  | $ | 53 |  |  | 5 |
| Customer contracts/relationships |  |  | 28 |  |  | 5 |
| Trade name |  |  | 3 |  |  | 3 |
| Total intangible assets |  | $ | 84 |  |  |  |

[0001564590-21-009843:notes:21]
The acquired assets and assumed liabilities of Spot and Cloud Jumper were recorded at their estimated fair values. We determined the estimated fair values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expect to realize revenue synergies, leverage and expand the existing Spot and Cloud Jumper sales channels and product development resources, and utilize their existing workforces. We also anticipate opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated fair value of their identifiable net assets acquired, and as a result, we have recorded goodwill in connection with both of these acquisitions. The goodwill is not deductible for income tax purposes.

[0001564590-21-009843:notes:22]
The results of operations related to the acquisition of both Spot and Cloud Jumper have been included in our condensed consolidated statements of operations from their respective acquisition dates. Pro forma results of operations have not been presented because the impact from these acquisitions would not have been material to our consolidated results of operations for each of the three and nine months ended January 29, 2021 and January 24, 2020.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-21-009843:notes:23]
[same as prior period, unchanged from 0001564590-20-056069:notes:24]

[0001564590-21-009843:notes:24]
[same as prior period, unchanged from 0001564590-20-056069:notes:25]

[0001564590-21-009843:notes:25]
|  |  | Amount |  |
| Balance as of April 24, 2020 |  | $ | 1,778 |  |
| Additions |  |  | 261 |  |
| Balance as of January 29, 2021 |  | $ | 2,039 |  |

[0001564590-21-009843:notes:26]
[same as prior period, unchanged from 0001564590-20-056069:notes:27]

[0001564590-21-009843:notes:27]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 215 |  |  | $ | (140 | ) |  | $ | 75 |  |  | $ | 192 |  |  | $ | (152 | ) |  | $ | 40 |  |
| Customer contracts/relationships |  |  | 38 |  |  |  | (6 | ) |  |  | 32 |  |  |  | 4 |  |  |  | — |  |  |  | 4 |  |
| Other purchased intangibles |  |  | 3 |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total purchased intangible assets |  | $ | 256 |  |  | $ | (146 | ) |  | $ | 110 |  |  | $ | 196 |  |  | $ | (152 | ) |  | $ | 44 |  |

[0001564590-21-009843:notes:28]
[same as prior period, unchanged from 0001564590-20-056069:notes:29]

[0001564590-21-009843:notes:29]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Statements of |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | Operations Classification |
| Developed technology |  | $ | 12 |  |  | $ | 8 |  |  | $ | 34 |  |  | $ | 30 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 3 |  |  |  | — |  |  |  | 6 |  |  |  | — |  |  | Operating expenses |
| Total |  | $ | 15 |  |  | $ | 8 |  |  | $ | 40 |  |  | $ | 30 |  |  |  |

[0001564590-21-009843:notes:30]
As of January 29, 2021, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-21-009843:notes:31]
| Fiscal Year |  | Amount |  |
| Remainder of 2021 |  | $ | 8 |  |
| 2022 |  |  | 37 |  |
| 2023 |  |  | 29 |  |
| 2024 |  |  | 17 |  |
| 2025 |  |  | 16 |  |
| 2026 |  |  | 3 |  |
| Total |  | $ | 110 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-21-009843:notes:32]
[same as prior period, unchanged from 0001564590-20-056069:notes:33]

[0001564590-21-009843:notes:33]
[same as prior period, unchanged from 0001564590-20-056069:notes:34]

[0001564590-21-009843:notes:34]
[same as prior period, unchanged from 0001564590-20-056069:notes:35]

[0001564590-21-009843:notes:35]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Cash and cash equivalents |  | $ | 3,808 |  |  | $ | 2,658 |  |
| Restricted cash |  |  | 6 |  |  |  | 8 |  |
| Cash, cash equivalents and restricted cash |  | $ | 3,814 |  |  | $ | 2,666 |  |

[0001564590-21-009843:notes:36]
[same as prior period, unchanged from 0001564590-20-056069:notes:37]

[0001564590-21-009843:notes:37]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Purchased components |  | $ | 19 |  |  | $ | 28 |  |
| Finished goods |  |  | 87 |  |  |  | 117 |  |
| Inventories |  | $ | 106 |  |  | $ | 145 |  |

[0001564590-21-009843:notes:38]
[same as prior period, unchanged from 0001564590-20-056069:notes:39]

[0001564590-21-009843:notes:39]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Land |  | $ | 103 |  |  | $ | 103 |  |
| Buildings and improvements |  |  | 601 |  |  |  | 597 |  |
| Leasehold improvements |  |  | 87 |  |  |  | 89 |  |
| Computer, production, engineering and other equipment |  |  | 867 |  |  |  | 802 |  |
| Computer software |  |  | 359 |  |  |  | 359 |  |
| Furniture and fixtures |  |  | 100 |  |  |  | 106 |  |
| Construction-in-progress |  |  | 43 |  |  |  | 32 |  |
|  |  |  | 2,160 |  |  |  | 2,088 |  |
| Accumulated depreciation and amortization |  |  | (1,429 | ) |  |  | (1,361 | ) |
| Property and equipment, net |  | $ | 731 |  |  | $ | 727 |  |

[0001564590-21-009843:notes:40]
[same as prior period, unchanged from 0001564590-20-056069:notes:41]

[0001564590-21-009843:notes:41]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Deferred tax assets |  | $ | 224 |  |  | $ | 220 |  |
| Operating lease ROU assets |  |  | 120 |  |  |  | 137 |  |
| Other assets |  |  | 348 |  |  |  | 342 |  |
| Other non-current assets |  | $ | 692 |  |  | $ | 699 |  |

[0001564590-21-009843:notes:42]
Other non-current assets as of January 29, 2021 and April 24, 2020 included $71 million and $67 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited, a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019.

[0001564590-21-009843:notes:43]
[same as prior period, unchanged from 0001564590-20-056069:notes:44]

[0001564590-21-009843:notes:44]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Accrued compensation and benefits |  | $ | 365 |  |  | $ | 322 |  |
| Product warranty liabilities |  |  | 22 |  |  |  | 26 |  |
| Operating lease liabilities |  |  | 50 |  |  |  | 51 |  |
| Other current liabilities |  |  | 324 |  |  |  | 375 |  |
| Accrued expenses |  | $ | 761 |  |  | $ | 774 |  |

[0001564590-21-009843:notes:45]
[same as prior period, unchanged from 0001564590-20-056069:notes:46]

[0001564590-21-009843:notes:46]
[same as prior period, unchanged from 0001564590-20-056069:notes:47]

[0001564590-21-009843:notes:47]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Balance at beginning of period |  | $ | 35 |  |  | $ | 40 |  |  | $ | 41 |  |  | $ | 40 |  |
| Expense accrued during the period |  |  | 5 |  |  |  | 7 |  |  |  | 10 |  |  |  | 19 |  |
| Warranty costs incurred |  |  | (6 | ) |  |  | (6 | ) |  |  | (17 | ) |  |  | (18 | ) |
| Balance at end of period |  | $ | 34 |  |  | $ | 41 |  |  | $ | 34 |  |  | $ | 41 |  |

[0001564590-21-009843:notes:48]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Accrued expenses |  | $ | 22 |  |  | $ | 26 |  |
| Other long-term liabilities |  |  | 12 |  |  |  | 15 |  |
| Total warranty liabilities |  | $ | 34 |  |  | $ | 41 |  |

[0001564590-21-009843:notes:49]
Warranty expense recognized during the period includes amounts accrued for systems at the time of shipment, adjustments for changes in estimated costs for warranties on systems shipped in the period and changes in estimated costs for warranties on systems shipped in prior periods.

[0001564590-21-009843:notes:50]
[same as prior period, unchanged from 0001564590-20-056069:notes:51]

[0001564590-21-009843:notes:51]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Liability for uncertain tax positions |  | $ | 133 |  |  | $ | 136 |  |
| Income taxes payable |  |  | 351 |  |  |  | 399 |  |
| Product warranty liabilities |  |  | 12 |  |  |  | 15 |  |
| Operating lease liabilities |  |  | 76 |  |  |  | 93 |  |
| Other liabilities |  |  | 79 |  |  |  | 71 |  |
| Other long-term liabilities |  | $ | 651 |  |  | $ | 714 |  |

[0001564590-21-009843:notes:52]
[same as prior period, unchanged from 0001564590-20-056069:notes:53]

[0001564590-21-009843:notes:53]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Interest income |  | $ | 2 |  |  | $ | 10 |  |  | $ | 7 |  |  | $ | 41 |  |
| Interest expense |  |  | (19 | ) |  |  | (14 | ) |  |  | (55 | ) |  |  | (41 | ) |
| Other income (expense), net |  |  | 6 |  |  |  | 12 |  |  |  | (2 | ) |  |  | 26 |  |
| Total other income (expense), net |  | $ | (11 | ) |  | $ | 8 |  |  | $ | (50 | ) |  | $ | 26 |  |

[0001564590-21-009843:notes:54]
[same as prior period, unchanged from 0001564590-20-056069:notes:55]

[0001564590-21-009843:notes:55]
[same as prior period, unchanged from 0001564590-20-056069:notes:56]

[0001564590-21-009843:notes:56]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 11 |  |  | $ | 7 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 309 |  |  | $ | 266 |  |
| Interest paid |  | $ | 51 |  |  | $ | 40 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-21-009843:notes:57]
[same as prior period, unchanged from 0001564590-20-056069:notes:58]

[0001564590-21-009843:notes:58]
[same as prior period, unchanged from 0001564590-20-056069:notes:59]

[0001564590-21-009843:notes:59]
[same as prior period, unchanged from 0001564590-20-056069:notes:60]

[0001564590-21-009843:notes:60]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Product revenues |  | $ | 775 |  |  | $ | 787 |  |  | $ | 2,151 |  |  | $ | 2,202 |  |
| Software maintenance revenues |  | 334 |  |  | 263 |  |  | 938 |  |  | 767 |  |
| Hardware maintenance and other services revenues |  | 361 |  |  | 354 |  |  |  | 1,100 |  |  |  | 1,042 |  |
| Hardware maintenance support contracts |  | 293 |  |  | 293 |  |  | 896 |  |  |  | 863 |  |
| Professional and other services |  | 68 |  |  | 61 |  |  | 204 |  |  |  | 179 |  |
| Net revenues |  | $ | 1,470 |  |  | $ | 1,404 |  |  | $ | 4,189 |  |  | $ | 4,011 |  |

[0001564590-21-009843:notes:61]
[same as prior period, unchanged from 0001564590-20-056069:notes:62]

[0001564590-21-009843:notes:62]
[same as prior period, unchanged from 0001564590-20-056069:notes:63]

[0001564590-21-009843:notes:63]
[same as prior period, unchanged from 0001564590-20-056069:notes:64]

[0001564590-21-009843:notes:64]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Deferred product revenue |  | $ | 68 |  |  | $ | 75 |  |
| Deferred services revenue |  |  | 3,690 |  |  |  | 3,567 |  |
| Financed unearned services revenue |  |  | 70 |  |  |  | 56 |  |
| Total |  | $ | 3,828 |  |  | $ | 3,698 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,953 |  |  | $ | 1,894 |  |
| Long-term |  |  | 1,875 |  |  |  | 1,804 |  |
| Total |  | $ | 3,828 |  |  | $ | 3,698 |  |

[0001564590-21-009843:notes:65]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 16 – Commitments and Contingencies for additional information related to these arrangements.

[0001564590-21-009843:notes:66]
[same as prior period, unchanged from 0001564590-20-056069:notes:67]

[0001564590-21-009843:notes:67]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Balance at beginning of period |  | $ | 3,698 |  |  | $ | 3,668 |  |
| Additions |  |  | 2,269 |  |  |  | 1,759 |  |
| Revenue recognized during the period |  |  | (2,139 | ) |  |  | (1,854 | ) |
| Balance at end of period |  | $ | 3,828 |  |  | $ | 3,573 |  |

[0001564590-21-009843:notes:68]
During the nine months ended January 29, 2021 and January 24, 2020, we recognized $1,687 million and $1,504 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001564590-21-009843:notes:69]
As of January 29, 2021, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,828 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this

[0001564590-21-009843:notes:70]
amount. We expect to recognize as revenue approximately 51% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 25% in the next 13 to 24 months, and the remainder thereafter.

[0001564590-21-009843:notes:71]
[same as prior period, unchanged from 0001564590-20-056069:notes:71]

[0001564590-21-009843:notes:72]
[same as prior period, unchanged from 0001564590-20-056069:notes:72]

[0001564590-21-009843:notes:73]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Balance at beginning of period |  | $ | 156 |  |  | $ | 172 |  |
| Additions |  |  | 89 |  |  |  | 52 |  |
| Expense recognized during the period |  |  | (73 | ) |  |  | (72 | ) |
| Balance at end of period |  | $ | 172 |  |  | $ | 152 |  |

[0001564590-21-009843:notes:74]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Other current assets |  | $ | 71 |  |  | $ | 67 |  |
| Other non-current assets |  |  | 101 |  |  |  | 89 |  |
| Total deferred commissions |  | $ | 172 |  |  | $ | 156 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-21-009843:notes:75]
[same as prior period, unchanged from 0001564590-20-056069:notes:75]

[0001564590-21-009843:notes:76]
[same as prior period, unchanged from 0001564590-20-056069:notes:76]

[0001564590-21-009843:notes:77]
[same as prior period, unchanged from 0001564590-20-056069:notes:77]

[0001564590-21-009843:notes:78]
[same as prior period, unchanged from 0001564590-20-056069:notes:78]

[0001564590-21-009843:notes:79]
[same as prior period, unchanged from 0001564590-20-056069:notes:79]

[0001564590-21-009843:notes:80]
[same as prior period, unchanged from 0001564590-20-056069:notes:80]

[0001564590-21-009843:notes:81]
[same as prior period, unchanged from 0001564590-20-056069:notes:81]

[0001564590-21-009843:notes:82]
[same as prior period, unchanged from 0001564590-20-056069:notes:82]

[0001564590-21-009843:notes:83]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 68 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 69 |  |  | $ | 155 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 156 |  |
| U.S. Treasury and government debt securities |  |  | 17 |  |  |  | — |  |  |  | — |  |  |  | 17 |  |  |  | 68 |  |  |  | — |  |  |  | — |  |  |  | 68 |  |
| Certificates of deposit |  |  | 59 |  |  |  | — |  |  |  | — |  |  |  | 59 |  |  |  | 158 |  |  |  | — |  |  |  | — |  |  |  | 158 |  |
| Mutual funds |  |  | 39 |  |  |  | — |  |  |  | — |  |  |  | 39 |  |  |  | 33 |  |  |  | — |  |  |  | — |  |  |  | 33 |  |
| Total debt and equity securities |  | $ | 183 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 184 |  |  | $ | 414 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 415 |  |

[0001564590-21-009843:notes:84]
The following table presents the contractual maturities of our debt investments as of January 29, 2021 (in millions):

[0001564590-21-009843:notes:85]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 95 |  |  | $ | 95 |  |
| Due after one year through five years |  |  | 44 |  |  |  | 45 |  |
| Due after five years through ten years |  |  | 5 |  |  |  | 5 |  |
|  |  | $ | 144 |  |  | $ | 145 |  |

[0001564590-21-009843:notes:86]
[same as prior period, unchanged from 0001564590-20-056069:notes:86]

[0001564590-21-009843:notes:87]
[same as prior period, unchanged from 0001564590-20-056069:notes:87]

[0001564590-21-009843:notes:88]
[same as prior period, unchanged from 0001564590-20-056069:notes:88]

[0001564590-21-009843:notes:89]
|  |  | January 29, 2021 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 3,749 |  |  | $ | 3,749 |  |  | $ | — |  |
| Corporate bonds |  |  | 69 |  |  |  | — |  |  |  | 69 |  |
| U.S. Treasury and government debt securities |  |  | 17 |  |  |  | 4 |  |  |  | 13 |  |
| Certificates of deposit |  |  | 59 |  |  |  | — |  |  |  | 59 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,894 |  |  | $ | 3,753 |  |  | $ | 141 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 8 |  |  | $ | 8 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 31 |  |  | $ | 31 |  |  | $ | — |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (3 | ) |  | $ | — |  |  | $ | (3 | ) |

[0001564590-21-009843:notes:90]
[same as prior period, unchanged from 0001564590-20-056069:notes:90]

[0001564590-21-009843:notes:91]
[same as prior period, unchanged from 0001564590-20-056069:notes:91]

[0001564590-21-009843:notes:92]
[same as prior period, unchanged from 0001564590-20-056069:notes:92]

[0001564590-21-009843:notes:93]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of January 29, 2021 and April 24, 2020, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-21-009843:notes:94]
[same as prior period, unchanged from 0001564590-20-056069:notes:94]

[0001564590-21-009843:notes:95]
As of January 29, 2021 and April 24, 2020, the fair value of our long-term debt was approximately $2,814 million and $1,176 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-21-009843:notes:96]
8. Financing Arrangements

[0001564590-21-009843:notes:97]
Long-Term Debt

[0001564590-21-009843:notes:98]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-21-009843:notes:99]
|  |  | Effective Interest Rate |  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  | $ | — |  |  | $ | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | — |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | — |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | — |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 1,150 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (18 | ) |  |  | (4 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,632 |  |  | $ | 1,146 |  |

[0001564590-21-009843:notes:100]
Senior Notes

[0001564590-21-009843:notes:101]
In June 2020, we issued $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, for which we received total proceeds of approximately $2.0 billion, net of discount and issuance costs. Interest on these Senior Notes is payable semi-annually in June and December. On July 27, 2020, we extinguished our 3.375% Senior Notes due June 2021 for an aggregate cash redemption price of $513 million, plus accrued and unpaid interest. As part of the debt extinguishment, we recognized a loss of $14 million during the first quarter of fiscal 2021, which includes a cash redemption premium of $13 million and the write-off of unamortized discount and issuance costs totaling $1 million. The loss on extinguishment of debt is included in other income (expense), net in our condensed consolidated statement of operations for the nine months ended January 29, 2021.

[0001564590-21-009843:notes:102]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September. Our 3.25% Senior Notes, with a principal amount of $250 million, were issued in December 2012 with interest paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-21-009843:notes:103]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 29, 2021, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-21-009843:notes:104]
As of January 29, 2021, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-21-009843:notes:105]
| Fiscal Year |  | Amount |  |
| 2023 |  | $ | 250 |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |

[0001564590-21-009843:notes:106]
Commercial Paper Program and Credit Facility

[0001564590-21-009843:notes:107]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. While no commercial paper notes were outstanding as of January 29, 2021, we had commercial paper notes outstanding with an aggregate principal amount of $523 million, a weighted-average interest rate of  2.01%, and maturities primarily less than three months as of April 24, 2020. During the first nine months of fiscal 2021, we received proceeds of $75 million from the issuance, and made repayments of $176 million for the settlement, of commercial paper notes with original maturities greater than three months.

[0001564590-21-009843:notes:108]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 29, 2021, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0001564590-21-009843:notes:109]
[same as prior period, unchanged from 0001564590-20-056069:notes:110]

[0001564590-21-009843:notes:110]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of January 29, 2021, have remaining lease terms of up to 15 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of January 29, 2021, have remaining lease terms of up to 4 years. As of January 29, 2021, our automobile leases have remaining lease terms of up to 5 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0001564590-21-009843:notes:111]
In June 2020, we entered into a build-to-suit lease agreement for an office building with future undiscounted payments of approximately $67 million. Because the Company does not control the underlying asset during the construction period, the Company is not considered the owner of the asset under construction for accounting purposes. The lease will commence upon completion of the construction of the office building which is expected to be in the third quarter of fiscal 2022. The initial term of the lease is twenty years with options to renew the lease during the lease term. An ROU asset and related lease liability will be measured and recognized in our financial statements in the period the lease commences.

[0001564590-21-009843:notes:112]
[same as prior period, unchanged from 0001564590-20-056069:notes:113]

[0001564590-21-009843:notes:113]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Operating lease cost |  | $ | 13 |  |  | $ | 13 |  |  | $ | 41 |  |  | $ | 42 |  |
| Variable lease cost |  |  | 3 |  |  |  | 4 |  |  |  | 8 |  |  |  | 12 |  |
| Total lease cost |  | $ | 16 |  |  | $ | 17 |  |  | $ | 49 |  |  | $ | 54 |  |

[0001564590-21-009843:notes:114]
[same as prior period, unchanged from 0001564590-20-056069:notes:115]

[0001564590-21-009843:notes:115]
[same as prior period, unchanged from 0001564590-20-056069:notes:116]

[0001564590-21-009843:notes:116]
|  |  |  |  | Nine Months Ended |  |
|  |  |  |  |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  |  |  |  |  | $ | 43 |  |  | $ | 43 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  |  |  |  |  | $ | 19 |  |  | $ | 32 |  |

[0001564590-21-009843:notes:117]
[same as prior period, unchanged from 0001564590-20-056069:notes:118]

[0001564590-21-009843:notes:118]
|  |  |  |  |  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Other non-current assets |  |  |  |  |  | $ | 120 |  |  | $ | 137 |  |
| Total operating lease ROU assets |  |  |  |  |  | $ | 120 |  |  | $ | 137 |  |
| Accrued expenses |  |  |  |  |  | $ | 50 |  |  | $ | 51 |  |
| Other long-term liabilities |  |  |  |  |  |  | 76 |  |  |  | 93 |  |
| Total operating lease liabilities |  |  |  |  |  | $ | 126 |  |  | $ | 144 |  |
| Weighted Average Remaining Lease Term |  |  |  |  |  | 3.4 years |  |  | 3.9 years |  |
| Weighted Average Discount Rate |  |  |  |  |  |  | 2.8 | % |  |  | 2.7 | % |

[0001564590-21-009843:notes:119]
Future minimum operating lease payments as of January 29, 2021, which exclude the undiscounted payments for the build-to-suit lease expected to commence in fiscal 2022, are as follows (in millions):

[0001564590-21-009843:notes:120]
| Fiscal Year |  |  |  |  |  | Operating Leases |  |
| 2021 (remainder) |  |  |  |  |  | $ | 16 |  |
| 2022 |  |  |  |  |  |  | 49 |  |
| 2023 |  |  |  |  |  |  | 29 |  |
| 2024 |  |  |  |  |  |  | 18 |  |
| 2025 |  |  |  |  |  |  | 10 |  |
| 2026 |  |  |  |  |  |  | 7 |  |
| Thereafter |  |  |  |  |  |  | 3 |  |
| Total lease payments |  |  |  |  |  | $ | 132 |  |
| Less: Interest |  |  |  |  |  |  | (6 | ) |
| Total |  |  |  |  |  | $ | 126 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-21-009843:notes:121]
[same as prior period, unchanged from 0001564590-20-056069:notes:122]

[0001564590-21-009843:notes:122]
[same as prior period, unchanged from 0001564590-20-056069:notes:123]

[0001564590-21-009843:notes:123]
As of January 29, 2021, we have certain equity incentive awards (awards) outstanding, which include stock options and restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs). Also outstanding are purchase rights under our Employee Stock Purchase Plan (ESPP).

[0001564590-21-009843:notes:124]
[same as prior period, unchanged from 0001564590-20-056069:notes:125]

[0001564590-21-009843:notes:125]
Less than 1 million options were outstanding as of January 29, 2021 and April 24, 2020.

[0001564590-21-009843:notes:126]
[same as prior period, unchanged from 0001564590-20-056069:notes:127]

[0001564590-21-009843:notes:127]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Intrinsic value of exercises |  | $ | 4 |  |  | $ | 4 |  |
| Proceeds received from exercises |  | $ | 2 |  |  | $ | 4 |  |
| Fair value of options vested |  | $ | 4 |  |  | $ | 1 |  |

[0001564590-21-009843:notes:128]
[same as prior period, unchanged from 0001564590-20-056069:notes:129]

[0001564590-21-009843:notes:129]
In the nine months ended January 29, 2021, we granted PBRSUs to certain of our executives. The PBRSUs have performance-based vesting criteria, in addition to the service based vesting criteria, such that the PBRSUs cliff-vest at the end of an approximate one, two or three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the first, second or third fiscal year, respectively following the grant date. The number of shares of common stock that will be issued to settle most of these PBRSUs at the end of the performance and service period, will range from 0% to 200% of a target number of shares originally granted. For PBRSUs with potential payouts above a 100% of target amount, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies

[0001564590-21-009843:notes:130]
(each expressed as a growth rate percentage) calculated as of the end of the performance period. The fair values of these TSR performance-based awards were fixed at grant date using a Monte Carlo simulation model. The aggregate grant date fair value of all PBRSUs granted in the current year was $27 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0001564590-21-009843:notes:131]
[same as prior period, unchanged from 0001564590-20-056069:notes:131]

[0001564590-21-009843:notes:132]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 24, 2020 |  |  | 7 |  |  | $ | 51.40 |  |
| Granted |  |  | 5 |  |  | $ | 40.94 |  |
| Vested |  |  | (2 | ) |  | $ | 44.68 |  |
| Forfeited |  |  | (1 | ) |  | $ | 51.53 |  |
| Outstanding as of January 29, 2021 |  |  | 9 |  |  | $ | 47.05 |  |

[0001564590-21-009843:notes:133]
[same as prior period, unchanged from 0001564590-20-056069:notes:133]

[0001564590-21-009843:notes:134]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 38 |  |  | $ | 77 |  |

[0001564590-21-009843:notes:135]
[same as prior period, unchanged from 0001564590-20-056069:notes:135]

[0001564590-21-009843:notes:136]
[same as prior period, unchanged from 0001564590-20-056069:notes:136]

[0001564590-21-009843:notes:137]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Shares issued under the ESPP |  |  | 2 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 90 |  |  | $ | 98 |  |

[0001564590-21-009843:notes:138]
[same as prior period, unchanged from 0001564590-20-056069:notes:138]

[0001564590-21-009843:notes:139]
[same as prior period, unchanged from 0001564590-20-056069:notes:139]

[0001564590-21-009843:notes:140]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 3 |  |
| Cost of hardware maintenance and other services revenues |  |  | 2 |  |  |  | 2 |  |  |  | 7 |  |  |  | 7 |  |
| Sales and marketing |  |  | 21 |  |  |  | 15 |  |  |  | 70 |  |  |  | 50 |  |
| Research and development |  |  | 15 |  |  |  | 13 |  |  |  | 49 |  |  |  | 41 |  |
| General and administrative |  |  | 7 |  |  |  | 5 |  |  |  | 20 |  |  |  | 17 |  |
| Total stock-based compensation expense |  | $ | 46 |  |  | $ | 36 |  |  | $ | 149 |  |  | $ | 118 |  |
| Income tax benefit for stock-based compensation expense |  | $ | 4 |  |  | $ | 3 |  |  | $ | 12 |  |  | $ | 11 |  |

[0001564590-21-009843:notes:141]
As of January 29, 2021, total unrecognized compensation expense related to our equity awards was $363 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.3 years.

[0001564590-21-009843:notes:142]
[same as prior period, unchanged from 0001564590-20-056069:notes:142]

[0001564590-21-009843:notes:143]
As of January 29, 2021, our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time, and it was suspended in March 2020 due to the economic impact of the COVID-19 pandemic. We reinitiated our stock repurchase program during the third quarter of fiscal 2021.

[0001564590-21-009843:notes:144]
The following table summarized activity related to the stock repurchase program for the nine months ended January 29, 2021 (in millions, except for per share amounts):

[0001564590-21-009843:notes:145]
| Number of shares repurchased |  |  | 1 |  |
| Average price per share |  | $ | 64.78 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 1 |  |
| Stock repurchases allocated to retained earnings |  | $ | 49 |  |
| Remaining authorization at end of period |  | $ | 427 |  |

[0001564590-21-009843:notes:146]
Since the May 13, 2003 inception of our stock repurchase program through January 29, 2021, we repurchased a total of 339 million shares of our common stock at an average price of $38.92 per share, for an aggregate purchase price of $13.2 billion.

[0001564590-21-009843:notes:147]
[same as prior period, unchanged from 0001564590-20-056069:notes:145]

[0001564590-21-009843:notes:148]
[same as prior period, unchanged from 0001564590-20-056069:notes:146]

[0001564590-21-009843:notes:149]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Dividends per share declared |  | $ | 1.44 |  |  | $ | 1.44 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 30 |  |  | $ | 334 |  |
| Dividend payments allocated to retained earnings |  | $ | 291 |  |  | $ | — |  |

[0001564590-21-009843:notes:150]
On February 19, 2021, we declared a cash dividend of $0.48 per share of common stock, payable on April 28, 2021 to holders of record as of the close of business on April 9, 2021. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-21-009843:notes:151]
[same as prior period, unchanged from 0001564590-20-056069:notes:149]

[0001564590-21-009843:notes:152]
[same as prior period, unchanged from 0001564590-20-056069:notes:150]

[0001564590-21-009843:notes:153]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 24, 2020 |  | $ | (42 | ) |  | $ | (1 | ) |  | $ | 1 |  |  | $ | — |  |  | $ | (42 | ) |
| Other comprehensive income (loss), net of tax |  |  | 10 |  |  |  | — |  |  |  | — |  |  |  | (13 | ) |  |  | (3 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 11 |  |  |  | 11 |  |
| Total other comprehensive income (loss) |  |  | 10 |  |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  | 8 |  |
| Balance as of January 29, 2021 |  | $ | (32 | ) |  | $ | (1 | ) |  | $ | 1 |  |  | $ | (2 | ) |  | $ | (34 | ) |

[0001564590-21-009843:notes:154]
[same as prior period, unchanged from 0001564590-20-056069:notes:152]

[0001564590-21-009843:notes:155]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | Statements of Operations Classification |
| Recognized gains on defined benefit obligations |  | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | (2 | ) |  | Operating expenses |
| Realized gains on available-for-sale securities |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (14 | ) |  | Other income (expense), net |
| Realized losses on cash flow hedges |  |  | 3 |  |  |  | — |  |  |  | 11 |  |  |  | — |  |  | Net revenues |
| Total reclassifications |  | $ | 3 |  |  | $ | (1 | ) |  | $ | 11 |  |  | $ | (16 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-21-009843:notes:156]
[same as prior period, unchanged from 0001564590-20-056069:notes:154]

[0001564590-21-009843:notes:157]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of January 29, 2021 or April 24, 2020. All contracts have a maturity of less than 12 months.

[0001564590-21-009843:notes:158]
[same as prior period, unchanged from 0001564590-20-056069:notes:156]

[0001564590-21-009843:notes:159]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 153 |  |  | $ | 124 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 182 |  |  | $ | 254 |  |
| Forward contracts purchased |  | $ | 82 |  |  | $ | 108 |  |

[0001564590-21-009843:notes:160]
The gain (loss) of cash flow hedges recognized in net revenues is presented in the condensed consolidated statements of comprehensive income and Note 10 – Stockholders’ Equity.

[0001564590-21-009843:notes:161]
[same as prior period, unchanged from 0001564590-20-056069:notes:159]

[0001564590-21-009843:notes:162]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Foreign currency exchange contracts |  | $ | 8 |  |  | $ | 5 |  |  | $ | 26 |  |  | $ | 2 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-21-009843:notes:163]
[same as prior period, unchanged from 0001564590-20-056069:notes:161]

[0001564590-21-009843:notes:164]
In the second quarter of fiscal 2021, we committed to a restructuring plan (the August 2020 Plan) to optimize our business and fund our biggest opportunities. In connection with the plan, we reduced our global workforce by approximately 5%. Charges related to the plan consisted primarily of employee severance-related costs. We completed substantially all activities related to this plan by the end of the third quarter of fiscal 2021.

[0001564590-21-009843:notes:165]
[same as prior period, unchanged from 0001564590-20-056069:notes:163]

[0001564590-21-009843:notes:166]
[same as prior period, unchanged from 0001564590-20-056069:notes:164]

[0001564590-21-009843:notes:167]
[same as prior period, unchanged from 0001564590-20-056069:notes:165]

[0001564590-21-009843:notes:168]
|  | Nine Months Ended |  |  | Nine Months Ended |  |
|  | January 29, 2021 |  |  | January 24, 2020 |  |
|  | August 2020 Plan |  | May 2020 Plan |  | May 2019 Plan |  | Total |  |  | May 2019 Plan |  | April 2019 Plan |  | November 2016 Plan |  | Total |  |
| Balance at beginning of period | $ | — |  | $ | — |  | $ | 1 |  | $ | 1 |  |  | $ | — |  | $ | 15 |  | $ | 4 |  | $ | 19 |  |
| Net charges |  | 37 |  |  | 5 |  |  | — |  |  | 42 |  |  |  | 21 |  |  | — |  |  | — |  |  | 21 |  |
| Cash payments |  | (35 | ) |  | (5 | ) |  | (1 | ) |  | (41 | ) |  |  | (20 | ) |  | (14 | ) |  | — |  |  | (34 | ) |
| Other |  | — |  |  | — |  |  | — |  |  | — |  |  |  | — |  |  | — |  |  | (4 | ) |  | (4 | ) |
| Balance at end of period | $ | 2 |  | $ | — |  | $ | — |  | $ | 2 |  |  | $ | 1 |  | $ | 1 |  | $ | — |  | $ | 2 |  |

[0001564590-21-009843:notes:169]
[same as prior period, unchanged from 0001564590-20-056069:notes:167]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-21-009843:notes:170]
[same as prior period, unchanged from 0001564590-20-056069:notes:168]

[0001564590-21-009843:notes:171]
[same as prior period, unchanged from 0001564590-20-056069:notes:169]

[0001564590-21-009843:notes:172]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Effective tax rates |  |  | 24.7 | % |  |  | 10.2 | % |

[0001564590-21-009843:notes:173]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. The effective tax rate for the nine months ended January 29, 2021 includes the impact of taxes resulting from the integration of acquired companies. The effective tax rate for the nine months ended January 24, 2020 included the impact of discrete tax benefits for lapses of statute of limitations. The remaining differences in effective tax rates for the first nine months of fiscal 2021 compared to the corresponding period of the prior year are primarily due to certain discrete expenses, including foreign audit results and differences in discrete tax benefits for stock-based compensation.

[0001564590-21-009843:notes:174]
As of January 29, 2021, we had $224 million of gross unrecognized tax benefits, of which $133 million has been recorded in other long-term liabilities. Inclusive of penalties, interest and certain income tax benefits, $133 million would affect our provision for income taxes if recognized.

[0001564590-21-009843:notes:175]
[same as prior period, unchanged from 0001564590-20-056069:notes:173]

[0001564590-21-009843:notes:176]
[same as prior period, unchanged from 0001564590-20-056069:notes:174]


## us-gaap:EarningsPerShareTextBlock

[0001564590-21-009843:notes:177]
[same as prior period, unchanged from 0001564590-20-056069:notes:175]

[0001564590-21-009843:notes:178]
[same as prior period, unchanged from 0001564590-20-056069:notes:176]

[0001564590-21-009843:notes:179]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 182 |  |  | $ | 277 |  |  | $ | 396 |  |  | $ | 623 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 223 |  |  |  | 226 |  |  |  | 222 |  |  |  | 233 |  |
| Dilutive impact of employee equity award plans |  |  | 4 |  |  |  | 3 |  |  |  | 3 |  |  |  | 3 |  |
| Shares used in diluted computation |  |  | 227 |  |  |  | 229 |  |  |  | 225 |  |  |  | 236 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.82 |  |  | $ | 1.23 |  |  | $ | 1.78 |  |  | $ | 2.67 |  |
| Diluted |  | $ | 0.80 |  |  | $ | 1.21 |  |  | $ | 1.76 |  |  | $ | 2.64 |  |

[0001564590-21-009843:notes:180]
No potential shares from outstanding employee awards were excluded from the diluted net income per share calculation for the three months ended January 29, 2021. Five million potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for the nine months ended January 29, 2021 and three million potential shares were excluded from the calculation for the three and nine months ended January 24, 2020, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-21-009843:notes:181]
[same as prior period, unchanged from 0001564590-20-056069:notes:179]

[0001564590-21-009843:notes:182]
[same as prior period, unchanged from 0001564590-20-056069:notes:180]

[0001564590-21-009843:notes:183]
[same as prior period, unchanged from 0001564590-20-056069:notes:181]

[0001564590-21-009843:notes:184]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| United States, Canada and Latin America (Americas) |  | $ | 778 |  |  | $ | 695 |  |  | $ | 2,268 |  |  | $ | 2,101 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 474 |  |  |  | 494 |  |  |  | 1,279 |  |  |  | 1,298 |  |
| Asia Pacific (APAC) |  |  | 218 |  |  |  | 215 |  |  |  | 642 |  |  |  | 612 |  |
| Net revenues |  | $ | 1,470 |  |  | $ | 1,404 |  |  | $ | 4,189 |  |  | $ | 4,011 |  |

[0001564590-21-009843:notes:185]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $693 million and $620 million during the three months ended January 29, 2021 and January 24, 2020, respectively, and were $2,035 million and $1,897 million during the nine months ended January 29, 2021 and January 24, 2020, respectively.

[0001564590-21-009843:notes:186]
[same as prior period, unchanged from 0001564590-20-056069:notes:184]

[0001564590-21-009843:notes:187]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| U.S. |  | $ | 1,598 |  |  | $ | 385 |  |
| International |  |  | 2,296 |  |  |  | 2,497 |  |
| Total |  | $ | 3,894 |  |  | $ | 2,882 |  |

[0001564590-21-009843:notes:188]
[same as prior period, unchanged from 0001564590-20-056069:notes:186]

[0001564590-21-009843:notes:189]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| U.S. |  | $ | 548 |  |  | $ | 540 |  |
| International |  |  | 183 |  |  |  | 187 |  |
| Total |  | $ | 731 |  |  | $ | 727 |  |

[0001564590-21-009843:notes:190]
[same as prior period, unchanged from 0001564590-20-056069:notes:188]

[0001564590-21-009843:notes:191]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 25 | % |  |  | 24 | % |  |  | 25 | % |
| Tech Data Corporation |  |  | 19 | % |  |  | 20 | % |  |  | 20 | % |  |  | 20 | % |

[0001564590-21-009843:notes:192]
The following customers accounted for 10% or more of accounts receivable in at least one of the periods presented:

[0001564590-21-009843:notes:193]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Arrow Electronics, Inc. |  |  | 7 | % |  |  | 13 | % |
| Tech Data Corporation |  |  | 13 | % |  |  | 19 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-21-009843:notes:194]
16. Commitments and Contingencies

[0001564590-21-009843:notes:195]
Purchase Orders and Other Commitments

[0001564590-21-009843:notes:196]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 29, 2021, we had $602 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 29, 2021 and April 24, 2020, such liability amounted to $8 million and $6 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-21-009843:notes:197]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 29, 2021, we had $181 million in other purchase obligations.

[0001564590-21-009843:notes:198]
Financing Guarantees

[0001564590-21-009843:notes:199]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $61 million and $49 million of receivables during the nine months ended January 29, 2021 and January 24, 2020, respectively.

[0001564590-21-009843:notes:200]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-21-009843:notes:201]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of January 29, 2021 and April 24, 2020, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-21-009843:notes:202]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 29, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-21-009843:notes:203]
Legal Contingencies

[0001564590-21-009843:notes:204]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-21-009843:notes:205]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised

[0001564590-21-009843:notes:206]
financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. On February 1, 2021, the District Court issued an order granting our motion to dismiss plaintiff’s amended class action complaint, and provided plaintiff leave to amend the complaint within 21 days. On February 22, 2021, plaintiff filed a notice of intent not to file a second amended complaint, but reserved his right to appeal the order granting our motion to dismiss. We believe the complaint is without merit and intend to defend the case vigorously.

[0001564590-21-009843:notes:207]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-21-009843:notes:208]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of January 29, 2021 related to such matters.
