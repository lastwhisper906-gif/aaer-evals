# NTAP 8-K — 0001564590-21-008093 filed 2021-02-24

## item codes, every 8-K on or before 2021-03-01

- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2021-03-01

- none on or before 2021-03-01

## item 2.02 — earnings release, exhibit 99.1

[0001564590-21-008093:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-21-008093:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-21-008093:8k_2_02:3]
Exhibit 99.1

[0001564590-21-008093:8k_2_02:4]
NetApp Reports Third Quarter of Fiscal Year 2021 Results

[0001564590-21-008093:8k_2_02:5]
Net revenues of $1.47 billion; up 5% year-over-year

[0001564590-21-008093:8k_2_02:6]
Operating margin and EPS above expectations

[0001564590-21-008093:8k_2_02:7]
| • | Billings1 of $1.60 billion, increased 6% year-over-year |  |

[0001564590-21-008093:8k_2_02:8]
| • | NetApp™ public cloud services annualized revenue run rate2 of $237 million, an increase of 186% year-over-year |  |

[0001564590-21-008093:8k_2_02:9]
| • | All-flash array annualized net revenue run rate3 of $2.6 billion, an increase of 11% year-over-year |  |

[0001564590-21-008093:8k_2_02:10]
| • | $157 million returned to shareholders in share repurchases and cash dividends |  |

[0001564590-21-008093:8k_2_02:11]
Sunnyvale, Calif.—February 24, 2021—NetApp (NASDAQ: NTAP) today reported financial results for the third quarter of fiscal year 2021, which ended on January 29, 2021.

[0001564590-21-008093:8k_2_02:12]
“We delivered another strong quarter with revenues at the top of our guidance range and operating margin and EPS above the high end of our expectations. We have sharpened our execution and Q3 fiscal year 2021 marks our third consecutive quarter of revenue and billings growth,” said George Kurian, chief executive officer. “Looking ahead, we are uniquely positioned to address customers’ requirements for digital transformations as they deploy workloads in the cloud, as well as maintain and modernize on premises. We are confident in the strength of our position as customers continue to turn to NetApp to help them solve the challenge of managing data in the hybrid cloud as the recovery unfolds.”

[0001564590-21-008093:8k_2_02:13]
Third quarter of fiscal year 2021 financial results

[0001564590-21-008093:8k_2_02:14]
| • | Net Revenues: $1.47 billion, compared to $1.40 billion in the third quarter of fiscal year 2020 |  |

[0001564590-21-008093:8k_2_02:15]
| • | Net Income: GAAP net income of $182 million, compared to GAAP net income of $277 million in the third quarter of fiscal year 2020; non-GAAP net income4 of $250 million, compared to non-GAAP net income of $265 million in the third quarter of fiscal year 2020 |  |

[0001564590-21-008093:8k_2_02:16]
| • | Earnings per Share: GAAP net income per share5 of $0.80 compared to GAAP net income per share of $1.21 in the third quarter of fiscal year 2020; non-GAAP net income per share of $1.10, compared to non-GAAP net income per share of $1.16 in the third quarter of fiscal year 2020 |  |

[0001564590-21-008093:8k_2_02:17]
| • | Cash, Cash Equivalents and Investments: $3.89 billion at the end of the third quarter of fiscal year 2021 |  |

[0001564590-21-008093:8k_2_02:18]
| • | Cash Provided by Operations: $373 million, compared to $420 million in the third quarter of fiscal year 2020 |  |

[0001564590-21-008093:8k_2_02:19]
| • | Share Repurchase and Dividend: Returned $157 million to shareholders through share repurchases and cash dividends |  |

[0001564590-21-008093:8k_2_02:20]
Fourth quarter of fiscal year 2021 financial outlook

[0001564590-21-008093:8k_2_02:21]
The company provided the following financial guidance for the fourth quarter of fiscal year 2021:

[0001564590-21-008093:8k_2_02:22]
| Net revenues are expected to be in the range of: | $1.44 billion to $1.54 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $0.78 - $0.86 | $1.06 - $1.14 |

[0001564590-21-008093:8k_2_02:23]
Dividend

[0001564590-21-008093:8k_2_02:24]
The next cash dividend of $0.48 per share is to be paid on April 28, 2021, to shareholders of record as of the close of business on April 9, 2021.

[0001564590-21-008093:8k_2_02:25]
Third quarter fiscal year 2021 business highlights

[0001564590-21-008093:8k_2_02:26]
NetApp delivers industry-leading products

[0001564590-21-008093:8k_2_02:27]
| • | The NetApp Cloud Volumes platform is now available across all major cloud providers, allowing customers to optimize data storage and performance no matter where the data resides. |

[0001564590-21-008093:8k_2_02:28]
| • | NetApp released NetApp ONTAP™ 9.8 with a simplified management experience, new visualizations, new workflows, and UI enhancements to further improve and simplify data storage management. |

[0001564590-21-008093:8k_2_02:29]
| • | NetApp unveiled the NetApp EF300 that includes up to 367TB of total raw capacity which follows the release of the NetApp EF600 a year ago. |

[0001564590-21-008093:8k_2_02:30]
| • | NetApp expanded the FAS product line by adding the NetApp FAS500f with the best latency and response times in NetApp’s FAS family and full NVMe throughput (to the hosts and drives). |

[0001564590-21-008093:8k_2_02:31]
| • | The NetApp Data Science Toolkit provides industry-leading, multitenant data management capabilities in a simple, easy-to-use interface that is designed for data scientists and data engineers. |

[0001564590-21-008093:8k_2_02:32]
| • | NetApp unveiled the NetApp StorageGRID™ SG100 designed for customers just getting started with object storage and provides the power of the StorageGRID Admin Node and Gateway Node Software. |

[0001564590-21-008093:8k_2_02:33]
| • | With the release of NetApp SnapCenter™ 4.4, NetApp continues to introduce innovative ways to protect data and add value by providing better integrations with ONTAP and enterprise applications. |

[0001564590-21-008093:8k_2_02:34]
| • | NetApp unveiled the release of NetApp Active IQ™ Unified Manager 9.7 that focuses on enhancement of existing features such as self-managing storage, reporting, Active IQ Unified Manager backup and restore, REST API, and VMware awareness. |

[0001564590-21-008093:8k_2_02:35]
NetApp partnering for innovation

[0001564590-21-008093:8k_2_02:36]
| • | NetApp and NVIDIA collaborated to create conversations AI architecture that deliver the required response times with NetApp ONTAP AI, which is powered by NVIDIA DGX systems and NetApp cloud-connected storage. |

[0001564590-21-008093:8k_2_02:37]
| • | NetApp and Google Cloud announced their latest collaboration, Anthos on bare metal with NetApp which will provide customers a deployment option to run Anthos on physical servers, without a hypervisor layer. |

[0001564590-21-008093:8k_2_02:38]
| • | NetApp and Microsoft collaborated on their joint cloud offering with Azure NetApp Files, a key service that has achieve Service Organization Controls6 compliance enabling customers to accomplish a variety of goals related to privacy, security, processing integrity, availability, and confidentiality. |

[0001564590-21-008093:8k_2_02:39]
| • | NetApp and Red Hat have collaborated on NetApp Project Astra™ using Red Hat OpenShift to meet emerging customer needs and improve Kubernetes data management. |

[0001564590-21-008093:8k_2_02:40]
| • | NetApp and IBM have partnered on IBM Cloud Satellite to solve operations complexity across multiple environments, including on premises, edge, and public cloud. |

[0001564590-21-008093:8k_2_02:41]
| • | NetApp announced that it has been selected by the University of Cambridge to modernize its IT systems and satisfy the new demands that higher education requires. |

[0001564590-21-008093:8k_2_02:42]
| • | NetApp announced that it has been selected by Photobox to fulfill customer orders quickly, for less cost, compared to a traditional data center infrastructure. |

[0001564590-21-008093:8k_2_02:43]
NetApp’s continued recognition

[0001564590-21-008093:8k_2_02:44]
| • | Once again, NetApp was named a leader in the 2020 Gartner7 Magic Quadrant for Primary Storage Arrays.8 |

[0001564590-21-008093:8k_2_02:45]
| • | NetApp won the 2020 BIG Stratus Award9 for top hybrid cloud provider. |

[0001564590-21-008093:8k_2_02:46]
| • | NetApp scored #1 in 3/4 Use Cases in the 2020 Gartner Critical Capabilities for Solid-State Arrays and 2/4 Use Cases in Gartner Critical Capabilities for Hybrid Array Storage Systems.10 |

[0001564590-21-008093:8k_2_02:47]
Webcast and conference call information

[0001564590-21-008093:8k_2_02:48]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today.

[0001564590-21-008093:8k_2_02:49]
###

[0001564590-21-008093:8k_2_02:50]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001564590-21-008093:8k_2_02:51]
Footnotes

[0001564590-21-008093:8k_2_02:52]
1Refer to the NetApp Usage of Non-GAAP Financial Information section below for an explanation of billings.

[0001564590-21-008093:8k_2_02:53]
2Public Cloud Services annualized revenue run rate (ARR) is calculated as the annualized value of all Public Cloud Services customer commitments as of the last day of the quarter, with the assumption that any commitment expiring during the next 12 months will be renewed with its existing terms.

[0001564590-21-008093:8k_2_02:54]
3All Flash Array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0001564590-21-008093:8k_2_02:55]
4Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) gains/losses on the sale of investments in equity securities, (i) debt extinguishment costs, (j) COVID-19 charges and (k) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-21-008093:8k_2_02:56]
5GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0001564590-21-008093:8k_2_02:57]
6Staff, Azure achieves Service Organization Controls compliance for 14 additional services (2020), https://azure.microsoft.com/en-us/updates/azure-achieves-service-and-organization-controls-compliance-for-14-additional-services/.

[0001564590-21-008093:8k_2_02:58]
7Gartner does not endorse any vendor, product or service depicted in its research publications and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner’s Research & Advisory organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001564590-21-008093:8k_2_02:59]
8Jeff Vogel, Roger W. Cox, Joseph Unsworth, Santhosh Rao, Gartner Magic Quadrant for Primary Storage Arrays (2020), https://www.gartner.com/en/documents/3993754/magic-quadrant-for-primary-storage-arrays.

[0001564590-21-008093:8k_2_02:60]
9Staff, 38 Cloud Computing Companies Win 2020 Stratus Awards for Cloud Computing (2020), https://www.bintelligence.com/blog/2020/12/8/38-cloud-computing-companies-win-2020-stratus-awards-for-cloud-computing?linkId=100000023380379.

[0001564590-21-008093:8k_2_02:61]
10Jeff Vogel, Roger W. Cox, Joseph Unsworth, Santhosh Rao, Critical Capabilities for Solid-State Arrays (2020), https://www.gartner.com/doc/reprints?id=1-24Q9VXGW&ct=201203&st=sb, https://www.gartner.com/doc/reprints?id=1-24Q9VXGT&ct=201203&st=sb.

[0001564590-21-008093:8k_2_02:62]
NetApp usage of non-GAAP financial information

[0001564590-21-008093:8k_2_02:63]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share. NetApp also presents the hardware and software components of our GAAP product revenues. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0001564590-21-008093:8k_2_02:64]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations.

[0001564590-21-008093:8k_2_02:65]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash

[0001564590-21-008093:8k_2_02:66]
flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-21-008093:8k_2_02:67]
NetApp believes that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0001564590-21-008093:8k_2_02:68]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it represents the amounts under purchase orders received by us during a given period that have been billed.

[0001564590-21-008093:8k_2_02:69]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-21-008093:8k_2_02:70]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-21-008093:8k_2_02:71]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-21-008093:8k_2_02:72]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-21-008093:8k_2_02:73]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-21-008093:8k_2_02:74]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not

[0001564590-21-008093:8k_2_02:75]
related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-21-008093:8k_2_02:76]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-21-008093:8k_2_02:77]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-21-008093:8k_2_02:78]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-21-008093:8k_2_02:79]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-21-008093:8k_2_02:80]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-21-008093:8k_2_02:81]
J. COVID-19 charges. NetApp has excluded certain non-recurring expenses incurred as a direct result of the COVID-19 pandemic. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-21-008093:8k_2_02:82]
K. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges

[0001564590-21-008093:8k_2_02:83]
resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-21-008093:8k_2_02:84]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-21-008093:8k_2_02:85]
About NetApp

[0001564590-21-008093:8k_2_02:86]
NetApp is a global cloud-led, data-centric software company that empowers organizations to lead with data in the age of accelerated digital transformation. The company provides systems, software, and cloud services that enable them to run their applications optimally from data center to cloud, whether they are developing in the cloud, moving to the cloud, or creating their own cloudlike experiences on premises. With solutions that perform across diverse environments, NetApp helps organizations build their own data fabric and securely deliver the right data, services, and applications to the right people—anytime, anywhere. Learn more at www.netapp.com or follow us on Twitter, LinkedIn, Facebook, and Instagram.

[0001564590-21-008093:8k_2_02:87]
NETAPP, INC.

[0001564590-21-008093:8k_2_02:88]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-21-008093:8k_2_02:89]
(In millions)

[0001564590-21-008093:8k_2_02:90]
(Unaudited)

[0001564590-21-008093:8k_2_02:91]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,894 |  |  | $ | 2,882 |  |
| Accounts receivable |  |  | 799 |  |  |  | 973 |  |
| Inventories |  |  | 106 |  |  |  | 145 |  |
| Other current assets |  |  | 315 |  |  |  | 274 |  |
| Total current assets |  |  | 5,114 |  |  |  | 4,274 |  |
| Property and equipment, net |  |  | 731 |  |  |  | 727 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,149 |  |  |  | 1,822 |  |
| Other non-current assets |  |  | 692 |  |  |  | 699 |  |
| Total assets |  | $ | 8,686 |  |  | $ | 7,522 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 336 |  |  | $ | 426 |  |
| Accrued expenses |  |  | 761 |  |  |  | 774 |  |
| Commercial paper notes |  |  | — |  |  |  | 522 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,953 |  |  |  | 1,894 |  |
| Total current liabilities |  |  | 3,050 |  |  |  | 3,616 |  |
| Long-term debt |  |  | 2,632 |  |  |  | 1,146 |  |
| Other long-term liabilities |  |  | 651 |  |  |  | 714 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,875 |  |  |  | 1,804 |  |
| Total liabilities |  |  | 8,208 |  |  |  | 7,280 |  |
| Stockholders' equity |  |  | 478 |  |  |  | 242 |  |
| Total liabilities and stockholders' equity |  | $ | 8,686 |  |  | $ | 7,522 |  |

[0001564590-21-008093:8k_2_02:92]
NETAPP, INC.

[0001564590-21-008093:8k_2_02:93]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-21-008093:8k_2_02:94]
(In millions, except per share amounts)

[0001564590-21-008093:8k_2_02:95]
(Unaudited)

[0001564590-21-008093:8k_2_02:96]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 775 |  |  | $ | 787 |  |  | $ | 2,151 |  |  | $ | 2,202 |  |
| Software maintenance |  |  | 334 |  |  |  | 263 |  |  |  | 938 |  |  |  | 767 |  |
| Hardware maintenance and other services |  |  | 361 |  |  |  | 354 |  |  |  | 1,100 |  |  |  | 1,042 |  |
| Net revenues |  |  | 1,470 |  |  |  | 1,404 |  |  |  | 4,189 |  |  |  | 4,011 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 369 |  |  |  | 360 |  |  |  | 1,045 |  |  |  | 1,013 |  |
| Cost of software maintenance |  |  | 28 |  |  |  | 12 |  |  |  | 67 |  |  |  | 33 |  |
| Cost of hardware maintenance and other services |  |  | 98 |  |  |  | 91 |  |  |  | 297 |  |  |  | 283 |  |
| Total cost of revenues |  |  | 495 |  |  |  | 463 |  |  |  | 1,409 |  |  |  | 1,329 |  |
| Gross profit |  |  | 975 |  |  |  | 941 |  |  |  | 2,780 |  |  |  | 2,682 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 436 |  |  |  | 402 |  |  |  | 1,297 |  |  |  | 1,196 |  |
| Research and development |  |  | 215 |  |  |  | 211 |  |  |  | 660 |  |  |  | 635 |  |
| General and administrative |  |  | 63 |  |  |  | 60 |  |  |  | 191 |  |  |  | 200 |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 42 |  |  |  | 21 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | — |  |  |  | 14 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (38 | ) |
| Total operating expenses |  |  | 717 |  |  |  | 673 |  |  |  | 2,204 |  |  |  | 2,014 |  |
| Income from operations |  |  | 258 |  |  |  | 268 |  |  |  | 576 |  |  |  | 668 |  |
| Other income (expense), net |  |  | (11 | ) |  |  | 8 |  |  |  | (50 | ) |  |  | 26 |  |
| Income before income taxes |  |  | 247 |  |  |  | 276 |  |  |  | 526 |  |  |  | 694 |  |
| Provision (benefit) for income taxes |  |  | 65 |  |  |  | (1 | ) |  |  | 130 |  |  |  | 71 |  |
| Net income |  | $ | 182 |  |  | $ | 277 |  |  | $ | 396 |  |  | $ | 623 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.82 |  |  | $ | 1.23 |  |  | $ | 1.78 |  |  | $ | 2.67 |  |
| Diluted |  | $ | 0.80 |  |  | $ | 1.21 |  |  | $ | 1.76 |  |  | $ | 2.64 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 223 |  |  |  | 226 |  |  |  | 222 |  |  |  | 233 |  |
| Diluted |  |  | 227 |  |  |  | 229 |  |  |  | 225 |  |  |  | 236 |  |

[0001564590-21-008093:8k_2_02:97]
NETAPP, INC.

[0001564590-21-008093:8k_2_02:98]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-21-008093:8k_2_02:99]
(In millions)

[0001564590-21-008093:8k_2_02:100]
(Unaudited)

[0001564590-21-008093:8k_2_02:101]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 182 |  |  | $ | 277 |  |  | $ | 396 |  |  | $ | 623 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 54 |  |  |  | 47 |  |  |  | 159 |  |  |  | 146 |  |
| Non-cash operating lease cost |  |  | 12 |  |  |  | 13 |  |  |  | 38 |  |  |  | 39 |  |
| Stock-based compensation |  |  | 46 |  |  |  | 36 |  |  |  | 149 |  |  |  | 118 |  |
| Deferred income taxes |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | (23 | ) |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (38 | ) |
| Other items, net |  |  | 7 |  |  |  | (3 | ) |  |  | 35 |  |  |  | (16 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 11 |  |  |  | (41 | ) |  |  | 208 |  |  |  | 394 |  |
| Inventories |  |  | 10 |  |  |  | (2 | ) |  |  | 39 |  |  |  | 18 |  |
| Accounts payable |  |  | (33 | ) |  |  | (1 | ) |  |  | (92 | ) |  |  | (158 | ) |
| Accrued expenses |  |  | 8 |  |  |  | 42 |  |  |  | (61 | ) |  |  | (273 | ) |
| Deferred revenue and financed unearned services revenue |  |  | 128 |  |  |  | 104 |  |  |  | 10 |  |  |  | (93 | ) |
| Long-term taxes payable |  |  | (5 | ) |  |  | (84 | ) |  |  | (51 | ) |  |  | (133 | ) |
| Changes in other operating assets and liabilities, net |  |  | (46 | ) |  |  | 32 |  |  |  | (55 | ) |  |  | 73 |  |
| Net cash provided by operating activities |  |  | 373 |  |  |  | 420 |  |  |  | 774 |  |  |  | 677 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 33 |  |  |  | 142 |  |  |  | 140 |  |  |  | 1,288 |  |
| Purchases of property and equipment |  |  | (32 | ) |  |  | (32 | ) |  |  | (124 | ) |  |  | (100 | ) |
| Proceeds from sale of properties |  |  | — |  |  |  | — |  |  |  | 6 |  |  |  | 96 |  |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | — |  |  |  | (350 | ) |  |  | (56 | ) |
| Other investing activities, net |  |  | — |  |  |  | 1 |  |  |  | 8 |  |  |  | (1 | ) |
| Net cash provided by (used in) investing activities |  |  | 1 |  |  |  | 111 |  |  |  | (320 | ) |  |  | 1,227 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 43 |  |  |  | 47 |  |  |  | 92 |  |  |  | 102 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (4 | ) |  |  | (3 | ) |  |  | (38 | ) |  |  | (77 | ) |
| Repurchase of common stock |  |  | (50 | ) |  |  | (500 | ) |  |  | (50 | ) |  |  | (1,250 | ) |
| Proceeds from (repayments of) commercial paper notes, original maturities of three months or less, net |  |  | — |  |  |  | 194 |  |  |  | (420 | ) |  |  | 443 |  |
| Issuance of debt, net of issuance costs |  |  | — |  |  |  | — |  |  |  | 2,057 |  |  |  | — |  |
| Repayments and extinguishment of debt |  |  | — |  |  |  | — |  |  |  | (689 | ) |  |  | (400 | ) |
| Dividends paid |  |  | (107 | ) |  |  | (108 | ) |  |  | (321 | ) |  |  | (334 | ) |
| Other financing activities, net |  |  | (4 | ) |  |  | (2 | ) |  |  | (7 | ) |  |  | (4 | ) |
| Net cash (used in) provided by financing activities |  |  | (122 | ) |  |  | (372 | ) |  |  | 624 |  |  |  | (1,520 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 26 |  |  |  | 1 |  |  |  | 70 |  |  |  | (4 | ) |
| Net increase in cash, cash equivalents and restricted cash |  |  | 278 |  |  |  | 160 |  |  |  | 1,148 |  |  |  | 380 |  |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 3,536 |  |  |  | 2,551 |  |  |  | 2,666 |  |  |  | 2,331 |  |
| End of period |  | $ | 3,814 |  |  | $ | 2,711 |  |  | $ | 3,814 |  |  | $ | 2,711 |  |

[0001564590-21-008093:8k_2_02:102]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q3'FY21 |  |  |  |  | Q2'FY21 |  |  |  |  | Q3'FY20 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 775 |  |  |  |  | $ | 749 |  |  |  |  | $ | 787 |  |
| Software Maintenance |  | $ | 334 |  |  |  |  | $ | 303 |  |  |  |  | $ | 263 |  |
| Hardware Maintenance & Other Services |  | $ | 361 |  |  |  |  | $ | 364 |  |  |  |  | $ | 354 |  |
| Hardware Maintenance Support Contracts |  | $ | 293 |  |  |  |  | $ | 296 |  |  |  |  | $ | 293 |  |
| Professional and Other Services |  | $ | 68 |  |  |  |  | $ | 68 |  |  |  |  | $ | 61 |  |
| Net Revenues |  | $ | 1,470 |  |  |  |  | $ | 1,416 |  |  |  |  | $ | 1,404 |  |
| Product Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 775 |  |  |  |  | $ | 749 |  |  |  |  | $ | 787 |  |
| Software* |  | $ | 428 |  |  |  |  | $ | 417 |  |  |  |  | $ | 375 |  |
| Hardware* |  | $ | 347 |  |  |  |  | $ | 332 |  |  |  |  | $ | 412 |  |
| * Our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation. We have provided a breakdown of our GAAP product revenues into the software and hardware components to display the significance of software included in total product revenues. |  |
|  |  | Q3'FY21 |  |  |  |  | Q2'FY21 |  |  |  |  | Q3'FY20 |  |
| Software and recurring maintenance and cloud revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product - Software |  | $ | 428 |  |  |  |  | $ | 417 |  |  |  |  | $ | 375 |  |
| Software Maintenance |  | $ | 334 |  |  |  |  | $ | 303 |  |  |  |  | $ | 263 |  |
| Hardware Maintenance Support Contracts |  | $ | 293 |  |  |  |  | $ | 296 |  |  |  |  | $ | 293 |  |
| Software and recurring maintenance and cloud revenue* |  | $ | 1,055 |  |  |  |  | $ | 1,016 |  |  |  |  | $ | 931 |  |
| Software and recurring maintenance and cloud revenue as a percentage of net revenues |  |  | 72 | % |  |  |  | 72 | % |  |  |  | 66 | % |
| Cloud revenue is included in software maintenance revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| *Software and recurring maintenance and cloud revenue is a non-GAAP measure because it includes the software component of our product revenues, but not the hardware component. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'21 Revenue |  |  |  |  | % of Q2 FY'21 Revenue |  |  |  |  | % of Q3 FY'20 Revenue |  |
| Americas |  |  | 53 | % |  |  |  |  | 55 | % |  |  |  |  | 50 | % |
| Americas Commercial |  |  | 43 | % |  |  |  |  | 40 | % |  |  |  |  | 39 | % |
| U.S. Public Sector |  |  | 10 | % |  |  |  |  | 15 | % |  |  |  |  | 11 | % |
| EMEA |  |  | 32 | % |  |  |  |  | 30 | % |  |  |  |  | 35 | % |
| Asia Pacific |  |  | 15 | % |  |  |  |  | 15 | % |  |  |  |  | 15 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'21 Revenue |  |  |  |  | % of Q2 FY'21 Revenue |  |  |  |  | % of Q3 FY'20 Revenue |  |
| Direct |  |  | 24 | % |  |  |  |  | 25 | % |  |  |  |  | 21 | % |
| Indirect |  |  | 76 | % |  |  |  |  | 75 | % |  |  |  |  | 79 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001564590-21-008093:8k_2_02:103]
|  |  | Q3'FY21 |  |  |  |  | Q2'FY21 |  |  |  |  | Q3'FY20 |  |
| Non-GAAP Gross Margin |  |  | 67.3 | % |  |  |  |  | 66.9 | % |  |  |  |  | 67.8 | % |
| Product |  |  | 53.4 | % |  |  |  |  | 53.0 | % |  |  |  |  | 55.4 | % |
| Software Maintenance |  |  | 93.1 | % |  |  |  |  | 93.7 | % |  |  |  |  | 95.4 | % |
| Hardware Maintenance & Other Services |  |  | 73.4 | % |  |  |  |  | 73.4 | % |  |  |  |  | 74.9 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY21 |  |  |  |  | Q2'FY21 |  |  |  |  | Q3'FY20 |  |
| Non-GAAP Income from Operations |  | $ | 322 |  |  |  |  | $ | 291 |  |  |  |  | $ | 312 |  |
| % of Net Revenues |  |  | 21.9 | % |  |  |  |  | 20.6 | % |  |  |  |  | 22.2 | % |
| Non-GAAP Income before Income Taxes |  | $ | 311 |  |  |  |  | $ | 278 |  |  |  |  | $ | 320 |  |
| Non-GAAP Effective Tax Rate |  |  | 19.6 | % |  |  |  |  | 15.1 | % |  |  |  |  | 17.2 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY21 |  |  |  |  | Q2'FY21 |  |  |  |  | Q3'FY20 |  |
| Non-GAAP Net Income |  | $ | 250 |  |  |  |  | $ | 236 |  |  |  |  | $ | 265 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 227 |  |  |  |  |  | 224 |  |  |  |  |  | 229 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.10 |  |  |  |  | $ | 1.05 |  |  |  |  | $ | 1.16 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY21 |  |  |  |  | Q2'FY21 |  |  |  |  | Q3'FY20 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,828 |  |  |  |  | $ | 3,651 |  |  |  |  | $ | 3,573 |  |
| DSO (days) |  |  | 49 |  |  |  |  |  | 51 |  |  |  |  |  | 53 |  |
| DPO (days) |  |  | 62 |  |  |  |  |  | 69 |  |  |  |  |  | 75 |  |
| Inventory Turns |  |  | 19 |  |  |  |  |  | 17 |  |  |  |  |  | 16 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY21 |  |  |  |  | Q2'FY21 |  |  |  |  | Q3'FY20 |  |
| Net Cash Provided by Operating Activities |  | $ | 373 |  |  |  |  | $ | 161 |  |  |  |  | $ | 420 |  |
| Purchases of Property and Equipment |  | $ | 32 |  |  |  |  | $ | 40 |  |  |  |  | $ | 32 |  |
| Free Cash Flow |  | $ | 341 |  |  |  |  | $ | 121 |  |  |  |  | $ | 388 |  |
| Free Cash Flow as % of Net Revenues |  |  | 23.2 | % |  |  |  |  | 8.5 | % |  |  |  |  | 27.6 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |

[0001564590-21-008093:8k_2_02:104]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY21 |  |  | Q2'FY21 |  |  | Q3'FY20 |  |
| NET INCOME |  | $ | 182 |  |  | $ | 137 |  |  | $ | 277 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 15 |  |  |  | 15 |  |  |  | 8 |  |
| Stock-based compensation |  |  | 46 |  |  |  | 49 |  |  |  | 36 |  |
| Litigation settlements |  |  | — |  |  |  | 5 |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | 37 |  |  |  | — |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 3 |  |  |  | — |  |
| Gain on sale of equity investment |  |  | — |  |  |  | (6 | ) |  |  | — |  |
| Income tax effects |  |  | (13 | ) |  |  | (9 | ) |  |  | (6 | ) |
| Income tax expenses from integration of acquired companies |  |  | 17 |  |  |  | 5 |  |  |  | — |  |
| Resolution of income tax matters |  |  | — |  |  |  | — |  |  |  | (50 | ) |
| NON-GAAP NET INCOME |  | $ | 250 |  |  | $ | 236 |  |  | $ | 265 |  |
| COST OF REVENUES |  | $ | 495 |  |  | $ | 483 |  |  | $ | 463 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (12 | ) |  |  | (12 | ) |  |  | (8 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (3 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 480 |  |  | $ | 468 |  |  | $ | 452 |  |
| COST OF PRODUCT REVENUES |  | $ | 369 |  |  | $ | 360 |  |  | $ | 360 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (7 | ) |  |  | (8 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 361 |  |  | $ | 352 |  |  | $ | 351 |  |
| COST OF SOFTWARE MAINTENANCE REVENUES |  | $ | 28 |  |  | $ | 24 |  |  | $ | 12 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | — |  |
| NON-GAAP COST OF SOFTWARE MAINTENANCE REVENUES |  | $ | 23 |  |  | $ | 19 |  |  | $ | 12 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 98 |  |  | $ | 99 |  |  | $ | 91 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (2 | ) |  |  | (2 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 96 |  |  | $ | 97 |  |  | $ | 89 |  |
| GROSS PROFIT |  | $ | 975 |  |  | $ | 933 |  |  | $ | 941 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 12 |  |  |  | 12 |  |  |  | 8 |  |
| Stock-based compensation |  |  | 3 |  |  |  | 3 |  |  |  | 3 |  |
| NON-GAAP GROSS PROFIT |  | $ | 990 |  |  | $ | 948 |  |  | $ | 952 |  |

[0001564590-21-008093:8k_2_02:105]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY21 |  |  | Q2'FY21 |  |  | Q3'FY20 |  |
| SALES AND MARKETING EXPENSES |  | $ | 436 |  |  | $ | 432 |  |  | $ | 402 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (3 | ) |  |  | — |  |
| Stock-based compensation |  |  | (21 | ) |  |  | (24 | ) |  |  | (15 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 412 |  |  | $ | 405 |  |  | $ | 387 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 215 |  |  | $ | 212 |  |  | $ | 211 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (15 | ) |  |  | (15 | ) |  |  | (13 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 200 |  |  | $ | 197 |  |  | $ | 198 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 63 |  |  | $ | 67 |  |  | $ | 60 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (7 | ) |  |  | (7 | ) |  |  | (5 | ) |
| Litigation settlements |  |  | — |  |  |  | (5 | ) |  |  | — |  |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 56 |  |  | $ | 55 |  |  | $ | 55 |  |
| RESTRUCTURING CHARGES |  | $ | — |  |  | $ | 37 |  |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | — |  |  |  | (37 | ) |  |  | — |  |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 3 |  |  | $ | 3 |  |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (3 | ) |  |  | (3 | ) |  |  | — |  |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 717 |  |  | $ | 751 |  |  | $ | 673 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (3 | ) |  |  | — |  |
| Stock-based compensation |  |  | (43 | ) |  |  | (46 | ) |  |  | (33 | ) |
| Litigation settlements |  |  | — |  |  |  | (5 | ) |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | (37 | ) |  |  | — |  |
| Acquisition-related expense |  |  | (3 | ) |  |  | (3 | ) |  |  | — |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 668 |  |  | $ | 657 |  |  | $ | 640 |  |

[0001564590-21-008093:8k_2_02:106]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY21 |  |  | Q2'FY21 |  |  | Q3'FY20 |  |
| INCOME FROM OPERATIONS |  | $ | 258 |  |  | $ | 182 |  |  | $ | 268 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 15 |  |  |  | 15 |  |  |  | 8 |  |
| Stock-based compensation |  |  | 46 |  |  |  | 49 |  |  |  | 36 |  |
| Litigation settlements |  |  | — |  |  |  | 5 |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | 37 |  |  |  | — |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 3 |  |  |  | — |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 322 |  |  | $ | 291 |  |  | $ | 312 |  |
| OTHER INCOME (EXPENSE), NET |  | $ | (11 | ) |  | $ | (7 | ) |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale of equity investment |  |  | — |  |  |  | (6 | ) |  |  | — |  |
| NON-GAAP OTHER INCOME (EXPENSE), NET |  | $ | (11 | ) |  | $ | (13 | ) |  | $ | — |  |
| INCOME BEFORE INCOME TAXES |  | $ | 247 |  |  | $ | 175 |  |  | $ | 276 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 15 |  |  |  | 15 |  |  |  | 8 |  |
| Stock-based compensation |  |  | 46 |  |  |  | 49 |  |  |  | 36 |  |
| Litigation settlements |  |  | — |  |  |  | 5 |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | 37 |  |  |  | — |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 3 |  |  |  | — |  |
| Gain on sale of equity investment |  |  | — |  |  |  | (6 | ) |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 311 |  |  | $ | 278 |  |  | $ | 320 |  |
| PROVISION FOR INCOME TAXES |  | $ | 65 |  |  | $ | 38 |  |  | $ | (1 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 13 |  |  |  | 9 |  |  |  | 6 |  |
| Income tax expenses from integration of acquired companies |  |  | (17 | ) |  |  | (5 | ) |  |  | — |  |
| Resolution of income tax matters |  |  | — |  |  |  | — |  |  |  | 50 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 61 |  |  | $ | 42 |  |  | $ | 55 |  |
| NET INCOME PER SHARE |  | $ | 0.80 |  |  | $ | 0.61 |  |  | $ | 1.21 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.07 |  |  |  | 0.07 |  |  |  | 0.03 |  |
| Stock-based compensation |  |  | 0.20 |  |  |  | 0.22 |  |  |  | 0.16 |  |
| Litigation settlements |  |  | — |  |  |  | 0.02 |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | 0.17 |  |  |  | — |  |
| Acquisition-related expense |  |  | 0.01 |  |  |  | 0.01 |  |  |  | — |  |
| Gain on sale of equity investment |  |  | — |  |  |  | (0.03 | ) |  | — |  |
| Income tax effects |  |  | (0.06 | ) |  |  | (0.04 | ) |  |  | (0.03 | ) |
| Income tax expenses from integration of acquired companies |  |  | 0.07 |  |  |  | 0.02 |  |  |  | — |  |
| Resolution of income tax matters |  |  | — |  |  |  | — |  |  |  | (0.22 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.10 |  |  | $ | 1.05 |  |  | $ | 1.16 |  |

[0001564590-21-008093:8k_2_02:107]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY21 |  |  | Q2'FY21 |  |  | Q3'FY20 |  |
| Gross margin-GAAP |  |  | 66.3 | % |  |  | 65.9 | % |  |  | 67.0 | % |
| Cost of revenues adjustments |  |  | 1.0 | % |  |  | 1.1 | % |  |  | 0.8 | % |
| Gross margin-Non-GAAP |  |  | 67.3 | % |  |  | 66.9 | % |  |  | 67.8 | % |
| GAAP cost of revenues |  | $ | 495 |  |  | $ | 483 |  |  | $ | 463 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (12 | ) |  |  | (12 | ) |  |  | (8 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (3 | ) |
| Non-GAAP cost of revenues |  | $ | 480 |  |  | $ | 468 |  |  | $ | 452 |  |
| Net revenues |  | $ | 1,470 |  |  | $ | 1,416 |  |  | $ | 1,404 |  |

[0001564590-21-008093:8k_2_02:108]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY21 |  |  | Q2'FY21 |  |  | Q3'FY20 |  |
| Product gross margin-GAAP |  |  | 52.4 | % |  |  | 51.9 | % |  |  | 54.3 | % |
| Cost of product revenues adjustments |  |  | 1.0 | % |  |  | 1.1 | % |  |  | 1.1 | % |
| Product gross margin-Non-GAAP |  |  | 53.4 | % |  |  | 53.0 | % |  |  | 55.4 | % |
| GAAP cost of product revenues |  | $ | 369 |  |  | $ | 360 |  |  | $ | 360 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (7 | ) |  |  | (8 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 361 |  |  | $ | 352 |  |  | $ | 351 |  |
| Product revenues |  | $ | 775 |  |  | $ | 749 |  |  | $ | 787 |  |

[0001564590-21-008093:8k_2_02:109]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| SOFTWARE MAINTENANCE GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY21 |  |  | Q2'FY21 |  |  | Q3'FY20 |  |
| Software maintenance gross margin-GAAP |  |  | 91.6 | % |  |  | 92.1 | % |  |  | 95.4 | % |
| Cost of software maintenance revenues adjustment |  |  | 1.5 | % |  |  | 1.7 | % |  |  | — | % |
| Software maintenance gross margin-Non-GAAP |  |  | 93.1 | % |  |  | 93.7 | % |  |  | 95.4 | % |
| GAAP cost of software maintenance revenues |  | $ | 28 |  |  | $ | 24 |  |  | $ | 12 |  |
| Cost of software maintenance revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | — |  |
| Non-GAAP cost of software maintenance revenues |  | $ | 23 |  |  | $ | 19 |  |  | $ | 12 |  |
| Software maintenance revenues |  | $ | 334 |  |  | $ | 303 |  |  | $ | 263 |  |

[0001564590-21-008093:8k_2_02:110]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY21 |  |  | Q2'FY21 |  |  | Q3'FY20 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 72.9 | % |  |  | 72.8 | % |  |  | 74.3 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.6 | % |  |  | 0.5 | % |  |  | 0.6 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 73.4 | % |  |  | 73.4 | % |  |  | 74.9 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 98 |  |  | $ | 99 |  |  | $ | 91 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (2 | ) |  |  | (2 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 96 |  |  | $ | 97 |  |  | $ | 89 |  |
| Hardware maintenance and other services revenues |  | $ | 361 |  |  | $ | 364 |  |  | $ | 354 |  |

[0001564590-21-008093:8k_2_02:111]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q3'FY21 |  |  | Q2'FY21 |  |  | Q3'FY20 |  |
| GAAP effective tax rate |  |  | 26.3 | % |  |  | 21.7 | % |  |  | (0.4 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 0.2 | % |  |  | (3.8 | )% |  |  | 2.0 | % |
| Income tax expenses from integration of acquired companies |  |  | (6.9 | )% |  |  | (2.9 | )% |  |  | — | % |
| Resolution of income tax matters |  |  | — | % |  |  | — | % |  |  | 15.6 | % |
| Non-GAAP effective tax rate |  |  | 19.6 | % |  |  | 15.1 | % |  |  | 17.2 | % |

[0001564590-21-008093:8k_2_02:112]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q3'FY21 |  |  | Q2'FY21 |  |  | Q3'FY20 |  |
| Net cash provided by operating activities |  | $ | 373 |  |  | $ | 161 |  |  | $ | 420 |  |
| Purchases of property and equipment |  |  | (32 | ) |  |  | (40 | ) |  |  | (32 | ) |
| Free cash flow |  | $ | 341 |  |  | $ | 121 |  |  | $ | 388 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q3'FY21 |  |  | Q2'FY21 |  |  | Q3'FY20 |  |
| Net revenues |  | $ | 1,470 |  |  | $ | 1,416 |  |  | $ | 1,404 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | 128 |  |  |  | 40 |  |  |  | 104 |  |
| Billings |  | $ | 1,598 |  |  | $ | 1,456 |  |  | $ | 1,508 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |  |  |  |  |  |  |  |  |  |  |  |

[0001564590-21-008093:8k_2_02:113]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| FOURTH QUARTER FISCAL 2021 |  |
|  |  | Fourth Quarter |  |
|  |  | Fiscal 2021 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $1.06 - $1.14 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Fourth Quarter Fiscal 2021: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.04 | ) |
| Stock-based compensation expense |  |  | (0.21 | ) |
| Income tax effects |  |  | (0.03 | ) |
| Total Adjustments |  |  | (0.28 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.78 - $0.86 |  |

[0001564590-21-008093:8k_2_02:114]
Some items may not add or recalculate due to rounding.

[0001564590-21-008093:8k_2_02:115]
Contacts:

[0001564590-21-008093:8k_2_02:116]
(Press)

[0001564590-21-008093:8k_2_02:117]
Chris Drago

[0001564590-21-008093:8k_2_02:118]
1 831 900 888

[0001564590-21-008093:8k_2_02:119]
chris.drago@netapp.com

[0001564590-21-008093:8k_2_02:120]
(Investors)

[0001564590-21-008093:8k_2_02:121]
Lance Berger

[0001564590-21-008093:8k_2_02:122]
1 408 822 6628

[0001564590-21-008093:8k_2_02:123]
lance.berger@netapp.com
