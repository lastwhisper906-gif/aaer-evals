# NTAP MD&A — 0001564590-21-009843


## mdna

[0001564590-21-009843:mdna:1]
[same as prior period, unchanged from 0001564590-20-056069:mdna:1]

[0001564590-21-009843:mdna:2]
[same as prior period, unchanged from 0001564590-20-056069:mdna:2]

[0001564590-21-009843:mdna:3]
[same as prior period, unchanged from 0001564590-20-056069:mdna:3]

[0001564590-21-009843:mdna:4]
[same as prior period, unchanged from 0001564590-20-056069:mdna:4]

[0001564590-21-009843:mdna:5]
[same as prior period, unchanged from 0001564590-20-056069:mdna:5]

[0001564590-21-009843:mdna:6]
[same as prior period, unchanged from 0001564590-20-056069:mdna:6]

[0001564590-21-009843:mdna:7]
[same as prior period, unchanged from 0001564590-20-056069:mdna:7]

[0001564590-21-009843:mdna:8]
[same as prior period, unchanged from 0001564590-20-056069:mdna:8]

[0001564590-21-009843:mdna:9]
[same as prior period, unchanged from 0001564590-20-056069:mdna:9]

[0001564590-21-009843:mdna:10]
[same as prior period, unchanged from 0001564590-20-056069:mdna:10]

[0001564590-21-009843:mdna:11]
[same as prior period, unchanged from 0001564590-20-056069:mdna:11]

[0001564590-21-009843:mdna:12]
[same as prior period, unchanged from 0001564590-20-056069:mdna:12]

[0001564590-21-009843:mdna:13]
[same as prior period, unchanged from 0001564590-20-056069:mdna:13]

[0001564590-21-009843:mdna:14]
[same as prior period, unchanged from 0001564590-20-056069:mdna:14]

[0001564590-21-009843:mdna:15]
[same as prior period, unchanged from 0001564590-20-056069:mdna:15]

[0001564590-21-009843:mdna:16]
[same as prior period, unchanged from 0001564590-20-056069:mdna:16]

[0001564590-21-009843:mdna:17]
[same as prior period, unchanged from 0001564590-20-056069:mdna:17]

[0001564590-21-009843:mdna:18]
During the first nine months of fiscal 2021, due to the macroeconomic uncertainty caused by COVID-19, we continue to observe certain customers delay purchases of our products and services, while other customers accelerate or place new orders to address the demands of remote working and digital business, though on a net basis the impact to product revenues was unfavorable. We also continue to experience certain logistical challenges in delivering our products and services to customers in certain regions, and minor supply chain constraints.

[0001564590-21-009843:mdna:19]
We believe our existing balances of cash, cash equivalents and investments, cash generated from operations, and ability to access capital markets and committed lines of credit will be sufficient to satisfy our working capital needs, capital expenditures, dividends, stock repurchases, required debt repayments and other liquidity requirements associated with our operations.

[0001564590-21-009843:mdna:20]
[same as prior period, unchanged from 0001564590-20-056069:mdna:20]

[0001564590-21-009843:mdna:21]
[same as prior period, unchanged from 0001564590-20-056069:mdna:21]

[0001564590-21-009843:mdna:22]
[same as prior period, unchanged from 0001564590-20-056069:mdna:22]

[0001564590-21-009843:mdna:23]
[same as prior period, unchanged from 0001564590-20-056069:mdna:23]

[0001564590-21-009843:mdna:24]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Net revenues |  | $ | 1,470 |  |  | $ | 1,404 |  |  | $ | 4,189 |  |  | $ | 4,011 |  |
| Gross profit |  | $ | 975 |  |  | $ | 941 |  |  | $ | 2,780 |  |  | $ | 2,682 |  |
| Gross profit margin percentage |  |  | 66 | % |  |  | 67 | % |  |  | 66 | % |  |  | 67 | % |
| Income from operations |  | $ | 258 |  |  | $ | 268 |  |  | $ | 576 |  |  | $ | 668 |  |
| Income from operations as a percentage of net revenues |  |  | 18 | % |  |  | 19 | % |  |  | 14 | % |  |  | 17 | % |
| Net income |  | $ | 182 |  |  | $ | 277 |  |  | $ | 396 |  |  | $ | 623 |  |
| Diluted net income per share |  | $ | 0.80 |  |  | $ | 1.21 |  |  | $ | 1.76 |  |  | $ | 2.64 |  |
| Net cash provided by operating activities |  | $ | 373 |  |  | $ | 420 |  |  | $ | 774 |  |  | $ | 677 |  |

[0001564590-21-009843:mdna:25]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,828 |  |  | $ | 3,698 |  |

[0001564590-21-009843:mdna:26]
Stock Repurchase and Dividend Activity

[0001564590-21-009843:mdna:27]
During the third quarter of fiscal 2021, we repurchased 0.8 million shares of our common stock at an average price of $64.78 per share, for an aggregate of $50 million. We also declared aggregate cash dividends of $0.48 per share in that period, for which we paid $107 million. During the first nine months of fiscal 2021, aggregate cash dividends declared totaled $1.44 per share, for which we paid an aggregate of $321 million.

[0001564590-21-009843:mdna:28]
[same as prior period, unchanged from 0001564590-20-056069:mdna:30]

[0001564590-21-009843:mdna:29]
[same as prior period, unchanged from 0001564590-20-056069:mdna:31]

[0001564590-21-009843:mdna:30]
[same as prior period, unchanged from 0001564590-20-056069:mdna:32]

[0001564590-21-009843:mdna:31]
[same as prior period, unchanged from 0001564590-20-056069:mdna:33]

[0001564590-21-009843:mdna:32]
See Note 2 – Recently Adopted Accounting Standards of the Notes to Condensed Consolidated Financial Statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on our financial statements.

[0001564590-21-009843:mdna:33]
[same as prior period, unchanged from 0001564590-20-056069:mdna:36]

[0001564590-21-009843:mdna:34]
[same as prior period, unchanged from 0001564590-20-056069:mdna:37]

[0001564590-21-009843:mdna:35]
[same as prior period, unchanged from 0001564590-20-056069:mdna:35]

[0001564590-21-009843:mdna:36]
The following table sets forth certain condensed consolidated statements of operations data as a percentage of net revenues for the periods indicated:

[0001564590-21-009843:mdna:37]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 53 | % |  |  | 56 | % |  |  | 51 | % |  |  | 55 | % |  |
| Software maintenance |  |  | 23 |  |  |  | 19 |  |  |  | 22 |  |  |  | 19 |  |  |
| Hardware maintenance and other services |  |  | 25 |  |  |  | 25 |  |  |  | 26 |  |  |  | 26 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 25 |  |  |  | 26 |  |  |  | 25 |  |  |  | 25 |  |  |
| Cost of software maintenance |  |  | 2 |  |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 7 |  |  |  | 6 |  |  |  | 7 |  |  |  | 7 |  |  |
| Gross profit |  |  | 66 |  |  |  | 67 |  |  |  | 66 |  |  |  | 67 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 30 |  |  |  | 29 |  |  |  | 31 |  |  |  | 30 |  |  |
| Research and development |  |  | 15 |  |  |  | 15 |  |  |  | 16 |  |  |  | 16 |  |  |
| General and administrative |  |  | 4 |  |  |  | 4 |  |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |
| Total operating expenses |  |  | 49 |  |  |  | 48 |  |  |  | 53 |  |  |  | 50 |  |  |
| Income from operations |  |  | 18 |  |  |  | 19 |  |  |  | 14 |  |  |  | 17 |  |  |
| Other income (expense), net |  |  | (1 | ) |  |  | 1 |  |  |  | (1 | ) |  |  | 1 |  |  |
| Income before income taxes |  |  | 17 |  |  |  | 20 |  |  |  | 13 |  |  |  | 17 |  |  |
| Provision (benefit) for income taxes |  |  | 4 |  |  |  | — |  |  |  | 3 |  |  |  | 2 |  |  |
| Net income |  |  | 12 | % |  |  | 20 | % |  |  | 9 | % |  |  | 16 | % |  |

[0001564590-21-009843:mdna:38]
[same as prior period, unchanged from 0001564590-20-056069:mdna:40]

[0001564590-21-009843:mdna:39]
[same as prior period, unchanged from 0001564590-20-056069:mdna:41]

[0001564590-21-009843:mdna:40]
[same as prior period, unchanged from 0001564590-20-056069:mdna:42]

[0001564590-21-009843:mdna:41]
Net revenues for the third quarter and first nine months of fiscal 2021 were $1,470 million and $4,189 million, respectively, reflecting an increase of $66 million, or 5%, and $178 million, or 4%, respectively, compared to the corresponding periods of the prior year. The growth in net revenues reflects an increase in software maintenance revenues and hardware maintenance and other services revenues, offset by a decrease in product revenues. For the third quarter of fiscal 2021, net revenues benefited by approximately two percentage points from fluctuations in foreign currency exchanges rates. For the first nine months of fiscal 2021, software and hardware maintenance revenues benefited from the extra week in our first quarter of fiscal 2021.

[0001564590-21-009843:mdna:42]
Gross profit as a percentage of net revenues for the third quarter and first nine months of fiscal 2021 decreased by approximately one percentage point each compared to the corresponding periods in fiscal 2020, primarily due to a reduction in gross profit margins on product revenues. Gross profit margins on product revenues decreased by two percentage points and three percentage points in the third quarter and first nine months of fiscal 2021, respectively, compared to the corresponding periods of fiscal 2020 primarily due to a decline in the average selling prices of our products. For the first nine months of fiscal 2021 our gross profit margins on product revenues were also impacted by an increase in average unit materials costs. The decline in gross profit margins on product revenues was partially offset by an increase in software maintenance revenues.

[0001564590-21-009843:mdna:43]
Sales and marketing, research and development, and general and administrative expenses for the third quarter and first nine months of fiscal 2021 totaled $714 million, or 49%, and $2,148 million, or 51% of net revenues, respectively, reflecting an increase of approximately one percentage point in both the third quarter and first nine months of fiscal 2021 compared to the corresponding periods of fiscal 2020.

[0001564590-21-009843:mdna:44]
[same as prior period, unchanged from 0001564590-20-056069:mdna:47]

[0001564590-21-009843:mdna:45]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |
| Net revenues |  | $ | 1,470 |  |  | $ | 1,404 |  |  |  | 5 | % |  | $ | 4,189 |  |  | $ | 4,011 |  |  |  | 4 | % |

[0001564590-21-009843:mdna:46]
[same as prior period, unchanged from 0001564590-20-056069:mdna:46]

[0001564590-21-009843:mdna:47]
The increase in net revenues for the third quarter and first nine months of fiscal 2021 compared to the corresponding periods of fiscal 2020 was primarily due to an increase in hardware and software maintenance revenues, which in the first nine months of 2021 benefited from an additional week in that period. Product revenues as a percentage of net revenues decreased by approximately three percentage points and four percentage points in the third quarter and first nine months of fiscal 2021, respectively, compared to the corresponding periods of fiscal 2020. Fluctuations in foreign currency exchange rates benefited third quarter net revenues by approximately two percentage points for fiscal 2021 compared to the corresponding period of fiscal 2020.

[0001564590-21-009843:mdna:48]
[same as prior period, unchanged from 0001564590-20-056069:mdna:50]

[0001564590-21-009843:mdna:49]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 25 | % |  |  | 24 | % |  |  | 25 | % |
| Tech Data Corporation |  |  | 19 | % |  |  | 20 | % |  |  | 20 | % |  |  | 20 | % |

[0001564590-21-009843:mdna:50]
[same as prior period, unchanged from 0001564590-20-056069:mdna:52]

[0001564590-21-009843:mdna:51]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |
| Product revenues |  | $ | 775 |  |  | $ | 787 |  |  |  | (2 | )% |  | $ | 2,151 |  |  | $ | 2,202 |  |  |  | (2 | )% |

[0001564590-21-009843:mdna:52]
Product revenues are derived through the sale of our data solutions and consist of sales of configured all-flash array and Hybrid systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, NetApp HCI, StorageGrid, OEM products and add-on optional software.

[0001564590-21-009843:mdna:53]
Total product revenues decreased in the third quarter and first nine months of fiscal 2021 compared to the corresponding periods of the prior year primarily due to less favorable macroeconomic conditions in the current year, in part due to the economic uncertainty caused by the COVID-19 pandemic. While sales of all-flash array systems increased in the current year, this increase was more than offset by a decline in sales of our other products. Fluctuations in foreign currency exchange rates benefited third quarter product revenues by approximately two percentage points for fiscal 2021 compared to the corresponding period of fiscal 2020.

[0001564590-21-009843:mdna:54]
[same as prior period, unchanged from 0001564590-20-056069:mdna:56]

[0001564590-21-009843:mdna:55]
Revenues from the hardware component of product revenues totaled $347 million, representing 45% of product revenues, in the third quarter of fiscal 2021, compared to $412 million, representing 52% of product revenues, in the corresponding period of the prior year. Revenues from the hardware component of product revenues totaled $995 million, representing 46% of product revenues, in the first nine months of fiscal 2021, compared to $1,155 million, representing 52% of product revenues, in the first nine months of fiscal 2020. The software component of product revenues totaled $428 million, representing 55% of product revenues, in the third quarter of fiscal 2021, compared to $375 million, representing 48% of product revenues, in the corresponding period of the prior year. The software component of product revenues totaled $1,156 million, representing 54% of product revenues, in the first nine months of fiscal 2021, compared to $1,047 million, representing 48% of product revenues, in the corresponding period of the prior year. The increase in the software component percentage of product revenues in the third quarter and first nine months of fiscal 2021 is primarily due to a higher mix of all-flash array systems revenues, which contain a higher proportion of software components than other products.

[0001564590-21-009843:mdna:56]
[same as prior period, unchanged from 0001564590-20-056069:mdna:58]

[0001564590-21-009843:mdna:57]
[same as prior period, unchanged from 0001564590-20-056069:mdna:59]

[0001564590-21-009843:mdna:58]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 334 |  |  | $ | 263 |  |  |  | 27 | % |  | $ | 938 |  |  | $ | 767 |  |  |  | 22 | % |

[0001564590-21-009843:mdna:59]
[same as prior period, unchanged from 0001564590-20-056069:mdna:61]

[0001564590-21-009843:mdna:60]
The growth in software maintenance revenues reflects higher Public Cloud Services revenue and the higher aggregate contract value of the installed base under software maintenance contracts, which is recognized as revenue ratably over the terms of the underlying contracts. Software maintenance revenues in the third quarter and first nine months of fiscal 2021 benefited from the continued growth in all-flash array product sales, as all flash systems carry a higher support dollar content than our other products. Software maintenance revenues in the first nine months of fiscal 2021 were favorably impacted by the additional week of deferred revenue amortization in that period, which contributed approximately $20 million of additional revenues.

[0001564590-21-009843:mdna:61]
[same as prior period, unchanged from 0001564590-20-056069:mdna:63]

[0001564590-21-009843:mdna:62]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 361 |  |  | $ | 354 |  |  |  | 2 | % |  | $ | 1,100 |  |  | $ | 1,042 |  |  |  | 6 | % |

[0001564590-21-009843:mdna:63]
[same as prior period, unchanged from 0001564590-20-056069:mdna:65]

[0001564590-21-009843:mdna:64]
Hardware maintenance contract revenues were flat at $293 million in the third quarter of each fiscal 2021 and fiscal 2020, while they were $896 million for the first nine months of fiscal 2021, compared to $863 million for the corresponding period of fiscal 2020, reflecting an increase of 4%. The increase in the first nine months of fiscal 2021 is partially due to the additional week in that period which contributed approximately $20 million of additional revenues.

[0001564590-21-009843:mdna:65]
Professional services and educational and training services revenues were $68 million and $204 million, respectively, for the third quarter and first nine months of fiscal 2021, compared to $61 million and $179 million, respectively, for the corresponding periods of the prior year. The increase in the first nine months of fiscal 2021 is partially due to the additional week in that period.

[0001564590-21-009843:mdna:66]
[same as prior period, unchanged from 0001564590-20-056069:mdna:68]

[0001564590-21-009843:mdna:67]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | January 29, 2021 |  |  | January 24, 2020 |  |
| United States, Canada and Latin America (Americas) |  |  | 53 | % |  |  | 50 | % |  |  | 54 | % |  |  | 52 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 32 | % |  |  | 35 | % |  |  | 31 | % |  |  | 32 | % |
| Asia Pacific (APAC) |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |

[0001564590-21-009843:mdna:68]
[same as prior period, unchanged from 0001564590-20-056069:mdna:70]

[0001564590-21-009843:mdna:69]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Demand across geographies was relatively consistent in the third quarter and first nine months of fiscal 2021 as compared to the corresponding periods of the prior year.

[0001564590-21-009843:mdna:70]
[same as prior period, unchanged from 0001564590-20-056069:mdna:72]

[0001564590-21-009843:mdna:71]
[same as prior period, unchanged from 0001564590-20-056069:mdna:73]

[0001564590-21-009843:mdna:72]
[same as prior period, unchanged from 0001564590-20-056069:mdna:74]

[0001564590-21-009843:mdna:73]
[same as prior period, unchanged from 0001564590-20-056069:mdna:75]

[0001564590-21-009843:mdna:74]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |
| Cost of product revenues |  | $ | 369 |  |  | $ | 360 |  |  |  | 3 | % |  | $ | 1,045 |  |  | $ | 1,013 |  |  |  | 3 | % |

[0001564590-21-009843:mdna:75]
[same as prior period, unchanged from 0001564590-20-056069:mdna:77]

[0001564590-21-009843:mdna:76]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2021 to Fiscal 2020 |  |  | Fiscal 2021 to Fiscal 2020 |  |
| Materials costs |  |  | 4 |  |  |  | 6 |  |
| Excess and obsolete inventory |  |  | (2 | ) |  |  | (2 | ) |
| Warranty |  |  | (1 | ) |  |  | (1 | ) |
| Other |  |  | 2 |  |  |  | — |  |
| Total change |  |  | 3 |  |  |  | 3 |  |

[0001564590-21-009843:mdna:77]
Cost of product revenues represented 48% and 49% of product revenues for the third quarter and first nine months of fiscal 2021, respectively, compared to 46% for each of the corresponding periods of fiscal 2020. Materials costs represented 89% of product costs for each of the third quarter and first nine months of fiscal 2021, compared to 87% and 85% in the corresponding periods of fiscal 2020.

[0001564590-21-009843:mdna:78]
Materials costs increased by approximately $15 million and $62 million in the third quarter and first nine months of fiscal 2021, respectively, compared to the corresponding periods of the prior year. The trend in product mix toward all flash-array systems, which carry higher materials costs than hybrid systems, was the primary driver of these increases. The average unit materials cost of all flash-array systems also increased in the first nine months of fiscal 2021 compared to the corresponding period of fiscal 2020, due to an increase in the price of certain product components, which adversely impacted product margins. Excess and obsolete inventory reserves and warranty expenses were lower in the third quarter and first nine months of fiscal 2021 compared to the corresponding periods of fiscal 2020.

[0001564590-21-009843:mdna:79]
In addition to the increase in average unit materials costs of all flash-array systems described above, product margins were also adversely impacted in the third quarter and first nine months of fiscal 2021 by a decrease in the average selling prices of most of our products.

[0001564590-21-009843:mdna:80]
[same as prior period, unchanged from 0001564590-20-056069:mdna:82]

[0001564590-21-009843:mdna:81]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 28 |  |  | $ | 12 |  |  |  | 133 | % |  | $ | 67 |  |  | $ | 33 |  |  |  | 103 | % |

[0001564590-21-009843:mdna:82]
Cost of software maintenance revenues increased in the third quarter and first nine months of fiscal 2021 compared to the corresponding periods of fiscal 2020, reflecting the increase in Public Cloud Services revenue and an increase in amortization expense for acquired developed technology. Cost of software maintenance revenues represented 8% and 7% of software maintenance revenues, respectively, for the third quarter and first nine months of fiscal 2021, and 5% and 4%, respectively, for the corresponding periods of fiscal 2020.

[0001564590-21-009843:mdna:83]
[same as prior period, unchanged from 0001564590-20-056069:mdna:85]

[0001564590-21-009843:mdna:84]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 98 |  |  | $ | 91 |  |  |  | 8 | % |  | $ | 297 |  |  | $ | 283 |  |  |  | 5 | % |

[0001564590-21-009843:mdna:85]
Cost of hardware maintenance and other services revenues increased in the third quarter and first nine months of fiscal 2021 compared to the corresponding periods of fiscal 2020, in line with the increase in hardware maintenance and other services revenues. Costs represented 27% of hardware maintenance and other services revenues in both the third quarter and first nine months of fiscal 2021, compared to 26% and 27%, respectively, in the corresponding periods of fiscal 2020.

[0001564590-21-009843:mdna:86]
[same as prior period, unchanged from 0001564590-20-056069:mdna:88]

[0001564590-21-009843:mdna:87]
[same as prior period, unchanged from 0001564590-20-056069:mdna:89]

[0001564590-21-009843:mdna:88]
[same as prior period, unchanged from 0001564590-20-056069:mdna:90]

[0001564590-21-009843:mdna:89]
[same as prior period, unchanged from 0001564590-20-056069:mdna:91]

[0001564590-21-009843:mdna:90]
Total compensation costs included in operating expenses increased by $64 million, or 17%, in the third quarter of fiscal 2021 compared to the corresponding period of the prior year, primarily reflecting higher incentive compensation expense and a 2% increase in average headcount.

[0001564590-21-009843:mdna:91]
Total compensation costs included in operating expenses increased $165 million, or 15% in the first nine months of fiscal 2021, compared to the corresponding period of the prior year, reflecting an increase in average headcount of 4%, higher incentive compensation expense, and the impact of one additional week in the first quarter of fiscal 2021.

[0001564590-21-009843:mdna:92]
[same as prior period, unchanged from 0001564590-20-056069:mdna:94]

[0001564590-21-009843:mdna:93]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 436 |  |  | $ | 402 |  |  |  | 8 | % |  | $ | 1,297 |  |  | $ | 1,196 |  |  |  | 8 | % |

[0001564590-21-009843:mdna:94]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, allocated facilities and information technology (IT) costs, advertising and marketing promotional expense and travel and entertainment expense. Changes in sales and marketing expense consisted of the following (in percentage points of the total change):

[0001564590-21-009843:mdna:95]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2021 to Fiscal 2020 |  |  | Fiscal 2021 to Fiscal 2020 |  |
| Compensation costs |  |  | 10 |  |  |  | 9 |  |
| Commissions |  |  | 1 |  |  |  | 3 |  |
| Advertising and marketing promotional expense |  |  | 1 |  |  |  | 1 |  |
| Travel and entertainment |  |  | (4 | ) |  |  | (4 | ) |
| Other |  |  | — |  |  |  | (1 | ) |
| Total change |  |  | 8 |  |  |  | 8 |  |

[0001564590-21-009843:mdna:96]
The increase in compensation costs for the third quarter and first nine months of fiscal 2021 reflected an increase in average headcount of 7% each, compared to the corresponding periods of the prior year, with this expansion of our sales and marketing teams supporting our ability to execute on key market opportunities. Compensation costs for the nine months of fiscal 2021 also reflected the impact of one additional week in the first quarter.

[0001564590-21-009843:mdna:97]
The increase in commissions expense for the third quarter and first nine months of fiscal 2021 is primarily due to higher performance against sales goals than in the corresponding periods of fiscal year 2020. Advertising and marketing promotional expense increased in the third quarter of fiscal 2021 compared to the corresponding period of the prior year, primarily due to higher spending levels on certain projects. Travel and entertainment spend decreased significantly due to the ongoing COVID-19 pandemic.

[0001564590-21-009843:mdna:98]
[same as prior period, unchanged from 0001564590-20-056069:mdna:100]

[0001564590-21-009843:mdna:99]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |
| Research and development expenses |  | $ | 215 |  |  | $ | 211 |  |  |  | 2 | % |  | $ | 660 |  |  | $ | 635 |  |  |  | 4 | % |

[0001564590-21-009843:mdna:100]
Research and development expenses consist primarily of compensation costs, allocated facilities and IT costs, depreciation, equipment and software-related costs, prototypes, non-recurring engineering charges and other outside services costs. Changes in research and development expense consisted of the following (in percentage points of the total change):

[0001564590-21-009843:mdna:101]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2021 to Fiscal 2020 |  |  | Fiscal 2021 to Fiscal 2020 |  |
| Compensation costs |  |  | 7 |  |  |  | 7 |  |
| Development projects and outside services |  |  | (2 | ) |  |  | (1 | ) |
| Facilities and IT support costs |  |  | (2 | ) |  |  | (1 | ) |
| Travel and entertainment |  |  | (1 | ) |  |  | (1 | ) |
| Total change |  |  | 2 |  |  |  | 4 |  |

[0001564590-21-009843:mdna:102]
34

[0001564590-21-009843:mdna:103]
The increase in compensation costs for the third quarter and first nine months of fiscal 2021 compared to the corresponding periods in the prior year was primarily due to higher incentive compensation expense as a result of stronger company achievement against financial targets. Compensation costs for the first nine months of fiscal 2021 also reflected the impact of one additional week in the first quarter. The decrease in development projects and outside services were primarily due to the lower spending on certain engineering projects. The decrease in facilities and IT support costs were primarily due to cost containment efforts, and lower travel and entertainment expense was due to the impact of the ongoing COVID-19 pandemic.

[0001564590-21-009843:mdna:104]
[same as prior period, unchanged from 0001564590-20-056069:mdna:105]

[0001564590-21-009843:mdna:105]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |
| General and administrative expenses |  | $ | 63 |  |  | $ | 60 |  |  |  | 5 | % |  | $ | 191 |  |  | $ | 200 |  |  |  | (5 | )% |

[0001564590-21-009843:mdna:106]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and allocated facilities and IT support costs. Changes in general and administrative expense consisted of the following (in percentage points of the total change):

[0001564590-21-009843:mdna:107]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2021 to Fiscal 2020 |  |  | Fiscal 2021 to Fiscal 2020 |  |
| Compensation costs |  |  | 13 |  |  |  | 7 |  |
| Professional and legal fees and outside services |  |  | (12 | ) |  |  | (15 | ) |
| Litigation settlement |  |  | — |  |  |  | 3 |  |
| Facilities and IT support costs |  |  | 2 |  |  |  | 1 |  |
| Other |  |  | 2 |  |  |  | (1 | ) |
| Total change |  |  | 5 |  |  |  | (5 | ) |

[0001564590-21-009843:mdna:108]
The increase in compensation costs in the third quarter and first nine months of fiscal 2021 compared to the corresponding periods of the prior year was primarily due to higher incentive compensation expense as a result of stronger company achievement against financial targets. The decrease in professional and legal fees and outside services expense in the third quarter and first nine months of fiscal 2021 was primarily due to lower spending on business transformation projects in the current year. The increase in facilities and IT support costs was primarily due to higher spending levels on IT projects. During the second quarter of fiscal 2021, we incurred a litigation settlement charge of approximately $5 million that was included in general and administrative expenses in our condensed consolidated statements of operations.

[0001564590-21-009843:mdna:109]
[same as prior period, unchanged from 0001564590-20-056069:mdna:110]

[0001564590-21-009843:mdna:110]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |
| Restructuring charges |  | $ | — |  |  | $ | — |  |  | NM |  | $ | 42 |  |  | $ | 21 |  |  |  | 100 | % |

[0001564590-21-009843:mdna:111]
[same as prior period, unchanged from 0001564590-20-056069:mdna:112]

[0001564590-21-009843:mdna:112]
In the second quarter of fiscal 2021, we announced a restructuring plan (the August 2020 Plan) to optimize our business and fund our biggest opportunities, which included a reduction in our global workforce of approximately 5%. Charges related to the plan consisted primarily of employee severance-related costs. We completed substantially all activities under the plan by the end of the third quarter fiscal 2021. See Note 12 – Restructuring Charges of the Notes to Condensed Consolidated Financial Statements for more details.

[0001564590-21-009843:mdna:113]
[same as prior period, unchanged from 0001564590-20-056069:mdna:114]

[0001564590-21-009843:mdna:114]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |
| Acquisition-related expense |  | $ | 3 |  |  |  | — |  |  | NM |  | $ | 14 |  |  | $ | — |  |  | NM |

[0001564590-21-009843:mdna:115]
[same as prior period, unchanged from 0001564590-20-056069:mdna:116]

[0001564590-21-009843:mdna:116]
35

[0001564590-21-009843:mdna:117]
In the first nine months of fiscal 2021, we incurred $14 million of acquisition-related costs, primarily legal and consulting fees associated with our acquisition and subsequent integration of Spot Inc.

[0001564590-21-009843:mdna:118]
[same as prior period, unchanged from 0001564590-20-056069:mdna:118]

[0001564590-21-009843:mdna:119]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |
| Gain on sale or derecognition of assets |  | $ | — |  |  | $ | — |  |  | NM |  | $ | — |  |  | $ | (38 | ) |  | NM |

[0001564590-21-009843:mdna:120]
[same as prior period, unchanged from 0001564590-20-056069:mdna:120]

[0001564590-21-009843:mdna:121]
[same as prior period, unchanged from 0001564590-20-056069:mdna:121]

[0001564590-21-009843:mdna:122]
[same as prior period, unchanged from 0001564590-20-056069:mdna:122]

[0001564590-21-009843:mdna:123]
[same as prior period, unchanged from 0001564590-20-056069:mdna:123]

[0001564590-21-009843:mdna:124]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |
| Interest income |  | $ | 2 |  |  | $ | 10 |  |  |  | (80 | )% |  | $ | 7 |  |  | $ | 41 |  |  |  | (83 | )% |
| Interest expense |  |  | (19 | ) |  |  | (14 | ) |  |  | 36 | % |  |  | (55 | ) |  |  | (41 | ) |  |  | 34 | % |
| Other income (expense), net |  |  | 6 |  |  |  | 12 |  |  |  | (50 | )% |  |  | (2 | ) |  |  | 26 |  |  |  | (108 | )% |
| Total |  | $ | (11 | ) |  | $ | 8 |  |  |  | (238 | )% |  | $ | (50 | ) |  | $ | 26 |  |  |  | (292 | )% |

[0001564590-21-009843:mdna:125]
Interest income decreased in the third quarter and first nine months of fiscal 2021 compared to the corresponding periods of the prior year due to both a reduction in the size of our investment portfolio and lower yields earned on the investments.

[0001564590-21-009843:mdna:126]
Interest expense increased in the third quarter and first nine months of fiscal 2021 compared to the corresponding periods of the prior year, as we issued Senior Notes in aggregate principal amount of $2.0 billion in the first quarter of fiscal 2021. The impact from the issuance of these Senior Notes was partially offset by the extinguishment of our Senior Notes due June 2021 in the first quarter of fiscal 2021, and a lower average outstanding commercial paper balance during fiscal 2021.

[0001564590-21-009843:mdna:127]
In the first nine months of fiscal 2021, Other income (expense), net includes a $6 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $8 million. This benefit was more than offset in the first nine months period by a $14 million loss recognized from the extinguishment of our Senior Notes due June 2021 in the first quarter of fiscal 2021. Other income (expense), net for the first nine months of fiscal 2020 includes a $14 million gain we realized on the sale of available-for-sale debt securities during that period. The remaining fluctuations in other income (expense), net are primarily due to foreign exchange gains and losses.

[0001564590-21-009843:mdna:128]
[same as prior period, unchanged from 0001564590-20-056069:mdna:128]

[0001564590-21-009843:mdna:129]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  | January 29, 2021 |  |  | January 24, 2020 |  |  | % Change |  |
| Provision (benefit) for income taxes |  | $ | 65 |  |  | $ | (1 | ) |  | NM |  | $ | 130 |  |  | $ | 71 |  |  |  | 83 | % |

[0001564590-21-009843:mdna:130]
NM – Not Meaningful

[0001564590-21-009843:mdna:131]
Our effective tax rate for the third quarter of fiscal 2021 was 26.3% compared to (0.4)% for the third quarter of fiscal 2020. Our effective tax rate for the first nine months of fiscal 2021 was 24.7% compared to 10.2% for the corresponding period of fiscal 2020. Our effective tax rates reflect the impact of a significant amount of our earnings being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rates for the third quarter and first nine months of fiscal 2021 increased compared to the corresponding periods of the prior year primarily due to the impact of taxes resulting from the integration of acquired companies. Additionally, the corresponding prior periods included discrete benefits for lapses in statutes of limitations. The remaining differences in effective tax rates for the third quarter of fiscal 2021 compared to the corresponding period of the prior year are primarily due to differences in discrete tax benefits/expenses for stock-based compensation.  The remaining differences in effective tax rates for the first nine months of fiscal 2021 compared to the corresponding period of the prior year are primarily due to certain discrete expenses, including foreign audit results and differences in discrete tax benefits for stock-based compensation.

[0001564590-21-009843:mdna:132]
36

[0001564590-21-009843:mdna:133]
As of January 29, 2021, we had $224 million of gross unrecognized tax benefits, of which $133 million has been recorded in other long-term liabilities. Inclusive of penalties, interest and certain income tax benefits, $133 million would affect our provision for income taxes if recognized.

[0001564590-21-009843:mdna:134]
[same as prior period, unchanged from 0001564590-20-056069:mdna:132]

[0001564590-21-009843:mdna:135]
[same as prior period, unchanged from 0001564590-20-056069:mdna:133]

[0001564590-21-009843:mdna:136]
| (In millions, except percentages) |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,894 |  |  | $ | 2,882 |  |
| Principal amount of debt |  | $ | 2,650 |  |  | $ | 1,673 |  |

[0001564590-21-009843:mdna:137]
[same as prior period, unchanged from 0001564590-20-056069:mdna:135]

[0001564590-21-009843:mdna:138]
|  |  | Nine Months Ended |  |
| (In millions) |  | January 29, 2021 |  |  | January 24, 2020 |  |
| Net cash provided by operating activities |  | $ | 774 |  |  | $ | 677 |  |
| Net cash (used in) provided by investing activities |  |  | (320 | ) |  |  | 1,227 |  |
| Net cash provided by (used in) financing activities |  |  | 624 |  |  |  | (1,520 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 70 |  |  |  | (4 | ) |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 1,148 |  |  | $ | 380 |  |

[0001564590-21-009843:mdna:139]
[same as prior period, unchanged from 0001564590-20-056069:mdna:137]

[0001564590-21-009843:mdna:140]
As of January 29, 2021, our cash, cash equivalents and short-term investments were $3.9 billion, an increase of $1.0 billion from April 24, 2020. The increase was primarily due to $2.0 billion of net proceeds from the issuance of Senior Notes and $774 million of cash provided by operating activities, partially offset by $513 million used for the extinguishment of our Senior Notes due June 2021, $420 million used for the net repayment of commercial paper notes with original maturities of three months or less, $350 million used for the acquisitions of two privately-held companies, $321 million used for the payment of dividends, and $124 million in purchases of property and equipment. Working capital increased by $1.4 billion to $2.1 billion as of January 29, 2021 compared to April 24, 2020 primarily due to the increases in cash, cash equivalents and short-term investments discussed above, and the net repayment of commercial paper notes.

[0001564590-21-009843:mdna:141]
[same as prior period, unchanged from 0001564590-20-056069:mdna:139]

[0001564590-21-009843:mdna:142]
During the first nine months of fiscal 2021, we generated cash from operating activities of $774 million, reflecting net income of $396 million, adjusted by non-cash depreciation and amortization of $159 million and stock-based compensation of $149 million, compared to $677 million of cash generated from operating activities during the first nine months of fiscal 2020.

[0001564590-21-009843:mdna:143]
Changes in assets and liabilities in the first nine months of fiscal 2021 included the following:

[0001564590-21-009843:mdna:144]
|  | • | Accounts receivable decreased $208 million, reflecting more favorable shipping linearity for the third quarter of fiscal 2021 compared to the fourth quarter of fiscal 2020. |

[0001564590-21-009843:mdna:145]
|  | • | Accounts payable decreased by $92 million, reflecting the timing of purchases from, and payments to, our contract manufacturers. |

[0001564590-21-009843:mdna:146]
[same as prior period, unchanged from 0001564590-20-056069:mdna:145]

[0001564590-21-009843:mdna:147]
[same as prior period, unchanged from 0001564590-20-056069:mdna:146]

[0001564590-21-009843:mdna:148]
During the first nine months of fiscal 2021, we generated $140 million from maturities and sales of investments, net of purchases, and paid $124 million for capital expenditures, while during the first nine months of fiscal 2020, we generated $1.3 billion from maturities and sales of investments, net of purchases, and paid $100 million for capital expenditures. Additionally, during the first nine months of fiscal 2021, we paid $350 million, net of cash acquired for two privately-held companies, as compared to $56 million, net of cash acquired that we paid in the first nine months of fiscal 2020 for a privately-held company. Additionally, during the first nine months of fiscal 2020, we received $96 million for the sale of land in Sunnyvale, California.

[0001564590-21-009843:mdna:149]
[same as prior period, unchanged from 0001564590-20-056069:mdna:148]

[0001564590-21-009843:mdna:150]
During the first nine months of fiscal 2021, cash flows provided by financing activities totaled $624 million, primarily due to net cash proceeds of $2.0 billion from the issuance of Senior Notes, partially offset by the use of $513 million for the extinguishment of our Senior Notes due June 2021, $420 million for the net repayment of commercial paper notes with original maturities of three months or less, $321 million for the payment of dividends, $176 million for the repayment of commercial paper notes with original maturities of greater than three months, and $50 million for the repurchase of 1 million shares of common stock. During the first nine months of fiscal 2020, we used $1.3 billion for the repurchase of 22 million shares of common stock, $334 million for the payment of dividends, and $400 million for the repayment of our Senior Notes due September 2019, partially offset by $443 million in net proceeds from the issuance of commercial paper notes with original maturities of three months or less.

[0001564590-21-009843:mdna:151]
[same as prior period, unchanged from 0001564590-20-056069:mdna:150]

[0001564590-21-009843:mdna:152]
[same as prior period, unchanged from 0001564590-20-056069:mdna:151]

[0001564590-21-009843:mdna:153]
Our principal sources of liquidity as of January 29, 2021 consisted of cash and cash equivalents, short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001564590-21-009843:mdna:154]
[same as prior period, unchanged from 0001564590-20-056069:mdna:153]

[0001564590-21-009843:mdna:155]
|  |  | January 29, 2021 |  |  | April 24, 2020 |  |
| Cash and cash equivalents |  | $ | 3,808 |  |  | $ | 2,658 |  |
| Short-term investments |  |  | 86 |  |  |  | 224 |  |
| Total |  | $ | 3,894 |  |  | $ | 2,882 |  |

[0001564590-21-009843:mdna:156]
As of January 29, 2021 and April 24, 2020, $2.3 billion and $2.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $1.6 billion and $0.4 billion, respectively, were available in the U.S. The Tax Cuts and Jobs Act (“TCJA”) imposed a one-time transition tax on substantially all accumulated foreign earnings through December 31, 2017, and generally allows companies to make distributions of foreign earnings without incurring additional federal taxes. As a part of the recognition of the impacts of the TCJA, we have reviewed our projected global cash requirements and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested.

[0001564590-21-009843:mdna:157]
[same as prior period, unchanged from 0001564590-20-056069:mdna:157]

[0001564590-21-009843:mdna:158]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of January 29, 2021.

[0001564590-21-009843:mdna:159]
[same as prior period, unchanged from 0001564590-20-056069:mdna:159]

[0001564590-21-009843:mdna:160]
[same as prior period, unchanged from 0001564590-20-056069:mdna:160]

[0001564590-21-009843:mdna:161]
The following table summarizes the principal amount of our Senior Notes as of January 29, 2021 (in millions):

[0001564590-21-009843:mdna:162]
| 3.25% Senior Notes Due December 2022 |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,650 |  |

[0001564590-21-009843:mdna:163]
[same as prior period, unchanged from 0001564590-20-056069:mdna:163]

[0001564590-21-009843:mdna:164]
Commercial Paper Program and Credit Facility

[0001564590-21-009843:mdna:165]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of January 29, 2021.

[0001564590-21-009843:mdna:166]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 29, 2021, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0001564590-21-009843:mdna:167]
[same as prior period, unchanged from 0001564590-20-056069:mdna:167]

[0001564590-21-009843:mdna:168]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2021 to be between $25 million and $50 million.

[0001564590-21-009843:mdna:169]
[same as prior period, unchanged from 0001564590-20-056069:mdna:170]

[0001564590-21-009843:mdna:170]
On February 19, 2021, we declared a cash dividend of $0.48 per share of common stock, payable on April 28, 2021 to holders of record as of the close of business on April 9, 2021.

[0001564590-21-009843:mdna:171]
As of January 29, 2021, our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through January 29, 2021, we repurchased a total of 339 million shares of our common stock at an average price of $38.92 per share, for an aggregate purchase price of $13.2 billion. As of January 29, 2021, the remaining authorized amount for stock repurchases under this program was $0.4 billion.

[0001564590-21-009843:mdna:172]
During the first quarter of fiscal 2021, we announced the suspension of our stock repurchases to strengthen our liquidity position given the uncertainty surrounding the overall impact of the ongoing COVID-19 pandemic. We reinitiated our stock repurchase program during the third quarter of fiscal 2021.

[0001564590-21-009843:mdna:173]
[same as prior period, unchanged from 0001564590-20-056069:mdna:174]

[0001564590-21-009843:mdna:174]
[same as prior period, unchanged from 0001564590-20-056069:mdna:175]

[0001564590-21-009843:mdna:175]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 29, 2021, we had $602 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-21-009843:mdna:176]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of January 29, 2021, we had $181 million in other purchase obligations.

[0001564590-21-009843:mdna:177]
[same as prior period, unchanged from 0001564590-20-056069:mdna:178]

[0001564590-21-009843:mdna:178]
As of January 29, 2021, our liability for uncertain tax positions was $133 million, including interest, penalties and certain income tax benefits. Due to uncertainties regarding tax audits and their possible outcomes, we are unable to make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-21-009843:mdna:179]
[same as prior period, unchanged from 0001564590-20-056069:mdna:180]

[0001564590-21-009843:mdna:180]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $61 million and $49 million of receivables during the first nine months of fiscal 2021 and fiscal 2020, respectively.

[0001564590-21-009843:mdna:181]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user.

[0001564590-21-009843:mdna:182]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of January 29, 2021 and April 24, 2020, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-21-009843:mdna:183]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of January 29, 2021, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-21-009843:mdna:184]
[same as prior period, unchanged from 0001564590-20-056069:mdna:185]

[0001564590-21-009843:mdna:185]
[same as prior period, unchanged from 0001564590-20-056069:mdna:186]

[0001564590-21-009843:mdna:186]
Legal Contingencies

[0001564590-21-009843:mdna:187]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 16 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0001564590-21-009843:mdna:188]
[same as prior period, unchanged from 0001564590-20-056069:mdna:189]
