# NTAP MD&A — 0001564590-15-000944


## mdna

[0001564590-15-000944:mdna:1]
Item 2.  Management’s Discussion and Analysis of Financial Condition and Results of Operations.

[0001564590-15-000944:mdna:2]
Forward-Looking Statements

[0001564590-15-000944:mdna:3]
| · | our future financial and operating results; |

[0001564590-15-000944:mdna:4]
| · | our strategy; |

[0001564590-15-000944:mdna:5]
| · | our beliefs and objectives for future operations, research and development; |

[0001564590-15-000944:mdna:6]
| · | political, economic and industry trends; |

[0001564590-15-000944:mdna:7]
| · | expected timing of, customer acceptance of and benefits from, product introductions, developments and enhancements; |

[0001564590-15-000944:mdna:8]
| · | expected benefits from acquisitions and joint ventures, growth opportunities and investments; |

[0001564590-15-000944:mdna:9]
| · | expected outcomes from legal, regulatory and administrative proceedings; |

[0001564590-15-000944:mdna:10]
| · | our competitive position; |

[0001564590-15-000944:mdna:11]
| · | our short-term and long-term cash requirements, including without limitation, anticipated capital expenditures; |

[0001564590-15-000944:mdna:12]
| · | our anticipated tax rate; |

[0001564590-15-000944:mdna:13]
| · | the repayment of our 2.00% Senior Notes due on December 15, 2017, 3.375% Senior Notes due on June 15, 2021 and 3.25% Senior Notes due on December 15, 2022 (collectively referred to as the Senior Notes); |

[0001564590-15-000944:mdna:14]
| · | future uses of our cash, including, without limitation, the continuation of our stock repurchase and cash dividend programs. |

[0001564590-15-000944:mdna:15]
All forward-looking statements included in this document are inherently uncertain as they are based on management’s current expectations and assumptions concerning future events, and are subject to numerous known and unknown risks and uncertainties. Therefore, actual events and results may differ materially from these forward-looking statements. Factors that could cause actual results to differ materially from those described herein include, but are not limited to:

[0001564590-15-000944:mdna:16]
| · | the overall growth and structure of the data storage industry; |

[0001564590-15-000944:mdna:17]
| · | our ability to understand, and effectively respond to changes affecting, our market environment, products, technologies and customer requirements; |

[0001564590-15-000944:mdna:18]
| · | general global political, macroeconomic and market conditions; |

[0001564590-15-000944:mdna:19]
| · | changes in U.S. government spending; |

[0001564590-15-000944:mdna:20]
| · | our ability to accurately forecast demand for our products and services, and future financial performance; |

[0001564590-15-000944:mdna:21]
| · | our ability to successfully manage our backlog; |

[0001564590-15-000944:mdna:22]
| · | our ability to successfully execute on our strategy to generate profitable growth and stockholder return; |

[0001564590-15-000944:mdna:23]
| · | disruptions in our supply chain, which could limit our ability to ship products to our customers in the amounts and at the prices forecasted; |

[0001564590-15-000944:mdna:24]
| · | our ability to maintain our customer, partner, supplier and contract manufacturer relationships on favorable terms and conditions; |

[0001564590-15-000944:mdna:25]
| · | our ability to maintain our gross profit margins; |

[0001564590-15-000944:mdna:26]
22

[0001564590-15-000944:mdna:27]
| · | our ability to timely and successfully introduce and increase volumes of new products and services and to forecast demand and pricing for the same; |

[0001564590-15-000944:mdna:28]
| · | our ability to gain customer acceptance of new products; |

[0001564590-15-000944:mdna:29]
| · | the actions of our competitors, most of which are larger and have greater financial and other resources than we have, including, without limitation, their ability to introduce competitive products and to acquire businesses and technologies that negatively impact our strategy, operations or customer demand for our products; |

[0001564590-15-000944:mdna:30]
| · | the impact of industry consolidation affecting our suppliers, competitors, partners and customers; |

[0001564590-15-000944:mdna:31]
| · | our ability to grow direct and indirect sales and to efficiently provide global service and support; |

[0001564590-15-000944:mdna:32]
| · | our ability to design, manufacture and market products meeting global environmental standards; |

[0001564590-15-000944:mdna:33]
| · | failure of our products and services to meet our customers’ quality requirements, including, without limitation, any epidemic failure event relating to our systems installed by our customers in their IT infrastructures; |

[0001564590-15-000944:mdna:34]
| · | our ability to resolve ongoing litigation, tax audits, government audits, inquiries and investigations in line with our expectations; |

[0001564590-15-000944:mdna:35]
| · | the availability of acceptable financing to support our future cash requirements; |

[0001564590-15-000944:mdna:36]
| · | our ability to effectively integrate acquired businesses, products and technologies; |

[0001564590-15-000944:mdna:37]
| · | valuation and liquidity of our investment portfolio; |

[0001564590-15-000944:mdna:38]
| · | foreign exchange rate impacts; |

[0001564590-15-000944:mdna:39]
| · | our ability to successfully recruit and retain critical employees and to manage our investment in people, process and systems; |

[0001564590-15-000944:mdna:40]
| · | our ability to anticipate techniques used to obtain unauthorized access or to sabotage systems and to implement adequate preventative measures against cybersecurity and other security breaches; and |

[0001564590-15-000944:mdna:41]
| · | those factors discussed under the heading “Risk Factors” elsewhere in this Quarterly Report on Form 10-Q. |

[0001564590-15-000944:mdna:42]
Readers are cautioned not to place undue reliance on these forward-looking statements, which speak only as of the date hereof and are based upon information available to us at this time. These statements are not guarantees of future performance. We disclaim any obligation to update information in any forward-looking statement. Actual results could vary from our forward-looking statements due to the foregoing factors as well as other important factors.

[0001564590-15-000944:mdna:43]
23

[0001564590-15-000944:mdna:44]
Overview

[0001564590-15-000944:mdna:45]
Financial Results and Key Performance Metrics Overview

[0001564590-15-000944:mdna:46]
The following table provides an overview of some of our key financial metrics (in millions, except per share amounts, percentages and days sales outstanding):

[0001564590-15-000944:mdna:47]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Net revenues |  | $ | 1,551.3 |  |  | $ | 1,610.0 |  |  | $ | 4,583.0 |  |  | $ | 4,676.1 |  |
| Gross profit |  | $ | 977.4 |  |  | $ | 1,002.3 |  |  | $ | 2,898.0 |  |  | $ | 2,877.1 |  |
| Gross profit margin percentage |  |  | 63.0 | % |  |  | 62.3 | % |  |  | 63.2 | % |  |  | 61.5 | % |
| Income from operations |  | $ | 202.5 |  |  | $ | 226.7 |  |  | $ | 554.9 |  |  | $ | 510.5 |  |
| Income from operations as a percentage of net revenues |  |  | 13.1 | % |  |  | 14.1 | % |  |  | 12.1 | % |  |  | 10.9 | % |
| Net income |  | $ | 176.8 |  |  | $ | 192.1 |  |  | $ | 425.0 |  |  | $ | 440.5 |  |
| Diluted net income per share |  | $ | 0.56 |  |  | $ | 0.55 |  |  | $ | 1.31 |  |  | $ | 1.25 |  |
| Operating cash flows |  | $ | 274.6 |  |  | $ | 331.8 |  |  | $ | 871.5 |  |  | $ | 980.1 |  |

[0001564590-15-000944:mdna:48]
|  |  |  |  |  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Deferred revenue |  |  |  |  |  | $ | 3,109.7 |  |  | $ | 3,100.2 |  |
| Days sales outstanding (DSO) |  |  |  |  |  |  | 39 |  |  |  | 47 |  |

[0001564590-15-000944:mdna:49]
Critical Accounting Policies and Estimates

[0001564590-15-000944:mdna:50]
Our condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America, which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and liabilities. Our estimates are based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0001564590-15-000944:mdna:51]
The summary of significant accounting policies is included under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended April 25, 2014. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. There have been no material changes to the critical accounting policies and estimates as filed in such report.

[0001564590-15-000944:mdna:52]
New Accounting Standards

[0001564590-15-000944:mdna:53]
See Note 2 of the accompanying condensed consolidated financial statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001564590-15-000944:mdna:54]
Results of Operations

[0001564590-15-000944:mdna:55]
The following table sets forth certain Condensed Consolidated Statements of Operations data as a percentage of net revenues for the periods indicated:

[0001564590-15-000944:mdna:56]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 59.9 |  | % |  | 63.0 |  | % |  | 59.8 |  | % |  | 62.0 |  | % |
| Software entitlements and maintenance |  | 14.6 |  |  |  | 14.1 |  |  |  | 14.7 |  |  |  | 14.7 |  |  |
| Service |  | 25.5 |  |  |  | 22.9 |  |  |  | 25.5 |  |  |  | 23.3 |  |  |
| Net revenues |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 27.1 |  |  |  | 28.0 |  |  |  | 26.5 |  |  |  | 28.3 |  |  |
| Cost of software entitlements and maintenance |  | 0.6 |  |  |  | 0.5 |  |  |  | 0.6 |  |  |  | 0.5 |  |  |
| Cost of service |  | 9.3 |  |  |  | 9.2 |  |  |  | 9.7 |  |  |  | 9.7 |  |  |
| Gross profit |  |  | 63.0 |  |  |  | 62.3 |  |  |  | 63.2 |  |  |  | 61.5 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 30.6 |  |  |  | 29.6 |  |  |  | 31.5 |  |  |  | 30.4 |  |  |
| Research and development |  | 14.8 |  |  |  | 14.3 |  |  |  | 15.0 |  |  |  | 14.7 |  |  |
| General and administrative |  | 4.5 |  |  |  | 4.3 |  |  |  | 4.6 |  |  |  | 4.4 |  |  |
| Restructuring and other charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.1 |  |  |
| Total operating expenses |  | 49.9 |  |  |  | 48.2 |  |  |  | 51.1 |  |  |  | 50.6 |  |  |
| Income from operations |  | 13.1 |  |  |  | 14.1 |  |  |  | 12.1 |  |  |  | 10.9 |  |  |
| Other income (expense), net |  |  | (0.2 | ) |  |  | 0.2 |  |  |  | (0.1 | ) |  |  | 0.1 |  |  |
| Income before income taxes |  |  | 12.9 |  |  |  | 14.3 |  |  |  | 12.0 |  |  |  | 11.0 |  |  |
| Provision for income taxes |  | 1.5 |  |  |  | 2.4 |  |  |  | 2.7 |  |  |  | 1.6 |  |  |
| Net income |  | 11.4 |  | % |  | 11.9 |  | % |  | 9.3 |  | % |  | 9.4 |  | % |

[0001564590-15-000944:mdna:57]
Discussion and Analysis of Results of Operations

[0001564590-15-000944:mdna:58]
Overview

[0001564590-15-000944:mdna:59]
Net revenues for the three and nine months ended January 23, 2015 were $1,551.3 million, down $58.7 million, or 4%, and $4,583.0 million, down $93.1 million, or 2%, respectively, compared to the corresponding periods in the prior year, reflecting decreases in product and software entitlements and maintenance (SEM) revenues, partially offset by an increase in hardware maintenance contract revenues. Unfavorable foreign exchange rate changes resulted in a $22.4 million reduction of net revenues during the three months ended January 23, 2015, but had no significant impact on net revenues for the nine months ended January 23, 2015.

[0001564590-15-000944:mdna:60]
Gross profit as a percentage of net revenues increased 1% during the three months ended January 23, 2015 compared to the corresponding period in the prior year, reflecting higher gross margins on service revenues, partially offset by lower gross margins on product revenues. The lower gross margins on product revenues were primarily due to lower average selling prices (ASPs) on configured systems, reflecting changes in product mix, partially offset by a decrease in warranty costs. Gross profit as a percentage of net revenues increased 2% during the nine months ended January 23, 2015 compared to the corresponding period of the prior year due to higher gross margins on product revenues and service revenues. The higher gross margins on product revenues was due to lower OEM revenues and lower warranty costs, partially offset by lower gross margins on add-on storage.

[0001564590-15-000944:mdna:61]
Sales and marketing, research and development, and general and administrative expenses for the three and nine months ended January 23, 2015 were $774.9 million and $2,343.1 million, respectively, relatively flat from the corresponding periods of the prior year, but up 2% as a percentage of net revenues for each of these periods. This is primarily due to a decrease in compensation costs, offset by higher spending on projects.

[0001564590-15-000944:mdna:62]
Net Revenues (in millions, except percentages):

[0001564590-15-000944:mdna:63]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |
| Net revenues |  | $ | 1,551.3 |  |  | $ | 1,610.0 |  |  |  | (4 | )% |  | $ | 4,583.0 |  |  | $ | 4,676.1 |  |  |  | (2 | )% |

[0001564590-15-000944:mdna:64]
The decrease in net revenues for the three months ended January 23, 2015 was primarily due to a decrease in product revenues of $85.5 million, partially offset by an increase in service revenues of $27.2 million. Product revenues comprised 60% of net revenues for the three months ended January 23, 2015, compared to 63% for the three months ended January 24, 2014.

[0001564590-15-000944:mdna:65]
The decrease in net revenues for the nine months ended January 23, 2015 was primarily due to a decrease in product and SEM revenues of $159.9 million and $15.2 million, respectively, partially offset by an increase in service revenues of $82.0 million. Product revenues comprised 60% of net revenues for the nine months ended January 23, 2015, compared to 62% for the nine months ended January 24, 2014.

[0001564590-15-000944:mdna:66]
Sales through our indirect channels represented 81% and 80% of net revenues for the three and nine months ended January 23, 2015, respectively, compared to 83% and 82% of net revenues for the corresponding periods of the prior year. Included in indirect channel sales were $123.8 million and $371.1 million of OEM revenue during the three and nine months ended January 23, 2015, respectively, compared to $157.3 million and $474.9 million during the corresponding periods in the prior year.

[0001564590-15-000944:mdna:67]
The following customers, each of which is a distributor, accounted for 10% or more of net revenues:

[0001564590-15-000944:mdna:68]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 20 | % |  |  | 23 | % |  |  | 21 | % |
| Avnet, Inc. |  |  | 16 | % |  |  | 15 | % |  |  | 16 | % |  |  | 16 | % |

[0001564590-15-000944:mdna:69]
Product Revenues (in millions, except percentages):

[0001564590-15-000944:mdna:70]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |
| Product revenues |  | $ | 929.5 |  |  | $ | 1,015.0 |  |  |  | (8 | )% |  | $ | 2,741.2 |  |  | $ | 2,901.1 |  |  |  | (6 | )% |

[0001564590-15-000944:mdna:71]
Product revenues consist of sales of configured systems, which include bundled hardware and software products, and non-configured products, which consist primarily of add-on storage, OEM products and add-on hardware and software products.

[0001564590-15-000944:mdna:72]
Total configured system revenues of $553.3 million decreased by $15.8 million for the three months ended January 23, 2015, compared to the corresponding period of the prior year. Revenues from E-Series systems (which include our all flash EF systems) increased, but were offset by decreases in FAS entry level and mid-range systems. Total configured systems unit volume increased 9%, primarily due to a unit volume increase in the FAS high-end systems and E Series systems, but was partially offset by a decrease in unit volume of the FAS mid-range systems. These changes in unit volume reflect a shift in customer demand to our newer FAS high-end systems and higher demand for our E-Series systems, and away from our older FAS mid-range systems. ASPs decreased across all FAS systems and E Series systems platforms due to higher demand of newer lower priced products within their respective platforms. As a result, overall ASPs of configured systems were lower in the three months ended January 23, 2015, compared to the corresponding period of the prior year. In addition, revenues for configured systems were negatively impacted by $14.2 million as a result of unfavorable foreign exchange rates in the three months ended January 23, 2015 compared to the corresponding period in the prior year.

[0001564590-15-000944:mdna:73]
Non-configured product revenues of $376.2 million decreased $69.8 million, or 16%, during the three months ended January 23, 2015, compared to the corresponding period of the prior year. This decrease was primarily due to lower revenues from add-on storage, which declined 35%, as well as from non-configured OEM products, which declined 22%, but was partially offset by a 114% increase in revenues from add-on software. The decrease in add-on storage and increase in add-on software are largely due to the change in our pricing strategy that was effective in the fourth quarter of fiscal 2014, whereby we now charge for operating system software for storage capacity but have lowered prices on storage hardware. Non-configured revenues were negatively impacted by $7.2 million as a result of unfavorable foreign exchange rates in the three months ended January 23, 2015 compared to the corresponding period in the prior year.

[0001564590-15-000944:mdna:74]
Total configured system revenues of $1,637.4 million decreased by $17.8 million for the nine months ended January 23, 2015, compared to the corresponding period of the prior year. Revenues from E-Series systems increased, but were offset by decreases in FAS entry level and mid-range systems. Total configured systems unit volume increased 4% primarily due to a unit volume increase in the FAS mid-range and high-end systems and E Series systems platforms, partially offset by a decrease in unit volume of the FAS entry level systems. These changes in unit volume reflect a shift in customer demand to our newer FAS mid-range and high-end systems and higher demand for our E-Series systems, and away from our older FAS entry level systems. ASPs decreased across all FAS systems and E Series systems due to higher demand of newer lower priced products within their respective platform. As a result, overall ASPs of configured systems were lower in the nine months ended January 23, 2015, compared to the corresponding period of the prior year. Foreign exchange rate changes had no significant impact on configured systems revenues for the nine months ended January 23, 2015.

[0001564590-15-000944:mdna:75]
26

[0001564590-15-000944:mdna:76]
Non-configured product revenues of $1,103.8 million decreased $142.1 million, or 11%, during the nine months ended January 23, 2015 compared to the corresponding period of the prior year. This decrease was primarily due to lower revenues from add-on storage, which declined 26%, non-configured OEM products, which declined 22%, and but was partially offset by a 123% increase in revenues from add-on software. The decrease in add-on storage and increase in add-on software are largely due to the change in our pricing strategy discussed above. Foreign exchange rate changes had no significant impact on non-configured product revenues for the nine months ended January 23, 2015.

[0001564590-15-000944:mdna:77]
Our systems are highly configurable to respond to customer requirements in the open systems storage markets that we serve. This can cause a wide variation in product configurations that can significantly impact revenues, cost of revenues and gross profits. Pricing changes, discounting practices, product competition, foreign currency impacts, unit volumes, customer mix, natural disasters and product materials costs can also impact revenues, cost of revenues and/or gross profits. Disks are a significant component of our storage systems. While our sales price per terabyte historically declines over time, improved system performance, increased capacity and software to manage this increased capacity have an offsetting favorable impact on product revenues.

[0001564590-15-000944:mdna:78]
Software Entitlements and Maintenance Revenues (in millions, except percentages):

[0001564590-15-000944:mdna:79]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |
| Software entitlements and maintenance revenues |  | $ | 226.6 |  |  | $ | 227.0 |  |  |  | — | % |  | $ | 672.1 |  |  | $ | 687.3 |  |  |  | (2 | )% |

[0001564590-15-000944:mdna:80]
SEM revenues are associated with contracts which entitle customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, as well as bug fixes and patch releases.

[0001564590-15-000944:mdna:81]
The decrease in SEM revenues for the nine months ended January 23, 2015 was due to a decrease in the aggregate contract value of the installed base under SEM contracts.

[0001564590-15-000944:mdna:82]
Service Revenues (in millions, except percentages):

[0001564590-15-000944:mdna:83]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |
| Service revenues |  | $ | 395.2 |  |  | $ | 368.0 |  |  |  | 7 | % |  | $ | 1,169.7 |  |  | $ | 1,087.7 |  |  |  | 8 | % |

[0001564590-15-000944:mdna:84]
Service revenues include hardware maintenance, professional services, and educational and training services.

[0001564590-15-000944:mdna:85]
Hardware maintenance contract revenues comprised 80% and 79% of service revenues for the three and nine months ended January 23, 2015, respectively, compared to 78% and 77% for the corresponding periods in the prior year, reflecting an increase of $29.7 million, or 10%, and $93.5 million, or 11%, respectively. The increases in hardware maintenance were a result of increases in the installed base and aggregate contract values under service contracts. Professional services and educational and training services comprised 20% and 21% of service revenues for the three and nine months ended January 23, 2015, respectively, and 22% and 23% of service revenues for the three and nine months ended January 24, 2014, respectively.

[0001564590-15-000944:mdna:86]
Revenues by Geographic Area:

[0001564590-15-000944:mdna:87]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Americas (United States, Canada and Latin America) |  |  | 54 | % |  |  | 52 | % |  |  | 56 | % |  |  | 56 | % |
| Europe, Middle East and Africa |  |  | 33 | % |  |  | 34 | % |  |  | 30 | % |  |  | 31 | % |
| Asia Pacific |  |  | 13 | % |  |  | 14 | % |  |  | 13 | % |  |  | 14 | % |

[0001564590-15-000944:mdna:88]
_________________________________

[0001564590-15-000944:mdna:89]
Percentages may not add due to rounding

[0001564590-15-000944:mdna:90]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Americas revenues were favorably impacted by higher revenues from U.S. public sectors markets, but unfavorably impacted by lower revenues from the U.S. commercial sector markets in the three months ended January 23, 2015, compared to the corresponding period in the prior year.

[0001564590-15-000944:mdna:91]
Cost of Revenues

[0001564590-15-000944:mdna:92]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping our products, amortization of purchased intangible assets, inventory write-downs, and warranty costs, (2) cost of SEM, which

[0001564590-15-000944:mdna:93]
includes the costs of providing SEM and third-party royalty costs and (3) cost of service revenues, which includes costs associated with providing support activities for hardware maintenance, global support partnership programs, professional services and educational and training services.

[0001564590-15-000944:mdna:94]
Our gross profit is impacted by a variety of factors, including pricing changes, discounting practices, foreign currency, product configuration, unit volumes, customer mix, revenue mix, natural disasters and product material costs. Service gross profit is typically impacted by factors such as changes in the size of our installed base of products, as well as the timing of support service initiations and renewals, and incremental investments in our customer support infrastructure. If any of these factors that impact our gross profit are adversely affected, whether by economic uncertainties or for other reasons, our gross profit could decline.

[0001564590-15-000944:mdna:95]
Cost of Product Revenues (in millions, except percentages):

[0001564590-15-000944:mdna:96]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |
| Cost of product revenues |  | $ | 419.6 |  |  | $ | 450.7 |  |  |  | (7 | )% |  | $ | 1,215.6 |  |  | $ | 1,323.9 |  |  |  | (8 | )% |

[0001564590-15-000944:mdna:97]
The changes in cost of product revenues consisted of the following (in percentage points of the total change):

[0001564590-15-000944:mdna:98]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2015 to Fiscal 2014 |  |  | Fiscal 2015 to Fiscal 2014 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials cost |  |  | (4 | ) |  |  | (5 | ) |
| Warranty |  |  | (4 | ) |  |  | (3 | ) |
| Excess and obsolete inventory |  |  | (1 | ) |  |  | (1 | ) |
| Amortization of purchased intangible assets |  |  | 1 |  |  |  | — |  |
| Other |  |  | 1 |  |  |  | 1 |  |
| Total change |  |  | (7 | ) |  |  | (8 | ) |

[0001564590-15-000944:mdna:99]
Cost of product revenues represented 45% and 44% of product revenues for the three and nine months ended January 23, 2015, respectively, compared to 44% and 46% for the corresponding period of the prior year. As a result, product gross margin percentages were 55% and 56% for the for the three and nine months ended January 23, 2015, respectively, compared to 56% and 54% for the corresponding period of the prior year.

[0001564590-15-000944:mdna:100]
Materials cost represented 86% and 84% of product costs for the three months ended January 23, 2015 and January 24, 2014. Materials cost decreased $17.8 million in the three months ended January 23, 2015 compared to the corresponding period of the prior year. Material costs were impacted by a 9% unit volume increase in configured systems in the three months ended January 23, 2015. Overall materials unit cost for configured systems decreased due to a decrease in average unit materials cost of all of our FAS systems and E-Series systems platforms, as well as changes in product mix. The decrease in materials costs also reflects lower OEM product volume and lower materials cost of add-on hardware. In addition, cost of product revenues were favorably impacted by decreases of $17.9 million in warranty expense and $3.9 million in excess and obsolete inventory write-downs, partially offset by a $4.6 million increase in the amortization of developed technology associated with our acquisitions.

[0001564590-15-000944:mdna:101]
Materials cost represented 86% and 83% of product costs for the nine months ended January 23, 2015 and January 24, 2014, respectively. Materials cost decreased $59.8 million in the nine months ended January 23, 2015 compared to the corresponding period of the prior year. Material costs were impacted by a 4% unit volume increase in configured systems in the nine months ended January 23, 2015 compared to the corresponding period of the prior year. Overall materials unit cost for configured systems decreased slightly due to a decrease in average unit materials costs in our mid-range and high-end FAS systems and E-Series platforms, as well as changes in product mix. Additionally, total material costs decreased due to lower OEM product volume and lower materials cost of add-on hardware. Cost of product revenues were also favorably impacted by decreases of $37.5 million in warranty expense and $9.8 million in excess and obsolete inventory write-downs.

[0001564590-15-000944:mdna:102]
Cost of Software Entitlements and Maintenance Revenues (in millions, except percentages):

[0001564590-15-000944:mdna:103]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |
| Cost of software entitlements and maintenance revenues |  | $ | 9.4 |  |  | $ | 7.7 |  |  |  | 22 | % |  | $ | 26.2 |  |  | $ | 22.7 |  |  |  | 15 | % |

[0001564590-15-000944:mdna:104]
Cost of SEM revenues increased primarily due to higher royalty costs and software maintenance costs in the three and nine months ended January 23, 2015 compared to the three and nine months ended January 24, 2014. Cost of SEM revenues represented 4% of SEM revenues for each of the three and nine months ended January 23, 2015 compared to 3% for each of the three and nine months ended January 24, 2014.

[0001564590-15-000944:mdna:105]
Cost of Service Revenues (in millions, except percentages):

[0001564590-15-000944:mdna:106]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |
| Cost of service revenues |  | $ | 144.9 |  |  | $ | 149.3 |  |  |  | (3 | )% |  | $ | 443.2 |  |  | $ | 452.4 |  |  |  | (2 | )% |

[0001564590-15-000944:mdna:107]
Cost of service revenues decreased during the three and nine months ended January 23, 2015 compared to the three and nine months ended January 24, 2014, primarily due to lower contracted services costs, logistics, materials rework and service delivery costs, partially offset by an increase in spares materials costs. Costs represented 37% and 41% of service revenues for the three months ended January 23, 2015 and January 24, 2014, respectively, and represented 38% and 42% of service revenues for the nine months ended January 23, 2015 and January 24, 2014, respectively.

[0001564590-15-000944:mdna:108]
Operating Expenses

[0001564590-15-000944:mdna:109]
Sales and Marketing, Research and Development and General and Administrative Expenses

[0001564590-15-000944:mdna:110]
Compensation costs comprise the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0001564590-15-000944:mdna:111]
Total compensation costs included in operating expenses decreased $19.8 million, or 4%, and $18.8 million, or 1%, for the three and nine months ended January 23, 2015, respectively, compared to the corresponding periods in the prior year, primarily due to decreases in incentive compensation costs reflecting lower attainment against goals.

[0001564590-15-000944:mdna:112]
Sales and Marketing (in millions, except percentages):

[0001564590-15-000944:mdna:113]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 474.8 |  |  | $ | 475.9 |  |  |  | — | % |  | $ | 1,443.0 |  |  | $ | 1,423.2 |  |  |  | 1 | % |

[0001564590-15-000944:mdna:114]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, allocated facilities and information technology costs, advertising and marketing promotional expense, and travel and entertainment expense. Sales and marketing expenses increased due to the following:

[0001564590-15-000944:mdna:115]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2015 to Fiscal 2014 |  |  | Fiscal 2015 to Fiscal 2014 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (3 | ) |  |  | (1 | ) |
| Commissions |  |  | — |  |  |  | 1 |  |
| Sales events |  |  | 1 |  |  |  | — |  |
| Other |  |  | 2 |  |  |  | 1 |  |
| Total change |  |  | — |  |  |  | 1 |  |

[0001564590-15-000944:mdna:116]
The decrease in compensation costs for the three and nine months ended January 23, 2015 is primarily due to lower salaries, stock-based compensation and benefits expense, reflecting a 1% decrease in headcount, as well as a decrease in incentive compensation costs. Commissions expense was relatively flat in the three months ended January 23, 2015, but increased during the nine months ended January 23, 2015, reflecting higher bookings achievement compared to the corresponding period in the prior year. In addition, foreign exchange rate changes resulted in a favorable impact of $10.0 million during the three months ended January 23, 2015, but had no significant impact for the nine months ended January 23, 2015.

[0001564590-15-000944:mdna:117]
Research and Development (in millions, except percentages):

[0001564590-15-000944:mdna:118]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |
| Research and development expenses |  | $ | 229.9 |  |  | $ | 230.3 |  |  |  | — | % |  | $ | 686.9 |  |  | $ | 686.6 |  |  |  | — | % |

[0001564590-15-000944:mdna:119]
Research and development expenses consist primarily of compensation costs, allocated facilities and IT costs, depreciation, equipment and software-related costs, prototypes, non-recurring engineering charges and other outside services costs. The changes in research and development expense consisted of the following:

[0001564590-15-000944:mdna:120]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2015 to Fiscal 2014 |  |  | Fiscal 2015 to Fiscal 2014 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (1 | ) |  |  | — |  |
| Outside services |  |  | 1 |  |  |  | 1 |  |
| Development projects |  |  | — |  |  |  | (1 | ) |
| Total change |  |  | — |  |  |  | — |  |

[0001564590-15-000944:mdna:121]
The decrease in compensation costs during the three months ended January 23, 2015 is primarily due to lower incentive compensation costs, partially offset by higher average salaries. Outside services expense during the three and nine months ended January 23, 2015 increased due to higher spending on contractors. The decrease in development projects expense during the nine months ended January 23, 2015 reflects lower spending on materials and services associated with engineering activities to develop new product lines and enhancements to existing products.

[0001564590-15-000944:mdna:122]
We believe that our future performance will depend in large part on our ability to maintain and enhance our current product line, develop new products that achieve market acceptance, maintain technological competitiveness and meet an expanding range of customer requirements. We expect to continue to spend on current and future product development efforts, broaden our existing product offerings and introduce new products that expand our solutions portfolio.

[0001564590-15-000944:mdna:123]
General and Administrative (in millions, except percentages):

[0001564590-15-000944:mdna:124]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |
| General and administrative expenses |  | $ | 70.2 |  |  | $ | 69.4 |  |  |  | 1 | % |  | $ | 213.2 |  |  | $ | 207.3 |  |  |  | 3 | % |

[0001564590-15-000944:mdna:125]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and allocated facilities and IT support costs. General and administrative expense increased due to the following:

[0001564590-15-000944:mdna:126]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2015 to Fiscal 2014 |  |  | Fiscal 2015 to Fiscal 2014 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (2 | ) |  |  | (1 | ) |
| Professional and legal fees and outside services |  |  | 3 |  |  |  | 2 |  |
| Bad debt expense |  |  | — |  |  |  | 1 |  |
| Other |  |  | — |  |  |  | 1 |  |
| Total change |  |  | 1 |  |  |  | 3 |  |

[0001564590-15-000944:mdna:127]
The decrease in compensation costs for the three and nine months ended January 23, 2015 is primarily due to lower incentive compensation costs and benefits expenses, partially offset by higher salaries due to a 3% increase in headcount. The increase in professional and legal fees and outside services for the three months and nine months ended January 23, 2015 reflects higher spending levels on contractors and professional services. Bad debt expense for the nine months ended January 23, 2015 increased $1.5 million, compared to the corresponding period in the prior year.

[0001564590-15-000944:mdna:128]
Restructuring and other charges (in millions, except percentages):

[0001564590-15-000944:mdna:129]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |
| Restructuring and other charges |  | $ | — |  |  | $ | — |  |  |  | — | % |  | $ | — |  |  | $ | 49.5 |  |  |  | (100 | )% |

[0001564590-15-000944:mdna:130]
In March 2014 and May 2013, we initiated business realignment plans designed to focus our resources on key strategic initiatives and streamline our business in light of the constrained IT spending environment, resulting in a reduction of our global workforce. The charges for the nine months ended January 24, 2014 represent employee severance costs recognized in connection with the May 2013 restructuring plan. We completed all activities under the May 2013 plan during fiscal 2014, and have completed activities under the March 2014 plan in the second quarter of fiscal 2015. See Note 11 to the Condensed Consolidated Financial Statements for more details regarding our restructuring plans.

[0001564590-15-000944:mdna:131]
30

[0001564590-15-000944:mdna:132]
Other Income (Expense), Net

[0001564590-15-000944:mdna:133]
Interest Income (in millions, except percentages):

[0001564590-15-000944:mdna:134]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |
| Interest income |  | $ | 8.6 |  |  | $ | 7.9 |  |  |  | 9 | % |  | $ | 25.0 |  |  | $ | 26.4 |  |  |  | (5 | )% |

[0001564590-15-000944:mdna:135]
The increase in interest income during the three months ended January 23, 2015 was primarily due to a shift in our investment portfolio to higher-yielding investments. The decrease in interest income during the nine months ended January 23, 2015 was primarily due to a decrease in our average investment portfolio compared to the corresponding period in the prior year.

[0001564590-15-000944:mdna:136]
Interest Expense (in millions, except percentages):

[0001564590-15-000944:mdna:137]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |
| Interest expense |  | $ | (11.1 | ) |  | $ | (6.7 | ) |  |  | 66 | % |  | $ | (31.0 | ) |  | $ | (29.7 | ) |  |  | 4 | % |

[0001564590-15-000944:mdna:138]
Interest expense, including the amortization of debt discount and issuance costs, is related to our Senior Notes and Convertible Notes as summarized below:

[0001564590-15-000944:mdna:139]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, |  |  | January 24, |  |  | January 23, |  |  | January 24, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Senior Notes |  | $ | 10.6 |  |  | $ | 6.2 |  |  | $ | 29.9 |  |  | $ | 18.7 |  |
| Convertible Notes |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 10.2 |  |
| Total |  | $ | 10.6 |  |  | $ | 6.2 |  |  | $ | 29.9 |  |  | $ | 28.9 |  |

[0001564590-15-000944:mdna:140]
The increase in interest expense related to our Senior Notes reflects the issuance of our 3.375% Senior Notes due 2021 in June 2014, and the decrease in interest expense related to our Convertible Notes reflects their maturity in June 2013.

[0001564590-15-000944:mdna:141]
Other Income (Expense), Net (in millions, except percentages):

[0001564590-15-000944:mdna:142]
|  |  | Three Months Ended |  |  | Nine Months Ended |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |
| Other income (expense), net |  | $ | 0.1 |  |  | $ | 1.7 |  |  |  | (94 | )% |  | $ | (0.2 | ) |  | $ | 6.9 |  |  | NM |

[0001564590-15-000944:mdna:143]
__________________

[0001564590-15-000944:mdna:144]
NM - Not Meaningful

[0001564590-15-000944:mdna:145]
The changes in other income (expense), net for the three and nine months ended January 23, 2015 compared to the corresponding period in the prior year is primarily due to higher net foreign exchange losses.

[0001564590-15-000944:mdna:146]
Provision for Income Taxes (in millions, except percentages):

[0001564590-15-000944:mdna:147]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | % Change |  |
| Provision for income taxes |  | $ | 23.3 |  |  | $ | 37.5 |  |  |  | (38 | )% |  | $ | 123.7 |  |  | $ | 73.6 |  |  |  | 68 | % |

[0001564590-15-000944:mdna:148]
Our effective tax rate for the three months ended January 23, 2015 was 11.7% compared to an effective tax rate of 16.3% for the three months ended January 24, 2014. Our effective tax rate for the nine months ended January 23, 2015 was 22.5% compared to an effective tax rate of 14.3% for the nine months ended January 24, 2014. Our effective tax rates reflect our corporate legal entity structure and the global nature of our business with a significant amount of our profits generated and taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The effective tax rates during the three and nine months ended January 23, 2015 and January 24, 2014, respectively, were favorably impacted by the geographic mix of profits. Our effective tax rate for the three months ended January 23, 2015 decreased compared to the prior year, as a result of the extension of the federal research credit through December 31, 2014. Our effective tax rate for the nine months ended January 23, 2015 increased compared to the prior year primarily as a result of the settlements of income tax audits, net of the benefits due to the extension of the federal research credit, as further discussed below.

[0001564590-15-000944:mdna:149]
31

[0001564590-15-000944:mdna:150]
On December 19, 2014, the federal research credit was retroactively extended for amounts paid or incurred after December 31, 2013, and before January 1, 2015. As a result of the extension, during the three months ended January 23, 2015 we recorded a benefit of $6.0 million related to the current year research credit and a discrete benefit of $4.1 million related to prior year credits that we will retroactively claim. The federal research credit expired on December 31, 2014.

[0001564590-15-000944:mdna:151]
In July 2014, the Internal Revenue Service (IRS) completed the examination of our fiscal 2005 to 2007 income tax returns upon approval by the Joint Committee of Taxation. We recorded a $47.4 million tax provision attributable to the audit settlement and related re-measurement of uncertain tax positions for tax years subject to future audits. The conclusion of the fiscal 2005 to 2007 income tax audit resulted in a net refund of $8.0 million, excluding interest.

[0001564590-15-000944:mdna:152]
In October 2014, the United Kingdom’s (UK’s) tax authority concluded the examination of our fiscal 2009 to 2012 UK income tax returns. We recorded a $1.0 million income tax benefit for the net impact of the audit adjustments and related release of unrecognized tax benefits.

[0001564590-15-000944:mdna:153]
As of January 23, 2015, we had $275.4 million of gross unrecognized tax benefits, of which $220.2 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $169.7 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized. During the nine months ended January 23, 2015, there was an increase in our unrecognized tax benefits of $19.1 million for tax positions related to the current year, a gross increase of $101.5 million and a gross decrease, including statute lapses, of $23.5 million for tax positions related to prior years. We also recorded a gross decrease of $57.6 million related to settlements with taxing authorities during the period.

[0001564590-15-000944:mdna:154]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions.

[0001564590-15-000944:mdna:155]
Liquidity, Capital Resources and Cash Requirements

[0001564590-15-000944:mdna:156]
| ($ in Millions) |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Cash and cash equivalents and short-term investments |  | $ | 5,252.5 |  |  | $ | 5,003.3 |  |
| Principal amount of Senior Notes |  |  | 1,500.0 |  |  |  | 1,000.0 |  |
| Debt as a % of stockholders' equity |  |  | 43 | % |  |  | 26 | % |

[0001564590-15-000944:mdna:157]
The following is a summary of our cash flows activities:

[0001564590-15-000944:mdna:158]
|  |  | Nine Months Ended |  |
| (In Millions) |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Net cash provided by operating activities |  | $ | 871.5 |  |  | $ | 980.1 |  |
| Net cash provided by (used in) investing activities |  |  | (178.6 | ) |  |  | 599.9 |  |
| Net cash used in financing activities |  |  | (389.3 | ) |  |  | (2,707.3 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (54.9 | ) |  |  | 2.9 |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | 248.7 |  |  | $ | (1,124.4 | ) |

[0001564590-15-000944:mdna:159]
Cash Flows

[0001564590-15-000944:mdna:160]
As of January 23, 2015, our cash, cash equivalents and short-term investments increased by $0.3 billion from April 25, 2014 to $5.3 billion. The increase was primarily due to $494.7 million of net proceeds received from the issuance of long-term debt and $871.5 million of cash provided by operating activities, partially offset by $918.9 million in cash paid for the repurchase of our common stock. Accounts receivable days sales outstanding as of January 23, 2015 decreased to 39 days from 47 days as of April 25, 2014, reflecting seasonal improvements in shipment linearity. Working capital increased by $286.6 million to $4.1 billion as of January 23, 2015 primarily as a result of an increase in cash, cash equivalents and short-term investments and a decrease in accrued compensation, partially offset by decrease in accounts receivable.

[0001564590-15-000944:mdna:161]
Cash Flows from Operating Activities

[0001564590-15-000944:mdna:162]
The primary sources of cash from operating activities during the nine months ended January 23, 2015 consisted of net income of $425.0 million, adjusted by non-cash depreciation and amortization of $234.6 million and stock-based compensation of $196.1 million.

[0001564590-15-000944:mdna:163]
Changes in assets and liabilities as of January 23, 2015 included the following:

[0001564590-15-000944:mdna:164]
| · | Accounts receivable decreased $186.7 million in the nine months ended January 23, 2015 and decreased $213.4 million in the nine months ended January 24, 2014, reflecting seasonal improvement of shipment linearity in the third quarter of our fiscal years compared to the fourth quarter of our fiscal years. |

[0001564590-15-000944:mdna:165]
| · | Accrued compensation and benefits decreased $85.5 million due primarily to employee compensation payouts related to fiscal year 2014 incentive compensation plans and restructuring obligations, compared to $53.6 million for the corresponding period of the prior year, reflecting higher incentive compensation plan payouts in the current period. |

[0001564590-15-000944:mdna:166]
We expect that cash provided by operating activities may materially fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, tax benefits or charges from stock-based compensation, and the timing and amount of compensation and other payments.

[0001564590-15-000944:mdna:167]
Cash Flows from Investing Activities

[0001564590-15-000944:mdna:168]
During the nine months ended January 23, 2015, we generated $41.6 million from maturities and sales of investments, net of purchases, and paid $138.1 million for capital expenditures, compared to $762.7 million and $165.4 million, respectively, in the corresponding period of the prior year. In addition, in the nine months ended January 23, 2015, we expended $84.6 million of cash on acquisitions.

[0001564590-15-000944:mdna:169]
Cash Flows from Financing Activities

[0001564590-15-000944:mdna:170]
During the nine months ended January 23, 2015, we generated $494.7 million, net, from the issuance of long-term debt and used $918.9 million for the repurchase of 23.1 million shares of our common stock and $156.9 million for the payment of dividends, compared to $1,507.0 million used for the repurchase of common stock and $153.1 million for the payment of dividends in the corresponding period of the prior year. In addition, we repaid $1,264.9 million of our Convertible Debt in the prior year.

[0001564590-15-000944:mdna:171]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including potential future issuances of debt, equity or other securities, will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all.

[0001564590-15-000944:mdna:172]
Liquidity

[0001564590-15-000944:mdna:173]
Our principal sources of liquidity as of January 23, 2015 consisted of cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001564590-15-000944:mdna:174]
Cash, cash equivalents and short-term investments consist of the following (in millions):

[0001564590-15-000944:mdna:175]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Cash and cash equivalents |  | $ | 2,539.7 |  |  | $ | 2,291.0 |  |
| Short-term investments |  |  | 2,712.8 |  |  |  | 2,712.3 |  |
| Total |  | $ | 5,252.5 |  |  | $ | 5,003.3 |  |

[0001564590-15-000944:mdna:176]
As of January 23, 2015 and April 25, 2014, $4.6 billion and $4.3 billion, respectively, of cash, cash equivalents and short-term investments was held by various foreign subsidiaries and was generally based in U.S. dollar-denominated holdings, while $0.7 billion was available in the United States as of each period end. Most of the amounts held outside the United States can be repatriated to the United States but, under current law, would be subject to U.S. federal, state income and foreign withholding taxes. If we were to repatriate foreign earnings for cash requirements in the United States, we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state tax credit carry forwards. However, our intent is to keep these funds permanently reinvested outside of the United States, and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies, and service interest and principal payments on our debt.

[0001564590-15-000944:mdna:177]
33

[0001564590-15-000944:mdna:178]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of January 23, 2015.

[0001564590-15-000944:mdna:179]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, and other liquidity requirements associated with our operations. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties.

[0001564590-15-000944:mdna:180]
Senior Notes

[0001564590-15-000944:mdna:181]
The following table summarizes the principal amount of our Senior Notes as of January 23, 2015 (in millions):

[0001564590-15-000944:mdna:182]
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |
| 3.375% Senior Notes Due 2021 |  |  | 500.0 |  |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |
| Total |  | $ | 1,500.0 |  |

[0001564590-15-000944:mdna:183]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 8 of the accompanying condensed consolidated financial statements.

[0001564590-15-000944:mdna:184]
Credit Facility

[0001564590-15-000944:mdna:185]
Our credit facility, under which we may borrow up to $250.0 million, provides another potential source of liquidity. The credit facility is an unsecured five-year revolving credit facility that terminates on December 21, 2017 if no extensions have been requested at that time, and contains financial covenants requiring us to maintain a maximum leverage ratio and a minimum interest coverage ratio. We may also, subject to certain requirements, request an increase in the facility up to an additional $100.0 million and request two additional one-year extensions, subject to certain conditions. As of January 23, 2015, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-15-000944:mdna:186]
We also have an automatic shelf registration statement on file with the Securities and Exchange Commission. We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001564590-15-000944:mdna:187]
Capital Expenditure Requirements

[0001564590-15-000944:mdna:188]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2015 to be between $25.0 million and $75.0 million.

[0001564590-15-000944:mdna:189]
Dividends and Stock Repurchase Program

[0001564590-15-000944:mdna:190]
On February 11, 2015, we declared a cash dividend of $0.165 per share of common stock, payable on April 23, 2015 to holders of record as of the close of business on April 10, 2015.

[0001564590-15-000944:mdna:191]
As of January 23, 2015, our Board of Directors had authorized the repurchase of up to $7.1 billion of our common stock under our stock repurchase program. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through January 23, 2015, we repurchased a total of 207.4 million shares of our common stock at an average price of $33.35 per share, for an aggregate purchase price of $6.9 billion. As of January 23, 2015, the remaining authorized amount for stock repurchases under this program was $205.9 million. In February 2015, our Board of Directors increased our stock repurchase program by an additional $2.5 billion with no termination date. We plan to repurchase $206 million of our common stock by the end of May 2015, and expect to repurchase the additional $2.5 billion by the end of May 2018, with the first $1 billion expected to be purchased by the end of May 2016.

[0001564590-15-000944:mdna:192]
34

[0001564590-15-000944:mdna:193]
The timing and amount of stock repurchase transactions and future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements.

[0001564590-15-000944:mdna:194]
Contractual Obligations

[0001564590-15-000944:mdna:195]
Operating Lease Commitments

[0001564590-15-000944:mdna:196]
As of January 23, 2015, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $203.2 million.

[0001564590-15-000944:mdna:197]
Purchase Orders and Other Commitments

[0001564590-15-000944:mdna:198]
In the ordinary course of business we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that product forecasts are not achieved, our commitments and associated accruals may change. As of January 23, 2015, we had $274.6 million in non-cancelable purchase commitments with our contract manufacturers and component suppliers. In addition, we recorded a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to cost of product revenues. As of January 23, 2015 and April 25, 2014, such liability amounted to $9.4 million and $11.5 million, respectively, and is included in other current liabilities in our condensed consolidated balance sheets.

[0001564590-15-000944:mdna:199]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not received goods or services. As of January 23, 2015, we had $68.8 million in capital purchase commitments and $192.2 million in other purchase commitments.

[0001564590-15-000944:mdna:200]
Unrecognized Tax Benefits

[0001564590-15-000944:mdna:201]
As of January 23, 2015, our liability for uncertain tax positions was $199.2 million, including penalties, interest and indirect benefits. Due to the uncertainty of the timing of future cash payments, we cannot make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-15-000944:mdna:202]
Legal Contingencies

[0001564590-15-000944:mdna:203]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 to our condensed consolidated financial statements.

[0001564590-15-000944:mdna:204]
Off-Balance Sheet Arrangements

[0001564590-15-000944:mdna:205]
In the ordinary course of business, we provide standby letters of credit or other guarantee instruments to third parties as required for certain transactions initiated either by us or our subsidiaries. As of January 23, 2015, we had financial guarantees of $10.2 million that were not recorded on our consolidated balance sheet that consisted of standby letters of credit and surety bonds.

[0001564590-15-000944:mdna:206]
Some of our customers have entered into recourse and non-recourse financing leasing arrangements using third-party financing companies, and in some situations, we enter into customer financing arrangements for our products and services that are contemporaneously sold on a recourse or non-recourse basis to third-party financing companies. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Under the terms of the non-recourse leases, we do not have any continuing obligations or liabilities to the third-party financing companies. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of January 23, 2015 and April 25, 2014, the aggregate amount by which such contingencies exceeded the associated deferred revenue was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001564590-15-000944:mdna:207]
We enter into indemnification agreements with third parties in the ordinary course of business. Generally, these indemnification agreements require us to reimburse losses suffered by the third-parties due to various events, such as lawsuits arising from patent or copyright infringement. These indemnification obligations are considered off-balance sheet arrangements under accounting guidance.
