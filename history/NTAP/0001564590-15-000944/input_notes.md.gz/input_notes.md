# NTAP notes — 0001564590-15-000944


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-15-000944:notes:1]
1. Description of Business and Significant Accounting Policies

[0001564590-15-000944:notes:2]
NetApp, Inc. (we, us, or the Company) is a global provider of innovative storage and data management software, systems and services. Our storage solutions help customers create the flexible, efficient and highly available IT infrastructures they need to support their organizations. We are a storage and data management provider to enterprises of all sizes, service providers, governmental organizations and original equipment manufacturers.

[0001564590-15-000944:notes:3]
Basis of Presentation and Preparation

[0001564590-15-000944:notes:4]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. Each quarter of fiscal 2015 and 2014 is a 13-week period.

[0001564590-15-000944:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 25, 2014 contained in our Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 17, 2014. The results of operations for the three and nine months ended January 23, 2015 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-15-000944:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-15-000944:notes:7]
There have been no significant changes in our significant accounting policies as of and for the nine months ended January 23, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 25, 2014.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-15-000944:notes:8]
3. Statements of Cash Flows Additional Information

[0001564590-15-000944:notes:9]
Non-cash investing activities and supplemental cash flow information are as follows (in millions):

[0001564590-15-000944:notes:10]
|  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 12.2 |  |  | $ | 25.7 |  |
| Acquisition of software through long-term financing |  | $ | 12.3 |  |  | $ | 11.4 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 89.0 |  |  | $ | 39.5 |  |
| Interest paid |  | $ | 32.5 |  |  | $ | 35.0 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-15-000944:notes:11]
4. Business Combinations

[0001564590-15-000944:notes:12]
On October 27, 2014, we completed the acquisition of certain assets related to Riverbed Technology, Inc.’s SteelStore product line for $79.1 million in cash. The SteelStore product line supports leading backup applications and cloud providers so that customers have a choice in how they extend their existing data protection infrastructure into the cloud.

[0001564590-15-000944:notes:13]
In addition, on the same date, we acquired certain intangible assets from a privately-held software developer for $5.5 million in cash.

[0001564590-15-000944:notes:14]
Following are the preliminary fair values of assets acquired and liabilities assumed as of the closing date (in millions):

[0001564590-15-000944:notes:15]
| Prepaid expenses and other current assets |  | $ | 2.7 |  |
| Finite-lived intangible assets |  |  | 31.8 |  |
| Goodwill |  |  | 43.2 |  |
| Deferred income taxes |  |  | 6.9 |  |
| Other non-current assets |  |  | 1.1 |  |
| Total assets acquired |  |  | 85.7 |  |
| Deferred revenues |  |  | (1.1 | ) |
| Total purchase price |  | $ | 84.6 |  |

[0001564590-15-000944:notes:16]
The results of operations related to these acquisitions have been included in our condensed consolidated statements of operations from the acquisition date. Pro forma results of operations have not been presented because the acquisitions were not material to our results of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-15-000944:notes:17]
5. Goodwill and Purchased Intangible Assets, Net

[0001564590-15-000944:notes:18]
Goodwill activity is summarized as follows (in millions):

[0001564590-15-000944:notes:19]
| Balance as of April 25, 2014 |  | $ | 988.1 |  |
| Goodwill acquired |  |  | 43.2 |  |
| Balance as of January 23, 2015 |  | $ | 1,031.3 |  |

[0001564590-15-000944:notes:20]
Purchased intangible assets, net are summarized below (in millions):

[0001564590-15-000944:notes:21]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 312.4 |  |  | $ | (210.0 | ) |  | $ | 102.4 |  |  | $ | 283.0 |  |  | $ | (162.6 | ) |  | $ | 120.4 |  |
| Customer contracts/relationships |  |  | 5.0 |  |  |  | (2.5 | ) |  |  | 2.5 |  |  |  | 9.6 |  |  |  | (9.0 | ) |  |  | 0.6 |  |
| Trademarks and trade names |  |  | 2.9 |  |  |  | (2.8 | ) |  |  | 0.1 |  |  |  | 2.9 |  |  |  | (2.4 | ) |  |  | 0.5 |  |
| Covenants not to compete |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.6 |  |  |  | (1.6 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 320.3 |  |  | $ | (215.3 | ) |  | $ | 105.0 |  |  | $ | 297.1 |  |  | $ | (175.6 | ) |  | $ | 121.5 |  |

[0001564590-15-000944:notes:22]
Amortization expense for purchased intangible assets is summarized below (in millions):

[0001564590-15-000944:notes:23]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Statement of |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | Operations Classifications |
| Developed technology |  | $ | 18.9 |  |  | $ | 14.2 |  |  | $ | 47.4 |  |  | $ | 42.8 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.4 |  |  |  | 1.0 |  |  | Operating expenses |
| Trademarks and trade names |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.4 |  |  |  | 0.3 |  |  | Operating expenses |
| Covenants not to compete |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.4 |  |  | Operating expenses |
|  |  | $ | 19.2 |  |  | $ | 14.7 |  |  | $ | 48.2 |  |  | $ | 44.5 |  |  |  |

[0001564590-15-000944:notes:24]
As of January 23, 2015, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-15-000944:notes:25]
| Fiscal Year |  | Amount |  |
| Remainder of 2015 |  | $ | 15.5 |  |
| 2016 |  |  | 58.4 |  |
| 2017 |  |  | 13.9 |  |
| 2018 |  |  | 9.4 |  |
| 2019 |  |  | 5.2 |  |
| Thereafter |  |  | 2.6 |  |
| Total |  | $ | 105.0 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-15-000944:notes:26]
6. Balance Sheet Details

[0001564590-15-000944:notes:27]
Cash and cash equivalents (in millions):

[0001564590-15-000944:notes:28]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Cash |  | $ | 2,266.7 |  |  | $ | 2,174.0 |  |
| Cash equivalents |  |  | 273.0 |  |  |  | 117.0 |  |
| Cash and cash equivalents |  | $ | 2,539.7 |  |  | $ | 2,291.0 |  |

[0001564590-15-000944:notes:29]
Inventories (in millions):

[0001564590-15-000944:notes:30]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Purchased components |  | $ | 25.9 |  |  | $ | 17.6 |  |
| Finished goods |  |  | 91.9 |  |  |  | 104.8 |  |
| Inventories |  | $ | 117.8 |  |  | $ | 122.4 |  |

[0001564590-15-000944:notes:31]
Other current assets (in millions):

[0001564590-15-000944:notes:32]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Prepaid expenses and other current assets |  | $ | 266.0 |  |  | $ | 219.4 |  |
| Deferred tax assets |  |  | 252.0 |  |  |  | 270.3 |  |
| Other current assets |  | $ | 518.0 |  |  | $ | 489.7 |  |

[0001564590-15-000944:notes:33]
Property and equipment, net (in millions):

[0001564590-15-000944:notes:34]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Land |  | $ | 265.5 |  |  | $ | 265.7 |  |
| Buildings and building improvements |  |  | 605.5 |  |  |  | 541.7 |  |
| Leasehold improvements |  |  | 104.8 |  |  |  | 102.9 |  |
| Computers, production, engineering and other equipment |  |  | 758.4 |  |  |  | 753.8 |  |
| Software |  |  | 372.3 |  |  |  | 369.1 |  |
| Furniture and fixtures |  |  | 85.5 |  |  |  | 86.4 |  |
| Construction-in-progress |  |  | 27.7 |  |  |  | 72.9 |  |
|  |  |  | 2,219.7 |  |  |  | 2,192.5 |  |
| Accumulated depreciation and amortization |  |  | (1,169.0 | ) |  |  | (1,083.7 | ) |
| Property and equipment, net |  | $ | 1,050.7 |  |  | $ | 1,108.8 |  |

[0001564590-15-000944:notes:35]
The net book value of software, which includes capitalized internal-use software development costs, is summarized below (in millions):

[0001564590-15-000944:notes:36]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Software |  | $ | 71.0 |  |  | $ | 103.5 |  |

[0001564590-15-000944:notes:37]
Other non-current assets (in millions):

[0001564590-15-000944:notes:38]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Auction rate securities |  | $ | — |  |  | $ | 36.0 |  |
| Deferred tax assets |  |  | 250.6 |  |  |  | 245.0 |  |
| Other assets |  |  | 242.5 |  |  |  | 248.5 |  |
| Other non-current assets |  | $ | 493.1 |  |  | $ | 529.5 |  |

[0001564590-15-000944:notes:39]
Short-term and long-term deferred revenue (in millions):

[0001564590-15-000944:notes:40]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Product |  | $ | 24.2 |  |  | $ | 23.4 |  |
| Software entitlements and maintenance and service |  |  | 3,085.5 |  |  |  | 3,076.8 |  |
| Total |  | $ | 3,109.7 |  |  | $ | 3,100.2 |  |
| Reported as: |  |  |  |  |  |  |  |  |
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Short-term |  | $ | 1,679.4 |  |  | $ | 1,653.8 |  |
| Long-term |  |  | 1,430.3 |  |  |  | 1,446.4 |  |
| Total |  | $ | 3,109.7 |  |  | $ | 3,100.2 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-15-000944:notes:41]
7. Financial Instruments and Fair Value Measurements

[0001564590-15-000944:notes:42]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis, whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the three levels of inputs to measure fair value:

[0001564590-15-000944:notes:43]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001564590-15-000944:notes:44]
Level 2: Inputs that reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; benchmark yields, reported trades, broker/dealer quotes, inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0001564590-15-000944:notes:45]
Level 3: Unobservable inputs that reflect our own assumptions incorporated in valuation techniques used to measure fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0001564590-15-000944:notes:46]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and consider an inactive market to be one in which there are infrequent or few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty’s non-performance risk is considered in measuring the fair values of liabilities and assets, respectively.

[0001564590-15-000944:notes:47]
[same as prior period, unchanged from 0001193125-14-425190:notes:122]

[0001564590-15-000944:notes:48]
The following is a summary of our investments (in millions):

[0001564590-15-000944:notes:49]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
|  |  |  |  |  |  | Gross Unrealized |  |  |  |  |  |  |  |  |  |  | Gross Unrealized |  |  |  |  |  |
|  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |
| Corporate bonds |  | $ | 2,083.9 |  |  | $ | 6.6 |  |  | $ | (0.4 | ) |  |  | 2,090.1 |  |  | $ | 2,142.3 |  |  | $ | 10.5 |  |  | $ | (0.5 | ) |  | $ | 2,152.3 |  |
| U.S. Treasury and government debt securities |  |  | 521.4 |  |  |  | 1.4 |  |  |  | (0.1 | ) |  |  | 522.7 |  |  |  | 263.4 |  |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 263.6 |  |
| Commercial paper |  |  | 15.0 |  |  |  | — |  |  |  | — |  |  |  | 15.0 |  |  |  | 168.4 |  |  |  | — |  |  |  | — |  |  |  | 168.4 |  |
| Certificates of deposit |  |  | 358.0 |  |  |  | — |  |  |  | — |  |  |  | 358.0 |  |  |  | 245.0 |  |  |  | — |  |  |  | — |  |  |  | 245.0 |  |
| Auction rate securities |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 36.9 |  |  |  | — |  |  |  | (0.9 | ) |  |  | 36.0 |  |
| Equity funds |  |  | 30.4 |  |  |  | — |  |  |  | — |  |  |  | 30.4 |  |  |  | 32.7 |  |  |  | — |  |  |  | — |  |  |  | 32.7 |  |
| Total debt and equity securities |  | $ | 3,008.7 |  |  | $ | 8.0 |  |  | $ | (0.5 | ) |  | $ | 3,016.2 |  |  | $ | 2,888.7 |  |  | $ | 10.8 |  |  | $ | (1.5 | ) |  | $ | 2,898.0 |  |

[0001564590-15-000944:notes:50]
The unrealized losses on our available-for-sale investments were caused by market value declines as a result of the economic environment, as well as fluctuations in market interest rates. Because the declines in market value are attributable to changes in market conditions and not credit quality, and because we have determined that (i) we do not have the intent to sell any of these investments and (ii) it is not more likely than not that we will be required to sell any of these investments before recovery of the entire amortized cost basis, we have concluded that no other-than-temporary impairments were required to be recognized on these investments as of January 23, 2015.

[0001564590-15-000944:notes:51]
The following table presents the contractual maturities of our debt investments as of January 23, 2015 (in millions):

[0001564590-15-000944:notes:52]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,479.8 |  |  | $ | 1,482.0 |  |
| Due in two through five years |  |  | 1,498.5 |  |  |  | 1,503.8 |  |
|  |  | $ | 2,978.3 |  |  | $ | 2,985.8 |  |

[0001564590-15-000944:notes:53]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0001564590-15-000944:notes:54]
[same as prior period, unchanged from 0001193125-14-425190:notes:128]

[0001564590-15-000944:notes:55]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis (in millions):

[0001564590-15-000944:notes:56]
|  |  | January 23, 2015 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  | Significant |  |
|  |  |  |  |  |  | in Active Markets |  |  | Other |  |
|  |  |  |  |  |  | for Identical Assets |  |  | Observable Inputs |  |
|  |  | Total |  |  | (Level 1) |  |  | (Level 2) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,090.1 |  |  | $ | — |  |  | $ | 2,090.1 |  |
| U.S. Treasury and government debt securities |  |  | 522.7 |  |  |  | 140.4 |  |  |  | 382.3 |  |
| Commercial paper |  |  | 15.0 |  |  |  | — |  |  |  | 15.0 |  |
| Certificates of deposit |  |  | 358.0 |  |  |  | — |  |  |  | 358.0 |  |
| Equity funds |  |  | 30.4 |  |  |  | 30.4 |  |  |  | — |  |
| Foreign currency contracts |  |  | 21.5 |  |  |  | — |  |  |  | 21.5 |  |
| Total |  | $ | 3,037.7 |  |  | $ | 170.8 |  |  | $ | 2,866.9 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | (6.9 | ) |  | $ | — |  |  | $ | (6.9 | ) |

[0001564590-15-000944:notes:57]
The following table summarizes the balance sheet classifications of our financial assets and liabilities measured at fair value on a recurring basis (in millions):

[0001564590-15-000944:notes:58]
|  |  | January 23, 2015 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  | Significant |  |
|  |  |  |  |  |  | in Active Markets |  |  | Other |  |
|  |  |  |  |  |  | for Identical Assets |  |  | Observable Inputs |  |
|  |  | Total |  |  | (Level 1) |  |  | (Level 2) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 273.0 |  |  | $ | — |  |  | $ | 273.0 |  |
| Short-term investments |  |  | 2,712.8 |  |  |  | 140.4 |  |  |  | 2,572.4 |  |
| Other current assets |  |  | 24.4 |  |  |  | 2.9 |  |  |  | 21.5 |  |
| Other non-current assets |  |  | 27.5 |  |  |  | 27.5 |  |  |  | — |  |
| Total |  | $ | 3,037.7 |  |  | $ | 170.8 |  |  | $ | 2,866.9 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | (6.9 | ) |  | $ | — |  |  | $ | (6.9 | ) |

[0001564590-15-000944:notes:59]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 financial instruments. As of January 23, 2015, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-15-000944:notes:60]
During the three months ended January 23. 2015, we settled our remaining investments in Auction Rate Securities (ARSs), which had been classified as Level 3 financial instruments at their respective par values.

[0001564590-15-000944:notes:61]
The table below provides a reconciliation of the beginning and ending balance of our Level 3 ARSs (in millions).

[0001564590-15-000944:notes:62]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Balance at beginning of period |  | $ | 23.0 |  |  | $ | 39.5 |  |  | $ | 36.0 |  |  | $ | 42.0 |  |
| Total unrealized gains, net included in other comprehensive income (loss) |  |  | 0.3 |  |  |  | 0.9 |  |  |  | 0.9 |  |  |  | 0.7 |  |
| Total realized gains included in earnings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.7 |  |
| Sales |  |  | — |  |  |  | — |  |  |  | (10.0 | ) |  |  | (3.0 | ) |
| Settlements |  |  | (23.3 | ) |  |  | — |  |  |  | (26.9 | ) |  |  | — |  |
| Balance at end of period |  | $ | — |  |  | $ | 40.4 |  |  | $ | — |  |  | $ | 40.4 |  |

[0001564590-15-000944:notes:63]
[same as prior period, unchanged from 0001193125-14-425190:notes:134]

[0001564590-15-000944:notes:64]
As of January 23, 2015, the fair value of our long-term debt was approximately $1,521.3 million. The fair value of our debt was based on observable market prices in a less active market and discounted cash flow models that take into consideration variables such as credit-rating and interest rate changes. All of our debt obligations are categorized as Level 2 financial instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-15-000944:notes:65]
8. Financing Arrangements

[0001564590-15-000944:notes:66]
Long-term Debt

[0001564590-15-000944:notes:67]
The following table summarizes the carrying value of our long-term debt (in millions):

[0001564590-15-000944:notes:68]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500.0 |  |  |  | 3.54 | % |  |  | — |  |  | N/A |  |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500.0 |  |  |  |  |  |  |  | 1,000.0 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.3 | ) |  |  |  |  |  |  | (4.5 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,494.7 |  |  |  |  |  |  | $ | 995.5 |  |  |  |  |  |

[0001564590-15-000944:notes:69]
__________________

[0001564590-15-000944:notes:70]
N/A - Not Applicable

[0001564590-15-000944:notes:71]
Senior Notes

[0001564590-15-000944:notes:72]
On June 5, 2014 we issued $500.0 million aggregate par value of 3.375% Senior Notes, with a maturity date of June 15, 2021, and received proceeds of approximately $494.7 million, net of discount and issuance costs, which will be used for general corporate purposes, including possible stock repurchases, dividends, capital expenditures, working capital and potential acquisitions and strategic transactions. Our 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $750.0 million and $250.0 million, respectively, were issued in December 2012. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any future senior unsecured indebtedness.

[0001564590-15-000944:notes:73]
We may redeem the Senior Notes in whole or in part at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 23, 2015, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-15-000944:notes:74]
As of January 23, 2015, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-15-000944:notes:75]
| Fiscal Year |  |  |  |  |  | Amount |  |
| 2018 |  |  |  |  |  | $ | 750.0 |  |
| Thereafter |  |  |  |  |  |  | 750.0 |  |
| Total |  |  |  |  |  | $ | 1,500.0 |  |

[0001564590-15-000944:notes:76]
Credit Facility

[0001564590-15-000944:notes:77]
In December 2012, we entered into a credit agreement with a syndicated group of lenders that is scheduled to expire on December 21, 2017 and provides for an unsecured $250.0 million revolving credit facility that is comprised of revolving loans, Eurocurrency loans and/or swingline loans. The credit facility includes a $100.0 million foreign currency sub-facility, a $50.0 million letter of credit sub-facility and a $10.0 million swingline sub-facility available on same-day notice. Available borrowings under the credit facility are reduced by the amount of any outstanding borrowings on the sub-facilities. We may also, subject to certain requirements, request an increase in the facility up to an additional $100.0 million and request two additional one-year extensions, subject to certain conditions. The proceeds from the facility may be used by us for general corporate purposes.

[0001564590-15-000944:notes:78]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of January 23, 2015, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-15-000944:notes:79]
Other Long-Term Financing Arrangements

[0001564590-15-000944:notes:80]
The following presents the amounts due under other long-term financing arrangements (in millions):

[0001564590-15-000944:notes:81]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Other long-term financing arrangements |  | $ | 17.6 |  |  | $ | 13.1 |  |
| Less: current portion |  |  | (9.4 | ) |  |  | (6.6 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 8.2 |  |  | $ | 6.5 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-15-000944:notes:82]
9. Stockholders’ Equity

[0001564590-15-000944:notes:83]
[same as prior period, unchanged from 0001193125-14-425190:notes:72]

[0001564590-15-000944:notes:84]
The following table summarizes activity related to our stock options (in millions, except for exercise price and contractual term):

[0001564590-15-000944:notes:85]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 25, 2014 |  |  | 14.5 |  |  | $ | 34.10 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2.2 |  |  | $ | 36.64 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (4.0 | ) |  | $ | 25.33 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (0.4 | ) |  | $ | 43.40 |  |  |  |  |  |  |  |  |  |
| Outstanding as of January 23, 2015 |  |  | 12.3 |  |  | $ | 37.03 |  |  |  | 3.85 |  |  | $ | 62.6 |  |
| Vested and expected to vest as of January 23, 2015 |  |  | 11.8 |  |  | $ | 37.05 |  |  |  | 3.76 |  |  |  | 61.0 |  |
| Exercisable as of January 23, 2015 |  |  | 8.1 |  |  | $ | 37.23 |  |  |  | 2.91 |  |  |  | 48.3 |  |

[0001564590-15-000944:notes:86]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our stock on that day for all in-the-money options.

[0001564590-15-000944:notes:87]
Additional information related to our stock options is summarized below (in millions):

[0001564590-15-000944:notes:88]
|  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Intrinsic value of exercises |  | $ | 61.2 |  |  | $ | 81.3 |  |
| Proceeds received from exercises |  | $ | 99.9 |  |  | $ | 147.7 |  |
| Fair value of options vested |  | $ | 26.3 |  |  | $ | 36.0 |  |

[0001564590-15-000944:notes:89]
[same as prior period, unchanged from 0001193125-14-425190:notes:76]

[0001564590-15-000944:notes:90]
The following table summarizes activity related to our restricted stock units (RSUs) (in millions, except for fair value):

[0001564590-15-000944:notes:91]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 25, 2014 |  |  | 13.2 |  |  | $ | 38.35 |  |
| Granted |  |  | 6.3 |  |  |  | 35.80 |  |
| Vested |  |  | (4.3 | ) |  |  | 40.05 |  |
| Forfeited |  |  | (1.3 | ) |  |  | 37.71 |  |
| Outstanding as of January 23, 2015 |  |  | 13.9 |  |  |  | 36.73 |  |

[0001564590-15-000944:notes:92]
RSUs are converted into common stock upon vesting. We primarily use the net share settlement approach upon vesting, where a portion of the shares are withheld as settlement of statutory employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001564590-15-000944:notes:93]
|  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Shares withheld for taxes |  |  | 1.4 |  |  |  | 1.3 |  |
| Fair value of shares withheld |  | $ | 51.4 |  |  | $ | 51.4 |  |

[0001564590-15-000944:notes:94]
[same as prior period, unchanged from 0001193125-14-425190:notes:79]

[0001564590-15-000944:notes:95]
The following table summarizes activity related to the purchase rights issued under the Employee Stock Purchase Plan (ESPP) (in millions):

[0001564590-15-000944:notes:96]
|  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Shares issued under the ESPP |  |  | 3.4 |  |  |  | 3.8 |  |
| Proceeds from issuance of shares |  | $ | 97.1 |  |  | $ | 95.5 |  |

[0001564590-15-000944:notes:97]
[same as prior period, unchanged from 0001193125-14-425190:notes:82]

[0001564590-15-000944:notes:98]
Stock-based compensation expense is included in the condensed consolidated statements of operations as follows (in millions):

[0001564590-15-000944:notes:99]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Cost of product revenues |  | $ | 1.4 |  |  | $ | 1.5 |  |  | $ | 4.5 |  |  | $ | 4.2 |  |
| Cost of service revenues |  |  | 4.0 |  |  |  | 4.6 |  |  |  | 12.4 |  |  |  | 12.8 |  |
| Sales and marketing |  |  | 29.6 |  |  |  | 33.0 |  |  |  | 87.0 |  |  |  | 94.6 |  |
| Research and development |  |  | 21.9 |  |  |  | 23.6 |  |  |  | 64.6 |  |  |  | 66.6 |  |
| General and administrative |  |  | 9.1 |  |  |  | 9.2 |  |  |  | 27.6 |  |  |  | 27.6 |  |
| Total stock-based compensation expense |  | $ | 66.0 |  |  | $ | 71.9 |  |  | $ | 196.1 |  |  | $ | 205.8 |  |

[0001564590-15-000944:notes:100]
As of January 23, 2015, total unrecognized compensation expense related to our equity awards was $416.7 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.4 years.

[0001564590-15-000944:notes:101]
Total income tax benefit associated with employee stock transactions and recognized in stockholders’ equity were as follows (in millions):

[0001564590-15-000944:notes:102]
|  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Income tax benefit associated with employee stock transactions |  | $ | 54.0 |  |  | $ | 22.5 |  |

[0001564590-15-000944:notes:103]
[same as prior period, unchanged from 0001193125-14-425190:notes:88]

[0001564590-15-000944:notes:104]
As of January 23, 2015, our Board of Directors has authorized the repurchase of up to $7.1 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management.

[0001564590-15-000944:notes:105]
The following table summarizes activity related to this program for the nine months ended January 23, 2015 (in millions, except per share information):

[0001564590-15-000944:notes:106]
| Number of shares repurchased |  |  | 23.1 |  |
| Average price per share |  | $ | 39.73 |  |
| Aggregate purchase price |  | $ | 918.9 |  |
| Remaining authorization at end of period |  | $ | 205.9 |  |

[0001564590-15-000944:notes:107]
The aggregate purchase price of our stock repurchases for the nine months ended January 23, 2015 consisted of $918.9 million of open market purchases, of which $667.4 million and $251.5 million was allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-15-000944:notes:108]
On February 9, 2015, our Board of Directors increased the authorization to repurchase our common stock by $2.5 billion.

[0001564590-15-000944:notes:109]
[same as prior period, unchanged from 0001193125-14-425190:notes:93]

[0001564590-15-000944:notes:110]
The following is a summary of our activities related to dividends on our common stock (in millions, except per share amounts):

[0001564590-15-000944:notes:111]
|  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Dividends per share declared and paid |  | $ | 0.495 |  |  | $ | 0.450 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 52.1 |  |  | $ | 50.4 |  |
| Dividend payments allocated to retained earnings |  | $ | 104.8 |  |  | $ | 102.7 |  |

[0001564590-15-000944:notes:112]
On February 11, 2015, we declared a cash dividend of $0.165 per share of common stock, payable on April 23, 2015 to holders of record as of the close of business on April 10, 2015. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by the Company to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-15-000944:notes:113]
[same as prior period, unchanged from 0001193125-14-425190:notes:97]

[0001564590-15-000944:notes:114]
A reconciliation of retained earnings for the nine months ended January 23, 2015 is as follows (in millions):

[0001564590-15-000944:notes:115]
| Balance as of April 25, 2014 |  | $ | 1.1 |  |
| Net income |  |  | 425.0 |  |
| Repurchases of common stock |  |  | (251.5 | ) |
| Dividends |  |  | (104.8 | ) |
| Balance as of January 23, 2015 |  | $ | 69.8 |  |

[0001564590-15-000944:notes:116]
[same as prior period, unchanged from 0001193125-14-425190:notes:100]

[0001564590-15-000944:notes:117]
Changes in accumulated other comprehensive income (AOCI) by component, net of tax, for the nine months ended January 23, 2015 are summarized below (in millions):

[0001564590-15-000944:notes:118]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivatives Instruments |  |  | Total |  |
| Balance as of April 25, 2014 |  | $ | 5.5 |  |  | $ | (4.8 | ) |  | $ | 8.9 |  |  | $ | (0.5 | ) |  | $ | 9.1 |  |
| Other comprehensive income (loss) (OCI) before reclassifications, net of tax |  |  | (26.9 | ) |  |  | 1.1 |  |  |  | (1.4 | ) |  |  | 13.1 |  |  |  | (14.1 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | (9.5 | ) |  |  | (9.3 | ) |
| Net OCI |  |  | (26.9 | ) |  |  | 1.4 |  |  |  | (1.5 | ) |  |  | 3.6 |  |  |  | (23.4 | ) |
| Balance as of January 23, 2015 |  | $ | (21.4 | ) |  | $ | (3.4 | ) |  | $ | 7.4 |  |  | $ | 3.1 |  |  | $ | (14.3 | ) |

[0001564590-15-000944:notes:119]
The amounts reclassified out of AOCI are as follows (in millions):

[0001564590-15-000944:notes:120]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |
| Recognized losses on defined benefit obligations |  | $ | 0.1 |  |  | $ | — |  |  | $ | 0.3 |  |  | $ | — |  |  | Operating expenses |
| Realized gains on available-for-sale securities |  |  | (0.3 | ) |  |  | — |  |  |  | (0.1 | ) |  |  | (1.1 | ) |  | Other income (expense), net |
| Realized (gains) losses on cash flow hedges |  |  | (15.7 | ) |  |  | (0.2 | ) |  |  | (9.5 | ) |  |  | 1.2 |  |  | Net revenues |
| Total reclassifications |  | $ | (15.9 | ) |  | $ | (0.2 | ) |  | $ | (9.3 | ) |  | $ | 0.1 |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-15-000944:notes:121]
10. Derivatives and Hedging Activities

[0001564590-15-000944:notes:122]
We use derivative instruments to manage exposures to foreign currency risk. All contracts have a maturity of less than six months. The notional amount of our outstanding U.S. dollar equivalent foreign currency exchange forward contracts consisted of the following (in millions):

[0001564590-15-000944:notes:123]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 159.1 |  |  | $ | 122.6 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  |  | 183.2 |  |  |  | 155.5 |  |
| Forward contracts purchased |  |  | 304.7 |  |  |  | 389.9 |  |

[0001564590-15-000944:notes:124]
We have master netting arrangements in place to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of January 23, 2015 and April 25, 2014. We did not recognize any gains and losses in earnings due to hedge ineffectiveness for any period presented.

[0001564590-15-000944:notes:125]
The effect of derivative instruments designated as cash flow hedges recognized in net revenues on our condensed consolidated statements of operations is presented in the condensed consolidated statements of comprehensive income and Note 9.

[0001564590-15-000944:notes:126]
The effect of derivative instruments not designated as hedging instruments recognized in other income (expense), net on our condensed consolidated statements of operations was as follows (in millions):

[0001564590-15-000944:notes:127]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |
|  |  | Gain Recognized into Income |  |  | Gain Recognized into Income |  |
| Foreign exchange contracts |  | $ | 11.0 |  |  | $ | 1.0 |  |  | $ | 9.4 |  |  | $ | 1.8 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-15-000944:notes:128]
11. Restructuring and Other Charges

[0001564590-15-000944:notes:129]
In May 2013, we initiated a business restructuring plan under which we realigned internal resources, resulting in a reduction of our global workforce of approximately 7%. Such activities were completed in the year ended April 25, 2014. In March 2014, we initiated a business realignment plan designed to focus our resources on key strategic initiatives and streamline our business in light of the constrained IT spending environment, resulting in a reduction of our global workforce of approximately 4%. Such activities were completed in the nine months ended January 23, 2015. Restructuring and other charges consisted primarily of employee severance-related costs.

[0001564590-15-000944:notes:130]
Activities related to these plans are summarized as follows (in millions):

[0001564590-15-000944:notes:131]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |
|  |  | (March 2014 Plan) |  |  | (May 2013 Plan) |  |
| Balance at beginning of period |  | $ | 26.5 |  |  | $ | — |  |
| Net charges |  |  | — |  |  |  | 49.5 |  |
| Cash payments |  |  | (26.5 | ) |  |  | (48.9 | ) |
| Balance at end of period |  | $ | — |  |  | $ | 0.6 |  |

[0001564590-15-000944:notes:132]
The liability for our restructuring plans is included in accrued compensation and related benefits in our condensed consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-15-000944:notes:133]
12. Income Taxes

[0001564590-15-000944:notes:134]
Our effective tax rates for the periods presented were as follows:

[0001564590-15-000944:notes:135]
|  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Effective tax rates |  |  | 22.5 | % |  |  | 14.3 | % |

[0001564590-15-000944:notes:136]
Our effective tax rates reflect the impact of a significant amount of our earnings being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. In addition, our effective tax rate for the nine months ended January 23, 2015 was impacted by the extension of the federal research credit and the settlements of income tax audits as discussed below.

[0001564590-15-000944:notes:137]
On December 19, 2014 the federal research credit was retroactively extended for amounts paid or incurred after December 31, 2013 and before January 1, 2015. As a result of the extension, during the three and nine months ended January 23, 2015, we recorded a benefit of $6.0 million related to the current year research credit and a discrete benefit of $4.1 million related to a prior year credit that we will retroactively claim. The federal research credit expired on December 31, 2014.

[0001564590-15-000944:notes:138]
In July 2014, the Internal Revenue Service (IRS) completed the examination of our fiscal 2005 to 2007 income tax returns upon approval by the Joint Committee of Taxation. We recorded a $47.4 million income tax provision attributable to the audit settlement and related re-measurement of uncertain tax positions for tax years subject to future audits. The audit adjustments resulted in lower earnings in our foreign subsidiaries which reduced the taxability of dividends that were previously repatriated from such subsidiaries. Due to this reduction in taxable dividends, the conclusion of the fiscal 2005 to 2007 income tax audit resulted in a net refund of $8.0 million, excluding interest.

[0001564590-15-000944:notes:139]
In October 2014, the United Kingdom’s (UK’s) tax authority concluded the examination of our fiscal 2009 to 2012 UK income tax returns. We recorded a $1.0 million income tax benefit for the net impact of the audit adjustments and related release of unrecognized tax benefits.

[0001564590-15-000944:notes:140]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001564590-15-000944:notes:141]
|  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Balance at beginning of period |  | $ | 235.9 |  |  | $ | 189.6 |  |
| Additions based on tax positions related to the current year |  |  | 19.1 |  |  |  | 20.9 |  |
| Additions for tax positions of prior years |  |  | 101.5 |  |  |  | 1.8 |  |
| Decreases for tax positions of prior years |  |  | (23.5 | ) |  |  | (4.5 | ) |
| Settlements |  |  | (57.6 | ) |  |  | - |  |
| Balance at end of period |  | $ | 275.4 |  |  | $ | 207.8 |  |

[0001564590-15-000944:notes:142]
As of January 23, 2015, we had $275.4 million of gross unrecognized tax benefits, of which $220.2 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $169.7 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-15-000944:notes:143]
We are currently undergoing federal income tax audits in the United States and several foreign tax jurisdictions. Transfer pricing calculations are key issues under audits in various jurisdictions, and are often subject to dispute and appeals. The IRS is currently auditing our fiscal 2008 to 2010 income tax returns. We expect the IRS examination team to complete their field audit within the next twelve months. However, the resolution of the fiscal 2008 to 2010 income tax return audits may likely occur beyond the next twelve months should we choose to appeal the IRS examination team’s audit findings.

[0001564590-15-000944:notes:144]
On September 17, 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 from our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. On December 19, 2011, the Danish Tax Tribunal issued a ruling that our Danish subsidiary was not liable for Danish withholding tax. The Danish tax examination agency appealed to the Danish High Court in March 2012. The Danish High Court hearing has not yet occurred.

[0001564590-15-000944:notes:145]
Our Dutch subsidiaries have concluded an advanced transfer pricing agreement with the Dutch tax authorities that will be effective from May 1, 2015 to April 30, 2020. The advanced transfer pricing agreement has terms similar to our current agreement which is set to expire on April 30, 2015.


## us-gaap:EarningsPerShareTextBlock

[0001564590-15-000944:notes:146]
13. Net Income per Share

[0001564590-15-000944:notes:147]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0001564590-15-000944:notes:148]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 176.8 |  |  | $ | 192.1 |  |  | $ | 425.0 |  |  | $ | 440.5 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 311.6 |  |  |  | 339.4 |  |  |  | 317.8 |  |  |  | 343.7 |  |
| Dilutive impact of employee equity award plans |  |  | 5.5 |  |  |  | 6.8 |  |  |  | 5.5 |  |  |  | 7.0 |  |
| Dilutive impact of assumed conversion of Convertible Notes |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.7 |  |
| Dilutive impact of warrants |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.3 |  |
| Shares used in diluted computation |  |  | 317.1 |  |  |  | 346.2 |  |  |  | 323.3 |  |  |  | 351.7 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.57 |  |  | $ | 0.57 |  |  | $ | 1.34 |  |  | $ | 1.28 |  |
| Diluted |  | $ | 0.56 |  |  | $ | 0.55 |  |  | $ | 1.31 |  |  | $ | 1.25 |  |

[0001564590-15-000944:notes:149]
The following potential weighted-average shares of common stock have been excluded from the diluted net income per share calculations, as their effect would have been anti-dilutive (in millions):

[0001564590-15-000944:notes:150]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Employee equity award plans |  |  | 6.8 |  |  |  | 5.7 |  |  |  | 7.5 |  |  |  | 6.5 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-15-000944:notes:151]
14. Segment, Geographic, and Significant Customer Information

[0001564590-15-000944:notes:152]
We operate in one industry segment: the design, manufacturing, marketing, and technical support of high-performance storage and data management solutions. We conduct business globally, and our sales and support activities are managed on a geographic basis. Our management reviews financial information presented on a consolidated basis, accompanied by disaggregated information it receives from our internal management system about revenues by geographic region, based on the location from which the customer relationship is managed, for purposes of allocating resources and evaluating financial performance. We do not allocate costs of revenues, research and development, sales and marketing, or general and administrative expenses to our geographic regions in this internal management reporting because management does not review operations or operating results, or make planning decisions, below the consolidated entity level.

[0001564590-15-000944:notes:153]
Summarized revenues by geographic region based on information from our internal management system and utilized by our Chief Executive Officer, who is considered our Chief Operating Decision Maker, is as follows (in millions):

[0001564590-15-000944:notes:154]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Americas (United States, Canada and Latin America) |  | $ | 836.9 |  |  | $ | 838.7 |  |  | $ | 2,574.2 |  |  | $ | 2,596.4 |  |
| Europe, Middle East and Africa |  |  | 509.2 |  |  |  | 546.9 |  |  |  | 1,391.7 |  |  |  | 1,439.9 |  |
| Asia Pacific |  |  | 205.2 |  |  |  | 224.4 |  |  |  | 617.1 |  |  |  | 639.8 |  |
| Net revenues |  | $ | 1,551.3 |  |  | $ | 1,610.0 |  |  | $ | 4,583.0 |  |  | $ | 4,676.1 |  |

[0001564590-15-000944:notes:155]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the United States were $747.2 million and $734.6 million during the three months ended January 23, 2015 and January 24, 2014, respectively, and were $2,309.8 million and $2,308.1 million during the nine months ended January 23, 2015 and January 24, 2014, respectively.

[0001564590-15-000944:notes:156]
The majority of our assets, excluding cash, cash equivalents, restricted cash, investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents, restricted cash and investments held in the United States and internationally in various foreign subsidiaries (in millions):

[0001564590-15-000944:notes:157]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| United States |  | $ | 671.1 |  |  | $ | 688.5 |  |
| International |  |  | 4,594.5 |  |  |  | 4,360.9 |  |
| Total |  | $ | 5,265.6 |  |  | $ | 5,049.4 |  |

[0001564590-15-000944:notes:158]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment information for geographic areas based on the physical location of the assets (in millions):

[0001564590-15-000944:notes:159]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| United States |  | $ | 954.9 |  |  | $ | 1,021.4 |  |
| International |  |  | 95.8 |  |  |  | 87.4 |  |
| Total |  | $ | 1,050.7 |  |  | $ | 1,108.8 |  |

[0001564590-15-000944:notes:160]
The following customers, each of which is a distributor, accounted for 10% or more of our net revenues:

[0001564590-15-000944:notes:161]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 20 | % |  |  | 23 | % |  |  | 21 | % |
| Avnet, Inc. |  |  | 16 | % |  |  | 15 | % |  |  | 16 | % |  |  | 16 | % |

[0001564590-15-000944:notes:162]
The following customers accounted for 10% or more of net accounts receivable:

[0001564590-15-000944:notes:163]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Arrow Electronics, Inc. |  |  | 12 | % |  |  | 14 | % |
| Avnet, Inc. |  | N/A |  |  |  | 16 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-15-000944:notes:164]
15. Commitments and Contingencies

[0001564590-15-000944:notes:165]
Operating Lease Commitments

[0001564590-15-000944:notes:166]
We lease various equipment, vehicles and office space in the U.S. and internationally. As of January 23, 2015, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $203.2 million.

[0001564590-15-000944:notes:167]
Purchase Orders and Other Commitments

[0001564590-15-000944:notes:168]
In the ordinary course of business we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that product forecasts are not achieved, our commitments and associated accruals may change. As of January 23, 2015, we had $274.6 million in non-cancelable purchase commitments with our contract manufacturers and component suppliers. In addition, we recorded a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to cost of product revenues. As of January 23, 2015 and April 25, 2014, such liability amounted to $9.4 million and $11.5 million, respectively, and is included in other current liabilities in our condensed consolidated balance sheets.

[0001564590-15-000944:notes:169]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 23, 2015, we had $68.8 million in capital purchase commitments and $192.2 million in other purchase commitments.

[0001564590-15-000944:notes:170]
Product Warranties

[0001564590-15-000944:notes:171]
We generally provide customers a warranty on software of ninety days and a warranty on hardware of three years. The following tables summarize the activity related to product warranty liabilities and their balances as reported in our condensed consolidated balance sheets (in millions):

[0001564590-15-000944:notes:172]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Balance at beginning of period |  | $ | 96.6 |  |  | $ | 116.0 |  |  | $ | 110.0 |  |  | $ | 117.2 |  |
| Expense accrued during the period |  |  | 3.1 |  |  |  | 21.1 |  |  |  | 21.9 |  |  |  | 59.4 |  |
| Warranty costs incurred |  |  | (12.2 | ) |  |  | (20.0 | ) |  |  | (44.4 | ) |  |  | (59.5 | ) |
| Balance at end of period |  | $ | 87.5 |  |  | $ | 117.1 |  |  | $ | 87.5 |  |  | $ | 117.1 |  |

[0001564590-15-000944:notes:173]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Other current liabilities |  | $ | 59.5 |  |  | $ | 73.0 |  |
| Other long-term liabilities |  |  | 28.0 |  |  |  | 37.0 |  |
| Total |  | $ | 87.5 |  |  | $ | 110.0 |  |

[0001564590-15-000944:notes:174]
Financing Guarantees

[0001564590-15-000944:notes:175]
Some of our customers have entered into recourse and non-recourse financing leasing arrangements using third-party financing companies, and in some situations, we enter into customer financing arrangements for our products and services that are contemporaneously sold on a recourse or non-recourse basis to third-party financing companies. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Under the terms of the non-recourse leases, we do not have any continuing obligations or liabilities to the third-party financing companies. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of January 23, 2015 and April 25, 2014, the aggregate amount by which such contingencies exceeded the associated deferred revenue was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001564590-15-000944:notes:176]
Legal Contingencies

[0001564590-15-000944:notes:177]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict, and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-15-000944:notes:178]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of January 23, 2015 related to such matters as they are not probable and/or reasonably estimable.
