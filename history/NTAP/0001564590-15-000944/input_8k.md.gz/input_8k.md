# NTAP 8-K — 0001102624-15-000197 filed 2015-02-11

## item codes, every 8-K on or before 2015-02-25

- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2015-02-25

- none on or before 2015-02-25

## item 2.02 — earnings release, exhibit 99.1

[0001102624-15-000197:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-15-000197:8k_2_02:2]
exh99_1.htm

[0001102624-15-000197:8k_2_02:3]
Exhibit 99.1

[0001102624-15-000197:8k_2_02:4]
|  | Press Contact: |  | Investor Contact: |
|  | Meghan Fintland |  | Kris Newton |
|  | NetApp |  | NetApp |
|  | 408-822-1389 |  | 408-822-3312 |
|  | meghan.fintland@netapp.com |  | kris.newton@netapp.com |

[0001102624-15-000197:8k_2_02:5]
NETAPP REPORTS THIRD QUARTER FISCAL YEAR 2015 RESULTS

[0001102624-15-000197:8k_2_02:6]
Net Revenues of $1.55 Billion; GAAP EPS of $0.56 and Non-GAAP EPS of $0.75

[0001102624-15-000197:8k_2_02:7]
| · | Clustered Data ONTAP® node shipments increased 160% year-over-year |

[0001102624-15-000197:8k_2_02:8]
| · | Introduced latest version of clustered Data ONTAP, the world’s #1 branded storage operating system1 |

[0001102624-15-000197:8k_2_02:9]
| · | Increased stock repurchase program by an additional $2.5 billion; first $1 billion of stock expected to be repurchased by the end of May 2016 |

[0001102624-15-000197:8k_2_02:10]
Sunnyvale, Calif.—February 11, 2015—NetApp (NASDAQ: NTAP) today reported financial results for the third quarter of fiscal year 2015, ended January 23, 2015.

[0001102624-15-000197:8k_2_02:11]
Third Quarter Financial Results

[0001102624-15-000197:8k_2_02:12]
Net revenues for the third quarter of fiscal year 2015 were $1.55 billion. GAAP net income for the third quarter of fiscal year 2015 was $177 million, or $0.56 per share,2 compared to GAAP net income of $192 million, or $0.55 per share, for the comparable period of the prior year. Non-GAAP net income for the third quarter of fiscal year 2015 was $238 million, or $0.75 per share,3 compared to non-GAAP net income of $261 million, or $0.75 per share, for the comparable period of the prior year.

[0001102624-15-000197:8k_2_02:13]
Cash, Cash Equivalents and Investments

[0001102624-15-000197:8k_2_02:14]
NetApp ended the third quarter of fiscal year 2015 with $5.25 billion of total cash, cash equivalents and investments and during the quarter generated $275 million in cash from operations. The Company returned $251 million to shareholders during the quarter through share repurchases and a cash dividend. The next dividend in the amount of $0.165 per share will be paid on April 23, 2015, to shareholders of record as of the close of business on April 10, 2015.

[0001102624-15-000197:8k_2_02:15]
“To position NetApp for success now, and in the future, we remain focused on extending our data fabric vision, a differentiated strategy for the hybrid cloud which allows customers to seamlessly manage their data regardless of where it’s stored,” said Tom Georgens, Chairman and CEO. “In the third quarter we continued to deliver against this vision, enhancing our strong product portfolio with new software, services and systems to help our customers to realize the value of the hybrid cloud.”

[0001102624-15-000197:8k_2_02:16]
Q4 Fiscal Year 2015 Outlook

[0001102624-15-000197:8k_2_02:17]
The Company provided the following financial guidance for the fourth quarter of fiscal year 2015:

[0001102624-15-000197:8k_2_02:18]
| · | Net revenues are expected to be in the range of $1.55 billion to $1.65 billion |

[0001102624-15-000197:8k_2_02:19]
| · | GAAP earnings per share is expected to be in the range of $0.46 to $0.51 per share |

[0001102624-15-000197:8k_2_02:20]
| · | Non-GAAP earnings per share is expected to be in the range of $0.70 to $0.75 per share |

[0001102624-15-000197:8k_2_02:21]
Business Highlights

[0001102624-15-000197:8k_2_02:22]
| · | NetApp Increased Stock Repurchase Program: |

[0001102624-15-000197:8k_2_02:23]
|  | - | NetApp increased its stock repurchase program, of which $206 million remained available, by an additional $2.5 billion. The Company plans to repurchase $206 million of its common stock by the end of May 2015. The additional $2.5 billion of repurchases is expected to be completed by the end of May 2018, with the first $1 billion expected to be completed by the end of May 2016. Under its stock repurchase program, NetApp may purchase shares of its outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by management. The timing and amount of repurchase transactions under the program will depend on market conditions, corporate business and financial considerations, and regulatory requirements. |

[0001102624-15-000197:8k_2_02:24]
| · | NetApp Expands Product Portfolio: |

[0001102624-15-000197:8k_2_02:25]
|  | - | Acquisition of Riverbed Technology’s SteelStore Product Line. NetApp purchased the SteelStore product to offer enterprises cloud-integrated storage to securely and efficiently back up data to both private and public cloud environments. |

[0001102624-15-000197:8k_2_02:26]
| · | NetApp Expands Hybrid Cloud Solutions in Support of Data Fabric Vision: |

[0001102624-15-000197:8k_2_02:27]
|  | - | Clustered Data ONTAP 8.3. Enhancements to the Company’s software-defined storage operating system help organizations of all sizes improve their levels of availability, performance and efficiency. New support for NetApp MetroCluster™ disaster recovery software provides enterprises with uninterrupted recovery from failures across data centers allowing critical business applications to continue to operate in the event of disasters or planned outages. |

[0001102624-15-000197:8k_2_02:28]
|  | - | Cloud ONTAP™. Built on clustered Data ONTAP 8.3, the first release of the Cloud ONTAP operating system combines the power of clustered Data ONTAP with the scale of Amazon Web Services (AWS), providing non-disruptive operations, seamless scalability and efficiency, combined with the on-demand computing benefits of cloud services. |

[0001102624-15-000197:8k_2_02:29]
|  | - | OnCommand® Cloud Manager. Efficient and easy provisioning of clustered Data ONTAP instances between private cloud and public cloud providers allows customers and partners to have seamless visibility into their hybrid cloud environments. |

[0001102624-15-000197:8k_2_02:30]
|  | - | NetApp Private Storage (NPS) for SoftLayer, an IBM Company. NPS for Cloud, which now includes SoftLayer, enables customers to use multiple clouds and maintain control of their data on a single NetApp data storage device strategically placed in select colocation facilities. |

[0001102624-15-000197:8k_2_02:31]
| · | NetApp Strengthens Partnerships: |

[0001102624-15-000197:8k_2_02:32]
|  | - | Deepens AWS Partnership. NetApp SteelStore virtual appliance and the NetApp Cloud ONTAP system, now available on AWS, extend enterprises’ existing on-premises data management and data protection operations to AWS. |

[0001102624-15-000197:8k_2_02:33]
|  | - | Further Strength in Hyperconverged Infrastructure. Powered by VMware EVO:RAIL and the NetApp Data ONTAP operating system, the NetApp Integrated EVO:RAIL solution allows customers to quickly deploy and manage virtualized business critical applications. |

[0001102624-15-000197:8k_2_02:34]
Webcast and Conference Call Information

[0001102624-15-000197:8k_2_02:35]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:30 p.m. Pacific Time today.

[0001102624-15-000197:8k_2_02:36]
About NetApp

[0001102624-15-000197:8k_2_02:37]
Leading organizations worldwide count on NetApp for software, systems and services to manage and store their data. Customers value our teamwork, expertise and passion for helping them succeed now and into the future.

[0001102624-15-000197:8k_2_02:38]
###

[0001102624-15-000197:8k_2_02:39]
NetApp, the NetApp logo, cloud ONTAP, clustered Data ONTAP, MetroCluster and OnCommand are trademarks or registered trademarks of NetApp, Inc. in the United States and/or other countries. All other marks are the property of their respective owners.

[0001102624-15-000197:8k_2_02:40]
1IDC Worldwide Quarterly Disk Storage Systems Tracker 2014 Q3, December 2014 (Open Networked Disk Storage Systems revenue)

[0001102624-15-000197:8k_2_02:41]
2GAAP earnings per share is calculated using the diluted number of shares for all periods presented.

[0001102624-15-000197:8k_2_02:42]
3Non-GAAP net income excludes, when applicable, the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Effective the first quarter of fiscal 2015, the non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-reoccurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) the impact of a temporary lapse of tax law, such as the federal research credit, if such extensions have routinely been granted based on past legislative history and are expected to be reinstated in the near future. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com.

[0001102624-15-000197:8k_2_02:43]
NetApp Usage of Non-GAAP Financials

[0001102624-15-000197:8k_2_02:44]
The Company refers to the non-GAAP financial measures in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes, when applicable, the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Effective the first quarter of fiscal 2015, the non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-reoccurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) the impact of a temporary lapse of tax law, such as the federal research credit, if such extensions have routinely been granted based on past legislative history and are expected to be reinstated in the near future. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods.

[0001102624-15-000197:8k_2_02:45]
We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has limitations and they should not solely be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we provide non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-15-000197:8k_2_02:46]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation.

[0001102624-15-000197:8k_2_02:47]
| NETAPP, INC. |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (In millions) |
| (Unaudited) |
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,252.5 |  |  | $ | 5,003.3 |  |
| Accounts receivable, net |  |  | 666.3 |  |  |  | 855.9 |  |
| Inventories |  |  | 117.8 |  |  |  | 122.4 |  |
| Other current assets |  |  | 518.0 |  |  |  | 489.7 |  |
| Total current assets |  |  | 6,554.6 |  |  |  | 6,471.3 |  |
| Property and equipment, net |  |  | 1,050.7 |  |  |  | 1,108.8 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,136.3 |  |  |  | 1,109.6 |  |
| Other non-current assets |  |  | 493.1 |  |  |  | 529.5 |  |
| Total assets |  | $ | 9,234.7 |  |  | $ | 9,219.2 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 194.2 |  |  | $ | 247.0 |  |
| Accrued compensation and other current liabilities |  |  | 617.7 |  |  |  | 793.8 |  |
| Short-term deferred revenue |  |  | 1,679.4 |  |  |  | 1,653.8 |  |
| Total current liabilities |  |  | 2,491.3 |  |  |  | 2,694.6 |  |
| Long-term debt |  |  | 1,494.7 |  |  |  | 995.5 |  |
| Other long-term liabilities |  |  | 310.4 |  |  |  | 296.2 |  |
| Long-term deferred revenue |  |  | 1,430.3 |  |  |  | 1,446.4 |  |
| Total liabilities |  |  | 5,726.7 |  |  |  | 5,432.7 |  |
| Stockholders' equity |  |  | 3,508.0 |  |  |  | 3,786.5 |  |
| Total liabilities and stockholders' equity |  | $ | 9,234.7 |  |  | $ | 9,219.2 |  |

[0001102624-15-000197:8k_2_02:48]
| NETAPP, INC. |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |
| (In millions, except per share amounts) |
| (Unaudited) |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 929.5 |  |  | $ | 1,015.0 |  |  | $ | 2,741.2 |  |  | $ | 2,901.1 |  |
| Software entitlements and maintenance |  |  | 226.6 |  |  |  | 227.0 |  |  |  | 672.1 |  |  |  | 687.3 |  |
| Service |  |  | 395.2 |  |  |  | 368.0 |  |  |  | 1,169.7 |  |  |  | 1,087.7 |  |
| Net revenues |  |  | 1,551.3 |  |  |  | 1,610.0 |  |  |  | 4,583.0 |  |  |  | 4,676.1 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 419.6 |  |  |  | 450.7 |  |  |  | 1,215.6 |  |  |  | 1,323.9 |  |
| Cost of software entitlements and maintenance |  |  | 9.4 |  |  |  | 7.7 |  |  |  | 26.2 |  |  |  | 22.7 |  |
| Cost of service |  |  | 144.9 |  |  |  | 149.3 |  |  |  | 443.2 |  |  |  | 452.4 |  |
| Total cost of revenues |  |  | 573.9 |  |  |  | 607.7 |  |  |  | 1,685.0 |  |  |  | 1,799.0 |  |
| Gross profit |  |  | 977.4 |  |  |  | 1,002.3 |  |  |  | 2,898.0 |  |  |  | 2,877.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 474.8 |  |  |  | 475.9 |  |  |  | 1,443.0 |  |  |  | 1,423.2 |  |
| Research and development |  |  | 229.9 |  |  |  | 230.3 |  |  |  | 686.9 |  |  |  | 686.6 |  |
| General and administrative |  |  | 70.2 |  |  |  | 69.4 |  |  |  | 213.2 |  |  |  | 207.3 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 49.5 |  |
| Total operating expenses |  |  | 774.9 |  |  |  | 775.6 |  |  |  | 2,343.1 |  |  |  | 2,366.6 |  |
| Income from operations |  |  | 202.5 |  |  |  | 226.7 |  |  |  | 554.9 |  |  |  | 510.5 |  |
| Other income/(expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 8.6 |  |  |  | 7.9 |  |  |  | 25.0 |  |  |  | 26.4 |  |
| Interest expense |  |  | (11.1 | ) |  |  | (6.7 | ) |  |  | (31.0 | ) |  |  | (29.7 | ) |
| Other income (expense), net |  |  | 0.1 |  |  |  | 1.7 |  |  |  | (0.2 | ) |  |  | 6.9 |  |
| Total other income/(expense), net |  |  | (2.4 | ) |  |  | 2.9 |  |  |  | (6.2 | ) |  |  | 3.6 |  |
| Income before income taxes |  |  | 200.1 |  |  |  | 229.6 |  |  |  | 548.7 |  |  |  | 514.1 |  |
| Provision for income taxes |  |  | 23.3 |  |  |  | 37.5 |  |  |  | 123.7 |  |  |  | 73.6 |  |
| Net income |  | $ | 176.8 |  |  | $ | 192.1 |  |  | $ | 425.0 |  |  | $ | 440.5 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.57 |  |  | $ | 0.57 |  |  | $ | 1.34 |  |  | $ | 1.28 |  |
| Diluted |  | $ | 0.56 |  |  | $ | 0.55 |  |  | $ | 1.31 |  |  | $ | 1.25 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 311.6 |  |  |  | 339.4 |  |  |  | 317.8 |  |  |  | 343.7 |  |
| Diluted |  |  | 317.1 |  |  |  | 346.2 |  |  |  | 323.3 |  |  |  | 351.7 |  |
| Cash dividends declared per share |  | $ | 0.165 |  |  | $ | 0.150 |  |  | $ | 0.495 |  |  | $ | 0.450 |  |

[0001102624-15-000197:8k_2_02:49]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 176.8 |  |  | $ | 192.1 |  |  | $ | 425.0 |  |  | $ | 440.5 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 79.5 |  |  |  | 83.6 |  |  |  | 234.6 |  |  |  | 252.0 |  |
| Stock-based compensation |  |  | 66.0 |  |  |  | 71.9 |  |  |  | 196.1 |  |  |  | 205.8 |  |
| Excess tax benefit from stock-based compensation |  |  | (4.4 | ) |  |  | (23.9 | ) |  |  | (53.8 | ) |  |  | (33.4 | ) |
| Other, net |  |  | (20.3 | ) |  |  | (6.3 | ) |  |  | 29.6 |  |  |  | (22.4 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (35.7 | ) |  |  | 4.1 |  |  |  | 186.7 |  |  |  | 213.4 |  |
| Inventories |  |  | (10.3 | ) |  |  | (2.3 | ) |  |  | 4.6 |  |  |  | 21.3 |  |
| Accounts payable |  |  | (13.8 | ) |  |  | (29.0 | ) |  |  | (45.9 | ) |  |  | (69.8 | ) |
| Accrued compensation and other current liabilities |  |  | (25.6 | ) |  |  | 7.9 |  |  |  | (162.1 | ) |  |  | (94.5 | ) |
| Deferred revenue |  |  | 79.2 |  |  |  | 40.6 |  |  |  | 34.4 |  |  |  | (27.0 | ) |
| Changes in other operating assets and liabilities, net |  |  | (16.8 | ) |  |  | (6.9 | ) |  |  | 22.3 |  |  |  | 94.2 |  |
| Net cash provided by operating activities |  |  | 274.6 |  |  |  | 331.8 |  |  |  | 871.5 |  |  |  | 980.1 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | (319.5 | ) |  |  | 90.6 |  |  |  | 41.6 |  |  |  | 762.7 |  |
| Purchases of property and equipment |  |  | (28.6 | ) |  |  | (57.9 | ) |  |  | (138.1 | ) |  |  | (165.4 | ) |
| Acquisitions of businesses |  |  | (84.6 | ) |  |  | - |  |  |  | (84.6 | ) |  |  | - |  |
| Other investing activities, net |  |  | 3.4 |  |  |  | (0.8 | ) |  |  | 2.5 |  |  |  | 2.6 |  |
| Net cash provided by (used in) investing activities |  |  | (429.3 | ) |  |  | 31.9 |  |  |  | (178.6 | ) |  |  | 599.9 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 74.4 |  |  |  | 67.9 |  |  |  | 145.6 |  |  |  | 191.8 |  |
| Repurchase of common stock and forward contract |  |  | (200.0 | ) |  |  | (507.0 | ) |  |  | (918.9 | ) |  |  | (1,507.0 | ) |
| Excess tax benefit from stock-based compensation |  |  | 4.4 |  |  |  | 23.9 |  |  |  | 53.8 |  |  |  | 33.4 |  |
| Repayment of debt |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (1,264.9 | ) |
| Issuance of long-term debt, net |  |  | - |  |  |  | - |  |  |  | 494.7 |  |  |  | - |  |
| Dividends paid |  |  | (51.4 | ) |  |  | (50.4 | ) |  |  | (156.9 | ) |  |  | (153.1 | ) |
| Other financing activities, net |  |  | (4.1 | ) |  |  | (1.8 | ) |  |  | (7.6 | ) |  |  | (7.5 | ) |
| Net cash used in financing activities |  |  | (176.7 | ) |  |  | (467.4 | ) |  |  | (389.3 | ) |  |  | (2,707.3 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (34.1 | ) |  |  | (4.1 | ) |  |  | (54.9 | ) |  |  | 2.9 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | (365.5 | ) |  |  | (107.8 | ) |  |  | 248.7 |  |  |  | (1,124.4 | ) |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,905.2 |  |  |  | 2,260.5 |  |  |  | 2,291.0 |  |  |  | 3,277.1 |  |
| End of period |  | $ | 2,539.7 |  |  | $ | 2,152.7 |  |  | $ | 2,539.7 |  |  | $ | 2,152.7 |  |

[0001102624-15-000197:8k_2_02:50]
| NETAPP, INC. |
| SUPPLEMENTAL DATA |
| (In millions except net income per share, percentages, DSO and Inventory Turns) |
| (Unaudited) |
|  |  | Q3 FY’15 |  |  | Q2 FY’15 |  |  | Q3 FY’14 |
| Revenues |  |  |  |  |  |  |  |  |  |
| Product Revenue |  | $ | 929.5 |  |  | $ | 929.1 |  |  | $ | 1,015.0 |  |
| Software Entitlements & Maintenance Revenue (SEM) |  |  | 226.6 |  |  |  | 224.2 |  |  |  | 227.0 |  |
| Service Revenue: |  |  | 395.2 |  |  |  | 389.2 |  |  |  | 368.0 |  |
| Hardware Maintenance Support Contracts Revenue |  |  | 315.6 |  |  |  | 311.0 |  |  |  | 285.9 |  |
| Professional & Other Services Revenue |  |  | 79.6 |  |  |  | 78.2 |  |  |  | 82.1 |  |
| Net Revenues |  | $ | 1,551.3 |  |  | $ | 1,542.5 |  |  | $ | 1,610.0 |  |
| Branded and OEM Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY’15 |  |  | Q2 FY’15 |  |  | Q3 FY’14 |
| Branded Revenue |  | $ | 1,427.5 |  |  | $ | 1,423.9 |  |  | $ | 1,452.7 |  |
| OEM Revenue |  |  | 123.8 |  |  |  | 118.6 |  |  |  | 157.3 |  |
| Net Revenues |  | $ | 1,551.3 |  |  | $ | 1,542.5 |  |  | $ | 1,610.0 |  |
| Branded revenue includes revenue from all products and services sold directly by us or our partners under the NetApp brand, including NetApp branded E-Series products and solutions. |
| OEM revenue comprises revenue from the sale of our products by other companies under their brands and includes revenue from IBM, Fujitsu, and other E-Series OEM relationships. |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'15 Revenue |  |  | % of Q2 FY'15 Revenue |  |  | % of Q3 FY’14 Revenue |
| Americas |  |  | 54 | % |  |  | 59 | % |  |  | 52 | % |
| Americas Commercial |  |  | 44 | % |  |  | 42 | % |  |  | 43 | % |
| U.S. Public Sector |  |  | 10 | % |  |  | 17 | % |  |  | 9 | % |
| EMEA |  |  | 33 | % |  |  | 28 | % |  |  | 34 | % |
| Asia Pacific |  |  | 13 | % |  |  | 13 | % |  |  | 14 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'15 Revenue |  |  | % of Q2 FY'15 Revenue |  |  | % of Q3 FY’14 Revenue |
| Direct |  |  | 19 | % |  |  | 20 | % |  |  | 17 | % |
| Indirect |  |  | 81 | % |  |  | 80 | % |  |  | 83 | % |
| Direct revenues are those sold through our direct sales force. Indirect revenues include those sold through value-added resellers, system integrators, OEMs and distributors. |
| Indirect revenue reflects order fulfillment and is not reflective of who is responsible for the customer relationship. |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY’15 |  |  | Q2 FY’15 |  |  | Q3 FY’14 |
| Non-GAAP Gross Margin |  |  | 64.6 | % |  |  | 65.0 | % |  |  | 63.5 | % |
| Product |  |  | 57.0 | % |  |  | 58.4 | % |  |  | 57.1 | % |
| Software Entitlements & Maintenance (SEM) |  |  | 95.9 | % |  |  | 96.2 | % |  |  | 96.6 | % |
| Service |  |  | 64.5 | % |  |  | 62.7 | % |  |  | 60.8 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |
|  |  | Q3 FY’15 |  |  | Q2 FY’15 |  |  | Q3 FY’14 |
| Non-GAAP Income from Operations |  | $ | 287.7 |  |  | $ | 274.8 |  |  | $ | 313.3 |  |
| % of Net Revenues |  |  | 18.5 | % |  |  | 17.8 | % |  |  | 19.5 | % |
| Non-GAAP Income before Income Taxes |  | $ | 285.3 |  |  | $ | 271.2 |  |  | $ | 316.2 |  |
| Non-GAAP Effective Tax Rate |  |  | 16.5 | % |  |  | 16.5 | % |  |  | 17.6 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY’15 |  |  | Q2 FY’15 |  |  | Q3 FY’14 |
| Non-GAAP Net Income |  | $ | 238.3 |  |  | $ | 226.4 |  |  | $ | 260.6 |  |
| Weighted Average Common Shares Outstanding, Diluted |  |  | 317.1 |  |  |  | 323.5 |  |  |  | 346.2 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 0.75 |  |  | $ | 0.70 |  |  | $ | 0.75 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY’15 |  |  | Q2 FY’15 |  |  | Q3 FY’14 |
| Deferred Revenue |  | $ | 3,109.7 |  |  | $ | 3,047.0 |  |  | $ | 2,959.3 |  |
| DSO (days) |  |  | 39 |  |  |  | 37 |  |  |  | 33 |  |
| Inventory Turns |  |  | 19 |  |  |  | 20 |  |  |  | 20 |  |
| Days sales outstanding (DSO) is defined as accounts receivable, net divided by net revenues, multiplied by the number of days in the quarter. |
| Inventory turns is defined as annualized non-GAAP cost of revenues divided by net inventories. |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY’15 |  |  | Q2 FY’15 |  |  | Q3 FY’14 |
| Net Cash Provided by Operating Activities |  | $ | 274.6 |  |  | $ | 381.4 |  |  | $ | 331.8 |  |
| Purchases of Property and Equipment |  | $ | 28.6 |  |  | $ | 51.1 |  |  | $ | 57.9 |  |
| Free Cash Flow |  | $ | 246.0 |  |  | $ | 330.3 |  |  | $ | 273.9 |  |
| Free Cash Flow as % of Net Revenues |  |  | 15.9 | % |  |  | 21.4 | % |  |  | 17.0 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |
| Some items may not add or recalculate due to rounding. |  |

[0001102624-15-000197:8k_2_02:51]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP TO GAAP |
| INCOME STATEMENT INFORMATION |
| (In millions, except net income per share amounts) |
|  |  | Q3'FY15 |  |  | Q2'FY15 |  |  | Q3'FY14 |  |
| NET INCOME |  | $ | 176.8 |  |  | $ | 159.8 |  |  | $ | 192.1 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 19.2 |  |  |  | 14.5 |  |  |  | 14.7 |  |
| Stock-based compensation |  |  | 66.0 |  |  |  | 67.8 |  |  |  | 71.9 |  |
| Income tax effect of non-GAAP adjustments |  |  | (23.7 | ) |  |  | (15.7 | ) |  |  | (18.1 | ) |
| NON-GAAP NET INCOME |  | $ | 238.3 |  |  | $ | 226.4 |  |  | $ | 260.6 |  |
| COST OF REVENUES |  | $ | 573.9 |  |  | $ | 560.0 |  |  | $ | 607.7 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (18.9 | ) |  |  | (14.2 | ) |  |  | (14.2 | ) |
| Stock-based compensation |  |  | (5.4 | ) |  |  | (5.6 | ) |  |  | (6.1 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 549.6 |  |  | $ | 540.2 |  |  | $ | 587.4 |  |
| COST OF PRODUCT REVENUES |  | $ | 419.6 |  |  | $ | 401.8 |  |  | $ | 450.7 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (18.3 | ) |  |  | (13.7 | ) |  |  | (13.6 | ) |
| Stock-based compensation |  |  | (1.4 | ) |  |  | (1.6 | ) |  |  | (1.5 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 399.9 |  |  | $ | 386.5 |  |  | $ | 435.6 |  |
| COST OF SERVICE REVENUES |  | $ | 144.9 |  |  | $ | 149.6 |  |  | $ | 149.3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.6 | ) |  |  | (0.5 | ) |  |  | (0.6 | ) |
| Stock-based compensation |  |  | (4.0 | ) |  |  | (4.0 | ) |  |  | (4.6 | ) |
| NON-GAAP COST OF SERVICE REVENUES |  | $ | 140.3 |  |  | $ | 145.1 |  |  | $ | 144.1 |  |
| GROSS PROFIT |  | $ | 977.4 |  |  | $ | 982.5 |  |  | $ | 1,002.3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 18.9 |  |  |  | 14.2 |  |  |  | 14.2 |  |
| Stock-based compensation |  |  | 5.4 |  |  |  | 5.6 |  |  |  | 6.1 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,001.7 |  |  | $ | 1,002.3 |  |  | $ | 1,022.6 |  |
| SALES AND MARKETING EXPENSES |  | $ | 474.8 |  |  | $ | 488.0 |  |  | $ | 475.9 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (0.5 | ) |
| Stock-based compensation |  |  | (29.6 | ) |  |  | (30.4 | ) |  |  | (33.0 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 444.9 |  |  | $ | 457.3 |  |  | $ | 442.4 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 229.9 |  |  | $ | 229.0 |  |  | $ | 230.3 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (21.9 | ) |  |  | (21.2 | ) |  |  | (23.6 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 208.0 |  |  | $ | 207.8 |  |  | $ | 206.7 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 70.2 |  |  | $ | 73.0 |  |  | $ | 69.4 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (9.1 | ) |  |  | (10.6 | ) |  |  | (9.2 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 61.1 |  |  | $ | 62.4 |  |  | $ | 60.2 |  |

[0001102624-15-000197:8k_2_02:52]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP TO GAAP |
| INCOME STATEMENT INFORMATION |
| (In millions, except net income per share amounts) |
|  |  | Q3'FY15 |  |  | Q2'FY15 |  |  | Q3'FY14 |  |
| OPERATING EXPENSES |  | $ | 774.9 |  |  | $ | 790.0 |  |  | $ | 775.6 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (0.5 | ) |
| Stock-based compensation |  |  | (60.6 | ) |  |  | (62.2 | ) |  |  | (65.8 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 714.0 |  |  | $ | 727.5 |  |  | $ | 709.3 |  |
| INCOME FROM OPERATIONS |  | $ | 202.5 |  |  | $ | 192.5 |  |  | $ | 226.7 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 19.2 |  |  |  | 14.5 |  |  |  | 14.7 |  |
| Stock-based compensation |  |  | 66.0 |  |  |  | 67.8 |  |  |  | 71.9 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 287.7 |  |  | $ | 274.8 |  |  | $ | 313.3 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 200.1 |  |  | $ | 188.9 |  |  | $ | 229.6 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 19.2 |  |  |  | 14.5 |  |  |  | 14.7 |  |
| Stock-based compensation |  |  | 66.0 |  |  |  | 67.8 |  |  |  | 71.9 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 285.3 |  |  | $ | 271.2 |  |  | $ | 316.2 |  |
| PROVISION FOR INCOME TAXES |  | $ | 23.3 |  |  | $ | 29.1 |  |  | $ | 37.5 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | 23.7 |  |  |  | 15.7 |  |  |  | 18.1 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 47.0 |  |  | $ | 44.8 |  |  | $ | 55.6 |  |
| NET INCOME PER SHARE |  | $ | 0.56 |  |  | $ | 0.49 |  |  | $ | 0.55 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.06 |  |  |  | 0.04 |  |  |  | 0.04 |  |
| Stock-based compensation |  |  | 0.21 |  |  |  | 0.21 |  |  |  | 0.21 |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.07 | ) |  |  | (0.05 | ) |  |  | (0.05 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.75 |  |  | $ | 0.70 |  |  | $ | 0.75 |  |

[0001102624-15-000197:8k_2_02:53]
| RECONCILIATION OF NON-GAAP TO GAAP |
| GROSS MARGIN |
| ($ in millions) |
|  |  | Q3'FY15 |  |  | Q2'FY15 |  |  | Q3'FY14 |  |
| Gross margin-GAAP |  |  | 63.0 | % |  |  | 63.7 | % |  |  | 62.3 | % |
| Cost of revenues adjustments |  |  | 1.6 | % |  |  | 1.3 | % |  |  | 1.3 | % |
| Gross margin-Non-GAAP |  |  | 64.6 | % |  |  | 65.0 | % |  |  | 63.5 | % |
| GAAP cost of revenues |  | $ | 573.9 |  |  | $ | 560.0 |  |  | $ | 607.7 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (18.9 | ) |  |  | (14.2 | ) |  |  | (14.2 | ) |
| Stock-based compensation |  |  | (5.4 | ) |  |  | (5.6 | ) |  |  | (6.1 | ) |
| Non-GAAP cost of revenues |  | $ | 549.6 |  |  | $ | 540.2 |  |  | $ | 587.4 |  |
| Net revenues |  | $ | 1,551.3 |  |  | $ | 1,542.5 |  |  | $ | 1,610.0 |  |

[0001102624-15-000197:8k_2_02:54]
| RECONCILIATION OF NON-GAAP TO GAAP |
| PRODUCT GROSS MARGIN |
| ($ in millions) |
|  |  | Q3'FY15 |  |  | Q2'FY15 |  |  | Q3'FY14 |  |
| Product gross margin-GAAP |  |  | 54.9 | % |  |  | 56.8 | % |  |  | 55.6 | % |
| Cost of product revenues adjustments |  |  | 2.1 | % |  |  | 1.6 | % |  |  | 1.5 | % |
| Product gross margin-Non-GAAP |  |  | 57.0 | % |  |  | 58.4 | % |  |  | 57.1 | % |
| GAAP cost of product revenues |  | $ | 419.6 |  |  | $ | 401.8 |  |  | $ | 450.7 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (18.3 | ) |  |  | (13.7 | ) |  |  | (13.6 | ) |
| Stock-based compensation |  |  | (1.4 | ) |  |  | (1.6 | ) |  |  | (1.5 | ) |
| Non-GAAP cost of product revenues |  | $ | 399.9 |  |  | $ | 386.5 |  |  | $ | 435.6 |  |
| Product revenues |  | $ | 929.5 |  |  | $ | 929.1 |  |  | $ | 1,015.0 |  |

[0001102624-15-000197:8k_2_02:55]
| RECONCILIATION OF NON-GAAP TO GAAP |
| SERVICES GROSS MARGIN |
| ($ in millions) |
|  |  | Q3'FY15 |  |  | Q2'FY15 |  |  | Q3'FY14 |  |
| Services gross margin-GAAP |  |  | 63.3 | % |  |  | 61.6 | % |  |  | 59.4 | % |
| Cost of service revenues adjustments |  |  | 1.2 | % |  |  | 1.2 | % |  |  | 1.4 | % |
| Services gross margin-Non-GAAP |  |  | 64.5 | % |  |  | 62.7 | % |  |  | 60.8 | % |
| GAAP cost of service revenues |  | $ | 144.9 |  |  | $ | 149.6 |  |  | $ | 149.3 |  |
| Cost of service revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.6 | ) |  |  | (0.5 | ) |  |  | (0.6 | ) |
| Stock-based compensation |  |  | (4.0 | ) |  |  | (4.0 | ) |  |  | (4.6 | ) |
| Non-GAAP cost of service revenues |  | $ | 140.3 |  |  | $ | 145.1 |  |  | $ | 144.1 |  |
| Service revenues |  | $ | 395.2 |  |  | $ | 389.2 |  |  | $ | 368.0 |  |

[0001102624-15-000197:8k_2_02:56]
| RECONCILIATION OF NON-GAAP TO GAAP |
| EFFECTIVE TAX RATE |  |
|  |  | Q3'FY15 |  |  | Q2'FY15 |  |  | Q3'FY14 |  |
| GAAP effective tax rate |  |  | 11.6 | % |  |  | 15.4 | % |  |  | 16.3 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | 4.9 | % |  |  | 1.1 | % |  |  | 1.3 | % |
| Non-GAAP effective tax rate |  |  | 16.5 | % |  |  | 16.5 | % |  |  | 17.6 | % |

[0001102624-15-000197:8k_2_02:57]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |
| TO FREE CASH FLOW (NON-GAAP) |
| (In millions) |
|  |  | Q3'FY15 |  |  | Q2'FY15 |  |  | Q3'FY14 |  |
| Net cash provided by operating activities |  | $ | 274.6 |  |  | $ | 381.4 |  |  | $ | 331.8 |  |
| Purchases of property and equipment |  |  | (28.6 | ) |  |  | (51.1 | ) |  |  | (57.9 | ) |
| Free cash flow |  | $ | 246.0 |  |  | $ | 330.3 |  |  | $ | 273.9 |  |

[0001102624-15-000197:8k_2_02:58]
| INVENTORY TURNS AND RECONCILIATION OF NON-GAAP TO GAAP |
| COST OF REVENUES USED IN INVENTORY TURNS |
| (In millions, except annualized inventory turns) |  |
|  |  | Q3'FY15 |  |  | Q2'FY15 |  |  | Q3'FY14 |  |
| Annualized inventory turns- GAAP |  |  | 19 |  |  |  | 21 |  |  |  | 21 |  |
| Cost of revenues adjustments |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Annualized inventory turns-Non-GAAP |  |  | 19 |  |  |  | 20 |  |  |  | 20 |  |
| GAAP cost of revenues |  | $ | 573.9 |  |  | $ | 560.0 |  |  | $ | 607.7 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (18.9 | ) |  |  | (14.2 | ) |  |  | (14.2 | ) |
| Stock-based compensation |  |  | (5.4 | ) |  |  | (5.6 | ) |  |  | (6.1 | ) |
| Non-GAAP cost of revenues |  | $ | 549.6 |  |  | $ | 540.2 |  |  | $ | 587.4 |  |
| Inventory |  | $ | 117.8 |  |  | $ | 107.6 |  |  | $ | 118.2 |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |

[0001102624-15-000197:8k_2_02:59]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FOURTH QUARTER FISCAL 2015 |
|  | Fourth Quarter |
|  | Fiscal 2015 |
| Non-GAAP Guidance - Net Income Per Share | $0.70 - $0.75 |
| Adjustments of Specific Items to |  |
| Net Income Per Share for the Fourth |  |
| Quarter Fiscal 2015: |  |
| Amortization of intangible assets | (0.05) |
| Stock-based compensation expense | (0.20) |
| Income tax effect of non-GAAP adjustments | 0.01 |
| Total Adjustments | (0.24) |
| GAAP Guidance - Net Income Per Share | $0.46 - $0.51 |
