# NTAP MD&A — 0000950170-23-005545


## mdna

[0000950170-23-005545:mdna:1]
[same as prior period, unchanged from 0000950170-22-025960:mdna:1]

[0000950170-23-005545:mdna:2]
27

[0000950170-23-005545:mdna:3]
[same as prior period, unchanged from 0000950170-22-025960:mdna:2]

[0000950170-23-005545:mdna:4]
[same as prior period, unchanged from 0000950170-22-025960:mdna:3]

[0000950170-23-005545:mdna:5]
NetApp is a global cloud-led, data-centric software company that gives organizations the freedom to put data to work in the applications that elevate their business. We help our customers get the most out of their data with industry-leading public cloud services, and hybrid cloud solutions. Building on more than three decades of innovation, we give customers the freedom to manage applications and data across hybrid multicloud environments. We envision a better IT experience – an evolved cloud state where on-premises and cloud environments are united, always delivering simplicity, security, savings, and sustainability. To that end, we build solutions that drive faster innovation wherever a customer’s data and applications are located, with unified management and AI-driven optimization.

[0000950170-23-005545:mdna:6]
[same as prior period, unchanged from 0000950170-22-025960:mdna:5]

[0000950170-23-005545:mdna:7]
[same as prior period, unchanged from 0000950170-22-025960:mdna:6]

[0000950170-23-005545:mdna:8]
[same as prior period, unchanged from 0000950170-22-025960:mdna:7]

[0000950170-23-005545:mdna:9]
[same as prior period, unchanged from 0000950170-22-025960:mdna:8]

[0000950170-23-005545:mdna:10]
[same as prior period, unchanged from 0000950170-22-025960:mdna:9]

[0000950170-23-005545:mdna:11]
Continuing global economic uncertainty, political conditions and fiscal challenges in the U.S. and abroad have resulted, and could continue to result in adverse macroeconomic conditions, including inflation, rising interest rates, foreign exchange volatility, slower growth or recession. In particular, during the first nine months of fiscal 2023, we continued to experience inflationary pressure, constraints in our supply chain and foreign exchange volatility. We also observed a slowdown in customer demand during the second and third quarters of fiscal 2023 as a result of continuing global economic uncertainty.

[0000950170-23-005545:mdna:12]
Supply chain constraints, which substantially began to impact us in the second half of fiscal 2022, and have eased in the second half of fiscal 2023, led to higher product component and freight costs in the first nine months of fiscal 2023 than incurred in the first nine months of fiscal 2022. Supply chain constraints also delayed our ability to fulfill certain customer orders during the first six months of fiscal 2023.

[0000950170-23-005545:mdna:13]
If these macroeconomic uncertainties or supply chain challenges persist or worsen for the remainder of fiscal 2023, we may continue to observe reduced customer demand for our offerings, increased competition for critical components, challenges fulfilling certain customer orders or continued increases in component and freight costs, any of which could impact our operating results.

[0000950170-23-005545:mdna:14]
[same as prior period, unchanged from 0000950170-22-025960:mdna:13]

[0000950170-23-005545:mdna:15]
[same as prior period, unchanged from 0000950170-22-025960:mdna:14]

[0000950170-23-005545:mdna:16]
[same as prior period, unchanged from 0000950170-22-025960:mdna:15]

[0000950170-23-005545:mdna:17]
Beginning in February 2022, in response to Russian military actions in Ukraine, the U.S. and other countries imposed sanctions on Russia, and we suspended business operations, including sales, support on existing contracts and professional services, in Russia and Belarus. In the second quarter of fiscal 2023, we discontinued business operations in Russia, Belarus, and certain regions of Ukraine. The impact of these actions was not significant to our results in either the third quarter or first nine months of fiscal 2023.

[0000950170-23-005545:mdna:18]
[same as prior period, unchanged from 0000950170-22-025960:mdna:17]

[0000950170-23-005545:mdna:19]
[same as prior period, unchanged from 0000950170-22-025960:mdna:18]

[0000950170-23-005545:mdna:20]
During the first nine months of fiscal 2023, we repurchased approximately 10 million shares of our common stock at an average price of $66.93 per share, for an aggregate of $700 million. We also declared aggregate cash dividends of $1.50 per share in that period, for which we paid $326 million.

[0000950170-23-005545:mdna:21]
[same as prior period, unchanged from 0000950170-22-025960:mdna:21]

[0000950170-23-005545:mdna:22]
In the third quarter of fiscal 2023 management approved a restructuring plan to redirect resources to highest return activities and reduce costs, which will reduce our global workforce by approximately 8%. Activities under this plan are expected to substantially complete by the end of fiscal 2023. Aggregate charges recorded from restructuring plans in the third quarter and first nine months of fiscal 2023 totaled $87 million and $109 million, respectively, and consisted primarily of employee severance-related costs.

[0000950170-23-005545:mdna:23]
[same as prior period, unchanged from 0000950170-22-025960:mdna:24]

[0000950170-23-005545:mdna:24]
[same as prior period, unchanged from 0000950170-22-025960:mdna:25]

[0000950170-23-005545:mdna:25]
[same as prior period, unchanged from 0000950170-22-025960:mdna:26]

[0000950170-23-005545:mdna:26]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | January 27, 2023 |  |  | January 28, 2022 |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 45 | % |  |  | 52 | % |  |  | 48 | % |  |  | 52 | % |  |
| Services |  |  | 55 |  |  |  | 48 |  |  |  | 52 |  |  |  | 48 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 24 |  |  |  | 25 |  |  |  | 25 |  |  |  | 24 |  |  |
| Cost of services |  |  | 10 |  |  |  | 8 |  |  |  | 10 |  |  |  | 9 |  |  |
| Gross profit |  |  | 66 |  |  |  | 66 |  |  |  | 66 |  |  |  | 68 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 29 |  |  |  | 29 |  |  |  | 29 |  |  |  | 30 |  |  |
| Research and development |  |  | 15 |  |  |  | 14 |  |  |  | 15 |  |  |  | 14 |  |  |
| General and administrative |  |  | 4 |  |  |  | 4 |  |  |  | 4 |  |  |  | 4 |  |  |
| Restructuring charges |  |  | 6 |  |  |  | — |  |  |  | 2 |  |  |  | 1 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Total operating expenses |  |  | 54 |  |  |  | 47 |  |  |  | 51 |  |  |  | 49 |  |  |
| Income from operations |  |  | 11 |  |  |  | 20 |  |  |  | 15 |  |  |  | 19 |  |  |
| Other income (expense), net |  |  | — |  |  |  | (1 | ) |  |  | 1 |  |  |  | (1 | ) |  |
| Income before income taxes |  |  | 12 |  |  |  | 19 |  |  |  | 16 |  |  |  | 18 |  |  |
| Provision (benefit) for income taxes |  |  | 7 |  |  |  | 3 |  |  |  | (6 | ) |  |  | 3 |  |  |
| Net income |  |  | 4 | % |  |  | 16 | % |  |  | 22 | % |  |  | 15 | % |  |

[0000950170-23-005545:mdna:27]
[same as prior period, unchanged from 0000950170-22-025960:mdna:28]

[0000950170-23-005545:mdna:28]
[same as prior period, unchanged from 0000950170-22-025960:mdna:29]

[0000950170-23-005545:mdna:29]
[same as prior period, unchanged from 0000950170-22-025960:mdna:30]

[0000950170-23-005545:mdna:30]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |
| Net revenues |  | $ | 1,526 |  |  | $ | 1,614 |  |  |  | (5 | )% |  | $ | 4,781 |  |  | $ | 4,638 |  |  |  | 3 | % |

[0000950170-23-005545:mdna:31]
The decrease in net revenues for the third quarter of fiscal 2023 compared to the corresponding period of fiscal 2022 was primarily due to a decrease in product revenues, partially offset by an increase in services revenues. The increase in net revenues for the first nine months of fiscal 2023 compared to the corresponding period of fiscal 2022 was primarily due to an increase in services revenues, partially offset by a decrease in product revenues. Product revenues as a percentage of net revenues decreased by eight percentage points and three percentage points in the third quarter and first nine months of fiscal 2023, respectively, compared to the corresponding periods of fiscal 2022. Fluctuations in foreign currency exchange rates adversely impacted net revenues percent growth by three percentage points and four percentage points in the third quarter and first nine months of fiscal 2023, respectively, compared to the corresponding periods of fiscal 2022.

[0000950170-23-005545:mdna:32]
[same as prior period, unchanged from 0000950170-22-025960:mdna:33]

[0000950170-23-005545:mdna:33]
[same as prior period, unchanged from 0000950170-22-025960:mdna:34]

[0000950170-23-005545:mdna:34]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |
| Product revenues |  | $ | 682 |  |  | $ | 846 |  |  |  | (19 | )% |  | $ | 2,305 |  |  | $ | 2,390 |  |  |  | (4 | )% |
| Hardware (Non-GAAP) |  |  | 292 |  |  |  | 338 |  |  |  | (14 | )% |  |  | 945 |  |  |  | 993 |  |  |  | (5 | )% |
| Software (Non-GAAP) |  |  | 390 |  |  |  | 508 |  |  |  | (23 | )% |  |  | 1,360 |  |  |  | 1,397 |  |  |  | (3 | )% |

[0000950170-23-005545:mdna:35]
[same as prior period, unchanged from 0000950170-22-025960:mdna:36]

[0000950170-23-005545:mdna:36]
[same as prior period, unchanged from 0000950170-22-025960:mdna:37]

[0000950170-23-005545:mdna:37]
[same as prior period, unchanged from 0000950170-22-025960:mdna:38]

[0000950170-23-005545:mdna:38]
Total product revenues decreased in the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of the prior year primarily due to lower sales of all flash array systems, as a result of softening customer demand. Product revenues were also unfavorably impacted by foreign exchange rate fluctuations.

[0000950170-23-005545:mdna:39]
Revenues from the hardware component of product revenues represented 43% and 41% of product revenues in the third quarter and first nine months of fiscal 2023, compared to 40% and 42% of product revenues in the corresponding periods of the prior year. The software component of product revenues represented 57% and 59% of product revenues in the third quarter and first nine months of fiscal 2023, compared to 60% and 58% of product revenues in the corresponding periods of the prior year. The decrease in the software component percentage of product revenues in the third quarter of fiscal 2023 was primarily due to the mix of systems sold.

[0000950170-23-005545:mdna:40]
[same as prior period, unchanged from 0000950170-22-025960:mdna:41]

[0000950170-23-005545:mdna:41]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |
| Services revenues |  | $ | 844 |  |  | $ | 768 |  |  |  | 10 | % |  | $ | 2,476 |  |  | $ | 2,248 |  |  |  | 10 | % |
| Support |  |  | 616 |  |  |  | 586 |  |  |  | 5 | % |  |  | 1,821 |  |  |  | 1,754 |  |  |  | 4 | % |
| Professional and other services |  |  | 78 |  |  |  | 72 |  |  |  | 8 | % |  |  | 231 |  |  |  | 218 |  |  |  | 6 | % |
| Public cloud |  |  | 150 |  |  |  | 110 |  |  |  | 36 | % |  |  | 424 |  |  |  | 276 |  |  |  | 54 | % |

[0000950170-23-005545:mdna:42]
[same as prior period, unchanged from 0000950170-22-025960:mdna:43]

[0000950170-23-005545:mdna:43]
[same as prior period, unchanged from 0000950170-22-025960:mdna:44]

[0000950170-23-005545:mdna:44]
Support revenues increased in the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of the prior year as a result of a higher aggregate support contract value for our installed based, primarily due to a higher mix of all-flash systems (which carry a higher support dollar content than our other products). This increase was partially offset by an unfavorable impact from foreign exchange rate fluctuations.

[0000950170-23-005545:mdna:45]
Professional and other services revenues increased slightly in the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of the prior year.

[0000950170-23-005545:mdna:46]
[same as prior period, unchanged from 0000950170-22-025960:mdna:47]

[0000950170-23-005545:mdna:47]
[same as prior period, unchanged from 0000950170-22-025960:mdna:48]

[0000950170-23-005545:mdna:48]
[same as prior period, unchanged from 0000950170-22-025960:mdna:49]

[0000950170-23-005545:mdna:49]
Public Cloud revenues increased in the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of the prior year primarily due to customer demand for NetApp’s diversified cloud offerings, coupled with overall growth in the cloud market and the acquisition of Instaclustr early in the first quarter of fiscal 2023. Revenues in the first nine months of fiscal 2023 also benefitted from the acquisition of CloudCheckr in the third quarter of fiscal 2022.

[0000950170-23-005545:mdna:50]
[same as prior period, unchanged from 0000950170-22-025960:mdna:51]

[0000950170-23-005545:mdna:51]
[same as prior period, unchanged from 0000950170-22-025960:mdna:52]

[0000950170-23-005545:mdna:52]
[same as prior period, unchanged from 0000950170-22-025960:mdna:53]

[0000950170-23-005545:mdna:53]
[same as prior period, unchanged from 0000950170-22-025960:mdna:54]

[0000950170-23-005545:mdna:54]
[same as prior period, unchanged from 0000950170-22-025960:mdna:55]

[0000950170-23-005545:mdna:55]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |
| Cost of product revenues |  | $ | 367 |  |  | $ | 407 |  |  |  | (10 | )% |  | $ | 1,182 |  |  | $ | 1,108 |  |  |  | 7 | % |
| Hybrid Cloud |  |  | 365 |  |  |  | 404 |  |  |  | (10 | )% |  |  | 1,177 |  |  |  | 1,099 |  |  |  | 7 | % |
| Unallocated |  |  | 2 |  |  |  | 3 |  |  |  | (33 | )% |  |  | 5 |  |  |  | 9 |  |  |  | (44 | )% |

[0000950170-23-005545:mdna:56]
[same as prior period, unchanged from 0000950170-22-025960:mdna:57]

[0000950170-23-005545:mdna:57]
Cost of Hybrid Cloud product revenues represented approximately 54% and 51% of product revenues for the third quarter and first nine months of fiscal 2023 compared to 48% and 46% for the corresponding periods of fiscal 2022. Materials costs represented 94% of cost of Hybrid Cloud product revenues for each of the third quarter and first nine months of fiscal 2023, respectively, compared to 94% and 92% for the corresponding periods of fiscal 2022.

[0000950170-23-005545:mdna:58]
Materials costs decreased by approximately $29 million in the third quarter of fiscal 2023 compared to the corresponding period of the prior year, reflecting the decrease in product revenues. Material costs increased by approximately $95 million in the first nine months of fiscal 2023 compared to the corresponding period of the prior year, reflecting the higher component and freight costs as a result of COVID-19 related supply chain challenges, partially offset by the decrease in product revenues.

[0000950170-23-005545:mdna:59]
Hybrid Cloud product gross margins decreased by approximately six percentage points and five percentage points in the third quarter and first nine months of fiscal 2023, respectively, compared to the corresponding periods of the prior year, primarily due to the  mix of products sold and the adverse impacts of fluctuations in foreign currency exchange rates on product revenues. For the first nine months of fiscal 2023, Hybrid Cloud product gross margins were also impacted by higher component and freight costs.

[0000950170-23-005545:mdna:60]
[same as prior period, unchanged from 0000950170-22-025960:mdna:61]

[0000950170-23-005545:mdna:61]
Unallocated cost of product revenues decreased in the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of the prior year due to certain intangible assets becoming fully amortized during the first quarter of fiscal 2023.

[0000950170-23-005545:mdna:62]
[same as prior period, unchanged from 0000950170-22-025960:mdna:63]

[0000950170-23-005545:mdna:63]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |
| Cost of services revenues |  | $ | 158 |  |  | $ | 134 |  |  |  | 18 | % |  | $ | 465 |  |  | $ | 399 |  |  |  | 17 | % |
| Support |  |  | 44 |  |  |  | 45 |  |  |  | (2 | )% |  |  | 132 |  |  |  | 141 |  |  |  | (6 | )% |
| Professional and other services |  |  | 50 |  |  |  | 46 |  |  |  | 9 | % |  |  | 156 |  |  |  | 151 |  |  |  | 3 | % |
| Public cloud |  |  | 47 |  |  |  | 32 |  |  |  | 47 | % |  |  | 132 |  |  |  | 80 |  |  |  | 65 | % |
| Unallocated |  |  | 17 |  |  |  | 11 |  |  |  | 55 | % |  |  | 45 |  |  |  | 27 |  |  |  | 67 | % |

[0000950170-23-005545:mdna:64]
[same as prior period, unchanged from 0000950170-22-025960:mdna:65]

[0000950170-23-005545:mdna:65]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, increased in the third quarter of fiscal 2023 and decreased in the first nine months of fiscal 2023 compared to the corresponding periods of fiscal 2022. Cost of Hybrid Cloud services revenues represented approximately 14% of Hybrid Cloud services revenues in the third quarter and first nine months of fiscal 2023, compared to 14% and 15% for the corresponding periods of fiscal 2022, respectively.

[0000950170-23-005545:mdna:66]
Hybrid Cloud support gross margins increased by one percentage point in the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of the prior year due to growth in support revenues achieved with a slightly reduced cost base resulting from operational efficiencies. Hybrid Cloud professional and other services gross margins were flat in the third quarter of fiscal 2023 compared to the corresponding period of fiscal 2022, while they increased by two percentage points in the first nine months of fiscal 2023 compared to the corresponding period of fiscal 2022 due to the mix of services provided.

[0000950170-23-005545:mdna:67]
[same as prior period, unchanged from 0000950170-22-025960:mdna:68]

[0000950170-23-005545:mdna:68]
Cost of Public Cloud revenues increased in the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of fiscal 2022 reflecting the increase in Public Cloud revenues. Public Cloud gross margins decreased by two percentage points in the third quarter and first nine months of fiscal 2023, respectively, compared to the corresponding periods of fiscal 2022, primarily due to the mix of offerings provided.

[0000950170-23-005545:mdna:69]
[same as prior period, unchanged from 0000950170-22-025960:mdna:70]

[0000950170-23-005545:mdna:70]
Unallocated cost of services revenues increased in the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of the prior year due to our acquisition of Instaclustr in the first quarter of fiscal 2023, which resulted in higher amortization expense from acquired intangible assets.

[0000950170-23-005545:mdna:71]
[same as prior period, unchanged from 0000950170-22-025960:mdna:72]

[0000950170-23-005545:mdna:72]
[same as prior period, unchanged from 0000950170-22-025960:mdna:73]

[0000950170-23-005545:mdna:73]
Sales and marketing, research and development, and general and administrative expenses for the third quarter of fiscal 2023 totaled $739 million, or 48% of net revenues, reflecting an increase of two percentage points compared to the corresponding period of fiscal 2022.

[0000950170-23-005545:mdna:74]
Sales and marketing, research and development, and general and administrative expenses for the first nine months of fiscal 2023 totaled $2,298 million, or 48% of net revenues, which was flat compared to the corresponding period of fiscal 2022.

[0000950170-23-005545:mdna:75]
While fluctuations in foreign currency exchange rates adversely impacted net revenues in the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of fiscal 2022, they favorably impacted sales and marketing, research and development and general and administrative expenses by approximately 3% in both periods.

[0000950170-23-005545:mdna:76]
Compensation costs represent the largest component of sales and marketing, research and development and general and administrative expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0000950170-23-005545:mdna:77]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses increased by $14 million, or 3%, in the third quarter of fiscal 2023, and by $99 million, or 8%, in the first nine months of fiscal 2023,  compared to the corresponding periods of the prior year, primarily due to higher salaries and stock-based compensation expense, reflecting an increase in average headcount of 12% and 11%, respectively. Stock-based compensation expense in the current year periods also included incremental expense related to the reset and rollover mechanism of our employee stock purchase plan. These increases were partially offset by lower incentive compensation expense.

[0000950170-23-005545:mdna:78]
[same as prior period, unchanged from 0000950170-22-025960:mdna:79]

[0000950170-23-005545:mdna:79]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 450 |  |  | $ | 461 |  |  |  | (2 | )% |  | $ | 1,387 |  |  | $ | 1,377 |  |  |  | 1 | % |

[0000950170-23-005545:mdna:80]
32

[0000950170-23-005545:mdna:81]
[same as prior period, unchanged from 0000950170-22-025960:mdna:81]

[0000950170-23-005545:mdna:82]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2023 to Fiscal 2022 |  |  | Fiscal 2023 to Fiscal 2022 |  |
| Compensation costs |  |  | 2 |  |  |  | 3 |  |
| Commissions |  |  | (2 | ) |  |  | (2 | ) |
| Advertising and marketing promotional expense |  |  | (3 | ) |  |  | (2 | ) |
| Travel and entertainment |  |  | 1 |  |  |  | 2 |  |
| Total change |  |  | (2 | ) |  |  | 1 |  |

[0000950170-23-005545:mdna:83]
The increase in compensation costs for the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of the prior year each reflected an increase in average headcount of approximately 9%. The impact of the increase in headcount was partially offset by lower incentive compensation expense and the impact of foreign exchange rate fluctuations.

[0000950170-23-005545:mdna:84]
The decrease in commissions expense for the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of the prior year was primarily due to lower performance against sales goals.

[0000950170-23-005545:mdna:85]
Advertising and marketing promotional expense decreased in the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of the prior year, primarily due to lower spending on certain marketing programs.

[0000950170-23-005545:mdna:86]
Travel and entertainment expense increased in the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of the prior year as COVID-19 related travel restrictions eased.

[0000950170-23-005545:mdna:87]
[same as prior period, unchanged from 0000950170-22-025960:mdna:86]

[0000950170-23-005545:mdna:88]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |
| Research and development expenses |  | $ | 230 |  |  | $ | 220 |  |  |  | 5 | % |  | $ | 713 |  |  | $ | 646 |  |  |  | 10 | % |

[0000950170-23-005545:mdna:89]
[same as prior period, unchanged from 0000950170-22-025960:mdna:88]

[0000950170-23-005545:mdna:90]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2023 to Fiscal 2022 |  |  | Fiscal 2023 to Fiscal 2022 |  |
| Compensation costs |  |  | 4 |  |  |  | 9 |  |
| Development projects and outside services |  |  | 1 |  |  |  | 1 |  |
| Total change |  |  | 5 |  |  |  | 10 |  |

[0000950170-23-005545:mdna:91]
The increase in compensation costs for the third quarter and first nine months of fiscal 2023 compared to the corresponding periods in the prior year was primarily attributable to an increase in average headcount of 16% and 14%, respectively. The impact of the increase in headcount was partially offset by lower incentive compensation expense and the impact of foreign exchange rate fluctuations.

[0000950170-23-005545:mdna:92]
The increase in development projects and outside services for the third quarter and first nine months of fiscal 2023 compared to the corresponding periods in the prior year was primarily due to the higher spending on certain engineering projects.

[0000950170-23-005545:mdna:93]
[same as prior period, unchanged from 0000950170-22-025960:mdna:92]

[0000950170-23-005545:mdna:94]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |
| General and administrative expenses |  | $ | 59 |  |  | $ | 65 |  |  |  | (9 | )% |  | $ | 198 |  |  | $ | 207 |  |  |  | (4 | )% |

[0000950170-23-005545:mdna:95]
[same as prior period, unchanged from 0000950170-22-025960:mdna:94]

[0000950170-23-005545:mdna:96]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2023 to Fiscal 2022 |  |  | Fiscal 2023 to Fiscal 2022 |  |
| Compensation costs |  |  | (7 | ) |  |  | — |  |
| Facilities and IT support costs |  |  | (6 | ) |  |  | (5 | ) |
| Other |  |  | 4 |  |  |  | 1 |  |
| Total change |  |  | (9 | ) |  |  | (4 | ) |

[0000950170-23-005545:mdna:97]
The decrease in compensation costs in the third quarter of fiscal 2023 compared to the corresponding period of the prior year was primarily attributable to lower incentive compensation expense, partially offset by the increase in salaries and stock-based compensation expenses.

[0000950170-23-005545:mdna:98]
The decrease in facilities and IT support costs in the third quarter and first nine months of fiscal 2023 was primarily related to lower spending for certain IT projects.

[0000950170-23-005545:mdna:99]
[same as prior period, unchanged from 0000950170-22-025960:mdna:100]

[0000950170-23-005545:mdna:100]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |
| Restructuring charges |  | $ | 87 |  |  | $ | — |  |  | NM |  | $ | 109 |  |  | $ | 29 |  |  |  | 276 | % |

[0000950170-23-005545:mdna:101]
[same as prior period, unchanged from 0000950170-22-025960:mdna:105]

[0000950170-23-005545:mdna:102]
The restructuring charges for the third quarter and first nine months of fiscal 2023 consisted primarily of severance-related costs associated with a restructuring plan approved by management during the third quarter of fiscal 2023 to redirect resources to highest return activities and reduce costs. This plan will result in a reduction of our global workforce by approximately 8%. The restructuring charges in fiscal 2023 also included severance-related costs, legal costs and tax-related consulting costs for ongoing restructuring activities related to the establishment of an international headquarters in Cork, Ireland, and a restructuring plan executed in the first quarter of fiscal 2023, which resulted in a reduction of our global workforce by approximately 1%.

[0000950170-23-005545:mdna:103]
[same as prior period, unchanged from 0000950170-22-025960:mdna:103]

[0000950170-23-005545:mdna:104]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |
| Acquisition-related expense |  | $ | 3 |  |  | $ | 6 |  |  | NM |  | $ | 18 |  |  | $ | 8 |  |  | NM |

[0000950170-23-005545:mdna:105]
[same as prior period, unchanged from 0000950170-22-025960:mdna:110]

[0000950170-23-005545:mdna:106]
Acquisition-related expenses, primarily legal and consulting fees, totaled $3 million and $18 million in the third quarter and first nine months of fiscal 2023, respectively, and were primarily related to our acquisition of Instaclustr US Holding, Inc.

[0000950170-23-005545:mdna:107]
[same as prior period, unchanged from 0000950170-22-025960:mdna:107]

[0000950170-23-005545:mdna:108]
[same as prior period, unchanged from 0000950170-22-025960:mdna:108]

[0000950170-23-005545:mdna:109]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |
| Interest income |  | $ | 21 |  |  | $ | 2 |  |  | NM |  |  | $ | 42 |  |  | $ | 5 |  |  | NM |  |
| Interest expense |  |  | (16 | ) |  |  | (19 | ) |  |  | (16 | )% |  |  | (51 | ) |  |  | (55 | ) |  |  | (7 | )% |
| Other, net |  |  | — |  |  |  | 2 |  |  | NM |  |  |  | 52 |  |  |  | 9 |  |  | NM |  |
| Total |  | $ | 5 |  |  | $ | (15 | ) |  | NM |  |  | $ | 43 |  |  | $ | (41 | ) |  | NM |  |

[0000950170-23-005545:mdna:110]
[same as prior period, unchanged from 0000950170-22-025960:mdna:115]

[0000950170-23-005545:mdna:111]
Interest income increased in the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of the prior year due primarily to higher yields earned on our cash and investments. Interest expense decreased in the third quarter and first nine months of fiscal 2023 compared to the corresponding periods of fiscal 2022 due to the extinguishment of certain senior notes in the second quarter of fiscal 2023.

[0000950170-23-005545:mdna:112]
Other, net for the first nine months of fiscal 2023 includes $21 million of other income for non-refundable, up-front payments from customers in Russia for support contracts, which we were not able to fulfill due to imposed sanctions and for which we have no remaining legal obligation to perform. Other, net for the first nine months of fiscal 2023 also includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million. The remaining differences in Other, net for the third quarter and first nine months of fiscal 2023 as compared to the corresponding periods of the prior year are partially due to foreign exchange gains and losses year-over-year.

[0000950170-23-005545:mdna:113]
Provision (benefit) for Income Taxes (in millions, except percentages):

[0000950170-23-005545:mdna:114]
|  |  | Three Months Ended |  |  | Nine Months Ended |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | % Change |
| Provision (benefit) for income taxes |  | $ | 112 |  |  | $ | 54 |  |  |  | 107 | % |  | $ | (277 | ) |  | $ | 145 |  |  | NM |

[0000950170-23-005545:mdna:115]
NM – Not Meaningful

[0000950170-23-005545:mdna:116]
Our effective tax rate for the three months ended January 27, 2023 increased compared to the corresponding period of the prior year, primarily due to the discrete tax expense recorded as a result of the Danish Supreme Court ruling received January 9, 2023. Our effective tax rate for the nine months ended January 27, 2023 decreased compared to the corresponding period of the prior year, primarily due to the discrete tax benefit resulting from an intra-entity asset transfer of certain IP.

[0000950170-23-005545:mdna:117]
During the second quarter of fiscal 2023, we completed an intra-entity asset transfer of certain IP to our international headquarters (the “IP Transfer”). The transaction resulted in a step-up of tax-deductible basis in the transferred assets, and accordingly, created a temporary difference where the tax basis exceeded the financial statement basis of such intangible assets, which resulted in the recognition of a discrete tax benefit and related deferred tax asset of $524 million during the second quarter of fiscal 2023.  Management applied significant judgment when determining the fair value of the IP, which serves as the tax basis of the deferred tax asset. With the assistance of third-party valuation specialists, the fair value of the IP was determined principally based on the present value of projected cash flows related to the IP which reflects management’s assumptions regarding projected revenues, expenses and a discount rate. The tax-deductible amortization related to the transferred IP rights will be recognized in future periods and any amortization that is unused in a particular year can be carried forward indefinitely. The deferred tax asset and the tax benefit were measured based on the enacted tax rates expected to apply in the years the asset is expected to be realized. We expect to realize the deferred tax asset resulting from the IP Transfer and will assess the realizability of the deferred tax asset quarterly. Any Organisation for Economic Co-operation and Development’s (“OECD”) actions adopted internationally, could impact our financial results in future periods. The impact of the transaction to net cash provided by or used in operating, investing and financing activities on the condensed consolidated statements of cash flows during the quarter ended January 27, 2023, was not material.

[0000950170-23-005545:mdna:118]
During the third quarter of fiscal 2023, the Danish Supreme Court issued a non-appealable ruling on the distributions declared in 2005 and 2006. The Danish Supreme Court reversed the lower court's decision and ruled the 2005 dividend was subject to at-source dividend withholding tax while the smaller 2006 distribution would not be subject to withholding tax. We recorded $69 million of tax expense, which includes $23 million of withholding tax and $46 million of interest, associated with the Danish Supreme Court ruling as a discrete item during the quarter ended January 27, 2023.

[0000950170-23-005545:mdna:119]
As of January 27, 2023, we had $228 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $141 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $141 million have been recorded in other long-term liabilities.

[0000950170-23-005545:mdna:120]
[same as prior period, unchanged from 0000950170-22-025960:mdna:119]

[0000950170-23-005545:mdna:121]
| (In millions) |  | January 27, 2023 |  |  | April 29, 2022 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,141 |  |  | $ | 4,134 |  |
| Principal amount of debt |  | $ | 2,400 |  |  | $ | 2,650 |  |

[0000950170-23-005545:mdna:122]
[same as prior period, unchanged from 0000950170-22-025960:mdna:121]

[0000950170-23-005545:mdna:123]
|  |  | Nine Months Ended |  |
| (In millions) |  | January 27, 2023 |  |  | January 28, 2022 |  |
| Net cash provided by operating activities |  | $ | 872 |  |  | $ | 800 |  |
| Net cash used in investing activities |  |  | (1,105 | ) |  |  | (481 | ) |
| Net cash used in financing activities |  |  | (1,244 | ) |  |  | (651 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 4 |  |  |  | (26 | ) |
| Net change in cash, cash equivalents and restricted cash |  | $ | (1,473 | ) |  | $ | (358 | ) |

[0000950170-23-005545:mdna:124]
[same as prior period, unchanged from 0000950170-22-025960:mdna:123]

[0000950170-23-005545:mdna:125]
As of January 27, 2023, our cash, cash equivalents and short-term investments were $3.1 billion, which represents a decrease of $1.0 billion for the first nine months of fiscal 2023. The decrease was primarily due to $491 million, net of cash acquired, used for the acquisition of a privately-held company, $700 million paid for the repurchase of our common stock, $326 million used for the payment of dividends and $250 million repayment of our Senior Notes, partially offset by $872 million provided by operating activities. Net working capital was $1.1 billion as of January 27, 2023, a reduction of $845 million when compared to April 29, 2022, primarily due to the decrease in cash, cash equivalents and short-term investments discussed above.

[0000950170-23-005545:mdna:126]
[same as prior period, unchanged from 0000950170-22-025960:mdna:125]

[0000950170-23-005545:mdna:127]
During the first nine months of fiscal 2023, we generated cash from operating activities of $872 million, reflecting net income of $1.0 billion which was reduced by $577 million for non-cash deferred tax benefits and increased for non-cash depreciation and amortization expense of $182 million and non-cash stock-based compensation expense of $238 million, compared to $800 million of cash generated from operating activities during the first nine months of fiscal 2022.

[0000950170-23-005545:mdna:128]
Significant changes in assets and liabilities in the first nine months of fiscal 2023 included the following:

[0000950170-23-005545:mdna:129]
•
Accounts receivable decreased $425 million, reflecting lower billings in the first nine months of fiscal 2023 compared to the last nine months of fiscal 2022.

[0000950170-23-005545:mdna:130]
•
Accounts payable decreased by $173 million, primarily reflecting lower inventory purchases, and the timing of those purchases from, and payments to, our contract manufacturers.

[0000950170-23-005545:mdna:131]
•
Accrued expenses decreased by $117 million, primarily due to employee compensation payouts related to fiscal year 2022 incentive compensation and commissions plans.

[0000950170-23-005545:mdna:132]
[same as prior period, unchanged from 0000950170-22-025960:mdna:130]

[0000950170-23-005545:mdna:133]
[same as prior period, unchanged from 0000950170-22-025960:mdna:131]

[0000950170-23-005545:mdna:134]
During the first nine months of fiscal 2023, we used $474 million for the purchases of investments, net of maturities and sales, and paid $200 million for capital expenditures, as compared to the same period of fiscal 2022, in which we generated $36 million from maturities and sales of investments, net of purchases, and paid $158 million for capital expenditures. During the first nine months of fiscal 2023, we paid approximately $491 million, net of cash acquired for a privately-held company, as compared to $359 million, net of cash acquired, that we paid for two privately-held companies in the first nine months of fiscal 2022. Additionally, we received proceeds of $59 million from the sale of one of our minority investments during the first nine months of fiscal 2023.

[0000950170-23-005545:mdna:135]
[same as prior period, unchanged from 0000950170-22-025960:mdna:133]

[0000950170-23-005545:mdna:136]
During the first nine months of fiscal 2023, cash flows used in financing activities totaled $1.2 billion and include $700 million for the repurchase of approximately ten million shares of common stock, $326 million for the payment of dividends and $250 million to redeem our Senior Notes due in December 2022. During the first nine months of fiscal 2022, cash flows used in financing activities totaled $651 million and included $350 million for the repurchase of approximately four million shares of common stock and $335 million for the payment of dividends.

[0000950170-23-005545:mdna:137]
36

[0000950170-23-005545:mdna:138]
[same as prior period, unchanged from 0000950170-22-025960:mdna:135]

[0000950170-23-005545:mdna:139]
[same as prior period, unchanged from 0000950170-22-025960:mdna:136]

[0000950170-23-005545:mdna:140]
Our principal sources of liquidity as of January 27, 2023 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-23-005545:mdna:141]
[same as prior period, unchanged from 0000950170-22-025960:mdna:138]

[0000950170-23-005545:mdna:142]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| Cash and cash equivalents |  | $ | 2,640 |  |  | $ | 4,112 |  |
| Short-term investments |  |  | 501 |  |  |  | 22 |  |
| Total |  | $ | 3,141 |  |  | $ | 4,134 |  |

[0000950170-23-005545:mdna:143]
As of January 27, 2023 and April 29, 2022, $2.0 billion and $2.3 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $1.1 billion and $1.8 billion, respectively, were available in the U.S.

[0000950170-23-005545:mdna:144]
[same as prior period, unchanged from 0000950170-22-025960:mdna:141]

[0000950170-23-005545:mdna:145]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of January 27, 2023.

[0000950170-23-005545:mdna:146]
[same as prior period, unchanged from 0000950170-22-025960:mdna:143]

[0000950170-23-005545:mdna:147]
[same as prior period, unchanged from 0000950170-22-025960:mdna:144]

[0000950170-23-005545:mdna:148]
The following table summarizes the principal amount of our Senior Notes as of January 27, 2023 (in millions):

[0000950170-23-005545:mdna:149]
|  |  | Amount |  |
| 3.30% Senior Notes Due September 2024 |  | $ | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,400 |  |

[0000950170-23-005545:mdna:150]
[same as prior period, unchanged from 0000950170-22-025960:mdna:147]

[0000950170-23-005545:mdna:151]
On September 15, 2022, we extinguished our 3.25% Senior Notes due December 2022 for an aggregate cash redemption price of $252 million, comprised of the principal and unpaid interest.

[0000950170-23-005545:mdna:152]
Commercial Paper Program and Credit Facility

[0000950170-23-005545:mdna:153]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of January 27, 2023.

[0000950170-23-005545:mdna:154]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 27, 2023, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-23-005545:mdna:155]
[same as prior period, unchanged from 0000950170-22-025960:mdna:152]

[0000950170-23-005545:mdna:156]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2023 to be between $25 million and $75 million.

[0000950170-23-005545:mdna:157]
[same as prior period, unchanged from 0000950170-22-025960:mdna:154]

[0000950170-23-005545:mdna:158]
The Tax Cuts and Jobs Act of 2017 imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits that had not previously been subject to U.S. income tax. As of January 27, 2023, outstanding payments related to the transition tax are estimated to be approximately $303 million of which $88 million, $115 million and $100 million are expected to be paid during fiscal 2024, fiscal 2025 and fiscal 2026, respectively. During the first nine months of fiscal 2023, transition tax payments totaled $48 million. Our estimates for future transition tax payments, however, could change with further guidance or review from U.S. federal and state tax authorities or other regulatory bodies.

[0000950170-23-005545:mdna:159]
[same as prior period, unchanged from 0000950170-22-025960:mdna:156]

[0000950170-23-005545:mdna:160]
On February 17, 2023, we declared a cash dividend of $0.50 per share of common stock, payable on April 26, 2023, to holders of record as of the close of business on April 6, 2023.

[0000950170-23-005545:mdna:161]
As of January 27, 2023, our Board of Directors had authorized the repurchase of up to $15.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through January 27, 2023, we repurchased a total of 358 million shares of our common stock at an average price of $40.74 per share, for an aggregate purchase price of $14.6 billion. As of January 27, 2023, the remaining authorized amount for stock repurchases under this program was $0.5 billion.

[0000950170-23-005545:mdna:162]
[same as prior period, unchanged from 0000950170-22-025960:mdna:159]

[0000950170-23-005545:mdna:163]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled approximately $0.8 billion at January 27, 2023.

[0000950170-23-005545:mdna:164]
[same as prior period, unchanged from 0000950170-22-025960:mdna:162]

[0000950170-23-005545:mdna:165]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $32 million and $48 million of receivables during the first nine months of fiscal 2023 and fiscal 2022, respectively.

[0000950170-23-005545:mdna:166]
[same as prior period, unchanged from 0000950170-22-025960:mdna:164]

[0000950170-23-005545:mdna:167]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of January 27, 2023 and April 29, 2022, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-23-005545:mdna:168]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of January 27, 2023, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-23-005545:mdna:169]
Legal Contingencies

[0000950170-23-005545:mdna:170]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0000950170-23-005545:mdna:171]
[same as prior period, unchanged from 0000950170-22-025960:mdna:169]

[0000950170-23-005545:mdna:172]
[same as prior period, unchanged from 0000950170-22-025960:mdna:170]

[0000950170-23-005545:mdna:173]
[same as prior period, unchanged from 0000950170-22-025960:mdna:171]

[0000950170-23-005545:mdna:174]
[same as prior period, unchanged from 0000950170-22-025960:mdna:172]

[0000950170-23-005545:mdna:175]
[same as prior period, unchanged from 0000950170-22-025960:mdna:173]
