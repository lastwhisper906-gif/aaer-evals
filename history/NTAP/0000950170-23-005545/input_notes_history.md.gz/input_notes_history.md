# NTAP note change history — 0000950170-22-025960 → 0000950170-23-005545


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-03-01):
[0000950170-23-005545:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of January 27, 2023, we had approximately $0.5 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 27, 2023 and April 29, 2022, such liability amounted to $20 million and $18 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2022-12-01, similarity 0.9864):
[0000950170-22-025960:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of October 28, 2022, we had approximately $0.6 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 28, 2022 and April 29, 2022, such liability amounted to $20 million and $18 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2023-03-01):
[0000950170-23-005545:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 27, 2023, we had approximately $0.3 billion in other purchase obligations.
  (was, 2022-12-01, similarity 0.9787):
[0000950170-22-025960:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 28, 2022, we had approximately $0.3 billion in other purchase obligations.

- changed (2023-03-01):
[0000950170-23-005545:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $32 million and $48 million of receivables during the nine months ended January 27, 2023 and January 28, 2022, respectively.
  (was, 2022-12-01, similarity 0.966):
[0000950170-22-025960:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $10 million and $38 million of receivables during the first six months ended October 28, 2022 and October 29, 2021, respectively.

- changed (2023-03-01):
[0000950170-23-005545:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of January 27, 2023 and April 29, 2022, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2022-12-01, similarity 0.9938):
[0000950170-22-025960:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of October 28, 2022 and April 29, 2022, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- changed (2023-03-01):
[0000950170-23-005545:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 27, 2023, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.
  (was, 2022-12-01, similarity 0.6489):
[0000950170-22-025960:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 28, 2022, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount

- changed (2023-03-01):
[0000950170-23-005545:note_history:6]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of January 27, 2023 related to such matters.
  (was, 2022-12-01, similarity 0.9922):
[0000950170-22-025960:note_history:6]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of October 28, 2022 related to such matters.

- removed (2023-03-01):
[0000950170-22-025960:note_history:7]
of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-03-01):
[0000950170-23-005545:note_history:8]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2022 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 27, 2023 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2022-12-01, similarity 0.9773):
[0000950170-22-025960:note_history:8]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2022 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 28, 2022 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-03-01):
[0000950170-23-005545:note_history:9]
|  |  | Effective Interest Rate |  | January 27, 2023 |  |  | April 29, 2022 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | — |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,400 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (12 | ) |  |  | (14 | ) |
| Total senior notes |  |  |  |  | 2,388 |  |  |  | 2,636 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (250 | ) |
| Total long-term debt |  |  |  | $ | 2,388 |  |  | $ | 2,386 |  |
  (was, 2022-12-01, similarity 0.9895):
[0000950170-22-025960:note_history:9]
|  |  | Effective Interest Rate |  | October 28, 2022 |  |  | April 29, 2022 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | — |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,400 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (13 | ) |  |  | (14 | ) |
| Total senior notes |  |  |  |  | 2,387 |  |  |  | 2,636 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (250 | ) |
| Total long-term debt |  |  |  | $ | 2,387 |  |  | $ | 2,386 |  |

- changed (2023-03-01):
[0000950170-23-005545:note_history:10]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were each issued in June 2020. Interest on each of these Senior Notes is payable semi-annually in June and December. Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September.
  (was, 2022-12-01, similarity 0.6457):
[0000950170-22-025960:note_history:10]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were each issued in

- changed (2023-03-01):
[0000950170-23-005545:note_history:11]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 27, 2023, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2022-12-01, similarity 0.9892):
[0000950170-22-025960:note_history:11]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 28, 2022, we were in compliance with all covenants associated with the Senior Notes.

- changed (2023-03-01):
[0000950170-23-005545:note_history:12]
As of January 27, 2023, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2022-12-01, similarity 0.9362):
[0000950170-22-025960:note_history:12]
As of October 28, 2022, our aggregate future principal debt maturities are as follows (in millions):

- changed (2023-03-01):
[0000950170-23-005545:note_history:13]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of January 27, 2023 or April 29, 2022.
  (was, 2022-12-01, similarity 0.9818):
[0000950170-22-025960:note_history:13]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of October 28, 2022 or April 29, 2022.

- changed (2023-03-01):
[0000950170-23-005545:note_history:14]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in January 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 27, 2023, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.
  (was, 2022-12-01, similarity 0.9912):
[0000950170-22-025960:note_history:14]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in January 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of October 28, 2022, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.

- removed (2023-03-01):
[0000950170-22-025960:note_history:15]
June 2020. Interest on each of these Senior Notes is payable semi-annually in June and December. Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-03-01):
[0000950170-23-005545:note_history:16]
|  |  | Effective Interest Rate |  | January 27, 2023 |  |  | April 29, 2022 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | — |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,400 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (12 | ) |  |  | (14 | ) |
| Total senior notes |  |  |  |  | 2,388 |  |  |  | 2,636 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (250 | ) |
| Total long-term debt |  |  |  | $ | 2,388 |  |  | $ | 2,386 |  |
  (was, 2022-12-01, similarity 0.9895):
[0000950170-22-025960:note_history:16]
|  |  | Effective Interest Rate |  | October 28, 2022 |  |  | April 29, 2022 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | — |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,400 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (13 | ) |  |  | (14 | ) |
| Total senior notes |  |  |  |  | 2,387 |  |  |  | 2,636 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (250 | ) |
| Total long-term debt |  |  |  | $ | 2,387 |  |  | $ | 2,386 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-03-01):
[0000950170-23-005545:note_history:17]
As of January 27, 2023, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2022-12-01, similarity 0.9362):
[0000950170-22-025960:note_history:17]
As of October 28, 2022, our aggregate future principal debt maturities are as follows (in millions):
