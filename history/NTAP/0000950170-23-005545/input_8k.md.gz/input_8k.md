# NTAP 8-K — 0000950170-23-003745 filed 2023-02-22

## item codes, every 8-K on or before 2023-03-01

- 2023-02-22 0000950170-23-003745 — 2.02, 9.01
- 2023-01-31 0001193125-23-019739 — 2.05, 7.01, 9.01
- 2022-11-29 0000950170-22-025793 — 2.02, 9.01
- 2022-11-16 0000950170-22-025317 — 5.02
- 2022-09-14 0000950170-22-018490 — 5.07
- 2022-08-24 0000950170-22-017731 — 2.02, 9.01
- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2023-03-01

- none on or before 2023-03-01

## item 2.02 — earnings release, exhibit 99.1

[0000950170-23-003745:8k_2_02:1]
EX-99
2
ntap-ex99_1.htm
EX-99.1

[0000950170-23-003745:8k_2_02:2]
EX-99

[0000950170-23-003745:8k_2_02:3]
Exhibit 99.1

[0000950170-23-003745:8k_2_02:4]
NetApp reports third quarter of fiscal year 2023 results

[0000950170-23-003745:8k_2_02:5]
Net revenues of $1.53 billion and billings1of $1.57 billion

[0000950170-23-003745:8k_2_02:6]
•
$308 million returned to shareholders in share repurchases and cash dividends in the third quarter

[0000950170-23-003745:8k_2_02:7]
•
Introduced significant innovation, including BlueXP™, a unified control plane for hybrid multicloud environments, and the latest version of NetApp ONTAP™ with enhanced protection capabilities to automatically detect and prevent ransomware attacks

[0000950170-23-003745:8k_2_02:8]
•
Announced the availability of new tools for companies to monitor, manage, and optimize their carbon footprints across their hybrid, multi-cloud environments

[0000950170-23-003745:8k_2_02:9]
•
Published third annual ESG report with goals to achieve 50% intensity reduction of Scope 3 greenhouse gas (GHG) emissions and a 42% reduction of Scope 1 and 2 GHG emissions by 2030

[0000950170-23-003745:8k_2_02:10]
SAN JOSE, Calif.—February 22, 2023—NetApp (NASDAQ: NTAP) today reported financial results for the third quarter of fiscal year 2023, which ended on January 27, 2023.

[0000950170-23-003745:8k_2_02:11]
“In Q3, we executed well on the elements under our control in the face of a weakening IT spending environment and continued cloud cost optimization,” said George Kurian, chief executive officer. “We are confident that we remain well positioned to take advantage of the secular growth trends of data-driven digital and cloud transformations. Building on that solid foundation, we are sharpening our execution to accelerate near-term results while strengthening our position when the spending environment rebounds.”

[0000950170-23-003745:8k_2_02:12]
Third quarter of fiscal year 2023 financial results

[0000950170-23-003745:8k_2_02:13]
•
Net revenues: $1.53 billion, compared to $1.61 billion in the third quarter of fiscal year 2022; a year-over-year decrease of 5%, or 2% in constant currency2.

[0000950170-23-003745:8k_2_02:14]
o
Hybrid Cloud segment revenue: $1.38 billion, compared to $1.50 billion in the third quarter of fiscal year 2022.

[0000950170-23-003745:8k_2_02:15]
o
Public Cloud segment revenue: $150 million, compared to $110 million in the third quarter of fiscal year 2022.

[0000950170-23-003745:8k_2_02:16]
•
Billings: $1.57 billion, compared to $1.76 billion in the third quarter of fiscal year 2022; a year-over-year decrease of 11%, or 7% in constant currency.

[0000950170-23-003745:8k_2_02:17]
•
NetApp Public Cloud annualized revenue run rate (ARR)3 $605 million, compared to $469 million in the third quarter of fiscal year 2022; a year-over-year increase of 29%.

[0000950170-23-003745:8k_2_02:18]
•
All-flash array ARR4 $2.8 billion, compared to $3.2 billion in the third quarter of fiscal year 2022; a year-over-year decrease of 12%.

[0000950170-23-003745:8k_2_02:19]
•
Net income: GAAP net income of $65 million, compared to $252 million in the third quarter of fiscal year 2022; non-GAAP net income5 of $301 million, compared to $330 million in the third quarter of fiscal year 2022. The year-over-year fluctuations in GAAP and Non-GAAP net income each include an unfavorable impact of approximately $30 million from foreign currency exchange rate changes.

[0000950170-23-003745:8k_2_02:20]
•
Earnings per share: GAAP net income per share6 of $0.30, compared to $1.10 in the third quarter of fiscal year 2022; non-GAAP net income per share of $1.37, compared to $1.44 in the third quarter of fiscal year 2022. The year-over-year fluctuations in GAAP and Non-GAAP net income per share each include an unfavorable impact of approximately $0.14 from foreign currency exchange rate changes.

[0000950170-23-003745:8k_2_02:21]
•
Cash, cash equivalents and investments: $3.1 billion at the end of the third quarter of fiscal year 2023.

[0000950170-23-003745:8k_2_02:22]
•
Cash provided by operations: $377 million, compared to $260 million in the third quarter of fiscal year 2022.

[0000950170-23-003745:8k_2_02:23]
•
Share repurchase and dividends: Returned $308 million to shareholders through share repurchases and cash dividends.

[0000950170-23-003745:8k_2_02:24]
Fourth quarter of fiscal year 2023 financial outlook

[0000950170-23-003745:8k_2_02:25]
The Company provided the following financial guidance for the third quarter of fiscal year 2023:

[0000950170-23-003745:8k_2_02:26]
| Net revenues are expected to be in the range of: | $1.475 billion to $1.625 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $0.92 - $1.02 | $1.30 - $1.40 |

[0000950170-23-003745:8k_2_02:27]
Full fiscal year 2023 financial outlook

[0000950170-23-003745:8k_2_02:28]
The Company provided the following financial guidance for the full fiscal year 2023:

[0000950170-23-003745:8k_2_02:29]
| Net revenues are expected to be flat year-over-year |  |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 65% - 66% | 66% - 67% |
| Operating margins are expected to be: | 15% - 16% | 23% - 24% |
| Earnings per share is expected to be: | $5.48 - $5.68 | $5.30 - $5.50 |

[0000950170-23-003745:8k_2_02:30]
Dividend

[0000950170-23-003745:8k_2_02:31]
The next cash dividend of $0.50 per share is to be paid on April 26, 2023, to shareholders of record as of the close of business on April 6, 2023.

[0000950170-23-003745:8k_2_02:32]
Third quarter of fiscal year 2023 business highlights

[0000950170-23-003745:8k_2_02:33]
Leading product innovation

[0000950170-23-003745:8k_2_02:34]
•
NetApp announced the availability of NetApp BlueXP, a unified control plane delivering a simple hybrid multicloud experience for storage and data services across on-premises and cloud environments.

[0000950170-23-003745:8k_2_02:35]
•
NetApp Cloud Volumes ONTAP™ for Google Cloud is now offered in three different capacity-tiered licensing packages.

[0000950170-23-003745:8k_2_02:36]
•
NetApp announced the availability of new ways for companies to monitor, manage, and optimize their carbon footprints across their hybrid multicloud environments.

[0000950170-23-003745:8k_2_02:37]
•
NetApp announced the latest release of NetApp ONTAP data management software, delivering enhanced protection capabilities that can automatically detect and prevent ransomware attacks.

[0000950170-23-003745:8k_2_02:38]
•
NetApp announced that it has begun shipping Titanium-rated power supplies for new controllers and shelves to help customers improve data center power efficiency.

[0000950170-23-003745:8k_2_02:39]
•
Spot by NetApp announced the release of Ocean CD public beta, a continuous delivery product for Kubernetes applications.

[0000950170-23-003745:8k_2_02:40]
•
Spot by NetApp announced that Spot Elastigroup by NetApp can now be easily provisioned and managed as an AWS Quick Start guide, created in collaboration with the AWS Quick Start team.

[0000950170-23-003745:8k_2_02:41]
Customer and partner momentum

[0000950170-23-003745:8k_2_02:42]
•
NetApp announced the general availability of Azure NetApp Files datastores for Azure VMware Solution.

[0000950170-23-003745:8k_2_02:43]
•
NetApp announced the support of NVIDIA AI Enterprise for VMware. This announcement makes NetApp the first enterprise storage partner to validate storage solutions with NVIDIA AI Enterprise for VMware environments.

[0000950170-23-003745:8k_2_02:44]
•
NetApp and Modzy partnered to deliver a new way of applying artificial intelligence (AI) and machine learning (ML) to any type of data, including imagery, audio, text, and tables, for at-scale AI and data science where trust matters.

[0000950170-23-003745:8k_2_02:45]
•
NetApp announced that customers can simplify operations and increase the performance of Confluent Platform storage by using NetApp ONTAP as both primary and tiered storage.

[0000950170-23-003745:8k_2_02:46]
•
AWS and NetApp announced new features for Amazon FSx for NetApp ONTAP around performance improvement, ease-of-use capabilities, and additional integrations.

[0000950170-23-003745:8k_2_02:47]
•
Cisco and NetApp announced that they will bring BlueXP technology and innovations into FlexPod™ XCS, for FlexPod and FlexPod XCS customers.

[0000950170-23-003745:8k_2_02:48]
•
NetApp announced that it has a Cisco Validated Design (CVD) proving that FlexPod is the best converged infrastructure for deploying Epic.

[0000950170-23-003745:8k_2_02:49]
•
Cisco and NetApp announced that they are bringing a new wave of NetApp, Cisco, and Intel innovation to the proven hybrid cloud capabilities of FlexPod XCS.

[0000950170-23-003745:8k_2_02:50]
NetApp awards and recognition

[0000950170-23-003745:8k_2_02:51]
•
NetApp was one of nine champions of the 2022 Canalys EMEA Channel Leadership Matrix.

[0000950170-23-003745:8k_2_02:52]
•
NetApp announced that Amazon FSx for NetApp ONTAP now has FedRAMP Moderate authorization in US East (N. Virginia), US East (Ohio), US West (N. California), and US West (Oregon), and FedRAMP High authorization in AWS GovCloud (US) Regions.

[0000950170-23-003745:8k_2_02:53]
•
NetApp was awarded the highest LEED (Leadership in Energy and Environmental Design) platinum certification for its international headquarters in Navigation Square, Cork, Ireland.

[0000950170-23-003745:8k_2_02:54]
•
NetApp announced that GigaOm named NetApp a leader and outperformer in cloud file storage.

[0000950170-23-003745:8k_2_02:55]
•
NetApp received the award of Best Enterprise Storage Vendor for the second year in a row at Data & Storage ASEAN’s DSA Awards.

[0000950170-23-003745:8k_2_02:56]
•
NetApp is recognized as a major player in IDC’s first-ever MarketScape for DaaS 2022.7

[0000950170-23-003745:8k_2_02:57]
•
NetApp was listed on Business Intelligence Group as the recipient of both the 2022 Stratus Awards as a Top Organization and the 2022 Excellence in Customer Service Awards as Organization of the Year.

[0000950170-23-003745:8k_2_02:58]
•
NetApp was named to Glassdoor’s Best Places to Work in 2023.

[0000950170-23-003745:8k_2_02:59]
•
NetApp is listed in Frost & Sullivan’s 2022 Global Technology Innovation Leadership Award for AI healthcare solutions in North America and healthcare cloud globally. NetApp was named Best Enterprise Flash Storage at the CIO Choice Awards.

[0000950170-23-003745:8k_2_02:60]
•
In its research, “Omdia Universe: Hybrid and Multicloud Management Solution, 2022–23,” Omdia named NetApp a Market Leader and gave BlueXP top scores in three subcategories and the second-highest score in a fourth subcategory.

[0000950170-23-003745:8k_2_02:61]
•
NetApp was part of the 20 coolest cloud storage companies of the CRN Cloud 100 list.

[0000950170-23-003745:8k_2_02:62]
Corporate news

[0000950170-23-003745:8k_2_02:63]
•
NetApp outlined its goal to achieve a 50% intensity reduction of Scope 3 GHG emissions by 2030, and a 42% reduction of Scope 1 and Scope 2 GHG emissions by 2030 through adoption of a science-aligned target.

[0000950170-23-003745:8k_2_02:64]
•
NetApp announced the opening of its new international headquarters in Cork, Ireland.

[0000950170-23-003745:8k_2_02:65]
Executive leadership announcements

[0000950170-23-003745:8k_2_02:66]
•
NetApp hired Piero Gallucci as the vice president and general manager to lead U.K. and Ireland employees as they focus on NetApp’s transformation as a hybrid cloud leader in the market.

[0000950170-23-003745:8k_2_02:67]
•
NetApp appointed Gabrielle “Gabie” Boko as the new chief marketing officer (CMO) with a strong focus on new software as NetApp transforms into a software-led, cloud-led company.

[0000950170-23-003745:8k_2_02:68]
•
NetApp hired David Kim as the chief diversity officer.

[0000950170-23-003745:8k_2_02:69]
Webcast and conference call information

[0000950170-23-003745:8k_2_02:70]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:00 p.m. Pacific Time today.

[0000950170-23-003745:8k_2_02:71]
statements about our GHG emission reduction goals, and statements about our ability to sharpen execution, deliver results, and position the Company to take advantage of secular growth trends. Actual results may differ materially from these statements for a variety of reasons, including, without limitation, our ability to keep pace with the rapid industry, technological and market trends and changes in the markets in which we operate, our ability to execute our evolved cloud strategy and introduce and gain market acceptance for our products and services, our ability to maintain our customer, partner, supplier and contract manufacturer relationships on favorable terms and conditions, general global political, macroeconomic and market conditions, including inflation, rising interest rates and foreign exchange volatility and the resulting impact on demand for our products, the impact of the COVID-19 pandemic, including supply chain disruptions, on our business operations, financial performance and results of operations, material cybersecurity and other security breaches, changes in U.S. government spending, revenue seasonality, changes in laws or regulations, including those relating to privacy, data protection and information security, and our ability to manage our gross profit margins. These and other equally important factors are described in reports and documents we file from time to time with the Securities and Exchange Commission, including the factors described under the section titled “Risk Factors” in our most recently submitted annual report on Form 10-K and quarterly report on Form 10-Q. We disclaim any obligation to update information contained in this press release whether as a result of new information, future events, or otherwise.

[0000950170-23-003745:8k_2_02:72]
###

[0000950170-23-003745:8k_2_02:73]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0000950170-23-003745:8k_2_02:74]
Footnotes

[0000950170-23-003745:8k_2_02:75]
1Refer to the NetApp Usage of Non-GAAP Financial Information section below for an explanation of billings.

[0000950170-23-003745:8k_2_02:76]
2Refer to the Constant Currency section below for an explanation of constant currency growth rates and the impact of foreign currency exchange rate changes on year-over-year fluctuations in earnings.

[0000950170-23-003745:8k_2_02:77]
3Public Cloud annualized revenue run rate (ARR) is calculated as the annualized value of all Public Cloud customer commitments with the assumption that any commitment expiring during the next 12 months will be renewed with its existing terms.

[0000950170-23-003745:8k_2_02:78]
4All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0000950170-23-003745:8k_2_02:79]
5Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) gains/losses on the sale of investments in equity securities, (i) debt extinguishment costs, and (j) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes that the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0000950170-23-003745:8k_2_02:80]
6GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0000950170-23-003745:8k_2_02:81]
7IDC MarketScape: “Worldwide Desktop as a Service 2022–2023 Vendor Assessment,” Shannon Kalvar.

[0000950170-23-003745:8k_2_02:82]
NetApp usage of non-GAAP financial information

[0000950170-23-003745:8k_2_02:83]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share. NetApp also presents the hardware and software components of our GAAP product revenues. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0000950170-23-003745:8k_2_02:84]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations.

[0000950170-23-003745:8k_2_02:85]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0000950170-23-003745:8k_2_02:86]
NetApp believes that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0000950170-23-003745:8k_2_02:87]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0000950170-23-003745:8k_2_02:88]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0000950170-23-003745:8k_2_02:89]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0000950170-23-003745:8k_2_02:90]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0000950170-23-003745:8k_2_02:91]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our

[0000950170-23-003745:8k_2_02:92]
employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0000950170-23-003745:8k_2_02:93]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0000950170-23-003745:8k_2_02:94]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0000950170-23-003745:8k_2_02:95]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0000950170-23-003745:8k_2_02:96]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0000950170-23-003745:8k_2_02:97]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-23-003745:8k_2_02:98]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-23-003745:8k_2_02:99]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-23-003745:8k_2_02:100]
J. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the

[0000950170-23-003745:8k_2_02:101]
fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0000950170-23-003745:8k_2_02:102]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0000950170-23-003745:8k_2_02:103]
Constant Currency

[0000950170-23-003745:8k_2_02:104]
NetApp presents certain constant currency growth rates or quantifies the impact of foreign currency exchange rate changes on year-over-year fluctuations, including for net revenues, billings, and earnings. This constant currency information assumes the same foreign currency exchange rates that were in effect for the comparable prior-year period were used in translation of the current period results.

[0000950170-23-003745:8k_2_02:105]
About NetApp

[0000950170-23-003745:8k_2_02:106]
NetApp is a global, cloud-led, data-centric software company that empowers organizations to lead with data in the age of accelerated digital transformation. The company provides systems, software, and cloud services that enable them to run their applications optimally from data center to cloud, whether they are developing in the cloud, moving to the cloud, or creating their own cloudlike experiences on premises. With solutions that perform across diverse environments, NetApp helps organizations build their own data fabric and securely

[0000950170-23-003745:8k_2_02:107]
deliver the right data, services, and applications to the right people—anytime, anywhere. Learn more at www.netapp.com or follow us on Twitter, LinkedIn, Facebook, and Instagram.

[0000950170-23-003745:8k_2_02:108]
NETAPP, INC.

[0000950170-23-003745:8k_2_02:109]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-23-003745:8k_2_02:110]
(In millions)

[0000950170-23-003745:8k_2_02:111]
(Unaudited)

[0000950170-23-003745:8k_2_02:112]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,141 |  |  | $ | 4,134 |  |
| Accounts receivable |  |  | 821 |  |  |  | 1,230 |  |
| Inventories |  |  | 175 |  |  |  | 204 |  |
| Other current assets |  |  | 403 |  |  |  | 377 |  |
| Total current assets |  |  | 4,540 |  |  |  | 5,945 |  |
| Property and equipment, net |  |  | 667 |  |  |  | 602 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,965 |  |  |  | 2,488 |  |
| Other non-current assets |  |  | 1,538 |  |  |  | 991 |  |
| Total assets |  | $ | 9,710 |  |  | $ | 10,026 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 432 |  |  | $ | 607 |  |
| Accrued expenses |  |  | 835 |  |  |  | 925 |  |
| Current portion of long-term debt |  |  | — |  |  |  | 250 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 2,126 |  |  |  | 2,171 |  |
| Total current liabilities |  |  | 3,393 |  |  |  | 3,953 |  |
| Long-term debt |  |  | 2,388 |  |  |  | 2,386 |  |
| Other long-term liabilities |  |  | 737 |  |  |  | 788 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 2,090 |  |  |  | 2,061 |  |
| Total liabilities |  |  | 8,608 |  |  |  | 9,188 |  |
| Stockholders' equity |  |  | 1,102 |  |  |  | 838 |  |
| Total liabilities and stockholders' equity |  | $ | 9,710 |  |  | $ | 10,026 |  |

[0000950170-23-003745:8k_2_02:113]
NETAPP, INC.

[0000950170-23-003745:8k_2_02:114]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-23-003745:8k_2_02:115]
(In millions, except per share amounts)

[0000950170-23-003745:8k_2_02:116]
(Unaudited)

[0000950170-23-003745:8k_2_02:117]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | January 27, 2023 |  |  | January 28, 2022 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 682 |  |  | $ | 846 |  |  | $ | 2,305 |  |  | $ | 2,390 |  |
| Services |  |  | 844 |  |  |  | 768 |  |  |  | 2,476 |  |  |  | 2,248 |  |
| Net revenues |  |  | 1,526 |  |  |  | 1,614 |  |  |  | 4,781 |  |  |  | 4,638 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 367 |  |  |  | 407 |  |  |  | 1,182 |  |  |  | 1,108 |  |
| Cost of services |  |  | 158 |  |  |  | 134 |  |  |  | 465 |  |  |  | 399 |  |
| Total cost of revenues |  |  | 525 |  |  |  | 541 |  |  |  | 1,647 |  |  |  | 1,507 |  |
| Gross profit |  |  | 1,001 |  |  |  | 1,073 |  |  |  | 3,134 |  |  |  | 3,131 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 450 |  |  |  | 461 |  |  |  | 1,387 |  |  |  | 1,377 |  |
| Research and development |  |  | 230 |  |  |  | 220 |  |  |  | 713 |  |  |  | 646 |  |
| General and administrative |  |  | 59 |  |  |  | 65 |  |  |  | 198 |  |  |  | 207 |  |
| Restructuring charges |  |  | 87 |  |  |  | — |  |  |  | 109 |  |  |  | 29 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 6 |  |  |  | 18 |  |  |  | 8 |  |
| Total operating expenses |  |  | 829 |  |  |  | 752 |  |  |  | 2,425 |  |  |  | 2,267 |  |
| Income from operations |  |  | 172 |  |  |  | 321 |  |  |  | 709 |  |  |  | 864 |  |
| Other income (expense), net |  |  | 5 |  |  |  | (15 | ) |  |  | 43 |  |  |  | (41 | ) |
| Income before income taxes |  |  | 177 |  |  |  | 306 |  |  |  | 752 |  |  |  | 823 |  |
| Provision (benefit) for income taxes |  |  | 112 |  |  |  | 54 |  |  |  | (277 | ) |  |  | 145 |  |
| Net income |  | $ | 65 |  |  | $ | 252 |  |  | $ | 1,029 |  |  | $ | 678 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.30 |  |  | $ | 1.13 |  |  | $ | 4.72 |  |  | $ | 3.04 |  |
| Diluted |  | $ | 0.30 |  |  | $ | 1.10 |  |  | $ | 4.66 |  |  | $ | 2.96 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 216 |  |  |  | 223 |  |  |  | 218 |  |  |  | 223 |  |
| Diluted |  |  | 219 |  |  |  | 229 |  |  |  | 221 |  |  |  | 229 |  |

[0000950170-23-003745:8k_2_02:118]
NETAPP, INC.

[0000950170-23-003745:8k_2_02:119]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-23-003745:8k_2_02:120]
(In millions)

[0000950170-23-003745:8k_2_02:121]
(Unaudited)

[0000950170-23-003745:8k_2_02:122]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | January 27, 2023 |  |  | January 28, 2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 65 |  |  | $ | 252 |  |  | $ | 1,029 |  |  | $ | 678 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 65 |  |  |  | 51 |  |  |  | 182 |  |  |  | 143 |  |
| Non-cash operating lease cost |  |  | 13 |  |  |  | 12 |  |  |  | 40 |  |  |  | 40 |  |
| Stock-based compensation |  |  | 93 |  |  |  | 64 |  |  |  | 238 |  |  |  | 179 |  |
| Deferred income taxes |  |  | (7 | ) |  |  | (34 | ) |  |  | (577 | ) |  |  | (66 | ) |
| Other items, net |  |  | 58 |  |  |  | (23 | ) |  |  | (69 | ) |  |  | (35 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 112 |  |  |  | (155 | ) |  |  | 425 |  |  |  | 137 |  |
| Inventories |  |  | 69 |  |  |  | (12 | ) |  |  | 29 |  |  |  | (53 | ) |
| Accounts payable |  |  | (145 | ) |  |  | (1 | ) |  |  | (173 | ) |  |  | 10 |  |
| Accrued expenses |  |  | (9 | ) |  |  | (1 | ) |  |  | (117 | ) |  |  | (207 | ) |
| Deferred revenue and financed unearned services revenue |  |  | 46 |  |  |  | 143 |  |  |  | (47 | ) |  |  | 46 |  |
| Long-term taxes payable |  |  | 2 |  |  |  | (1 | ) |  |  | (82 | ) |  |  | (66 | ) |
| Changes in other operating assets and liabilities, net |  |  | 15 |  |  |  | (35 | ) |  |  | (6 | ) |  |  | (6 | ) |
| Net cash provided by operating activities |  |  | 377 |  |  |  | 260 |  |  |  | 872 |  |  |  | 800 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| (Purchases) redemptions of investments, net |  |  | (132 | ) |  |  | 10 |  |  |  | (474 | ) |  |  | 36 |  |
| Purchases of property and equipment |  |  | (58 | ) |  |  | (61 | ) |  |  | (200 | ) |  |  | (158 | ) |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | (345 | ) |  |  | (491 | ) |  |  | (359 | ) |
| Other investing activities, net |  |  | 1 |  |  |  | — |  |  |  | 60 |  |  |  | — |  |
| Net cash used in investing activities |  |  | (189 | ) |  |  | (396 | ) |  |  | (1,105 | ) |  |  | (481 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 54 |  |  |  | 52 |  |  |  | 108 |  |  |  | 105 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (11 | ) |  |  | (6 | ) |  |  | (74 | ) |  |  | (69 | ) |
| Repurchase of common stock |  |  | (200 | ) |  |  | (125 | ) |  |  | (700 | ) |  |  | (350 | ) |
| Repayments and extinguishment of debt |  |  | — |  |  |  | — |  |  |  | (250 | ) |  |  | — |  |
| Dividends paid |  |  | (108 | ) |  |  | (111 | ) |  |  | (326 | ) |  |  | (335 | ) |
| Other financing activities, net |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  | (2 | ) |
| Net cash used in financing activities |  |  | (265 | ) |  |  | (190 | ) |  |  | (1,244 | ) |  |  | (651 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 47 |  |  |  | (13 | ) |  |  | 4 |  |  |  | (26 | ) |
| Net change in cash, cash equivalents and restricted cash |  |  | (30 | ) |  |  | (339 | ) |  |  | (1,473 | ) |  |  | (358 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,676 |  |  |  | 4,516 |  |  |  | 4,119 |  |  |  | 4,535 |  |
| End of period |  | $ | 2,646 |  |  | $ | 4,177 |  |  | $ | 2,646 |  |  | $ | 4,177 |  |

[0000950170-23-003745:8k_2_02:123]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| Product |  | $ | 682 |  |  | $ | 837 |  |  | $ | 846 |  |
| Support |  |  | 616 |  |  |  | 607 |  |  |  | 586 |  |
| Professional and Other Services |  |  | 78 |  |  |  | 77 |  |  |  | 72 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,376 |  |  |  | 1,521 |  |  |  | 1,504 |  |
| Public Cloud Segment Net Revenues |  |  | 150 |  |  |  | 142 |  |  |  | 110 |  |
| Net Revenues |  | $ | 1,526 |  |  | $ | 1,663 |  |  | $ | 1,614 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| Product |  | $ | 317 |  |  | $ | 420 |  |  | $ | 442 |  |
| Support |  |  | 572 |  |  |  | 562 |  |  |  | 541 |  |
| Professional and Other Services |  |  | 28 |  |  |  | 23 |  |  |  | 26 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 917 |  |  |  | 1,005 |  |  |  | 1,009 |  |
| Public Cloud Segment Gross Profit |  |  | 103 |  |  |  | 97 |  |  |  | 78 |  |
| Total Segments Gross Profit |  |  | 1,020 |  |  |  | 1,102 |  |  |  | 1,087 |  |
| Amortization of Intangible Assets |  |  | (11 | ) |  |  | (10 | ) |  |  | (9 | ) |
| Stock-based Compensation |  |  | (8 | ) |  |  | (5 | ) |  |  | (5 | ) |
| Unallocated Cost of Revenues |  |  | (19 | ) |  |  | (15 | ) |  |  | (14 | ) |
| Gross Profit |  | $ | 1,001 |  |  | $ | 1,087 |  |  | $ | 1,073 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| Product |  |  | 46.5 | % |  |  | 50.2 | % |  |  | 52.2 | % |
| Support |  |  | 92.9 | % |  |  | 92.6 | % |  |  | 92.3 | % |
| Professional and Other Services |  |  | 35.9 | % |  |  | 29.9 | % |  |  | 36.1 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 66.6 | % |  |  | 66.1 | % |  |  | 67.1 | % |
| Public Cloud Segment Gross Margin |  |  | 68.7 | % |  |  | 68.3 | % |  |  | 70.9 | % |
| Product Revenues |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| Total |  | $ | 682 |  |  | $ | 837 |  |  | $ | 846 |  |
| Software* |  | $ | 390 |  |  | $ | 495 |  |  | $ | 507 |  |
| Hardware* |  | $ | 292 |  |  | $ | 342 |  |  | $ | 339 |  |
| Software and recurring support and public cloud revenue |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| Product - Software |  | $ | 390 |  |  | $ | 495 |  |  | $ | 507 |  |
| Support |  |  | 616 |  |  |  | 607 |  |  |  | 586 |  |
| Public Cloud |  |  | 150 |  |  |  | 142 |  |  |  | 110 |  |
| Software and recurring support and public cloud revenue* |  | $ | 1,156 |  |  | $ | 1,244 |  |  | $ | 1,203 |  |
| Software and recurring support and public cloud revenue as a percentage of net revenues |  |  | 76 | % |  |  | 75 | % |  |  | 75 | % |
| * Our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation. We have provided a breakdown of our GAAP product revenues into the software and hardware components, which are considered non-GAAP measures, to display the significance of software included in total product revenues. Software and recurring support and public cloud revenue is a non-GAAP measure because it includes the software component of our product revenues, but not the hardware component. |  |

[0000950170-23-003745:8k_2_02:124]
| Geographic Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'23 |  |  | % of Q2 FY'23 |  |  | % of Q3 FY'22 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 54 | % |  |  | 54 | % |  |  | 56 | % |
| Americas Commercial |  |  | 44 | % |  |  | 40 | % |  |  | 47 | % |
| U.S. Public Sector |  |  | 10 | % |  |  | 14 | % |  |  | 9 | % |
| EMEA |  |  | 32 | % |  |  | 32 | % |  |  | 32 | % |
| Asia Pacific |  |  | 14 | % |  |  | 14 | % |  |  | 12 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'23 |  |  | % of Q2 FY'23 |  |  | % of Q3 FY'22 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 22 | % |  |  | 23 | % |  |  | 21 | % |
| Indirect |  |  | 78 | % |  |  | 77 | % |  |  | 79 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| Non-GAAP Income from Operations |  | $ | 372 |  |  | $ | 393 |  |  | $ | 404 |  |
| % of Net Revenues |  |  | 24.4 | % |  |  | 23.6 | % |  |  | 25.0 | % |
| Non-GAAP Income before Income Taxes |  | $ | 377 |  |  | $ | 416 |  |  | $ | 389 |  |
| Non-GAAP Effective Tax Rate |  |  | 20.2 | % |  |  | 21.6 | % |  |  | 15.2 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| Non-GAAP Net Income |  | $ | 301 |  |  | $ | 326 |  |  | $ | 330 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 219 |  |  |  | 220 |  |  |  | 229 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.37 |  |  | $ | 1.48 |  |  | $ | 1.44 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 4,216 |  |  | $ | 4,051 |  |  | $ | 3,969 |  |
| DSO (days) |  |  | 49 |  |  |  | 50 |  |  |  | 45 |  |
| DPO (days) |  |  | 75 |  |  |  | 92 |  |  |  | 73 |  |
| Inventory Turns |  |  | 12 |  |  |  | 9 |  |  |  | 13 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| Net Cash Provided by Operating Activities |  | $ | 377 |  |  | $ | 214 |  |  | $ | 260 |  |
| Purchases of Property and Equipment |  | $ | 58 |  |  | $ | 77 |  |  | $ | 61 |  |
| Free Cash Flow |  | $ | 319 |  |  | $ | 137 |  |  | $ | 199 |  |
| Free Cash Flow as % of Net Revenues |  |  | 20.9 | % |  |  | 8.2 | % |  |  | 12.3 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0000950170-23-003745:8k_2_02:125]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| NET INCOME |  | $ | 65 |  |  | $ | 750 |  |  | $ | 252 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 17 |  |  |  | 17 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 93 |  |  |  | 78 |  |  |  | 64 |  |
| Restructuring charges |  |  | 87 |  |  |  | 11 |  |  |  | — |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 5 |  |  |  | 6 |  |
| Income tax effects |  |  | (33 | ) |  |  | (11 | ) |  |  | (5 | ) |
| Resolution of income tax matters |  |  | 69 |  |  |  | — |  |  |  | — |  |
| Income tax benefit from intra-entity intellectual property transfer |  |  | — |  |  |  | (524 | ) |  |  | — |  |
| NON-GAAP NET INCOME |  | $ | 301 |  |  | $ | 326 |  |  | $ | 330 |  |
| COST OF REVENUES |  | $ | 525 |  |  | $ | 576 |  |  | $ | 541 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (11 | ) |  |  | (10 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (8 | ) |  |  | (5 | ) |  |  | (5 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 506 |  |  | $ | 561 |  |  | $ | 527 |  |
| COST OF PRODUCT REVENUES |  | $ | 367 |  |  | $ | 418 |  |  | $ | 407 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | — |  |  |  | (2 | ) |
| Stock-based compensation |  |  | (2 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 365 |  |  | $ | 417 |  |  | $ | 404 |  |
| COST OF SERVICES REVENUES |  | $ | 158 |  |  | $ | 158 |  |  | $ | 134 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (11 | ) |  |  | (10 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (4 | ) |  |  | (4 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 141 |  |  | $ | 144 |  |  | $ | 123 |  |
| GROSS PROFIT |  | $ | 1,001 |  |  | $ | 1,087 |  |  | $ | 1,073 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 10 |  |  |  | 9 |  |
| Stock-based compensation |  |  | 8 |  |  |  | 5 |  |  |  | 5 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,020 |  |  | $ | 1,102 |  |  | $ | 1,087 |  |

[0000950170-23-003745:8k_2_02:126]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| SALES AND MARKETING EXPENSES |  | $ | 450 |  |  | $ | 479 |  |  | $ | 461 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (7 | ) |  |  | (4 | ) |
| Stock-based compensation |  |  | (40 | ) |  |  | (35 | ) |  |  | (30 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 404 |  |  | $ | 437 |  |  | $ | 427 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 230 |  |  | $ | 243 |  |  | $ | 220 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (32 | ) |  |  | (26 | ) |  |  | (19 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 198 |  |  | $ | 217 |  |  | $ | 201 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 59 |  |  | $ | 67 |  |  | $ | 65 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (13 | ) |  |  | (12 | ) |  |  | (10 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 46 |  |  | $ | 55 |  |  | $ | 55 |  |
| RESTRUCTURING CHARGES |  | $ | 87 |  |  | $ | 11 |  |  | $ | — |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (87 | ) |  |  | (11 | ) |  |  | — |  |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 3 |  |  | $ | 5 |  |  | $ | 6 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (3 | ) |  |  | (5 | ) |  |  | (6 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 829 |  |  | $ | 805 |  |  | $ | 752 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (7 | ) |  |  | (4 | ) |
| Stock-based compensation |  |  | (85 | ) |  |  | (73 | ) |  |  | (59 | ) |
| Restructuring charges |  |  | (87 | ) |  |  | (11 | ) |  |  | — |  |
| Acquisition-related expense |  |  | (3 | ) |  |  | (5 | ) |  |  | (6 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 648 |  |  | $ | 709 |  |  | $ | 683 |  |

[0000950170-23-003745:8k_2_02:127]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| INCOME FROM OPERATIONS |  | $ | 172 |  |  | $ | 282 |  |  | $ | 321 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 17 |  |  |  | 17 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 93 |  |  |  | 78 |  |  |  | 64 |  |
| Restructuring charges |  |  | 87 |  |  |  | 11 |  |  |  | — |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 5 |  |  |  | 6 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 372 |  |  | $ | 393 |  |  | $ | 404 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 177 |  |  | $ | 305 |  |  | $ | 306 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 17 |  |  |  | 17 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 93 |  |  |  | 78 |  |  |  | 64 |  |
| Restructuring charges |  |  | 87 |  |  |  | 11 |  |  |  | — |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 5 |  |  |  | 6 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 377 |  |  | $ | 416 |  |  | $ | 389 |  |
| PROVISION (BENEFIT) FOR INCOME TAXES |  | $ | 112 |  |  | $ | (445 | ) |  | $ | 54 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 33 |  |  |  | 11 |  |  |  | 5 |  |
| Resolution of income tax matters |  |  | (69 | ) |  |  | — |  |  |  | — |  |
| Income tax benefit from intra-entity intellectual property transfer |  |  | — |  |  |  | 524 |  |  |  | — |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 76 |  |  | $ | 90 |  |  | $ | 59 |  |
| NET INCOME PER SHARE |  | $ | 0.30 |  |  | $ | 3.41 |  |  | $ | 1.10 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.08 |  |  |  | 0.08 |  |  |  | 0.06 |  |
| Stock-based compensation |  |  | 0.42 |  |  |  | 0.35 |  |  |  | 0.28 |  |
| Restructuring charges |  |  | 0.40 |  |  |  | 0.05 |  |  |  | — |  |
| Acquisition-related expense |  |  | 0.01 |  |  |  | 0.02 |  |  |  | 0.03 |  |
| Income tax effects |  |  | (0.15 | ) |  |  | (0.05 | ) |  |  | (0.02 | ) |
| Resolution of income tax matters |  |  | 0.32 |  |  |  | — |  |  |  | — |  |
| Income tax benefit from intra-entity intellectual property transfer |  |  | — |  |  |  | (2.38 | ) |  |  | — |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.37 |  |  | $ | 1.48 |  |  | $ | 1.44 |  |

[0000950170-23-003745:8k_2_02:128]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| Gross margin-GAAP |  |  | 65.6 | % |  |  | 65.4 | % |  |  | 66.5 | % |
| Cost of revenues adjustments |  |  | 1.2 | % |  |  | 0.9 | % |  |  | 0.9 | % |
| Gross margin-Non-GAAP |  |  | 66.8 | % |  |  | 66.3 | % |  |  | 67.3 | % |
| GAAP cost of revenues |  | $ | 525 |  |  | $ | 576 |  |  | $ | 541 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (11 | ) |  |  | (10 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (8 | ) |  |  | (5 | ) |  |  | (5 | ) |
| Non-GAAP cost of revenues |  | $ | 506 |  |  | $ | 561 |  |  | $ | 527 |  |
| Net revenues |  | $ | 1,526 |  |  | $ | 1,663 |  |  | $ | 1,614 |  |

[0000950170-23-003745:8k_2_02:129]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| Product gross margin-GAAP |  |  | 46.2 | % |  |  | 50.1 | % |  |  | 51.9 | % |
| Cost of product revenues adjustments |  |  | 0.3 | % |  |  | 0.1 | % |  |  | 0.4 | % |
| Product gross margin-Non-GAAP |  |  | 46.5 | % |  |  | 50.2 | % |  |  | 52.2 | % |
| GAAP cost of product revenues |  | $ | 367 |  |  | $ | 418 |  |  | $ | 407 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | — |  |  |  | (2 | ) |
| Stock-based compensation |  |  | (2 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 365 |  |  | $ | 417 |  |  | $ | 404 |  |
| Product revenues |  | $ | 682 |  |  | $ | 837 |  |  | $ | 846 |  |

[0000950170-23-003745:8k_2_02:130]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| Services gross margin-GAAP |  |  | 81.3 | % |  |  | 80.9 | % |  |  | 82.6 | % |
| Cost of services revenues adjustments |  |  | 2.0 | % |  |  | 1.7 | % |  |  | 1.4 | % |
| Services gross margin-Non-GAAP |  |  | 83.3 | % |  |  | 82.6 | % |  |  | 84.0 | % |
| GAAP cost of services revenues |  | $ | 158 |  |  | $ | 158 |  |  | $ | 134 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (11 | ) |  |  | (10 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (4 | ) |  |  | (4 | ) |
| Non-GAAP cost of services revenues |  | $ | 141 |  |  | $ | 144 |  |  | $ | 123 |  |
| Services revenues |  | $ | 844 |  |  | $ | 826 |  |  | $ | 768 |  |

[0000950170-23-003745:8k_2_02:131]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| GAAP effective tax rate |  |  | 63.3 | % |  |  | (145.9 | )% |  |  | 17.6 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | (4.1 | )% |  |  | 41.6 | % |  |  | (2.5 | )% |
| Resolution of income tax matters |  |  | (39.0 | )% |  |  | — | % |  |  | — | % |
| Income tax benefit from intra-entity intellectual property transfer |  |  | — | % |  |  | 126.0 | % |  |  | — | % |
| Non-GAAP effective tax rate |  |  | 20.2 | % |  |  | 21.6 | % |  |  | 15.2 | % |

[0000950170-23-003745:8k_2_02:132]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| Net cash provided by operating activities |  | $ | 377 |  |  | $ | 214 |  |  | $ | 260 |  |
| Purchases of property and equipment |  |  | (58 | ) |  |  | (77 | ) |  |  | (61 | ) |
| Free cash flow |  | $ | 319 |  |  | $ | 137 |  |  | $ | 199 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q3'FY23 |  |  | Q2'FY23 |  |  | Q3'FY22 |  |
| Net revenues |  | $ | 1,526 |  |  | $ | 1,663 |  |  | $ | 1,614 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | 46 |  |  |  | (61 | ) |  |  | 143 |  |
| Billings |  | $ | 1,572 |  |  | $ | 1,602 |  |  | $ | 1,757 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0000950170-23-003745:8k_2_02:133]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FOURTH QUARTER FISCAL 2023 |
|  |  | Fourth Quarter |
|  |  | Fiscal 2023 |
| Non-GAAP Guidance - Net Income Per Share |  | $1.30-$1.40 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the Fourth Quarter Fiscal 2023: |  |  |
| Amortization of intangible assets |  | ($0.08) |
| Stock-based compensation expense |  | ($0.35) |
| Income tax effects |  | $0.05 |
| Total Adjustments |  | ($0.38) |
| GAAP Guidance - Net Income Per Share |  | $0.92-$1.02 |

[0000950170-23-003745:8k_2_02:134]
Some items may not add or recalculate due to rounding.

[0000950170-23-003745:8k_2_02:135]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| FISCAL 2023 |
|  |  | Fiscal 2023 |
| Gross Margin - Non-GAAP Guidance |  | 66% - 67% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | (1)% |
| Gross Margin - GAAP Guidance |  | 65% - 66% |
|  |  | Fiscal 2023 |
| Operating Margin - Non-GAAP Guidance |  | 23% - 24% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | (1)% |
| Stock-based compensation expense |  | (5)% |
| Restructuring charges |  | (2)% |
| Operating Margin - GAAP Guidance |  | 15% - 16% |

[0000950170-23-003745:8k_2_02:136]
Some items may not add or recalculate due to rounding.

[0000950170-23-003745:8k_2_02:137]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FISCAL 2023 |
|  |  | Fiscal 2023 |
| Non-GAAP Guidance - Net Income Per Share |  | $5.30 - $5.50 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2023: |  |  |
| Amortization of intangible assets |  | ($0.31) |
| Stock-based compensation expense |  | ($1.43) |
| Restructuring charges |  | ($0.49) |
| Acquisition-related expenses |  | ($0.08) |
| Gain on sale of equity investment |  | $0.15 |
| Resolution of income tax matters |  | ($0.31) |
| Income tax benefit from intra-entity intellectual property transfer |  | $2.38 |
| Income tax effects |  | $0.27 |
| Total Adjustments |  | $0.18 |
| GAAP Guidance - Net Income Per Share |  | $5.48 - $5.68 |

[0000950170-23-003745:8k_2_02:138]
Some items may not add or recalculate due to rounding.

[0000950170-23-003745:8k_2_02:139]
Contacts:

[0000950170-23-003745:8k_2_02:140]
(Press)

[0000950170-23-003745:8k_2_02:141]
Chris Drago

[0000950170-23-003745:8k_2_02:142]
1 831 900 8889

[0000950170-23-003745:8k_2_02:143]
chris.drago@netapp.com

[0000950170-23-003745:8k_2_02:144]
(Investors)

[0000950170-23-003745:8k_2_02:145]
Kris Newton

[0000950170-23-003745:8k_2_02:146]
1 408 822 3312

[0000950170-23-003745:8k_2_02:147]
kris.newton@netapp.com
