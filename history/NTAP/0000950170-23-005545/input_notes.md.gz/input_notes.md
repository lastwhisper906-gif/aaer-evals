# NTAP notes — 0000950170-23-005545


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000950170-23-005545:notes:1]
[same as prior period, unchanged from 0000950170-22-025960:notes:1]

[0000950170-23-005545:notes:2]
[same as prior period, unchanged from 0000950170-22-025960:notes:2]

[0000950170-23-005545:notes:3]
[same as prior period, unchanged from 0000950170-22-025960:notes:3]

[0000950170-23-005545:notes:4]
[same as prior period, unchanged from 0000950170-22-025960:notes:4]

[0000950170-23-005545:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2022 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 27, 2023 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0000950170-23-005545:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; valuation of intellectual property; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates. Management’s estimates include, as applicable, the anticipated impacts of the COVID-19 pandemic.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000950170-23-005545:notes:7]
2. Recent Accounting Pronouncements

[0000950170-23-005545:notes:8]
Although there are new accounting pronouncements issued or proposed by the FASB that we have adopted or will adopt, as applicable, we do not believe any of these accounting pronouncements had or will have a material impact on our consolidated financial position, operating results, cash flows or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-23-005545:notes:9]
[same as prior period, unchanged from 0000950170-22-025960:notes:9]

[0000950170-23-005545:notes:10]
[same as prior period, unchanged from 0000950170-22-025960:notes:10]

[0000950170-23-005545:notes:11]
[same as prior period, unchanged from 0000950170-22-025960:notes:11]

[0000950170-23-005545:notes:12]
On May 20, 2022, we acquired all the outstanding shares of privately-held Instaclustr US Holding, Inc. (Instaclustr) for approximately $498 million. Instaclustr is a leading platform provider of fully managed open-source database, pipeline and workflow applications delivered as-a-service.

[0000950170-23-005545:notes:13]
[same as prior period, unchanged from 0000950170-22-025960:notes:13]

[0000950170-23-005545:notes:14]
[same as prior period, unchanged from 0000950170-22-025960:notes:14]

[0000950170-23-005545:notes:15]
[same as prior period, unchanged from 0000950170-22-025960:notes:15]

[0000950170-23-005545:notes:16]
[same as prior period, unchanged from 0000950170-22-025960:notes:16]

[0000950170-23-005545:notes:17]
[same as prior period, unchanged from 0000950170-22-025960:notes:17]

[0000950170-23-005545:notes:18]
[same as prior period, unchanged from 0000950170-22-025960:notes:18]

[0000950170-23-005545:notes:19]
[same as prior period, unchanged from 0000950170-22-025960:notes:19]

[0000950170-23-005545:notes:20]
[same as prior period, unchanged from 0000950170-22-025960:notes:20]

[0000950170-23-005545:notes:21]
On February 18, 2022, we acquired all the outstanding shares of privately-held NeurOps Inc. (which operated under the name "Fylamynt") for approximately $27 million in cash, of which $22 million was paid at closing. The purchase price includes $5 million related to an indemnity holdback provision, of which $4 million was paid in the fourth quarter of fiscal 2023. Fylamynt is an innovative CloudOps automation technology company that enables customers to build, run, manage and analyze workflows securely in any cloud with little to no code.

[0000950170-23-005545:notes:22]
[same as prior period, unchanged from 0000950170-22-025960:notes:22]

[0000950170-23-005545:notes:23]
[same as prior period, unchanged from 0000950170-22-025960:notes:23]

[0000950170-23-005545:notes:24]
[same as prior period, unchanged from 0000950170-22-025960:notes:24]

[0000950170-23-005545:notes:25]
[same as prior period, unchanged from 0000950170-22-025960:notes:25]

[0000950170-23-005545:notes:26]
[same as prior period, unchanged from 0000950170-22-025960:notes:26]

[0000950170-23-005545:notes:27]
[same as prior period, unchanged from 0000950170-22-025960:notes:27]

[0000950170-23-005545:notes:28]
[same as prior period, unchanged from 0000950170-22-025960:notes:28]

[0000950170-23-005545:notes:29]
[same as prior period, unchanged from 0000950170-22-025960:notes:29]

[0000950170-23-005545:notes:30]
[same as prior period, unchanged from 0000950170-22-025960:notes:30]

[0000950170-23-005545:notes:31]
[same as prior period, unchanged from 0000950170-22-025960:notes:31]

[0000950170-23-005545:notes:32]
[same as prior period, unchanged from 0000950170-22-025960:notes:32]

[0000950170-23-005545:notes:33]
[same as prior period, unchanged from 0000950170-22-025960:notes:33]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-23-005545:notes:34]
[same as prior period, unchanged from 0000950170-22-025960:notes:34]

[0000950170-23-005545:notes:35]
[same as prior period, unchanged from 0000950170-22-025960:notes:35]

[0000950170-23-005545:notes:36]
|  |  | Amount |  |
| Balance as of April 29, 2022 |  | $ | 2,346 |  |
| Additions |  |  | 421 |  |
| Balance as of January 27, 2023 |  | $ | 2,767 |  |

[0000950170-23-005545:notes:37]
[same as prior period, unchanged from 0000950170-22-025960:notes:37]

[0000950170-23-005545:notes:38]
Goodwill by reportable segment as of January 27, 2023 is as follows (in millions):

[0000950170-23-005545:notes:39]
[same as prior period, unchanged from 0000950170-22-025960:notes:39]

[0000950170-23-005545:notes:40]
[same as prior period, unchanged from 0000950170-22-025960:notes:40]

[0000950170-23-005545:notes:41]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 212 |  |  | $ | (97 | ) |  | $ | 115 |  |  | $ | 157 |  |  | $ | (65 | ) |  | $ | 92 |  |
| Customer contracts/relationships |  |  | 118 |  |  |  | (38 | ) |  |  | 80 |  |  |  | 68 |  |  |  | (20 | ) |  |  | 48 |  |
| Other purchased intangibles |  |  | 6 |  |  |  | (3 | ) |  |  | 3 |  |  |  | 4 |  |  |  | (2 | ) |  |  | 2 |  |
| Total purchased intangible assets |  | $ | 336 |  |  | $ | (138 | ) |  | $ | 198 |  |  | $ | 229 |  |  | $ | (87 | ) |  | $ | 142 |  |

[0000950170-23-005545:notes:42]
[same as prior period, unchanged from 0000950170-22-025960:notes:42]

[0000950170-23-005545:notes:43]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Statements of |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | IncomeClassification |
| Developed technology |  | $ | 10 |  |  | $ | 9 |  |  | $ | 31 |  |  | $ | 23 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 7 |  |  |  | 4 |  |  |  | 19 |  |  |  | 7 |  |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 2 |  |  | Operating expenses |
| Total |  | $ | 17 |  |  | $ | 13 |  |  | $ | 51 |  |  | $ | 32 |  |  |  |

[0000950170-23-005545:notes:44]
As of January 27, 2023, future amortization expense related to purchased intangible assets is as follows (in millions):

[0000950170-23-005545:notes:45]
| Fiscal Year |  | Amount |  |
| 2023 (remainder) |  | $ | 17 |  |
| 2024 |  |  | 57 |  |
| 2025 |  |  | 55 |  |
| 2026 |  |  | 39 |  |
| 2027 |  |  | 29 |  |
| 2028 |  |  | 1 |  |
| Total |  | $ | 198 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0000950170-23-005545:notes:46]
The
Goodwill by reportable segment as of January 27, 2023 is as follows (in millions):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-23-005545:notes:47]
[same as prior period, unchanged from 0000950170-22-025960:notes:47]

[0000950170-23-005545:notes:48]
[same as prior period, unchanged from 0000950170-22-025960:notes:48]

[0000950170-23-005545:notes:49]
[same as prior period, unchanged from 0000950170-22-025960:notes:49]

[0000950170-23-005545:notes:50]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| Cash and cash equivalents |  | $ | 2,640 |  |  | $ | 4,112 |  |
| Restricted cash |  |  | 6 |  |  |  | 7 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,646 |  |  | $ | 4,119 |  |

[0000950170-23-005545:notes:51]
[same as prior period, unchanged from 0000950170-22-025960:notes:51]

[0000950170-23-005545:notes:52]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| Purchased components |  | $ | 84 |  |  | $ | 131 |  |
| Finished goods |  |  | 91 |  |  |  | 73 |  |
| Inventories |  | $ | 175 |  |  | $ | 204 |  |

[0000950170-23-005545:notes:53]
[same as prior period, unchanged from 0000950170-22-025960:notes:53]

[0000950170-23-005545:notes:54]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 357 |  |  |  | 353 |  |
| Leasehold improvements |  |  | 93 |  |  |  | 92 |  |
| Computer, production, engineering and other equipment |  |  | 1,050 |  |  |  | 904 |  |
| Computer software |  |  | 329 |  |  |  | 316 |  |
| Furniture and fixtures |  |  | 86 |  |  |  | 76 |  |
| Construction-in-progress |  |  | 51 |  |  |  | 65 |  |
|  |  |  | 2,012 |  |  |  | 1,852 |  |
| Accumulated depreciation and amortization |  |  | (1,345 | ) |  |  | (1,250 | ) |
| Property and equipment, net |  | $ | 667 |  |  | $ | 602 |  |

[0000950170-23-005545:notes:55]
[same as prior period, unchanged from 0000950170-22-025960:notes:55]

[0000950170-23-005545:notes:56]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| Deferred tax assets |  | $ | 938 |  |  | $ | 362 |  |
| Operating lease ROU assets |  |  | 289 |  |  |  | 294 |  |
| Other assets |  |  | 311 |  |  |  | 335 |  |
| Other non-current assets |  | $ | 1,538 |  |  | $ | 991 |  |

[0000950170-23-005545:notes:57]
Other non-current assets as of January 27, 2023 and April 29, 2022 include $79 million and $73 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies. Our sales to LNTL are conducted on terms equivalent to those prevailing in an arm’s length transaction.

[0000950170-23-005545:notes:58]
[same as prior period, unchanged from 0000950170-22-025960:notes:58]

[0000950170-23-005545:notes:59]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| Accrued compensation and benefits |  | $ | 341 |  |  | $ | 462 |  |
| Product warranty liabilities |  |  | 17 |  |  |  | 17 |  |
| Operating lease liabilities |  |  | 48 |  |  |  | 47 |  |
| Other current liabilities |  |  | 429 |  |  |  | 399 |  |
| Accrued expenses |  | $ | 835 |  |  | $ | 925 |  |

[0000950170-23-005545:notes:60]
[same as prior period, unchanged from 0000950170-22-025960:notes:60]

[0000950170-23-005545:notes:61]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| Liability for uncertain tax positions |  | $ | 141 |  |  | $ | 131 |  |
| Income taxes payable |  |  | 215 |  |  |  | 303 |  |
| Product warranty liabilities |  |  | 8 |  |  |  | 9 |  |
| Operating lease liabilities |  |  | 254 |  |  |  | 257 |  |
| Other liabilities |  |  | 119 |  |  |  | 88 |  |
| Other long-term liabilities |  | $ | 737 |  |  | $ | 788 |  |

[0000950170-23-005545:notes:62]
[same as prior period, unchanged from 0000950170-22-025960:notes:62]

[0000950170-23-005545:notes:63]
[same as prior period, unchanged from 0000950170-22-025960:notes:63]

[0000950170-23-005545:notes:64]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| Deferred product revenue |  | $ | 21 |  |  | $ | 31 |  |
| Deferred services revenue |  |  | 4,146 |  |  |  | 4,140 |  |
| Financed unearned services revenue |  |  | 49 |  |  |  | 61 |  |
| Total |  | $ | 4,216 |  |  | $ | 4,232 |  |
| Reported as: |  |  |  |  |  |  |
| Short-term |  | $ | 2,126 |  |  | $ | 2,171 |  |
| Long-term |  |  | 2,090 |  |  |  | 2,061 |  |
| Total |  | $ | 4,216 |  |  | $ | 4,232 |  |

[0000950170-23-005545:notes:65]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 15 – Commitments and Contingencies for additional information related to these arrangements.

[0000950170-23-005545:notes:66]
During the nine months ended January 27, 2023, we recognized revenue of $1,751 million that was included in the deferred revenue and financed unearned services revenue balance as of April 29, 2022.

[0000950170-23-005545:notes:67]
As of January 27, 2023, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied approximated our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as

[0000950170-23-005545:notes:68]
revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 24% in the next 13 to 24 months, and the remainder thereafter.

[0000950170-23-005545:notes:69]
[same as prior period, unchanged from 0000950170-22-025960:notes:69]

[0000950170-23-005545:notes:70]
[same as prior period, unchanged from 0000950170-22-025960:notes:70]

[0000950170-23-005545:notes:71]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| Other current assets |  | $ | 67 |  |  | $ | 80 |  |
| Other non-current assets |  |  | 103 |  |  |  | 117 |  |
| Total deferred commissions |  | $ | 170 |  |  | $ | 197 |  |

[0000950170-23-005545:notes:72]
[same as prior period, unchanged from 0000950170-22-025960:notes:72]

[0000950170-23-005545:notes:73]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | January 27, 2023 |  |  | January 28, 2022 |  |
| Interest income |  | $ | 21 |  |  | $ | 2 |  |  | $ | 42 |  |  | $ | 5 |  |
| Interest expense |  |  | (16 | ) |  |  | (19 | ) |  |  | (51 | ) |  |  | (55 | ) |
| Other, net |  |  | — |  |  |  | 2 |  |  |  | 52 |  |  |  | 9 |  |
| Total other income (expense), net |  | $ | 5 |  |  | $ | (15 | ) |  | $ | 43 |  |  | $ | (41 | ) |

[0000950170-23-005545:notes:74]
In the nine months ended January 27, 2023, Other, net includes $21 million of other income for non-refundable, up-front payments from customers in Russia for support contracts, which we were not able to fulfill due to imposed sanctions and for which we have no remaining legal obligation to perform. Other, net also includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million in the first quarter of fiscal 2023.

[0000950170-23-005545:notes:75]
[same as prior period, unchanged from 0000950170-22-025960:notes:75]

[0000950170-23-005545:notes:76]
[same as prior period, unchanged from 0000950170-22-025960:notes:76]

[0000950170-23-005545:notes:77]
|  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 19 |  |  | $ | 24 |  |  |  |
| Liabilities incurred to former owners of acquired business |  | $ | 3 |  |  | $ | — |  |  |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 290 |  |  | $ | 318 |  |  |  |
| Interest paid |  | $ | 59 |  |  | $ | 61 |  |  |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-23-005545:notes:78]
[same as prior period, unchanged from 0000950170-22-025960:notes:78]

[0000950170-23-005545:notes:79]
[same as prior period, unchanged from 0000950170-22-025960:notes:79]

[0000950170-23-005545:notes:80]
[same as prior period, unchanged from 0000950170-22-025960:notes:80]

[0000950170-23-005545:notes:81]
[same as prior period, unchanged from 0000950170-22-025960:notes:81]

[0000950170-23-005545:notes:82]
[same as prior period, unchanged from 0000950170-22-025960:notes:82]

[0000950170-23-005545:notes:83]
[same as prior period, unchanged from 0000950170-22-025960:notes:83]

[0000950170-23-005545:notes:84]
[same as prior period, unchanged from 0000950170-22-025960:notes:84]

[0000950170-23-005545:notes:85]
The following is a summary of our investments at their cost or amortized cost for the periods ended January 27, 2023 and April 29, 2022 (in millions):

[0000950170-23-005545:notes:86]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |  |
| Corporate bonds |  | $ | — |  |  | $ | 9 |  |  |
| U.S. Treasury and government debt securities |  |  | 501 |  |  |  | 13 |  |  |
| Money market funds |  |  | 730 |  |  |  | 2,166 |  |  |
| Certificates of deposit |  |  | 50 |  |  |  | 71 |  |  |
| Mutual funds |  |  | 37 |  |  |  | 36 |  |  |
| Total debt and equity securities |  | $ | 1,318 |  |  | $ | 2,295 |  |  |

[0000950170-23-005545:notes:87]
[same as prior period, unchanged from 0000950170-22-025960:notes:87]

[0000950170-23-005545:notes:88]
As of January 27, 2023, all our debt investments are due to mature in one year or less.

[0000950170-23-005545:notes:89]
[same as prior period, unchanged from 0000950170-22-025960:notes:89]

[0000950170-23-005545:notes:90]
[same as prior period, unchanged from 0000950170-22-025960:notes:90]

[0000950170-23-005545:notes:91]
|  |  | January 27, 2023 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 1,860 |  |  | $ | 1,860 |  |  | $ | — |  |
| Money market funds |  |  | 730 |  |  |  | 730 |  |  |  | — |  |
| Certificates of deposit |  |  | 50 |  |  |  | — |  |  |  | 50 |  |
| Total cash and cash equivalents |  |  | 2,640 |  |  |  | 2,590 |  |  |  | 50 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 501 |  |  |  | 501 |  |  |  | — |  |
| Total short-term investments |  |  | 501 |  |  |  | 501 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,141 |  |  | $ | 3,091 |  |  | $ | 50 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 31 |  |  | $ | 31 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |

[0000950170-23-005545:notes:92]
[same as prior period, unchanged from 0000950170-22-025960:notes:92]

[0000950170-23-005545:notes:93]
[same as prior period, unchanged from 0000950170-22-025960:notes:93]

[0000950170-23-005545:notes:94]
[same as prior period, unchanged from 0000950170-22-025960:notes:94]

[0000950170-23-005545:notes:95]
[same as prior period, unchanged from 0000950170-22-025960:notes:95]

[0000950170-23-005545:notes:96]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of January 27, 2023 and April 29, 2022, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0000950170-23-005545:notes:97]
[same as prior period, unchanged from 0000950170-22-025960:notes:97]

[0000950170-23-005545:notes:98]
As of January 27, 2023 and April 29, 2022, the fair value of our long-term debt was approximately $2,189 million and $2,491 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0000950170-23-005545:notes:99]
7. Financing Arrangements

[0000950170-23-005545:notes:100]
Long-Term Debt

[0000950170-23-005545:notes:101]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0000950170-23-005545:notes:102]
|  |  | Effective Interest Rate |  | January 27, 2023 |  |  | April 29, 2022 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | — |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,400 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (12 | ) |  |  | (14 | ) |
| Total senior notes |  |  |  |  | 2,388 |  |  |  | 2,636 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (250 | ) |
| Total long-term debt |  |  |  | $ | 2,388 |  |  | $ | 2,386 |  |

[0000950170-23-005545:notes:103]
Senior Notes

[0000950170-23-005545:notes:104]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were each issued in June 2020. Interest on each of these Senior Notes is payable semi-annually in June and December. Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September.

[0000950170-23-005545:notes:105]
On September 15, 2022, we extinguished our 3.25% Senior Notes due December 2022 for an aggregate cash redemption price of $252 million, comprised of the principal and unpaid interest.

[0000950170-23-005545:notes:106]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0000950170-23-005545:notes:107]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 27, 2023, we were in compliance with all covenants associated with the Senior Notes.

[0000950170-23-005545:notes:108]
As of January 27, 2023, our aggregate future principal debt maturities are as follows (in millions):

[0000950170-23-005545:notes:109]
| Fiscal Year |  | Amount |  |
| 2023 (remainder) |  | $ | — |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| 2027 |  |  | — |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,400 |  |

[0000950170-23-005545:notes:110]
Commercial Paper Program and Credit Facility

[0000950170-23-005545:notes:111]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of January 27, 2023 or April 29, 2022.

[0000950170-23-005545:notes:112]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in January 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 27, 2023, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0000950170-23-005545:notes:113]
[same as prior period, unchanged from 0000950170-22-025960:notes:114]

[0000950170-23-005545:notes:114]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of January 27, 2023, have remaining lease terms not exceeding 19 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of January 27, 2023, have remaining lease terms not exceeding 4 years. As of January 27, 2023, our automobile leases have remaining lease terms not exceeding 4 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0000950170-23-005545:notes:115]
[same as prior period, unchanged from 0000950170-22-025960:notes:116]

[0000950170-23-005545:notes:116]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | January 27, 2023 |  |  | January 28, 2022 |  |
| Operating lease cost |  | $ | 15 |  |  | $ | 15 |  |  | $ | 46 |  |  | $ | 46 |  |
| Variable lease cost |  |  | 4 |  |  |  | 3 |  |  |  | 12 |  |  |  | 11 |  |
| Total lease cost |  | $ | 19 |  |  | $ | 18 |  |  | $ | 58 |  |  | $ | 57 |  |

[0000950170-23-005545:notes:117]
[same as prior period, unchanged from 0000950170-22-025960:notes:118]

[0000950170-23-005545:notes:118]
[same as prior period, unchanged from 0000950170-22-025960:notes:119]

[0000950170-23-005545:notes:119]
|  |  |  |  | Nine Months Ended |  |
|  |  |  |  |  |  | January 27, 2023 |  |  | January 28, 2022 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  |  |  |  |  | $ | 41 |  |  | $ | 41 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  |  |  |  |  | $ | 33 |  |  | $ | 236 |  |

[0000950170-23-005545:notes:120]
[same as prior period, unchanged from 0000950170-22-025960:notes:121]

[0000950170-23-005545:notes:121]
|  |  |  |  |  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| Other non-current assets |  |  |  |  |  | $ | 289 |  |  | $ | 294 |  |
| Total operating lease ROU assets |  |  |  |  |  | $ | 289 |  |  | $ | 294 |  |
| Accrued expenses |  |  |  |  |  | $ | 48 |  |  | $ | 47 |  |
| Other long-term liabilities |  |  |  |  |  |  | 254 |  |  |  | 257 |  |
| Total operating lease liabilities |  |  |  |  |  | $ | 302 |  |  | $ | 304 |  |
| Weighted Average Remaining Lease Term |  |  |  |  |  | 9.5 years |  |  | 9.6 years |  |
| Weighted Average Discount Rate |  |  |  |  |  |  | 2.9 | % |  |  | 2.8 | % |

[0000950170-23-005545:notes:122]
Future minimum operating lease payments as of January 27, 2023, are as follows (in millions):

[0000950170-23-005545:notes:123]
| Fiscal Year |  |  |  |  |  | Amount |  |
| 2023 (remainder) |  |  |  |  |  | $ | 14 |  |
| 2024 |  |  |  |  |  |  | 51 |  |
| 2025 |  |  |  |  |  |  | 41 |  |
| 2026 |  |  |  |  |  |  | 36 |  |
| 2027 |  |  |  |  |  |  | 32 |  |
| Thereafter |  |  |  |  |  |  | 176 |  |
| Total lease payments |  |  |  |  |  |  | 350 |  |
| Less: Interest |  |  |  |  |  |  | (48 | ) |
| Total |  |  |  |  |  | $ | 302 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000950170-23-005545:notes:124]
[same as prior period, unchanged from 0000950170-22-025960:notes:125]

[0000950170-23-005545:notes:125]
[same as prior period, unchanged from 0000950170-22-025960:notes:126]

[0000950170-23-005545:notes:126]
We granted approximately 7 million restricted stock units (RSUs) with a weighted average grant date fair value of $59.80 per share, including performance-based RSUs (PBRSUs), during the nine months ended January 27, 2023. In the nine months ended January 27, 2023, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSUs cliff-vest at the end of an approximate one, two or three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the first, second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle most of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the nine months ended January 27, 2023, the number of shares issued will depend upon

[0000950170-23-005545:notes:127]
our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. The fair values of these TSR performance-based awards were fixed at grant date using a Monte Carlo simulation model. For the remaining half of the PBRSUs granted in the nine months ended January 27, 2023, the number of shares issued will depend upon the Company's billings result average over the three-year performance period as compared to a predetermined billings target. Billings for purposes of measuring the performance of these PBRSUs means the total obtained by adding net revenues as reported on the Company's Consolidated Statements of Income to the amount reported as the change in deferred revenue and financed unearned services revenue on the Consolidated Statements of Cash Flows for the applicable measurement period, excluding the impact of fluctuations in foreign currency exchange rates. The fair values of these billings PBRSUs were established consistent with our methodology for valuing time-based RSUs, while compensation cost is being recognized based on the probable outcome of the performance condition. The aggregate grant date fair value of PBRSUs effectively granted in the current year was $27 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0000950170-23-005545:notes:128]
[same as prior period, unchanged from 0000950170-22-025960:notes:129]

[0000950170-23-005545:notes:129]
[same as prior period, unchanged from 0000950170-22-025960:notes:130]

[0000950170-23-005545:notes:130]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | January 27, 2023 |  |  | January 28, 2022 |  |
| Cost of product revenues |  | $ | 2 |  |  | $ | 1 |  |  | $ | 4 |  |  | $ | 3 |  |
| Cost of services revenues |  |  | 6 |  |  |  | 4 |  |  |  | 14 |  |  |  | 10 |  |
| Sales and marketing |  |  | 40 |  |  |  | 30 |  |  |  | 103 |  |  |  | 85 |  |
| Research and development |  |  | 32 |  |  |  | 19 |  |  |  | 82 |  |  |  | 53 |  |
| General and administrative |  |  | 13 |  |  |  | 10 |  |  |  | 35 |  |  |  | 28 |  |
| Total stock-based compensation expense |  | $ | 93 |  |  | $ | 64 |  |  | $ | 238 |  |  | $ | 179 |  |

[0000950170-23-005545:notes:131]
As of January 27, 2023, total unrecognized compensation expense related to our equity awards was $704 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.3 years.

[0000950170-23-005545:notes:132]
[same as prior period, unchanged from 0000950170-22-025960:notes:133]

[0000950170-23-005545:notes:133]
As of January 27, 2023, our Board of Directors has authorized the repurchase of up to $15.1 billion of our common stock. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time.

[0000950170-23-005545:notes:134]
The following table summarizes activity related to the stock repurchase program for the nine months ended January 27, 2023 (in millions, except for per share amounts):

[0000950170-23-005545:notes:135]
| Number of shares repurchased |  |  | 10 |  |
| Average price per share |  | $ | 66.93 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 37 |  |
| Stock repurchases allocated to retained earnings |  | $ | 663 |  |
| Remaining authorization at end of period |  | $ | 552 |  |

[0000950170-23-005545:notes:136]
Since the May 13, 2003 inception of our stock repurchase program through January 27, 2023, we repurchased a total of 358 million shares of our common stock at an average price of $40.74 per share, for an aggregate purchase price of $14.6 billion.

[0000950170-23-005545:notes:137]
[same as prior period, unchanged from 0000950170-22-025960:notes:138]

[0000950170-23-005545:notes:138]
[same as prior period, unchanged from 0000950170-22-025960:notes:139]

[0000950170-23-005545:notes:139]
|  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |
| Dividends per share declared |  | $ | 1.50 |  |  | $ | 1.50 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 106 |  |  | $ | — |  |
| Dividend payments allocated to retained earnings |  | $ | 220 |  |  | $ | 335 |  |

[0000950170-23-005545:notes:140]
On February 17, 2023, we declared a cash dividend of $0.50 per share of common stock, payable on April 26, 2023 to holders of record as of the close of business on April 6, 2023. The timing and amount of future dividends will depend on market conditions,

[0000950170-23-005545:notes:141]
corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0000950170-23-005545:notes:142]
[same as prior period, unchanged from 0000950170-22-025960:notes:142]

[0000950170-23-005545:notes:143]
[same as prior period, unchanged from 0000950170-22-025960:notes:143]

[0000950170-23-005545:notes:144]
|  |  | ForeignCurrencyTranslationAdjustments |  |  | DefinedBenefitObligationAdjustments |  |  | UnrealizedGains(Losses) onDerivativeInstruments |  |  | Total |  |
| Balance as of April 29, 2022 |  | $ | (44 | ) |  | $ | (1 | ) |  | $ | 1 |  |  | $ | (44 | ) |
| Other comprehensive loss, net of tax |  |  | (6 | ) |  |  | — |  |  |  | (7 | ) |  |  | (13 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | 2 |  |
| Total other comprehensive loss |  |  | (6 | ) |  |  | — |  |  |  | (5 | ) |  |  | (11 | ) |
| Balance as of January 27, 2023 |  | $ | (50 | ) |  | $ | (1 | ) |  | $ | (4 | ) |  | $ | (55 | ) |

[0000950170-23-005545:notes:145]
[same as prior period, unchanged from 0000950170-22-025960:notes:145]

[0000950170-23-005545:notes:146]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | Statements ofIncome Classification |
| Realized gains (losses) on cash flow hedges |  | $ | 6 |  |  | $ | (4 | ) |  | $ | 2 |  |  | $ | (5 | ) |  | Net revenues |
| Total reclassifications |  | $ | 6 |  |  | $ | (4 | ) |  | $ | 2 |  |  | $ | (5 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-23-005545:notes:147]
[same as prior period, unchanged from 0000950170-22-025960:notes:147]

[0000950170-23-005545:notes:148]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of January 27, 2023 or April 29, 2022. All contracts have a maturity of less than 12 months.

[0000950170-23-005545:notes:149]
[same as prior period, unchanged from 0000950170-22-025960:notes:149]

[0000950170-23-005545:notes:150]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 156 |  |  | $ | 78 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 799 |  |  | $ | 841 |  |
| Forward contracts purchased |  | $ | 92 |  |  | $ | 129 |  |

[0000950170-23-005545:notes:151]
[same as prior period, unchanged from 0000950170-22-025960:notes:151]

[0000950170-23-005545:notes:152]
[same as prior period, unchanged from 0000950170-22-025960:notes:152]

[0000950170-23-005545:notes:153]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | January 27, 2023 |  |  | January 28, 2022 |  |
| Foreign currency exchange contracts |  | $ | 58 |  |  | $ | (20 | ) |  | $ | 2 |  |  | $ | (46 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-23-005545:notes:154]
[same as prior period, unchanged from 0000950170-22-025960:notes:154]

[0000950170-23-005545:notes:155]
During the third quarter of fiscal 2023, management approved a restructuring plan to redirect resources to highest return activities and reduce costs. As a result, we recorded restructuring charges in the third quarter comprised of employee severance-related expenses. This plan will reduce our global workforce by approximately 8% and activities under this plan are expected to be substantially complete by the end of fiscal 2023.

[0000950170-23-005545:notes:156]
In the first six months of fiscal 2023, we executed a restructuring plan to redirect resources to highest return activities, which included a reduction in our global workforce of approximately 1% and resulted in restructuring charges comprised primarily of employee severance-related costs. Activities under this plan are substantially complete.

[0000950170-23-005545:notes:157]
We also continued activities related to the establishment of an international headquarters in Cork, Ireland, during the first nine months of fiscal 2023, and incurred restructuring charges consisting primarily of severance-related costs and legal and tax-related professional fees. Activities under this plan, for which we expect to incur additional charges, will continue during the remainder of fiscal 2023.

[0000950170-23-005545:notes:158]
During the first nine months of fiscal 2022, we executed a restructuring plan to reduce the amount of office space we occupied as we allow more employees to work remotely. In connection with the plan, we also reduced our global workforce by approximately 1%. Charges related to the plan consisted primarily of office relocation costs, lease termination fees, and employee severance-related costs. Substantially all activities under the plan had been completed by the end of fiscal 2022.

[0000950170-23-005545:notes:159]
[same as prior period, unchanged from 0000950170-22-025960:notes:158]

[0000950170-23-005545:notes:160]
|  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |
| Balance at beginning of period |  | $ | 3 |  |  | $ | 1 |  |
| Net charges |  |  | 109 |  |  |  | 29 |  |
| Cash payments |  |  | (22 | ) |  |  | (30 | ) |
| Balance at end of period |  | $ | 90 |  |  | $ | — |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-005545:notes:161]
[same as prior period, unchanged from 0000950170-22-025960:notes:160]

[0000950170-23-005545:notes:162]
[same as prior period, unchanged from 0000950170-22-025960:notes:161]

[0000950170-23-005545:notes:163]
|  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |
| Effective tax rates |  |  | (36.8 | )% |  |  | 17.6 | % |

[0000950170-23-005545:notes:164]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. Our effective tax rate for the nine months ended January 27, 2023 was primarily driven by a discrete tax benefit of $524 million that resulted from an intra-entity asset transfer of certain intellectual property (“IP”) offset partially by a Danish Supreme Court decision resulting in $69 million of discrete tax expense. Additionally, our effective tax rate for the nine months ended January 27, 2023 includes an increase from the prior year primarily due to the capitalization of research and development expenses partially offset by the discrete benefits related to stock-based compensation. Under the Tax Cuts and Jobs Act of 2017, research and development costs incurred beginning in our fiscal 2023 are to be amortized over five or 15 years depending on where the research activities are conducted. The effective tax rate for the nine months ended January 28, 2022, includes the impact of discrete tax benefits for lapses of statute of limitations as well as larger benefits related to stock-based compensation as compared to the current year.

[0000950170-23-005545:notes:165]
[same as prior period, unchanged from 0000950170-22-025960:notes:164]

[0000950170-23-005545:notes:166]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We did not believe that our Danish subsidiary was liable for such withholding tax and filed an appeal with the Danish Tax Tribunal. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012. In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). In March 2018, the Advocate General issued an opinion which was largely in favor of NetApp. The CJEU was not bound by the opinion of the Advocate General and issued its preliminary ruling in February 2019. On May 3, 2021, the DHC reached a decision resulting in NetApp prevailing on the predominate distribution made in 2005. The smaller distribution made in 2006 was ruled in favor of the Danish Tax Authorities. On May 28, 2021, the Danish Tax Authorities appealed the DHC decision to the Danish Supreme Court. On January 9, 2023, the Danish Supreme Court reversed the lower court's decision and ruled the 2005 dividend was subject to withholding tax while the smaller 2006 distribution would not be subject to withholding tax. The Danish Supreme Court ruling on the distributions declared in 2005 and 2006 is non-appealable. During the third quarter ended January 27, 2023, we recorded $69 million of discrete tax expense, which includes $23 million of withholding tax and $46 million of interest, associated with the Danish Supreme Court ruling.

[0000950170-23-005545:notes:167]
[same as prior period, unchanged from 0000950170-22-025960:notes:166]

[0000950170-23-005545:notes:168]
[same as prior period, unchanged from 0000950170-22-025960:notes:169]

[0000950170-23-005545:notes:169]
As of January 27, 2023, we had $228 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $141 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $141 million have been recorded in other long-term liabilities.


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-005545:notes:170]
[same as prior period, unchanged from 0000950170-22-025960:notes:170]

[0000950170-23-005545:notes:171]
[same as prior period, unchanged from 0000950170-22-025960:notes:171]

[0000950170-23-005545:notes:172]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | January 27, 2023 |  |  | January 28, 2022 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 65 |  |  | $ | 252 |  |  | $ | 1,029 |  |  | $ | 678 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 216 |  |  |  | 223 |  |  |  | 218 |  |  |  | 223 |  |
| Dilutive impact of employee equity award plans |  |  | 3 |  |  |  | 6 |  |  |  | 3 |  |  |  | 6 |  |
| Shares used in diluted computation |  |  | 219 |  |  |  | 229 |  |  |  | 221 |  |  |  | 229 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.30 |  |  | $ | 1.13 |  |  | $ | 4.72 |  |  | $ | 3.04 |  |
| Diluted |  | $ | 0.30 |  |  | $ | 1.10 |  |  | $ | 4.66 |  |  | $ | 2.96 |  |

[0000950170-23-005545:notes:173]
Six million shares each from outstanding employee awards were excluded from the diluted net income per share calculation for the three and nine months ended January 27, 2023, respectively, as their inclusion would have been anti-dilutive. No potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for the three and nine months ended January 28, 2022.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-005545:notes:174]
[same as prior period, unchanged from 0000950170-22-025960:notes:174]

[0000950170-23-005545:notes:175]
[same as prior period, unchanged from 0000950170-22-025960:notes:175]

[0000950170-23-005545:notes:176]
[same as prior period, unchanged from 0000950170-22-025960:notes:176]

[0000950170-23-005545:notes:177]
[same as prior period, unchanged from 0000950170-22-025960:notes:177]

[0000950170-23-005545:notes:178]
[same as prior period, unchanged from 0000950170-22-025960:notes:178]

[0000950170-23-005545:notes:179]
[same as prior period, unchanged from 0000950170-22-025960:notes:179]

[0000950170-23-005545:notes:180]
|  | Three Months Ended January 27, 2023 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 682 |  |  | $ | — |  |  | $ | 682 |  |
| Support revenues |  | 616 |  |  |  | — |  |  |  | 616 |  |
| Professional and other services revenues |  | 78 |  |  |  | — |  |  |  | 78 |  |
| Public cloud revenues |  | — |  |  |  | 150 |  |  |  | 150 |  |
| Net revenues |  | 1,376 |  |  |  | 150 |  |  |  | 1,526 |  |
| Cost of product revenues |  | 365 |  |  |  | — |  |  |  | 365 |  |
| Cost of support revenues |  | 44 |  |  |  | — |  |  |  | 44 |  |
| Cost of professional and other services revenues |  | 50 |  |  |  | — |  |  |  | 50 |  |
| Cost of public cloud revenues |  | — |  |  |  | 47 |  |  |  | 47 |  |
| Segment cost of revenues |  | 459 |  |  |  | 47 |  |  |  | 506 |  |
| Segment gross profit | $ | 917 |  |  | $ | 103 |  |  | $ | 1,020 |  |
| Segment gross margin |  | 66.6 | % |  |  | 68.7 | % |  |  | 66.8 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 19 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,001 |  |
| Total gross margin |  |  |  |  |  |  |  | 65.6 | % |
| 1 Unallocated cost of revenues are composed of $8 million of stock-based compensation expense and $11 million of amortization of intangible assets. |  |

[0000950170-23-005545:notes:181]
|  | Three Months Ended January 28, 2022 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 846 |  |  | $ | — |  |  | $ | 846 |  |
| Support revenues |  | 586 |  |  |  | — |  |  |  | 586 |  |
| Professional and other services revenues |  | 72 |  |  |  | — |  |  |  | 72 |  |
| Public cloud revenues |  | — |  |  |  | 110 |  |  |  | 110 |  |
| Net revenues |  | 1,504 |  |  |  | 110 |  |  |  | 1,614 |  |
| Cost of product revenues |  | 404 |  |  |  | — |  |  |  | 404 |  |
| Cost of support revenues |  | 45 |  |  |  | — |  |  |  | 45 |  |
| Cost of professional and other services revenues |  | 46 |  |  |  | — |  |  |  | 46 |  |
| Cost of public cloud revenues |  | — |  |  |  | 32 |  |  |  | 32 |  |
| Segment cost of revenues |  | 495 |  |  |  | 32 |  |  |  | 527 |  |
| Segment gross profit | $ | 1,009 |  |  | $ | 78 |  |  | $ | 1,087 |  |
| Segment gross margin |  | 67.1 | % |  |  | 70.9 | % |  |  | 67.3 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 14 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,073 |  |
| Total gross margin |  |  |  |  |  |  |  | 66.5 | % |
| 1 Unallocated cost of revenues are composed of $5 million of stock-based compensation expense and $9 million of amortization of intangible assets. |  |

[0000950170-23-005545:notes:182]
|  | Nine Months Ended January 27, 2023 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 2,305 |  |  | $ | — |  |  | $ | 2,305 |  |
| Support revenues |  | 1,821 |  |  |  | — |  |  |  | 1,821 |  |
| Professional and other services revenues |  | 231 |  |  |  | — |  |  |  | 231 |  |
| Public cloud revenues |  | — |  |  |  | 424 |  |  |  | 424 |  |
| Net revenues |  | 4,357 |  |  |  | 424 |  |  |  | 4,781 |  |
| Cost of product revenues |  | 1,177 |  |  |  | — |  |  |  | 1,177 |  |
| Cost of support revenues |  | 132 |  |  |  | — |  |  |  | 132 |  |
| Cost of professional and other services revenues |  | 156 |  |  |  | — |  |  |  | 156 |  |
| Cost of public cloud revenues |  | — |  |  |  | 132 |  |  |  | 132 |  |
| Segment cost of revenues |  | 1,465 |  |  |  | 132 |  |  |  | 1,597 |  |
| Segment gross profit | $ | 2,892 |  |  | $ | 292 |  |  | $ | 3,184 |  |
| Segment gross margin |  | 66.4 | % |  |  | 68.9 | % |  |  | 66.6 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 50 |  |
| Total gross profit |  |  |  |  |  |  | $ | 3,134 |  |
| Total gross margin |  |  |  |  |  |  |  | 65.6 | % |
| 1 Unallocated cost of revenues are composed of $18 million of stock-based compensation expense and $32 million of amortization of intangible assets. |  |

[0000950170-23-005545:notes:183]
|  | Nine Months Ended January 28, 2022 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 2,390 |  |  | $ | — |  |  | $ | 2,390 |  |
| Support revenues |  | 1,754 |  |  |  | — |  |  |  | 1,754 |  |
| Professional and other services revenues |  | 218 |  |  |  | — |  |  |  | 218 |  |
| Public cloud revenues |  | — |  |  |  | 276 |  |  |  | 276 |  |
| Net revenues |  | 4,362 |  |  |  | 276 |  |  |  | 4,638 |  |
| Cost of product revenues |  | 1,099 |  |  |  | — |  |  |  | 1,099 |  |
| Cost of support revenues |  | 141 |  |  |  | — |  |  |  | 141 |  |
| Cost of professional and other services revenues |  | 151 |  |  |  | — |  |  |  | 151 |  |
| Cost of public cloud revenues |  | — |  |  |  | 80 |  |  |  | 80 |  |
| Segment cost of revenues |  | 1,391 |  |  |  | 80 |  |  |  | 1,471 |  |
| Segment gross profit | $ | 2,971 |  |  | $ | 196 |  |  | $ | 3,167 |  |
| Segment gross margin |  | 68.1 | % |  |  | 71.0 | % |  |  | 68.3 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 36 |  |
| Total gross profit |  |  |  |  |  |  | $ | 3,131 |  |
| Total gross margin |  |  |  |  |  |  |  | 67.5 | % |
| 1 Unallocated cost of revenues are composed of $13 million of stock-based compensation expense and $23 million of amortization of intangible assets. |  |

[0000950170-23-005545:notes:184]
[same as prior period, unchanged from 0000950170-22-025960:notes:184]

[0000950170-23-005545:notes:185]
[same as prior period, unchanged from 0000950170-22-025960:notes:185]

[0000950170-23-005545:notes:186]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | January 27, 2023 |  |  | January 28, 2022 |  |
| United States, Canada and Latin America (Americas) |  | $ | 821 |  |  | $ | 902 |  |  | $ | 2,566 |  |  | $ | 2,556 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 491 |  |  |  | 516 |  |  |  | 1,526 |  |  |  | 1,431 |  |
| Asia Pacific (APAC) |  |  | 214 |  |  |  | 196 |  |  |  | 689 |  |  |  | 651 |  |
| Net revenues |  | $ | 1,526 |  |  | $ | 1,614 |  |  | $ | 4,781 |  |  | $ | 4,638 |  |

[0000950170-23-005545:notes:187]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $714 million and $796 million during the three months ended January 27, 2023 and January 28, 2022, respectively, and were $2,241 million and $2,265 million during the nine months ended January 27, 2023 and January 28, 2022, respectively.

[0000950170-23-005545:notes:188]
[same as prior period, unchanged from 0000950170-22-025960:notes:188]

[0000950170-23-005545:notes:189]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| U.S. |  | $ | 1,113 |  |  | $ | 1,820 |  |
| International |  |  | 2,028 |  |  |  | 2,314 |  |
| Total |  | $ | 3,141 |  |  | $ | 4,134 |  |

[0000950170-23-005545:notes:190]
[same as prior period, unchanged from 0000950170-22-025960:notes:190]

[0000950170-23-005545:notes:191]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| U.S. |  | $ | 427 |  |  | $ | 392 |  |
| International |  |  | 240 |  |  |  | 210 |  |
| Total |  | $ | 667 |  |  | $ | 602 |  |

[0000950170-23-005545:notes:192]
[same as prior period, unchanged from 0000950170-22-025960:notes:192]

[0000950170-23-005545:notes:193]
[same as prior period, unchanged from 0000950170-22-025960:notes:193]

[0000950170-23-005545:notes:194]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2023 |  |  | January 28, 2022 |  |  | January 27, 2023 |  |  | January 28, 2022 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 25 | % |  |  | 24 | % |  |  | 25 | % |
| Tech Data Corporation |  |  | 21 | % |  |  | 21 | % |  |  | 20 | % |  |  | 21 | % |

[0000950170-23-005545:notes:195]
[same as prior period, unchanged from 0000950170-22-025960:notes:195]

[0000950170-23-005545:notes:196]
|  |  | January 27, 2023 |  |  | April 29, 2022 |  |
| Arrow Electronics, Inc. |  |  | 10 | % |  |  | 10 | % |
| Tech Data Corporation |  |  | 17 | % |  |  | 19 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-005545:notes:197]
15. Commitments and Contingencies

[0000950170-23-005545:notes:198]
Purchase Orders and Other Commitments

[0000950170-23-005545:notes:199]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of January 27, 2023, we had approximately $0.5 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 27, 2023 and April 29, 2022, such liability amounted to $20 million and $18 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0000950170-23-005545:notes:200]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 27, 2023, we had approximately $0.3 billion in other purchase obligations.

[0000950170-23-005545:notes:201]
Financing Guarantees

[0000950170-23-005545:notes:202]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $32 million and $48 million of receivables during the nine months ended January 27, 2023 and January 28, 2022, respectively.

[0000950170-23-005545:notes:203]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0000950170-23-005545:notes:204]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of January 27, 2023 and April 29, 2022, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-23-005545:notes:205]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 27, 2023, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-23-005545:notes:206]
Legal Contingencies

[0000950170-23-005545:notes:207]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0000950170-23-005545:notes:208]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. The defendants' Motion to Dismiss was granted and on February 26, 2021 and the judge entered judgment in favor of NetApp and the other defendants. On March 26, 2021, plaintiffs filed a notice of appeal. The parties subsequently engaged in settlement discussions, and on July 30, 2021 entered into a Memorandum of Understanding (MOU) providing for the settlement of the class action. Pursuant to the terms of the MOU, NetApp has agreed to pay approximately $2.0 million in connection with the settlement, and this amount was accrued during the three months ended July 30, 2021. The parties subsequently executed a stipulation of settlement, which contains no admission of liability, wrongdoing or responsibility by any of the parties, and which provides that the class action will be dismissed with prejudice, with mutual releases by all parties, upon final court approval. On September 24, 2021, plaintiff filed an unopposed motion seeking court approval of the settlement. On May 2, 2022, the court preliminarily approved the settlement. On September 1, 2022, the court held a final approval hearing, approved the settlement and dismissed the case with prejudice.

[0000950170-23-005545:notes:209]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0000950170-23-005545:notes:210]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of January 27, 2023 related to such matters.
