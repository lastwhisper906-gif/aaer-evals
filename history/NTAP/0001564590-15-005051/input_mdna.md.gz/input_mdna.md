# NTAP MD&A — 0001564590-15-005051


## mdna

[0001564590-15-005051:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001564590-15-005051:mdna:2]
The following discussion of our financial condition and results of operations should be read together with the financial statements and the accompanying notes set forth under Item 8. – Financial Statements and Supplementary Data. The following discussion also contains trend information and other forward-looking statements that involve a number of risks and uncertainties. The Risk Factors set forth in Item 1A. – Risk Factors are hereby incorporated into the discussion by reference.

[0001564590-15-005051:mdna:3]
Executive Overview

[0001564590-15-005051:mdna:4]
Our Company

[0001564590-15-005051:mdna:5]
We are a leading global provider of software, systems and services to manage and store customer data. We enable enterprises, service providers, governmental organizations, and partners to envision, deploy and evolve their information technology (IT) environments and to reduce costs and risk while driving growth and success for their organizations.

[0001564590-15-005051:mdna:6]
Our unified scale-out fabric-attached storage (FAS) platform is designed to meet the demanding requirements of shared infrastructures and cloud environments. Our E-Series high-performance storage area network platform is designed to meet demanding performance and capacity requirements of dedicated workloads, while retaining simplicity and an optimized price to performance ratio. Our FAS storage platform uses the NetApp DataONTAP storage operating system to deliver integrated data protection, comprehensive data management, and built-in efficiency software for virtualized, shared infrastructures, cloud computing, and mixed workload business applications. We offer hybrid and all-flash configurations of both FAS and E-Series platforms. Our configured systems consist of (1) entry level product platform, which consists of our FAS2000 systems, (2) mid-range product platform, which consists of our legacy FAS3000 systems and our new FAS8020 and FAS8040 systems, and (3) high-end product platform, which consists of our legacy 6000 systems and our new FAS8060 systems.

[0001564590-15-005051:mdna:7]
In addition to our products, we provide a variety of services including software maintenance (formerly called Software Maintenance and Entitlement or SEM Revenues), hardware maintenance and other services including professional services, global support solutions, and customer education and training to help customers most effectively manage their data (formerly called Services Revenues).

[0001564590-15-005051:mdna:8]
We employ a multichannel distribution strategy, selling products and services to end users and service providers through a direct sales force and through channel partners, including value-added resellers, system integrators, original equipment manufacturers (OEMs) and distributors.

[0001564590-15-005051:mdna:9]
Financial Results and Key Performance Metrics Overview

[0001564590-15-005051:mdna:10]
The following table provides an overview of some of our key financial metrics for each of the last three fiscal years (in millions, except per share amounts, percentages and days sales outstanding):

[0001564590-15-005051:mdna:11]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Net revenues |  | $ | 6,122.7 |  |  | $ | 6,325.1 |  |  | $ | 6,332.4 |  |
| Gross profit |  | $ | 3,833.2 |  |  | $ | 3,919.1 |  |  | $ | 3,761.1 |  |
| Gross profit margin percentage |  |  | 63 | % |  |  | 62 | % |  |  | 59 | % |
| Income from operations |  | $ | 716.5 |  |  | $ | 734.3 |  |  | $ | 607.8 |  |
| Income from operations as a percentage of net revenues |  |  | 12 | % |  |  | 12 | % |  |  | 10 | % |
| Net income |  | $ | 559.9 |  |  | $ | 637.5 |  |  | $ | 505.3 |  |
| Diluted net income per share |  | $ | 1.75 |  |  | $ | 1.83 |  |  | $ | 1.37 |  |
| Operating cash flows |  | $ | 1,268.1 |  |  | $ | 1,349.6 |  |  | $ | 1,386.3 |  |

[0001564590-15-005051:mdna:12]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Deferred revenue |  | $ | 3,197.2 |  |  | $ | 3,100.2 |  |
| Days sales outstanding (DSO) |  |  | 46 |  |  |  | 47 |  |

[0001564590-15-005051:mdna:13]
| · | Net revenues: Our net revenues declined 3% in fiscal 2015 compared to fiscal 2014. This was primarily due to a decrease of 7% in product revenues, which included the impact of unfavorable foreign currency exchange rate changes during the second half of fiscal 2015, partially offset by a 7% increase in hardware maintenance and other services revenues generated from a higher installed base of our hardware products under maintenance contracts. |

[0001564590-15-005051:mdna:14]
| · | Gross profit margin percentage: Our gross profit margin as a percentage of net revenues increased in fiscal 2015 compared to fiscal 2014 primarily due to higher gross margins on hardware maintenance and other services revenues. |

[0001564590-15-005051:mdna:15]
30

[0001564590-15-005051:mdna:16]
| · | Income from operations as a percentage of net revenues: Our income from operations as a percentage of net revenues was relatively flat in fiscal 2015 compared to fiscal 2014 primarily due to cost control measures executed during the year. |

[0001564590-15-005051:mdna:17]
| · | Net income and Diluted income per share: The 12% and 4% decrease in net income and diluted net income per share, respectively, in fiscal 2015 compared to fiscal 2014 reflects lower operating income in dollars, as well as an increase of 7.6 percentage points in our effective tax rate. In addition to these factors, diluted net income per share was favorably impacted by an 8% decrease in the number of dilutive shares, primarily due to the favorable impact of share repurchases. |

[0001564590-15-005051:mdna:18]
| · | Operating cash flows: Operating cash flows decreased 6% in fiscal 2015, reflecting a decrease in net income, as well as unfavorable changes in net operating assets and liabilities. |

[0001564590-15-005051:mdna:19]
| · | Deferred revenue: Total deferred revenue increased $97.0 million, or 3%, in fiscal 2015 compared to fiscal 2014 primarily due an increase in deferred software and hardware maintenance contract sales and renewals. |

[0001564590-15-005051:mdna:20]
| · | DSO: Days Sales Outstanding (DSO) were 46 in the fourth quarter of fiscal 2015 compared to 47 in the fourth quarter of fiscal 2014 reflecting seasonal shipment linearity. |

[0001564590-15-005051:mdna:21]
Stock Repurchase Program and Dividend Activity

[0001564590-15-005051:mdna:22]
During fiscal 2015, we repurchased 29.6 million shares of our common stock at an average price of $39.30 per share, for an aggregate of $1.2 billion. We also declared cash dividends of an aggregate of $0.66 per share in fiscal 2015, for which we paid an aggregate of $207.4 million.

[0001564590-15-005051:mdna:23]
Critical Accounting Policies and Estimates

[0001564590-15-005051:mdna:24]
Our consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (GAAP), which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and liabilities. Our estimates are based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0001564590-15-005051:mdna:25]
The summary of significant accounting policies is included in Note 1 – Description of Business and Significant Accounting Policies of the Notes to Consolidated Financial Statements. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. The accounting policies described below reflect the significant judgments, estimates and assumptions used in the preparation of the consolidated financial statements.

[0001564590-15-005051:mdna:26]
Revenue Recognition, Reserves and Allowances

[0001564590-15-005051:mdna:27]
We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable and collection is reasonably assured. Revenue from the sale of hardware systems and software components essential to the functionality of the hardware systems is recognized in accordance with general revenue recognition accounting guidance. Our product revenues also include revenues from the sale of non-essential software products, which generally includes a perpetual license to our software. Non-essential software sales are subject to industry specific software revenue recognition accounting guidance. Software maintenance and hardware maintenance services revenues are recognized ratably over their contractual terms, generally from one to five years.

[0001564590-15-005051:mdna:28]
For multiple element arrangements, we allocate revenue to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement. For our non-software deliverables, we allocate the arrangement consideration based on the relative selling price of the deliverables using estimated selling price (ESP). For our software maintenance services, we generally use vendor-specific objective evidence of selling price (VSOE). When we are unable to establish VSOE for our software maintenance services, we use ESP in our allocation of arrangement consideration.

[0001564590-15-005051:mdna:29]
The selling price for each element is based upon the following selling price hierarchy: VSOE if available, third party evidence (TPE) if VSOE is not available, or ESP if neither VSOE nor TPE are available. Generally, we are not able to determine TPE because our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained.

[0001564590-15-005051:mdna:30]
We record reductions to revenue for estimated sales returns at the time of shipment. We also maintain a separate allowance for doubtful accounts for estimated losses based on our assessment of the collectability of specific customer accounts.

[0001564590-15-005051:mdna:31]
31

[0001564590-15-005051:mdna:32]
The following are the key estimates and assumptions and corresponding uncertainties for recognizing revenue:

[0001564590-15-005051:mdna:33]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| · | We establish VSOE of selling price using the price charged for a deliverable when sold separately and generally evidenced by a substantial majority of historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer type, and other variables in determining VSOE. Our revenue estimates and assumptions are based on our ability to assert and maintain VSOE. ESP is generally evidenced by a majority of historical transactions falling within a reasonable price range. We also consider multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer type and distribution channels. Our revenue estimates and assumptions are based on our ability to maintain consistent ESP. |  | · | As our business and offerings evolve over time, modifications to our pricing and discounting methodologies, changes in the scope and nature of service offerings and/or changes in customer segmentation may result in a lack of consistency required to establish and/or maintain VSOE or to maintain consistent ESP. Additionally, technological changes resulting in variability in product costs and gross margins may require changes to our ESP model. Changes in ESP may result in a different allocation of revenue to the deliverables in multiple-element arrangements. These factors, among others, may adversely impact the amount of revenue and gross margin we report in a particular period. |
| · | Sales returns are estimated based on historical sales returns, current trends and our expectations regarding future experience. Additionally, distributors and partners participate in various marketing and other programs, and we maintain estimated accruals and allowances for these programs based on contractual terms and historical experience. |  | · | If there is insufficient relevant historical data for determining our sales returns estimates, or if we experience changes in practices related to sales returns or changes in market or competitive conditions resulting in higher than expected return rates, or if actual credits received by our distributors and partners deviate significantly from our estimates, our revenues may be adversely impacted. |

[0001564590-15-005051:mdna:34]
Inventory Valuation and Purchase Order Accruals

[0001564590-15-005051:mdna:35]
Inventories consist primarily of purchased components and finished goods and are stated at the lower of cost or market, which approximates actual cost on a first-in, first-out basis. A provision is recorded when inventory is determined to be in excess of anticipated demand or obsolete in order to adjust inventory to its estimated realizable value. The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our inventories:

[0001564590-15-005051:mdna:36]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| · | We periodically perform an excess and obsolete analysis of our inventory. Inventories are written down based on excess and obsolete reserves determined primarily on assumptions about future demand forecasts and market conditions. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. |  | · | Although we use our best estimates to forecast future product demand, any significant unanticipated changes in demand or obsolescence related to technological developments, new product introductions, customer requirements, competition or other factors could have a significant impact on the valuation of our inventory. If actual market conditions are less favorable than those projected, additional write-downs and other charges against earnings that adversely impact gross margins may be required. If actual market conditions are more favorable, we may realize higher gross profits in the period when the written-down inventory is sold. We are subject to a variety of environmental laws relating to the manufacture of our products. If there are changes to the current regulations, we may be required to make product design changes which may result in excess or obsolete inventory, which could adversely impact our operating results. |
| · | We make commitments to our third-party contract manufacturers and other suppliers to manage lead times and meet product forecasts and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on non-cancelable purchase commitments when we believe it is probable that the components will not be utilized in future operations. |  | · | If the actual materials demand is significantly lower than our forecast, we may be required to increase our recorded liabilities for estimated losses on non-cancelable purchase commitments which would adversely impact our operating results. |

[0001564590-15-005051:mdna:37]
32

[0001564590-15-005051:mdna:38]
Goodwill and Purchased Intangible Assets

[0001564590-15-005051:mdna:39]
We allocate the purchase price of acquisitions to identifiable assets acquired and liabilities assumed at their acquisition date fair values based on established valuation techniques. Goodwill represents the residual value as of the acquisition date, which in most cases is measured as the excess of the purchase consideration transferred over the net of the acquisition date fair values of the assets acquired and liabilities assumed.

[0001564590-15-005051:mdna:40]
The carrying values of purchased intangible assets are reviewed whenever events and circumstances indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. We periodically review the estimated remaining useful lives of our intangible assets. This review may result in impairment charges or shortened useful lives, resulting in charges to our consolidated statements of operations.

[0001564590-15-005051:mdna:41]
We review goodwill for impairment annually and whenever events or changes in circumstances indicate the carrying value of an asset may not be recoverable. The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. For our annual goodwill impairment test in the fourth quarter of fiscal 2015, we performed a quantitative test at the reporting unit level and determined the fair value substantially exceeded the carrying value for each reporting unit and, therefore, found no impairment of goodwill.

[0001564590-15-005051:mdna:42]
The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our goodwill and purchased intangible assets:

[0001564590-15-005051:mdna:43]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| · | The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the accounting guidance for the fair value measurement of nonfinancial assets. The valuation of purchased intangible assets is principally based on estimates of the future performance and cash flows expected to be generated by the acquired assets from the acquired business. |  | · | While we employ experts to determine the acquisition date fair value of acquired intangibles, the fair value of assets acquired and liabilities assumed are based on significant management assumptions and estimates, which are inherently uncertain and highly subjective and as a result, actual results may differ from estimates. If different assumptions were to be used, it could materially impact the purchase price allocation. |
| · | Evaluations of possible goodwill and purchased intangible assets impairment require us to make judgments and assumptions related to the allocation of our balance sheet and income statement amounts and estimate future cash flows and fair market values of our reporting units and assets. |  | · | In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill or purchased intangible assets. Assumptions and estimates about expected future cash flows and the fair values of our goodwill and purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as the adverse impact of unanticipated changes in macroeconomic conditions and technological changes or new product introductions from competitors. They can also be affected by internal factors such as changes in business strategy or in forecasted product life cycles and roadmaps. Our ongoing consideration of these and other factors could result in future impairment charges or accelerated amortization expense, which could adversely affect our operating results. |

[0001564590-15-005051:mdna:44]
Product Warranties

[0001564590-15-005051:mdna:45]
Estimated future hardware and software warranty costs are recorded as a cost of product revenues at the time of product shipment. We assess the adequacy of our warranty accrual each quarter and adjust the amount as considered necessary.

[0001564590-15-005051:mdna:46]
The following are the key estimates and assumptions and corresponding uncertainties for product warranties:

[0001564590-15-005051:mdna:47]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| · | Estimated future software and hardware warranty costs are based on historical and projected warranty claim rates, product failure rates, historical and projected materials and logistics costs, distribution and labor costs and knowledge of specific product failures that are outside of our typical experience. We also evaluate our estimates to assess the adequacy of our warranty liability considering the size of the installed base of products subject to warranty protection and adjust the estimates as necessary. |  | · | Although we engage in product quality programs and processes, if we experience unexpected quality issues resulting in higher failure rates or experience increases in costs to remediate product failures, additional warranty costs may be incurred. Additionally, for new products our warranty liability is based on limited historical experience. If our projections differ from such limited experience, our warranty costs may increase, which could adversely impact our gross margins. |

[0001564590-15-005051:mdna:48]
Stock-Based Compensation

[0001564590-15-005051:mdna:49]
We recognize stock-based compensation expense for all share-based payment awards, net of an estimated forfeiture rate, on a straight-line basis over the requisite service period.

[0001564590-15-005051:mdna:50]
The following are the key estimates and assumptions and corresponding uncertainties for our stock-based compensation:

[0001564590-15-005051:mdna:51]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| · | The fair values of employee stock options and rights to purchase shares under our Employee Stock Purchase Plan (ESPP) are estimated using the Black-Scholes option-pricing model. The key assumptions used in estimating the fair value of such awards include the expected term of the awards, risk free interest rates, future dividend rates and the expected stock price volatility over the expected term of the awards. |  | · | To the extent that market conditions or company specific events lead to higher stock price volatility or employee stock option exercise behavior differs from expectations, the estimated fair value and stock-based compensation expense may differ significantly in future periods, which could impact our operating results. |
| · | Stock-based compensation expense is based on awards ultimately expected to meet service vesting conditions and is impacted by the estimated forfeiture rate. |  | · | If we experience employee turnover different from our historical rates, our stock-based compensation expense in the future may differ significantly from what we have recorded in the current period. |

[0001564590-15-005051:mdna:52]
Valuation of Investment Securities

[0001564590-15-005051:mdna:53]
Our investments in debt securities are reported at fair value and are subject to periodic impairment review. Unrealized gains and losses related to changes in the fair value of these securities are recognized in accumulated other comprehensive income, net of tax, unless they are determined to be other-than-temporary impairments. The ultimate value realized on these securities is subject to market price volatility until they are sold.

[0001564590-15-005051:mdna:54]
The following are the key estimates and assumptions and corresponding uncertainties for the valuation of our investment securities:

[0001564590-15-005051:mdna:55]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| · | The estimated fair value of our debt securities, and the associated accounting for unrealized losses is based on an evaluation of current economic and market conditions, the credit rating of the security’s issuer, the length of time and extent a security’s fair value has been below its amortized cost and our ability and intent to hold the security for a period of time sufficient to allow for anticipated recovery in value. If we determine that an investment has an other-than-temporary decline in fair value, we recognize the investment loss in earnings. |  | · | The fair value of our investments in debt securities could decrease significantly from uncertainties in the credit and capital markets, credit rating downgrades and/or solvency of the issuer, decreases in the marketability of the securities or changes in our ability and intent to continue to hold the securities. If the fair value of our investments decreases significantly and is determined to be other-than-temporary, we may incur impairment charges that could adversely affect our results of operations. |

[0001564590-15-005051:mdna:56]
Income Taxes

[0001564590-15-005051:mdna:57]
We are subject to income taxes in the United States and numerous foreign jurisdictions. We compute our provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0001564590-15-005051:mdna:58]
The following are the key estimates and assumptions and corresponding uncertainties for our income taxes:

[0001564590-15-005051:mdna:59]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| · | Our income tax provision is based on existing tax law and advanced pricing agreements or letter rulings we have with various tax authorities. |  | · | Our provision for income taxes is subject to volatility and could be adversely impacted by future changes in existing tax laws, such as a change in tax rate, possible U.S. changes to the taxation of earnings of our foreign subsidiaries, and uncertainties as to future renewals of favorable tax agreements and rulings. |
| · | Deferred income taxes have not been provided on the undistributed earnings of foreign subsidiaries because these earnings have been indefinitely reinvested and there is no plan in the foreseeable future to initiate any action that would precipitate the payment of income taxes thereon. |  | · | We consider the following matters, among others, in evaluating our plans for indefinite reinvestment: the forecasts, budgets and financial requirements of the parent and subsidiaries for both the long and short term; the tax consequences of a decision to reinvest; and any U.S. and foreign government programs designed to influence remittances. If factors change, future income tax expense and payments may differ significantly from the current period and could materially adversely affect our results of operations. |
| · | The determination of whether we should record or adjust a valuation allowance against our deferred tax assets is based on assumptions regarding our future profitability. |  | · | Our future profits could differ from current expectations resulting in a change to our determination as to the amount of deferred tax assets that are more likely than not to be realized. We could adjust our valuation allowance with a corresponding impact to the tax provision in the period in which such determination is made. |
| · | The estimates for our uncertain tax positions are based primarily on company specific circumstances, applicable tax laws, tax opinions from outside firms and past results from examinations of our income tax returns. |  | · | Significant judgment is required in evaluating our uncertain tax positions. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome or tax court rulings of these matters will not be different from that which is reflected in our historical tax provisions and accruals. |

[0001564590-15-005051:mdna:60]
New Accounting Standards

[0001564590-15-005051:mdna:61]
See Note 3 – Recent Accounting Standards Not Yet Effective of the Notes to Consolidated Financial Statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on our financial statements.

[0001564590-15-005051:mdna:62]
35

[0001564590-15-005051:mdna:63]
Results of Operations

[0001564590-15-005051:mdna:64]
Our fiscal year is reported on a 52- or 53-week year that ends on the last Friday in April. Our fiscal years 2015, 2014 and 2013 ended on April 24, 2015, April 25, 2014 and April 26, 2013, respectively, and were each 52-week years. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2016 will span 53 weeks, with a 14th week included in the first quarter of fiscal 2016. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0001564590-15-005051:mdna:65]
The following table sets forth certain Consolidated Statements of Operations data as a percentage of net revenues for the periods indicated:

[0001564590-15-005051:mdna:66]
|  |  | Fiscal Year |  |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 60 |  | % |  | 62 |  | % |  | 65 |  | % |
| Software maintenance |  |  | 15 |  |  |  | 14 |  |  |  | 14 |  |  |
| Hardware maintenance and other services |  |  | 26 |  |  |  | 23 |  |  |  | 21 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 27 |  |  |  | 28 |  |  |  | 31 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | — |  |  |  | — |  |  |
| Cost of hardware maintenance and other services |  |  | 10 |  |  |  | 9 |  |  |  | 9 |  |  |
| Gross profit |  |  | 63 |  |  |  | 62 |  |  |  | 59 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 31 |  |  |  | 30 |  |  |  | 31 |  |  |
| Research and development |  |  | 15 |  |  |  | 15 |  |  |  | 14 |  |  |
| General and administrative |  |  | 5 |  |  |  | 4 |  |  |  | 4 |  |  |
| Restructuring and other charges |  |  | — |  |  |  | 1 |  |  |  | — |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Total operating expenses |  |  | 51 |  |  |  | 50 |  |  |  | 50 |  |  |
| Income from operations |  |  | 12 |  |  |  | 12 |  |  |  | 10 |  |  |
| Other income (expense), net |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |
| Income before income taxes |  |  | 12 |  |  |  | 12 |  |  |  | 9 |  |  |
| Provision for income taxes |  |  | 2 |  |  |  | 2 |  |  |  | 1 |  |  |
| Net income |  |  | 9 |  | % |  | 10 |  | % |  | 8 |  | % |

[0001564590-15-005051:mdna:67]
Percentages may not add due to rounding

[0001564590-15-005051:mdna:68]
Discussion and Analysis of Results of Operations

[0001564590-15-005051:mdna:69]
Overview — Net revenues for fiscal 2015 were $6,122.7 million, down $202.4 million, or 3%, compared to fiscal 2014, reflecting a decrease in product and software maintenance revenues, partially offset by an increase in hardware maintenance and other services revenues. Net revenues for fiscal 2014 were $6,325.1 million, down $7.3 million, or less than 1%, compared to fiscal 2013, reflecting a decrease in product revenues, mostly offset by increases in software maintenance and hardware maintenance and other services revenues.

[0001564590-15-005051:mdna:70]
Gross profit as a percentage of net revenues increased 1% during fiscal 2015 compared to fiscal 2014, reflecting higher gross margins on hardware maintenance contract and other services revenues. Gross profit margins on product revenues in fiscal 2015 were relatively flat compared to fiscal 2014 primarily due to lower average selling price (ASP) for configured systems being offset by lower unit materials cost due to changes in product mix. Gross profit as a percentage of net revenues increased 3% during fiscal 2014 compared to fiscal 2013, primarily due to lower unit materials costs due to supply chain efficiencies, partially offset by lower ASPs for total configured systems. Additionally, gross profit was favorably impacted in fiscal 2014 by lower OEM revenues and higher margins on hardware maintenance and other services revenues.

[0001564590-15-005051:mdna:71]
Sales and marketing, research and development, and general and administrative expenses for fiscal 2015 totaled $3,116.7 million, up 2% as a percentage of net revenues compared to fiscal 2014, primarily due to a slight decrease in costs on a lower revenue denominator. Sales and marketing, research and development, and general and administrative expenses for fiscal 2014 totaled $3,096.5 million, down 1% as a percentage of net revenues compared to fiscal 2013, reflecting cost control programs implemented in fiscal 2014, partially offset by an increase in incentive compensation due to higher achievement against plan.

[0001564590-15-005051:mdna:72]
Net Revenues (in millions, except percentages):

[0001564590-15-005051:mdna:73]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2013 |  |  | % Change |  |
| Net revenues |  | $ | 6,122.7 |  |  | $ | 6,325.1 |  |  |  | (3 | )% |  | $ | 6,332.4 |  |  |  | — | % |

[0001564590-15-005051:mdna:74]
The decrease in net revenues for fiscal 2015 was primarily due to a reduction of $289.3 million in product revenues, partially offset by $103.1 million increase in hardware maintenance and other services revenues. Product revenues comprised 60% of net revenues for fiscal 2015, compared to 62% of net revenues for fiscal 2014.

[0001564590-15-005051:mdna:75]
The slight decrease in net revenues for fiscal 2014 was due to a decrease of $148.4 million in product revenues, offset by an aggregate increase in software maintenance, hardware maintenance and other services revenues of $141.1 million. Product revenues comprised 62% of net revenues for fiscal 2014, compared to 65% of net revenues for fiscal 2013.

[0001564590-15-005051:mdna:76]
Sales through our indirect channels represented 80%, 82% and 81% of net revenues in fiscal 2015, 2014 and 2013, respectively. Included in indirect channel sales were $472.8 million, $584.7 million and $787.2 million of OEM revenues for fiscal 2015, 2014 and 2013, respectively.

[0001564590-15-005051:mdna:77]
The following customers, each of which is a distributor, accounted for 10% or more of net revenues:

[0001564590-15-005051:mdna:78]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Arrow Electronics, Inc. |  |  | 23 | % |  |  | 22 | % |  |  | 19 | % |
| Avnet, Inc. |  |  | 16 | % |  |  | 16 | % |  |  | 15 | % |

[0001564590-15-005051:mdna:79]
Product Revenues (in millions, except percentages):

[0001564590-15-005051:mdna:80]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2013 |  |  | % Change |  |
| Product revenues |  | $ | 3,654.6 |  |  | $ | 3,943.9 |  |  |  | (7 | )% |  | $ | 4,092.3 |  |  |  | (4 | )% |

[0001564590-15-005051:mdna:81]
Product revenues consist of configured systems, which include bundled hardware and software products, and non-configured products, which consist primarily of add-on storage, OEM products and add-on hardware and software products.

[0001564590-15-005051:mdna:82]
Total configured system revenues of $2,212.9 million decreased by $74.4 million, or 3%, in fiscal 2015, compared to fiscal 2014. Revenues decreased in FAS entry level, mid-range and high-end systems, partially offset by an increase in E-Series systems (which include our all flash EF systems). Total configured systems unit volume increased 5% primarily due to a unit volume increase in FAS mid-range, high-end systems and E-Series systems platforms, partially offset by a decrease in unit volume in FAS entry level systems. These changes in unit volume reflect a shift in customer demand to our newer FAS mid-range and high-end systems and higher demand for our E-Series systems, and away from our older FAS entry level systems. ASPs decreased across all FAS systems and E-Series systems platforms due to a combination of newer lower priced products within their respective platforms and unfavorable foreign exchange rates, which had an aggregate negative impact of $45.8 million on configured systems revenues in fiscal 2015 compared to fiscal 2014. As a result, overall ASPs of configured systems were lower in fiscal 2015 compared to fiscal 2014.

[0001564590-15-005051:mdna:83]
Non-configured product revenues of $1,441.7 million decreased by $214.9 million, or 13%, during fiscal 2015 compared to fiscal 2014. This decrease was primarily due to a decrease of 32% in add-on storage revenues and decrease of 20% in OEM revenues, partially offset by a 133% increase in add-on software. The decrease in add-on storage and increase in add-on software are largely due to the change in our pricing strategy that was effective in the fourth quarter of fiscal 2014, whereby we now charge for operating system software for storage capacity but have lowered prices on storage hardware. Non-configured systems revenues were negatively impacted by $21.1 million as a result of unfavorable foreign exchange rates in fiscal 2015, compared to fiscal 2014.

[0001564590-15-005051:mdna:84]
Total configured system revenues of $2,287.3 million increased by $4.2 million in fiscal 2014 compared to fiscal 2013. Revenues from FAS high-end systems and E-Series systems (which include our all flash EF systems) increased, offset by decreases in FAS entry level and mid-range systems. Total configured systems unit volume increased 2% during fiscal 2014 compared to fiscal 2013, primarily as a result of unit increases in the FAS high-end and mid-range systems and E-Series systems, partially offset by a decrease in unit volume of the FAS entry level systems, reflecting a shift in customer demand to our newer mid-range and high-end products, lower sales to the U.S. public sector market, and higher demand for our E-Series systems. The ASPs decreased across all FAS system platforms in fiscal 2014 compared to fiscal 2013 due to higher discounting and higher demand of newer lower priced products, while the ASP for E-Series increased due to higher ASPs on all-flash E-Series systems. Overall, ASPs of total configured systems decreased 1% during fiscal 2014 due to higher discounting and product mix.

[0001564590-15-005051:mdna:85]
Non-configured product revenues of $1,656.6 million decreased $152.6 million, or 8%, during fiscal 2014 compared to fiscal 2013. This decrease was primarily due to lower revenues from non-configured OEM products, which declined 26%.

[0001564590-15-005051:mdna:86]
Our systems are highly configurable to respond to customer requirements in the open systems storage markets that we serve. This can cause a wide variation in product configurations that can significantly impact revenues, cost of revenues and gross profits. Pricing changes, discounting practices, product competition, foreign currency, unit volumes, customer mix, natural disasters and product materials costs can also impact revenues, cost of revenues and/or gross profits. Disk drive and flash storage materials are a significant component of our storage systems. While our sales price per terabyte historically declines over time, improved system performance, increased capacity and software to manage this increased capacity have an offsetting favorable impact on product revenues.

[0001564590-15-005051:mdna:87]
Software Maintenance Revenues (in millions, except percentages):

[0001564590-15-005051:mdna:88]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2013 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 898.6 |  |  | $ | 914.8 |  |  |  | (2 | )% |  | $ | 893.5 |  |  |  | 2 | % |

[0001564590-15-005051:mdna:89]
Software maintenance revenues are associated with contracts which entitle customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, bug fixes and patch releases, as well as internet and telephone access to technical support personnel located in our global support centers.

[0001564590-15-005051:mdna:90]
The fluctuations in software maintenance revenues reflect fluctuations in the aggregate contract value of the installed base under software maintenance contracts, which is recognized as revenue ratably over the terms of the underlying contracts. Our software maintenance revenues were favorably impacted by a change in our pricing strategy, effective in the fourth quarter of fiscal 2014, such that we now charge for software maintenance services on the storage capacity sold in our configured systems and add-on storage products. We expect this change to continue to result in favorable trends in our software maintenance revenues as a percentage of total revenues.

[0001564590-15-005051:mdna:91]
Hardware Maintenance and Other Services Revenues (in millions, except percentages):

[0001564590-15-005051:mdna:92]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2013 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 1,569.5 |  |  | $ | 1,466.4 |  |  |  | 7 | % |  | $ | 1,346.6 |  |  |  | 9 | % |

[0001564590-15-005051:mdna:93]
Hardware maintenance and other services revenues include hardware maintenance, professional services and educational and training services revenues.

[0001564590-15-005051:mdna:94]
Hardware maintenance contract revenues were $1,252.5 million, $1,129.6 million and $991.8 million in fiscal 2015, 2014 and 2013, respectively. These revenues increased 11% during fiscal 2015 compared to fiscal 2014 and increased 14% during fiscal 2014 compared to fiscal 2013. The increases are a result of increases in the installed base and aggregate contract values under hardware maintenance contracts. Professional services and educational and training services revenues aggregated to $317.0 million, $336.8 million and $354.8 million in fiscal 2015, 2014 and 2013, respectively.

[0001564590-15-005051:mdna:95]
Revenues by Geographic Area:

[0001564590-15-005051:mdna:96]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| United States, Canada and Latin America (Americas) |  |  | 56 | % |  |  | 56 | % |  |  | 56 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 30 | % |  |  | 31 | % |  |  | 30 | % |
| Asia Pacific (APAC) |  |  | 13 | % |  |  | 14 | % |  |  | 13 | % |

[0001564590-15-005051:mdna:97]
Percentages may not add due to rounding

[0001564590-15-005051:mdna:98]
Americas revenues consist of sales to Americas commercial and United States (U.S.) public sector markets. During fiscal 2015, Americas revenues were favorably impacted by higher revenues from U.S. public sector markets, but unfavorably impacted by lower Americas commercial revenues. EMEA revenues were unfavorably impacted by foreign exchange rates in fiscal 2015 compared to fiscal 2014. During fiscal 2014, Americas revenues were unfavorably impacted by a decrease in sales to the U.S. public sector market. During fiscal 2013, EMEA revenues were negatively impacted by the general macroeconomic conditions in the region.

[0001564590-15-005051:mdna:99]
Cost of Revenues

[0001564590-15-005051:mdna:100]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping our storage products, amortization of purchased intangible assets, inventory write-downs, and warranty costs, (2) cost of software maintenance, which includes the costs of providing software maintenance and third-party royalty costs and (3) cost of hardware maintenance and other services revenues, which includes costs associated with providing support activities for hardware maintenance, global support partnership programs, professional services and educational and training services.

[0001564590-15-005051:mdna:101]
Our gross profit is impacted by a variety of factors, including pricing changes, discounting practices, foreign currency, product configuration, unit volumes, customer mix, revenue mix, natural disasters and product material costs. Hardware maintenance and other services gross profit is typically impacted by factors such as changes in the size of our installed base of products, as well as the timing of hardware maintenance and other services initiations and contract renewals, and incremental investments in our customer support infrastructure. If any of these factors are adversely affected, whether by economic uncertainties or for other reasons, our gross profit could decline.

[0001564590-15-005051:mdna:102]
Cost of Product Revenues (in millions, except percentages):

[0001564590-15-005051:mdna:103]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2013 |  |  | % Change |  |
| Cost of product revenues |  | $ | 1,656.9 |  |  | $ | 1,777.1 |  |  |  | (7 | )% |  | $ | 1,959.9 |  |  |  | (9 | )% |

[0001564590-15-005051:mdna:104]
The changes in cost of product revenues consisted of the following (in percentage points of the total change):

[0001564590-15-005051:mdna:105]
|  |  | Fiscal 2015 to Fiscal 2014 |  |  | Fiscal 2014 to Fiscal 2013 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials cost |  |  | (5 | ) |  |  | (7 | ) |
| Warranty |  |  | (2 | ) |  |  | (1 | ) |
| Excess and obsolete inventory |  |  | — |  |  |  | (1 | ) |
| Total change |  |  | (7 | ) |  |  | (9 | ) |

[0001564590-15-005051:mdna:106]
Cost of product revenues represented 45%, 45% and 48% of product revenues for fiscal 2015, 2014 and 2013, respectively.

[0001564590-15-005051:mdna:107]
Materials cost represented 85%, 84% and 83% of product costs for fiscal 2015, 2014 and 2013, respectively.

[0001564590-15-005051:mdna:108]
Materials cost decreased $82.1 million in fiscal 2015 compared to fiscal 2014. Materials costs were impacted by a 5% unit volume increase in configured systems in fiscal 2015 compared to fiscal 2014. Overall materials unit cost for configured systems decreased due to a decrease in the average unit materials costs in all of our configured systems platforms, except our FAS entry level systems, which increased slightly, due to changes in product mix. The decrease in materials costs also reflects lower OEM product volume and lower costs of add-on storage. Cost of product revenues were also favorably impacted by a $35.0 million decrease in hardware-related warranty expense due to a combination of a lower installed base subject to warranty and lower estimated warranty cost per unit.

[0001564590-15-005051:mdna:109]
Materials cost decreased $129.0 million in fiscal 2014 compared to fiscal 2013 due to an overall decrease in average unit materials cost across all FAS platforms, reflecting increased supply chain efficiencies and favorable changes in product mix. Additionally, materials cost was favorably impacted by lower OEM product volume compared to fiscal 2013 and to lower materials cost of add-on hardware and storage. This decrease was partially offset by a 2% unit volume increase in configured systems, resulting in higher gross margins on products compared to fiscal 2013. In addition, cost of product revenues in fiscal 2014 was favorably impacted by a $24.6 million decrease in hardware-related warranty expense and a $14.1 million decrease in excess and obsolete inventory write-downs compared to fiscal 2013.

[0001564590-15-005051:mdna:110]
Cost of Software Maintenance Revenues (in millions, except percentages):

[0001564590-15-005051:mdna:111]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2013 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 35.7 |  |  | $ | 30.7 |  |  |  | 16 | % |  | $ | 28.3 |  |  |  | 8 | % |

[0001564590-15-005051:mdna:112]
Cost of software maintenance revenues increased primarily due to higher third-party royalties in fiscal 2015 compared to fiscal 2014 and in fiscal 2014 compared to fiscal 2013. Cost of software maintenance revenues represented 4%, 3% and 3% of software maintenance revenues for fiscal 2015, 2014 and 2013, respectively.

[0001564590-15-005051:mdna:113]
Cost of Hardware Maintenance and Other Services Revenues (in millions, except percentages):

[0001564590-15-005051:mdna:114]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2013 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 596.9 |  |  | $ | 598.2 |  |  |  | — | % |  | $ | 583.1 |  |  |  | 3 | % |

[0001564590-15-005051:mdna:115]
Cost of hardware maintenance and other services revenues were relatively flat in fiscal 2015 compared to fiscal 2014 due to lower contracted services costs, logistics, materials rework and service delivery costs, offset by an increase in spares materials costs and headcount related costs. Cost of hardware maintenance and other services revenues increased in fiscal 2014 compared to 2013 primarily due to increases in spares materials costs and a higher volume of service calls related to a higher service contract base, largely offset by headcount related savings and lower per unit logistics and service delivery costs. Costs represented 38%, 41% and 43% of hardware maintenance and other services revenues for fiscal 2015, 2014 and 2013.

[0001564590-15-005051:mdna:116]
Operating Expenses

[0001564590-15-005051:mdna:117]
Sales and Marketing, Research and Development and General and Administrative Expenses

[0001564590-15-005051:mdna:118]
Compensation costs comprise the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0001564590-15-005051:mdna:119]
Total compensation costs included in operating expenses decreased $18.4 million, or 1% during fiscal 2015 compared to fiscal 2014, primarily due to a decrease in incentive compensation costs, reflecting lower operating performance against goals, and lower stock-based compensation expense.

[0001564590-15-005051:mdna:120]
Total compensation costs included in operating expenses increased $28.2 million, or 2% during fiscal 2014 compared to fiscal 2013, primarily due to increases in incentive compensation reflecting stronger operating performance against goals.

[0001564590-15-005051:mdna:121]
Sales and Marketing (in millions, except percentages):

[0001564590-15-005051:mdna:122]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2013 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 1,913.2 |  |  | $ | 1,898.2 |  |  |  | 1 | % |  | $ | 1,974.8 |  |  |  | (4 | )% |

[0001564590-15-005051:mdna:123]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, allocated facilities and IT costs, advertising and marketing promotional expense and travel and entertainment expense. The changes in sales and marketing expenses consisted of the following:

[0001564590-15-005051:mdna:124]
|  |  | Fiscal 2015 to Fiscal 2014 |  |  | Fiscal 2014 to Fiscal 2013 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (1 | ) |  |  | — |  |
| Depreciation and amortization |  |  | — |  |  |  | (1 | ) |
| Facilities and IT support costs |  |  | — |  |  |  | 1 |  |
| Other |  |  | 2 |  |  |  | (4 | ) |
| Total change |  |  | 1 |  |  |  | (4 | ) |

[0001564590-15-005051:mdna:125]
The decrease in compensation costs during fiscal 2015 is primarily due to lower stock-based compensation and salaries expense, reflecting lower compensation cost per headcount that was partially offset by a 5% increase in headcount. In addition, foreign exchange rate changes resulted in a favorable impact of $29.1 million during fiscal 2015.

[0001564590-15-005051:mdna:126]
Compensation costs during fiscal 2014 reflect higher incentive compensation that was more than offset by lower stock-based compensation and salaries expense. Depreciation and amortization expense decreased during fiscal 2014 due to certain intangible assets becoming fully amortized during fiscal 2013. Facilities and IT support costs increased during fiscal 2014 due to our increased investment in sales IT systems. The decrease in other sales and marketing expenses was primarily due to our fiscal 2014 cost containment programs.

[0001564590-15-005051:mdna:127]
Research and Development (in millions, except percentages):

[0001564590-15-005051:mdna:128]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2013 |  |  | % Change |  |
| Research and development expenses |  | $ | 919.3 |  |  | $ | 917.3 |  |  |  | — | % |  | $ | 904.2 |  |  |  | 1 | % |

[0001564590-15-005051:mdna:129]
Research and development expenses consist primarily of compensation costs, allocated facilities and IT costs, depreciation, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs. Changes in research and development expense consisted of the following:

[0001564590-15-005051:mdna:130]
|  |  | Fiscal 2015 to Fiscal 2014 |  |  | Fiscal 2014 to Fiscal 2013 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | — |  |  |  | 2 |  |
| Depreciation |  |  | — |  |  |  | 1 |  |
| Development projects |  |  | — |  |  |  | (1 | ) |
| Other |  |  | — |  |  |  | (1 | ) |
| Total change |  |  | — |  |  |  | 1 |  |

[0001564590-15-005051:mdna:131]
Research and development expenses were relatively flat in fiscal 2015 compared to fiscal 2014.

[0001564590-15-005051:mdna:132]
The increase in compensation costs during fiscal 2014 is primarily due to higher incentive compensation. Depreciation expense during fiscal 2014 increased due to higher levels of investment in engineering equipment. The decrease in development projects expense during fiscal 2014 reflects lower spending on materials and services associated with engineering activities to develop new product lines and enhancements to existing products.

[0001564590-15-005051:mdna:133]
We believe that our future performance will depend in large part on our ability to maintain and enhance our current product line, develop new products that achieve market acceptance, maintain technological competitiveness and meet an expanding range of customer requirements. We expect to continue to spend on current and future product development efforts, broaden our existing product offerings and introduce new products that expand our solutions portfolio.

[0001564590-15-005051:mdna:134]
General and Administrative (in millions, except percentages):

[0001564590-15-005051:mdna:135]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2013 |  |  | % Change |  |
| General and administrative expenses |  | $ | 284.2 |  |  | $ | 281.0 |  |  |  | 1 | % |  | $ | 272.6 |  |  |  | 3 | % |

[0001564590-15-005051:mdna:136]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and allocated facilities and IT support costs. Changes in general and administrative expense consisted of the following:

[0001564590-15-005051:mdna:137]
|  |  | Fiscal 2015 to Fiscal 2014 |  |  | Fiscal 2014 to Fiscal 2013 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (1 | ) |  |  | 5 |  |
| Professional and legal fees and outside services |  |  | 1 |  |  |  | 1 |  |
| Bad debt expense |  |  | — |  |  |  | (2 | ) |
| Other |  |  | 1 |  |  |  | (1 | ) |
| Total change |  |  | 1 |  |  |  | 3 |  |

[0001564590-15-005051:mdna:138]
The decrease in compensation costs during 2015 is primarily due to lower incentive compensation costs, stock-based compensation and benefits expenses, partially offset by higher salaries due to a 5% increase in headcount. The increase in professional and legal fees and outside services during 2015 reflects higher spending levels on contractors and professional services.

[0001564590-15-005051:mdna:139]
The increase in compensation costs in fiscal 2014 is primarily due to higher incentive compensation and to a lesser extent higher stock-based compensation and salaries expense. The increase in professional and legal fees and outside services during fiscal 2014 reflects higher fees related to legal activities, partially offset by lower spending levels on contractors and professional services. Bad debt expense in fiscal 2014 decreased $6.5 million compared to fiscal 2013.

[0001564590-15-005051:mdna:140]
Acquisition-related Expense (in millions, except percentages):

[0001564590-15-005051:mdna:141]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2013 |  |  | % Change |  |
| Acquisition-related expense |  | $ | — |  |  | $ | — |  |  |  | — | % |  | $ | 1.7 |  |  |  | (100 | )% |

[0001564590-15-005051:mdna:142]
During fiscal 2013, we incurred $1.7 million of acquisition costs, primarily related to severance costs associated with the termination of certain acquiree company employees.

[0001564590-15-005051:mdna:143]
Restructuring and Other Charges (in millions, except percentages):

[0001564590-15-005051:mdna:144]
|  |  | Fiscal Year |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2013 |  |  | % Change |
| Restructuring and other charges |  | $ | — |  |  | $ | 88.3 |  |  |  | (100 | )% |  | $ | — |  |  | NM |

[0001564590-15-005051:mdna:145]
NM - Not Meaningful

[0001564590-15-005051:mdna:146]
In March 2014 and May 2013, we initiated business realignment plans designed to focus our resources on key strategic initiatives and streamline our business in light of the constrained IT spending environment, resulting in a reduction of our global workforce of approximately 11% in aggregate, for which we recognized an aggregate of $88.3 million of employee severance costs in fiscal 2014. We completed all activities under these plans.

[0001564590-15-005051:mdna:147]
Other Income (Expense), Net (in millions, except percentages)

[0001564590-15-005051:mdna:148]
The components of other income (expense) were as follows:

[0001564590-15-005051:mdna:149]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2013 |  |  | % Change |  |
| Interest income |  | $ | 36.6 |  |  | $ | 34.9 |  |  |  | 5 | % |  | $ | 42.2 |  |  |  | (17 | )% |
| Interest expense |  |  | (42.0 | ) |  |  | (36.1 | ) |  |  | 16 | % |  |  | (91.7 | ) |  |  | (61 | )% |
| Net gains recognized on investments |  |  | 5.4 |  |  |  | 6.4 |  |  |  | (16 | )% |  |  | 4.3 |  |  |  | 49 | % |
| Net gains (losses) on foreign currency activities |  |  | (3.7 | ) |  |  | 1.2 |  |  | NM |  |  |  | 4.0 |  |  |  | (70 | )% |
| Total |  | $ | (3.7 | ) |  | $ | 6.4 |  |  | NM |  |  | $ | (41.2 | ) |  | NM |  |

[0001564590-15-005051:mdna:150]
NM - Not Meaningful

[0001564590-15-005051:mdna:151]
The increase in interest income during fiscal 2015 was primarily due to a shift in our investment portfolio to higher-yielding investments compared to fiscal 2014. The decrease in interest income for fiscal 2014 compared to fiscal 2013 was primarily due to a decrease in our investment portfolio as a result of the liquidation of some of our investments to repay our debt obligations and to pay for stock repurchases.

[0001564590-15-005051:mdna:152]
Interest expense, including the amortization of debt discount and issuance costs, is primarily related to our Senior Notes and Convertible Notes as summarized below:

[0001564590-15-005051:mdna:153]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Senior Notes |  | $ | 40.7 |  |  | $ | 25.1 |  |  | $ | 9.4 |  |
| Convertible Notes |  |  | — |  |  |  | 10.2 |  |  |  | 81.2 |  |
| Total |  | $ | 40.7 |  |  | $ | 35.3 |  |  | $ | 90.6 |  |

[0001564590-15-005051:mdna:154]
The increases in interest expense related to our Senior Notes reflects the issuance of our Senior Notes in fiscal years 2013 and 2015, and the decreases in interest expense related to our Convertible Notes reflects their maturity in June 2013.

[0001564590-15-005051:mdna:155]
Provision for Income Taxes (in millions, except percentages):

[0001564590-15-005051:mdna:156]
|  |  | Fiscal Year |  |
|  |  | 2015 |  |  | 2014 |  |  | % Change |  |  | 2013 |  |  | % Change |  |
| Provision for income taxes |  | $ | 152.9 |  |  | $ | 103.2 |  |  |  | 48 | % |  | $ | 61.3 |  |  |  | 68 | % |

[0001564590-15-005051:mdna:157]
Our effective tax rate for fiscal 2015 was 21.5% compared to an effective tax rate of 13.9% for fiscal 2014, and an effective tax rate of 10.8% for fiscal 2013. Our effective tax rates reflect our corporate legal entity structure and the global nature of our business with a significant amount of our profits generated and taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The effective tax rates for fiscal 2013 through fiscal 2015 were favorably impacted by the geographic mix of profits. Our effective tax rate for fiscal 2015 increased compared to the prior year primarily as a result of the settlements of income tax audits, as further discussed below.

[0001564590-15-005051:mdna:158]
The effective tax rate of 21.5% in fiscal 2015 included a benefit of $141.0 million, or 19.8 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 35%. Other key components of our effective tax rate for the year included a benefit of $13.7 million, or 1.9 percentage points, related to current and prior year research and development credits, an expense of $5.5 million, or 0.8 percentage points, attributable to non-deductible stock-based compensation, an expense of $5.4 million, or 0.8 percentage points, related to state tax provisions, and an expense of $46.4 million, or 6.5 percentage points, in connection with income tax audits.

[0001564590-15-005051:mdna:159]
The effective tax rate of 13.9% in fiscal 2014 included a benefit of $163.3 million, or 22.0 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 35%. Other key components of our effective tax rate for the year included a benefit of $8.7 million, or 1.2 percentage points, related to current year research and development credits, an expense of $9.8 million, or 1.3 percentage points, attributable to non-deductible stock-based compensation and an expense of $5.6 million, or 0.8 percentage points, related to state tax provisions.

[0001564590-15-005051:mdna:160]
The effective tax rate of 10.8% in fiscal 2013 included a benefit of $144.4 million, or 25.5 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 35%. Other key components of our effective tax rate for the year included a benefit of $12.1 million, or 2.1 percentage points, related to current year research and development credits, and an expense of $18.4 million, or 3.2 percentage points, attributable to non-deductible stock-based compensation.

[0001564590-15-005051:mdna:161]
On December 19, 2014, the federal research credit was retroactively extended for amounts paid or incurred after December 31, 2013 and before January 1, 2015. As a result of the extension, in fiscal 2015 we recorded a benefit of $9.6 million related to the fiscal 2015 research credit and a benefit of $4.1 million related to a prior year credit that we will retroactively claim. The federal research credit expired on December 31, 2014.

[0001564590-15-005051:mdna:162]
In July 2014, the Internal Revenue Service (IRS) completed the examination of our fiscal 2005 to 2007 income tax returns upon approval by the Joint Committee of Taxation. We recorded a $47.4 million income tax provision attributable to the audit settlement and related re-measurement of uncertain tax positions for tax years subject to future audits. The audit adjustments resulted in lower earnings in our foreign subsidiaries which reduced the taxability of dividends that were previously repatriated from such subsidiaries. Due to this reduction in taxable dividends, the conclusion of the fiscal 2005 to 2007 income tax audit resulted in a net refund of $8.0 million, excluding interest.

[0001564590-15-005051:mdna:163]
In October 2014, the United Kingdom’s (UK’s) tax authority concluded the examination of our fiscal 2009 to 2012 UK income tax returns. We recorded a $1.0 million income tax benefit for the net impact of the audit adjustments and related release of unrecognized tax benefits.

[0001564590-15-005051:mdna:164]
We are currently undergoing federal income tax audits in the United States and several foreign tax jurisdictions. Transfer pricing calculations are key issues under audits in various jurisdictions, and are often subject to dispute and appeals. The IRS is currently auditing our fiscal 2008 to 2010 income tax returns. We expect the IRS examination team to complete their field audit within the next twelve months. However, the resolution of the fiscal 2008 to 2010 income tax return audits may likely occur beyond the next twelve months should we choose to appeal the IRS examination team’s audit findings.

[0001564590-15-005051:mdna:165]
Our open years in U.S. federal jurisdictions are fiscal 2008 and later years. In addition, we are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal year 2001, in that we have tax attribute carryforwards from these years that could be subject to adjustments, if and when utilized.

[0001564590-15-005051:mdna:166]
On September 17, 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 from our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. On December 19, 2011, the Danish Tax Tribunal issued a ruling that our Danish subsidiary was not liable for Danish withholding tax. The Danish tax examination agency appealed to the Danish High Court in March 2012. The Danish High Court hearing has not yet occurred.

[0001564590-15-005051:mdna:167]
We continue to monitor the progress of ongoing tax controversies and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. Given the uncertainties involved, we estimate a potential decrease in our unrecognized tax benefit balance of up to $95.4 million may occur within the next 12 months associated with the potential settlements and statute lapses.

[0001564590-15-005051:mdna:168]
Liquidity, Capital Resources and Cash Requirements

[0001564590-15-005051:mdna:169]
| (In millions, except percentages) |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Cash and cash equivalents and short-term investments |  | $ | 5,326.2 |  |  | $ | 5,003.3 |  |
| Principal amount of Senior Notes |  |  | 1,500.0 |  |  |  | 1,000.0 |  |
| Debt as a % of stockholders' equity |  |  | 44 | % |  |  | 26 | % |

[0001564590-15-005051:mdna:170]
The following is a summary of our cash flow activities:

[0001564590-15-005051:mdna:171]
|  |  | Fiscal Year |  |
| (In millions) |  | 2015 |  |  | 2014 |  |
| Net cash provided by operating activities |  | $ | 1,268.1 |  |  | $ | 1,349.6 |  |
| Net cash provided by (used in) investing activities |  |  | (903.2 | ) |  |  | 760.4 |  |
| Net cash used in financing activities |  |  | (675.2 | ) |  |  | (3,104.0 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (59.2 | ) |  |  | 7.9 |  |
| Net decrease in cash and cash equivalents |  | $ | (369.5 | ) |  | $ | (986.1 | ) |

[0001564590-15-005051:mdna:172]
Cash Flows

[0001564590-15-005051:mdna:173]
As of April 24, 2015, our cash, cash equivalents and short-term investments increased by $0.3 billion from April 25, 2014 to $5.3 billion. The increase was primarily due to $494.7 million of net proceeds received from the issuance of long-term debt and $1,268.1 million of cash provided by operating activities, partially offset by $1,165.2 million in cash paid for the repurchase of our common stock. Accounts receivable DSO was 46 days for the fourth quarter of fiscal 2015 compared to 47 days for the fourth quarter of fiscal 2014, reflecting seasonal shipment linearity. Working capital increased by $287.7 million to $4.1 billion as of April 24, 2015 primarily as a result of an increase in cash, cash equivalents and short-term investments.

[0001564590-15-005051:mdna:174]
Cash Flows from Operating Activities

[0001564590-15-005051:mdna:175]
During fiscal 2015, we generated cash from operating activities of $1.3 billion. The primary sources of cash from operating activities during fiscal 2015 consisted of net income of $559.9 million, adjusted by non-cash depreciation and amortization of $307.2 million and stock-based compensation of $259.3 million.

[0001564590-15-005051:mdna:176]
Changes in assets and liabilities during fiscal 2015 included the following:

[0001564590-15-005051:mdna:177]
| · | Accounts receivable decreased primarily due to lower invoicing levels. |

[0001564590-15-005051:mdna:178]
| · | Accrued expenses decreased primarily due to employee compensation payouts related to fiscal year 2014 incentive compensation plans and restructuring obligations. |

[0001564590-15-005051:mdna:179]
| · | Deferred revenue increased due to an increase in deferred software and hardware maintenance contract revenues. |

[0001564590-15-005051:mdna:180]
During fiscal 2014, we generated cash from operating activities of $1.3 billion. The primary sources of cash from operating activities during fiscal 2014 consisted of net income of $637.5 million, adjusted by depreciation and amortization of $334.1 million and stock-based compensation of $273.0 million.

[0001564590-15-005051:mdna:181]
Changes in assets and liabilities during fiscal 2014 included the following:

[0001564590-15-005051:mdna:182]
| · | Accounts receivable increased primarily due to the impact of more back-ended shipment linearity in the fourth quarter of fiscal 2014 compared to the corresponding period in the prior year. |

[0001564590-15-005051:mdna:183]
| · | Deferred revenue increased due to an increase in deferred software and hardware maintenance contract revenues. |

[0001564590-15-005051:mdna:184]
We expect that cash provided by operating activities may materially fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, tax benefits or charges from stock-based compensation, and the timing and amount of compensation and other payments.

[0001564590-15-005051:mdna:185]
Cash Flows from Investing Activities

[0001564590-15-005051:mdna:186]
During fiscal 2015, we used $644.8 million for purchases of investments, net of maturities and sales, and paid $175.3 million for capital expenditures. In addition, we expended $84.6 million of cash on acquisitions.

[0001564590-15-005051:mdna:187]
During fiscal 2014, we generated $975.0 million from maturities and sales of investments, net of purchases, and paid $221.4 million for capital expenditures.

[0001564590-15-005051:mdna:188]
Cash Flows from Financing Activities

[0001564590-15-005051:mdna:189]
During fiscal 2015, we generated $494.7 million, net, from the issuance of long-term debt and used $1.2 billion for the repurchase of 29.6 million shares of our common stock and $207.4 million for the payment of dividends.

[0001564590-15-005051:mdna:190]
During fiscal 2014, we used $1.3 billion for the principal repayment of our Convertible Notes and used $1.9 billion for the repurchase of 47.3 million shares of our common stock and the purchase of a related forward contract and $202.3 million for the payment of dividends.

[0001564590-15-005051:mdna:191]
44

[0001564590-15-005051:mdna:192]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including potential future issuances of debt, equity or other securities, will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all.

[0001564590-15-005051:mdna:193]
Liquidity

[0001564590-15-005051:mdna:194]
Our principal sources of liquidity as of April 24, 2015 consisted of cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001564590-15-005051:mdna:195]
Cash, cash equivalents and short-term investments consist of the following (in millions):

[0001564590-15-005051:mdna:196]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Cash and cash equivalents |  | $ | 1,921.5 |  |  | $ | 2,291.0 |  |
| Short-term investments |  |  | 3,404.7 |  |  |  | 2,712.3 |  |
| Total |  | $ | 5,326.2 |  |  | $ | 5,003.3 |  |

[0001564590-15-005051:mdna:197]
As of April 24, 2015 and April 25, 2014, $4.7 billion and $4.3 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.6 billion and $0.7 billion, respectively, were available in the U.S. Most of the amounts held outside the U.S. can be repatriated to the U.S. but, under current law, would be subject to U.S. federal, state income and foreign withholding taxes. If we were to repatriate foreign earnings to fund cash requirements in the U.S., we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state tax credit carryforwards. However, our intent is to keep these funds permanently reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, and invest in critical or complementary technologies, and service interest and principal payments on our debt.

[0001564590-15-005051:mdna:198]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of April 24, 2015.

[0001564590-15-005051:mdna:199]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, and other liquidity requirements associated with our operations. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties.

[0001564590-15-005051:mdna:200]
Senior Notes

[0001564590-15-005051:mdna:201]
The following table summarizes the principal amount of our Senior Notes as of April 24, 2015 (in millions):

[0001564590-15-005051:mdna:202]
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |
| 3.375% Senior Notes Due 2021 |  |  | 500.0 |  |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |
| Total |  | $ | 1,500.0 |  |

[0001564590-15-005051:mdna:203]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 10 – Financing Arrangements of the Notes to Consolidated Financial Statements.

[0001564590-15-005051:mdna:204]
Credit Facility

[0001564590-15-005051:mdna:205]
Our credit facility, under which we may borrow up to $250.0 million, provides another potential source of liquidity. The credit facility is an unsecured five-year revolving credit facility that terminates on December 21, 2017 if no extensions have been requested by that time, and contains financial covenants requiring us to maintain a maximum leverage ratio and a minimum interest coverage ratio. We may also, subject to certain requirements, request an increase in the facility up to an additional $100.0 million and request two additional one-year extensions, subject to certain conditions. As of April 24, 2015, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-15-005051:mdna:206]
We also have an automatic shelf registration statement on file with the Securities and Exchange Commission. We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001564590-15-005051:mdna:207]
Capital Expenditure Requirements

[0001564590-15-005051:mdna:208]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for fiscal 2016 to be between $225.0 million and $275.0 million.

[0001564590-15-005051:mdna:209]
Dividends and Stock Repurchase Program

[0001564590-15-005051:mdna:210]
On May 20, 2015, we declared a cash dividend of $0.18 per share of common stock, payable on July 23, 2015 to holders of record as of the close of business on July 10, 2015.

[0001564590-15-005051:mdna:211]
Our Board of Directors has authorized the repurchase of up to $9.6 billion of our common stock under our stock repurchase program, including a $2.5 billion increase approved by our Board of Directors in February 2015. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through April 24, 2015, we repurchased a total of 214.0 million shares of our common stock at an average price of $33.48 per share, for an aggregate purchase price of $7.2 billion. As of April 24, 2015, the remaining authorized amount for stock repurchases under this program was $2.5 billion with no termination date, which we plan to complete by May 2018, with the first $1 billion expected to be purchased by the end of May 2016.

[0001564590-15-005051:mdna:212]
The timing and amount of stock repurchase transactions and future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements.

[0001564590-15-005051:mdna:213]
May 2015 Restructuring Plan

[0001564590-15-005051:mdna:214]
On May 19, 2015, we committed to a realignment designed to drive efficiency, eliminate costs and redirect resources to highest return activities. As part of the realignment, we expect to reduce our global headcount by approximately 500 employees and to incur aggregate charges of between $25 to $35 million for employee terminations and other costs associated with the realignment. We expect that most of these charges will be cash expenditures. We expect to recognize the majority of these charges in the first quarter of fiscal 2016.

[0001564590-15-005051:mdna:215]
46

[0001564590-15-005051:mdna:216]
Contractual Obligations

[0001564590-15-005051:mdna:217]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. The following table summarizes our contractual obligations at April 24, 2015 (in millions):

[0001564590-15-005051:mdna:218]
|  |  |  | 2016 |  |  |  | 2017 |  |  |  | 2018 |  |  |  | 2019 |  |  |  | 2020 |  |  | Thereafter |  |  | Total |  |
| Off-balance sheet commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Office space and equipment lease commitments |  | $ | 61.9 |  |  | $ | 44.0 |  |  | $ | 29.6 |  |  | $ | 21.0 |  |  | $ | 17.3 |  |  | $ | 31.7 |  |  | $ | 205.5 |  |
| Purchase commitments with contract manufacturers (1) |  |  | 295.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 295.0 |  |
| Construction related obligations |  |  | 60.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 60.0 |  |
| Other purchase obligations (2) |  |  | 131.2 |  |  |  | 41.6 |  |  |  | 20.7 |  |  |  | 7.0 |  |  |  | 4.0 |  |  |  | 6.5 |  |  |  | 211.0 |  |
| Total off-balance sheet commitments |  |  | 548.1 |  |  |  | 85.6 |  |  |  | 50.3 |  |  |  | 28.0 |  |  |  | 21.3 |  |  |  | 38.2 |  |  |  | 771.5 |  |
| Long-term debt obligations (3) |  |  | 40.0 |  |  |  | 40.0 |  |  |  | 790.0 |  |  |  | 25.0 |  |  |  | 25.0 |  |  |  | 799.7 |  |  |  | 1,719.7 |  |
| Long-term financing arrangements |  |  | 11.3 |  |  |  | 5.0 |  |  |  | 2.4 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 18.7 |  |
| Uncertain tax positions (4) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 193.2 |  |
| Total |  | $ | 599.4 |  |  | $ | 130.6 |  |  | $ | 842.7 |  |  | $ | 53.0 |  |  | $ | 46.3 |  |  | $ | 837.9 |  |  | $ | 2,703.1 |  |
| Other Commercial Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit |  | $ | 5.2 |  |  | $ | 1.5 |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | 0.6 |  |  | $ | 0.8 |  |  | $ | 9.3 |  |

[0001564590-15-005051:mdna:219]
| (1) | Contract manufacturer commitments consist of obligations for on-hand inventories and non-cancelable purchase orders with our contract manufacturers. We recorded a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to cost of product sales. As of April 24, 2015, such liability amounted to $16.9 million and is included in accrued expenses in our consolidated balance sheets. |

[0001564590-15-005051:mdna:220]
| (2) | Purchase obligations represent an estimate of all open purchase orders and contractual obligations in the ordinary course of business, other than commitments with contract manufacturers, for which we have not received the goods or services. Purchase obligations do not include contracts that may be cancelled without penalty. Although open purchase orders are considered enforceable and legally binding, the terms generally allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services. |

[0001564590-15-005051:mdna:221]
| (3) | Included in long-term debt are obligations related to our $1.5 billion principal amount of our Senior Notes, of which $750.0 million is due in December 2017, $500.0 million is due in June 2021 and $250.0 million is due in December 2022. Estimated interest payments for our long-term debt, assuming no early retirement of debt obligations are $219.7 million for fiscal 2016 through fiscal 2023. |

[0001564590-15-005051:mdna:222]
| (4) | As of April 24, 2015, our liability for uncertain tax positions was $193.2 million, including interest, penalties and offsetting indirect benefits, which due to the uncertainty of the timing of future payments, are presented in the total column on a separate line in this table. |

[0001564590-15-005051:mdna:223]
Some of the amounts in the table above are based on management’s estimates and assumptions, including the commitment duration, the possibility of renewal or termination, anticipated actions by management and third parties and other factors. Because these estimates and assumptions are subjective, our actual future obligations may vary from those reflected in the table.

[0001564590-15-005051:mdna:224]
Legal Contingencies

[0001564590-15-005051:mdna:225]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 18 – Commitments and Contingencies of the Notes to Consolidated Financial Statements.

[0001564590-15-005051:mdna:226]
Off-Balance Sheet Arrangements

[0001564590-15-005051:mdna:227]
In the ordinary course of business, we provide standby letters of credit or other guarantee instruments to third parties as required for certain transactions initiated either by us or our subsidiaries. As of April 24, 2015, our financial guarantees of $9.3 million that were not recorded on our consolidated balance sheets consisted primarily of standby letters of credit and surety bonds.

[0001564590-15-005051:mdna:228]
Some of our customers have entered into recourse and non-recourse financing leasing arrangements using third-party financing companies, and in some situations, we enter into customer financing arrangements for our products and services that are contemporaneously sold on a recourse or non-recourse basis to third-party financing companies. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Under the terms of the non-recourse leases, we do not have any continuing obligations or liabilities to the third-party financing companies. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of April 24, 2015 and April 25, 2014, the aggregate amount by which such contingencies exceeded the associated deferred revenue was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001564590-15-005051:mdna:229]
47

[0001564590-15-005051:mdna:230]
We enter into indemnification agreements with third parties in the ordinary course of business. Generally, these indemnification agreements require us to reimburse losses suffered by the third-parties due to various events, such as lawsuits arising from patent or copyright infringement. These indemnification obligations are considered off-balance sheet arrangements under accounting guidance.
