# NTAP 8-K — 0001102624-15-000862 filed 2015-05-20

## item codes, every 8-K on or before 2015-06-12

- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2015-06-12

- none on or before 2015-06-12

## item 2.02 — earnings release, exhibit 99.1

[0001102624-15-000862:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-15-000862:8k_2_02:2]
exh99_1.htm

[0001102624-15-000862:8k_2_02:3]
Exhibit 99.1

[0001102624-15-000862:8k_2_02:4]
|  | Press Contact: | Investor Contact: |
|  | Meghan Fintland | Kris Newton |
|  | NetApp | NetApp |
|  | 1 408 822 1389 | 1 408 822 3312 |
|  | meghan.fintland@netapp.com | kris.newton@netapp.com |

[0001102624-15-000862:8k_2_02:5]
NETAPP REPORTS FOURTH QUARTER AND FISCAL YEAR 2015 RESULTS

[0001102624-15-000862:8k_2_02:6]
Net Revenues for the Fourth Quarter of $1.54 Billion; GAAP EPS of $0.43

[0001102624-15-000862:8k_2_02:7]
and Non-GAAP EPS of $0.65

[0001102624-15-000862:8k_2_02:8]
| · | NetApp® clustered Data ONTAP® node shipments increased 163%; All Flash FAS units grew 260% for fiscal year 2015. |

[0001102624-15-000862:8k_2_02:9]
| · | Cash from operations for fiscal year 2015 was $1.27 billion. |

[0001102624-15-000862:8k_2_02:10]
| · | Increased first quarter fiscal year 2016 cash dividend by 9% to $0.18 per share. |

[0001102624-15-000862:8k_2_02:11]
Sunnyvale, Calif.—May 20, 2015—NetApp (NASDAQ: NTAP) today reported financial results for the fourth quarter and fiscal year 2015, ended April 24, 2015.

[0001102624-15-000862:8k_2_02:12]
Fourth Quarter Financial Results

[0001102624-15-000862:8k_2_02:13]
Net revenues for the fourth quarter of fiscal year 2015 were $1.54 billion. GAAP net income for the fourth quarter of fiscal year 2015 was $135 million, or $0.43 per share,1 compared to GAAP net income of $197 million, or $0.59 per share, for the comparable period of the prior year. Non-GAAP net income for the fourth quarter of fiscal year 2015 was $202 million, or $0.65 per share,2 compared to non-GAAP net income of $284 million, or $0.84 per share, for the comparable period of the prior year.

[0001102624-15-000862:8k_2_02:14]
Fiscal Year 2015 Financial Results

[0001102624-15-000862:8k_2_02:15]
Net revenues for fiscal year 2015 were $6.12 billion. GAAP net income for fiscal year 2015 was $560 million, or $1.75 per share,1 compared to GAAP net income of $638 million, or $1.83 per share, for the comparable period of the prior year. Non-GAAP net income for fiscal year 2015 was $865 million, or $2.70 per share,2 compared to non-GAAP net income of $968 million, or $2.78 per share, for the comparable period of the prior year.

[0001102624-15-000862:8k_2_02:16]
Cash, Cash Equivalents and Investments

[0001102624-15-000862:8k_2_02:17]
NetApp ended fiscal year 2015 with $5.33 billion of total cash, cash equivalents and investments and generated $1.27 billion in cash from operations. During fiscal year 2015, the Company returned $1.37 billion to shareholders through share repurchases and a cash dividend.

[0001102624-15-000862:8k_2_02:18]
The Company increased the first quarter fiscal year 2016 dividend by 9% to $0.18 per share.  The dividend will be paid on July 23, 2015, to shareholders of record as of the close of business on July 10, 2015.

[0001102624-15-000862:8k_2_02:19]
1

[0001102624-15-000862:8k_2_02:20]
“We are not satisfied with our fourth quarter results and are taking concrete action to transition NetApp for the next phase of growth,” said Tom Georgens, chairman and CEO. “Clustered ONTAP is the foundation of a Data Fabric, our vision for the future of data management, which enables enterprises to realize the value of the cloud as a seamless extension of their on-premises environment. This vision is resonating well with customers and underpins our confidence.”

[0001102624-15-000862:8k_2_02:21]
Q1 Fiscal Year 2016 Outlook

[0001102624-15-000862:8k_2_02:22]
The Company provided the following financial guidance for the first quarter of fiscal year 2016:

[0001102624-15-000862:8k_2_02:23]
| · | Net revenues are expected to be in the range of $1.275 billion to $1.375 billion |

[0001102624-15-000862:8k_2_02:24]
| · | GAAP loss per share is expected to be in the range of $0.11 to $0.06 per share |

[0001102624-15-000862:8k_2_02:25]
| · | Non-GAAP earnings per share is expected to be in the range of $0.20 to $0.25 per share |

[0001102624-15-000862:8k_2_02:26]
Business Highlights

[0001102624-15-000862:8k_2_02:27]
| · | NetApp Strengthens Partnerships: |

[0001102624-15-000862:8k_2_02:28]
|  | - | NetApp Provides a Secure Path to Transfer Data from On-premises to Amazon Web Services Cloud Solutions. As an Amazon Machine Image, three new models of NetApp SteelStore cloud-native backup solution provide an efficient and secure approach to backing up cloud-based workloads. NetApp supports Amazon Simple Storage Service (Amazon S3) as a storage tier to NetApp StorageGRID® Webscale. |

[0001102624-15-000862:8k_2_02:29]
| · | NetApp Expands Product Portfolio: |

[0001102624-15-000862:8k_2_02:30]
|  | - | New All-Flash and Hybrid Storage Arrays Accelerate High Performance for Enterprise-Class SAN Applications. The new EF560 all-flash array offers consistent latency, bandwidth and IOPS critical to enterprise database and analytics applications. The hybrid E5600 storage array delivers increased performance and reliability for more capacity-intensive SAN applications including data warehousing, email and backup. |

[0001102624-15-000862:8k_2_02:31]
| · | NetApp Expands Hybrid Cloud Solutions in Support of Data Fabric Vision: |

[0001102624-15-000862:8k_2_02:32]
|  | - | NetApp OnCommand® Insight 7.1. The new software includes enhanced features for brokering and monitoring hybrid storage deployments as well as innovations that reduce storage operating expenses and capital expenditures while improving capacity planning. |

[0001102624-15-000862:8k_2_02:33]
|  | - | OnCommand Cloud Manager Software and NetApp Cloud ONTAP® Software Subscription. Customers can simplify deployment of Cloud ONTAP and OnCommand Cloud Manager by using software subscriptions that manage NetApp’s customer data replication to the cloud with a single application. |

[0001102624-15-000862:8k_2_02:34]
|  | - | StorageGRID Appliance and StorageGRID Webscale Software for Scalable, Durable Object Storage. NetApp introduced the StorageGRID 5560 appliance and StorageGRID Webscale software 10.1, which adds support for industry-leading storage efficiency through hierarchical globally distributed erasure coding for long-term archives. |

[0001102624-15-000862:8k_2_02:35]
| · | NetApp Recognition and Awards: |

[0001102624-15-000862:8k_2_02:36]
|  | - | NetApp All-Flash Arrays Achieve Industry-Standard Benchmarks.NetApp’s all-flash EF560 achieved the leading SPC-1price-performance benchmark for all-flash arrays3 with an average response time of less than one millisecond. The NetApp All Flash FAS8080 placed #5 in the SPC-1 “Top Ten” list by Performance.3 |

[0001102624-15-000862:8k_2_02:37]
|  | - | 2015 Best Companies to Work For. For the 13th year in a row, NetApp is one of the Fortune 100 Best Companies to Work For. Being on the FORTUNE "100 Best" list is a testament to NetApp’s strong global culture and is a reflection of the passion and commitment that employees bring to work every day. |

[0001102624-15-000862:8k_2_02:38]
2

[0001102624-15-000862:8k_2_02:39]
Webcast and Conference Call Information

[0001102624-15-000862:8k_2_02:40]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:00 p.m. Pacific Time today.

[0001102624-15-000862:8k_2_02:41]
About NetApp

[0001102624-15-000862:8k_2_02:42]
Leading organizations worldwide count on NetApp for software, systems and services to manage and store their data. Customers value our teamwork, expertise and passion for helping them succeed now and into the future.

[0001102624-15-000862:8k_2_02:43]
###

[0001102624-15-000862:8k_2_02:44]
NetApp, the NetApp logo, Cloud ONTAP, Data ONTAP, OnCommand, and StorageGRID are trademarks or registered trademarks of NetApp, Inc. in the United States and/or other countries. All other marks are the property of their respective owners.

[0001102624-15-000862:8k_2_02:45]
1GAAP earnings per share is calculated using the diluted number of shares for all periods presented.

[0001102624-15-000862:8k_2_02:46]
2Non-GAAP net income excludes, when applicable, the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Effective the first quarter of fiscal 2015, the non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-reoccurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) the impact of a temporary lapse of tax law, such as the federal research credit, if such extensions have routinely been granted based on past legislative history and are expected to be reinstated in the near future. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com.

[0001102624-15-000862:8k_2_02:47]
3Storage Performance Council SPC-1 price-performance for all-flash arrays and “Top Ten” list by Performance, http://www.storageperformance.org/results/benchmark_results_spc1_top-ten/#spc1_top10_performance, January–April 2015.

[0001102624-15-000862:8k_2_02:48]
3

[0001102624-15-000862:8k_2_02:49]
NetApp Usage of Non-GAAP Financials

[0001102624-15-000862:8k_2_02:50]
The Company refers to the non-GAAP financial measures in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes, when applicable, the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Effective the  first quarter of fiscal 2015, the non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-reoccurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) the impact of a temporary lapse of tax law, such as the federal research credit, if such extensions have routinely been granted based on past legislative history and are expected to be reinstated in the near future. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods.

[0001102624-15-000862:8k_2_02:51]
We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has limitations and they should not solely be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we provide non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-15-000862:8k_2_02:52]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation.

[0001102624-15-000862:8k_2_02:53]
4

[0001102624-15-000862:8k_2_02:54]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,326.2 |  |  | $ | 5,003.3 |  |
| Accounts receivable |  |  | 778.9 |  |  |  | 855.9 |  |
| Inventories |  |  | 146.5 |  |  |  | 122.4 |  |
| Other current assets |  |  | 521.8 |  |  |  | 489.7 |  |
| Total current assets |  |  | 6,773.4 |  |  |  | 6,471.3 |  |
| Property and equipment, net |  |  | 1,029.9 |  |  |  | 1,108.8 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,116.9 |  |  |  | 1,109.6 |  |
| Other non-current assets(1) |  |  | 481.0 |  |  |  | 524.1 |  |
| Total assets |  | $ | 9,401.2 |  |  | $ | 9,213.8 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 283.4 |  |  | $ | 247.0 |  |
| Accrued expenses |  |  | 701.4 |  |  |  | 793.8 |  |
| Short-term deferred revenue |  |  | 1,724.2 |  |  |  | 1,653.8 |  |
| Total current liabilities |  |  | 2,709.0 |  |  |  | 2,694.6 |  |
| Long-term debt(1) |  |  | 1,487.5 |  |  |  | 990.1 |  |
| Other long-term liabilities |  |  | 317.6 |  |  |  | 296.2 |  |
| Long-term deferred revenue |  |  | 1,473.0 |  |  |  | 1,446.4 |  |
| Total liabilities |  |  | 5,987.1 |  |  |  | 5,427.3 |  |
| Stockholders' equity |  |  | 3,414.1 |  |  |  | 3,786.5 |  |
| Total liabilities and stockholders' equity |  | $ | 9,401.2 |  |  | $ | 9,213.8 |  |
| (1) In the fourth quarter of fiscal 2015, we adopted a new accounting standard that resulted in a reclassification of debt issuance costs of $7.5 million and $5.4 million as of April 24, 2015 and April 25, 2014, respectively from other assets to an offset to long-term debt. |  |

[0001102624-15-000862:8k_2_02:55]
5

[0001102624-15-000862:8k_2_02:56]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 913.4 |  |  | $ | 1,042.8 |  |  | $ | 3,654.6 |  |  | $ | 3,943.9 |  |
| Software maintenance |  |  | 226.5 |  |  |  | 227.5 |  |  |  | 898.6 |  |  |  | 914.8 |  |
| Hardware maintenance and other services |  |  | 399.8 |  |  |  | 378.7 |  |  |  | 1,569.5 |  |  |  | 1,466.4 |  |
| Net revenues |  |  | 1,539.7 |  |  |  | 1,649.0 |  |  |  | 6,122.7 |  |  |  | 6,325.1 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 441.3 |  |  |  | 453.2 |  |  |  | 1,656.9 |  |  |  | 1,777.1 |  |
| Cost of software maintenance |  |  | 9.5 |  |  |  | 8.0 |  |  |  | 35.7 |  |  |  | 30.7 |  |
| Cost of hardware maintenance and other services |  |  | 153.7 |  |  |  | 145.8 |  |  |  | 596.9 |  |  |  | 598.2 |  |
| Total cost of revenues |  |  | 604.5 |  |  |  | 607.0 |  |  |  | 2,289.5 |  |  |  | 2,406.0 |  |
| Gross profit |  |  | 935.2 |  |  |  | 1,042.0 |  |  |  | 3,833.2 |  |  |  | 3,919.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 470.2 |  |  |  | 475.0 |  |  |  | 1,913.2 |  |  |  | 1,898.2 |  |
| Research and development |  |  | 232.4 |  |  |  | 230.7 |  |  |  | 919.3 |  |  |  | 917.3 |  |
| General and administrative |  |  | 71.0 |  |  |  | 73.7 |  |  |  | 284.2 |  |  |  | 281.0 |  |
| Restructuring and other charges |  |  | - |  |  |  | 38.8 |  |  |  | - |  |  |  | 88.3 |  |
| Total operating expenses |  |  | 773.6 |  |  |  | 818.2 |  |  |  | 3,116.7 |  |  |  | 3,184.8 |  |
| Income from operations |  |  | 161.6 |  |  |  | 223.8 |  |  |  | 716.5 |  |  |  | 734.3 |  |
| Other income (expense), net |  |  | 2.5 |  |  |  | 2.8 |  |  |  | (3.7 | ) |  |  | 6.4 |  |
| Income before income taxes |  |  | 164.1 |  |  |  | 226.6 |  |  |  | 712.8 |  |  |  | 740.7 |  |
| Provision for income taxes |  |  | 29.2 |  |  |  | 29.6 |  |  |  | 152.9 |  |  |  | 103.2 |  |
| Net income |  | $ | 134.9 |  |  | $ | 197.0 |  |  | $ | 559.9 |  |  | $ | 637.5 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.44 |  |  | $ | 0.60 |  |  | $ | 1.77 |  |  | $ | 1.87 |  |
| Diluted |  | $ | 0.43 |  |  | $ | 0.59 |  |  | $ | 1.75 |  |  | $ | 1.83 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 308.8 |  |  |  | 330.2 |  |  |  | 315.5 |  |  |  | 340.3 |  |
| Diluted |  |  | 313.3 |  |  |  | 336.4 |  |  |  | 320.7 |  |  |  | 347.9 |  |
| Cash dividends declared per share |  | $ | 0.165 |  |  | $ | 0.150 |  |  | $ | 0.660 |  |  | $ | 0.600 |  |

[0001102624-15-000862:8k_2_02:57]
6

[0001102624-15-000862:8k_2_02:58]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 134.9 |  |  | $ | 197.0 |  |  | $ | 559.9 |  |  | $ | 637.5 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 72.6 |  |  |  | 82.1 |  |  |  | 307.2 |  |  |  | 334.1 |  |
| Stock-based compensation |  |  | 63.2 |  |  |  | 67.2 |  |  |  | 259.3 |  |  |  | 273.0 |  |
| Excess tax benefit from stock-based compensation |  |  | (1.4 | ) |  |  | (19.1 | ) |  |  | (55.2 | ) |  |  | (52.5 | ) |
| Other, net |  |  | 2.3 |  |  |  | (26.3 | ) |  |  | 31.9 |  |  |  | (48.7 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (111.9 | ) |  |  | (270.0 | ) |  |  | 74.8 |  |  |  | (56.6 | ) |
| Inventories |  |  | (28.7 | ) |  |  | (4.3 | ) |  |  | (24.1 | ) |  |  | 17.0 |  |
| Accounts payable |  |  | 84.5 |  |  |  | 57.7 |  |  |  | 38.6 |  |  |  | (12.1 | ) |
| Accrued expenses |  |  | 95.4 |  |  |  | 126.8 |  |  |  | (66.7 | ) |  |  | 32.3 |  |
| Deferred revenue |  |  | 87.7 |  |  |  | 133.6 |  |  |  | 122.1 |  |  |  | 106.6 |  |
| Changes in other operating assets and liabilities, net |  |  | (2.0 | ) |  |  | 24.8 |  |  |  | 20.3 |  |  |  | 119.0 |  |
| Net cash provided by operating activities |  |  | 396.6 |  |  |  | 369.5 |  |  |  | 1,268.1 |  |  |  | 1,349.6 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | (686.4 | ) |  |  | 212.3 |  |  |  | (644.8 | ) |  |  | 975.0 |  |
| Purchases of property and equipment |  |  | (37.2 | ) |  |  | (56.0 | ) |  |  | (175.3 | ) |  |  | (221.4 | ) |
| Acquisitions of businesses |  |  | - |  |  |  | - |  |  |  | (84.6 | ) |  |  | - |  |
| Other investing activities, net |  |  | (1.0 | ) |  |  | 4.2 |  |  |  | 1.5 |  |  |  | 6.8 |  |
| Net cash provided by (used in) investing activities |  |  | (724.6 | ) |  |  | 160.5 |  |  |  | (903.2 | ) |  |  | 760.4 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 11.3 |  |  |  | 9.6 |  |  |  | 156.9 |  |  |  | 201.4 |  |
| Repurchase of common stock and forward contract |  |  | (246.3 | ) |  |  | (374.5 | ) |  |  | (1,165.2 | ) |  |  | (1,881.5 | ) |
| Excess tax benefit from stock-based compensation |  |  | 1.4 |  |  |  | 19.1 |  |  |  | 55.2 |  |  |  | 52.5 |  |
| Repayment of debt |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (1,264.9 | ) |
| Issuance of long-term debt, net |  |  | - |  |  |  | - |  |  |  | 494.7 |  |  |  | - |  |
| Dividends paid |  |  | (50.5 | ) |  |  | (49.2 | ) |  |  | (207.4 | ) |  |  | (202.3 | ) |
| Other financing activities, net |  |  | (1.8 | ) |  |  | (1.7 | ) |  |  | (9.4 | ) |  |  | (9.2 | ) |
| Net cash used in financing activities |  |  | (285.9 | ) |  |  | (396.7 | ) |  |  | (675.2 | ) |  |  | (3,104.0 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (4.3 | ) |  |  | 5.0 |  |  |  | (59.2 | ) |  |  | 7.9 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | (618.2 | ) |  |  | 138.3 |  |  |  | (369.5 | ) |  |  | (986.1 | ) |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,539.7 |  |  |  | 2,152.7 |  |  |  | 2,291.0 |  |  |  | 3,277.1 |  |
| End of period |  | $ | 1,921.5 |  |  | $ | 2,291.0 |  |  | $ | 1,921.5 |  |  | $ | 2,291.0 |  |

[0001102624-15-000862:8k_2_02:59]
7

[0001102624-15-000862:8k_2_02:60]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q4 FY'15 |  |  | Q3 FY’15 |  |  | Q4 FY’14 |  |  | FY 2015 |  |  | FY 2014 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 913.4 |  |  | $ | 929.5 |  |  | $ | 1,042.8 |  |  | $ | 3,654.6 |  |  | $ | 3,943.9 |  |
| Software Maintenance |  |  | 226.5 |  |  |  | 226.6 |  |  |  | 227.5 |  |  |  | 898.6 |  |  |  | 914.8 |  |
| Hardware Maintenance & Other Services: |  |  | 399.8 |  |  |  | 395.2 |  |  |  | 378.7 |  |  |  | 1,569.5 |  |  |  | 1,466.4 |  |
| Hardware Maintenance Support Contracts |  |  | 323.1 |  |  |  | 315.6 |  |  |  | 293.7 |  |  |  | 1,252.5 |  |  |  | 1,129.6 |  |
| Professional & Other Services |  |  | 76.7 |  |  |  | 79.6 |  |  |  | 85.0 |  |  |  | 317.0 |  |  |  | 336.7 |  |
| Net Revenues |  | $ | 1,539.7 |  |  | $ | 1,551.3 |  |  | $ | 1,649.0 |  |  | $ | 6,122.7 |  |  | $ | 6,325.1 |  |
| Software Maintenance revenue was formerly called Software Entitlements & Maintenance (SEM) revenue. |  |  |  |  |  |  |  |  |
| Hardware Maintenance & Other Services revenue was formerly called Services revenue. |  |  |  |  |  |  |  |  |
| Branded and OEM Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'15 |  |  | Q3 FY’15 |  |  | Q4 FY’14 |  |  | FY 2015 |  |  | FY 2014 |  |
| Branded Revenue |  | $ | 1,438.0 |  |  | $ | 1,427.5 |  |  | $ | 1,539.2 |  |  | $ | 5,649.9 |  |  | $ | 5,740.4 |  |
| OEM Revenue |  |  | 101.7 |  |  |  | 123.8 |  |  |  | 109.8 |  |  |  | 472.8 |  |  |  | 584.7 |  |
| Net Revenues |  | $ | 1,539.7 |  |  | $ | 1,551.3 |  |  | $ | 1,649.0 |  |  | $ | 6,122.7 |  |  | $ | 6,325.1 |  |
| Branded revenue includes revenue from all products and services sold directly by us or our partners under the NetApp brand, including NetApp branded E-Series products and solutions. |
| OEM revenue comprises revenue from the sale of our products by other companies under their brands and includes revenue from IBM, Fujitsu, and other E-Series OEM relationships. |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'15 Revenue |  |  | % of Q3 FY'15 Revenue |  |  | % of Q4 FY'14 Revenue |  |  | % of FY 2015 Revenue |  |  | % of FY 2014 Revenue |  |
| Americas |  |  | 57 | % |  |  | 54 | % |  |  | 56 | % |  |  | 56 | % |  |  | 56 | % |
| Americas Commercial |  |  | 43 | % |  |  | 44 | % |  |  | 43 | % |  |  | 43 | % |  |  | 43 | % |
| U.S. Public Sector |  |  | 14 | % |  |  | 10 | % |  |  | 12 | % |  |  | 13 | % |  |  | 12 | % |
| EMEA |  |  | 30 | % |  |  | 33 | % |  |  | 31 | % |  |  | 30 | % |  |  | 31 | % |
| Asia Pacific |  |  | 13 | % |  |  | 13 | % |  |  | 13 | % |  |  | 13 | % |  |  | 14 | % |
| Pathways Mix |  |  |  |  |  |
|  |  | % of Q4 FY'15 Revenue |  |  | % of Q3 FY'15 Revenue |  |  | % of Q4 FY'14 Revenue |  |  | % of FY 2015 Revenue |  |  | % of FY 2014 Revenue |  |
| Direct |  |  | 21 | % |  |  | 19 | % |  |  | 17 | % |  |  | 20 | % |  |  | 18 | % |
| Indirect |  |  | 79 | % |  |  | 81 | % |  |  | 83 | % |  |  | 80 | % |  |  | 82 | % |
| Direct revenues are those sold through our direct sales force. Indirect revenues include those sold through value-added resellers, system integrators, OEMs and distributors. |
| Indirect revenue reflects order fulfillment and is not reflective of who is responsible for the customer relationship. |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'15 |  |  | Q3 FY’15 |  |  | Q4 FY’14 |  |  | FY 2015 |  |  | FY 2014 |  |
| Non-GAAP Gross Margin |  |  | 62.0 | % |  |  | 64.6 | % |  |  | 64.4 | % |  |  | 64.0 | % |  |  | 63.2 | % |
| Product |  |  | 53.4 | % |  |  | 57.0 | % |  |  | 58.0 | % |  |  | 56.5 | % |  |  | 56.5 | % |
| Software Maintenance |  |  | 95.8 | % |  |  | 95.9 | % |  |  | 96.5 | % |  |  | 96.0 | % |  |  | 96.6 | % |
| Hardware Maintenance & Other Services |  |  | 62.6 | % |  |  | 64.5 | % |  |  | 62.7 | % |  |  | 63.1 | % |  |  | 60.5 | % |
| Non-GAAP Income from Operations, Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'15 |  |  | Q3 FY’15 |  |  | Q4 FY’14 |  |  | FY 2015 |  |  | FY 2014 |  |
| Non-GAAP Income from Operations |  | $ | 240.3 |  |  | $ | 287.7 |  |  | $ | 344.4 |  |  | $ | 1,039.5 |  |  | $ | 1,154.7 |  |
| % of Net Revenues |  |  | 15.6 | % |  |  | 18.5 | % |  |  | 20.9 | % |  |  | 17.0 | % |  |  | 18.3 | % |
| Non-GAAP Income before Income Taxes |  | $ | 242.8 |  |  | $ | 285.3 |  |  | $ | 347.2 |  |  | $ | 1,035.8 |  |  | $ | 1,169.3 |  |
| Non-GAAP Effective Tax Rate |  |  | 16.7 | % |  |  | 16.5 | % |  |  | 18.1 | % |  |  | 16.5 | % |  |  | 17.2 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'15 |  |  | Q3 FY’15 |  |  | Q4 FY’14 |  |  | FY 2015 |  |  | FY 2014 |  |
| Non-GAAP Net Income |  | $ | 202.3 |  |  | $ | 238.3 |  |  | $ | 284.2 |  |  | $ | 864.5 |  |  | $ | 968.2 |  |
| Weighted Average Common Shares Outstanding, Diluted |  |  | 313.3 |  |  |  | 317.1 |  |  |  | 336.4 |  |  |  | 320.7 |  |  |  | 347.9 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 0.65 |  |  | $ | 0.75 |  |  | $ | 0.84 |  |  | $ | 2.70 |  |  | $ | 2.78 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'15 |  |  | Q3 FY’15 |  |  | Q4 FY’14 |  |  |  |  |  |  |  |  |  |
| Deferred Revenue |  | $ | 3,197.2 |  |  | $ | 3,109.7 |  |  | $ | 3,100.2 |  |  |  |  |  |  |  |  |  |
| DSO (days) |  |  | 46 |  |  |  | 39 |  |  |  | 47 |  |  |  |  |  |  |  |  |  |
| Inventory Turns |  |  | 16 |  |  |  | 19 |  |  |  | 19 |  |  |  |  |  |  |  |  |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized non-GAAP cost of revenues divided by net inventories. |  |  |  |  |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'15 |  |  | Q3 FY’15 |  |  | Q4 FY’14 |  |  | FY 2015 |  |  | FY 2014 |  |
| Net Cash Provided by Operating Activities |  | $ | 396.6 |  |  | $ | 274.6 |  |  | $ | 369.5 |  |  | $ | 1,268.1 |  |  | $ | 1,349.6 |  |
| Purchases of Property and Equipment |  | $ | 37.2 |  |  | $ | 28.6 |  |  | $ | 56.0 |  |  | $ | 175.3 |  |  | $ | 221.4 |  |
| Free Cash Flow |  | $ | 359.4 |  |  | $ | 246.0 |  |  | $ | 313.5 |  |  | $ | 1,092.8 |  |  | $ | 1,128.2 |  |
| Free Cash Flow as % of Net Revenues |  |  | 23.3 | % |  |  | 15.9 | % |  |  | 19.0 | % |  |  | 17.8 | % |  |  | 17.8 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |  |  |  |  |  |  |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001102624-15-000862:8k_2_02:61]
8

[0001102624-15-000862:8k_2_02:62]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY15 |  |  | Q3'FY15 |  |  | Q4'FY14 |  |  | FY2015 |  |  | FY2014 |  |
| NET INCOME |  | $ | 134.9 |  |  | $ | 176.8 |  |  | $ | 197.0 |  |  | $ | 559.9 |  |  | $ | 637.5 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 15.5 |  |  |  | 19.2 |  |  |  | 14.6 |  |  |  | 63.7 |  |  |  | 59.1 |  |
| Stock-based compensation |  |  | 63.2 |  |  |  | 66.0 |  |  |  | 67.2 |  |  |  | 259.3 |  |  |  | 273.0 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 38.8 |  |  |  | - |  |  |  | 88.3 |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 8.2 |  |
| Income tax effect of non-GAAP adjustments |  |  | (11.3 | ) |  |  | (23.7 | ) |  |  | (33.4 | ) |  |  | (65.8 | ) |  |  | (97.9 | ) |
| Settlement of income tax audit |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 47.4 |  |  |  | - |  |
| NON-GAAP NET INCOME |  | $ | 202.3 |  |  | $ | 238.3 |  |  | $ | 284.2 |  |  | $ | 864.5 |  |  | $ | 968.2 |  |
| COST OF REVENUES |  | $ | 604.5 |  |  | $ | 573.9 |  |  | $ | 607.0 |  |  | $ | 2,289.5 |  |  | $ | 2,406.0 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (15.2 | ) |  |  | (18.9 | ) |  |  | (14.3 | ) |  |  | (62.6 | ) |  |  | (57.1 | ) |
| Stock-based compensation |  |  | (4.9 | ) |  |  | (5.4 | ) |  |  | (5.3 | ) |  |  | (21.8 | ) |  |  | (22.3 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 584.4 |  |  | $ | 549.6 |  |  | $ | 587.4 |  |  | $ | 2,205.1 |  |  | $ | 2,326.6 |  |
| COST OF PRODUCT REVENUES |  | $ | 441.3 |  |  | $ | 419.6 |  |  | $ | 453.2 |  |  | $ | 1,656.9 |  |  | $ | 1,777.1 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14.7 | ) |  |  | (18.3 | ) |  |  | (13.7 | ) |  |  | (60.4 | ) |  |  | (54.8 | ) |
| Stock-based compensation |  |  | (1.3 | ) |  |  | (1.4 | ) |  |  | (1.4 | ) |  |  | (5.8 | ) |  |  | (5.6 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 425.3 |  |  | $ | 399.9 |  |  | $ | 438.1 |  |  | $ | 1,590.7 |  |  | $ | 1,716.7 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 153.7 |  |  | $ | 144.9 |  |  | $ | 145.8 |  |  | $ | 596.9 |  |  | $ | 598.2 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.5 | ) |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | (2.2 | ) |  |  | (2.3 | ) |
| Stock-based compensation |  |  | (3.6 | ) |  |  | (4.0 | ) |  |  | (3.9 | ) |  |  | (16.0 | ) |  |  | (16.7 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 149.6 |  |  | $ | 140.3 |  |  | $ | 141.3 |  |  | $ | 578.7 |  |  | $ | 579.2 |  |
| GROSS PROFIT |  | $ | 935.2 |  |  | $ | 977.4 |  |  | $ | 1,042.0 |  |  | $ | 3,833.2 |  |  | $ | 3,919.1 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 15.2 |  |  |  | 18.9 |  |  |  | 14.3 |  |  |  | 62.6 |  |  |  | 57.1 |  |
| Stock-based compensation |  |  | 4.9 |  |  |  | 5.4 |  |  |  | 5.3 |  |  |  | 21.8 |  |  |  | 22.3 |  |
| NON-GAAP GROSS PROFIT |  | $ | 955.3 |  |  | $ | 1,001.7 |  |  | $ | 1,061.6 |  |  | $ | 3,917.6 |  |  | $ | 3,998.5 |  |
| SALES AND MARKETING EXPENSES |  | $ | 470.2 |  |  | $ | 474.8 |  |  | $ | 475.0 |  |  | $ | 1,913.2 |  |  | $ | 1,898.2 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (1.1 | ) |  |  | (2.0 | ) |
| Stock-based compensation |  |  | (29.5 | ) |  |  | (29.6 | ) |  |  | (30.4 | ) |  |  | (116.5 | ) |  |  | (125.0 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 440.4 |  |  | $ | 444.9 |  |  | $ | 444.3 |  |  | $ | 1,795.6 |  |  | $ | 1,771.2 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 232.4 |  |  | $ | 229.9 |  |  | $ | 230.7 |  |  | $ | 919.3 |  |  | $ | 917.3 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (19.5 | ) |  |  | (21.9 | ) |  |  | (21.1 | ) |  |  | (84.1 | ) |  |  | (87.7 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 212.9 |  |  | $ | 208.0 |  |  | $ | 209.6 |  |  | $ | 835.2 |  |  | $ | 829.6 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 71.0 |  |  | $ | 70.2 |  |  | $ | 73.7 |  |  | $ | 284.2 |  |  | $ | 281.0 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (9.3 | ) |  |  | (9.1 | ) |  |  | (10.4 | ) |  |  | (36.9 | ) |  |  | (38.0 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 61.7 |  |  | $ | 61.1 |  |  | $ | 63.3 |  |  | $ | 247.3 |  |  | $ | 243.0 |  |

[0001102624-15-000862:8k_2_02:63]
9

[0001102624-15-000862:8k_2_02:64]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY15 |  |  | Q3'FY15 |  |  | Q4'FY14 |  |  | FY2015 |  |  | FY2014 |  |
| RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | - |  |  | $ | 38.8 |  |  | $ | - |  |  | $ | 88.3 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | (38.8 | ) |  |  | - |  |  |  | (88.3 | ) |
| NON-GAAP RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| OPERATING EXPENSES |  | $ | 773.6 |  |  | $ | 774.9 |  |  | $ | 818.2 |  |  | $ | 3,116.7 |  |  | $ | 3,184.8 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (1.1 | ) |  |  | (2.0 | ) |
| Stock-based compensation |  |  | (58.3 | ) |  |  | (60.6 | ) |  |  | (61.9 | ) |  |  | (237.5 | ) |  |  | (250.7 | ) |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | (38.8 | ) |  |  | - |  |  |  | (88.3 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 715.0 |  |  | $ | 714.0 |  |  | $ | 717.2 |  |  | $ | 2,878.1 |  |  | $ | 2,843.8 |  |
| INCOME FROM OPERATIONS |  | $ | 161.6 |  |  | $ | 202.5 |  |  | $ | 223.8 |  |  | $ | 716.5 |  |  | $ | 734.3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 15.5 |  |  |  | 19.2 |  |  |  | 14.6 |  |  |  | 63.7 |  |  |  | 59.1 |  |
| Stock-based compensation |  |  | 63.2 |  |  |  | 66.0 |  |  |  | 67.2 |  |  |  | 259.3 |  |  |  | 273.0 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 38.8 |  |  |  | - |  |  |  | 88.3 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 240.3 |  |  | $ | 287.7 |  |  | $ | 344.4 |  |  | $ | 1,039.5 |  |  | $ | 1,154.7 |  |
| OTHER INCOME (EXPENSE), NET |  | $ | 2.5 |  |  | $ | (2.4 | ) |  | $ | 2.8 |  |  | $ | (3.7 | ) |  | $ | 6.4 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 8.2 |  |
| NON-GAAP OTHER INCOME (EXPENSE), NET |  | $ | 2.5 |  |  | $ | (2.4 | ) |  | $ | 2.8 |  |  | $ | (3.7 | ) |  | $ | 14.6 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 164.1 |  |  | $ | 200.1 |  |  | $ | 226.6 |  |  | $ | 712.8 |  |  | $ | 740.7 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 15.5 |  |  |  | 19.2 |  |  |  | 14.6 |  |  |  | 63.7 |  |  |  | 59.1 |  |
| Stock-based compensation |  |  | 63.2 |  |  |  | 66.0 |  |  |  | 67.2 |  |  |  | 259.3 |  |  |  | 273.0 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 38.8 |  |  |  | - |  |  |  | 88.3 |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 8.2 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 242.8 |  |  | $ | 285.3 |  |  | $ | 347.2 |  |  | $ | 1,035.8 |  |  | $ | 1,169.3 |  |
| PROVISION FOR INCOME TAXES |  | $ | 29.2 |  |  | $ | 23.3 |  |  | $ | 29.6 |  |  | $ | 152.9 |  |  | $ | 103.2 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | 11.3 |  |  |  | 23.7 |  |  |  | 33.4 |  |  |  | 65.8 |  |  |  | 97.9 |  |
| Settlement of income tax audit |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (47.4 | ) |  |  | - |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 40.5 |  |  | $ | 47.0 |  |  | $ | 63.0 |  |  | $ | 171.3 |  |  | $ | 201.1 |  |
| NET INCOME PER SHARE |  | $ | 0.43 |  |  | $ | 0.56 |  |  | $ | 0.59 |  |  | $ | 1.75 |  |  | $ | 1.83 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  |  | 0.06 |  |  |  | 0.04 |  |  |  | 0.20 |  |  |  | 0.17 |  |
| Stock-based compensation |  |  | 0.20 |  |  |  | 0.21 |  |  |  | 0.20 |  |  |  | 0.81 |  |  |  | 0.79 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 0.11 |  |  |  | - |  |  |  | 0.25 |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.02 |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.04 | ) |  |  | (0.07 | ) |  |  | (0.10 | ) |  |  | (0.21 | ) |  |  | (0.28 | ) |
| Settlement of income tax audit |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.15 |  |  |  | - |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.65 |  |  | $ | 0.75 |  |  | $ | 0.84 |  |  | $ | 2.70 |  |  | $ | 2.78 |  |

[0001102624-15-000862:8k_2_02:65]
10

[0001102624-15-000862:8k_2_02:66]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY15 |  |  | Q3'FY15 |  |  | Q4'FY14 |  |  | FY2015 |  |  | FY2014 |  |
| Gross margin-GAAP |  |  | 60.7 | % |  |  | 63.0 | % |  |  | 63.2 | % |  |  | 62.6 | % |  |  | 62.0 | % |
| Cost of revenues adjustments |  |  | 1.3 | % |  |  | 1.6 | % |  |  | 1.2 | % |  |  | 1.4 | % |  |  | 1.3 | % |
| Gross margin-Non-GAAP |  |  | 62.0 | % |  |  | 64.6 | % |  |  | 64.4 | % |  |  | 64.0 | % |  |  | 63.2 | % |
| GAAP cost of revenues |  | $ | 604.5 |  |  | $ | 573.9 |  |  | $ | 607.0 |  |  | $ | 2,289.5 |  |  | $ | 2,406.0 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (15.2 | ) |  |  | (18.9 | ) |  |  | (14.3 | ) |  |  | (62.6 | ) |  |  | (57.1 | ) |
| Stock-based compensation |  |  | (4.9 | ) |  |  | (5.4 | ) |  |  | (5.3 | ) |  |  | (21.8 | ) |  |  | (22.3 | ) |
| Non-GAAP cost of revenues |  | $ | 584.4 |  |  | $ | 549.6 |  |  | $ | 587.4 |  |  | $ | 2,205.1 |  |  | $ | 2,326.6 |  |
| Net revenues |  | $ | 1,539.7 |  |  | $ | 1,551.3 |  |  | $ | 1,649.0 |  |  | $ | 6,122.7 |  |  | $ | 6,325.1 |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY15 |  |  | Q3'FY15 |  |  | Q4'FY14 |  |  | FY2015 |  |  | FY2014 |  |
| Product gross margin-GAAP |  |  | 51.7 | % |  |  | 54.9 | % |  |  | 56.5 | % |  |  | 54.7 | % |  |  | 54.9 | % |
| Cost of product revenues adjustments |  |  | 1.8 | % |  |  | 2.1 | % |  |  | 1.4 | % |  |  | 1.8 | % |  |  | 1.5 | % |
| Product gross margin-Non-GAAP |  |  | 53.4 | % |  |  | 57.0 | % |  |  | 58.0 | % |  |  | 56.5 | % |  |  | 56.5 | % |
| GAAP cost of product revenues |  | $ | 441.3 |  |  | $ | 419.6 |  |  | $ | 453.2 |  |  | $ | 1,656.9 |  |  | $ | 1,777.1 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14.7 | ) |  |  | (18.3 | ) |  |  | (13.7 | ) |  |  | (60.4 | ) |  |  | (54.8 | ) |
| Stock-based compensation |  |  | (1.3 | ) |  |  | (1.4 | ) |  |  | (1.4 | ) |  |  | (5.8 | ) |  |  | (5.6 | ) |
| Non-GAAP cost of product revenues |  | $ | 425.3 |  |  | $ | 399.9 |  |  | $ | 438.1 |  |  | $ | 1,590.7 |  |  | $ | 1,716.7 |  |
| Product revenues |  | $ | 913.4 |  |  | $ | 929.5 |  |  | $ | 1,042.8 |  |  | $ | 3,654.6 |  |  | $ | 3,943.9 |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY15 |  |  | Q3'FY15 |  |  | Q4'FY14 |  |  | FY2015 |  |  | FY2014 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 61.6 | % |  |  | 63.3 | % |  |  | 61.5 | % |  |  | 62.0 | % |  |  | 59.2 | % |
| Cost of hardware maintenance and other services revenues adjustments |  |  | 1.0 | % |  |  | 1.2 | % |  |  | 1.2 | % |  |  | 1.2 | % |  |  | 1.3 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 62.6 | % |  |  | 64.5 | % |  |  | 62.7 | % |  |  | 63.1 | % |  |  | 60.5 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 153.7 |  |  | $ | 144.9 |  |  | $ | 145.8 |  |  | $ | 596.9 |  |  | $ | 598.2 |  |
| Cost of hardware maintenance and other services revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.5 | ) |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | (2.2 | ) |  |  | (2.3 | ) |
| Stock-based compensation |  |  | (3.6 | ) |  |  | (4.0 | ) |  |  | (3.9 | ) |  |  | (16.0 | ) |  |  | (16.7 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 149.6 |  |  | $ | 140.3 |  |  | $ | 141.3 |  |  | $ | 578.7 |  |  | $ | 579.2 |  |
| Hardware maintenance and other services revenues |  | $ | 399.8 |  |  | $ | 395.2 |  |  | $ | 378.7 |  |  | $ | 1,569.5 |  |  | $ | 1,466.4 |  |

[0001102624-15-000862:8k_2_02:67]
11

[0001102624-15-000862:8k_2_02:68]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q4'FY15 |  |  | Q3'FY15 |  |  | Q4'FY14 |  |  | FY2015 |  |  | FY2014 |  |
| GAAP effective tax rate |  |  | 17.8 | % |  |  | 11.6 | % |  |  | 13.1 | % |  |  | 21.5 | % |  |  | 13.9 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | (1.1 | %) |  |  | 4.9 | % |  |  | 5.1 | % |  |  | (0.3 | %) |  |  | 3.3 | % |
| Settlement of income tax audit |  |  | - | % |  |  | - | % |  |  | - | % |  |  | (4.6 | %) |  |  | - | % |
| Non-GAAP effective tax rate |  |  | 16.7 | % |  |  | 16.5 | % |  |  | 18.1 | % |  |  | 16.5 | % |  |  | 17.2 | % |
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q4'FY15 |  |  | Q3'FY15 |  |  | Q4'FY14 |  |  | FY2015 |  |  | FY2014 |  |
| Net cash provided by operating activities |  | $ | 396.6 |  |  | $ | 274.6 |  |  | $ | 369.5 |  |  | $ | 1,268.1 |  |  | $ | 1,349.6 |  |
| Purchases of property and equipment |  |  | (37.2 | ) |  |  | (28.6 | ) |  |  | (56.0 | ) |  |  | (175.3 | ) |  |  | (221.4 | ) |
| Free cash flow |  | $ | 359.4 |  |  | $ | 246.0 |  |  | $ | 313.5 |  |  | $ | 1,092.8 |  |  | $ | 1,128.2 |  |
| INVENTORY TURNS AND RECONCILIATION OF NON-GAAP TO GAAP |  |
| COST OF REVENUES USED IN INVENTORY TURNS |  |
| (In millions, except annualized inventory turns) |  |
|  |  | Q4'FY15 |  |  | Q3'FY15 |  |  | Q4'FY14 |  |  |  |  |  |  |  |  |  |
| Annualized inventory turns-GAAP |  |  | 17 |  |  |  | 19 |  |  |  | 20 |  |  |  |  |  |  |  |  |  |
| Cost of revenues adjustments |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |  |  |  |  |  |  |  |  |
| Annualized inventory turns-Non-GAAP |  |  | 16 |  |  |  | 19 |  |  |  | 19 |  |  |  |  |  |  |  |  |  |
| GAAP cost of revenues |  | $ | 604.5 |  |  | $ | 573.9 |  |  | $ | 607.0 |  |  |  |  |  |  |  |  |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (15.2 | ) |  |  | (18.9 | ) |  |  | (14.3 | ) |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (4.9 | ) |  |  | (5.4 | ) |  |  | (5.3 | ) |  |  |  |  |  |  |  |  |
| Non-GAAP cost of revenues |  | $ | 584.4 |  |  | $ | 549.6 |  |  | $ | 587.4 |  |  |  |  |  |  |  |  |  |
| Inventory |  | $ | 146.5 |  |  | $ | 117.8 |  |  | $ | 122.4 |  |  |  |  |  |  |  |  |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001102624-15-000862:8k_2_02:69]
12

[0001102624-15-000862:8k_2_02:70]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS (LOSS) PER SHARE |
| FIRST QUARTER FISCAL 2016 |
|  | First Quarter |
|  | Fiscal 2016 |
| Non-GAAP Guidance - Net Income Per Share* | $0.20 - $0.25 |
| Adjustments of Specific Items to Net Income |  |
| Per Share for the First Quarter Fiscal 2016: |  |
| Amortization of intangible assets | (0.05) |
| Stock-based compensation expense | (0.24) |
| Restructuring charges | (0.09) |
| Income tax effect of non-GAAP adjustments | 0.07 |
| Total Adjustments | (0.31) |
| GAAP Guidance - Net Loss Per Share** | $(0.11) - $(0.06) |
| *Non-GAAP net income per share was computed using forecasted diluted shares of 315 million. |
| **GAAP net loss per share was computed using forecasted basic shares of 309 million. |

[0001102624-15-000862:8k_2_02:71]
13
