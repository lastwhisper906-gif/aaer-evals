# NTAP notes — 0001564590-15-005051


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-15-005051:notes:1]
1. Description of Business and Significant Accounting Policies

[0001564590-15-005051:notes:2]
Description of Business —NetApp, Inc. (we, us, or the Company) provide software, systems and services to manage and store computer data. We enable enterprises, service providers, governmental organizations, and original equipment manufacturers to envision, deploy and evolve their information technology environments and to reduce costs and risk while driving growth and success for their organizations.

[0001564590-15-005051:notes:3]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year that ends on the last Friday in April. Our fiscal years 2015, 2014 and 2013 ended on April 24, 2015, April 25, 2014 and April 26, 2013, respectively, and were each 52-week years. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2016 will span 53 weeks, with a 14th week included in the first quarter of fiscal 2016. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended on the last Friday of April and the associated quarters, months and periods of those fiscal years.

[0001564590-15-005051:notes:4]
Principles of Consolidation — The consolidated financial statements include the Company and its subsidiaries. Intercompany accounts and transactions are eliminated in consolidation.

[0001564590-15-005051:notes:5]
Accounting Change — In our fourth quarter of fiscal 2015, we adopted an Accounting Standards Update (ASU) that simplifies the presentation of debt issuance costs by requiring them to be presented as a direct deduction from the carrying amount of the related debt liability, rather than as a deferred charge, consistent with debt discounts. The new guidance was applied on a retrospective basis to April 25, 2014. The amended presentation of debt issuance costs resulted in a $7.5 million and $5.4 million reduction of each of other non-current assets and long-term debt in the consolidated balance sheets as of April 24, 2015 and April 25, 2014, respectively.

[0001564590-15-005051:notes:6]
Use of Estimates — The preparation of the consolidated financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-15-005051:notes:7]
Cash Equivalents — We consider all highly liquid debt investments with original maturities of three months or less at the time of purchase to be cash equivalents.

[0001564590-15-005051:notes:8]
Available-for-Sale Investments — We classify our investments in debt securities as available-for-sale investments. Debt securities primarily consist of corporate bonds, U.S. Treasury and government debt securities and certificates of deposit. These available-for-sale investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of debt securities sold. These investments are recorded in the consolidated balance sheets at fair value.

[0001564590-15-005051:notes:9]
Unrealized gains and temporary losses, net of related taxes, are included in accumulated other comprehensive income (loss) (AOCI). Upon realization, those amounts are reclassified from AOCI to earnings. The amortization of premiums and discounts on the investments are included in our results of operations. Realized gains and losses on our available-for-sale investments are calculated based on the specific identification method.

[0001564590-15-005051:notes:10]
We classify our investments as current or noncurrent based on the nature of the investments and their availability for use in current operations.

[0001564590-15-005051:notes:11]
Other-than-Temporary Impairments on Investments — All of our available-for-sale investments are subject to periodic impairment review. When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and we assess whether the impairment is other-than-temporary. An impairment is considered other-than-temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of the entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost basis of the security. If impairment is considered other-than-temporary based on condition (i) or (ii) described above, the entire difference between the amortized cost and the fair value of the debt security is recognized in the results of operations. If an impairment is considered other-than-temporary based on condition (iii) described above, the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in earnings, and the amount relating to all other factors is recognized in other comprehensive income (OCI).

[0001564590-15-005051:notes:12]
For our auction rate securities (ARSs), impairment was determined based on fair value and marketability of these investments. The valuation models used to estimate fair value include numerous assumptions such as assessments of the underlying structure of each security, expected cash flows, discount rates, trading activity in the secondary market for similar securities, credit ratings, workout periods, and overall capital market liquidity.

[0001564590-15-005051:notes:13]
Inventories — Inventories are stated at the lower of cost or market, which approximates actual cost on a first-in, first-out basis. We write down excess and obsolete inventory based on the difference between the cost of inventory and the estimated net realizable value based upon assumptions about future demand forecasts and market conditions. At the point of a loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts or circumstances do not result in the restoration or increase in that newly established basis. In addition, we record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0001564590-15-005051:notes:14]
Property and Equipment — Property and equipment are recorded at cost.

[0001564590-15-005051:notes:15]
Depreciation and amortization is computed using the straight-line method, generally over the following periods:

[0001564590-15-005051:notes:16]
|  |  | Depreciation Life |
| Buildings and improvements |  | 10 to 40 years |
| Furniture and fixtures |  | 5 years |
| Computer, production, engineering and other equipment |  | 2 to 3 years |
| Computer software |  | 3 to 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |

[0001564590-15-005051:notes:17]
Construction in progress will be depreciated over the estimated useful lives of the respective assets when they are ready for use. We capitalize interest on significant facility assets under construction and on significant software development projects.

[0001564590-15-005051:notes:18]
Software Development Costs — The costs for the development of new software products and substantial enhancements to existing software products are expensed as incurred until technological feasibility has been established, at which time any additional costs would be capitalized in accordance with the accounting guidance for software. Because our current process for developing software is essentially completed concurrently with the establishment of technological feasibility, which occurs upon the completion of a working model, no costs have been capitalized for any of the periods presented.

[0001564590-15-005051:notes:19]
Internal-Use Software Development Costs — We capitalize qualifying costs, which are incurred during the application development stage, for computer software developed or obtained for internal-use and amortize them over the software’s estimated useful life.

[0001564590-15-005051:notes:20]
Business Combinations — We recognize identifiable assets acquired and liabilities assumed at their acquisition date fair values. Goodwill as of the acquisition date is measured as the excess of consideration transferred over the net of the acquisition date fair values of the assets acquired and the liabilities assumed. While we use our best estimates and assumptions as a part of the purchase price allocation process to accurately value assets acquired and liabilities assumed at the acquisition date, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001564590-15-005051:notes:21]
Goodwill and Purchased Intangible Assets — Goodwill is recorded when the consideration paid for an acquisition exceeds the fair value of net tangible and intangible assets acquired. Purchased intangible assets are amortized on a straight-line basis over their economic lives of three to six years for developed technology, two to eight years for customer contracts/relationships, two to three years for covenants not to compete and two to seven years for trademarks and trade names as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed.

[0001564590-15-005051:notes:22]
The carrying value of goodwill is tested for impairment on an annual basis in the fourth quarter of our fiscal year, or more frequently if we believe indicators of impairment exist. Triggering events for impairment reviews may be indicators such as adverse industry or economic trends, restructuring actions, lower projections of profitability, or a sustained decline in our market capitalization. The performance of the test involves a two-step process. The first step requires comparing the fair value of each of our reporting units to its net book value, including goodwill. We have three reporting units, the fair values of which are determined based on an allocation of our entity level market capitalization, as determined through quoted market prices. A potential impairment exists if the fair value of the reporting unit is lower than its net book value. The second step of the process is only performed if a potential impairment exists, and it involves determining the difference between the fair value of the reporting unit’s net assets other than goodwill and the fair value of the reporting unit. If that difference is less than the net book value of goodwill, an impairment exists and is recorded. We have not been required to perform this second step of the process because the fair values of each of our reporting units have exceeded their respective net book values in fiscal 2015, 2014 and 2013.

[0001564590-15-005051:notes:23]
Impairment of Long-Lived Assets — We review the carrying values of long-lived assets whenever events and circumstances, such as reductions in demand, lower projections of profitability, significant changes in the manner of our use of acquired assets, or significant negative industry or economic trends, indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. If this review indicates that there is an impairment, the impaired asset is written down to its fair value, which is typically calculated using: (i) quoted market prices and/or (ii) expected future cash flows utilizing a discount rate. Our estimates regarding future anticipated net revenue and cash flows, the remaining economic life of the products and technologies, or both, may differ from those used to assess the recoverability of assets. In that event, impairment charges or shortened useful lives of certain long-lived assets may be required, resulting in charges to our consolidated statements of operations when such determinations are made.

[0001564590-15-005051:notes:24]
Derivative Instruments — Our derivative instruments consist of foreign currency exchange contracts as described below:

[0001564590-15-005051:notes:25]
Balance Sheet Hedges — We utilize foreign currency exchange forward and option contracts to hedge against the short-term impact of foreign currency exchange rate fluctuations related to certain foreign currency denominated monetary assets and liabilities, primarily intercompany receivables and payables. These derivative instruments are not designated as hedging instruments and do not subject us to material balance sheet risk due to exchange rate movements because the gains and losses on these contracts are intended to offset the gains and losses in the underlying foreign currency denominated monetary assets and liabilities being hedged and the net amount is included in earnings.

[0001564590-15-005051:notes:26]
Cash Flow Hedges — We use foreign currency exchange forward contracts to hedge foreign currency exchange exposures related to forecasted sales transactions denominated in certain foreign currencies. These derivative instruments are designated and qualify as cash flow hedges and in general, closely match the underlying forecasted transactions in duration. The contracts are carried in the consolidated balance sheets at fair value, and the effective portion of the contracts’ gains and losses resulting from changes in fair value is recorded in AOCI until the forecasted transaction is recognized in the consolidated statements of operations. When the forecasted transactions occur, we reclassify the related gains or losses on the cash flow hedges into net revenues. If the underlying forecasted transactions do not occur, or it becomes probable that they will not occur within the defined hedge period, the gains or losses on the related cash flow hedges are reclassified from AOCI and recognized immediately in earnings. We measure the effectiveness of hedges of forecasted transactions on a monthly basis by comparing the fair values of the designated foreign currency exchange forward purchase contracts with the fair values of the forecasted transactions. Any ineffective portion of the derivative hedging gain or loss, as well as changes in the fair value of the derivative’s time value (which are excluded from the assessment of hedge effectiveness), are recognized in earnings.

[0001564590-15-005051:notes:27]
Factors that could have an impact on the effectiveness of our hedging programs include the accuracy of forecasts and the volatility of foreign currency markets. These programs reduce, but do not entirely eliminate, the impact of currency exchange movements. Currently, we do not enter into any foreign currency exchange forward contracts to hedge exposures related to firm commitments or nonmarketable investments. Cash flows from our derivative programs are included under operating activities in the consolidated statements of cash flows.

[0001564590-15-005051:notes:28]
Revenue Recognition — We recognize revenue when:

[0001564590-15-005051:notes:29]
| · | Persuasive evidence of an arrangement exists. Customarily we have a purchase order and/or contract prior to recognizing revenue on an arrangement from our end users, customers, value-added resellers or distributors. |

[0001564590-15-005051:notes:30]
| · | Delivery has occurred. Our product is physically delivered to our customers. We typically do not allow for restocking rights with any of our value-added resellers or distributors. Products shipped with acceptance criteria or return rights are not recognized as revenue until all criteria are achieved. We do not recognize revenue if undelivered products or services exist that are essential to the functionality of the delivered product in an arrangement. |

[0001564590-15-005051:notes:31]
| · | The fee is fixed or determinable. Arrangements with payment terms extending beyond our standard terms, conditions and practices are not considered to be fixed or determinable. Revenue from such arrangements is recognized at the earlier of customer payment or when the fees become due and payable. We typically do not allow for price-protection rights with any of our value-added resellers or distributors. |

[0001564590-15-005051:notes:32]
| · | Collection is reasonably assured. If there is considerable doubt surrounding the creditworthiness of a customer at the outset of an arrangement, the associated revenue is deferred and recognized upon cash receipt. |

[0001564590-15-005051:notes:33]
The hardware systems and software components essential to the functionality of the hardware systems are considered non-software deliverables and therefore are not subject to industry-specific software revenue recognition guidance.

[0001564590-15-005051:notes:34]
Our product revenues also include revenues from the sale of non-essential software products. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales are subject to the industry-specific software revenue recognition guidance.

[0001564590-15-005051:notes:35]
Our multiple element arrangements may include our systems, software maintenance, hardware maintenance and other services. Software maintenance contracts entitle our customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, and patch releases. Hardware maintenance services include contracts for extended warranty, technical support and minimum response times. Other services include professional services and customer education and training services. Revenues from software maintenance and hardware maintenance services are recognized ratably over the contractual term, generally from one to five years. We also offer extended warranty contracts (which extend our standard parts warranty and may include premium hardware maintenance) at the end of the original warranty term; revenues from these contracts are recognized ratably over their respective contract term. We sell professional services either on a time and materials basis or under fixed price projects; we recognize revenue for these services as they are performed.

[0001564590-15-005051:notes:36]
For multiple element arrangements, we allocate revenue to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement. The selling price for each element is based upon the following selling price hierarchy: vendor specific objective evidence of selling price (VSOE) if available, third party evidence (TPE) if VSOE is not available, or estimated selling price (ESP) if neither VSOE nor TPE are available. ESP is generally evidenced by a majority of historical transactions falling within a reasonable price range. We also consider multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, type of customer and distribution channels. For our non-software deliverables, we generally allocate the arrangement consideration based on the relative selling price of the deliverables using ESP. For our software maintenance services, we generally use VSOE. When we are unable to establish VSOE for our software maintenance services, we use ESP in our allocation of arrangement consideration.

[0001564590-15-005051:notes:37]
VSOE is based upon the normal pricing and discounting practices for those services when sold separately. VSOE is generally evidenced by a substantial majority of historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer type, and other variables in determining VSOE.

[0001564590-15-005051:notes:38]
When VSOE cannot be established, we attempt to establish the selling price of each element based on third party evidence of selling price (TPE). Generally, we are not able to determine TPE because our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained.

[0001564590-15-005051:notes:39]
We regularly review VSOE, TPE, and ESP and maintain internal controls over the establishment and updates of these estimates.

[0001564590-15-005051:notes:40]
For our software deliverables, we use the residual method to recognize revenue when an arrangement includes one or more elements to be delivered at a future date and VSOE of all undelivered elements exists. Typically, only software maintenance, hardware maintenance and/or other services remain undelivered after the product is delivered. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the consideration is recognized as product revenues for delivered elements. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is software maintenance, the entire arrangement is recognized ratably over the maintenance period.

[0001564590-15-005051:notes:41]
We record reductions to revenue for estimated sales returns at the time of shipment. Sales returns are estimated based on historical sales returns, current trends, and our expectations regarding future experience. We monitor and analyze the accuracy of sales returns estimates by reviewing actual returns and adjust them for future expectations. Additionally, distributors and retail partners participate in various cooperative marketing and other programs, and we record estimated accruals and allowances for these programs. We accrue for these programs based on contractual terms and historical experience. Sales and value added taxes collected from customers and remitted to governmental authorities are presented on a net basis in the accompanying consolidated statements of operations.

[0001564590-15-005051:notes:42]
Product Warranties — Estimated future hardware and software warranty costs are recorded as a cost of product revenues at the time of product shipment, based on historical and projected warranty claim rates, historical and projected cost-per-claim and knowledge of specific product failures that are outside our typical experience. Factors that affect our warranty liability include the number of installed units subject to warranty protection, product failure rates, estimated material costs, estimated distribution costs and estimated labor costs. We assess the adequacy of our warranty accrual each quarter and adjust the amount as considered necessary.

[0001564590-15-005051:notes:43]
Foreign Currency Translation — For international subsidiaries whose functional currency is the local currency, gains and losses resulting from translation of these foreign currency financial statements into U.S. dollars are recorded in AOCI. For subsidiaries where the functional currency is the U.S. dollar, gains and losses resulting from the process of remeasuring foreign currency financial statements into U.S. dollars are included in other income (expense), net.

[0001564590-15-005051:notes:44]
Benefit Plans — We have a postretirement health care plan and various international defined benefit plans for certain of our employees. We record actuarial gains and losses within AOCI and amortize net gains or losses in excess of 10 percent of the greater of the market value of plan assets or the plans' projected benefit obligation on a straight-line basis over the remaining estimated service life of plan participants. The measurement date for all defined benefit plans is our fiscal year end.

[0001564590-15-005051:notes:45]
Stock-Based Compensation — We measure and recognize stock-based compensation for all stock-based awards, including employee stock options, restricted stock units (RSUs) and rights to purchase shares under our employee stock purchase plan (ESPP), based on their estimated fair value, and recognize the costs in our financial statements using the single option straight-line approach over the requisite service period for the entire award.

[0001564590-15-005051:notes:46]
The fair value of employee RSUs is equal to the market value of our common stock on the grant date of the award, less the present value of expected dividends during the vesting period, discounted at a risk-free interest rate. Calculating the fair value of employee stock options and the rights to purchase shares under the ESPP requires estimates and significant judgment. The fair value of each award is estimated on the grant date using the Black-Scholes option pricing model, and is not remeasured as a result of subsequent stock price fluctuations. Option-pricing models require the input of highly subjective assumptions, including the expected term of awards and the stock price volatility of the underlying stock of such awards. Our expected term assumption is based primarily on historical exercise and post-vesting forfeiture experience. Effective fiscal 2013, our stock price volatility assumption is based on a combination of our historical and implied volatility, whereas prior to fiscal 2013, we solely used implied volatility.

[0001564590-15-005051:notes:47]
In addition, the Black-Scholes option pricing model requires risk-free interest rates and expected dividends. The risk-free interest rates are based upon United States Treasury bills with equivalent expected terms, and the expected dividends are based on our history and expected dividend payouts.

[0001564590-15-005051:notes:48]
We estimate the number of stock-based awards that will be forfeited due to employee turnover. Our forfeiture assumption is primarily based on historical experience.

[0001564590-15-005051:notes:49]
In the event of a modification of stock-based awards, if the requisite service period of the modified award is longer than the requisite service period of the original award and, both before and after the modification, it is probable that the awards will vest, we recognize the unrecognized compensation cost remaining from the original award plus the incremental compensation cost, if any, as a result of a modification in its entirety over the remaining portion of the requisite service period of the modified award.

[0001564590-15-005051:notes:50]
Income Taxes — Deferred income tax assets and liabilities are provided for temporary differences that will result in tax deductions or income in future periods, as well as the future benefit of tax credit carryforwards. A valuation allowance reduces tax assets to their estimated realizable value. Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001564590-15-005051:notes:51]
The accounting guidance for income taxes prescribes a comprehensive model for how a company should recognize, measure, present, and disclose in its financial statements uncertain tax positions that we have taken or expect to take on a tax return (including a decision whether to file or not to file a return in a particular jurisdiction). We recognize the tax liability for uncertain income tax positions on the income tax return based on the two-step process prescribed in the interpretation. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. The Company recognizes interest and penalties related to unrecognized tax benefits within the income tax expense line in the accompanying consolidated statement of operations.

[0001564590-15-005051:notes:52]
Determining the liability for uncertain tax positions requires us to make significant estimates and judgments as to whether, and the extent to which, additional taxes may be due based on potential tax audit issues in the U.S. and other tax jurisdictions throughout the world. Our estimates are based on the outcomes of previous audits, as well as the precedents set in cases in which others have taken similar tax positions to those taken by us. If we later determine that our exposure is lower or that the liability is not sufficient to cover our revised expectations, we adjust the liability and effect a related change in our tax provision during the period in which we make such a determination.

[0001564590-15-005051:notes:53]
Tax attributes related to the exercise of employee stock options are not realized until they result in a reduction of taxes payable. We do not include unrealized stock option attributes as components of our gross deferred tax assets and corresponding valuation allowance disclosures.

[0001564590-15-005051:notes:54]
Net Income per Share — Basic net income per share is computed by dividing income available to common stockholders by the weighted-average number of common shares outstanding. Diluted net income per share is computed giving effect to all dilutive potential shares that were outstanding during the period. Potential dilutive common shares can consist of outstanding stock options, shares to be purchased under our employee stock purchase plan and unvested RSUs, as well as outstanding warrants and shares to be issued upon the conversion of convertible notes.

[0001564590-15-005051:notes:55]
Treasury Stock — We account for treasury stock under the cost method. Upon the retirement of treasury stock, we allocate the value of treasury shares between common stock, additional paid-in capital and retained earnings.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-15-005051:notes:56]
2. Concentration of Risk

[0001564590-15-005051:notes:57]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, investments, foreign currency exchange contracts and accounts receivable. Cash equivalents and short-term investments consist primarily of corporate bonds, U.S. Treasury and government debt securities and certificates of deposit, all of which are considered high investment grade. Our policy is to limit the amount of credit exposure through diversification and investment in highly rated securities. We further mitigate concentrations of credit risk in our investments by limiting our investments in the debt securities of a single issuer and by diversifying risk across geographies and type of issuer.

[0001564590-15-005051:notes:58]
By entering into foreign currency exchange contracts, we have assumed the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and we do not expect any losses as a result of counterparty defaults.

[0001564590-15-005051:notes:59]
We sell our products primarily to large organizations in different industries and geographies. We do not require collateral or other security to support accounts receivable. In addition, we maintain an allowance for potential credit losses. To reduce credit risk, we perform ongoing credit evaluations on our customers’ financial condition. We establish an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information and, to date, such losses have been within management’s expectations. Concentrations of credit risk with respect to trade accounts receivable are limited due to the wide variety of customers who are dispersed across many geographic regions.

[0001564590-15-005051:notes:60]
There are no concentrations of business transacted with a particular market that would severely impact our business in the near term. However, we rely on a limited number of suppliers for certain key components and a few key contract manufacturers to manufacture most of our products; any disruption or termination of these arrangements could materially adversely affect our operating results.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-15-005051:notes:61]
4. Statements of Cash Flows Additional Information

[0001564590-15-005051:notes:62]
Non-cash investing activities and supplemental cash flow information are as follows (in millions):

[0001564590-15-005051:notes:63]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Reclassification of equity component of Convertible Notes |  | $ | — |  |  | $ | — |  |  | $ | 62.6 |  |
| Capital expenditures incurred but not paid |  | $ | 12.1 |  |  | $ | 18.0 |  |  | $ | 20.2 |  |
| Acquisition of software through long-term financing |  | $ | 12.3 |  |  | $ | 11.4 |  |  | $ | 0.8 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 97.4 |  |  | $ | 58.1 |  |  | $ | 46.7 |  |
| Interest paid |  | $ | 32.7 |  |  | $ | 35.2 |  |  | $ | 22.8 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-15-005051:notes:64]
5. Business Combinations

[0001564590-15-005051:notes:65]
Fiscal 2015 Acquisitions

[0001564590-15-005051:notes:66]
On October 27, 2014, we completed the acquisition of certain assets related to Riverbed Technology, Inc.’s SteelStore product line for $79.1 million in cash. The SteelStore product line supports leading backup applications and cloud providers so that customers have a choice in how they extend their existing data protection infrastructure into the cloud.

[0001564590-15-005051:notes:67]
In addition, on the same date, we acquired certain intangible assets from a privately-held software developer for $5.5 million in cash.

[0001564590-15-005051:notes:68]
The preliminary fair values of assets acquired and liabilities assumed as of the closing date are summarized as follows (in millions):

[0001564590-15-005051:notes:69]
| Prepaid expenses and other current assets |  | $ | 2.7 |  |
| Finite-lived intangible assets |  |  | 31.8 |  |
| Goodwill |  |  | 39.3 |  |
| Deferred income taxes |  |  | 10.8 |  |
| Other non-current assets |  |  | 1.1 |  |
| Total assets acquired |  |  | 85.7 |  |
| Deferred revenue |  |  | (1.1 | ) |
| Total purchase price |  | $ | 84.6 |  |

[0001564590-15-005051:notes:70]
The results of operations related to these acquisitions have been included in our consolidated statements of operations from the acquisition date. Pro forma results of operations have not been presented because the acquisitions were not material to our results of operations.

[0001564590-15-005051:notes:71]
Fiscal 2013 Acquisitions

[0001564590-15-005051:notes:72]
Consideration related to our fiscal 2013 acquisitions consisted of the following (in millions):

[0001564590-15-005051:notes:73]
| Cash |  | $ | 106.9 |  |
| Equity |  |  | 1.2 |  |
| Total purchase price |  | $ | 108.1 |  |

[0001564590-15-005051:notes:74]
The allocation of the purchase consideration for business combinations completed in fiscal 2013 is summarized as follows (in millions):

[0001564590-15-005051:notes:75]
| Net liabilities assumed |  | $ | (5.1 | ) |
| Finite-lived intangible assets |  |  | 30.3 |  |
| Goodwill |  |  | 82.9 |  |
| Total purchase price |  | $ | 108.1 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-15-005051:notes:76]
6. Goodwill and Purchased Intangible Assets, Net

[0001564590-15-005051:notes:77]
Goodwill activity is summarized as follows (in millions):

[0001564590-15-005051:notes:78]
| Balance as of April 26, 2013 |  | $ | 988.1 |  |
| Goodwill acquired |  |  | — |  |
| Balance as of April 25, 2014 |  |  | 988.1 |  |
| Goodwill acquired |  |  | 39.3 |  |
| Balance as of April 24, 2015 |  | $ | 1,027.4 |  |

[0001564590-15-005051:notes:79]
We conducted our annual goodwill impairment test during the fourth quarter of fiscal 2015. Based on this analysis, we determined that there was no impairment to goodwill. We will continue to monitor our recorded goodwill for indicators of impairment.

[0001564590-15-005051:notes:80]
Purchased intangible assets, net are summarized below (in millions):

[0001564590-15-005051:notes:81]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 312.4 |  |  | $ | (225.2 | ) |  | $ | 87.2 |  |  | $ | 283.0 |  |  | $ | (162.6 | ) |  | $ | 120.4 |  |
| Customer contracts/relationships |  |  | 5.0 |  |  |  | (2.7 | ) |  |  | 2.3 |  |  |  | 9.6 |  |  |  | (9.0 | ) |  |  | 0.6 |  |
| Other purchased intangibles |  |  | 2.9 |  |  |  | (2.9 | ) |  |  | — |  |  |  | 4.5 |  |  |  | (4.0 | ) |  |  | 0.5 |  |
| Total purchased intangible assets |  | $ | 320.3 |  |  | $ | (230.8 | ) |  | $ | 89.5 |  |  | $ | 297.1 |  |  | $ | (175.6 | ) |  | $ | 121.5 |  |

[0001564590-15-005051:notes:82]
Amortization expense for purchased intangible assets is summarized below (in millions):

[0001564590-15-005051:notes:83]
|  |  | Year Ended |  |  | Statement of |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |  | Operations Classifications |
| Developed technology |  | $ | 62.6 |  |  | $ | 57.1 |  |  | $ | 55.9 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 0.7 |  |  |  | 1.0 |  |  |  | 25.2 |  |  | Operating expenses |
| Other purchased intangibles |  |  | 0.4 |  |  |  | 1.0 |  |  |  | 4.7 |  |  | Operating expenses |
| Total |  | $ | 63.7 |  |  | $ | 59.1 |  |  | $ | 85.8 |  |  |  |

[0001564590-15-005051:notes:84]
As of April 24, 2015, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-15-005051:notes:85]
| Fiscal Year |  | Amount |  |
| 2016 |  | $ | 58.4 |  |
| 2017 |  |  | 13.9 |  |
| 2018 |  |  | 9.4 |  |
| 2019 |  |  | 5.2 |  |
| 2020 |  |  | 2.6 |  |
| Total |  | $ | 89.5 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-15-005051:notes:86]
7. Balance Sheet Details

[0001564590-15-005051:notes:87]
Cash and cash equivalents (in millions):

[0001564590-15-005051:notes:88]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Cash |  | $ | 1,666.3 |  |  | $ | 2,174.0 |  |
| Cash equivalents |  |  | 255.2 |  |  |  | 117.0 |  |
| Cash and cash equivalents |  | $ | 1,921.5 |  |  | $ | 2,291.0 |  |

[0001564590-15-005051:notes:89]
Inventories (in millions):

[0001564590-15-005051:notes:90]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Purchased components |  | $ | 36.2 |  |  | $ | 17.6 |  |
| Finished goods |  |  | 110.3 |  |  |  | 104.8 |  |
| Inventories |  | $ | 146.5 |  |  | $ | 122.4 |  |

[0001564590-15-005051:notes:91]
Other current assets (in millions):

[0001564590-15-005051:notes:92]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Prepaid expenses and other current assets |  | $ | 268.3 |  |  | $ | 219.4 |  |
| Deferred tax assets |  |  | 253.5 |  |  |  | 270.3 |  |
| Other current assets |  | $ | 521.8 |  |  | $ | 489.7 |  |

[0001564590-15-005051:notes:93]
Property and equipment, net (in millions):

[0001564590-15-005051:notes:94]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Land |  | $ | 265.5 |  |  | $ | 265.7 |  |
| Buildings and improvements |  |  | 607.0 |  |  |  | 541.7 |  |
| Leasehold improvements |  |  | 106.6 |  |  |  | 102.9 |  |
| Computer, production, engineering and other equipment |  |  | 753.7 |  |  |  | 753.8 |  |
| Computer software |  |  | 371.9 |  |  |  | 369.1 |  |
| Furniture and fixtures |  |  | 85.4 |  |  |  | 86.4 |  |
| Construction-in-progress |  |  | 33.0 |  |  |  | 72.9 |  |
|  |  |  | 2,223.1 |  |  |  | 2,192.5 |  |
| Accumulated depreciation and amortization |  |  | (1,193.2 | ) |  |  | (1,083.7 | ) |
| Property and equipment, net |  | $ | 1,029.9 |  |  | $ | 1,108.8 |  |

[0001564590-15-005051:notes:95]
The net book value of computer software, which includes capitalized internal-use software development costs, is summarized below (in millions):

[0001564590-15-005051:notes:96]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Computer software |  | $ | 58.5 |  |  | $ | 103.5 |  |

[0001564590-15-005051:notes:97]
Depreciation and amortization expense related to property and equipment, net is summarized below (in millions):

[0001564590-15-005051:notes:98]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Depreciation and amortization expense |  | $ | 243.5 |  |  | $ | 275.0 |  |  | $ | 258.8 |  |

[0001564590-15-005051:notes:99]
Included in depreciation and amortization expense above is amortization related to computer software, as summarized below (in millions):

[0001564590-15-005051:notes:100]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Computer software amortization expense |  | $ | 84.6 |  |  | $ | 74.4 |  |  | $ | 76.7 |  |

[0001564590-15-005051:notes:101]
Other non-current assets (in millions):

[0001564590-15-005051:notes:102]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Auction rate securities |  | $ | — |  |  | $ | 36.0 |  |
| Deferred tax assets |  |  | 255.9 |  |  |  | 245.0 |  |
| Other assets |  |  | 225.1 |  |  |  | 243.1 |  |
| Other non-current assets |  | $ | 481.0 |  |  | $ | 524.1 |  |

[0001564590-15-005051:notes:103]
Accrued expenses (in millions):

[0001564590-15-005051:notes:104]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Accrued compensation and benefits |  | $ | 358.8 |  |  | $ | 407.8 |  |
| Product warranty liability |  |  | 57.8 |  |  |  | 73.0 |  |
| Other current liabilities |  |  | 284.8 |  |  |  | 313.0 |  |
| Accrued expenses |  | $ | 701.4 |  |  | $ | 793.8 |  |

[0001564590-15-005051:notes:105]
Product warranty liabilities:

[0001564590-15-005051:notes:106]
Equipment and software systems sales include a standard product warranty. The following tables summarize the activity related to product warranty liabilities and their balances as reported in our consolidated balance sheets (in millions):

[0001564590-15-005051:notes:107]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Balance at beginning of year |  | $ | 110.0 |  |  | $ | 117.2 |  |
| Expense accrued during the year |  |  | 35.2 |  |  |  | 70.2 |  |
| Warranty costs incurred |  |  | (59.5 | ) |  |  | (77.4 | ) |
| Balance at end of year |  | $ | 85.7 |  |  | $ | 110.0 |  |

[0001564590-15-005051:notes:108]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Accrued expenses |  | $ | 57.8 |  |  | $ | 73.0 |  |
| Other long-term liabilities |  |  | 27.9 |  |  |  | 37.0 |  |
| Total warranty liabilities |  | $ | 85.7 |  |  | $ | 110.0 |  |

[0001564590-15-005051:notes:109]
Warranty expense accrued during the period includes amounts accrued for systems at the time of shipment, adjustments for changes in estimated costs for warranties on systems shipped in the period and changes in estimated costs for warranties on systems shipped in prior periods.

[0001564590-15-005051:notes:110]
Short-term and long-term deferred revenue (in millions):

[0001564590-15-005051:notes:111]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Product |  | $ | 17.4 |  |  | $ | 23.4 |  |
| Services |  |  | 3,179.8 |  |  |  | 3,076.8 |  |
| Total |  | $ | 3,197.2 |  |  | $ | 3,100.2 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,724.2 |  |  | $ | 1,653.8 |  |
| Long-term |  |  | 1,473.0 |  |  |  | 1,446.4 |  |
| Total |  | $ | 3,197.2 |  |  | $ | 3,100.2 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-15-005051:notes:112]
8. Other income (expense), net

[0001564590-15-005051:notes:113]
Other income (expense), net consists of the following (in millions):

[0001564590-15-005051:notes:114]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Interest income |  | $ | 36.6 |  |  | $ | 34.9 |  |  | $ | 42.2 |  |
| Interest expense |  |  | (42.0 | ) |  |  | (36.1 | ) |  |  | (91.7 | ) |
| Other income, net |  |  | 1.7 |  |  |  | 7.6 |  |  |  | 8.3 |  |
| Total other income (expense), net |  | $ | (3.7 | ) |  | $ | 6.4 |  |  | $ | (41.2 | ) |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-15-005051:notes:115]
9. Financial Instruments and Fair Value Measurements

[0001564590-15-005051:notes:116]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis, whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the three levels of inputs to measure fair value:

[0001564590-15-005051:notes:117]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001564590-15-005051:notes:118]
Level 2: Inputs that reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; benchmark yields, reported trades, broker/dealer quotes, inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0001564590-15-005051:notes:119]
Level 3: Unobservable inputs that reflect our own assumptions incorporated in valuation techniques used to measure fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0001564590-15-005051:notes:120]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and consider an inactive market to be one in which there are infrequent or few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty’s non-performance risk is considered in measuring the fair values of liabilities and assets, respectively.

[0001564590-15-005051:notes:121]
Investments

[0001564590-15-005051:notes:122]
The following is a summary of our investments (in millions):

[0001564590-15-005051:notes:123]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 2,249.4 |  |  | $ | 8.7 |  |  | $ | (0.5 | ) |  |  | 2,257.6 |  |  | $ | 2,142.3 |  |  | $ | 10.5 |  |  | $ | (0.5 | ) |  | $ | 2,152.3 |  |
| U.S. Treasury and government debt securities |  |  | 1,055.7 |  |  |  | 2.5 |  |  |  | — |  |  |  | 1,058.2 |  |  |  | 263.4 |  |  |  | 0.3 |  |  |  | (0.1 | ) |  |  | 263.6 |  |
| Foreign government debt securities |  |  | 37.7 |  |  |  | 0.2 |  |  |  | — |  |  |  | 37.9 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Commercial paper |  |  | 20.0 |  |  |  | — |  |  |  | — |  |  |  | 20.0 |  |  |  | 168.4 |  |  |  | — |  |  |  | — |  |  |  | 168.4 |  |
| Certificates of deposit |  |  | 286.2 |  |  |  | — |  |  |  | — |  |  |  | 286.2 |  |  |  | 245.0 |  |  |  | — |  |  |  | — |  |  |  | 245.0 |  |
| Auction rate securities |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 36.9 |  |  |  | — |  |  |  | (0.9 | ) |  |  | 36.0 |  |
| Mutual funds |  |  | 32.2 |  |  |  | — |  |  |  | — |  |  |  | 32.2 |  |  |  | 32.7 |  |  |  | — |  |  |  | — |  |  |  | 32.7 |  |
| Total debt and equity securities |  | $ | 3,681.2 |  |  | $ | 11.4 |  |  | $ | (0.5 | ) |  | $ | 3,692.1 |  |  | $ | 2,888.7 |  |  | $ | 10.8 |  |  | $ | (1.5 | ) |  | $ | 2,898.0 |  |

[0001564590-15-005051:notes:124]
As of April 24, 2015, gross unrealized losses related to individual securities were not significant. The following table shows the gross unrealized losses and estimated fair values of our available-for-sale investments with gross unrealized losses and the length of time that individual securities have been in continuous unrealized loss positions as of April 25, 2014 (in millions):

[0001564590-15-005051:notes:125]
|  |  | April 25, 2014 |  |
|  |  | Less than 12 Months |  |  | 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Loss |  |  | Fair Value |  |  | Unrealized Loss |  |  | Fair Value |  |  | Unrealized Loss |  |
| Corporate bonds |  | $ | 233.1 |  |  | $ | (0.5 | ) |  | $ | — |  |  | $ | — |  |  | $ | 233.1 |  |  | $ | (0.5 | ) |
| U.S. Treasury and government debt securities |  |  | 63.0 |  |  |  | (0.1 | ) |  |  | — |  |  |  | — |  |  |  | 63.0 |  |  |  | (0.1 | ) |
| Auction rate securities |  |  | — |  |  |  | — |  |  |  | 36.0 |  |  |  | (0.9 | ) |  |  | 36.0 |  |  |  | (0.9 | ) |
| Total |  | $ | 296.1 |  |  | $ | (0.6 | ) |  | $ | 36.0 |  |  | $ | (0.9 | ) |  | $ | 332.1 |  |  | $ | (1.5 | ) |

[0001564590-15-005051:notes:126]
The following table presents the contractual maturities of our debt investments as of April 24, 2015 (in millions):

[0001564590-15-005051:notes:127]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,437.8 |  |  | $ | 1,440.2 |  |
| Due after one year through five years |  |  | 2,211.2 |  |  |  | 2,219.7 |  |
|  |  | $ | 3,649.0 |  |  | $ | 3,659.9 |  |

[0001564590-15-005051:notes:128]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0001564590-15-005051:notes:129]
Fair Value of Financial Instruments

[0001564590-15-005051:notes:130]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis (in millions):

[0001564590-15-005051:notes:131]
|  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 1,666.3 |  |  | $ | 1,666.3 |  |  | $ | — |  |
| Corporate bonds |  |  | 2,257.6 |  |  |  | — |  |  |  | 2,257.6 |  |
| U.S. Treasury and government debt securities |  |  | 1,058.2 |  |  |  | 145.6 |  |  |  | 912.6 |  |
| Foreign government debt securities |  |  | 37.9 |  |  |  | — |  |  |  | 37.9 |  |
| Commercial paper |  |  | 20.0 |  |  |  | — |  |  |  | 20.0 |  |
| Certificates of deposit |  |  | 286.2 |  |  |  | — |  |  |  | 286.2 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 5,326.2 |  |  | $ | 1,811.9 |  |  | $ | 3,514.3 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 2.8 |  |  | $ | 2.8 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 29.4 |  |  | $ | 29.4 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 3.4 |  |  | $ | — |  |  | $ | 3.4 |  |
| Long-term debt |  | $ | (1,523.6 | ) |  | $ | — |  |  | $ | (1,523.6 | ) |

[0001564590-15-005051:notes:132]
|  |  | April 25, 2014 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |
| Cash |  | $ | 2,174.0 |  |  | $ | 2,174.0 |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds |  |  | 2,152.3 |  |  |  | — |  |  |  | 2,152.3 |  |  |  | — |  |
| U.S. Treasury and government debt securities |  |  | 263.6 |  |  |  | 185.1 |  |  |  | 78.5 |  |  |  | — |  |
| Commercial paper |  |  | 168.4 |  |  |  | — |  |  |  | 168.4 |  |  |  | — |  |
| Certificates of deposit |  |  | 245.0 |  |  |  | — |  |  |  | 245.0 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 5,003.3 |  |  | $ | 2,359.1 |  |  | $ | 2,644.2 |  |  | $ | — |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Auction rate securities (2) |  | $ | 36.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 36.0 |  |
| Mutual funds (1) |  | $ | 6.4 |  |  | $ | 6.4 |  |  | $ | — |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 26.3 |  |  | $ | 26.3 |  |  | $ | — |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 0.4 |  |  | $ | — |  |  | $ | 0.4 |  |  | $ | — |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1.9 | ) |  | $ | — |  |  | $ | (1.9 | ) |  | $ | — |  |
| Long-term debt |  | $ | (1,000.0 | ) |  | $ | — |  |  | $ | (1,000.0 | ) |  | $ | — |  |

[0001564590-15-005051:notes:133]
| (1) | Reported as other current assets in the consolidated balance sheets |

[0001564590-15-005051:notes:134]
| (2) | Reported as other non-current assets in the consolidated balance sheets |

[0001564590-15-005051:notes:135]
| (3) | Reported as accrued expenses in the consolidated balance sheets |

[0001564590-15-005051:notes:136]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 financial instruments. As of April 24, 2015 and April 25, 2014, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-15-005051:notes:137]
During fiscal 2015, we settled our remaining ARS investments, which had been classified as Level 3 financial instruments at their respective par values. Quantitative information about our Level 3 fair value measurements as of April 24, 2014 for our ARSs is as follows:

[0001564590-15-005051:notes:138]
|  |  | Estimated Fair Value as of April 25, 2014 (in millions) |  |  | Valuation Techniques |  | Unobservable Inputs |  | Range (Weighted average) |
| ARSs |  | $ | 36.0 |  |  | Discounted cash flow |  | Time-to-economic maturity |  | 6.7 yrs - 10.0 yrs (8.2 yrs) |
|  |  |  |  |  |  |  |  | Illiquidity premium |  | 1.1% - 2.8% (1.8%) |
|  |  |  |  |  |  |  |  | Coupon rate |  | 1.1% - 2.7% (1.8%) |
|  |  |  |  |  |  | Market comparable securities |  | Discount rate |  | 1.0% - 5.0% (2.4%) |

[0001564590-15-005051:notes:139]
All of our ARSs were backed by pools of student loans guaranteed by the U.S. Department of Education. We estimated the fair value of each individual ARS using an income (discounted cash flow) and market approach that incorporated both observable and unobservable inputs. Key inputs into the discounted cash flow analysis included the time-to-economic maturity, illiquidity premium, (which factors in liquidity risk, market credit spread and other factors), and a coupon rate. The key input into the market approach is a discount rate. We reviewed the fair value of our Level 3 financial instruments for overall reasonableness by reviewing service provider pricing methodologies, key inputs and assumptions and by understanding the processes used by our third-party service provider.

[0001564590-15-005051:notes:140]
The table below provides a reconciliation of the beginning and ending balance of our Level 3 ARSs measured at fair value on a recurring basis using significant unobservable inputs (in millions):

[0001564590-15-005051:notes:141]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Balance at beginning of year |  | $ | 36.0 |  |  | $ | 42.0 |  |  | $ | 51.0 |  |
| Total unrealized gains, net included in other comprehensive income (loss) |  |  | 0.9 |  |  |  | 1.3 |  |  |  | 0.5 |  |
| Total realized gains included in earnings |  |  | — |  |  |  | 0.7 |  |  |  | 1.1 |  |
| Sales |  |  | (10.0 | ) |  |  | (8.0 | ) |  |  | — |  |
| Settlements |  |  | (26.9 | ) |  |  | — |  |  |  | (10.6 | ) |
| Balance at end of year |  | $ | — |  |  | $ | 36.0 |  |  | $ | 42.0 |  |

[0001564590-15-005051:notes:142]
Fair Value of Long-Term Debt

[0001564590-15-005051:notes:143]
The fair value of our long-term debt was based on observable market prices in a less active market and discounted cash flow models that take into consideration variables such as credit-rating and interest rate changes. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-15-005051:notes:144]
10. Financing Arrangements

[0001564590-15-005051:notes:145]
Long-term Debt

[0001564590-15-005051:notes:146]
The following table summarizes information related to our long-term debt (in millions, except interest rates):

[0001564590-15-005051:notes:147]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500.0 |  |  |  | 3.54 | % |  |  | — |  |  | N/A |  |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500.0 |  |  |  |  |  |  |  | 1,000.0 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (5.0 | ) |  |  |  |  |  |  | (4.5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (7.5 | ) |  |  |  |  |  |  | (5.4 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,487.5 |  |  |  |  |  |  | $ | 990.1 |  |  |  |  |  |

[0001564590-15-005051:notes:148]
N/A - Not Applicable

[0001564590-15-005051:notes:149]
Senior Notes

[0001564590-15-005051:notes:150]
On June 5, 2014 we issued $500.0 million aggregate par value of 3.375% Senior Notes, with a maturity date of June 15, 2021, and received proceeds of approximately $494.7 million, net of discount and issuance costs, which will be used for general corporate purposes, including possible stock repurchases, dividends, capital expenditures, working capital and potential acquisitions and strategic transactions. Our 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $750.0 million and $250.0 million, respectively, were issued in December 2012. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any future senior unsecured indebtedness.

[0001564590-15-005051:notes:151]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of April 24, 2015, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-15-005051:notes:152]
As of April 24, 2015, our aggregate future principal debt maturities for our Senior Notes are as follows (in millions):

[0001564590-15-005051:notes:153]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750.0 |  |
| Thereafter |  |  | 750.0 |  |
| Total |  | $ | 1,500.0 |  |

[0001564590-15-005051:notes:154]
1.75% Convertible Senior Notes due 2013 settled in June 2013

[0001564590-15-005051:notes:155]
On June 10, 2008, we issued $1,265.0 million aggregate principal amount of 1.75% Convertible Senior Notes (the Convertible Notes) that matured in June 2013. Upon maturity, the Convertible Notes were converted into shares of common stock at a conversion rate of 31.40 shares of common stock per $1,000 principal amount of the Convertible Notes (which represented the effective conversion price of $31.85 per share). Upon conversion in June 2013, the holders received cash for the principal amount of the Convertible Notes and an aggregate of 4.9 million shares of common stock for the $178.9 million excess of the conversion value over the principal amount.

[0001564590-15-005051:notes:156]
We separately accounted for the liability and equity components of the Convertible Notes. The initial debt component of the Convertible Notes was valued at $1,017.0 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 6.31%, with the equity component representing the residual amount of the proceeds of $248.0 million which was recorded as a debt discount. Issuance costs were allocated pro-rata based on the relative initial carrying amounts of the debt and equity components. As a result, $5.2 million of the issuance costs was allocated to the equity component of the Convertible Notes, and $21.4 million of the issuance costs remained classified as other non-current assets. The debt discount and the issuance costs allocated to the debt component were amortized as additional interest expense over the term of the Convertible Notes using the effective interest method.

[0001564590-15-005051:notes:157]
The interest expense recognized on the Convertible Notes consisted of the following (in millions):

[0001564590-15-005051:notes:158]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Contractual coupon interest expense |  | $ | 2.5 |  |  | $ | 22.0 |  |
| Amortization of debt discount |  |  | 7.1 |  |  |  | 55.5 |  |
| Amortization of debt issuance costs |  |  | 0.6 |  |  |  | 4.8 |  |
| Less capitalized interest |  |  | — |  |  |  | (1.1 | ) |
| Total interest expense related to Convertible Notes |  | $ | 10.2 |  |  | $ | 81.2 |  |

[0001564590-15-005051:notes:159]
Concurrent with the issuance of the Convertible Notes, we entered into arrangements to buy up to approximately 31.8 million shares of our common stock, at a price of $31.85 per share. During fiscal 2014, concurrent with the repayment and conversion of the Convertible Notes, we exercised the Convertible Note hedges which were net settled for an aggregate of 3.9 million shares from the counterparties. We also entered into separate transactions in which we sold warrants to acquire 39.7 million shares of our common stock at an exercise price of $41.28 per share. During fiscal 2014, 31.9 million warrants were exercised at a weighted-average price of $43.09 and were net settled with 1.1 million shares of our common stock, equal to the difference between the market price on the date of exercise and the exercise price of the warrants on their respective exercise dates, and the remaining warrants expired unexercised.

[0001564590-15-005051:notes:160]
Credit Facility

[0001564590-15-005051:notes:161]
In December 2012, we entered into a credit agreement with a syndicated group of lenders that is scheduled to expire on December 21, 2017 and provides for an unsecured $250.0 million revolving credit facility that is comprised of revolving loans, Eurocurrency loans and/or swingline loans. The credit facility includes a $100.0 million foreign currency sub-facility, a $50.0 million letter of credit sub-facility and a $10.0 million swingline sub-facility available on same-day notice. Available borrowings under the credit facility are reduced by the amount of any outstanding borrowings on the sub-facilities. We may also, subject to certain requirements, request an increase in the facility up to an additional $100.0 million and request two additional one-year extensions, subject to certain conditions. The proceeds from the facility may be used by us for general corporate purposes.

[0001564590-15-005051:notes:162]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of April 24, 2015, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-15-005051:notes:163]
Other Long-Term Financing Arrangements

[0001564590-15-005051:notes:164]
The following presents the amounts due under other long-term financing arrangements (in millions):

[0001564590-15-005051:notes:165]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Other long-term financing arrangements |  | $ | 15.9 |  |  | $ | 13.1 |  |
| Less: current portion |  |  | (9.5 | ) |  |  | (6.6 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 6.4 |  |  | $ | 6.5 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-15-005051:notes:166]
11. Stockholders’ Equity

[0001564590-15-005051:notes:167]
Equity Incentive Programs

[0001564590-15-005051:notes:168]
The 1999 Plan — As most recently amended on September 5, 2014, the 1999 Stock Option Plan (the Plan) comprises five separate equity incentive programs: (i) the Discretionary Option Grant Program under which options may be granted to eligible individuals at a fixed price per share; (ii) the Stock Appreciation Rights Program under which eligible persons may be granted stock appreciation rights that allow individuals to receive the appreciation in fair market value of the shares; (iii) the Stock Issuance Program under which eligible individuals may be issued shares of common stock directly; (iv) the Performance Share and Performance Unit Program (also known as RSUs) under which eligible persons may be granted performance shares or performance units which result in payment to the participant only if performance goals or other vesting criteria are achieved and (v) the Automatic Award Program under which nonemployee board members automatically receive equity grants at designated intervals over their period of board service. The Plan expires in August 2019.

[0001564590-15-005051:notes:169]
Under the Plan, the Board of Directors may grant to employees, nonemployee directors, consultants and independent advisors options to purchase shares of our common stock during their period of service. The exercise price for an incentive stock option and a nonstatutory option cannot be less than 100% of the fair market value of the common stock on the grant date. Options granted under the Plan generally vest over a four-year period. Options granted generally have a term of seven years after the grant date, subject to earlier termination upon the occurrence of certain events. The Plan prohibits the repricing of any outstanding stock option or stock appreciation right after it has been granted or to cancel any outstanding stock option or stock appreciation right and immediately replace it with a new stock option or stock appreciation right with a lower exercise price unless approved by stockholders. RSUs granted under the Plan generally vest over a four-year period with 25% vesting on each anniversary of the grant date. The Compensation Committee of the Board of Directors has the discretion to use different vesting schedules.

[0001564590-15-005051:notes:170]
Under the Plan, the number of shares reserved for issuance is reduced by two shares for every share subject to a full value award, which are specified to be grants that are in the form of performance shares and/or performance unit awards, stock, restricted stock, restricted stock units. The Plan (i) limits the number of shares that may be granted pursuant to awards under the Stock Issuance Program to a participant in any calendar year to 1 million, (ii) limits the initial value of performance units a participant may receive to not more than $5 million and (iii) limits the number of performance shares a participant may receive in a calendar year to 1 million.

[0001564590-15-005051:notes:171]
During fiscal 2015, the shares reserved for issuance under the plan were increased by 7.5 million shares. As of April 24, 2015, 12.7 million shares were available for grant under our equity incentive plans.

[0001564590-15-005051:notes:172]
Stock Options

[0001564590-15-005051:notes:173]
The following table summarizes activity related to our stock options (in millions, except for exercise price and contractual term):

[0001564590-15-005051:notes:174]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding at April 27, 2012 |  |  | 20.6 |  |  | $ | 29.98 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2.4 |  |  | $ | 28.87 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (3.0 | ) |  | $ | 18.37 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (0.8 | ) |  | $ | 40.11 |  |  |  |  |  |  |  |  |  |
| Outstanding at April 26, 2013 |  |  | 19.2 |  |  | $ | 31.27 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2.9 |  |  | $ | 38.26 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (6.3 | ) |  | $ | 25.83 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (1.3 | ) |  | $ | 42.47 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 25, 2014 |  |  | 14.5 |  |  | $ | 34.10 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2.2 |  |  | $ | 36.64 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (4.6 | ) |  | $ | 25.25 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (0.6 | ) |  | $ | 42.42 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 24, 2015 |  |  | 11.5 |  |  | $ | 37.74 |  |  |  | 3.70 |  |  | $ | 29.8 |  |
| Vested and expected to vest as of April 24, 2015 |  |  | 11.1 |  |  | $ | 37.78 |  |  |  | 3.63 |  |  | $ | 29.5 |  |
| Exercisable as of April 24, 2015 |  |  | 7.9 |  |  | $ | 38.32 |  |  |  | 2.89 |  |  | $ | 26.1 |  |

[0001564590-15-005051:notes:175]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our stock on that day for all in-the-money options.

[0001564590-15-005051:notes:176]
Additional information related to our stock options is summarized below (in millions):

[0001564590-15-005051:notes:177]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Intrinsic value of exercises |  | $ | 69.9 |  |  | $ | 90.7 |  |  | $ | 46.1 |  |
| Proceeds received from exercises |  | $ | 116.6 |  |  | $ | 163.7 |  |  | $ | 56.5 |  |
| Fair value of options vested |  | $ | 33.4 |  |  | $ | 45.3 |  |  | $ | 55.9 |  |

[0001564590-15-005051:notes:178]
Restricted Stock Units

[0001564590-15-005051:notes:179]
The following table summarizes activity related to our RSUs (in millions, except for fair value):

[0001564590-15-005051:notes:180]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding at April 27, 2012 |  |  | 12.0 |  |  | $ | 43.28 |  |
| Granted |  |  | 6.0 |  |  | $ | 29.94 |  |
| Vested |  |  | (4.0 | ) |  | $ | 39.83 |  |
| Forfeited |  |  | (1.2 | ) |  | $ | 40.95 |  |
| Outstanding at April 26, 2013 |  |  | 12.8 |  |  | $ | 38.36 |  |
| Granted |  |  | 6.5 |  |  | $ | 38.61 |  |
| Vested |  |  | (4.5 | ) |  | $ | 38.48 |  |
| Forfeited |  |  | (1.6 | ) |  | $ | 39.08 |  |
| Outstanding as of April 25, 2014 |  |  | 13.2 |  |  | $ | 38.35 |  |
| Granted |  |  | 6.5 |  |  | $ | 35.80 |  |
| Vested |  |  | (4.7 | ) |  | $ | 40.14 |  |
| Forfeited |  |  | (1.7 | ) |  | $ | 37.48 |  |
| Outstanding as of April 24, 2015 |  |  | 13.3 |  |  | $ | 36.58 |  |

[0001564590-15-005051:notes:181]
RSUs are converted into common stock upon vesting. We primarily use the net share settlement approach upon vesting, where a portion of the shares are withheld as settlement of statutory employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001564590-15-005051:notes:182]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Shares withheld for taxes |  |  | 1.5 |  |  |  | 1.5 |  |  |  | 1.3 |  |
| Fair value of shares withheld |  | $ | 56.8 |  |  | $ | 57.7 |  |  | $ | 40.9 |  |

[0001564590-15-005051:notes:183]
Employee Stock Purchase Plan

[0001564590-15-005051:notes:184]
Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. On September 5, 2014, the ESPP was amended to increase the shares reserved for issuance by 5.0 million shares of common stock. As of April 24, 2015, 8.9 million shares were available for issuance. The following table summarizes activity related to the purchase rights issued under the ESPP (in millions):

[0001564590-15-005051:notes:185]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Shares issued under the ESPP |  |  | 3.4 |  |  |  | 3.8 |  |  |  | 3.8 |  |
| Proceeds from issuance of shares |  | $ | 97.1 |  |  | $ | 95.5 |  |  | $ | 95.0 |  |

[0001564590-15-005051:notes:186]
Stock-Based Compensation Expense

[0001564590-15-005051:notes:187]
Stock-based compensation expense is included in the consolidated statements of operations as follows (in millions):

[0001564590-15-005051:notes:188]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Cost of product revenues |  | $ | 5.8 |  |  | $ | 5.6 |  |  | $ | 6.1 |  |
| Cost of hardware maintenance and other services revenues |  |  | 16.0 |  |  |  | 16.7 |  |  |  | 19.4 |  |
| Sales and marketing |  |  | 116.5 |  |  |  | 125.0 |  |  |  | 132.2 |  |
| Research and development |  |  | 84.1 |  |  |  | 87.7 |  |  |  | 84.1 |  |
| General and administrative |  |  | 36.9 |  |  |  | 38.0 |  |  |  | 34.8 |  |
| Total stock-based compensation expense |  | $ | 259.3 |  |  | $ | 273.0 |  |  | $ | 276.6 |  |

[0001564590-15-005051:notes:189]
As of April 24, 2015, total unrecognized compensation expense related to our equity awards was $358.7 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.2 years.

[0001564590-15-005051:notes:190]
Total income tax benefit associated with employee stock transactions and recognized in stockholders’ equity were as follows (in millions):

[0001564590-15-005051:notes:191]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Income tax benefit associated with employee stock transactions |  | $ | 56.9 |  |  | $ | 40.5 |  |  | $ | 53.8 |  |

[0001564590-15-005051:notes:192]
Valuation Assumptions

[0001564590-15-005051:notes:193]
The valuation of stock options, RSUs and ESPP purchase rights and the underlying weighted-average assumptions are summarized as follows:

[0001564590-15-005051:notes:194]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Stock options: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected term in years |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 4.8 |  |
| Risk-free interest rate |  |  | 1.6 | % |  |  | 1.1 | % |  |  | 0.6 | % |
| Expected volatility |  |  | 29 | % |  |  | 34 | % |  |  | 41 | % |
| Expected dividend yield |  |  | 1.8 | % |  |  | 1.6 | % |  |  | — | % |
| Weighted-average fair value per share granted |  | $ | 8.24 |  |  | $ | 9.85 |  |  | $ | 11.52 |  |
| RSUs: |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 0.6 | % |  |  | 0.5 | % |  | N/A |  |
| Expected dividend yield |  |  | 1.8 | % |  |  | 1.6 | % |  |  | — | % |
| Weighted-average fair value per share granted |  | $ | 35.80 |  |  | $ | 38.61 |  |  | $ | 29.94 |  |
| ESPP: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected term in years |  |  | 1.3 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 0.2 | % |  |  | 0.2 | % |  |  | 0.2 | % |
| Expected volatility |  |  | 27 | % |  |  | 31 | % |  |  | 40 | % |
| Expected dividend yield |  |  | 1.8 | % |  |  | 1.6 | % |  |  | — | % |
| Weighted-average fair value per right granted |  | $ | 9.81 |  |  | $ | 10.83 |  |  | $ | 10.36 |  |

[0001564590-15-005051:notes:195]
Stock Repurchase Program

[0001564590-15-005051:notes:196]
As of April 24, 2015, our Board of Directors has authorized the repurchase of up to $9.6 billion of our common stock, including a $2.5 billion increase approved by our Board of Directors in fiscal 2015. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management.

[0001564590-15-005051:notes:197]
The following table summarizes activity related to this program (in millions, except per share information):

[0001564590-15-005051:notes:198]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Number of shares repurchased |  |  | 29.6 |  |  |  | 47.3 |  |  |  | 18.1 |  |
| Average price per share |  | $ | 39.30 |  |  | $ | 39.78 |  |  | $ | 32.68 |  |
| Aggregate purchase price |  | $ | 1,165.2 |  |  | $ | 1,881.5 |  |  | $ | 590.0 |  |
| Remaining authorization at end of period |  | $ | 2,459.5 |  |  | $ | 1,124.8 |  |  | $ | 1,406.3 |  |

[0001564590-15-005051:notes:199]
The aggregate purchase price of our stock repurchases for fiscal 2015 consisted of $1,165.2 million of open market purchases, of which, $812.8 million and $352.4 million was allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-15-005051:notes:200]
Since the May 13, 2003 inception of our stock repurchase program through April 24, 2015, we repurchased a total of 214.0 million shares of our common stock at an average price of $33.48 per share, for an aggregate purchase price of $7.2 billion.

[0001564590-15-005051:notes:201]
Accelerated Share Repurchase Agreement

[0001564590-15-005051:notes:202]
In fiscal 2014, we entered into a collared Accelerated Share Repurchase (ASR) with a third party under which we prepaid $750.0 million to purchase shares of our common stock. The aggregate number of shares ultimately purchased was determined based on the volume weighted-average share price of our common stock over a specified period of time. This contract settled in fiscal 2014, resulting in the repurchase of 19.2 million shares, at an average price per share of $39.13. The value of the ASR forward contract was determined to be $13.9 million, which was recorded as additional paid-in capital.

[0001564590-15-005051:notes:203]
Preferred Stock

[0001564590-15-005051:notes:204]
Our Board of Directors has the authority to issue up to 5.0 million shares of preferred stock and to determine the price, rights, preferences, privileges, and restrictions, including voting rights, of those shares without any further vote or action by the stockholders. No shares of preferred stock were issued or outstanding in any period presented.

[0001564590-15-005051:notes:205]
Dividends

[0001564590-15-005051:notes:206]
The following is a summary of our fiscal 2015 and 2014 activities related to dividends on our common stock (in millions, except per share amounts). No dividends were declared or paid in fiscal 2013.

[0001564590-15-005051:notes:207]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Dividends per share declared |  | $ | 0.66 |  |  | $ | 0.60 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 52.0 |  |  | $ | 50.4 |  |
| Dividend payments allocated to retained earnings |  | $ | 155.4 |  |  | $ | 151.9 |  |

[0001564590-15-005051:notes:208]
On May 20, 2015, we declared a cash dividend of $0.18 per share of common stock, payable on July 23, 2015 to holders of record as of the close of business on July 10, 2015. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by the Company to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-15-005051:notes:209]
Accumulated Other Comprehensive Income (Loss)

[0001564590-15-005051:notes:210]
Changes in AOCI by component, net of tax, are summarized below (in millions):

[0001564590-15-005051:notes:211]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivatives Instruments |  |  | Total |  |
| Balance as of April 26, 2013 |  | $ | 2.0 |  |  | $ | (5.7 | ) |  | $ | 11.4 |  |  | $ | 1.0 |  |  | $ | 8.7 |  |
| OCI before reclassifications, net of tax |  |  | 3.5 |  |  |  | 0.5 |  |  |  | (1.2 | ) |  |  | (3.5 | ) |  |  | (0.7 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | 0.4 |  |  |  | (1.3 | ) |  |  | 2.0 |  |  |  | 1.1 |  |
| Total OCI |  |  | 3.5 |  |  |  | 0.9 |  |  |  | (2.5 | ) |  |  | (1.5 | ) |  |  | 0.4 |  |
| Balance as of April 25, 2014 |  |  | 5.5 |  |  |  | (4.8 | ) |  |  | 8.9 |  |  |  | (0.5 | ) |  |  | 9.1 |  |
| OCI before reclassifications, net of tax |  |  | (28.3 | ) |  |  | (7.8 | ) |  |  | 2.3 |  |  |  | 15.5 |  |  |  | (18.3 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | 0.2 |  |  |  | (0.3 | ) |  |  | (14.4 | ) |  |  | (14.5 | ) |
| Total OCI |  |  | (28.3 | ) |  |  | (7.6 | ) |  |  | 2.0 |  |  |  | 1.1 |  |  |  | (32.8 | ) |
| Balance as of April 24, 2015 |  | $ | (22.8 | ) |  | $ | (12.4 | ) |  | $ | 10.9 |  |  | $ | 0.6 |  |  | $ | (23.7 | ) |

[0001564590-15-005051:notes:212]
The amounts reclassified out of AOCI are as follows (in millions):

[0001564590-15-005051:notes:213]
|  |  | Year Ended |  |  |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |
| Recognized losses on defined benefit obligations |  | $ | 0.2 |  |  | $ | 0.4 |  |  | $ | — |  |  | Operating expenses |
| Realized gains on available-for-sale securities |  |  | (0.3 | ) |  |  | (1.3 | ) |  |  | (0.6 | ) |  | Other income (expense), net |
| Realized (gains) losses on cash flow hedges |  |  | (14.4 | ) |  |  | 2.0 |  |  |  | (2.2 | ) |  | Net revenues |
| Total reclassifications |  | $ | (14.5 | ) |  | $ | 1.1 |  |  | $ | (2.8 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-15-005051:notes:214]
12. Derivatives and Hedging Activities

[0001564590-15-005051:notes:215]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of April 24, 2015 or April 25, 2014. We did not recognize any gains and losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-15-005051:notes:216]
Over the next 12 months, we expect an immaterial amount of derivative net gains recorded in AOCI as of April 24, 2015 will be reclassified into net revenues. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is six months.

[0001564590-15-005051:notes:217]
The notional amount of our outstanding U.S. dollar equivalent foreign currency exchange contracts consisted of the following (in millions):

[0001564590-15-005051:notes:218]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 93.6 |  |  | $ | 122.6 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 160.2 |  |  | $ | 155.5 |  |
| Forward contracts purchased |  | $ | 231.2 |  |  | $ | 389.9 |  |

[0001564590-15-005051:notes:219]
The effect of derivative instruments designated as cash flow hedges recognized in net revenues on our consolidated statements of operations is presented in the consolidated statements of comprehensive income and Note 11 – Stockholders’ Equity.

[0001564590-15-005051:notes:220]
The effect of derivative instruments not designated as hedging instruments recognized in other income (expense), net on our consolidated statements of operations was as follows (in millions):

[0001564590-15-005051:notes:221]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
|  |  | Gain Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 14.1 |  |  | $ | 0.8 |  |  | $ | 6.5 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-15-005051:notes:222]
13. Restructuring and Other Charges

[0001564590-15-005051:notes:223]
In May 2013, we initiated a business restructuring plan under which we realigned internal resources, resulting in a reduction of our global workforce of approximately 7%. Such activities were completed in the year ended April 25, 2014. In March 2014, we initiated a business realignment plan designed to focus our resources on key strategic initiatives and streamline our business in light of the constrained information technology spending environment, resulting in a reduction of our global workforce of approximately 4%. Such activities were completed in the year ended April 24, 2015. Restructuring and other charges consisted primarily of employee severance-related costs.

[0001564590-15-005051:notes:224]
Activities related to these plans are summarized as follows (in millions):

[0001564590-15-005051:notes:225]
|  |  | March 2014 Plan |  |  | May 2013 Plan |  |  | Total |  |
| Balance as of April 26, 2013 |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net charges |  |  | 38.8 |  |  |  | 49.5 |  |  |  | 88.3 |  |
| Cash payments |  |  | (12.3 | ) |  |  | (49.5 | ) |  |  | (61.8 | ) |
| Balance as of April 25, 2014 |  |  | 26.5 |  |  |  | — |  |  |  | 26.5 |  |
| Net charges |  |  | — |  |  |  | — |  |  |  | — |  |
| Cash payments |  |  | (26.5 | ) |  |  | — |  |  |  | (26.5 | ) |
| Balance as of April 24, 2015 |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001564590-15-005051:notes:226]
Liabilities for our restructuring plans were included in accrued expenses in our consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-15-005051:notes:227]
14. Income Taxes

[0001564590-15-005051:notes:228]
Income before income taxes is as follows (in millions):

[0001564590-15-005051:notes:229]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Domestic |  | $ | 252.9 |  |  | $ | 120.5 |  |  | $ | (63.8 | ) |
| Foreign |  |  | 459.9 |  |  |  | 620.2 |  |  |  | 630.4 |  |
| Total |  | $ | 712.8 |  |  | $ | 740.7 |  |  | $ | 566.6 |  |

[0001564590-15-005051:notes:230]
Domestic income before taxes is lower than foreign income before taxes due to significant domestic expenses related to the amortization of intangibles, stock based compensation and, for fiscal years 2014 and 2013, convertible notes interest.

[0001564590-15-005051:notes:231]
The provision for income taxes consists of the following (in millions):

[0001564590-15-005051:notes:232]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 103.6 |  |  | $ | 123.7 |  |  | $ | 85.3 |  |
| State |  |  | 11.7 |  |  |  | 14.6 |  |  |  | 14.6 |  |
| Foreign |  |  | 40.3 |  |  |  | 40.9 |  |  |  | 38.0 |  |
| Total current |  |  | 155.6 |  |  |  | 179.2 |  |  |  | 137.9 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 8.0 |  |  |  | (64.8 | ) |  |  | (56.9 | ) |
| State |  |  | (3.3 | ) |  |  | (6.1 | ) |  |  | (17.8 | ) |
| Foreign |  |  | (7.4 | ) |  |  | (5.1 | ) |  |  | (1.9 | ) |
| Total deferred |  |  | (2.7 | ) |  |  | (76.0 | ) |  |  | (76.6 | ) |
| Provision for income taxes |  | $ | 152.9 |  |  | $ | 103.2 |  |  | $ | 61.3 |  |

[0001564590-15-005051:notes:233]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0001564590-15-005051:notes:234]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Tax computed at federal statutory rate |  | $ | 249.5 |  |  | $ | 259.2 |  |  | $ | 198.3 |  |
| State income taxes, net of federal benefit |  |  | 5.4 |  |  |  | 5.6 |  |  |  | (2.0 | ) |
| Foreign earnings in lower tax jurisdictions |  |  | (141.0 | ) |  |  | (163.3 | ) |  |  | (144.4 | ) |
| Stock-based compensation |  |  | 5.5 |  |  |  | 9.8 |  |  |  | 18.4 |  |
| Research and experimentation credits |  |  | (13.7 | ) |  |  | (8.7 | ) |  |  | (12.1 | ) |
| Resolution of income tax examinations |  |  | 46.4 |  |  |  | — |  |  |  | 0.1 |  |
| Other |  |  | 0.8 |  |  |  | 0.6 |  |  |  | 3.0 |  |
| Provision for income taxes |  | $ | 152.9 |  |  | $ | 103.2 |  |  | $ | 61.3 |  |

[0001564590-15-005051:notes:235]
The components of our deferred tax assets and liabilities are as follows (in millions):

[0001564590-15-005051:notes:236]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Reserves and accruals |  | $ | 94.3 |  |  | $ | 89.3 |  |
| Acquired intangibles |  |  | 43.8 |  |  |  | 22.3 |  |
| Net operating loss and credit carryforwards |  |  | 79.6 |  |  |  | 87.6 |  |
| Stock-based compensation |  |  | 70.4 |  |  |  | 73.3 |  |
| Deferred revenue |  |  | 297.7 |  |  |  | 318.9 |  |
| Other |  |  | 27.0 |  |  |  | 19.8 |  |
| Gross deferred tax assets |  |  | 612.8 |  |  |  | 611.2 |  |
| Valuation allowance |  |  | (57.7 | ) |  |  | (49.6 | ) |
| Deferred tax assets, net of valuation allowance |  |  | 555.1 |  |  |  | 561.6 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Reserves and accruals |  |  | 4.0 |  |  |  | 3.9 |  |
| Acquired intangibles |  |  | 13.7 |  |  |  | 10.0 |  |
| Property and equipment |  |  | 26.3 |  |  |  | 30.8 |  |
| Other |  |  | 3.5 |  |  |  | 2.6 |  |
| Total deferred tax liabilities |  |  | 47.5 |  |  |  | 47.3 |  |
| Deferred tax assets, net of valuation allowance and deferred tax liabilities |  | $ | 507.6 |  |  | $ | 514.3 |  |

[0001564590-15-005051:notes:237]
Net deferred tax assets consist of the following (in millions):

[0001564590-15-005051:notes:238]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Current deferred tax assets, net |  | $ | 251.7 |  |  | $ | 269.3 |  |
| Non-current deferred tax assets, net |  | $ | 255.9 |  |  | $ | 245.0 |  |

[0001564590-15-005051:notes:239]
The valuation allowance increased by $8.1 million and $9.8 million in fiscal 2015 and 2014, respectively. The increases are mainly attributable to corresponding changes in deferred tax assets, primarily foreign tax credit carryforwards in a foreign jurisdiction and state tax credit carryforwards in certain states.

[0001564590-15-005051:notes:240]
As of April 24, 2015, the federal and state net operating loss carryforwards were approximately $21.7 million and $85.4 million, respectively, before applying tax rates for the respective jurisdictions. The federal and state tax credit carryforwards were approximately $117.0 million and $145.5 million, respectively. Certain acquired net operating loss and credit carryforwards are subject to an annual limitation under Internal Revenue Code Section 382, but are expected to be realized with the exception of those which have a valuation allowance. The federal and state net operating loss carryforwards and credits will expire in various years from fiscal 2018 through 2035. If realized, $122.0 million, tax effected, of net operating loss and tax credit carryovers will be recognized as additional paid-in capital.

[0001564590-15-005051:notes:241]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001564590-15-005051:notes:242]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Balance at beginning of period |  | $ | 235.9 |  |  | $ | 189.6 |  |  | $ | 161.0 |  |
| Additions based on tax positions related to the current year |  |  | 21.7 |  |  |  | 26.9 |  |  |  | 34.5 |  |
| Additions for tax positions of prior years |  |  | 101.2 |  |  |  | 23.8 |  |  |  | 1.0 |  |
| Decreases for tax positions of prior years |  |  | (29.3 | ) |  |  | (4.4 | ) |  |  | (6.9 | ) |
| Settlements |  |  | (57.6 | ) |  |  | — |  |  |  | — |  |
| Balance at end of period |  | $ | 271.9 |  |  | $ | 235.9 |  |  | $ | 189.6 |  |

[0001564590-15-005051:notes:243]
As of April 24, 2015, we had $271.9 million of gross unrecognized tax benefits, of which $213.6 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $167.5 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-15-005051:notes:244]
We recognize accrued interest and penalties related to unrecognized tax benefits in the income tax provision. During fiscal 2015, 2014 and 2013, we recognized accrued interest and penalties of approximately $3.6 million, $2.2 million and $1.2 million, respectively in the consolidated statements of operations and $8.6 million and $5.0 million, respectively, were recorded in the consolidated balance sheets as of April 24, 2015 and April 25, 2014.

[0001564590-15-005051:notes:245]
The tax years that remain subject to examination for our major tax jurisdictions are shown below:

[0001564590-15-005051:notes:246]
Fiscal Years Subject to Examination for Major Tax Jurisdictions at April 24, 2015

[0001564590-15-005051:notes:247]
| 2008 — 2015 |  | United States — federal income tax |
| 2008 — 2015 |  | United States — state and local income tax |
| 2011 — 2015 |  | Australia |
| 2009 — 2015 |  | Germany |
| 2006 — 2015 |  | India |
| 2009 — 2015 |  | Japan |
| 2011 — 2015 |  | The Netherlands |
| 2013 — 2015 |  | United Kingdom |
| 2008 — 2015 |  | Canada |

[0001564590-15-005051:notes:248]
In addition, we are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal 2001, in that we have net operating loss carryforwards from these years that could be subject to adjustment upon utilization.

[0001564590-15-005051:notes:249]
In July 2014, the Internal Revenue Service (IRS) completed the examination of our fiscal 2005 to 2007 income tax returns upon approval by the Joint Committee of Taxation. We recorded a $47.4 million income tax provision attributable to the audit settlement and related re-measurement of uncertain tax positions for tax years subject to future audits. The audit adjustments resulted in lower earnings in our foreign subsidiaries which reduced the taxability of dividends that were previously repatriated from such subsidiaries. Due to this reduction in taxable dividends, the conclusion of the fiscal 2005 to 2007 income tax audit resulted in a net refund of $8.0 million, excluding interest.

[0001564590-15-005051:notes:250]
In October 2014, the United Kingdom’s (UK’s) tax authority concluded the examination of our fiscal 2009 to 2012 UK income tax returns. We recorded a $1.0 million income tax benefit for the net impact of the audit adjustments and related release of unrecognized tax benefits.

[0001564590-15-005051:notes:251]
We are currently undergoing federal income tax audits in the United States (U.S.) and several foreign tax jurisdictions. Transfer pricing calculations are key issues under audits in various jurisdictions, and are often subject to dispute and appeals. The IRS is currently auditing our fiscal 2008 to 2010 income tax returns. We expect the IRS examination team to complete their field audit within the next twelve months. However, the resolution of the fiscal 2008 to 2010 income tax return audits may likely occur beyond the next twelve months should we choose to appeal the IRS examination team’s audit findings.

[0001564590-15-005051:notes:252]
On September 17, 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 from our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. On December 19, 2011, the Danish Tax Tribunal issued a ruling that our Danish subsidiary was not liable for Danish withholding tax. The Danish tax examination agency appealed to the Danish High Court in March 2012. The Danish High Court hearing has not yet occurred.

[0001564590-15-005051:notes:253]
We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. Given the uncertainties involved in all tax audits, we estimate a potential decrease in our unrecognized tax benefit balance of up to $95.4 million may occur within the next 12 months associated with the potential settlements and statute lapses.

[0001564590-15-005051:notes:254]
As of April 24, 2015, the amount of accumulated unremitted earnings from our foreign subsidiaries is approximately $3.3 billion. We have not provided U.S. income taxes and foreign withholding taxes on the undistributed earnings of foreign subsidiaries because we intend to permanently reinvest such earnings outside the U.S. If these foreign earnings were to be repatriated in the future, the related U.S. tax liability may be reduced by any foreign income taxes previously paid on these earnings as well as tax attribute carryforwards. We estimate the unrecognized deferred tax liability related to these earnings to be approximately $1 billion as of April 24, 2015.


## us-gaap:EarningsPerShareTextBlock

[0001564590-15-005051:notes:255]
15. Net Income per Share

[0001564590-15-005051:notes:256]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0001564590-15-005051:notes:257]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 559.9 |  |  | $ | 637.5 |  |  | $ | 505.3 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 315.5 |  |  |  | 340.3 |  |  |  | 361.5 |  |
| Dilutive impact of employee equity award plans |  |  | 5.2 |  |  |  | 6.9 |  |  |  | 5.4 |  |
| Dilutive impact of assumed conversion of Convertible Notes |  |  | — |  |  |  | 0.5 |  |  |  | 1.1 |  |
| Dilutive impact of warrants |  |  | — |  |  |  | 0.2 |  |  |  | — |  |
| Shares used in diluted computation |  |  | 320.7 |  |  |  | 347.9 |  |  |  | 368.0 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.77 |  |  | $ | 1.87 |  |  | $ | 1.40 |  |
| Diluted |  | $ | 1.75 |  |  | $ | 1.83 |  |  | $ | 1.37 |  |

[0001564590-15-005051:notes:258]
The following potential weighted-average shares of common stock have been excluded from the diluted net income per share calculations, as their effect would have been anti-dilutive (in millions):

[0001564590-15-005051:notes:259]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Employee equity award plans |  |  | 7.8 |  |  |  | 6.4 |  |  |  | 15.1 |  |

[0001564590-15-005051:notes:260]
Dilutive shares outstanding during fiscal 2013 do not include any effect resulting from warrants, as their impact would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-15-005051:notes:261]
16. Segment, Geographic, and Significant Customer Information

[0001564590-15-005051:notes:262]
We operate in one industry segment: the design, manufacturing, marketing, and technical support of high-performance storage and data management solutions. We conduct business globally, and our sales and support activities are managed on a geographic basis. Our management reviews financial information presented on a consolidated basis, accompanied by disaggregated information it receives from our internal management system about revenues by geographic region, based on the location from which the customer relationship is managed, for purposes of allocating resources and evaluating financial performance. We do not allocate costs of revenues, research and development, sales and marketing, or general and administrative expenses to our geographic regions in this internal management reporting because management does not review operations or operating results, or make planning decisions, below the consolidated entity level.

[0001564590-15-005051:notes:263]
Summarized revenues by geographic region based on information from our internal management system and utilized by our Chief Executive Officer, who is considered our Chief Operating Decision Maker, is as follows (in millions):

[0001564590-15-005051:notes:264]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| United States, Canada and Latin America (Americas) |  | $ | 3,446.8 |  |  | $ | 3,513.3 |  |  | $ | 3,552.5 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 1,857.4 |  |  |  | 1,954.6 |  |  |  | 1,928.8 |  |
| Asia Pacific (APAC) |  |  | 818.5 |  |  |  | 857.2 |  |  |  | 851.1 |  |
| Net revenues |  | $ | 6,122.7 |  |  | $ | 6,325.1 |  |  | $ | 6,332.4 |  |

[0001564590-15-005051:notes:265]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $3,096.1 million, $3,130.9 million and $3,152.7 million during fiscal 2015, 2014 and 2013, respectively.

[0001564590-15-005051:notes:266]
The majority of our assets, excluding cash, cash equivalents, short-term investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents and short-term investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0001564590-15-005051:notes:267]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| U.S. |  | $ | 596.2 |  |  | $ | 681.8 |  |
| International |  |  | 4,730.0 |  |  |  | 4,321.5 |  |
| Total |  | $ | 5,326.2 |  |  | $ | 5,003.3 |  |

[0001564590-15-005051:notes:268]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment information for geographic areas based on the physical location of the assets (in millions):

[0001564590-15-005051:notes:269]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| U.S. |  | $ | 926.9 |  |  | $ | 1,021.4 |  |
| International |  |  | 103.0 |  |  |  | 87.4 |  |
| Total |  | $ | 1,029.9 |  |  | $ | 1,108.8 |  |

[0001564590-15-005051:notes:270]
The following customers, each of which is a distributor, accounted for 10% or more of our net revenues:

[0001564590-15-005051:notes:271]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| Arrow Electronics, Inc. |  |  | 23 | % |  |  | 22 | % |  |  | 19 | % |
| Avnet, Inc. |  |  | 16 | % |  |  | 16 | % |  |  | 15 | % |

[0001564590-15-005051:notes:272]
The following customers accounted for 10% or more of accounts receivable:

[0001564590-15-005051:notes:273]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Arrow Electronics, Inc. |  |  | 14 | % |  |  | 14 | % |
| Avnet, Inc. |  |  | 16 | % |  |  | 16 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-15-005051:notes:274]
17. Employee Benefits and Deferred Compensation

[0001564590-15-005051:notes:275]
Employee 401(k) Plan

[0001564590-15-005051:notes:276]
Our 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit. Effective January 1, 2015, we match 100% of the first 2% of eligible earnings an employee contributes to the 401(k) Plan, and then match 50% of the next 4% of eligible earnings an employee contributes. An employee receives the full 4% match when he/she contributes at least 6% of his/her eligible earnings, up to a maximum calendar year matching contribution of $6,000. Effective the same date, employer matching contributions made in the current and previous years vested immediately. Our employer matching contributions to the 401(k) Plan were as follows (in millions):

[0001564590-15-005051:notes:277]
|  |  | Year Ended |  |
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | April 26, 2013 |  |
| 401(k) matching contributions |  | $ | 16.3 |  |  | $ | 19.6 |  |  | $ | 19.9 |  |

[0001564590-15-005051:notes:278]
Deferred Compensation Plan

[0001564590-15-005051:notes:279]
We have a non-qualified deferred compensation plan that allows a group of employees within the U.S. to contribute base salary and commissions or incentive compensation on a tax deferred basis in excess of the IRS limits imposed on 401(k) plans. The marketable securities related to these investments are held in a Rabbi Trust. The related deferred compensation plan assets and liabilities under the non-qualified deferred compensation plan were as follows (in millions):

[0001564590-15-005051:notes:280]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Deferred compensation plan assets |  | $ | 32.2 |  |  | $ | 32.7 |  |
| Deferred compensation liabilities reported as: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 2.8 |  |  | $ | 6.4 |  |
| Other long-term liabilities |  | $ | 29.4 |  |  | $ | 26.3 |  |

[0001564590-15-005051:notes:281]
Postretirement Health Care Plan

[0001564590-15-005051:notes:282]
We maintain a plan to provide postretirement health and welfare benefits to certain executives who meet certain age and service requirements. Coverage continues through the duration of the lifetime of the retiree or the retiree’s spouse, whichever is longer. There is no funding requirement associated with the plan and none of the benefit obligation was funded as of April 24, 2015. Assumed health care cost trend rates have a significant effect on the amounts reported for the health care plan.

[0001564590-15-005051:notes:283]
International Defined Benefit Plans

[0001564590-15-005051:notes:284]
We maintain various defined benefit plans to provide termination and postretirement benefits to certain eligible employees outside of the U.S. We also provide disability benefits to certain eligible employees in the U.S. Eligibility is determined based on the terms of our plans and local statutory requirements. Assumed discount rates and expected long-term returns on plan assets have significant effects on the amounts reported for the defined benefit plans.

[0001564590-15-005051:notes:285]
Funded Status

[0001564590-15-005051:notes:286]
The funded status of our postretirement health care and international termination and postretirement benefits was as follows (in millions):

[0001564590-15-005051:notes:287]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Fair value of plan assets |  | $ | 19.7 |  |  | $ | 18.7 |  |
| Benefit obligations |  |  | (60.2 | ) |  |  | (45.7 | ) |
| Unfunded obligations |  | $ | (40.5 | ) |  | $ | (27.0 | ) |

[0001564590-15-005051:notes:288]
Amounts recognized in the consolidated balance sheets were as follows (in millions):

[0001564590-15-005051:notes:289]
|  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Other long-term liabilities |  | $ | 40.5 |  |  | $ | 27.0 |  |
| AOCI |  | $ | (12.4 | ) |  | $ | (4.8 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-15-005051:notes:290]
18. Commitments and Contingencies

[0001564590-15-005051:notes:291]
Operating Leases

[0001564590-15-005051:notes:292]
We lease various equipment, vehicles and office space in the U.S. and internationally.

[0001564590-15-005051:notes:293]
Future annual minimum lease payments under all non-cancelable operating leases with an initial term in excess of one year as of April 24, 2015 are as follows (in millions):

[0001564590-15-005051:notes:294]
|  |  |  | 2016 |  |  |  | 2017 |  |  |  | 2018 |  |  |  | 2019 |  |  |  | 2020 |  |  | Thereafter |  |  | Total |  |
| Operating lease commitments |  | $ | 61.9 |  |  | $ | 44.0 |  |  | $ | 29.6 |  |  | $ | 21.0 |  |  | $ | 17.3 |  |  | $ | 31.7 |  |  | $ | 205.5 |  |

[0001564590-15-005051:notes:295]
Rent expense under all cancellable and non-cancelable operating leases was $67.0 million, $65.5 million and $64.9 million in fiscal 2015, 2014 and 2013, respectively.

[0001564590-15-005051:notes:296]
Purchase Orders and Other Commitments

[0001564590-15-005051:notes:297]
In the ordinary course of business, we make commitments to third-party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on non-cancellable purchase commitments for components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. As of April 24, 2015, we had $295.0 million in non-cancelable purchase commitments with our contract manufacturers. In addition, we recorded a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to cost of product revenues. As of April 24, 2015 and April 25, 2014, such liability amounted to $16.9 million and $11.5 million, respectively, and is included in accrued expenses in our consolidated balance sheets.

[0001564590-15-005051:notes:298]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of April 24, 2015, we had $60.0 million in construction related obligations and $211.0 million in other purchase obligations.

[0001564590-15-005051:notes:299]
During the ordinary course of business, we provide standby letters of credit or other guarantee instruments to third parties as required for certain transactions initiated either by us or our subsidiaries. As of April 24, 2015, our financial guarantees of $9.3 million that were not recorded on our consolidated balance sheets consisted primarily of standby letters of credit and surety bonds.

[0001564590-15-005051:notes:300]
Financing Guarantees

[0001564590-15-005051:notes:301]
Some of our customers have entered into recourse and non-recourse financing leasing arrangements using third-party financing companies, and in some situations, we enter into customer financing arrangements for our products and services that are contemporaneously sold on a recourse or non-recourse basis to third-party financing companies. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Under the terms of the non-recourse leases, we do not have any continuing obligations or liabilities to the third-party financing companies. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of April 24, 2015 and April 25, 2014, the aggregate amount by which such contingencies exceeded the associated deferred revenue was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001564590-15-005051:notes:302]
Indemnification Agreements

[0001564590-15-005051:notes:303]
We enter into standard indemnification agreements in the ordinary course of business. Pursuant to these agreements, we agree to defend and indemnify other parties, primarily our customers or business partners or subcontractors, for damages and reasonable costs incurred in any suit or claim brought against them alleging that our products sold to them infringe any U.S. patent, copyright, trade secret, or similar right. If a product becomes the subject of an infringement claim, we may, at our option: (i) replace the product with another non-infringing product that provides substantially similar performance; (ii) modify the infringing product so that it no longer infringes but remains functionally equivalent; (iii) obtain the right for the customer to continue using the product at our expense and for the reseller to continue selling the product; (iv) take back the infringing product and refund to the customer the purchase price paid less depreciation amortized on a straight-line basis. We have not been required to make material payments pursuant to these provisions historically. We have not recorded any liability at April 24, 2015 related to these guarantees since the maximum amount of potential future payments under such guarantees, indemnities and warranties is not determinable, other than as described above.

[0001564590-15-005051:notes:304]
Legal Contingencies

[0001564590-15-005051:notes:305]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-15-005051:notes:306]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of April 24, 2015 related to such matters as they are not probable and/or reasonably estimable.
