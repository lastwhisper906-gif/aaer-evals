# NTAP 8-K — 0001002047-26-000003 filed 2026-09-02

## item codes, every 8-K on or before 2026-09-02

- 2026-09-02 0001002047-26-000003 — 2.02, 9.01
- 2026-05-28 0001193125-26-245196 — 2.02, 8.01, 9.01
- 2026-02-26 0001193125-26-076545 — 2.02, 9.01
- 2026-01-12 0001193125-26-010401 — 5.02, 7.01, 9.01
- 2025-11-25 0001193125-25-297164 — 2.02, 9.01
- 2025-09-15 0001193125-25-202408 — 5.02, 5.07, 9.01
- 2025-08-27 0000950170-25-111700 — 2.02, 9.01
- 2025-05-29 0000950170-25-078936 — 2.02, 5.02, 8.01, 9.01
- 2025-03-26 0000950170-25-045244 — 5.02, 7.01, 9.01
- 2025-03-17 0001193125-25-055656 — 1.01, 2.03, 8.01, 9.01
- 2025-03-05 0001193125-25-047187 — 1.01, 2.03, 9.01
- 2025-02-27 0000950170-25-029022 — 2.02, 9.01
- 2025-02-26 0001193125-25-036882 — 5.02, 9.01
- 2025-01-28 0001193125-25-014441 — 5.02, 9.01
- 2024-11-21 0000950170-24-129714 — 2.02, 9.01
- 2024-09-12 0000950170-24-105928 — 5.02, 5.07, 9.01
- 2024-08-28 0000950170-24-101383 — 2.02, 5.02, 9.01
- 2024-05-30 0000950170-24-066567 — 2.02, 8.01, 9.01
- 2024-04-09 0000950170-24-042957 — 5.02
- 2024-02-29 0000950170-24-023060 — 2.02, 9.01
- 2023-11-28 0000950170-23-066400 — 2.02, 9.01
- 2023-11-16 0000950170-23-064506 — 5.02, 5.03, 9.01
- 2023-09-15 0000950170-23-048229 — 5.02, 5.07, 9.01
- 2023-08-23 0000950170-23-044130 — 2.02, 9.01
- 2023-08-10 0000950170-23-041348 — 5.02
- 2023-05-31 0000950170-23-025324 — 1.01, 2.02, 8.01, 9.01
- 2023-02-22 0000950170-23-003745 — 2.02, 9.01
- 2023-01-31 0001193125-23-019739 — 2.05, 7.01, 9.01
- 2022-11-29 0000950170-22-025793 — 2.02, 9.01
- 2022-11-16 0000950170-22-025317 — 5.02
- 2022-09-14 0000950170-22-018490 — 5.07
- 2022-08-24 0000950170-22-017731 — 2.02, 9.01
- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2026-09-02

- none on or before 2026-09-02

## item 2.02 — earnings release, exhibit 99.1

[0001002047-26-000003:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0001002047-26-000003:8k_2_02:2]
EX-99.1

[0001002047-26-000003:8k_2_02:3]
Exhibit 99.1

[0001002047-26-000003:8k_2_02:4]
NetApp Reports First Quarter of Fiscal Year 2027 Results

[0001002047-26-000003:8k_2_02:5]
Delivers record quarterly net revenues of $2.03 billion, an increase of 30% year-over-year;

[0001002047-26-000003:8k_2_02:6]
First quarter GAAP earnings per share of $1.88; record non-GAAP earnings per share of $2.58;

[0001002047-26-000003:8k_2_02:7]
Significantly raised fiscal year 2027 revenue and earnings per share guidance

[0001002047-26-000003:8k_2_02:8]
News Summary

[0001002047-26-000003:8k_2_02:9]
•
Record all-flash array net revenue of $1.3 billion for the first quarter of fiscal year 2027, an increase of 47% year-over-year

[0001002047-26-000003:8k_2_02:10]
•
Record Public Cloud net revenue of $206 million for the first quarter of fiscal year 2027, an increase of 28% year-over-year

[0001002047-26-000003:8k_2_02:11]
•
Billings of $2.06 billion for the first quarter of fiscal year 2027, an increase of 36% year-over-year

[0001002047-26-000003:8k_2_02:12]
•
First quarter GAAP operating margin of 23.9%; first quarter non-GAAP operating margin of 31.9%

[0001002047-26-000003:8k_2_02:13]
•
Acquired DataPelago, Inc., an AI data infrastructure company, to help customers simplify and accelerate AI deployment at scale

[0001002047-26-000003:8k_2_02:14]
SAN JOSE, Calif.—September 2, 2026—NetApp (NASDAQ: NTAP), the Intelligent Data Infrastructure company, today reported financial results for the first quarter of fiscal year 2027, which ended on July 31, 2026.

[0001002047-26-000003:8k_2_02:15]
“NetApp delivered a record-setting start to the year, exceeding guidance on every metric and achieving our strongest first quarter ever,” said George Kurian, Chief Executive Officer. “Our momentum reflects not only the trust of existing customers but also our success in winning new ones, as organizations choose the NetApp Platform to power their AI and hybrid multi-cloud initiatives. Through continued innovation and strategic investments, we are enabling customers to address their most critical needs and creating lasting value for all stakeholders.”

[0001002047-26-000003:8k_2_02:16]
First Quarter of Fiscal Year 2027 Financial Results

[0001002047-26-000003:8k_2_02:17]
($ in millions, except earnings per share)

[0001002047-26-000003:8k_2_02:18]
| GAAP Results |  |  |
|  |  | Q1 FY27 |  |  | Q1 FY26 |  |  | % Change |  |  |
| Net revenues |  | $ | 2,025 |  |  | $ | 1,559 |  |  |  | 30 | % |  |
| Hybrid Cloud segment revenues |  | $ | 1,819 |  |  | $ | 1,398 |  |  |  | 30 | % |  |
| Public Cloud segment revenues |  | $ | 206 |  |  | $ | 161 |  |  |  | 28 | % |  |
| Gross profit |  | $ | 1,419 |  |  | $ | 1,098 |  |  |  | 29 | % |  |
| Net income |  | $ | 375 |  |  | $ | 233 |  |  |  | 61 | % |  |
| Earnings per share |  | $ | 1.88 |  |  | $ | 1.15 |  |  |  | 63 | % |  |
| Net cash provided by operating activities |  | $ | 503 |  |  | $ | 673 |  |  |  | (25 | )% |  |

[0001002047-26-000003:8k_2_02:19]
| Non-GAAP Results |  |  |
|  |  | Q1 FY27 |  |  | Q1 FY26 |  |  | % Change |  |  |
| Billings |  | $ | 2,057 |  |  | $ | 1,511 |  |  |  | 36 | % |  |
| Net revenues |  | $ | 2,025 |  |  | $ | 1,559 |  |  |  | 30 | % |  |
| Hybrid Cloud segment revenues |  | $ | 1,819 |  |  | $ | 1,398 |  |  |  | 30 | % |  |
| Public Cloud segment revenues |  | $ | 206 |  |  | $ | 161 |  |  |  | 28 | % |  |
| Gross profit |  | $ | 1,429 |  |  | $ | 1,108 |  |  |  | 29 | % |  |
| Net income |  | $ | 515 |  |  | $ | 314 |  |  |  | 64 | % |  |
| Earnings per share |  | $ | 2.58 |  |  | $ | 1.55 |  |  |  | 66 | % |  |
| Free cash flow |  | $ | 401 |  |  | $ | 620 |  |  |  | (35 | )% |  |
| Full reconciliations between GAAP and non-GAAP measures, and explanations related to the usage of non-GAAP measures, are provided below. |

[0001002047-26-000003:8k_2_02:20]
Second Quarter of Fiscal Year 2027 Financial Outlook

[0001002047-26-000003:8k_2_02:21]
| The Company provided the following financial guidance for the second quarter of fiscal year 2027: |
| Net revenues are expected to be in the range of: | $2.025 billion - $2.175 billion |
|  | GAAP |  | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 66.0% - 67.0% |  | 67.0% - 68.0% |
| Operating margins are expected to be in the range of: | 24.9% - 25.9% |  | 30.9% - 31.9% |
| Earnings per share is expected to be in the range of: | $1.97 - $2.07 |  | $2.54 - $2.64 |

[0001002047-26-000003:8k_2_02:22]
Full Fiscal Year 2027 Financial Outlook

[0001002047-26-000003:8k_2_02:23]
| The Company provided the following financial guidance for the full fiscal year 2027: |  |  |
| Net revenues are expected to be in the range of: | $7.975 billion - $8.225 billion |
|  | GAAP |  | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 67.1% - 68.1% |  | 68.1% - 69.1% |
| Operating margins are expected to be in the range of: | 24.3% - 25.3% |  | 30.3% - 31.3% |
| Earnings per share is expected to be in the range of: | $7.35 - $7.65 |  | $9.73 - $10.03 |

[0001002047-26-000003:8k_2_02:24]
Dividend

[0001002047-26-000003:8k_2_02:25]
The next cash dividend of $0.52 per share is to be paid on October 28, 2026, to stockholders of record as of the close of business on October 9, 2026.

[0001002047-26-000003:8k_2_02:26]
First Quarter of Fiscal Year 2027 Business Highlights

[0001002047-26-000003:8k_2_02:27]
Leading Product Innovation

[0001002047-26-000003:8k_2_02:28]
•
NetApp announced the release of StorageGRID 12.1, designed to help customers scale AI and other modern workloads with a federated global namespace, improving how data is accessed, processed, and managed across distributed environments to support AI data pipelines.

[0001002047-26-000003:8k_2_02:29]
•
NetApp announced new capabilities to NetApp Trident software 26.06 that helps Kubernetes platform teams scale workloads, while adding smarter volume placement, non-disruptive iSCSI volume rebalancing, expanded cloud support, and deeper integration for OpenShift Virtualization migrations.

[0001002047-26-000003:8k_2_02:30]
•
NetApp announced new data management capabilities optimized for Red Hat OpenShift that enable advanced levels of resilience and scale for virtualized environments, on-premises and in the cloud.

[0001002047-26-000003:8k_2_02:31]
•
NetApp announced Instaclustr for Model Context Protocol (MCP) Gateway, a fully managed gateway service that connects Instaclustr managed data infrastructure to AI applications and agents.

[0001002047-26-000003:8k_2_02:32]
•
NetApp announced the general availability of Azure NetApp Files support for large files up to 64 TiB on regular volumes to help remove the friction from large-scale migrations, de-risk VMware estate moves, and allow architects to design cleaner, more cost-effective solutions.

[0001002047-26-000003:8k_2_02:33]
•
NetApp announced the general availability of Azure NetApp Files Object REST API to eliminate complex data pipelines and enable direct access to AI capabilities through standardized interfaces.

[0001002047-26-000003:8k_2_02:34]
•
NetApp introduced nconnect on Azure VMware Solution, increasing throughput and lowering effective latency under load without adding datastores or hosts.

[0001002047-26-000003:8k_2_02:35]
•
NetApp announced the general availability of Azure NetApp Files migration assistant to accelerate and simplify migrations of business-critical applications and data to Azure.

[0001002047-26-000003:8k_2_02:36]
Customer and Partner Momentum

[0001002047-26-000003:8k_2_02:37]
•
NetApp announced a collaboration with Cisco to offer new solutions for secure, scalable, and simplified AI, expanding on the success of FlexPod to support AI adoption across organizations.

[0001002047-26-000003:8k_2_02:38]
•
NetApp announced an expanded collaboration with Cisco to strengthen defense-in-depth strategies for customers with the new NetApp Splunk Security Orchestration, Automation, and Response (SOAR) playbook.

[0001002047-26-000003:8k_2_02:39]
•
NetApp announced a deepened global alliance with CGI where NetApp Keystone will power CGI’s block storage solutions within its shared services platform.

[0001002047-26-000003:8k_2_02:40]
•
NetApp and SK Telecom announced the completion of a joint proof of concept, using NetApp AFX systems with SK Telecom’s Petasus AI Cloud, demonstrating a solution that enables enterprises to scale AI infrastructure in virtualized environments while maintaining high performance.

[0001002047-26-000003:8k_2_02:41]
•
NetApp and Okestro signed a strategic partnership agreement to jointly develop integrated enterprise AI and disaster recovery infrastructure.

[0001002047-26-000003:8k_2_02:42]
•
NetApp announced a strategic partnership with Tata Consultancy Services to better help organizations discover, classify, and govern data across locations, reduce the impact of cyber-attacks, speed up recovery times, and provide insights on sensitive data locations and permissions.

[0001002047-26-000003:8k_2_02:43]
Corporate News and Events

[0001002047-26-000003:8k_2_02:44]
•
NetApp announced its acquisition of DataPelago, Inc., to further enable computing where data is created and stored, accelerating demanding workloads while improving infrastructure efficiency at scale.

[0001002047-26-000003:8k_2_02:45]
Personnel

[0001002047-26-000003:8k_2_02:46]
•
NetApp appointed Alvaro Celis as Chief Partner and Ecosystem Officer to lead partner ecosystems, modernize incentive programs, improve partner satisfaction, and drive growth.

[0001002047-26-000003:8k_2_02:47]
Awards and Recognition

[0001002047-26-000003:8k_2_02:48]
•
NetApp CEO, George Kurian, was named to CRN’s 25 Most Influential Executives of 2026 list, emphasizing his leadership in data storage amid the age of cloud and AI.

[0001002047-26-000003:8k_2_02:49]
•
NetApp’s AI Data Engine was named as a finalist in CRN’s 2026 Tech Innovator Awards, noting its ability to transform massive unstructured data estates into always-fresh, AI-ready assets with enterprise-grade security, compliance, and operational efficiency.

[0001002047-26-000003:8k_2_02:50]
•
NetApp was named a Leader in the Forrester WaveTM: Object Storage Solutions, Q2 2026, showcasing our strong fit for large enterprises managing distributed, regulated object estates that want to balance governance and hybrid consistency against the need for AI-native storage services.

[0001002047-26-000003:8k_2_02:51]
•
NetApp was recognized in The Wall Street Journal’s 2026 Best Companies For The Future list, ranking 60 out of 500 organizations.

[0001002047-26-000003:8k_2_02:52]
•
NetApp was named as one of the Greatest Workplaces in America, California, and Tech for 2026 by Newsweek, receiving a five-star rating based on a comprehensive worker satisfaction study.

[0001002047-26-000003:8k_2_02:53]
•
NetApp was named to Time Magazine’s Best Companies of 2026 list, ranking 271 out of 1,000 organizations.

[0001002047-26-000003:8k_2_02:54]
•
NetApp was named as one of the Best Companies to Work For by U.S. News, highlighting its top work environment.

[0001002047-26-000003:8k_2_02:55]
Webcast and Conference Call Information

[0001002047-26-000003:8k_2_02:56]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today. NetApp uses its website as a tool to disclose important information about NetApp and comply with its disclosure obligations under Regulation Fair Disclosure.

[0001002047-26-000003:8k_2_02:57]
Actual results may differ materially from these statements for a variety of reasons, including, without limitation, our ability to keep pace with the rapid industry, technological and market trends and changes in the markets in which we operate; our ability to execute our evolved cloud strategy and introduce and gain market acceptance for our products and services; our ability to maintain our customer, partner, supplier and contract manufacturer relationships on favorable terms and conditions; global political, macroeconomic and market conditions, including inflation, fluctuating interest rates, tariffs, changes in trade policy, regulations, monetary policy shifts, recession risks, and foreign exchange volatility and the resulting impact on demand for our products; the impact of new or ongoing geopolitical conflicts and sanctions; adoption or changes to laws, regulations, standards, or policies affecting our operations, products, services, the storage industry, or AI usage; material cybersecurity and other security breaches; the impact of supply chain disruptions on our business operations, financial performance and results of operations; changes and related uncertainty in U.S. government spending or policy, including due to prolonged federal government shutdowns; changes in overall technology spending by our customers; revenue seasonality; changes in laws or regulations, including those relating to privacy, data protection and information security; the timing of orders and their fulfillment; and our ability to manage our gross profit margins, including managing component costs. These and other equally important factors are described in reports and documents we file from time to time with the Securities and Exchange Commission, including the factors described under the sections titled “Risk Factors” in our most recently filed annual report on Form 10-K and quarterly report on Form 10-Q. All statements made in this release are made only as of the date set forth at the beginning of this release. We disclaim any obligation to update information contained in this press release, whether as a result of new information, future events, or otherwise.

[0001002047-26-000003:8k_2_02:58]
NetApp Usage of Non-GAAP Financial Information

[0001002047-26-000003:8k_2_02:59]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP gross margins, non-GAAP gross profit, non-GAAP operating income, non-GAAP operating margins, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per share.

[0001002047-26-000003:8k_2_02:60]
NetApp believes that the presentation of its non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. Non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001002047-26-000003:8k_2_02:61]
NetApp believes that the presentation of non-GAAP gross margins, non-GAAP gross profit, non-GAAP operating income, non-GAAP operating margins, non-GAAP effective tax rate, non-GAAP net income, and non-GAAP earnings per share data provides investors with supplemental metrics that assist in understanding current results and future prospects, earnings and profitability that are complementary to GAAP metrics. Each of these non-GAAP metrics is defined as the applicable GAAP metric adjusted to exclude the items defined in A through I below, as applicable, while our non-GAAP effective tax rate and non-GAAP net income also reflect a non-GAAP tax provision, as described in item J below, instead of our GAAP tax provision. GAAP earnings per share and non-GAAP earnings per share are calculated using the net income divided by the diluted number of shares for the applicable period.

[0001002047-26-000003:8k_2_02:62]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to investors and management because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001002047-26-000003:8k_2_02:63]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to investors and management because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0001002047-26-000003:8k_2_02:64]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001002047-26-000003:8k_2_02:65]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001002047-26-000003:8k_2_02:66]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001002047-26-000003:8k_2_02:67]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001002047-26-000003:8k_2_02:68]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0001002047-26-000003:8k_2_02:69]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001002047-26-000003:8k_2_02:70]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001002047-26-000003:8k_2_02:71]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer and/or lose control of assets to a third party. This is inclusive of third-party advisory, legal and other costs that result directly from and are essential to a sale transaction and that would not have been incurred had the decision to sell not been made. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0001002047-26-000003:8k_2_02:72]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0001002047-26-000003:8k_2_02:73]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such non-recurring costs do not reflect the results of its underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0001002047-26-000003:8k_2_02:74]
J. Income tax effects. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges or benefits that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges or benefits resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001002047-26-000003:8k_2_02:75]
Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies. In addition, non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with GAAP. A detailed reconciliation of our non-GAAP to GAAP results can be found herein. In the press release and accompanying financial statements and reconciliations, the terms "operating income" and "income from operations" are used interchangeably. Similarly, "earnings per share" and "net income per share" are also used interchangeably.

[0001002047-26-000003:8k_2_02:76]
Constant Currency

[0001002047-26-000003:8k_2_02:77]
In periods in which the impacts of foreign currency exchange rate changes are significant, NetApp presents certain constant currency growth rates or quantifies the impact of foreign currency exchange rate changes on year-over-year fluctuations, including for net revenues, billings, and earnings. This constant currency information assumes that the same foreign currency exchange rates that were in effect for the comparable prior-year period were used in translation of the current period results.

[0001002047-26-000003:8k_2_02:78]
About NetApp

[0001002047-26-000003:8k_2_02:79]
For more than three decades, NetApp has helped the world’s leading organizations navigate change – from the rise of enterprise storage to the intelligent era defined by data and AI. Today, NetApp is the Intelligent Data Infrastructure company, helping customers turn data into a catalyst for innovation, resilience, and growth.

[0001002047-26-000003:8k_2_02:80]
At the heart of that infrastructure is the NetApp data platform – the unified, enterprise-grade, intelligent foundation that connects, protects, and activates data across every cloud, workload, and environment. Built on the proven power of NetApp ONTAP, our leading data management software and OS, and enhanced by automation through the AI Data Engine and AFX, it delivers observability, resilience, and intelligence at scale.

[0001002047-26-000003:8k_2_02:81]
Disaggregated by design, the NetApp data platform separates storage, services, and control so enterprises can modernize faster, scale efficiently, and innovate without lock-in. As the only enterprise storage platform natively embedded in the world’s largest clouds, it gives organizations the freedom to run any workload anywhere with consistent performance, governance, and protection.

[0001002047-26-000003:8k_2_02:82]
With NetApp, data is always ready – ready to defend against threats, ready to power AI, and ready to drive the next breakthrough. That’s why the world’s most forward-thinking enterprises trust NetApp to turn intelligence into advantage.

[0001002047-26-000003:8k_2_02:83]
Learn more at www.netapp.com or follow us on X, LinkedIn, Facebook, and Instagram.

[0001002047-26-000003:8k_2_02:84]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001002047-26-000003:8k_2_02:85]
NETAPP, INC.

[0001002047-26-000003:8k_2_02:86]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001002047-26-000003:8k_2_02:87]
($ in millions)

[0001002047-26-000003:8k_2_02:88]
(Unaudited)

[0001002047-26-000003:8k_2_02:89]
|  |  | July 31, 2026 |  |  | April 24, 2026 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,576 |  |  | $ | 3,584 |  |
| Accounts receivable |  |  | 966 |  |  |  | 1,286 |  |
| Inventories |  |  | 375 |  |  |  | 198 |  |
| Other current assets |  |  | 755 |  |  |  | 708 |  |
| Total current assets |  |  | 5,672 |  |  |  | 5,776 |  |
| Property and equipment, net |  |  | 663 |  |  |  | 592 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,954 |  |  |  | 2,794 |  |
| Other non-current assets |  |  | 1,666 |  |  |  | 1,582 |  |
| Total assets |  | $ | 10,955 |  |  | $ | 10,744 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 566 |  |  | $ | 550 |  |
| Accrued expenses |  |  | 1,200 |  |  |  | 1,151 |  |
| Current portion of long-term debt |  |  | 550 |  |  |  | — |  |
| Short-term deferred revenue |  |  | 2,252 |  |  |  | 2,320 |  |
| Total current liabilities |  |  | 4,568 |  |  |  | 4,021 |  |
| Long-term debt |  |  | 1,938 |  |  |  | 2,487 |  |
| Other long-term liabilities |  |  | 360 |  |  |  | 360 |  |
| Long-term deferred revenue |  |  | 2,594 |  |  |  | 2,525 |  |
| Total liabilities |  |  | 9,460 |  |  |  | 9,393 |  |
| Stockholders' equity |  |  | 1,495 |  |  |  | 1,351 |  |
| Total liabilities and stockholders' equity |  | $ | 10,955 |  |  | $ | 10,744 |  |

[0001002047-26-000003:8k_2_02:90]
NETAPP, INC.

[0001002047-26-000003:8k_2_02:91]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001002047-26-000003:8k_2_02:92]
($ in millions, except net income per share amounts)

[0001002047-26-000003:8k_2_02:93]
(Unaudited)

[0001002047-26-000003:8k_2_02:94]
|  |  | Three Months Ended |
|  |  | July 31, 2026 |  |  | July 25, 2025 |  |  |
| Revenues: |  |  |  |  |  |  |  |
| Product |  | $ | 987 |  |  | $ | 654 |  |  |
| Services |  |  | 1,038 |  |  |  | 905 |  |  |
| Net revenues |  |  | 2,025 |  |  |  | 1,559 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product |  |  | 450 |  |  |  | 302 |  |  |
| Cost of services |  |  | 156 |  |  |  | 159 |  |  |
| Total cost of revenues |  |  | 606 |  |  |  | 461 |  |  |
| Gross profit |  |  | 1,419 |  |  |  | 1,098 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 507 |  |  |  | 461 |  |  |
| Research and development |  |  | 274 |  |  |  | 242 |  |  |
| General and administrative |  |  | 98 |  |  |  | 84 |  |  |
| Restructuring charges |  |  | 56 |  |  |  | 2 |  |  |
| Total operating expenses |  |  | 935 |  |  |  | 789 |  |  |
| Income from operations |  |  | 484 |  |  |  | 309 |  |  |
| Other expense, net |  |  | — |  |  |  | (5 | ) |  |
| Income before income taxes |  |  | 484 |  |  |  | 304 |  |  |
| Provision for income taxes |  |  | 109 |  |  |  | 71 |  |  |
| Net income |  | $ | 375 |  |  | $ | 233 |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic |  | $ | 1.91 |  |  | $ | 1.16 |  |  |
| Diluted |  | $ | 1.88 |  |  | $ | 1.15 |  |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |
| Basic |  |  | 196 |  |  |  | 201 |  |  |
| Diluted |  |  | 200 |  |  |  | 203 |  |  |

[0001002047-26-000003:8k_2_02:95]
NETAPP, INC.

[0001002047-26-000003:8k_2_02:96]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001002047-26-000003:8k_2_02:97]
($ in millions)

[0001002047-26-000003:8k_2_02:98]
(Unaudited)

[0001002047-26-000003:8k_2_02:99]
|  |  | Three Months Ended |  |
|  |  | July 31, 2026 |  |  | July 25, 2025 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income |  | $ | 375 |  |  | $ | 233 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 33 |  |  |  | 51 |  |
| Non-cash operating lease cost |  |  | 11 |  |  |  | 11 |  |
| Stock-based compensation |  |  | 98 |  |  |  | 83 |  |
| Deferred income taxes |  |  | (5 | ) |  |  | 9 |  |
| Other items, net |  |  | (15 | ) |  |  | 46 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable |  |  | 317 |  |  |  | 466 |  |
| Inventories |  |  | (176 | ) |  |  | 54 |  |
| Accounts payable |  |  | 19 |  |  |  | (107 | ) |
| Accrued expenses |  |  | (75 | ) |  |  | (240 | ) |
| Deferred revenue |  |  | 32 |  |  |  | (48 | ) |
| Changes in other operating assets and liabilities, net |  |  | (111 | ) |  |  | 115 |  |
| Net cash provided by operating activities |  |  | 503 |  |  |  | 673 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of investments, net |  |  | (494 | ) |  |  | (143 | ) |
| Purchases of property and equipment |  |  | (102 | ) |  |  | (53 | ) |
| Acquisition of business, net of cash acquired |  |  | (78 | ) |  |  | — |  |
| Other investing activities, net |  |  | — |  |  |  | 15 |  |
| Net cash used in investing activities |  |  | (674 | ) |  |  | (181 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 57 |  |  |  | 54 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (74 | ) |  |  | (57 | ) |
| Repurchase of common stock |  |  | (200 | ) |  |  | (300 | ) |
| Repayments and extinguishment of debt |  |  | — |  |  |  | (750 | ) |
| Dividends paid |  |  | (102 | ) |  |  | (104 | ) |
| Net cash used in financing activities |  |  | (319 | ) |  |  | (1,157 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (6 | ) |  |  | 7 |  |
| Net change in cash, cash equivalents and restricted cash |  |  | (496 | ) |  |  | (658 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |
| Beginning of period |  |  | 2,075 |  |  |  | 2,749 |  |
| End of period |  | $ | 1,579 |  |  | $ | 2,091 |  |

[0001002047-26-000003:8k_2_02:100]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| ($ in millions) |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| NET INCOME |  | $ | 375 |  |  |  | $ | 233 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 6 |  |  |  |  | 6 |  |
| Stock-based compensation |  |  | 98 |  |  |  |  | 83 |  |
| Restructuring charges |  |  | 56 |  |  |  |  | 2 |  |
| Acquisition-related expense |  |  | 1 |  |  |  |  | — |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | 1 |  |
| Income tax effects |  |  | (21 | ) |  |  |  | (11 | ) |
| NON-GAAP NET INCOME |  | $ | 515 |  |  |  | $ | 314 |  |
| COST OF REVENUES |  | $ | 606 |  |  |  | $ | 461 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (3 | ) |
| Stock-based compensation |  |  | (7 | ) |  |  |  | (7 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 596 |  |  |  | $ | 451 |  |
| COST OF PRODUCT REVENUES |  | $ | 450 |  |  |  | $ | 302 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 448 |  |  |  | $ | 301 |  |
| COST OF SERVICES REVENUES |  | $ | 156 |  |  |  | $ | 159 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (3 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  |  | (6 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 148 |  |  |  | $ | 150 |  |
| GROSS PROFIT |  | $ | 1,419 |  |  |  | $ | 1,098 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 3 |  |  |  |  | 3 |  |
| Stock-based compensation |  |  | 7 |  |  |  |  | 7 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,429 |  |  |  | $ | 1,108 |  |

[0001002047-26-000003:8k_2_02:101]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| ($ in millions) |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| SALES AND MARKETING EXPENSES |  | $ | 507 |  |  |  | $ | 461 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (3 | ) |
| Stock-based compensation |  |  | (40 | ) |  |  |  | (34 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 464 |  |  |  | $ | 424 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 274 |  |  |  | $ | 242 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (35 | ) |  |  |  | (25 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 239 |  |  |  | $ | 217 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 98 |  |  |  | $ | 84 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (16 | ) |  |  |  | (17 | ) |
| Acquisition-related expense |  |  | (1 | ) |  |  |  | — |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | (1 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 81 |  |  |  | $ | 66 |  |
| RESTRUCTURING CHARGES |  | $ | 56 |  |  |  | $ | 2 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (56 | ) |  |  |  | (2 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 935 |  |  |  | $ | 789 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (3 | ) |
| Stock-based compensation |  |  | (91 | ) |  |  |  | (76 | ) |
| Restructuring charges |  |  | (56 | ) |  |  |  | (2 | ) |
| Acquisition-related expense |  |  | (1 | ) |  |  |  | — |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | (1 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 784 |  |  |  | $ | 707 |  |

[0001002047-26-000003:8k_2_02:102]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| ($ in millions, except net income per share) |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| INCOME FROM OPERATIONS |  | $ | 484 |  |  |  | $ | 309 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 6 |  |  |  |  | 6 |  |
| Stock-based compensation |  |  | 98 |  |  |  |  | 83 |  |
| Restructuring charges |  |  | 56 |  |  |  |  | 2 |  |
| Acquisition-related expense |  |  | 1 |  |  |  |  | — |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | 1 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 645 |  |  |  | $ | 401 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 484 |  |  |  | $ | 304 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 6 |  |  |  |  | 6 |  |
| Stock-based compensation |  |  | 98 |  |  |  |  | 83 |  |
| Restructuring charges |  |  | 56 |  |  |  |  | 2 |  |
| Acquisition-related expense |  |  | 1 |  |  |  |  | — |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | 1 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 645 |  |  |  | $ | 396 |  |
| PROVISION FOR INCOME TAXES |  | $ | 109 |  |  |  | $ | 71 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Income tax effects |  |  | 21 |  |  |  |  | 11 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 130 |  |  |  | $ | 82 |  |
| NET INCOME PER SHARE |  | $ | 1.88 |  |  |  | $ | 1.15 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.03 |  |  |  |  | 0.03 |  |
| Stock-based compensation |  |  | 0.49 |  |  |  |  | 0.41 |  |
| Restructuring charges |  |  | 0.28 |  |  |  |  | 0.01 |  |
| Acquisition-related expense |  |  | 0.01 |  |  |  |  | — |  |
| Income tax effects |  |  | (0.11 | ) |  |  |  | (0.05 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 2.58 |  |  |  | $ | 1.55 |  |

[0001002047-26-000003:8k_2_02:103]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Gross margin |  |  | 70.1 | % |  |  |  | 70.4 | % |
| Cost of revenues adjustments |  |  | 0.5 | % |  |  |  | 0.7 | % |
| Non-GAAP Gross margin |  |  | 70.6 | % |  |  |  | 71.1 | % |
| Cost of revenues |  | $ | 606 |  |  |  | $ | 461 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (3 | ) |
| Stock-based compensation |  |  | (7 | ) |  |  |  | (7 | ) |
| Non-GAAP Cost of revenues |  | $ | 596 |  |  |  | $ | 451 |  |
| Net revenues |  | $ | 2,025 |  |  |  | $ | 1,559 |  |

[0001002047-26-000003:8k_2_02:104]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Product gross margin |  |  | 54.4 | % |  |  |  | 53.8 | % |
| Cost of product revenues adjustments |  |  | 0.2 | % |  |  |  | 0.2 | % |
| Non-GAAP Product gross margin |  |  | 54.6 | % |  |  |  | 54.0 | % |
| Cost of product revenues |  | $ | 450 |  |  |  | $ | 302 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  |  | (1 | ) |
| Non-GAAP Cost of product revenues |  | $ | 448 |  |  |  | $ | 301 |  |
| Product revenues |  | $ | 987 |  |  |  | $ | 654 |  |

[0001002047-26-000003:8k_2_02:105]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Services gross margin |  |  | 85.0 | % |  |  |  | 82.4 | % |
| Cost of services revenues adjustments |  |  | 0.7 | % |  |  |  | 1.0 | % |
| Non-GAAP Services gross margin |  |  | 85.7 | % |  |  |  | 83.4 | % |
| Cost of services revenues |  | $ | 156 |  |  |  | $ | 159 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (3 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  |  | (6 | ) |
| Non-GAAP Cost of services revenues |  | $ | 148 |  |  |  | $ | 150 |  |
| Services revenues |  | $ | 1,038 |  |  |  | $ | 905 |  |

[0001002047-26-000003:8k_2_02:106]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| OPERATING MARGIN |  |
| ($ in millions) |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Operating margin |  |  | 23.9 | % |  |  |  | 19.8 | % |
| Adjustments |  |  | 8.0 | % |  |  |  | 5.9 | % |
| Non-GAAP Operating margin |  |  | 31.9 | % |  |  |  | 25.7 | % |
| Income from operations |  | $ | 484 |  |  |  | $ | 309 |  |
| Income from operations adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 6 |  |  |  |  | 6 |  |
| Stock-based compensation |  |  | 98 |  |  |  |  | 83 |  |
| Restructuring charges |  |  | 56 |  |  |  |  | 2 |  |
| Acquisition-related expense |  |  | 1 |  |  |  |  | — |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | 1 |  |
| Non-GAAP Income from operations |  | $ | 645 |  |  |  | $ | 401 |  |
| Net revenues |  | $ | 2,025 |  |  |  | $ | 1,559 |  |

[0001002047-26-000003:8k_2_02:107]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Effective tax rate |  |  | 22.5 | % |  |  |  | 23.4 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Income tax effects |  |  | (2.3 | )% |  |  |  | (2.7 | )% |
| Non-GAAP Effective tax rate |  |  | 20.2 | % |  |  |  | 20.7 | % |

[0001002047-26-000003:8k_2_02:108]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| ($ in millions) |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Net cash provided by operating activities |  | $ | 503 |  |  |  | $ | 673 |  |
| Purchases of property and equipment |  |  | (102 | ) |  |  |  | (53 | ) |
| Free cash flow |  | $ | 401 |  |  |  | $ | 620 |  |

[0001002047-26-000003:8k_2_02:109]
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| ($ in millions) |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Net revenues |  | $ | 2,025 |  |  |  | $ | 1,559 |  |
| Change in deferred revenue* |  |  | 32 |  |  |  |  | (48 | ) |
| Billings |  | $ | 2,057 |  |  |  | $ | 1,511 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0001002047-26-000003:8k_2_02:110]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| ($ in millions, except net income per share, DSO, DPO, and Inventory Turns) |  |
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Product |  | $ | 987 |  |  |  | $ | 654 |  |
| Support |  |  | 720 |  |  |  |  | 647 |  |
| Professional and Other Services |  |  | 112 |  |  |  |  | 97 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,819 |  |  |  |  | 1,398 |  |
| Public Cloud Segment Net Revenues |  |  | 206 |  |  |  |  | 161 |  |
| Net Revenues |  | $ | 2,025 |  |  |  | $ | 1,559 |  |
| Hybrid Cloud Segment Net Revenues by Storage Category |  |  |  |  |  |  |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| All-flash revenues |  | $ | 1,309 |  |  |  | $ | 893 |  |
| Hybrid-flash and other revenues |  |  | 510 |  |  |  |  | 505 |  |
| Hybrid Cloud Segment Net Revenues |  | $ | 1,819 |  |  |  | $ | 1,398 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Product |  | $ | 539 |  |  |  | $ | 353 |  |
| Support |  |  | 671 |  |  |  |  | 597 |  |
| Professional and Other Services |  |  | 41 |  |  |  |  | 29 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 1,251 |  |  |  |  | 979 |  |
| Public Cloud Segment Gross Profit |  |  | 178 |  |  |  |  | 129 |  |
| Total Segments Gross Profit |  |  | 1,429 |  |  |  |  | 1,108 |  |
| Amortization of Intangible Assets |  |  | (3 | ) |  |  |  | (3 | ) |
| Stock-based Compensation |  |  | (7 | ) |  |  |  | (7 | ) |
| Unallocated Cost of Revenues |  |  | (10 | ) |  |  |  | (10 | ) |
| Gross Profit |  | $ | 1,419 |  |  |  | $ | 1,098 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Product |  |  | 54.6 | % |  |  |  | 54.0 | % |
| Support |  |  | 93.2 | % |  |  |  | 92.3 | % |
| Professional and Other Services |  |  | 36.6 | % |  |  |  | 29.9 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 68.8 | % |  |  |  | 70.0 | % |
| Public Cloud Segment Gross Margin |  |  | 86.4 | % |  |  |  | 80.1 | % |

[0001002047-26-000003:8k_2_02:111]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| ($ in millions, except net income per share, DSO, DPO, and Inventory Turns) |  |
| (Unaudited) |  |
| Net Revenues by Geographic Area |  |  |  |  |  |  |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Americas |  |  | 48 | % |  |  |  | 51 | % |
| Americas Commercial |  |  | 37 | % |  |  |  | 40 | % |
| U.S. Public Sector* |  |  | 11 | % |  |  |  | 11 | % |
| EMEA |  |  | 33 | % |  |  |  | 32 | % |
| Asia Pacific |  |  | 19 | % |  |  |  | 17 | % |
| * U.S. Public Sector includes revenue from both the U.S. federal government and U.S. state governments, local municipalities and education institutions. |  |

[0001002047-26-000003:8k_2_02:112]
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Non-GAAP Income from Operations |  | $ | 645 |  |  |  | $ | 401 |  |
| Operating Margin |  |  | 31.9 | % |  |  |  | 25.7 | % |
| Non-GAAP Income before Income Taxes |  | $ | 645 |  |  |  | $ | 396 |  |
| Non-GAAP Effective Tax Rate |  |  | 20.2 | % |  |  |  | 20.7 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Non-GAAP Net Income |  | $ | 515 |  |  |  | $ | 314 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 200 |  |  |  |  | 203 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 2.58 |  |  |  | $ | 1.55 |  |

[0001002047-26-000003:8k_2_02:113]
| Select Balance Sheet Items |  |  |  |  |  |  |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Deferred Revenue |  | $ | 4,846 |  |  |  | $ | 4,526 |  |
| DSO (days) |  |  | 47 |  |  |  |  | 46 |  |
| DPO (days) |  |  | 92 |  |  |  |  | 80 |  |
| Inventory Turns |  |  | 6 |  |  |  |  | 14 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |

[0001002047-26-000003:8k_2_02:114]
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |
|  |  | Q1 FY27 |  |  |  | Q1 FY26 |  |
| Net Cash Provided by Operating Activities |  | $ | 503 |  |  |  | $ | 673 |  |
| Purchases of Property and Equipment |  | $ | 102 |  |  |  | $ | 53 |  |
| Free Cash Flow |  | $ | 401 |  |  |  | $ | 620 |  |
| Free Cash Flow Margin |  |  | 19.8 | % |  |  |  | 39.8 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Free cash flow margin is defined as free cash flow as a percentage of net revenues. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001002047-26-000003:8k_2_02:115]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| SECOND QUARTER FISCAL 2027 |
|  |  | Second Quarter |
|  |  | Fiscal 2027 |
| GAAP Guidance - Gross Margin |  | 66.0% - 67.0% |
| Adjustments: |  |  |
| Cost of revenues adjustments |  | 1% |
| Non-GAAP Guidance - Gross Margin |  | 67.0% - 68.0% |
|  |  | Second Quarter |
|  |  | Fiscal 2027 |
| GAAP Guidance - Operating Margin |  | 24.9% - 25.9% |
| Adjustments: |  |  |
| Stock-based compensation expense |  | 6% |
| Non-GAAP Guidance - Operating Margin |  | 30.9% - 31.9% |
| Some items may not add or recalculate due to rounding. |

[0001002047-26-000003:8k_2_02:116]
|  |  | Second Quarter |
|  |  | Fiscal 2027 |
| GAAP Guidance - Net Income Per Share |  | $1.97 - $2.07 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share: |  |  |
| Amortization of intangible assets |  | $0.03 |
| Stock-based compensation expense |  | $0.58 |
| Income tax effects |  | ($0.04) |
| Total Adjustments |  | $0.57 |
| Non-GAAP Guidance - Net Income Per Share |  | $2.54 - $2.64 |
| Some items may not add or recalculate due to rounding. |

[0001002047-26-000003:8k_2_02:117]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| FISCAL 2027 |
|  |  | Fiscal 2027 |
| GAAP Guidance - Gross Margin |  | 67.1% - 68.1% |
| Adjustments: |  |  |
| Cost of revenues adjustments |  | 1% |
| Non-GAAP Guidance - Gross Margin |  | 68.1% - 69.1% |
|  |  | Fiscal 2027 |
| GAAP Guidance - Operating Margin |  | 24.3% - 25.3% |
| Adjustments: |  |  |
| Stock-based compensation expense |  | 5% |
| Restructuring charges |  | 1% |
| Non-GAAP Guidance - Operating Margin |  | 30.3% - 31.3% |
| Some items may not add or recalculate due to rounding. |

[0001002047-26-000003:8k_2_02:118]
|  |  | Fiscal 2027 |
| GAAP Guidance - Net Income Per Share |  | $7.35 - $7.65 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share: |  |  |
| Amortization of intangible assets |  | $0.12 |
| Stock-based compensation expense |  | $2.19 |
| Restructuring charges |  | $0.28 |
| Acquisition-related expenses |  | $0.01 |
| Income tax effects |  | ($0.22) |
| Total Adjustments |  | $2.38 |
| Non-GAAP Guidance - Net Income Per Share |  | $9.73 - $10.03 |
| Some items may not add or recalculate due to rounding. |

[0001002047-26-000003:8k_2_02:119]
Contacts:

[0001002047-26-000003:8k_2_02:120]
(Press)

[0001002047-26-000003:8k_2_02:121]
Kenya Hayes

[0001002047-26-000003:8k_2_02:122]
1 703 589 7595

[0001002047-26-000003:8k_2_02:123]
kenya.hayes@netapp.com

[0001002047-26-000003:8k_2_02:124]
(Investors)

[0001002047-26-000003:8k_2_02:125]
Kris Newton

[0001002047-26-000003:8k_2_02:126]
1 408 822 3312

[0001002047-26-000003:8k_2_02:127]
kris.newton@netapp.com
