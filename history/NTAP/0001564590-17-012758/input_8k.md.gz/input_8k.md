# NTAP 8-K — 0001564590-17-011611 filed 2017-05-24

## item codes, every 8-K on or before 2017-06-20

- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2017-06-20

- none on or before 2017-06-20

## item 2.02 — earnings release, exhibit 99.1

[0001564590-17-011611:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-17-011611:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-17-011611:8k_2_02:3]
Exhibit 99.1

[0001564590-17-011611:8k_2_02:4]
NETAPP REPORTS FOURTH QUARTER AND FISCAL YEAR 2017 RESULTS

[0001564590-17-011611:8k_2_02:5]
Net Revenues of $1.48 Billion for the Fourth Quarter and $5.52 Billion for Fiscal Year 2017

[0001564590-17-011611:8k_2_02:6]
| • | Net Revenues for Q4 up 5% quarter-over-quarter and 7% year-over-year. |

[0001564590-17-011611:8k_2_02:7]
| • | Q4 All-flash array annualized net revenue run rate of $1.70 billion, up almost 140% year-over-year. |

[0001564590-17-011611:8k_2_02:8]
| • | Over an exabyte of flash shipped in fiscal year 2017. |

[0001564590-17-011611:8k_2_02:9]
| • | $913 million returned to shareholders in share repurchases and cash dividends in fiscal year 2017. |

[0001564590-17-011611:8k_2_02:10]
| • | First quarter fiscal year 2018 dividend to increase by 5% to $0.20 per share. |

[0001564590-17-011611:8k_2_02:11]
Sunnyvale, Calif.—May 24, 2017—NetApp (NASDAQ: NTAP) today reported financial results for the fourth quarter and fiscal year 2017, ended April 28, 2017.

[0001564590-17-011611:8k_2_02:12]
Fourth Quarter Financial Results

[0001564590-17-011611:8k_2_02:13]
Net revenues for the fourth quarter of fiscal year 2017 were $1.48 billion. GAAP net income for the fourth quarter of fiscal year 2017 was $190 million, or $0.68 per share,1 compared to GAAP net loss of $8 million, or $0.03 loss per share,2 for the comparable period of the prior year. Non-GAAP net income for the fourth quarter of fiscal year 2017 was $239 million, or $0.86 per share,3 compared to non-GAAP net income of $157 million, or $0.55 per share, for the comparable period of the prior year.

[0001564590-17-011611:8k_2_02:14]
Fiscal Year 2017 Financial Results

[0001564590-17-011611:8k_2_02:15]
Net revenues for fiscal year 2017 were $5.52 billion. GAAP net income for fiscal year 2017 was $509 million, or $1.81 per share,1 compared to GAAP net income of $229 million, or $0.77 per share, for the comparable period of the prior year. Non-GAAP net income for fiscal year 2017 was $768 million, or $2.73 per share,3 compared to non-GAAP net income of $633 million, or $2.13 per share, for the comparable period of the prior year.

[0001564590-17-011611:8k_2_02:16]
Cash, Cash Equivalents and Investments

[0001564590-17-011611:8k_2_02:17]
NetApp ended the fourth quarter of fiscal year 2017 with $4.9 billion in total cash, cash equivalents and investments. During the fourth quarter of fiscal year 2017, the Company generated $365 million in cash from operations and returned $180 million to shareholders through share repurchases and a cash dividend.

[0001564590-17-011611:8k_2_02:18]
The Company will increase the first quarter fiscal year 2018 dividend by 5% to $0.20 per share. The quarterly dividend will be paid on July 26, 2017, to shareholders of record as of the close of business on July 7, 2017.

[0001564590-17-011611:8k_2_02:19]
“Our continued focus and disciplined execution yielded yet another quarter of solid results. We have regained momentum, returning the company to revenue growth and delivering against all of our fiscal year 2017 commitments,” said George Kurian, chief executive officer. “By innovating to redefine traditional markets and to bring enterprise-grade technology to emerging areas of the market, we are gaining market share, expanding our addressable market, and creating new opportunities for NetApp.”

[0001564590-17-011611:8k_2_02:20]
Q1 Fiscal Year 2018 Outlook

[0001564590-17-011611:8k_2_02:21]
The Company provided the following financial guidance for the first quarter of fiscal year 2018:

[0001564590-17-011611:8k_2_02:22]
| • | Net revenues are expected to be in the range of $1.24 billion to $1.39 billion GAAPNon-GAAP |

[0001564590-17-011611:8k_2_02:23]
| • | Earnings per share is expected to be in the range of:$0.30 - $0.38$0.49 - $0.57 |

[0001564590-17-011611:8k_2_02:24]
Full Fiscal Year 2018 Outlook

[0001564590-17-011611:8k_2_02:25]
The Company provided the following financial guidance for the full fiscal year 2018:

[0001564590-17-011611:8k_2_02:26]
GAAPNon-GAAP

[0001564590-17-011611:8k_2_02:27]
| • | Consolidated gross margin is expected to be in the range of:61% - 62% 62% - 63% |

[0001564590-17-011611:8k_2_02:28]
| • | Operating margin is expected to be in the range of:14% - 16% 18% - 20% |

[0001564590-17-011611:8k_2_02:29]
| • | Effective tax rate is expected to be in the range of:23% - 24% 19% - 20% |

[0001564590-17-011611:8k_2_02:30]
Business Highlights

[0001564590-17-011611:8k_2_02:31]
| • | NetApp Expands Impact in Flash, Cloud, and Next-Generation Data Center |

[0001564590-17-011611:8k_2_02:32]
|  | - | New NetApp All-Flash Innovations Improve Data Center Economics. New All Flash FAS A700s array delivers breakthrough performance in a compact form factor to modernize IT for demanding enterprise applications, analytic workloads and cloud integration. |

[0001564590-17-011611:8k_2_02:33]
|  | - | NetApp Names Anthony Lye to Lead Cloud Business Unit. Cloud champion joins NetApp to accelerate hyperscaler and hybrid cloud progress. Lye, who reports to NetApp CEO George Kurian, drives the strategy and execution necessary to create a profitable cloud business for NetApp and establish the Company as the undisputed leader in managing data in a cloud-integrated world. |

[0001564590-17-011611:8k_2_02:34]
|  | - | One-Year Anniversary: NetApp SolidFire Redefines Data Center Infrastructure. NetApp celebrated the one-year anniversary of its acquisition of SolidFire, fueling the advance of the next-generation data center that is transforming IT for enterprises and service providers. |

[0001564590-17-011611:8k_2_02:35]
| • | Customers Team with NetApp to Drive Transformation and Improve Performance with Their Choice of Hybrid Cloud Deployment |

[0001564590-17-011611:8k_2_02:36]
|  | - | NetApp Supports Vital Energi in Transforming Data into Energy Savings Throughout the UK. Sustainable energy company, Vital Energi, deployed a NetApp all-flash array to speed performance and NetApp AltaVault cloud-integrated storage to help the company meet mandatory back up requirements. |

[0001564590-17-011611:8k_2_02:37]
|  | - | DARZ Drives DevOps Success with NetApp. German IT services leader fuels customers’ digital transformation by enabling agile software development through its Docker & Container as a Service offering. |

[0001564590-17-011611:8k_2_02:38]
|  | - | neteffect Offers Hybrid Cloud Disaster Recovery Solutions with NetApp. NetApp converged infrastructure gives neteffect technologies the flexibility to blend on-premises and cloud services for customers. |

[0001564590-17-011611:8k_2_02:39]
|  | - | NetApp Helps Kaufman Hall Transform Businesses with Data-Driven Insight. Kaufman Hall takes critical first step toward a hybrid cloud future by consolidating on FlexPod to speed innovation as well as maximize performance and growth. |

[0001564590-17-011611:8k_2_02:40]
|  | - | Contegix Accelerates Private Cloud Deployment and Cuts Service Costs in Half with NetApp SolidFire. The leading cloud host provider prepares for coming data deluge with high- |

[0001564590-17-011611:8k_2_02:41]
|  |  | performing, scalable NetApp SolidFire all-flash storage to meet customers’ demands for scalability and guaranteed performance to accelerate their private cloud deployments. |

[0001564590-17-011611:8k_2_02:42]
Webcast and Conference Call Information

[0001564590-17-011611:8k_2_02:43]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:30 p.m. Pacific Time today.

[0001564590-17-011611:8k_2_02:44]
About NetApp

[0001564590-17-011611:8k_2_02:45]
Leading organizations worldwide count on NetApp for software, systems and services to manage and store data. We help customers capitalize on the value of their data in the hybrid cloud through our Data Fabric strategy, data management expertise, portfolio and ecosystem. To learn more, visit www.netapp.com.

[0001564590-17-011611:8k_2_02:46]
Securities and Exchange Commission, including the factors described under the section titled “Risk Factors” in our most recently submitted Annual Report on Form 10-K. We disclaim any obligation to update information contained in this press release whether as a result of new information, future events, or otherwise.

[0001564590-17-011611:8k_2_02:47]
###

[0001564590-17-011611:8k_2_02:48]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-17-011611:8k_2_02:49]
1GAAP net income per share is calculated using the diluted number of shares.

[0001564590-17-011611:8k_2_02:50]
2GAAP net loss per share is calculated using the basic number of shares and excludes common stock equivalents because the impact would be anti-dilutive.

[0001564590-17-011611:8k_2_02:51]
3Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) acquisition-related expenses, (d) restructuring charges, (e) asset impairments, (f) gains/losses on the sale of properties, and (g) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-17-011611:8k_2_02:52]
NetApp Usage of Non-GAAP Financial Information

[0001564590-17-011611:8k_2_02:53]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-17-011611:8k_2_02:54]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data when shown in conjunction with the corresponding

[0001564590-17-011611:8k_2_02:55]
GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-17-011611:8k_2_02:56]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, in fiscal years 2016 and 2017 these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001564590-17-011611:8k_2_02:57]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-17-011611:8k_2_02:58]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-17-011611:8k_2_02:59]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-17-011611:8k_2_02:60]
C. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily

[0001564590-17-011611:8k_2_02:61]
because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-17-011611:8k_2_02:62]
D. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-17-011611:8k_2_02:63]
E. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-17-011611:8k_2_02:64]
F. Gains/losses on the sale of properties. These are gains/losses from the sale of our properties. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-17-011611:8k_2_02:65]
G. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual properties from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-17-011611:8k_2_02:66]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the

[0001564590-17-011611:8k_2_02:67]
Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-17-011611:8k_2_02:68]
NETAPP, INC.

[0001564590-17-011611:8k_2_02:69]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-17-011611:8k_2_02:70]
(In millions)

[0001564590-17-011611:8k_2_02:71]
(Unaudited)

[0001564590-17-011611:8k_2_02:72]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,921 |  |  | $ | 5,303 |  |
| Accounts receivable |  |  | 731 |  |  |  | 813 |  |
| Inventories |  |  | 163 |  |  |  | 98 |  |
| Other current assets |  |  | 383 |  |  |  | 234 |  |
| Total current assets |  |  | 6,198 |  |  |  | 6,448 |  |
| Property and equipment, net |  |  | 799 |  |  |  | 937 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,815 |  |  |  | 1,856 |  |
| Other non-current assets |  |  | 681 |  |  |  | 796 |  |
| Total assets |  | $ | 9,493 |  |  | $ | 10,037 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 347 |  |  | $ | 254 |  |
| Accrued expenses |  |  | 782 |  |  |  | 765 |  |
| Commercial paper notes |  |  | 500 |  |  |  | — |  |
| Short-term loan |  |  | — |  |  |  | 849 |  |
| Current portion of long-term debt |  |  | 749 |  |  |  | — |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,661 |  |  |  | 1,794 |  |
| Total current liabilities |  |  | 4,039 |  |  |  | 3,662 |  |
| Long-term debt |  |  | 744 |  |  |  | 1,490 |  |
| Other long-term liabilities |  |  | 249 |  |  |  | 413 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,681 |  |  |  | 1,591 |  |
| Total liabilities |  |  | 6,713 |  |  |  | 7,156 |  |
| Stockholders' equity |  |  | 2,780 |  |  |  | 2,881 |  |
| Total liabilities and stockholders' equity |  | $ | 9,493 |  |  | $ | 10,037 |  |

[0001564590-17-011611:8k_2_02:73]
NETAPP, INC.

[0001564590-17-011611:8k_2_02:74]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-17-011611:8k_2_02:75]
(In millions, except per share amounts)

[0001564590-17-011611:8k_2_02:76]
(Unaudited)

[0001564590-17-011611:8k_2_02:77]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 852 |  |  | $ | 757 |  |  | $ | 3,006 |  |  | $ | 2,986 |  |
| Software maintenance |  |  | 242 |  |  |  | 234 |  |  |  | 965 |  |  |  | 949 |  |
| Hardware maintenance and other services |  |  | 387 |  |  |  | 389 |  |  |  | 1,548 |  |  |  | 1,611 |  |
| Net revenues |  |  | 1,481 |  |  |  | 1,380 |  |  |  | 5,519 |  |  |  | 5,546 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 444 |  |  |  | 424 |  |  |  | 1,614 |  |  |  | 1,558 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | 9 |  |  |  | 28 |  |  |  | 37 |  |
| Cost of hardware maintenance and other services |  |  | 118 |  |  |  | 129 |  |  |  | 487 |  |  |  | 578 |  |
| Total cost of revenues |  |  | 568 |  |  |  | 562 |  |  |  | 2,129 |  |  |  | 2,173 |  |
| Gross profit |  |  | 913 |  |  |  | 818 |  |  |  | 3,390 |  |  |  | 3,373 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 405 |  |  |  | 434 |  |  |  | 1,633 |  |  |  | 1,792 |  |
| Research and development |  |  | 191 |  |  |  | 201 |  |  |  | 779 |  |  |  | 861 |  |
| General and administrative |  |  | 70 |  |  |  | 84 |  |  |  | 271 |  |  |  | 307 |  |
| Restructuring charges |  |  | — |  |  |  | 80 |  |  |  | 52 |  |  |  | 108 |  |
| Acquisition-related expense |  |  | — |  |  |  | 6 |  |  |  | — |  |  |  | 8 |  |
| Gain on sale of properties |  |  | — |  |  |  | (51 | ) |  |  | (10 | ) |  |  | (51 | ) |
| Total operating expenses |  |  | 666 |  |  |  | 754 |  |  |  | 2,725 |  |  |  | 3,025 |  |
| Income from operations |  |  | 247 |  |  |  | 64 |  |  |  | 665 |  |  |  | 348 |  |
| Other income (expense), net |  |  | 1 |  |  |  | (4 | ) |  |  | — |  |  |  | (3 | ) |
| Income before income taxes |  |  | 248 |  |  |  | 60 |  |  |  | 665 |  |  |  | 345 |  |
| Provision for income taxes |  |  | 58 |  |  |  | 68 |  |  |  | 156 |  |  |  | 116 |  |
| Net income (loss) |  | $ | 190 |  |  | $ | (8 | ) |  | $ | 509 |  |  | $ | 229 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.70 |  |  | $ | (0.03 | ) |  | $ | 1.85 |  |  | $ | 0.78 |  |
| Diluted |  | $ | 0.68 |  |  | $ | (0.03 | ) |  | $ | 1.81 |  |  | $ | 0.77 |  |
| Shares used in net income (loss) per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 270 |  |  |  | 284 |  |  |  | 275 |  |  |  | 294 |  |
| Diluted |  |  | 278 |  |  |  | 284 |  |  |  | 281 |  |  |  | 297 |  |
| Cash dividends declared per share |  | $ | 0.190 |  |  | $ | 0.180 |  |  | $ | 0.760 |  |  | $ | 0.720 |  |

[0001564590-17-011611:8k_2_02:78]
NETAPP, INC.

[0001564590-17-011611:8k_2_02:79]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-17-011611:8k_2_02:80]
(In millions)

[0001564590-17-011611:8k_2_02:81]
(Unaudited)

[0001564590-17-011611:8k_2_02:82]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 190 |  |  | $ | (8 | ) |  | $ | 509 |  |  | $ | 229 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 53 |  |  |  | 77 |  |  |  | 226 |  |  |  | 279 |  |
| Stock-based compensation |  |  | 46 |  |  |  | 61 |  |  |  | 195 |  |  |  | 260 |  |
| Gain on sale of properties |  |  | — |  |  |  | (51 | ) |  |  | (10 | ) |  |  | (51 | ) |
| Other items, net |  |  | 19 |  |  |  | 31 |  |  |  | 84 |  |  |  | (43 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (127 | ) |  |  | (206 | ) |  |  | 81 |  |  |  | (16 | ) |
| Inventories |  |  | (38 | ) |  |  | 5 |  |  |  | (65 | ) |  |  | 49 |  |
| Accounts payable |  |  | 81 |  |  |  | 60 |  |  |  | 94 |  |  |  | (53 | ) |
| Accrued expenses |  |  | 35 |  |  |  | 108 |  |  |  | (86 | ) |  |  | 30 |  |
| Deferred revenue and financed unearned services revenue |  |  | 111 |  |  |  | 238 |  |  |  | (37 | ) |  |  | 186 |  |
| Changes in other operating assets and liabilities, net |  |  | (5 | ) |  |  | 30 |  |  |  | (5 | ) |  |  | 104 |  |
| Net cash provided by operating activities |  |  | 365 |  |  |  | 345 |  |  |  | 986 |  |  |  | 974 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | (45 | ) |  |  | 103 |  |  |  | (43 | ) |  |  | 982 |  |
| Purchases of property and equipment |  |  | (38 | ) |  |  | (35 | ) |  |  | (175 | ) |  |  | (160 | ) |
| Proceeds from sale of properties |  |  | — |  |  |  | 102 |  |  |  | — |  |  |  | 102 |  |
| Acquisitions of businesses, net of cash acquired |  |  | (8 | ) |  |  | (842 | ) |  |  | (8 | ) |  |  | (842 | ) |
| Other investing activities, net |  |  | 4 |  |  |  | 4 |  |  |  | 6 |  |  |  | 3 |  |
| Net cash provided by (used in) investing activities |  |  | (87 | ) |  |  | (668 | ) |  |  | (220 | ) |  |  | 85 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock under employee stock award plans |  |  | 22 |  |  |  | — |  |  |  | 92 |  |  |  | 70 |  |
| Repurchase of common stock |  |  | (129 | ) |  |  | (262 | ) |  |  | (705 | ) |  |  | (960 | ) |
| Changes in commercial paper notes, net |  |  | 107 |  |  |  | — |  |  |  | 499 |  |  |  | — |  |
| Proceeds from sale-leaseback financing transactions |  |  | — |  |  |  | 148 |  |  |  | — |  |  |  | 148 |  |
| Proceeds from short-term loan |  |  | — |  |  |  | 870 |  |  |  | — |  |  |  | 870 |  |
| Repayment of short-term loan |  |  | — |  |  |  | (20 | ) |  |  | (850 | ) |  |  | (20 | ) |
| Dividends paid |  |  | (51 | ) |  |  | (51 | ) |  |  | (208 | ) |  |  | (210 | ) |
| Other financing activities, net |  |  | — |  |  |  | (4 | ) |  |  | (7 | ) |  |  | (7 | ) |
| Net cash provided by (used in) financing activities |  |  | (51 | ) |  |  | 681 |  |  |  | (1,179 | ) |  |  | (109 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 4 |  |  |  | 15 |  |  |  | (11 | ) |  |  | (4 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 231 |  |  |  | 373 |  |  |  | (424 | ) |  |  | 946 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,213 |  |  |  | 2,495 |  |  |  | 2,868 |  |  |  | 1,922 |  |
| End of period |  | $ | 2,444 |  |  | $ | 2,868 |  |  | $ | 2,444 |  |  | $ | 2,868 |  |

[0001564590-17-011611:8k_2_02:83]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q4 FY'17 |  |  | Q3 FY'17 |  |  | Q4 FY'16 |  |  | FY 2017 |  |  | FY 2016 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (1) |  | $ | 852 |  |  | $ | 784 |  |  | $ | 757 |  |  | $ | 3,006 |  |  | $ | 2,986 |  |
| Strategic |  | $ | 596 |  |  | $ | 512 |  |  | $ | 481 |  |  | $ | 1,971 |  |  | $ | 1,682 |  |
| Mature |  | $ | 256 |  |  | $ | 272 |  |  | $ | 276 |  |  | $ | 1,035 |  |  | $ | 1,304 |  |
| Software Maintenance |  | $ | 242 |  |  | $ | 240 |  |  | $ | 234 |  |  | $ | 965 |  |  | $ | 949 |  |
| Hardware Maintenance and Other Services: |  | $ | 387 |  |  | $ | 380 |  |  | $ | 389 |  |  | $ | 1,548 |  |  | $ | 1,611 |  |
| Hardware Maintenance Support Contracts |  | $ | 313 |  |  | $ | 313 |  |  | $ | 318 |  |  | $ | 1,265 |  |  | $ | 1,316 |  |
| Professional and Other Services |  | $ | 74 |  |  | $ | 67 |  |  | $ | 71 |  |  | $ | 283 |  |  | $ | 295 |  |
| Net Revenues |  | $ | 1,481 |  |  | $ | 1,404 |  |  | $ | 1,380 |  |  | $ | 5,519 |  |  | $ | 5,546 |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'17 Revenue |  |  | % of Q3 FY'17 Revenue |  |  | % of Q4 FY'16 Revenue |  |  | % of FY 2017 Revenue |  |  | % of FY 2016 Revenue |  |
| Americas |  |  | 54 | % |  |  | 55 | % |  |  | 54 | % |  |  | 56 | % |  |  | 55 | % |
| Americas Commercial |  |  | 42 | % |  |  | 44 | % |  |  | 43 | % |  |  | 43 | % |  |  | 43 | % |
| U.S. Public Sector |  |  | 12 | % |  |  | 10 | % |  |  | 12 | % |  |  | 13 | % |  |  | 12 | % |
| EMEA |  |  | 32 | % |  |  | 33 | % |  |  | 33 | % |  |  | 31 | % |  |  | 32 | % |
| Asia Pacific |  |  | 14 | % |  |  | 13 | % |  |  | 13 | % |  |  | 13 | % |  |  | 13 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'17 Revenue |  |  | % of Q3 FY'17 Revenue |  |  | % of Q4 FY'16 Revenue |  |  | % of FY 2017 Revenue |  |  | % of FY 2016 Revenue |  |
| Direct |  |  | 22 | % |  |  | 21 | % |  |  | 26 | % |  |  | 22 | % |  |  | 23 | % |
| Indirect |  |  | 78 | % |  |  | 79 | % |  |  | 74 | % |  |  | 78 | % |  |  | 77 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'17 |  |  | Q3 FY'17 |  |  | Q4 FY'16 |  |  | FY 2017 |  |  | FY 2016 |  |
| Non-GAAP Gross Margin |  |  | 62.5 | % |  |  | 61.5 | % |  |  | 61.1 | % |  |  | 62.3 | % |  |  | 62.5 | % |
| Product |  |  | 48.9 | % |  |  | 45.7 | % |  |  | 46.8 | % |  |  | 47.4 | % |  |  | 50.2 | % |
| Software Maintenance |  |  | 97.5 | % |  |  | 97.1 | % |  |  | 96.2 | % |  |  | 97.1 | % |  |  | 96.1 | % |
| Hardware Maintenance and Other Services |  |  | 70.3 | % |  |  | 71.6 | % |  |  | 67.9 | % |  |  | 69.4 | % |  |  | 65.7 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'17 |  |  | Q3 FY'17 |  |  | Q4 FY'16 |  |  | FY 2017 |  |  | FY 2016 |  |
| Non-GAAP Income from Operations |  | $ | 306 |  |  | $ | 284 |  |  | $ | 185 |  |  | $ | 950 |  |  | $ | 751 |  |
| % of Net Revenues |  |  | 20.7 | % |  |  | 20.2 | % |  |  | 13.4 | % |  |  | 17.2 | % |  |  | 13.5 | % |
| Non-GAAP Income before Income Taxes |  | $ | 307 |  |  | $ | 284 |  |  | $ | 181 |  |  | $ | 950 |  |  | $ | 748 |  |
| Non-GAAP Effective Tax Rate |  |  | 22.1 | % |  |  | 18.6 | % |  |  | 13.1 | % |  |  | 19.2 | % |  |  | 15.4 | % |

[0001564590-17-011611:8k_2_02:84]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'17 |  |  | Q3 FY'17 |  |  | Q4 FY'16 |  |  | FY 2017 |  |  | FY 2016 |  |
| Non-GAAP Net Income |  | $ | 239 |  |  | $ | 231 |  |  | $ | 157 |  |  | $ | 768 |  |  | $ | 633 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 278 |  |  |  | 281 |  |  |  | 287 |  |  |  | 281 |  |  |  | 297 |  |
| Non-GAAP Income per Share, Diluted |  | $ | 0.86 |  |  | $ | 0.82 |  |  | $ | 0.55 |  |  | $ | 2.73 |  |  | $ | 2.13 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'17 |  |  | Q3 FY'17 |  |  | Q4 FY'16 |  |  |  |  |  |  |  |  |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,342 |  |  | $ | 3,234 |  |  | $ | 3,385 |  |  |  |  |  |  |  |  |  |
| DSO (days) |  |  | 45 |  |  |  | 39 |  |  |  | 54 |  |  |  |  |  |  |  |  |  |
| DIO (days) |  |  | 26 |  |  |  | 21 |  |  |  | 16 |  |  |  |  |  |  |  |  |  |
| DPO (days) |  |  | 56 |  |  |  | 42 |  |  |  | 41 |  |  |  |  |  |  |  |  |  |
| CCC (days) |  |  | 15 |  |  |  | 17 |  |  |  | 28 |  |  |  |  |  |  |  |  |  |
| Inventory Turns |  |  | 14 |  |  |  | 18 |  |  |  | 23 |  |  |  |  |  |  |  |  |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |  |  |  |  |  |  |  |  |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |  |  |  |  |  |  |  |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'17 |  |  | Q3 FY'17 |  |  | Q4 FY'16 |  |  | FY 2017 |  |  | FY 2016 |  |
| Net Cash Provided by Operating Activities |  | $ | 365 |  |  | $ | 235 |  |  | $ | 345 |  |  | $ | 986 |  |  | $ | 974 |  |
| Purchases of Property and Equipment |  | $ | 38 |  |  | $ | 45 |  |  | $ | 35 |  |  | $ | 175 |  |  | $ | 160 |  |
| Free Cash Flow |  | $ | 327 |  |  | $ | 190 |  |  | $ | 310 |  |  | $ | 811 |  |  | $ | 814 |  |
| Free Cash Flow as a % of Net Revenues |  |  | 22.1 | % |  |  | 13.5 | % |  |  | 22.5 | % |  |  | 14.7 | % |  |  | 14.7 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |
| (1) Sales of certain products which should have been reported as strategic products were improperly reported as mature product revenues. All FY 2016 periods presented have been recast to reflect the appropriate classification. |  |

[0001564590-17-011611:8k_2_02:85]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income (loss) per share amounts) |  |
|  |  | Q4'FY17 |  |  | Q3'FY17 |  |  | Q4'FY16 |  |  | FY2017 |  |  | FY2016 |  |
| NET INCOME (LOSS) |  | $ | 190 |  |  | $ | 146 |  |  | $ | (8 | ) |  | $ | 509 |  |  | $ | 229 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 13 |  |  |  | 25 |  |  |  | 48 |  |  |  | 67 |  |
| Stock-based compensation |  |  | 46 |  |  |  | 46 |  |  |  | 61 |  |  |  | 195 |  |  |  | 260 |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 11 |  |
| Restructuring charges |  |  | — |  |  |  | 52 |  |  |  | 80 |  |  |  | 52 |  |  |  | 108 |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | 6 |  |  |  | — |  |  |  | 8 |  |
| Gain on sale of properties |  |  | — |  |  |  | (10 | ) |  |  | (51 | ) |  |  | (10 | ) |  |  | (51 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (10 | ) |  |  | (16 | ) |  |  | (20 | ) |  |  | (26 | ) |  |  | (86 | ) |
| Income tax expenses from integration of intellectual properties from acquisition |  |  | — |  |  |  | — |  |  |  | 64 |  |  |  | — |  |  |  | 64 |  |
| Settlement of income tax audit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 23 |  |
| NON-GAAP NET INCOME |  | $ | 239 |  |  | $ | 231 |  |  | $ | 157 |  |  | $ | 768 |  |  | $ | 633 |  |
| COST OF REVENUES |  | $ | 568 |  |  | $ | 553 |  |  | $ | 562 |  |  | $ | 2,129 |  |  | $ | 2,173 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (8 | ) |  |  | (20 | ) |  |  | (29 | ) |  |  | (61 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (5 | ) |  |  | (17 | ) |  |  | (24 | ) |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (11 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 556 |  |  | $ | 541 |  |  | $ | 537 |  |  | $ | 2,083 |  |  | $ | 2,077 |  |
| COST OF PRODUCT REVENUES |  | $ | 444 |  |  | $ | 435 |  |  | $ | 424 |  |  | $ | 1,614 |  |  | $ | 1,558 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (8 | ) |  |  | (20 | ) |  |  | (29 | ) |  |  | (61 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |  |  | (4 | ) |  |  | (5 | ) |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (5 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 435 |  |  | $ | 426 |  |  | $ | 403 |  |  | $ | 1,581 |  |  | $ | 1,487 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 118 |  |  | $ | 111 |  |  | $ | 129 |  |  | $ | 487 |  |  | $ | 578 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (4 | ) |  |  | (13 | ) |  |  | (19 | ) |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (6 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 115 |  |  | $ | 108 |  |  | $ | 125 |  |  | $ | 474 |  |  | $ | 553 |  |
| GROSS PROFIT |  | $ | 913 |  |  | $ | 851 |  |  | $ | 818 |  |  | $ | 3,390 |  |  | $ | 3,373 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 8 |  |  |  | 8 |  |  |  | 20 |  |  |  | 29 |  |  |  | 61 |  |
| Stock-based compensation |  |  | 4 |  |  |  | 4 |  |  |  | 5 |  |  |  | 17 |  |  |  | 24 |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 11 |  |
| NON-GAAP GROSS PROFIT |  | $ | 925 |  |  | $ | 863 |  |  | $ | 843 |  |  | $ | 3,436 |  |  | $ | 3,469 |  |

[0001564590-17-011611:8k_2_02:86]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income (loss) per share amounts) |  |
|  |  | Q4'FY17 |  |  | Q3'FY17 |  |  | Q4'FY16 |  |  | FY2017 |  |  | FY2016 |  |
| SALES AND MARKETING EXPENSES |  | $ | 405 |  |  | $ | 381 |  |  | $ | 434 |  |  | $ | 1,633 |  |  | $ | 1,792 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | (5 | ) |  |  | (19 | ) |  |  | (6 | ) |
| Stock-based compensation |  |  | (20 | ) |  |  | (20 | ) |  |  | (26 | ) |  |  | (84 | ) |  |  | (110 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 380 |  |  | $ | 356 |  |  | $ | 403 |  |  | $ | 1,530 |  |  | $ | 1,676 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 191 |  |  | $ | 181 |  |  | $ | 201 |  |  | $ | 779 |  |  | $ | 861 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (13 | ) |  |  | (14 | ) |  |  | (20 | ) |  |  | (59 | ) |  |  | (84 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 178 |  |  | $ | 167 |  |  | $ | 181 |  |  | $ | 720 |  |  | $ | 777 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 70 |  |  | $ | 64 |  |  | $ | 84 |  |  | $ | 271 |  |  | $ | 307 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (9 | ) |  |  | (8 | ) |  |  | (10 | ) |  |  | (35 | ) |  |  | (42 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 61 |  |  | $ | 56 |  |  | $ | 74 |  |  | $ | 236 |  |  | $ | 265 |  |
| RESTRUCTURING CHARGES |  | $ | — |  |  | $ | 52 |  |  | $ | 80 |  |  | $ | 52 |  |  | $ | 108 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | — |  |  |  | (52 | ) |  |  | (80 | ) |  |  | (52 | ) |  |  | (108 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | 6 |  |  | $ | — |  |  | $ | 8 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | (6 | ) |  |  | — |  |  |  | (8 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| GAIN ON SALE OF PROPERTIES |  | $ | — |  |  | $ | (10 | ) |  | $ | (51 | ) |  | $ | (10 | ) |  | $ | (51 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale of properties |  |  | — |  |  |  | 10 |  |  |  | 51 |  |  |  | 10 |  |  |  | 51 |  |
| NON-GAAP GAIN ON SALE OF PROPERTIES |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 666 |  |  | $ | 668 |  |  | $ | 754 |  |  | $ | 2,725 |  |  | $ | 3,025 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | (5 | ) |  |  | (19 | ) |  |  | (6 | ) |
| Stock-based compensation |  |  | (42 | ) |  |  | (42 | ) |  |  | (56 | ) |  |  | (178 | ) |  |  | (236 | ) |
| Restructuring charges |  |  | — |  |  |  | (52 | ) |  |  | (80 | ) |  |  | (52 | ) |  |  | (108 | ) |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | (6 | ) |  |  | — |  |  |  | (8 | ) |
| Gain on sale of properties |  |  | — |  |  |  | 10 |  |  |  | 51 |  |  |  | 10 |  |  |  | 51 |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 619 |  |  | $ | 579 |  |  | $ | 658 |  |  | $ | 2,486 |  |  | $ | 2,718 |  |

[0001564590-17-011611:8k_2_02:87]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income (loss) per share amounts) |  |
|  |  | Q4'FY17 |  |  | Q3'FY17 |  |  | Q4'FY16 |  |  | FY2017 |  |  | FY2016 |  |
| INCOME FROM OPERATIONS |  | $ | 247 |  |  | $ | 183 |  |  | $ | 64 |  |  | $ | 665 |  |  | $ | 348 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 13 |  |  |  | 25 |  |  |  | 48 |  |  |  | 67 |  |
| Stock-based compensation |  |  | 46 |  |  |  | 46 |  |  |  | 61 |  |  |  | 195 |  |  |  | 260 |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 11 |  |
| Restructuring charges |  |  | — |  |  |  | 52 |  |  |  | 80 |  |  |  | 52 |  |  |  | 108 |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | 6 |  |  |  | — |  |  |  | 8 |  |
| Gain on sale of properties |  |  | — |  |  |  | (10 | ) |  |  | (51 | ) |  |  | (10 | ) |  |  | (51 | ) |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 306 |  |  | $ | 284 |  |  | $ | 185 |  |  | $ | 950 |  |  | $ | 751 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 248 |  |  | $ | 183 |  |  | $ | 60 |  |  | $ | 665 |  |  | $ | 345 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 13 |  |  |  | 25 |  |  |  | 48 |  |  |  | 67 |  |
| Stock-based compensation |  |  | 46 |  |  |  | 46 |  |  |  | 61 |  |  |  | 195 |  |  |  | 260 |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 11 |  |
| Restructuring charges |  |  | — |  |  |  | 52 |  |  |  | 80 |  |  |  | 52 |  |  |  | 108 |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | 6 |  |  |  | — |  |  |  | 8 |  |
| Gain on sale of properties |  |  | — |  |  |  | (10 | ) |  |  | (51 | ) |  |  | (10 | ) |  |  | (51 | ) |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 307 |  |  | $ | 284 |  |  | $ | 181 |  |  | $ | 950 |  |  | $ | 748 |  |
| PROVISION FOR INCOME TAXES |  | $ | 58 |  |  | $ | 37 |  |  | $ | 68 |  |  | $ | 156 |  |  | $ | 116 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | 10 |  |  |  | 16 |  |  |  | 20 |  |  |  | 26 |  |  |  | 86 |  |
| Income tax expenses from integration of intellectual properties from acquisition |  |  | — |  |  |  | — |  |  |  | (64 | ) |  |  | — |  |  |  | (64 | ) |
| Settlement of income tax audit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (23 | ) |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 68 |  |  | $ | 53 |  |  | $ | 24 |  |  | $ | 182 |  |  | $ | 115 |  |
| NET INCOME (LOSS) PER SHARE |  | $ | 0.68 |  |  | $ | 0.52 |  |  | $ | (0.03 | ) |  | $ | 1.81 |  |  | $ | 0.77 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.09 |  |  |  | 0.17 |  |  |  | 0.23 |  |
| Stock-based compensation |  |  | 0.17 |  |  |  | 0.16 |  |  |  | 0.21 |  |  |  | 0.69 |  |  |  | 0.88 |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.04 |  |
| Restructuring charges |  |  | — |  |  |  | 0.19 |  |  |  | 0.28 |  |  |  | 0.19 |  |  |  | 0.36 |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | 0.02 |  |  |  | — |  |  |  | 0.03 |  |
| Gain on sale of properties |  |  | — |  |  |  | (0.04 | ) |  |  | (0.18 | ) |  |  | (0.04 | ) |  |  | (0.17 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.04 | ) |  |  | (0.06 | ) |  |  | (0.07 | ) |  |  | (0.09 | ) |  |  | (0.29 | ) |
| Income tax expenses from integration of intellectual properties from acquisition |  |  | — |  |  |  | — |  |  |  | 0.23 |  |  |  | — |  |  |  | 0.22 |  |
| Settlement of income tax audit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.08 |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.86 |  |  | $ | 0.82 |  |  | $ | 0.55 |  |  | $ | 2.73 |  |  | $ | 2.13 |  |

[0001564590-17-011611:8k_2_02:88]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY17 |  |  | Q3'FY17 |  |  | Q4'FY16 |  |  | FY2017 |  |  | FY2016 |  |
| Gross margin-GAAP |  |  | 61.6 | % |  |  | 60.6 | % |  |  | 59.3 | % |  |  | 61.4 | % |  |  | 60.8 | % |
| Cost of revenues adjustments |  |  | 0.8 | % |  |  | 0.9 | % |  |  | 1.8 | % |  |  | 0.8 | % |  |  | 1.7 | % |
| Gross margin-Non-GAAP |  |  | 62.5 | % |  |  | 61.5 | % |  |  | 61.1 | % |  |  | 62.3 | % |  |  | 62.5 | % |
| GAAP cost of revenues |  | $ | 568 |  |  | $ | 553 |  |  | $ | 562 |  |  | $ | 2,129 |  |  | $ | 2,173 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (8 | ) |  |  | (20 | ) |  |  | (29 | ) |  |  | (61 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (4 | ) |  |  | (5 | ) |  |  | (17 | ) |  |  | (24 | ) |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (11 | ) |
| Non-GAAP cost of revenues |  | $ | 556 |  |  | $ | 541 |  |  | $ | 537 |  |  | $ | 2,083 |  |  | $ | 2,077 |  |
| Net revenues |  | $ | 1,481 |  |  | $ | 1,404 |  |  | $ | 1,380 |  |  | $ | 5,519 |  |  | $ | 5,546 |  |

[0001564590-17-011611:8k_2_02:89]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY17 |  |  | Q3'FY17 |  |  | Q4'FY16 |  |  | FY2017 |  |  | FY2016 |  |
| Product gross margin-GAAP |  |  | 47.9 | % |  |  | 44.5 | % |  |  | 44.0 | % |  |  | 46.3 | % |  |  | 47.8 | % |
| Cost of product revenues adjustments |  |  | 1.1 | % |  |  | 1.1 | % |  |  | 2.8 | % |  |  | 1.1 | % |  |  | 2.4 | % |
| Product gross margin-Non-GAAP |  |  | 48.9 | % |  |  | 45.7 | % |  |  | 46.8 | % |  |  | 47.4 | % |  |  | 50.2 | % |
| GAAP cost of product revenues |  | $ | 444 |  |  | $ | 435 |  |  | $ | 424 |  |  | $ | 1,614 |  |  | $ | 1,558 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (8 | ) |  |  | (20 | ) |  |  | (29 | ) |  |  | (61 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |  |  | (4 | ) |  |  | (5 | ) |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (5 | ) |
| Non-GAAP cost of product revenues |  | $ | 435 |  |  | $ | 426 |  |  | $ | 403 |  |  | $ | 1,581 |  |  | $ | 1,487 |  |
| Product revenues |  | $ | 852 |  |  | $ | 784 |  |  | $ | 757 |  |  | $ | 3,006 |  |  | $ | 2,986 |  |

[0001564590-17-011611:8k_2_02:90]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY17 |  |  | Q3'FY17 |  |  | Q4'FY16 |  |  | FY2017 |  |  | FY2016 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 69.5 | % |  |  | 70.8 | % |  |  | 66.8 | % |  |  | 68.5 | % |  |  | 64.1 | % |
| Cost of hardware maintenance and other services revenues adjustments |  |  | 0.8 | % |  |  | 0.8 | % |  |  | 1.0 | % |  |  | 0.8 | % |  |  | 1.6 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 70.3 | % |  |  | 71.6 | % |  |  | 67.9 | % |  |  | 69.4 | % |  |  | 65.7 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 118 |  |  | $ | 111 |  |  | $ | 129 |  |  | $ | 487 |  |  | $ | 578 |  |
| Cost of hardware maintenance and other services revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (4 | ) |  |  | (13 | ) |  |  | (19 | ) |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (6 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 115 |  |  | $ | 108 |  |  | $ | 125 |  |  | $ | 474 |  |  | $ | 553 |  |
| Hardware maintenance and other services revenues |  | $ | 387 |  |  | $ | 380 |  |  | $ | 389 |  |  | $ | 1,548 |  |  | $ | 1,611 |  |

[0001564590-17-011611:8k_2_02:91]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q4'FY17 |  |  | Q3'FY17 |  |  | Q4'FY16 |  |  | FY2017 |  |  | FY2016 |  |
| GAAP effective tax rate |  |  | 23.4 | % |  |  | 20.2 | % |  |  | 113.3 | % |  |  | 23.5 | % |  |  | 33.6 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | (1.3 | )% |  |  | (1.6 | )% |  |  | (64.9 | )% |  |  | (4.3 | )% |  |  | (6.6 | )% |
| Income tax expenses from integration of intellectual properties from acquisition |  |  | — | % |  |  | — | % |  |  | (35.4 | )% |  |  | — | % |  |  | (8.6 | )% |
| Settlement of income tax audit |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | (3.1 | )% |
| Non-GAAP effective tax rate |  |  | 22.1 | % |  |  | 18.6 | % |  |  | 13.1 | % |  |  | 19.2 | % |  |  | 15.4 | % |

[0001564590-17-011611:8k_2_02:92]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q4'FY17 |  |  | Q3'FY17 |  |  | Q4'FY16 |  |  | FY2017 |  |  | FY2016 |  |
| Net cash provided by operating activities |  | $ | 365 |  |  | $ | 235 |  |  | $ | 345 |  |  | $ | 986 |  |  | $ | 974 |  |
| Purchases of property and equipment |  |  | (38 | ) |  |  | (45 | ) |  |  | (35 | ) |  |  | (175 | ) |  |  | (160 | ) |
| Free cash flow |  | $ | 327 |  |  | $ | 190 |  |  | $ | 310 |  |  | $ | 811 |  |  | $ | 814 |  |

[0001564590-17-011611:8k_2_02:93]
Some items may not add or recalculate due to rounding.

[0001564590-17-011611:8k_2_02:94]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| FIRST QUARTER FISCAL 2018 |  |
|  |  | First Quarter |  |
|  |  | Fiscal 2018 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $0.49 - $0.57 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the First Quarter Fiscal 2018: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.05 | ) |
| Stock-based compensation expense |  |  | (0.17 | ) |
| Income tax effect of non-GAAP adjustments |  |  | 0.03 |  |
| Total Adjustments |  |  | (0.19 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.30 - $0.38 |  |

[0001564590-17-011611:8k_2_02:95]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| FISCAL 2018 |
| (Unaudited) |
|  |  | GROSS MARGIN |
| Gross Margin - Non-GAAP Guidance |  | 62% - 63% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | (1)% |
| Gross Margin - GAAP Guidance |  | 61% - 62% |
|  |  | OPERATING MARGIN |
| Operating Margin - Non-GAAP Guidance |  | 18% - 20% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | (1)% |
| Stock-based compensation expense |  | (3)% |
| Operating Margin - GAAP Guidance |  | 14% - 16% |
|  |  | EFFECTIVE TAX RATE |
| Effective Tax Rate - Non-GAAP Guidance |  | 19% - 20% |
| Adjustment: |  |  |
| Tax effect of non-GAAP adjustments |  | 4% |
| Effective Tax Rate - GAAP Guidance |  | 23% - 24% |

[0001564590-17-011611:8k_2_02:96]
Some items may not add or recalculate due to rounding.

[0001564590-17-011611:8k_2_02:97]
Press Contact:

[0001564590-17-011611:8k_2_02:98]
Judy Radlinsky

[0001564590-17-011611:8k_2_02:99]
NetApp

[0001564590-17-011611:8k_2_02:100]
1 408 822 6527

[0001564590-17-011611:8k_2_02:101]
judy.radlinsky@netapp.com

[0001564590-17-011611:8k_2_02:102]
Investor Contact:

[0001564590-17-011611:8k_2_02:103]
Kris Newton

[0001564590-17-011611:8k_2_02:104]
NetApp

[0001564590-17-011611:8k_2_02:105]
1 408 822 3312

[0001564590-17-011611:8k_2_02:106]
kris.newton@netapp.com
