# NTAP notes — 0001564590-17-012758


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-17-012758:notes:1]
1. Description of Business and Significant Accounting Policies

[0001564590-17-012758:notes:2]
Description of Business — NetApp, Inc. (we, us, or the Company) provides global organizations the ability to manage and share their data across on-premises, private and public clouds. Together with our partners, we provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.

[0001564590-17-012758:notes:3]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2017, which ended on April 28, 2017, and fiscal year 2015, which ended on April 24, 2015, were each 52-week years; fiscal year 2016, which ended on April 29, 2016, was a 53-week year. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended on the last Friday of April and the associated quarters, months and periods of those fiscal years.

[0001564590-17-012758:notes:4]
Principles of Consolidation — The consolidated financial statements include the Company and its subsidiaries. Intercompany accounts and transactions are eliminated in consolidation.

[0001564590-17-012758:notes:5]
Accounting Change — In the first quarter of fiscal 2017, we early adopted a new accounting standards update that the Financial Accounting Standards Board (FASB) issued in March 2016 that simplifies the accounting for certain aspects of stock-based payments to employees. The new standard requires that certain amendments relevant to us be applied using a modified-retrospective transition method by means of a cumulative-effect adjustment to retained earnings as of the beginning of the period in which the guidance is adopted.

[0001564590-17-012758:notes:6]
In connection with the adoption, we elected to account for forfeitures as they occur and the cumulative-effect impact of that change in accounting policy was a $7 million increase in retained earnings and a corresponding decrease in additional paid-in capital as of April 30, 2016. We also recorded a $3 million cumulative-effect adjustment decrease to retained earnings and a related decrease in deferred tax assets related to the forfeiture rate policy change on outstanding stock-based awards as of April 30, 2016. The standard also eliminates the requirement that excess tax benefits be realized before companies can recognize them. Accordingly, we recorded a $17 million cumulative-effect adjustment increase in retained earnings and an offsetting increase in deferred tax assets for previously unrecognized excess tax benefits as of April 30, 2016.

[0001564590-17-012758:notes:7]
The new standard eliminated the requirement to report excess tax benefits and certain tax deficiencies related to share-based payment transactions as additional paid-in capital. As a result, we recognized $18 million of tax deficiencies in our provision for income taxes, rather than additional paid–in capital, for the year ended April 28, 2017.

[0001564590-17-012758:notes:8]
We elected to report cash flows related to excess tax benefits on a prospective basis. The presentation requirements for cash flows related to employee taxes paid for withheld shares had no impact to our statements of cash flows since such cash flows have historically been presented as a financing activity.

[0001564590-17-012758:notes:9]
Use of Estimates — The preparation of the consolidated financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-17-012758:notes:10]
Cash Equivalents — We consider all highly liquid debt investments with original maturities of three months or less at the time of purchase to be cash equivalents.

[0001564590-17-012758:notes:11]
Available-for-Sale Investments — We classify our investments in debt securities as available-for-sale investments. Debt securities primarily consist of corporate bonds, U.S. Treasury and government debt securities, commercial paper and certificates of deposit. These available-for-sale investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of debt securities sold. These investments are recorded in the consolidated balance sheets at fair value.

[0001564590-17-012758:notes:12]
Unrealized gains and temporary losses, net of related taxes, are included in accumulated other comprehensive income (loss) (AOCI). Upon realization, those amounts are reclassified from AOCI to earnings. The amortization of premiums and discounts on the investments are included in our results of operations. Realized gains and losses on our available-for-sale investments are calculated based on the specific identification method.

[0001564590-17-012758:notes:13]
We classify our investments as current or noncurrent based on the nature of the investments and their availability for use in current operations.

[0001564590-17-012758:notes:14]
Other-than-Temporary Impairments on Investments — All of our available-for-sale investments are subject to periodic impairment review. When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and we assess whether the impairment is other-than-temporary. An impairment is considered other-than-temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of the entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost basis of the security. If impairment is considered other-than-temporary based on condition (i) or (ii) described above, the entire difference between the amortized cost and the fair value of the debt security is recognized in the results of operations. If an impairment is considered other-than-temporary based on condition (iii) described above, the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in earnings, and the amount relating to all other factors is recognized in other comprehensive income (OCI).

[0001564590-17-012758:notes:15]
Inventories — Inventories are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. We write down excess and obsolete inventory based on the difference between the cost of inventory and the estimated net realizable value based upon assumptions about future demand forecasts and market conditions. At the point of a loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts or circumstances do not result in the restoration or increase in that newly established basis. In addition, we record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0001564590-17-012758:notes:16]
Property and Equipment — Property and equipment are recorded at cost.

[0001564590-17-012758:notes:17]
Depreciation and amortization is computed using the straight-line method, generally over the following periods:

[0001564590-17-012758:notes:18]
|  |  | Depreciation Life |
| Buildings and improvements |  | 10 to 40 years |
| Furniture and fixtures |  | 5 years |
| Computer, production, engineering and other equipment |  | 2 to 3 years |
| Computer software |  | 3 to 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |

[0001564590-17-012758:notes:19]
Construction in progress will be depreciated over the estimated useful lives of the respective assets when they are ready for use. We capitalize interest on significant facility assets under construction and on significant software development projects.

[0001564590-17-012758:notes:20]
Software Development Costs — The costs for the development of new software products and substantial enhancements to existing software products are expensed as incurred until technological feasibility has been established, at which time any additional costs would be capitalized in accordance with the accounting guidance for software. Because our current process for developing software is essentially completed concurrently with the establishment of technological feasibility, which occurs upon the completion of a working model, no costs have been capitalized for any of the periods presented.

[0001564590-17-012758:notes:21]
Internal-Use Software Development Costs — We capitalize qualifying costs, which are incurred during the application development stage, for computer software developed or obtained for internal-use and amortize them over the software’s estimated useful life.

[0001564590-17-012758:notes:22]
Business Combinations — We recognize identifiable assets acquired and liabilities assumed at their acquisition date fair values. Goodwill as of the acquisition date is measured as the excess of consideration transferred over the net of the acquisition date fair values of the assets acquired and the liabilities assumed. While we use our best estimates and assumptions as a part of the purchase price allocation process to accurately value assets acquired and liabilities assumed at the acquisition date, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001564590-17-012758:notes:23]
Goodwill and Purchased Intangible Assets — Goodwill is recorded when the consideration paid for an acquisition exceeds the fair value of net tangible and intangible assets acquired. Purchased intangible assets with finite lives are amortized on a straight-line basis over their economic lives of three to six years for developed technology, two to eight years for customer contracts/relationships, two to three years for covenants not to compete and two to seven years for trademarks and trade names as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. In-process research and development is accounted for as an indefinite lived intangible asset and is assessed for potential impairment annually until development is complete or when events or circumstances indicate that their carrying amounts might be impaired. Upon completion of development, in-process research and development is accounted for as a finite-lived intangible asset.

[0001564590-17-012758:notes:24]
The carrying value of goodwill is tested for impairment on an annual basis in the fourth quarter of our fiscal year, or more frequently if we believe indicators of impairment exist. Triggering events for impairment reviews may be indicators such as adverse industry or economic trends, restructuring actions, lower projections of profitability, or a sustained decline in our market capitalization. The performance of the quantitative impairment test requires comparing the fair value of each of our reporting units to its carrying amount, including goodwill. We have three reporting units, the fair values of which are determined based on an allocation of our entity level market capitalization, as determined through quoted market prices. An impairment exists if the fair value of a reporting unit is lower than its carrying amount. The impairment loss is measured based on the amount by which the carrying amount of the reporting unit exceeds its fair value, with the recognized loss not to exceed the total amount of goodwill allocated to that reporting unit. The fair values of each of our reporting units have substantially exceeded their respective carrying amounts in all periods presented.

[0001564590-17-012758:notes:25]
Impairment of Long-Lived Assets — We review the carrying values of long-lived assets whenever events and circumstances, such as reductions in demand, lower projections of profitability, significant changes in the manner of our use of acquired assets, or significant negative industry or economic trends, indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. If this review indicates that there is an impairment, the impaired asset is written down to its fair value, which is typically calculated using: (i) quoted market prices and/or (ii) expected future cash flows utilizing a discount rate. Our estimates regarding future anticipated cash flows, the remaining economic life of the products and technologies, or both, may differ from those used to assess the recoverability of assets. In that event, impairment charges or shortened useful lives of certain long-lived assets may be required, resulting in charges to our consolidated statements of operations when such determinations are made.

[0001564590-17-012758:notes:26]
Derivative Instruments — Our derivative instruments, which are carried at fair value in our consolidated balance sheets, consist of foreign currency exchange contracts as described below:

[0001564590-17-012758:notes:27]
Balance Sheet Hedges — We utilize foreign currency exchange forward and option contracts to hedge against the short-term impact of foreign currency exchange rate fluctuations related to certain foreign currency denominated monetary assets and liabilities, primarily intercompany receivables and payables. These derivative instruments are not designated as hedging instruments and do not subject us to material balance sheet risk due to exchange rate movements because the gains and losses on these contracts are intended to offset the gains and losses in the underlying foreign currency denominated monetary assets and liabilities being hedged, and the net amount is included in earnings.

[0001564590-17-012758:notes:28]
Cash Flow Hedges — We utilize foreign currency exchange forward contracts to hedge foreign currency exchange exposures related to forecasted sales transactions denominated in certain foreign currencies. These derivative instruments are designated and qualify as cash flow hedges and in general, closely match the underlying forecasted transactions in duration. The effective portion of the contracts’ gains and losses resulting from changes in fair value is recorded in AOCI until the forecasted transaction is recognized in the consolidated statements of operations. When the forecasted transactions occur, we reclassify the related gains or losses on the cash flow hedges into net revenues. If the underlying forecasted transactions do not occur, or it becomes probable that they will not occur within the defined hedge period, the gains or losses on the related cash flow hedges are reclassified from AOCI and recognized immediately in earnings. We measure the effectiveness of hedges of forecasted transactions on a monthly basis by comparing the fair values of the designated foreign currency exchange forward purchase contracts with the fair values of the forecasted transactions. Any ineffective portion of the derivative hedging gain or loss, as well as changes in the fair value of the derivative’s time value (which are excluded from the assessment of hedge effectiveness), are recognized in earnings.

[0001564590-17-012758:notes:29]
Factors that could have an impact on the effectiveness of our hedging programs include the accuracy of forecasts and the volatility of foreign currency markets. These programs reduce, but do not entirely eliminate, the impact of currency exchange movements. Currently, we do not enter into any foreign currency exchange forward contracts to hedge exposures related to firm commitments. Cash flows from our derivative programs are included under operating activities in the consolidated statements of cash flows.

[0001564590-17-012758:notes:30]
Revenue Recognition — We recognize revenue when:

[0001564590-17-012758:notes:31]
|  | • | Persuasive evidence of an arrangement exists. Customarily we have a purchase order and/or contract prior to recognizing revenue on an arrangement from our end users, customers, value-added resellers or distributors. |

[0001564590-17-012758:notes:32]
|  | • | Delivery has occurred. Our product is physically delivered to our customers. We typically do not allow for restocking rights with any of our value-added resellers or distributors. Products shipped with acceptance criteria or return rights are not recognized as revenue until all criteria are achieved. We do not recognize revenue if undelivered products or services exist that are essential to the functionality of the delivered product in an arrangement. |

[0001564590-17-012758:notes:33]
|  | • | The fee is fixed or determinable. Arrangements with payment terms extending beyond our standard terms, conditions and practices are not considered to be fixed or determinable. Revenue from such arrangements is recognized at the earlier of customer payment or when the fees become due and payable. We typically do not allow for price-protection rights with any of our value-added resellers or distributors. |

[0001564590-17-012758:notes:34]
|  | • | Collection is reasonably assured. If there is considerable doubt surrounding the creditworthiness of a customer at the outset of an arrangement, the associated revenue is deferred and recognized upon cash receipt. |

[0001564590-17-012758:notes:35]
The hardware systems and software components essential to the functionality of the hardware systems are considered non-software deliverables and therefore are not subject to industry-specific software revenue recognition guidance.

[0001564590-17-012758:notes:36]
Our product revenues also include revenues from the sale of non-essential software products. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales are subject to the industry-specific software revenue recognition guidance.

[0001564590-17-012758:notes:37]
Our multiple element arrangements may include our systems, software maintenance, hardware maintenance and other services. Software maintenance contracts entitle our customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, and patch releases. Hardware maintenance services include contracts for extended warranty, technical support and minimum response times. Other services include professional services and customer education and training services. Revenues from software maintenance and hardware maintenance services are recognized ratably over the contractual term, generally from one to five years. We also offer extended warranty contracts (which extend our standard parts warranty and may include premium hardware maintenance) at the end of the original warranty term; revenues from these contracts are recognized ratably over their respective contract term. We sell professional services either on a time and materials basis or under fixed price projects; we recognize revenue for these services as they are performed.

[0001564590-17-012758:notes:38]
For multiple element arrangements, we allocate revenue to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement. The selling price for each element is based upon the following selling price hierarchy: vendor specific objective evidence of selling price (VSOE) if available, third party evidence (TPE) if VSOE is not available, or estimated selling price (ESP) if neither VSOE nor TPE are available. ESP is generally evidenced by a majority of historical transactions falling within a reasonable price range. We also consider multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, type of customer and distribution channels. For our non-software deliverables, we generally allocate the arrangement consideration based on the relative selling price of the deliverables using ESP. For our software maintenance services, we generally use VSOE. When we are unable to establish VSOE for our software maintenance services, we use ESP in our allocation of arrangement consideration.

[0001564590-17-012758:notes:39]
VSOE is based upon the normal pricing and discounting practices for those services when sold separately. VSOE is generally evidenced by a substantial majority of historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer type, and other variables in determining VSOE.

[0001564590-17-012758:notes:40]
When VSOE cannot be established, we attempt to establish the selling price of each element based on third party evidence of selling price (TPE). Generally, we are not able to determine TPE because our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained.

[0001564590-17-012758:notes:41]
We regularly review VSOE, TPE, and ESP and maintain internal controls over the establishment and updates of these estimates.

[0001564590-17-012758:notes:42]
For our software deliverables, we use the residual method to recognize revenue when an arrangement includes one or more elements to be delivered at a future date and VSOE of all undelivered elements exists. Typically, only software maintenance, hardware maintenance and/or other services remain undelivered after the product is delivered. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the consideration is recognized as product revenues for delivered elements. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is software maintenance, the entire arrangement is recognized ratably over the maintenance period.

[0001564590-17-012758:notes:43]
We record reductions to revenue for estimated sales returns at the time of shipment. Sales returns are estimated based on historical sales returns, current trends, and our expectations regarding future experience. We monitor and analyze the accuracy of sales returns estimates by reviewing actual returns and adjust them for future expectations. Additionally, distributors and retail partners participate in various marketing and other programs, and we record estimated accruals and allowances for these programs. We accrue for these programs based on contractual terms and historical experience. Sales and value added taxes collected from customers and remitted to governmental authorities are presented on a net basis in the accompanying consolidated statements of operations.

[0001564590-17-012758:notes:44]
Product Warranties — Estimated future hardware and software warranty costs are recorded as a cost of product revenues at the time of product shipment, based on historical and projected warranty claim rates, historical and projected cost-per-claim and knowledge of specific product failures that are outside our typical experience. Factors that affect our warranty liability include the number of installed units subject to warranty protection, product failure rates, and estimated materials, distribution and labor costs. We assess the adequacy of our warranty accrual each quarter and adjust the amount as considered necessary.

[0001564590-17-012758:notes:45]
Foreign Currency Translation — For international subsidiaries whose functional currency is the local currency, gains and losses resulting from translation of these foreign currency financial statements into U.S. dollars are recorded in AOCI. For subsidiaries where the functional currency is the U.S. dollar, gains and losses resulting from the process of remeasuring foreign currency financial statements into U.S. dollars are included in other income (expense), net.

[0001564590-17-012758:notes:46]
Benefit Plans — We have a postretirement health care plan and various international defined benefit plans for certain of our employees. We record actuarial gains and losses within AOCI and amortize net gains or losses in excess of 10 percent of the greater of the market value of plan assets or the plans' projected benefit obligation on a straight-line basis over the remaining estimated service life of plan participants. The measurement date for all defined benefit plans is our fiscal year end.

[0001564590-17-012758:notes:47]
Stock-Based Compensation — We measure and recognize stock-based compensation for all stock-based awards, including employee stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and rights to purchase shares under our employee stock purchase plan (ESPP), based on their estimated fair value, and recognize the costs in our financial statements using the single option straight-line approach over the requisite service period for the entire award.

[0001564590-17-012758:notes:48]
The fair value of employee time-based RSUs is equal to the market value of our common stock on the grant date of the award, less the present value of expected dividends during the vesting period, discounted at a risk-free interest rate. The fair value of PBRSUs is measured using a Monte Carlo simulation model on the date of grant.

[0001564590-17-012758:notes:49]
The fair value of each award is estimated on the grant date and is not remeasured as a result of subsequent stock price fluctuations. Our expected term assumption is based primarily on historical exercise and post-vesting forfeiture experience. Our stock price volatility assumption is based on a combination of our historical and implied volatility. The risk-free interest rates are based upon United States Treasury bills with equivalent expected terms, and the expected dividends are based on our history and expected dividend payouts.

[0001564590-17-012758:notes:50]
We account for forfeitures of stock-based awards as they occur.

[0001564590-17-012758:notes:51]
Income Taxes — Deferred income tax assets and liabilities are provided for temporary differences that will result in tax deductions or income in future periods, as well as the future benefit of tax credit carryforwards. A valuation allowance reduces tax assets to their estimated realizable value.

[0001564590-17-012758:notes:52]
We recognize the tax liability for uncertain income tax positions on the income tax return based on the two-step process prescribed in the interpretation. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. We recognize interest and penalties related to unrecognized tax benefits within the income tax expense line in the accompanying consolidated statements of operations.

[0001564590-17-012758:notes:53]
Net Income per Share — Basic net income per share is computed by dividing income available to common stockholders by the weighted-average number of common shares outstanding. Diluted net income per share is computed giving effect to all dilutive potential shares that were outstanding during the period. Potential dilutive common shares consist primarily of outstanding stock options, shares to be purchased under our employee stock purchase plan and unvested RSUs.

[0001564590-17-012758:notes:54]
Treasury Stock — We account for treasury stock under the cost method. Upon the retirement of treasury stock, we allocate the value of treasury shares between common stock, additional paid-in capital and retained earnings.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-17-012758:notes:55]
3. Concentration of Risk

[0001564590-17-012758:notes:56]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, investments, foreign currency exchange contracts and accounts receivable. Cash equivalents and short-term investments consist primarily of corporate bonds, U.S. Treasury and government debt securities, commercial paper and certificates of deposit, all of which are considered high investment grade. Our policy is to limit the amount of credit exposure through diversification and investment in highly rated securities. We further mitigate concentrations of credit risk in our investments by limiting our investments in the debt securities of a single issuer and by diversifying risk across geographies and type of issuer.

[0001564590-17-012758:notes:57]
By entering into foreign currency exchange contracts, we have assumed the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and we do not expect any losses as a result of counterparty defaults.

[0001564590-17-012758:notes:58]
We sell our products primarily to large organizations in different industries and geographies. We do not require collateral or other security to support accounts receivable. In addition, we maintain an allowance for potential credit losses. To reduce credit risk, we perform ongoing credit evaluations on our customers’ financial condition. We establish an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information and, to date, such losses have been within management’s expectations. Concentrations of credit risk with respect to trade accounts receivable are limited due to the wide variety of customers who are dispersed across many geographic regions.

[0001564590-17-012758:notes:59]
There are no concentrations of business transacted with a particular market that would severely impact our business in the near term. However, we rely on a limited number of suppliers for certain key components and a few key contract manufacturers to manufacture most of our products; any disruption or termination of these arrangements could materially adversely affect our operating results.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-17-012758:notes:60]
4. Statements of Cash Flows Additional Information

[0001564590-17-012758:notes:61]
Non-cash investing and financing activities and supplemental cash flow information are as follows (in millions):

[0001564590-17-012758:notes:62]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 19 |  |  | $ | 18 |  |  | $ | 12 |  |
| Non-cash extinguishment of sale-leaseback financing obligations |  | $ | 19 |  |  | $ | — |  |  | $ | — |  |
| Acquisition of software through long-term financing |  | $ | — |  |  | $ | — |  |  | $ | 12 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 102 |  |  | $ | 161 |  |  | $ | 97 |  |
| Interest paid |  | $ | 44 |  |  | $ | 43 |  |  | $ | 33 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-17-012758:notes:63]
5. Business Combinations

[0001564590-17-012758:notes:64]
Fiscal 2017 Acquisition

[0001564590-17-012758:notes:65]
On March 24, 2017, we acquired all of the outstanding shares of a privately-held consulting and software development company for $8 million in cash. Substantially all of the purchase price was recorded to goodwill.

[0001564590-17-012758:notes:66]
Fiscal 2016 Acquisition

[0001564590-17-012758:notes:67]
On February 2, 2016, we acquired all of the outstanding shares of privately-held SolidFire, Inc. (SolidFire), a maker of all-flash storage systems based in Colorado, for $850 million in cash. This acquisition extends our position in the all-flash array market by adding new flash offerings that will enhance our ability to deliver customers all-flash storage with a webscale architecture that simplifies data center operations and enables rapid deployments of new applications.

[0001564590-17-012758:notes:68]
The acquired assets and assumed liabilities were recorded at their estimated fair values. We determined the estimated fair values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expect to realize revenue synergies, leverage and expand the existing SolidFire sales channels and product development resources, and utilize the existing workforce. We also anticipate opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated fair value of SolidFire’s identifiable net assets acquired, and as a result, we have recorded goodwill in connection with this acquisition. The U.S. goodwill is not deductible for income tax purposes.

[0001564590-17-012758:notes:69]
The fair values of assets acquired and liabilities assumed on the closing date are summarized as follows (in millions):

[0001564590-17-012758:notes:70]
| Cash |  | $ | 8 |  |
| Intangible assets |  |  | 168 |  |
| Goodwill |  |  | 649 |  |
| Other assets |  |  | 56 |  |
| Total assets acquired |  |  | 881 |  |
| Liabilities assumed |  |  | (31 | ) |
| Total purchase price |  | $ | 850 |  |

[0001564590-17-012758:notes:71]
The components of intangible assets acquired were as follows (in millions, except useful life):

[0001564590-17-012758:notes:72]
|  |  |  |  |  |  | Estimated useful life (years) |
| Developed technology |  | $ | 99 |  |  | 5 |
| Customer contracts/relationships |  |  | 41 |  |  | 3 |
| Trade name |  |  | 9 |  |  | 2 |
| Total intangible assets subject to amortization |  |  | 149 |  |  |  |
| In-process research and development |  |  | 19 |  |  | N/A |
| Total intangible assets |  | $ | 168 |  |  |  |

[0001564590-17-012758:notes:73]
N/A - Not applicable

[0001564590-17-012758:notes:74]
In-process research and development was valued with input from valuation specialists using the multi-period excess earnings method under the income approach by discounting forecasted cash flows directly related to the products expected to result from the associated project, net of returns on contributory assets. The in-process development project acquired related to a major new generation of the SolidFire technology platform.

[0001564590-17-012758:notes:75]
The results of operations related to the SolidFire acquisition have been included in our consolidated statements of operations from the acquisition date. The following unaudited pro forma condensed combined financial information gives effect to the acquisition of SolidFire as if it had been consummated on April 26, 2014. The unaudited pro forma condensed combined financial information is presented for informational purposes only, and is not intended to represent or be indicative of the results of operations of the Company that would have been reported had the acquisition occurred on April 26, 2014 and should not be taken as representative of future consolidated results of operations of the combined company (in millions).

[0001564590-17-012758:notes:76]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Net income |  | $ | 219 |  |  | $ | 377 |  |

[0001564590-17-012758:notes:77]
Adjustments have been reflected in the unaudited pro forma condensed combined information to include the amortization of identifiable intangible assets, purchase accounting adjustments to deferred revenue, interest expense related to the associated financing arrangement, costs directly attributable to the acquisition and impacts to our provision for income taxes as a result of the acquisition. Pro forma net revenues were not materially different than those presented in the consolidated statements of operations.

[0001564590-17-012758:notes:78]
Fiscal 2015 Acquisitions

[0001564590-17-012758:notes:79]
On October 27, 2014, we completed the acquisition of certain assets related to Riverbed Technology, Inc.’s SteelStore product line for $79 million in cash. The SteelStore product line supports leading backup applications and cloud providers so that customers have a choice in how they extend their existing data protection infrastructure into the cloud.

[0001564590-17-012758:notes:80]
In addition, on the same date, we acquired certain intangible assets from a privately-held software developer for $6 million in cash.

[0001564590-17-012758:notes:81]
Following are the fair values of net assets acquired as of the closing date (in millions):

[0001564590-17-012758:notes:82]
| Net tangible assets |  | $ | 14 |  |
| Finite-lived intangible assets |  |  | 32 |  |
| Goodwill |  |  | 39 |  |
| Total purchase price |  | $ | 85 |  |

[0001564590-17-012758:notes:83]
The results of operations related to these acquisitions have been included in our consolidated statements of operations from the acquisition date. Pro forma results of operations have not been presented because the acquisitions were not material to our results of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-17-012758:notes:84]
6. Goodwill and Purchased Intangible Assets, Net

[0001564590-17-012758:notes:85]
Goodwill activity is summarized as follows (in millions):

[0001564590-17-012758:notes:86]
| Balance as of April 24, 2015 |  | $ | 1,027 |  |
| Goodwill acquired |  |  | 649 |  |
| Balance as of April 29, 2016 |  |  | 1,676 |  |
| Goodwill acquired |  |  | 8 |  |
| Balance as of April 28, 2017 |  | $ | 1,684 |  |

[0001564590-17-012758:notes:87]
Purchased intangible assets are summarized below (in millions):

[0001564590-17-012758:notes:88]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 148 |  |  | $ | (44 | ) |  | $ | 104 |  |  | $ | 403 |  |  | $ | (289 | ) |  | $ | 114 |  |
| Customer contracts/relationships |  |  | 43 |  |  |  | (19 | ) |  |  | 24 |  |  |  | 46 |  |  |  | (7 | ) |  |  | 39 |  |
| Other purchased intangibles |  |  | 9 |  |  |  | (6 | ) |  |  | 3 |  |  |  | 10 |  |  |  | (2 | ) |  |  | 8 |  |
| Total intangible assets subject to amortization |  |  | 200 |  |  |  | (69 | ) |  |  | 131 |  |  |  | 459 |  |  |  | (298 | ) |  |  | 161 |  |
| In-process research and development |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 19 |  |  |  | — |  |  |  | 19 |  |
| Total purchased intangible assets |  | $ | 200 |  |  | $ | (69 | ) |  | $ | 131 |  |  | $ | 478 |  |  | $ | (298 | ) |  | $ | 180 |  |

[0001564590-17-012758:notes:89]
In fiscal 2017, the in-process research and development project related to the SolidFire acquisition was completed, and the associated intangible asset was reclassified to developed technology.

[0001564590-17-012758:notes:90]
During fiscal 2016, we recorded a charge of $11 million to fully impair developed technology related to our fiscal 2013 acquisition of CacheIQ as a result of our discontinued use of such technology. The impairment charge is included in accumulated amortization as of April 29, 2016 in the table above.

[0001564590-17-012758:notes:91]
Amortization expense for purchased intangible assets is summarized below (in millions):

[0001564590-17-012758:notes:92]
|  |  | Year Ended |  |  | Statement of |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | Operations Classifications |
| Developed technology |  | $ | 29 |  |  | $ | 61 |  |  | $ | 63 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 14 |  |  |  | 5 |  |  |  | 1 |  |  | Operating expenses |
| Other purchased intangibles |  |  | 5 |  |  |  | 1 |  |  |  | — |  |  | Operating expenses |
| Total |  | $ | 48 |  |  | $ | 67 |  |  | $ | 64 |  |  |  |

[0001564590-17-012758:notes:93]
As of April 28, 2017, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-17-012758:notes:94]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 49 |  |
| 2019 |  |  | 42 |  |
| 2020 |  |  | 25 |  |
| 2021 |  |  | 15 |  |
| Total |  | $ | 131 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-17-012758:notes:95]
7. Balance Sheet Details

[0001564590-17-012758:notes:96]
Cash and cash equivalents (in millions):

[0001564590-17-012758:notes:97]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Cash |  | $ | 2,275 |  |  | $ | 2,714 |  |
| Cash equivalents |  |  | 169 |  |  |  | 154 |  |
| Cash and cash equivalents |  | $ | 2,444 |  |  | $ | 2,868 |  |

[0001564590-17-012758:notes:98]
Inventories (in millions):

[0001564590-17-012758:notes:99]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Purchased components |  | $ | 28 |  |  | $ | 10 |  |
| Finished goods |  |  | 135 |  |  |  | 88 |  |
| Inventories |  | $ | 163 |  |  | $ | 98 |  |

[0001564590-17-012758:notes:100]
Property and equipment, net (in millions):

[0001564590-17-012758:notes:101]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Land |  | $ | 132 |  |  | $ | 215 |  |
| Buildings and improvements |  |  | 612 |  |  |  | 605 |  |
| Leasehold improvements |  |  | 93 |  |  |  | 106 |  |
| Computer, production, engineering and other equipment |  |  | 741 |  |  |  | 751 |  |
| Computer software |  |  | 353 |  |  |  | 352 |  |
| Furniture and fixtures |  |  | 90 |  |  |  | 88 |  |
| Construction-in-progress |  |  | 26 |  |  |  | 74 |  |
|  |  |  | 2,047 |  |  |  | 2,191 |  |
| Accumulated depreciation and amortization |  |  | (1,248 | ) |  |  | (1,254 | ) |
| Property and equipment, net |  | $ | 799 |  |  | $ | 937 |  |

[0001564590-17-012758:notes:102]
As of April 28, 2017, we classified certain land and buildings previously reported as property and equipment as assets held-for-sale because we expect to sell them within the next twelve months. The book value of these assets was $118 million as of April 28, 2017 and is included in other current assets in the consolidated balance sheets.

[0001564590-17-012758:notes:103]
On April 19, 2016, we sold certain buildings and land in Sunnyvale, California which had a net book value of $118 million at the time of sale, for $250 million in cash. Certain of the properties did not qualify as sales under accounting standards due to continuing involvement related to leaseback arrangements. In fiscal 2016, a portion of the remaining properties, which had a net book value of $51 million and related sales proceeds of $102 million, were recognized as sales, resulting in a gain of $51 million. In fiscal 2017, we recognized the sale of an additional portion of these properties, which had a net book value of $9 million and related sales proceeds of $19 million, resulting in a gain of $10 million. Please see Note 10 – Financing Arrangements for additional information.

[0001564590-17-012758:notes:104]
Depreciation and amortization expense related to property and equipment, net is summarized below (in millions):

[0001564590-17-012758:notes:105]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Depreciation and amortization expense |  | $ | 178 |  |  | $ | 212 |  |  | $ | 243 |  |

[0001564590-17-012758:notes:106]
Other non-current assets (in millions):

[0001564590-17-012758:notes:107]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Deferred tax assets |  | $ | 525 |  |  | $ | 621 |  |
| Other assets |  |  | 156 |  |  |  | 175 |  |
| Other non-current assets |  | $ | 681 |  |  | $ | 796 |  |

[0001564590-17-012758:notes:108]
Accrued expenses (in millions):

[0001564590-17-012758:notes:109]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Accrued compensation and benefits |  | $ | 340 |  |  | $ | 371 |  |
| Sale-leaseback financing obligations |  |  | 130 |  |  |  | 19 |  |
| Product warranty liability |  |  | 33 |  |  |  | 48 |  |
| Other current liabilities |  |  | 279 |  |  |  | 327 |  |
| Accrued expenses |  | $ | 782 |  |  | $ | 765 |  |

[0001564590-17-012758:notes:110]
Product warranty liabilities:

[0001564590-17-012758:notes:111]
Equipment and software systems sales include a standard product warranty. The following tables summarize the activity related to product warranty liabilities and their balances as reported in our consolidated balance sheets (in millions):

[0001564590-17-012758:notes:112]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Balance at beginning of period |  | $ | 70 |  |  | $ | 86 |  |
| Expense accrued during the period |  |  | 17 |  |  |  | 35 |  |
| Warranty costs incurred |  |  | (37 | ) |  |  | (51 | ) |
| Balance at end of period |  | $ | 50 |  |  | $ | 70 |  |

[0001564590-17-012758:notes:113]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Accrued expenses |  | $ | 33 |  |  | $ | 48 |  |
| Other long-term liabilities |  |  | 17 |  |  |  | 22 |  |
| Total warranty liabilities |  | $ | 50 |  |  | $ | 70 |  |

[0001564590-17-012758:notes:114]
Warranty expense accrued during the period includes amounts accrued for systems at the time of shipment, adjustments for changes in estimated costs for warranties on systems shipped in the period and changes in estimated costs for warranties on systems shipped in prior periods.

[0001564590-17-012758:notes:115]
Deferred revenue and financed unearned services revenue (in millions):

[0001564590-17-012758:notes:116]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Deferred product revenue |  | $ | 124 |  |  | $ | 68 |  |
| Deferred services revenue |  |  | 2,999 |  |  |  | 3,100 |  |
| Financed unearned services revenue |  |  | 219 |  |  |  | 217 |  |
| Total |  | $ | 3,342 |  |  | $ | 3,385 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,744 |  |  | $ | 1,794 |  |
| Long-term |  |  | 1,598 |  |  |  | 1,591 |  |
| Total |  | $ | 3,342 |  |  | $ | 3,385 |  |

[0001564590-17-012758:notes:117]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 18 – Commitments and Contingencies for additional information related to these arrangements.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-17-012758:notes:118]
8. Other expense, net

[0001564590-17-012758:notes:119]
Other expense, net consists of the following (in millions):

[0001564590-17-012758:notes:120]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Interest income |  | $ | 44 |  |  | $ | 46 |  |  | $ | 37 |  |
| Interest expense |  |  | (52 | ) |  |  | (49 | ) |  |  | (42 | ) |
| Other income, net |  |  | 8 |  |  |  | — |  |  |  | 2 |  |
| Total other expense, net |  | $ | — |  |  | $ | (3 | ) |  | $ | (3 | ) |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-17-012758:notes:121]
9. Financial Instruments and Fair Value Measurements

[0001564590-17-012758:notes:122]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis, whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the three levels of inputs to measure fair value:

[0001564590-17-012758:notes:123]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001564590-17-012758:notes:124]
Level 2: Inputs that reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; benchmark yields, reported trades, broker/dealer quotes, inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0001564590-17-012758:notes:125]
Level 3: Unobservable inputs that reflect our own assumptions incorporated in valuation techniques used to measure fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0001564590-17-012758:notes:126]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and consider an inactive market to be one in which there are infrequent or few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty’s non-performance risk is considered in measuring the fair values of liabilities and assets, respectively.

[0001564590-17-012758:notes:127]
Investments

[0001564590-17-012758:notes:128]
The following is a summary of our investments (in millions):

[0001564590-17-012758:notes:129]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,535 |  |  | $ | 3 |  |  | $ | (2 | ) |  | $ | 1,536 |  |  | $ | 1,370 |  |  | $ | 5 |  |  | $ | (1 | ) |  | $ | 1,374 |  |
| U.S. Treasury and government debt securities |  |  | 629 |  |  |  | 1 |  |  |  | (2 | ) |  |  | 628 |  |  |  | 878 |  |  |  | 2 |  |  |  | — |  |  |  | 880 |  |
| Foreign government debt securities |  |  | 21 |  |  |  | — |  |  |  | — |  |  |  | 21 |  |  |  | 35 |  |  |  | — |  |  |  | — |  |  |  | 35 |  |
| Commercial paper |  |  | 362 |  |  |  | — |  |  |  | — |  |  |  | 362 |  |  |  | 202 |  |  |  | — |  |  |  | — |  |  |  | 202 |  |
| Certificates of deposit |  |  | 99 |  |  |  | — |  |  |  | — |  |  |  | 99 |  |  |  | 98 |  |  |  | — |  |  |  | — |  |  |  | 98 |  |
| Mutual funds |  |  | 31 |  |  |  | — |  |  |  | — |  |  |  | 31 |  |  |  | 30 |  |  |  | — |  |  |  | — |  |  |  | 30 |  |
| Total debt and equity securities |  | $ | 2,677 |  |  | $ | 4 |  |  | $ | (4 | ) |  | $ | 2,677 |  |  | $ | 2,613 |  |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 2,619 |  |

[0001564590-17-012758:notes:130]
As of April 28, 2017 and April 29, 2016, gross unrealized losses related to individual securities were not significant.

[0001564590-17-012758:notes:131]
The following table presents the contractual maturities of our debt investments as of April 28, 2017 (in millions):

[0001564590-17-012758:notes:132]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,170 |  |  | $ | 1,170 |  |
| Due after one year through five years |  |  | 1,246 |  |  |  | 1,246 |  |
| Due after five years through ten years |  |  | 225 |  |  |  | 225 |  |
| Due after ten years |  |  | 5 |  |  |  | 5 |  |
|  |  | $ | 2,646 |  |  | $ | 2,646 |  |

[0001564590-17-012758:notes:133]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0001564590-17-012758:notes:134]
Fair Value of Financial Instruments

[0001564590-17-012758:notes:135]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis (in millions):

[0001564590-17-012758:notes:136]
|  |  | April 28, 2017 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,275 |  |  | $ | 2,275 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,536 |  |  |  | — |  |  |  | 1,536 |  |
| U.S. Treasury and government debt securities |  |  | 628 |  |  |  | 273 |  |  |  | 355 |  |
| Foreign government debt securities |  |  | 21 |  |  |  | — |  |  |  | 21 |  |
| Commercial paper |  |  | 362 |  |  |  | — |  |  |  | 362 |  |
| Certificates of deposit |  |  | 99 |  |  |  | — |  |  |  | 99 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,921 |  |  | $ | 2,548 |  |  | $ | 2,373 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 24 |  |  | $ | 24 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |

[0001564590-17-012758:notes:137]
|  |  | April 29, 2016 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,714 |  |  | $ | 2,714 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,374 |  |  |  | — |  |  |  | 1,374 |  |
| U.S. Treasury and government debt securities |  |  | 880 |  |  |  | 276 |  |  |  | 604 |  |
| Foreign government debt securities |  |  | 35 |  |  |  | — |  |  |  | 35 |  |
| Commercial paper |  |  | 202 |  |  |  | — |  |  |  | 202 |  |
| Certificates of deposit |  |  | 98 |  |  |  | — |  |  |  | 98 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 5,303 |  |  | $ | 2,990 |  |  | $ | 2,313 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 5 |  |  | $ | 5 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 25 |  |  | $ | 25 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (8 | ) |  | $ | — |  |  | $ | (8 | ) |

[0001564590-17-012758:notes:138]
| (1) | Reported as other current assets in the consolidated balance sheets |

[0001564590-17-012758:notes:139]
| (2) | Reported as other non-current assets in the consolidated balance sheets |

[0001564590-17-012758:notes:140]
| (3) | Reported as accrued expenses in the consolidated balance sheets |

[0001564590-17-012758:notes:141]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of April 28, 2017 and April 29, 2016, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-17-012758:notes:142]
Fair Value of Debt

[0001564590-17-012758:notes:143]
As of April 28, 2017 and April 29, 2016, the fair value of our long-term debt was approximately $1,520 million and $1,519 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-17-012758:notes:144]
10. Financing Arrangements

[0001564590-17-012758:notes:145]
Long-Term Debt

[0001564590-17-012758:notes:146]
The following table summarizes information relating to our long-term debt (in millions, except interest rates):

[0001564590-17-012758:notes:147]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (10 | ) |  |  |  |  |
| Total senior notes |  |  | 1,493 |  |  |  |  |  |  |  | 1,490 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (749 | ) |  |  |  |  |  |  | — |  |  |  |  |  |
| Total long-term debt |  | $ | 744 |  |  |  |  |  |  | $ | 1,490 |  |  |  |  |  |

[0001564590-17-012758:notes:148]
Senior Notes

[0001564590-17-012758:notes:149]
Our 3.375% Senior Notes, 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $500 million, $750 million and $250 million, respectively, were issued in June 2014, December 2012 and December 2012, respectively. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-17-012758:notes:150]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of April 28, 2017, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-17-012758:notes:151]
As of April 28, 2017, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-17-012758:notes:152]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| 2022 |  |  | 500 |  |
| Thereafter |  |  | 250 |  |
| Total |  | $ | 1,500 |  |

[0001564590-17-012758:notes:153]
Commercial Paper Program and Credit Facility

[0001564590-17-012758:notes:154]
In December 2016, we entered into a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $600 million. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes will be used for general corporate purposes. As of April 28, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $500 million, a weighted-average interest rate of 1.26% and maturities ranging from 7 days to 38 days.

[0001564590-17-012758:notes:155]
In connection with the Program, we entered into a new senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021, and we terminated our existing credit agreement that had been scheduled to expire on December 21, 2017. The new credit agreement provides a $600 million revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of April 28, 2017, no borrowings or letters of credit were outstanding under this facility, and we were in compliance with all associated covenants.

[0001564590-17-012758:notes:156]
Short-Term Loan

[0001564590-17-012758:notes:157]
In February 2016, in connection with the SolidFire acquisition, we entered into a short-term loan of $870 million that had a maturity date of November 2, 2016. As of April 28, 2017, we have repaid the loan in full and have terminated the related loan agreement.

[0001564590-17-012758:notes:158]
Sale-leaseback Transactions

[0001564590-17-012758:notes:159]
In fiscal 2016 we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, until such time as the related leases are terminated, the assets will remain on our balance sheets and proceeds received by us from these transactions are reported as financing transactions. During fiscal 2017, we terminated one of the leases, ending our continuing involvement with the related properties. As a result, we recorded a non-cash sale of properties having a net book value of $9 million, the extinguishment of $19 million of associated financing obligations, and a gain of $10 million. As of April 28, 2017, the balance of the remaining financing obligations, which relate to properties whose leases we expect to terminate in December 2017, was $130 million. At the end of the leaseback period, or when our continuing involvement under the leaseback agreement ends, this transaction will be reported as a non-cash sale and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-17-012758:notes:160]
11. Stockholders’ Equity

[0001564590-17-012758:notes:161]
Equity Incentive Programs

[0001564590-17-012758:notes:162]
The 1999 Plan — As most recently amended on September 15, 2016, the 1999 Stock Option Plan (the Plan) comprises five separate equity incentive programs: (i) the Discretionary Option Grant Program under which options may be granted to eligible individuals at a fixed price per share; (ii) the Stock Appreciation Rights Program under which eligible persons may be granted stock appreciation rights that allow individuals to receive the appreciation in fair market value of the shares; (iii) the Stock Issuance Program under which eligible individuals may be issued shares of common stock directly; (iv) the Performance Share and Performance Unit Program under which eligible persons may be granted performance shares or performance units which result in payment to the participant only if performance goals or other vesting criteria are achieved and (v) the Automatic Award Program under which nonemployee board members automatically receive equity grants at designated intervals over their period of board service. The Plan expires in August 2019.

[0001564590-17-012758:notes:163]
Under the Plan, the Board of Directors may grant to employees, nonemployee directors, consultants and independent advisors options to purchase shares of our common stock during their period of service. The exercise price for an incentive stock option and a nonstatutory option cannot be less than 100% of the fair market value of the common stock on the grant date. Options granted under the Plan generally vest over a four-year period. Options granted generally have a term of seven years after the grant date, subject to earlier termination upon the occurrence of certain events. The Plan prohibits the repricing of any outstanding stock option or stock appreciation right after it has been granted or to cancel any outstanding stock option or stock appreciation right and immediately replace it with a new stock option or stock appreciation right with a lower exercise price unless approved by stockholders. RSUs granted under the Plan include time-based RSUs that generally vest over a four-year period with 25% vesting on each anniversary of the grant date. The Compensation Committee of the Board of Directors (the Compensation Committee) has the discretion to use different vesting schedules. In addition, performance-based RSUs may be granted under the Plan and are subject to performance criteria and vesting terms specified by the Compensation Committee.

[0001564590-17-012758:notes:164]
Under the Plan, the number of shares reserved for issuance is reduced by two shares for every share subject to a full value award, which are specified to be grants that are in the form of performance shares and/or performance unit awards, stock, restricted stock or restricted stock units. The Plan (i) limits the number of shares that may be granted pursuant to awards under the Stock Issuance Program to a participant in any calendar year to 1 million, (ii) limits the initial value of performance units a participant may receive to not more than $5 million and (iii) limits the number of performance shares a participant may receive in a calendar year to 1 million.

[0001564590-17-012758:notes:165]
During fiscal 2017, the shares reserved for issuance under the Plan were increased by approximately 4 million shares of common stock. As of April 28, 2017, 23 million shares were available for grant under the Plan.

[0001564590-17-012758:notes:166]
Stock Options

[0001564590-17-012758:notes:167]
The following table summarizes information related to our stock options (in millions, except exercise price and contractual term):

[0001564590-17-012758:notes:168]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 25, 2014 |  |  | 15 |  |  | $ | 34.10 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2 |  |  | $ | 36.64 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (5 | ) |  | $ | 25.25 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | — |  |  | $ | 42.42 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 24, 2015 |  |  | 12 |  |  | $ | 37.74 |  |  |  |  |  |  |  |  |  |
| Assumed in acquisition |  |  | 2 |  |  | $ | 5.20 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (2 | ) |  | $ | 19.64 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (3 | ) |  | $ | 38.27 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 29, 2016 |  |  | 9 |  |  | $ | 34.01 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (3 | ) |  | $ | 25.61 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (2 | ) |  | $ | 39.36 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 28, 2017 |  |  | 4 |  |  | $ | 35.76 |  |  |  | 3.25 |  |  | $ | 31 |  |
| Exercisable as of April 28, 2017 |  |  | 3 |  |  | $ | 40.92 |  |  |  | 2.39 |  |  | $ | 11 |  |

[0001564590-17-012758:notes:169]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our stock on that day for all in-the-money options.

[0001564590-17-012758:notes:170]
Additional information related to our stock options is summarized below (in millions):

[0001564590-17-012758:notes:171]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Intrinsic value of exercises |  | $ | 26 |  |  | $ | 16 |  |  | $ | 70 |  |
| Proceeds received from exercises |  | $ | 60 |  |  | $ | 27 |  |  | $ | 117 |  |
| Fair value of options vested |  | $ | 15 |  |  | $ | 15 |  |  | $ | 33 |  |

[0001564590-17-012758:notes:172]
Restricted Stock Units

[0001564590-17-012758:notes:173]
In fiscal 2017 and 2016, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service based vesting criteria) such that the PBRSU cliff-vests at the end of either an approximate two year or three year performance period, which began on the date specified in the grant agreement and ends the last day of the second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted, and will depend upon our Total Stockholder Return (TSR) as compared to an index TSR (each expressed as a growth rate percentage) calculated as of the applicable period end date. The fair values of the PBRSUs were fixed at grant date and the related aggregate compensation cost of PBRSUs granted in fiscal 2017 and 2016 was $15 million and $20 million, respectively, which is being recognized over the shorter of the remaining applicable performance or service periods.

[0001564590-17-012758:notes:174]
As of April 28, 2017 and April 29, 2016, respectively, there were approximately 1 million and 500 thousand PBRSUs outstanding.

[0001564590-17-012758:notes:175]
The following table summarizes information related to RSUs, including PBRSUs, (in millions, except for fair value):

[0001564590-17-012758:notes:176]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 25, 2014 |  |  | 13 |  |  | $ | 38.35 |  |
| Granted |  |  | 7 |  |  | $ | 35.80 |  |
| Vested |  |  | (5 | ) |  | $ | 40.14 |  |
| Forfeited |  |  | (2 | ) |  | $ | 37.48 |  |
| Outstanding as of April 24, 2015 |  |  | 13 |  |  | $ | 36.58 |  |
| Granted |  |  | 7 |  |  | $ | 29.26 |  |
| Vested |  |  | (5 | ) |  | $ | 37.72 |  |
| Forfeited |  |  | (2 | ) |  | $ | 34.85 |  |
| Outstanding as of April 29, 2016 |  |  | 13 |  |  | $ | 32.46 |  |
| Granted |  |  | 5 |  |  | $ | 24.99 |  |
| Vested |  |  | (5 | ) |  | $ | 32.03 |  |
| Forfeited |  |  | (2 | ) |  | $ | 31.66 |  |
| Outstanding as of April 28, 2017 |  |  | 11 |  |  | $ | 28.81 |  |

[0001564590-17-012758:notes:177]
We primarily use the net share settlement approach upon vesting, where a portion of the shares are withheld as settlement of employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001564590-17-012758:notes:178]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Shares withheld for taxes |  |  | 2 |  |  |  | 2 |  |  |  | 2 |  |
| Fair value of shares withheld |  | $ | 48 |  |  | $ | 50 |  |  | $ | 57 |  |

[0001564590-17-012758:notes:179]
Employee Stock Purchase Plan

[0001564590-17-012758:notes:180]
Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. On September 15, 2016, the ESPP was amended to increase the shares reserved for issuance by 3 million shares of common stock. As of April 28, 2017, 9 million shares were available for issuance. The following table summarizes activity related to the purchase rights issued under the ESPP (in millions):

[0001564590-17-012758:notes:181]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Shares issued under the ESPP |  |  | 4 |  |  |  | 3 |  |  |  | 3 |  |
| Proceeds from issuance of shares |  | $ | 80 |  |  | $ | 93 |  |  | $ | 97 |  |

[0001564590-17-012758:notes:182]
Stock-Based Compensation Expense

[0001564590-17-012758:notes:183]
Stock-based compensation expense is included in the consolidated statements of operations as follows (in millions):

[0001564590-17-012758:notes:184]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Cost of product revenues |  | $ | 4 |  |  | $ | 5 |  |  | $ | 6 |  |
| Cost of hardware maintenance and other services revenues |  |  | 13 |  |  |  | 19 |  |  |  | 16 |  |
| Sales and marketing |  |  | 84 |  |  |  | 110 |  |  |  | 116 |  |
| Research and development |  |  | 59 |  |  |  | 84 |  |  |  | 84 |  |
| General and administrative |  |  | 35 |  |  |  | 42 |  |  |  | 37 |  |
| Total stock-based compensation expense |  | $ | 195 |  |  | $ | 260 |  |  | $ | 259 |  |
| Income tax benefit for stock-based compensation |  | $ | 41 |  |  | $ | 53 |  |  | $ | 57 |  |

[0001564590-17-012758:notes:185]
As of April 28, 2017, total unrecognized compensation expense related to our equity awards was $211 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 1.8 years.

[0001564590-17-012758:notes:186]
Valuation Assumptions

[0001564590-17-012758:notes:187]
The valuation of stock options, RSUs and ESPP purchase rights and the underlying weighted-average assumptions are summarized as follows:

[0001564590-17-012758:notes:188]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Stock options: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected term in years |  | N/A |  |  | N/A |  |  |  | 4.8 |  |
| Risk-free interest rate |  | N/A |  |  | N/A |  |  |  | 1.6 | % |
| Expected volatility |  | N/A |  |  | N/A |  |  |  | 29 | % |
| Expected dividend yield |  | N/A |  |  | N/A |  |  |  | 1.8 | % |
| Weighted-average fair value per share granted |  | N/A |  |  | N/A |  |  | $ | 8.24 |  |
| RSUs: |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 1.0 | % |  |  | 0.6 | % |  |  | 0.6 | % |
| Expected dividend yield |  |  | 3.1 | % |  |  | 2.3 | % |  |  | 1.8 | % |
| Weighted-average fair value per share granted |  | $ | 24.99 |  |  | $ | 29.26 |  |  | $ | 35.80 |  |
| ESPP: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.3 |  |
| Risk-free interest rate |  |  | 0.8 | % |  |  | 0.5 | % |  |  | 0.2 | % |
| Expected volatility |  |  | 30 | % |  |  | 27 | % |  |  | 27 | % |
| Expected dividend yield |  |  | 3.1 | % |  |  | 2.3 | % |  |  | 1.8 | % |
| Weighted-average fair value per right granted |  | $ | 7.85 |  |  | $ | 8.18 |  |  | $ | 9.81 |  |

[0001564590-17-012758:notes:189]
N/A - Not applicable. No options were granted in fiscal years 2017 or 2016.

[0001564590-17-012758:notes:190]
In connection with our fiscal 2016 acquisition of SolidFire, we assumed all of the then outstanding unvested options to purchase SolidFire common stock and converted those into unvested options to purchase 2 million shares of our common stock. The weighted average assumptions used to value these options, as of the acquisition date, were an expected term of 4.3 years, risk-free interest rate of 1.1%, expected volatility of 31% and expected dividend yield of 3.3%. The weighted average fair value per share of these options was $14.32.

[0001564590-17-012758:notes:191]
Stock Repurchase Program

[0001564590-17-012758:notes:192]
As of April 28, 2017, our Board of Directors has authorized the repurchase of up to $9.6 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management.

[0001564590-17-012758:notes:193]
The following table summarizes activity related to this program (in millions, except per share amounts):

[0001564590-17-012758:notes:194]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Number of shares repurchased |  |  | 22 |  |  |  | 33 |  |  |  | 30 |  |
| Average price per share |  | $ | 32.72 |  |  | $ | 28.80 |  |  | $ | 39.30 |  |
| Aggregate purchase price |  | $ | 705 |  |  | $ | 960 |  |  | $ | 1,165 |  |
| Remaining authorization at end of period |  | $ | 794 |  |  | $ | 1,499 |  |  | $ | 2,460 |  |

[0001564590-17-012758:notes:195]
The aggregate purchase price of our stock repurchases for fiscal 2017 consisted of $705 million of open market purchases, of which, $335 million and $370 million was allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-17-012758:notes:196]
Since the May 13, 2003 inception of our stock repurchase program through April 28, 2017, we repurchased a total of 269 million shares of our common stock at an average price of $32.84 per share, for an aggregate purchase price of $8.8 billion.

[0001564590-17-012758:notes:197]
Preferred Stock

[0001564590-17-012758:notes:198]
Our Board of Directors has the authority to issue up to 5 million shares of preferred stock and to determine the price, rights, preferences, privileges, and restrictions, including voting rights, of those shares without any further vote or action by the stockholders. No shares of preferred stock were issued or outstanding in any period presented.

[0001564590-17-012758:notes:199]
Dividends

[0001564590-17-012758:notes:200]
The following is a summary of our fiscal 2017, 2016 and 2015 activities related to dividends on our common stock (in millions, except per share amounts).

[0001564590-17-012758:notes:201]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Dividends per share declared |  | $ | 0.76 |  |  | $ | 0.72 |  |  | $ | 0.66 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 88 |  |  | $ | 125 |  |  | $ | 52 |  |
| Dividend payments allocated to retained earnings |  | $ | 120 |  |  | $ | 85 |  |  | $ | 156 |  |

[0001564590-17-012758:notes:202]
On May 24, 2017, we declared a cash dividend of $0.20 per share of common stock, payable on July 26, 2017 to holders of record as of the close of business on July 7, 2017. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by the Company to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-17-012758:notes:203]
Accumulated Other Comprehensive Income (Loss)

[0001564590-17-012758:notes:204]
Changes in AOCI by component, net of tax, are summarized below (in millions):

[0001564590-17-012758:notes:205]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 24, 2015 |  | $ | (23 | ) |  | $ | (13 | ) |  | $ | 11 |  |  | $ | 1 |  |  | $ | (24 | ) |
| OCI before reclassifications, net of tax |  |  | 4 |  |  |  | (5 | ) |  |  | (4 | ) |  |  | (4 | ) |  |  | (9 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | 2 |  |  |  | (1 | ) |  |  | 1 |  |  |  | 2 |  |
| Total OCI |  |  | 4 |  |  |  | (3 | ) |  |  | (5 | ) |  |  | (3 | ) |  |  | (7 | ) |
| Balance as of April 29, 2016 |  |  | (19 | ) |  |  | (16 | ) |  |  | 6 |  |  |  | (2 | ) |  |  | (31 | ) |
| OCI before reclassifications, net of tax |  |  | (10 | ) |  |  | 16 |  |  |  | (6 | ) |  |  | 8 |  |  |  | 8 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (6 | ) |  |  | (6 | ) |
| Total OCI |  |  | (10 | ) |  |  | 16 |  |  |  | (6 | ) |  |  | 2 |  |  |  | 2 |  |
| Balance as of April 28, 2017 |  | $ | (29 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (29 | ) |

[0001564590-17-012758:notes:206]
The amounts reclassified out of AOCI are as follows (in millions):

[0001564590-17-012758:notes:207]
|  |  | Year Ended |  |  |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |
| Recognized losses on defined benefit obligations |  | $ | 1 |  |  | $ | 2 |  |  |  | — |  |  | Operating expenses |
| Realized gains on available-for-sale securities |  |  | — |  |  |  | (1 | ) |  |  | — |  |  | Other expense, net |
| Realized (gains) losses on cash flow hedges |  |  | (6 | ) |  |  | 1 |  |  |  | (14 | ) |  | Net revenues |
| Total reclassifications |  | $ | (5 | ) |  | $ | 2 |  |  | $ | (14 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-17-012758:notes:208]
12. Derivatives and Hedging Activities

[0001564590-17-012758:notes:209]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is six months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of April 28, 2017 or April 29, 2016. We did not recognize any gains or losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-17-012758:notes:210]
The notional amount of our outstanding U.S. dollar equivalent foreign currency exchange forward contracts consisted of the following (in millions):

[0001564590-17-012758:notes:211]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | — |  |  | $ | 99 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 165 |  |  | $ | 160 |  |
| Forward contracts purchased |  | $ | 257 |  |  | $ | 396 |  |

[0001564590-17-012758:notes:212]
The effect of derivative instruments designated as cash flow hedges recognized in net revenues on our consolidated statements of operations is presented in the consolidated statements of comprehensive income and Note 11 – Stockholders’ Equity.

[0001564590-17-012758:notes:213]
The effect of derivative instruments not designated as hedging instruments recognized in other expense, net on our consolidated statements of operations was as follows (in millions):

[0001564590-17-012758:notes:214]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
|  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 1 |  |  | $ | (4 | ) |  | $ | 14 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-17-012758:notes:215]
13. Restructuring Charges

[0001564590-17-012758:notes:216]
Management has approved several restructuring actions to streamline our business, eliminate costs and redirect resources to our highest return activities. including the May 2015 Plan, the March 2016 Plan and the November 2016 Plan, under which we reduced our global workforce by approximately 3%, 11%, and 6%, respectively. We have completed all of these activities as of April 28, 2017. Charges related to our restructuring plans consisted primarily of employee severance-related costs.

[0001564590-17-012758:notes:217]
Activities related to our restructuring plans are summarized as follows (in millions):

[0001564590-17-012758:notes:218]
|  |  | November 2016 Plan |  |  | March 2016 Plan |  |  | May 2015 Plan |  |  | Total |  |
| Balance as of April 24, 2015 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net charges |  |  | — |  |  |  | 80 |  |  |  | 28 |  |  |  | 108 |  |
| Cash payments |  |  | — |  |  |  | (35 | ) |  |  | (28 | ) |  |  | (63 | ) |
| Balance as of April 29, 2016 |  |  | — |  |  |  | 45 |  |  |  | — |  |  |  | 45 |  |
| Net charges |  |  | 52 |  |  |  | — |  |  |  | — |  |  |  | 52 |  |
| Cash payments |  |  | (39 | ) |  |  | (45 | ) |  |  | — |  |  |  | (84 | ) |
| Balance as of April 28, 2017 |  | $ | 13 |  |  | $ | — |  |  | $ | — |  |  | $ | 13 |  |

[0001564590-17-012758:notes:219]
Liabilities for our restructuring activities are included in accrued expenses in our consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-17-012758:notes:220]
14. Income Taxes

[0001564590-17-012758:notes:221]
Income before income taxes is as follows (in millions):

[0001564590-17-012758:notes:222]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Domestic |  | $ | 206 |  |  | $ | 88 |  |  | $ | 253 |  |
| Foreign |  |  | 459 |  |  |  | 257 |  |  |  | 460 |  |
| Total |  | $ | 665 |  |  | $ | 345 |  |  | $ | 713 |  |

[0001564590-17-012758:notes:223]
Domestic income before taxes is lower than foreign income before taxes due to significant domestic expenses related to the amortization of intangibles, stock-based compensation and restructuring expenses.

[0001564590-17-012758:notes:224]
The provision for income taxes consists of the following (in millions):

[0001564590-17-012758:notes:225]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 22 |  |  | $ | 180 |  |  | $ | 104 |  |
| State |  |  | 3 |  |  |  | 14 |  |  |  | 12 |  |
| Foreign |  |  | 41 |  |  |  | 35 |  |  |  | 40 |  |
| Total current |  |  | 66 |  |  |  | 229 |  |  |  | 156 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 75 |  |  |  | (91 | ) |  |  | 8 |  |
| State |  |  | 18 |  |  |  | (17 | ) |  |  | (3 | ) |
| Foreign |  |  | (3 | ) |  |  | (5 | ) |  |  | (8 | ) |
| Total deferred |  |  | 90 |  |  |  | (113 | ) |  |  | (3 | ) |
| Provision for income taxes |  | $ | 156 |  |  | $ | 116 |  |  | $ | 153 |  |

[0001564590-17-012758:notes:226]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0001564590-17-012758:notes:227]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Tax computed at federal statutory rate |  | $ | 233 |  |  | $ | 121 |  |  | $ | 250 |  |
| State income taxes, net of federal benefit |  |  | 14 |  |  |  | (3 | ) |  |  | 5 |  |
| Foreign earnings in lower tax jurisdictions |  |  | (100 | ) |  |  | (81 | ) |  |  | (141 | ) |
| Stock-based compensation |  |  | 16 |  |  |  | 13 |  |  |  | 6 |  |
| Research and development credits |  |  | (8 | ) |  |  | (14 | ) |  |  | (14 | ) |
| Resolution of income tax examinations |  |  | — |  |  |  | 20 |  |  |  | 46 |  |
| Domestic production activities deduction |  |  | (4 | ) |  |  | (10 | ) |  |  | (5 | ) |
| Tax charge from integration of intellectual property from the SolidFire acquisition |  |  | — |  |  |  | 64 |  |  |  | — |  |
| Other |  |  | 5 |  |  |  | 6 |  |  |  | 6 |  |
| Provision for income taxes |  | $ | 156 |  |  | $ | 116 |  |  | $ | 153 |  |

[0001564590-17-012758:notes:228]
We generated foreign earnings in lower tax jurisdictions primarily related to income from our European operations which are headquartered in the Netherlands. During fiscal 2016, we acquired SolidFire and recorded a tax charge of $64 million related to the integration of SolidFire intellectual property into our worldwide operations.

[0001564590-17-012758:notes:229]
During the first quarter of fiscal 2017, we adopted a new accounting standard that simplifies stock-based compensation income tax accounting and presentation within the financial statements. During fiscal 2017, we recorded a tax charge of $18 million following the post-adoption rules which require that all excess tax benefits and deficiencies from stock-based compensation be recognized as a component of income tax expense. See Note 1 – Description of Business and Significant Accounting Policies for more details regarding the adoption of this accounting standard.

[0001564590-17-012758:notes:230]
The components of our deferred tax assets and liabilities are as follows (in millions):

[0001564590-17-012758:notes:231]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Reserves and accruals |  | $ | 149 |  |  | $ | 214 |  |
| Net operating loss and credit carryforwards |  |  | 104 |  |  |  | 72 |  |
| Stock-based compensation |  |  | 49 |  |  |  | 66 |  |
| Deferred revenue |  |  | 329 |  |  |  | 336 |  |
| Other |  |  | 32 |  |  |  | 39 |  |
| Gross deferred tax assets |  |  | 663 |  |  |  | 727 |  |
| Valuation allowance |  |  | (94 | ) |  |  | (59 | ) |
| Deferred tax assets, net of valuation allowance |  |  | 569 |  |  |  | 668 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Prepaids and accruals |  |  | 3 |  |  |  | 3 |  |
| Acquired intangibles |  |  | 36 |  |  |  | 27 |  |
| Property and equipment |  |  | 4 |  |  |  | 14 |  |
| Other |  |  | 2 |  |  |  | 3 |  |
| Total deferred tax liabilities |  |  | 45 |  |  |  | 47 |  |
| Deferred tax assets, net of valuation allowance and deferred tax liabilities |  | $ | 524 |  |  | $ | 621 |  |

[0001564590-17-012758:notes:232]
The valuation allowance increased by $35 million in fiscal 2017. The increase is mainly attributable to the adoption of the new accounting standard which requires that tax attributes related to excess tax benefits now be recognized as deferred tax assets, offset by corresponding valuation allowances, if applicable.

[0001564590-17-012758:notes:233]
As of April 28, 2017, we have federal net operating loss and tax credit carryforwards of approximately $8 million and $37 million, respectively. In addition, we have gross state net operating loss and tax credit carryforwards of $30 million and $142 million, respectively. The majority of the state credit carryforwards are California research credits which are offset by a valuation allowance as we believe it is more likely than not that these credits will not be utilized. We also have $22 million of foreign tax credit carryforwards generated by our Dutch subsidiary which are fully offset by a valuation allowance. Certain acquired net operating loss and credit carryforwards are subject to an annual limitation under Internal Revenue Code Section 382, but are expected to be realized with the exception of those which have a valuation allowance. The federal and state net operating loss carryforwards and credits will expire in various years from fiscal 2018 through 2037. The California research credit and Dutch foreign tax credit carryforwards do not expire.

[0001564590-17-012758:notes:234]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001564590-17-012758:notes:235]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Balance at beginning of period |  | $ | 216 |  |  | $ | 272 |  |  | $ | 236 |  |
| Additions based on tax positions related to the current year |  |  | 7 |  |  |  | 14 |  |  |  | 22 |  |
| Additions for tax positions of prior years |  |  | 7 |  |  |  | 21 |  |  |  | 101 |  |
| Decreases for tax positions of prior years |  |  | — |  |  |  | (39 | ) |  |  | (29 | ) |
| Settlements |  |  | (12 | ) |  |  | (52 | ) |  |  | (58 | ) |
| Balance at end of period |  | $ | 218 |  |  | $ | 216 |  |  | $ | 272 |  |

[0001564590-17-012758:notes:236]
As of April 28, 2017, we had $218 million of gross unrecognized tax benefits, of which $156 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $159 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-17-012758:notes:237]
We recognize accrued interest and penalties related to unrecognized tax benefits in the income tax provision. During fiscal 2017, 2016 and 2015, we recognized accrued interest and penalties of approximately $5 million, $2 million and $4 million, respectively in the consolidated statements of operations and $16 million and $11 million, respectively, were recorded in the consolidated balance sheets as of April 28, 2017 and April 29, 2016.

[0001564590-17-012758:notes:238]
The tax years that remain subject to examination for our major tax jurisdictions are shown below:

[0001564590-17-012758:notes:239]
Fiscal Years Subject to Examination for Major Tax Jurisdictions at April 28, 2017

[0001564590-17-012758:notes:240]
| 2012 — 2017 |  | United States — federal income tax |
| 2008 — 2017 |  | United States — state and local income tax |
| 2013 — 2017 |  | Australia |
| 2014 — 2017 |  | Germany |
| 2007 — 2017 |  | India |
| 2011 — 2017 |  | Japan |
| 2013 — 2017 |  | The Netherlands |
| 2014 — 2017 |  | United Kingdom |
| 2009 — 2017 |  | Canada |

[0001564590-17-012758:notes:241]
In addition, we are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal 2001, in that we have carryforward attributes from these years that could be subject to adjustment in the tax years of utilization.

[0001564590-17-012758:notes:242]
In June 2015, the Internal Revenue Service (IRS) signed a closing agreement on our fiscal 2008 to 2010 transfer pricing arrangements and, in October 2015, completed the examination of our fiscal 2008 to 2010 income tax returns. During fiscal 2016, we recorded discrete charges totaling $23 million attributable to audit settlements and the related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-17-012758:notes:243]
In July 2014, the IRS completed the examination of our fiscal 2005 to 2007 income tax returns upon approval by the Joint Committee of Taxation. During fiscal 2015, we recorded a tax charge of $47 million attributable to the audit settlement and related re-measurements of uncertain tax positions for tax years subject to future audits.

[0001564590-17-012758:notes:244]
We are currently undergoing federal income tax audits in the United States (U.S.) and several foreign tax jurisdictions. Transfer pricing calculations are key issues under audits in various jurisdictions, and are often subject to dispute and appeals. The IRS has concluded the examination of our tax returns for our fiscal years through 2010. The IRS commenced the examination of our federal income tax returns for our fiscal years 2012 and 2013 in August 2016.

[0001564590-17-012758:notes:245]
On September 17, 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 from our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. On December 19, 2011, the Danish Tax Tribunal issued a ruling that our Danish subsidiary was not liable for Danish withholding tax. The Danish tax examination agency appealed to the Danish High Court in March 2012. In February 2016, the Danish High Court referred the case to the European Court of Justice.

[0001564590-17-012758:notes:246]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. Based on current information, we do not expect significant changes to our existing unrecognized tax benefits as of April 28, 2017.

[0001564590-17-012758:notes:247]
As of April 28, 2017, the amount of accumulated unremitted earnings from our foreign subsidiaries is approximately $4 billion. We have not provided U.S. income taxes and foreign withholding taxes on the undistributed earnings of foreign subsidiaries because we intend to indefinitely reinvest such earnings outside the U.S. If these foreign earnings were to be repatriated in the future, the related U.S. tax liability may be reduced by any foreign income taxes previously paid on these earnings as well as tax attributes. We estimate the unrecognized deferred tax liability related to these earnings to be approximately $1 billion as of April 28, 2017.


## us-gaap:EarningsPerShareTextBlock

[0001564590-17-012758:notes:248]
15. Net Income per Share

[0001564590-17-012758:notes:249]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0001564590-17-012758:notes:250]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 509 |  |  | $ | 229 |  |  | $ | 560 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 275 |  |  |  | 294 |  |  |  | 316 |  |
| Dilutive impact of employee equity award plans |  |  | 6 |  |  |  | 3 |  |  |  | 5 |  |
| Shares used in diluted computation |  |  | 281 |  |  |  | 297 |  |  |  | 321 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.85 |  |  | $ | 0.78 |  |  | $ | 1.77 |  |
| Diluted |  | $ | 1.81 |  |  | $ | 0.77 |  |  | $ | 1.75 |  |

[0001564590-17-012758:notes:251]
Potential shares from outstanding employee equity awards totaling 6 million, 12 million and 8 million for fiscal 2017, 2016 and 2015, respectively, were excluded from the diluted net income per share calculations as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-17-012758:notes:252]
16. Segment, Geographic, and Significant Customer Information

[0001564590-17-012758:notes:253]
We operate in one industry segment: the design, manufacturing, marketing, and technical support of high-performance storage and data management solutions. We conduct business globally, and our sales and support activities are managed on a geographic basis. Our management reviews financial information presented on a consolidated basis, accompanied by disaggregated information it receives from our internal management system about revenues by geographic region, based on the location from which the customer relationship is managed, for purposes of allocating resources and evaluating financial performance. We do not allocate costs of revenues, research and development, sales and marketing, or general and administrative expenses to our geographic regions in this internal management reporting because management does not review operations or operating results, or make planning decisions, below the consolidated entity level.

[0001564590-17-012758:notes:254]
Summarized revenues by geographic region based on information from our internal management system and utilized by our Chief Executive Officer, who is considered our Chief Operating Decision Maker, is as follows (in millions):

[0001564590-17-012758:notes:255]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| United States, Canada and Latin America (Americas) |  | $ | 3,077 |  |  | $ | 3,067 |  |  | $ | 3,447 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 1,712 |  |  |  | 1,757 |  |  |  | 1,857 |  |
| Asia Pacific (APAC) |  |  | 730 |  |  |  | 722 |  |  |  | 819 |  |
| Net revenues |  | $ | 5,519 |  |  | $ | 5,546 |  |  | $ | 6,123 |  |

[0001564590-17-012758:notes:256]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $2,774 million, $2,753 million and $3,096 million during fiscal 2017, 2016 and 2015, respectively.

[0001564590-17-012758:notes:257]
The majority of our assets, excluding cash, cash equivalents, short-term investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents and short-term investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0001564590-17-012758:notes:258]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| U.S. |  | $ | 425 |  |  | $ | 513 |  |
| International |  |  | 4,496 |  |  |  | 4,790 |  |
| Total |  | $ | 4,921 |  |  | $ | 5,303 |  |

[0001564590-17-012758:notes:259]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment information for geographic areas based on the physical location of the assets (in millions):

[0001564590-17-012758:notes:260]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| U.S. |  | $ | 593 |  |  | $ | 797 |  |
| International |  |  | 206 |  |  |  | 140 |  |
| Total |  | $ | 799 |  |  | $ | 937 |  |

[0001564590-17-012758:notes:261]
The following customers, each of which is a distributor, accounted for 10% or more of our net revenues:

[0001564590-17-012758:notes:262]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 22 | % |  |  | 23 | % |
| Avnet, Inc. |  |  | 20 | % |  |  | 19 | % |  |  | 16 | % |

[0001564590-17-012758:notes:263]
The following customers accounted for 10% or more of accounts receivable:

[0001564590-17-012758:notes:264]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Arrow Electronics, Inc. |  |  | 15 | % |  |  | 12 | % |
| Avnet, Inc. |  |  | 14 | % |  |  | 15 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-17-012758:notes:265]
17. Employee Benefits and Deferred Compensation

[0001564590-17-012758:notes:266]
Employee 401(k) Plan

[0001564590-17-012758:notes:267]
Our 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit. We match 100% of the first 2% of eligible earnings an employee contributes to the 401(k) Plan, and then match 50% of the next 4% of eligible earnings an employee contributes. An employee receives the full 4% match when he/she contributes at least 6% of his/her eligible earnings, up to a maximum calendar year matching contribution of $6,000. Our employer matching contributions to the 401(k) Plan were as follows (in millions):

[0001564590-17-012758:notes:268]
|  |  | Year Ended |  |
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| 401(k) matching contributions |  | $ | 30 |  |  | $ | 35 |  |  | $ | 16 |  |

[0001564590-17-012758:notes:269]
Deferred Compensation Plan

[0001564590-17-012758:notes:270]
We have a non-qualified deferred compensation plan that allows a group of employees within the U.S. to contribute base salary and commissions or incentive compensation on a tax deferred basis in excess of the IRS limits imposed on 401(k) plans. The marketable securities related to these investments are held in a Rabbi Trust. The related deferred compensation plan assets and liabilities under the non-qualified deferred compensation plan were as follows (in millions):

[0001564590-17-012758:notes:271]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Deferred compensation plan assets |  | $ | 31 |  |  | $ | 30 |  |
| Deferred compensation liabilities reported as: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 7 |  |  | $ | 5 |  |
| Other long-term liabilities |  | $ | 24 |  |  | $ | 25 |  |

[0001564590-17-012758:notes:272]
Postretirement Health Care Plan

[0001564590-17-012758:notes:273]
Certain of our executive officers are eligible to participate in our Executive Retirement Medical Plan (the ERM Plan). The ERM Plan provides, upon retirement, medical benefits beyond the COBRA maximum benefit period to a defined group of senior executives based on minimum age, years of service and position. The ERM Plan was unfunded as of April 29, 2016 and April 28, 2017, and there is no minimum funding requirement under the ERM Plan.

[0001564590-17-012758:notes:274]
In November 2016, we made certain amendments to the ERM Plan, which prior to amendment, provided group health insurance benefits to eligible retirees. Effective January 1, 2017, the amended ERM Plan provides each eligible retiree with a capped reimbursement of premiums for the period from January 1, 2017 through December 31, 2019. During the period from December 31, 2019 through December 31, 2021, participants in the ERM Plan will be eligible to receive a lump sum cash payment equal to two years of projected health care costs, or a prorated portion thereof, pursuant to the methodology set forth in the ERM Plan. Such payment will be made by us outside the ERM Plan as the ERM Plan is expected to terminate on December 31, 2019.

[0001564590-17-012758:notes:275]
These plan amendments resulted in a prior service credit adjustment, with the following impacts to our consolidated financial statements in fiscal 2017 (in millions):

[0001564590-17-012758:notes:276]
| Decrease in other long-term liabilities |  | $ | 23 |  |
| Decrease in deferred tax assets |  | $ | 9 |  |
| Other comprehensive income, net of taxes |  | $ | 14 |  |

[0001564590-17-012758:notes:277]
International Defined Benefit Plans

[0001564590-17-012758:notes:278]
We maintain various defined benefit plans to provide termination and postretirement benefits to certain eligible employees outside of the U.S. We also provide disability benefits to certain eligible employees in the U.S. Eligibility is determined based on the terms of our plans and local statutory requirements. Assumed discount rates and expected long-term returns on plan assets have significant effects on the amounts reported for the defined benefit plans.

[0001564590-17-012758:notes:279]
Funded Status

[0001564590-17-012758:notes:280]
The funded status of our postretirement health care and international termination and postretirement benefits was as follows (in millions):

[0001564590-17-012758:notes:281]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Fair value of plan assets |  | $ | 23 |  |  | $ | 24 |  |
| Benefit obligations |  |  | (50 | ) |  |  | (76 | ) |
| Unfunded obligations |  | $ | (27 | ) |  | $ | (52 | ) |

[0001564590-17-012758:notes:282]
Amounts recognized in the consolidated balance sheets were as follows (in millions):

[0001564590-17-012758:notes:283]
|  |  | April 28, 2017 |  |  | April 29, 2016 |  |
| Other long-term liabilities |  | $ | 27 |  |  | $ | 52 |  |
| AOCI |  | $ | — |  |  | $ | (16 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-17-012758:notes:284]
18. Commitments and Contingencies

[0001564590-17-012758:notes:285]
Operating Leases

[0001564590-17-012758:notes:286]
We lease various equipment, vehicles and office space in the U.S. and internationally.

[0001564590-17-012758:notes:287]
Future annual minimum lease payments under all non-cancelable operating leases with an initial term in excess of one year as of April 28, 2017 are as follows (in millions):

[0001564590-17-012758:notes:288]
|  |  |  | 2018 |  |  |  | 2019 |  |  |  | 2020 |  |  |  | 2021 |  |  |  | 2022 |  |  | Thereafter |  |  | Total |  |
| Operating lease commitments |  | $ | 55 |  |  | $ | 47 |  |  | $ | 37 |  |  | $ | 27 |  |  | $ | 19 |  |  | $ | 34 |  |  | $ | 219 |  |

[0001564590-17-012758:notes:289]
Rent expense under all cancellable and non-cancelable operating leases was $64 million, $69 million and $67 million in fiscal 2017, 2016 and 2015, respectively.

[0001564590-17-012758:notes:290]
Purchase Orders and Other Commitments

[0001564590-17-012758:notes:291]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of April 28, 2017, we had $343 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 28, 2017 and April 29, 2016, such liability amounted to $10 million and $7 million, respectively, and is included in accrued expenses in our consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-17-012758:notes:292]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of April 28, 2017, we had $16 million in construction related obligations and $232 million in other purchase obligations.

[0001564590-17-012758:notes:293]
During the ordinary course of business, we provide standby letters of credit or other guarantee instruments to third parties as required for certain transactions initiated either by us or our subsidiaries. As of April 28, 2017, our financial guarantees of $7 million that were not recorded on our consolidated balance sheets consisted primarily of standby letters of credit and surety bonds.

[0001564590-17-012758:notes:294]
Financing Guarantees

[0001564590-17-012758:notes:295]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $183 million, $243 million and $197 million of receivables during fiscal 2017, 2016 and 2015, respectively.

[0001564590-17-012758:notes:296]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-17-012758:notes:297]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of April 28, 2017, and April 29, 2016, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-17-012758:notes:298]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of April 28, 2017, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0001564590-17-012758:notes:299]
Indemnification Agreements

[0001564590-17-012758:notes:300]
We enter into standard indemnification agreements in the ordinary course of business. Pursuant to these agreements, we agree to defend and indemnify other parties, primarily our customers or business partners or subcontractors, for damages and reasonable costs incurred in any suit or claim brought against them alleging that our products sold to them infringe any U.S. patent, copyright, trade secret, or similar right. If a product becomes the subject of an infringement claim, we may, at our option: (i) replace the product with another non-infringing product that provides substantially similar performance; (ii) modify the infringing product so that it no longer infringes but remains functionally equivalent; (iii) obtain the right for the customer to continue using the product at our expense and for the reseller to continue selling the product; (iv) take back the infringing product and refund to the customer the purchase price paid less depreciation amortized on a straight-line basis. We have not been required to make material payments pursuant to these provisions historically. We have not recorded any liability at April 28, 2017 related to these guarantees since the maximum amount of potential future payments under such guarantees, indemnities and warranties is not determinable, other than as described above.

[0001564590-17-012758:notes:301]
Legal Contingencies

[0001564590-17-012758:notes:302]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-17-012758:notes:303]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of April 28, 2017 related to such matters as they are not probable and/or reasonably estimable.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001564590-17-012758:notes:304]
Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights.
