# NTAP notes — 0001564590-20-056069


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-20-056069:notes:1]
[same as prior period, unchanged from 0001564590-20-041759:notes:1]

[0001564590-20-056069:notes:2]
[same as prior period, unchanged from 0001564590-20-041759:notes:2]

[0001564590-20-056069:notes:3]
[same as prior period, unchanged from 0001564590-20-041759:notes:3]

[0001564590-20-056069:notes:4]
[same as prior period, unchanged from 0001564590-20-041759:notes:4]

[0001564590-20-056069:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2020 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 30, 2020 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-20-056069:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates. Management’s estimates include, as applicable, the anticipated impacts of the COVID-19 pandemic.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-20-056069:notes:7]
2. Recently Adopted Accounting Standards

[0001564590-20-056069:notes:8]
In June 2016, the FASB issued an accounting standards update on the measurement of credit losses on financial instruments. The standard introduces a new model for measuring and recognizing credit losses on financial instruments, requiring financial assets measured at amortized cost basis to be presented at the net amount expected to be collected. It also requires that credit losses be recorded through an allowance for credit losses. On April 25, 2020, we adopted the standard with no material impact to our condensed consolidated financial statements.

[0001564590-20-056069:notes:9]
There have been no other significant changes in our significant accounting policies as of and for the six months ended October 30, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 24, 2020.

[0001564590-20-056069:notes:10]
Recent accounting pronouncements pending adoption not discussed are either not applicable or will not have or are not expected to have a material impact on our consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-20-056069:notes:11]
[same as prior period, unchanged from 0001564590-20-041759:notes:11]

[0001564590-20-056069:notes:12]
[same as prior period, unchanged from 0001564590-20-041759:notes:12]

[0001564590-20-056069:notes:13]
[same as prior period, unchanged from 0001564590-20-041759:notes:13]

[0001564590-20-056069:notes:14]
[same as prior period, unchanged from 0001564590-20-041759:notes:14]

[0001564590-20-056069:notes:15]
[same as prior period, unchanged from 0001564590-20-041759:notes:15]

[0001564590-20-056069:notes:16]
[same as prior period, unchanged from 0001564590-20-041759:notes:16]

[0001564590-20-056069:notes:17]
[same as prior period, unchanged from 0001564590-20-041759:notes:17]

[0001564590-20-056069:notes:18]
| Cash |  | $ | 24 |  |
| Intangible assets |  |  | 84 |  |
| Goodwill |  |  | 249 |  |
| Other assets |  |  | 6 |  |
| Total assets acquired |  |  | 363 |  |
| Liabilities assumed |  |  | (23 | ) |
| Total purchase price |  | $ | 340 |  |

[0001564590-20-056069:notes:19]
[same as prior period, unchanged from 0001564590-20-041759:notes:19]

[0001564590-20-056069:notes:20]
[same as prior period, unchanged from 0001564590-20-041759:notes:20]

[0001564590-20-056069:notes:21]
[same as prior period, unchanged from 0001564590-20-041759:notes:21]

[0001564590-20-056069:notes:22]
The results of operations related to the acquisition of both Spot and Cloud Jumper have been included in our condensed consolidated statements of operations from their respective acquisition dates. Pro forma results of operations have not been presented

[0001564590-20-056069:notes:23]
because the impact from these acquisitions would not have been material to our consolidated results of operations for each of the three and six months ended October 30, 2020 and October 25, 2019.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-20-056069:notes:24]
[same as prior period, unchanged from 0001564590-20-041759:notes:23]

[0001564590-20-056069:notes:25]
[same as prior period, unchanged from 0001564590-20-041759:notes:24]

[0001564590-20-056069:notes:26]
| Balance as of April 24, 2020 |  | $ | 1,778 |  |
| Additions |  |  | 261 |  |
| Balance as of October 30, 2020 |  | $ | 2,039 |  |

[0001564590-20-056069:notes:27]
[same as prior period, unchanged from 0001564590-20-041759:notes:26]

[0001564590-20-056069:notes:28]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 215 |  |  | $ | (128 | ) |  | $ | 87 |  |  | $ | 192 |  |  | $ | (152 | ) |  | $ | 40 |  |
| Customer contracts/relationships |  |  | 38 |  |  |  | (3 | ) |  |  | 35 |  |  |  | 4 |  |  |  | — |  |  |  | 4 |  |
| Other purchased intangibles |  |  | 3 |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total purchased intangible assets |  | $ | 256 |  |  | $ | (131 | ) |  | $ | 125 |  |  | $ | 196 |  |  | $ | (152 | ) |  | $ | 44 |  |

[0001564590-20-056069:notes:29]
[same as prior period, unchanged from 0001564590-20-041759:notes:28]

[0001564590-20-056069:notes:30]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Statements of |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | Operations Classification |
| Developed technology |  | $ | 12 |  |  | $ | 11 |  |  | $ | 22 |  |  | $ | 22 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 3 |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  | Operating expenses |
| Total |  | $ | 15 |  |  | $ | 11 |  |  | $ | 25 |  |  | $ | 22 |  |  |  |

[0001564590-20-056069:notes:31]
As of October 30, 2020, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-20-056069:notes:32]
| Fiscal Year |  | Amount |  |
| Remainder of 2021 |  | $ | 23 |  |
| 2022 |  |  | 37 |  |
| 2023 |  |  | 29 |  |
| 2024 |  |  | 17 |  |
| 2025 |  |  | 16 |  |
| 2026 |  |  | 3 |  |
| Total |  | $ | 125 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-20-056069:notes:33]
[same as prior period, unchanged from 0001564590-20-041759:notes:32]

[0001564590-20-056069:notes:34]
[same as prior period, unchanged from 0001564590-20-041759:notes:33]

[0001564590-20-056069:notes:35]
[same as prior period, unchanged from 0001564590-20-041759:notes:34]

[0001564590-20-056069:notes:36]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Cash and cash equivalents |  | $ | 3,529 |  |  | $ | 2,658 |  |
| Restricted cash |  |  | 7 |  |  |  | 8 |  |
| Cash, cash equivalents and restricted cash |  | $ | 3,536 |  |  | $ | 2,666 |  |

[0001564590-20-056069:notes:37]
[same as prior period, unchanged from 0001564590-20-041759:notes:36]

[0001564590-20-056069:notes:38]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Purchased components |  | $ | 20 |  |  | $ | 28 |  |
| Finished goods |  |  | 96 |  |  |  | 117 |  |
| Inventories |  | $ | 116 |  |  | $ | 145 |  |

[0001564590-20-056069:notes:39]
[same as prior period, unchanged from 0001564590-20-041759:notes:38]

[0001564590-20-056069:notes:40]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Land |  | $ | 103 |  |  | $ | 103 |  |
| Buildings and improvements |  |  | 602 |  |  |  | 597 |  |
| Leasehold improvements |  |  | 91 |  |  |  | 89 |  |
| Computer, production, engineering and other equipment |  |  | 850 |  |  |  | 802 |  |
| Computer software |  |  | 359 |  |  |  | 359 |  |
| Furniture and fixtures |  |  | 109 |  |  |  | 106 |  |
| Construction-in-progress |  |  | 37 |  |  |  | 32 |  |
|  |  |  | 2,151 |  |  |  | 2,088 |  |
| Accumulated depreciation and amortization |  |  | (1,414 | ) |  |  | (1,361 | ) |
| Property and equipment, net |  | $ | 737 |  |  | $ | 727 |  |

[0001564590-20-056069:notes:41]
[same as prior period, unchanged from 0001564590-20-041759:notes:40]

[0001564590-20-056069:notes:42]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Deferred tax assets |  | $ | 225 |  |  | $ | 220 |  |
| Operating lease ROU assets |  |  | 129 |  |  |  | 137 |  |
| Other assets |  |  | 344 |  |  |  | 342 |  |
| Other non-current assets |  | $ | 698 |  |  | $ | 699 |  |

[0001564590-20-056069:notes:43]
Other non-current assets as of October 30, 2020 and April 24, 2020 included $69 million and $67 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited, a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019.

[0001564590-20-056069:notes:44]
[same as prior period, unchanged from 0001564590-20-041759:notes:43]

[0001564590-20-056069:notes:45]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Accrued compensation and benefits |  | $ | 376 |  |  | $ | 322 |  |
| Product warranty liabilities |  |  | 23 |  |  |  | 26 |  |
| Operating lease liabilities |  |  | 52 |  |  |  | 51 |  |
| Other current liabilities |  |  | 287 |  |  |  | 375 |  |
| Accrued expenses |  | $ | 738 |  |  | $ | 774 |  |

[0001564590-20-056069:notes:46]
[same as prior period, unchanged from 0001564590-20-041759:notes:45]

[0001564590-20-056069:notes:47]
[same as prior period, unchanged from 0001564590-20-041759:notes:46]

[0001564590-20-056069:notes:48]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Balance at beginning of period |  | $ | 37 |  |  | $ | 39 |  |  | $ | 41 |  |  | $ | 40 |  |
| Expense accrued during the period |  |  | 4 |  |  |  | 7 |  |  |  | 5 |  |  |  | 12 |  |
| Warranty costs incurred |  |  | (6 | ) |  |  | (6 | ) |  |  | (11 | ) |  |  | (12 | ) |
| Balance at end of period |  | $ | 35 |  |  | $ | 40 |  |  | $ | 35 |  |  | $ | 40 |  |

[0001564590-20-056069:notes:49]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Accrued expenses |  | $ | 23 |  |  | $ | 26 |  |
| Other long-term liabilities |  |  | 12 |  |  |  | 15 |  |
| Total warranty liabilities |  | $ | 35 |  |  | $ | 41 |  |

[0001564590-20-056069:notes:50]
[same as prior period, unchanged from 0001564590-20-041759:notes:49]

[0001564590-20-056069:notes:51]
[same as prior period, unchanged from 0001564590-20-041759:notes:50]

[0001564590-20-056069:notes:52]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Liability for uncertain tax positions |  | $ | 138 |  |  | $ | 136 |  |
| Income taxes payable |  |  | 351 |  |  |  | 399 |  |
| Product warranty liabilities |  |  | 12 |  |  |  | 15 |  |
| Operating lease liabilities |  |  | 84 |  |  |  | 93 |  |
| Other liabilities |  |  | 78 |  |  |  | 71 |  |
| Other long-term liabilities |  | $ | 663 |  |  | $ | 714 |  |

[0001564590-20-056069:notes:53]
[same as prior period, unchanged from 0001564590-20-041759:notes:52]

[0001564590-20-056069:notes:54]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Interest income |  | $ | 2 |  |  | $ | 12 |  |  | $ | 5 |  |  | $ | 31 |  |
| Interest expense |  |  | (18 | ) |  |  | (12 | ) |  |  | (36 | ) |  |  | (27 | ) |
| Other income (expense), net |  |  | 9 |  |  |  | 3 |  |  |  | (8 | ) |  |  | 14 |  |
| Total other income (expense), net |  | $ | (7 | ) |  | $ | 3 |  |  | $ | (39 | ) |  | $ | 18 |  |

[0001564590-20-056069:notes:55]
[same as prior period, unchanged from 0001564590-20-041759:notes:54]

[0001564590-20-056069:notes:56]
[same as prior period, unchanged from 0001564590-20-041759:notes:55]

[0001564590-20-056069:notes:57]
|  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 9 |  |  | $ | 6 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 238 |  |  | $ | 260 |  |
| Interest paid |  | $ | 23 |  |  | $ | 25 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-056069:notes:58]
[same as prior period, unchanged from 0001564590-20-041759:notes:57]

[0001564590-20-056069:notes:59]
[same as prior period, unchanged from 0001564590-20-041759:notes:58]

[0001564590-20-056069:notes:60]
[same as prior period, unchanged from 0001564590-20-041759:notes:59]

[0001564590-20-056069:notes:61]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Product revenues |  | $ | 749 |  |  | $ | 771 |  |  | $ | 1,376 |  |  | $ | 1,415 |  |
| Software maintenance revenues |  | 303 |  |  | 254 |  |  | 604 |  |  | 504 |  |
| Hardware maintenance and other services revenues |  | 364 |  |  | 346 |  |  |  | 739 |  |  |  | 688 |  |
| Hardware maintenance support contracts |  | 296 |  |  | 286 |  |  | 603 |  |  |  | 570 |  |
| Professional and other services |  | 68 |  |  | 60 |  |  | 136 |  |  |  | 118 |  |
| Net revenues |  | $ | 1,416 |  |  | $ | 1,371 |  |  | $ | 2,719 |  |  | $ | 2,607 |  |

[0001564590-20-056069:notes:62]
[same as prior period, unchanged from 0001564590-20-041759:notes:61]

[0001564590-20-056069:notes:63]
[same as prior period, unchanged from 0001564590-20-041759:notes:62]

[0001564590-20-056069:notes:64]
[same as prior period, unchanged from 0001564590-20-041759:notes:63]

[0001564590-20-056069:notes:65]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Deferred product revenue |  | $ | 39 |  |  | $ | 75 |  |
| Deferred services revenue |  |  | 3,554 |  |  |  | 3,567 |  |
| Financed unearned services revenue |  |  | 58 |  |  |  | 56 |  |
| Total |  | $ | 3,651 |  |  | $ | 3,698 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,815 |  |  | $ | 1,894 |  |
| Long-term |  |  | 1,836 |  |  |  | 1,804 |  |
| Total |  | $ | 3,651 |  |  | $ | 3,698 |  |

[0001564590-20-056069:notes:66]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 16 – Commitments and Contingencies for additional information related to these arrangements.

[0001564590-20-056069:notes:67]
[same as prior period, unchanged from 0001564590-20-041759:notes:66]

[0001564590-20-056069:notes:68]
|  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Balance at beginning of period |  | $ | 3,698 |  |  | $ | 3,668 |  |
| Additions |  |  | 1,364 |  |  |  | 1,011 |  |
| Revenue recognized during the period |  |  | (1,411 | ) |  |  | (1,211 | ) |
| Balance at end of period |  | $ | 3,651 |  |  | $ | 3,468 |  |

[0001564590-20-056069:notes:69]
During the six months ended October 30, 2020 and October 25, 2019, we recognized $1,207 million and $1,045 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001564590-20-056069:notes:70]
As of October 30, 2020, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,651 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 26% in the next 13 to 24 months, and the remainder thereafter.

[0001564590-20-056069:notes:71]
[same as prior period, unchanged from 0001564590-20-041759:notes:70]

[0001564590-20-056069:notes:72]
[same as prior period, unchanged from 0001564590-20-041759:notes:71]

[0001564590-20-056069:notes:73]
|  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Balance at beginning of period |  | $ | 156 |  |  | $ | 172 |  |
| Additions |  |  | 57 |  |  |  | 32 |  |
| Expense recognized during the period |  |  | (45 | ) |  |  | (50 | ) |
| Balance at end of period |  | $ | 168 |  |  | $ | 154 |  |

[0001564590-20-056069:notes:74]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Other current assets |  | $ | 70 |  |  | $ | 67 |  |
| Other non-current assets |  |  | 98 |  |  |  | 89 |  |
| Total deferred commissions |  | $ | 168 |  |  | $ | 156 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-20-056069:notes:75]
[same as prior period, unchanged from 0001564590-20-041759:notes:74]

[0001564590-20-056069:notes:76]
[same as prior period, unchanged from 0001564590-20-041759:notes:75]

[0001564590-20-056069:notes:77]
[same as prior period, unchanged from 0001564590-20-041759:notes:76]

[0001564590-20-056069:notes:78]
[same as prior period, unchanged from 0001564590-20-041759:notes:77]

[0001564590-20-056069:notes:79]
[same as prior period, unchanged from 0001564590-20-041759:notes:78]

[0001564590-20-056069:notes:80]
[same as prior period, unchanged from 0001564590-20-041759:notes:79]

[0001564590-20-056069:notes:81]
[same as prior period, unchanged from 0001564590-20-041759:notes:80]

[0001564590-20-056069:notes:82]
[same as prior period, unchanged from 0001564590-20-041759:notes:81]

[0001564590-20-056069:notes:83]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 99 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 101 |  |  | $ | 155 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 156 |  |
| U.S. Treasury and government debt securities |  |  | 16 |  |  |  | — |  |  |  | — |  |  |  | 16 |  |  |  | 68 |  |  |  | — |  |  |  | — |  |  |  | 68 |  |
| Certificates of deposit |  |  | 106 |  |  |  | — |  |  |  | — |  |  |  | 106 |  |  |  | 158 |  |  |  | — |  |  |  | — |  |  |  | 158 |  |
| Mutual funds |  |  | 37 |  |  |  | — |  |  |  | — |  |  |  | 37 |  |  |  | 33 |  |  |  | — |  |  |  | — |  |  |  | 33 |  |
| Total debt and equity securities |  | $ | 258 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 260 |  |  | $ | 414 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 415 |  |

[0001564590-20-056069:notes:84]
The following table presents the contractual maturities of our debt investments as of October 30, 2020 (in millions):

[0001564590-20-056069:notes:85]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 172 |  |  | $ | 173 |  |
| Due after one year through five years |  |  | 44 |  |  |  | 45 |  |
| Due after five years through ten years |  |  | 5 |  |  |  | 5 |  |
|  |  | $ | 221 |  |  | $ | 223 |  |

[0001564590-20-056069:notes:86]
[same as prior period, unchanged from 0001564590-20-041759:notes:85]

[0001564590-20-056069:notes:87]
[same as prior period, unchanged from 0001564590-20-041759:notes:86]

[0001564590-20-056069:notes:88]
[same as prior period, unchanged from 0001564590-20-041759:notes:87]

[0001564590-20-056069:notes:89]
|  |  | October 30, 2020 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 3,423 |  |  | $ | 3,423 |  |  | $ | — |  |
| Corporate bonds |  |  | 101 |  |  |  | — |  |  |  | 101 |  |
| U.S. Treasury and government debt securities |  |  | 16 |  |  |  | 3 |  |  |  | 13 |  |
| Certificates of deposit |  |  | 106 |  |  |  | — |  |  |  | 106 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,646 |  |  | $ | 3,426 |  |  | $ | 220 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 30 |  |  | $ | 30 |  |  | $ | — |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0001564590-20-056069:notes:90]
[same as prior period, unchanged from 0001564590-20-041759:notes:89]

[0001564590-20-056069:notes:91]
[same as prior period, unchanged from 0001564590-20-041759:notes:90]

[0001564590-20-056069:notes:92]
[same as prior period, unchanged from 0001564590-20-041759:notes:91]

[0001564590-20-056069:notes:93]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of October 30, 2020 and April 24, 2020, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-20-056069:notes:94]
[same as prior period, unchanged from 0001564590-20-041759:notes:93]

[0001564590-20-056069:notes:95]
As of October 30, 2020 and April 24, 2020, the fair value of our long-term debt was approximately $2,775 million and $1,176 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-20-056069:notes:96]
8. Financing Arrangements

[0001564590-20-056069:notes:97]
Long-Term Debt

[0001564590-20-056069:notes:98]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-20-056069:notes:99]
|  |  |  |  |  |  | October 30, 2020 |  |  | April 24, 2020 |  |
|  |  | Effective Interest Rate |  |  | Amount |  |  | Amount |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  | $ | — |  |  | $ | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | — |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | — |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | — |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 1,150 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (19 | ) |  |  | (4 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,631 |  |  | $ | 1,146 |  |

[0001564590-20-056069:notes:100]
Senior Notes

[0001564590-20-056069:notes:101]
In June 2020, we issued $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, for which we received total proceeds of approximately $2.0 billion, net of discount and issuance costs. Interest on these Senior Notes is payable semi-annually in June and December. On July 27, 2020, we extinguished our 3.375% Senior Notes due June 2021 for an aggregate cash redemption price of $513 million, plus accrued and unpaid interest. As part of the debt extinguishment, we recognized a loss of $14 million during the first quarter of fiscal 2021, which includes a cash redemption premium of $13 million and the write-off of unamortized discount and issuance costs totaling $1 million. The loss on extinguishment of debt is included in other income (expense), net in our Condensed Consolidated Statement of Operations for the six months ended October 30, 2020.

[0001564590-20-056069:notes:102]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September. Our 3.25% Senior Notes, with a principal amount of $250 million, were issued in December 2012 with interest paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-20-056069:notes:103]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 30, 2020, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-20-056069:notes:104]
As of October 30, 2020, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-20-056069:notes:105]
| Fiscal Year |  | Amount |  |
| 2023 |  | $ | 250 |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |

[0001564590-20-056069:notes:106]
Commercial Paper Program and Credit Facility

[0001564590-20-056069:notes:107]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. While no commercial paper notes were outstanding as of October 30, 2020, we had commercial paper notes outstanding with an aggregate principal amount of $523 million, a weighted-average interest rate of  2.01%, and maturities primarily less than three months as of April 24, 2020. During

[0001564590-20-056069:notes:108]
the first six months of fiscal 2021, we received proceeds of $75 million from the issuance, and made repayments of $176 million for the settlement, of commercial paper notes with original maturities greater than three months.

[0001564590-20-056069:notes:109]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of October 30, 2020 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0001564590-20-056069:notes:110]
[same as prior period, unchanged from 0001564590-20-041759:notes:109]

[0001564590-20-056069:notes:111]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of October 30, 2020, have remaining lease terms of up to 15 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of October 30, 2020, have remaining lease terms of up to 4 years. As of October 30, 2020, our automobile leases have remaining lease terms of up to 5 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0001564590-20-056069:notes:112]
[same as prior period, unchanged from 0001564590-20-041759:notes:111]

[0001564590-20-056069:notes:113]
[same as prior period, unchanged from 0001564590-20-041759:notes:112]

[0001564590-20-056069:notes:114]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Operating lease cost |  | $ | 14 |  |  | $ | 15 |  |  | $ | 28 |  |  | $ | 29 |  |
| Variable lease cost |  |  | 2 |  |  |  | 4 |  |  |  | 5 |  |  |  | 8 |  |
| Total lease cost |  | $ | 16 |  |  | $ | 19 |  |  | $ | 33 |  |  | $ | 37 |  |

[0001564590-20-056069:notes:115]
[same as prior period, unchanged from 0001564590-20-041759:notes:114]

[0001564590-20-056069:notes:116]
[same as prior period, unchanged from 0001564590-20-041759:notes:115]

[0001564590-20-056069:notes:117]
|  |  |  |  | Six Months Ended |  |
|  |  |  |  |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  |  |  |  |  | $ | 28 |  |  | $ | 29 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  |  |  |  |  | $ | 16 |  |  | $ | 21 |  |

[0001564590-20-056069:notes:118]
[same as prior period, unchanged from 0001564590-20-041759:notes:117]

[0001564590-20-056069:notes:119]
|  |  |  |  |  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Other non-current assets |  |  |  |  |  | $ | 129 |  |  | $ | 137 |  |
| Total operating lease ROU assets |  |  |  |  |  | $ | 129 |  |  | $ | 137 |  |
| Accrued expenses |  |  |  |  |  | $ | 52 |  |  | $ | 51 |  |
| Other long-term liabilities |  |  |  |  |  |  | 84 |  |  |  | 93 |  |
| Total operating lease liabilities |  |  |  |  |  | $ | 136 |  |  | $ | 144 |  |
| Weighted Average Remaining Lease Term |  |  |  |  |  | 3.5 years |  |  | 3.9 years |  |
| Weighted Average Discount Rate |  |  |  |  |  |  | 2.7 | % |  |  | 2.7 | % |

[0001564590-20-056069:notes:120]
Future minimum operating lease payments as of October 30, 2020, which exclude the undiscounted payments for the build-to-suit lease expected to commence in fiscal 2021, are as follows (in millions):

[0001564590-20-056069:notes:121]
|  |  |  |  |  |  | Operating Leases |  |
| Fiscal 2021 (remainder) |  |  |  |  |  | $ | 30 |  |
| Fiscal 2022 |  |  |  |  |  |  | 47 |  |
| Fiscal 2023 |  |  |  |  |  |  | 28 |  |
| Fiscal 2024 |  |  |  |  |  |  | 17 |  |
| Fiscal 2025 |  |  |  |  |  |  | 9 |  |
| Fiscal 2026 |  |  |  |  |  |  | 8 |  |
| Thereafter |  |  |  |  |  |  | 3 |  |
| Total lease payments |  |  |  |  |  | $ | 142 |  |
| Less: Interest |  |  |  |  |  |  | (6 | ) |
| Total |  |  |  |  |  | $ | 136 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-20-056069:notes:122]
[same as prior period, unchanged from 0001564590-20-041759:notes:121]

[0001564590-20-056069:notes:123]
[same as prior period, unchanged from 0001564590-20-041759:notes:122]

[0001564590-20-056069:notes:124]
As of October 30, 2020, we have certain equity incentive awards (awards) outstanding, which include stock options and restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs). Also outstanding are purchase rights under our Employee Stock Purchase Plan (ESPP).

[0001564590-20-056069:notes:125]
[same as prior period, unchanged from 0001564590-20-041759:notes:124]

[0001564590-20-056069:notes:126]
Less than 1 million options were outstanding as of October 30, 2020 and April 24, 2020.

[0001564590-20-056069:notes:127]
Information related to our stock options is summarized below (in millions):

[0001564590-20-056069:notes:128]
|  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Intrinsic value of exercises |  | $ | 1 |  |  | $ | 3 |  |
| Proceeds received from exercises |  | $ | 2 |  |  | $ | 2 |  |
| Fair value of options vested |  | $ | 1 |  |  | $ | — |  |

[0001564590-20-056069:notes:129]
[same as prior period, unchanged from 0001564590-20-041759:notes:126]

[0001564590-20-056069:notes:130]
In the six months ended October 30, 2020, we granted PBRSUs to certain of our executives. The PBRSUs have performance-based vesting criteria, in addition to the service based vesting criteria, such that the PBRSUs cliff-vest at the end of an approximate one, two or three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of  the first, second or third fiscal year, respectively following the grant date. The number of shares of common stock that will be issued to settle most of these PBRSUs at the end of the performance and service period, will range from 0% to 200% of a target number of shares originally granted. The number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. The fair values of these awards were fixed at grant date using a Monte Carlo simulation model. The aggregate grant date fair value of all PBRSUs granted in the current year was $25 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0001564590-20-056069:notes:131]
[same as prior period, unchanged from 0001564590-20-041759:notes:128]

[0001564590-20-056069:notes:132]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 24, 2020 |  |  | 7 |  |  | $ | 51.40 |  |
| Granted |  |  | 5 |  |  | $ | 39.44 |  |
| Vested |  |  | (2 | ) |  | $ | 44.21 |  |
| Forfeited |  |  | (1 | ) |  | $ | 52.26 |  |
| Outstanding as of October 30, 2020 |  |  | 9 |  |  | $ | 46.65 |  |

[0001564590-20-056069:notes:133]
[same as prior period, unchanged from 0001564590-20-041759:notes:130]

[0001564590-20-056069:notes:134]
|  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 34 |  |  | $ | 74 |  |

[0001564590-20-056069:notes:135]
[same as prior period, unchanged from 0001564590-20-041759:notes:132]

[0001564590-20-056069:notes:136]
[same as prior period, unchanged from 0001564590-20-041759:notes:133]

[0001564590-20-056069:notes:137]
|  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Shares issued under the ESPP |  |  | 1 |  |  |  | 1 |  |
| Proceeds from issuance of shares |  | $ | 47 |  |  | $ | 54 |  |

[0001564590-20-056069:notes:138]
[same as prior period, unchanged from 0001564590-20-041759:notes:135]

[0001564590-20-056069:notes:139]
[same as prior period, unchanged from 0001564590-20-041759:notes:136]

[0001564590-20-056069:notes:140]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |
| Cost of hardware maintenance and other services revenues |  |  | 2 |  |  |  | 3 |  |  |  | 5 |  |  |  | 5 |  |
| Sales and marketing |  |  | 24 |  |  |  | 17 |  |  |  | 49 |  |  |  | 35 |  |
| Research and development |  |  | 15 |  |  |  | 13 |  |  |  | 34 |  |  |  | 28 |  |
| General and administrative |  |  | 7 |  |  |  | 6 |  |  |  | 13 |  |  |  | 12 |  |
| Total stock-based compensation expense |  | $ | 49 |  |  | $ | 40 |  |  | $ | 103 |  |  | $ | 82 |  |
| Income tax benefit for stock-based compensation expense |  | $ | 8 |  |  | $ | 4 |  |  | $ | 12 |  |  | $ | 8 |  |

[0001564590-20-056069:notes:141]
As of October 30, 2020, total unrecognized compensation expense related to our equity awards was $398 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.5 years.

[0001564590-20-056069:notes:142]
[same as prior period, unchanged from 0001564590-20-041759:notes:139]

[0001564590-20-056069:notes:143]
As of October 30, 2020, our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time, and it was suspended in March 2020 due to the economic impact of the COVID-19 pandemic. Accordingly, no share repurchases were executed for the six months ended October 30, 2020.

[0001564590-20-056069:notes:144]
Since the May 13, 2003 inception of our stock repurchase program through October 30, 2020, we repurchased a total of 338 million shares of our common stock at an average price of $38.86 per share, for an aggregate purchase price of $13.1 billion. As of October 30, 2020, the remaining authorized amount for stock repurchases under this program was $477 million.

[0001564590-20-056069:notes:145]
[same as prior period, unchanged from 0001564590-20-041759:notes:142]

[0001564590-20-056069:notes:146]
[same as prior period, unchanged from 0001564590-20-041759:notes:143]

[0001564590-20-056069:notes:147]
|  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Dividends per share declared |  | $ | 0.96 |  |  | $ | 0.96 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 30 |  |  | $ | 226 |  |
| Dividend payments allocated to retained earnings |  | $ | 184 |  |  | $ | — |  |

[0001564590-20-056069:notes:148]
On November 23, 2020, we declared a cash dividend of $0.48 per share of common stock, payable on January 27, 2021 to holders of record as of the close of business on January 8, 2021. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-20-056069:notes:149]
[same as prior period, unchanged from 0001564590-20-041759:notes:146]

[0001564590-20-056069:notes:150]
[same as prior period, unchanged from 0001564590-20-041759:notes:147]

[0001564590-20-056069:notes:151]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 24, 2020 |  | $ | (42 | ) |  | $ | (1 | ) |  | $ | 1 |  |  | $ | — |  |  | $ | (42 | ) |
| Other comprehensive income (loss), net of tax |  |  | 9 |  |  |  | — |  |  |  | 1 |  |  |  | (8 | ) |  |  | 2 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 8 |  |  |  | 8 |  |
| Total other comprehensive income (loss) |  |  | 9 |  |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 10 |  |
| Balance as of October 30, 2020 |  | $ | (33 | ) |  | $ | (1 | ) |  | $ | 2 |  |  | $ | — |  |  | $ | (32 | ) |

[0001564590-20-056069:notes:152]
[same as prior period, unchanged from 0001564590-20-041759:notes:149]

[0001564590-20-056069:notes:153]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Classification |
| Recognized gains on defined benefit obligations |  | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |  | Operating expenses |
| Realized gains on available-for-sale securities |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (14 | ) |  | Other income (expense), net |
| Realized losses on cash flow hedges |  |  | 7 |  |  |  | — |  |  |  | 8 |  |  |  | — |  |  | Net revenues |
| Total reclassifications |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 8 |  |  | $ | (15 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-20-056069:notes:154]
[same as prior period, unchanged from 0001564590-20-041759:notes:151]

[0001564590-20-056069:notes:155]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of our agreements with them. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of October 30, 2020 or April 24, 2020. All contracts have a maturity of less than 12 months.

[0001564590-20-056069:notes:156]
[same as prior period, unchanged from 0001564590-20-041759:notes:153]

[0001564590-20-056069:notes:157]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 145 |  |  | $ | 124 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 378 |  |  | $ | 254 |  |
| Forward contracts purchased |  | $ | 111 |  |  | $ | 108 |  |

[0001564590-20-056069:notes:158]
[same as prior period, unchanged from 0001564590-20-041759:notes:155]

[0001564590-20-056069:notes:159]
[same as prior period, unchanged from 0001564590-20-041759:notes:156]

[0001564590-20-056069:notes:160]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
|  |  | Gain (Loss) Recognized in Income |  |  | Gain (Loss) Recognized in Income |  |
| Foreign currency exchange contracts |  | $ | (6 | ) |  | $ | — |  |  | $ | 17 |  |  | $ | (3 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-056069:notes:161]
[same as prior period, unchanged from 0001564590-20-041759:notes:158]

[0001564590-20-056069:notes:162]
In the second quarter of fiscal 2021, we committed to a restructuring plan (the August 2020 Plan) to optimize our business and fund our biggest opportunities. In connection with the plan, we reduced our global workforce by approximately 5%. Charges related to the plan consisted primarily of employee severance-related costs. We expect to complete substantially all activities related to this plan by the end of the third quarter of fiscal 2021.

[0001564590-20-056069:notes:163]
[same as prior period, unchanged from 0001564590-20-041759:notes:159]

[0001564590-20-056069:notes:164]
Management has previously approved several restructuring actions, including the May 2019 Plan and April 2019 Plan, under which we reduced our global workforce by approximately 2%, and approximately 1%, respectively. Charges related to these restructuring plans consisted primarily of employee severance-related costs. Substantially all activities under the May 2019 Plan were complete as of the end of the second quarter of fiscal 2020, and substantially all activities under the April 2019 Plan were complete as of the end of fiscal 2020.

[0001564590-20-056069:notes:165]
[same as prior period, unchanged from 0001564590-20-041759:notes:161]

[0001564590-20-056069:notes:166]
|  | Six Months Ended |  |  | Six Months Ended |  |
|  | October 30, 2020 |  |  | October 25, 2019 |  |
|  | August 2020 Plan |  | May 2020 Plan |  | May 2019 Plan |  | Total |  |  | May 2019 Plan |  | April 2019 Plan |  | November 2016 Plan |  | Total |  |
| Balance at beginning of period | $ | — |  | $ | — |  | $ | 1 |  | $ | 1 |  |  | $ | — |  | $ | 15 |  | $ | 4 |  | $ | 19 |  |
| Net charges |  | 37 |  |  | 5 |  |  | — |  |  | 42 |  |  |  | 21 |  |  | — |  |  | — |  |  | 21 |  |
| Cash payments |  | (18 | ) |  | (5 | ) |  | (1 | ) |  | (24 | ) |  |  | (19 | ) |  | (12 | ) |  | — |  |  | (31 | ) |
| Other |  | — |  |  | — |  |  | — |  |  | — |  |  |  | — |  |  | — |  |  | (4 | ) |  | (4 | ) |
| Balance at end of period | $ | 19 |  | $ | — |  | $ | — |  | $ | 19 |  |  | $ | 2 |  | $ | 3 |  | $ | — |  | $ | 5 |  |

[0001564590-20-056069:notes:167]
[same as prior period, unchanged from 0001564590-20-041759:notes:163]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-056069:notes:168]
[same as prior period, unchanged from 0001564590-20-041759:notes:164]

[0001564590-20-056069:notes:169]
[same as prior period, unchanged from 0001564590-20-041759:notes:165]

[0001564590-20-056069:notes:170]
|  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Effective tax rates |  |  | 23.3 | % |  |  | 17.2 | % |

[0001564590-20-056069:notes:171]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. The effective tax rate for the six months ended October 30, 2020 includes the impact of taxes resulting from the integration of acquired companies. The remaining differences in effective tax rates for the first six months of fiscal 2021 compared to the corresponding period of the prior year are primarily due to certain discrete expenses, including foreign audit results and differences in discrete tax benefits for stock-based compensation in fiscal 2021.

[0001564590-20-056069:notes:172]
As of October 30, 2020, we had $224 million of gross unrecognized tax benefits, of which $138 million has been recorded in other long-term liabilities. Inclusive of penalties, interest and certain income tax benefits, $138 million would affect our provision for income taxes if recognized.

[0001564590-20-056069:notes:173]
[same as prior period, unchanged from 0001564590-20-041759:notes:170]

[0001564590-20-056069:notes:174]
[same as prior period, unchanged from 0001564590-20-041759:notes:171]


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-056069:notes:175]
[same as prior period, unchanged from 0001564590-20-041759:notes:172]

[0001564590-20-056069:notes:176]
[same as prior period, unchanged from 0001564590-20-041759:notes:173]

[0001564590-20-056069:notes:177]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 137 |  |  | $ | 243 |  |  | $ | 214 |  |  | $ | 346 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 222 |  |  |  | 235 |  |  |  | 222 |  |  |  | 237 |  |
| Dilutive impact of employee equity award plans |  |  | 2 |  |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |
| Shares used in diluted computation |  |  | 224 |  |  |  | 236 |  |  |  | 223 |  |  |  | 240 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.62 |  |  | $ | 1.03 |  |  | $ | 0.96 |  |  | $ | 1.46 |  |
| Diluted |  | $ | 0.61 |  |  | $ | 1.03 |  |  | $ | 0.96 |  |  | $ | 1.44 |  |

[0001564590-20-056069:notes:178]
Eight million and seven million potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for the three and six months ended October 30, 2020, respectively, while six million and three million potential shares were excluded from the calculation for the three and six months ended October 25, 2019, respectively, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-056069:notes:179]
[same as prior period, unchanged from 0001564590-20-041759:notes:176]

[0001564590-20-056069:notes:180]
[same as prior period, unchanged from 0001564590-20-041759:notes:177]

[0001564590-20-056069:notes:181]
[same as prior period, unchanged from 0001564590-20-041759:notes:178]

[0001564590-20-056069:notes:182]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| United States, Canada and Latin America (Americas) |  | $ | 781 |  |  | $ | 771 |  |  | $ | 1,490 |  |  | $ | 1,406 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 422 |  |  |  | 402 |  |  |  | 805 |  |  |  | 804 |  |
| Asia Pacific (APAC) |  |  | 213 |  |  |  | 198 |  |  |  | 424 |  |  |  | 397 |  |
| Net revenues |  | $ | 1,416 |  |  | $ | 1,371 |  |  | $ | 2,719 |  |  | $ | 2,607 |  |

[0001564590-20-056069:notes:183]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $705 million and $703 million during the three months ended October 30, 2020 and October 25, 2019, respectively, and were $1,342 million and $1,277 million during the six months ended October 30, 2020 and October 25, 2019, respectively.

[0001564590-20-056069:notes:184]
[same as prior period, unchanged from 0001564590-20-041759:notes:181]

[0001564590-20-056069:notes:185]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| U.S. |  | $ | 1,442 |  |  | $ | 385 |  |
| International |  |  | 2,204 |  |  |  | 2,497 |  |
| Total |  | $ | 3,646 |  |  | $ | 2,882 |  |

[0001564590-20-056069:notes:186]
[same as prior period, unchanged from 0001564590-20-041759:notes:183]

[0001564590-20-056069:notes:187]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| U.S. |  | $ | 552 |  |  | $ | 540 |  |
| International |  |  | 185 |  |  |  | 187 |  |
| Total |  | $ | 737 |  |  | $ | 727 |  |

[0001564590-20-056069:notes:188]
[same as prior period, unchanged from 0001564590-20-041759:notes:185]

[0001564590-20-056069:notes:189]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Arrow Electronics, Inc. |  |  | 25 | % |  |  | 24 | % |  |  | 24 | % |  |  | 24 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 21 | % |  |  | 20 | % |  |  | 21 | % |

[0001564590-20-056069:notes:190]
The following customers accounted for 10% or more of accounts receivable:

[0001564590-20-056069:notes:191]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Arrow Electronics, Inc. |  |  | 12 | % |  |  | 13 | % |
| Tech Data Corporation |  |  | 18 | % |  |  | 19 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-056069:notes:192]
16. Commitments and Contingencies

[0001564590-20-056069:notes:193]
Purchase Orders and Other Commitments

[0001564590-20-056069:notes:194]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 30, 2020, we had $566 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 30, 2020 and April 24, 2020, such liability amounted to $10 million and $6 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-20-056069:notes:195]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 30, 2020, we had $192 million in other purchase obligations.

[0001564590-20-056069:notes:196]
Financing Guarantees

[0001564590-20-056069:notes:197]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $26 million and $34 million of receivables during the six months ended October 30, 2020 and October 25, 2019, respectively.

[0001564590-20-056069:notes:198]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-20-056069:notes:199]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of October 30, 2020 and April 24, 2020, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-20-056069:notes:200]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 30, 2020, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-20-056069:notes:201]
Legal Contingencies

[0001564590-20-056069:notes:202]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-20-056069:notes:203]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised

[0001564590-20-056069:notes:204]
financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. We believe the complaint is without merit and intend to defend the case vigorously.

[0001564590-20-056069:notes:205]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-20-056069:notes:206]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of October 30, 2020 related to such matters.
