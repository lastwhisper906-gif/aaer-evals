# NTAP 8-K — 0001564590-20-055739 filed 2020-12-01

## item codes, every 8-K on or before 2020-12-03

- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2020-12-03

- none on or before 2020-12-03

## item 2.02 — earnings release, exhibit 99.1

[0001564590-20-055739:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-20-055739:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-20-055739:8k_2_02:3]
Exhibit 99.1

[0001564590-20-055739:8k_2_02:4]
NetApp Reports Second Quarter of Fiscal Year 2021 Results

[0001564590-20-055739:8k_2_02:5]
Net Revenues of $1.42 Billion; Up 3% Year-over-Year

[0001564590-20-055739:8k_2_02:6]
| • | NetApp™ public cloud services annualized revenue run rate of $216 million, an increase of 200% year-over-year |  |

[0001564590-20-055739:8k_2_02:7]
| • | All-flash array annualized net revenue run rate of $2.5 billion, an increase of 15% year-over-year |  |

[0001564590-20-055739:8k_2_02:8]
| • | Billings1 of $1.46 billion, increased 10% year-over-year |  |

[0001564590-20-055739:8k_2_02:9]
| • | $107 million returned to shareholders in cash dividend |  |

[0001564590-20-055739:8k_2_02:10]
| • | Expanded hybrid cloud customer value proposition with industry-leading innovations |  |

[0001564590-20-055739:8k_2_02:11]
Sunnyvale, Calif.—December 1, 2020—NetApp (NASDAQ: NTAP) today reported financial results for the second quarter of fiscal year 2021, which ended on October 30, 2020.

[0001564590-20-055739:8k_2_02:12]
“In the second quarter, NetApp again delivered strong results, successfully executing against our plan to scale our cloud business while growing in the storage market. We also introduced significant new products and services which further advance our Data Fabric strategy,” said George Kurian, chief executive officer. “We are a primary beneficiary of the increasing importance of data and are uniquely positioned to help customers with their digital transformations. I am confident in our ability to drive long-term growth, extend our hybrid cloud leadership, and deliver value for customers, partners, and shareholders.”

[0001564590-20-055739:8k_2_02:13]
Second Quarter of Fiscal Year 2021 Financial Results

[0001564590-20-055739:8k_2_02:14]
| • | Net Revenues: $1.42 billion, compared to $1.37 billion in the second quarter of fiscal year 2020 |  |

[0001564590-20-055739:8k_2_02:15]
| • | Net Income: GAAP net income of $137 million, compared to GAAP net income of $243 million in the second quarter of fiscal year 2020; non-GAAP net income2 of $236 million, compared to non-GAAP net income of $257 million in the second quarter of fiscal year 2020 |  |

[0001564590-20-055739:8k_2_02:16]
| • | Earnings per Share: GAAP net income per share3 of $0.61 compared to GAAP net income per share of $1.03 in the second quarter of fiscal year 2020; non-GAAP net income per share of $1.05, compared to non-GAAP net income per share of $1.09 in the second quarter of fiscal year 2020 |  |

[0001564590-20-055739:8k_2_02:17]
| • | Cash, Cash Equivalents and Investments: $3.65 billion at the end of the second quarter of fiscal year 2021 |  |

[0001564590-20-055739:8k_2_02:18]
| • | Cash Provided By (Used In) Operations: $161 million, compared to $(53) million in the second quarter of fiscal year 2020 |  |

[0001564590-20-055739:8k_2_02:19]
| • | Dividend: Returned $107 million to shareholders through cash dividend |  |

[0001564590-20-055739:8k_2_02:20]
Third Quarter of Fiscal Year 2021 Financial Outlook

[0001564590-20-055739:8k_2_02:21]
The company provided the following financial guidance for the third quarter of fiscal year 2021:

[0001564590-20-055739:8k_2_02:22]
| Net revenues are expected to be in the range of: | $1.34 billion to $1.49 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $0.67 - $0.75 | $0.94 - $1.02 |

[0001564590-20-055739:8k_2_02:23]
Dividend

[0001564590-20-055739:8k_2_02:24]
The next cash dividend of $0.48 per share is to be paid on January 27, 2021, to shareholders of record as of the close of business on January 8, 2021.

[0001564590-20-055739:8k_2_02:25]
Second Quarter of Fiscal Year 2021 Business Highlights

[0001564590-20-055739:8k_2_02:26]
Delivering Innovation with Industry-Leading Products and Services

[0001564590-20-055739:8k_2_02:27]
| • | NetApp introduced updated software data services to bring the simplicity and flexibility of the cloud to the data center. These updates enable enterprises to accelerate their digital transformation by easily building and optimizing applications across cloud and on-premises environments. New features and capabilities include: |

[0001564590-20-055739:8k_2_02:28]
|  | • | NetApp ONTAP™ 9.8 software capabilities offer greater consolidation, deeper cloud integration, and continuous data availability for improved simplicity, efficiency, and protection of business-critical enterprise applications. |

[0001564590-20-055739:8k_2_02:29]
|  | • | Updates to NetApp Keystone™ Flex Subscription provide a fast, flexible path to a cloud-enabled data center with “pay-as-you-grow” subscriptions for a cloudlike experience on premises. |

[0001564590-20-055739:8k_2_02:30]
|  | • | The new NetApp SolidFire™ Enterprise SDS solution provides a simple and automated foundation for private cloud with NetApp Element™ software as standalone software-defined storage that can be deployed on industry-standard hardware. |

[0001564590-20-055739:8k_2_02:31]
| • | NetApp announced new services to bring optimization and enterprise data services to the cloud. These new capabilities help simplify and optimize multicloud management for the highest performance at a low cost, offering true portability for data-rich cloud applications and delivering comprehensive workplace solutions across hybrid cloud environments. New features and capabilities include: |

[0001564590-20-055739:8k_2_02:32]
|  | • | A groundbreaking serverless and storageless solution for containers, Spot Storage by NetApp, combined with Spot Ocean by NetApp, makes it easy for organizations build, deploy, and run microservice-based applications on Kubernetes without having to administer storage. |

[0001564590-20-055739:8k_2_02:33]
|  | • | NetApp Cloud Manager offers full visibility and control across on-premises, Azure, AWS, and Google Cloud storage and delivers an easy, native cloud experience for advanced data services: data sync, data backup, data tiering, file caching, and compliance. |

[0001564590-20-055739:8k_2_02:34]
|  | • | New, fully managed, cloud-based NetApp Virtual Desktop Management Service (VDMS) and a new validated hybrid cloud virtual desktop infrastructure (VDI) design to help organizations scale their infrastructure resources to meet the growing needs of their remote workforce. |

[0001564590-20-055739:8k_2_02:35]
| • | NetApp unveiled new storage platforms that further extend the industry’s broadest portfolio of all-flash, hybrid-flash, and object storage systems. New platforms include: |

[0001564590-20-055739:8k_2_02:36]
|  | • | AFF A250, a brand-new, entry-level, end-to-end NVMe system, has embedded NVMe SSDs on the back end and NVMe/FC host connectivity on the front end. |

[0001564590-20-055739:8k_2_02:37]
|  | • | Refreshed AFF A700, now an end-to-end NVMe system, supports NVMe SSDs on the back end, with two new high-speed I/Os added for host connections: 100GbE and 25GbE. |

[0001564590-20-055739:8k_2_02:38]
|  | • | AFF A800 All-SAN Array is designed for enterprise organizations that require dedicated storage for SAN workloads. |

[0001564590-20-055739:8k_2_02:39]
|  | • | FAS500f, a new rack-dense 2U form factor, supports dual controllers and up to 367TB of base flash capacity. |

[0001564590-20-055739:8k_2_02:40]
|  | • | Entry-level EF300, an end-to-end NVMe storage system, delivers affordable, high-performance storage. |

[0001564590-20-055739:8k_2_02:41]
| • | NetApp introduced new, validated FlexPod™ solutions from NetApp and Cisco, including FlexPod for Medical Imaging, SAP Data Hub with Cisco Container Platform (CCP) on FlexPod, FlexPod Monitoring with Cloud Insights, SAP HANA solution on Fibre Channel for FlexPod, FlexPod-verified SAP applications (non-HANA) on Oracle and SQL Server, and FlexPod running on Red Hat OpenShift. |

[0001564590-20-055739:8k_2_02:42]
| • | NetApp released the NetApp ONTAP AI reference architecture, utilizing NVDIAI DGX A100, offering compute density, performance, and flexibility in the world’s first 5 petaflops AI system. |

[0001564590-20-055739:8k_2_02:43]
| • | NetApp announced the expansion of NetApp Cloud Volumes Service for Google Cloud to thirteen regions globally. |

[0001564590-20-055739:8k_2_02:44]
| • | Additional innovations announced include: |

[0001564590-20-055739:8k_2_02:45]
|  | • | NetApp Hybrid Cloud Control 2.14 manageability suite makes day-to-day NetApp HCI and SolidFire operations easier with a streamlined user experience. |

[0001564590-20-055739:8k_2_02:46]
|  | • | NetApp HCI Pre-Install Validation Tool in Active IQ Config Advisor helps determine the readiness of the customer’s network when installing NetApp HCI. |

[0001564590-20-055739:8k_2_02:47]
|  | • | Active IQ Unified Manager ServiceNow Integration helps customers develop workflows on ServiceNow. |

[0001564590-20-055739:8k_2_02:48]
|  | • | SnapDiff™ v3 backup architecture efficiently backs up NAS data to both on-premises and cloud object storage across the data fabric. |

[0001564590-20-055739:8k_2_02:49]
Strengthening Partnerships

[0001564590-20-055739:8k_2_02:50]
| • | Our growing partnership with Microsoft enables our joint customers to take advantage of NetApp’s industry leading technologies. Microsoft recently announced several new capabilities and new regions for Azure NetApp Files, including Azure Government Regions. |

[0001564590-20-055739:8k_2_02:51]
| • | With the support of NetApp, Dentsu Aegis Network announced that it has successfully completed its ambitious plan of going cloud native in 2 years. |

[0001564590-20-055739:8k_2_02:52]
| • | NetApp and Run:AI partnered to streamline the process of both data pipelines and machine scheduling for deep learning for customers using NetApp ONTAP AI. |

[0001564590-20-055739:8k_2_02:53]
| • | NetApp and IBM partnered to offer up to 180,000 IOPS of NetApp-based storage in the cloud to deliver high levels of performance, resilience, and reliability. |

[0001564590-20-055739:8k_2_02:54]
NetApp Recognition

[0001564590-20-055739:8k_2_02:55]
| • | For the second year in a row, NetApp won the coveted AI Breakthrough Award for the Best Machine Learning Platform, with its partner Lenovo. |

[0001564590-20-055739:8k_2_02:56]
Webcast and Conference Call Information

[0001564590-20-055739:8k_2_02:57]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:00 p.m. Pacific Time today.

[0001564590-20-055739:8k_2_02:58]
most recently submitted annual report on Form 10-K and quarterly report on Form 10-Q. We disclaim any obligation to update information contained in this press release whether as a result of new information, future events, or otherwise.

[0001564590-20-055739:8k_2_02:59]
###

[0001564590-20-055739:8k_2_02:60]
NetApp, the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001564590-20-055739:8k_2_02:61]
Footnotes

[0001564590-20-055739:8k_2_02:62]
1Refer to the NetApp Usage of Non-GAAP Financial Information section below for an explanation of billings.

[0001564590-20-055739:8k_2_02:63]
2Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) gains/losses on the sale of investments in equity securities, (i) debt extinguishment costs, (j) COVID-19 charges and (k) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-20-055739:8k_2_02:64]
3GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0001564590-20-055739:8k_2_02:65]
NetApp Usage of Non-GAAP Financial Information

[0001564590-20-055739:8k_2_02:66]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share. NetApp also presents the hardware and software components of our GAAP product revenues. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0001564590-20-055739:8k_2_02:67]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations.

[0001564590-20-055739:8k_2_02:68]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-20-055739:8k_2_02:69]
NetApp believes that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0001564590-20-055739:8k_2_02:70]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it represents the amounts under purchase orders received by us during a given period that have been billed.

[0001564590-20-055739:8k_2_02:71]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-20-055739:8k_2_02:72]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-20-055739:8k_2_02:73]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-20-055739:8k_2_02:74]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-20-055739:8k_2_02:75]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-20-055739:8k_2_02:76]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-20-055739:8k_2_02:77]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-20-055739:8k_2_02:78]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-20-055739:8k_2_02:79]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-20-055739:8k_2_02:80]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-20-055739:8k_2_02:81]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-20-055739:8k_2_02:82]
J. COVID-19 charges. NetApp has excluded certain non-recurring expenses incurred as a direct result of the COVID-19 pandemic. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-20-055739:8k_2_02:83]
K. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-20-055739:8k_2_02:84]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-20-055739:8k_2_02:85]
About NetApp

[0001564590-20-055739:8k_2_02:86]
NetApp is a global cloud-led, data-centric software company that empowers organizations to lead with data in the age of accelerated digital transformation. The company provides systems, software, and cloud services that enable them to run their applications optimally from data center to cloud, whether they are developing in the cloud, moving to the cloud, or creating their own cloudlike experiences on premises. With solutions that perform across diverse environments, NetApp helps organizations build their own data fabric and securely deliver the right data, services, and applications to the right people—anytime, anywhere. Learn more at www.netapp.com or follow us on Twitter, LinkedIn, Facebook, and Instagram.

[0001564590-20-055739:8k_2_02:87]
NETAPP, INC.

[0001564590-20-055739:8k_2_02:88]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-20-055739:8k_2_02:89]
(In millions)

[0001564590-20-055739:8k_2_02:90]
(Unaudited)

[0001564590-20-055739:8k_2_02:91]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,646 |  |  | $ | 2,882 |  |
| Accounts receivable |  |  | 796 |  |  |  | 973 |  |
| Inventories |  |  | 116 |  |  |  | 145 |  |
| Other current assets |  |  | 263 |  |  |  | 274 |  |
| Total current assets |  |  | 4,821 |  |  |  | 4,274 |  |
| Property and equipment, net |  |  | 737 |  |  |  | 727 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,164 |  |  |  | 1,822 |  |
| Other non-current assets |  |  | 698 |  |  |  | 699 |  |
| Total assets |  | $ | 8,420 |  |  | $ | 7,522 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 367 |  |  | $ | 426 |  |
| Accrued expenses |  |  | 738 |  |  |  | 774 |  |
| Commercial paper notes |  |  | — |  |  |  | 522 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,815 |  |  |  | 1,894 |  |
| Total current liabilities |  |  | 2,920 |  |  |  | 3,616 |  |
| Long-term debt |  |  | 2,631 |  |  |  | 1,146 |  |
| Other long-term liabilities |  |  | 663 |  |  |  | 714 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,836 |  |  |  | 1,804 |  |
| Total liabilities |  |  | 8,050 |  |  |  | 7,280 |  |
| Stockholders' equity |  |  | 370 |  |  |  | 242 |  |
| Total liabilities and stockholders' equity |  | $ | 8,420 |  |  | $ | 7,522 |  |

[0001564590-20-055739:8k_2_02:92]
NETAPP, INC.

[0001564590-20-055739:8k_2_02:93]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-20-055739:8k_2_02:94]
(In millions, except per share amounts)

[0001564590-20-055739:8k_2_02:95]
(Unaudited)

[0001564590-20-055739:8k_2_02:96]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 749 |  |  | $ | 771 |  |  | $ | 1,376 |  |  | $ | 1,415 |  |
| Software maintenance |  |  | 303 |  |  |  | 254 |  |  |  | 604 |  |  |  | 504 |  |
| Hardware maintenance and other services |  |  | 364 |  |  |  | 346 |  |  |  | 739 |  |  |  | 688 |  |
| Net revenues |  |  | 1,416 |  |  |  | 1,371 |  |  |  | 2,719 |  |  |  | 2,607 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 360 |  |  |  | 341 |  |  |  | 676 |  |  |  | 653 |  |
| Cost of software maintenance |  |  | 24 |  |  |  | 11 |  |  |  | 39 |  |  |  | 21 |  |
| Cost of hardware maintenance and other services |  |  | 99 |  |  |  | 94 |  |  |  | 199 |  |  |  | 192 |  |
| Total cost of revenues |  |  | 483 |  |  |  | 446 |  |  |  | 914 |  |  |  | 866 |  |
| Gross profit |  |  | 933 |  |  |  | 925 |  |  |  | 1,805 |  |  |  | 1,741 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 432 |  |  |  | 389 |  |  |  | 861 |  |  |  | 794 |  |
| Research and development |  |  | 212 |  |  |  | 209 |  |  |  | 445 |  |  |  | 424 |  |
| General and administrative |  |  | 67 |  |  |  | 69 |  |  |  | 128 |  |  |  | 140 |  |
| Restructuring charges |  |  | 37 |  |  |  | — |  |  |  | 42 |  |  |  | 21 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | — |  |  |  | 11 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (38 | ) |  |  | — |  |  |  | (38 | ) |
| Total operating expenses |  |  | 751 |  |  |  | 629 |  |  |  | 1,487 |  |  |  | 1,341 |  |
| Income from operations |  |  | 182 |  |  |  | 296 |  |  |  | 318 |  |  |  | 400 |  |
| Other income (expense), net |  |  | (7 | ) |  |  | 3 |  |  |  | (39 | ) |  |  | 18 |  |
| Income before income taxes |  |  | 175 |  |  |  | 299 |  |  |  | 279 |  |  |  | 418 |  |
| Provision for income taxes |  |  | 38 |  |  |  | 56 |  |  |  | 65 |  |  |  | 72 |  |
| Net income |  | $ | 137 |  |  | $ | 243 |  |  | $ | 214 |  |  | $ | 346 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.62 |  |  | $ | 1.03 |  |  | $ | 0.96 |  |  | $ | 1.46 |  |
| Diluted |  | $ | 0.61 |  |  | $ | 1.03 |  |  | $ | 0.96 |  |  | $ | 1.44 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 222 |  |  |  | 235 |  |  |  | 222 |  |  |  | 237 |  |
| Diluted |  |  | 224 |  |  |  | 236 |  |  |  | 223 |  |  |  | 240 |  |

[0001564590-20-055739:8k_2_02:97]
NETAPP, INC.

[0001564590-20-055739:8k_2_02:98]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-20-055739:8k_2_02:99]
(In millions)

[0001564590-20-055739:8k_2_02:100]
(Unaudited)

[0001564590-20-055739:8k_2_02:101]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 137 |  |  | $ | 243 |  |  | $ | 214 |  |  | $ | 346 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 56 |  |  |  | 50 |  |  |  | 105 |  |  |  | 99 |  |
| Non-cash operating lease cost |  |  | 13 |  |  |  | 13 |  |  |  | 26 |  |  |  | 26 |  |
| Stock-based compensation |  |  | 49 |  |  |  | 40 |  |  |  | 103 |  |  |  | 82 |  |
| Deferred income taxes |  |  | — |  |  |  | (16 | ) |  |  | — |  |  |  | (23 | ) |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (38 | ) |  |  | — |  |  |  | (38 | ) |
| Other items, net |  |  | 3 |  |  |  | (6 | ) |  |  | 28 |  |  |  | (13 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (194 | ) |  |  | (237 | ) |  |  | 197 |  |  |  | 435 |  |
| Inventories |  |  | 20 |  |  |  | 5 |  |  |  | 29 |  |  |  | 20 |  |
| Accounts payable |  |  | (30 | ) |  |  | 38 |  |  |  | (59 | ) |  |  | (157 | ) |
| Accrued expenses |  |  | 117 |  |  |  | (38 | ) |  |  | (69 | ) |  |  | (315 | ) |
| Deferred revenue and financed unearned services revenue |  |  | 40 |  |  |  | (43 | ) |  |  | (118 | ) |  |  | (197 | ) |
| Long-term taxes payable |  |  | (52 | ) |  |  | (46 | ) |  |  | (46 | ) |  |  | (49 | ) |
| Changes in other operating assets and liabilities, net |  |  | 2 |  |  |  | (18 | ) |  |  | (9 | ) |  |  | 41 |  |
| Net cash provided by (used in) operating activities |  |  | 161 |  |  |  | (53 | ) |  |  | 401 |  |  |  | 257 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 22 |  |  |  | 119 |  |  |  | 107 |  |  |  | 1,146 |  |
| Purchases of property and equipment |  |  | (40 | ) |  |  | (36 | ) |  |  | (92 | ) |  |  | (68 | ) |
| Proceeds from sale of properties |  |  | — |  |  |  | 96 |  |  |  | 6 |  |  |  | 96 |  |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | — |  |  |  | (350 | ) |  |  | (56 | ) |
| Other investing activities, net |  |  | 8 |  |  |  | (1 | ) |  |  | 8 |  |  |  | (2 | ) |
| Net cash provided by (used in) investing activities |  |  | (10 | ) |  |  | 178 |  |  |  | (321 | ) |  |  | 1,116 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 1 |  |  |  | 1 |  |  |  | 49 |  |  |  | 55 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (1 | ) |  |  | (3 | ) |  |  | (34 | ) |  |  | (74 | ) |
| Repurchase of common stock |  |  | — |  |  |  | (500 | ) |  |  | — |  |  |  | (750 | ) |
| Proceeds from (repayments of) commercial paper notes, original maturities of three months or less, net |  |  | (50 | ) |  |  | 468 |  |  |  | (420 | ) |  |  | 249 |  |
| Issuance of debt, net of issuance costs |  |  | — |  |  |  | — |  |  |  | 2,057 |  |  |  | — |  |
| Repayments and extinguishment of debt |  |  | (100 | ) |  |  | (400 | ) |  |  | (689 | ) |  |  | (400 | ) |
| Dividends paid |  |  | (107 | ) |  |  | (111 | ) |  |  | (214 | ) |  |  | (226 | ) |
| Other financing activities, net |  |  | — |  |  |  | — |  |  |  | (3 | ) |  |  | (2 | ) |
| Net cash provided by (used in) financing activities |  |  | (257 | ) |  |  | (545 | ) |  |  | 746 |  |  |  | (1,148 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 1 |  |  |  | (2 | ) |  |  | 44 |  |  |  | (5 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | (105 | ) |  |  | (422 | ) |  |  | 870 |  |  |  | 220 |  |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 3,641 |  |  |  | 2,973 |  |  |  | 2,666 |  |  |  | 2,331 |  |
| End of period |  | $ | 3,536 |  |  | $ | 2,551 |  |  | $ | 3,536 |  |  | $ | 2,551 |  |

[0001564590-20-055739:8k_2_02:102]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q2'FY21 |  |  | Q1'FY21 |  |  | Q2'FY20 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 749 |  |  | $ | 627 |  |  | $ | 771 |  |
| Software Maintenance |  | $ | 303 |  |  | $ | 301 |  |  | $ | 254 |  |
| Hardware Maintenance & Other Services |  | $ | 364 |  |  | $ | 375 |  |  | $ | 346 |  |
| Hardware Maintenance Support Contracts |  | $ | 296 |  |  | $ | 307 |  |  | $ | 286 |  |
| Professional and Other Services |  | $ | 68 |  |  | $ | 68 |  |  | $ | 60 |  |
| Net Revenues |  | $ | 1,416 |  |  | $ | 1,303 |  |  | $ | 1,371 |  |
| Product Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 749 |  |  | $ | 627 |  |  | $ | 771 |  |
| Software* |  | $ | 417 |  |  | $ | 311 |  |  | $ | 366 |  |
| Hardware* |  | $ | 332 |  |  | $ | 316 |  |  | $ | 405 |  |
| * Our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation. We have provided a breakdown of our GAAP product revenues into the software and hardware components to display the significance of software included in total product revenues. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'21 Revenue |  |  | % of Q1 FY'21 Revenue |  |  | % of Q2 FY'20 Revenue |  |
| Americas |  |  | 55 | % |  |  | 54 | % |  |  | 56 | % |
| Americas Commercial |  |  | 40 | % |  |  | 43 | % |  |  | 42 | % |
| U.S. Public Sector |  |  | 15 | % |  |  | 12 | % |  |  | 14 | % |
| EMEA |  |  | 30 | % |  |  | 29 | % |  |  | 29 | % |
| Asia Pacific |  |  | 15 | % |  |  | 16 | % |  |  | 14 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'21 Revenue |  |  | % of Q1 FY'21 Revenue |  |  | % of Q2 FY'20 Revenue |  |
| Direct |  |  | 25 | % |  |  | 22 | % |  |  | 21 | % |
| Indirect |  |  | 75 | % |  |  | 78 | % |  |  | 79 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY21 |  |  | Q1'FY21 |  |  | Q2'FY20 |  |
| Non-GAAP Gross Margin |  |  | 66.9 | % |  |  | 68.0 | % |  |  | 68.6 | % |
| Product |  |  | 53.0 | % |  |  | 51.4 | % |  |  | 57.3 | % |
| Software Maintenance |  |  | 93.7 | % |  |  | 95.0 | % |  |  | 95.7 | % |
| Hardware Maintenance & Other Services |  |  | 73.4 | % |  |  | 74.1 | % |  |  | 73.7 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY21 |  |  | Q1'FY21 |  |  | Q2'FY20 |  |
| Non-GAAP Income from Operations |  | $ | 291 |  |  | $ | 213 |  |  | $ | 309 |  |
| % of Net Revenues |  |  | 20.6 | % |  |  | 16.3 | % |  |  | 22.5 | % |
| Non-GAAP Income before Income Taxes |  | $ | 278 |  |  | $ | 195 |  |  | $ | 312 |  |
| Non-GAAP Effective Tax Rate |  |  | 15.1 | % |  |  | 16.4 | % |  |  | 17.6 | % |

[0001564590-20-055739:8k_2_02:103]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY21 |  |  | Q1'FY21 |  |  | Q2'FY20 |  |
| Non-GAAP Net Income |  | $ | 236 |  |  | $ | 163 |  |  | $ | 257 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 224 |  |  |  | 222 |  |  |  | 236 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.05 |  |  | $ | 0.73 |  |  | $ | 1.09 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY21 |  |  | Q1'FY21 |  |  | Q2'FY20 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,651 |  |  | $ | 3,620 |  |  | $ | 3,468 |  |
| DSO (days) |  |  | 51 |  |  |  | 45 |  |  |  | 52 |  |
| DPO (days) |  |  | 69 |  |  |  | 90 |  |  |  | 78 |  |
| Inventory Turns |  |  | 17 |  |  |  | 13 |  |  |  | 16 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY21 |  |  | Q1'FY21 |  |  | Q2'FY20 |  |
| Net Cash Provided by (used in) Operating Activities |  | $ | 161 |  |  | $ | 240 |  |  | $ | (53 | ) |
| Purchases of Property and Equipment |  | $ | 40 |  |  | $ | 52 |  |  | $ | 36 |  |
| Free Cash Flow |  | $ | 121 |  |  | $ | 188 |  |  | $ | (89 | ) |
| Free Cash Flow as % of Net Revenues |  |  | 8.5 | % |  |  | 14.4 | % |  |  | (6.5 | )% |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |

[0001564590-20-055739:8k_2_02:104]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY21 |  | Q1'FY21 |  | Q2'FY20 |  |
| NET INCOME |  | $ | 137 |  | $ | 77 |  | $ | 243 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 15 |  |  | 10 |  |  | 11 |  |
| Stock-based compensation |  |  | 49 |  |  | 54 |  |  | 40 |  |
| Litigation settlements |  |  | 5 |  |  | — |  |  | — |  |
| Restructuring charges |  |  | 37 |  |  | 5 |  |  | — |  |
| Acquisition-related expense |  |  | 3 |  |  | 8 |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | — |  |  | — |  |  | (38 | ) |
| Gain on sale of equity investment |  |  | (6 | ) |  | — |  |  | — |  |
| Debt extinguishment costs |  |  | — |  |  | 14 |  |  | — |  |
| Income tax effects |  |  | (9 | ) |  | (16 | ) |  | 1 |  |
| Income tax expenses from integration of acquired companies |  |  | 5 |  |  | 11 |  |  | — |  |
| NON-GAAP NET INCOME |  | $ | 236 |  | $ | 163 |  | $ | 257 |  |
| COST OF REVENUES |  | $ | 483 |  | $ | 431 |  | $ | 446 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (12 | ) |  | (10 | ) |  | (11 | ) |
| Stock-based compensation |  |  | (3 | ) |  | (4 | ) |  | (4 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 468 |  | $ | 417 |  | $ | 431 |  |
| COST OF PRODUCT REVENUES |  | $ | 360 |  | $ | 316 |  | $ | 341 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  | (10 | ) |  | (11 | ) |
| Stock-based compensation |  |  | (1 | ) |  | (1 | ) |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 352 |  | $ | 305 |  | $ | 329 |  |
| COST OF SOFTWARE MAINTENANCE REVENUES |  | $ | 24 |  | $ | 15 |  | $ | 11 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  | — |  |  | — |  |
| NON-GAAP COST OF SOFTWARE MAINTENANCE REVENUES |  | $ | 19 |  | $ | 15 |  | $ | 11 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 99 |  | $ | 100 |  | $ | 94 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  | (3 | ) |  | (3 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 97 |  | $ | 97 |  | $ | 91 |  |
| GROSS PROFIT |  | $ | 933 |  | $ | 872 |  | $ | 925 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 12 |  |  | 10 |  |  | 11 |  |
| Stock-based compensation |  |  | 3 |  |  | 4 |  |  | 4 |  |
| NON-GAAP GROSS PROFIT |  | $ | 948 |  | $ | 886 |  | $ | 940 |  |

[0001564590-20-055739:8k_2_02:105]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY21 |  | Q1'FY21 |  | Q2'FY20 |  |
| SALES AND MARKETING EXPENSES |  | $ | 432 |  | $ | 429 |  | $ | 389 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) | — |  |  | — |  |
| Stock-based compensation |  |  | (24 | ) |  | (25 | ) |  | (17 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 405 |  | $ | 404 |  | $ | 372 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 212 |  | $ | 233 |  | $ | 209 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (15 | ) |  | (19 | ) |  | (13 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 197 |  | $ | 214 |  | $ | 196 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 67 |  | $ | 61 |  | $ | 69 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (7 | ) |  | (6 | ) |  | (6 | ) |
| Litigation settlements |  |  | (5 | ) | — |  |  | — |  |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 55 |  | $ | 55 |  | $ | 63 |  |
| RESTRUCTURING CHARGES |  | $ | 37 |  | $ | 5 |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (37 | ) |  | (5 | ) |  | — |  |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  | $ | — |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 3 |  | $ | 8 |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (3 | ) |  | (8 | ) |  | — |  |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  | $ | — |  | $ | — |  |
| GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  | $ | — |  | $ | (38 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |
| Gain on sale or derecognition of assets |  |  | — |  |  | — |  |  | 38 |  |
| NON-GAAP GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  | $ | — |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 751 |  | $ | 736 |  | $ | 629 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  | — |  |  | — |  |
| Stock-based compensation |  |  | (46 | ) |  | (50 | ) |  | (36 | ) |
| Litigation settlements |  |  | (5 | ) |  | — |  |  | — |  |
| Restructuring charges |  |  | (37 | ) |  | (5 | ) |  | — |  |
| Acquisition-related expense |  |  | (3 | ) |  | (8 | ) |  | — |  |
| Gain on sale or derecognition of assets |  |  | — |  |  | — |  |  | 38 |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 657 |  | $ | 673 |  | $ | 631 |  |

[0001564590-20-055739:8k_2_02:106]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY21 |  | Q1'FY21 |  | Q2'FY20 |  |
| INCOME FROM OPERATIONS |  | $ | 182 |  | $ | 136 |  | $ | 296 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 15 |  |  | 10 |  |  | 11 |  |
| Stock-based compensation |  |  | 49 |  |  | 54 |  |  | 40 |  |
| Litigation settlements |  |  | 5 |  |  | — |  |  | — |  |
| Restructuring charges |  |  | 37 |  |  | 5 |  |  | — |  |
| Acquisition-related expense |  |  | 3 |  |  | 8 |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | — |  |  | — |  |  | (38 | ) |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 291 |  | $ | 213 |  | $ | 309 |  |
| OTHER INCOME (EXPENSE), NET |  | $ | (7 | ) | $ | (32 | ) | $ | 3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Debt extinguishment costs |  |  | — |  |  | 14 |  |  | — |  |
| Gain on sale of equity investment |  |  | (6 | ) |  | — |  |  | — |  |
| NON-GAAP OTHER INCOME (EXPENSE), NET |  | $ | (13 | ) | $ | (18 | ) | $ | 3 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 175 |  | $ | 104 |  | $ | 299 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 15 |  |  | 10 |  |  | 11 |  |
| Stock-based compensation |  |  | 49 |  |  | 54 |  |  | 40 |  |
| Litigation settlements |  |  | 5 |  | — |  |  | — |  |
| Restructuring charges |  |  | 37 |  |  | 5 |  |  | — |  |
| Acquisition-related expense |  |  | 3 |  |  | 8 |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | — |  | — |  |  | (38 | ) |
| Debt extinguishment costs |  |  | — |  |  | 14 |  |  | — |  |
| Gain on sale of equity investment |  |  | (6 | ) |  | — |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 278 |  | $ | 195 |  | $ | 312 |  |
| PROVISION FOR INCOME TAXES |  | $ | 38 |  | $ | 27 |  | $ | 56 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 9 |  |  | 16 |  |  | (1 | ) |
| Income tax expenses from integration of acquired companies |  |  | (5 | ) |  | (11 | ) |  | — |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 42 |  | $ | 32 |  | $ | 55 |  |
| NET INCOME PER SHARE |  | $ | 0.61 |  | $ | 0.35 |  | $ | 1.03 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.07 |  |  | 0.05 |  |  | 0.05 |  |
| Stock-based compensation |  |  | 0.22 |  |  | 0.24 |  |  | 0.17 |  |
| Litigation settlements |  |  | 0.02 |  | — |  |  | — |  |
| Restructuring charges |  |  | 0.17 |  |  | 0.02 |  |  | — |  |
| Acquisition-related expense |  |  | 0.01 |  |  | 0.04 |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | — |  | — |  |  | (0.16 | ) |
| Debt extinguishment costs |  | — |  |  | 0.06 |  |  | — |  |
| Gain on sale of equity investment |  |  | (0.03 | ) | — |  | — |  |
| Income tax effects |  |  | (0.04 | ) |  | (0.07 | ) |  | — |  |
| Income tax expenses from integration of acquired companies |  |  | 0.02 |  |  | 0.05 |  |  | — |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.05 |  | $ | 0.73 |  | $ | 1.09 |  |

[0001564590-20-055739:8k_2_02:107]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY21 |  | Q1'FY21 |  | Q2'FY20 |  |
| Gross margin-GAAP |  |  | 65.9 | % |  | 66.9 | % |  | 67.5 | % |
| Cost of revenues adjustments |  |  | 1.1 | % |  | 1.1 | % |  | 1.1 | % |
| Gross margin-Non-GAAP |  |  | 66.9 | % |  | 68.0 | % |  | 68.6 | % |
| GAAP cost of revenues |  | $ | 483 |  | $ | 431 |  | $ | 446 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (12 | ) |  | (10 | ) |  | (11 | ) |
| Stock-based compensation |  |  | (3 | ) |  | (4 | ) |  | (4 | ) |
| Non-GAAP cost of revenues |  | $ | 468 |  | $ | 417 |  | $ | 431 |  |
| Net revenues |  | $ | 1,416 |  | $ | 1,303 |  | $ | 1,371 |  |

[0001564590-20-055739:8k_2_02:108]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY21 |  | Q1'FY21 |  | Q2'FY20 |  |
| Product gross margin-GAAP |  |  | 51.9 | % |  | 49.6 | % |  | 55.8 | % |
| Cost of product revenues adjustments |  |  | 1.1 | % |  | 1.8 | % |  | 1.6 | % |
| Product gross margin-Non-GAAP |  |  | 53.0 | % |  | 51.4 | % |  | 57.3 | % |
| GAAP cost of product revenues |  | $ | 360 |  | $ | 316 |  | $ | 341 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  | (10 | ) |  | (11 | ) |
| Stock-based compensation |  |  | (1 | ) |  | (1 | ) |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 352 |  | $ | 305 |  | $ | 329 |  |
| Product revenues |  | $ | 749 |  | $ | 627 |  | $ | 771 |  |

[0001564590-20-055739:8k_2_02:109]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| SOFTWARE MAINTENANCE GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY21 |  | Q1'FY21 |  | Q2'FY20 |  |
| Software maintenance gross margin-GAAP |  |  | 92.1 | % |  | 95.0 | % |  | 95.7 | % |
| Cost of software maintenance revenues adjustment |  |  | 1.7 | % |  | — | % |  | — | % |
| Software maintenance gross margin-Non-GAAP |  |  | 93.7 | % |  | 95.0 | % |  | 95.7 | % |
| GAAP cost of software maintenance revenues |  | $ | 24 |  | $ | 15 |  | $ | 11 |  |
| Cost of software maintenance revenues adjustment: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  | — |  |  | — |  |
| Non-GAAP cost of software maintenance revenues |  | $ | 19 |  | $ | 15 |  | $ | 11 |  |
| Software maintenance revenues |  | $ | 303 |  | $ | 301 |  | $ | 254 |  |

[0001564590-20-055739:8k_2_02:110]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY21 |  | Q1'FY21 |  | Q2'FY20 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 72.8 | % |  | 73.3 | % |  | 72.8 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.5 | % |  | 0.8 | % |  | 0.9 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 73.4 | % |  | 74.1 | % |  | 73.7 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 99 |  | $ | 100 |  | $ | 94 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  | (3 | ) |  | (3 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 97 |  | $ | 97 |  | $ | 91 |  |
| Hardware maintenance and other services revenues |  | $ | 364 |  | $ | 375 |  | $ | 346 |  |

[0001564590-20-055739:8k_2_02:111]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q2'FY21 |  | Q1'FY21 |  | Q2'FY20 |  |
| GAAP effective tax rate |  |  | 21.7 | % |  | 26.0 | % |  | 18.7 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | (3.8 | )% |  | 1.0 | % |  | (1.1 | )% |
| Income tax expenses from integration of acquired companies |  |  | (2.9 | )% |  | (10.6 | )% |  | — | % |
| Non-GAAP effective tax rate |  |  | 15.1 | % |  | 16.4 | % |  | 17.6 | % |

[0001564590-20-055739:8k_2_02:112]
| RECONCILIATION OF NET CASH PROVIDED BY (USED IN) OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY21 |  | Q1'FY21 |  | Q2'FY20 |  |
| Net cash provided by (used in) operating activities |  | $ | 161 |  | $ | 240 |  | $ | (53 | ) |
| Purchases of property and equipment |  |  | (40 | ) |  | (52 | ) |  | (36 | ) |
| Free cash flow |  | $ | 121 |  | $ | 188 |  | $ | (89 | ) |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY21 |  | Q1'FY21 |  | Q2'FY20 |  |
| Net revenues |  | $ | 1,416 |  | $ | 1,303 |  | $ | 1,371 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | 40 |  |  | (158 | ) |  | (43 | ) |
| Billings |  | $ | 1,456 |  | $ | 1,145 |  | $ | 1,328 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |  |  |  |  |  |  |  |  |  |

[0001564590-20-055739:8k_2_02:113]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| THIRD QUARTER FISCAL 2021 |  |
|  |  | Third Quarter |  |
|  |  | Fiscal 2021 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $0.94 - $1.02 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Third Quarter Fiscal 2021: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.06 | ) |
| Stock-based compensation expense |  |  | (0.21 | ) |
| Income tax effects |  |  | — |  |
| Total Adjustments |  |  | (0.27 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.67 - $0.75 |  |

[0001564590-20-055739:8k_2_02:114]
Some items may not add or recalculate due to rounding.

[0001564590-20-055739:8k_2_02:115]
Contacts:

[0001564590-20-055739:8k_2_02:116]
(Press)

[0001564590-20-055739:8k_2_02:117]
Amelia Vierra

[0001564590-20-055739:8k_2_02:118]
1 408 822 6403

[0001564590-20-055739:8k_2_02:119]
amelia.vierra@netapp.com

[0001564590-20-055739:8k_2_02:120]
(Investors)

[0001564590-20-055739:8k_2_02:121]
Lance Berger

[0001564590-20-055739:8k_2_02:122]
1 408 822 6628

[0001564590-20-055739:8k_2_02:123]
lance.berger@netapp.com
