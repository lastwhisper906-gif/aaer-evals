# NTAP MD&A — 0001564590-20-056069


## mdna

[0001564590-20-056069:mdna:1]
[same as prior period, unchanged from 0001564590-20-041759:mdna:1]

[0001564590-20-056069:mdna:2]
[same as prior period, unchanged from 0001564590-20-041759:mdna:19]

[0001564590-20-056069:mdna:3]
[same as prior period, unchanged from 0001564590-20-041759:mdna:2]

[0001564590-20-056069:mdna:4]
[same as prior period, unchanged from 0001564590-20-041759:mdna:3]

[0001564590-20-056069:mdna:5]
[same as prior period, unchanged from 0001564590-20-041759:mdna:4]

[0001564590-20-056069:mdna:6]
[same as prior period, unchanged from 0001564590-20-041759:mdna:5]

[0001564590-20-056069:mdna:7]
[same as prior period, unchanged from 0001564590-20-041759:mdna:6]

[0001564590-20-056069:mdna:8]
[same as prior period, unchanged from 0001564590-20-041759:mdna:7]

[0001564590-20-056069:mdna:9]
[same as prior period, unchanged from 0001564590-20-041759:mdna:8]

[0001564590-20-056069:mdna:10]
[same as prior period, unchanged from 0001564590-20-041759:mdna:9]

[0001564590-20-056069:mdna:11]
[same as prior period, unchanged from 0001564590-20-041759:mdna:10]

[0001564590-20-056069:mdna:12]
[same as prior period, unchanged from 0001564590-20-041759:mdna:11]

[0001564590-20-056069:mdna:13]
[same as prior period, unchanged from 0001564590-20-041759:mdna:12]

[0001564590-20-056069:mdna:14]
[same as prior period, unchanged from 0001564590-20-041759:mdna:13]

[0001564590-20-056069:mdna:15]
[same as prior period, unchanged from 0001564590-20-041759:mdna:14]

[0001564590-20-056069:mdna:16]
[same as prior period, unchanged from 0001564590-20-041759:mdna:15]

[0001564590-20-056069:mdna:17]
[same as prior period, unchanged from 0001564590-20-041759:mdna:16]

[0001564590-20-056069:mdna:18]
During the first half of fiscal 2021, due to the macroeconomic uncertainty caused by COVID-19, we continue to observe certain customers delay purchases of our products and services, while other customers accelerate or place new orders to address the demands of remote working and digital business, though on a net basis the impact to product revenues was unfavorable. We also continue to experience certain logistical challenges in delivering our products and services to customers in certain regions, and minor supply chain constraints.

[0001564590-20-056069:mdna:19]
We believe our existing balances of cash, cash equivalents and investments, cash generated from operations, and ability to access capital markets and committed lines of credit will be sufficient to satisfy our working capital needs, capital expenditures, dividends, required debt repayments and other liquidity requirements associated with our operations.

[0001564590-20-056069:mdna:20]
[same as prior period, unchanged from 0001564590-20-041759:mdna:34]

[0001564590-20-056069:mdna:21]
[same as prior period, unchanged from 0001564590-20-041759:mdna:20]

[0001564590-20-056069:mdna:22]
[same as prior period, unchanged from 0001564590-20-041759:mdna:21]

[0001564590-20-056069:mdna:23]
[same as prior period, unchanged from 0001564590-20-041759:mdna:22]

[0001564590-20-056069:mdna:24]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Net revenues |  | $ | 1,416 |  |  | $ | 1,371 |  |  | $ | 2,719 |  |  | $ | 2,607 |  |
| Gross profit |  | $ | 933 |  |  | $ | 925 |  |  | $ | 1,805 |  |  | $ | 1,741 |  |
| Gross profit margin percentage |  |  | 66 | % |  |  | 67 | % |  |  | 66 | % |  |  | 67 | % |
| Income from operations |  | $ | 182 |  |  | $ | 296 |  |  | $ | 318 |  |  | $ | 400 |  |
| Income from operations as a percentage of net revenues |  |  | 13 | % |  |  | 22 | % |  |  | 12 | % |  |  | 15 | % |
| Net income |  | $ | 137 |  |  | $ | 243 |  |  | $ | 214 |  |  | $ | 346 |  |
| Diluted net income per share |  | $ | 0.61 |  |  | $ | 1.03 |  |  | $ | 0.96 |  |  | $ | 1.44 |  |
| Net cash provided by (used in) operating activities |  | $ | 161 |  |  | $ | (53 | ) |  | $ | 401 |  |  | $ | 257 |  |

[0001564590-20-056069:mdna:25]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,651 |  |  | $ | 3,698 |  |

[0001564590-20-056069:mdna:26]
[same as prior period, unchanged from 0001564590-20-041759:mdna:25]

[0001564590-20-056069:mdna:27]
During the second quarter of fiscal 2021, we declared aggregate cash dividends of $0.48 per share, for which we paid $107 million. During the first six months of fiscal 2021, aggregate cash dividends declared totaled $0.96 per share, for which we paid an aggregate of $214 million.

[0001564590-20-056069:mdna:28]
Restructuring Event

[0001564590-20-056069:mdna:29]
On August 25, 2020, we committed to a restructuring plan (the August 2020 Plan) to optimize our business and fund our biggest opportunities. In connection with the August 2020 Plan, we reduced our global workforce by approximately 5% and recognized expenses totaling $37 million in the second quarter of fiscal 2021, consisting primarily of employee severance-related costs. Substantially all activities under the August 2020 Plan are expected to be complete by the end of the third quarter of fiscal 2021.

[0001564590-20-056069:mdna:30]
[same as prior period, unchanged from 0001564590-20-041759:mdna:35]

[0001564590-20-056069:mdna:31]
[same as prior period, unchanged from 0001564590-20-041759:mdna:36]

[0001564590-20-056069:mdna:32]
[same as prior period, unchanged from 0001564590-20-041759:mdna:37]

[0001564590-20-056069:mdna:33]
[same as prior period, unchanged from 0001564590-20-041759:mdna:38]

[0001564590-20-056069:mdna:34]
See Note 2 – Recently Adopted Accounting Standards of the Notes to Condensed Consolidated Financial Statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on our financial statements.

[0001564590-20-056069:mdna:35]
[same as prior period, unchanged from 0001564590-20-041759:mdna:44]

[0001564590-20-056069:mdna:36]
[same as prior period, unchanged from 0001564590-20-041759:mdna:40]

[0001564590-20-056069:mdna:37]
[same as prior period, unchanged from 0001564590-20-041759:mdna:41]

[0001564590-20-056069:mdna:38]
[same as prior period, unchanged from 0001564590-20-041759:mdna:42]

[0001564590-20-056069:mdna:39]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 53 | % |  |  | 56 | % |  |  | 51 | % |  |  | 54 | % |  |
| Software maintenance |  |  | 21 |  |  |  | 19 |  |  |  | 22 |  |  |  | 19 |  |  |
| Hardware maintenance and other services |  |  | 26 |  |  |  | 25 |  |  |  | 27 |  |  |  | 26 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 25 |  |  |  | 25 |  |  |  | 25 |  |  |  | 25 |  |  |
| Cost of software maintenance |  |  | 2 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 7 |  |  |  | 7 |  |  |  | 7 |  |  |  | 7 |  |  |
| Gross profit |  |  | 66 |  |  |  | 67 |  |  |  | 66 |  |  |  | 67 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 31 |  |  |  | 28 |  |  |  | 32 |  |  |  | 30 |  |  |
| Research and development |  |  | 15 |  |  |  | 15 |  |  |  | 16 |  |  |  | 16 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | 3 |  |  |  | — |  |  |  | 2 |  |  |  | 1 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (3 | ) |  |  | — |  |  |  | (1 | ) |  |
| Total operating expenses |  |  | 53 |  |  |  | 46 |  |  |  | 55 |  |  |  | 51 |  |  |
| Income from operations |  |  | 13 |  |  |  | 22 |  |  |  | 12 |  |  |  | 15 |  |  |
| Other income (expense), net |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | 1 |  |  |
| Income before income taxes |  |  | 12 |  |  |  | 22 |  |  |  | 10 |  |  |  | 16 |  |  |
| Provision for income taxes |  |  | 3 |  |  |  | 4 |  |  |  | 2 |  |  |  | 3 |  |  |
| Net income |  |  | 10 | % |  |  | 18 | % |  |  | 8 | % |  |  | 13 | % |  |

[0001564590-20-056069:mdna:40]
[same as prior period, unchanged from 0001564590-20-041759:mdna:45]

[0001564590-20-056069:mdna:41]
[same as prior period, unchanged from 0001564590-20-041759:mdna:46]

[0001564590-20-056069:mdna:42]
[same as prior period, unchanged from 0001564590-20-041759:mdna:47]

[0001564590-20-056069:mdna:43]
Net revenues for the second quarter and first six months of fiscal 2021 were $1,416 million and $2,719 million, respectively, reflecting an increase of $45 million, or 3%, and $112 million, or 4%, respectively, compared to the corresponding periods of the prior year. The growth in net revenues reflects an increase in software maintenance revenues and hardware maintenance and other services revenues, offset by a decrease in product revenues. In the first six months of fiscal 2021, software and hardware maintenance revenues benefitted from the extra week in that period.

[0001564590-20-056069:mdna:44]
Gross profit as a percentage of net revenues for the second quarter and first six months of fiscal 2021 decreased by approximately one percentage point each compared to the corresponding periods in fiscal 2020, primarily as a result of a reduction in gross profit margins on product revenues. Gross profit margins on product revenues decreased by four percentage points and three percentage points in the second quarter and first six months of fiscal 2021, respectively, compared to the corresponding periods of fiscal 2020 primarily due to a decline in the average selling prices of our products and an increase in average unit materials costs. The decline in gross profit margins on product revenues was partially offset by an increase in software and hardware maintenance revenues.

[0001564590-20-056069:mdna:45]
Sales and marketing, research and development, and general and administrative expenses for the second quarter and first six months of fiscal 2021 totaled $711 million, or 50%, and $1,434 million, or 53% of net revenues, respectively, reflecting an increase of approximately two percentage points and one percentage point, respectively, compared to the corresponding periods of fiscal 2020.

[0001564590-20-056069:mdna:46]
30

[0001564590-20-056069:mdna:47]
[same as prior period, unchanged from 0001564590-20-041759:mdna:51]

[0001564590-20-056069:mdna:48]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |
| Net revenues |  | $ | 1,416 |  |  | $ | 1,371 |  |  |  | 3 | % |  | $ | 2,719 |  |  | $ | 2,607 |  |  |  | 4 | % |

[0001564590-20-056069:mdna:49]
The increase in net revenues for the second quarter and first six months of fiscal 2021 compared to the corresponding periods of fiscal 2020 was primarily due to an increase in hardware and software maintenance revenues, which in the first six months of 2021 benefitted from an additional week in that period. Product revenues as a percentage of net revenues decreased by approximately three percentage points in both the second quarter and first six months of fiscal 2021 compared to the corresponding periods of fiscal 2020.

[0001564590-20-056069:mdna:50]
[same as prior period, unchanged from 0001564590-20-041759:mdna:54]

[0001564590-20-056069:mdna:51]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Arrow Electronics, Inc. |  |  | 25 | % |  |  | 24 | % |  |  | 24 | % |  |  | 24 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 21 | % |  |  | 20 | % |  |  | 21 | % |

[0001564590-20-056069:mdna:52]
[same as prior period, unchanged from 0001564590-20-041759:mdna:56]

[0001564590-20-056069:mdna:53]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |
| Product revenues |  | $ | 749 |  |  | $ | 771 |  |  |  | (3 | )% |  | $ | 1,376 |  |  | $ | 1,415 |  |  |  | (3 | )% |

[0001564590-20-056069:mdna:54]
[same as prior period, unchanged from 0001564590-20-041759:mdna:58]

[0001564590-20-056069:mdna:55]
Total product revenues decreased in the second quarter and first six months of fiscal 2021 compared to the corresponding periods of the prior year primarily due to less favorable macroeconomic conditions in the current year, in part due to the economic uncertainty caused by the COVID-19 pandemic. While sales of all-flash array systems increased in the current year, this increase was more than offset by a decline in sales of our other products. Product revenues in the second quarter of fiscal 2021 benefitted slightly from the favorable impact of foreign exchange rate fluctuations.

[0001564590-20-056069:mdna:56]
As discussed in the Overview section, beginning in fiscal 2021, we disclose the software and hardware components of our product revenues. Because our revenue recognition policy under generally accepted accounting principles in the United States of America (GAAP) defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, the hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components. We believe that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0001564590-20-056069:mdna:57]
Revenues from the hardware component of product revenues totaled $332 million, representing 44% of product revenues, in the second quarter of fiscal 2021, compared to $405 million, representing 53% of product revenues, in the corresponding period of the prior year. Revenues from the hardware component of product revenues totaled $648 million, representing 47% of product revenues, in the first six months of fiscal 2021, compared to $743 million, representing 53% of product revenues, in the first six months of fiscal 2020. The software component of product revenues totaled $417 million, representing 56% of product revenues, in the second quarter of fiscal 2021, compared to $366 million, representing 47% of product revenues, in the corresponding period of the prior year. The software component of product revenues totaled $728 million, representing 53% of product revenues, in the first six months of fiscal 2021, compared to $672 million, representing 47% of product revenues, in the corresponding period of the prior year. The increase in the software component percentage of product revenues in the second quarter and first six months of fiscal 2021 is primarily due to a higher mix of all-flash array systems revenues, which contain a higher proportion of software components than other products.

[0001564590-20-056069:mdna:58]
31

[0001564590-20-056069:mdna:59]
[same as prior period, unchanged from 0001564590-20-041759:mdna:63]

[0001564590-20-056069:mdna:60]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 303 |  |  | $ | 254 |  |  |  | 19 | % |  | $ | 604 |  |  | $ | 504 |  |  |  | 20 | % |

[0001564590-20-056069:mdna:61]
[same as prior period, unchanged from 0001564590-20-041759:mdna:65]

[0001564590-20-056069:mdna:62]
The growth in software maintenance revenues reflect the higher aggregate contract value of the installed base under software maintenance contracts, which is recognized as revenue ratably over the terms of the underlying contracts. Software maintenance revenues in the second quarter and first six months of fiscal 2021 benefitted from the continued growth in all-flash array product sales, as all flash systems carry a higher support dollar content than our other products. Software maintenance revenues in the first six months of fiscal 2021 were favorably impacted by the additional week of deferred revenue amortization in that period, which contributed approximately $20 million of additional revenues.

[0001564590-20-056069:mdna:63]
[same as prior period, unchanged from 0001564590-20-041759:mdna:67]

[0001564590-20-056069:mdna:64]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 364 |  |  | $ | 346 |  |  |  | 5 | % |  | $ | 739 |  |  | $ | 688 |  |  |  | 7 | % |

[0001564590-20-056069:mdna:65]
[same as prior period, unchanged from 0001564590-20-041759:mdna:69]

[0001564590-20-056069:mdna:66]
Hardware maintenance contract revenues were $296 million and $603 million, respectively, for the second quarter and first six months of fiscal 2021, compared to $286 million and $570 million, respectively, for the corresponding periods of fiscal 2020, reflecting an increase of 3% and 6%, respectively. The increase in the first six months of fiscal 2021 is partially due to the additional week in that period which contributed approximately $20 million of additional revenues.

[0001564590-20-056069:mdna:67]
Professional services and educational and training services revenues were $68 million and $136 million, respectively, for the second quarter and first six months of fiscal 2021, compared to $60 million and $118 million, respectively, for the corresponding periods of the prior year.

[0001564590-20-056069:mdna:68]
[same as prior period, unchanged from 0001564590-20-041759:mdna:72]

[0001564590-20-056069:mdna:69]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| United States, Canada and Latin America (Americas) |  |  | 55 | % |  |  | 56 | % |  |  | 55 | % |  |  | 54 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 30 | % |  |  | 29 | % |  |  | 30 | % |  |  | 31 | % |
| Asia Pacific (APAC) |  |  | 15 | % |  |  | 14 | % |  |  | 16 | % |  |  | 15 | % |

[0001564590-20-056069:mdna:70]
[same as prior period, unchanged from 0001564590-20-041759:mdna:74]

[0001564590-20-056069:mdna:71]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Demand across geographies was relatively consistent in the second quarter and first six months of fiscal 2021 as compared to the corresponding periods of the prior year.

[0001564590-20-056069:mdna:72]
[same as prior period, unchanged from 0001564590-20-041759:mdna:76]

[0001564590-20-056069:mdna:73]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping our storage products, amortization of purchased intangible assets, inventory write-downs, and warranty costs, (2) cost of software maintenance, which includes the costs of providing software maintenance, third-party royalty costs and amortization of purchased intangible assets and (3) cost of hardware maintenance and other services revenues, which includes costs associated with providing support activities for hardware maintenance, global support partnership programs, professional services and educational and training services.

[0001564590-20-056069:mdna:74]
32

[0001564590-20-056069:mdna:75]
[same as prior period, unchanged from 0001564590-20-041759:mdna:79]

[0001564590-20-056069:mdna:76]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |
| Cost of product revenues |  | $ | 360 |  |  | $ | 341 |  |  |  | 6 | % |  | $ | 676 |  |  | $ | 653 |  |  |  | 4 | % |

[0001564590-20-056069:mdna:77]
[same as prior period, unchanged from 0001564590-20-041759:mdna:81]

[0001564590-20-056069:mdna:78]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2021 to Fiscal 2020 |  |  | Fiscal 2021 to Fiscal 2020 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | 7 |  |  |  | 7 |  |
| Excess and obsolete inventory |  |  | (1 | ) |  |  | (1 | ) |
| Warranty |  |  | (1 | ) |  |  | (1 | ) |
| Other |  |  | 1 |  |  |  | (1 | ) |
| Total change |  |  | 6 |  |  |  | 4 |  |

[0001564590-20-056069:mdna:79]
Cost of product revenues represented 48% and 49% of product revenues for the second quarter and first six months of fiscal 2021, respectively, compared to 44% and 46% for the corresponding periods of fiscal 2020. Materials costs represented 89% and 88% of product costs for the second quarter and first six months of fiscal 2021, respectively, compared to 86% and 84% in the corresponding periods of fiscal 2020.

[0001564590-20-056069:mdna:80]
Materials costs increased by approximately $25 million and $48 million in the second quarter and first six months of fiscal 2021, respectively, compared to the corresponding periods of the prior year. The trend in product mix toward all flash-array systems, which carry higher materials costs than hybrid systems, was the primary driver of these increases. The average unit materials cost of all flash-array systems also increased in the second quarter and first six months of fiscal 2021 compared to the corresponding periods of fiscal 2020, due to an increase in the price of certain product components, which adversely impacted product margins. Excess and obsolete inventory reserves and warranty expenses were lower in the second quarter and first six months of fiscal 2021 compared to the corresponding periods of fiscal 2020.

[0001564590-20-056069:mdna:81]
In addition to the increase in average unit materials costs of all flash-array systems described above, product margins were also adversely impacted in the second quarter and first six months of fiscal 2021 by a decrease in the average selling prices of most of our products.

[0001564590-20-056069:mdna:82]
[same as prior period, unchanged from 0001564590-20-041759:mdna:86]

[0001564590-20-056069:mdna:83]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 24 |  |  | $ | 11 |  |  |  | 118 | % |  | $ | 39 |  |  | $ | 21 |  |  |  | 86 | % |

[0001564590-20-056069:mdna:84]
Cost of software maintenance revenues increased in the second quarter and first six months of fiscal 2021 compared to the corresponding periods of fiscal 2020, in part due to an increase in amortization expense for acquired developed technology, and represented 8% and 6% of software maintenance revenues, respectively, for the second quarter and first six months of fiscal 2021, and 4% for each of the corresponding periods of fiscal 2020.

[0001564590-20-056069:mdna:85]
[same as prior period, unchanged from 0001564590-20-041759:mdna:89]

[0001564590-20-056069:mdna:86]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 99 |  |  | $ | 94 |  |  |  | 5 | % |  | $ | 199 |  |  | $ | 192 |  |  |  | 4 | % |

[0001564590-20-056069:mdna:87]
Cost of hardware maintenance and other services revenues increased in the second quarter and first six months of fiscal 2021 compared to the corresponding periods of fiscal 2020, in line with the increase in hardware maintenance and other services revenues. Costs represented 27% of hardware maintenance and other services revenues in both the second quarter and first six months of fiscal 2021, compared to 27% and 28% in the corresponding periods of fiscal 2020.

[0001564590-20-056069:mdna:88]
[same as prior period, unchanged from 0001564590-20-041759:mdna:108]

[0001564590-20-056069:mdna:89]
[same as prior period, unchanged from 0001564590-20-041759:mdna:92]

[0001564590-20-056069:mdna:90]
[same as prior period, unchanged from 0001564590-20-041759:mdna:93]

[0001564590-20-056069:mdna:91]
[same as prior period, unchanged from 0001564590-20-041759:mdna:94]

[0001564590-20-056069:mdna:92]
Total compensation costs included in operating expenses increased by $43 million, or 7%, in the second quarter of fiscal 2021 compared to the corresponding period of the prior year, reflecting a 5% increase in average headcount and higher incentive compensation expense.

[0001564590-20-056069:mdna:93]
Total compensation costs included in operating expenses increased $101 million, or 8% in the first six months of fiscal 2021, compared to the corresponding period of the prior year, reflecting an increase in average headcount of 5%, higher incentive compensation expense, and the impact of one additional week in the first quarter of fiscal 2021.

[0001564590-20-056069:mdna:94]
[same as prior period, unchanged from 0001564590-20-041759:mdna:96]

[0001564590-20-056069:mdna:95]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 432 |  |  | $ | 389 |  |  |  | 11 | % |  | $ | 861 |  |  | $ | 794 |  |  |  | 8 | % |

[0001564590-20-056069:mdna:96]
[same as prior period, unchanged from 0001564590-20-041759:mdna:98]

[0001564590-20-056069:mdna:97]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2021 to Fiscal 2020 |  |  | Fiscal 2021 to Fiscal 2020 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 8 |  |  |  | 8 |  |
| Commissions |  |  | 4 |  |  |  | 4 |  |
| Advertising and marketing promotional expense |  |  | 2 |  |  |  | — |  |
| Travel and entertainment |  |  | (4 | ) |  |  | (4 | ) |
| Other |  |  | 1 |  |  |  | — |  |
| Total change |  |  | 11 |  |  |  | 8 |  |

[0001564590-20-056069:mdna:98]
The increase in compensation costs for the second quarter and first six months of fiscal 2021 reflected an increase in average headcount of 9% and 7%, respectively, compared to the corresponding periods of the prior year, with this expansion of our sales and marketing teams supporting our ability to execute on key market opportunities. Compensation costs for the six months of fiscal 2021 also reflected the impact of one additional week in the first quarter.

[0001564590-20-056069:mdna:99]
The increase in commissions expense for the second quarter and first six months of fiscal 2021 is primarily due to higher performance against sales goals than in fiscal 2020. Advertising and marketing promotional expense increased in the second quarter of fiscal 2021 compared to the corresponding period of the prior year, primarily due to higher spending levels on certain projects. Travel and entertainment spend decreased significantly due to the ongoing COVID-19 pandemic.

[0001564590-20-056069:mdna:100]
[same as prior period, unchanged from 0001564590-20-041759:mdna:101]

[0001564590-20-056069:mdna:101]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |
| Research and development expenses |  | $ | 212 |  |  | $ | 209 |  |  |  | 1 | % |  | $ | 445 |  |  | $ | 424 |  |  |  | 5 | % |

[0001564590-20-056069:mdna:102]
[same as prior period, unchanged from 0001564590-20-041759:mdna:103]

[0001564590-20-056069:mdna:103]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2021 to Fiscal 2020 |  |  | Fiscal 2021 to Fiscal 2020 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 4 |  |  |  | 7 |  |
| Facilities and IT support costs |  |  | (1 | ) |  |  | (1 | ) |
| Travel and entertainment |  |  | (1 | ) |  |  | (1 | ) |
| Other |  |  | (1 | ) |  |  | — |  |
| Total change |  |  | 1 |  |  |  | 5 |  |

[0001564590-20-056069:mdna:104]
The increase in compensation costs for the second quarter and first six months of fiscal 2021 compared to the corresponding periods in the prior year was primarily due to higher incentive compensation expense as a result of stronger company achievement against financial targets. Compensation costs for the six months of fiscal 2021 also reflected the impact of one additional week in the first quarter. The decrease in facilities and IT support costs were primarily due to cost containment efforts, and travel and entertainment expense decreased due to the impact of the ongoing COVID-19 pandemic.

[0001564590-20-056069:mdna:105]
[same as prior period, unchanged from 0001564590-20-041759:mdna:106]

[0001564590-20-056069:mdna:106]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |
| General and administrative expenses |  | $ | 67 |  |  | $ | 69 |  |  |  | (3 | )% |  | $ | 128 |  |  | $ | 140 |  |  |  | (9 | )% |

[0001564590-20-056069:mdna:107]
[same as prior period, unchanged from 0001564590-20-041759:mdna:109]

[0001564590-20-056069:mdna:108]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2021 to Fiscal 2020 |  |  | Fiscal 2021 to Fiscal 2020 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 6 |  |  |  | 5 |  |
| Professional and legal fees and outside services |  |  | (15 | ) |  |  | (17 | ) |
| Litigation settlement |  |  | 7 |  |  |  | 4 |  |
| Other |  |  | (1 | ) |  |  | (1 | ) |
| Total change |  |  | (3 | ) |  |  | (9 | ) |

[0001564590-20-056069:mdna:109]
The increase in compensation costs in the second quarter and first six months of fiscal 2021 compared to the corresponding periods of the prior year was primarily due to higher incentive compensation expense as a result of stronger company achievement against financial targets. The decrease in professional and legal fees and outside services expense in the second quarter and first six months of fiscal 2021 was primarily due to lower spending on business transformation projects in the current year. During the second quarter of fiscal 2021, we incurred a litigation settlement charge of approximately $5 million that was included in general and administrative expenses in our Condensed Consolidated Statements of Operations.

[0001564590-20-056069:mdna:110]
[same as prior period, unchanged from 0001564590-20-041759:mdna:112]

[0001564590-20-056069:mdna:111]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |
| Restructuring charges |  | $ | 37 |  |  | $ | — |  |  | NM |  | $ | 42 |  |  | $ | 21 |  |  |  | 100 | % |

[0001564590-20-056069:mdna:112]
[same as prior period, unchanged from 0001564590-20-041759:mdna:117]

[0001564590-20-056069:mdna:113]
In the second quarter of fiscal 2021, we announced a restructuring plan (the August 2020 Plan) to optimize our business and fund our biggest opportunities, which included a reduction in our global workforce of approximately 5%. Charges related to the plan consisted primarily of employee severance-related costs. We expect to complete substantially all activities under the plan by the end of the third quarter fiscal 2021. See Note 12 – Restructuring Charges of the Notes to Condensed Consolidated Financial Statements for more details.

[0001564590-20-056069:mdna:114]
[same as prior period, unchanged from 0001564590-20-041759:mdna:115]

[0001564590-20-056069:mdna:115]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |
| Acquisition-related expense |  | $ | 3 |  |  |  | — |  |  | NM |  | $ | 11 |  |  | $ | — |  |  | NM |

[0001564590-20-056069:mdna:116]
NM – Not Meaningful

[0001564590-20-056069:mdna:117]
In the first six months of fiscal 2021, we incurred $11 million of acquisition-related costs, primarily legal and consulting fees associated with our acquisition and subsequent integration of Spot Inc.

[0001564590-20-056069:mdna:118]
Gain on sale or derecognition of assets (in millions, except percentages)

[0001564590-20-056069:mdna:119]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |
| Gain on sale or derecognition of assets |  | $ | — |  |  | $ | (38 | ) |  | NM |  | $ | — |  |  | $ | (38 | ) |  | NM |

[0001564590-20-056069:mdna:120]
NM – Not Meaningful

[0001564590-20-056069:mdna:121]
In September 2017, we entered into an agreement to sell certain land and buildings located in Sunnyvale, California, through two separate and independent closings, the first of which was completed in fiscal 2018. On August 29, 2019, the second closing occurred and we consummated the sale of the land, with a net book value of $53 million, and received cash proceeds of $96 million, resulting in a gain, net of direct selling costs, of $38 million.

[0001564590-20-056069:mdna:122]
[same as prior period, unchanged from 0001564590-20-041759:mdna:119]

[0001564590-20-056069:mdna:123]
[same as prior period, unchanged from 0001564590-20-041759:mdna:120]

[0001564590-20-056069:mdna:124]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |
| Interest income |  | $ | 2 |  |  | $ | 12 |  |  |  | (83 | )% |  | $ | 5 |  |  | $ | 31 |  |  |  | (84 | )% |
| Interest expense |  |  | (18 | ) |  |  | (12 | ) |  |  | 50 | % |  |  | (36 | ) |  |  | (27 | ) |  |  | 33 | % |
| Other income (expense), net |  |  | 9 |  |  |  | 3 |  |  |  | 200 | % |  |  | (8 | ) |  |  | 14 |  |  |  | (157 | )% |
| Total |  | $ | (7 | ) |  | $ | 3 |  |  |  | (333 | )% |  | $ | (39 | ) |  | $ | 18 |  |  |  | (317 | )% |

[0001564590-20-056069:mdna:125]
Interest income decreased in the second quarter and first six months of fiscal 2021 compared to the corresponding periods of the prior year due to both a reduction in the size of our investment portfolio and lower yields earned on the investments.

[0001564590-20-056069:mdna:126]
Interest expense increased in the second quarter and first six months of fiscal 2021 compared to the corresponding periods of the prior year, as we issued Senior Notes in aggregate principal amount of $2.0 billion in the first quarter of fiscal 2021. The impact from the issuance of these Senior Notes was partially offset by the extinguishment of our Senior Notes due June 2021 in the first quarter of fiscal 2021, and a lower average outstanding commercial paper balance during fiscal 2021.

[0001564590-20-056069:mdna:127]
In the second quarter and first six months of fiscal 2021, Other income (expense), net includes a $6 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $8 million. This benefit was more than offset in the first six months period by a $14 million loss recognized from the extinguishment of our Senior Notes due June 2021 in the first quarter of fiscal 2021. Other income (expense), net for the first six months of fiscal 2020 includes a $14 million gain we realized on the sale of available-for-sale debt securities during that period. The remaining fluctuations in other income (expense), net are primarily due to foreign exchange gains and losses.

[0001564590-20-056069:mdna:128]
[same as prior period, unchanged from 0001564590-20-041759:mdna:123]

[0001564590-20-056069:mdna:129]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | % Change |  |
| Provision for income taxes |  | $ | 38 |  |  | $ | 56 |  |  |  | (32 | )% |  | $ | 65 |  |  | $ | 72 |  |  |  | (10 | )% |

[0001564590-20-056069:mdna:130]
Our effective tax rate for the second quarter of fiscal 2021 was 21.7% compared to 18.7% for the second quarter of fiscal 2020. Our effective tax rate for the first six months of fiscal 2021 was 23.3% compared to 17.2% for the corresponding period of fiscal 2020. Our effective tax rates reflect the impact of a significant amount of our earnings being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rates for the second quarter and first six months of fiscal 2021 increased compared to the corresponding period of the prior year primarily due to the impact of taxes resulting from the integration of acquired companies. The remaining differences in effective tax rates for the second quarter of fiscal 2021 compared to the corresponding period of the prior year are primarily due to differences in discrete tax benefits/expenses for stock-based compensation.  The remaining differences in effective tax rates for the first six months of fiscal 2021 compared to the corresponding period of the prior year are primarily due to certain discrete expenses, including foreign audit results and differences in discrete tax benefits for stock-based compensation in fiscal 2021.

[0001564590-20-056069:mdna:131]
As of October 30, 2020, we had $224 million of gross unrecognized tax benefits, of which $138 million has been recorded in other long-term liabilities. Inclusive of penalties, interest and certain income tax benefits, $138 million would affect our provision for income taxes if recognized.

[0001564590-20-056069:mdna:132]
[same as prior period, unchanged from 0001564590-20-041759:mdna:127]

[0001564590-20-056069:mdna:133]
[same as prior period, unchanged from 0001564590-20-041759:mdna:128]

[0001564590-20-056069:mdna:134]
| (In millions, except percentages) |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,646 |  |  | $ | 2,882 |  |
| Principal amount of debt |  | $ | 2,650 |  |  | $ | 1,673 |  |

[0001564590-20-056069:mdna:135]
[same as prior period, unchanged from 0001564590-20-041759:mdna:130]

[0001564590-20-056069:mdna:136]
|  |  | Six Months Ended |  |
| (In millions) |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Net cash provided by operating activities |  | $ | 401 |  |  | $ | 257 |  |
| Net cash provided by (used in) investing activities |  |  | (321 | ) |  |  | 1,116 |  |
| Net cash provided by (used in) financing activities |  |  | 746 |  |  |  | (1,148 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 44 |  |  |  | (5 | ) |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 870 |  |  | $ | 220 |  |

[0001564590-20-056069:mdna:137]
[same as prior period, unchanged from 0001564590-20-041759:mdna:132]

[0001564590-20-056069:mdna:138]
As of October 30, 2020, our cash, cash equivalents and short-term investments were $3.6 billion, an increase of $0.8 billion from April 24, 2020. The increase was primarily due to $2.0 billion of net proceeds from the issuance of long-term debt and $401 million of cash provided by operating activities, partially offset by $513 million used for the extinguishment of our Senior Notes due June 2021, $420 million used for the net repayment of commercial paper notes with original maturities of three months or less, $350 million used for the acquisitions of two privately-held companies, $214 million used for the payment of dividends, and $92 million in purchases of property and equipment. Working capital increased by $1.2 billion to $1.9 billion as of October 30, 2020 compared to April 24, 2020 primarily due to the increases in cash, cash equivalents and short-term investments discussed above, and the net repayment of commercial paper notes.

[0001564590-20-056069:mdna:139]
[same as prior period, unchanged from 0001564590-20-041759:mdna:134]

[0001564590-20-056069:mdna:140]
During the first six months of fiscal 2021, we generated cash from operating activities of $401 million, reflecting net income of $214 million, adjusted by non-cash depreciation and amortization of $105 million and stock-based compensation of $103 million, compared to $257 million of cash generated from operating activities during the first six months of fiscal 2020.

[0001564590-20-056069:mdna:141]
Changes in assets and liabilities in the first six months of fiscal 2021 included the following:

[0001564590-20-056069:mdna:142]
|  | • | Accounts receivable decreased $197 million, reflecting more favorable shipping linearity and seasonally lower invoicing levels for the first six months of fiscal 2021 compared to the last six months of fiscal 2020. |

[0001564590-20-056069:mdna:143]
37

[0001564590-20-056069:mdna:144]
|  | • | Deferred revenue and financed unearned services revenue decreased $118 million, primarily due to a decrease in deferred software and hardware maintenance contract revenues reflecting the seasonality of maintenance contract renewal activities. |

[0001564590-20-056069:mdna:145]
[same as prior period, unchanged from 0001564590-20-041759:mdna:140]

[0001564590-20-056069:mdna:146]
[same as prior period, unchanged from 0001564590-20-041759:mdna:141]

[0001564590-20-056069:mdna:147]
During the first six months of fiscal 2021, we generated $107 million from maturities and sales of investments, net of purchases, and paid $92 million for capital expenditures, while during the first six months of fiscal 2020, we generated $1.1 billion from maturities and sales of investments, net of purchases, and paid $68 million for capital expenditures. Additionally, during the first six months of fiscal 2021, we paid $350 million, net of cash acquired for two privately-held companies, as compared to $56 million, net of cash acquired that we paid in the first six months of fiscal 2020 for a privately-held company. Additionally, during the first six months of fiscal 2020, we received $96 million for the sale of land in Sunnyvale, California.

[0001564590-20-056069:mdna:148]
[same as prior period, unchanged from 0001564590-20-041759:mdna:143]

[0001564590-20-056069:mdna:149]
During the first six months of fiscal 2021, cash flows provided by financing activities totaled $746 million, primarily due to net cash proceeds of $2.0 billion from the issuance of Senior Notes, partially offset by the use of $513 million for the extinguishment of our Senior Notes due June 2021, $420 million for the net repayment of commercial paper notes with original maturities of three months or less, $214 million for the payment of dividends, and $176 million for the repayment of commercial paper notes with original maturities of greater than three months. During the first six months of fiscal 2020, we used $750 million for the repurchase of 14 million shares of common stock, $226 million for the payment of dividends, and $400 million for the repayment of our Senior Notes due September 2019, partially offset by $249 million in net proceeds from the issuance of commercial paper notes with original maturities of three months or less.

[0001564590-20-056069:mdna:150]
[same as prior period, unchanged from 0001564590-20-041759:mdna:145]

[0001564590-20-056069:mdna:151]
[same as prior period, unchanged from 0001564590-20-041759:mdna:146]

[0001564590-20-056069:mdna:152]
Our principal sources of liquidity as of October 30, 2020 consisted of cash and cash equivalents, short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001564590-20-056069:mdna:153]
[same as prior period, unchanged from 0001564590-20-041759:mdna:148]

[0001564590-20-056069:mdna:154]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Cash and cash equivalents |  | $ | 3,529 |  |  | $ | 2,658 |  |
| Short-term investments |  |  | 117 |  |  |  | 224 |  |
| Total |  | $ | 3,646 |  |  | $ | 2,882 |  |

[0001564590-20-056069:mdna:155]
As of October 30, 2020 and April 24, 2020, $2.2 billion and $2.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $1.4 billion and $0.4 billion, respectively, were available in the U.S. The TCJA imposed a one-time transition tax on substantially all accumulated foreign earnings through December 31, 2017, and generally allows companies to make distributions of foreign earnings without incurring additional federal taxes. As a part of the recognition of the impacts of the TCJA, we have reviewed our projected global cash requirements and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested.

[0001564590-20-056069:mdna:156]
38

[0001564590-20-056069:mdna:157]
[same as prior period, unchanged from 0001564590-20-041759:mdna:151]

[0001564590-20-056069:mdna:158]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of October 30, 2020.

[0001564590-20-056069:mdna:159]
[same as prior period, unchanged from 0001564590-20-041759:mdna:153]

[0001564590-20-056069:mdna:160]
[same as prior period, unchanged from 0001564590-20-041759:mdna:154]

[0001564590-20-056069:mdna:161]
The following table summarizes the principal amount of our Senior Notes as of October 30, 2020 (in millions):

[0001564590-20-056069:mdna:162]
| 3.25% Senior Notes Due December 2022 |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,650 |  |

[0001564590-20-056069:mdna:163]
[same as prior period, unchanged from 0001564590-20-041759:mdna:157]

[0001564590-20-056069:mdna:164]
Commercial Paper Program and Credit Facility

[0001564590-20-056069:mdna:165]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of October 30, 2020.

[0001564590-20-056069:mdna:166]
In connection with the Program, we have a senior unsecured credit agreement that expires on December 10, 2021. The credit agreement provides a $1.0 billion revolving unsecured credit facility that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes, providing another potential source of liquidity to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement also includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of October 30, 2020, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-20-056069:mdna:167]
[same as prior period, unchanged from 0001564590-20-041759:mdna:161]

[0001564590-20-056069:mdna:168]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2021 to be between $50 million and $100 million.

[0001564590-20-056069:mdna:169]
[same as prior period, unchanged from 0001564590-20-041759:mdna:182]

[0001564590-20-056069:mdna:170]
[same as prior period, unchanged from 0001564590-20-041759:mdna:163]

[0001564590-20-056069:mdna:171]
On November 23, 2020, we declared a cash dividend of $0.48 per share of common stock, payable on January 27, 2021 to holders of record as of the close of business on January 8, 2021.

[0001564590-20-056069:mdna:172]
As of October 30, 2020, our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through October 30, 2020, we repurchased a total of 338 million shares of our common stock at an average price of $38.86 per share, for an aggregate purchase price of $13.1 billion. As of October 30, 2020, the remaining authorized amount for stock repurchases under this program was $0.5 billion.

[0001564590-20-056069:mdna:173]
During the first quarter of fiscal 2021, we announced the suspension of our stock repurchases to strengthen our liquidity position given the uncertainty surrounding the overall impact of the ongoing COVID-19 pandemic. More recently, we have been encouraged by the stability of our business, broader macro trends and the positive results of several COVID-19 vaccine trials. As a result, we plan to reinitiate our share repurchase program during our third quarter of fiscal 2021.

[0001564590-20-056069:mdna:174]
[same as prior period, unchanged from 0001564590-20-041759:mdna:167]

[0001564590-20-056069:mdna:175]
[same as prior period, unchanged from 0001564590-20-041759:mdna:168]

[0001564590-20-056069:mdna:176]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 30, 2020, we had $566 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-20-056069:mdna:177]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of October 30, 2020, we had $192 million in other purchase obligations.

[0001564590-20-056069:mdna:178]
[same as prior period, unchanged from 0001564590-20-041759:mdna:171]

[0001564590-20-056069:mdna:179]
As of October 30, 2020, our liability for uncertain tax positions was $138 million, including interest, penalties and certain income tax benefits. Due to uncertainties regarding tax audits and their possible outcomes, we are unable to make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-20-056069:mdna:180]
[same as prior period, unchanged from 0001564590-20-041759:mdna:173]

[0001564590-20-056069:mdna:181]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $26 million and $34 million of receivables during the first six months of fiscal 2021 and fiscal 2020, respectively.

[0001564590-20-056069:mdna:182]
[same as prior period, unchanged from 0001564590-20-041759:mdna:175]

[0001564590-20-056069:mdna:183]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of October 30, 2020 and April 24, 2020, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-20-056069:mdna:184]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of October 30, 2020, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-20-056069:mdna:185]
[same as prior period, unchanged from 0001564590-20-041759:mdna:178]

[0001564590-20-056069:mdna:186]
[same as prior period, unchanged from 0001564590-20-041759:mdna:179]

[0001564590-20-056069:mdna:187]
Legal Contingencies

[0001564590-20-056069:mdna:188]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 16 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0001564590-20-056069:mdna:189]
41
