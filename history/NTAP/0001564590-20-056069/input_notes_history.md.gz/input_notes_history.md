# NTAP note change history — 0001564590-20-041759 → 0001564590-20-056069


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-12-03):
[0001564590-20-056069:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 30, 2020, we had $566 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 30, 2020 and April 24, 2020, such liability amounted to $10 million and $6 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2020-08-28, similarity 0.9889):
[0001564590-20-041759:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 31, 2020, we had $614 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 31, 2020 and April 24, 2020, such liability amounted to $7 million and $6 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2020-12-03):
[0001564590-20-056069:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 30, 2020, we had $192 million in other purchase obligations.
  (was, 2020-08-28, similarity 0.9825):
[0001564590-20-041759:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 31, 2020, we had $205 million in other purchase obligations.

- changed (2020-12-03):
[0001564590-20-056069:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $26 million and $34 million of receivables during the six months ended October 30, 2020 and October 25, 2019, respectively.
  (was, 2020-08-28, similarity 0.9713):
[0001564590-20-041759:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $13 million and $14 million of receivables during the three months ended July 31, 2020 and July 26, 2019, respectively.

- changed (2020-12-03):
[0001564590-20-056069:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of October 30, 2020 and April 24, 2020, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2020-08-28, similarity 0.9951):
[0001564590-20-041759:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of July 31, 2020 and April 24, 2020, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- added (2020-12-03):
[0001564590-20-056069:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 30, 2020, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- changed (2020-12-03):
[0001564590-20-056069:note_history:6]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised
  (was, 2020-08-28, similarity 0.8151):
[0001564590-20-041759:note_history:6]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. We believe the complaint is without merit and intend to defend the case vigorously.

- added (2020-12-03):
[0001564590-20-056069:note_history:7]
financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. We believe the complaint is without merit and intend to defend the case vigorously.

- changed (2020-12-03):
[0001564590-20-056069:note_history:8]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of October 30, 2020 related to such matters.
  (was, 2020-08-28, similarity 0.9938):
[0001564590-20-041759:note_history:8]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends.  No material accrual has been recorded as of July 31, 2020 related to such matters.

- removed (2020-12-03):
[0001564590-20-041759:note_history:9]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 31, 2020, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-12-03):
[0001564590-20-056069:note_history:10]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2020 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 30, 2020 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2020-08-28, similarity 0.8787):
[0001564590-20-041759:note_history:10]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2020 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 31, 2020 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- changed (2020-12-03):
[0001564590-20-056069:note_history:11]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates. Management’s estimates include, as applicable, the anticipated impacts of the COVID-19 pandemic.
  (was, 2020-08-28, similarity 0.9983):
[0001564590-20-041759:note_history:11]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates. Management’s estimates include, as applicable, the anticipated impacts of the COVID-19 pandem


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-12-03):
[0001564590-20-056069:note_history:12]
|  |  |  |  |  |  | October 30, 2020 |  |  | April 24, 2020 |  |
|  |  | Effective Interest Rate |  |  | Amount |  |  | Amount |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  | $ | — |  |  | $ | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | — |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | — |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | — |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 1,150 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (19 | ) |  |  | (4 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,631 |  |  | $ | 1,146 |  |
  (was, 2020-08-28, similarity 0.9917):
[0001564590-20-041759:note_history:12]
|  |  |  |  |  |  | July 31, 2020 |  |  | April 24, 2020 |  |
|  |  | Effective Interest Rate |  |  | Amount |  |  | Amount |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  | $ | — |  |  | $ | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | — |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | — |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | — |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 1,150 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (20 | ) |  |  | (4 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,630 |  |  | $ | 1,146 |  |

- changed (2020-12-03):
[0001564590-20-056069:note_history:13]
In June 2020, we issued $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, for which we received total proceeds of approximately $2.0 billion, net of discount and issuance costs. Interest on these Senior Notes is payable semi-annually in June and December. On July 27, 2020, we extinguished our 3.375% Senior Notes due June 2021 for an aggregate cash redemption price of $513 million, plus accrued and unpaid interest. As part of the debt extinguishment, we recognized a loss of $14 million during the first quarter of fiscal 2021, which includes a cash redemption premium of $13 million and the write-off of unamortized discount and issuance costs totaling $1 million. The loss on extinguishment of debt is included in other income (expense), net in our Condensed Consolidated Statement of Operations for the six months ended October 30, 2020.
  (was, 2020-08-28, similarity 0.9502):
[0001564590-20-041759:note_history:13]
In June 2020, we issued $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, for which we received total proceeds of approximately $2.0 billion, net of discount and issuance costs. Interest on these Senior Notes is payable semi-annually in June and December. On July 27, 2020, we extinguished our 3.375% Senior Notes due June 2021 for an aggregate cash redemption price of $513 million, plus accrued and unpaid interest. As part of the debt extinguishment, we recognized a loss of $14 million, which includes a cash redemption premium of $13 million and the write-off of unamortized discount and issuance costs totaling $1 million. The loss on extinguishment of debt is included in other income (expense), net in our Condensed Consolidated Statement of Operations for the three months ended July 31, 2020.

- changed (2020-12-03):
[0001564590-20-056069:note_history:14]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 30, 2020, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2020-08-28, similarity 0.9915):
[0001564590-20-041759:note_history:14]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 31, 2020, we were in compliance with all covenants associated with the Senior Notes.

- changed (2020-12-03):
[0001564590-20-056069:note_history:15]
As of October 30, 2020, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2020-08-28, similarity 0.9405):
[0001564590-20-041759:note_history:15]
As of July 31, 2020, our aggregate future principal debt maturities are as follows (in millions):

- changed (2020-12-03):
[0001564590-20-056069:note_history:16]
| Fiscal Year |  | Amount |  |
| 2023 |  | $ | 250 |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |
  (was, 2020-08-28, similarity 0.9919):
[0001564590-20-041759:note_history:16]
| Fiscal Year |  | Amount |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |

- changed (2020-12-03):
[0001564590-20-056069:note_history:17]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. While no commercial paper notes were outstanding as of October 30, 2020, we had commercial paper notes outstanding with an aggregate principal amount of $523 million, a weighted-average interest rate of  2.01%, and maturities primarily less than three months as of April 24, 2020. During
  (was, 2020-08-28, similarity 0.794):
[0001564590-20-041759:note_history:17]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of July 31, 2020 and April 24, 2020, we had commercial paper notes outstanding with aggregate principal amounts of $150 million and $523 million, respectively, weighted-average interest rates of 1.29% and 2.01%, respectively, and maturities primarily less than three months.

- changed (2020-12-03):
[0001564590-20-056069:note_history:18]
the first six months of fiscal 2021, we received proceeds of $75 million from the issuance, and made repayments of $176 million for the settlement, of commercial paper notes with original maturities greater than three months.
  (was, 2020-08-28, similarity 0.9):
[0001564590-20-041759:note_history:18]
During the first quarter of fiscal 2021, we received proceeds of $75 million from the issuance, and made repayments of $76 million for the settlement, of commercial paper notes with original maturities greater than three months.

- changed (2020-12-03):
[0001564590-20-056069:note_history:19]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of October 30, 2020 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.
  (was, 2020-08-28, similarity 0.9939):
[0001564590-20-041759:note_history:19]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of July 31, 2020 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-12-03):
[0001564590-20-056069:note_history:20]
|  |  |  |  |  |  | October 30, 2020 |  |  | April 24, 2020 |  |
|  |  | Effective Interest Rate |  |  | Amount |  |  | Amount |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  | $ | — |  |  | $ | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | — |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | — |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | — |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 1,150 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (19 | ) |  |  | (4 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,631 |  |  | $ | 1,146 |  |
  (was, 2020-08-28, similarity 0.9917):
[0001564590-20-041759:note_history:20]
|  |  |  |  |  |  | July 31, 2020 |  |  | April 24, 2020 |  |
|  |  | Effective Interest Rate |  |  | Amount |  |  | Amount |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  | $ | — |  |  | $ | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | — |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | — |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | — |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 1,150 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (20 | ) |  |  | (4 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,630 |  |  | $ | 1,146 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-12-03):
[0001564590-20-056069:note_history:21]
As of October 30, 2020, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2020-08-28, similarity 0.9405):
[0001564590-20-041759:note_history:21]
As of July 31, 2020, our aggregate future principal debt maturities are as follows (in millions):

- changed (2020-12-03):
[0001564590-20-056069:note_history:22]
| Fiscal Year |  | Amount |  |
| 2023 |  | $ | 250 |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |
  (was, 2020-08-28, similarity 0.9919):
[0001564590-20-041759:note_history:22]
| Fiscal Year |  | Amount |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-12-03):
[0001564590-20-056069:note_history:23]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Product revenues |  | $ | 749 |  |  | $ | 771 |  |  | $ | 1,376 |  |  | $ | 1,415 |  |
| Software maintenance revenues |  | 303 |  |  | 254 |  |  | 604 |  |  | 504 |  |
| Hardware maintenance and other services revenues |  | 364 |  |  | 346 |  |  |  | 739 |  |  |  | 688 |  |
| Hardware maintenance support contracts |  | 296 |  |  | 286 |  |  | 603 |  |  |  | 570 |  |
| Professional and other services |  | 68 |  |  | 60 |  |  | 136 |  |  |  | 118 |  |
| Net revenues |  | $ | 1,416 |  |  | $ | 1,371 |  |  | $ | 2,719 |  |  | $ | 2,607 |  |

- removed (2020-12-03):
[0001564590-20-041759:note_history:24]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Product revenues |  | $ | 627 |  |  | $ | 644 |  |
| Software maintenance revenues |  | 301 |  |  | 250 |  |
| Hardware maintenance and other services revenues |  |  | 375 |  |  |  | 342 |  |
| Hardware maintenance support contracts |  | 307 |  |  |  | 284 |  |
| Professional and other services |  | 68 |  |  |  | 58 |  |
| Net revenues |  | $ | 1,303 |  |  | $ | 1,236 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-12-03):
[0001564590-20-056069:note_history:25]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Product revenues |  | $ | 749 |  |  | $ | 771 |  |  | $ | 1,376 |  |  | $ | 1,415 |  |
| Software maintenance revenues |  | 303 |  |  | 254 |  |  | 604 |  |  | 504 |  |
| Hardware maintenance and other services revenues |  | 364 |  |  | 346 |  |  |  | 739 |  |  |  | 688 |  |
| Hardware maintenance support contracts |  | 296 |  |  | 286 |  |  | 603 |  |  |  | 570 |  |
| Professional and other services |  | 68 |  |  | 60 |  |  | 136 |  |  |  | 118 |  |
| Net revenues |  | $ | 1,416 |  |  | $ | 1,371 |  |  | $ | 2,719 |  |  | $ | 2,607 |  |

- changed (2020-12-03):
[0001564590-20-056069:note_history:26]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Deferred product revenue |  | $ | 39 |  |  | $ | 75 |  |
| Deferred services revenue |  |  | 3,554 |  |  |  | 3,567 |  |
| Financed unearned services revenue |  |  | 58 |  |  |  | 56 |  |
| Total |  | $ | 3,651 |  |  | $ | 3,698 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,815 |  |  | $ | 1,894 |  |
| Long-term |  |  | 1,836 |  |  |  | 1,804 |  |
| Total |  | $ | 3,651 |  |  | $ | 3,698 |  |
  (was, 2020-08-28, similarity 0.9852):
[0001564590-20-041759:note_history:26]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Deferred product revenue |  | $ | 49 |  |  | $ | 75 |  |
| Deferred services revenue |  |  | 3,520 |  |  |  | 3,567 |  |
| Financed unearned services revenue |  |  | 51 |  |  |  | 56 |  |
| Total |  | $ | 3,620 |  |  | $ | 3,698 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,814 |  |  | $ | 1,894 |  |
| Long-term |  |  | 1,806 |  |  |  | 1,804 |  |
| Total |  | $ | 3,620 |  |  | $ | 3,698 |  |

- added (2020-12-03):
[0001564590-20-056069:note_history:27]
|  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Balance at beginning of period |  | $ | 3,698 |  |  | $ | 3,668 |  |
| Additions |  |  | 1,364 |  |  |  | 1,011 |  |
| Revenue recognized during the period |  |  | (1,411 | ) |  |  | (1,211 | ) |
| Balance at end of period |  | $ | 3,651 |  |  | $ | 3,468 |  |

- changed (2020-12-03):
[0001564590-20-056069:note_history:28]
During the six months ended October 30, 2020 and October 25, 2019, we recognized $1,207 million and $1,045 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.
  (was, 2020-08-28, similarity 0.9004):
[0001564590-20-041759:note_history:28]
During the three months ended July 31, 2020 and July 26, 2019, we recognized $661 million and $552 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

- changed (2020-12-03):
[0001564590-20-056069:note_history:29]
As of October 30, 2020, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,651 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 26% in the next 13 to 24 months, and the remainder thereafter.
  (was, 2020-08-28, similarity 0.9925):
[0001564590-20-041759:note_history:29]
As of July 31, 2020, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,620 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 25% in the next 13 to 24 months, and the remainder thereafter.

- added (2020-12-03):
[0001564590-20-056069:note_history:30]
|  |  | Six Months Ended |  |
|  |  | October 30, 2020 |  |  | October 25, 2019 |  |
| Balance at beginning of period |  | $ | 156 |  |  | $ | 172 |  |
| Additions |  |  | 57 |  |  |  | 32 |  |
| Expense recognized during the period |  |  | (45 | ) |  |  | (50 | ) |
| Balance at end of period |  | $ | 168 |  |  | $ | 154 |  |

- changed (2020-12-03):
[0001564590-20-056069:note_history:31]
|  |  | October 30, 2020 |  |  | April 24, 2020 |  |
| Other current assets |  | $ | 70 |  |  | $ | 67 |  |
| Other non-current assets |  |  | 98 |  |  |  | 89 |  |
| Total deferred commissions |  | $ | 168 |  |  | $ | 156 |  |
  (was, 2020-08-28, similarity 0.9708):
[0001564590-20-041759:note_history:31]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Other current assets |  | $ | 64 |  |  | $ | 67 |  |
| Other non-current assets |  |  | 88 |  |  |  | 89 |  |
| Total deferred commissions |  | $ | 152 |  |  | $ | 156 |  |

- removed (2020-12-03):
[0001564590-20-041759:note_history:32]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Product revenues |  | $ | 627 |  |  | $ | 644 |  |
| Software maintenance revenues |  | 301 |  |  | 250 |  |
| Hardware maintenance and other services revenues |  |  | 375 |  |  |  | 342 |  |
| Hardware maintenance support contracts |  | 307 |  |  |  | 284 |  |
| Professional and other services |  | 68 |  |  |  | 58 |  |
| Net revenues |  | $ | 1,303 |  |  | $ | 1,236 |  |

- removed (2020-12-03):
[0001564590-20-041759:note_history:33]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Balance at beginning of period |  | $ | 3,698 |  |  | $ | 3,668 |  |
| Additions |  |  | 644 |  |  |  | 447 |  |
| Revenue recognized during the period |  |  | (722 | ) |  |  | (605 | ) |
| Balance at end of period |  | $ | 3,620 |  |  | $ | 3,510 |  |

- removed (2020-12-03):
[0001564590-20-041759:note_history:34]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Balance at beginning of period |  | $ | 156 |  |  | $ | 172 |  |
| Additions |  |  | 21 |  |  |  | 16 |  |
| Expense recognized during the period |  |  | (25 | ) |  |  | (25 | ) |
| Balance at end of period |  | $ | 152 |  |  | $ | 163 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2020-12-03):
[0001564590-20-041759:note_history:35]
17. Subsequent Event

- removed (2020-12-03):
[0001564590-20-041759:note_history:36]
On August 25, 2020, we committed to a restructuring plan to optimize our business and fund our biggest opportunities. In connection with the restructuring plan, we expect to reduce our global workforce by approximately 5%. This reduction in workforce will be implemented throughout fiscal 2021. We expect to incur aggregate expenses of $35 million to $40 million for employee terminations and other costs associated with the restructuring plan. We expect that most of these expenses will be cash expenditures and that we will recognize the majority of these expenses in our second quarter of fiscal 2021.
