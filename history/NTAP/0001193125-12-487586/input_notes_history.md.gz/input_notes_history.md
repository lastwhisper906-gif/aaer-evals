# NTAP note change history — 0001193125-12-375807 → 0001193125-12-487586


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2012-11-30):
[0001193125-12-487586:note_history:1]
As of October 26, 2012, future annual minimum lease
payments under all non-cancelable facilities and equipment
operating leases with an initial term in excess of one year totaled
$334.6 million.
  (was, 2012-08-30, similarity 0.9699):
[0001193125-12-375807:note_history:1]
As of July 27, 2012, future annual minimum lease payments
under all non-cancelable facilities and equipment operating leases
with an initial term in excess of one year totaled $325.7
million.

- changed (2012-11-30):
[0001193125-12-487586:note_history:2]
As of October 26, 2012, we have three leasing arrangements
with BNP Paribas LLC (BNPPLC), one of which require us to lease
certain of our land to BNPPLC for a period of 99 years and all
of which require us to lease approximately 0.3 million square
feet of office space from BNPPLC for our headquarters in Sunnyvale,
California, which had an original cost of $69.6 million. Under
these leasing arrangements, we pay BNPPLC minimum lease payments,
which vary based on a fixed rate on the costs of the facilities on
the respective lease commencement dates. We make payments for each
of the leases for a term of five years. We have the option to renew
each of the leases for two consecutive five-year periods upon
approval by BNPPLC. The initial lease terms expire in December 2012
and January 2013. Upon expiration (or upon any earlier termination)
of the lease terms, we must elect one of the following options:
(i) purchase the buildings from BNPPLC at cost; (ii) if
certain conditions are met, arrange for the sale of the buildings
by BNPPLC to a third-party, and be liable for any deficiency
between the net proceeds received from the third-party and
BNPPLC’s cost, up to 85% of cost (residual guarantee); or
(iii) pay BNPPLC supplemental payments for an amount equal to
the difference between BNPPLC’s cost and fair value, up to
the residual guarantee, in which event we may recoup some or all of
such payments by arranging for a sale of each or all buildings by
BNPPLC during the ensuing two-year period.
  (was, 2012-08-30, similarity 0.9963):
[0001193125-12-375807:note_history:2]
As of July 27, 2012, we have three leasing arrangements
with BNP Paribas LLC (BNPPLC), one of which require us to lease
certain of our land to BNPPLC for a period of 99 years and all
of which require us to lease approximately 0.3 million square
feet of office space from BNPPLC for our headquarters in Sunnyvale,
California, which had an original cost of $69.6 million. Under
these leasing arrangements, we pay BNPPLC minimum lease payments,
which vary based on a fixed rate on the costs of the facilities on
the respective lease commencement dates. We make payments for each
of the leases for a term of five years. We have the option to renew
each of the leases for two consecutive five-year periods upon
approval by BNPPLC. The initial lease terms expire in December 2012
and January 2013. Upon expiration (or upon any earlier termination)
of the lease terms, we must elect one of the following options:
(i) purchase the buildings from BNPPLC at cost; (ii) if
certain conditions are met, arrange for the sale of the buildings
by BNPPLC to a third-party, and be liable for any deficiency
between the net proceeds received from the third-party and
BNPPLC’s cost, up to 85% of cost (residual guarantee); or
(iii) pay BNPPLC supplemental payments for an amount equal to
the difference between BNPPLC’s cost and fair value, up to
the residual guarantee, in which event we may recoup some or all of
such payments by arranging for a sale of each or all buildings by
BNPPLC during the ensuing two-year period.

- added (2012-11-30):
[0001193125-12-487586:note_history:3]
These leases require us to maintain specified financial
covenants with which we were in compliance as of October 26,
2012. Such financial covenants include a maximum ratio of Total
Debt to Earnings before Interest, Taxes, Depreciation and
Amortization of less than 3:1 and a minimum amount of Unencumbered
Cash and Short-Term Investments of $300.0 million.

- changed (2012-11-30):
[0001193125-12-487586:note_history:4]
In the normal course of business we make commitments to our
third-party contract manufacturers, to manage manufacturer lead
times and meet product forecasts, and to other parties, to purchase
various key components used in the manufacture of our products. We
establish accruals for estimated losses on purchased components to
the extent we believe it is probable that such components will not
be utilized in future operations. To the extent that such forecasts
are not achieved, our commitments and associated accruals may
change. As of October 26, 2012, we had $266.7 million in
non-cancelable purchase commitments with our contract
manufacturers. In addition, we recorded a liability for firm,
non-cancelable and unconditional purchase commitments with contract
manufacturers for quantities in excess of our future demand
forecasts through a charge to cost of product sales. As of
October 26, 2012 and April 27, 2012, such liability
amounted to $8.5 million and $3.3 million, respectively, and is
included in other current liabilities in the condensed consolidated
balance sheets.
  (was, 2012-08-30, similarity 0.7584):
[0001193125-12-375807:note_history:4]
In the normal course of business we make commitments to our
third-party contract manufacturers, to manage manufacturer lead
times and meet product forecasts, and to other parties, to purchase
various key components used in the manufacture of our products. We
establish accruals for estimated losses on purchased components to
the extent we believe it is probable that such components will not
be utilized in future operations. To the extent that such forecasts
are not achieved, our commitments and associated accruals may
change. We had $281.0 million in non-cancelable purchase
commitments with our contract manufacturers as of July 27,
2012. In addition, we recorded a liability for firm, non-cancelable
and unconditional purchase commitments with contract manufacturers
for quantities in excess of our future demand forecasts through a
charge to product cost of sales. As of July 27, 2012 and
April 27, 2012, such liability amounted to $7.2 million and
$3.3 million, respectively, and is included in other current
liabilities in the condensed consolidated balance
sheets.

- changed (2012-11-30):
[0001193125-12-487586:note_history:5]
In addition to commitments with contract manufacturers and
component suppliers, we have open purchase orders and contractual
obligations associated with our ordinary course business for which
we have not received goods or services. As of October 26,
2012, we had $41.5 million in capital purchase commitments and
$190.1 million in other purchase commitments.
  (was, 2012-08-30, similarity 0.984):
[0001193125-12-375807:note_history:5]
In addition to commitments with contract manufacturers and
component suppliers, we have open purchase orders and contractual
obligations associated with our ordinary course business for which
we have not received goods or services. As of July 27, 2012,
we had $50.3 million in capital purchase commitments and $200.6
million in other purchase commitments.

- added (2012-11-30):
[0001193125-12-487586:note_history:6]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Beginning balance |  | $ | 96.5 |  |  | $ | 59.5 |  |  | $ | 83.1 |  |  | $ | 40.5 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 17.5 |  |
| Expense accrued during the period |  |  | 27.1 |  |  |  | 15.7 |  |  |  | 50.8 |  |  |  | 27.4 |  |
| Warranty costs incurred |  |  | (11.8 | ) |  |  | (10.2 | ) |  |  | (22.1 | ) |  |  | (20.4 | ) |
| Ending balance |  | $ | 111.8 |  |  | $ | 65.0 |  |  | $ | 111.8 |  |  | $ | 65.0 |  |

- changed (2012-11-30):
[0001193125-12-487586:note_history:7]
Some of our customers have entered into recourse and
non-recourse financing leasing arrangements using third-party
financing companies, and in some situations, we enter into customer
financing arrangements for our products and services that are
contemporaneously sold on a recourse or non-recourse basis to
third-party financing companies. Under the terms of recourse
leases, which are generally three years or less, we remain liable
for the aggregate unpaid remaining lease payments to the
third-party leasing companies in the event of end-user customer
default. These arrangements are generally collateralized by a
security interest in the underlying assets. Under the terms of the
nonrecourse leases, we do not have any continuing obligations or
liabilities to the third-party financing companies. Where we
provide a guarantee for recourse leases, we defer revenues subject
to the industry-specific software revenue recognition guidance, and
recognize revenues for non-software deliverables in accordance with
our multiple deliverable revenue arrangement policy.
  (was, 2012-08-30, similarity 0.8468):
[0001193125-12-375807:note_history:7]
Some of our customers have entered into recourse and
nonrecourse financing leasing arrangements using third-party
financing companies. Under the terms of recourse leases, which are
generally three years or less, we remain liable for the aggregate
unpaid remaining lease payments to the third-party leasing
companies in the event of end-user customer default. These
arrangements are generally collateralized by a security interest in
the underlying assets. Under the terms of the nonrecourse leases,
we do not have any continuing obligations or liabilities to the
third-party financing companies. Where we provide a guarantee for
recourse leases, we defer revenues subject to the industry-specific
software revenue recognition guidance, and recognize revenues for
non-software deliverables in accordance with our multiple
deliverable revenue arrangement policy.

- changed (2012-11-30):
[0001193125-12-487586:note_history:8]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Maximum guaranteed payment contingencies |  | $ | 170.8 |  |  | $ | 169.0 |  |
| Deferred revenue associated with financing guarantees |  |  | (154.5 | ) |  |  | (149.9 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 16.3 |  |  | $ | 19.1 |  |
  (was, 2012-08-30, similarity 0.9828):
[0001193125-12-375807:note_history:8]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Maximum guaranteed payment contingencies |  | $ | 161.4 |  |  | $ | 169.0 |  |
| Deferred revenue associated with financing guarantees |  |  | (151.3 | ) |  |  | (149.9 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 10.1 |  |  | $ | 19.1 |  |

- changed (2012-11-30):
[0001193125-12-487586:note_history:9]
We are subject to various legal proceedings and claims that
arise in the normal course of business. No material accrual has
been recorded as of October 26, 2012 related to such
matters.
  (was, 2012-08-30, similarity 0.9692):
[0001193125-12-375807:note_history:9]
We are subject to various legal proceedings and claims that
arise in the normal course of business. No material accrual has
been recorded as of July 27, 2012 related to such
matters.

- removed (2012-11-30):
[0001193125-12-375807:note_history:10]
These leases require us to maintain specified financial
covenants with which we were in compliance as of July 27,
2012. Such financial covenants include a maximum ratio of Total
Debt to Earnings before Interest, Taxes, Depreciation and
Amortization of less than 3:1 and a minimum amount of Unencumbered
Cash and Short-Term Investments of $300.0 million.

- removed (2012-11-30):
[0001193125-12-375807:note_history:11]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Beginning balance |  | $ | 83.1 |  |  | $ | 40.5 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 17.5 |  |
| Expense accrued during the period |  |  | 23.7 |  |  |  | 11.7 |  |
| Warranty costs incurred |  |  | (10.3 | ) |  |  | (10.2 | ) |
| Ending balance |  | $ | 96.5 |  |  | $ | 59.5 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2012-11-30):
[0001193125-12-487586:note_history:12]
Fiscal Year — Our fiscal year is reported on
a 52- or 53-week year ending on the last Friday in April. The first
and second quarters of fiscal 2013 and 2012 were each 13-week
periods.
  (was, 2012-08-30, similarity 0.9674):
[0001193125-12-375807:note_history:12]
Fiscal Year — Our fiscal year is reported on
a 52- or 53-week year ending on the last Friday in April. The first
quarters of fiscal 2013 and 2012 were each 13-week
periods.

- changed (2012-11-30):
[0001193125-12-487586:note_history:13]
Basis of Presentation — The accompanying unaudited
condensed consolidated financial statements have been prepared by
the Company, and reflect all adjustments, consisting only of normal
recurring adjustments, that are, in the opinion of management,
necessary for the fair presentation of our financial position,
results of operations, and cash flows for the interim periods
presented. The statements have been prepared in accordance with
accounting principles generally accepted in the United States of
America (GAAP) for interim financial information and in accordance
with the instructions to Form 10-Q and Rule 10-01 of Regulation
S-X. Accordingly, these statements do not include all information
and footnotes required by GAAP for annual consolidated financial
statements, and should be read in conjunction with our audited
consolidated financial statements as of and for the fiscal year
ended April 27, 2012 contained in our Annual Report on Form
10-K filed with the Securities and Exchange Commission on
June 19, 2012. The results of operations for the three and six
months ended October 26, 2012 are not necessarily indicative
of the operating results to be expected for the full fiscal year or
future operating periods.
  (was, 2012-08-30, similarity 0.9017):
[0001193125-12-375807:note_history:13]
Basis of Presentation — The accompanying unaudited
condensed consolidated financial statements have been prepared by
the Company, and reflect all adjustments, consisting only of normal
recurring adjustments that are, in the opinion of management,
necessary for the fair presentation of our financial position,
results of operations, and cash flows for the interim periods
presented. The statements have been prepared in accordance with
accounting principles generally accepted in the United States of
America (GAAP) for interim financial information and in accordance
with the instructions to Form 10-Q and Rule 10-01 of Regulation
S-X. Accordingly, these statements do not include all information
and footnotes required by GAAP for annual consolidated financial
statements, and should be read in conjunction with our audited
consolidated financial statements as of and for the fiscal year
ended April 27, 2012 contained in our Annual Report on Form
10-K filed with the Securities and Exchange Commission on
June 19, 2012. The results of operations for the three months
ended July 27, 2012 are not necessarily indicative of the
operating results to be expected for the full fiscal year or future
operating periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2012-11-30):
[0001193125-12-487586:note_history:14]
There have been no significant changes in our significant
accounting policies as of and for the six months ended
October 26, 2012, as compared to the significant accounting
policies described in our Annual Report on Form 10-K for the fiscal
year ended April 27, 2012.
  (was, 2012-08-30, similarity 0.9625):
[0001193125-12-375807:note_history:14]
There have been no significant changes in our significant
accounting policies as of and for the three months ended
July 27, 2012, as compared to the significant accounting
policies described in our Annual Report on Form 10-K for the fiscal
year ended April 27, 2012.

- added (2012-11-30):
[0001193125-12-487586:note_history:15]
In September 2011, the Financial Accounting Standards
Board (FASB) issued a revised accounting standard intended to
simplify how an entity tests goodwill for impairment. The revised
standard will allow an entity to first assess qualitative factors
to determine whether it is necessary to perform the two-step
quantitative goodwill impairment test. An entity will no longer be
required to calculate the fair value of a reporting unit unless it
determines, based on a qualitative assessment, that it is more
likely than not that its fair value is less than its carrying
amount. This guidance is effective for us beginning in our fourth
quarter of fiscal 2013. We do not expect this guidance to have a
material impact on our consolidated financial
statements.

- changed (2012-11-30):
[0001193125-12-487586:note_history:16]
In December 2011, the FASB issued new guidance that will
require us to disclose information about offsetting arrangements
associated with financial and derivative instruments to enable
users of our financial statements to understand the effect of those
arrangements on our financial position. This guidance is effective
for us beginning in our first quarter of fiscal 2014, at which time
we will include the applicable disclosures required by this
accounting standard update. Other than requiring additional
disclosures related to offsetting arrangements, we do not
anticipate material impacts on our financial statements upon
adoption.
  (was, 2012-08-30, similarity 0.8234):
[0001193125-12-375807:note_history:16]
In December 2011, the Financial Accounting Standards Board
issued new guidance that will require us to disclose information
about offsetting arrangements associated with financial and
derivative instruments to enable users of our financial statements
to understand the effect of those arrangements on our financial
position. This guidance is effective for us beginning in our first
quarter of fiscal 2014, at which time we will include the
applicable disclosures required by this accounting standard
update.

- removed (2012-11-30):
[0001193125-12-375807:note_history:17]
In September 2011, the FASB issued a revised accounting
standard intended to simplify how an entity tests goodwill for
impairment. The revised standard will allow an entity to first
assess qualitative factors to determine whether it is necessary to
perform the two-step quantitative goodwill impairment test. An
entity will no longer be required to calculate the fair value of a
reporting unit unless it determines, based on a qualitative
assessment, that it is more likely than not that its fair value is
less than its carrying amount. This guidance is effective for us
beginning in our fourth quarter of fiscal 2013. We do not expect
this guidance to have a material impact on our consolidated
financial statements.


## ntap:DebtDiscountAndIssuanceCostTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2012-11-30):
[0001193125-12-487586:note_history:18]
The following table reflects the remaining debt discount and
issuance costs as of October 26, 2012 (in
millions):
  (was, 2012-08-30, similarity 0.9484):
[0001193125-12-375807:note_history:18]
The following table reflects the remaining debt discount and
issuance costs as of July 27, 2012 (in millions):


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2012-11-30):
[0001193125-12-487586:note_history:19]
Our common stock price did not exceed the conversion threshold
price of $41.41 per share set forth for the Notes for at least 20
trading days during the 30 consecutive trading days ended
September 30, 2012, and accordingly, as of October 26,
2012, the Notes were not convertible at the option of the holder.
Since the Notes were not convertible, the difference between the
principal amount and the carrying value of the Notes was reflected
as equity on our condensed consolidated balance sheet as of
October 26, 2012.

- changed (2012-11-30):
[0001193125-12-487586:note_history:20]
The determination of whether or not the Notes are convertible
must continue to be performed quarterly. Consequently, if the
conversion threshold is exceeded during the quarter ending
January 25, 2013, the Notes will become unconditionally
convertible at that time. At such time that the Notes become
convertible at the option of the holder, the difference between the
principal amount and the carrying value of the Notes would be
reflected as convertible debt in mezzanine on our condensed
consolidated balance sheets.
  (was, 2012-08-30, similarity 0.7523):
[0001193125-12-375807:note_history:20]
The determination of whether or not the Notes are convertible
must continue to be performed quarterly. Consequently, the
Notes may be convertible in future quarters prior to March 1,
2013 at which time they become unconditionally convertible. If the
Notes become convertible at the option of the holder, the
difference between the principal amount and the carrying value of
the Notes would be reflected as convertible debt in mezzanine on
our condensed consolidated balance sheets.

- added (2012-11-30):
[0001193125-12-487586:note_history:21]
Upon conversion of the Notes, we deliver cash up to the
principal amount of the Notes and, with respect to any excess
conversion value greater than the principal amount of the Notes,
shares of our common stock. As of October 26, 2012, shares
issued related to the Notes were minimal. Based on the closing
price of our common stock of $27.88 on October 26, 2012, the
if-converted value of our Notes was below their principal
amount.

- added (2012-11-30):
[0001193125-12-487586:note_history:22]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| 1.75% Convertible Senior Notes due 2013 |  | $ | 1,264.9 |  |  | $ | 1,264.9 |  |
| Less: Unamortized discount |  |  | (35.5 | ) |  |  | (62.6 | ) |
| Net carrying amount of Notes |  | $ | 1,229.4 |  |  | $ | 1,202.3 |  |

- changed (2012-11-30):
[0001193125-12-487586:note_history:23]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 11.0 |  |  | $ | 11.0 |  |
| Amortization of debt discount |  |  | 13.6 |  |  |  | 12.8 |  |  |  | 27.1 |  |  |  | 25.4 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 1.1 |  |  |  | 2.4 |  |  |  | 2.2 |  |
| Less capitalized interest |  |  | (0.6 | ) |  |  | (3.5 | ) |  |  | (1.1 | ) |  |  | (3.5 | ) |
| Total interest expense related to Notes |  | $ | 19.7 |  |  | $ | 15.9 |  |  | $ | 39.4 |  |  | $ | 35.1 |  |
  (was, 2012-08-30, similarity 0.7412):
[0001193125-12-375807:note_history:23]
|  |  | Three Months Ended |  |
|  |  | July 27, 2012 |  |  | July 29, 2011 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |
| Amortization of debt discount |  |  | 13.5 |  |  |  | 12.6 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 1.1 |  |
| Less capitalized interest |  |  | (0.5 | ) |  |  | 0.0 |  |
| Total interest expense related to Notes |  | $ | 19.7 |  |  | $ | 19.2 |  |

- changed (2012-11-30):
[0001193125-12-487586:note_history:24]
The following table reflects the remaining debt discount and
issuance costs as of October 26, 2012 (in
millions):
  (was, 2012-08-30, similarity 0.9484):
[0001193125-12-375807:note_history:24]
The following table reflects the remaining debt discount and
issuance costs as of July 27, 2012 (in millions):

- changed (2012-11-30):
[0001193125-12-487586:note_history:25]
• Note Hedges: As of October 26, 2012 and
April 27, 2012, we had arrangements with counterparties to buy
up to approximately 31.8 million shares of our common stock,
subject to anti-dilution adjustments, at a price of $31.85 per
share, subject to adjustment. The Note hedge transactions will
expire at the earlier of (1) the last day on which any Notes
remain outstanding or (2) the scheduled trading day
immediately preceding the maturity date of the Notes. Upon exercise
of the Note hedges, we have the option to receive cash or shares of
our common stock equal to the difference between the then market
price and the strike price of the hedges.
  (was, 2012-08-30, similarity 0.8606):
[0001193125-12-375807:note_history:25]
• Note Hedges: As of July 27, 2012 and
April 27, 2012, we had arrangements with counterparties to buy
up to approximately 31.8 million shares, subject to
anti-dilution adjustments, of our common stock at a price of $31.85
per share, subject to adjustment. The Note hedge transactions will
expire at the earlier of (1) the last day on which any Notes
remain outstanding or (2) the scheduled trading day
immediately preceding the maturity date of the Notes. Upon exercise
of the Note hedges, we have the option to receive cash or shares of
our common stock equal to the difference between the then market
price and the strike price of the hedges.

- changed (2012-11-30):
[0001193125-12-487586:note_history:26]
• Warrants: As of October 26, 2012 and
April 27, 2012, we had outstanding warrants for others to
acquire, subject to anti-dilution adjustments, 39.7 million
shares of our common stock at an exercise price of $41.28 per
share, subject to adjustment, on a series of days commencing on
September 3, 2013. Upon exercise of the warrants, we have the
option to deliver cash or shares of our common stock equal to the
difference between the then market price and the strike price of
the warrants.
  (was, 2012-08-30, similarity 0.9882):
[0001193125-12-375807:note_history:26]
• Warrants: As of July 27, 2012 and April 27,
2012, we had outstanding warrants for others to acquire, subject to
anti-dilution adjustments, 39.7 million shares of our common
stock at an exercise price of $41.28 per share, subject to
adjustment, on a series of days commencing on September 3,
2013. Upon exercise of the warrants, we have the option to deliver
cash or shares of our common stock equal to the difference between
the then market price and the strike price of the
warrants.

- changed (2012-11-30):
[0001193125-12-487586:note_history:27]
As of October 26, 2012, we were subject to potential
dilution on the approximately 20% unhedged portion of our Notes
upon conversion, if on the date of conversion, the per-share market
price of our common stock exceeds the conversion price of
$31.85.
  (was, 2012-08-30, similarity 0.9767):
[0001193125-12-375807:note_history:27]
As of July 27, 2012, we were subject to potential dilution
on the approximately 20% unhedged portion of our Notes upon
conversion, if on the date of conversion, the per-share market
price of our common stock exceeds the conversion price of
$31.85.

- changed (2012-11-30):
[0001193125-12-487586:note_history:28]
As of October 26, 2012, we received a minimal number of
shares related to the Note hedge transactions and no cash or shares
were delivered related to the warrant transactions.
  (was, 2012-08-30, similarity 0.9672):
[0001193125-12-375807:note_history:28]
As of July 27, 2012, we received a minimal number of
shares related to the Note hedge transactions and no cash or shares
were delivered related to the warrant transactions.

- added (2012-11-30):
[0001193125-12-487586:note_history:29]
As of October 26, 2012, the fair value of the principal
amount of the Notes, which includes the debt and equity components,
was approximately $1,340.2 million, or 106.0% of the face value of
the Notes, based upon quoted market information provided by
third-party pricing providers (Level 1).

- changed (2012-11-30):
[0001193125-12-487586:note_history:30]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.0 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 6.3 |  |  |  | 3.5 |  |
| Total |  | $ | 12.3 |  |  | $ | 12.6 |  |
  (was, 2012-08-30, similarity 0.9772):
[0001193125-12-375807:note_history:30]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 7.9 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 2.7 |  |  |  | 3.5 |  |
| Total |  | $ | 10.6 |  |  | $ | 12.6 |  |

- removed (2012-11-30):
[0001193125-12-375807:note_history:31]
Our common stock price did not exceed the conversion threshold
price of $41.41 per share set forth for the Notes for at least 20
trading days during the 30 consecutive trading days ended
June 30, 2012, and accordingly, as of July 27, 2012, the
Notes were not convertible at the option of the holder. Since the
Notes were not convertible, the difference between the principal
amount and the carrying value of the Notes was reflected as equity
on our condensed consolidated balance sheet as of July 27,
2012.

- removed (2012-11-30):
[0001193125-12-375807:note_history:32]
Upon conversion of the Notes, we deliver cash up to the
principal amount of the Notes and, with respect to any excess
conversion value greater than the principal amount of the Notes,
shares of our common stock. As of July 27, 2012, shares issued
related to the Notes were minimal. Based on the closing price of
our common stock of $32.91 on July 27, 2012, the if-converted
value of our Notes exceeded their principal amount by approximately
$42.2 million.

- removed (2012-11-30):
[0001193125-12-375807:note_history:33]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| 1.75% Convertible Senior Notes Due 2013 |  | $ | 1,264.9 |  |  | $ | 1,264.9 |  |
| Less: Unamortized discount |  |  | (49.1 | ) |  |  | (62.6 | ) |
| Net carrying amount of Notes |  | $ | 1,215.8 |  |  | $ | 1,202.3 |  |

- removed (2012-11-30):
[0001193125-12-375807:note_history:34]
As of July 27, 2012, the approximate fair value of the
principal amount of the Notes, which includes the debt and equity
components, was approximately $1,476.0 million, or 116.7% of the
face value of the Notes, based upon quoted market information
provided by third party pricing providers (Level 1).


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2012-11-30):
[0001193125-12-487586:note_history:35]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.0 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 6.3 |  |  |  | 3.5 |  |
| Total |  | $ | 12.3 |  |  | $ | 12.6 |  |
  (was, 2012-08-30, similarity 0.9772):
[0001193125-12-375807:note_history:35]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 7.9 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 2.7 |  |  |  | 3.5 |  |
| Total |  | $ | 10.6 |  |  | $ | 12.6 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2012-11-30):
[0001193125-12-487586:note_history:36]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| 1.75% Convertible Senior Notes due 2013 |  | $ | 1,264.9 |  |  | $ | 1,264.9 |  |
| Less: Unamortized discount |  |  | (35.5 | ) |  |  | (62.6 | ) |
| Net carrying amount of Notes |  | $ | 1,229.4 |  |  | $ | 1,202.3 |  |

- removed (2012-11-30):
[0001193125-12-375807:note_history:37]
|  |  | July 27, 2012 |  |  | April 27, 2012 |  |
| 1.75% Convertible Senior Notes Due 2013 |  | $ | 1,264.9 |  |  | $ | 1,264.9 |  |
| Less: Unamortized discount |  |  | (49.1 | ) |  |  | (62.6 | ) |
| Net carrying amount of Notes |  | $ | 1,215.8 |  |  | $ | 1,202.3 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2012-11-30):
[0001193125-12-487586:note_history:38]
16. Subsequent
Event

- added (2012-11-30):
[0001193125-12-487586:note_history:39]
On November 14, 2012, we completed the acquisition of
CacheIQ, Inc., a privately held storage solutions company based in
Austin, Texas, for approximately $90.0 million in cash. This
acquisition provides us with intellectual property that extends our
capabilities to support non-disruptive operations for enterprise
data center environments. We will integrate this intellectual
property into our product offerings over time. Through
October 26, 2012, acquisition-related expenses associated with
the transaction were immaterial. We are in the process of
completing the purchase price allocation for this
acquisition. Pro forma results of operations have not been
presented because the acquisition was not material to our results
of operations.
