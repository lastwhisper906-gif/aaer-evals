# NTAP 8-K — 0001102624-12-000925 filed 2012-11-14

## item codes, every 8-K on or before 2012-11-30

- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2012-11-30

- none on or before 2012-11-30

## item 2.02 — earnings release, exhibit 99.1

[0001102624-12-000925:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-12-000925:8k_2_02:2]
exh99_1.htm

[0001102624-12-000925:8k_2_02:3]
| Exhibit 99.1 |  |

[0001102624-12-000925:8k_2_02:4]
| Press Contact: | Investor Contact: |  |  |
| Ryan Lowry NetApp (408) 822-7544 ryanl@netapp.com | Kris Newton NetApp (408) 822-3312 kris.newton@netapp.com |  |  |

[0001102624-12-000925:8k_2_02:5]
NETAPP ANNOUNCES RESULTS FOR SECOND QUARTER FISCAL YEAR 2013

[0001102624-12-000925:8k_2_02:6]
Reports Q2 FY’13 Revenues of $1.541 Billion; Non-GAAP Earnings per Share of $0.51

[0001102624-12-000925:8k_2_02:7]
Company Increases Stock Repurchase Authorization

[0001102624-12-000925:8k_2_02:8]
Sunnyvale, Calif.—November 14, 2012—NetApp (NASDAQ: NTAP) today reported results for the second quarter of fiscal year 2013, which ended October 26, 2012. Revenues for the second quarter of fiscal year 2013 totaled $1.541 billion and were in line with prior guidance. Revenues for the same period a year ago totaled $1.507 billion.

[0001102624-12-000925:8k_2_02:9]
For the second quarter of fiscal year 2013, GAAP net income was $110 million, or $0.30 per share,1 compared to GAAP net income of $166 million, or $0.44 per share for the same period a year ago. Non-GAAP net income for the second quarter of fiscal year 2013 was $189 million, or $0.51 per share,2 compared to non-GAAP net income of $236 million, or $0.63 per share for the same period a year ago.

[0001102624-12-000925:8k_2_02:10]
Revenues for the first six months of fiscal year 2013 totaled $2.986 billion compared to revenues of $2.965 billion for the first six months of the prior fiscal year. GAAP net income for the first six months of fiscal year 2013 totaled $173 million, or $0.47 per share, compared to GAAP net income of $305 million, or $0.78 per share for the first six months of the prior fiscal year. Non-GAAP net income for the first six months of fiscal year 2013 totaled $345 million, or $0.93 per share, compared to non-GAAP net income of $458 million, or $1.17 per share for the first six months of the prior fiscal year.

[0001102624-12-000925:8k_2_02:11]
“NetApp produced healthy financial results in the second quarter with revenue roughly at the midpoint of and EPS above our guidance range, despite a difficult environment. We saw a strong uptake of NetApp® Data ONTAP® 8 and clustered Data ONTAP, as customers are looking to build agile data infrastructure environments with intelligent data management, nearly unlimited scalability, and nondisruptive operations,” said Tom Georgens, president and CEO. “We also saw momentum in our partnering strategy with continued FlexPod® growth and a record high revenue contribution from Arrow and Avnet. Our focus on delivering best-of-breed storage solutions and the leverage we gain through go-to-market and channel partners will enable NetApp to grow our business and gain share.”

[0001102624-12-000925:8k_2_02:12]
NetApp also announces it will continue its share repurchase program with an additional $1.5 billion authorized. Under this program, NetApp can purchase shares of its outstanding common stock through open market and in privately negotiated transactions at prices deemed appropriate by management. The timing and amount of repurchase transactions under the program will depend on market conditions, corporate considerations, and regulatory requirements. The purchases will be funded from available working capital.

[0001102624-12-000925:8k_2_02:13]
Outlook

[0001102624-12-000925:8k_2_02:14]
NetApp’s outlook for the third quarter of fiscal year 2013 is based on current business expectations, market conditions, and continued uncertainty in the macroeconomic environment.

[0001102624-12-000925:8k_2_02:15]
| · | NetApp estimates revenue for the third quarter of fiscal year 2013 to be in the range of $1.575 billion to $1.675 billion. |

[0001102624-12-000925:8k_2_02:16]
| · | NetApp estimates GAAP earnings per share for the third quarter of fiscal year 2013 to be approximately $0.29 to $0.34 per share. NetApp estimates non-GAAP earnings per share for the third quarter of fiscal year 2013 to be approximately $0.53 to $0.58 per share. |

[0001102624-12-000925:8k_2_02:17]
| · | NetApp estimates that the share count for the third quarter of fiscal year 2013 will decrease to approximately 365 million shares. |

[0001102624-12-000925:8k_2_02:18]
Business Highlights

[0001102624-12-000925:8k_2_02:19]
NetApp is built on a culture of innovation that aims to provide customers with the best experience possible. This comes not only from NetApp’s direct relationship with customers, but also by delivering compelling technology solutions and forging best-in-class partnerships.

[0001102624-12-000925:8k_2_02:20]
In its second quarter of fiscal year 2013, NetApp’s culture of innovation was on display across every aspect of its business. NetApp continued to strengthen and extend its best-of-breed partner ecosystem by announcing new joint solutions and key integrations with industry leaders such as Cisco, Microsoft, VMware, Oracle, and Citrix that will help customers of all sizes accelerate their businesses. A foundational component to several of the new joint offerings is NetApp’s Data ONTAP, the world’s #1 storage operating system.

[0001102624-12-000925:8k_2_02:21]
Highlights include:

[0001102624-12-000925:8k_2_02:22]
NetApp Announces Definitive Agreement to Acquire CacheIQ, Inc.

[0001102624-12-000925:8k_2_02:23]
| · | NetApp has entered into a definitive agreement to acquire CacheIQ, Inc., a privately held storage solutions company based in Austin, Texas. The acquisition will provide NetApp with intellectual property that extends its capabilities to support nondisruptive operations for enterprise data center environments. NetApp will integrate this intellectual property into its product offerings over time. Financial terms of the acquisition are not being disclosed at this time. |

[0001102624-12-000925:8k_2_02:24]
Best-in-Class Partner Integration Fuels Innovation for Customers

[0001102624-12-000925:8k_2_02:25]
| · | NetApp and Cisco expand data center infrastructure solutions for midsized businesses to large enterprises. The FlexPod data center platform now features support and validation for VMware vSphere on NetApp clustered Data ONTAP to help organizations drive growth by adding nodes to their storage cluster creating large storage pools that span storage devices and can scale almost infinitely. The two companies also introduced ExpressPod, a prepackaged and tested solution for growing small and medium-sized organizations that require increased IT efficiency and simplicity. Celebrating its two-year anniversary, more than 1,500 organizations in 35 countries are accelerating their transition to the cloud with FlexPod. Additionally, more than 660 certified FlexPod Partners around the world are helping these customers deploy their infrastructures more quickly and easily. |

[0001102624-12-000925:8k_2_02:26]
| · | NetApp and Microsoft technology collaboration drives public, private, and hybrid cloud migration. NetApp announced support for Windows Server 2012 with storage solutions for server and desktop virtualization, storage and availability, Web and application platform development, and private cloud deployment. For organizations of any size and in any industry, this close collaboration simplifies and accelerates how storage is pooled, provisioned, accessed, and managed in Windows environments. |

[0001102624-12-000925:8k_2_02:27]
| · | NetApp and VMware team up to accelerate customers’ transition to an agile data infrastructure. NetApp and VMware continue to build on their nearly 10 year partnership by unveiling integration between VMware vSphere 5.1 and NetApp clustered Data ONTAP. The integration will also enable customers to securely manage and deploy infinite storage pools and to deliver nondisruptive migration of data among hundreds of virtual machines at a time. Customers will be able to achieve continuous data access and uninterrupted business operations as their infrastructures grow and scale in capacity and performance. |

[0001102624-12-000925:8k_2_02:28]
| · | NetApp and Oracle integration helps customers reduce cost and complexity of managing business-critical applications. NetApp achieved Oracle Validated Integration of the NetApp Storage System Plug-In version 1.0 with Oracle Enterprise Manager 12c, extending the application-to-disk coverage of Oracle Enterprise Manager environments that include NetApp managed storage. As a result, customers will benefit from improved risk management and smoother upgrade capabilities, leading to lower total cost of ownership and greater overall satisfaction. |

[0001102624-12-000925:8k_2_02:29]
| · | NetApp and Citrix collaborate to simplify cloud storage. NetApp and Citrix announced an extension of their current collaboration aimed at accelerating the adoption of enterprise cloud deployments. The two companies will provide a fully integrated cloud orchestration and storage solution that will address storage automation, resource allocation, and virtual machine backup and recovery. The move greatly simplifies cloud storage deployment for customers and will result in faster transitions to private and hybrid clouds. |

[0001102624-12-000925:8k_2_02:30]
NetApp Enhances Flash Portfolio and Ecosystem

[0001102624-12-000925:8k_2_02:31]
| · | NetApp Flash Accel helps customers enhance application and server performance. NetApp introduced NetApp Flash Accel to speed customer application performance by turning server-side Flash into a cache for storing “hot,” frequently accessed data. From servers to their back-end storage, cost- and performance-conscious system architects can now balance how Flash is used within their organizations to maximize application performance, minimize rising IT costs, preserve high availability, protect data, and simplify management. NetApp also expanded its Alliance Partner Program to embrace hardware and software server-caching partners looking to develop solutions with NetApp. This will provide the widest coverage for joint customers’ infrastructures as they deploy server-side caching to deliver increased ROI. |

[0001102624-12-000925:8k_2_02:32]
8

[0001102624-12-000925:8k_2_02:33]
| · | NetApp signs technology reseller agreement with Fusion-io. As part of its commitment to providing customers with end-to-end Flash technologies, NetApp entered into a resale agreement with Fusion-io, a leader in Flash memory solutions. NetApp will continue to resell Fusion-io ioMemory platform products and two server caching software products: ioTurbine for virtualized environments and Direct Cache for nonvirtualized environments. |

[0001102624-12-000925:8k_2_02:34]
NetApp Recognized for Its Culture and Innovative Spirit

[0001102624-12-000925:8k_2_02:35]
| · | NetApp repeats as one of the world’s most innovative companies. For the second consecutive year, NetApp made Forbes magazine’s “World’s Most Innovative Companies” list for 2012. As the only storage vendor to make this year’s list, the recognition is a testament to NetApp’s 20 years of innovation and true innovative spirit which continues to thrive today to help customers and partners achieve great business outcomes. |

[0001102624-12-000925:8k_2_02:36]
| · | NetApp cements its standing as one of the world’s best places to work. NetApp was named the #3 best workplace in the world by the Great Place to Work Institute on November 13, 2012. It marks the second consecutive year that NetApp finished in the top 5 of this exclusive list and is a testament to the company’s unique workplace culture and commitment to employee excellence which help produce great results for NetApp customers and partners. |

[0001102624-12-000925:8k_2_02:37]
Webcast and Conference Call Information

[0001102624-12-000925:8k_2_02:38]
The NetApp second quarter fiscal year 2013 conference call will be broadcast live on the Internet at investors.netapp.com on Wednesday, November 14, 2012, at 2 p.m. Pacific Time. This press release and any other information related to the call will also be posted on the Web site at that location. An audio replay Webcast will be available after 4 p.m. Pacific Time on the Web site.

[0001102624-12-000925:8k_2_02:39]
NetApp uses a hybrid format for disclosing key financial information associated with our quarterly results. Concurrent with the press release, NetApp posts a supplemental commentary with financial information and statistics to our Web site at investors.netapp.com.

[0001102624-12-000925:8k_2_02:40]
About NetApp

[0001102624-12-000925:8k_2_02:41]
NetApp creates innovative storage and data management solutions that deliver outstanding cost efficiency and accelerate business breakthroughs. Our commitment to living our core values and consistently being recognized as a great place to work around the world are fundamental to our long-term growth and success, as well as the success of our pathway partners and customers. Discover our passion for helping companies around the world go further, faster at www.netapp.com.

[0001102624-12-000925:8k_2_02:42]
###

[0001102624-12-000925:8k_2_02:43]
NetApp, the NetApp logo, Go further, faster, Data ONTAP, Flash Accel and FlexPod are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001102624-12-000925:8k_2_02:44]
| 1 | GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |

[0001102624-12-000925:8k_2_02:45]
| 2 | Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our convertible debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |

[0001102624-12-000925:8k_2_02:46]
NetApp Usage of Non-GAAP Financials

[0001102624-12-000925:8k_2_02:47]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our convertible debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-12-000925:8k_2_02:48]
10

[0001102624-12-000925:8k_2_02:49]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation. We have historically reported similar non-GAAP financial measures to our investors and believe that the inclusion of comparative numbers provides consistency in our financial reporting at this time.

[0001102624-12-000925:8k_2_02:50]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,571.0 |  |  | $ | 5,398.5 |  |
| Accounts receivable, net |  |  | 615.0 |  |  |  | 830.9 |  |
| Inventories |  |  | 213.2 |  |  |  | 161.5 |  |
| Other current assets |  |  | 488.5 |  |  |  | 435.6 |  |
| Total current assets |  |  | 6,887.7 |  |  |  | 6,826.5 |  |
| Property and equipment, net |  |  | 1,132.4 |  |  |  | 1,137.2 |  |
| Goodwill and other intangible assets, net |  |  | 1,098.3 |  |  |  | 1,141.2 |  |
| Other non-current assets |  |  | 435.5 |  |  |  | 427.4 |  |
| Total assets |  | $ | 9,553.9 |  |  | $ | 9,532.3 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 246.6 |  |  | $ | 233.1 |  |
| Accrued compensation and other current liabilities |  |  | 689.2 |  |  |  | 717.9 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | 1,229.4 |  |  |  | 1,202.3 |  |
| Short-term deferred revenue |  |  | 1,408.5 |  |  |  | 1,366.5 |  |
| Total current liabilities |  |  | 3,573.7 |  |  |  | 3,519.8 |  |
| Other long-term liabilities |  |  | 216.3 |  |  |  | 206.9 |  |
| Long-term deferred revenue |  |  | 1,361.7 |  |  |  | 1,449.4 |  |
| Total liabilities |  |  | 5,151.7 |  |  |  | 5,176.1 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | - |  |  |  | 62.6 |  |
| Stockholders' equity |  |  | 4,402.2 |  |  |  | 4,293.6 |  |
| Total liabilities and stockholders' equity |  | $ | 9,553.9 |  |  | $ | 9,532.3 |  |

[0001102624-12-000925:8k_2_02:51]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 995.8 |  |  | $ | 1,016.2 |  |  | $ | 1,893.8 |  |  | $ | 1,981.9 |  |
| Software entitlements and maintenance |  |  | 219.4 |  |  |  | 198.0 |  |  |  | 437.9 |  |  |  | 396.2 |  |
| Service |  |  | 326.0 |  |  |  | 292.8 |  |  |  | 654.1 |  |  |  | 587.1 |  |
| Net revenues |  |  | 1,541.2 |  |  |  | 1,507.0 |  |  |  | 2,985.8 |  |  |  | 2,965.2 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 477.3 |  |  |  | 460.7 |  |  |  | 929.5 |  |  |  | 898.1 |  |
| Cost of software entitlements and maintenance |  |  | 7.0 |  |  |  | 5.6 |  |  |  | 13.6 |  |  |  | 10.9 |  |
| Cost of service |  |  | 143.0 |  |  |  | 127.7 |  |  |  | 278.7 |  |  |  | 246.3 |  |
| Total cost of revenues |  |  | 627.3 |  |  |  | 594.0 |  |  |  | 1,221.8 |  |  |  | 1,155.3 |  |
| Gross profit |  |  | 913.9 |  |  |  | 913.0 |  |  |  | 1,764.0 |  |  |  | 1,809.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 488.2 |  |  |  | 454.1 |  |  |  | 971.1 |  |  |  | 908.9 |  |
| Research and development |  |  | 223.8 |  |  |  | 199.7 |  |  |  | 445.2 |  |  |  | 398.3 |  |
| General and administrative |  |  | 66.6 |  |  |  | 65.1 |  |  |  | 132.2 |  |  |  | 130.2 |  |
| Acquisition-related expense |  |  | - |  |  |  | 1.7 |  |  |  | - |  |  |  | 3.9 |  |
| Total operating expenses |  |  | 778.6 |  |  |  | 720.6 |  |  |  | 1,548.5 |  |  |  | 1,441.3 |  |
| Income from operations |  |  | 135.3 |  |  |  | 192.4 |  |  |  | 215.5 |  |  |  | 368.6 |  |
| Other expense, net |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 11.0 |  |  |  | 8.3 |  |  |  | 21.8 |  |  |  | 18.9 |  |
| Interest expense |  |  | (19.8 | ) |  |  | (16.4 | ) |  |  | (39.7 | ) |  |  | (35.8 | ) |
| Other income (expense), net |  |  | 1.2 |  |  |  | (0.4 | ) |  |  | 4.3 |  |  |  | (0.7 | ) |
| Total other expense, net |  |  | (7.6 | ) |  |  | (8.5 | ) |  |  | (13.6 | ) |  |  | (17.6 | ) |
| Income before income taxes |  |  | 127.7 |  |  |  | 183.9 |  |  |  | 201.9 |  |  |  | 351.0 |  |
| Provision for income taxes |  |  | 18.1 |  |  |  | 18.3 |  |  |  | 28.5 |  |  |  | 45.9 |  |
| Net income |  | $ | 109.6 |  |  | $ | 165.6 |  |  | $ | 173.4 |  |  | $ | 305.1 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.30 |  |  | $ | 0.46 |  |  | $ | 0.48 |  |  | $ | 0.83 |  |
| Diluted |  | $ | 0.30 |  |  | $ | 0.44 |  |  | $ | 0.47 |  |  | $ | 0.78 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 362.0 |  |  |  | 361.5 |  |  |  | 364.1 |  |  |  | 365.9 |  |
| Diluted |  |  | 368.2 |  |  |  | 376.0 |  |  |  | 369.7 |  |  |  | 390.8 |  |

[0001102624-12-000925:8k_2_02:52]
12

[0001102624-12-000925:8k_2_02:53]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOW |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 109.6 |  |  | $ | 165.6 |  |  | $ | 173.4 |  |  | $ | 305.1 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 86.7 |  |  |  | 68.4 |  |  |  | 169.1 |  |  |  | 136.9 |  |
| Stock-based compensation |  |  | 65.0 |  |  |  | 63.0 |  |  |  | 144.2 |  |  |  | 121.1 |  |
| Accretion of discount and issuance costs on Notes |  |  | 14.4 |  |  |  | 11.5 |  |  |  | 28.7 |  |  |  | 25.2 |  |
| Tax benefit from stock-based compensation |  |  | 37.0 |  |  |  | 50.4 |  |  |  | 28.2 |  |  |  | 79.1 |  |
| Excess tax benefit from stock-based compensation |  |  | (38.7 | ) |  |  | (52.6 | ) |  |  | (43.6 | ) |  |  | (84.7 | ) |
| Other, net |  |  | (15.9 | ) |  |  | (43.8 | ) |  |  | (39.9 | ) |  |  | (74.4 | ) |
| Changes in assets and liabilities, net of acquisition of business: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (31.3 | ) |  |  | (29.4 | ) |  |  | 212.9 |  |  |  | 115.6 |  |
| Inventories |  |  | (9.5 | ) |  |  | (25.1 | ) |  |  | (51.7 | ) |  |  | (18.3 | ) |
| Accounts payable |  |  | (28.0 | ) |  |  | 22.8 |  |  |  | 13.9 |  |  |  | 45.6 |  |
| Accrued compensation and other current liabilities |  |  | 130.8 |  |  |  | 75.2 |  |  |  | (15.9 | ) |  |  | (173.1 | ) |
| Deferred revenue |  |  | 4.4 |  |  |  | 60.2 |  |  |  | (42.6 | ) |  |  | 126.9 |  |
| Changes in other operating assets and liabilities, net |  |  | 11.9 |  |  |  | 4.0 |  |  |  | (11.1 | ) |  |  | 5.8 |  |
| Net cash provided by operating activities |  |  | 336.4 |  |  |  | 370.2 |  |  |  | 565.6 |  |  |  | 610.8 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | 159.5 |  |  |  | (205.4 | ) |  |  | 93.4 |  |  |  | 40.4 |  |
| Purchases of property and equipment |  |  | (67.1 | ) |  |  | (93.3 | ) |  |  | (129.0 | ) |  |  | (191.6 | ) |
| Acquisition of business |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (480.0 | ) |
| Other investing activities, net |  |  | 1.5 |  |  |  | 0.3 |  |  |  | 2.8 |  |  |  | 2.0 |  |
| Net cash provided by (used in) investing activities |  |  | 93.9 |  |  |  | (298.4 | ) |  |  | (32.8 | ) |  |  | (629.2 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 10.1 |  |  |  | 5.3 |  |  |  | 45.1 |  |  |  | 51.9 |  |
| Repurchase and retirement of common stock |  |  | (198.3 | ) |  |  | (400.0 | ) |  |  | (348.3 | ) |  |  | (600.0 | ) |
| Excess tax benefit from stock-based compensation |  |  | 38.7 |  |  |  | 52.6 |  |  |  | 43.6 |  |  |  | 84.7 |  |
| Other financing activities, net |  |  | 1.7 |  |  |  | 1.3 |  |  |  | (0.3 | ) |  |  | 1.6 |  |
| Net cash used in financing activities |  |  | (147.8 | ) |  |  | (340.8 | ) |  |  | (259.9 | ) |  |  | (461.8 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 4.9 |  |  |  | (5.2 | ) |  |  | (5.9 | ) |  |  | (8.1 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 287.4 |  |  |  | (274.2 | ) |  |  | 267.0 |  |  |  | (488.3 | ) |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 1,529.4 |  |  |  | 2,543.2 |  |  |  | 1,549.8 |  |  |  | 2,757.3 |  |
| End of period |  | $ | 1,816.8 |  |  | $ | 2,269.0 |  |  | $ | 1,816.8 |  |  | $ | 2,269.0 |  |

[0001102624-12-000925:8k_2_02:54]
13

[0001102624-12-000925:8k_2_02:55]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP AND GAAP |  |
| IN THE CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| SUMMARY RECONCILIATION OF NET INCOME |  |  |  |  |  |  |  |  |  |  |  |  |
| NET INCOME |  | $ | 109.6 |  |  | $ | 165.6 |  |  |  | 173.4 |  |  |  | 305.1 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 21.5 |  |  |  | 21.7 |  |  |  | 42.9 |  |  |  | 46.0 |  |
| Stock-based compensation |  |  | 65.0 |  |  |  | 63.0 |  |  |  | 144.2 |  |  |  | 121.1 |  |
| Acquisition-related expense |  |  | - |  |  |  | 1.7 |  |  |  | - |  |  |  | 11.9 |  |
| Non-cash interest expense |  |  | 14.4 |  |  |  | 11.5 |  |  |  | 28.7 |  |  |  | 25.2 |  |
| Income tax effect of non-GAAP adjustments |  |  | (21.5 | ) |  |  | (28.0 | ) |  |  | (43.8 | ) |  |  | (51.5 | ) |
| NON-GAAP NET INCOME |  | $ | 189.0 |  |  | $ | 235.5 |  |  | $ | 345.4 |  |  | $ | 457.8 |  |
| NET INCOME PER SHARE |  | $ | 0.298 |  |  | $ | 0.440 |  |  |  | 0.469 |  |  |  | 0.781 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.058 |  |  |  | 0.058 |  |  |  | 0.116 |  |  |  | 0.118 |  |
| Stock-based compensation |  |  | 0.176 |  |  |  | 0.168 |  |  |  | 0.390 |  |  |  | 0.310 |  |
| Acquisition-related expense |  |  | - |  |  |  | 0.004 |  |  |  | - |  |  |  | 0.030 |  |
| Non-cash interest expense |  |  | 0.039 |  |  |  | 0.031 |  |  |  | 0.078 |  |  |  | 0.064 |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.058 | ) |  |  | (0.075 | ) |  |  | (0.119 | ) |  |  | (0.132 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.513 |  |  | $ | 0.626 |  |  | $ | 0.934 |  |  | $ | 1.171 |  |

[0001102624-12-000925:8k_2_02:56]
14

[0001102624-12-000925:8k_2_02:57]
| NETAPP, INC. |  |
| SUPPLEMENTAL INFORMATION |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended October 26, 2012 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Acquisition-related Expense |  |  | Non-cash Interest Expense |  |  | Total |  |
| Cost of product revenues |  | $ | 13.9 |  |  | $ | 1.5 |  |  | $ | - |  |  | $ | - |  |  | $ | 15.4 |  |
| Cost of service revenues |  |  | - |  |  |  | 4.6 |  |  |  | - |  |  |  | - |  |  |  | 4.6 |  |
| Sales and marketing expenses |  |  | 7.6 |  |  |  | 30.9 |  |  |  | - |  |  |  | - |  |  |  | 38.5 |  |
| Research and development expenses |  |  | - |  |  |  | 19.3 |  |  |  | - |  |  |  | - |  |  |  | 19.3 |  |
| General and administrative expenses |  |  | - |  |  |  | 8.7 |  |  |  | - |  |  |  | - |  |  |  | 8.7 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 14.4 |  |  |  | 14.4 |  |
| Effect on income before income taxes |  | $ | 21.5 |  |  | $ | 65.0 |  |  | $ | - |  |  | $ | 14.4 |  |  | $ | 100.9 |  |
|  |  | Six Months Ended October 26, 2012 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Acquisition-related Expense |  |  | Non-cash Interest Expense |  |  | Total |  |
| Cost of product revenues |  | $ | 27.9 |  |  | $ | 3.3 |  |  | $ | - |  |  | $ | - |  |  | $ | 31.2 |  |
| Cost of service revenues |  |  | - |  |  |  | 10.2 |  |  |  | - |  |  |  | - |  |  |  | 10.2 |  |
| Sales and marketing expense |  |  | 15.0 |  |  |  | 69.9 |  |  |  | - |  |  |  | - |  |  |  | 84.9 |  |
| Research and development expense |  |  | - |  |  |  | 43.0 |  |  |  | - |  |  |  | - |  |  |  | 43.0 |  |
| General and administrative expense |  |  | - |  |  |  | 17.8 |  |  |  | - |  |  |  | - |  |  |  | 17.8 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 28.7 |  |  |  | 28.7 |  |
| Effect on income before income taxes |  | $ | 42.9 |  |  | $ | 144.2 |  |  | $ | - |  |  | $ | 28.7 |  |  | $ | 215.8 |  |
|  |  | Three Months Ended October 28, 2011 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Acquisition-related Expense |  |  | Non-cash Interest Expense |  |  | Total |  |
| Cost of product revenues |  | $ | 14.0 |  |  | $ | 1.4 |  |  | $ | - |  |  | $ | - |  |  | $ | 15.4 |  |
| Cost of service revenues |  |  | - |  |  |  | 4.2 |  |  |  | - |  |  |  | - |  |  |  | 4.2 |  |
| Sales and marketing expenses |  |  | 7.7 |  |  |  | 30.4 |  |  |  | - |  |  |  | - |  |  |  | 38.1 |  |
| Research and development expenses |  |  | - |  |  |  | 18.2 |  |  |  | - |  |  |  | - |  |  |  | 18.2 |  |
| General and administrative expenses |  |  | - |  |  |  | 8.8 |  |  |  | - |  |  |  | - |  |  |  | 8.8 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | 1.7 |  |  |  | - |  |  |  | 1.7 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 11.5 |  |  |  | 11.5 |  |
| Effect on income before income taxes |  | $ | 21.7 |  |  | $ | 63.0 |  |  | $ | 1.7 |  |  | $ | 11.5 |  |  | $ | 97.9 |  |
|  |  | Six Months Ended October 28, 2011 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Acquisition-related Expense |  |  | Non-cash Interest Expense |  |  | Total |  |
| Cost of product revenues |  | $ | 27.9 |  |  | $ | 2.5 |  |  | $ | 5.4 |  |  | $ | - |  |  | $ | 35.8 |  |
| Cost of service revenues |  |  | - |  |  |  | 8.1 |  |  |  | - |  |  |  | - |  |  |  | 8.1 |  |
| Sales and marketing expense |  |  | 18.0 |  |  |  | 59.0 |  |  |  | - |  |  |  | - |  |  |  | 77.0 |  |
| Research and development expense |  |  | 0.1 |  |  |  | 34.2 |  |  |  | 2.6 |  |  |  | - |  |  |  | 36.9 |  |
| General and administrative expense |  |  | - |  |  |  | 17.3 |  |  |  | - |  |  |  | - |  |  |  | 17.3 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | 3.9 |  |  |  | - |  |  |  | 3.9 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 25.2 |  |  |  | 25.2 |  |
| Effect on income before income taxes |  | $ | 46.0 |  |  | $ | 121.1 |  |  | $ | 11.9 |  |  | $ | 25.2 |  |  | $ | 204.2 |  |

[0001102624-12-000925:8k_2_02:58]
15

[0001102624-12-000925:8k_2_02:59]
|  | NETAPP, INC. |
|  | RECONCILIATION OF NON GAAP GUIDANCE TO GAAP |
|  | EXPRESSED AS EARNINGS PER SHARE |
|  | THIRD QUARTER 2013 |
|  | (Unaudited) |
|  | Third Quarter |
|  | 2013 |
| Non-GAAP Guidance - Net Income Per Share | $0.53 - $0.58 |
| Adjustments of Specific Items to |  |
| Net Income Per Share for the Third |  |
| Quarter 2013: |  |
| Amortization of intangible assets | (0.06) |
| Stock-based compensation expense | (0.21) |
| Non-cash interest expense | (0.04) |
| Income tax effect | 0.07 |
| Total Adjustments | (0.24) |
| GAAP Guidance - Net Income Per Share | $0.29 - $0.34 |

[0001102624-12-000925:8k_2_02:60]
16
