# NTAP MD&A — 0001193125-12-487586


## mdna

[0001193125-12-487586:mdna:1]
[same as prior period, unchanged from 0001193125-12-375807:mdna:1]

[0001193125-12-487586:mdna:2]
[same as prior period, unchanged from 0001193125-12-375807:mdna:2]

[0001193125-12-487586:mdna:3]
[same as prior period, unchanged from 0001193125-12-375807:mdna:3]

[0001193125-12-487586:mdna:4]
[same as prior period, unchanged from 0001193125-12-375807:mdna:4]

[0001193125-12-487586:mdna:5]
[same as prior period, unchanged from 0001193125-12-375807:mdna:5]

[0001193125-12-487586:mdna:6]
[same as prior period, unchanged from 0001193125-12-375807:mdna:6]

[0001193125-12-487586:mdna:7]
[same as prior period, unchanged from 0001193125-12-375807:mdna:7]

[0001193125-12-487586:mdna:8]
|  | • |  | acquisitions and joint ventures, growth opportunities, investments and legal proceedings; |

[0001193125-12-487586:mdna:9]
[same as prior period, unchanged from 0001193125-12-375807:mdna:9]

[0001193125-12-487586:mdna:10]
[same as prior period, unchanged from 0001193125-12-375807:mdna:10]

[0001193125-12-487586:mdna:11]
[same as prior period, unchanged from 0001193125-12-375807:mdna:11]

[0001193125-12-487586:mdna:12]
[same as prior period, unchanged from 0001193125-12-375807:mdna:12]

[0001193125-12-487586:mdna:13]
|  | • |  | the dilutive effect of our 1.75% Convertible Senior Notes due June 2013 (the Notes) and associated warrants on our earnings per share; |

[0001193125-12-487586:mdna:14]
[same as prior period, unchanged from 0001193125-12-375807:mdna:14]

[0001193125-12-487586:mdna:15]
|  | • |  | compliance with laws, regulations and debt covenants; and |

[0001193125-12-487586:mdna:16]
[same as prior period, unchanged from 0001193125-12-375807:mdna:16]

[0001193125-12-487586:mdna:17]
[same as prior period, unchanged from 0001193125-12-375807:mdna:17]

[0001193125-12-487586:mdna:18]
[same as prior period, unchanged from 0001193125-12-375807:mdna:18]

[0001193125-12-487586:mdna:19]
|  | • |  | general global macroeconomic and market conditions, particularly in the Eurozone, and the continuing deliberations regarding future tax and fiscal policy in the United States; |

[0001193125-12-487586:mdna:20]
[same as prior period, unchanged from 0001193125-12-375807:mdna:20]

[0001193125-12-487586:mdna:21]
[same as prior period, unchanged from 0001193125-12-375807:mdna:21]

[0001193125-12-487586:mdna:22]
[same as prior period, unchanged from 0001193125-12-375807:mdna:22]

[0001193125-12-487586:mdna:23]
[same as prior period, unchanged from 0001193125-12-375807:mdna:23]

[0001193125-12-487586:mdna:24]
[same as prior period, unchanged from 0001193125-12-375807:mdna:24]

[0001193125-12-487586:mdna:25]
[same as prior period, unchanged from 0001193125-12-375807:mdna:25]

[0001193125-12-487586:mdna:26]
[same as prior period, unchanged from 0001193125-12-375807:mdna:26]

[0001193125-12-487586:mdna:27]
[same as prior period, unchanged from 0001193125-12-375807:mdna:27]

[0001193125-12-487586:mdna:28]
[same as prior period, unchanged from 0001193125-12-375807:mdna:28]

[0001193125-12-487586:mdna:29]
[same as prior period, unchanged from 0001193125-12-375807:mdna:29]

[0001193125-12-487586:mdna:30]
[same as prior period, unchanged from 0001193125-12-375807:mdna:30]

[0001193125-12-487586:mdna:31]
[same as prior period, unchanged from 0001193125-12-375807:mdna:31]

[0001193125-12-487586:mdna:32]
[same as prior period, unchanged from 0001193125-12-375807:mdna:32]

[0001193125-12-487586:mdna:33]
[same as prior period, unchanged from 0001193125-12-375807:mdna:33]

[0001193125-12-487586:mdna:34]
[same as prior period, unchanged from 0001193125-12-375807:mdna:34]

[0001193125-12-487586:mdna:35]
[same as prior period, unchanged from 0001193125-12-375807:mdna:35]

[0001193125-12-487586:mdna:36]
[same as prior period, unchanged from 0001193125-12-375807:mdna:36]

[0001193125-12-487586:mdna:37]
[same as prior period, unchanged from 0001193125-12-375807:mdna:37]

[0001193125-12-487586:mdna:38]
[same as prior period, unchanged from 0001193125-12-375807:mdna:38]

[0001193125-12-487586:mdna:39]
[same as prior period, unchanged from 0001193125-12-375807:mdna:39]

[0001193125-12-487586:mdna:40]
[same as prior period, unchanged from 0001193125-12-375807:mdna:40]

[0001193125-12-487586:mdna:41]
[same as prior period, unchanged from 0001193125-12-375807:mdna:41]

[0001193125-12-487586:mdna:42]
|  | • |  | our ability to finance the exercise of our option to buy out our synthetic leases when their terms expire; |

[0001193125-12-487586:mdna:43]
|  | • |  | the results of our ongoing litigation, tax audits, government audits, inquiries and investigations; and |

[0001193125-12-487586:mdna:44]
[same as prior period, unchanged from 0001193125-12-375807:mdna:43]

[0001193125-12-487586:mdna:45]
Readers are cautioned not to place undue reliance on these forward-looking statements, which speak only as of the date
hereof and are based upon information available to us at this time. These statements are not guarantees of future performance. We disclaim any obligation to update information in any forward-looking statement. Actual results could vary from our
forward-looking statements due to the foregoing factors as well as other important factors.

[0001193125-12-487586:mdna:46]
[same as prior period, unchanged from 0001193125-12-375807:mdna:45]

[0001193125-12-487586:mdna:47]
Our discussion and analysis of financial condition and results of operations are based upon our
condensed consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of such statements requires us to make estimates and assumptions that
affect the reported amounts of revenues and expenses during the reporting periods and the reported amounts of assets, liabilities and equity as of the date of the financial statements. Our estimates are based on historical experience and other
assumptions that we consider to be appropriate under the circumstances. However, future results may vary from our estimates.

[0001193125-12-487586:mdna:48]
We believe the accounting policies discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for
the fiscal year ended April 27, 2012 are significantly affected by critical accounting estimates and that they are both highly important to the portrayal of our financial condition and results of operations and require difficult management
judgments and assumptions about matters that are inherently uncertain. There have been no material changes to the critical accounting policies and estimates as filed in such report.

[0001193125-12-487586:mdna:49]
24

[0001193125-12-487586:mdna:50]
[same as prior period, unchanged from 0001193125-12-375807:mdna:49]

[0001193125-12-487586:mdna:51]
[same as prior period, unchanged from 0001193125-12-375807:mdna:50]

[0001193125-12-487586:mdna:52]
[same as prior period, unchanged from 0001193125-12-375807:mdna:51]

[0001193125-12-487586:mdna:53]
[same as prior period, unchanged from 0001193125-12-375807:mdna:52]

[0001193125-12-487586:mdna:54]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | October 26,2012 |  |  | October 28,2011 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 64.6 | % |  |  | 67.4 | % |  |  | 63.4 | % |  |  | 66.8 | % |
| Software entitlements and maintenance |  |  | 14.2 |  |  |  | 13.1 |  |  |  | 14.7 |  |  |  | 13.4 |  |
| Service |  |  | 21.2 |  |  |  | 19.5 |  |  |  | 21.9 |  |  |  | 19.8 |  |
| Net revenues |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 31.0 |  |  |  | 30.5 |  |  |  | 31.1 |  |  |  | 30.3 |  |
| Cost of software entitlements and maintenance |  |  | 0.4 |  |  |  | 0.4 |  |  |  | 0.5 |  |  |  | 0.4 |  |
| Cost of service |  |  | 9.3 |  |  |  | 8.5 |  |  |  | 9.3 |  |  |  | 8.3 |  |
| Gross profit |  |  | 59.3 |  |  |  | 60.6 |  |  |  | 59.1 |  |  |  | 61.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 31.7 |  |  |  | 30.1 |  |  |  | 32.5 |  |  |  | 30.7 |  |
| Research and development |  |  | 14.5 |  |  |  | 13.3 |  |  |  | 14.9 |  |  |  | 13.4 |  |
| General and administrative |  |  | 4.3 |  |  |  | 4.3 |  |  |  | 4.5 |  |  |  | 4.4 |  |
| Acquisition-related expense |  |  | — |  |  |  | 0.1 |  |  |  | — |  |  |  | 0.1 |  |
| Total operating expenses |  |  | 50.5 |  |  |  | 47.8 |  |  |  | 51.9 |  |  |  | 48.6 |  |
| Income from operations |  |  | 8.8 |  |  |  | 12.8 |  |  |  | 7.2 |  |  |  | 12.4 |  |
| Other expense, net |  |  | (0.5 | ) |  |  | (0.6 | ) |  |  | (0.4 | ) |  |  | (0.6 | ) |
| Income before income taxes |  |  | 8.3 |  |  |  | 12.2 |  |  |  | 6.8 |  |  |  | 11.8 |  |
| Provision for income taxes |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.0 |  |  |  | 1.5 |  |
| Net income |  |  | 7.1 | % |  |  | 11.0 | % |  |  | 5.8 | % |  |  | 10.3 | % |

[0001193125-12-487586:mdna:55]
[same as prior period, unchanged from 0001193125-12-375807:mdna:54]

[0001193125-12-487586:mdna:56]
[same as prior period, unchanged from 0001193125-12-375807:mdna:55]

[0001193125-12-487586:mdna:57]
Net revenues for the three and six months ended October 26, 2012 were $1,541.2 million, up $34.2 million, or 2%, and $2,985.8 million, up $20.6 million, or 1%, respectively, compared to the prior
year. The increases were due to increases in hardware maintenance contract and software entitlements and maintenance (SEM) revenues, partially offset by decreases in product revenues.

[0001193125-12-487586:mdna:58]
Gross margin percentage decreased during the three and six months ended October 26, 2012 compared to the prior year,
primarily due to changes in mix, hardware-related warranty expense and unfavorable exchange rates.

[0001193125-12-487586:mdna:59]
Sales and
marketing, research and development, and general and administrative expenses for the three and six months ended October 26, 2012 totaled $778.6 million and $1,548.5 million, respectively, up 8% in each period, compared to the prior year. These
increases were primarily due to a 7% and 11% increase in the average headcount during the three and six months ended October 26, 2012, respectively, compared to the prior year and higher compensation cost per headcount. Exchange rates had a
favorable impact on expenses.

[0001193125-12-487586:mdna:60]
Net Revenues (in millions, except percentages):

[0001193125-12-487586:mdna:61]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Net revenues |  | $ | 1,541.2 |  |  | $ | 1,507.0 |  |  |  | 2 | % |  | $ | 2,985.8 |  |  | $ | 2,965.2 |  |  |  | 1 | % |

[0001193125-12-487586:mdna:62]
[same as prior period, unchanged from 0001193125-12-375807:mdna:73]

[0001193125-12-487586:mdna:63]
Net revenues increased by $34.2 million, or 2% for the three months ended
October 26, 2012, compared to the prior year. The increase in net revenues was due to increases in service and SEM revenues of $54.6 million, partially offset by a decrease in product revenues of $20.4 million. Product revenues comprised 65% of
net revenues for the three months ended October 26, 2012, compared to 67% of net revenues for the three months ended October 28, 2011.

[0001193125-12-487586:mdna:64]
Net revenues increased by $20.6 million, or 1%, for the six months ended October 26, 2012, compared to the prior year. The increase in net revenues was due to increases in service and SEM revenues of
$108.7 million, partially offset by a decrease in product revenues of $88.1 million. Product revenue comprised 63% of net revenues for the six months ended October 26, 2012, compared to 67% of net revenues for the six months ended
October 28, 2011.

[0001193125-12-487586:mdna:65]
Sales through our indirect channels represented 82% and 80% of net revenues for the
three and six months ended October 26, 2012, respectively, compared to 80% and 78% of net revenues for the three and six months ended October 28, 2011, respectively. Included in indirect channel sales were $209.6 million and $418.5 million
of OEM revenue during the three and six months ended October 26, 2012, respectively, compared to $229.6 million and $443.0 million during the three and six months ended October 28, 2011, respectively.

[0001193125-12-487586:mdna:66]
The following customers, each of which is a distributor, accounted for 10% or more of net revenues:

[0001193125-12-487586:mdna:67]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | October 26,2012 |  |  | October 28,2011 |  |
| Arrow Electronics, Inc. |  |  | 20 | % |  |  | 18 | % |  |  | 18 | % |  |  | 16 | % |
| Avnet, Inc. |  |  | 15 | % |  |  | 13 | % |  |  | 14 | % |  |  | 12 | % |

[0001193125-12-487586:mdna:68]
[same as prior period, unchanged from 0001193125-12-375807:mdna:65]

[0001193125-12-487586:mdna:69]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Product revenues |  | $ | 995.8 |  |  | $ | 1,016.2 |  |  |  | (2 | )% |  | $ | 1,893.8 |  |  | $ | 1,981.9 |  |  |  | (4 | )% |

[0001193125-12-487586:mdna:70]
Product revenues decreased by $20.4 million, or 2%, and by $88.1 million, or 4%, during
the three and six months ended October 26, 2012, respectively, compared to the prior year. Product revenues consist of configured systems, which include bundled hardware and software products, and non-configured products, which consist
primarily of add-on storage, OEM products and add-on hardware and software products.

[0001193125-12-487586:mdna:71]
Total configured system
revenues of $531.2 million increased by $10.1 million, or 2%, during the three months ended October 26, 2012, compared to the prior year, primarily due to increases in the 2000 and 6000 series systems, partially offset by a decrease in the 3000
series systems. Configured systems unit volume increased 15% during the three months ended October 26, 2012, compared to the prior year. Unit volume of the 2000 and 6000 series increased and unit volume of the 3000 series systems decreased,
reflecting a shift in customer demand from certain 3000 series systems to recently introduced 2000 series systems and increased demand for 6000 series systems. The average selling prices (ASPs) of total configured systems decreased during the three
months ended October 26, 2012, compared to the prior year, due to a shift in sales from higher priced 3000 series systems to lower priced 2000 series systems, as well as product mix within the various series, partially offset by an increase in
sales from the higher priced 6000 series systems. In addition, ASPs were negatively impacted by unfavorable foreign currency rates and higher discounting.

[0001193125-12-487586:mdna:72]
Non-configured product revenues of $464.6 million decreased $30.5 million, or 6%, during the three months ended October 26, 2012, compared to the prior year. This decrease was primarily due to lower
revenue from non-configured OEM products, which declined 13% during the three months ended October 26, 2012 compared to the prior year. Non-configured product revenues were unfavorably impacted by product mix.

[0001193125-12-487586:mdna:73]
Total configured system revenues of $993.4 million decreased by $37.8 million, or 4%, during the six months ended
October 26, 2012, compared to the prior year, primarily due to a decrease in the 3000 series systems, partially offset by an increase in the 2000 series systems. Configured systems unit volume increased 12% during the six months ended
October 26, 2012, compared to the same period in the prior year. Unit volume of the 2000 series increased and unit volume of the 3000 series systems decreased, reflecting a shift in customer demand from certain 3000 series systems to the
recently introduced 2000 series systems. The ASPs of total configured systems decreased during the six months ended October 26, 2012, compared to the prior year, primarily due to a shift in sales from higher priced 3000 series systems to lower
priced 2000 series systems, as well as product mix within the various series. In addition, ASPs decreased due to unfavorable foreign currency rates.

[0001193125-12-487586:mdna:74]
Non-configured product revenues of $900.4 million decreased $50.3 million,
or 5%, during the six months ended October 26, 2012, compared to the prior year. This decrease was primarily due to lower revenue from non-configured OEM products, which declined 8%, and lower add-on storage revenue. Non-configured product
revenues were unfavorably impacted by product and customer mix.

[0001193125-12-487586:mdna:75]
Our systems are highly configurable to
respond to customer requirements in the open systems storage markets that we serve. This can cause a wide variation in product configurations that can significantly impact revenues, cost of revenues and gross profit performance. Pricing changes,
discounting practices, product competition, foreign currency, unit volumes, customer mix, natural disasters and product material costs can also impact revenues, cost of revenues and/or gross profit performance. Disks are a significant component of
our storage systems. Industry disk pricing has fallen every year; however, when supplies are constrained, disk prices may increase. To the extent that disk prices increase or decrease, we intend to pass along those price increases or decreases to
our customers while working to maintain relatively constant profit margins on our disk drives. As our sales price per terabyte continues to decline, improved system performance, increased capacity and software to manage this increased capacity have
an offsetting impact on product revenues.

[0001193125-12-487586:mdna:76]
Software Entitlements and Maintenance Revenues (in millions, except
percentages):

[0001193125-12-487586:mdna:77]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Software entitlements and maintenance revenues |  | $ | 219.4 |  |  | $ | 198.0 |  |  |  | 11 | % |  | $ | 437.9 |  |  | $ | 396.2 |  |  |  | 11 | % |

[0001193125-12-487586:mdna:78]
SEM revenues increased $21.4 million and $41.7 million, or 11% each, during the three and
six months ended October 26, 2012, respectively, compared to the prior year. The increases in each period were due to increases in the aggregate contract values of the installed base under SEM contracts, which is recognized as revenue ratably
over the terms of the underlying contracts.

[0001193125-12-487586:mdna:79]
[same as prior period, unchanged from 0001193125-12-375807:mdna:75]

[0001193125-12-487586:mdna:80]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Service revenues |  | $ | 326.0 |  |  | $ | 292.8 |  |  |  | 11 | % |  | $ | 654.1 |  |  | $ | 587.1 |  |  |  | 11 | % |

[0001193125-12-487586:mdna:81]
Service revenues include hardware maintenance, professional services and educational and
training services. Service revenues increased $33.2 million and $67.0 million, or 11% each, during the three and six months ended October 26, 2012, respectively, compared to the prior year.

[0001193125-12-487586:mdna:82]
Hardware maintenance contract revenues comprised 74% and 72% of service revenues for the three and six months ended
October 26, 2012, respectively, and 71% and 70% for the three and six months ended October 28, 2011, respectively. These revenues increased $33.0 million, or 16%, and $62.6 million, or 15%, during the three and six months ended
October 26, 2012, respectively, compared to the prior year, as a result of increases in the installed base and aggregate contract values under service contracts. Professional services and educational and training services comprised 26% and 28%
of service revenues for the three and six months ended October 26, 2012, respectively, and 29% and 30% of service revenues for the three and six months ended October 28, 2011, respectively.

[0001193125-12-487586:mdna:83]
[same as prior period, unchanged from 0001193125-12-375807:mdna:79]

[0001193125-12-487586:mdna:84]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Americas (United States, Canada and Latin America) |  | $ | 897.3 |  |  | $ | 897.1 |  |  |  | — | % |  | $ | 1,698.4 |  |  | $ | 1,710.5 |  |  |  | (1 | )% |
| Europe, Middle East and Africa (EMEA) |  |  | 437.7 |  |  |  | 428.9 |  |  |  | 2 | % |  |  | 877.0 |  |  |  | 885.6 |  |  |  | (1 | )% |
| Asia Pacific and Japan (APAC) |  |  | 206.2 |  |  |  | 181.0 |  |  |  | 14 | % |  |  | 410.4 |  |  |  | 369.1 |  |  |  | 11 | % |
| Net revenues |  | $ | 1,541.2 |  |  | $ | 1,507.0 |  |  |  |  |  |  | $ | 2,985.8 |  |  | $ | 2,965.2 |  |  |  |  |  |

[0001193125-12-487586:mdna:85]
Americas revenues consist of Americas commercial and U.S. public sector
markets.

[0001193125-12-487586:mdna:86]
Sales to customers inside the United States comprised 89% and 86% of Americas net revenues during
the three months ended October 26, 2012 and October 28, 2011, respectively, and 89% and 85% of Americas net revenues during the six months ended October 26, 2012 and October 28, 2011, respectively. During both the three and six
months ended October 26, 2012, EMEA revenues were negatively impacted by the general macroeconomic conditions in the region, as well as unfavorable foreign currency rates. No single foreign country accounted for 10% or more of net revenues in
any of the periods presented.

[0001193125-12-487586:mdna:87]
[same as prior period, unchanged from 0001193125-12-375807:mdna:83]

[0001193125-12-487586:mdna:88]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of
manufacturing and shipping of our storage products, amortization of purchased intangible assets, inventory write-downs, and warranty costs; (2) cost of SEM, which includes the costs of providing SEM and third-party royalty costs and
(3) cost of service revenues, which reflects costs associated with providing support activities for hardware, global support partnership programs, professional services and educational and training services.

[0001193125-12-487586:mdna:89]
[same as prior period, unchanged from 0001193125-12-375807:mdna:85]

[0001193125-12-487586:mdna:90]
[same as prior period, unchanged from 0001193125-12-375807:mdna:86]

[0001193125-12-487586:mdna:91]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Cost of product revenues |  | $ | 477.3 |  |  | $ | 460.7 |  |  |  | 4 | % |  | $ | 929.5 |  |  | $ | 898.1 |  |  |  | 3 | % |

[0001193125-12-487586:mdna:92]
Cost of product revenues increased $16.6 million, or 4%, and $31.4 million, or 3%, during
the three and six months ended October 26, 2012, respectively, compared to the prior year. The changes consisted of the following elements (in percentage points of the total change):

[0001193125-12-487586:mdna:93]
|  |  | Three Months EndedFiscal 2013 to Fiscal 2012Percentage ChangePoints |  |  | Six Months EndedFiscal 2013 to Fiscal 2012Percentage ChangePoints |  |
| Materials cost |  |  | 1 |  |  |  | 1 |  |
| Warranty |  |  | 3 |  |  |  | 3 |  |
| Excess and obsolete inventory |  |  | — |  |  |  | (1 | ) |
| Total change |  |  | 4 |  |  |  | 3 |  |

[0001193125-12-487586:mdna:94]
Materials cost represented 83% and 85% of product costs for the three months ended
October 26, 2012 and October 28, 2011, respectively, and increased $6.3 million from the prior year primarily due to a 15% unit volume increase in configured systems, partially offset by materials cost reductions due to a change in mix
towards lower cost 2000 series systems. Other product costs of sales for the three months ended October 26, 2012 included an $11.4 million increase in hardware-related warranty expense compared to the prior year.

[0001193125-12-487586:mdna:95]
Materials cost represented 82% and 84% of product costs for the six months ended October 26, 2012 and
October 28, 2011, respectively, and increased $7.7 million from the prior year primarily due to a 12% unit volume increase in configured systems, partially offset by materials cost reductions due to a change in mix towards lower cost 2000
series systems. Other product costs of sales for the six months ended October 26, 2012 included a $23.4 million increase in hardware-related warranty expense.

[0001193125-12-487586:mdna:96]
Cost of product revenues represented 48% and 49% of product revenue for the three and six months ended October 26,
2012, respectively, compared to 45% for each of the three and six months ended October 28, 2011.

[0001193125-12-487586:mdna:97]
Cost of Software Entitlements and Maintenance Revenues (in millions, except
percentages):

[0001193125-12-487586:mdna:98]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Cost of software entitlements and maintenance revenues |  | $ | 7.0 |  |  | $ | 5.6 |  |  |  | 25 | % |  | $ | 13.6 |  |  | $ | 10.9 |  |  |  | 25 | % |

[0001193125-12-487586:mdna:99]
Cost of SEM revenues increased $1.4 million and $2.7 million, or 25% in each period,
during the three and six months ended October 26, 2012, respectively, compared to the prior year, primarily due to an increase in volume-related software support costs. Cost of SEM revenues represented 3% of SEM revenues for all periods
presented.

[0001193125-12-487586:mdna:100]
[same as prior period, unchanged from 0001193125-12-375807:mdna:95]

[0001193125-12-487586:mdna:101]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Cost of service revenues |  | $ | 143.0 |  |  | $ | 127.7 |  |  |  | 12 | % |  | $ | 278.7 |  |  | $ | 246.3 |  |  |  | 13 | % |

[0001193125-12-487586:mdna:102]
Cost of service revenues increased $15.3 million, or 12%, and $32.4 million, or 13%
during the three and six months ended October 26, 2012, respectively, compared to the prior year primarily due to increases in contract fulfillment, logistics and service delivery costs. Costs represented 44% of service revenues for each of the
three months ended October 26, 2012 and October 28, 2011, respectively, and represented 43% and 42% of service revenues for the six months ended October 26, 2012 and October 28, 2011, respectively.

[0001193125-12-487586:mdna:103]
[same as prior period, unchanged from 0001193125-12-375807:mdna:98]

[0001193125-12-487586:mdna:104]
[same as prior period, unchanged from 0001193125-12-375807:mdna:99]

[0001193125-12-487586:mdna:105]
Compensation costs comprise the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation costs and
employee incentive compensation plan costs. Compensation costs included in operating expenses increased $41.7 million and $81.4 million, or 11% for each of the three and six months ended October 26, 2012, respectively, compared to the
prior year, primarily due to:

[0001193125-12-487586:mdna:106]
(i) an increase in salaries, benefits and other compensation-related costs of
$28.0 million and $41.7 million for the three and six months ended October 26, 2012, respectively, due to increases in average headcount;

[0001193125-12-487586:mdna:107]
(ii) an increase in stock-based compensation of $20.2 million for the six months ended October 26, 2012, which included $12.8 million of expense in the three months ended July 27, 2012 related
to the reset of the employee stock purchase plan offering triggered by the decline in our stock price below the grant date prices of the offerings that vested in May 2012 and

[0001193125-12-487586:mdna:108]
(iii) an increase in incentive compensation expense of $12.1 million and $19.5 million for the three and six months ended
October 26, 2012, respectively, reflecting increased headcount and stronger revenue and operating performance against goals as compared to the prior year.

[0001193125-12-487586:mdna:109]
[same as prior period, unchanged from 0001193125-12-375807:mdna:104]

[0001193125-12-487586:mdna:110]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 488.2 |  |  | $ | 454.1 |  |  |  | 8 | % |  | $ | 971.1 |  |  | $ | 908.9 |  |  |  | 7 | % |

[0001193125-12-487586:mdna:111]
Sales and marketing expense consists primarily of compensation costs,
commissions, outside services, allocated facilities and information technology (IT) costs, advertising and marketing promotional expense and travel and entertainment expense. Sales and marketing expenses increased due to the following:

[0001193125-12-487586:mdna:112]
|  |  | Three Months EndedFiscal 2013 to Fiscal 2012Percentage ChangePoints |  |  | Six Months EndedFiscal 2013 to Fiscal 2012Percentage ChangePoints |  |
| Salaries |  |  | 2 |  |  |  | 2 |  |
| Incentive plan compensation |  |  | 1 |  |  |  | 1 |  |
| Stock-based compensation |  |  | — |  |  |  | 1 |  |
| Other compensation and benefit costs |  |  | 2 |  |  |  | 1 |  |
| Total compensation costs |  |  | 5 |  |  |  | 5 |  |
| Commissions |  |  | 1 |  |  |  | — |  |
| Facilities and IT support costs |  |  | 2 |  |  |  | 2 |  |
| Advertising and marketing promotional expense |  |  | 1 |  |  |  | 1 |  |
| Other |  |  | (1 | ) |  |  | (1 | ) |
| Total change |  |  | 8 |  |  |  | 7 |  |

[0001193125-12-487586:mdna:113]
The increases in total compensation costs during the three and six months ended
October 26, 2012 reflect increases of 9% and 11%, respectively, in average sales and marketing headcount and higher compensation cost per employee compared to the prior year. The increase in total compensation costs during the six months ended
October 26, 2012 also reflects higher stock-based compensation expense. The increases in facilities and IT support costs during the three and six months ended October 26, 2012 reflects an increase in our investment in IT systems.

[0001193125-12-487586:mdna:114]
[same as prior period, unchanged from 0001193125-12-375807:mdna:109]

[0001193125-12-487586:mdna:115]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Research and development expenses |  | $ | 223.8 |  |  | $ | 199.7 |  |  |  | 12 | % |  | $ | 445.2 |  |  | $ | 398.3 |  |  |  | 12 | % |

[0001193125-12-487586:mdna:116]
[same as prior period, unchanged from 0001193125-12-375807:mdna:111]

[0001193125-12-487586:mdna:117]
|  |  | Three Months EndedFiscal 2013 to Fiscal 2012Percentage ChangePoints |  |  | Six Months EndedFiscal 2013 to Fiscal 2012Percentage ChangePoints |  |
| Salaries |  |  | 4 |  |  |  | 3 |  |
| Incentive plan compensation |  |  | 2 |  |  |  | 2 |  |
| Stock-based compensation |  |  | 1 |  |  |  | 2 |  |
| Other compensation and benefit costs |  |  | 1 |  |  |  | 1 |  |
| Total compensation costs |  |  | 8 |  |  |  | 8 |  |
| Depreciation and amortization |  |  | 2 |  |  |  | 2 |  |
| Development projects |  |  | 1 |  |  |  | 2 |  |
| Other |  |  | 1 |  |  |  | — |  |
| Total change |  |  | 12 |  |  |  | 12 |  |

[0001193125-12-487586:mdna:118]
The increases in total compensation costs during the three and six months ended
October 26, 2012 reflect increases of 5% and 11%, respectively, in average engineering headcount and higher compensation cost per employee compared to the prior year. The increase in total compensation costs during the six months ended
October 26, 2012 also reflects higher stock-based compensation expense. Depreciation and amortization increased during the three and six months ended October 26, 2012 due to higher levels of investment in engineering equipment. The
increase in development project expense during the three and six months ended October 26, 2012 reflects increased spending on materials and services associated with engineering activities to develop new product lines and enhancements to
existing products.

[0001193125-12-487586:mdna:119]
We believe that our future performance will depend in large part on our ability to
maintain and enhance our current product line, develop new products that achieve market acceptance, maintain technological competitiveness and meet an expanding range of customer requirements. We expect to continue to spend on current and future
product development efforts, broaden our existing product offerings and introduce new products that expand our solutions portfolio.

[0001193125-12-487586:mdna:120]
General and Administrative Expense (in millions, except percentages):

[0001193125-12-487586:mdna:121]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| General and administrative expenses |  | $ | 66.6 |  |  | $ | 65.1 |  |  |  | 2 | % |  | $ | 132.2 |  |  | $ | 130.2 |  |  |  | 2 | % |

[0001193125-12-487586:mdna:122]
[same as prior period, unchanged from 0001193125-12-375807:mdna:117]

[0001193125-12-487586:mdna:123]
|  |  | Three Months EndedFiscal 2013 to Fiscal 2012Percentage ChangePoints |  |  | Six Months EndedFiscal 2013 to Fiscal 2012Percentage ChangePoints |  |
| Salaries |  |  | 1 |  |  |  | 1 |  |
| Incentive plan compensation |  |  | 3 |  |  |  | 3 |  |
| Other compensation and benefit costs |  |  | 1 |  |  |  | 1 |  |
| Total compensation costs |  |  | 5 |  |  |  | 5 |  |
| Outside services |  |  | (3 | ) |  |  | (4 | ) |
| Professional and corporate legal fees |  |  | (1 | ) |  |  | — |  |
| Other |  |  | 1 |  |  |  | 1 |  |
| Total change |  |  | 2 |  |  |  | 2 |  |

[0001193125-12-487586:mdna:124]
The increases in total compensation costs reflect increases of 8% in average general and
administrative headcount during each of the three and six months ended October 26, 2012 and higher incentive compensation expense compared to the prior year. The decreases in outside services during the three and six months ended
October 26, 2012 reflect lower spending on contractors and various operational projects. Additionally, the decrease in outside services during the six months ended October 26, 2012 reflects costs associated with Engenio integration
activities that were completed in fiscal 2012.

[0001193125-12-487586:mdna:125]
[same as prior period, unchanged from 0001193125-12-375807:mdna:120]

[0001193125-12-487586:mdna:126]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Acquisition-related expense |  | $ | — |  |  | $ | 1.7 |  |  |  | (100 | )% |  | $ | — |  |  | $ | 3.9 |  |  |  | (100 | )% |

[0001193125-12-487586:mdna:127]
During the three and six months ended October 28, 2011, we incurred due diligence,
legal and integration costs of $1.7 million and $3.9 million, respectively, associated with our fiscal 2012 acquisition of Engenio.

[0001193125-12-487586:mdna:128]
Other Expense, Net

[0001193125-12-487586:mdna:129]
Interest Income (in millions, except
percentages):

[0001193125-12-487586:mdna:130]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Interest income |  | $ | 11.0 |  |  | $ | 8.3 |  |  |  | 33 | % |  | $ | 21.8 |  |  | $ | 18.9 |  |  |  | 15 | % |

[0001193125-12-487586:mdna:131]
The increases in interest income during the three and six months ended October 26,
2012, compared to the prior year, were primarily due to increases in our investment portfolio.

[0001193125-12-487586:mdna:132]
Interest Expense (in
millions, except percentages):

[0001193125-12-487586:mdna:133]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Interest expense |  | $ | (19.8 | ) |  | $ | (16.4 | ) |  |  | 21 | % |  | $ | (39.7 | ) |  | $ | (35.8 | ) |  |  | 11 | % |

[0001193125-12-487586:mdna:134]
During the three months ended October 26, 2012 and October 28, 2011, we
recognized non-cash interest expense from the amortization of debt discount and issuance costs related to our Notes, net of capitalized interest, of $14.4 million and $11.5 million, respectively. The coupon interest expense related to our Notes, net
of capitalized interest, was $5.3 million and $4.5 million during the three months ended October 26, 2012 and October 28, 2011, respectively.

[0001193125-12-487586:mdna:135]
During the six months ended October 26, 2012 and October 28, 2011,
we recognized non-cash interest expense from the amortization of debt discount and issuance costs related to our Notes, net of capitalized interest, of $28.7 million and $25.2 million, respectively. The coupon interest expense related to our Notes,
net of capitalized interest, was $10.7 million and $10.0 million during the six months ended October 26, 2012 and October 28, 2011, respectively.

[0001193125-12-487586:mdna:136]
[same as prior period, unchanged from 0001193125-12-375807:mdna:131]

[0001193125-12-487586:mdna:137]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Other income (expense), net |  | $ | 1.2 |  |  | $ | (0.4 | ) |  |  | NM |  |  | $ | 4.3 |  |  | $ | (0.7 | ) |  |  | NM |  |

[0001193125-12-487586:mdna:138]
[same as prior period, unchanged from 0001193125-12-375807:mdna:133]

[0001193125-12-487586:mdna:139]
Other income (expense), net, increased $1.6
million and $5.0 million, during the three and six months ended October 26, 2012, respectively, compared to the prior year. The increase during the six months ended October 26, 2012 is primarily due to net foreign exchange gains of $3.3
million.

[0001193125-12-487586:mdna:140]
Provision for Income Taxes (in millions, except percentages):

[0001193125-12-487586:mdna:141]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |  | October 26,2012 |  |  | October 28,2011 |  |  | % Change |  |
| Provision for income taxes |  | $ | 18.1 |  |  | $ | 18.3 |  |  |  | (1 | )% |  | $ | 28.5 |  |  | $ | 45.9 |  |  |  | (38 | )% |

[0001193125-12-487586:mdna:142]
Our effective tax rate for the three months ended October 26, 2012 was 14.2%
compared to an effective tax rate of 10.0% for the three months ended October 28, 2011. Our effective tax rate for the six months ended October 26, 2012 was 14.1% compared to an effective tax rate of 13.1% for the six months ended
October 28, 2011. Our effective tax rates for the three and six months ended October 26, 2012 and October 28, 2011 differ from the U.S. statutory rate of 35% because our foreign earnings are taxed at rates lower than the U.S.
statutory rate. Our provision for income taxes decreased for the three and six months ended October 26, 2012 compared to the prior year as a result of lower pre-tax income, primarily in the United States. Our effective tax rates increased for
the three and six months ended October 26, 2012 compared to the prior year as a result of higher non-deductible stock-based compensation expense and the expiration of the federal research credit, partially offset by the tax benefit from reduced
profits, primarily in the United States.

[0001193125-12-487586:mdna:143]
As of October 26, 2012, we had $165.3 million of unrecognized
tax benefits, of which $109.7 million has been recorded in other long-term liabilities and of which $98.3 million, including penalties and interest, would affect our provision for income taxes if recognized.

[0001193125-12-487586:mdna:144]
[same as prior period, unchanged from 0001193125-12-375807:mdna:139]

[0001193125-12-487586:mdna:145]
The following sections discuss our principal liquidity requirements, as well as our sources and uses of cash flows on our liquidity and capital resources. The principal objectives of our investment policy
are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors
closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of October 26,
2012.

[0001193125-12-487586:mdna:146]
[same as prior period, unchanged from 0001193125-12-375807:mdna:141]

[0001193125-12-487586:mdna:147]
Our principal sources of liquidity as of October 26, 2012 consisted of $5.6 billion in cash, cash equivalents
and short-term investments, as well as cash we expect to generate from operations.

[0001193125-12-487586:mdna:148]
Cash, cash equivalents and
short-term investments consist of the following (in millions):

[0001193125-12-487586:mdna:149]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Cash and cash equivalents |  | $ | 1,816.8 |  |  | $ | 1,549.8 |  |
| Short-term investments |  |  | 3,754.2 |  |  |  | 3,848.7 |  |
| Total |  | $ | 5,571.0 |  |  | $ | 5,398.5 |  |

[0001193125-12-487586:mdna:150]
As of October 26, 2012, $2.5 billion of cash, cash equivalents and
short-term investments were held in the United States, while $3.1 billion were held in foreign countries. Most of the amounts held outside the United States can be repatriated to the United States but, under current law, would be subject to U.S.
federal and state income taxes. If we were to repatriate foreign earnings for cash requirements in the United States, we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state net operating loss
and tax credit carry forwards. However, our intent is to keep these funds permanently reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity
requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies, and service interest and principal
payments on our debt. Our contractual obligations as of October 26, 2012 are summarized below in the Contractual Obligations table.

[0001193125-12-487586:mdna:151]
[same as prior period, unchanged from 0001193125-12-375807:mdna:146]

[0001193125-12-487586:mdna:152]
[same as prior period, unchanged from 0001193125-12-375807:mdna:147]

[0001193125-12-487586:mdna:153]
[same as prior period, unchanged from 0001193125-12-375807:mdna:148]

[0001193125-12-487586:mdna:154]
Our
Notes, which have a principal amount of $1.265 billion, become unconditionally convertible at the option of the holders of the Notes on March 1, 2013 and mature on June 1, 2013 unless earlier repurchased or converted (see Note 9 of the
accompanying condensed consolidated financial statements). Our common stock price did not exceed the conversion threshold for the Notes for at least 20 trading days during the 30 consecutive trading days ended September 30, 2012, and
accordingly, as of October 26, 2012 the Notes were not convertible at the option of the holder. Upon conversion of our Notes, we will deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater
than the principal amount of the Notes, shares of our common stock.

[0001193125-12-487586:mdna:155]
We are actively evaluating our options
for retiring this debt. These options range from paying off the Notes by drawing from available cash to issuing new debt, which may be in the form of convertible notes or conventional debt.

[0001193125-12-487586:mdna:156]
[same as prior period, unchanged from 0001193125-12-375807:mdna:150]

[0001193125-12-487586:mdna:157]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through
existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes
in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We expect that our existing facilities and those being developed in Sunnyvale, California; Research Triangle Park,
North Carolina; India and other locations worldwide are adequate for our requirements over at least the next two years and that additional space will be available as needed. Our capital expenditures were $129.0 million during the six months ended
October 26, 2012. We anticipate capital expenditures for the remainder of fiscal 2013 to be between $150.0 million and $200.0 million, including $69.6 million for the anticipated buyout of our properties subject to synthetic leases.

[0001193125-12-487586:mdna:158]
[same as prior period, unchanged from 0001193125-12-375807:mdna:175]

[0001193125-12-487586:mdna:159]
[same as prior period, unchanged from 0001193125-12-375807:mdna:152]

[0001193125-12-487586:mdna:160]
As of October 26, 2012, our Board of Directors had authorized the repurchase of up to $4.0 billion of our common
stock under our stock repurchase program. As of October 26, 2012, the remaining authorized amount for stock repurchases under our stock repurchase program was $0.1 billion with no termination date. On November 14, 2012, our Board of
Directors approved an increase of $1.5 billion to our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our
management. The stock repurchase program may be suspended or discontinued at any time.

[0001193125-12-487586:mdna:161]
Acquisition Requirements

[0001193125-12-487586:mdna:162]
On November 14, 2012, we completed the acquisition of CacheIQ, a privately held storage
solutions software company based in Austin, Texas, for approximately $90.0 million in cash.

[0001193125-12-487586:mdna:163]
[same as prior period, unchanged from 0001193125-12-375807:mdna:154]

[0001193125-12-487586:mdna:164]
As of October 26, 2012, our cash, cash equivalents and short-term investments increased by
$172.5 million from April 27, 2012, to $5.6 billion. The increase was primarily a result of $565.6 million of cash provided by operating activities and $45.1 million from issuances of common stock under employee equity award plans,
partially offset by $348.3 million in cash paid for the repurchase of common stock and $129.0 million in capital expenditures. We derive our liquidity and capital resources primarily from our operating cash flows and from working capital. Accounts
receivable days sales outstanding as of October 26, 2012 decreased to 36 days, compared to 44 days as of April 27, 2012, primarily due to improvements in shipment linearity and faster collections. Working capital increased by
$7.3 million to $3.3 billion as of October 26, 2012, primarily due to a net increase in cash, cash equivalents and short-term investments, inventory and short-term deferred revenue, partially offset by a decrease in accounts
receivable and accrued compensation and related benefits.

[0001193125-12-487586:mdna:165]
[same as prior period, unchanged from 0001193125-12-375807:mdna:156]

[0001193125-12-487586:mdna:166]
During the six months ended October 26, 2012, we generated cash from operating activities of $565.6 million.
The primary sources of cash from operating activities during the six months ended October 26, 2012 consisted of net income of $173.4 million, adjusted by depreciation and amortization of $169.1 million and stock-based compensation of
$144.2 million. Significant changes in assets and liabilities impacting operating cash flows included a decrease in accounts receivable of $212.9 million.

[0001193125-12-487586:mdna:167]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, shipment linearity, accounts
receivable collections performance, inventory and supply chain management, tax benefits or charges from stock-based compensation, and the timing and amount of compensation and other payments.

[0001193125-12-487586:mdna:168]
[same as prior period, unchanged from 0001193125-12-375807:mdna:159]

[0001193125-12-487586:mdna:169]
During the six months ended October 26, 2012, we generated $93.4 million from maturities and sales of investments, net of purchases, and paid $129.0 million for capital expenditures.

[0001193125-12-487586:mdna:170]
[same as prior period, unchanged from 0001193125-12-375807:mdna:161]

[0001193125-12-487586:mdna:171]
During the six months ended October 26, 2012, we used $259.9 million in financing activities, which included $348.3 million for the repurchase of 10.9 million shares of common stock at an
average price of $31.86 per share.

[0001193125-12-487586:mdna:172]
[same as prior period, unchanged from 0001193125-12-375807:mdna:163]

[0001193125-12-487586:mdna:173]
The following table summarizes our contractual obligations as of October 26, 2012 and the effect such obligations
are expected to have on our liquidity and cash flows in future periods (in millions):

[0001193125-12-487586:mdna:174]
|  |  | Remainderof2013 |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | Thereafter |  |  | Total |  |
| Off-balance sheet commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Office operating lease payments |  | $ | 20.2 |  |  | $ | 43.7 |  |  | $ | 40.2 |  |  | $ | 36.6 |  |  | $ | 21.4 |  |  | $ | 59.1 |  |  | $ | 221.2 |  |
| Real estate lease payments(1) |  |  | 59.6 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 59.6 |  |
| Less: sublease income |  |  | (0.5 | ) |  |  | (1.2 | ) |  |  | (1.2 | ) |  |  | (0.9 | ) |  |  | — |  |  |  | — |  |  |  | (3.8 | ) |
| Equipment operating lease payments |  |  | 14.1 |  |  |  | 21.3 |  |  |  | 11.8 |  |  |  | 5.8 |  |  |  | 0.8 |  |  |  | — |  |  |  | 53.8 |  |
| Purchase commitments with contract manufacturers(2) |  |  | 265.3 |  |  |  | 1.2 |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 266.7 |  |
| Capital expenditures |  |  | 23.1 |  |  |  | 17.7 |  |  |  | 0.5 |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | 41.5 |  |
| Other purchase obligations(3) |  |  | 80.4 |  |  |  | 47.1 |  |  |  | 32.8 |  |  |  | 16.8 |  |  |  | 11.5 |  |  |  | 1.5 |  |  |  | 190.1 |  |
| Total off balance-sheet commitments |  |  | 462.2 |  |  |  | 129.8 |  |  |  | 84.3 |  |  |  | 58.5 |  |  |  | 33.7 |  |  |  | 60.6 |  |  |  | 829.1 |  |
| 1.75% Convertible Notes(4) |  |  | 1,275.9 |  |  |  | 11.1 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,287.0 |  |
| Long-term financing arrangements |  |  | 3.8 |  |  |  | 6.3 |  |  |  | 4.0 |  |  |  | 3.6 |  |  |  | 1.3 |  |  |  | — |  |  |  | 19.0 |  |
| Uncertain tax positions(5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 112.2 |  |
| Total |  | $ | 1,741.9 |  |  | $ | 147.2 |  |  | $ | 88.3 |  |  | $ | 62.1 |  |  | $ | 35.0 |  |  | $ | 60.6 |  |  | $ | 2,247.3 |  |
| Other Commercial Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit |  | $ | 3.6 |  |  | $ | 2.2 |  |  | $ | 0.2 |  |  | $ | 0.5 |  |  | $ | 1.8 |  |  | $ | 1.7 |  |  | $ | 10.0 |  |

[0001193125-12-487586:mdna:175]
| (1) | Included in real estate lease payments pursuant to three financing arrangements with BNP Paribas LLC (BNPPLC) are (i) lease commitments of $0.5 million, which are based on a fixed rate for terms of five years, and (ii) at the expiration or termination of the leasing arrangements, a supplemental payment obligation equal to our minimum guarantee of $59.1 million in the event that we elect not to purchase or arrange for sale of the buildings. |

[0001193125-12-487586:mdna:176]
| (2) | Contract manufacturer commitments consist of obligations for on-hand inventories and non-cancelable purchase orders with our contract manufacturers. As of October 26, 2012, we recorded accruals of $8.5 million for firm, non-cancelable purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts, which is consistent with the valuation of our excess and obsolete inventory. |

[0001193125-12-487586:mdna:177]
[same as prior period, unchanged from 0001193125-12-375807:mdna:168]

[0001193125-12-487586:mdna:178]
| (4) | Included in these amounts are obligations related to the $1.265 billion principal amount of our Notes (see Note 9 of the accompanying condensed consolidated financial statements), which become unconditionally convertible at the option of the holders in fiscal 2013 and mature in fiscal 2014 unless earlier repurchased or converted. Estimated interest payments for the Notes are $11.0 million and $11.1 million for the remainder of fiscal 2013 and fiscal 2014, respectively. |

[0001193125-12-487586:mdna:179]
| (5) | As of October 26, 2012, our liability for uncertain tax positions was $112.2 million, including interest and penalties, which due to the uncertainty of the timing of future payments, are presented in the total column on a separate line in this table. |

[0001193125-12-487586:mdna:180]
[same as prior period, unchanged from 0001193125-12-375807:mdna:171]

[0001193125-12-487586:mdna:181]
As of October 26, 2012, we have three leasing arrangements with BNPPLC, one of which requires us to lease certain of our land to BNPPLC for a period of 99 years and all of which require us
to lease approximately 0.3 million square feet of office space from BNPPLC for our headquarters in Sunnyvale, California, which had an aggregate original cost of $69.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease
payments, which vary based on a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of the leases for two
consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of the lease terms, we must elect one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain
conditions are met, arrange for the sale of the buildings by BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received from the third-party and BNPPLC’s cost, up to 85% of cost (residual guarantee); or
(iii) pay BNPPLC supplemental payments for an amount equal to the difference between BNPPLC’s cost and fair value, up to the residual guarantee, in which event we may recoup some or all of such payments by arranging for a sale of each or
all buildings by BNPPLC during the ensuing two-year period. The following table summarizes the aggregate cost, the aggregate residual guarantee, the applicable fixed rates at October 26, 2012 and the lease commencement dates for our leasing
arrangements:

[0001193125-12-487586:mdna:182]
[same as prior period, unchanged from 0001193125-12-375807:mdna:173]

[0001193125-12-487586:mdna:183]
35

[0001193125-12-487586:mdna:184]
These leasing arrangements require us to maintain specified financial
covenants with which we were in compliance as of October 26, 2012. Such financial covenants include a maximum ratio of Total Debt to Earnings before Interest, Taxes, Depreciation and Amortization of less than 3:1 and a minimum amount of
Unencumbered Cash and Short-Term Investments of $300.0 million. Our failure to comply with these financial covenants could result in a default under the leases, which, subject to our right and ability to exercise our purchase option, would give
BNPPLC the right to, among other things, (i) terminate our possession of the leased property and require us to pay lease termination damages and other amounts as set forth in the lease agreements or (ii) exercise certain foreclosure
remedies.

[0001193125-12-487586:mdna:185]
Our current intention, subject to change at our election, is to exercise our option to buy out our
synthetic leases when their five year terms expire in December 2012 through January 2013.

[0001193125-12-487586:mdna:186]
Legal Contingencies

[0001193125-12-487586:mdna:187]
We are subject to various legal proceedings and claims which arise in the normal course of business.
See further details on such matters in Note 15 to our condensed consolidated financial statements.

[0001193125-12-487586:mdna:188]
Off-Balance Sheet
Arrangements

[0001193125-12-487586:mdna:189]
In the ordinary course of business, we provide standby letters of credit or other
guarantee instruments to third parties as required for certain transactions initiated either by us or our subsidiaries. As of October 26, 2012, our financial guarantees of $10.0 million that were not recorded on our condensed consolidated
balance sheet consisted of standby letters of credit related to workers’ compensation, a customs guarantee, a corporate credit card program, foreign rent guarantees and surety bonds, which were primarily related to self-insurance.

[0001193125-12-487586:mdna:190]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives
is to reduce the volatility of earnings and cash flows associated with changes in foreign currency. The program is not designated for trading or speculative purposes. Currently, we do not enter into any foreign exchange forward contracts to hedge
exposures related to firm commitments or nonmarketable investments. Our major foreign currency exchange exposures and related hedging programs are described below:

[0001193125-12-487586:mdna:191]
|  | • |  | We use monthly foreign currency forward and options contracts to hedge exchange rate fluctuations related to certain foreign monetary assets and liabilities. |

[0001193125-12-487586:mdna:192]
[same as prior period, unchanged from 0001193125-12-375807:mdna:183]

[0001193125-12-487586:mdna:193]
As of October 26, 2012, the notional fair value of foreign currency forward and option contracts totaled $657.3 million. We do not believe that these derivatives present significant credit risks
because of the short term maturity of the outstanding contracts at any point in time, the counterparties to the derivatives consist of major financial institutions and we manage the notional amount of contracts entered into with any one
counterparty. Other than the risk associated with the financial condition of the counterparties, our maximum exposure related to foreign currency forward and option contracts is limited to the premiums paid. See Note 11 of the accompanying
condensed consolidated financial statements for more information related to our hedging activities.

[0001193125-12-487586:mdna:194]
In the
ordinary course of business, some of our customers have entered into recourse and non-recourse financing leasing arrangements using third-party financing companies, and in some situations, we enter into customer financing arrangements for our
products and services that are contemporaneously sold on a recourse or non-recourse basis to third-party financing companies. During the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid
remaining lease payments to the third-party leasing companies in the event of end-user customer default. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and
recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. As of October 26, 2012, the maximum guaranteed payment contingencies under our financing arrangements totaled $170.8
million, and the related deferred revenue totaled $154.5 million.

[0001193125-12-487586:mdna:195]
We enter into indemnification agreements with third parties in the ordinary
course of business. Generally, these indemnification agreements require us to reimburse losses suffered by the third-parties due to various events, such as lawsuits arising from patent or copyright infringement. These indemnification obligations are
considered off-balance sheet arrangements under accounting guidance.

[0001193125-12-487586:mdna:196]
We have commitments related to three
leasing arrangements with BNPPLC for approximately 0.3 million square feet of office space for our headquarters in Sunnyvale, California (as further described above under “Contractual Obligations”). Our future minimum lease payments
and residual guarantees under these real estate leases will amount to a total of $59.6 million as discussed above in “Contractual Obligations.”

[0001193125-12-487586:mdna:197]
37
