# NTAP notes — 0001193125-12-487586


## us-gaap:ScheduleOfShareBasedCompensationEmployeeStockPurchasePlanActivityTableTextBlock

[0001193125-12-487586:notes:1]
Additional information related to the purchase rights issued
under the ESPP is provided below (in millions, except per right and
per share information):

[0001193125-12-487586:notes:2]
|  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Weighted-average fair value per right granted |  | $ | 10.25 |  |  | $ | 15.88 |  |
| Shares issued under the ESPP |  |  | 1.9 |  |  |  | 1.1 |  |
| Weighted-average price per share issued |  | $ | 25.30 |  |  | $ | 39.17 |  |


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-12-487586:notes:3]
[same as prior period, unchanged from 0001193125-12-375807:notes:3]

[0001193125-12-487586:notes:4]
[same as prior period, unchanged from 0001193125-12-375807:notes:4]

[0001193125-12-487586:notes:5]
|  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Reclassification of equity component of convertible debt |  | $ | 62.6 |  |  | $ | 114.6 |  |
| Acquisition of property and equipment on account |  | $ | 20.0 |  |  | $ | 41.0 |  |
| Acquisition of property and equipment through long-term financing |  | $ | 0.8 |  |  | $ | 2.5 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 26.5 |  |  | $ | 22.7 |  |
| Interest paid, net of capitalized interest |  | $ | 11.3 |  |  | $ | 10.3 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-12-487586:notes:6]
[same as prior period, unchanged from 0001193125-12-375807:notes:6]

[0001193125-12-487586:notes:7]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 109.6 |  |  | $ | 165.6 |  |  | $ | 173.4 |  |  | $ | 305.1 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 362.0 |  |  |  | 361.5 |  |  |  | 364.1 |  |  |  | 365.9 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 5.2 |  |  |  | 7.8 |  |  |  | 5.1 |  |  |  | 9.8 |  |
| Dilutive impact of assumed conversion of Notes |  |  | 1.0 |  |  |  | 6.7 |  |  |  | 0.5 |  |  |  | 11.1 |  |
| Dilutive impact of warrants |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 4.0 |  |
| Shares used in diluted computation |  |  | 368.2 |  |  |  | 376.0 |  |  |  | 369.7 |  |  |  | 390.8 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.30 |  |  | $ | 0.46 |  |  | $ | 0.48 |  |  | $ | 0.83 |  |
| Diluted |  | $ | 0.30 |  |  | $ | 0.44 |  |  | $ | 0.47 |  |  | $ | 0.78 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-12-487586:notes:8]
[same as prior period, unchanged from 0001193125-12-375807:notes:8]

[0001193125-12-487586:notes:9]
[same as prior period, unchanged from 0001193125-12-375807:notes:9]

[0001193125-12-487586:notes:10]
[same as prior period, unchanged from 0001193125-12-375807:notes:10]

[0001193125-12-487586:notes:11]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding at April 27, 2012 |  |  | 20.6 |  |  | $ | 29.98 |  |  |  |  |  |  |  |  |  |
| Options granted |  |  | 2.2 |  |  |  | 30.03 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (1.1 | ) |  |  | 18.05 |  |  |  |  |  |  |  |  |  |
| Options forfeited and expired |  |  | (0.6 | ) |  |  | 39.75 |  |  |  |  |  |  |  |  |  |
| Outstanding at October 26, 2012 |  |  | 21.1 |  |  |  | 30.31 |  |  |  | 3.66 |  |  | $ | 75.3 |  |
| Options vested and expected to vest as of October 26, 2012 |  |  | 20.5 |  |  |  | 30.07 |  |  |  | 3.59 |  |  |  | 75.2 |  |
| Exercisable at October 26, 2012 |  |  | 15.0 |  |  |  | 27.46 |  |  |  | 2.95 |  |  |  | 69.3 |  |

[0001193125-12-487586:notes:12]
The aggregate intrinsic value represents the pre-tax difference
between the exercise price of stock options and the quoted market
price of our stock on that day for all in-the-money options. As of
October 26, 2012, the total unrecognized compensation expense
related to stock options was $68.6 million, which is expected
to be recognized on a straight-line basis over a weighted-average
remaining service period of 2.3 years.

[0001193125-12-487586:notes:13]
[same as prior period, unchanged from 0001193125-12-375807:notes:13]

[0001193125-12-487586:notes:14]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Weighted-average fair value per share granted |  | $ | 12.40 |  |  | $ | 13.77 |  |  | $ | 10.86 |  |  | $ | 16.96 |  |
| Intrinsic value of options exercised |  | $ | 10.4 |  |  | $ | 6.8 |  |  | $ | 15.8 |  |  | $ | 50.6 |  |
| Proceeds received from the exercise of stock options |  | $ | 12.8 |  |  | $ | 7.7 |  |  | $ | 19.5 |  |  | $ | 42.7 |  |
| Fair value of options vested |  | $ | 15.1 |  |  | $ | 20.3 |  |  | $ | 29.5 |  |  | $ | 38.7 |  |

[0001193125-12-487586:notes:15]
[same as prior period, unchanged from 0001193125-12-375807:notes:15]

[0001193125-12-487586:notes:16]
[same as prior period, unchanged from 0001193125-12-375807:notes:16]

[0001193125-12-487586:notes:17]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding at April 27, 2012 |  |  | 12.0 |  |  | $ | 43.28 |  |
| RSUs granted |  |  | 5.0 |  |  |  | 29.31 |  |
| RSUs vested |  |  | (2.3 | ) |  |  | 39.74 |  |
| RSUs forfeited |  |  | (0.7 | ) |  |  | 41.32 |  |
| Outstanding at October 26, 2012 |  |  | 14.0 |  |  |  | 39.01 |  |

[0001193125-12-487586:notes:18]
[same as prior period, unchanged from 0001193125-12-375807:notes:18]

[0001193125-12-487586:notes:19]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Shares withheld for taxes |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.7 |  |  |  | 0.6 |  |
| Fair value of shares withheld and retired |  | $ | 2.8 |  |  | $ | 2.5 |  |  | $ | 22.6 |  |  | $ | 27.8 |  |

[0001193125-12-487586:notes:20]
As of October 26, 2012, the total unrecognized
compensation expense related to RSUs was $379.1 million, which is
expected to be recognized on a straight-line basis over a
weighted-average remaining service period of 2.8 years.

[0001193125-12-487586:notes:21]
[same as prior period, unchanged from 0001193125-12-375807:notes:21]

[0001193125-12-487586:notes:22]
Under the Employee Stock Purchase Plan (ESPP), employees who
elect to participate are granted options that include a purchase
price adjustment provision under which the employees may purchase
common stock at a 15% discount from the market value of the common
stock at certain specified dates within a two-year offering period.
Additional information related to the purchase rights issued under
the ESPP is provided below (in millions, except per right and per
share information):

[0001193125-12-487586:notes:23]
As of October 26, 2012, the total unrecognized
compensation expense related to the ESPP was $63.5 million, which
is expected to be recognized on a straight-line basis over a
weighted-average remaining service period of 1.6 years.

[0001193125-12-487586:notes:24]
[same as prior period, unchanged from 0001193125-12-375807:notes:24]

[0001193125-12-487586:notes:25]
[same as prior period, unchanged from 0001193125-12-375807:notes:25]

[0001193125-12-487586:notes:26]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Cost of product revenues |  | $ | 1.5 |  |  | $ | 1.4 |  |  | $ | 3.3 |  |  | $ | 2.5 |  |
| Cost of service revenues |  |  | 4.6 |  |  |  | 4.2 |  |  |  | 10.2 |  |  |  | 8.1 |  |
| Sales and marketing |  |  | 30.9 |  |  |  | 30.4 |  |  |  | 69.9 |  |  |  | 59.0 |  |
| Research and development |  |  | 19.3 |  |  |  | 18.2 |  |  |  | 43.0 |  |  |  | 34.2 |  |
| General and administrative |  |  | 8.7 |  |  |  | 8.8 |  |  |  | 17.8 |  |  |  | 17.3 |  |
| Total stock-based compensation expense |  | $ | 65.0 |  |  | $ | 63.0 |  |  | $ | 144.2 |  |  | $ | 121.1 |  |

[0001193125-12-487586:notes:27]
[same as prior period, unchanged from 0001193125-12-375807:notes:27]

[0001193125-12-487586:notes:28]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Employee stock options |  | $ | 11.7 |  |  | $ | 14.7 |  |  | $ | 23.7 |  |  | $ | 29.2 |  |
| RSUs |  |  | 43.3 |  |  |  | 38.9 |  |  |  | 87.8 |  |  |  | 73.3 |  |
| ESPP |  |  | 10.0 |  |  |  | 9.4 |  |  |  | 32.7 |  |  |  | 18.6 |  |
| Total stock-based compensation expense |  | $ | 65.0 |  |  | $ | 63.0 |  |  | $ | 144.2 |  |  | $ | 121.1 |  |

[0001193125-12-487586:notes:29]
Total income tax benefit associated with employee stock
transactions and recognized in stockholders’ equity was as
follows (in millions):

[0001193125-12-487586:notes:30]
|  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Income tax benefit associated with employee stock transactions |  | $ | 28.2 |  |  | $ | 79.1 |  |

[0001193125-12-487586:notes:31]
[same as prior period, unchanged from 0001193125-12-375807:notes:32]

[0001193125-12-487586:notes:32]
[same as prior period, unchanged from 0001193125-12-375807:notes:33]

[0001193125-12-487586:notes:33]
|  |  | Stock Options |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Expected term in years |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 4.8 |  |
| Risk-free interest rate |  |  | 0.62 | % |  |  | 0.97 | % |  |  | 0.63 | % |  |  | 1.55 | % |
| Volatility |  |  | 43 | % |  |  | 41 | % |  |  | 41 | % |  |  | 36 | % |

[0001193125-12-487586:notes:34]
|  |  |  |  |  |  | ESPP |  |
|  |  |  |  |  |  | Six Months Ended |  |
|  |  |  |  |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Expected term in years |  |  |  |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  |  |  |  |  | 0.18 | % |  |  | 0.25 | % |
| Volatility |  |  |  |  |  |  | 38 | % |  |  | 35 | % |

[0001193125-12-487586:notes:35]
[same as prior period, unchanged from 0001193125-12-375807:notes:36]

[0001193125-12-487586:notes:36]
During the six months ended October 26, 2012, we
repurchased and retired 10.9 million shares of our common
stock at an average price of $31.86 per share, for an aggregate
purchase price of $348.3 million, of which $104.6 million and
$243.7 million was allocated to additional paid-in capital and
retained earnings, respectively. Since the May 13, 2003
inception of our stock repurchase program through October 26,
2012, we repurchased a total of 129.9 million shares of our
common stock at an average price of $29.84 per share, for an
aggregate purchase price of $3.9 billion.

[0001193125-12-487586:notes:37]
As of October 26, 2012, our Board of Directors had
authorized the repurchase of up to $4.0 billion of our common stock
under our stock repurchase program. As of October 26, 2012,
the remaining authorized amount for stock repurchases under this
program was $0.1 billion with no termination date. On
November 14, 2012, our Board of Directors approved an increase
of $1.5 billion to our stock repurchase program. Under this
program, we may purchase shares of our outstanding common stock
through open market and privately negotiated transactions at prices
deemed appropriate by our management. The stock repurchase program
may be suspended or discontinued at any time.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001193125-12-487586:notes:38]
[same as prior period, unchanged from 0001193125-12-375807:notes:39]

[0001193125-12-487586:notes:39]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| United States |  | $ | 2,470.5 |  |  | $ | 2,697.6 |  |
| International |  |  | 3,100.5 |  |  |  | 2,763.8 |  |
| Total |  | $ | 5,571.0 |  |  | $ | 5,461.4 |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001193125-12-487586:notes:40]
The following table presents property and equipment information
for geographic areas based on the physical location of the assets
(in millions):

[0001193125-12-487586:notes:41]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| United States |  | $ | 1,032.7 |  |  | $ | 1,038.9 |  |
| International |  |  | 99.7 |  |  |  | 98.3 |  |
| Total |  | $ | 1,132.4 |  |  | $ | 1,137.2 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-12-487586:notes:42]
[same as prior period, unchanged from 0001193125-12-375807:notes:43]

[0001193125-12-487586:notes:43]
[same as prior period, unchanged from 0001193125-12-375807:notes:44]

[0001193125-12-487586:notes:44]
[same as prior period, unchanged from 0001193125-12-375807:notes:45]

[0001193125-12-487586:notes:45]
The following are the fair value of assets acquired and
liabilities assumed as of the closing date (in
millions):

[0001193125-12-487586:notes:46]
[same as prior period, unchanged from 0001193125-12-375807:notes:47]

[0001193125-12-487586:notes:47]
[same as prior period, unchanged from 0001193125-12-375807:notes:48]


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-487586:notes:48]
[same as prior period, unchanged from 0001193125-12-375807:notes:49]

[0001193125-12-487586:notes:49]
[same as prior period, unchanged from 0001193125-12-375807:notes:50]

[0001193125-12-487586:notes:50]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Employee equity award plans |  |  | 16.3 |  |  |  | 15.6 |  |  |  | 17.1 |  |  |  | 9.6 |  |

[0001193125-12-487586:notes:51]
Dilutive shares outstanding during the three and six months
ended October 26, 2012 and during the three months ended
October 28, 2011 do not include any effect resulting from
warrants, as their impact would have been anti-dilutive. The Note
hedges are not included in the calculation of earnings per share
for any period as their effect would have been anti-dilutive. The
Note hedges, if exercised upon conversion of the Notes, are
expected to reduce approximately 80% of the dilutive effect of the
Notes when our stock price is above $31.85 per share.


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001193125-12-487586:notes:52]
[same as prior period, unchanged from 0001193125-12-375807:notes:53]

[0001193125-12-487586:notes:53]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Cash |  | $ | 1,275.2 |  |  | $ | 649.8 |  |
| Cash equivalents |  |  | 541.6 |  |  |  | 900.0 |  |
| Cash and cash equivalents |  | $ | 1,816.8 |  |  | $ | 1,549.8 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-12-487586:notes:54]
8.  Financial
Instruments and Fair Value Measurements

[0001193125-12-487586:notes:55]
[same as prior period, unchanged from 0001193125-12-375807:notes:56]

[0001193125-12-487586:notes:56]
[same as prior period, unchanged from 0001193125-12-375807:notes:57]

[0001193125-12-487586:notes:57]
[same as prior period, unchanged from 0001193125-12-375807:notes:58]

[0001193125-12-487586:notes:58]
[same as prior period, unchanged from 0001193125-12-375807:notes:59]

[0001193125-12-487586:notes:59]
[same as prior period, unchanged from 0001193125-12-375807:notes:60]

[0001193125-12-487586:notes:60]
[same as prior period, unchanged from 0001193125-12-375807:notes:61]

[0001193125-12-487586:notes:61]
[same as prior period, unchanged from 0001193125-12-375807:notes:62]

[0001193125-12-487586:notes:62]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
|  |  |  |  |  | Gross Unrealized |  |  |  |  |  |  |  |  | Gross Unrealized |  |  |  |  |
|  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |
| Corporate bonds |  | $ | 2,964.3 |  |  | $ | 14.7 |  |  | $ | (0.7 | ) |  | $ | 2,978.3 |  |  | $ | 2,665.2 |  |  | $ | 9.5 |  |  | $ | (1.4 | ) |  | $ | 2,673.3 |  |
| U.S. Treasury and government debt securities |  |  | 518.9 |  |  |  | 0.8 |  |  |  | 0.0 |  |  |  | 519.7 |  |  |  | 836.7 |  |  |  | 1.2 |  |  |  | (0.1 | ) |  |  | 837.8 |  |
| Commercial paper |  |  | 85.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 85.0 |  |  |  | 164.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 164.6 |  |
| Certificates of deposit |  |  | 222.6 |  |  |  | 0.3 |  |  |  | 0.0 |  |  |  | 222.9 |  |  |  | 347.7 |  |  |  | 0.5 |  |  |  | 0.0 |  |  |  | 348.2 |  |
| Municipal bonds |  |  | 8.4 |  |  |  | 0.0 |  |  |  | (0.1 | ) |  |  | 8.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Money market funds |  |  | 481.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 481.6 |  |  |  | 724.8 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 724.8 |  |
| Auction rate securities |  |  | 49.1 |  |  |  | 0.9 |  |  |  | (3.5 | ) |  |  | 46.5 |  |  |  | 54.1 |  |  |  | 0.9 |  |  |  | (4.0 | ) |  |  | 51.0 |  |
| Equity funds |  |  | 26.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 26.1 |  |  |  | 25.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 25.5 |  |
| Total debt and equity securities |  | $ | 4,356.0 |  |  | $ | 16.7 |  |  | $ | (4.3 | ) |  | $ | 4,368.4 |  |  | $ | 4,818.6 |  |  | $ | 12.1 |  |  | $ | (5.5 | ) |  | $ | 4,825.2 |  |

[0001193125-12-487586:notes:63]
The following table presents the contractual maturities of our
debt investments as of October 26, 2012 (in
millions):

[0001193125-12-487586:notes:64]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,586.3 |  |  | $ | 1,589.3 |  |
| Due in one through five years |  |  | 2,152.9 |  |  |  | 2,164.9 |  |
| Due after ten years* |  |  | 49.1 |  |  |  | 46.5 |  |
|  |  | $ | 3,788.3 |  |  | $ | 3,800.7 |  |

[0001193125-12-487586:notes:65]
[same as prior period, unchanged from 0001193125-12-375807:notes:66]

[0001193125-12-487586:notes:66]
[same as prior period, unchanged from 0001193125-12-375807:notes:67]

[0001193125-12-487586:notes:67]
The following table summarizes our financial assets and
liabilities measured at fair value on a recurring basis as of
October 26, 2012 (in millions):

[0001193125-12-487586:notes:68]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,978.3 |  |  | $ | 0.0 |  |  | $ | 2,978.3 |  |  | $ | 0.0 |  |
| U.S. Treasury and government debt securities |  |  | 519.7 |  |  |  | 203.6 |  |  |  | 316.1 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 85.0 |  |  |  | 0.0 |  |  |  | 85.0 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 222.9 |  |  |  | 0.0 |  |  |  | 222.9 |  |  |  | 0.0 |  |
| Municipal bonds |  |  | 8.3 |  |  |  | 0.0 |  |  |  | 8.3 |  |  |  | 0.0 |  |
| Money market funds |  |  | 481.6 |  |  |  | 481.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 46.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 46.5 |  |
| Equity funds |  |  | 26.1 |  |  |  | 26.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign currency contracts |  |  | 2.9 |  |  |  | 0.0 |  |  |  | 2.9 |  |  |  | 0.0 |  |
| Total |  | $ | 4,371.3 |  |  | $ | 711.3 |  |  | $ | 3,613.5 |  |  | $ | 46.5 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | 1.8 |  |  | $ | 0.0 |  |  | $ | 1.8 |  |  | $ | 0.0 |  |

[0001193125-12-487586:notes:69]
The following table summarizes the balance sheet
classifications of our financial assets and liabilities measured at
fair value on a recurring basis as of October 26, 2012 (in
millions):

[0001193125-12-487586:notes:70]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 541.6 |  |  | $ | 481.6 |  |  | $ | 60.0 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 3,754.2 |  |  |  | 203.6 |  |  |  | 3,550.6 |  |  |  | 0.0 |  |
| Other current assets |  |  | 8.9 |  |  |  | 6.0 |  |  |  | 2.9 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 66.6 |  |  |  | 20.1 |  |  |  | 0.0 |  |  |  | 46.5 |  |
| Total |  | $ | 4,371.3 |  |  | $ | 711.3 |  |  | $ | 3,613.5 |  |  | $ | 46.5 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 1.8 |  |  | $ | 0.0 |  |  | $ | 1.8 |  |  | $ | 0.0 |  |

[0001193125-12-487586:notes:71]
Level 2 investments are held by a custodian who prices some of
the investments itself using standard inputs in various asset price
models or obtains investment prices from a third-party pricing
provider that incorporates standard inputs in various asset price
models. We review Level 2 inputs and fair value for reasonableness
and the values may be further validated by comparison to multiple
independent pricing sources. In addition, we review third-party
pricing provider models, key inputs and assumptions and understand
the pricing processes at our third-party providers in determining
the overall reasonableness of the fair value of our Level 2
financial instruments. As of October 26, 2012 and
April 27, 2012, we have not made any adjustments to the prices
obtained from our third-party pricing providers.

[0001193125-12-487586:notes:72]
The unrealized losses on our available-for-sale investments
were caused by market value declines as a result of the
economic environment, as well as fluctuations in market interest
rates. Because the decline in market value is attributable to
changes in market conditions and not credit quality, and because we
have concluded currently that we neither intend to sell nor is it
more likely than not that we will be required to sell these
investments prior to a recovery of par value, we do not consider
these investments to be other-than temporarily impaired as of
October 26, 2012.

[0001193125-12-487586:notes:73]
[same as prior period, unchanged from 0001193125-12-375807:notes:74]

[0001193125-12-487586:notes:74]
|  |  | Fair Value at October 26, 2012 |  |  | Valuation Techniques |  | Unobservable Inputs |  | Range (Weighted average) |
| ARS |  | $ | 46.5 |  |  | Discounted cash flow |  | Time-to-economic maturity |  | 6.7 yrs – 13.7 yrs (9.2 yrs) |
|  |  |  |  |  |  |  |  | Liquidity risk premium, market credit spread and other factors |  | 1.8% - 2.4% (2.0%) |
|  |  |  |  |  |  |  |  | Coupon rate |  | 0.0% - 2.7% (1.4%) |
|  |  |  |  |  |  | Market comparable securities |  | Discount rate |  | 4.7% - 15.0% (9.0%) |

[0001193125-12-487586:notes:75]
All of our auction rate securities (ARS) are classified as
other non-current assets and are backed by pools of student loans
guaranteed by the U.S. Department of Education. We estimate the
fair value of each individual ARS using an income (discounted cash
flow) and market approach that incorporate both observable and
unobservable inputs. Key inputs into the discounted cash flow
analysis include the time-to-economic maturity, liquidity risk
premium, market credit spread and other factors and a coupon rate.
The key input into the market approach is a discount rate. A
significant increase (decrease) in the time-to-economic maturity,
liquidity risk premium, market credit spread and other factors,
coupon rate or discount rate could result in a significantly lower
(higher) fair value estimate. We review the fair value of our Level
3 financial instruments for overall reasonableness by reviewing
service provider pricing methodologies, key inputs and assumptions
and by understanding the processes used by our third-party service
providers. We will continue to monitor our ARS investments in light
of the debt market environment and evaluate these investments for
impairment and classification.

[0001193125-12-487586:notes:76]
The table below provides a reconciliation of the beginning and
ending balance of our Level 3 ARS measured at fair value on a
recurring basis using significant unobservable inputs (in
millions):

[0001193125-12-487586:notes:77]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Balance at beginning of period |  | $ | 46.3 |  |  | $ | 56.3 |  |  | $ | 51.0 |  |  | $ | 65.1 |  |
| Total unrealized gains, net included in other comprehensive income (loss) |  |  | 0.2 |  |  |  | 0.4 |  |  |  | 0.5 |  |  |  | 1.3 |  |
| Settlements |  |  | (0.0 | ) |  |  | (0.7 | ) |  |  | (5.0 | ) |  |  | (10.4 | ) |
| Balance at end of period |  | $ | 46.5 |  |  | $ | 56.0 |  |  | $ | 46.5 |  |  | $ | 56.0 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-12-487586:notes:78]
[same as prior period, unchanged from 0001193125-12-375807:notes:79]

[0001193125-12-487586:notes:79]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Cash |  | $ | 1,275.2 |  |  | $ | 649.8 |  |
| Cash equivalents |  |  | 541.6 |  |  |  | 900.0 |  |
| Cash and cash equivalents |  | $ | 1,816.8 |  |  | $ | 1,549.8 |  |
| Inventories (in millions): |  |  |  |  |  |  |  |  |
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Purchased components |  | $ | 52.9 |  |  | $ | 30.9 |  |
| Finished goods |  |  | 160.3 |  |  |  | 130.6 |  |
| Inventories |  | $ | 213.2 |  |  | $ | 161.5 |  |
| Other current assets (in millions): |  |  |  |  |  |  |  |  |
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Deferred tax assets |  | $ | 248.4 |  |  | $ | 201.6 |  |
| Prepaid expenses and other current assets |  |  | 233.5 |  |  |  | 225.4 |  |
| Short-term restricted cash |  |  | 6.6 |  |  |  | 8.6 |  |
| Other current assets |  | $ | 488.5 |  |  | $ | 435.6 |  |
| Property and equipment, net (in millions): |  |  |  |  |  |  |  |  |
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Land |  | $ | 247.6 |  |  | $ | 247.6 |  |
| Buildings and building improvements |  |  | 447.6 |  |  |  | 417.9 |  |
| Leasehold improvements |  |  | 104.5 |  |  |  | 96.5 |  |
| Computer, production, engineering and other equipment |  |  | 695.9 |  |  |  | 638.1 |  |
| Software |  |  | 390.4 |  |  |  | 381.6 |  |
| Furniture and fixtures |  |  | 80.7 |  |  |  | 71.7 |  |
| Construction-in-progress |  |  | 99.9 |  |  |  | 107.1 |  |
|  |  |  | 2,066.6 |  |  |  | 1,960.5 |  |
| Accumulated depreciation and amortization |  |  | (934.2 | ) |  |  | (823.3 | ) |
| Property and equipment, net |  | $ | 1,132.4 |  |  | $ | 1,137.2 |  |

[0001193125-12-487586:notes:80]
[same as prior period, unchanged from 0001193125-12-375807:notes:86]

[0001193125-12-487586:notes:81]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Computer software |  | $ | 132.5 |  |  | $ | 160.1 |  |

[0001193125-12-487586:notes:82]
[same as prior period, unchanged from 0001193125-12-375807:notes:88]

[0001193125-12-487586:notes:83]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Auction rate securities |  | $ | 46.5 |  |  | $ | 51.0 |  |
| Restricted cash |  |  | 2.5 |  |  |  | 2.6 |  |
| Deferred tax assets |  |  | 190.3 |  |  |  | 203.8 |  |
| Other assets |  |  | 196.2 |  |  |  | 170.0 |  |
| Other non-current assets |  | $ | 435.5 |  |  | $ | 427.4 |  |

[0001193125-12-487586:notes:84]
[same as prior period, unchanged from 0001193125-12-375807:notes:90]

[0001193125-12-487586:notes:85]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Product |  | $ | 18.6 |  |  | $ | 25.7 |  |
| SEM and service |  |  | 2,751.6 |  |  |  | 2,790.2 |  |
| Total |  | $ | 2,770.2 |  |  | $ | 2,815.9 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,408.5 |  |  | $ | 1,366.5 |  |
| Long-term |  |  | 1,361.7 |  |  |  | 1,449.4 |  |
| Total |  | $ | 2,770.2 |  |  | $ | 2,815.9 |  |

[0001193125-12-487586:notes:86]
[same as prior period, unchanged from 0001193125-12-375807:notes:92]

[0001193125-12-487586:notes:87]
[same as prior period, unchanged from 0001193125-12-375807:notes:93]

[0001193125-12-487586:notes:88]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Accumulated foreign currency translation adjustments |  | $ | 3.3 |  |  | $ | 4.9 |  |
| Accumulated defined benefit obligation adjustments |  |  | (4.2 | ) |  |  | (4.4 | ) |
| Accumulated unrealized gains on available-for-sale securities |  |  | 10.6 |  |  |  | 4.9 |  |
| Accumulated unrealized losses on derivatives instruments |  |  | (1.5 | ) |  |  | (0.5 | ) |
| Total accumulated other comprehensive income |  | $ | 8.2 |  |  | $ | 4.9 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001193125-12-487586:notes:89]
The following customers accounted for 10% or more of net
accounts receivable:

[0001193125-12-487586:notes:90]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Arrow Electronics, Inc. |  |  | 11 | % |  |  | N/A |  |
| Avnet, Inc. |  |  | 11 | % |  |  | 11 | % |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-12-487586:notes:91]
[same as prior period, unchanged from 0001193125-12-375807:notes:95]

[0001193125-12-487586:notes:92]
Other intangible assets, net consist of acquisition-related
finite-lived intangibles, as summarized below (in
millions):

[0001193125-12-487586:notes:93]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
|  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Other Intangible Assets, Net |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Other Intangible Assets, Net |  |
| Developed technology |  | $ | 282.1 |  |  | $ | (106.9 | ) |  | $ | 175.2 |  |  | $ | 282.1 |  |  | $ | (79.0 | ) |  | $ | 203.1 |  |
| Customer contracts/relationships |  |  | 54.6 |  |  |  | (40.5 | ) |  |  | 14.1 |  |  |  | 59.4 |  |  |  | (32.7 | ) |  |  | 26.7 |  |
| Trademarks and trade names |  |  | 9.9 |  |  |  | (6.9 | ) |  |  | 3.0 |  |  |  | 14.7 |  |  |  | (9.7 | ) |  |  | 5.0 |  |
| Covenants not to compete |  |  | 2.2 |  |  |  | (1.4 | ) |  |  | 0.8 |  |  |  | 2.2 |  |  |  | (1.0 | ) |  |  | 1.2 |  |
| Total other intangible assets |  | $ | 348.8 |  |  | $ | (155.7 | ) |  | $ | 193.1 |  |  | $ | 358.4 |  |  | $ | (122.4 | ) |  | $ | 236.0 |  |

[0001193125-12-487586:notes:94]
[same as prior period, unchanged from 0001193125-12-375807:notes:98]

[0001193125-12-487586:notes:95]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Statements of Operations |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | Classifications |
| Developed technology |  | $ | 14.0 |  |  | $ | 14.0 |  |  | $ | 27.9 |  |  | $ | 27.9 |  |  | Cost of product revenues |
| Customer contracts/relationships |  |  | 6.3 |  |  |  | 6.4 |  |  |  | 12.6 |  |  |  | 15.4 |  |  | Sales and marketing |
| Trademarks and trade names |  |  | 1.0 |  |  |  | 1.1 |  |  |  | 2.0 |  |  |  | 2.3 |  |  | Sales and marketing |
| Covenants not to compete |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.4 |  |  |  | 0.4 |  |  | Sales and marketing |
|  |  | $ | 21.5 |  |  | $ | 21.7 |  |  | $ | 42.9 |  |  | $ | 46.0 |  |  |  |

[0001193125-12-487586:notes:96]
As of October 26, 2012, future amortization expense
related to finite-lived intangible assets is as follows (in
millions):

[0001193125-12-487586:notes:97]
| Fiscal Year |  | Amount |  |
| Remainder of 2013 |  | $ | 41.3 |  |
| 2014 |  |  | 52.0 |  |
| 2015 |  |  | 50.6 |  |
| 2016 |  |  | 46.9 |  |
| 2017 |  |  | 2.3 |  |
| Total |  | $ | 193.1 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001193125-12-487586:notes:98]
[same as prior period, unchanged from 0001193125-12-375807:notes:102]

[0001193125-12-487586:notes:99]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Americas (United States, Canada and Latin America) |  | $ | 897.3 |  |  | $ | 897.1 |  |  | $ | 1,698.4 |  |  | $ | 1,710.5 |  |
| Europe, Middle East and Africa |  |  | 437.7 |  |  |  | 428.9 |  |  |  | 877.0 |  |  |  | 885.6 |  |
| Asia Pacific and Japan |  |  | 206.2 |  |  |  | 181.0 |  |  |  | 410.4 |  |  |  | 369.1 |  |
| Net revenues |  | $ | 1,541.2 |  |  | $ | 1,507.0 |  |  | $ | 2,985.8 |  |  | $ | 2,965.2 |  |


## us-gaap:SubsequentEventsTextBlock

[0001193125-12-487586:notes:100]
16. Subsequent
Event

[0001193125-12-487586:notes:101]
On November 14, 2012, we completed the acquisition of
CacheIQ, Inc., a privately held storage solutions company based in
Austin, Texas, for approximately $90.0 million in cash. This
acquisition provides us with intellectual property that extends our
capabilities to support non-disruptive operations for enterprise
data center environments. We will integrate this intellectual
property into our product offerings over time. Through
October 26, 2012, acquisition-related expenses associated with
the transaction were immaterial. We are in the process of
completing the purchase price allocation for this
acquisition. Pro forma results of operations have not been
presented because the acquisition was not material to our results
of operations.


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001193125-12-487586:notes:102]
[same as prior period, unchanged from 0001193125-12-375807:notes:105]

[0001193125-12-487586:notes:103]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Euro |  | $ | 142.4 |  |  | $ | 96.9 |  |
| British Pound Sterling |  |  | 39.6 |  |  |  | 29.8 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Euro |  |  | 179.0 |  |  |  | 267.4 |  |
| British Pound Sterling |  |  | 76.2 |  |  |  | 86.4 |  |
| Australian Dollar |  |  | 95.4 |  |  |  | 38.5 |  |
| Canadian Dollar |  |  | 30.4 |  |  |  | 54.3 |  |
| Swiss Franc |  |  | 24.8 |  |  |  | 7.3 |  |
| Israeli Shekel |  |  | 24.4 |  |  |  | 17.2 |  |
| Other |  |  | 45.1 |  |  |  | 44.0 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-12-487586:notes:104]
The following customers, each of which is a distributor,
accounted for 10% or more of our net revenues:

[0001193125-12-487586:notes:105]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Arrow Electronics, Inc. |  |  | 20 | % |  |  | 18 | % |  |  | 18 | % |  |  | 16 | % |
| Avnet, Inc. |  |  | 15 | % |  |  | 13 | % |  |  | 14 | % |  |  | 12 | % |


## us-gaap:ScheduleOfCashFlowHedgesIncludedInAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-12-487586:notes:106]
[same as prior period, unchanged from 0001193125-12-375807:notes:109]

[0001193125-12-487586:notes:107]
|  |  | Three Months Ended October 26, 2012 |  |  | Three Months Ended October 28, 2011 |  |
| Derivatives in Cash Flow Hedging Relationships |  | Loss Recognized in AOCI |  |  | Loss Reclassified from AOCI into Income |  |  | Gain Recognized in AOCI |  |  | Gain Reclassified from AOCI into Income |  |
| Foreign exchange forward purchase contracts |  | $ | 5.5 |  |  | $ | 2.6 |  |  | $ | 5.9 |  |  | $ | 5.8 |  |

[0001193125-12-487586:notes:108]
|  |  | Six Months Ended October 26, 2012 |  |  | Six Months Ended October 28, 2011 |  |
| Derivatives in Cash Flow Hedging Relationships |  | Gain Recognized in AOCI |  |  | Gain Reclassified from AOCI into Income |  |  | Gain Recognized in AOCI |  |  | Gain Reclassified from AOCI into Income |  |
| Foreign exchange forward purchase contracts |  | $ | 0.9 |  |  | $ | 1.9 |  |  | $ | 10.3 |  |  | $ | 7.6 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001193125-12-487586:notes:109]
[same as prior period, unchanged from 0001193125-12-375807:notes:111]

[0001193125-12-487586:notes:110]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Beginning balance |  | $ | 96.5 |  |  | $ | 59.5 |  |  | $ | 83.1 |  |  | $ | 40.5 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 17.5 |  |
| Expense accrued during the period |  |  | 27.1 |  |  |  | 15.7 |  |  |  | 50.8 |  |  |  | 27.4 |  |
| Warranty costs incurred |  |  | (11.8 | ) |  |  | (10.2 | ) |  |  | (22.1 | ) |  |  | (20.4 | ) |
| Ending balance |  | $ | 111.8 |  |  | $ | 65.0 |  |  | $ | 111.8 |  |  | $ | 65.0 |  |


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-12-487586:notes:111]
The
effect of derivative instruments not designated as hedges
recognized in other income (expense), net on our condensed
consolidated statements of operations was as follows (in
millions):

[0001193125-12-487586:notes:112]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Derivatives Not Designated as Hedging Instruments |  | Gain (Loss) Recognized into Income |  |  | Gain Recognized into Income |  |
| Foreign exchange forward purchase contracts |  | $ | (9.7 | ) |  | $ | 7.9 |  |  | $ | 6.2 |  |  | $ | 14.1 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-487586:notes:113]
[same as prior period, unchanged from 0001193125-12-375807:notes:115]

[0001193125-12-487586:notes:114]
[same as prior period, unchanged from 0001193125-12-375807:notes:116]

[0001193125-12-487586:notes:115]
|  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Effective tax rates |  |  | 14.1 | % |  |  | 13.1 | % |

[0001193125-12-487586:notes:116]
Our effective tax rates reflect the impact of a significant
amount of our earnings being taxed in foreign jurisdictions at
rates below the U.S. statutory tax rate. As of October 26,
2012, we had $165.3 million of unrecognized tax benefits, of which
$109.7 million has been recorded in other long-term liabilities and
$98.3 million, including penalties and interest, would affect our
provision for income taxes if recognized.

[0001193125-12-487586:notes:117]
On March 26, 2012, we received a Revenue Agent’s
Report from the IRS for our fiscal 2005 through 2007 income tax
returns. On April 25, 2012, we filed a protest related to
transfer pricing matters comparable to similar matters that were
resolved in our favor in our last audit cycle. In September 2012,
we reached a tentative agreement with the IRS field examination
team on the transfer pricing matters under appeals. The IRS field
examination team is currently in the process of revising the
Revenue Agent’s Report for our fiscal 2005 through 2007
income tax returns. This report will be reviewed by certain higher
authorities within the IRS and Joint Committee of Taxation. In
February 2012, the IRS commenced an examination of our fiscal 2008
through 2010 income tax returns. We are also under audit by the
California Franchise Tax Board for our fiscal 2007 and 2008
California income tax returns. Our open years in U.S. federal
jurisdictions are fiscal 2005 and later years. In addition, we are
effectively subject to federal tax examination adjustments for tax
years ended on or after fiscal year 2000, in that we have tax
attribute carryforwards from these years that could be subject to
adjustments, if and when utilized.

[0001193125-12-487586:notes:118]
[same as prior period, unchanged from 0001193125-12-375807:notes:120]

[0001193125-12-487586:notes:119]
We are in various stages of the examination and appeals process
in connection with tax audits worldwide, and it is difficult to
determine when these examinations will be settled. It is reasonably
possible that over the next twelve-month period, we may experience
an increase or decrease in unrecognized tax benefits. It is not
possible to determine either the magnitude or the range of any
increase or decrease at this time.

[0001193125-12-487586:notes:120]
In April 2010, our Dutch subsidiary received a favorable tax
ruling from the Dutch tax authorities effective May 1, 2010
that replaces the previous Dutch tax ruling that expired on
April 30, 2010. This ruling results in both a lower level of
earnings subject to tax in the Netherlands and an extension of the
expiration date to April 30, 2015.


## us-gaap:DebtDisclosureTextBlock

[0001193125-12-487586:notes:121]
9.  Financing
Arrangements

[0001193125-12-487586:notes:122]
1.75% Convertible Senior Notes due
2013

[0001193125-12-487586:notes:123]
On June 10, 2008, we issued $1,265.0 million
aggregate principal amount of 1.75% Convertible Senior Notes
due 2013 (the Notes). The Notes are unsecured, unsubordinated
obligations of the Company, which pay interest in cash
semi-annually at a rate of 1.75% per annum. The Notes will
mature on June 1, 2013 unless earlier repurchased or converted
in accordance with their terms prior to such date. The Notes may be
converted, under the conditions specified below, based on an
initial conversion rate of 31.40 shares of common stock per
$1,000 principal amount of Notes (which represents an initial
effective conversion price of the Notes of $31.85 per share),
subject to adjustment as described in the indenture governing the
Notes.

[0001193125-12-487586:notes:124]
The Notes are not redeemable by us prior to the maturity date.
In the event of a fundamental change (as defined in the indenture
for the Notes), holders of the Notes may require us to repurchase
all or a portion of their Notes at a repurchase price equal to 100%
of the principal amount of the Notes plus accrued and unpaid
interest, if any, to, but excluding, the fundamental change
repurchase date.

[0001193125-12-487586:notes:125]
The holders of the Notes may convert their Notes until the
close of business on the scheduled trading day immediately
preceding the maturity date if any of the following conditions are
met: (1) during the five business day period after any five
consecutive trading day period (the measurement period) in which
the trading price of the Notes for each day in the measurement
period was less than 98% of an amount equal to (i) the last
reported sale price of our common stock multiplied by (ii) the
conversion rate for the Notes on each such day; (2) during any
calendar quarter (and only during such calendar quarter) if the
last reported sale price of our common stock for 20 or more trading
days in a period of 30 consecutive trading days ending on the last
trading day of the immediately preceding calendar quarter exceeds
130% of the applicable conversion price in effect for the Notes on
the last trading day of such immediately preceding calendar
quarter; or (3) upon the occurrence of specified corporate
transactions set forth in the indenture for the Notes. On or after
March 1, 2013, until the scheduled trading day immediately
preceding the maturity date, holders of the Notes may convert their
Notes regardless of the foregoing conditions. Upon conversion, a
holder will receive cash in an amount equal to the lesser of the
conversion value and the principal amount of the Notes, and shares
of our common stock for any conversion value in excess of the
principal amount of the Notes, if any. Holders of the Notes who
convert their Notes in connection with a fundamental change will,
under certain circumstances, be entitled to a make-whole premium in
the form of an increase in the conversion rate.

[0001193125-12-487586:notes:126]
Our common stock price did not exceed the conversion threshold
price of $41.41 per share set forth for the Notes for at least 20
trading days during the 30 consecutive trading days ended
September 30, 2012, and accordingly, as of October 26,
2012, the Notes were not convertible at the option of the holder.
Since the Notes were not convertible, the difference between the
principal amount and the carrying value of the Notes was reflected
as equity on our condensed consolidated balance sheet as of
October 26, 2012.

[0001193125-12-487586:notes:127]
The determination of whether or not the Notes are convertible
must continue to be performed quarterly. Consequently, if the
conversion threshold is exceeded during the quarter ending
January 25, 2013, the Notes will become unconditionally
convertible at that time. At such time that the Notes become
convertible at the option of the holder, the difference between the
principal amount and the carrying value of the Notes would be
reflected as convertible debt in mezzanine on our condensed
consolidated balance sheets.

[0001193125-12-487586:notes:128]
Upon conversion of the Notes, we deliver cash up to the
principal amount of the Notes and, with respect to any excess
conversion value greater than the principal amount of the Notes,
shares of our common stock. As of October 26, 2012, shares
issued related to the Notes were minimal. Based on the closing
price of our common stock of $27.88 on October 26, 2012, the
if-converted value of our Notes was below their principal
amount.

[0001193125-12-487586:notes:129]
We separately account for the liability and equity components
of the Notes. The initial debt component of the Notes was valued at
$1,017.0 million based on the contractual cash flows
discounted at an appropriate comparable market non-convertible debt
borrowing rate at the date of issuance of 6.31%, with the equity
component representing the residual amount of the proceeds of
$248.0 million which was recorded as a debt discount. Issuance
costs were allocated pro-rata based on the relative initial
carrying amounts of the debt and equity components. As a result,
$5.2 million of the issuance costs was allocated to the equity
component of the Notes, and $21.4 million of the issuance
costs remained classified as other non-current assets. The debt
discount and the issuance costs allocated to the debt component are
amortized as additional interest expense over the term of the Notes
using the effective interest method and an effective interest rate
of 6.31% for all periods presented.

[0001193125-12-487586:notes:130]
The following table reflects the carrying value of the Notes
(in millions):

[0001193125-12-487586:notes:131]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| 1.75% Convertible Senior Notes due 2013 |  | $ | 1,264.9 |  |  | $ | 1,264.9 |  |
| Less: Unamortized discount |  |  | (35.5 | ) |  |  | (62.6 | ) |
| Net carrying amount of Notes |  | $ | 1,229.4 |  |  | $ | 1,202.3 |  |

[0001193125-12-487586:notes:132]
The following table presents the amount of interest expense
recognized related to the Notes (in millions):

[0001193125-12-487586:notes:133]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 26, 2012 |  |  | October 28, 2011 |  |  | October 26, 2012 |  |  | October 28, 2011 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 11.0 |  |  | $ | 11.0 |  |
| Amortization of debt discount |  |  | 13.6 |  |  |  | 12.8 |  |  |  | 27.1 |  |  |  | 25.4 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 1.1 |  |  |  | 2.4 |  |  |  | 2.2 |  |
| Less capitalized interest |  |  | (0.6 | ) |  |  | (3.5 | ) |  |  | (1.1 | ) |  |  | (3.5 | ) |
| Total interest expense related to Notes |  | $ | 19.7 |  |  | $ | 15.9 |  |  | $ | 39.4 |  |  | $ | 35.1 |  |

[0001193125-12-487586:notes:134]
The following table reflects the remaining debt discount and
issuance costs as of October 26, 2012 (in
millions):

[0001193125-12-487586:notes:135]
| Remaining debt discount |  | $ | 35.5 |  |
| Remaining issuance costs |  |  | 3.0 |  |
| Remaining life of the Notes (years) |  |  | 0.6 |  |

[0001193125-12-487586:notes:136]
Note
Hedges and Warrants

[0001193125-12-487586:notes:137]
Concurrent with the issuance of the Notes, we purchased Note
hedges and sold warrants. The separate Note hedge and warrant
transactions are structured to reduce the potential future economic
dilution associated with the conversion of the Notes.

[0001193125-12-487586:notes:138]
• Note Hedges: As of October 26, 2012 and
April 27, 2012, we had arrangements with counterparties to buy
up to approximately 31.8 million shares of our common stock,
subject to anti-dilution adjustments, at a price of $31.85 per
share, subject to adjustment. The Note hedge transactions will
expire at the earlier of (1) the last day on which any Notes
remain outstanding or (2) the scheduled trading day
immediately preceding the maturity date of the Notes. Upon exercise
of the Note hedges, we have the option to receive cash or shares of
our common stock equal to the difference between the then market
price and the strike price of the hedges.

[0001193125-12-487586:notes:139]
• Warrants: As of October 26, 2012 and
April 27, 2012, we had outstanding warrants for others to
acquire, subject to anti-dilution adjustments, 39.7 million
shares of our common stock at an exercise price of $41.28 per
share, subject to adjustment, on a series of days commencing on
September 3, 2013. Upon exercise of the warrants, we have the
option to deliver cash or shares of our common stock equal to the
difference between the then market price and the strike price of
the warrants.

[0001193125-12-487586:notes:140]
As of October 26, 2012, we were subject to potential
dilution on the approximately 20% unhedged portion of our Notes
upon conversion, if on the date of conversion, the per-share market
price of our common stock exceeds the conversion price of
$31.85.

[0001193125-12-487586:notes:141]
As of October 26, 2012, we received a minimal number of
shares related to the Note hedge transactions and no cash or shares
were delivered related to the warrant transactions.

[0001193125-12-487586:notes:142]
Fair
Value of Notes

[0001193125-12-487586:notes:143]
As of October 26, 2012, the fair value of the principal
amount of the Notes, which includes the debt and equity components,
was approximately $1,340.2 million, or 106.0% of the face value of
the Notes, based upon quoted market information provided by
third-party pricing providers (Level 1).

[0001193125-12-487586:notes:144]
Other
Long-Term Financing Arrangements

[0001193125-12-487586:notes:145]
The following presents the amounts due under other long-term
financing arrangements (in millions):

[0001193125-12-487586:notes:146]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Current portion of other long-term financing arrangements |  | $ | 6.0 |  |  | $ | 9.1 |  |
| Non-current portion of other long-term financing arrangements |  |  | 6.3 |  |  |  | 3.5 |  |
| Total |  | $ | 12.3 |  |  | $ | 12.6 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-487586:notes:147]
15.  Commitments and Contingencies

[0001193125-12-487586:notes:148]
Lease
Commitments

[0001193125-12-487586:notes:149]
As of October 26, 2012, future annual minimum lease
payments under all non-cancelable facilities and equipment
operating leases with an initial term in excess of one year totaled
$334.6 million.

[0001193125-12-487586:notes:150]
As of October 26, 2012, we have three leasing arrangements
with BNP Paribas LLC (BNPPLC), one of which require us to lease
certain of our land to BNPPLC for a period of 99 years and all
of which require us to lease approximately 0.3 million square
feet of office space from BNPPLC for our headquarters in Sunnyvale,
California, which had an original cost of $69.6 million. Under
these leasing arrangements, we pay BNPPLC minimum lease payments,
which vary based on a fixed rate on the costs of the facilities on
the respective lease commencement dates. We make payments for each
of the leases for a term of five years. We have the option to renew
each of the leases for two consecutive five-year periods upon
approval by BNPPLC. The initial lease terms expire in December 2012
and January 2013. Upon expiration (or upon any earlier termination)
of the lease terms, we must elect one of the following options:
(i) purchase the buildings from BNPPLC at cost; (ii) if
certain conditions are met, arrange for the sale of the buildings
by BNPPLC to a third-party, and be liable for any deficiency
between the net proceeds received from the third-party and
BNPPLC’s cost, up to 85% of cost (residual guarantee); or
(iii) pay BNPPLC supplemental payments for an amount equal to
the difference between BNPPLC’s cost and fair value, up to
the residual guarantee, in which event we may recoup some or all of
such payments by arranging for a sale of each or all buildings by
BNPPLC during the ensuing two-year period.

[0001193125-12-487586:notes:151]
These leases require us to maintain specified financial
covenants with which we were in compliance as of October 26,
2012. Such financial covenants include a maximum ratio of Total
Debt to Earnings before Interest, Taxes, Depreciation and
Amortization of less than 3:1 and a minimum amount of Unencumbered
Cash and Short-Term Investments of $300.0 million.

[0001193125-12-487586:notes:152]
Purchase
Orders and Other Commitments

[0001193125-12-487586:notes:153]
In the normal course of business we make commitments to our
third-party contract manufacturers, to manage manufacturer lead
times and meet product forecasts, and to other parties, to purchase
various key components used in the manufacture of our products. We
establish accruals for estimated losses on purchased components to
the extent we believe it is probable that such components will not
be utilized in future operations. To the extent that such forecasts
are not achieved, our commitments and associated accruals may
change. As of October 26, 2012, we had $266.7 million in
non-cancelable purchase commitments with our contract
manufacturers. In addition, we recorded a liability for firm,
non-cancelable and unconditional purchase commitments with contract
manufacturers for quantities in excess of our future demand
forecasts through a charge to cost of product sales. As of
October 26, 2012 and April 27, 2012, such liability
amounted to $8.5 million and $3.3 million, respectively, and is
included in other current liabilities in the condensed consolidated
balance sheets.

[0001193125-12-487586:notes:154]
In addition to commitments with contract manufacturers and
component suppliers, we have open purchase orders and contractual
obligations associated with our ordinary course business for which
we have not received goods or services. As of October 26,
2012, we had $41.5 million in capital purchase commitments and
$190.1 million in other purchase commitments.

[0001193125-12-487586:notes:155]
Product
Warranties

[0001193125-12-487586:notes:156]
We provide customers a warranty on software of ninety days to
five years and a warranty on hardware of one to five years. The
following table summarizes our warranty reserves (in
millions):

[0001193125-12-487586:notes:157]
Financing
Guarantees

[0001193125-12-487586:notes:158]
Some of our customers have entered into recourse and
non-recourse financing leasing arrangements using third-party
financing companies, and in some situations, we enter into customer
financing arrangements for our products and services that are
contemporaneously sold on a recourse or non-recourse basis to
third-party financing companies. Under the terms of recourse
leases, which are generally three years or less, we remain liable
for the aggregate unpaid remaining lease payments to the
third-party leasing companies in the event of end-user customer
default. These arrangements are generally collateralized by a
security interest in the underlying assets. Under the terms of the
nonrecourse leases, we do not have any continuing obligations or
liabilities to the third-party financing companies. Where we
provide a guarantee for recourse leases, we defer revenues subject
to the industry-specific software revenue recognition guidance, and
recognize revenues for non-software deliverables in accordance with
our multiple deliverable revenue arrangement policy.

[0001193125-12-487586:notes:159]
The aggregate amount of financing guarantees representing the
total maximum potential future payments under financing
arrangements with third parties, and the related deferred revenue
are summarized as follows (in millions):

[0001193125-12-487586:notes:160]
|  |  | October 26, 2012 |  |  | April 27, 2012 |  |
| Maximum guaranteed payment contingencies |  | $ | 170.8 |  |  | $ | 169.0 |  |
| Deferred revenue associated with financing guarantees |  |  | (154.5 | ) |  |  | (149.9 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 16.3 |  |  | $ | 19.1 |  |

[0001193125-12-487586:notes:161]
To date, we have not experienced material losses under our
lease financing programs or other financing
arrangements.

[0001193125-12-487586:notes:162]
Legal
Contingencies

[0001193125-12-487586:notes:163]
When a loss is considered probable and reasonably estimable, we
record a liability in the amount of our best estimate for the
ultimate loss. However, the likelihood of a loss with respect to a
particular contingency is often difficult to predict and
determining a meaningful estimate of the loss or a range of loss
may not be practicable based on the information available and the
potential effect of future events and decisions by third parties
that will determine the ultimate resolution of the
contingency.

[0001193125-12-487586:notes:164]
We are subject to various legal proceedings and claims that
arise in the normal course of business. No material accrual has
been recorded as of October 26, 2012 related to such
matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-487586:notes:165]
[same as prior period, unchanged from 0001193125-12-375807:notes:167]

[0001193125-12-487586:notes:166]
[same as prior period, unchanged from 0001193125-12-375807:notes:168]

[0001193125-12-487586:notes:167]
Americas revenues consist of Americas commercial and U.S.
public sector markets. Sales to customers inside the United States
accounted for $797.6 million and $770.4 million of Americas net
revenues during the three months ended October 26, 2012 and
October 28, 2011, respectively, and $1,509.0 million and
$1,459.7 million of Americas net revenues during the six months
ended October 26, 2012 and October 28, 2011,
respectively. No single foreign country accounted for 10% or more
of net revenues in any of the periods presented.

[0001193125-12-487586:notes:168]
[same as prior period, unchanged from 0001193125-12-375807:notes:169]

[0001193125-12-487586:notes:169]
With the exception of property and equipment, we do not
identify or allocate our long-lived assets by geographic area. The
following table presents property and equipment information for
geographic areas based on the physical location of the assets (in
millions):

[0001193125-12-487586:notes:170]
N/A - Not
Applicable


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-12-487586:notes:171]
[same as prior period, unchanged from 0001193125-12-375807:notes:176]

[0001193125-12-487586:notes:172]
[same as prior period, unchanged from 0001193125-12-375807:notes:177]

[0001193125-12-487586:notes:173]
The fair value of our short-term foreign currency contracts was
not material as of October 26, 2012 and April 27, 2012.
We did not recognize any gains and losses in earnings due to hedge
ineffectiveness for any period presented.

[0001193125-12-487586:notes:174]
The effect of derivative instruments not designated as hedges
recognized in other income (expense), net on our condensed
consolidated statements of operations was as follows (in
millions):


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-12-487586:notes:175]
[same as prior period, unchanged from 0001193125-12-375807:notes:179]

[0001193125-12-487586:notes:176]
There have been no significant changes in our significant
accounting policies as of and for the six months ended
October 26, 2012, as compared to the significant accounting
policies described in our Annual Report on Form 10-K for the fiscal
year ended April 27, 2012.

[0001193125-12-487586:notes:177]
[same as prior period, unchanged from 0001193125-12-375807:notes:181]

[0001193125-12-487586:notes:178]
In September 2011, the Financial Accounting Standards
Board (FASB) issued a revised accounting standard intended to
simplify how an entity tests goodwill for impairment. The revised
standard will allow an entity to first assess qualitative factors
to determine whether it is necessary to perform the two-step
quantitative goodwill impairment test. An entity will no longer be
required to calculate the fair value of a reporting unit unless it
determines, based on a qualitative assessment, that it is more
likely than not that its fair value is less than its carrying
amount. This guidance is effective for us beginning in our fourth
quarter of fiscal 2013. We do not expect this guidance to have a
material impact on our consolidated financial
statements.

[0001193125-12-487586:notes:179]
In December 2011, the FASB issued new guidance that will
require us to disclose information about offsetting arrangements
associated with financial and derivative instruments to enable
users of our financial statements to understand the effect of those
arrangements on our financial position. This guidance is effective
for us beginning in our first quarter of fiscal 2014, at which time
we will include the applicable disclosures required by this
accounting standard update. Other than requiring additional
disclosures related to offsetting arrangements, we do not
anticipate material impacts on our financial statements upon
adoption.

[0001193125-12-487586:notes:180]
[same as prior period, unchanged from 0001193125-12-375807:notes:184]

[0001193125-12-487586:notes:181]
The preparation of the condensed consolidated financial
statements in conformity with GAAP requires management to make
estimates and assumptions that affect the reported amounts of
assets and liabilities and disclosure of contingent assets and
liabilities at the date of the financial statements and the
reported amounts of revenues and expenses during the reporting
periods. Such estimates include, but are not limited to, revenue
recognition, reserves and allowances; inventory valuation and
purchase order accruals; valuation of goodwill and intangibles;
restructuring reserves; product warranties; employee benefit
accruals; stock-based compensation; loss contingencies; investment
impairments; income taxes, and fair value measurements. Actual
results could differ materially from those estimates.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-12-487586:notes:182]
[same as prior period, unchanged from 0001193125-12-375807:notes:186]

[0001193125-12-487586:notes:183]
Fiscal Year — Our fiscal year is reported on
a 52- or 53-week year ending on the last Friday in April. The first
and second quarters of fiscal 2013 and 2012 were each 13-week
periods.

[0001193125-12-487586:notes:184]
Basis of Presentation — The accompanying unaudited
condensed consolidated financial statements have been prepared by
the Company, and reflect all adjustments, consisting only of normal
recurring adjustments, that are, in the opinion of management,
necessary for the fair presentation of our financial position,
results of operations, and cash flows for the interim periods
presented. The statements have been prepared in accordance with
accounting principles generally accepted in the United States of
America (GAAP) for interim financial information and in accordance
with the instructions to Form 10-Q and Rule 10-01 of Regulation
S-X. Accordingly, these statements do not include all information
and footnotes required by GAAP for annual consolidated financial
statements, and should be read in conjunction with our audited
consolidated financial statements as of and for the fiscal year
ended April 27, 2012 contained in our Annual Report on Form
10-K filed with the Securities and Exchange Commission on
June 19, 2012. The results of operations for the three and six
months ended October 26, 2012 are not necessarily indicative
of the operating results to be expected for the full fiscal year or
future operating periods.
