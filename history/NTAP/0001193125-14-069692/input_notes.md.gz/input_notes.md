# NTAP notes — 0001193125-14-069692


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-14-069692:notes:1]
[same as prior period, unchanged from 0001193125-13-454984:notes:1]

[0001193125-14-069692:notes:2]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Land and land improvements |  | $ | 265.7 |  |  | $ | 265.5 |  |
| Buildings and building improvements |  |  | 540.6 |  |  |  | 534.8 |  |
| Leasehold improvements |  |  | 102.3 |  |  |  | 100.3 |  |
| Computer, production, engineering and other equipment |  |  | 759.0 |  |  |  | 714.0 |  |
| Software |  |  | 429.4 |  |  |  | 422.6 |  |
| Furniture and fixtures |  |  | 86.1 |  |  |  | 82.2 |  |
| Construction-in-progress |  |  | 61.2 |  |  |  | 19.9 |  |
|  |  |  | 2,244.3 |  |  |  | 2,139.3 |  |
| Accumulated depreciation and amortization |  |  | (1,115.7 | ) |  |  | (968.4 | ) |
| Property and equipment, net |  | $ | 1,128.6 |  |  | $ | 1,170.9 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-14-069692:notes:3]
As of January 24, 2014, future amortization expense
 related to purchased intangible assets is as follows (in
 millions):

[0001193125-14-069692:notes:4]
| Fiscal Year |  | Amount |  |
| Remainder of 2014 |  | $ | 14.7 |  |
| 2015 |  |  | 57.8 |  |
| 2016 |  |  | 53.6 |  |
| 2017 |  |  | 6.7 |  |
| 2018 |  |  | 3.3 |  |
| Total |  | $ | 136.1 |  |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001193125-14-069692:notes:5]
The notional amount of our outstanding U.S. dollar equivalent
 foreign currency exchange forward contracts consisted of the
 following (in millions):

[0001193125-14-069692:notes:6]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 188.8 |  |  | $ | 108.4 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  |  | 148.4 |  |  |  | 158.2 |  |
| Forward contracts purchased |  |  | 340.5 |  |  |  | 358.4 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-14-069692:notes:7]
[same as prior period, unchanged from 0001193125-13-454984:notes:7]

[0001193125-14-069692:notes:8]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Arrow Electronics, Inc.(1) |  |  | 20 | % |  |  | 18 | % |  |  | 21 | % |  |  | 19 | % |
| Avnet, Inc.(1) |  |  | 15 | % |  |  | 15 | % |  |  | 16 | % |  |  | 15 | % |

[0001193125-14-069692:notes:9]
| (1) | Net revenues for Arrow Electronics, Inc. for the nine months ended January 25, 2013 have been corrected from 18% previously disclosed to 19%. Net revenues for Avnet, Inc. for each of the three and nine months ended January 25, 2013 have been corrected from 14% previously disclosed to 15%. |


## us-gaap:ScheduleOfAntidilutiveSecuritiesExcludedFromComputationOfEarningsPerShareTextBlock

[0001193125-14-069692:notes:10]
[same as prior period, unchanged from 0001193125-13-454984:notes:10]

[0001193125-14-069692:notes:11]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Employee equity award plans |  |  | 5.7 |  |  |  | 15.0 |  |  |  | 6.5 |  |  |  | 16.4 |  |


## us-gaap:ScheduleOfOtherDerivativesNotDesignatedAsHedgingInstrumentsStatementsOfFinancialPerformanceAndFinancialPositionLocationTableTextBlock

[0001193125-14-069692:notes:12]
[same as prior period, unchanged from 0001193125-13-454984:notes:12]

[0001193125-14-069692:notes:13]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
|  |  | Gain Recognized into Income |  |  | Gain Recognized into Income |  |
| Foreign currency exchange forward contracts |  | $ | 1.0 |  |  | $ | 0.0 |  |  | $ | 1.8 |  |  | $ | 6.2 |  |


## us-gaap:ScheduleOfRecognizedIdentifiedAssetsAcquiredAndLiabilitiesAssumedTableTextBlock

[0001193125-14-069692:notes:14]
Following are the fair value of assets acquired and liabilities
 assumed as of the closing date (in millions):

[0001193125-14-069692:notes:15]
| Cash |  | $ | 0.4 |  |
| Other current assets |  |  | 4.0 |  |
| Finite-lived intangible assets |  |  | 22.0 |  |
| Goodwill |  |  | 72.9 |  |
| Other assets |  |  | 0.9 |  |
| Total assets acquired |  |  | 100.2 |  |
| Current liabilities |  |  | (0.5 | ) |
| Deferred income taxes |  |  | (8.7 | ) |
| Total purchase price |  | $ | 91.0 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-14-069692:notes:16]
9.  Financing
 Arrangements

[0001193125-14-069692:notes:17]
Long-term Debt

[0001193125-14-069692:notes:18]
The following table summarizes the carrying value of our
 long-term debt (in millions):

[0001193125-14-069692:notes:19]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
|  |  | Amount |  |  | Effective Interest Rate |  |  | Amount |  |  | Effective Interest Rate |  |
| 2.00% Senior Notes due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.25% Senior Notes due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| 1.75% Convertible Notes due 2013 |  |  | 0.0 |  |  |  | N/A |  |  |  | 1,264.9 |  |  |  | 6.31 | % |
| Total principal amount |  |  | 1,000.0 |  |  |  |  |  |  |  | 2,264.9 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (4.8 | ) |  |  |  |  |  |  | (12.5 | ) |  |  |  |  |
| Total debt |  |  | 995.2 |  |  |  |  |  |  |  | 2,252.4 |  |  |  |  |  |
| Less: Current portion |  |  | (0.0 | ) |  |  |  |  |  |  | (1,257.8 | ) |  |  |  |  |
| Total long-term portion |  | $ | 995.2 |  |  |  |  |  |  | $ | 994.6 |  |  |  |  |  |

[0001193125-14-069692:notes:20]
N/A - Not
 Applicable

[0001193125-14-069692:notes:21]
Senior Notes

[0001193125-14-069692:notes:22]
Our Senior Notes, issued in December 2012, are unsecured,
 unsubordinated obligations, which pay interest semi-annually on
 June 15 and December 15 and rank equally in right of
 payment with any future senior unsecured indebtedness. Interest
 expense associated with the Senior Notes was $6.2 million and $18.7
 million for the three and nine months ended January 24, 2014,
 respectively, and was $3.1 million for each of the three and nine
 months ended January 25, 2013.

[0001193125-14-069692:notes:23]
We may redeem the Senior Notes in whole or in part at any time
 at our option at specified redemption prices. In addition, upon the
 occurrence of certain change of control triggering events, we may
 be required to repurchase the Senior Notes at 101% of their
 aggregate principal amount, plus accrued and unpaid interest to the
 date of repurchase. The Senior Notes also include covenants that
 limit our ability to incur debt secured by liens on assets or on
 shares of stock or indebtedness of our subsidiaries; to engage in
 sale and lease-back transactions; and to consolidate, merge or sell
 all or substantially all of our assets. As of January 24,
 2014, we were in compliance with all covenants associated with the
 Senior Notes.

[0001193125-14-069692:notes:24]
1.75% Convertible Senior Notes due 2013

[0001193125-14-069692:notes:25]
On June 10, 2008, we issued $1,265.0 million
 aggregate principal amount of 1.75% Convertible Senior Notes
 (the Convertible Notes) with a maturity date of June 1, 2013.
 The Convertible Notes were unsecured, unsubordinated obligations of
 the Company and paid interest in cash semi-annually at a rate of
 1.75% per annum. Upon maturity, the Convertible Notes were
 converted into shares of common stock at a conversion rate of 31.40
 shares of common stock per $1,000 principal amount of the
 Convertible Notes (which represented the effective conversion price
 of $31.85 per share). Upon conversion in June 2013, the holders
 received cash for the principal amount of the Convertible Notes and
 an aggregate of 4.9 million shares of common stock for the
 $178.9 million excess of the conversion value over the principal
 amount.

[0001193125-14-069692:notes:26]
We separately accounted for the liability and equity components
 of the Convertible Notes. The initial debt component of the
 Convertible Notes was valued at $1,017.0 million based on the
 contractual cash flows discounted at an appropriate comparable
 market non-convertible debt borrowing rate at the date of issuance
 of 6.31%, with the equity component representing the residual
 amount of the proceeds of $248.0 million which was recorded as
 a debt discount. Issuance costs were allocated pro-rata based on
 the relative initial carrying amounts of the debt and equity
 components. As a result, $5.2 million of the issuance costs
 was allocated to the equity component of the Convertible Notes, and
 $21.4 million of the issuance costs remained classified as
 other non-current assets. The debt discount and the issuance costs
 allocated to the debt component were amortized as additional
 interest expense over the term of the Convertible Notes using the
 effective interest method.

[0001193125-14-069692:notes:27]
Convertible Note Hedges and Warrants

[0001193125-14-069692:notes:28]
Concurrent with the issuance of the Convertible Notes, we
 purchased Convertible Note hedges and sold warrants. The separate
 Convertible Note hedge and warrant transactions were structured to
 reduce the potential future economic dilution associated with the
 conversion of the Convertible Notes.

[0001193125-14-069692:notes:29]
• Convertible Note Hedges: As of April 26, 2013, we
 had arrangements with counterparties to buy up to approximately
 31.8 million shares of our common stock, at a price of $31.85
 per share. In June 2013, concurrent with the repayment and
 conversion of the Convertible Notes, we exercised the Convertible
 Note hedges that were net settled for an aggregate of
 3.9 million shares from the counterparties.

[0001193125-14-069692:notes:30]
• Warrants: As of April 26, 2013, we had outstanding
 warrants for certain counterparties to acquire 39.7 million
 shares of our common stock at an exercise price of $41.28 per
 share. The warrants were exercisable on a series of days commencing
 on September 3, 2013 and ending on October 28, 2013. The
 number of warrants and exercise price were adjusted in July 2013 to
 39.9 million and $41.12 per share, respectively, to reflect
 our July 2013 dividend. On October 17, 2013, the exercise
 price of the warrants then outstanding was further adjusted to
 $40.97 per share to reflect our October 2013 dividend. Through
 October 28, 2013, 31.9 million warrants were exercised
 and net settled with 1.1 million shares of our common stock
 equal to the difference between the market price on the date of
 exercise and the exercise price of the warrants on the respective
 exercise dates. No warrants were exercised during the three months
 ended January 24, 2014 as their exercise price exceeded the
 market value of our stock prior to their expiration during the
 quarter.

[0001193125-14-069692:notes:31]
Interest Expense on Convertible Notes

[0001193125-14-069692:notes:32]
The following table presents the amount of interest expense
 related to the Convertible Notes (in millions):

[0001193125-14-069692:notes:33]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 2.5 |  |  | $ | 16.5 |  |
| Amortization of debt discount |  |  | 13.9 |  |  |  | 7.1 |  |  |  | 41.0 |  |
| Amortization of debt issuance costs |  |  | 1.2 |  |  |  | 0.6 |  |  |  | 3.6 |  |
| Less capitalized interest |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (1.1 | ) |
| Total interest expense related to Convertible Notes |  | $ | 20.6 |  |  | $ | 10.2 |  |  | $ | 60.0 |  |

[0001193125-14-069692:notes:34]
No interest expense related to the Convertible Notes was
 recognized in the three months ended January 24, 2014 due to
 their maturity.

[0001193125-14-069692:notes:35]
Debt Maturities

[0001193125-14-069692:notes:36]
As of January 24, 2014, our aggregate future principal
 debt maturities are as follows (in millions):

[0001193125-14-069692:notes:37]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750.0 |  |
| Thereafter |  |  | 250.0 |  |
| Total |  | $ | 1,000.0 |  |

[0001193125-14-069692:notes:38]
Credit Facility

[0001193125-14-069692:notes:39]
In December 2012, we entered into a credit agreement with a
 syndicated group of lenders that provides for an unsecured $250.0
 million revolving credit facility that is comprised of revolving
 loans, Eurocurrency loans and/or swingline loans. The credit
 facility includes a $100.0 million foreign currency sub-facility, a
 $50.0 million letter of credit sub-facility and a $10.0 million
 swingline sub-facility available on same-day notice. Available
 borrowings under the credit facility are reduced by the amount of
 any outstanding borrowings on the sub-facilities. We may also,
 subject to certain requirements, request an increase in the
 facility up to an additional $100.0 million and request two
 additional one-year extensions, subject to certain conditions. The
 proceeds from the facility may be used by us for general corporate
 purposes.

[0001193125-14-069692:notes:40]
Borrowings under the facility, except for swingline loans,
 accrue interest in arrears at an alternate base rate as defined in
 the credit agreement or, at our option, an adjusted London
 Interbank Offered Rate (LIBOR) plus in each case, a spread (based
 on our public debt ratings and the type of loan) ranging from 0.2%
 to 1.2%. Swingline borrowings accrue interest at an alternate base
 rate. In addition, we are required to pay fees to maintain the
 credit facility, whether or not we have outstanding borrowings. The
 facility terminates on December 21, 2017 if no extensions have
 been requested and contains financial covenants requiring us to
 maintain a maximum leverage ratio of not more than 3.0:1.0 and a
 minimum interest coverage ratio of not less than 3.5:1.0. The
 facility contains customary affirmative and negative covenants,
 including covenants that limit our ability to incur debt secured by
 liens on assets or indebtedness of our subsidiaries and to
 consolidate, merge or sell all or substantially all of our assets.
 As of January 24, 2014, no borrowings were outstanding under
 the facility and we were in compliance with all covenants
 associated with the facility.

[0001193125-14-069692:notes:41]
Other Long-Term Financing Arrangements

[0001193125-14-069692:notes:42]
The following presents the amounts due under other long-term
 financing arrangements (in millions):

[0001193125-14-069692:notes:43]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Other long-term financing arrangements |  | $ | 14.8 |  |  | $ | 10.8 |  |
| Less: current portion |  |  | (6.9 | ) |  |  | (5.2 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 7.9 |  |  | $ | 5.6 |  |


## us-gaap:ScheduleOfShareBasedCompensationArrangementByShareBasedPaymentAwardOptionsGrantsInPeriodGrantDateIntrinsicValueTableTextBlock

[0001193125-14-069692:notes:44]
[same as prior period, unchanged from 0001193125-13-454984:notes:42]

[0001193125-14-069692:notes:45]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Weighted-average fair value per share granted |  | $ | 10.34 |  |  | $ | 20.53 |  |  | $ | 9.88 |  |  | $ | 11.54 |  |
| Intrinsic value of exercises |  | $ | 20.9 |  |  | $ | 15.0 |  |  | $ | 81.3 |  |  | $ | 30.8 |  |
| Proceeds received from exercises |  | $ | 34.5 |  |  | $ | 15.8 |  |  | $ | 147.7 |  |  | $ | 35.3 |  |
| Fair value of options vested |  | $ | 10.6 |  |  | $ | 14.5 |  |  | $ | 36.0 |  |  | $ | 44.0 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001193125-14-069692:notes:46]
[same as prior period, unchanged from 0001193125-13-454984:notes:44]

[0001193125-14-069692:notes:47]
|  |  | April 26, 2013 |  |
| Arrow Electronics, Inc. |  |  | 16 | % |
| Avnet, Inc. |  |  | 14 | % |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-14-069692:notes:48]
Changes in accumulated other comprehensive income (AOCI) by
 component, net of tax, for the nine months ended January 24,
 2014 are summarized below (in millions):

[0001193125-14-069692:notes:49]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains on Available- for-Sale Securities |  |  | Unrealized Gains on Derivative Instruments |  |  | Total |  |
| Balance as of April 26, 2013 |  | $ | 2.0 |  |  | $ | (5.7 | ) |  | $ | 11.4 |  |  | $ | 1.0 |  |  | $ | 8.7 |  |
| Other comprehensive income (loss) (OCI) before reclassifications |  |  | 0.9 |  |  |  | 0.3 |  |  |  | (1.3 | ) |  |  | (2.0 | ) |  |  | (2.1 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (1.1 | ) |  |  | 1.2 |  |  |  | 0.1 |  |
| Net OCI |  |  | 0.9 |  |  |  | 0.3 |  |  |  | (2.4 | ) |  |  | (0.8 | ) |  |  | (2.0 | ) |
| Balance as of January 24, 2014 |  | $ | 2.9 |  |  | $ | (5.4 | ) |  | $ | 9.0 |  |  | $ | 0.2 |  |  | $ | 6.7 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-14-069692:notes:50]
[same as prior period, unchanged from 0001193125-13-454984:notes:48]

[0001193125-14-069692:notes:51]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 26, 2013 |  |  | 19.2 |  |  | $ | 31.27 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2.7 |  |  |  | 38.28 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (5.7 | ) |  |  | 25.91 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (1.1 | ) |  |  | 42.04 |  |  |  |  |  |  |  |  |  |
| Outstanding as of January 24, 2014 |  |  | 15.1 |  |  |  | 33.79 |  |  |  | 3.62 |  |  | $ | 176.6 |  |
| Vested and expected to vest as of January 24, 2014 |  |  | 14.6 |  |  |  | 33.67 |  |  |  | 3.54 |  |  |  | 173.0 |  |
| Exercisable as of January 24, 2014 |  |  | 10.7 |  |  |  | 31.86 |  |  |  | 2.77 |  |  |  | 145.9 |  |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-14-069692:notes:52]
The following table summarizes our financial assets and
 liabilities measured at fair value on a recurring basis as of
 January 24, 2014 (in millions):

[0001193125-14-069692:notes:53]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,444.6 |  |  | $ | 0.0 |  |  | $ | 2,444.6 |  |  | $ | 0.0 |  |
| U.S. Treasury and government debt securities |  |  | 249.6 |  |  |  | 180.5 |  |  |  | 69.1 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 237.2 |  |  |  | 0.0 |  |  |  | 237.2 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 135.0 |  |  |  | 0.0 |  |  |  | 135.0 |  |  |  | 0.0 |  |
| Money market funds |  |  | 13.1 |  |  |  | 13.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 40.4 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 40.4 |  |
| Equity funds |  |  | 32.5 |  |  |  | 32.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Foreign currency contracts |  |  | 2.4 |  |  |  | 0.0 |  |  |  | 2.4 |  |  |  | 0.0 |  |
| Total |  | $ | 3,154.8 |  |  | $ | 226.1 |  |  | $ | 2,888.3 |  |  | $ | 40.4 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | 2.0 |  |  | $ | 0.0 |  |  | $ | 2.0 |  |  | $ | 0.0 |  |


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001193125-14-069692:notes:54]
[same as prior period, unchanged from 0001193125-13-454984:notes:52]

[0001193125-14-069692:notes:55]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | Statements of Operations Classifications |
| Developed technology |  | $ | 14.2 |  |  | $ | 13.9 |  |  | $ | 42.8 |  |  | $ | 41.8 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 0.3 |  |  |  | 6.3 |  |  |  | 1.0 |  |  |  | 18.9 |  |  | Operating expenses |
| Trademarks and trade names |  |  | 0.1 |  |  |  | 1.1 |  |  |  | 0.3 |  |  |  | 3.1 |  |  | Operating expenses |
| Covenants not to compete |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.4 |  |  |  | 0.5 |  |  | Operating expenses |
|  |  | $ | 14.7 |  |  | $ | 21.4 |  |  | $ | 44.5 |  |  | $ | 64.3 |  |  |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-14-069692:notes:56]
[same as prior period, unchanged from 0001193125-13-454984:notes:54]

[0001193125-14-069692:notes:57]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Purchased components |  | $ | 18.9 |  |  | $ | 16.3 |  |
| Finished goods |  |  | 99.3 |  |  |  | 123.2 |  |
| Inventories |  | $ | 118.2 |  |  | $ | 139.5 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-14-069692:notes:58]
The following table presents the contractual maturities of our
 debt investments as of January 24, 2014 (in
 millions):

[0001193125-14-069692:notes:59]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,155.4 |  |  | $ | 1,157.5 |  |
| Due in one through five years |  |  | 1,750.1 |  |  |  | 1,759.1 |  |
| Due after ten years* |  |  | 41.9 |  |  |  | 40.4 |  |
|  |  | $ | 2,947.4 |  |  | $ | 2,957.0 |  |

[0001193125-14-069692:notes:60]
| * | Consists of auction rate securities (ARSs) which have contractual maturities of greater than 10 years. |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-14-069692:notes:61]
11.  Derivatives and Hedging
 Activities

[0001193125-14-069692:notes:62]
[same as prior period, unchanged from 0001193125-13-454984:notes:59]

[0001193125-14-069692:notes:63]
We have master netting arrangements in place to mitigate the
 credit risk of our counterparties and to potentially reduce our
 losses due to counterparty nonperformance. We present our
 derivative instruments as net amounts in our condensed consolidated
 balance sheets. The gross and net fair value amounts of such
 instruments were not material as of January 24, 2014 and
 April 26, 2013. We did not recognize any gains and losses in
 earnings due to hedge ineffectiveness for any period
 presented.

[0001193125-14-069692:notes:64]
The effect of derivative instruments designated as cash flow
 hedges recognized in net revenues on our condensed consolidated
 statements of operations is presented in the condensed consolidated
 statements of comprehensive income and Note 10.


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001193125-14-069692:notes:65]
[same as prior period, unchanged from 0001193125-13-454984:notes:62]

[0001193125-14-069692:notes:66]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Cash |  | $ | 1,989.8 |  |  | $ | 1,634.7 |  |
| Cash equivalents |  |  | 162.9 |  |  |  | 1,642.4 |  |
| Cash and cash equivalents |  | $ | 2,152.7 |  |  | $ | 3,277.1 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001193125-14-069692:notes:67]
[same as prior period, unchanged from 0001193125-13-454984:notes:64]

[0001193125-14-069692:notes:68]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Auction rate securities |  | $ | 40.4 |  |  | $ | 42.0 |  |
| Deferred tax assets |  |  | 224.3 |  |  |  | 200.4 |  |
| Other assets |  |  | 253.7 |  |  |  | 242.2 |  |
| Other non-current assets |  | $ | 518.4 |  |  | $ | 484.6 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-14-069692:notes:69]
8.  Financial
 Instruments and Fair Value Measurements

[0001193125-14-069692:notes:70]
The accounting guidance for fair value measurements provides a
 framework for measuring fair value on either a recurring or
 nonrecurring basis, whereby the inputs used in our valuation
 techniques are assigned a hierarchical level. The following are the
 three levels of inputs to measure fair value:

[0001193125-14-069692:notes:71]
[same as prior period, unchanged from 0001193125-13-454984:notes:68]

[0001193125-14-069692:notes:72]
[same as prior period, unchanged from 0001193125-13-454984:notes:69]

[0001193125-14-069692:notes:73]
[same as prior period, unchanged from 0001193125-13-454984:notes:70]

[0001193125-14-069692:notes:74]
[same as prior period, unchanged from 0001193125-13-454984:notes:71]

[0001193125-14-069692:notes:75]
[same as prior period, unchanged from 0001193125-13-454984:notes:72]

[0001193125-14-069692:notes:76]
[same as prior period, unchanged from 0001193125-13-454984:notes:73]

[0001193125-14-069692:notes:77]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
|  |  |  |  |  | Gross Unrealized |  |  |  |  |  |  |  |  | Gross Unrealized |  |  |  |  |
|  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |  | Cost or Amortized Cost |  |  | Gains |  |  | Losses |  |  | Estimated Fair Value |  |
| Corporate bonds |  | $ | 2,433.8 |  |  | $ | 11.5 |  |  | $ | (0.7 | ) |  | $ | 2,444.6 |  |  | $ | 3,132.8 |  |  | $ | 14.9 |  |  | $ | (0.6 | ) |  | $ | 3,147.1 |  |
| U.S. Treasury and government debt securities |  |  | 249.3 |  |  |  | 0.3 |  |  |  | 0.0 |  |  |  | 249.6 |  |  |  | 392.8 |  |  |  | 0.9 |  |  |  | 0.0 |  |  |  | 393.7 |  |
| Commercial paper |  |  | 237.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 237.2 |  |  |  | 178.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 178.5 |  |
| Certificates of deposit |  |  | 135.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 135.0 |  |  |  | 135.4 |  |  |  | 0.1 |  |  |  | 0.0 |  |  |  | 135.5 |  |
| Money market funds |  |  | 13.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 13.1 |  |  |  | 1,463.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,463.1 |  |
| Auction rate securities |  |  | 41.9 |  |  |  | 0.0 |  |  |  | (1.5 | ) |  |  | 40.4 |  |  |  | 44.2 |  |  |  | 0.5 |  |  |  | (2.7 | ) |  |  | 42.0 |  |
| Equity funds |  |  | 32.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 32.5 |  |  |  | 28.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 28.3 |  |
| Total debt and equity securities |  | $ | 3,142.8 |  |  | $ | 11.8 |  |  | $ | (2.2 | ) |  | $ | 3,152.4 |  |  | $ | 5,375.1 |  |  | $ | 16.4 |  |  | $ | (3.3 | ) |  | $ | 5,388.2 |  |

[0001193125-14-069692:notes:78]
The unrealized losses on our available-for-sale investments
 were caused by market value declines as a result of the economic
 environment, as well as fluctuations in market interest rates.
 Because the declines in market value are attributable to changes in
 market conditions and not credit quality, and because we have
 currently concluded that we neither intend to sell nor is it more
 likely than not that we will be required to sell these investments
 prior to a recovery of par value, we do not consider these
 investments to be other-than temporarily impaired as of
 January 24, 2014.

[0001193125-14-069692:notes:79]
[same as prior period, unchanged from 0001193125-13-454984:notes:77]

[0001193125-14-069692:notes:80]
The following table summarizes the balance sheet
 classifications of our financial assets and liabilities measured at
 fair value on a recurring basis as of January 24, 2014 (in
 millions):

[0001193125-14-069692:notes:81]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 162.9 |  |  | $ | 13.1 |  |  | $ | 149.8 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 2,916.6 |  |  |  | 180.5 |  |  |  | 2,736.1 |  |  |  | 0.0 |  |
| Other current assets |  |  | 6.2 |  |  |  | 3.8 |  |  |  | 2.4 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 69.1 |  |  |  | 28.7 |  |  |  | 0.0 |  |  |  | 40.4 |  |
| Total |  | $ | 3,154.8 |  |  | $ | 226.1 |  |  | $ | 2,888.3 |  |  | $ | 40.4 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 2.0 |  |  | $ | 0.0 |  |  | $ | 2.0 |  |  | $ | 0.0 |  |

[0001193125-14-069692:notes:82]
Level 2 investments are held by a custodian who prices some of
 the investments using standard inputs in various asset price models
 or obtains investment prices from a third-party pricing provider
 that incorporates standard inputs in various asset price models. We
 review Level 2 inputs and fair value for reasonableness and the
 values may be further validated by comparison to multiple
 independent pricing sources. In addition, we review third-party
 pricing providers’ models, key inputs and assumptions and
 understand the pricing processes at our third-party providers in
 determining the overall reasonableness of the fair value of our
 Level 2 financial instruments. As of January 24, 2014, we have
 not made any adjustments to the prices obtained from our
 third-party pricing providers.

[0001193125-14-069692:notes:83]
Quantitative
 information about our Level 3 fair value measurements is as follows
 (fair value in millions):

[0001193125-14-069692:notes:84]
|  |  | Estimated Fair Value as of January 24, 2014 |  |  | Valuation Techniques |  | Unobservable Inputs |  | Range (Weighted average) |
| ARSs |  | $ | 40.4 |  |  | Discounted cash flow |  | Time-to-economic maturity |  | 6.7 yrs. –10.6 yrs. (8.2 yrs.) |
|  |  |  |  |  |  |  |  | Illiquidity premium |  | 1.5% - 3.3% (2.3%) |
|  |  |  |  |  |  |  |  | Coupon rate |  | 1.1% - 2.7% (1.9%) |
|  |  |  |  |  |  | Market comparable securities |  | Discount rate |  | 2.0% - 4.0% (2.8%) |

[0001193125-14-069692:notes:85]
All of our ARSs are classified as other non-current assets and
 are backed by pools of student loans guaranteed by the U.S.
 Department of Education. We estimate the fair value of each
 individual ARS using an income (discounted cash flow) and market
 approach that incorporate both observable and unobservable inputs.
 Key inputs into the discounted cash flow analysis include the
 time-to-economic maturity, illiquidity premium, which factors in
 liquidity risk, market credit spread and other factors, and a
 coupon rate. The key input into the market approach is a discount
 rate. A significant increase (decrease) in the time-to-economic
 maturity, liquidity risk premium, market credit spread and other
 factors, coupon rate or discount rate could result in a
 significantly lower (higher) fair value estimate. We review the
 fair value of our Level 3 financial instruments for overall
 reasonableness by reviewing service provider pricing methodologies,
 key inputs and assumptions and by understanding the processes used
 by our third-party service provider. We will continue to monitor
 our ARS investments in light of the debt market environment and
 evaluate these investments for impairment and
 classification.

[0001193125-14-069692:notes:86]
The table below provides a reconciliation of the beginning and
 ending balance of our Level 3 ARSs measured at fair value on a
 recurring basis using significant unobservable inputs (in
 millions):

[0001193125-14-069692:notes:87]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Balance at beginning of period |  | $ | 39.5 |  |  | $ | 46.5 |  |  | $ | 42.0 |  |  | $ | 51.0 |  |
| Total unrealized gains, net included in other comprehensive income (loss) |  |  | 0.9 |  |  |  | 0.0 |  |  |  | 0.7 |  |  |  | 0.5 |  |
| Total realized gains included in earnings |  |  | 0.0 |  |  |  | 0.7 |  |  |  | 0.7 |  |  |  | 0.7 |  |
| Sales |  |  | 0.0 |  |  |  | 0.0 |  |  |  | (3.0 | ) |  |  | 0.0 |  |
| Settlements |  |  | 0.0 |  |  |  | (5.0 | ) |  |  | 0.0 |  |  |  | (10.0 | ) |
| Balance at end of period |  | $ | 40.4 |  |  | $ | 42.2 |  |  | $ | 40.4 |  |  | $ | 42.2 |  |

[0001193125-14-069692:notes:88]
[same as prior period, unchanged from 0001193125-13-454984:notes:86]

[0001193125-14-069692:notes:89]
As of January 24, 2014, the fair value of our 2.00% Senior
 Notes and 3.25% Senior Notes (collectively referred to as Senior
 Notes) was approximately $983.7 million. The fair value of our debt
 was based on observable market prices in a less active market and
 discounted cash flow models that take into consideration variables
 such as credit-rating and interest rate changes. All of our debt
 obligations are categorized as Level 2 instruments.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-14-069692:notes:90]
7.  Balance
 Sheet Details

[0001193125-14-069692:notes:91]
[same as prior period, unchanged from 0001193125-13-454984:notes:89]

[0001193125-14-069692:notes:92]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Prepaid expenses and other current assets |  | $ | 210.6 |  |  | $ | 271.5 |  |
| Deferred tax assets |  |  | 247.0 |  |  |  | 253.7 |  |
| Other current assets |  | $ | 457.6 |  |  | $ | 525.2 |  |

[0001193125-14-069692:notes:93]
[same as prior period, unchanged from 0001193125-13-454984:notes:91]

[0001193125-14-069692:notes:94]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Computer software |  | $ | 119.9 |  |  | $ | 162.5 |  |

[0001193125-14-069692:notes:95]
[same as prior period, unchanged from 0001193125-13-454984:notes:93]

[0001193125-14-069692:notes:96]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Product |  | $ | 32.4 |  |  | $ | 15.7 |  |
| Software entitlements and maintenance and service |  |  | 2,926.9 |  |  |  | 2,993.8 |  |
| Total |  | $ | 2,959.3 |  |  | $ | 3,009.5 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,566.3 |  |  | $ | 1,563.3 |  |
| Long-term |  |  | 1,393.0 |  |  |  | 1,446.2 |  |
| Total |  | $ | 2,959.3 |  |  | $ | 3,009.5 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0001193125-14-069692:notes:97]
|  |  | ESPP |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 0.2 | % |  |  | 0.2 | % |  |  | 0.2 | % |  |  | 0.2 | % |
| Volatility |  |  | 30 | % |  |  | 41 | % |  |  | 31 | % |  |  | 40 | % |
| Dividend yield |  |  | 1.6 | % |  |  | 0.0 | % |  |  | 1.6 | % |  |  | 0.0 | % |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001193125-14-069692:notes:98]
A reconciliation of retained earnings for the nine months ended
 January 24, 2014 is as follows (in millions):

[0001193125-14-069692:notes:99]
| Balance as of April 26, 2013 |  | $ | 2,896.8 |  |
| Net income |  |  | 440.5 |  |
| Repurchases of common stock |  |  | (921.3 | ) |
| Retirement of treasury stock |  |  | (2,313.3 | ) |
| Dividends |  |  | (102.7 | ) |
| Balance as of January 24, 2014 |  | $ | 0.0 |  |


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0001193125-14-069692:notes:100]
Activities related to this plan for the nine months ended
 January 24, 2014 were as follows (in millions):

[0001193125-14-069692:notes:101]
|  |  | Total |  |
| Net charges |  | $ | 49.5 |  |
| Cash payments |  |  | (48.9 | ) |
| Balance as of January 24, 2014 |  | $ | 0.6 |  |


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-14-069692:notes:102]
[same as prior period, unchanged from 0001193125-13-454984:notes:100]

[0001193125-14-069692:notes:103]
[same as prior period, unchanged from 0001193125-13-454984:notes:101]

[0001193125-14-069692:notes:104]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Reclassification of equity component of Convertible Notes |  | $ | 0.0 |  |  | $ | 62.6 |  |
| Acquisition of property and equipment outstanding in accounts payable |  | $ | 25.7 |  |  | $ | 30.4 |  |
| Acquisition of software through long-term financing |  | $ | 11.4 |  |  | $ | 0.8 |  |
| Vested options assumed in acquisition |  | $ | 0.0 |  |  | $ | 1.2 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 39.5 |  |  | $ | 33.9 |  |
| Interest paid, net of capitalized interest |  | $ | 35.0 |  |  | $ | 22.6 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-14-069692:notes:105]
[same as prior period, unchanged from 0001193125-13-454984:notes:103]

[0001193125-14-069692:notes:106]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 192.1 |  |  | $ | 158.1 |  |  | $ | 440.5 |  |  | $ | 331.5 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 339.4 |  |  |  | 359.5 |  |  |  | 343.7 |  |  |  | 362.5 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 6.8 |  |  |  | 5.1 |  |  |  | 7.0 |  |  |  | 5.1 |  |
| Dilutive impact of assumed conversion of Convertible Notes |  |  | 0.0 |  |  |  | 0.1 |  |  |  | 0.7 |  |  |  | 0.5 |  |
| Dilutive impact of warrants |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.3 |  |  |  | 0.0 |  |
| Shares used in diluted computation |  |  | 346.2 |  |  |  | 364.7 |  |  |  | 351.7 |  |  |  | 368.1 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.57 |  |  | $ | 0.44 |  |  | $ | 1.28 |  |  | $ | 0.91 |  |
| Diluted |  | $ | 0.55 |  |  | $ | 0.43 |  |  | $ | 1.25 |  |  | $ | 0.90 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-14-069692:notes:107]
12.  Restructuring and Other
 Charges

[0001193125-14-069692:notes:108]
In May
 2013, we initiated a business restructuring plan under which we
 realigned internal resources, resulting in a reduction of our
 global workforce of approximately 7%. Such activities have been
 substantially completed as of January 24, 2014. Restructuring
 and other charges during the nine months ended January 24,
 2014 consisted primarily of employee severance-related
 costs.

[0001193125-14-069692:notes:109]
The
 reserve balance as of January 24, 2014 is included in accrued
 compensation and related benefits in our condensed consolidated
 balance sheet.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001193125-14-069692:notes:110]
[same as prior period, unchanged from 0001193125-13-454984:notes:108]

[0001193125-14-069692:notes:111]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| United States |  | $ | 1,010.3 |  |  | $ | 3,419.3 |  |
| International |  |  | 4,111.0 |  |  |  | 3,586.8 |  |
| Total |  | $ | 5,121.3 |  |  | $ | 7,006.1 |  |


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001193125-14-069692:notes:112]
[same as prior period, unchanged from 0001193125-13-454984:notes:110]

[0001193125-14-069692:notes:113]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |  |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |  |  |  |
| OCI Components |  | Amounts Reclassified from AOCI |  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |  |
| Realized losses (gains) on available-for-sale securities |  | $ | 0.0 |  |  | $ | 0.1 |  |  | $ | (1.1 | ) |  | $ | (0.5 | ) |  |  | Other income (expense), net |  |
| Realized losses (gains) on cash flow hedges |  |  | (0.2 | ) |  |  | 3.1 |  |  |  | 1.2 |  |  |  | 1.2 |  |  |  | Net revenues |  |
| Total reclassifications |  | $ | (0.2 | ) |  | $ | 3.2 |  |  | $ | 0.1 |  |  | $ | 0.7 |  |  |  |  |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001193125-14-069692:notes:114]
[same as prior period, unchanged from 0001193125-13-454984:notes:112]

[0001193125-14-069692:notes:115]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| United States |  | $ | 1,043.6 |  |  | $ | 1,076.3 |  |
| International |  |  | 85.0 |  |  |  | 94.6 |  |
| Total |  | $ | 1,128.6 |  |  | $ | 1,170.9 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-14-069692:notes:116]
5.  Business
 Combination

[0001193125-14-069692:notes:117]
On
 November 14, 2012, we acquired all of the outstanding shares
 of CacheIQ, Inc., a privately-held storage solutions company based
 in Texas, for $89.8 million in cash and $1.2 million in equity.
 This acquisition provides us with technology that extends our
 capabilities to support non-disruptive operations for enterprise
 data center environments. We will integrate this technology into
 our product offerings over time.

[0001193125-14-069692:notes:118]
The
 results of operations of CacheIQ have been included in our
 condensed consolidated statements of operations from the
 acquisition date. Pro forma results of operations have not been
 presented because the acquisition was not material to our results
 of operations.


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001193125-14-069692:notes:119]
[same as prior period, unchanged from 0001193125-13-454984:notes:114]

[0001193125-14-069692:notes:120]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Beginning balance |  | $ | 116.0 |  |  | $ | 111.8 |  |  | $ | 117.2 |  |  | $ | 83.1 |  |
| Expense accrued during the period |  |  | 21.1 |  |  |  | 23.5 |  |  |  | 59.4 |  |  |  | 74.3 |  |
| Warranty costs incurred |  |  | (20.0 | ) |  |  | (18.5 | ) |  |  | (59.5 | ) |  |  | (40.6 | ) |
| Ending balance |  | $ | 117.1 |  |  | $ | 116.8 |  |  | $ | 117.1 |  |  | $ | 116.8 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-14-069692:notes:121]
14.  Net
 Income per Share


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-14-069692:notes:122]
6.  Purchased
 Intangible Assets, Net

[0001193125-14-069692:notes:123]
[same as prior period, unchanged from 0001193125-13-454984:notes:118]

[0001193125-14-069692:notes:124]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
|  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |  | Gross Assets |  |  | Accumulated Amortization |  |  | Net Assets |  |
| Developed technology |  | $ | 283.0 |  |  | $ | (148.3 | ) |  | $ | 134.7 |  |  | $ | 312.4 |  |  | $ | (134.9 | ) |  | $ | 177.5 |  |
| Customer contracts/relationships |  |  | 9.6 |  |  |  | (8.9 | ) |  |  | 0.7 |  |  |  | 54.7 |  |  |  | (53.1 | ) |  |  | 1.6 |  |
| Trademarks and trade names |  |  | 2.9 |  |  |  | (2.3 | ) |  |  | 0.6 |  |  |  | 9.9 |  |  |  | (8.9 | ) |  |  | 1.0 |  |
| Covenants not to compete |  |  | 1.6 |  |  |  | (1.5 | ) |  |  | 0.1 |  |  |  | 2.2 |  |  |  | (1.7 | ) |  |  | 0.5 |  |
| Total purchased intangible assets |  | $ | 297.1 |  |  | $ | (161.0 | ) |  | $ | 136.1 |  |  | $ | 379.2 |  |  | $ | (198.6 | ) |  | $ | 180.6 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001193125-14-069692:notes:125]
10.  Stockholders’ Equity

[0001193125-14-069692:notes:126]
[same as prior period, unchanged from 0001193125-13-454984:notes:122]

[0001193125-14-069692:notes:127]
[same as prior period, unchanged from 0001193125-13-454984:notes:123]

[0001193125-14-069692:notes:128]
[same as prior period, unchanged from 0001193125-13-454984:notes:124]

[0001193125-14-069692:notes:129]
[same as prior period, unchanged from 0001193125-13-454984:notes:125]

[0001193125-14-069692:notes:130]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 26, 2013 |  |  | 12.8 |  |  | $ | 38.36 |  |
| Granted |  |  | 6.3 |  |  |  | 38.67 |  |
| Vested |  |  | (4.0 | ) |  |  | 38.20 |  |
| Forfeited |  |  | (1.4 | ) |  |  | 39.23 |  |
| Outstanding as of January 24, 2014 |  |  | 13.7 |  |  |  | 38.45 |  |

[0001193125-14-069692:notes:131]
[same as prior period, unchanged from 0001193125-13-454984:notes:127]

[0001193125-14-069692:notes:132]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Shares withheld for taxes |  |  | 0.3 |  |  |  | 0.4 |  |  |  | 1.3 |  |  |  | 1.1 |  |
| Fair value of shares withheld |  | $ | 12.1 |  |  | $ | 12.2 |  |  | $ | 51.4 |  |  | $ | 34.8 |  |

[0001193125-14-069692:notes:133]
[same as prior period, unchanged from 0001193125-13-454984:notes:129]

[0001193125-14-069692:notes:134]
[same as prior period, unchanged from 0001193125-13-454984:notes:130]

[0001193125-14-069692:notes:135]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Weighted-average fair value per right granted |  | $ | 11.03 |  |  | $ | 10.37 |  |  | $ | 10.83 |  |  | $ | 10.36 |  |
| Shares issued under the ESPP |  |  | 1.8 |  |  |  | 1.9 |  |  |  | 3.8 |  |  |  | 3.8 |  |
| Proceeds from issuance of shares |  | $ | 45.6 |  |  | $ | 46.8 |  |  | $ | 95.5 |  |  | $ | 95.0 |  |

[0001193125-14-069692:notes:136]
[same as prior period, unchanged from 0001193125-13-454984:notes:132]

[0001193125-14-069692:notes:137]
[same as prior period, unchanged from 0001193125-13-454984:notes:133]

[0001193125-14-069692:notes:138]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Cost of product revenues |  | $ | 1.5 |  |  | $ | 1.4 |  |  | $ | 4.2 |  |  | $ | 4.7 |  |
| Cost of service revenues |  |  | 4.6 |  |  |  | 4.8 |  |  |  | 12.8 |  |  |  | 15.0 |  |
| Sales and marketing |  |  | 33.0 |  |  |  | 31.9 |  |  |  | 94.6 |  |  |  | 101.8 |  |
| Research and development |  |  | 23.6 |  |  |  | 20.8 |  |  |  | 66.6 |  |  |  | 63.8 |  |
| General and administrative |  |  | 9.2 |  |  |  | 8.4 |  |  |  | 27.6 |  |  |  | 26.2 |  |
| Total stock-based compensation expense |  | $ | 71.9 |  |  | $ | 67.3 |  |  | $ | 205.8 |  |  | $ | 211.5 |  |

[0001193125-14-069692:notes:139]
As of January 24, 2014, total unrecognized compensation
 expense related to our equity awards was $449.3 million, which is
 expected to be recognized on a straight-line basis over a
 weighted-average remaining service period of
 2.5 years.

[0001193125-14-069692:notes:140]
Total income tax benefits associated with employee stock
 transactions and recognized in stockholders’ equity were as
 follows (in millions):

[0001193125-14-069692:notes:141]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Income tax benefits associated with employee stock transactions |  | $ | 22.5 |  |  | $ | 35.4 |  |

[0001193125-14-069692:notes:142]
[same as prior period, unchanged from 0001193125-13-454984:notes:138]

[0001193125-14-069692:notes:143]
[same as prior period, unchanged from 0001193125-13-454984:notes:139]

[0001193125-14-069692:notes:144]
|  |  | Stock Options |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Expected term in years |  |  | 4.8 |  |  |  | 4.5 |  |  |  | 4.8 |  |  |  | 4.8 |  |
| Risk-free interest rate |  |  | 1.4 | % |  |  | 0.6 | % |  |  | 1.1 | % |  |  | 0.6 | % |
| Volatility |  |  | 32 | % |  |  | 43 | % |  |  | 34 | % |  |  | 42 | % |
| Dividend yield |  |  | 1.6 | % |  |  | 0.0 | % |  |  | 1.6 | % |  |  | 0.0 | % |

[0001193125-14-069692:notes:145]
[same as prior period, unchanged from 0001193125-13-454984:notes:141]

[0001193125-14-069692:notes:146]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Grant date fair value per share |  | $ | 39.87 |  |  | $ | 30.69 |  |  | $ | 38.67 |  |  | $ | 29.45 |  |
| Expected dividend |  |  | 1.6 | % |  |  | 0.0 | % |  |  | 1.6 | % |  |  | 0.0 | % |

[0001193125-14-069692:notes:147]
[same as prior period, unchanged from 0001193125-13-454984:notes:143]

[0001193125-14-069692:notes:148]
[same as prior period, unchanged from 0001193125-13-454984:notes:144]

[0001193125-14-069692:notes:149]
As of January 24, 2014, our Board of Directors has
 authorized the repurchase of up to $7.1 billion of our common
 stock. Under this program, which we may suspend or discontinue at
 any time, we may purchase shares of our outstanding common stock
 through open market and privately negotiated transactions at prices
 deemed appropriate by our management.

[0001193125-14-069692:notes:150]
The following table summarizes activity related to this program
 for the nine months ended January 24, 2014 (in millions,
 except per share information):

[0001193125-14-069692:notes:151]
| Number of shares repurchased |  |  | 37.6 |  |
| Average price per share |  | $ | 40.04 |  |
| Aggregate purchase price |  | $ | 1,507.0 |  |
| Remaining authorization at end of period |  | $ | 1,499.2 |  |

[0001193125-14-069692:notes:152]
The aggregate purchase price of our stock repurchases for the
 nine months ended January 24, 2014 consisted of $750.0 million
 under an accelerated share repurchase agreement (ASR) and $757.0
 million of open market purchases, for which collectively $585.7
 million and $921.3 million was allocated to additional paid-in
 capital and retained earnings, respectively.

[0001193125-14-069692:notes:153]
During the nine months ended January 24, 2014, we retired
 104.3 million shares of common stock repurchased in prior
 years and previously reported as treasury stock, resulting in
 reductions of $0.1 million in common stock (par value), $614.0
 million in additional paid-in capital and $2,313.3 million in
 retained earnings.

[0001193125-14-069692:notes:154]
[same as prior period, unchanged from 0001193125-13-454984:notes:150]

[0001193125-14-069692:notes:155]
[same as prior period, unchanged from 0001193125-13-454984:notes:151]

[0001193125-14-069692:notes:156]
[same as prior period, unchanged from 0001193125-13-454984:notes:152]

[0001193125-14-069692:notes:157]
During the nine months ended January 24, 2014, we declared
 and paid quarterly cash dividends of $0.15 per share of outstanding
 common stock, or an aggregate of $153.1 million, of which $50.4
 million and $102.7 million was allocated to additional paid-in
 capital and retained earnings, respectively. On February 12,
 2014, we declared a cash dividend of $0.15 per share of common
 stock, payable on April 22, 2014 to holders of record as of
 the close of business on April 10, 2014. No dividends were
 declared or paid during the nine months ended January 25,
 2013. The timing and amount of future dividends will depend on
 market conditions, corporate business and financial considerations
 and regulatory requirements. All dividends declared have been
 determined by the Company to be legally authorized under the laws
 of the state in which we are incorporated.

[0001193125-14-069692:notes:158]
[same as prior period, unchanged from 0001193125-13-454984:notes:154]

[0001193125-14-069692:notes:159]
[same as prior period, unchanged from 0001193125-13-454984:notes:155]


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001193125-14-069692:notes:160]
[same as prior period, unchanged from 0001193125-13-454984:notes:156]

[0001193125-14-069692:notes:161]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Americas (United States, Canada and Latin America) |  | $ | 838.7 |  |  | $ | 882.8 |  |  | $ | 2,596.4 |  |  | $ | 2,581.2 |  |
| Europe, Middle East and Africa |  |  | 546.9 |  |  |  | 528.6 |  |  |  | 1,439.9 |  |  |  | 1,405.6 |  |
| Asia Pacific |  |  | 224.4 |  |  |  | 218.7 |  |  |  | 639.8 |  |  |  | 629.1 |  |
| Net revenues |  | $ | 1,610.0 |  |  | $ | 1,630.1 |  |  | $ | 4,676.1 |  |  | $ | 4,615.9 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-14-069692:notes:162]
[same as prior period, unchanged from 0001193125-13-454984:notes:158]

[0001193125-14-069692:notes:163]
There
 have been no significant changes in our significant accounting
 policies as of and for the nine months ended January 24, 2014,
 as compared to the significant accounting policies described in our
 Annual Report on Form 10-K for the fiscal year ended April 26,
 2013.

[0001193125-14-069692:notes:164]
Use
 of Estimates — The preparation of the condensed
 consolidated financial statements in conformity with GAAP requires
 management to make estimates and assumptions that affect the
 reported amounts of assets and liabilities and disclosure of
 contingent assets and liabilities at the date of the financial
 statements and the reported amounts of revenues and expenses during
 the reporting periods. Such estimates include, but are not limited
 to, revenue recognition, reserves and allowances; inventory
 valuation and purchase order accruals; valuation of goodwill and
 intangibles; restructuring reserves; product warranties; employee
 benefit accruals; stock-based compensation; loss contingencies;
 investment impairments; income taxes and fair value measurements.
 Actual results could differ materially from those
 estimates.


## us-gaap:ScheduleOfGuaranteeObligationsTextBlock

[0001193125-14-069692:notes:165]
[same as prior period, unchanged from 0001193125-13-454984:notes:162]

[0001193125-14-069692:notes:166]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Maximum guaranteed payment contingencies |  | $ | 218.0 |  |  | $ | 182.4 |  |
| Deferred revenue associated with financing guarantees |  |  | (203.8 | ) |  |  | (168.6 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue |  | $ | 14.2 |  |  | $ | 13.8 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-069692:notes:167]
13.  Income
 Taxes

[0001193125-14-069692:notes:168]
[same as prior period, unchanged from 0001193125-13-454984:notes:165]

[0001193125-14-069692:notes:169]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Effective tax rates |  |  | 14.3 | % |  |  | 12.2 | % |

[0001193125-14-069692:notes:170]
[same as prior period, unchanged from 0001193125-13-454984:notes:167]

[0001193125-14-069692:notes:171]
As of January 24, 2014, we had $207.8 million of
 unrecognized tax benefits, of which $148.6 million has been
 recorded in other long-term liabilities. Unrecognized tax benefits
 of $135.8 million, including penalties and interest, would affect
 our provision for income taxes if recognized. During the nine
 months ended January 24, 2014, there was a gross increase in
 our unrecognized tax benefits of $20.9 million for tax positions
 related to the current year, and a gross increase of $1.8 million
 and gross decrease, including settlements and statute lapses, of
 $4.5 million for tax positions related to prior years.

[0001193125-14-069692:notes:172]
Our fiscal 2005 through 2007 income tax returns are currently
 under audit by the IRS. In September 2012, we reached a tentative
 agreement with the IRS field examination team on certain transfer
 pricing matters under appeals, and in July 2013, we received a
 revised Revenue Agent’s Report (RAR) from the IRS. We are
 currently in the process of preparing for the review of the revised
 RAR by certain higher authorities within the IRS and the Joint
 Committee on Taxation. In February 2012, the IRS commenced an
 examination of our fiscal 2008 through fiscal 2010 income tax
 returns. Our open years in U.S. federal jurisdictions are fiscal
 2005 and later years. In addition, we are effectively subject to
 federal tax examination adjustments for tax years ended on or after
 fiscal year 2000, in that we have tax attribute carryforwards from
 these years that could be subject to adjustments, if and when
 utilized. In January 2014, the California Franchise Tax Board
 temporarily closed the audit of our fiscal 2007 and 2008 income tax
 returns and will reopen the audit upon the conclusion of the
 applicable federal IRS audits.

[0001193125-14-069692:notes:173]
[same as prior period, unchanged from 0001193125-13-454984:notes:170]

[0001193125-14-069692:notes:174]
[same as prior period, unchanged from 0001193125-13-454984:notes:171]

[0001193125-14-069692:notes:175]
In April 2010, our Dutch subsidiary received a favorable tax
 ruling from the Dutch tax authorities, effective May 1, 2010,
 that replaces the previous Dutch tax ruling that expired on
 April 30, 2010. This ruling results in both a lower level of
 earnings subject to tax in the Netherlands and an extension of the
 expiration date to April 30, 2015.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-069692:notes:176]
15.  Segment,
 Geographic, and Significant Customer Information

[0001193125-14-069692:notes:177]
[same as prior period, unchanged from 0001193125-13-454984:notes:174]

[0001193125-14-069692:notes:178]
Americas revenues consist of Americas commercial and U.S.
 public sector revenues. Sales to customers inside the United States
 comprised $734.6 million and $778.9 million of Americas net
 revenues during the three months ended January 24, 2014 and
 January 25, 2013, respectively, and $2,308.1 million and
 $2,287.9 million of Americas net revenues during the nine months
 ended January 24, 2014 and January 25, 2013,
 respectively. Sales to Germany accounted for $163.8 million of net
 revenues for the three months ended January 25, 2013. No
 single foreign country accounted for 10% or more of our net
 revenues for any other period presented.

[0001193125-14-069692:notes:179]
[same as prior period, unchanged from 0001193125-13-454984:notes:176]

[0001193125-14-069692:notes:180]
[same as prior period, unchanged from 0001193125-13-454984:notes:177]

[0001193125-14-069692:notes:181]
No customer accounted for 10% or more of net accounts
 receivable as of January 24, 2014.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-069692:notes:182]
16.  Commitments and Contingencies

[0001193125-14-069692:notes:183]
Operating Lease Commitments

[0001193125-14-069692:notes:184]
As of January 24, 2014, future annual minimum lease
 payments under non-cancelable operating leases with an initial term
 in excess of one year totaled $216.1 million.

[0001193125-14-069692:notes:185]
Purchase Orders and Other Commitments

[0001193125-14-069692:notes:186]
In the normal course of business we make commitments to our
 third-party contract manufacturers, to manage manufacturer lead
 times and meet product forecasts, and to other parties, to purchase
 various key components used in the manufacture of our products. We
 establish accruals for estimated losses on purchased components to
 the extent we believe it is probable that such components will not
 be utilized in future operations. To the extent that such forecasts
 are not achieved, our commitments and associated accruals may
 change. As of January 24, 2014, we had $240.2 million in
 non-cancelable purchase commitments with our contract
 manufacturers. In addition, we recorded a liability for firm,
 non-cancelable and unconditional purchase commitments with contract
 manufacturers for quantities in excess of our future demand
 forecasts through a charge to cost of product revenues. As of
 January 24, 2014 and April 26, 2013, such liability
 amounted to $15.4 million and $9.5 million, respectively, and is
 included in other current liabilities in our condensed consolidated
 balance sheets.

[0001193125-14-069692:notes:187]
In addition to commitments with contract manufacturers and
 component suppliers, we have open purchase orders and contractual
 obligations associated with our ordinary course of business for
 which we have not received goods or services. As of
 January 24, 2014, we had $44.1 million in capital purchase
 commitments and $203.2 million in other purchase
 commitments.

[0001193125-14-069692:notes:188]
Product Warranties

[0001193125-14-069692:notes:189]
We provide customers a warranty on software of ninety days to
 five years and a warranty on hardware of one to five years. The
 following table summarizes our warranty reserves (in
 millions):

[0001193125-14-069692:notes:190]
Our warranty reserves were reported in our condensed
 consolidated balance sheets as follows (in millions):

[0001193125-14-069692:notes:191]
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| Other current liabilities |  | $ | 79.8 |  |  | $ | 81.6 |  |
| Other long-term liabilities |  |  | 37.3 |  |  |  | 35.6 |  |
| Total |  | $ | 117.1 |  |  | $ | 117.2 |  |

[0001193125-14-069692:notes:192]
Financing Guarantees

[0001193125-14-069692:notes:193]
Some of our customers have entered into recourse and
 non-recourse financing leasing arrangements using third-party
 financing companies, and in some situations, we enter into customer
 financing arrangements for our products and services that are
 contemporaneously sold on a recourse or non-recourse basis to
 third-party financing companies. Under the terms of recourse
 leases, which are generally three years or less, we remain liable
 for the aggregate unpaid remaining lease payments to the
 third-party leasing companies in the event of end-user customer
 default. These arrangements are generally collateralized by a
 security interest in the underlying assets. Under the terms of the
 nonrecourse leases, we do not have any continuing obligations or
 liabilities to the third-party financing companies. Where we
 provide a guarantee for recourse leases, we defer revenues subject
 to the industry-specific software revenue recognition guidance, and
 recognize revenues for non-software deliverables in accordance with
 our multiple deliverable revenue arrangement policy. In connection
 with certain recourse financing arrangements, we receive advance
 payments associated with undelivered elements that are subject to
 customer refund rights. We defer revenue associated with these
 advance payments until the related refund rights expire and we
 perform the services.

[0001193125-14-069692:notes:194]
To date, we have not experienced material losses under our
 lease financing programs or other financing
 arrangements.

[0001193125-14-069692:notes:195]
Legal Contingencies

[0001193125-14-069692:notes:196]
When a loss is considered probable and reasonably estimable, we
 record a liability in the amount of our best estimate for the
 ultimate loss. However, the likelihood of a loss with respect to a
 particular contingency is often difficult to predict and
 determining a meaningful estimate of the loss or a range of loss
 may not be practicable based on the information available and the
 potential effect of future events and decisions by third parties
 that will determine the ultimate resolution of the
 contingency.

[0001193125-14-069692:notes:197]
We are subject to various legal proceedings and claims that
 arise in the normal course of business. No accrual has been
 recorded as of January 24, 2014 related to such matters as
 they are not probable and/or reasonably estimable.
