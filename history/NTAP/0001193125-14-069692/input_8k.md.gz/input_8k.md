# NTAP 8-K — 0001102624-14-000200 filed 2014-02-12

## item codes, every 8-K on or before 2014-02-26

- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2014-02-26

- none on or before 2014-02-26

## item 2.02 — earnings release, exhibit 99.1

[0001102624-14-000200:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-14-000200:8k_2_02:2]
exh99_1.htm

[0001102624-14-000200:8k_2_02:3]
Exhibit 99.1

[0001102624-14-000200:8k_2_02:4]
| Press Contact: | Investor Contact: |
| Ryan Lowry | Kris Newton |
| NetApp | NetApp |
| 408-822-7544 | 408-822-3312 |
| ryan.lowry@netapp.com | kris.newton@netapp.com |

[0001102624-14-000200:8k_2_02:5]
NETAPP REPORTS THIRD QUARTER FISCAL YEAR 2014 RESULTS

[0001102624-14-000200:8k_2_02:6]
Non-GAAP Earnings Per Share of $0.75, Up 12% Year over Year

[0001102624-14-000200:8k_2_02:7]
| · | Net revenues of $1.610 billion |

[0001102624-14-000200:8k_2_02:8]
| · | Cash from operations of $332 million; free cash flow 17% of revenue |

[0001102624-14-000200:8k_2_02:9]
| · | Clustered Data ONTAP® node shipments up almost 300% year over year |

[0001102624-14-000200:8k_2_02:10]
Sunnyvale, CA—February 12, 2014—NetApp (NASDAQ: NTAP) today reported financial results for the third quarter of fiscal year 2014, ended January 24, 2014.

[0001102624-14-000200:8k_2_02:11]
Third Quarter Financial Results

[0001102624-14-000200:8k_2_02:12]
Net revenues for the third quarter of fiscal year 2014 were $1.610 billion. GAAP net income for the third quarter of fiscal year 2014 was $192 million, or $0.55 per share,1 compared to GAAP net income of $158 million, or $0.43 per share, for the comparable period of the prior year. Non-GAAP net income for the third quarter of fiscal year 2014 was $261 million, or $0.75 per share,2 compared to non-GAAP net income of $243 million, or $0.67 per share, for the comparable period of the prior year.

[0001102624-14-000200:8k_2_02:13]
Cash, Cash Equivalents, and Investments

[0001102624-14-000200:8k_2_02:14]
NetApp ended the third quarter of 2014 with $5.069 billion of total cash, cash equivalents, and investments and during the quarter generated approximately $332 million in cash from operations. The Company returned $557 million to shareholders during the quarter through share repurchases and a cash dividend. The next dividend in the amount of $0.15 per share will be paid on April 22, 2014 to shareholders of record as of the close of business on April 10, 2014.

[0001102624-14-000200:8k_2_02:15]
“We are pleased with our strong operational execution again this quarter,” said Tom Georgens, president and CEO. “With our strategy of delivering best-of-breed cloud-integrated and flash-accelerated solutions and our unique ability to manage data seamlessly across on- and off-premise environments, we are well positioned to create ongoing opportunity in the evolving IT landscape.”

[0001102624-14-000200:8k_2_02:16]
Q4 Fiscal Year 2014 Outlook

[0001102624-14-000200:8k_2_02:17]
The Company is providing the following financial guidance for the fourth quarter of fiscal year 2014:

[0001102624-14-000200:8k_2_02:18]
| · | Total revenue is expected to be in the range of $1.620 billion to $1.720 billion |

[0001102624-14-000200:8k_2_02:19]
| · | GAAP earnings per share is expected to be in the range of $0.57 to $0.62 per share |

[0001102624-14-000200:8k_2_02:20]
| · | Non-GAAP earnings per share is expected to be in the range of $0.77 to $0.82 per share |

[0001102624-14-000200:8k_2_02:21]
Business Highlights

[0001102624-14-000200:8k_2_02:22]
In its third quarter of fiscal year 2014, NetApp continued to execute one of the industry’s most innovative roadmaps with a focus on delivering cloud-integrated and flash-accelerated storage and data-management solutions that address customers’ shared and dedicated infrastructure requirements. Highlights include:

[0001102624-14-000200:8k_2_02:23]
| · | Continued Adoption of Clustered Data ONTAP. The attach rate of clustered ONTAP increased across every product line, with the FAS3000 family showing the largest increase. Clustered node shipments in the quarter increased by almost 300% year over year. |

[0001102624-14-000200:8k_2_02:24]
| · | NetApp Introduces New All-Flash Array. The new NetApp® EF550 all-flash array delivers high performance and consistent low latency for business-critical applications that require responsiveness and enterprise reliability. NetApp continues to execute its flash technology roadmap, solidifying its position as one of the established leaders in flash technology innovation. |

[0001102624-14-000200:8k_2_02:25]
| · | NetApp Unveils Performance-Optimized Enterprise Storage Systems. The new NetApp E2700 offers simple and flexible management for small remote/branch offices requiring optimal price/performance. The updated NetApp E5500 delivers enhanced performance, density, and modular flexibility for the widest range of data-intensive workloads. |

[0001102624-14-000200:8k_2_02:26]
| · | NetApp Simplifies and Accelerates Deployment of OpenStack Cloud Services. NetApp announced new contributions to OpenStack that include solutions for OpenStack Havana, incubation of a service for OpenStack Icehouse, and expanded support for partners and customers, including options that provide lower cost, faster innovation, flexibility, and no vendor lock-in. |

[0001102624-14-000200:8k_2_02:27]
| · | Leading Analyst Firm Ranks NetApp #1 in Storage System Capacity Shipped for Public Cloud Infrastructure. Recently, IDC ranked NetApp as having the #1 storage solution shipped for 2012 for public cloud infrastructure from the perspective of external system capacity. The ranking was conducted as part of IDC’s biannual Storage User Demand Study,3 which analyzes current and future deployments of enterprise storage systems for particular data uses. |

[0001102624-14-000200:8k_2_02:28]
| · | NetApp Once Again Recognized as a Best Company to Work for in America. The recognition marks the 12th consecutive year that NetApp was named to this list of 100 elite companies by FORTUNE magazine. |

[0001102624-14-000200:8k_2_02:29]
Webcast and Conference Call Information

[0001102624-14-000200:8k_2_02:30]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available after 4:30 p.m. Pacific Time today on the website.

[0001102624-14-000200:8k_2_02:31]
Historical supplemental data tables, providing historical multi-period financial information, are available on our investor relations website at investors.netapp.com.

[0001102624-14-000200:8k_2_02:32]
About NetApp

[0001102624-14-000200:8k_2_02:33]
NetApp creates innovative storage and data management solutions that deliver outstanding cost efficiency and accelerate business breakthroughs. Our commitment to living our core values and consistently being recognized as a great place to work around the world are fundamental to our long-term growth and success, as well as the success of our pathway partners and customers. Discover our passion for helping companies around the world go further, faster at www.netapp.com.

[0001102624-14-000200:8k_2_02:34]
###

[0001102624-14-000200:8k_2_02:35]
NetApp, the NetApp logo, Go further, faster, and Data ONTAP are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001102624-14-000200:8k_2_02:36]
1GAAP earnings per share is calculated using the diluted number of shares for all periods presented.

[0001102624-14-000200:8k_2_02:37]
2Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com.

[0001102624-14-000200:8k_2_02:38]
3IDC Storage Users Demand Study 2013–Spring Edition, IDC #244209, November 2013

[0001102624-14-000200:8k_2_02:39]
NetApp Usage of Non-GAAP Financials

[0001102624-14-000200:8k_2_02:40]
The Company refers to the non-GAAP financial measures in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has limitations and they should not solely be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we provide both non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-14-000200:8k_2_02:41]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation. We have historically reported similar non-GAAP financial measures to our investors and believe that the inclusion of comparative numbers provides consistency in our financial reporting at this time.

[0001102624-14-000200:8k_2_02:42]
9

[0001102624-14-000200:8k_2_02:43]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | January 24, 2014 |  |  | April 26, 2013 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,069.3 |  |  | $ | 6,952.6 |  |
| Accounts receivable, net |  |  | 584.3 |  |  |  | 800.9 |  |
| Inventories |  |  | 118.2 |  |  |  | 139.5 |  |
| Other current assets |  |  | 457.6 |  |  |  | 525.2 |  |
| Total current assets |  |  | 6,229.4 |  |  |  | 8,418.2 |  |
| Property and equipment, net |  |  | 1,128.6 |  |  |  | 1,170.9 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,124.2 |  |  |  | 1,168.7 |  |
| Other non-current assets |  |  | 518.4 |  |  |  | 484.6 |  |
| Total assets |  | $ | 9,000.6 |  |  | $ | 11,242.4 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 186.6 |  |  | $ | 259.7 |  |
| Accrued compensation and other current liabilities |  |  | 670.9 |  |  |  | 749.8 |  |
| Current portion of long-term debt |  |  | - |  |  |  | 1,257.8 |  |
| Short-term deferred revenue |  |  | 1,566.3 |  |  |  | 1,563.3 |  |
| Total current liabilities |  |  | 2,423.8 |  |  |  | 3,830.6 |  |
| Long-term debt |  |  | 995.2 |  |  |  | 994.6 |  |
| Other long-term liabilities |  |  | 272.7 |  |  |  | 253.5 |  |
| Long-term deferred revenue |  |  | 1,393.0 |  |  |  | 1,446.2 |  |
| Total liabilities |  |  | 5,084.7 |  |  |  | 6,524.9 |  |
| Stockholders' equity |  |  | 3,915.9 |  |  |  | 4,717.5 |  |
| Total liabilities and stockholders' equity |  | $ | 9,000.6 |  |  | $ | 11,242.4 |  |

[0001102624-14-000200:8k_2_02:44]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,015.0 |  |  | $ | 1,060.7 |  |  | $ | 2,901.1 |  |  | $ | 2,954.5 |  |
| Software entitlements and maintenance |  |  | 227.0 |  |  |  | 228.6 |  |  |  | 687.3 |  |  |  | 666.5 |  |
| Service |  |  | 368.0 |  |  |  | 340.8 |  |  |  | 1,087.7 |  |  |  | 994.9 |  |
| Net revenues |  |  | 1,610.0 |  |  |  | 1,630.1 |  |  |  | 4,676.1 |  |  |  | 4,615.9 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 450.7 |  |  |  | 512.5 |  |  |  | 1,323.9 |  |  |  | 1,442.0 |  |
| Cost of software entitlements and maintenance |  |  | 7.7 |  |  |  | 7.3 |  |  |  | 22.7 |  |  |  | 20.9 |  |
| Cost of service |  |  | 149.3 |  |  |  | 145.4 |  |  |  | 452.4 |  |  |  | 424.1 |  |
| Total cost of revenues |  |  | 607.7 |  |  |  | 665.2 |  |  |  | 1,799.0 |  |  |  | 1,887.0 |  |
| Gross profit |  |  | 1,002.3 |  |  |  | 964.9 |  |  |  | 2,877.1 |  |  |  | 2,728.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 475.9 |  |  |  | 493.5 |  |  |  | 1,423.2 |  |  |  | 1,464.6 |  |
| Research and development |  |  | 230.3 |  |  |  | 215.6 |  |  |  | 686.6 |  |  |  | 660.8 |  |
| General and administrative |  |  | 69.4 |  |  |  | 66.2 |  |  |  | 207.3 |  |  |  | 198.4 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 49.5 |  |  |  | - |  |
| Acquisition-related expense |  |  | - |  |  |  | 1.7 |  |  |  | - |  |  |  | 1.7 |  |
| Total operating expenses |  |  | 775.6 |  |  |  | 777.0 |  |  |  | 2,366.6 |  |  |  | 2,325.5 |  |
| Income from operations |  |  | 226.7 |  |  |  | 187.9 |  |  |  | 510.5 |  |  |  | 403.4 |  |
| Other income/(expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 7.9 |  |  |  | 10.3 |  |  |  | 26.4 |  |  |  | 32.1 |  |
| Interest expense |  |  | (6.7 | ) |  |  | (24.0 | ) |  |  | (29.7 | ) |  |  | (63.7 | ) |
| Other income, net |  |  | 1.7 |  |  |  | 1.6 |  |  |  | 6.9 |  |  |  | 5.9 |  |
| Total other income/(expense), net |  |  | 2.9 |  |  |  | (12.1 | ) |  |  | 3.6 |  |  |  | (25.7 | ) |
| Income before income taxes |  |  | 229.6 |  |  |  | 175.8 |  |  |  | 514.1 |  |  |  | 377.7 |  |
| Provision for income taxes |  |  | 37.5 |  |  |  | 17.7 |  |  |  | 73.6 |  |  |  | 46.2 |  |
| Net income |  | $ | 192.1 |  |  | $ | 158.1 |  |  | $ | 440.5 |  |  | $ | 331.5 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.57 |  |  | $ | 0.44 |  |  | $ | 1.28 |  |  | $ | 0.91 |  |
| Diluted |  | $ | 0.55 |  |  | $ | 0.43 |  |  | $ | 1.25 |  |  | $ | 0.90 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 339.4 |  |  |  | 359.5 |  |  |  | 343.7 |  |  |  | 362.5 |  |
| Diluted |  |  | 346.2 |  |  |  | 364.7 |  |  |  | 351.7 |  |  |  | 368.1 |  |
| Cash dividends declared per share |  | $ | 0.15 |  |  | $ | - |  |  | $ | 0.45 |  |  | $ | - |  |

[0001102624-14-000200:8k_2_02:45]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOW |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2014 |  |  | January 25, 2013 |  |  | January 24, 2014 |  |  | January 25, 2013 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 192.1 |  |  | $ | 158.1 |  |  | $ | 440.5 |  |  | $ | 331.5 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 83.6 |  |  |  | 86.4 |  |  |  | 252.0 |  |  |  | 255.5 |  |
| Stock-based compensation |  |  | 71.9 |  |  |  | 67.3 |  |  |  | 205.8 |  |  |  | 211.5 |  |
| Accretion of discount and issuance costs on debt |  |  | 0.4 |  |  |  | 15.3 |  |  |  | 9.2 |  |  |  | 44.0 |  |
| Excess tax benefit from stock-based compensation |  |  | (23.9 | ) |  |  | (9.4 | ) |  |  | (33.4 | ) |  |  | (53.0 | ) |
| Other, net |  |  | (6.7 | ) |  |  | 3.4 |  |  |  | (31.6 | ) |  |  | (8.3 | ) |
| Changes in assets and liabilities, net of acquired business |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 4.1 |  |  |  | (19.8 | ) |  |  | 213.4 |  |  |  | 193.1 |  |
| Inventories |  |  | (2.3 | ) |  |  | 40.3 |  |  |  | 21.3 |  |  |  | (11.4 | ) |
| Accounts payable |  |  | (29.0 | ) |  |  | (29.9 | ) |  |  | (69.8 | ) |  |  | (16.0 | ) |
| Accrued compensation and other current liabilities |  |  | 7.9 |  |  |  | (19.2 | ) |  |  | (94.5 | ) |  |  | (35.1 | ) |
| Deferred revenue |  |  | 40.6 |  |  |  | 105.3 |  |  |  | (27.0 | ) |  |  | 62.7 |  |
| Changes in other operating assets and liabilities, net |  |  | (6.9 | ) |  |  | (32.7 | ) |  |  | 94.2 |  |  |  | (43.8 | ) |
| Net cash provided by operating activities |  |  | 331.8 |  |  |  | 365.1 |  |  |  | 980.1 |  |  |  | 930.7 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 90.6 |  |  |  | 110.7 |  |  |  | 762.7 |  |  |  | 204.1 |  |
| Purchases of property and equipment |  |  | (57.9 | ) |  |  | (110.7 | ) |  |  | (165.4 | ) |  |  | (239.7 | ) |
| Acquisition of business, net of cash acquired |  |  | - |  |  |  | (89.4 | ) |  |  | - |  |  |  | (89.4 | ) |
| Other investing activities, net |  |  | (0.8 | ) |  |  | 0.2 |  |  |  | 2.6 |  |  |  | 3.0 |  |
| Net cash provided by (used in) investing activities |  |  | 31.9 |  |  |  | (89.2 | ) |  |  | 599.9 |  |  |  | (122.0 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock under employee stock plans |  |  | 67.9 |  |  |  | 50.4 |  |  |  | 191.8 |  |  |  | 95.5 |  |
| Repurchase of common stock and forward contract |  |  | (507.0 | ) |  |  | (61.7 | ) |  |  | (1,507.0 | ) |  |  | (410.0 | ) |
| Excess tax benefit from stock-based compensation |  |  | 23.9 |  |  |  | 9.4 |  |  |  | 33.4 |  |  |  | 53.0 |  |
| Repayment of debt |  |  | - |  |  |  | - |  |  |  | (1,264.9 | ) |  |  | - |  |
| Issuance of long-term debt, net |  |  | - |  |  |  | 987.3 |  |  |  | - |  |  |  | 987.3 |  |
| Dividends paid |  |  | (50.4 | ) |  |  | - |  |  |  | (153.1 | ) |  |  | - |  |
| Other financing activities, net |  |  | (1.8 | ) |  |  | (0.4 | ) |  |  | (7.5 | ) |  |  | (0.7 | ) |
| Net cash provided by (used in) financing activities |  |  | (467.4 | ) |  |  | 985.0 |  |  |  | (2,707.3 | ) |  |  | 725.1 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (4.1 | ) |  |  | 4.0 |  |  |  | 2.9 |  |  |  | (1.9 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (107.8 | ) |  |  | 1,264.9 |  |  |  | (1,124.4 | ) |  |  | 1,531.9 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,260.5 |  |  |  | 1,816.8 |  |  |  | 3,277.1 |  |  |  | 1,549.8 |  |
| End of period |  | $ | 2,152.7 |  |  | $ | 3,081.7 |  |  | $ | 2,152.7 |  |  | $ | 3,081.7 |  |

[0001102624-14-000200:8k_2_02:46]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except percentages, DSO and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q3 FY’14 |  |  | Q2 FY’14 |  |  | Q3 FY’13 |  |
| Revenues |  |  |  |  |  |  |  |  |  |
| Product Revenue |  | $ | 1,015.0 |  |  | $ | 955.3 |  |  | $ | 1,060.7 |  |
| Software Entitlements & Maintenance Revenue (SEM) |  |  | 227.0 |  |  |  | 231.8 |  |  |  | 228.6 |  |
| Service Revenue: |  |  | 368.0 |  |  |  | 362.8 |  |  |  | 340.8 |  |
| Hardware Maintenance Support Contracts Revenue |  |  | 285.9 |  |  |  | 276.4 |  |  |  | 254.8 |  |
| Professional & Other Services Revenue |  |  | 82.1 |  |  |  | 86.4 |  |  |  | 86.0 |  |
| Net Revenues |  | $ | 1,610.0 |  |  | $ | 1,549.9 |  |  | $ | 1,630.1 |  |
| Branded and OEM Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY’14 |  |  | Q2 FY’14 |  |  | Q3 FY’13 |  |
| Branded Revenue |  | $ | 1,452.7 |  |  | $ | 1,398.8 |  |  | $ | 1,426.9 |  |
| OEM Revenue |  |  | 157.3 |  |  |  | 151.1 |  |  |  | 203.2 |  |
| Net Revenues |  | $ | 1,610.0 |  |  | $ | 1,549.9 |  |  | $ | 1,630.1 |  |
| Branded revenue includes revenue from all products and services sold directly by us or our partners under the NetApp brand, including NetApp branded E-Series products and solutions. |  |
| OEM revenue comprises revenue from the sale of our products by other companies under their brands and includes revenue from IBM, Fujitsu, and other E-Series OEM relationships. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY’14 Revenue |  |  | % of Q2 FY’14 Revenue |  |  | % of Q3 FY’13 Revenue |  |
| Americas* |  |  | 52 | % |  |  | 58 | % |  |  | 54 | % |
| Americas Commercial |  |  | 43 | % |  |  | 42 | % |  |  | 44 | % |
| U.S. Public Sector |  |  | 9 | % |  |  | 16 | % |  |  | 10 | % |
| EMEA |  |  | 34 | % |  |  | 29 | % |  |  | 32 | % |
| Asia Pacific |  |  | 14 | % |  |  | 13 | % |  |  | 13 | % |
| * Americas Commercial and USPS revenue for Q3FY'13 is recast as a result of reporting certain healthcare revenue in Americas Commercial revenue that was previously included |  |
| in U.S. Public Sector revenue. A reconciliation of this change is posted to our website at investors.netapp.com. |  |  |  |  |  |  |  |  |  |  |  |  |
| Pathways Mix |  |
|  |  | % of Q3 FY’14 Revenue |  |  | % of Q2 FY’14 Revenue |  |  | % of Q3 FY’13 Revenue |  |
| Direct |  |  | 17 | % |  |  | 17 | % |  |  | 19 | % |
| Indirect |  |  | 83 | % |  |  | 83 | % |  |  | 81 | % |
| Indirect revenues include those sold through value-added resellers, system integrators, OEMs and distributors. |  |  |  |  |  |  |  |  |  |  |  |  |
| Direct revenues are those sold through our direct sales force. Direct / Indirect revenue mix reflects order fulfillment and not reflective of who is responsible for the customer relationship. |  |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY’14 |  |  | Q2 FY’14 |  |  | Q3 FY’13 |  |
| Non-GAAP Gross Margin |  |  | 63.5 | % |  |  | 63.6 | % |  |  | 60.4 | % |
| Product |  |  | 57.1 | % |  |  | 57.3 | % |  |  | 53.1 | % |
| Software Entitlements & Maintenance (SEM) |  |  | 96.6 | % |  |  | 96.8 | % |  |  | 96.8 | % |
| Service |  |  | 60.8 | % |  |  | 58.9 | % |  |  | 58.7 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY’14 |  |  | Q2 FY’14 |  |  | Q3 FY’13 |  |
| Non-GAAP Income from Operations |  | $ | 313.3 |  |  | $ | 270.5 |  |  | $ | 278.3 |  |
| % of Net Revenue |  |  | 19.5 | % |  |  | 17.5 | % |  |  | 17.1 | % |
| Non-GAAP Income before Income Taxes |  | $ | 316.2 |  |  | $ | 275.8 |  |  | $ | 280.8 |  |
| Non-GAAP Effective Tax Rate |  |  | 17.6 | % |  |  | 16.1 | % |  |  | 13.6 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY’14 |  |  | Q2 FY’14 |  |  | Q3 FY’13 |  |
| Non-GAAP Net Income |  | $ | 260.6 |  |  | $ | 231.5 |  |  | $ | 242.7 |  |
| Weighted Average Common Shares Outstanding, Diluted |  |  | 346.2 |  |  |  | 349.1 |  |  |  | 364.7 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 0.75 |  |  | $ | 0.66 |  |  | $ | 0.67 |  |
| Included in the diluted weighted average common shares outstanding are 0.1 million shares in Q3 FY'13 related to the impact |  |  |  |  |  |  |  |  |  |
| of our convertible notes. The convertible notes matured in Q1 FY'14, and thus had no impact on any other period presented. |  |  |  |  |  |  |  |  |  |  |  |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY’14 |  |  | Q2 FY’14 |  |  | Q3 FY’13 |  |
| Deferred Revenue |  | $ | 2,959.3 |  |  | $ | 2,931.9 |  |  | $ | 2,876.0 |  |
| DSO (days) |  |  | 33 |  |  |  | 35 |  |  |  | 35 |  |
| Inventory Turns |  |  | 20 |  |  |  | 20 |  |  |  | 15 |  |
| Days sales outstanding (DSO) is defined as accounts receivable, net divided by net revenues, multiplied by the number of days in the quarter. |  |  |  |  |  |  |  |  |  |
| Inventory turns is defined as annualized non-GAAP cost of revenues divided by net inventories. |  |  |  |  |  |  |  |  |  |  |  |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY’14 |  |  | Q2 FY’14 |  |  | Q3 FY’13 |  |
| Net Cash Provided by Operating Activities |  | $ | 331.8 |  |  | $ | 362.5 |  |  | $ | 365.1 |  |
| Purchases of Property and Equipment |  | $ | 57.9 |  |  | $ | 42.2 |  |  | $ | 110.7 |  |
| Free Cash Flow |  | $ | 273.9 |  |  | $ | 320.3 |  |  | $ | 254.4 |  |
| Free Cash Flow as % of Total Revenue |  |  | 17.0 | % |  |  | 20.7 | % |  |  | 15.6 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |  |  |  |  |  |  |  |  |  |  |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |

[0001102624-14-000200:8k_2_02:47]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| FINANCIAL STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |
|  |  | January 24, 2014 |  |  | October 25, 2013 |  |  | January 25, 2013 |  |
| NET INCOME |  | $ | 192.1 |  |  | $ | 166.8 |  |  | $ | 158.1 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.7 |  |  |  | 14.9 |  |  |  | 21.4 |  |
| Stock-based compensation |  |  | 71.9 |  |  |  | 67.6 |  |  |  | 67.3 |  |
| Restructuring and other charges |  |  | - |  |  |  | 1.1 |  |  |  | - |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | 1.7 |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | 15.3 |  |
| Gain on investments |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |
| Income tax effect of Non-GAAP adjustments |  |  | (18.1 | ) |  |  | (18.9 | ) |  |  | (20.4 | ) |
| NON-GAAP NET INCOME |  | $ | 260.6 |  |  | $ | 231.5 |  |  | $ | 242.7 |  |
| COST OF REVENUES |  | $ | 607.7 |  |  | $ | 584.7 |  |  | $ | 665.2 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14.2 | ) |  |  | (14.3 | ) |  |  | (13.9 | ) |
| Stock-based compensation |  |  | (6.1 | ) |  |  | (5.6 | ) |  |  | (6.2 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 587.4 |  |  | $ | 564.8 |  |  | $ | 645.1 |  |
| COST OF PRODUCT REVENUES |  | $ | 450.7 |  |  | $ | 423.3 |  |  | $ | 512.5 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (13.6 | ) |  |  | (13.8 | ) |  |  | (13.9 | ) |
| Stock-based compensation |  |  | (1.5 | ) |  |  | (1.4 | ) |  |  | (1.4 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 435.6 |  |  | $ | 408.1 |  |  | $ | 497.2 |  |
| COST OF SERVICE REVENUES |  | $ | 149.3 |  |  | $ | 153.9 |  |  | $ | 145.4 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.6 | ) |  |  | (0.5 | ) |  |  | - |  |
| Stock-based compensation |  |  | (4.6 | ) |  |  | (4.2 | ) |  |  | (4.8 | ) |
| NON-GAAP COST OF SERVICE REVENUES |  | $ | 144.1 |  |  | $ | 149.2 |  |  | $ | 140.6 |  |
| GROSS PROFIT |  | $ | 1,002.3 |  |  | $ | 965.2 |  |  | $ | 964.9 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.2 |  |  |  | 14.3 |  |  |  | 13.9 |  |
| Stock-based compensation |  |  | 6.1 |  |  |  | 5.6 |  |  |  | 6.2 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,022.6 |  |  | $ | 985.1 |  |  | $ | 985.0 |  |
| SALES AND MARKETING EXPENSES |  | $ | 475.9 |  |  | $ | 479.5 |  |  | $ | 493.5 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.5 | ) |  |  | (0.6 | ) |  |  | (7.5 | ) |
| Stock-based compensation |  |  | (33.0 | ) |  |  | (31.1 | ) |  |  | (31.9 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 442.4 |  |  | $ | 447.8 |  |  | $ | 454.1 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 230.3 |  |  | $ | 228.2 |  |  | $ | 215.6 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (23.6 | ) |  |  | (21.6 | ) |  |  | (20.8 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 206.7 |  |  | $ | 206.6 |  |  | $ | 194.8 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 69.4 |  |  | $ | 69.5 |  |  | $ | 66.2 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (9.2 | ) |  |  | (9.3 | ) |  |  | (8.4 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 60.2 |  |  | $ | 60.2 |  |  | $ | 57.8 |  |
| RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | 1.1 |  |  | $ | - |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  |  | - |  |  |  | (1.1 | ) |  |  | - |  |
| NON-GAAP RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| ACQUISITION-RELATED EXPENSE |  | $ | - |  |  | $ | - |  |  | $ | 1.7 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | (1.7 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| OPERATING EXPENSES |  | $ | 775.6 |  |  | $ | 778.3 |  |  | $ | 777.0 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (0.5 | ) |  |  | (0.6 | ) |  |  | (7.5 | ) |
| Stock-based compensation |  |  | (65.8 | ) |  |  | (62.0 | ) |  |  | (61.1 | ) |
| Restructuring and other charges |  |  | - |  |  |  | (1.1 | ) |  |  | - |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | (1.7 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 709.3 |  |  | $ | 714.6 |  |  | $ | 706.7 |  |
| INCOME FROM OPERATIONS |  | $ | 226.7 |  |  | $ | 186.9 |  |  | $ | 187.9 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.7 |  |  |  | 14.9 |  |  |  | 21.4 |  |
| Stock-based compensation |  |  | 71.9 |  |  |  | 67.6 |  |  |  | 67.3 |  |
| Restructuring and other charges |  |  | - |  |  |  | 1.1 |  |  |  | - |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | 1.7 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 313.3 |  |  | $ | 270.5 |  |  | $ | 278.3 |  |
| TOTAL OTHER INCOME (EXPENSE), NET |  | $ | 2.9 |  |  | $ | 5.3 |  |  | $ | (12.1 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | 15.3 |  |
| Gain on investments |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |
| NON-GAAP TOTAL OTHER INCOME, NET |  | $ | 2.9 |  |  | $ | 5.3 |  |  | $ | 2.5 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 229.6 |  |  | $ | 192.2 |  |  | $ | 175.8 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14.7 |  |  |  | 14.9 |  |  |  | 21.4 |  |
| Stock-based compensation |  |  | 71.9 |  |  |  | 67.6 |  |  |  | 67.3 |  |
| Restructuring and other charges |  |  | - |  |  |  | 1.1 |  |  |  | - |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | 1.7 |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | 15.3 |  |
| Gain on investments |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 316.2 |  |  | $ | 275.8 |  |  | $ | 280.8 |  |
| PROVISION FOR INCOME TAXES |  | $ | 37.5 |  |  | $ | 25.4 |  |  | $ | 17.7 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of Non-GAAP adjustments |  |  | 18.1 |  |  |  | 18.9 |  |  |  | 20.4 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 55.6 |  |  | $ | 44.3 |  |  | $ | 38.1 |  |
| NET INCOME PER SHARE |  | $ | 0.555 |  |  | $ | 0.478 |  |  | $ | 0.434 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.042 |  |  |  | 0.043 |  |  |  | 0.059 |  |
| Stock-based compensation |  |  | 0.208 |  |  |  | 0.194 |  |  |  | 0.184 |  |
| Restructuring and other charges |  |  | - |  |  |  | 0.002 |  |  |  | - |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | 0.005 |  |
| Non-cash interest expense |  |  | - |  |  |  | - |  |  |  | 0.042 |  |
| Gain on investments |  |  | - |  |  |  | - |  |  |  | (0.002 | ) |
| Income tax effect of Non-GAAP adjustments |  |  | (0.052 | ) |  |  | (0.054 | ) |  |  | (0.057 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.753 |  |  | $ | 0.663 |  |  | $ | 0.665 |  |

[0001102624-14-000200:8k_2_02:48]
|  | NETAPP, INC. |  |
|  | RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
|  | EXPRESSED AS EARNINGS PER SHARE |  |
|  | FOURTH QUARTER 2014 |  |
|  | (Unaudited) |  |
|  |  | Fourth Quarter |
|  |  | 2014 |
| Non-GAAP Guidance - Net Income Per Share |  | $0.77 - $0.82 |
| Adjustments of Specific Items to |  |  |
| Net Income Per Share for the Fourth |  |  |
| Quarter 2014: |  |  |
| Amortization of intangible assets |  | (0.04) |
| Stock-based compensation expense |  | (0.22) |
| Income tax effect |  | 0.06 |
| Total Adjustments |  | (0.20) |
| GAAP Guidance - Net Income Per Share |  | $0.57 - $0.62 |
