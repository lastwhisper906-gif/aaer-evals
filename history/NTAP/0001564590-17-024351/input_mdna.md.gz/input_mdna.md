# NTAP MD&A — 0001564590-17-024351


## mdna

[0001564590-17-024351:mdna:1]
[same as prior period, unchanged from 0001564590-17-018158:mdna:1]

[0001564590-17-024351:mdna:2]
23

[0001564590-17-024351:mdna:3]
[same as prior period, unchanged from 0001564590-17-018158:mdna:2]

[0001564590-17-024351:mdna:4]
[same as prior period, unchanged from 0001564590-17-018158:mdna:3]

[0001564590-17-024351:mdna:5]
[same as prior period, unchanged from 0001564590-17-018158:mdna:4]

[0001564590-17-024351:mdna:6]
[same as prior period, unchanged from 0001564590-17-018158:mdna:5]

[0001564590-17-024351:mdna:7]
[same as prior period, unchanged from 0001564590-17-018158:mdna:6]

[0001564590-17-024351:mdna:8]
[same as prior period, unchanged from 0001564590-17-018158:mdna:7]

[0001564590-17-024351:mdna:9]
[same as prior period, unchanged from 0001564590-17-018158:mdna:8]

[0001564590-17-024351:mdna:10]
[same as prior period, unchanged from 0001564590-17-018158:mdna:9]

[0001564590-17-024351:mdna:11]
[same as prior period, unchanged from 0001564590-17-018158:mdna:10]

[0001564590-17-024351:mdna:12]
[same as prior period, unchanged from 0001564590-17-018158:mdna:11]

[0001564590-17-024351:mdna:13]
[same as prior period, unchanged from 0001564590-17-018158:mdna:12]

[0001564590-17-024351:mdna:14]
[same as prior period, unchanged from 0001564590-17-018158:mdna:13]

[0001564590-17-024351:mdna:15]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Net revenues |  | $ | 1,422 |  |  | $ | 1,340 |  |  | $ | 2,747 |  |  | $ | 2,634 |  |
| Gross profit |  | $ | 902 |  |  | $ | 829 |  |  | $ | 1,736 |  |  | $ | 1,626 |  |
| Gross profit margin percentage |  |  | 63 | % |  |  | 62 | % |  |  | 63 | % |  |  | 62 | % |
| Income from operations |  | $ | 219 |  |  | $ | 142 |  |  | $ | 367 |  |  | $ | 235 |  |
| Income from operations as a percentage of net revenues |  |  | 15 | % |  |  | 11 | % |  |  | 13 | % |  |  | 9 | % |
| Net income |  | $ | 175 |  |  | $ | 109 |  |  | $ | 311 |  |  | $ | 173 |  |
| Diluted net income per share |  | $ | 0.64 |  |  | $ | 0.38 |  |  | $ | 1.12 |  |  | $ | 0.61 |  |
| Operating cash flows |  | $ | 314 |  |  | $ | 158 |  |  | $ | 564 |  |  | $ | 386 |  |

[0001564590-17-024351:mdna:16]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,167 |  |  | $ | 3,342 |  |
| Cash conversion cycle (days) |  |  | (10 | ) |  |  | 15 |  |

[0001564590-17-024351:mdna:17]
[same as prior period, unchanged from 0001564590-17-018158:mdna:16]

[0001564590-17-024351:mdna:18]
During the first six months of fiscal 2018, we repurchased 7 million shares of our common stock at an average price of $41.80 per share, for an aggregate of $300 million. We also declared cash dividends of an aggregate of $0.40 per share in that period, for which we paid an aggregate of $108 million.

[0001564590-17-024351:mdna:19]
Senior Notes Issuances and Redemption

[0001564590-17-024351:mdna:20]
In September 2017, we issued $400 million aggregate principal amount of 2.00% Senior Notes due on September 27, 2019 and $400 million aggregate principal amount of 3.30% Senior Notes due on September 29, 2024. The net proceeds will be used for general corporate purposes, including the repayment of our $750 million aggregate principal amount of 2.00% Senior Notes due December 2017.

[0001564590-17-024351:mdna:21]
On October 4, 2017, we issued a notice to redeem all our 2.00% Senior Notes due December 2017. On November 3, 2017, in the third quarter of fiscal 2018, the notes were extinguished through redemption for cash at an aggregate redemption price of $751 million, plus accrued and unpaid interest.

[0001564590-17-024351:mdna:22]
[same as prior period, unchanged from 0001564590-17-018158:mdna:18]

[0001564590-17-024351:mdna:23]
[same as prior period, unchanged from 0001564590-17-018158:mdna:19]

[0001564590-17-024351:mdna:24]
[same as prior period, unchanged from 0001564590-17-018158:mdna:20]

[0001564590-17-024351:mdna:25]
[same as prior period, unchanged from 0001564590-17-018158:mdna:21]

[0001564590-17-024351:mdna:26]
[same as prior period, unchanged from 0001564590-17-018158:mdna:22]

[0001564590-17-024351:mdna:27]
[same as prior period, unchanged from 0001564590-17-018158:mdna:23]

[0001564590-17-024351:mdna:28]
[same as prior period, unchanged from 0001564590-17-018158:mdna:24]

[0001564590-17-024351:mdna:29]
[same as prior period, unchanged from 0001564590-17-018158:mdna:26]

[0001564590-17-024351:mdna:30]
|  |  | Three Months Ended |  |  | Six Months Ended |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 57 |  | % |  | 53 |  | % |  | 56 |  | % |  | 52 |  | % |
| Software maintenance |  |  | 17 |  |  |  | 18 |  |  |  | 17 |  |  |  | 18 |  |  |
| Hardware maintenance and other services |  |  | 26 |  |  |  | 29 |  |  |  | 27 |  |  |  | 30 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 28 |  |  |  | 28 |  |  |  | 28 |  |  |  | 28 |  |  |
| Cost of software maintenance |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 8 |  |  |  | 10 |  |  |  | 8 |  |  |  | 10 |  |  |
| Gross profit |  |  | 63 |  |  |  | 62 |  |  |  | 63 |  |  |  | 62 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 30 |  |  |  | 31 |  |  |  | 31 |  |  |  | 32 |  |  |
| Research and development |  |  | 14 |  |  |  | 15 |  |  |  | 14 |  |  |  | 15 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |
| Total operating expenses |  |  | 48 |  |  |  | 51 |  |  |  | 50 |  |  |  | 53 |  |  |
| Income from operations |  |  | 15 |  |  |  | 11 |  |  |  | 13 |  |  |  | 9 |  |  |
| Other income (expense), net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Income before income taxes |  |  | 16 |  |  |  | 11 |  |  |  | 14 |  |  |  | 9 |  |  |
| Provision for income taxes |  |  | 4 |  |  |  | 2 |  |  |  | 2 |  |  |  | 2 |  |  |
| Net income |  |  | 12 |  | % |  | 8 |  | % |  | 11 |  | % |  | 7 |  | % |

[0001564590-17-024351:mdna:31]
[same as prior period, unchanged from 0001564590-17-018158:mdna:28]

[0001564590-17-024351:mdna:32]
[same as prior period, unchanged from 0001564590-17-018158:mdna:29]

[0001564590-17-024351:mdna:33]
[same as prior period, unchanged from 0001564590-17-018158:mdna:30]

[0001564590-17-024351:mdna:34]
Net revenues for the second quarter and first six months of fiscal 2018 were $1,422 million and $2,747 million, respectively, reflecting an increase of $82 million, or 6%, and $113 million, or 4%, respectively, compared to the corresponding periods of the prior year, reflecting higher product revenues, partially offset by lower hardware maintenance and other services revenues.

[0001564590-17-024351:mdna:35]
Gross profit as a percentage of net revenues for the second quarter and the first six months of fiscal 2018 increased by one and a half percentage points compared to the corresponding periods in fiscal 2017, reflecting higher margins on product revenues, partially offset by lower margins on software maintenance and hardware maintenance and other services revenues. Gross profit margins on product revenues increased three and a half percentage points in the second quarter of fiscal 2018 and three percentage points in the first six months of fiscal 2018 compared to the corresponding periods of fiscal 2017, primarily due to an increase in average selling price (ASP).

[0001564590-17-024351:mdna:36]
Sales and marketing, research and development, and general and administrative expenses for the second quarter and the first six months of fiscal 2018 totaled $683 million, or 48% of net revenues and $1,369 million, or 50% of net revenues, respectively, representing a decrease of three percentage points compared to the corresponding periods of fiscal 2017, primarily due to higher net revenues in the current year periods coupled with lower average headcount as a result of our restructuring plans and other cost reduction initiatives.

[0001564590-17-024351:mdna:37]
[same as prior period, unchanged from 0001564590-17-018158:mdna:53]

[0001564590-17-024351:mdna:38]
[same as prior period, unchanged from 0001564590-17-018158:mdna:34]

[0001564590-17-024351:mdna:39]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |
| Net revenues |  | $ | 1,422 |  |  | $ | 1,340 |  |  |  | 6 | % |  | $ | 2,747 |  |  | $ | 2,634 |  |  |  | 4 | % |

[0001564590-17-024351:mdna:40]
The increase in net revenues for the second quarter and first six months of fiscal 2018 compared to the corresponding periods of fiscal 2017 was primarily due to an increase in product revenues of $97 million and $160 million, respectively, partially offset by a decrease in hardware maintenance and other services revenues of $13 million and $38 million, respectively. Product revenues as a percentage of net revenues increased four percentage points in the second quarter and first six months of fiscal 2018 compared to the corresponding periods of fiscal 2017.

[0001564590-17-024351:mdna:41]
[same as prior period, unchanged from 0001564590-17-018158:mdna:37]

[0001564590-17-024351:mdna:42]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 23 | % |  |  | 23 | % |  |  | 21 | % |
| Tech Data Corporation (previously presented as Avnet, Inc.) |  |  | 19 | % |  |  | 20 | % |  |  | 20 | % |  |  | 20 | % |

[0001564590-17-024351:mdna:43]
[same as prior period, unchanged from 0001564590-17-018158:mdna:39]

[0001564590-17-024351:mdna:44]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |
| Product revenues |  | $ | 807 |  |  | $ | 710 |  |  |  | 14 | % |  | $ | 1,530 |  |  | $ | 1,370 |  |  |  | 12 | % |

[0001564590-17-024351:mdna:45]
[same as prior period, unchanged from 0001564590-17-018158:mdna:41]

[0001564590-17-024351:mdna:46]
Product revenues from strategic solutions represented 69% of product revenues in the second quarter and first six months of fiscal 2018, compared to 64% and 63% in the corresponding periods of the prior year. Product revenues from mature solutions represented 31% of product revenues in the second quarter and first six months of fiscal 2018, compared to 36% and 37% in the corresponding periods of the prior year.

[0001564590-17-024351:mdna:47]
Total product revenues from strategic solutions totaled $557 million in the second quarter of fiscal 2018 reflecting a 23% increase from $452 million in the second quarter of fiscal 2017. This increase was primarily due to a 9% increase in unit volume of Clustered ONTAP systems and an increase in ASP driven by sales of our All-Flash FAS products. Total product revenue from mature solutions totaled $250 million in the second quarter of fiscal 2018 reflecting a 3% decrease from $258 million in the second quarter of fiscal 2017. This decrease was primarily due to a 64% decrease in unit volume of 7-mode systems reflecting the movement of customer demand from older products to our newer products, and an 8% decrease in OEM revenues, partially offset by a 10% increase in add-on hardware, storage and related OS revenues.

[0001564590-17-024351:mdna:48]
Total product revenues from strategic solutions totaled $1,057 million in the first six months of fiscal 2018 reflecting a 22% increase from $863 million in the first six months of fiscal 2017. This increase was primarily due to a 9% increase in unit volume of Clustered ONTAP systems and an increase in ASP driven by sales of our All-Flash FAS products. Total product revenue from mature solutions totaled $473 million in the first six months of fiscal 2018 reflecting a 7% decrease from $507 million in the first six months of fiscal 2017. This decrease was primarily due to a 63% decrease in unit volume of 7-mode systems, and a 17% decrease in OEM revenues, partially offset by a 10% increase in add-on hardware, storage and related OS revenues.

[0001564590-17-024351:mdna:49]
[same as prior period, unchanged from 0001564590-17-018158:mdna:44]

[0001564590-17-024351:mdna:50]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 240 |  |  | $ | 242 |  |  |  | (1 | )% |  | $ | 474 |  |  | $ | 483 |  |  |  | (2 | )% |

[0001564590-17-024351:mdna:51]
[same as prior period, unchanged from 0001564590-17-018158:mdna:46]

[0001564590-17-024351:mdna:52]
[same as prior period, unchanged from 0001564590-17-018158:mdna:70]

[0001564590-17-024351:mdna:53]
[same as prior period, unchanged from 0001564590-17-018158:mdna:47]

[0001564590-17-024351:mdna:54]
[same as prior period, unchanged from 0001564590-17-018158:mdna:48]

[0001564590-17-024351:mdna:55]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 375 |  |  | $ | 388 |  |  |  | (3 | )% |  | $ | 743 |  |  | $ | 781 |  |  |  | (5 | )% |

[0001564590-17-024351:mdna:56]
[same as prior period, unchanged from 0001564590-17-018158:mdna:50]

[0001564590-17-024351:mdna:57]
Hardware maintenance contract revenues were $306 million and $604 million for the second quarter and first six months of fiscal 2018, respectively, compared to $316 million and $639 million for the corresponding periods of the prior year. The decreases in the current year were primarily due to lower contract renewal rates, and a decline in ASP on executed contracts.

[0001564590-17-024351:mdna:58]
Professional services and educational and training services revenues were $69 million and $139 million for the second quarter and first six months of fiscal 2018, respectively, compared to $72 million and $142 million for the corresponding periods of the prior year.

[0001564590-17-024351:mdna:59]
[same as prior period, unchanged from 0001564590-17-018158:mdna:54]

[0001564590-17-024351:mdna:60]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| United States, Canada and Latin America (Americas) |  |  | 56 | % |  |  | 57 | % |  |  | 55 | % |  |  | 57 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 30 | % |  |  | 30 | % |  |  | 30 | % |  |  | 30 | % |
| Asia Pacific (APAC) |  |  | 14 | % |  |  | 13 | % |  |  | 14 | % |  |  | 13 | % |

[0001564590-17-024351:mdna:61]
[same as prior period, unchanged from 0001564590-17-018158:mdna:56]

[0001564590-17-024351:mdna:62]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Our percentage of net revenues from the Americas decreased in the second quarter and first six months of fiscal 2018 compared to the corresponding periods of fiscal 2017 due to a decrease in revenues from the Americas commercial market.

[0001564590-17-024351:mdna:63]
[same as prior period, unchanged from 0001564590-17-018158:mdna:58]

[0001564590-17-024351:mdna:64]
[same as prior period, unchanged from 0001564590-17-018158:mdna:59]

[0001564590-17-024351:mdna:65]
[same as prior period, unchanged from 0001564590-17-018158:mdna:60]

[0001564590-17-024351:mdna:66]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |
| Cost of product revenues |  | $ | 399 |  |  | $ | 376 |  |  |  | 6 | % |  | $ | 770 |  |  | $ | 735 |  |  |  | 5 | % |

[0001564590-17-024351:mdna:67]
[same as prior period, unchanged from 0001564590-17-018158:mdna:62]

[0001564590-17-024351:mdna:68]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2018 to Fiscal 2017 |  |  | Fiscal 2018 to Fiscal 2017 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | 5 |  |  |  | 3 |  |
| Excess and obsolete inventory |  |  | — |  |  |  | 1 |  |
| Other |  |  | 1 |  |  |  | 1 |  |
| Total change |  |  | 6 |  |  |  | 5 |  |

[0001564590-17-024351:mdna:69]
[same as prior period, unchanged from 0001564590-17-018158:mdna:86]

[0001564590-17-024351:mdna:70]
Cost of product revenues represented 49% and 50% of product revenues for the second quarter and first six months of fiscal 2018, respectively, compared to 53% and 54% for the second quarter and first six months of fiscal 2017, respectively. Materials costs represented 91% and 90% of product costs for the second quarter and first six months of fiscal 2018, respectively, compared to 92% and 91% in the second quarter and first six months of fiscal 2017, respectively.

[0001564590-17-024351:mdna:71]
Materials costs increased $18 million and $20 million in the second quarter and first six months of fiscal 2018, respectively, compared to the corresponding periods of the prior year, primarily due to higher overall unit volume.

[0001564590-17-024351:mdna:72]
Average unit materials costs for Clustered ONTAP systems were relatively consistent in the second quarter and first six months of fiscal 2018 compared to the corresponding periods of the prior year.

[0001564590-17-024351:mdna:73]
An increase in ASP for strategic systems resulted in higher margins for strategic products in the second quarter and first six months of fiscal 2018 compared to the second quarter and first six months of fiscal 2017. Average unit materials costs for 7-mode systems were relatively consistent across all periods, while ASP increased slightly, resulting in slightly higher margins for mature products in the second quarter and first six months of fiscal 2018.

[0001564590-17-024351:mdna:74]
Cost of product revenues in the first six months of fiscal 2018 compared to the first six months of fiscal 2017 were unfavorably impacted by a $7 million increase in charges for excess and obsolete inventory, primarily as a result of our transition to new product platforms.

[0001564590-17-024351:mdna:75]
[same as prior period, unchanged from 0001564590-17-018158:mdna:68]

[0001564590-17-024351:mdna:76]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 6 |  |  | $ | 7 |  |  |  | (14 | )% |  | $ | 13 |  |  | $ | 15 |  |  |  | (13 | )% |

[0001564590-17-024351:mdna:77]
Cost of software maintenance revenues was relatively flat in the second quarter and first six months of fiscal 2018 compared to the corresponding periods of fiscal 2017 and represented 3% of software maintenance revenues for all periods presented.

[0001564590-17-024351:mdna:78]
[same as prior period, unchanged from 0001564590-17-018158:mdna:72]

[0001564590-17-024351:mdna:79]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 115 |  |  | $ | 128 |  |  |  | (10 | )% |  | $ | 228 |  |  | $ | 258 |  |  |  | (12 | )% |

[0001564590-17-024351:mdna:80]
Cost of hardware maintenance and other services revenues decreased $13 million, or 10%, for the second quarter of fiscal 2018 compared to the second quarter of fiscal 2017, and decreased $30 million, or 12%, for the first six months of fiscal 2018 compared to the first six months of fiscal 2017, primarily due to the favorable impact of cost savings initiatives. Costs represented 31% of hardware maintenance and other services revenues in the second quarter and first six months of fiscal 2018, compared to 33% in the second quarter and first six months of fiscal 2017.

[0001564590-17-024351:mdna:81]
[same as prior period, unchanged from 0001564590-17-018158:mdna:75]

[0001564590-17-024351:mdna:82]
[same as prior period, unchanged from 0001564590-17-018158:mdna:76]

[0001564590-17-024351:mdna:83]
[same as prior period, unchanged from 0001564590-17-018158:mdna:77]

[0001564590-17-024351:mdna:84]
Total compensation costs included in operating expenses decreased by $13 million, or 3% in the second quarter of fiscal 2018 compared to the corresponding period in the prior year primarily due to lower salaries, benefits and stock-based compensation expenses, reflecting a 3% decrease in average headcount as a result of cost reduction initiatives, partially offset by higher incentive compensation expense, reflecting stronger operating performance against goals.

[0001564590-17-024351:mdna:85]
Total compensation costs included in operating expenses decreased by $32 million, or 4% in the first six months of fiscal 2018 compared to the corresponding period in the prior year primarily due to lower salaries, benefits and stock-based compensation expenses, reflecting a 5% decrease in average headcount as a result of cost reduction initiatives, partially offset by higher incentive compensation expense, reflecting stronger operating performance against goals.

[0001564590-17-024351:mdna:86]
29

[0001564590-17-024351:mdna:87]
[same as prior period, unchanged from 0001564590-17-018158:mdna:79]

[0001564590-17-024351:mdna:88]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 420 |  |  | $ | 418 |  |  |  | — | % |  | $ | 845 |  |  | $ | 847 |  |  |  | — | % |

[0001564590-17-024351:mdna:89]
[same as prior period, unchanged from 0001564590-17-018158:mdna:81]

[0001564590-17-024351:mdna:90]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2018 to Fiscal 2017 |  |  | Fiscal 2018 to Fiscal 2017 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Commissions |  |  | 1 |  |  |  | — |  |
| Advertising and marketing promotional expense |  |  | 1 |  |  |  | 2 |  |
| Facilities and IT support costs |  |  | (1 | ) |  |  | (1 | ) |
| Other |  |  | (1 | ) |  |  | (1 | ) |
| Total change |  |  | — |  |  |  | — |  |

[0001564590-17-024351:mdna:91]
Compensation costs and average headcount were relatively flat for the second quarter and first six months of fiscal 2018 compared to the corresponding periods of the prior year. The increase in advertising and marketing promotional expense was primarily due to higher spending levels on marketing activities for new products in the second quarter and the first six months of fiscal 2018. Facilities and IT support costs decreased during the second quarter and the first six months of fiscal 2018 from the corresponding periods in the prior year primarily due to cost containment efforts and certain internal-use software becoming fully amortized by the end of fiscal 2017.

[0001564590-17-024351:mdna:92]
[same as prior period, unchanged from 0001564590-17-018158:mdna:84]

[0001564590-17-024351:mdna:93]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |
| Research and development expenses |  | $ | 194 |  |  | $ | 200 |  |  |  | (3 | )% |  | $ | 387 |  |  | $ | 407 |  |  |  | (5 | )% |

[0001564590-17-024351:mdna:94]
[same as prior period, unchanged from 0001564590-17-018158:mdna:87]

[0001564590-17-024351:mdna:95]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2018 to Fiscal 2017 |  |  | Fiscal 2018 to Fiscal 2017 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (3 | ) |  |  | (4 | ) |
| Depreciation |  |  | (1 | ) |  |  | (1 | ) |
| Facilities and IT support costs |  |  | (1 | ) |  |  | (1 | ) |
| Other |  |  | 2 |  |  |  | 1 |  |
| Total change |  |  | (3 | ) |  |  | (5 | ) |

[0001564590-17-024351:mdna:96]
Compensation costs for the second quarter and the first six months of fiscal 2018 were favorably impacted by lower salaries, benefits and stock-based compensation expenses compared to the corresponding periods of the prior year due to a decrease in average headcount of 4% and 7%, respectively, partially offset by higher incentive compensation expense. Depreciation expense decreased primarily due to certain equipment becoming fully depreciated by the end of fiscal 2017, and facilities and IT support costs decreased primarily due to cost containment efforts.

[0001564590-17-024351:mdna:97]
[same as prior period, unchanged from 0001564590-17-018158:mdna:90]

[0001564590-17-024351:mdna:98]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |
| General and administrative expenses |  | $ | 69 |  |  | $ | 69 |  |  |  | — | % |  | $ | 137 |  |  | $ | 137 |  |  |  | — | % |

[0001564590-17-024351:mdna:99]
[same as prior period, unchanged from 0001564590-17-018158:mdna:116]

[0001564590-17-024351:mdna:100]
[same as prior period, unchanged from 0001564590-17-018158:mdna:92]

[0001564590-17-024351:mdna:101]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2018 to Fiscal 2017 |  |  | Fiscal 2018 to Fiscal 2017 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (7 | ) |  |  | (8 | ) |
| Professional and legal fees and outside services |  |  | 4 |  |  |  | 4 |  |
| Facilities and IT support costs |  |  | 2 |  |  |  | 3 |  |
| Other |  |  | 1 |  |  |  | 1 |  |
| Total change |  |  | — |  |  |  | — |  |

[0001564590-17-024351:mdna:102]
Compensation costs for the second quarter and the first six months of fiscal 2018 were favorably impacted by lower salaries, benefits and stock-based compensation expenses compared to the corresponding periods of fiscal 2017 due to a decrease in average headcount of 12% and 13%, respectively, partially offset by higher incentive compensation expense. The increase in professional and legal fees and outside services expense in the second quarter and first six months of fiscal 2018 was primarily due to higher spending levels on projects and outside services, while the increase in facilities and IT support costs was primarily due to an increase in spending on IT projects.

[0001564590-17-024351:mdna:103]
[same as prior period, unchanged from 0001564590-17-018158:mdna:95]

[0001564590-17-024351:mdna:104]
[same as prior period, unchanged from 0001564590-17-018158:mdna:96]

[0001564590-17-024351:mdna:105]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |
| Interest income |  | $ | 19 |  |  | $ | 10 |  |  |  | 90 | % |  | $ | 35 |  |  | $ | 21 |  |  |  | 67 | % |
| Interest expense |  |  | (17 | ) |  |  | (12 | ) |  |  | 42 | % |  |  | (30 | ) |  |  | (27 | ) |  |  | 11 | % |
| Other income, net |  |  | 4 |  |  |  | 2 |  |  |  | 100 | % |  |  | 6 |  |  |  | 5 |  |  |  | 20 | % |
| Total |  | $ | 6 |  |  | $ | — |  |  | NM |  |  | $ | 11 |  |  | $ | (1 | ) |  | NM |  |

[0001564590-17-024351:mdna:106]
[same as prior period, unchanged from 0001564590-17-018158:mdna:98]

[0001564590-17-024351:mdna:107]
Interest income increased in the second quarter and the first six months of fiscal 2018 compared to the corresponding periods of the prior year, primarily due to a shift in our investment portfolio to higher-yielding investments.

[0001564590-17-024351:mdna:108]
Interest expense increased in the second quarter and the first six months of fiscal 2018 primarily as a result of our commercial paper program, which began in the third quarter of fiscal 2017, and the issuance of $800 million aggregate principal amount of Senior Notes in September 2017.

[0001564590-17-024351:mdna:109]
[same as prior period, unchanged from 0001564590-17-018158:mdna:101]

[0001564590-17-024351:mdna:110]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | % Change |  |
| Provision for income taxes |  | $ | 50 |  |  | $ | 33 |  |  |  | 52 | % |  | $ | 67 |  |  | $ | 61 |  |  |  | 10 | % |

[0001564590-17-024351:mdna:111]
Our effective tax rate for the second quarter of fiscal 2018 was 22.2% compared to an effective tax rate of 23.2% for the second quarter of fiscal 2017. Our effective tax rate for the first six months of fiscal 2018 was 17.7% compared to an effective tax rate of 26.1% for the corresponding period of fiscal 2017. Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations which are headquartered in the Netherlands, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rate decreased for the second quarter and first six months of fiscal 2018 compared to the corresponding periods in the prior year, primarily as a result of differences in discrete impacts related to stock-based compensation and differences in the respective periods’ income before taxes.

[0001564590-17-024351:mdna:112]
As of October 27, 2017, we had $222 million of gross unrecognized tax benefits, of which $157 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $163 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-17-024351:mdna:113]
[same as prior period, unchanged from 0001564590-17-018158:mdna:105]

[0001564590-17-024351:mdna:114]
31

[0001564590-17-024351:mdna:115]
[same as prior period, unchanged from 0001564590-17-018158:mdna:106]

[0001564590-17-024351:mdna:116]
| (In millions, except percentages) |  | October 27, 2017 |  |  | April 28, 2017 |  |
| Cash, cash equivalents and short-term investments |  | $ | 5,965 |  |  | $ | 4,921 |  |
| Principal amount of debt |  | $ | 3,019 |  |  | $ | 2,000 |  |
| Debt as a percentage of stockholders' equity |  |  | 109 | % |  |  | 72 | % |

[0001564590-17-024351:mdna:117]
[same as prior period, unchanged from 0001564590-17-018158:mdna:108]

[0001564590-17-024351:mdna:118]
|  |  | Six Months Ended |  |
| (In millions) |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Net cash provided by operating activities |  | $ | 564 |  |  | $ | 386 |  |
| Net cash provided by (used in) investing activities |  |  | (87 | ) |  |  | 97 |  |
| Net cash provided by (used in) financing activities |  |  | 601 |  |  |  | (1,225 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 13 |  |  |  | (13 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 1,091 |  |  | $ | (755 | ) |

[0001564590-17-024351:mdna:119]
[same as prior period, unchanged from 0001564590-17-018158:mdna:110]

[0001564590-17-024351:mdna:120]
As of October 27, 2017, our cash, cash equivalents and short-term investments were $6.0 billion, an increase of $1.0 billion from April 28, 2017. The increase was primarily due to $795 million of net proceeds from the issuance of long-term debt, $218 million in proceeds from the issuance of commercial paper notes, net of repayments, and $564 million of cash provided by operating activities, partially offset by $300 million paid for the repurchase of our common stock and $108 million used for the payment of dividends. Working capital increased by $730 million to $2.8 billion as of October 27, 2017 compared to April 28, 2017 primarily due to an increase in cash and cash equivalents that was largely attributable to the issuance of long-term debt in September 2017, partially offset by a decrease in accounts receivable and an increase in the balance of outstanding commercial paper notes.

[0001564590-17-024351:mdna:121]
[same as prior period, unchanged from 0001564590-17-018158:mdna:112]

[0001564590-17-024351:mdna:122]
[same as prior period, unchanged from 0001564590-17-018158:mdna:113]

[0001564590-17-024351:mdna:123]
|  |  | Three Months Ended |  |
| (In days) |  | October 27, 2017 |  |  | April 28, 2017 |  |  | October 28, 2016 |  |
| Days sales outstanding (1) |  |  | 37 |  |  |  | 45 |  |  |  | 37 |  |
| Days inventory outstanding (2) |  |  | 19 |  |  |  | 26 |  |  |  | 17 |  |
| Days payables outstanding (3) |  |  | (66 | ) |  |  | (56 | ) |  |  | (45 | ) |
| Cash conversion cycle (4) |  |  | (10 | ) |  |  | 15 |  |  |  | 9 |  |

[0001564590-17-024351:mdna:124]
[same as prior period, unchanged from 0001564590-17-018158:mdna:115]

[0001564590-17-024351:mdna:125]
| (1) | Days sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on ending accounts receivable and net revenue for each period. DSO is calculated by dividing accounts receivable by average net revenue per day for the current quarter (91 days for each of the quarters presented above). The decrease in DSO for the second quarter of fiscal 2018 compared to the fourth quarter of fiscal 2017 was due to seasonal patterns of shipping linearity. |

[0001564590-17-024351:mdna:126]
| (2) | Days inventory outstanding, referred to as DIO, measures the average number of days from procurement to sale of our products. DIO is based on ending inventory and cost of revenues for each period. DIO is calculated by dividing ending inventory by average cost of revenues per day for the current quarter. DIO for the second quarter of fiscal 2018 decreased compared to the fourth quarter of fiscal 2017 due to lower levels of purchased components, primarily solid state drives, on hand at the end of the current quarter. |

[0001564590-17-024351:mdna:127]
| (3) | Days payables outstanding, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and cost of revenues for each period. DPO is calculated by dividing accounts payable by average cost of revenues per day for the current quarter. DPO for the second quarter of fiscal 2018 increased compared to the fourth and second quarters of fiscal 2017, primarily as a result of improved vendor payables management and an extension of payment terms with our suppliers. |

[0001564590-17-024351:mdna:128]
[same as prior period, unchanged from 0001564590-17-018158:mdna:120]

[0001564590-17-024351:mdna:129]
[same as prior period, unchanged from 0001564590-17-018158:mdna:121]

[0001564590-17-024351:mdna:130]
During the first six months of fiscal 2018, we generated cash from operating activities of $564 million, reflecting net income of $311 million, adjusted by non-cash depreciation and amortization of $102 million and stock-based compensation of $87 million, compared to $386 million of cash generated from operating activities during the first six months of fiscal 2017.

[0001564590-17-024351:mdna:131]
[same as prior period, unchanged from 0001564590-17-018158:mdna:147]

[0001564590-17-024351:mdna:132]
Changes in assets and liabilities in the first six months of fiscal 2018 included the following:

[0001564590-17-024351:mdna:133]
|  | • | Accounts receivable decreased $149 million, primarily due to lower seasonal invoicing levels in the second quarter of fiscal 2018 compared to the fourth quarter of fiscal 2017. |

[0001564590-17-024351:mdna:134]
|  | • | Deferred revenue and financed unearned services revenue decreased $183 million, primarily due to a decrease in deferred software and hardware maintenance contract revenues reflecting lower contract renewal rates and a decline in ASP on executed contracts. |

[0001564590-17-024351:mdna:135]
[same as prior period, unchanged from 0001564590-17-018158:mdna:127]

[0001564590-17-024351:mdna:136]
[same as prior period, unchanged from 0001564590-17-018158:mdna:128]

[0001564590-17-024351:mdna:137]
During the first six months of fiscal 2018, we generated $48 million from maturities and sales of investments, net of purchases, and paid $65 million for capital expenditures compared to $190 million and $92 million, respectively, during the first six months of fiscal 2017. We also paid $75 million to acquire two privately-held companies in the first six months of fiscal 2018.

[0001564590-17-024351:mdna:138]
[same as prior period, unchanged from 0001564590-17-018158:mdna:130]

[0001564590-17-024351:mdna:139]
During the first six months of fiscal 2018, we generated $795 million in cash from the issuance of long-term debt, $218 million in cash from issuances of commercial paper notes, net of repayments, and used $300 million for the repurchase of 7 million shares of our common stock and $108 million for the payment of dividends, compared to $850 million used to repay our short-term loan, $292 million used for the repurchase of common stock and $105 million for the payment of dividends during the first six months of fiscal 2017.

[0001564590-17-024351:mdna:140]
[same as prior period, unchanged from 0001564590-17-018158:mdna:132]

[0001564590-17-024351:mdna:141]
[same as prior period, unchanged from 0001564590-17-018158:mdna:133]

[0001564590-17-024351:mdna:142]
Our principal sources of liquidity as of October 27, 2017 consisted of cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001564590-17-024351:mdna:143]
[same as prior period, unchanged from 0001564590-17-018158:mdna:135]

[0001564590-17-024351:mdna:144]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
| Cash and cash equivalents |  | $ | 3,535 |  |  | $ | 2,444 |  |
| Short-term investments |  |  | 2,430 |  |  |  | 2,477 |  |
| Total |  | $ | 5,965 |  |  | $ | 4,921 |  |

[0001564590-17-024351:mdna:145]
As of October 27, 2017 and April 28, 2017, $5.0 billion and $4.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $1.0 billion and $0.4 billion, respectively, were available in the U.S. at the end of each period. Most of the amounts held outside the U.S. can be repatriated to the U.S. but, under current law, would be subject to U.S. federal, state income and foreign withholding taxes. If we were to repatriate foreign earnings to fund cash requirements in the U.S., we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state tax credit carryforwards. However, our intent is to keep these funds indefinitely reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies, and service interest and principal payments on our debt.

[0001564590-17-024351:mdna:146]
[same as prior period, unchanged from 0001564590-17-018158:mdna:165]

[0001564590-17-024351:mdna:147]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of October 27, 2017.

[0001564590-17-024351:mdna:148]
[same as prior period, unchanged from 0001564590-17-018158:mdna:139]

[0001564590-17-024351:mdna:149]
[same as prior period, unchanged from 0001564590-17-018158:mdna:140]

[0001564590-17-024351:mdna:150]
The following table summarizes the principal amount of our Senior Notes as of October 27, 2017 (in millions):

[0001564590-17-024351:mdna:151]
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |
| 2.00% Senior Notes Due September 2019 |  |  | 400 |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| Total |  | $ | 2,300 |  |

[0001564590-17-024351:mdna:152]
On October 4, 2017, we issued a notice to redeem all our 2.00% Senior Notes due December 2017. On November 3, 2017, in the third quarter of fiscal 2018, the notes were extinguished through redemption for cash at an aggregate redemption price of $751 million, plus accrued and unpaid interest.

[0001564590-17-024351:mdna:153]
[same as prior period, unchanged from 0001564590-17-018158:mdna:143]

[0001564590-17-024351:mdna:154]
Commercial Paper Program and Credit Facility

[0001564590-17-024351:mdna:155]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. On July 17, 2017 we amended the Program to increase the maximum amounts available that may be borrowed, repaid and re-borrowed to an aggregate face or principal amount of the notes outstanding of $1.0 billion, as compared to $600 million prior to the amendment. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of October 27, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $719 million, a weighted-average interest rate of 1.43% and maturities ranging from 13 days to 44 days.

[0001564590-17-024351:mdna:156]
In connection with the Program, we have a senior unsecured credit agreement that expires on December 10, 2021. The credit agreement, which was amended on July 17, 2017 provides a $1.0 billion revolving unsecured credit facility that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes, providing another potential source of liquidity to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement also includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of October 27, 2017, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-17-024351:mdna:157]
[same as prior period, unchanged from 0001564590-17-018158:mdna:149]

[0001564590-17-024351:mdna:158]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2018 to be between $75 million and $125 million.

[0001564590-17-024351:mdna:159]
[same as prior period, unchanged from 0001564590-17-018158:mdna:151]

[0001564590-17-024351:mdna:160]
On November 15, 2017, we declared a cash dividend of $0.20 per share of common stock, payable on January 24, 2018 to holders of record as of the close of business on January 5, 2018.

[0001564590-17-024351:mdna:161]
Our Board of Directors had authorized the repurchase of up to $9.6 billion of our common stock under our stock repurchase program. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through October 27, 2017, we repurchased a total of 276 million shares of our common stock at an average price of $33.07 per share, for an aggregate purchase price of $9.1 billion. As of October 27, 2017, the remaining authorized amount for stock repurchases under this program was $0.5 billion, with no termination date, which we plan to complete by May 2018.

[0001564590-17-024351:mdna:162]
[same as prior period, unchanged from 0001564590-17-018158:mdna:154]

[0001564590-17-024351:mdna:163]
[same as prior period, unchanged from 0001564590-17-018158:mdna:155]

[0001564590-17-024351:mdna:164]
[same as prior period, unchanged from 0001564590-17-018158:mdna:156]

[0001564590-17-024351:mdna:165]
As of October 27, 2017, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $203 million.

[0001564590-17-024351:mdna:166]
[same as prior period, unchanged from 0001564590-17-018158:mdna:158]

[0001564590-17-024351:mdna:167]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 27, 2017, we had $347 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-17-024351:mdna:168]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of October 27, 2017, we had $31 million in construction related obligations and $199 million in other purchase obligations.

[0001564590-17-024351:mdna:169]
[same as prior period, unchanged from 0001564590-17-018158:mdna:161]

[0001564590-17-024351:mdna:170]
As of October 27, 2017, our liability for uncertain tax positions was $150 million, including interest, penalties and offsetting indirect benefits. Due to the uncertainty of the timing of future cash payments, we cannot make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-17-024351:mdna:171]
[same as prior period, unchanged from 0001564590-17-018158:mdna:163]

[0001564590-17-024351:mdna:172]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, until such time as the related leases are terminated, the assets will remain on our condensed consolidated balance sheets, and proceeds received by us from these transactions are reported as financing obligations. As of October 27, 2017, the balance of the remaining financing obligations, which relate to properties whose leases we expect to terminate in December 2017, was $130 million. At the end of the leaseback period, or when our continuing involvement under the leaseback agreement ends, this transaction will be reported as a non-cash sale and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain.

[0001564590-17-024351:mdna:173]
[same as prior period, unchanged from 0001564590-17-018158:mdna:167]

[0001564590-17-024351:mdna:174]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these

[0001564590-17-024351:mdna:175]
35

[0001564590-17-024351:mdna:176]
arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $66 million and $108 million of receivables during the first six months of fiscal 2018 and fiscal 2017, respectively.

[0001564590-17-024351:mdna:177]
[same as prior period, unchanged from 0001564590-17-018158:mdna:169]

[0001564590-17-024351:mdna:178]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of October 27, 2017 and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-17-024351:mdna:179]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of October 27, 2017, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-17-024351:mdna:180]
[same as prior period, unchanged from 0001564590-17-018158:mdna:172]

[0001564590-17-024351:mdna:181]
[same as prior period, unchanged from 0001564590-17-018158:mdna:173]

[0001564590-17-024351:mdna:182]
Legal Contingencies

[0001564590-17-024351:mdna:183]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 16 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.
