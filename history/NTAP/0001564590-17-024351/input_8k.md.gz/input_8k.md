# NTAP 8-K — 0001564590-17-023882 filed 2017-11-15

## item codes, every 8-K on or before 2017-11-29

- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2017-11-29

- none on or before 2017-11-29

## item 2.02 — earnings release, exhibit 99.1

[0001564590-17-023882:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-17-023882:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-17-023882:8k_2_02:3]
Exhibit 99.1

[0001564590-17-023882:8k_2_02:4]
NetApp Reports Second Quarter Fiscal Year 2018 Results

[0001564590-17-023882:8k_2_02:5]
Net Revenues of $1.42 Billion Grew 6% Year-over-Year

[0001564590-17-023882:8k_2_02:6]
Second Quarter Fiscal 2018 Highlights

[0001564590-17-023882:8k_2_02:7]
| • | Product revenue increased 14% year-over-year |  |

[0001564590-17-023882:8k_2_02:8]
| • | All-flash array annualized net revenue run rate of $1.7 billion increased 58% year-over-year |  |

[0001564590-17-023882:8k_2_02:9]
| • | GAAP EPS of $0.64 and non-GAAP EPS of $0.81 increased 68% and 35% year-over-year, respectively |  |

[0001564590-17-023882:8k_2_02:10]
Sunnyvale, Calif.—November 15, 2017—NetApp (NASDAQ: NTAP) today reported financial results for the second quarter fiscal year 2018, ended October 27, 2017.

[0001564590-17-023882:8k_2_02:11]
“In the second quarter, NetApp again delivered strong operating results on the top and bottom lines. We also introduced a number of industry-leading innovations that position us for continued growth and expand our leadership position in the growth segments of the market,” said George Kurian, chief executive officer. “Our strong performance was driven by excellent execution and reflects our customers’ clear and growing preference for the value of our Data Fabric strategy. We are winning because we enable our customers’ success through data.”

[0001564590-17-023882:8k_2_02:12]
Second Quarter Fiscal 2018 Financial Results

[0001564590-17-023882:8k_2_02:13]
| • | Net Revenues: $1.42 billion, increased 6% year-over-year from $1.34 billion in the second quarter of fiscal 2017 |  |

[0001564590-17-023882:8k_2_02:14]
| • | Net Income: GAAP net income of $175 million, compared to GAAP net income of $109 million in the second quarter of fiscal 2017; non-GAAP net income1 of $223 million, compared to non-GAAP net income of $169 million in the second quarter of fiscal 2017 |  |

[0001564590-17-023882:8k_2_02:15]
| • | Earnings per Share: GAAP earnings per share2 of $0.64, compared to GAAP earnings per share of $0.38 in the second quarter of fiscal 2017; non-GAAP earnings per share of $0.81, compared to non-GAAP earnings per share of $0.60 in the second quarter of fiscal 2017 |  |

[0001564590-17-023882:8k_2_02:16]
| • | Cash, Cash Equivalents and Investments: $6.0 billion at the end of the second quarter fiscal year 2018 |  |

[0001564590-17-023882:8k_2_02:17]
| • | Cash from Operations: $314 million, compared to $158 million in the second quarter of fiscal 2017 |  |

[0001564590-17-023882:8k_2_02:18]
| • | Share Repurchase and Dividend: Returned $204 million to shareholders through share repurchases and a cash dividend |  |

[0001564590-17-023882:8k_2_02:19]
Third Quarter Fiscal 2018 Financial Outlook

[0001564590-17-023882:8k_2_02:20]
The Company provided the following financial guidance for the third quarter of fiscal year 2018:

[0001564590-17-023882:8k_2_02:21]
| • | Net revenues are expected to be in the range of $1.425 billion to $1.575 billion |  |

[0001564590-17-023882:8k_2_02:22]
|  | GAAP | Non-GAAP |
| •Earnings per share is expected to be in the range of: | $1.18–$1.26* | $0.86–$0.94 |

[0001564590-17-023882:8k_2_02:23]
* GAAP earnings per share includes an expected $0.50 per share benefit, after tax, from gains on the sale of certain properties.

[0001564590-17-023882:8k_2_02:24]
Dividend

[0001564590-17-023882:8k_2_02:25]
| • | Next cash dividend of $0.20 per share to be paid on January 24, 2018, to shareholders of record as of the close of business on January 5, 2018. |  |

[0001564590-17-023882:8k_2_02:26]
Second Quarter Fiscal 2018 Business Highlights

[0001564590-17-023882:8k_2_02:27]
New Solutions Expand NetApp Impact in Flash, Next-Generation Data Center, and Cloud

[0001564590-17-023882:8k_2_02:28]
| • | NetApp™ EF570 all-flash system is the storage industry’s price/performance leader as demonstrated by SPC-1 and SPC-2 benchmark tests.3 |  |

[0001564590-17-023882:8k_2_02:29]
| • | NetApp E5700 Series hybrid flash system accelerates performance and increases density with a hybrid flash system optimal for modern enterprise applications. |  |

[0001564590-17-023882:8k_2_02:30]
| • | NetApp SANtricity™ Cloud Connector enables Data Fabric capabilities by providing cost-effective backup and recovery to the cloud from NetApp E-Series and EF-Series systems. |  |

[0001564590-17-023882:8k_2_02:31]
| • | NetApp SANtricity 11.4 software now comes with security enhancements such as role-based access control and audit log, Active Directory support, and an external key manager. |  |

[0001564590-17-023882:8k_2_02:32]
| • | NetApp Converged Infrastructure Solution for Data Analytics brings together the latest storage, networking, and server technologies to help simplify deployment of data analytics environments. |  |

[0001564590-17-023882:8k_2_02:33]
| • | NetApp introduces new AI-enabled virtual support assistant, Elio, and Active IQ™ cloud-based analytics to help companies gain intelligent insights. |  |

[0001564590-17-023882:8k_2_02:34]
| • | NetApp expands collaboration with Microsoft Azure to deliver the industry's first Azure enterprise NFS service. |  |

[0001564590-17-023882:8k_2_02:35]
| • | NetApp SolidFire™ Element™ OS 10 supports data movement from Element OS systems to ONTAP™ systems across the Data Fabric and helps customers align IT service levels to business goals. |  |

[0001564590-17-023882:8k_2_02:36]
| • | NetApp HCI, built on SolidFire Element OS, the world’s first enterprise-scale hyper converged solution, became generally available in October 2017. |  |

[0001564590-17-023882:8k_2_02:37]
| • | StorageGRID™ Webscale 11 simplifies the creation of next-generation data center cloud architecture by enabling easy implementation of hybrid cloud data pipelines with AWS. |  |

[0001564590-17-023882:8k_2_02:38]
| • | NetApp ONTAP 9.3 software offers 40% increased performance over earlier versions, further optimizes deduplication, and enhances security and compliance. |  |

[0001564590-17-023882:8k_2_02:39]
| • | OnCommand™ Insight updated with new cloud cost monitoring provides a complete picture of IT infrastructure. |  |

[0001564590-17-023882:8k_2_02:40]
NetApp Enables Customers to Improve Their Performance Through Cloud and Flash Services

[0001564590-17-023882:8k_2_02:41]
| • | NetApp SolidFire enables Ensono to deliver more value with fewer resources allowing their clients to focus on accelerating their businesses and leave the burden of managing IT to Ensono. |  |

[0001564590-17-023882:8k_2_02:42]
| • | NetApp Data Fabric solutions allow Renown Health to reduce downtime and performance concerns, while enabling the integrated healthcare network to deliver leading-edge services and care to more patients. |  |

[0001564590-17-023882:8k_2_02:43]
| • | CloudOps leverages NetApp SolidFire as the storage foundation for CloudMC, the IaaS platform that enables users such as cloud.ca to rapidly grow secure, successful cloud-based businesses. |  |

[0001564590-17-023882:8k_2_02:44]
| • | Healthix enlists NetApp as a strategic partner to build a nondisruptive solution for sharing patient data among unrelated healthcare organizations, while remaining compliant with patient privacy laws and regulations. |  |

[0001564590-17-023882:8k_2_02:45]
Webcast and Conference Call Information

[0001564590-17-023882:8k_2_02:46]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:30 p.m. Pacific Time today.

[0001564590-17-023882:8k_2_02:47]
About NetApp

[0001564590-17-023882:8k_2_02:48]
NetApp is the data authority for hybrid cloud. We provide a full range of hybrid cloud data services that simplify management of applications and data across cloud and on-premises environments to accelerate digital transformation. Together with our partners, we empower global organizations to unleash the full potential of their data to expand customer touchpoints, foster greater innovation and optimize their operations. For more information, visit www.netapp.com. #DataDriven

[0001564590-17-023882:8k_2_02:49]
###

[0001564590-17-023882:8k_2_02:50]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-17-023882:8k_2_02:51]
Footnotes

[0001564590-17-023882:8k_2_02:52]
1Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) acquisition-related expenses, (d) restructuring charges, (e) asset impairments, (f) gains/losses on the sale of properties, and (g) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-17-023882:8k_2_02:53]
2GAAP earnings per share and non-GAAP earnings per share are calculated using the diluted number of shares for all periods presented.

[0001564590-17-023882:8k_2_02:54]
3Storage Performance Council, NetApp EF570 SPC-1, September 18, 2017, and NetApp EF570 SPC-2, September 18, 2017. Full Disclosure Reports.

[0001564590-17-023882:8k_2_02:55]
NetApp Usage of Non-GAAP Financial Information

[0001564590-17-023882:8k_2_02:56]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-17-023882:8k_2_02:57]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in

[0001564590-17-023882:8k_2_02:58]
accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-17-023882:8k_2_02:59]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-17-023882:8k_2_02:60]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-17-023882:8k_2_02:61]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-17-023882:8k_2_02:62]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-17-023882:8k_2_02:63]
C. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-17-023882:8k_2_02:64]
D. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-17-023882:8k_2_02:65]
E. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-17-023882:8k_2_02:66]
F. Gains/losses on the sale of properties. These are gains/losses from the sale of our properties. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-17-023882:8k_2_02:67]
G. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual properties from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-17-023882:8k_2_02:68]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-17-023882:8k_2_02:69]
NETAPP, INC.

[0001564590-17-023882:8k_2_02:70]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-17-023882:8k_2_02:71]
(In millions)

[0001564590-17-023882:8k_2_02:72]
(Unaudited)

[0001564590-17-023882:8k_2_02:73]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,965 |  |  | $ | 4,921 |  |
| Accounts receivable |  |  | 584 |  |  |  | 731 |  |
| Inventories |  |  | 108 |  |  |  | 163 |  |
| Other current assets |  |  | 363 |  |  |  | 383 |  |
| Total current assets |  |  | 7,020 |  |  |  | 6,198 |  |
| Property and equipment, net |  |  | 795 |  |  |  | 799 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,859 |  |  |  | 1,815 |  |
| Other non-current assets |  |  | 634 |  |  |  | 681 |  |
| Total assets |  | $ | 10,308 |  |  | $ | 9,493 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 379 |  |  | $ | 347 |  |
| Accrued expenses |  |  | 722 |  |  |  | 782 |  |
| Commercial paper notes |  |  | 718 |  |  |  | 500 |  |
| Current portion of long-term debt |  |  | 750 |  |  |  | 749 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,645 |  |  |  | 1,744 |  |
| Total current liabilities |  |  | 4,214 |  |  |  | 4,122 |  |
| Long-term debt |  |  | 1,540 |  |  |  | 744 |  |
| Other long-term liabilities |  |  | 255 |  |  |  | 249 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,522 |  |  |  | 1,598 |  |
| Total liabilities |  |  | 7,531 |  |  |  | 6,713 |  |
| Stockholders' equity |  |  | 2,777 |  |  |  | 2,780 |  |
| Total liabilities and stockholders' equity |  | $ | 10,308 |  |  | $ | 9,493 |  |

[0001564590-17-023882:8k_2_02:74]
NETAPP, INC.

[0001564590-17-023882:8k_2_02:75]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-17-023882:8k_2_02:76]
(In millions, except per share amounts)

[0001564590-17-023882:8k_2_02:77]
(Unaudited)

[0001564590-17-023882:8k_2_02:78]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 807 |  |  | $ | 710 |  |  | $ | 1,530 |  |  | $ | 1,370 |  |
| Software maintenance |  |  | 240 |  |  |  | 242 |  |  |  | 474 |  |  |  | 483 |  |
| Hardware maintenance and other services |  |  | 375 |  |  |  | 388 |  |  |  | 743 |  |  |  | 781 |  |
| Net revenues |  |  | 1,422 |  |  |  | 1,340 |  |  |  | 2,747 |  |  |  | 2,634 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 399 |  |  |  | 376 |  |  |  | 770 |  |  |  | 735 |  |
| Cost of software maintenance |  |  | 6 |  |  |  | 7 |  |  |  | 13 |  |  |  | 15 |  |
| Cost of hardware maintenance and other services |  |  | 115 |  |  |  | 128 |  |  |  | 228 |  |  |  | 258 |  |
| Total cost of revenues |  |  | 520 |  |  |  | 511 |  |  |  | 1,011 |  |  |  | 1,008 |  |
| Gross profit |  |  | 902 |  |  |  | 829 |  |  |  | 1,736 |  |  |  | 1,626 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 420 |  |  |  | 418 |  |  |  | 845 |  |  |  | 847 |  |
| Research and development |  |  | 194 |  |  |  | 200 |  |  |  | 387 |  |  |  | 407 |  |
| General and administrative |  |  | 69 |  |  |  | 69 |  |  |  | 137 |  |  |  | 137 |  |
| Total operating expenses |  |  | 683 |  |  |  | 687 |  |  |  | 1,369 |  |  |  | 1,391 |  |
| Income from operations |  |  | 219 |  |  |  | 142 |  |  |  | 367 |  |  |  | 235 |  |
| Other income (expense), net |  |  | 6 |  |  |  | — |  |  |  | 11 |  |  |  | (1 | ) |
| Income before income taxes |  |  | 225 |  |  |  | 142 |  |  |  | 378 |  |  |  | 234 |  |
| Provision for income taxes |  |  | 50 |  |  |  | 33 |  |  |  | 67 |  |  |  | 61 |  |
| Net income |  | $ | 175 |  |  | $ | 109 |  |  | $ | 311 |  |  | $ | 173 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.65 |  |  | $ | 0.39 |  |  | $ | 1.15 |  |  | $ | 0.62 |  |
| Diluted |  | $ | 0.64 |  |  | $ | 0.38 |  |  | $ | 1.12 |  |  | $ | 0.61 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 269 |  |  |  | 278 |  |  |  | 270 |  |  |  | 278 |  |
| Diluted |  |  | 275 |  |  |  | 284 |  |  |  | 277 |  |  |  | 283 |  |
| Cash dividends declared per share |  | $ | 0.200 |  |  | $ | 0.190 |  |  | $ | 0.400 |  |  | $ | 0.380 |  |

[0001564590-17-023882:8k_2_02:79]
NETAPP, INC.

[0001564590-17-023882:8k_2_02:80]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-17-023882:8k_2_02:81]
(In millions)

[0001564590-17-023882:8k_2_02:82]
(Unaudited)

[0001564590-17-023882:8k_2_02:83]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 175 |  |  | $ | 109 |  |  | $ | 311 |  |  | $ | 173 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 51 |  |  |  | 57 |  |  |  | 102 |  |  |  | 117 |  |
| Stock-based compensation |  |  | 39 |  |  |  | 51 |  |  |  | 87 |  |  |  | 103 |  |
| Other items, net |  |  | 32 |  |  |  | 1 |  |  |  | 39 |  |  |  | 13 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (69 | ) |  |  | (47 | ) |  |  | 149 |  |  |  | 264 |  |
| Inventories |  |  | 35 |  |  |  | (16 | ) |  |  | 55 |  |  |  | 1 |  |
| Accounts payable |  |  | 92 |  |  |  | 17 |  |  |  | 34 |  |  |  | (13 | ) |
| Accrued expenses |  |  | 67 |  |  |  | 60 |  |  |  | (68 | ) |  |  | (138 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (76 | ) |  |  | (96 | ) |  |  | (183 | ) |  |  | (179 | ) |
| Changes in other operating assets and liabilities, net |  |  | (32 | ) |  |  | 22 |  |  |  | 38 |  |  |  | 45 |  |
| Net cash provided by operating activities |  |  | 314 |  |  |  | 158 |  |  |  | 564 |  |  |  | 386 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | (64 | ) |  |  | (123 | ) |  |  | 48 |  |  |  | 190 |  |
| Purchases of property and equipment |  |  | (29 | ) |  |  | (56 | ) |  |  | (65 | ) |  |  | (92 | ) |
| Acquisitions of businesses, net of cash acquired |  |  | (51 | ) |  |  | — |  |  |  | (75 | ) |  |  | — |  |
| Other investing activities, net |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | (1 | ) |
| Net cash provided by (used in) investing activities |  |  | (144 | ) |  |  | (179 | ) |  |  | (87 | ) |  |  | 97 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 9 |  |  |  | 19 |  |  |  | 57 |  |  |  | 61 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (3 | ) |  |  | (3 | ) |  |  | (60 | ) |  |  | (36 | ) |
| Repurchase of common stock |  |  | (150 | ) |  |  | (117 | ) |  |  | (300 | ) |  |  | (292 | ) |
| Proceeds from (repayments of) commercial paper notes, net |  |  | (176 | ) |  |  | — |  |  |  | 218 |  |  |  | — |  |
| Issuance of long-term debt, net |  |  | 795 |  |  |  | — |  |  |  | 795 |  |  |  | — |  |
| Repayment of short-term loan |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (850 | ) |
| Dividends paid |  |  | (54 | ) |  |  | (52 | ) |  |  | (108 | ) |  |  | (105 | ) |
| Other financing activities, net |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |  |  | (3 | ) |
| Net cash provided by (used in) financing activities |  |  | 420 |  |  |  | (154 | ) |  |  | 601 |  |  |  | (1,225 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (6 | ) |  |  | (6 | ) |  |  | 13 |  |  |  | (13 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 584 |  |  |  | (181 | ) |  |  | 1,091 |  |  |  | (755 | ) |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,951 |  |  |  | 2,294 |  |  |  | 2,444 |  |  |  | 2,868 |  |
| End of period |  | $ | 3,535 |  |  | $ | 2,113 |  |  | $ | 3,535 |  |  | $ | 2,113 |  |

[0001564590-17-023882:8k_2_02:84]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q2 FY'18 |  |  | Q1 FY'18 |  |  | Q2 FY'17 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (1) |  | $ | 807 |  |  | $ | 723 |  |  | $ | 710 |  |
| Strategic |  | $ | 557 |  |  | $ | 500 |  |  | $ | 452 |  |
| Mature |  | $ | 250 |  |  | $ | 223 |  |  | $ | 258 |  |
| Software Maintenance |  | $ | 240 |  |  | $ | 234 |  |  | $ | 242 |  |
| Hardware Maintenance and Other Services |  | $ | 375 |  |  | $ | 368 |  |  | $ | 388 |  |
| Hardware Maintenance Support Contracts |  | $ | 306 |  |  | $ | 298 |  |  | $ | 316 |  |
| Professional and Other Services |  | $ | 69 |  |  | $ | 70 |  |  | $ | 72 |  |
| Net Revenues |  | $ | 1,422 |  |  | $ | 1,325 |  |  | $ | 1,340 |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'18 Revenue |  |  | % of Q1 FY'18 Revenue |  |  | % of Q2 FY'17 Revenue |  |
| Americas |  |  | 56 | % |  |  | 55 | % |  |  | 57 | % |
| Americas Commercial |  |  | 40 | % |  |  | 42 | % |  |  | 42 | % |
| U.S. Public Sector |  |  | 16 | % |  |  | 13 | % |  |  | 16 | % |
| EMEA |  |  | 30 | % |  |  | 30 | % |  |  | 30 | % |
| Asia Pacific |  |  | 14 | % |  |  | 15 | % |  |  | 13 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'18 Revenue |  |  | % of Q1 FY'18 Revenue |  |  | % of Q2 FY'17 Revenue |  |
| Direct |  |  | 22 | % |  |  | 20 | % |  |  | 22 | % |
| Indirect |  |  | 78 | % |  |  | 80 | % |  |  | 78 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'18 |  |  | Q1 FY'18 |  |  | Q2 FY'17 |  |
| Non-GAAP Gross Margin |  |  | 64.3 | % |  |  | 63.8 | % |  |  | 62.7 | % |
| Product |  |  | 51.8 | % |  |  | 49.9 | % |  |  | 48.2 | % |
| Software Maintenance |  |  | 97.5 | % |  |  | 97.0 | % |  |  | 97.1 | % |
| Hardware Maintenance and Other Services |  |  | 69.9 | % |  |  | 70.1 | % |  |  | 67.8 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'18 |  |  | Q1 FY'18 |  |  | Q2 FY'17 |  |
| Non-GAAP Income from Operations |  | $ | 272 |  |  | $ | 209 |  |  | $ | 204 |  |
| % of Net Revenues |  |  | 19.1 | % |  |  | 15.8 | % |  |  | 15.2 | % |
| Non-GAAP Income before Income Taxes |  | $ | 278 |  |  | $ | 214 |  |  | $ | 204 |  |
| Non-GAAP Effective Tax Rate |  |  | 19.4 | % |  |  | 19.4 | % |  |  | 17.3 | % |

[0001564590-17-023882:8k_2_02:85]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'18 |  |  | Q1 FY'18 |  |  | Q2 FY'17 |  |
| Non-GAAP Net Income |  | $ | 223 |  |  | $ | 173 |  |  | $ | 169 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 275 |  |  |  | 278 |  |  |  | 284 |  |
| Non-GAAP Income per Share, Diluted |  | $ | 0.81 |  |  | $ | 0.62 |  |  | $ | 0.60 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'18 |  |  | Q1 FY'18 |  |  | Q2 FY'17 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,167 |  |  | $ | 3,251 |  |  | $ | 3,201 |  |
| DSO (days) |  |  | 37 |  |  |  | 36 |  |  |  | 37 |  |
| DIO (days) |  |  | 19 |  |  |  | 27 |  |  |  | 17 |  |
| DPO (days) |  |  | 66 |  |  |  | 54 |  |  |  | 45 |  |
| CCC (days) |  |  | (10 | ) |  |  | 9 |  |  |  | 9 |  |
| Inventory Turns |  |  | 19 |  |  |  | 14 |  |  |  | 21 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'18 |  |  | Q1 FY'18 |  |  | Q2 FY'17 |  |
| Net Cash Provided by Operating Activities |  | $ | 314 |  |  | $ | 250 |  |  | $ | 158 |  |
| Purchases of Property and Equipment |  | $ | 29 |  |  | $ | 36 |  |  | $ | 56 |  |
| Free Cash Flow |  | $ | 285 |  |  | $ | 214 |  |  | $ | 102 |  |
| Free Cash Flow as a % of Net Revenues |  |  | 20.0 | % |  |  | 16.2 | % |  |  | 7.6 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| (1) Sales of certain products which should have been reported as strategic products were improperly reported as mature product revenues in Q2 FY'17. That period has been recast to reflect the appropriate classification. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001564590-17-023882:8k_2_02:86]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | Q2'FY17 |  |
| NET INCOME |  | $ | 175 |  |  | $ | 136 |  |  | $ | 109 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 13 |  |  |  | 11 |  |
| Stock-based compensation |  |  | 39 |  |  |  | 48 |  |  |  | 51 |  |
| Income tax effect of non-GAAP adjustments |  |  | (5 | ) |  |  | (24 | ) |  |  | (2 | ) |
| NON-GAAP NET INCOME |  | $ | 223 |  |  | $ | 173 |  |  | $ | 169 |  |
| COST OF REVENUES |  | $ | 520 |  |  | $ | 491 |  |  | $ | 511 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (8 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (4 | ) |  |  | (4 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 508 |  |  | $ | 479 |  |  | $ | 500 |  |
| COST OF PRODUCT REVENUES |  | $ | 399 |  |  | $ | 371 |  |  | $ | 376 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (8 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 389 |  |  | $ | 362 |  |  | $ | 368 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 115 |  |  | $ | 113 |  |  | $ | 128 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (3 | ) |  |  | (3 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 113 |  |  | $ | 110 |  |  | $ | 125 |  |
| GROSS PROFIT |  | $ | 902 |  |  | $ | 834 |  |  | $ | 829 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 8 |  |  |  | 7 |  |
| Stock-based compensation |  |  | 3 |  |  |  | 4 |  |  |  | 4 |  |
| NON-GAAP GROSS PROFIT |  | $ | 914 |  |  | $ | 846 |  |  | $ | 840 |  |

[0001564590-17-023882:8k_2_02:87]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | Q2'FY17 |  |
| SALES AND MARKETING EXPENSES |  | $ | 420 |  |  | $ | 425 |  |  | $ | 418 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | (4 | ) |
| Stock-based compensation |  |  | (16 | ) |  |  | (21 | ) |  |  | (21 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 399 |  |  | $ | 399 |  |  | $ | 393 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 194 |  |  | $ | 193 |  |  | $ | 200 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (12 | ) |  |  | (15 | ) |  |  | (17 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 182 |  |  | $ | 178 |  |  | $ | 183 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 69 |  |  | $ | 68 |  |  | $ | 69 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (8 | ) |  |  | (8 | ) |  |  | (9 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 61 |  |  | $ | 60 |  |  | $ | 60 |  |
| OPERATING EXPENSES |  | $ | 683 |  |  | $ | 686 |  |  | $ | 687 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (5 | ) |  |  | (4 | ) |
| Stock-based compensation |  |  | (36 | ) |  |  | (44 | ) |  |  | (47 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 642 |  |  | $ | 637 |  |  | $ | 636 |  |

[0001564590-17-023882:8k_2_02:88]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | Q2'FY17 |  |
| INCOME FROM OPERATIONS |  | $ | 219 |  |  | $ | 148 |  |  | $ | 142 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 13 |  |  |  | 11 |  |
| Stock-based compensation |  |  | 39 |  |  |  | 48 |  |  |  | 51 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 272 |  |  | $ | 209 |  |  | $ | 204 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 225 |  |  | $ | 153 |  |  | $ | 142 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 13 |  |  |  | 11 |  |
| Stock-based compensation |  |  | 39 |  |  |  | 48 |  |  |  | 51 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 278 |  |  | $ | 214 |  |  | $ | 204 |  |
| PROVISION FOR INCOME TAXES |  | $ | 50 |  |  | $ | 17 |  |  | $ | 33 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | 5 |  |  |  | 24 |  |  |  | 2 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 55 |  |  | $ | 41 |  |  | $ | 35 |  |
| NET INCOME PER SHARE |  | $ | 0.64 |  |  | $ | 0.49 |  |  | $ | 0.38 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.04 |  |
| Stock-based compensation |  |  | 0.14 |  |  |  | 0.17 |  |  |  | 0.18 |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.02 | ) |  |  | (0.09 | ) |  |  | (0.01 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.81 |  |  | $ | 0.62 |  |  | $ | 0.60 |  |

[0001564590-17-023882:8k_2_02:89]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | Q2'FY17 |  |
| Gross margin-GAAP |  |  | 63.4 | % |  |  | 62.9 | % |  |  | 61.9 | % |
| Cost of revenues adjustments |  |  | 0.8 | % |  |  | 0.9 | % |  |  | 0.8 | % |
| Gross margin-Non-GAAP |  |  | 64.3 | % |  |  | 63.8 | % |  |  | 62.7 | % |
| GAAP cost of revenues |  | $ | 520 |  |  | $ | 491 |  |  | $ | 511 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (8 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (4 | ) |  |  | (4 | ) |
| Non-GAAP cost of revenues |  | $ | 508 |  |  | $ | 479 |  |  | $ | 500 |  |
| Net revenues |  | $ | 1,422 |  |  | $ | 1,325 |  |  | $ | 1,340 |  |

[0001564590-17-023882:8k_2_02:90]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | Q2'FY17 |  |
| Product gross margin-GAAP |  |  | 50.6 | % |  |  | 48.7 | % |  |  | 47.0 | % |
| Cost of product revenues adjustments |  |  | 1.2 | % |  |  | 1.2 | % |  |  | 1.1 | % |
| Product gross margin-Non-GAAP |  |  | 51.8 | % |  |  | 49.9 | % |  |  | 48.2 | % |
| GAAP cost of product revenues |  | $ | 399 |  |  | $ | 371 |  |  | $ | 376 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (8 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 389 |  |  | $ | 362 |  |  | $ | 368 |  |
| Product revenues |  | $ | 807 |  |  | $ | 723 |  |  | $ | 710 |  |

[0001564590-17-023882:8k_2_02:91]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | Q2'FY17 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 69.3 | % |  |  | 69.3 | % |  |  | 67.0 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.5 | % |  |  | 0.8 | % |  |  | 0.8 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 69.9 | % |  |  | 70.1 | % |  |  | 67.8 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 115 |  |  | $ | 113 |  |  | $ | 128 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (3 | ) |  |  | (3 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 113 |  |  | $ | 110 |  |  | $ | 125 |  |
| Hardware maintenance and other services revenues |  | $ | 375 |  |  | $ | 368 |  |  | $ | 388 |  |

[0001564590-17-023882:8k_2_02:92]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | Q2'FY17 |  |
| GAAP effective tax rate |  |  | 22.2 | % |  |  | 11.1 | % |  |  | 23.2 | % |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | (2.8 | )% |  |  | 8.3 | % |  |  | (5.9 | )% |
| Non-GAAP effective tax rate |  |  | 19.4 | % |  |  | 19.4 | % |  |  | 17.3 | % |

[0001564590-17-023882:8k_2_02:93]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY18 |  |  | Q1'FY18 |  |  | Q2'FY17 |  |
| Net cash provided by operating activities |  | $ | 314 |  |  | $ | 250 |  |  | $ | 158 |  |
| Purchases of property and equipment |  |  | (29 | ) |  |  | (36 | ) |  |  | (56 | ) |
| Free cash flow |  | $ | 285 |  |  | $ | 214 |  |  | $ | 102 |  |

[0001564590-17-023882:8k_2_02:94]
Some items may not add or recalculate due to rounding.

[0001564590-17-023882:8k_2_02:95]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| THIRD QUARTER FISCAL 2018 |  |
|  |  | Third Quarter |  |
|  |  | Fiscal 2018 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $0.86 - $0.94 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Third Quarter Fiscal 2018: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.05 | ) |
| Stock-based compensation expense |  |  | (0.14 | ) |
| Gains on sale of properties |  |  | 0.80 |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.29 | ) |
| Total Adjustments |  |  | 0.32 |  |
| GAAP Guidance - Net Income Per Share |  | $1.18 - $1.26 |  |

[0001564590-17-023882:8k_2_02:96]
Press Contact:

[0001564590-17-023882:8k_2_02:97]
Madge Miller

[0001564590-17-023882:8k_2_02:98]
NetApp

[0001564590-17-023882:8k_2_02:99]
1 408 419 5263

[0001564590-17-023882:8k_2_02:100]
madge.miller@netapp.com

[0001564590-17-023882:8k_2_02:101]
Investor Contact:

[0001564590-17-023882:8k_2_02:102]
Kris Newton

[0001564590-17-023882:8k_2_02:103]
NetApp

[0001564590-17-023882:8k_2_02:104]
1 408 822 3312

[0001564590-17-023882:8k_2_02:105]
kris.newton@netapp.com

## item 5.02 — body, verbatim

[0001564590-17-023882:8k_body:1]
Item 5.02. Departure of Directors or Principal Officers; Election of Directors; Appointment of Principal Officers; Compensatory Arrangements of Certain Officers.

[0001564590-17-023882:8k_body:2]
(d)

[0001564590-17-023882:8k_body:3]
Appointment of New Directors

[0001564590-17-023882:8k_body:4]
On November 9, 2017, the Company’s board of directors (the “Board”) approved an increase in the number of authorized directors on the Board from eight (8) to ten (10) and appointed Deborah L. Kerr and Scott F. Schenkel as members of the Board to fill the vacancies created thereby.

[0001564590-17-023882:8k_body:5]
There are no arrangements or understandings between either Ms. Kerr or Mr. Schenkel, on the one hand, and the Company or any other persons, on the other hand, pursuant to which either Ms. Kerr or Mr. Schenkel was selected as a director. There are no related party transactions between the Company and either Ms. Kerr or Mr. Schenkel (or any immediate family member thereof) requiring disclosure under Item 404(a) of Regulation S-K. Neither Ms. Kerr nor Mr. Schenkel have any family relationships with any of the Company’s directors or executive officers.

[0001564590-17-023882:8k_body:6]
Ms. Kerr and Mr. Schenkel will both serve as members of the Audit Committee.

[0001564590-17-023882:8k_body:7]
As non-employee directors, Ms. Kerr and Mr. Schenkel will participate in the non-employee director compensation arrangements described in the Company’s definitive proxy statement filed with the Securities and Exchange Commission on August 1, 2017. In addition, it is expected that they will each enter into the Company’s standard form of director indemnification agreement. The form of the indemnification agreement was filed as Exhibit 10.1 to the Company’s Quarterly Report on Form 10-Q for the period ended July 25, 2014, as filed with the SEC on August 28, 2014.

[0001564590-17-023882:8k_body:8]
A copy of the Company’s press release announcing the appointment of Ms. Kerr and Mr. Schenkel to the Board is attached hereto as Exhibit 99.2 and the information set forth therein is incorporated herein by reference.
