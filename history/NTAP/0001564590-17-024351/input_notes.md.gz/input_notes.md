# NTAP notes — 0001564590-17-024351


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-17-024351:notes:1]
[same as prior period, unchanged from 0001564590-17-018158:notes:1]

[0001564590-17-024351:notes:2]
[same as prior period, unchanged from 0001564590-17-018158:notes:2]

[0001564590-17-024351:notes:3]
[same as prior period, unchanged from 0001564590-17-018158:notes:3]

[0001564590-17-024351:notes:4]
[same as prior period, unchanged from 0001564590-17-018158:notes:4]

[0001564590-17-024351:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 28, 2017 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 27, 2017 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-17-024351:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; valuation of investment securities; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-17-024351:notes:7]
There have been no significant changes in our significant accounting policies as of and for the six months ended October 27, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 28, 2017.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-17-024351:notes:8]
[same as prior period, unchanged from 0001564590-17-018158:notes:8]

[0001564590-17-024351:notes:9]
[same as prior period, unchanged from 0001564590-17-018158:notes:9]

[0001564590-17-024351:notes:10]
|  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 17 |  |  | $ | 35 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 28 |  |  | $ | 70 |  |
| Interest paid |  | $ | 24 |  |  | $ | 23 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-17-024351:notes:11]
4. Business Combinations

[0001564590-17-024351:notes:12]
On August 4, 2017, we acquired all of the outstanding shares of Greenqloud ehf., a privately-held provider of cloud management software based in Iceland, for $51 million in cash, of which we preliminarily allocated $10 million to developed technology, $38 million to goodwill, and the remainder to other assets.

[0001564590-17-024351:notes:13]
[same as prior period, unchanged from 0001564590-17-018158:notes:12]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-17-024351:notes:14]
[same as prior period, unchanged from 0001564590-17-018158:notes:13]

[0001564590-17-024351:notes:15]
[same as prior period, unchanged from 0001564590-17-018158:notes:14]

[0001564590-17-024351:notes:16]
| Balance as of April 28, 2017 |  | $ | 1,684 |  |
| Additions |  |  | 55 |  |
| Balance as of October 27, 2017 |  | $ | 1,739 |  |

[0001564590-17-024351:notes:17]
[same as prior period, unchanged from 0001564590-17-018158:notes:16]

[0001564590-17-024351:notes:18]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 164 |  |  | $ | (61 | ) |  | $ | 103 |  |  | $ | 148 |  |  | $ | (44 | ) |  | $ | 104 |  |
| Customer contracts/relationships |  |  | 43 |  |  |  | (27 | ) |  |  | 16 |  |  |  | 43 |  |  |  | (19 | ) |  |  | 24 |  |
| Other purchased intangibles |  |  | 9 |  |  |  | (8 | ) |  |  | 1 |  |  |  | 9 |  |  |  | (6 | ) |  |  | 3 |  |
| Total purchased intangible assets |  | $ | 216 |  |  | $ | (96 | ) |  | $ | 120 |  |  | $ | 200 |  |  | $ | (69 | ) |  | $ | 131 |  |

[0001564590-17-024351:notes:19]
[same as prior period, unchanged from 0001564590-17-018158:notes:18]

[0001564590-17-024351:notes:20]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Statements of |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | Operations Classification |
| Developed technology |  | $ | 9 |  |  | $ | 7 |  |  | $ | 17 |  |  | $ | 13 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 4 |  |  |  | 3 |  |  |  | 8 |  |  |  | 7 |  |  | Operating expenses |
| Other purchased intangibles |  |  | 1 |  |  |  | 1 |  |  |  | 2 |  |  |  | 2 |  |  | Operating expenses |
| Total |  | $ | 14 |  |  | $ | 11 |  |  | $ | 27 |  |  | $ | 22 |  |  |  |

[0001564590-17-024351:notes:21]
As of October 27, 2017, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-17-024351:notes:22]
| Fiscal Year |  | Amount |  |
| Remainder of 2018 |  | $ | 26 |  |
| 2019 |  |  | 47 |  |
| 2020 |  |  | 31 |  |
| 2021 |  |  | 16 |  |
| Total |  | $ | 120 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-17-024351:notes:23]
[same as prior period, unchanged from 0001564590-17-018158:notes:22]

[0001564590-17-024351:notes:24]
[same as prior period, unchanged from 0001564590-17-018158:notes:23]

[0001564590-17-024351:notes:25]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
| Cash |  | $ | 3,111 |  |  | $ | 2,275 |  |
| Cash equivalents |  |  | 424 |  |  |  | 169 |  |
| Cash and cash equivalents |  | $ | 3,535 |  |  | $ | 2,444 |  |

[0001564590-17-024351:notes:26]
[same as prior period, unchanged from 0001564590-17-018158:notes:25]

[0001564590-17-024351:notes:27]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
| Purchased components |  | $ | 32 |  |  | $ | 28 |  |
| Finished goods |  |  | 76 |  |  |  | 135 |  |
| Inventories |  | $ | 108 |  |  | $ | 163 |  |

[0001564590-17-024351:notes:28]
[same as prior period, unchanged from 0001564590-17-018158:notes:27]

[0001564590-17-024351:notes:29]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
| Land |  | $ | 132 |  |  | $ | 132 |  |
| Buildings and improvements |  |  | 633 |  |  |  | 612 |  |
| Leasehold improvements |  |  | 100 |  |  |  | 93 |  |
| Computer, production, engineering and other equipment |  |  | 749 |  |  |  | 741 |  |
| Computer software |  |  | 352 |  |  |  | 353 |  |
| Furniture and fixtures |  |  | 96 |  |  |  | 90 |  |
| Construction-in-progress |  |  | 13 |  |  |  | 26 |  |
|  |  |  | 2,075 |  |  |  | 2,047 |  |
| Accumulated depreciation and amortization |  |  | (1,280 | ) |  |  | (1,248 | ) |
| Property and equipment, net |  | $ | 795 |  |  | $ | 799 |  |

[0001564590-17-024351:notes:30]
We have classified certain land and buildings located in Sunnyvale, California previously reported as property and equipment as assets held-for-sale. The book value of these assets is $118 million and is included in other current assets in the condensed consolidated balance sheets.  On September 8, 2017, we entered into an agreement to sell these assets for a total of $306 million, of which $210 million is payable at the first closing and $96 million is payable at the second closing. Each closing is subject to due diligence, certain termination rights and customary closing conditions, including, in the case of the second closing, local governmental approval of the subdivision of a land parcel. The first closing is expected to occur in the third quarter of fiscal 2018 and the second closing is expected to occur within the next twelve months.

[0001564590-17-024351:notes:31]
[same as prior period, unchanged from 0001564590-17-018158:notes:30]

[0001564590-17-024351:notes:32]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
| Deferred tax assets |  | $ | 483 |  |  | $ | 525 |  |
| Other assets |  |  | 151 |  |  |  | 156 |  |
| Other non-current assets |  | $ | 634 |  |  | $ | 681 |  |

[0001564590-17-024351:notes:33]
[same as prior period, unchanged from 0001564590-17-018158:notes:32]

[0001564590-17-024351:notes:34]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
| Accrued compensation and benefits |  | $ | 291 |  |  | $ | 340 |  |
| Sale-leaseback financing obligations |  |  | 130 |  |  |  | 130 |  |
| Product warranty liabilities |  |  | 29 |  |  |  | 33 |  |
| Other current liabilities |  |  | 272 |  |  |  | 279 |  |
| Accrued expenses |  | $ | 722 |  |  | $ | 782 |  |

[0001564590-17-024351:notes:35]
[same as prior period, unchanged from 0001564590-17-018158:notes:34]

[0001564590-17-024351:notes:36]
[same as prior period, unchanged from 0001564590-17-018158:notes:35]

[0001564590-17-024351:notes:37]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Balance at beginning of period |  | $ | 44 |  |  | $ | 61 |  |  | $ | 50 |  |  | $ | 70 |  |
| Expense accrued during the period |  |  | 7 |  |  |  | 1 |  |  |  | 8 |  |  |  | 5 |  |
| Warranty costs incurred |  |  | (7 | ) |  |  | (8 | ) |  |  | (14 | ) |  |  | (21 | ) |
| Balance at end of period |  | $ | 44 |  |  | $ | 54 |  |  | $ | 44 |  |  | $ | 54 |  |

[0001564590-17-024351:notes:38]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
| Accrued expenses |  | $ | 29 |  |  | $ | 33 |  |
| Other long-term liabilities |  |  | 15 |  |  |  | 17 |  |
| Total warranty liabilities |  | $ | 44 |  |  | $ | 50 |  |

[0001564590-17-024351:notes:39]
[same as prior period, unchanged from 0001564590-17-018158:notes:38]

[0001564590-17-024351:notes:40]
[same as prior period, unchanged from 0001564590-17-018158:notes:39]

[0001564590-17-024351:notes:41]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
| Deferred product revenue |  | $ | 123 |  |  | $ | 124 |  |
| Deferred services revenue |  |  | 2,881 |  |  |  | 2,999 |  |
| Financed unearned services revenue |  |  | 163 |  |  |  | 219 |  |
| Total |  | $ | 3,167 |  |  | $ | 3,342 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,645 |  |  | $ | 1,744 |  |
| Long-term |  |  | 1,522 |  |  |  | 1,598 |  |
| Total |  | $ | 3,167 |  |  | $ | 3,342 |  |

[0001564590-17-024351:notes:42]
[same as prior period, unchanged from 0001564590-17-018158:notes:41]


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-17-024351:notes:43]
[same as prior period, unchanged from 0001564590-17-018158:notes:42]

[0001564590-17-024351:notes:44]
[same as prior period, unchanged from 0001564590-17-018158:notes:43]

[0001564590-17-024351:notes:45]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Interest income |  | $ | 19 |  |  | $ | 10 |  |  | $ | 35 |  |  | $ | 21 |  |
| Interest expense |  |  | (17 | ) |  |  | (12 | ) |  |  | (30 | ) |  |  | (27 | ) |
| Other income, net |  |  | 4 |  |  |  | 2 |  |  |  | 6 |  |  |  | 5 |  |
| Total other income (expense), net |  | $ | 6 |  |  | $ | — |  |  | $ | 11 |  |  | $ | (1 | ) |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-17-024351:notes:46]
[same as prior period, unchanged from 0001564590-17-018158:notes:45]

[0001564590-17-024351:notes:47]
[same as prior period, unchanged from 0001564590-17-018158:notes:46]

[0001564590-17-024351:notes:48]
[same as prior period, unchanged from 0001564590-17-018158:notes:47]

[0001564590-17-024351:notes:49]
[same as prior period, unchanged from 0001564590-17-018158:notes:48]

[0001564590-17-024351:notes:50]
[same as prior period, unchanged from 0001564590-17-018158:notes:49]

[0001564590-17-024351:notes:51]
[same as prior period, unchanged from 0001564590-17-018158:notes:50]

[0001564590-17-024351:notes:52]
[same as prior period, unchanged from 0001564590-17-018158:notes:51]

[0001564590-17-024351:notes:53]
[same as prior period, unchanged from 0001564590-17-018158:notes:52]

[0001564590-17-024351:notes:54]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,747 |  |  | $ | 6 |  |  | $ | (3 | ) |  | $ | 1,750 |  |  | $ | 1,535 |  |  | $ | 3 |  |  | $ | (2 | ) |  | $ | 1,536 |  |
| U.S. Treasury and government debt securities |  |  | 474 |  |  |  | — |  |  |  | (2 | ) |  |  | 472 |  |  |  | 629 |  |  |  | 1 |  |  |  | (2 | ) |  |  | 628 |  |
| Foreign government debt securities |  |  | 21 |  |  |  | — |  |  |  | — |  |  |  | 21 |  |  |  | 21 |  |  |  | — |  |  |  | — |  |  |  | 21 |  |
| Commercial paper |  |  | 504 |  |  |  | — |  |  |  | — |  |  |  | 504 |  |  |  | 362 |  |  |  | — |  |  |  | — |  |  |  | 362 |  |
| Certificates of deposit |  |  | 107 |  |  |  | — |  |  |  | — |  |  |  | 107 |  |  |  | 99 |  |  |  | — |  |  |  | — |  |  |  | 99 |  |
| Mutual funds |  |  | 34 |  |  |  | — |  |  |  | — |  |  |  | 34 |  |  |  | 31 |  |  |  | — |  |  |  | — |  |  |  | 31 |  |
| Total debt and equity securities |  | $ | 2,887 |  |  | $ | 6 |  |  | $ | (5 | ) |  | $ | 2,888 |  |  | $ | 2,677 |  |  | $ | 4 |  |  | $ | (4 | ) |  | $ | 2,677 |  |

[0001564590-17-024351:notes:55]
As of October 27, 2017 and April 28, 2017, gross unrealized losses related to individual securities were not significant.

[0001564590-17-024351:notes:56]
The following table presents the contractual maturities of our debt investments as of October 27, 2017 (in millions):

[0001564590-17-024351:notes:57]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,242 |  |  | $ | 1,242 |  |
| Due after one year through five years |  |  | 1,187 |  |  |  | 1,186 |  |
| Due after five years through ten years |  |  | 419 |  |  |  | 421 |  |
| Due after ten years |  |  | 5 |  |  |  | 5 |  |
|  |  | $ | 2,853 |  |  | $ | 2,854 |  |

[0001564590-17-024351:notes:58]
[same as prior period, unchanged from 0001564590-17-018158:notes:57]

[0001564590-17-024351:notes:59]
[same as prior period, unchanged from 0001564590-17-018158:notes:58]

[0001564590-17-024351:notes:60]
[same as prior period, unchanged from 0001564590-17-018158:notes:59]

[0001564590-17-024351:notes:61]
|  |  | October 27, 2017 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 3,111 |  |  | $ | 3,111 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,750 |  |  |  | — |  |  |  | 1,750 |  |
| U.S. Treasury and government debt securities |  |  | 472 |  |  |  | 191 |  |  |  | 281 |  |
| Foreign government debt securities |  |  | 21 |  |  |  | — |  |  |  | 21 |  |
| Commercial paper |  |  | 504 |  |  |  | — |  |  |  | 504 |  |
| Certificates of deposit |  |  | 107 |  |  |  | — |  |  |  | 107 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 5,965 |  |  | $ | 3,302 |  |  | $ | 2,663 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 27 |  |  | $ | 27 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (4 | ) |  | $ | — |  |  | $ | (4 | ) |

[0001564590-17-024351:notes:62]
[same as prior period, unchanged from 0001564590-17-018158:notes:61]

[0001564590-17-024351:notes:63]
[same as prior period, unchanged from 0001564590-17-018158:notes:62]

[0001564590-17-024351:notes:64]
[same as prior period, unchanged from 0001564590-17-018158:notes:63]

[0001564590-17-024351:notes:65]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of October 27, 2017 and April 28, 2017, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-17-024351:notes:66]
[same as prior period, unchanged from 0001564590-17-018158:notes:65]

[0001564590-17-024351:notes:67]
As of October 27, 2017 and April 28, 2017, the fair value of our long-term debt was approximately $2,316 million and $1,520 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-17-024351:notes:68]
9. Financing Arrangements

[0001564590-17-024351:notes:69]
Long-Term Debt

[0001564590-17-024351:notes:70]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-17-024351:notes:71]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 2.00% Senior Notes Due September 2019 |  |  | 400 |  |  |  | 2.32 | % |  |  | — |  |  | N/A |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | — |  |  | N/A |  |
| Total principal amount |  |  | 2,300 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (10 | ) |  |  |  |  |  |  | (7 | ) |  |  |  |  |
| Total senior notes |  |  | 2,290 |  |  |  |  |  |  |  | 1,493 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (750 | ) |  |  |  |  |  |  | (749 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,540 |  |  |  |  |  |  | $ | 744 |  |  |  |  |  |

[0001564590-17-024351:notes:72]
__________________

[0001564590-17-024351:notes:73]
N/A - Not applicable

[0001564590-17-024351:notes:74]
Senior Notes

[0001564590-17-024351:notes:75]
In September 2017, we issued $400 million aggregate principal amount of 2.00% Senior Notes due on September 27, 2019 and $400 million aggregate principal amount of 3.30% Senior Notes due on September 29, 2024. We received total proceeds of approximately $795 million, net of discount and issuance costs, which will be used for general corporate purposes, including the repayment of our outstanding 2.00% Senior Notes due December 2017. Interest on these Senior Notes is payable semi-annually in March and September. Our 3.375% Senior Notes, 2.00% Senior Notes due December 2017 and 3.25% Senior Notes, with principal amounts of $500 million, $750 million and $250 million, respectively, were issued in June 2014, December 2012 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-17-024351:notes:76]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 27, 2017, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-17-024351:notes:77]
On October 4, 2017, we issued a notice to redeem all our 2.00% Senior Notes due December 2017. On November 3, 2017, the notes were extinguished through redemption for cash at an aggregate redemption price of $751 million, plus accrued and unpaid interest.

[0001564590-17-024351:notes:78]
As of October 27, 2017, our aggregate future principal debt maturities, including the 2.00% Senior Notes due December 2017, are as follows (in millions):

[0001564590-17-024351:notes:79]
| Fiscal Year |  | Amount |  |
| Remainder of 2018 |  | $ | 750 |  |
| 2020 |  |  | 400 |  |
| 2022 |  |  | 500 |  |
| Thereafter |  |  | 650 |  |
| Total |  | $ | 2,300 |  |

[0001564590-17-024351:notes:80]
Commercial Paper Program and Credit Facility

[0001564590-17-024351:notes:81]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended on July 17, 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of October 27, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $719 million, a weighted-average interest rate of 1.43% and maturities ranging from 13 days to 44 days. As of April 28, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $500 million, a weighted-average interest rate of 1.26% and maturities ranging from 7 days to 38 days.

[0001564590-17-024351:notes:82]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended on July 17, 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of October 27, 2017 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-17-024351:notes:83]
Sale-leaseback Transactions

[0001564590-17-024351:notes:84]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, until such time as the related leases are terminated, the assets will remain on our condensed consolidated balance sheets and proceeds received by us from these transactions are reported as financing obligations. As of October 27, 2017, the balance of the remaining financing obligations, which relate to properties whose leases we expect to terminate in December 2017, was $130 million. At the end of the leaseback period, or when our continuing involvement under the leaseback agreement ends, this transaction will be reported as a non-cash sale and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-17-024351:notes:85]
[same as prior period, unchanged from 0001564590-17-018158:notes:81]

[0001564590-17-024351:notes:86]
[same as prior period, unchanged from 0001564590-17-018158:notes:82]

[0001564590-17-024351:notes:87]
As of October 27, 2017, we have certain equity incentive awards (awards) outstanding, which include stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and Employee Stock Purchase Plan (ESPP) awards.

[0001564590-17-024351:notes:88]
[same as prior period, unchanged from 0001564590-17-018158:notes:84]

[0001564590-17-024351:notes:89]
[same as prior period, unchanged from 0001564590-17-018158:notes:85]

[0001564590-17-024351:notes:90]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 28, 2017 |  |  | 4 |  |  | $ | 35.76 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (1 | ) |  | $ | 24.14 |  |  |  |  |  |  |  |  |  |
| Outstanding as of October 27, 2017 |  |  | 3 |  |  | $ | 37.30 |  |  |  | 2.77 |  |  | $ | 29 |  |
| Exercisable as of October 27, 2017 |  |  | 3 |  |  | $ | 40.97 |  |  |  | 2.14 |  |  | $ | 16 |  |

[0001564590-17-024351:notes:91]
[same as prior period, unchanged from 0001564590-17-018158:notes:87]

[0001564590-17-024351:notes:92]
[same as prior period, unchanged from 0001564590-17-018158:notes:88]

[0001564590-17-024351:notes:93]
|  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Intrinsic value of exercises |  | $ | 11 |  |  | $ | 11 |  |
| Proceeds received from exercises |  | $ | 15 |  |  | $ | 20 |  |
| Fair value of options vested |  | $ | 5 |  |  | $ | 9 |  |

[0001564590-17-024351:notes:94]
[same as prior period, unchanged from 0001564590-17-018158:notes:90]

[0001564590-17-024351:notes:95]
In the six months ended October 27, 2017, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria such that the PBRSU cliff-vests at the end of either an approximate two year or three year performance period, which began on the date specified in the grant agreement and ends the last day of the second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted, and will depend upon our Total Stockholder Return (TSR) as compared to an index TSR (each expressed as a growth rate percentage) calculated as of the applicable period end date. The fair values of the PBRSUs were fixed at grant date using a Monte Carlo simulation model and the related aggregate compensation cost of $20 million is being recognized over the shorter of the remaining applicable performance or service periods.

[0001564590-17-024351:notes:96]
The following table summarizes information related to our RSUs, including PBRSUs, (in millions, except fair value):

[0001564590-17-024351:notes:97]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 28, 2017 |  |  | 11 |  |  | $ | 28.81 |  |
| Granted |  |  | 4 |  |  | $ | 38.61 |  |
| Vested |  |  | (4 | ) |  | $ | 31.29 |  |
| Forfeited |  |  | (1 | ) |  | $ | 28.30 |  |
| Outstanding as of October 27, 2017 |  |  | 10 |  |  | $ | 31.73 |  |

[0001564590-17-024351:notes:98]
[same as prior period, unchanged from 0001564590-17-018158:notes:94]

[0001564590-17-024351:notes:99]
|  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Shares withheld for taxes |  |  | 2 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 60 |  |  | $ | 36 |  |

[0001564590-17-024351:notes:100]
[same as prior period, unchanged from 0001564590-17-018158:notes:96]

[0001564590-17-024351:notes:101]
[same as prior period, unchanged from 0001564590-17-018158:notes:97]

[0001564590-17-024351:notes:102]
|  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Shares issued under the ESPP |  |  | 2 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 42 |  |  | $ | 42 |  |

[0001564590-17-024351:notes:103]
[same as prior period, unchanged from 0001564590-17-018158:notes:99]

[0001564590-17-024351:notes:104]
[same as prior period, unchanged from 0001564590-17-018158:notes:100]

[0001564590-17-024351:notes:105]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |
| Cost of hardware maintenance and other services revenues |  |  | 2 |  |  |  | 3 |  |  |  | 5 |  |  |  | 7 |  |
| Sales and marketing |  |  | 16 |  |  |  | 21 |  |  |  | 37 |  |  |  | 44 |  |
| Research and development |  |  | 12 |  |  |  | 17 |  |  |  | 27 |  |  |  | 32 |  |
| General and administrative |  |  | 8 |  |  |  | 9 |  |  |  | 16 |  |  |  | 18 |  |
| Total stock-based compensation expense |  | $ | 39 |  |  | $ | 51 |  |  | $ | 87 |  |  | $ | 103 |  |
| Income tax benefit for stock-based compensation |  | $ | 9 |  |  | $ | 11 |  |  | $ | 18 |  |  | $ | 20 |  |

[0001564590-17-024351:notes:106]
As of October 27, 2017, total unrecognized compensation expense related to our equity awards was $269 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.3 years.

[0001564590-17-024351:notes:107]
[same as prior period, unchanged from 0001564590-17-018158:notes:103]

[0001564590-17-024351:notes:108]
Our Board of Directors has authorized the repurchase of up to $9.6 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management.

[0001564590-17-024351:notes:109]
The following table summarizes activity related to this program for the six months ended October 27, 2017 (in millions, except per share amounts):

[0001564590-17-024351:notes:110]
| Number of shares repurchased |  |  | 7 |  |
| Average price per share |  | $ | 41.80 |  |
| Aggregate purchase price |  | $ | 300 |  |
| Remaining authorization at end of period |  | $ | 494 |  |

[0001564590-17-024351:notes:111]
The aggregate purchase price of our stock repurchases for the six months ended October 27, 2017 consisted of $300 million of open market purchases, of which $74 million and $226 million were allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-17-024351:notes:112]
Since the May 13, 2003 inception of our stock repurchase program through October 27, 2017, we repurchased a total of 276 million shares of our common stock at an average price of $33.07 per share, for an aggregate purchase price of $9.1 billion.

[0001564590-17-024351:notes:113]
[same as prior period, unchanged from 0001564590-17-018158:notes:109]

[0001564590-17-024351:notes:114]
[same as prior period, unchanged from 0001564590-17-018158:notes:110]

[0001564590-17-024351:notes:115]
|  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Dividends per share declared |  | $ | 0.40 |  |  | $ | 0.38 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | — |  |  | $ | 76 |  |
| Dividend payments allocated to retained earnings |  | $ | 108 |  |  | $ | 29 |  |

[0001564590-17-024351:notes:116]
On November 15, 2017, we declared a cash dividend of $0.20 per share of common stock, payable on January 24, 2018 to holders of record as of the close of business on January 5, 2018. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-17-024351:notes:117]
[same as prior period, unchanged from 0001564590-17-018158:notes:113]

[0001564590-17-024351:notes:118]
[same as prior period, unchanged from 0001564590-17-018158:notes:114]

[0001564590-17-024351:notes:119]
| Balance as of April 28, 2017 |  | $ | 40 |  |
| Net income |  |  | 311 |  |
| Repurchases of common stock |  |  | (226 | ) |
| Dividends |  |  | (108 | ) |
| Balance as of October 27, 2017 |  | $ | 17 |  |

[0001564590-17-024351:notes:120]
[same as prior period, unchanged from 0001564590-17-018158:notes:116]

[0001564590-17-024351:notes:121]
[same as prior period, unchanged from 0001564590-17-018158:notes:117]

[0001564590-17-024351:notes:122]
|  |  | Foreign Currency Translation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Total |  |
| Balance as of April 28, 2017 |  | $ | (29 | ) |  | $ | — |  |  | $ | (29 | ) |
| Other comprehensive income, net of tax |  |  | 8 |  |  |  | 2 |  |  |  | 10 |  |
| Balance as of October 27, 2017 |  | $ | (21 | ) |  | $ | 2 |  |  | $ | (19 | ) |

[0001564590-17-024351:notes:123]
The amounts reclassified out of accumulated other comprehensive income (loss) are as follows (in millions):

[0001564590-17-024351:notes:124]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Classification |
| Recognized (gains) losses on defined benefit obligations |  | $ | (1 | ) |  | $ | 1 |  |  | $ | (1 | ) |  | $ | 1 |  |  | Operating expenses |
| Realized gains on cash flow hedges |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  | Net revenues |
| Total reclassifications |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-17-024351:notes:125]
[same as prior period, unchanged from 0001564590-17-018158:notes:119]

[0001564590-17-024351:notes:126]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is six months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of October 27, 2017 or April 28, 2017. We did not recognize any gains or losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-17-024351:notes:127]
[same as prior period, unchanged from 0001564590-17-018158:notes:121]

[0001564590-17-024351:notes:128]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 136 |  |  | $ | 165 |  |
| Forward contracts purchased |  | $ | 248 |  |  | $ | 257 |  |

[0001564590-17-024351:notes:129]
As of October 27, 2017 and April 28, 2017, there were no instruments designated as cash flow hedges outstanding.

[0001564590-17-024351:notes:130]
The effect of cash flow hedges recognized in net revenues is presented in the condensed consolidated statements of comprehensive income and in Note 10 – Stockholders’ Equity.

[0001564590-17-024351:notes:131]
[same as prior period, unchanged from 0001564590-17-018158:notes:124]

[0001564590-17-024351:notes:132]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |
|  |  | Gain Recognized into Income |  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 1 |  |  | $ | 2 |  |  | $ | (1 | ) |  | $ | 6 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-17-024351:notes:133]
[same as prior period, unchanged from 0001564590-17-018158:notes:126]

[0001564590-17-024351:notes:134]
Management has previously approved several restructuring actions to streamline our business, eliminate costs and redirect resources to our highest return activities, including the March 2016 Plan and the November 2016 Plan, under which we reduced our global workforce by approximately 11%, and 6%, respectively. We completed all workforce related activities under these plans as of the end of fiscal 2017. Charges related to our restructuring plans consisted primarily of employee severance-related costs. The remaining balance as of October 27, 2017 principally relates to lease obligations and will be paid over their remaining terms.

[0001564590-17-024351:notes:135]
[same as prior period, unchanged from 0001564590-17-018158:notes:128]

[0001564590-17-024351:notes:136]
|  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |
|  |  | November 2016 Plan |  |  | March 2016 Plan |  |
| Balance at beginning of period |  | $ | 13 |  |  | $ | 45 |  |
| Cash payments |  |  | (5 | ) |  |  | (42 | ) |
| Balance at end of period |  | $ | 8 |  |  | $ | 3 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-17-024351:notes:137]
[same as prior period, unchanged from 0001564590-17-018158:notes:130]

[0001564590-17-024351:notes:138]
[same as prior period, unchanged from 0001564590-17-018158:notes:131]

[0001564590-17-024351:notes:139]
|  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Effective tax rates |  |  | 17.7 | % |  |  | 26.1 | % |

[0001564590-17-024351:notes:140]
Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations which are headquartered in the Netherlands, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The differences in effective tax rates for the six months ended October 27, 2017 and October 28, 2016 were primarily a result of differences in discrete impacts related to stock-based compensation and differences in year-to-date profits before tax.

[0001564590-17-024351:notes:141]
As of October 27, 2017, we had $222 million of gross unrecognized tax benefits, of which $157 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $163 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-17-024351:notes:142]
[same as prior period, unchanged from 0001564590-17-018158:notes:135]

[0001564590-17-024351:notes:143]
On September 17, 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 from our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. On December 19, 2011, the Danish Tax Tribunal issued a ruling that our Danish subsidiary was not liable for Danish withholding tax. The Danish tax examination agency appealed to the Danish High Court in March 2012. In February 2016, the Danish High Court referred the case to the Court of Justice of the European Union where it was heard before the court in October 2017. We expect the court to issue their opinion and judgment by the end of fiscal 2018.

[0001564590-17-024351:notes:144]
[same as prior period, unchanged from 0001564590-17-018158:notes:137]


## us-gaap:EarningsPerShareTextBlock

[0001564590-17-024351:notes:145]
[same as prior period, unchanged from 0001564590-17-018158:notes:138]

[0001564590-17-024351:notes:146]
[same as prior period, unchanged from 0001564590-17-018158:notes:139]

[0001564590-17-024351:notes:147]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 175 |  |  | $ | 109 |  |  | $ | 311 |  |  | $ | 173 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 269 |  |  |  | 278 |  |  |  | 270 |  |  |  | 278 |  |
| Dilutive impact of employee equity award plans |  |  | 6 |  |  |  | 6 |  |  |  | 7 |  |  |  | 5 |  |
| Shares used in diluted computation |  |  | 275 |  |  |  | 284 |  |  |  | 277 |  |  |  | 283 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.65 |  |  | $ | 0.39 |  |  | $ | 1.15 |  |  | $ | 0.62 |  |
| Diluted |  | $ | 0.64 |  |  | $ | 0.38 |  |  | $ | 1.12 |  |  | $ | 0.61 |  |

[0001564590-17-024351:notes:148]
Potential shares from outstanding employee equity awards totaling 1 million and 5 million for the three months ended October 27, 2017 and October 28, 2016, respectively, and 2 million and 10 million for the six months ended October 27, 2017 and October 28, 2016, respectively, were excluded from the diluted net income per share calculations as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-17-024351:notes:149]
[same as prior period, unchanged from 0001564590-17-018158:notes:142]

[0001564590-17-024351:notes:150]
[same as prior period, unchanged from 0001564590-17-018158:notes:143]

[0001564590-17-024351:notes:151]
[same as prior period, unchanged from 0001564590-17-018158:notes:144]

[0001564590-17-024351:notes:152]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| United States, Canada and Latin America (Americas) |  | $ | 796 |  |  | $ | 768 |  |  | $ | 1,522 |  |  | $ | 1,504 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 431 |  |  |  | 396 |  |  |  | 832 |  |  |  | 783 |  |
| Asia Pacific (APAC) |  |  | 195 |  |  |  | 176 |  |  |  | 393 |  |  |  | 347 |  |
| Net revenues |  | $ | 1,422 |  |  | $ | 1,340 |  |  | $ | 2,747 |  |  | $ | 2,634 |  |

[0001564590-17-024351:notes:153]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $726 million and $697 million during the three months ended October 27, 2017 and October 28, 2016, respectively, and were $1,376 million and $1,363 million during the six months ended October 27, 2017 and October 28, 2016, respectively.

[0001564590-17-024351:notes:154]
[same as prior period, unchanged from 0001564590-17-018158:notes:147]

[0001564590-17-024351:notes:155]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
| U.S. |  | $ | 941 |  |  | $ | 425 |  |
| International |  |  | 5,024 |  |  |  | 4,496 |  |
| Total |  | $ | 5,965 |  |  | $ | 4,921 |  |

[0001564590-17-024351:notes:156]
[same as prior period, unchanged from 0001564590-17-018158:notes:149]

[0001564590-17-024351:notes:157]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
| U.S. |  | $ | 595 |  |  | $ | 593 |  |
| International |  |  | 200 |  |  |  | 206 |  |
| Total |  | $ | 795 |  |  | $ | 799 |  |

[0001564590-17-024351:notes:158]
[same as prior period, unchanged from 0001564590-17-018158:notes:151]

[0001564590-17-024351:notes:159]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2017 |  |  | October 28, 2016 |  |  | October 27, 2017 |  |  | October 28, 2016 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 23 | % |  |  | 23 | % |  |  | 21 | % |
| Tech Data Corporation (previously presented as Avnet, Inc.) |  |  | 19 | % |  |  | 20 | % |  |  | 20 | % |  |  | 20 | % |

[0001564590-17-024351:notes:160]
[same as prior period, unchanged from 0001564590-17-018158:notes:153]

[0001564590-17-024351:notes:161]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
| Arrow Electronics, Inc. |  |  | 14 | % |  |  | 15 | % |
| Tech Data Corporation (previously presented as Avnet, Inc.) |  |  | 15 | % |  |  | 14 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-17-024351:notes:162]
16. Commitments and Contingencies

[0001564590-17-024351:notes:163]
Operating Leases

[0001564590-17-024351:notes:164]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $203 million as of October 27, 2017.

[0001564590-17-024351:notes:165]
Purchase Orders and Other Commitments

[0001564590-17-024351:notes:166]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 27, 2017, we had $347 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 27, 2017 and April 28, 2017, such liability amounted to $10 million and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-17-024351:notes:167]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 27, 2017, we had $31 million in construction related obligations and $199 million in other purchase obligations.

[0001564590-17-024351:notes:168]
Financing Guarantees

[0001564590-17-024351:notes:169]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $66 million and $108 million of receivables during the six months ended October 27, 2017 and October 28, 2016, respectively.

[0001564590-17-024351:notes:170]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-17-024351:notes:171]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of October 27, 2017 and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-17-024351:notes:172]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 27, 2017, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-17-024351:notes:173]
Legal Contingencies

[0001564590-17-024351:notes:174]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict, and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-17-024351:notes:175]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are involved in active patent litigations brought by non-practicing entities. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-17-024351:notes:176]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No accrual has been recorded as of October 27, 2017 related to such matters as they are not probable and reasonably estimable.
