# NTAP note change history — 0001564590-17-018158 → 0001564590-17-024351


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-11-29):
[0001564590-17-024351:note_history:1]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $203 million as of October 27, 2017.
  (was, 2017-08-29, similarity 0.977):
[0001564590-17-018158:note_history:1]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $212 million as of July 28, 2017.

- changed (2017-11-29):
[0001564590-17-024351:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 27, 2017, we had $347 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 27, 2017 and April 28, 2017, such liability amounted to $10 million and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2017-08-29, similarity 0.9733):
[0001564590-17-018158:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 28, 2017, we had $295 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 28, 2017 and April 28, 2017, such liability amounted to $13 million and $10 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2017-11-29):
[0001564590-17-024351:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 27, 2017, we had $31 million in construction related obligations and $199 million in other purchase obligations.
  (was, 2017-08-29, similarity 0.9849):
[0001564590-17-018158:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 28, 2017, we had $29 million in construction related obligations and $235 million in other purchase obligations.

- changed (2017-11-29):
[0001564590-17-024351:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $66 million and $108 million of receivables during the six months ended October 27, 2017 and October 28, 2016, respectively.
  (was, 2017-08-29, similarity 0.9713):
[0001564590-17-018158:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $31 million and $76 million of receivables during the three months ended July 28, 2017 and July 29, 2016, respectively.

- changed (2017-11-29):
[0001564590-17-024351:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of October 27, 2017 and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2017-08-29, similarity 0.8076):
[0001564590-17-018158:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of July 28, 2017 and April 28, 2017, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- added (2017-11-29):
[0001564590-17-024351:note_history:6]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 27, 2017, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- added (2017-11-29):
[0001564590-17-024351:note_history:7]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are involved in active patent litigations brought by non-practicing entities. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

- added (2017-11-29):
[0001564590-17-024351:note_history:8]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No accrual has been recorded as of October 27, 2017 related to such matters as they are not probable and reasonably estimable.

- removed (2017-11-29):
[0001564590-17-018158:note_history:9]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 28, 2017, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- removed (2017-11-29):
[0001564590-17-018158:note_history:10]
We are subject to various legal proceedings and claims that arise in the normal course of business. Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends.

- removed (2017-11-29):
[0001564590-17-018158:note_history:11]
No accrual has been recorded as of July 28, 2017 related to such matters as they are not probable and reasonably estimable.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-29):
[0001564590-17-024351:note_history:12]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 28, 2017 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 27, 2017 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2017-08-29, similarity 0.8761):
[0001564590-17-018158:note_history:12]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 28, 2017 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 28, 2017 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- changed (2017-11-29):
[0001564590-17-024351:note_history:13]
There have been no significant changes in our significant accounting policies as of and for the six months ended October 27, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 28, 2017.
  (was, 2017-08-29, similarity 0.9625):
[0001564590-17-018158:note_history:13]
There have been no significant changes in our significant accounting policies as of and for the three months ended July 28, 2017, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 28, 2017.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-29):
[0001564590-17-024351:note_history:14]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):
  (was, 2017-08-29, similarity 0.8102):
[0001564590-17-018158:note_history:14]
The following table summarizes information relating to our long-term debt (in millions, except interest rates):

- changed (2017-11-29):
[0001564590-17-024351:note_history:15]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 2.00% Senior Notes Due September 2019 |  |  | 400 |  |  |  | 2.32 | % |  |  | — |  |  | N/A |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | — |  |  | N/A |  |
| Total principal amount |  |  | 2,300 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (10 | ) |  |  |  |  |  |  | (7 | ) |  |  |  |  |
| Total senior notes |  |  | 2,290 |  |  |  |  |  |  |  | 1,493 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (750 | ) |  |  |  |  |  |  | (749 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,540 |  |  |  |  |  |  | $ | 744 |  |  |  |  |  |
  (was, 2017-08-29, similarity 0.7877):
[0001564590-17-018158:note_history:15]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (6 | ) |  |  |  |  |  |  | (7 | ) |  |  |  |  |
| Total senior notes |  |  | 1,494 |  |  |  |  |  |  |  | 1,493 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (749 | ) |  |  |  |  |  |  | (749 | ) |  |  |  |  |
| Total long-term debt |  | $ | 745 |  |  |  |  |  |  | $ | 744 |  |  |  |  |  |

- added (2017-11-29):
[0001564590-17-024351:note_history:16]
__________________

- added (2017-11-29):
[0001564590-17-024351:note_history:17]
N/A - Not applicable

- added (2017-11-29):
[0001564590-17-024351:note_history:18]
In September 2017, we issued $400 million aggregate principal amount of 2.00% Senior Notes due on September 27, 2019 and $400 million aggregate principal amount of 3.30% Senior Notes due on September 29, 2024. We received total proceeds of approximately $795 million, net of discount and issuance costs, which will be used for general corporate purposes, including the repayment of our outstanding 2.00% Senior Notes due December 2017. Interest on these Senior Notes is payable semi-annually in March and September. Our 3.375% Senior Notes, 2.00% Senior Notes due December 2017 and 3.25% Senior Notes, with principal amounts of $500 million, $750 million and $250 million, respectively, were issued in June 2014, December 2012 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

- changed (2017-11-29):
[0001564590-17-024351:note_history:19]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 27, 2017, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2017-08-29, similarity 0.9915):
[0001564590-17-018158:note_history:19]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 28, 2017, we were in compliance with all covenants associated with the Senior Notes.

- added (2017-11-29):
[0001564590-17-024351:note_history:20]
On October 4, 2017, we issued a notice to redeem all our 2.00% Senior Notes due December 2017. On November 3, 2017, the notes were extinguished through redemption for cash at an aggregate redemption price of $751 million, plus accrued and unpaid interest.

- changed (2017-11-29):
[0001564590-17-024351:note_history:21]
As of October 27, 2017, our aggregate future principal debt maturities, including the 2.00% Senior Notes due December 2017, are as follows (in millions):
  (was, 2017-08-29, similarity 0.7532):
[0001564590-17-018158:note_history:21]
As of July 28, 2017, our aggregate future principal debt maturities are as follows (in millions):

- changed (2017-11-29):
[0001564590-17-024351:note_history:22]
| Fiscal Year |  | Amount |  |
| Remainder of 2018 |  | $ | 750 |  |
| 2020 |  |  | 400 |  |
| 2022 |  |  | 500 |  |
| Thereafter |  |  | 650 |  |
| Total |  | $ | 2,300 |  |
  (was, 2017-08-29, similarity 0.8826):
[0001564590-17-018158:note_history:22]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| 2022 |  |  | 500 |  |
| Thereafter |  |  | 250 |  |
| Total |  | $ | 1,500 |  |

- changed (2017-11-29):
[0001564590-17-024351:note_history:23]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended on July 17, 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of October 27, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $719 million, a weighted-average interest rate of 1.43% and maturities ranging from 13 days to 44 days. As of April 28, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $500 million, a weighted-average interest rate of 1.26% and maturities ranging from 7 days to 38 days.
  (was, 2017-08-29, similarity 0.9951):
[0001564590-17-018158:note_history:23]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended on July 17, 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of July 28, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $895 million, a weighted-average interest rate of 1.45% and maturities ranging from 13 days to 56 days. As of April 28, 2017, we had commercial paper notes outstanding with an aggregate principal amount of $500 million, a weighted-average interest rate of 1.26% and maturities ranging from 7 days to 38 days.

- changed (2017-11-29):
[0001564590-17-024351:note_history:24]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended on July 17, 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of October 27, 2017 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.
  (was, 2017-08-29, similarity 0.9939):
[0001564590-17-018158:note_history:24]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended on July 17, 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of July 28, 2017 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

- changed (2017-11-29):
[0001564590-17-024351:note_history:25]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, until such time as the related leases are terminated, the assets will remain on our condensed consolidated balance sheets and proceeds received by us from these transactions are reported as financing obligations. As of October 27, 2017, the balance of the remaining financing obligations, which relate to properties whose leases we expect to terminate in December 2017, was $130 million. At the end of the leaseback period, or when our continuing involvement under the leaseback agreement ends, this transaction will be reported as a non-cash sale and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain.
  (was, 2017-08-29, similarity 0.9957):
[0001564590-17-018158:note_history:25]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, until such time as the related leases are terminated, the assets will remain on our condensed consolidated balance sheets and proceeds received by us from these transactions are reported as financing obligations. As of July 28, 2017, the balance of the remaining financing obligations, which relate to properties whose leases we expect to terminate in December 2017, was $130 million. At the end of the leaseback period, or when our continuing involvement under the leaseback agreement ends, this transaction will be reported as a non-cash sale and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain.

- removed (2017-11-29):
[0001564590-17-018158:note_history:26]
Our 3.375% Senior Notes, 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $500 million, $750 million and $250 million, respectively, were issued in June 2014, December 2012 and December 2012, respectively. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-29):
[0001564590-17-024351:note_history:27]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):
  (was, 2017-08-29, similarity 0.8102):
[0001564590-17-018158:note_history:27]
The following table summarizes information relating to our long-term debt (in millions, except interest rates):

- changed (2017-11-29):
[0001564590-17-024351:note_history:28]
|  |  | October 27, 2017 |  |  | April 28, 2017 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 2.00% Senior Notes Due September 2019 |  |  | 400 |  |  |  | 2.32 | % |  |  | — |  |  | N/A |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | — |  |  | N/A |  |
| Total principal amount |  |  | 2,300 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (10 | ) |  |  |  |  |  |  | (7 | ) |  |  |  |  |
| Total senior notes |  |  | 2,290 |  |  |  |  |  |  |  | 1,493 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (750 | ) |  |  |  |  |  |  | (749 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,540 |  |  |  |  |  |  | $ | 744 |  |  |  |  |  |
  (was, 2017-08-29, similarity 0.7877):
[0001564590-17-018158:note_history:28]
|  |  | July 28, 2017 |  |  | April 28, 2017 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (6 | ) |  |  |  |  |  |  | (7 | ) |  |  |  |  |
| Total senior notes |  |  | 1,494 |  |  |  |  |  |  |  | 1,493 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | (749 | ) |  |  |  |  |  |  | (749 | ) |  |  |  |  |
| Total long-term debt |  | $ | 745 |  |  |  |  |  |  | $ | 744 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-29):
[0001564590-17-024351:note_history:29]
As of October 27, 2017, our aggregate future principal debt maturities, including the 2.00% Senior Notes due December 2017, are as follows (in millions):
  (was, 2017-08-29, similarity 0.7532):
[0001564590-17-018158:note_history:29]
As of July 28, 2017, our aggregate future principal debt maturities are as follows (in millions):

- changed (2017-11-29):
[0001564590-17-024351:note_history:30]
| Fiscal Year |  | Amount |  |
| Remainder of 2018 |  | $ | 750 |  |
| 2020 |  |  | 400 |  |
| 2022 |  |  | 500 |  |
| Thereafter |  |  | 650 |  |
| Total |  | $ | 2,300 |  |
  (was, 2017-08-29, similarity 0.8826):
[0001564590-17-018158:note_history:30]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| 2022 |  |  | 500 |  |
| Thereafter |  |  | 250 |  |
| Total |  | $ | 1,500 |  |
