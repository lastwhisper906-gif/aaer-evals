# NTAP note change history — 0001193125-11-330462 → 0001193125-12-096831


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2012-03-05):
[0001193125-12-096831:note_history:1]
As of January 27, 2012, future annual minimum lease payments under all non-cancelable facilities and equipment operating leases with an initial term in excess of one year totaled $402.7 million.
  (was, 2011-12-05, similarity 0.9022):
[0001193125-11-330462:note_history:1]
Future annual minimum lease payments under all non-cancelable facilities and equipment operating leases with an initial term in excess of one year as of October 28, 2011 totaled $390.7 million.

- changed (2012-03-05):
[0001193125-12-096831:note_history:2]
As of January 27, 2012, we have four leasing arrangements (Leasing Arrangements 1, 2, 3 and 4) with BNP Paribas LLC (BNPPLC), some of which require us to lease certain of our land to BNPPLC for a period of 99 years and to lease approximately 0.6 million square feet of office space from BNPPLC for our headquarters in Sunnyvale, California, which had an original cost of $149.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on LIBOR plus a spread or a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of the leases for two consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of the lease terms, we must elect one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received from the third-party and BNPPLC's cost, up to 85% of cost (residual guarantee); or (iii) pay BNPPLC supplemental payments for an amount equal to the difference between BNPPLC's cost and fair value, up to the residual guarantee, in which event we may recoup some or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period.
  (was, 2011-12-05, similarity 0.9638):
[0001193125-11-330462:note_history:2]
As of October 28, 2011, we have four leasing arrangements (Leasing Arrangements 1, 2, 3 and 4) with BNP Paribas LLC (BNPPLC), some of which require us to lease certain of our land to BNPPLC for a period of 99 years and to lease approximately 0.6 million square feet of office space for our headquarters in Sunnyvale, which had an original cost of $149.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on LIBOR plus a spread or a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of the leases for two consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of the lease terms, we must elect one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received from the third-party and BNPPLC's cost up to 85% of cost (residual guarantee); or (iii) pay BNPPLC supplemental payments for an amount equal to the difference between the residual guarantee and fair value, in which event we may recoup some or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period.

- changed (2012-03-05):
[0001193125-12-096831:note_history:3]
These leases require us to maintain specified financial covenants with which we were in compliance as of January 27, 2012.
  (was, 2011-12-05, similarity 0.9483):
[0001193125-11-330462:note_history:3]
These leases require us to maintain specified financial covenants with which we were in compliance as of October 28, 2011.

- added (2012-03-05):
[0001193125-12-096831:note_history:4]
As of January 27, 2012, we estimated that the fair value of certain properties under synthetic lease was $51.0 million below the cost of the properties. We are accruing for this deficiency over the remaining terms of the respective leases. As of January 27, 2012, a deficiency reserve of $32.4 million was included in other current liabilities.

- changed (2012-03-05):
[0001193125-12-096831:note_history:5]
In the normal course of business we make commitments to our third-party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. We had $220.4 million in non-cancelable purchase commitments with our contract manufacturers as of January 27, 2012. In addition, we recorded a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to product cost of sales. As of January 27, 2012 and April 29, 2011, such liability amounted to $3.2 million and $4.5 million, respectively, and is included in other current liabilities in the condensed consolidated balance sheets.
  (was, 2011-12-05, similarity 0.8896):
[0001193125-11-330462:note_history:5]
In the normal course of business we make commitments to our third-party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. We had $176.1 million in non-cancelable purchase commitments with our contract manufacturers as of October 28, 2011. In addition, we recorded a liability for firm non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to product cost of sales. As of October 28, 2011 and April 29, 2011, such liability amounted to $5.5 million and $4.5 million, respectively, and is included in other current liabilities in the condensed consolidated balance sheets.

- changed (2012-03-05):
[0001193125-12-096831:note_history:6]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course business for which we have not received goods or services. As of January 27, 2012, we had $48.5 million in capital purchase commitments and $230.7 million in other purchase commitments.
  (was, 2011-12-05, similarity 0.9463):
[0001193125-11-330462:note_history:6]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course business for which we have not received goods or services. We had $13.3 million in capital purchase commitments and $327.5 million in other purchase commitments as of October 28, 2011.

- changed (2012-03-05):
[0001193125-12-096831:note_history:7]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Beginning balance |  | $ | 65.0 |  |  | $ | 33.5 |  |  | $ | 40.5 |  |  | $ | 31.9 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 17.5 |  |  |  | 0.0 |  |
| Expense accrued during the period |  |  | 14.1 |  |  |  | 8.0 |  |  |  | 41.5 |  |  |  | 20.9 |  |
| Warranty costs incurred |  |  | (10.9 | ) |  |  | (5.8 | ) |  |  | (31.3 | ) |  |  | (17.1 | ) |
| Ending balance |  | $ | 68.2 |  |  | $ | 35.7 |  |  | $ | 68.2 |  |  | $ | 35.7 |  |
  (was, 2011-12-05, similarity 0.881):
[0001193125-11-330462:note_history:7]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Beginning balance |  | $ | 59.5 |  |  | $ | 32.1 |  |  | $ | 40.5 |  |  | $ | 31.9 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 17.5 |  |  |  | 0.0 |  |
| Expense accrued during the period |  |  | 15.7 |  |  |  | 7.0 |  |  |  | 27.4 |  |  |  | 12.9 |  |
| Warranty costs incurred |  |  | (10.2 | ) |  |  | (5.6 | ) |  |  | (20.4 | ) |  |  | (11.3 | ) |
| Ending balance |  | $ | 65.0 |  |  | $ | 33.5 |  |  | $ | 65.0 |  |  | $ | 33.5 |  |

- changed (2012-03-05):
[0001193125-12-096831:note_history:8]
We have both nonrecourse and recourse lease financing arrangements with third-party financing companies through new and preexisting relationships with customers. In addition, from time to time we provide guarantees for a portion of financing arrangements under which we could be called upon to make payments to these third-party financing companies in the event of nonpayment by end-user customers. Under the terms of the nonrecourse leases, we do not have any continuing obligations or liabilities to the third-party financing companies. Under the terms of the recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party financing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. As of January 27, 2012, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $101.2 million, and the related deferred revenue and cost of revenues totaled approximately $98.9 million and $9.6 million, respectively. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.
  (was, 2011-12-05, similarity 0.8665):
[0001193125-11-330462:note_history:8]
We have both nonrecourse and recourse lease financing arrangements with third-party leasing companies through new and preexisting relationships with customers. In addition, from time to time we provide guarantees for a portion of other financing arrangements under which we could be called upon to make payments to our third-party funding companies in the event of nonpayment by end-user customers. Under the terms of the nonrecourse leases, we do not have any continuing obligations or liabilities to the third-party leasing companies. Under the terms of the recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee, we defer the revenues associated with the end-user financing arrangement in accordance with our revenue recognition policies. As of October 28, 2011, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $105.1 million, and the related deferred revenue and cost of revenues totaled approximately $107.4 million and $12.4 million, respectively. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

- changed (2012-03-05):
[0001193125-12-096831:note_history:9]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as of January 27, 2012, as the outcome of these legal matters is currently not determinable.
  (was, 2011-12-05, similarity 0.7227):
[0001193125-11-330462:note_history:9]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as of October 28, 2011, as the outcome of these legal matters is currently not determinable.

- changed (2012-03-05):
[0001193125-12-096831:note_history:10]
On August 9, 2011, Amalgamated Bank filed a complaint in Delaware Chancery Court against us for the purpose of obtaining, in a summary proceeding, books and records to help Amalgamated Bank amend its complaint in the California lawsuit. Each of the parties filed cross motions for summary judgment, and a hearing was held before the Delaware Chancery Court on November 16, 2011. Following that hearing, the Court directed Amalgamated Bank to more narrowly tailor its requests. On December 5, 2011, the court allowed plaintiff to conduct a very limited document inspection. On February 6, 2012, the court denied plaintiff's motion to compel further document production.
  (was, 2011-12-05, similarity 0.8363):
[0001193125-11-330462:note_history:10]
On August 9, 2011, Amalgamated Bank filed a complaint in Delaware Chancery Court against us for the purpose of obtaining, in a summary proceeding, books and records to help Amalgamated Bank amend its complaint in the California lawsuit. Each of the parties filed cross motions for summary judgment, and a hearing was held before the Delaware Chancery Court on November 16, 2011. Following that hearing, the Court directed Amalgamated Bank to more narrowly tailor its requests.

- added (2012-03-05):
[0001193125-12-096831:note_history:11]
The plaintiff filed an amended complaint for a third time on September 15, 2011. This complaint alleged the same claims and requests for relief as the previous complaints. On January 9, 2012, the defendants filed motions to dismiss the amended complaint. A hearing on our motion to dismiss the California lawsuit will be held on March 23, 2012.

- removed (2012-03-05):
[0001193125-11-330462:note_history:12]
As of October 28, 2011, we estimated that the fair value of the properties under synthetic lease was $51.0 million below the residual guarantee. We are accruing for this deficiency over the remaining terms of the respective leases. As of October 28, 2011, a deficiency reserve of $27.0 million was included in other long-term liabilities.

- removed (2012-03-05):
[0001193125-11-330462:note_history:13]
The plaintiff filed an amended complaint in the California lawsuit on September 15, 2011. We will move to dismiss this or any other further amended complaint by January 9, 2012. A hearing on our motion to dismiss the California lawsuit is scheduled for February 24, 2012.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2012-03-05):
[0001193125-12-096831:note_history:14]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. The first, second and third quarters of fiscal 2012 and 2011 were each 13-week periods.
  (was, 2011-12-05, similarity 0.8757):
[0001193125-11-330462:note_history:14]
Fiscal Year — We operate on a 52- or 53-week year ending on the last Friday in April. The first and second quarters of fiscal 2012 and 2011 were each 13-week periods.

- changed (2012-03-05):
[0001193125-12-096831:note_history:15]
Basis of Presentation — The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2011 contained in our Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 23, 2011. The results of operations for the three and nine months ended January 27, 2012 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2011-12-05, similarity 0.8208):
[0001193125-11-330462:note_history:15]
Basis of Presentation — The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments that are, in the opinion of management, necessary for a fair presentation of our financial position, results of operations, and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, the statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with the Company's audited consolidated financial statements as of and for the fiscal year ended April 29, 2011 contained in the Company's Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 23, 2011. The results of operations for the three and six months ended October 28, 2011 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2012-03-05):
[0001193125-12-096831:note_history:16]
There have been no significant changes in our significant accounting policies as of and for the nine months ended January 27, 2012, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2011.
  (was, 2011-12-05, similarity 0.9058):
[0001193125-11-330462:note_history:16]
There have been no significant changes in our significant accounting policies for the six months ended October 28, 2011, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2011.

- changed (2012-03-05):
[0001193125-12-096831:note_history:17]
Our product revenues also include revenues from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer-negotiated refunds or return rights for the delivered elements.
  (was, 2011-12-05, similarity 0.9781):
[0001193125-11-330462:note_history:17]
Our product revenue also includes revenue from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer-negotiated refunds or return rights for the delivered elements.

- changed (2012-03-05):
[0001193125-12-096831:note_history:18]
For our non-software deliverables, we recognize revenue based on the new standards and allocate the arrangement consideration based on the relative selling price of the deliverables. For our non-software deliverables, we use BESP as our selling price. For our software entitlements and support services, we generally use VSOE as our selling price. When we are unable to establish selling prices using VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement consideration.
  (was, 2011-12-05, similarity 0.999):
[0001193125-11-330462:note_history:18]
For our non-software deliverables, we recognize revenue based on the new standards and allocate the arrangement consideration based on the relative selling price of the deliverables. For our non-software deliverables, we use BESP as our selling price. For our software entitlements and support services, we generally use VSOE as our selling price. When we are unable to establish selling price using VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement consideration.

- added (2012-03-05):
[0001193125-12-096831:note_history:19]
When VSOE cannot be established, we attempt to establish the selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, we typically are not able to determine TPE for our products or services.

- changed (2012-03-05):
[0001193125-12-096831:note_history:20]
When we are unable to establish the selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.
  (was, 2011-12-05, similarity 0.9973):
[0001193125-11-330462:note_history:20]
When we are unable to establish selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

- changed (2012-03-05):
[0001193125-12-096831:note_history:21]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal year 2011, we recognize revenue based on software revenue recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be delivered at a future date and VSOE of fair value of all undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is software entitlements and maintenance (SEM) and/or service. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the contract fee is recognized as product revenues. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire arrangement is recognized ratably over the maintenance period.
  (was, 2011-12-05, similarity 0.9996):
[0001193125-11-330462:note_history:21]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal year 2011, we recognize revenue based on software revenue recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be delivered at a future date and VSOE of fair value of all undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is software entitlements and maintenance (SEM) and/or service. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the contract fee is recognized as product revenue. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire arrangement is recognized ratably over the maintenance period.

- changed (2012-03-05):
[0001193125-12-096831:note_history:22]
In May 2011, the FASB issued new guidance for fair value measurements to provide a consistent definition of fair value and ensure that the fair value measurement and disclosure requirements are similar between GAAP and International Financial Reporting Standards. The guidance changes certain fair value measurement principles and enhances the disclosure requirements, particularly for level 3 fair value measurements. The guidance is effective for us prospectively beginning in our fourth quarter of fiscal 2012. There will be no impact to our results of operations, financial position and cash flows as the guidance relates only to financial statement presentation.
  (was, 2011-12-05, similarity 0.8073):
[0001193125-11-330462:note_history:22]
In May 2011, the FASB issued new guidance for fair value measurements to provide a consistent definition of fair value and ensure that the fair value measurement and disclosure requirements are similar between GAAP and International Financial Reporting Standards. The guidance changes certain fair value measurement principles and enhances the disclosure requirements, particularly for level 3 fair value measurements. The guidance is effective for us prospectively beginning in the fourth quarter of fiscal 2012, and we are currently evaluating the impact of adoption on our consolidated financial statements.

- changed (2012-03-05):
[0001193125-12-096831:note_history:23]
In June 2011, as modified in December 2011, the FASB issued new guidance on the presentation of comprehensive income. Specifically, the new guidance requires an entity to present components of net income and other comprehensive income in one continuous statement, referred to as the statement of comprehensive income, or in two separate, but consecutive statements. The new guidance eliminates the current option to report other comprehensive income and its components in the statement of stockholders' equity. The specific requirement to present items that are reclassified from accumulated other comprehensive income to net income separately within their respective components of net income and other comprehensive income has been deferred. While the new guidance changes the presentation of comprehensive income, there are no changes to the components that are recognized in net income or other comprehensive income under current accounting guidance. This new guidance is effective for us beginning in our first quarter of fiscal 2013 and is required to be applied retrospectively. There will be no impact to our results of operations, financial position and cash flows as the guidance relates only to financial statement presentation.
  (was, 2011-12-05, similarity 0.857):
[0001193125-11-330462:note_history:23]
In June 2011, the FASB issued new guidance on the presentation of comprehensive income. Specifically, the new guidance requires an entity to present components of net income and other comprehensive income in one continuous statement, referred to as the statement of comprehensive income, or in two separate, but consecutive statements. The new guidance eliminates the current option to report other comprehensive income and its components in the statement of stockholders' equity. While the new guidance changes the presentation of comprehensive income, there are no changes to the components that are recognized in net income or other comprehensive income under current accounting guidance. This new guidance is effective for us beginning in our first quarter of fiscal 2013 and is required to be applied retrospectively. There will be no impact to our results as the guidance relates only to financial statement presentation.

- added (2012-03-05):
[0001193125-12-096831:note_history:24]
In December 2011, the FASB issued new guidance that will require us to disclose information about offsetting arrangements associated with financial and derivative instruments to enable users of our financial statements to understand the effect of those arrangements on our financial position. This guidance is effective for us beginning in our first quarter of fiscal 2014 and is required to be applied retrospectively. We are currently evaluating the impact of adoption on our consolidated financial statements.

- changed (2012-03-05):
[0001193125-12-096831:note_history:25]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefits; stock-based compensation; loss contingencies; investment impairments; income taxes, and fair value measurements. Actual results could differ materially from those estimates.
  (was, 2011-12-05, similarity 0.9667):
[0001193125-11-330462:note_history:25]
The preparation of the consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; self-insurance; stock-based compensation; loss contingencies; investment impairments; income taxes, and fair value measurements. Actual results could differ from those estimates.

- removed (2012-03-05):
[0001193125-11-330462:note_history:26]
When VSOE cannot be established, the Company attempts to establish the selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE for our products or services.


## ntap:LongTermDebtByCurrentAndNonCurrentTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2012-03-05):
[0001193125-12-096831:note_history:27]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 9.3 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.4 |  |  |  | 6.0 |  |
| Total |  | $ | 14.7 |  |  | $ | 11.5 |  |

- removed (2012-03-05):
[0001193125-11-330462:note_history:28]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 8.1 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.2 |  |  |  | 6.0 |  |
|  |  | $ | 13.3 |  |  | $ | 11.5 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2012-03-05):
[0001193125-12-096831:note_history:29]
On June 10, 2008, we issued $1,265.0 million aggregate principal amount of 1.75% Convertible Senior Notes due 2013 (the Notes). The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.75% per annum. The Notes will mature on June 1, 2013 unless earlier repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified below, based on an initial conversion rate of 31.40 shares of common stock per $1,000 principal amount of Notes (which represents an initial effective conversion price of the Notes of $31.85 per share), subject to adjustment as described in the indenture governing the Notes.
  (was, 2011-12-05, similarity 0.8701):
[0001193125-11-330462:note_history:29]
On June 10, 2008, we issued $1,265.0 million aggregate principal amount of 1.75% Convertible Senior Notes due 2013 (the Notes). The Notes are unsecured, unsubordinated obligations of the Company. Interest is payable in cash semi-annually at a rate of 1.75% per annum. The Notes will mature on June 1, 2013 unless repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified below, based on an initial conversion rate of 31.40 shares of common stock per $1,000 principal amount of Notes (which represents an initial effective conversion price of the Notes of approximately $31.85 per share), subject to adjustment as described in the indenture governing the Notes.

- added (2012-03-05):
[0001193125-12-096831:note_history:30]
Our common stock price did not exceed the conversion threshold price of $41.41 per share set forth for the Notes for at least 20 trading days during the 30 consecutive trading days ended December 31, 2011. Accordingly, as of January 27, 2012, the Notes were not convertible at the option of the holder and, therefore, the carrying value of the Notes was classified as long-term debt and the difference between the principal amount and the carrying value of the Notes is reflected as equity on our condensed consolidated balance sheet as of that date.

- changed (2012-03-05):
[0001193125-12-096831:note_history:31]
Upon conversion of any Notes, we deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal amount of the Notes, shares of our common stock. As of January 27, 2012, shares issued related to the Notes were minimal. Based on the closing price of our common stock of $37.28 on January 27, 2012, the if-converted value of our Notes exceeded their principal amount by approximately $215.6 million.
  (was, 2011-12-05, similarity 0.9683):
[0001193125-11-330462:note_history:31]
Upon conversion of any Notes, we deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal amount of the Notes, shares of our common stock. As of October 28, 2011, shares issued related to the Notes were minimal. Based on the closing price of our common stock of $41.59 on October 28, 2011, the if-converted value of our Notes exceeded their principal amount by approximately $387.0 million.

- changed (2012-03-05):
[0001193125-12-096831:note_history:32]
The following table reflects the carrying value of the Notes (in millions):
  (was, 2011-12-05, similarity 0.7006):
[0001193125-11-330462:note_history:32]
The following table presents the amount of interest cost recognized (in millions):

- changed (2012-03-05):
[0001193125-12-096831:note_history:33]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| 1.75% Convertible Senior Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (76.2 | ) |  |  | (114.6 | ) |
| Net carrying amount of Notes |  | $ | 1,188.8 |  |  | $ | 1,150.4 |  |
  (was, 2011-12-05, similarity 0.9489):
[0001193125-11-330462:note_history:33]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (89.2 | ) |  |  | (114.6 | ) |
| Net carrying amount of Notes |  | $ | 1,175.8 |  |  | $ | 1,150.4 |  |

- changed (2012-03-05):
[0001193125-12-096831:note_history:34]
We capitalize interest on facility assets under construction and on significant software development projects. The following table presents the amount of interest expense recognized related to the Notes (in millions):
  (was, 2011-12-05, similarity 0.6728):
[0001193125-11-330462:note_history:34]
We capitalize interest on facility assets under construction and on significant software development projects.

- changed (2012-03-05):
[0001193125-12-096831:note_history:35]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 16.5 |  |  | $ | 16.5 |  |
| Amortization of debt discount |  |  | 13.0 |  |  |  | 12.2 |  |  |  | 38.4 |  |  |  | 36.1 |  |
| Amortization of debt issuance costs |  |  | 1.1 |  |  |  | 1.1 |  |  |  | 3.3 |  |  |  | 3.1 |  |
| Less capitalized interest |  |  | (0.9 | ) |  |  | 0.0 |  |  |  | (4.3 | ) |  |  | 0.0 |  |
| Total interest expense related to Notes |  | $ | 18.7 |  |  | $ | 18.8 |  |  | $ | 53.9 |  |  | $ | 55.7 |  |
  (was, 2011-12-05, similarity 0.7672):
[0001193125-11-330462:note_history:35]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28,2011 |  |  | October 29,2010 |  |  | October 28,2011 |  |  | October 29,2010 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 11.0 |  |  | $ | 11.0 |  |
| Amortization of debt discount |  |  | 12.8 |  |  |  | 12.0 |  |  |  | 25.4 |  |  |  | 23.9 |  |
| Amortization of issuance costs |  |  | 1.1 |  |  |  | 1.0 |  |  |  | 2.2 |  |  |  | 2.0 |  |
| Less capitalized interest |  |  | (3.5 | ) |  |  | 0.0 |  |  |  | (3.5 | ) |  |  | 0.0 |  |
| Total interest expense recognized |  | $ | 15.9 |  |  | $ | 18.5 |  |  | $ | 35.1 |  |  | $ | 36.9 |  |

- changed (2012-03-05):
[0001193125-12-096831:note_history:36]
The following table reflects the remaining debt discount and issuance costs as of January 27, 2012 (in millions):
  (was, 2011-12-05, similarity 0.9444):
[0001193125-11-330462:note_history:36]
The following table reflects the remaining debt discount and issuance costs as of October 28, 2011 (in millions):

- changed (2012-03-05):
[0001193125-12-096831:note_history:37]
Concurrent with the issuance of the Notes, we purchased Note hedges and sold warrants. The separate Note hedge and warrant transactions are structured to reduce the potential future economic dilution associated with the conversion of the Notes.
  (was, 2011-12-05, similarity 0.998):
[0001193125-11-330462:note_history:37]
Concurrent with the issuance of the Notes, we purchased Note hedges and sold warrants. The separate Note hedge and warrants transactions are structured to reduce the potential future economic dilution associated with the conversion of the Notes.

- changed (2012-03-05):
[0001193125-12-096831:note_history:38]
|  | • |  | Note Hedges: As of January 27, 2012 and April 29, 2011, we had arrangements with counterparties to buy up to approximately 31.8 million shares, subject to anti-dilution adjustments, of our common stock at a price of $31.85 per share, subject to adjustment. The Note hedge transactions will expire at the earlier of (1) the last day on which any Notes remain outstanding or (2) the scheduled trading day immediately preceding the maturity date of the Notes. Upon exercise of the Note hedges, we have the option to receive cash or shares of our common stock equal to the difference between the then market price and the strike price of the hedges. |
  (was, 2011-12-05, similarity 0.9843):
[0001193125-11-330462:note_history:38]
| • |  | Note Hedges: As of October 28, 2011 and April 29, 2011, we had arrangements with counterparties to buy up to approximately 31.8 million shares, subject to anti-dilution adjustments, of our common stock at a price of $31.85 per share, subject to adjustment. The Note hedge transactions will expire at the earlier of (1) the last day on which any Notes remain outstanding or (2) the scheduled trading day immediately preceding the maturity date of the Notes. Upon exercise of the Note hedges, we have the option to receive cash or shares of our common stock equal to the difference between the then market price and the strike price of the hedges. |

- changed (2012-03-05):
[0001193125-12-096831:note_history:39]
|  | • |  | Warrants: As of January 27, 2012 and April 29, 2011, we had outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |
  (was, 2011-12-05, similarity 0.9853):
[0001193125-11-330462:note_history:39]
|  | • |  | Warrants: As of October 28, 2011 and April 29, 2011, we had outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |

- changed (2012-03-05):
[0001193125-12-096831:note_history:40]
As of January 27, 2012, we were subject to potential dilution on the approximately 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of $31.85.
  (was, 2011-12-05, similarity 0.9429):
[0001193125-11-330462:note_history:40]
As of October 28, 2011, we were subject to potential dilution on the approximately 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of approximately $31.85.

- changed (2012-03-05):
[0001193125-12-096831:note_history:41]
As of January 27, 2012, we received a minimal number of shares related to the Note hedge transactions and no cash or shares were delivered related to the warrant transactions.
  (was, 2011-12-05, similarity 0.8459):
[0001193125-11-330462:note_history:41]
As of October 28, 2011, receipts of shares related to the Note hedge transactions were minimal and no cash or shares were delivered related to the warrant transactions.

- added (2012-03-05):
[0001193125-12-096831:note_history:42]
As of January 27, 2012, the approximate fair value of the principal amount of the Notes, which includes the debt and equity components, was approximately $1,630.8 million, or 129% of the face value of the Notes, based upon quoted market information.

- added (2012-03-05):
[0001193125-12-096831:note_history:43]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 9.3 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.4 |  |  |  | 6.0 |  |
| Total |  | $ | 14.7 |  |  | $ | 11.5 |  |

- removed (2012-03-05):
[0001193125-11-330462:note_history:44]
Our common stock price did not exceed the conversion threshold price of $41.41 per share set forth for the Notes for at least 20 trading days during the 30 consecutive trading days ended September 30, 2011. Accordingly, as of October 28, 2011, the Notes were not convertible at the option of the holder and, therefore, the carrying value of the Notes was classified as long-term debt and the difference between the principal amount and the carrying value of the Notes is reflected as equity on our condensed consolidated balance sheet.

- removed (2012-03-05):
[0001193125-11-330462:note_history:45]
The following table reflects the carrying value of our convertible debt as of October 28, 2011 and April 29, 2011, respectively (in millions):

- removed (2012-03-05):
[0001193125-11-330462:note_history:46]
As of October 28, 2011, the approximate fair value of the principal amount of our Notes, which includes the debt and equity components, was approximately $1,761.5 million, or 139% of the face value of the Notes, based upon quoted market information.

- removed (2012-03-05):
[0001193125-11-330462:note_history:47]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 8.1 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.2 |  |  |  | 6.0 |  |
|  |  | $ | 13.3 |  |  | $ | 11.5 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2012-03-05):
[0001193125-12-096831:note_history:48]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| 1.75% Convertible Senior Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (76.2 | ) |  |  | (114.6 | ) |
| Net carrying amount of Notes |  | $ | 1,188.8 |  |  | $ | 1,150.4 |  |
  (was, 2011-12-05, similarity 0.9489):
[0001193125-11-330462:note_history:48]
|  |  | October 28,2011 |  |  | April 29,2011 |  |
| 1.75% Convertible Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (89.2 | ) |  |  | (114.6 | ) |
| Net carrying amount of Notes |  | $ | 1,175.8 |  |  | $ | 1,150.4 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2012-03-05):
[0001193125-12-096831:note_history:49]
Our product revenues also include revenues from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer-negotiated refunds or return rights for the delivered elements.
  (was, 2011-12-05, similarity 0.9781):
[0001193125-11-330462:note_history:49]
Our product revenue also includes revenue from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer-negotiated refunds or return rights for the delivered elements.

- changed (2012-03-05):
[0001193125-12-096831:note_history:50]
For our non-software deliverables, we recognize revenue based on the new standards and allocate the arrangement consideration based on the relative selling price of the deliverables. For our non-software deliverables, we use BESP as our selling price. For our software entitlements and support services, we generally use VSOE as our selling price. When we are unable to establish selling prices using VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement consideration.
  (was, 2011-12-05, similarity 0.999):
[0001193125-11-330462:note_history:50]
For our non-software deliverables, we recognize revenue based on the new standards and allocate the arrangement consideration based on the relative selling price of the deliverables. For our non-software deliverables, we use BESP as our selling price. For our software entitlements and support services, we generally use VSOE as our selling price. When we are unable to establish selling price using VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement consideration.

- added (2012-03-05):
[0001193125-12-096831:note_history:51]
When VSOE cannot be established, we attempt to establish the selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, we typically are not able to determine TPE for our products or services.

- changed (2012-03-05):
[0001193125-12-096831:note_history:52]
When we are unable to establish the selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.
  (was, 2011-12-05, similarity 0.9973):
[0001193125-11-330462:note_history:52]
When we are unable to establish selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

- changed (2012-03-05):
[0001193125-12-096831:note_history:53]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal year 2011, we recognize revenue based on software revenue recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be delivered at a future date and VSOE of fair value of all undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is software entitlements and maintenance (SEM) and/or service. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the contract fee is recognized as product revenues. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire arrangement is recognized ratably over the maintenance period.
  (was, 2011-12-05, similarity 0.9996):
[0001193125-11-330462:note_history:53]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal year 2011, we recognize revenue based on software revenue recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be delivered at a future date and VSOE of fair value of all undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is software entitlements and maintenance (SEM) and/or service. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the contract fee is recognized as product revenue. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire arrangement is recognized ratably over the maintenance period.

- removed (2012-03-05):
[0001193125-11-330462:note_history:54]
Accounting Standards Recently Adopted

- removed (2012-03-05):
[0001193125-11-330462:note_history:55]
When VSOE cannot be established, the Company attempts to establish the selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, the Company is typically not able to determine TPE for our products or services.
