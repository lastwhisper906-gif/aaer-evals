# NTAP MD&A — 0001193125-12-096831


## mdna

[0001193125-12-096831:mdna:1]
Item 2. Management’s Discussion and Analysis of Financial
Condition and Results of Operations

[0001193125-12-096831:mdna:2]
[same as prior period, unchanged from 0001193125-11-330462:mdna:2]

[0001193125-12-096831:mdna:3]
[same as prior period, unchanged from 0001193125-11-330462:mdna:3]

[0001193125-12-096831:mdna:4]
[same as prior period, unchanged from 0001193125-11-330462:mdna:4]

[0001193125-12-096831:mdna:5]
[same as prior period, unchanged from 0001193125-11-330462:mdna:5]

[0001193125-12-096831:mdna:6]
[same as prior period, unchanged from 0001193125-11-330462:mdna:6]

[0001193125-12-096831:mdna:7]
|  | • |  | acquisitions and joint ventures, growth opportunities, investments and legal proceedings; |

[0001193125-12-096831:mdna:8]
[same as prior period, unchanged from 0001193125-11-330462:mdna:8]

[0001193125-12-096831:mdna:9]
[same as prior period, unchanged from 0001193125-11-330462:mdna:9]

[0001193125-12-096831:mdna:10]
[same as prior period, unchanged from 0001193125-11-330462:mdna:10]

[0001193125-12-096831:mdna:11]
[same as prior period, unchanged from 0001193125-11-330462:mdna:11]

[0001193125-12-096831:mdna:12]
[same as prior period, unchanged from 0001193125-11-330462:mdna:12]

[0001193125-12-096831:mdna:13]
|  | • |  | the conversion, maturation or repurchase of the Notes; |

[0001193125-12-096831:mdna:14]
|  | • |  | compliance with laws, regulations and debt covenants; |

[0001193125-12-096831:mdna:15]
[same as prior period, unchanged from 0001193125-11-330462:mdna:15]

[0001193125-12-096831:mdna:16]
[same as prior period, unchanged from 0001193125-11-330462:mdna:16]

[0001193125-12-096831:mdna:17]
|  | • |  | acceptance of, and demand for, our products, including our recent product introductions; |

[0001193125-12-096831:mdna:18]
[same as prior period, unchanged from 0001193125-11-330462:mdna:18]

[0001193125-12-096831:mdna:19]
|  | • |  | general economic and market conditions, particularly the continuing fiscal challenges in the United States (U.S.) and Europe; |

[0001193125-12-096831:mdna:20]
[same as prior period, unchanged from 0001193125-11-330462:mdna:20]

[0001193125-12-096831:mdna:21]
[same as prior period, unchanged from 0001193125-11-330462:mdna:21]

[0001193125-12-096831:mdna:22]
[same as prior period, unchanged from 0001193125-11-330462:mdna:22]

[0001193125-12-096831:mdna:23]
[same as prior period, unchanged from 0001193125-11-330462:mdna:23]

[0001193125-12-096831:mdna:24]
[same as prior period, unchanged from 0001193125-11-330462:mdna:48]

[0001193125-12-096831:mdna:25]
[same as prior period, unchanged from 0001193125-11-330462:mdna:24]

[0001193125-12-096831:mdna:26]
[same as prior period, unchanged from 0001193125-11-330462:mdna:25]

[0001193125-12-096831:mdna:27]
[same as prior period, unchanged from 0001193125-11-330462:mdna:26]

[0001193125-12-096831:mdna:28]
[same as prior period, unchanged from 0001193125-11-330462:mdna:27]

[0001193125-12-096831:mdna:29]
[same as prior period, unchanged from 0001193125-11-330462:mdna:28]

[0001193125-12-096831:mdna:30]
[same as prior period, unchanged from 0001193125-11-330462:mdna:29]

[0001193125-12-096831:mdna:31]
[same as prior period, unchanged from 0001193125-11-330462:mdna:30]

[0001193125-12-096831:mdna:32]
[same as prior period, unchanged from 0001193125-11-330462:mdna:31]

[0001193125-12-096831:mdna:33]
[same as prior period, unchanged from 0001193125-11-330462:mdna:32]

[0001193125-12-096831:mdna:34]
[same as prior period, unchanged from 0001193125-11-330462:mdna:33]

[0001193125-12-096831:mdna:35]
[same as prior period, unchanged from 0001193125-11-330462:mdna:34]

[0001193125-12-096831:mdna:36]
[same as prior period, unchanged from 0001193125-11-330462:mdna:35]

[0001193125-12-096831:mdna:37]
[same as prior period, unchanged from 0001193125-11-330462:mdna:36]

[0001193125-12-096831:mdna:38]
[same as prior period, unchanged from 0001193125-11-330462:mdna:37]

[0001193125-12-096831:mdna:39]
[same as prior period, unchanged from 0001193125-11-330462:mdna:38]

[0001193125-12-096831:mdna:40]
[same as prior period, unchanged from 0001193125-11-330462:mdna:39]

[0001193125-12-096831:mdna:41]
[same as prior period, unchanged from 0001193125-11-330462:mdna:40]

[0001193125-12-096831:mdna:42]
[same as prior period, unchanged from 0001193125-11-330462:mdna:41]

[0001193125-12-096831:mdna:43]
[same as prior period, unchanged from 0001193125-11-330462:mdna:42]

[0001193125-12-096831:mdna:44]
|  | • |  | the results of our ongoing litigation, tax audits, government audits, inquiries and investigations; and |

[0001193125-12-096831:mdna:45]
[same as prior period, unchanged from 0001193125-11-330462:mdna:44]

[0001193125-12-096831:mdna:46]
[same as prior period, unchanged from 0001193125-11-330462:mdna:45]

[0001193125-12-096831:mdna:47]
[same as prior period, unchanged from 0001193125-11-330462:mdna:46]

[0001193125-12-096831:mdna:48]
On May 6, 2011, we completed the acquisition of certain
assets related to the Engenio external storage systems business (Engenio) of LSI Corporation (LSI). We paid LSI $480.0 million in cash and also assumed certain liabilities related to Engenio. We expect this acquisition to enable us to address
growing customer requirements in the areas of high bandwidth and intensive analytics workloads such as video, including full-motion video capture and digital video surveillance, as well as high-performance computing applications, such as genomics
sequencing and scientific research. Our consolidated net revenues for the three and nine months ended January 27, 2012 include $178.3 million and $517.8 million, respectively, attributable to Engenio since the acquisition.

[0001193125-12-096831:mdna:49]
[same as prior period, unchanged from 0001193125-11-330462:mdna:60]

[0001193125-12-096831:mdna:50]
Net revenues for the three and nine months ended January 27, 2012 were $1,565.5
million, up $275.9 million, or 21%, and $4,530.7 million, up $836.4 million, or 23%, respectively, from the comparable periods in the prior year. The revenue growth in each of these periods was primarily due to our acquisition of Engenio, continued
demand for our storage efficiency and data management solutions, and an increase in hardware maintenance contract revenue. Gross profit as a percentage of net revenues decreased during the three and nine months ended January 27, 2012 compared
to the same periods in the prior year, primarily due to the inclusion of lower gross margin E-Series OEM products resulting from the Engenio acquisition in the revenue mix and the impact of higher discounting. These decreases were partially offset
by manufacturing cost reductions.

[0001193125-12-096831:mdna:51]
Sales and marketing, research and development, and general and administrative expenses for
the three and nine months ended January 27, 2012 totaled $748.5 million, up 20%, and $2,185.9 million, up 22%, respectively, from the comparable periods in the prior year. These increases were primarily due to a 25% and 27% increase in average
headcount in the three and nine months ended January 27, 2012, respectively, from the comparable periods in the prior year. The May 2011 acquisition of Engenio represented approximately 10% of the average headcount for the three and nine months
ended January 27, 2012.

[0001193125-12-096831:mdna:52]
[same as prior period, unchanged from 0001193125-11-330462:mdna:51]

[0001193125-12-096831:mdna:53]
Our discussion and analysis of financial condition and results of operations are based upon our condensed consolidated financial
statements, which have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP). The preparation of such statements requires us to make estimates and assumptions that affect the reported
amounts of revenues and expenses during the reporting periods and the reported amounts of assets and liabilities as of the date of the financial statements. Our estimates are based on historical experience and other assumptions that we consider to
be appropriate under the circumstances. However, future results may vary from our estimates.

[0001193125-12-096831:mdna:54]
We believe the accounting
policies discussed under Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in our Annual Report on Form 10-K for the fiscal year ended April 29, 2011 are significantly affected
by critical accounting estimates and that they are both highly important to the portrayal of our financial condition and results and require difficult management judgments and assumptions about matters that are inherently uncertain. There have been
no material changes to the critical accounting policies and estimates as filed in such report.

[0001193125-12-096831:mdna:55]
[same as prior period, unchanged from 0001193125-11-330462:mdna:54]

[0001193125-12-096831:mdna:56]
[same as prior period, unchanged from 0001193125-11-330462:mdna:55]

[0001193125-12-096831:mdna:57]
[same as prior period, unchanged from 0001193125-11-330462:mdna:56]

[0001193125-12-096831:mdna:58]
[same as prior period, unchanged from 0001193125-11-330462:mdna:57]

[0001193125-12-096831:mdna:59]
[same as prior period, unchanged from 0001193125-11-330462:mdna:58]

[0001193125-12-096831:mdna:60]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 67.9 | % |  |  | 65.5 | % |  |  | 67.2 | % |  |  | 65.1 | % |
| Software entitlements and maintenance |  |  | 13.0 |  |  |  | 14.2 |  |  |  | 13.2 |  |  |  | 14.5 |  |
| Service |  |  | 19.1 |  |  |  | 20.3 |  |  |  | 19.6 |  |  |  | 20.4 |  |
| Net revenues |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 33.1 |  |  |  | 25.5 |  |  |  | 31.2 |  |  |  | 26.1 |  |
| Cost of software entitlements and maintenance |  |  | 0.4 |  |  |  | 0.3 |  |  |  | 0.4 |  |  |  | 0.3 |  |
| Cost of service |  |  | 8.5 |  |  |  | 8.6 |  |  |  | 8.4 |  |  |  | 8.6 |  |
| Gross profit |  |  | 58.0 |  |  |  | 65.6 |  |  |  | 60.0 |  |  |  | 65.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 30.5 |  |  |  | 30.8 |  |  |  | 30.6 |  |  |  | 30.7 |  |
| Research and development |  |  | 13.3 |  |  |  | 12.9 |  |  |  | 13.4 |  |  |  | 12.8 |  |
| General and administrative |  |  | 4.0 |  |  |  | 4.8 |  |  |  | 4.3 |  |  |  | 4.9 |  |
| Restructuring and other charges |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |  |  | — |  |
| Acquisition-related expense |  |  | 0.2 |  |  |  | — |  |  |  | 0.2 |  |  |  | — |  |
| Total operating expenses |  |  | 48.0 |  |  |  | 48.4 |  |  |  | 48.5 |  |  |  | 48.4 |  |
| Income from operations |  |  | 10.0 |  |  |  | 17.2 |  |  |  | 11.5 |  |  |  | 16.6 |  |
| Other expense, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 0.6 |  |  |  | 0.8 |  |  |  | 0.6 |  |  |  | 0.8 |  |
| Interest expense |  |  | (1.2 | ) |  |  | (1.5 | ) |  |  | (1.2 | ) |  |  | (1.5 | ) |
| Other income (expense), net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total other expense, net |  |  | (0.6 | ) |  |  | (0.7 | ) |  |  | (0.6 | ) |  |  | (0.7 | ) |
| Income before income taxes |  |  | 9.4 |  |  |  | 16.5 |  |  |  | 10.9 |  |  |  | 15.9 |  |
| Provision for income taxes |  |  | 1.7 |  |  |  | 2.0 |  |  |  | 1.6 |  |  |  | 2.0 |  |
| Net income |  |  | 7.7 | % |  |  | 14.5 | % |  |  | 9.3 | % |  |  | 13.9 | % |

[0001193125-12-096831:mdna:61]
[same as prior period, unchanged from 0001193125-11-330462:mdna:73]

[0001193125-12-096831:mdna:62]
[same as prior period, unchanged from 0001193125-11-330462:mdna:62]

[0001193125-12-096831:mdna:63]
Net Revenues — Net revenues for the three and nine months ended January 27, 2012 and January 28, 2011 were as
follows (in millions, except percentages):

[0001193125-12-096831:mdna:64]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| Net revenues |  | $ | 1,565.5 |  |  | $ | 1,289.6 |  |  |  | 21 | % |  | $ | 4,530.7 |  |  | $ | 3,694.3 |  |  |  | 23 | % |

[0001193125-12-096831:mdna:65]
Net revenues increased by $275.9 million, or 21%, and increased by $836.4 million, or 23%, for the three
and nine months ended January 27, 2012, respectively, from the comparable periods in the prior year. The increase in our net revenues for both periods was primarily due to an increase in product revenues, which comprised 68% and 67% of net
revenues for the three and nine months ended January 27, 2012, respectively compared to 65% in each of the three and nine months ended January 28, 2011.

[0001193125-12-096831:mdna:66]
Sales through our indirect channels represented 79% and 78% of net revenues for the three and nine months ended January 27, 2012, respectively, and represented 74% and 72% of net revenues for the
three and nine months ended January 28, 2011, respectively. The increase in our indirect channels as a percentage of net revenues reflects the acquisition of Engenio.

[0001193125-12-096831:mdna:67]
[same as prior period, unchanged from 0001193125-11-330462:mdna:67]

[0001193125-12-096831:mdna:68]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | % of NetRevenues |  |  | January 28,2011 |  |  | % of NetRevenues |  |  | January 27,2012 |  |  | % of NetRevenues |  |  | January 28,2011 |  |  | % of NetRevenues |  |
| Arrow Electronics, Inc. |  | $ | 238.8 |  |  |  | 15 | % |  | $ | 223.4 |  |  |  | 17 | % |  | $ | 725.9 |  |  |  | 16 | % |  | $ | 619.7 |  |  |  | 17 | % |
| Avnet, Inc. |  |  | 179.3 |  |  |  | 11 | % |  |  | 151.3 |  |  |  | 12 | % |  |  | 537.2 |  |  |  | 12 | % |  |  | 461.9 |  |  |  | 13 | % |

[0001193125-12-096831:mdna:69]
[same as prior period, unchanged from 0001193125-11-330462:mdna:69]

[0001193125-12-096831:mdna:70]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| Product revenues |  | $ | 1,062.7 |  |  | $ | 844.3 |  |  |  | 26 | % |  | $ | 3,044.6 |  |  | $ | 2,406.6 |  |  |  | 27 | % |

[0001193125-12-096831:mdna:71]
Product revenues increased by $218.4 million, or 26%, and increased by $638.0 million, or 27%, for the
three and nine months ended January 27, 2012, respectively, from the comparable periods in the prior year. Product revenues consist of configured systems, which are comprised of bundled hardware and software products, and non-configured
products, which consist primarily of add-on hardware, storage, and software products, as well as OEM products.

[0001193125-12-096831:mdna:72]
Total
configured system revenues of $540.7 million increased by $42.6 million, or 9%, for the three months ended January 27, 2012, and total configured system revenues of $1,571.9 million increased by $118.4 million, or 8%, for the nine months ended
January 27, 2012, compared to the prior year, with the largest increase in the 6000 series systems, partially offset by decreases in the 2000 series systems. Configured systems unit volume increased by 5% and 3% for the three and nine months
ended January 27, 2012, respectively, compared to the prior year, with increases in each period in both the 6000 and 3000 series systems, offset by a decrease in each period in the 2000 series systems. The increases in the unit volume of the
6000 and 3000 series in each period were due to customer demand for these newer systems. The decreases in the 2000 series unit volume in each period were primarily due to a decrease in demand for the older products within this series, as well as a
shift in demand to the newer 3000 series systems. The average selling prices (ASPs) of total configured systems increased during the three and nine months ended January 27, 2012, compared to the prior year due to a shift in system revenue mix
from the lower ASP 2000 series to the higher ASP 3000 and 6000 series. However, ASP’s across each series decreased compared to the same periods in the prior year primarily due to higher discounting and, to a lesser extent, manufacturing cost
reductions being passed along to customers as price reductions.

[0001193125-12-096831:mdna:73]
Non-configured product revenues of $522.0 million increased $175.8 million, or 51%, during
the three months ended January 27, 2012, and non-configured product revenues of $1,472.7 million increased $519.6 million, or 55%, during the nine months ended January 27, 2012, compared to the prior year. These increases were primarily
due to E-Series OEM product revenues of $174.3 million and $504.1 million during the three and nine months ended January 27, 2012, respectively, that resulted from the Engenio acquisition and a 4% and 3% increase in sales of our add-on storage
products during the three and nine months ended January 27, 2012, respectively.

[0001193125-12-096831:mdna:74]
Our systems are highly configurable to
respond to customer requirements in the open systems storage markets that we serve. This can cause a wide variation in product configurations that can significantly impact revenues, cost of revenues and gross profit performance. Pricing changes,
discounting practices, product competition, foreign currency, unit volumes, customer mix, natural disasters and product material costs can also impact revenues, cost of revenues and/or gross profit performance. Disks are a significant component of
our storage systems. Industry disk pricing has fallen every year; however, with the recent flooding in Thailand, disk prices have increased and may continue to do so. To the extent that disk prices increase or decrease, we intend to pass along those
price increases or decreases to our customers while working to maintain relatively constant profit margins on our disk drives. As our sales price per terabyte continues to decline, improved system performance, increased capacity and software to
manage this increased capacity have an offsetting impact on product revenues.

[0001193125-12-096831:mdna:75]
Software Entitlements and Maintenance
Revenues (in millions, except percentages):

[0001193125-12-096831:mdna:76]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| Software entitlements and maintenance revenues |  | $ | 203.5 |  |  | $ | 182.7 |  |  |  | 11 | % |  | $ | 599.7 |  |  | $ | 533.6 |  |  |  | 12 | % |

[0001193125-12-096831:mdna:77]
Software entitlements and maintenance (SEM) revenues increased by $20.8 million, or 11%, and increased by
$66.1 million, or 12%, during the three and nine months ended January 27, 2012, respectively, from the comparable periods in the prior year. The increases in each period were due to an increase in the aggregate contract value of the installed
base under SEM contracts, which is recognized as revenue ratably over the terms of the underlying contracts.

[0001193125-12-096831:mdna:78]
[same as prior period, unchanged from 0001193125-11-330462:mdna:79]

[0001193125-12-096831:mdna:79]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| Service revenues |  | $ | 299.3 |  |  | $ | 262.6 |  |  |  | 14 | % |  | $ | 886.4 |  |  | $ | 754.1 |  |  |  | 18 | % |

[0001193125-12-096831:mdna:80]
Service revenues include hardware maintenance, professional services and educational and training
services. Service revenues increased by $36.7 million, or 14%, and by $132.3 million, or 18%, during the three and nine months ended January 27, 2012, respectively, from the comparable periods in the prior year.

[0001193125-12-096831:mdna:81]
Hardware maintenance contract revenues constituted approximately 71% and 70% of our service revenues for the three and nine months ended
January 27, 2012, respectively, and 66% and 65% for the three and nine months ended January 28, 2011, respectively. Such revenues increased by $36.6 million, or 21%, and by $128.6 million, or 26%, during the three and nine months ended
January 27, 2012, respectively, from the comparable periods in the prior year, as a result of an increase in each period in the installed base under service contracts. Professional services and educational and training services constituted
approximately 29% and 30% of our service revenues for the three and nine months ended January 27, 2012, respectively, and 34% and 35% of our service revenues for the three and nine months ended January 28, 2011, respectively.

[0001193125-12-096831:mdna:82]
[same as prior period, unchanged from 0001193125-11-330462:mdna:82]

[0001193125-12-096831:mdna:83]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| Americas (United States, Canada and Latin America) |  | $ | 853.7 |  |  | $ | 702.8 |  |  |  | 21 | % |  | $ | 2,564.2 |  |  | $ | 2,094.2 |  |  |  | 22 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 525.5 |  |  |  | 457.1 |  |  |  | 15 | % |  |  | 1,411.1 |  |  |  | 1,232.5 |  |  |  | 14 | % |
| Asia Pacific and Japan (APAC) |  |  | 186.3 |  |  |  | 129.7 |  |  |  | 44 | % |  |  | 555.4 |  |  |  | 367.6 |  |  |  | 51 | % |
| Net revenues |  | $ | 1,565.5 |  |  | $ | 1,289.6 |  |  |  |  |  |  | $ | 4,530.7 |  |  | $ | 3,694.3 |  |  |  |  |  |

[0001193125-12-096831:mdna:84]
Americas revenues consist of Americas commercial and U.S. public sector markets. Sales to
customers inside the United States comprised 86% and 90% of Americas net revenues during the three months ended January 27, 2012 and January 28, 2011, respectively, and 85% and 90% of Americas net revenue during the nine months ended
January 27, 2012 and January 28, 2011, respectively. Sales to Germany accounted for 12% and 10% of net revenues during the three and nine months ended January 27, 2012, respectively. Sales to Germany accounted for 13% and 12% of net
revenues during the three and nine months ended January 28, 2011, respectively. No other single foreign country accounted for 10% or more of net revenues in any of the periods presented.

[0001193125-12-096831:mdna:85]
[same as prior period, unchanged from 0001193125-11-330462:mdna:85]

[0001193125-12-096831:mdna:86]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping of our storage products, amortization of purchased intangible
assets, inventory write-downs, and warranty costs; (2) cost of SEM, which includes the costs of providing SEM and third-party royalty costs, and (3) cost of service revenues, which reflects costs associated with providing support
activities for hardware, global support partnership programs, professional services and educational and training services.

[0001193125-12-096831:mdna:87]
[same as prior period, unchanged from 0001193125-11-330462:mdna:87]

[0001193125-12-096831:mdna:88]
[same as prior period, unchanged from 0001193125-11-330462:mdna:88]

[0001193125-12-096831:mdna:89]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| Cost of product revenues |  | $ | 517.8 |  |  | $ | 328.4 |  |  |  | 58 | % |  | $ | 1,415.9 |  |  | $ | 962.9 |  |  |  | 47 | % |

[0001193125-12-096831:mdna:90]
Cost of product revenues increased by $189.4 million, or 58%, and $453.0 million, or 47%, during the
three and nine months ended January 27, 2012, from the comparable periods in the prior year. The changes were comprised of the following elements (in percentage points of the total change):

[0001193125-12-096831:mdna:91]
|  |  | Three Months EndedFiscal 2012 to Fiscal 2011Percentage ChangePoints |  |  | Nine Months Ended Fiscal2012 to Fiscal 2011Percentage ChangePoints |  |
| Materials cost |  |  | 49 |  |  |  | 38 |  |
| Amortization of developed technology |  |  | 4 |  |  |  | 3 |  |
| Warranty |  |  | 2 |  |  |  | 2 |  |
| Manufacturing overhead |  |  | 2 |  |  |  | 2 |  |
| Excess and obsolete inventory |  |  | (1 | ) |  |  | 1 |  |
| Other |  |  | 2 |  |  |  | 1 |  |
| Total change |  |  | 58 |  |  |  | 47 |  |

[0001193125-12-096831:mdna:92]
During the three and nine months ended January 27, 2012, the increase in materials cost was
primarily due to $99.6 million and $283.1 million, respectively, in materials cost relating to the sales of E-Series OEM products resulting from the Engenio acquisition. The increase in materials cost was also impacted by the 5% and 3% unit volume
increases in configured systems during these periods; however, the average cost per unit of configured systems across all product families decreased as a result of materials cost reductions, partially offsetting volume increases during these
reporting periods.

[0001193125-12-096831:mdna:93]
The increase in the amortization of developed technology was due to identified intangible assets acquired
from the Engenio acquisition, which are amortized on a straight-line basis over their estimated useful life.

[0001193125-12-096831:mdna:94]
Cost of product revenues represented 49% and 39% of product revenue for the three months
ended January 27, 2012 and January 28, 2011, respectively, and 47% and 40% of product revenue for the nine months ended January 27, 2012 and January 28, 2011, respectively. The overall increases in costs as a percentage of
revenues for the three and nine months ended January 27, 2012, as compared to the same periods in the prior year, were primarily the result of E-Series OEM products acquired through the Engenio transaction, which have lower material margins
than configured systems and add-on products as well as the decrease in ASPs.

[0001193125-12-096831:mdna:95]
Cost of Software Entitlements and
Maintenance Revenues (in millions, except percentages):

[0001193125-12-096831:mdna:96]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| Cost of software entitlements and maintenance revenues |  | $ | 6.2 |  |  | $ | 4.0 |  |  |  | 55 | % |  | $ | 17.1 |  |  | $ | 10.9 |  |  |  | 57 | % |

[0001193125-12-096831:mdna:97]
Cost of SEM revenues increased by $2.2 million, or 55%, and $6.2 million, or 57%, during the three and
nine months ended January 27, 2012, respectively, from the comparable periods in the prior year, primarily due to an increase in volume-related software support costs. Cost of SEM revenues represented 3% of SEM revenues for both the three and
nine months ended January 27, 2012 and 2% of SEM revenues for both the three and nine months ended January 28, 2011.

[0001193125-12-096831:mdna:98]
[same as prior period, unchanged from 0001193125-11-330462:mdna:99]

[0001193125-12-096831:mdna:99]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| Cost of service revenues |  | $ | 133.0 |  |  | $ | 111.0 |  |  |  | 20 | % |  | $ | 379.3 |  |  | $ | 320.0 |  |  |  | 19 | % |

[0001193125-12-096831:mdna:100]
Cost of service revenues increased by $22.0 million, or 20%, and $59.3 million, or 19%, during the three
and nine months ended January 27, 2012, respectively, from the comparable periods in the prior year primarily due to the costs associated with servicing a larger installed base and an increase in logistics and materials costs. Costs represented
44% and 42% of service revenues for the three months ended January 27, 2012 and January 28, 2011, respectively, and represented 43% and 42% of service revenues for the nine months ended January 27, 2012 and January 28, 2011,
respectively.

[0001193125-12-096831:mdna:101]
[same as prior period, unchanged from 0001193125-11-330462:mdna:102]

[0001193125-12-096831:mdna:102]
[same as prior period, unchanged from 0001193125-11-330462:mdna:103]

[0001193125-12-096831:mdna:103]
Compensation costs comprise the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation costs and
employee incentive compensation plan costs. Compensation costs included in operating expenses increased approximately $59.8 million, or 17%, and $205.4 million, or 21%, for the three and nine months ended January 27, 2012, respectively,
from the comparable periods in the prior year, primarily due to:

[0001193125-12-096831:mdna:104]
(i) an increase in salaries, benefits and other
compensation-related costs of $63.8 million and $210.1 million for the three and nine months ended January 27, 2012, respectively, due to an increase in average headcount, which included the impact of the Engenio acquisition;

[0001193125-12-096831:mdna:105]
(ii) an increase in stock-based compensation of $29.0 million and $66.1 million for the three and nine months ended January 27,
2012, respectively, which includes the impact of the Engenio acquisition and $10.9 million of expense related to the reset of the employee stock purchase plan (ESPP) offerings triggered by the decline in our stock price below the grant date prices
of the offerings;

[0001193125-12-096831:mdna:106]
(iii) partially offset by a decrease in incentive compensation expense of $33.0 million and $70.8 million
for the three and nine months ended January 27, 2012, respectively, due to lower achievement of performance against plan operating targets during the three and nine months ended January 27, 2012.

[0001193125-12-096831:mdna:107]
Sales and Marketing (in millions, except percentages):

[0001193125-12-096831:mdna:108]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 477.0 |  |  | $ | 397.4 |  |  |  | 20 | % |  | $ | 1,385.9 |  |  | $ | 1,134.4 |  |  |  | 22 | % |

[0001193125-12-096831:mdna:109]
[same as prior period, unchanged from 0001193125-11-330462:mdna:110]

[0001193125-12-096831:mdna:110]
|  |  | Three Months EndedFiscal 2012 to Fiscal 2011Percentage ChangePoints |  |  | Nine Months EndedFiscal 2012 to Fiscal 2011Percentage ChangePoints |  |
| Salaries |  |  | 8 |  |  |  | 9 |  |
| Stock-based compensation |  |  | 4 |  |  |  | 3 |  |
| Incentive plan compensation |  |  | (4 | ) |  |  | (3 | ) |
| Other compensation and benefit costs |  |  | 2 |  |  |  | 2 |  |
| Total compensation costs |  |  | 10 |  |  |  | 11 |  |
| Outside services |  |  | 1 |  |  |  | 2 |  |
| Amortization expense |  |  | 2 |  |  |  | 2 |  |
| Commissions |  |  | 3 |  |  |  | 2 |  |
| Facilities and IT support costs |  |  | 2 |  |  |  | 2 |  |
| Advertising and marketing promotional expense |  |  | 2 |  |  |  | 2 |  |
| Other |  |  | — |  |  |  | 1 |  |
| Total change |  |  | 20 |  |  |  | 22 |  |

[0001193125-12-096831:mdna:111]
The increase in total compensation costs for the three and nine months ended January 27, 2012
reflects an increase in average sales and marketing headcount of 21% and 22%, respectively, as compared to the same periods in the prior year. These increases were partially offset by a decrease in incentive compensation expense. The increase in
commissions expense for the three and nine months ended January 27, 2012 was due to higher sales levels compared to the same periods in the prior year. Amortization expense increased due to the addition of intangible assets as a result of the
acquisition of Engenio.

[0001193125-12-096831:mdna:112]
[same as prior period, unchanged from 0001193125-11-330462:mdna:113]

[0001193125-12-096831:mdna:113]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| Research and development expenses |  | $ | 208.3 |  |  | $ | 166.0 |  |  |  | 25 | % |  | $ | 606.6 |  |  | $ | 472.1 |  |  |  | 28 | % |

[0001193125-12-096831:mdna:114]
[same as prior period, unchanged from 0001193125-11-330462:mdna:115]

[0001193125-12-096831:mdna:115]
|  |  | Three Months EndedFiscal 2012 to Fiscal 2011Percentage ChangePoints |  |  | Nine Months EndedFiscal 2012 to Fiscal 2011Percentage ChangePoints |  |
| Salaries |  |  | 12 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 7 |  |  |  | 5 |  |
| Incentive plan compensation |  |  | (8 | ) |  |  | (5 | ) |
| Other compensation and benefit costs |  |  | 3 |  |  |  | 4 |  |
| Total compensation costs |  |  | 14 |  |  |  | 17 |  |
| Facilities and IT support costs |  |  | 4 |  |  |  | 5 |  |
| Depreciation expense |  |  | 3 |  |  |  | 3 |  |
| Outside services |  |  | 2 |  |  |  | 2 |  |
| Other |  |  | 2 |  |  |  | 1 |  |
| Total change |  |  | 25 |  |  |  | 28 |  |

[0001193125-12-096831:mdna:116]
The increase in total compensation costs reflects a 38% and 39% increase in average engineering headcount
during the three and nine months ended January 27, 2012, respectively, compared to the same periods in the prior year. These increases were partially offset by a decrease in incentive compensation expense. The increase in facilities and IT
support costs in each period reflects the acquisition of Engenio. Depreciation expense increased due to purchases of production and engineering equipment.

[0001193125-12-096831:mdna:117]
We believe that our future performance will depend in large part on our ability to maintain and enhance our current product line, develop new products that achieve market acceptance, maintain
technological competitiveness and meet an expanding range of customer requirements. We expect to continue to spend on current and future product development efforts, broaden our existing product offerings and introduce new products that expand our
solutions portfolio.

[0001193125-12-096831:mdna:118]
[same as prior period, unchanged from 0001193125-11-330462:mdna:119]

[0001193125-12-096831:mdna:119]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| General and administrative expenses |  | $ | 63.2 |  |  | $ | 61.9 |  |  |  | 2 | % |  | $ | 193.4 |  |  | $ | 182.3 |  |  |  | 6 | % |

[0001193125-12-096831:mdna:120]
General and administrative expense consists primarily of compensation costs, professional and corporate
legal fees, outside services and allocated facilities and IT costs. General and administrative expenses increased due to the following:

[0001193125-12-096831:mdna:121]
|  |  | Three Months EndedFiscal 2012 to Fiscal 2011Percentage ChangePoints |  |  | Nine Months EndedFiscal 2012 to Fiscal 2011Percentage ChangePoints |  |
| Salaries |  |  | 3 |  |  |  | 5 |  |
| Stock-based compensation |  |  | 2 |  |  |  | 2 |  |
| Incentive plan compensation |  |  | (10 | ) |  |  | (8 | ) |
| Total compensation costs |  |  | (5 | ) |  |  | (1 | ) |
| Outside services |  |  | 1 |  |  |  | 4 |  |
| Professional and corporate legal fees |  |  | 8 |  |  |  | 3 |  |
| Other |  |  | (2 | ) |  |  | — |  |
| Total change |  |  | 2 |  |  |  | 6 |  |

[0001193125-12-096831:mdna:122]
The decrease in total compensation costs was driven by a decrease in incentive compensation expense for
the three and nine months ended January 27, 2012. These decreases were partially offset by the impact of a 13% and 16% increase in average general and administrative headcount during the three and nine months ended January 27, 2012,
respectively, compared to the same periods in the prior year. Professional and corporate legal fees are higher than the comparable prior year periods as a result of a legal fee settlement in the three months ended January 28, 2011 associated with
the resolution of the Sun Microsystems litigation. The increase in outside services for the nine months ended January 27, 2012 reflects additional spending on contractors and costs associated with the Engenio integration activities and various
on-going operational projects.

[0001193125-12-096831:mdna:123]
Acquisition-Related Expense (in millions, except percentages):

[0001193125-12-096831:mdna:124]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| Acquisition-related expense |  | $ | 3.5 |  |  | $ | 0.6 |  |  |  | 483 | % |  | $ | 7.4 |  |  | $ | 0.9 |  |  |  | 722 | % |

[0001193125-12-096831:mdna:125]
During the three and nine months ended January 27, 2012, we incurred $3.5 million and $7.4 million,
respectively, of due diligence, legal and other integration charges associated with our acquisition of Engenio. During the nine months ended January 28, 2011, we incurred $0.9 million of costs associated with our acquisitions of Bycast Inc. and
Akorri Networks, Inc.

[0001193125-12-096831:mdna:126]
[same as prior period, unchanged from 0001193125-11-330462:mdna:129]

[0001193125-12-096831:mdna:127]
Interest Income (in millions, except percentages):

[0001193125-12-096831:mdna:128]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| Interest income |  | $ | 8.7 |  |  | $ | 10.3 |  |  |  | (16 | )% |  | $ | 27.6 |  |  | $ | 29.6 |  |  |  | (7 | )% |

[0001193125-12-096831:mdna:129]
The decrease in interest income during the three and nine months ended January 27, 2012, from the
comparable periods in the prior year, was primarily due to lower yields on new investments.

[0001193125-12-096831:mdna:130]
[same as prior period, unchanged from 0001193125-11-330462:mdna:133]

[0001193125-12-096831:mdna:131]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| Interest expense |  | $ | (18.9 | ) |  | $ | (19.0 | ) |  |  | (1 | )% |  | $ | (54.7 | ) |  | $ | (56.2 | ) |  |  | (3 | )% |

[0001193125-12-096831:mdna:132]
Interest expense decreased 1% and 3% during the three and nine months ended January 27,
2012, respectively, from the comparable periods in the prior year. During the three and nine months ended January 27, 2012, we recognized incremental non-cash interest expense from the amortization of debt discount and issuance costs relating
to our Notes of approximately $13.5 million and $38.7 million, respectively, net of capitalized interest. During the three and nine months ended January 28, 2011, we recognized incremental non-cash interest expense from the amortization of
debt discount and issuance costs relating to our Notes of approximately $13.3 million and $39.2 million, respectively. The coupon interest expense related to the Notes was $5.2 million and $15.2 million during the three and nine months
ended January 27, 2012, respectively, net of capitalized interest and $5.5 million and $16.5 million during the three and nine months ended January 28, 2011, respectively. During the three and nine months ended January 27, 2012, we
capitalized interest of $0.9 million and $4.3 million, respectively, on facility assets under construction and on significant software development projects.

[0001193125-12-096831:mdna:133]
[same as prior period, unchanged from 0001193125-11-330462:mdna:138]

[0001193125-12-096831:mdna:134]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |  | January 27,2012 |  |  | January 28,2011 |  |  | % Change |  |
| Provision for income taxes |  | $ | 27.3 |  |  | $ | 26.3 |  |  |  | 4 | % |  | $ | 73.2 |  |  | $ | 73.5 |  |  |  | — | % |

[0001193125-12-096831:mdna:135]
Our effective tax rates for the three months ended January 27, 2012 and January 28, 2011 were
18.6% and 12.4%, respectively, and 14.7% and 12.5% for the nine months ended January 27, 2012 and January 28, 2011, respectively. Our effective tax rates for the three and nine months ended January 27, 2012 and January 28, 2011
differ from the U.S. statutory rate of 35% because our foreign earnings are taxed at rates lower than the U.S. statutory rate. In January 2012, we reached agreement with the U.S. Internal Revenue Service (IRS) with regards to a tax position taken
during prior periods. Our provision for income taxes increased for the three months ended January 27, 2012 compared to the three months ended January 28, 2011 primarily as a result of a discrete tax expense of $11.7 million, net of federal
tax benefit, related to this settlement and the resulting remeasurement of our tax positions. Our provision for income taxes decreased for the nine months ended January 27, 2012 compared to the nine months ended January 28, 2011 primarily
as a result of a decrease in U.S. pre-tax profits, partially offset by the tax effect of the remeasurement of a prior year tax position and lower tax benefits from disqualified dispositions of our ESPP.

[0001193125-12-096831:mdna:136]
As of January 27, 2012, we had $155.5 million of unrecognized tax benefits, of which $104.3 million has been recorded in other
long-term liabilities and $96.6 million, including penalties and interest, would affect our provision for income taxes if recognized. During the nine months ended January 27, 2012, there was a gross increase in our unrecognized tax benefits of
$8.0 million for tax positions related to the current year, and a gross increase of $20.3 million and a gross decrease of $6.0 million for tax positions related to prior years.

[0001193125-12-096831:mdna:137]
[same as prior period, unchanged from 0001193125-11-330462:mdna:141]

[0001193125-12-096831:mdna:138]
The following sections discuss our
principal liquidity requirements, as well as our sources and uses of cash flows on our liquidity and capital resources. The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to
mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid
and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of January 27, 2012.

[0001193125-12-096831:mdna:139]
Liquidity Sources and Cash Requirements

[0001193125-12-096831:mdna:140]
Our principal sources of liquidity as of January 27, 2012 consisted of approximately $4.9 billion in cash, cash equivalents and short-term investments, as well as cash we expect to generate from
operations.

[0001193125-12-096831:mdna:141]
[same as prior period, unchanged from 0001193125-11-330462:mdna:145]

[0001193125-12-096831:mdna:142]
|  |  | January 27, 2012 |  |  | April 29, 2011 |  |
| Cash and cash equivalents |  | $ | 2,420.9 |  |  | $ | 2,757.3 |  |
| Short-term investments |  |  | 2,445.2 |  |  |  | 2,417.4 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,866.1 |  |  | $ | 5,174.7 |  |

[0001193125-12-096831:mdna:143]
As of January 27, 2012, $2.4 billion of cash, cash equivalents and short-term
investments were held in the U.S., while $2.5 billion were held in foreign countries. Most of the amounts held outside the U.S. can be repatriated to the U.S. but, under current law, would be subject to U.S. federal and state income taxes. If we
were to repatriate foreign earnings for cash requirements in the U.S., we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state net operating loss and tax credit carry forwards. However, our
intent is to keep these funds permanently reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working capital
needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies, and service our debt and synthetic leases. Our contractual obligations as of
January 27, 2012 are summarized below in the Contractual Obligations table.

[0001193125-12-096831:mdna:144]
Key factors that could affect our cash flows
include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable and inventories, our ability to effectively integrate acquired products, businesses and technologies,
including Engenio, and conversions of our Notes by holders. Based on our current business outlook, we believe that our sources of cash will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases,
contractual obligations, commitments, interest payments on our Notes and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is
insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to
obtain additional financing, if necessary, on satisfactory terms, if at all.

[0001193125-12-096831:mdna:145]
Our investment portfolio, including auction rate
securities, has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize our market risk on our investment portfolio. Based on
our ability to access our cash and short-term investments, our expected operating cash flows, and our other potential sources of cash, we do not anticipate that the lack of liquidity of these investments will impact our ability to fund working
capital needs, capital expenditures, acquisitions or other cash requirements. We intend to and believe that we have the ability to hold these investments until the market recovers. If current market conditions deteriorate, we may be required to
record additional charges to earnings in future periods.

[0001193125-12-096831:mdna:146]
[same as prior period, unchanged from 0001193125-11-330462:mdna:150]

[0001193125-12-096831:mdna:147]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use
software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a
number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We expect that our existing facilities and those
being developed in Sunnyvale, California; Research Triangle Park, North Carolina and other locations worldwide are adequate for our requirements over at least the next two years and that additional space will be available as needed. We anticipate
capital expenditures to be between $45.0 million and $65.0 million over the next three months.

[0001193125-12-096831:mdna:148]
[same as prior period, unchanged from 0001193125-11-330462:mdna:152]

[0001193125-12-096831:mdna:149]
On May 6, 2011, we completed the acquisition of certain assets related to the Engenio business of
LSI. We paid LSI $480.0 million in cash and also assumed certain assets and liabilities related to Engenio. As part of our efforts to integrate Engenio into our business, we expect to incur additional integration charges. See Note 5 of the
accompanying condensed consolidated financial statements for more information.

[0001193125-12-096831:mdna:150]
[same as prior period, unchanged from 0001193125-11-330462:mdna:154]

[0001193125-12-096831:mdna:151]
As of January 27, 2012, our cash, cash equivalents and short-term and long-term investments decreased by $323.1 million from
April 29, 2011, to $4.9 billion. The decrease was primarily a result of $600.0 million in cash paid for the repurchase of common stock, $480.0 million net cash paid in connection with the acquisition of Engenio, $282.9 million in capital
expenditures and $21.2 million of net purchases of investments, partially offset by $880.0 million of cash provided by operating activities and $101.0 million from issuances of common stock related to employee stock option exercises and purchases
under the ESPP. We derive our liquidity and capital resources primarily from our operating cash flows and from working capital. Accounts receivable days sales outstanding as of January 27, 2012 decreased to 40 days, compared to
47 days as of April 29, 2011, primarily due to improvements in shipment linearity. Working capital increased by $1.0 billion to $4.0 billion as of January 27, 2012, compared to $3.0 billion as of April 29, 2011,
primarily due to the reclassification of our $1.2 billion Notes to long-term liabilities as the underlying contingent conversion threshold was not met at January 27, 2012 and a decrease in accrued compensation and related benefits of $168.0
million, partially offset by a decrease in cash, cash equivalents and short-term investments of $308.6 million and accounts receivable of $57.2 million.

[0001193125-12-096831:mdna:152]
[same as prior period, unchanged from 0001193125-11-330462:mdna:156]

[0001193125-12-096831:mdna:153]
During the nine months ended January 27, 2012, we generated cash from operating activities of $880.0 million. The primary
sources of cash from operating activities consisted of net income of $424.7 million, adjusted by depreciation and amortization of $210.5 million, stock-based compensation of $197.8 million and deferred income taxes of $64.0 million.
Significant changes in assets and liabilities impacting operating cash flows included an increase in deferred revenue of $234.5 million and a decrease in accounts receivable of $55.8 million, partially offset by a decrease in accrued compensation
and other current liabilities of $160.5 million, which was primarily attributable to cash payouts to employees related to the fiscal year 2011 commissions and incentive compensation plans.

[0001193125-12-096831:mdna:154]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including
fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, tax benefits from stock-based compensation, and the timing and amount of compensation and other payments.

[0001193125-12-096831:mdna:155]
[same as prior period, unchanged from 0001193125-11-330462:mdna:159]

[0001193125-12-096831:mdna:156]
During the nine months ended January 27, 2012, we completed our acquisition of Engenio for a total net cash payment of $480.0 million, purchased $282.9 million of capital expenditures and purchased
$21.2 million in net purchases of our investments.

[0001193125-12-096831:mdna:157]
[same as prior period, unchanged from 0001193125-11-330462:mdna:161]

[0001193125-12-096831:mdna:158]
We used $415.2 million in financing activities for the nine months ended January 27, 2012, which primarily consisted of $600.0
million for the repurchase of common stock, partially offset by $80.7 million of excess tax benefit from stock-based compensation and $101.0 million of proceeds from employee equity award plans, net of shares withheld for taxes.

[0001193125-12-096831:mdna:159]
Net proceeds from the issuance of common stock related to employee participation in employee equity award programs have historically been
a significant component of our liquidity. The extent to which our employees exercise stock options generally increases or decreases based upon changes in the market price of our common stock. As a result, our cash flow resulting from the issuance of
common stock in connection with these programs and related tax benefits will vary.

[0001193125-12-096831:mdna:160]
[same as prior period, unchanged from 0001193125-11-330462:mdna:164]

[0001193125-12-096831:mdna:161]
During the nine months ended January 27, 2012, 14.6 million shares of our common stock were repurchased as
described below. Since the May 13, 2003 inception of our stock repurchase program through January 27, 2012, we have repurchased a total of 119.0 million shares of our common stock at an average price of $29.65 per share, for an
aggregate purchase price of $3.5 billion. As of January 27, 2012, our Board of Directors had authorized the repurchase of up to $4.0 billion of our common stock under this stock repurchase program. As of January 27, 2012, the remaining
authorized amount for stock repurchases under this program was $0.5 billion with no termination date. The stock repurchase program may be suspended or discontinued at any time.

[0001193125-12-096831:mdna:162]
[same as prior period, unchanged from 0001193125-11-330462:mdna:166]

[0001193125-12-096831:mdna:163]
On July 8, 2011, we entered into a collared accelerated share repurchase agreement (ASR) with Bank of America, N.A, under which we prepaid $200.0 million to purchase shares of our common stock. The
aggregate number of shares ultimately purchased was determined based on the volume weighted-average share price of our common stock over a specified period of time. The contract was settled in August 2011. The total number of shares repurchased and
retired under this ASR was 4.1 million shares at a price of $48.30.

[0001193125-12-096831:mdna:164]
On August 19, 2011, we entered into an ASR with
Wells Fargo Bank, National Association, under which we prepaid $400.0 million to purchase shares of our common stock. The aggregate number of shares ultimately purchased was determined based on the volume weighted-average share price of our common
stock over a specified period of time. The contract was settled in November 2011. The total number of shares repurchased and retired under this ASR was 10.5 million shares at a price of $38.08.

[0001193125-12-096831:mdna:165]
[same as prior period, unchanged from 0001193125-11-330462:mdna:169]

[0001193125-12-096831:mdna:166]
As of January 27, 2012, we had $1.265 billion principal amount of 1.75% Convertible Senior Notes due 2013 (See Note 9
of the accompanying condensed consolidated financial statements). The Notes will mature on June 1, 2013, unless earlier repurchased or converted. Our common stock price did not exceed the conversion threshold price of $41.41 per share set forth
for these Notes for at least 20 trading days during the 30 consecutive trading days ended December 31, 2011. Accordingly, as of January 27, 2012, the Notes were not convertible at the option of the holder and, therefore, the carrying value
of the Notes was classified as long-term debt and the difference between the principal amount and the carrying value of the Notes was reflected as equity on our condensed consolidated balance sheet as of January 27, 2012.

[0001193125-12-096831:mdna:167]
The determination of whether or not the Notes are convertible must continue to be performed quarterly. Consequently, the Notes may
be convertible in future quarters, and therefore may be classified as short-term debt if the contingent conversion thresholds are met in such quarters. Additionally, since the Notes would be convertible at the option of the holder and the principal
amount would be required to be paid in cash, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in mezzanine on our condensed consolidated balance sheets. As of
January 27, 2012, shares issued related to conversion of the Notes were minimal. As of January 27, 2012, we received a minimal number of shares related to the Note hedge transactions and no cash or shares were delivered related to the
warrant transactions.

[0001193125-12-096831:mdna:168]
[same as prior period, unchanged from 0001193125-11-330462:mdna:172]

[0001193125-12-096831:mdna:169]
The following table summarizes our contractual obligations as of January 27, 2012 and the effect such obligations are expected to
have on our liquidity and cash flows in future periods (in millions):

[0001193125-12-096831:mdna:170]
|  |  | Remainderof2012 |  |  | 2013 |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | Thereafter |  |  | Total |  |
| Off-balance sheet commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Office operating lease payments |  | $ | 9.4 |  |  | $ | 37.1 |  |  | $ | 36.2 |  |  | $ | 36.3 |  |  | $ | 31.2 |  |  | $ | 74.9 |  |  | $ | 225.1 |  |
| Real estate lease payments(1) |  |  | 0.8 |  |  |  | 129.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 130.0 |  |
| Less: sublease income |  |  | (0.5 | ) |  |  | (1.2 | ) |  |  | (0.8 | ) |  |  | (0.8 | ) |  |  | (0.5 | ) |  |  | — |  |  |  | (3.8 | ) |
| Equipment operating lease payments |  |  | 7.4 |  |  |  | 20.5 |  |  |  | 13.4 |  |  |  | 4.4 |  |  |  | 1.3 |  |  |  | 0.6 |  |  |  | 47.6 |  |
| Purchase commitments with contract manufacturers(2) |  |  | 215.4 |  |  |  | 3.6 |  |  |  | 1.2 |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |  |  | 220.4 |  |
| Capital expenditures |  |  | 19.6 |  |  |  | 17.2 |  |  |  | 11.7 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 48.5 |  |
| Other purchase obligations(3) |  |  | 89.9 |  |  |  | 92.6 |  |  |  | 17.6 |  |  |  | 10.6 |  |  |  | 10.0 |  |  |  | 10.0 |  |  |  | 230.7 |  |
| Total off balance-sheet commitments |  |  | 342.0 |  |  |  | 299.0 |  |  |  | 79.3 |  |  |  | 50.7 |  |  |  | 42.0 |  |  |  | 85.5 |  |  |  | 898.5 |  |
| 1.75% Convertible notes(4) |  |  | — |  |  |  | 22.1 |  |  |  | 1,276.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,298.1 |  |
| Long-term financing arrangements |  |  | 3.8 |  |  |  | 10.9 |  |  |  | 3.4 |  |  |  | 2.2 |  |  |  | 1.7 |  |  |  | 0.8 |  |  |  | 22.8 |  |
| Uncertain tax positions(5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 105.9 |  |
| Total |  | $ | 345.8 |  |  | $ | 332.0 |  |  | $ | 1,358.7 |  |  | $ | 52.9 |  |  | $ | 43.7 |  |  | $ | 86.3 |  |  | $ | 2,325.3 |  |
| Other Commercial Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit |  | $ | 6.0 |  |  | $ | 1.4 |  |  | $ | — |  |  | $ | 0.2 |  |  | $ | 0.4 |  |  | $ | 1.2 |  |  | $ | 9.2 |  |

[0001193125-12-096831:mdna:171]
| (1) | Included in real estate lease payments pursuant to four financing arrangements with BNP Paribas LLC (BNPPLC) are: (i) lease commitments of $0.8 million for the remainder of fiscal 2012 and $2.1 million in fiscal 2013, which are based on either the LIBOR rate as of January 27, 2012 plus a spread or a fixed rate for terms of five years and (ii) at the expiration or termination of the leasing arrangements, a supplemental payment obligation equal to our minimum guarantee of $127.1 million in the event that we elect not to purchase or arrange for sale of the buildings. |

[0001193125-12-096831:mdna:172]
| (2) | Contract manufacturer commitments consist of obligations for on-hand inventories and non-cancelable purchase orders with our contract manufacturers. As of January 27, 2012, we recorded accruals of $3.2 million for firm, non-cancelable purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts, which is consistent with the valuation of our excess and obsolete inventory. |

[0001193125-12-096831:mdna:173]
[same as prior period, unchanged from 0001193125-11-330462:mdna:177]

[0001193125-12-096831:mdna:174]
38

[0001193125-12-096831:mdna:175]
| (4) | Included in these amounts are obligations related to the $1.265 billion principal amount of 1.75% Notes due 2013 (see Note 9 of the accompanying condensed consolidated financial statements). Estimated interest payments for the Notes are $33.2 million for the remainder of fiscal 2012 through fiscal 2014. |

[0001193125-12-096831:mdna:176]
| (5) | As of January 27, 2012, our liability for uncertain tax positions was $105.9 million, including interest and penalties, which due to the uncertainty of the timing of future payments, are presented in the total column on a separate line in this table. |

[0001193125-12-096831:mdna:177]
Some of the
amounts in the table above are based on management’s estimates and assumptions, including their duration, the possibility of renewal or termination, anticipated actions by management and third parties and other factors. Because these estimates
and assumptions are subjective, our actual future obligations may vary from those reflected in the table. We expect to fund our contractual obligations and other commitments in the table above through existing cash, cash equivalents, investments,
and cash generated from operations or obtain additional financing, if necessary.

[0001193125-12-096831:mdna:178]
As of January 27, 2012, we have four
leasing arrangements (Leasing Arrangements 1, 2, 3 and 4) with BNPPLC, some of which require us to lease certain of our land to BNPPLC for a period of 99 years and to lease approximately 0.6 million square feet of office space from
BNPPLC for our headquarters in Sunnyvale, California, which had an original cost of $149.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on LIBOR plus a spread or a fixed rate on the costs of
the facilities on the respective lease commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of the leases for two consecutive five-year periods upon approval by BNPPLC. Upon
expiration (or upon any earlier termination) of the lease terms, we must elect one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by
BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received from the third-party and BNPPLC’s cost, up to 85% of cost (residual guarantee); or (iii) pay BNPPLC supplemental payments for an amount equal to
the difference between BNPPLC’s cost and fair value, up to the residual guarantee, in which event we may recoup some or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period. The
following table summarizes the costs, the residual guarantee, the applicable LIBOR plus spread or fixed rate at January 27, 2012 and the date we began to make payments for each of our leasing arrangements (in millions):

[0001193125-12-096831:mdna:179]
| Leasing Arrangements |  | Cost |  |  | Residual Guarantee |  |  | LIBOR Plus Spread or Fixed Rate |  | Lease Commencement Date |  | Term |
| 1 |  | $ | 48.5 |  |  | $ | 41.2 |  |  | 3.14% |  | January 2008 |  | 5 years |
| 2 |  |  | 80.0 |  |  |  | 68.0 |  |  | 0.22% |  | December 2007 |  | 5 years |
| 3 |  |  | 10.5 |  |  |  | 8.9 |  |  | 3.12% |  | December 2007 |  | 5 years |
| 4 |  |  | 10.6 |  |  |  | 9.0 |  |  | 3.14% |  | December 2007 |  | 5 years |

[0001193125-12-096831:mdna:180]
These leasing arrangements require us to maintain specified financial covenants with which we were in
compliance as of January 27, 2012. Such financial covenants include a maximum ratio of Total Debt to Earnings before Interest, Taxes, Depreciation and Amortization of less than 3:1 and a minimum amount of Unencumbered Cash and Short-Term
Investments of $300.0 million. Our failure to comply with these financial covenants could result in a default under the leases, which, subject to our right and ability to exercise our purchase option, would give BNPPLC the right to, among other
things, (i) terminate our possession of the leased property and require us to pay lease termination damages and other amounts as set forth in the lease agreements or (ii) exercise certain foreclosure remedies. If we were to exercise our
purchase option, or be required to pay lease termination damages, these payments would significantly reduce our available liquidity, which could constrain our operating flexibility.

[0001193125-12-096831:mdna:181]
As of January 27, 2012, we estimated that the fair value of certain properties under synthetic lease was $51.0 million below
the cost of the properties. We are accruing for this deficiency over the remaining terms of the respective leases. As of January 27, 2012, a deficiency reserve of $32.4 million was included in other current liabilities.

[0001193125-12-096831:mdna:182]
We may from time to time terminate one or more of our leasing arrangements and repay amounts outstanding in order to meet our operating
or other objectives.

[0001193125-12-096831:mdna:183]
Legal Contingencies

[0001193125-12-096831:mdna:184]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as
of January 27, 2012, as the outcome of these legal matters is currently not determinable.

[0001193125-12-096831:mdna:185]
On October 13, 2010,
Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of
California, Santa Clara County. The lawsuit named certain of our current and former directors as defendants. On February 3, 2011, the plaintiff filed an amended complaint in response to motions to dismiss that we and the individual defendants
had filed. Like the original complaint, the amended complaint included claims of breach of fiduciary duty and waste of corporate assets and alleges that the defendants failed to monitor internal controls to ensure that we complied with legal
requirements in our General Services Administration (GSA) contracting activities, resulting in us incurring defense and settlement costs. The amended complaint sought disgorgement of salaries and other compensation from the defendants and additional
unspecified damages. We and the individual defendants filed motions to dismiss the amended complaint in early March 2011. Following a hearing on July 15, 2011, the Court granted the motions to dismiss, but permitted plaintiff leave to amend its
complaint on or before September 16, 2011.

[0001193125-12-096831:mdna:186]
On August 9, 2011, Amalgamated Bank filed a complaint in Delaware
Chancery Court against us for the purpose of obtaining, in a summary proceeding, books and records to help Amalgamated Bank amend its complaint in the California lawsuit. Each of the parties filed cross motions for summary judgment, and a hearing
was held before the Delaware Chancery Court on November 16, 2011. Following that hearing, the Court directed Amalgamated Bank to more narrowly tailor its requests. On December 5, 2011, the court allowed plaintiff to conduct a very limited
document inspection. On February 6, 2012, the court denied plaintiff’s motion to compel further document production.

[0001193125-12-096831:mdna:187]
The plaintiff filed an amended complaint for a third time on September 15, 2011. This complaint alleged the same claims and requests
for relief as the previous complaints. On January 9, 2012, the defendants filed motions to dismiss the amended complaint. A hearing on our motion to dismiss the California lawsuit will be held on March 23, 2012.

[0001193125-12-096831:mdna:188]
[same as prior period, unchanged from 0001193125-11-330462:mdna:192]

[0001193125-12-096831:mdna:189]
During the ordinary course of business, we provide standby letters of credit or other guarantee instruments to third parties as required for certain transactions initiated either by us or our
subsidiaries. As of January 27, 2012, our financial guarantees of $9.2 million that were not recorded on our condensed consolidated balance sheet consisted of standby letters of credit related to workers’ compensation, a customs
guarantee, a corporate credit card program, foreign rent guarantees and surety bonds, which were primarily related to self-insurance.

[0001193125-12-096831:mdna:190]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in
foreign currency. The program is not designated for trading or speculative purposes. Currently, we do not enter into any foreign exchange forward contracts to hedge exposures related to firm commitments or nonmarketable investments. Our major
foreign currency exchange exposures and related hedging programs are described below:

[0001193125-12-096831:mdna:191]
[same as prior period, unchanged from 0001193125-11-330462:mdna:195]

[0001193125-12-096831:mdna:192]
[same as prior period, unchanged from 0001193125-11-330462:mdna:196]

[0001193125-12-096831:mdna:193]
As of January 27, 2012, the notional fair value of foreign exchange forward and foreign currency option contracts totaled $612.4 million. We do not believe that these derivatives present
significant credit risks, because of the short term maturity of the outstanding contracts at any point in time, the counterparties to the derivatives consist of major financial institutions, and we manage the notional amount of contracts entered
into with any one counterparty. Other than the risk associated with the financial condition of the counterparties, our maximum exposure related to foreign currency forward and option contracts is limited to the premiums paid. See Note 11 of the
accompanying condensed consolidated financial statements for more information related to our hedging activities.

[0001193125-12-096831:mdna:194]
In the
ordinary course of business, we enter into recourse lease financing arrangements with third-party financing companies and from time to time provide guarantees for a portion of financing arrangements under which we could be called upon to make
payments to these third-party financing companies in the event of nonpayment by end-user customers. See Note 15 of the accompanying condensed consolidated financial statements for more information related to these financing arrangements.

[0001193125-12-096831:mdna:195]
We enter into indemnification agreements with third parties in the ordinary course of
business. Generally, these indemnification agreements require us to reimburse losses suffered by the third-parties due to various events, such as lawsuits arising from patent or copyright infringement. These indemnification obligations are
considered off-balance sheet arrangements under accounting guidance.

[0001193125-12-096831:mdna:196]
We have commitments related to four leasing arrangements
with BNPPLC for approximately 0.6 million square feet of office space for our headquarters in Sunnyvale, California (as further described above under “Contractual Obligations”). Our future minimum lease payments and residual
guarantees under these real estate leases will amount to a total of $130.0 million as discussed above in “Contractual Obligations.”

[0001193125-12-096831:mdna:197]
We have evaluated these leases under variable interest entity accounting guidance and have determined the following:

[0001193125-12-096831:mdna:198]
|  | • |  | BNPPLC is a leasing company for BNP Paribas in the U.S. BNPPLC is not a “special purpose entity” organized for the sole purpose of facilitating the leases to us. The obligation to absorb expected losses and receive expected residual returns rests with the parent, BNP Paribas. Therefore, we are not the primary beneficiary of BNPPLC as we do not absorb the majority of BNPPLC’s expected losses or expected residual returns; and |

[0001193125-12-096831:mdna:199]
|  | • |  | BNPPLC has represented in the related closing agreements that the fair value of the properties leased to us by BNPPLC is less than half of the total of the fair value of all assets of BNPPLC, excluding any assets of BNPPLC held within a silo. Further, the property leased to us is not held within a silo. The definition of “held within a silo” means that BNPPLC has obtained funds equal to or in excess of 95% of the fair value of the leased asset to acquire or maintain its investment in such asset through nonrecourse financing or other contractual arrangements, the effect of which is to leave such asset (or proceeds thereof) as the only significant asset of BNPPLC at risk for the repayment of such funds. |

[0001193125-12-096831:mdna:200]
Accordingly, we are not required
to consolidate either the leasing entity or the specific assets that we lease under the BNPPLC lease.
