# NTAP 8-K — 0001102624-12-000111 filed 2012-02-15

## item codes, every 8-K on or before 2012-03-05

- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2012-03-05

- none on or before 2012-03-05

## item 2.02 — earnings release, exhibit 99.1

[0001102624-12-000111:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-12-000111:8k_2_02:2]
exh99_1.htm

[0001102624-12-000111:8k_2_02:3]
Exhibit 99.1 PRESS RELEASE

[0001102624-12-000111:8k_2_02:4]
| Press Contact: | Investor Contact: |  |  |
| Ryan Lowry | Shauna O’Boyle |  |  |
| NetApp | NetApp |  |  |
| (408) 822-7544 | (408) 822-7655 |  |  |
| ryanl@netapp.com | oboyle@netapp.com |  |  |

[0001102624-12-000111:8k_2_02:5]
NETAPP ANNOUNCES RESULTS FOR THIRD QUARTER FISCAL YEAR 2012

[0001102624-12-000111:8k_2_02:6]
Company Reports Q3 FY’12 Revenue of $1.566 Billion, Delivering Ninth Consecutive Quarter of over 20% Year over Year Revenue Growth

[0001102624-12-000111:8k_2_02:7]
Sunnyvale, Calif.—February 15, 2012—NetApp (NASDAQ: NTAP) today reported results for the third quarter of fiscal year 2012, which ended January 27, 2012. Revenues for the third quarter of fiscal year 2012 totaled $1.566 billion compared to revenues of $1.290 billion for the same period one year ago.

[0001102624-12-000111:8k_2_02:8]
For the third quarter of fiscal year 2012, GAAP net income was $120 million, or $0.32 per share1, compared to GAAP net income of $186 million, or $0.46 per share, for the same period a year ago. Non-GAAP net income for the third quarter of fiscal year 2012 was $216 million, or $0.58 per share2, compared to non-GAAP net income of $226 million, or $0.56 per share, for the same period a year ago.

[0001102624-12-000111:8k_2_02:9]
Revenues for the first nine months of fiscal year 2012 totaled $4.531 billion compared to revenues of $3.694 billion for the first nine months of the prior fiscal year, an increase of 23% year over year. GAAP net income for the first nine months of fiscal year 2012 totaled $425 million, or $1.10 per share, compared to GAAP net income of $513 million, or $1.31 per share for the first nine months of the prior fiscal year. Non-GAAP net income for the first nine months of fiscal year 2012 totaled $674 million, or $1.75 per share, compared to non-GAAP net income of $629 million, or $1.61 per share for the first nine months of the prior fiscal year.

[0001102624-12-000111:8k_2_02:10]
"More and more customers are leveraging storage virtualization to re-architect their data centers in order to gain efficiency, flexibility and cost savings, and NetApp provides the most compelling value proposition in the industry for both private and public cloud deployments," said Tom Georgens, president and CEO. "Our success is evident in our results, as NetApp won a record number of new customers, significantly increased our units shipped -- including a record number of high-end systems, and saw solid revenue growth across almost all geographies in our third quarter."

[0001102624-12-000111:8k_2_02:11]
Outlook

[0001102624-12-000111:8k_2_02:12]
| ● | NetApp estimates revenue for the fourth quarter of fiscal year 2012 to be in the range of $1.645 billion to $1.725 billion, which equates to approximately 5% to 10% sequential revenue growth and approximately 15% to 21% year-over-year revenue growth. |

[0001102624-12-000111:8k_2_02:13]
| ● | NetApp estimates that fourth quarter fiscal year 2012 GAAP earnings per share will be approximately $0.38 to $0.43 per share. NetApp estimates that fourth quarter fiscal year 2012 non-GAAP earnings per share will be approximately $0.60 to $0.65 per share. |

[0001102624-12-000111:8k_2_02:14]
| ● | NetApp estimates that share count for the fourth quarter of fiscal year 2012 will increase to approximately 378 million shares, including an estimated 8 million shares from the Company’s outstanding convertible notes3. Share count does not include the Company’s outstanding note hedges which are expected to offset 80% of the dilution from the convertible notes at maturity or conversion. |

[0001102624-12-000111:8k_2_02:15]
Business Highlights

[0001102624-12-000111:8k_2_02:16]
During the third quarter of fiscal year 2012, NetApp continued to demonstrate the innovation and commitment needed to help its customers and partners address today’s expanding data requirements to drive business success. NetApp unveiled its “Smart Decisions” initiative aimed at helping midsize business customers start right, keep it simple, and grow smart, while at the same time enabling its partners to offer the best technologies and solutions to grow their own businesses, increase profits, and help their customers succeed. Highlights for the quarter include the following:

[0001102624-12-000111:8k_2_02:17]
Midsize Business Customers Build on NetApp to Address Growing Business Demands and the Need to Do More with Less

[0001102624-12-000111:8k_2_02:18]
| ● | NetApp unveiled the new NetApp® FAS2000 entry product line which enables customers to start right and grow with the needs of their business. The enhanced portfolio also allows partners to offer their customers the best technologies and solutions to increase their own business, increase profits, and help their customers succeed. The powerful new FAS2240 delivers a two to three times of performance improvement and greater flexibility, allowing customers to maximize their storage investments, support demanding workloads, and add capabilities as their business needs change. NetApp OnCommand™ System Manager 2.0 software helps customers simplify, control, and automate setup and management of NetApp storage. With more than 10,000 midsize business customers already turning to NetApp each year for their storage needs, the enhanced portfolio will help NetApp continue to build on its position as an industry leader. |

[0001102624-12-000111:8k_2_02:19]
Be The Match Leverages NetApp to Turn Its IT Environment into a Catalyst for Life-Saving Speed and Flexibility

[0001102624-12-000111:8k_2_02:20]
| ● | Be The Match, which operates the world’s largest listing of potential marrow donors and donated cord blood units, depends on its IT infrastructure to allow the organization to facilitate thousands of potentially life-saving transplants each year. To help accelerate the flow of data and enhance its ability to match donors with patients, Be The Match recently chose NetApp as its storage foundation. By transforming its IT infrastructure, utilizing NetApp as one of its vendors, the organization expects to reduce the time to transplant by 15%, double its annual donor registrations, and facilitate 50% more transplants around the world. |

[0001102624-12-000111:8k_2_02:21]
NetApp Helps Customers Control Explosive Data Growth and Gain Greater Insight

[0001102624-12-000111:8k_2_02:22]
| ● | New NetApp solution helps customers maximize enterprise Hadoop implementations. The NetApp Open Solution for Hadoop provides customers with improved flexibility and performance along with lower total cost of ownership, enabling customers to gain greater insight into and a competitive advantage from their data. Additionally, NetApp teamed with Cloudera to distribute Cloudera’s Distribution, including Apache Hadoop and Cloudera Enterprise with the NetApp Open Solution for Hadoop, to help speed enterprise deployment and production use of Apache Hadoop. |

[0001102624-12-000111:8k_2_02:23]
| ● | NetApp unveils new solutions based on the E-Series platform to address big data requirements. The NetApp High-Performance Computing Solution for Lustre is purpose-built to help customers efficiently scale bandwidth and density, with proven reliability to solve difficult research, modeling, and simulation problems. The NetApp Seismic Processing Solution provides efficient access to big data generated by seismic processing operations to help exploration teams make optimal decisions. |

[0001102624-12-000111:8k_2_02:24]
Awards and Milestones

[0001102624-12-000111:8k_2_02:25]
|  | ● | NetApp continues to earn recognition as a great place to work. Built on a culture of innovation committed to partner and customer success, NetApp was ranked #6 on FORTUNE magazine’s “100 Best Companies to Work For” list for 2012. The honor marks the fourth consecutive year that NetApp was ranked in the top 10 and the sixth consecutive year it was ranked in the top 15. Additionally, NetApp was ranked #6 on the Crain’s New York Business annual “Best Places to Work in New York City” list for 2011. |
|  | ● | NetApp is One of Six Companies Named "Partner of the Year" by CDW. NetApp was among only six companies named a winner of CDW's fifth annual "Partner of the Year" awards which recognized companies that have consistently provided exemplary support to CDW and its customers, as well as delivered strong growth and financial performance over the previous 12 months. NetApp was honored not only for its outstanding performance, but also the value it delivers which has greatly contributed to both CDW and its customers' success. |
|  | ● | NetApp positioned in Leaders quadrant. Gartner, Inc. placed NetApp in the Leaders quadrant for midrange and high-end modular disk arrays. Gartner asserted that vendors in the Leaders quadrant “have the highest scores in their ability to execute and completeness of vision.”4 |

[0001102624-12-000111:8k_2_02:26]
Webcast and Conference Call Information

[0001102624-12-000111:8k_2_02:27]
The NetApp third quarter fiscal year 2012 results conference call will be broadcast live on the Internet at investors.netapp.com on Wednesday, February 15, 2012, at 2 p.m. Pacific Time. This press release and any other information related to the call will also be posted on the Web site at that location. An audio replay Webcast will be available after 4 p.m. Pacific Time on the Web site.

[0001102624-12-000111:8k_2_02:28]
NetApp uses a hybrid format for disclosing key financial information associated with our quarterly results. Concurrent with the press release, NetApp posts a supplemental commentary with financial information and statistics to our Web site at investors.netapp.com.

[0001102624-12-000111:8k_2_02:29]
About NetApp

[0001102624-12-000111:8k_2_02:30]
NetApp creates innovative storage and data management solutions that deliver outstanding cost efficiency and accelerate business breakthroughs. Discover our passion for helping companies around the world go further, faster at www.netapp.com.

[0001102624-12-000111:8k_2_02:31]
###

[0001102624-12-000111:8k_2_02:32]
NetApp, the NetApp logo, Go further, faster, and OnCommand are trademarks or registered trademarks of NetApp, Inc. All other marks are the property of their respective owners and should be treated as such.

[0001102624-12-000111:8k_2_02:33]
| 1 | GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |

[0001102624-12-000111:8k_2_02:34]
| 2 | Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our convertible debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. |

[0001102624-12-000111:8k_2_02:35]
| 3 | 80% hedged on maturity or conversion of the convertible notes. |

[0001102624-12-000111:8k_2_02:36]
| 4 | “Magic Quadrant for Midrange and High-End Modular Disk Arrays” by Roger W. Cox, Pushan Rinnen, Stanley Zaffos, and Jimmie Chang, November 17, 2011. |

[0001102624-12-000111:8k_2_02:37]
NetApp Usage of Non-GAAP Financials

[0001102624-12-000111:8k_2_02:38]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our convertible debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-12-000111:8k_2_02:39]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation. We have historically reported similar non-GAAP financial measures to our investors and believe that the inclusion of comparative numbers provides consistency in our financial reporting at this time.

[0001102624-12-000111:8k_2_02:40]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | January 27, 2012 |  |  | April 29, 2011 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,866.1 |  |  | $ | 5,174.7 |  |
| Accounts receivable, net |  |  | 685.4 |  |  |  | 742.6 |  |
| Inventories |  |  | 153.8 |  |  |  | 108.5 |  |
| Other current assets |  |  | 462.4 |  |  |  | 339.4 |  |
| Total current assets |  |  | 6,167.7 |  |  |  | 6,365.2 |  |
| Property and equipment, net |  |  | 1,081.8 |  |  |  | 911.6 |  |
| Goodwill and other intangible assets, net |  |  | 1,162.7 |  |  |  | 813.3 |  |
| Other non-current assets |  |  | 409.4 |  |  |  | 408.7 |  |
| Total assets |  | $ | 8,821.6 |  |  | $ | 8,498.8 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 220.2 |  |  | $ | 232.8 |  |
| Accrued compensation and other current liabilities |  |  | 628.0 |  |  |  | 763.0 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | - |  |  |  | 1,150.4 |  |
| Short-term deferred revenue |  |  | 1,309.3 |  |  |  | 1,226.6 |  |
| Total current liabilities |  |  | 2,157.5 |  |  |  | 3,372.8 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | 1,188.8 |  |  |  | - |  |
| Other long-term liabilities |  |  | 197.3 |  |  |  | 192.9 |  |
| Long-term deferred revenue |  |  | 1,236.5 |  |  |  | 1,088.3 |  |
| Total liabilities |  |  | 4,780.1 |  |  |  | 4,654.0 |  |
| 1.75% Convertible Senior Notes due 2013 |  |  | - |  |  |  | 114.6 |  |
| Stockholders' equity |  |  | 4,041.5 |  |  |  | 3,730.2 |  |
| Total liabilities and stockholders' equity |  | $ | 8,821.6 |  |  | $ | 8,498.8 |  |

[0001102624-12-000111:8k_2_02:41]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2012 |  |  | January 28, 2011 |  |  | January 27, 2012 |  |  | January 28, 2011 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,062.7 |  |  | $ | 844.3 |  |  | $ | 3,044.6 |  |  | $ | 2,406.6 |  |
| Software entitlements and maintenance |  |  | 203.5 |  |  |  | 182.7 |  |  |  | 599.7 |  |  |  | 533.6 |  |
| Service |  |  | 299.3 |  |  |  | 262.6 |  |  |  | 886.4 |  |  |  | 754.1 |  |
| Net revenues |  |  | 1,565.5 |  |  |  | 1,289.6 |  |  |  | 4,530.7 |  |  |  | 3,694.3 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 517.8 |  |  |  | 328.4 |  |  |  | 1,415.9 |  |  |  | 962.9 |  |
| Cost of software entitlements and maintenance |  |  | 6.2 |  |  |  | 4.0 |  |  |  | 17.1 |  |  |  | 10.9 |  |
| Cost of service |  |  | 133.0 |  |  |  | 111.0 |  |  |  | 379.3 |  |  |  | 320.0 |  |
| Total cost of revenues |  |  | 657.0 |  |  |  | 443.4 |  |  |  | 1,812.3 |  |  |  | 1,293.8 |  |
| Gross profit |  |  | 908.5 |  |  |  | 846.2 |  |  |  | 2,718.4 |  |  |  | 2,400.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 477.0 |  |  |  | 397.4 |  |  |  | 1,385.9 |  |  |  | 1,134.4 |  |
| Research and development |  |  | 208.3 |  |  |  | 166.0 |  |  |  | 606.6 |  |  |  | 472.1 |  |
| General and administrative |  |  | 63.2 |  |  |  | 61.9 |  |  |  | 193.4 |  |  |  | 182.3 |  |
| Restructuring and other charges |  |  | - |  |  |  | (0.7 | ) |  |  | - |  |  |  | (0.6 | ) |
| Acquisition-related expense |  |  | 3.5 |  |  |  | 0.6 |  |  |  | 7.4 |  |  |  | 0.9 |  |
| Total operating expenses |  |  | 752.0 |  |  |  | 625.2 |  |  |  | 2,193.3 |  |  |  | 1,789.1 |  |
| Income from operations |  |  | 156.5 |  |  |  | 221.0 |  |  |  | 525.1 |  |  |  | 611.4 |  |
| Other expense, net |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  |  | 8.7 |  |  |  | 10.3 |  |  |  | 27.6 |  |  |  | 29.6 |  |
| Interest expense |  |  | (18.9 | ) |  |  | (19.0 | ) |  |  | (54.7 | ) |  |  | (56.2 | ) |
| Other income (expense), net |  |  | 0.6 |  |  |  | 0.4 |  |  |  | (0.1 | ) |  |  | 1.2 |  |
| Total other expense, net |  |  | (9.6 | ) |  |  | (8.3 | ) |  |  | (27.2 | ) |  |  | (25.4 | ) |
| Income before income taxes |  |  | 146.9 |  |  |  | 212.7 |  |  |  | 497.9 |  |  |  | 586.0 |  |
| Provision for income taxes |  |  | 27.3 |  |  |  | 26.3 |  |  |  | 73.2 |  |  |  | 73.5 |  |
| Net income |  | $ | 119.6 |  |  | $ | 186.4 |  |  | $ | 424.7 |  |  | $ | 512.5 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.33 |  |  | $ | 0.51 |  |  | $ | 1.17 |  |  | $ | 1.43 |  |
| Diluted |  | $ | 0.32 |  |  | $ | 0.46 |  |  | $ | 1.10 |  |  | $ | 1.31 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 360.3 |  |  |  | 364.8 |  |  |  | 364.0 |  |  |  | 358.8 |  |
| Diluted |  |  | 373.7 |  |  |  | 406.2 |  |  |  | 385.1 |  |  |  | 390.7 |  |

[0001102624-12-000111:8k_2_02:42]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOW |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2012 |  |  | January 28, 2011 |  |  | January 27, 2012 |  |  | January 28, 2011 |  |
| Cash Flows from Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 119.6 |  |  | $ | 186.4 |  |  | $ | 424.7 |  |  | $ | 512.5 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 73.6 |  |  |  | 41.0 |  |  |  | 210.5 |  |  |  | 123.3 |  |
| Stock-based compensation |  |  | 76.7 |  |  |  | 45.0 |  |  |  | 197.8 |  |  |  | 127.0 |  |
| Accretion of discount and issuance costs on notes |  |  | 13.5 |  |  |  | 13.3 |  |  |  | 38.7 |  |  |  | 39.2 |  |
| Tax benefit (charges) from stock-based compensation |  |  | (4.4 | ) |  |  | 25.1 |  |  |  | 74.7 |  |  |  | 74.9 |  |
| Shortfall (excess tax benefit) from stock-based compensation |  |  | 4.0 |  |  |  | (21.7 | ) |  |  | (80.7 | ) |  |  | (63.3 | ) |
| Other, net |  |  | 2.5 |  |  |  | (6.8 | ) |  |  | (71.9 | ) |  |  | (26.2 | ) |
| Changes in assets and liabilities, net of acquisition of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (59.8 | ) |  |  | (98.9 | ) |  |  | 55.8 |  |  |  | (77.5 | ) |
| Inventories |  |  | 9.5 |  |  |  | (12.2 | ) |  |  | (8.8 | ) |  |  | 18.8 |  |
| Accounts payable |  |  | (56.0 | ) |  |  | 16.3 |  |  |  | (10.4 | ) |  |  | (2.3 | ) |
| Accrued compensation and other current liabilities |  |  | 12.6 |  |  |  | 55.5 |  |  |  | (160.5 | ) |  |  | (40.6 | ) |
| Deferred revenue |  |  | 107.6 |  |  |  | 123.3 |  |  |  | 234.5 |  |  |  | 151.5 |  |
| Changes in other operating assets and liabilities, net |  |  | (30.2 | ) |  |  | (11.9 | ) |  |  | (24.4 | ) |  |  | 50.2 |  |
| Net cash provided by operating activities |  |  | 269.2 |  |  |  | 354.4 |  |  |  | 880.0 |  |  |  | 887.5 |  |
| Cash Flows from Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases of investments, net |  |  | (61.6 | ) |  |  | (240.7 | ) |  |  | (21.2 | ) |  |  | (835.5 | ) |
| Purchases of property and equipment |  |  | (91.3 | ) |  |  | (66.3 | ) |  |  | (282.9 | ) |  |  | (149.8 | ) |
| Acquisition of businesses, net of cash acquired |  |  | - |  |  |  | - |  |  |  | (480.0 | ) |  |  | (74.9 | ) |
| Other investing activities, net |  |  | (2.0 | ) |  |  | 0.8 |  |  |  | - |  |  |  | 0.8 |  |
| Net cash used in investing activities |  |  | (154.9 | ) |  |  | (306.2 | ) |  |  | (784.1 | ) |  |  | (1,059.4 | ) |
| Cash Flows from Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 49.1 |  |  |  | 75.9 |  |  |  | 101.0 |  |  |  | 312.0 |  |
| Repurchase and retirement of common stock |  |  | - |  |  |  | - |  |  |  | (600.0 | ) |  |  | - |  |
| Excess tax benefit (shortfall) from stock-based compensation |  |  | (4.0 | ) |  |  | 21.7 |  |  |  | 80.7 |  |  |  | 63.3 |  |
| Other financing activities, net |  |  | 1.5 |  |  |  | 2.4 |  |  |  | 3.1 |  |  |  | 0.4 |  |
| Net cash provided by (used in) financing activities |  |  | 46.6 |  |  |  | 100.0 |  |  |  | (415.2 | ) |  |  | 375.7 |  |
| Effect of Exchange Rate Changes on Cash and Cash Equivalents |  |  | (9.0 | ) |  |  | 0.1 |  |  |  | (17.1 | ) |  |  | 10.6 |  |
| Net Increase (Decrease) in Cash and Cash Equivalents |  |  | 151.9 |  |  |  | 148.3 |  |  |  | (336.4 | ) |  |  | 214.4 |  |
| Cash and Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,269.0 |  |  |  | 1,771.1 |  |  |  | 2,757.3 |  |  |  | 1,705.0 |  |
| End of period |  | $ | 2,420.9 |  |  | $ | 1,919.4 |  |  | $ | 2,420.9 |  |  | $ | 1,919.4 |  |

[0001102624-12-000111:8k_2_02:43]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP AND GAAP |  |
| IN THE CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except net income per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27, 2012 |  |  | January 28, 2011 |  |  | January 27, 2012 |  |  | January 28, 2011 |  |
| SUMMARY RECONCILIATION OF NET INCOME |  |  |  |  |  |  |  |  |  |  |  |  |
| NET INCOME |  | $ | 119.6 |  |  | $ | 186.4 |  |  | $ | 424.7 |  |  | $ | 512.5 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 21.6 |  |  |  | 3.4 |  |  |  | 67.6 |  |  |  | 13.3 |  |
| Stock-based compensation |  |  | 76.7 |  |  |  | 44.8 |  |  |  | 197.8 |  |  |  | 126.8 |  |
| Restructuring and other charges |  |  | - |  |  |  | (0.7 | ) |  |  | - |  |  |  | (0.6 | ) |
| Acquisition-related expense |  |  | 3.5 |  |  |  | 0.6 |  |  |  | 15.4 |  |  |  | 0.9 |  |
| Non-cash interest expense |  |  | 13.5 |  |  |  | 13.2 |  |  |  | 38.7 |  |  |  | 39.1 |  |
| Gain on investments |  |  | (0.7 | ) |  |  | - |  |  |  | (0.7 | ) |  |  | (2.5 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (18.2 | ) |  |  | (21.9 | ) |  |  | (69.7 | ) |  |  | (60.6 | ) |
| NON-GAAP NET INCOME |  | $ | 216.0 |  |  | $ | 225.8 |  |  | $ | 673.8 |  |  | $ | 628.9 |  |
| NET INCOME PER SHARE |  | $ | 0.320 |  |  | $ | 0.459 |  |  | $ | 1.103 |  |  | $ | 1.312 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.058 |  |  |  | 0.008 |  |  |  | 0.175 |  |  |  | 0.034 |  |
| Stock-based compensation |  |  | 0.205 |  |  |  | 0.110 |  |  |  | 0.514 |  |  |  | 0.325 |  |
| Restructuring and other charges |  |  | - |  |  |  | (0.002 | ) |  |  | - |  |  |  | (0.002 | ) |
| Acquisition-related expense |  |  | 0.010 |  |  |  | 0.002 |  |  |  | 0.040 |  |  |  | 0.002 |  |
| Non-cash interest expense |  |  | 0.036 |  |  |  | 0.033 |  |  |  | 0.101 |  |  |  | 0.100 |  |
| Gain on investments |  |  | (0.002 | ) |  |  | - |  |  |  | (0.002 | ) |  |  | (0.006 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.049 | ) |  |  | (0.054 | ) |  |  | (0.181 | ) |  |  | (0.155 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.578 |  |  | $ | 0.556 |  |  | $ | 1.750 |  |  | $ | 1.610 |  |

[0001102624-12-000111:8k_2_02:44]
| NETAPP, INC. |  |
| SUPPLEMENTAL INFORMATION |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended January 27, 2012 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Restructuring and Other Charges |  |  | Acquisition- related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 13.9 |  |  | $ | 1.6 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 15.5 |  |
| Cost of service revenues |  |  | - |  |  |  | 5.7 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 5.7 |  |
| Sales and marketing expense |  |  | 7.6 |  |  |  | 37.5 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 45.1 |  |
| Research and development expense |  |  | 0.1 |  |  |  | 22.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 22.9 |  |
| General and administrative expense |  |  | - |  |  |  | 9.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 9.1 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3.5 |  |  |  | - |  |  |  | - |  |  |  | 3.5 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 13.5 |  |  |  | - |  |  |  | 13.5 |  |
| Other income (expense), net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |  |  | (0.7 | ) |
| Effect on income before income taxes |  | $ | 21.6 |  |  | $ | 76.7 |  |  | $ | - |  |  | $ | 3.5 |  |  | $ | 13.5 |  |  | $ | (0.7 | ) |  | $ | 114.6 |  |
|  |  | Three Months Ended January 28, 2011 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Restructuring and Other Charges |  |  | Acquisition- related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 2.5 |  |  | $ | 0.9 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 3.4 |  |
| Cost of service revenues |  |  | - |  |  |  | 3.6 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3.6 |  |
| Sales and marketing expense |  |  | 0.9 |  |  |  | 21.2 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 22.1 |  |
| Research and development expense |  |  | - |  |  |  | 11.3 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 11.3 |  |
| General and administrative expense |  |  | - |  |  |  | 7.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 7.8 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.6 |  |  |  | - |  |  |  | - |  |  |  | 0.6 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 13.2 |  |  |  | - |  |  |  | 13.2 |  |
| Effect on income before income taxes |  | $ | 3.4 |  |  | $ | 44.8 |  |  | $ | (0.7 | ) |  | $ | 0.6 |  |  | $ | 13.2 |  |  | $ | - |  |  | $ | 61.3 |  |
|  |  | Nine Months Ended January 27, 2012 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Restructuring and Other Charges |  |  | Acquisition- related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 41.8 |  |  | $ | 4.1 |  |  | $ | - |  |  | $ | 5.4 |  |  | $ | - |  |  | $ | - |  |  | $ | 51.3 |  |
| Cost of service revenues |  |  | - |  |  |  | 13.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 13.8 |  |
| Sales and marketing expense |  |  | 25.6 |  |  |  | 96.5 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 122.1 |  |
| Research and development expense |  |  | 0.2 |  |  |  | 57.0 |  |  |  | - |  |  |  | 2.6 |  |  |  | - |  |  |  | - |  |  |  | 59.8 |  |
| General and administrative expense |  |  | - |  |  |  | 26.4 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 26.4 |  |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 7.4 |  |  |  | - |  |  |  | - |  |  |  | 7.4 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 38.7 |  |  |  | - |  |  |  | 38.7 |  |
| Other income (expense), net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.7 | ) |  |  | (0.7 | ) |
| Effect on income before income taxes |  | $ | 67.6 |  |  | $ | 197.8 |  |  | $ | - |  |  | $ | 15.4 |  |  | $ | 38.7 |  |  | $ | (0.7 | ) |  | $ | 318.8 |  |
|  |  | Nine Months Ended January 28, 2011 |  |
|  |  | Amortization of Intangible Assets |  |  | Stock-based Compensation |  |  | Restructuring and Other Charges |  |  | Acquisition-related Expense |  |  | Non-cash Interest Expense |  |  | Gain on Investments |  |  | Total |  |
| Cost of product revenues |  | $ | 10.2 |  |  | $ | 2.6 |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 12.8 |  |
| Cost of service revenues |  |  | - |  |  |  | 10.6 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 10.6 |  |
| Sales and marketing expense |  |  | 3.1 |  |  |  | 59.1 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 62.2 |  |
| Research and development expense |  |  | - |  |  |  | 31.6 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 31.6 |  |
| General and administrative expense |  |  | - |  |  |  | 22.9 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 22.9 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | (0.6 | ) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.6 | ) |
| Acquisition-related expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.9 |  |  |  | - |  |  |  | - |  |  |  | 0.9 |  |
| Interest expense |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 39.1 |  |  |  | - |  |  |  | 39.1 |  |
| Other income (expense), net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (2.5 | ) |  |  | (2.5 | ) |
| Effect on income before income taxes |  | $ | 13.3 |  |  | $ | 126.8 |  |  | $ | (0.6 | ) |  | $ | 0.9 |  |  | $ | 39.1 |  |  | $ | (2.5 | ) |  | $ | 177.0 |  |

[0001102624-12-000111:8k_2_02:45]
|  | NETAPP, INC. |
|  | RECONCILIATION OF NON GAAP GUIDANCE TO GAAP |
|  | EXPRESSED AS EARNINGS PER SHARE |
|  | FOURTH QUARTER 2012 |
|  | (Unaudited) |
|  | Fourth Quarter |
|  | 2012 |
| Non-GAAP Guidance | $0.60 - $0.65 |
| Adjustments of Specific Items to |  |
| Net Income Per Share for the Fourth |  |
| Quarter 2012: |  |
| Amortization of intangible assets | (0.06) |
| Stock-based compensation | (0.19) |
| Acquisition-related expense | (0.01) |
| Non-cash interest expense | (0.03) |
| Income tax effect | 0.07 |
| Total Adjustments | (0.22) |
| GAAP Guidance -Net Income Per Share | $0.38 - $0.43 |
