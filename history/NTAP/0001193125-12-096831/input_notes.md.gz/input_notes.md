# NTAP notes — 0001193125-12-096831


## ntap:AccountsReceivableFromSignificantCustomersTextBlock

[0001193125-12-096831:notes:1]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Arrow Electronics, Inc. |  | $ | N/A |  |  | $ | 101.4 |  |
| Avnet, Inc. |  |  | 70.9 |  |  |  | 107.5 |  |

[0001193125-12-096831:notes:2]
N/A - Not Applicable


## ntap:AmortizationFiniteLivedIntangibleAssetsTextBlock

[0001193125-12-096831:notes:3]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |  | Statements of OperationsClassifications |
| Developed technology |  | $ | 14.0 |  |  | $ | 2.5 |  |  | $ | 41.9 |  |  | $ | 10.2 |  |  | Cost of product revenues |
| Customer contracts/relationships |  |  | 6.4 |  |  |  | 0.6 |  |  |  | 21.8 |  |  |  | 2.2 |  |  | Sales and marketing |
| Trademarks and trade names |  |  | 1.0 |  |  |  | 0.3 |  |  |  | 3.3 |  |  |  | 0.9 |  |  | Sales and marketing |
| Covenants not to compete |  |  | 0.2 |  |  |  | 0.0 |  |  |  | 0.6 |  |  |  | 0.0 |  |  | Sales and marketing/Research and development |
|  |  | $ | 21.6 |  |  | $ | 3.4 |  |  | $ | 67.6 |  |  | $ | 13.3 |  |  |  |


## ntap:DebtDiscountAndIssuanceCostTextBlock

[0001193125-12-096831:notes:4]
| Remaining debt discount |  | $ | 76.2 |  |
| Remaining issuance costs |  |  | 6.6 |  |
| Remaining life of the Notes (years) |  |  | 1.3 |  |


## ntap:DisclosureOfShareBasedCompensationArrangementsAdditionalInformationRelatedToStockOptionsTextBlock

[0001193125-12-096831:notes:5]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Weighted-average fair value per share granted |  | $ | 13.26 |  |  | $ | 18.79 |  |  | $ | 16.88 |  |  | $ | 15.72 |  |
| Weighted-average fair value per share of options assumed in acquisition |  |  | N/A |  |  |  | N/A |  |  |  | N/A |  |  | $ | 21.15 |  |
| Intrinsic value of options exercised |  | $ | 21.0 |  |  | $ | 79.4 |  |  | $ | 71.6 |  |  | $ | 294.0 |  |
| Proceeds received from the exercise of stock options |  | $ | 19.5 |  |  | $ | 53.9 |  |  | $ | 62.2 |  |  | $ | 278.8 |  |
| Fair value of options vested |  | $ | 18.1 |  |  | $ | 23.1 |  |  | $ | 56.8 |  |  | $ | 77.5 |  |


## ntap:InterestCostIncurredTextBlock

[0001193125-12-096831:notes:6]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Contractual coupon interest expense |  | $ | 5.5 |  |  | $ | 5.5 |  |  | $ | 16.5 |  |  | $ | 16.5 |  |
| Amortization of debt discount |  |  | 13.0 |  |  |  | 12.2 |  |  |  | 38.4 |  |  |  | 36.1 |  |
| Amortization of debt issuance costs |  |  | 1.1 |  |  |  | 1.1 |  |  |  | 3.3 |  |  |  | 3.1 |  |
| Less capitalized interest |  |  | (0.9 | ) |  |  | 0.0 |  |  |  | (4.3 | ) |  |  | 0.0 |  |
| Total interest expense related to Notes |  | $ | 18.7 |  |  | $ | 18.8 |  |  | $ | 53.9 |  |  | $ | 55.7 |  |


## ntap:InternationalSalesToSingleForeignCountriesTextBlock

[0001193125-12-096831:notes:7]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Germany |  | $ | 181.9 |  |  | $ | 164.4 |  |  | $ | 470.9 |  |  | $ | 461.3 |  |


## ntap:LongTermDebtByCurrentAndNonCurrentTextBlock

[0001193125-12-096831:notes:8]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Current portion of other long-term financing arrangements |  | $ | 9.3 |  |  | $ | 5.5 |  |
| Non-current portion of other long-term financing arrangements |  |  | 5.4 |  |  |  | 6.0 |  |
| Total |  | $ | 14.7 |  |  | $ | 11.5 |  |


## ntap:OtherCurrentAssetsTextBlock

[0001193125-12-096831:notes:9]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Deferred tax assets, net |  | $ | 223.2 |  |  | $ | 145.7 |  |
| Prepaid expenses and other current assets |  |  | 231.1 |  |  |  | 188.4 |  |
| Short-term restricted cash |  |  | 8.1 |  |  |  | 5.3 |  |
| Other current assets |  | $ | 462.4 |  |  | $ | 339.4 |  |


## ntap:ScheduleOfComputerSoftwareTableTextBlock

[0001193125-12-096831:notes:10]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Computer software |  | $ | 154.0 |  |  | $ | 88.3 |  |


## ntap:ScheduleOfIncomeTaxEffectsAllocatedDirectlyToEquityEmployeeStockOptionsTextBlock

[0001193125-12-096831:notes:11]
|  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |
| Income tax benefits associated with employee stock transactions |  | $ | 74.7 |  |  | $ | 74.9 |  |


## ntap:ShareBasedCompensationArrangementByShareBasedPaymentAwardFairValueAssumptionsMethodUsedTextBlock

[0001193125-12-096831:notes:12]
|  |  | Stock Options |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Expected term in years |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 4.8 |  |  |  | 4.8 |  |
| Risk-free interest rate |  |  | 0.84 | % |  |  | 2.07 | % |  |  | 1.54 | % |  |  | 1.99 | % |
| Volatility |  |  | 43 | % |  |  | 37 | % |  |  | 36 | % |  |  | 37 | % |

[0001193125-12-096831:notes:13]
|  |  | ESPP |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.3 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 0.18 | % |  |  | 0.35 | % |  |  | 0.19 | % |  |  | 0.43 | % |
| Volatility |  |  | 45 | % |  |  | 39 | % |  |  | 44 | % |  |  | 39 | % |


## ntap:SharesWithheldForEmployeeTaxesTextBlock

[0001193125-12-096831:notes:14]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Shares withheld for taxes |  |  | 0.4 |  |  |  | 0.3 |  |  |  | 1.0 |  |  |  | 0.8 |  |
| Fair value of shares withheld and retired |  | $ | 16.4 |  |  | $ | 15.9 |  |  | $ | 44.2 |  |  | $ | 35.5 |  |


## us-gaap:AcceleratedShareRepurchasesTextBlock

[0001193125-12-096831:notes:15]
|  |  | Shares ofCommonStock |  |  | AdditionalPaid-inCapital |  |  | RetainedEarnings |  |  | TotalRepurchaseActivity |  |
| Repurchase and retirement of common stock |  |  | (14.6 | ) |  | $ | (125.8 | ) |  | $ | (474.1 | ) |  | $ | (599.9 | ) |
| Value of ASR forward contracts |  |  |  |  |  |  | (0.1 | ) |  |  |  |  |  |  | (0.1 | ) |
| Total cash payment |  |  | (14.6 | ) |  | $ | (125.9 | ) |  | $ | (474.1 | ) |  | $ | (600.0 | ) |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-12-096831:notes:16]
|  |  | January 27, 2012 |  |  | April 29, 2011 |  |
|  |  |  |  |  | Gross Unrealized |  |  |  |  |  |  |  |  | Gross Unrealized |  |  |  |  |
|  |  | Cost orAmortizedCost |  |  | Gains |  |  | Losses |  |  | EstimatedFairValue |  |  | Cost orAmortizedCost |  |  | Gains |  |  | Losses |  |  | EstimatedFairValue |  |
| Corporate bonds |  | $ | 1,968.6 |  |  | $ | 7.2 |  |  | $ | (2.0 | ) |  | $ | 1,973.8 |  |  | $ | 1,643.2 |  |  | $ | 10.2 |  |  | $ | (0.6 | ) |  | $ | 1,652.8 |  |
| U.S. treasury and government debt securities |  |  | 351.4 |  |  |  | 0.3 |  |  |  | 0.0 |  |  |  | 351.7 |  |  |  | 661.9 |  |  |  | 0.6 |  |  |  | (0.7 | ) |  |  | 661.8 |  |
| Commercial paper |  |  | 66.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 66.2 |  |  |  | 5.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 5.0 |  |
| Certificates of deposit |  |  | 107.3 |  |  |  | 0.4 |  |  |  | 0.0 |  |  |  | 107.7 |  |  |  | 96.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 96.3 |  |
| Money market funds |  |  | 1,612.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,612.1 |  |  |  | 1,539.6 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1,539.6 |  |
| Auction rate securities |  |  | 54.4 |  |  |  | 0.8 |  |  |  | (4.2 | ) |  |  | 51.0 |  |  |  | 69.2 |  |  |  | 0.4 |  |  |  | (4.5 | ) |  |  | 65.1 |  |
| Equity funds |  |  | 24.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 24.3 |  |  |  | 20.2 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 20.2 |  |
| Private equity fund |  |  | 1.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.0 |  |  |  | 1.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.3 |  |
| Municipal bonds |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.5 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.5 |  |
| Total debt and equity securities |  | $ | 4,185.3 |  |  | $ | 8.7 |  |  | $ | (6.2 | ) |  | $ | 4,187.8 |  |  | $ | 4,038.2 |  |  | $ | 11.2 |  |  | $ | (5.8 | ) |  | $ | 4,043.6 |  |


## us-gaap:BusinessAcquisitionIntegrationRestructuringAndOtherRelatedCostsTextBlock

[0001193125-12-096831:notes:17]
|  |  | Three MonthsEnded |  |  | Nine MonthsEnded |  |
|  |  | January 27,2012 |  |  | January 27,2012 |  |
| Acquisition-related expense |  | $ | 3.5 |  |  | $ | 7.4 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001193125-12-096831:notes:18]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Net revenues |  | $ | 1,565.5 |  |  | $ | 1,486.6 |  |  | $ | 4,539.3 |  |  | $ | 4,240.5 |  |
| Net income |  | $ | 119.6 |  |  | $ | 142.8 |  |  | $ | 431.3 |  |  | $ | 459.0 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-12-096831:notes:19]
[same as prior period, unchanged from 0001193125-11-330462:notes:24]

[0001193125-12-096831:notes:20]
[same as prior period, unchanged from 0001193125-11-330462:notes:25]

[0001193125-12-096831:notes:21]
On May 6, 2011, we completed the acquisition of certain assets related to the Engenio external storage systems business (Engenio) of LSI Corporation (LSI). We paid LSI $480.0 million in cash and also assumed certain liabilities related to Engenio. During the three years following the acquisition, LSI will pay us a total of $13.0 million to service certain LSI customer warranties. This acquisition enables us to address growing customer requirements in the areas of high bandwidth and intensive analytics workloads such as video, including full-motion video capture and digital video surveillance, as well as high-performance computing applications, such as genomics sequencing and scientific research.

[0001193125-12-096831:notes:22]
[same as prior period, unchanged from 0001193125-11-330462:notes:27]

[0001193125-12-096831:notes:23]
[same as prior period, unchanged from 0001193125-11-330462:notes:28]

[0001193125-12-096831:notes:24]
[same as prior period, unchanged from 0001193125-11-330462:notes:29]

[0001193125-12-096831:notes:25]
[same as prior period, unchanged from 0001193125-11-330462:notes:31]

[0001193125-12-096831:notes:26]
As this was an asset acquisition, United States (U.S.) goodwill is deductible for income tax purposes. The goodwill is comprised of expected synergies in utilizing Engenio's technology in our products and channels (and vice versa), reduction in future combined research and development expenses, and intangible assets, such as acquired workforce, that do not qualify for separate recognition.

[0001193125-12-096831:notes:27]
[same as prior period, unchanged from 0001193125-11-330462:notes:32]

[0001193125-12-096831:notes:28]
|  |  | Estimated FairValue |  |  | Useful Life(Years) |  |
| Developed technology |  | $ | 216.0 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 45.0 |  |  |  | 2 |  |
| Trademarks and trade names |  |  | 7.0 |  |  |  | 2 |  |
| Order backlog |  |  | 2.5 |  |  |  | 0 |  |
| Covenant not to compete |  |  | 1.6 |  |  |  | 3 |  |
| Total identified intangible assets |  | $ | 272.1 |  |  |  |  |  |

[0001193125-12-096831:notes:29]
Our consolidated net revenues for the three and nine months ended January 27, 2012 included $178.3 million and $517.8 million, respectively, attributable to Engenio since the acquisition. Due to continued integration of the combined businesses since the date of acquisition, it is impracticable to determine the earnings contributed by Engenio.

[0001193125-12-096831:notes:30]
The following unaudited pro forma condensed combined financial information gives effect to the acquisition of Engenio as if it were consummated on May 1, 2010 (the beginning of the comparable prior annual reporting period). Due to historically differing fiscal year ends of the Company and Engenio, the unaudited pro forma condensed combined financial information for the three and nine months ended January 28, 2011 is based on historical results of the Company for the three and nine months ended January 28, 2011 and the historical results of Engenio for the three and nine months ended December 31, 2010.

[0001193125-12-096831:notes:31]
[same as prior period, unchanged from 0001193125-11-330462:notes:36]

[0001193125-12-096831:notes:32]
A nonrecurring adjustment of $5.6 million has been reflected in the unaudited pro forma condensed combined information with the effect of increasing net income for the nine months ended January 27, 2012 and decreasing net income for the nine months ended January 28, 2011 to present the impact on cost of revenues from the step-up in inventory as if the acquisition occurred on May 1, 2010.

[0001193125-12-096831:notes:33]
Acquisition-related expense included in our condensed consolidated statements of operations was:

[0001193125-12-096831:notes:34]
For the nine months ended January 27, 2012, acquisition-related expense consisted of due diligence and legal charges of $0.7 million directly related to the acquisition of Engenio and $6.7 million of integration charges related to the combined business.

[0001193125-12-096831:notes:35]
[same as prior period, unchanged from 0001193125-11-330462:notes:40]

[0001193125-12-096831:notes:36]
[same as prior period, unchanged from 0001193125-11-330462:notes:41]

[0001193125-12-096831:notes:37]
The following table summarizes the purchase price components and equity interests acquired as of January 27, 2012 (in millions):

[0001193125-12-096831:notes:38]
|  |  | Akorri |  |  | Bycast |  |
| Acquisition dates |  | January 31,2011 |  |  | May 13,2010 |  |
| Percentage of equity interest acquired |  |  | 100 | % |  |  | 100 | % |
| Total purchase price |  | $ | 62.3 |  |  | $ | 83.8 |  |
| Cash component of purchase price |  | $ | 62.3 |  |  | $ | 80.5 |  |
| Fair value of vested options assumed |  | $ | 0.0 |  |  | $ | 3.3 |  |
| Purchase price held in escrow to secure obligations of acquired entity |  | $ | 7.9 |  |  | $ | 0.0 |  |

[0001193125-12-096831:notes:39]
In the three months ended January 27, 2012, the escrow period for the Bycast acquisition expired and the remaining purchase price of $13.1 million was released to the former shareholders. Subject to any claims for indemnity, the escrow funds for Akorri will be released in July 2012.

[0001193125-12-096831:notes:40]
[same as prior period, unchanged from 0001193125-11-330462:notes:45]

[0001193125-12-096831:notes:41]
[same as prior period, unchanged from 0001193125-11-330462:notes:46]

[0001193125-12-096831:notes:42]
In the three and nine months ended January 27, 2012, an adjustment of $1.2 million was recorded to the value of Akorri goodwill related to an adjustment to deferred income taxes.

[0001193125-12-096831:notes:43]
Goodwill related to the Akorri and Bycast acquisitions is not deductible for income tax purposes.

[0001193125-12-096831:notes:44]
The results of operations of Akorri and Bycast are included in our condensed consolidated statements of operations from their respective acquisition dates. Pro forma results of operations have not been presented because the acquisitions were not material to our results of operations.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001193125-12-096831:notes:45]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Cash |  | $ | 754.6 |  |  | $ | 1,169.1 |  |
| Cash equivalents |  |  | 1,666.3 |  |  |  | 1,588.2 |  |
| Cash and cash equivalents |  | $ | 2,420.9 |  |  | $ | 2,757.3 |  |


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001193125-12-096831:notes:46]
[same as prior period, unchanged from 0001193125-11-330462:notes:50]

[0001193125-12-096831:notes:47]
Non-cash investing and financing activities and supplemental cash flow information are as follows (in millions):

[0001193125-12-096831:notes:48]
|  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Reclassification of equity component of convertible debt |  | $ | 114.6 |  |  | $ | 0.0 |  |
| Acquisition of property and equipment on account |  | $ | 37.4 |  |  | $ | 7.8 |  |
| Acquisition of property and equipment through long-term financing |  | $ | 3.0 |  |  | $ | 12.6 |  |
| Options assumed from acquired business |  | $ | 0.0 |  |  | $ | 3.3 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 39.3 |  |  | $ | 23.4 |  |
| Interest paid (net of capitalized interest of $1.3 million and $0.0 million, respectively) |  | $ | 21.3 |  |  | $ | 22.6 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-096831:notes:49]
15. Commitments and Contingencies

[0001193125-12-096831:notes:50]
Lease Commitments

[0001193125-12-096831:notes:51]
As of January 27, 2012, future annual minimum lease payments under all non-cancelable facilities and equipment operating leases with an initial term in excess of one year totaled $402.7 million.

[0001193125-12-096831:notes:52]
As of January 27, 2012, we have four leasing arrangements (Leasing Arrangements 1, 2, 3 and 4) with BNP Paribas LLC (BNPPLC), some of which require us to lease certain of our land to BNPPLC for a period of 99 years and to lease approximately 0.6 million square feet of office space from BNPPLC for our headquarters in Sunnyvale, California, which had an original cost of $149.6 million. Under these leasing arrangements, we pay BNPPLC minimum lease payments, which vary based on LIBOR plus a spread or a fixed rate on the costs of the facilities on the respective lease commencement dates. We make payments for each of the leases for a term of five years. We have the option to renew each of the leases for two consecutive five-year periods upon approval by BNPPLC. Upon expiration (or upon any earlier termination) of the lease terms, we must elect one of the following options: (i) purchase the buildings from BNPPLC at cost; (ii) if certain conditions are met, arrange for the sale of the buildings by BNPPLC to a third-party, and be liable for any deficiency between the net proceeds received from the third-party and BNPPLC's cost, up to 85% of cost (residual guarantee); or (iii) pay BNPPLC supplemental payments for an amount equal to the difference between BNPPLC's cost and fair value, up to the residual guarantee, in which event we may recoup some or all of such payments by arranging for a sale of each or all buildings by BNPPLC during the ensuing two-year period.

[0001193125-12-096831:notes:53]
These leases require us to maintain specified financial covenants with which we were in compliance as of January 27, 2012.

[0001193125-12-096831:notes:54]
As of January 27, 2012, we estimated that the fair value of certain properties under synthetic lease was $51.0 million below the cost of the properties. We are accruing for this deficiency over the remaining terms of the respective leases. As of January 27, 2012, a deficiency reserve of $32.4 million was included in other current liabilities.

[0001193125-12-096831:notes:55]
Purchase Orders and Other Commitments

[0001193125-12-096831:notes:56]
In the normal course of business we make commitments to our third-party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. We had $220.4 million in non-cancelable purchase commitments with our contract manufacturers as of January 27, 2012. In addition, we recorded a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to product cost of sales. As of January 27, 2012 and April 29, 2011, such liability amounted to $3.2 million and $4.5 million, respectively, and is included in other current liabilities in the condensed consolidated balance sheets.

[0001193125-12-096831:notes:57]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course business for which we have not received goods or services. As of January 27, 2012, we had $48.5 million in capital purchase commitments and $230.7 million in other purchase commitments.

[0001193125-12-096831:notes:58]
Product Warranties

[0001193125-12-096831:notes:59]
We provide customers a warranty on software of ninety days to five years and a warranty on hardware of one to five years. The following table summarizes our warranty reserves (in millions):

[0001193125-12-096831:notes:60]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Beginning balance |  | $ | 65.0 |  |  | $ | 33.5 |  |  | $ | 40.5 |  |  | $ | 31.9 |  |
| Liability assumed in acquisition |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 17.5 |  |  |  | 0.0 |  |
| Expense accrued during the period |  |  | 14.1 |  |  |  | 8.0 |  |  |  | 41.5 |  |  |  | 20.9 |  |
| Warranty costs incurred |  |  | (10.9 | ) |  |  | (5.8 | ) |  |  | (31.3 | ) |  |  | (17.1 | ) |
| Ending balance |  | $ | 68.2 |  |  | $ | 35.7 |  |  | $ | 68.2 |  |  | $ | 35.7 |  |

[0001193125-12-096831:notes:61]
Financing Guarantees

[0001193125-12-096831:notes:62]
We have both nonrecourse and recourse lease financing arrangements with third-party financing companies through new and preexisting relationships with customers. In addition, from time to time we provide guarantees for a portion of financing arrangements under which we could be called upon to make payments to these third-party financing companies in the event of nonpayment by end-user customers. Under the terms of the nonrecourse leases, we do not have any continuing obligations or liabilities to the third-party financing companies. Under the terms of the recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party financing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. As of January 27, 2012, the maximum guaranteed payment contingencies under our financing arrangements totaled approximately $101.2 million, and the related deferred revenue and cost of revenues totaled approximately $98.9 million and $9.6 million, respectively. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001193125-12-096831:notes:63]
Legal Contingencies

[0001193125-12-096831:notes:64]
We are subject to various legal proceedings and claims which may arise in the normal course of business. No accrual has been recorded as of January 27, 2012, as the outcome of these legal matters is currently not determinable.

[0001193125-12-096831:notes:65]
On October 13, 2010, Amalgamated Bank (as trustee of the Longview Largecap 500 Index Fund and the Longview Largecap 500 Index Veba Fund) filed a derivative lawsuit on behalf of NetApp, Inc. and NetApp U.S. Public Sector, Inc. in the Superior Court of the State of California, Santa Clara County. The lawsuit named certain of our current and former directors as defendants. On February 3, 2011, the plaintiff filed an amended complaint in response to motions to dismiss that we and the individual defendants had filed. Like the original complaint, the amended complaint included claims of breach of fiduciary duty and waste of corporate assets and alleges that the defendants failed to monitor internal controls to ensure that we complied with legal requirements in our General Services Administration (GSA) contracting activities, resulting in us incurring defense and settlement costs. The amended complaint sought disgorgement of salaries and other compensation from the defendants and additional unspecified damages. We and the individual defendants filed motions to dismiss the amended complaint in early March 2011. Following a hearing on July 15, 2011, the Court granted the motions to dismiss, but permitted plaintiff leave to amend its complaint on or before September 16, 2011.

[0001193125-12-096831:notes:66]
On August 9, 2011, Amalgamated Bank filed a complaint in Delaware Chancery Court against us for the purpose of obtaining, in a summary proceeding, books and records to help Amalgamated Bank amend its complaint in the California lawsuit. Each of the parties filed cross motions for summary judgment, and a hearing was held before the Delaware Chancery Court on November 16, 2011. Following that hearing, the Court directed Amalgamated Bank to more narrowly tailor its requests. On December 5, 2011, the court allowed plaintiff to conduct a very limited document inspection. On February 6, 2012, the court denied plaintiff's motion to compel further document production.

[0001193125-12-096831:notes:67]
The plaintiff filed an amended complaint for a third time on September 15, 2011. This complaint alleged the same claims and requests for relief as the previous complaints. On January 9, 2012, the defendants filed motions to dismiss the amended complaint. A hearing on our motion to dismiss the California lawsuit will be held on March 23, 2012.


## us-gaap:DebtDisclosureTextBlock

[0001193125-12-096831:notes:68]
9. Financing Arrangements

[0001193125-12-096831:notes:69]
1.75% Convertible Senior Notes Due 2013

[0001193125-12-096831:notes:70]
On June 10, 2008, we issued $1,265.0 million aggregate principal amount of 1.75% Convertible Senior Notes due 2013 (the Notes). The Notes are unsecured, unsubordinated obligations of the Company, which pay interest in cash semi-annually at a rate of 1.75% per annum. The Notes will mature on June 1, 2013 unless earlier repurchased or converted in accordance with their terms prior to such date. The Notes may be converted, under the conditions specified below, based on an initial conversion rate of 31.40 shares of common stock per $1,000 principal amount of Notes (which represents an initial effective conversion price of the Notes of $31.85 per share), subject to adjustment as described in the indenture governing the Notes.

[0001193125-12-096831:notes:71]
The Notes are not redeemable by us prior to the maturity date. In the event of a fundamental change (as defined in the indenture for the Notes), holders of the Notes may require us to repurchase all or a portion of their Notes at a repurchase price equal to 100% of the principal amount of the Notes plus accrued and unpaid interest, if any, to, but excluding, the fundamental change repurchase date.

[0001193125-12-096831:notes:72]
The holders of the Notes may convert their Notes until the close of business on the scheduled trading day immediately preceding the maturity date if any of the following conditions are met: (1) during the five business day period after any five consecutive trading day period (the measurement period) in which the trading price of the Notes for each day in the measurement period was less than 98% of an amount equal to (i) the last reported sale price of our common stock multiplied by (ii) the conversion rate for the Notes on each such day; (2) during any calendar quarter (and only during such calendar quarter) if the last reported sale price of our common stock for 20 or more trading days in a period of 30 consecutive trading days ending on the last trading day of the immediately preceding calendar quarter exceeds 130% of the applicable conversion price in effect for the Notes on the last trading day of such immediately preceding calendar quarter; or (3) upon the occurrence of specified corporate transactions set forth in the indenture for the Notes. On or after March 1, 2013, until the scheduled trading day immediately preceding the maturity date, holders of the Notes may convert their Notes regardless of the foregoing conditions. Upon conversion, a holder will receive cash in an amount equal to the lesser of the conversion value and the principal amount of the Notes, and any shares of our common stock for any conversion value in excess of the principal amount of the Notes, if any. Holders of the Notes who convert their Notes in connection with a fundamental change will, under certain circumstances, be entitled to a make-whole premium in the form of an increase in the conversion rate.

[0001193125-12-096831:notes:73]
Our common stock price did not exceed the conversion threshold price of $41.41 per share set forth for the Notes for at least 20 trading days during the 30 consecutive trading days ended December 31, 2011. Accordingly, as of January 27, 2012, the Notes were not convertible at the option of the holder and, therefore, the carrying value of the Notes was classified as long-term debt and the difference between the principal amount and the carrying value of the Notes is reflected as equity on our condensed consolidated balance sheet as of that date.

[0001193125-12-096831:notes:74]
Our common stock price exceeded the conversion threshold for the Notes for at least 20 trading days during the 30 consecutive trading days ended March 31, 2011. Accordingly, as of April 29, 2011, the Notes were convertible at the option of the holder and, therefore, the carrying value of the Notes was classified as short-term debt. Since the Notes were convertible at the option of the holder and the principal amount would have been required to be paid in cash, the difference between the principal amount and the carrying value of the Notes was reflected as convertible debt in mezzanine on our condensed consolidated balance sheet as of April 29, 2011.

[0001193125-12-096831:notes:75]
The determination of whether or not the Notes are convertible must continue to be performed quarterly. Consequently, the Notes may be convertible in future quarters, and therefore may be classified as short-term debt, if the conversion thresholds are met in such quarters. Additionally, since the Notes would be convertible at the option of the holder and the principal amount would be required to be paid in cash, the difference between the principal amount and the carrying value of the Notes would be reflected as convertible debt in mezzanine on our condensed consolidated balance sheets.

[0001193125-12-096831:notes:76]
Upon conversion of any Notes, we deliver cash up to the principal amount of the Notes and, with respect to any excess conversion value greater than the principal amount of the Notes, shares of our common stock. As of January 27, 2012, shares issued related to the Notes were minimal. Based on the closing price of our common stock of $37.28 on January 27, 2012, the if-converted value of our Notes exceeded their principal amount by approximately $215.6 million.

[0001193125-12-096831:notes:77]
The following table reflects the carrying value of the Notes (in millions):

[0001193125-12-096831:notes:78]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| 1.75% Convertible Senior Notes Due 2013 |  | $ | 1,265.0 |  |  | $ | 1,265.0 |  |
| Less: Unamortized discount |  |  | (76.2 | ) |  |  | (114.6 | ) |
| Net carrying amount of Notes |  | $ | 1,188.8 |  |  | $ | 1,150.4 |  |

[0001193125-12-096831:notes:79]
We capitalize interest on facility assets under construction and on significant software development projects. The following table presents the amount of interest expense recognized related to the Notes (in millions):

[0001193125-12-096831:notes:80]
The following table reflects the remaining debt discount and issuance costs as of January 27, 2012 (in millions):

[0001193125-12-096831:notes:81]
Note Hedges and Warrants

[0001193125-12-096831:notes:82]
Concurrent with the issuance of the Notes, we purchased Note hedges and sold warrants. The separate Note hedge and warrant transactions are structured to reduce the potential future economic dilution associated with the conversion of the Notes.

[0001193125-12-096831:notes:83]
|  | • |  | Note Hedges: As of January 27, 2012 and April 29, 2011, we had arrangements with counterparties to buy up to approximately 31.8 million shares, subject to anti-dilution adjustments, of our common stock at a price of $31.85 per share, subject to adjustment. The Note hedge transactions will expire at the earlier of (1) the last day on which any Notes remain outstanding or (2) the scheduled trading day immediately preceding the maturity date of the Notes. Upon exercise of the Note hedges, we have the option to receive cash or shares of our common stock equal to the difference between the then market price and the strike price of the hedges. |

[0001193125-12-096831:notes:84]
|  | • |  | Warrants: As of January 27, 2012 and April 29, 2011, we had outstanding warrants for others to acquire, subject to anti-dilution adjustments, 39.7 million shares of our common stock at an exercise price of $41.28 per share, subject to adjustment, on a series of days commencing on September 3, 2013. Upon exercise of the warrants, we have the option to deliver cash or shares of our common stock equal to the difference between the then market price and the strike price of the warrants. |

[0001193125-12-096831:notes:85]
As of January 27, 2012, we were subject to potential dilution on the approximately 20% unhedged portion of our Notes upon conversion, if on the date of conversion, the per-share market price of our common stock exceeds the conversion price of $31.85.

[0001193125-12-096831:notes:86]
As of January 27, 2012, we received a minimal number of shares related to the Note hedge transactions and no cash or shares were delivered related to the warrant transactions.

[0001193125-12-096831:notes:87]
Fair Value of Notes

[0001193125-12-096831:notes:88]
As of January 27, 2012, the approximate fair value of the principal amount of the Notes, which includes the debt and equity components, was approximately $1,630.8 million, or 129% of the face value of the Notes, based upon quoted market information.

[0001193125-12-096831:notes:89]
Other Long-Term Financing Arrangements

[0001193125-12-096831:notes:90]
The following presents the amounts due under other long-term financing arrangements (in millions):


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001193125-12-096831:notes:91]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Product |  | $ | 32.8 |  |  | $ | 106.2 |  |
| SEM and service |  |  | 2,513.0 |  |  |  | 2,208.7 |  |
| Total |  | $ | 2,545.8 |  |  | $ | 2,314.9 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,309.3 |  |  | $ | 1,226.6 |  |
| Long-term |  |  | 1,236.5 |  |  |  | 1,088.3 |  |
| Total |  | $ | 2,545.8 |  |  | $ | 2,314.9 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-12-096831:notes:92]
| 11. | Derivatives and Hedging Activities |

[0001193125-12-096831:notes:93]
We use derivative instruments to manage exposures to foreign currency risk. The maximum length of time over which forecasted foreign denominated revenues are hedged is six months. The notional value of our outstanding foreign currency forward contracts that were entered into to hedge forecasted foreign currency denominated sales and our foreign currency denominated monetary asset and liability exposures consisted of the following (in millions):

[0001193125-12-096831:notes:94]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Euro |  | $ | 147.9 |  |  | $ | 104.0 |  |
| British Pound Sterling |  |  | 36.5 |  |  |  | 20.9 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Euro |  |  | 256.3 |  |  |  | 253.7 |  |
| British Pound Sterling |  |  | 45.4 |  |  |  | 70.8 |  |
| Australian Dollar |  |  | 39.8 |  |  |  | 34.4 |  |
| Canadian Dollar |  |  | 22.9 |  |  |  | 56.0 |  |
| Other |  |  | 63.6 |  |  |  | 52.6 |  |

[0001193125-12-096831:notes:95]
As of January 27, 2012 and April 29, 2011, the fair value of our short-term foreign currency contracts was not material. Certain of these contracts are designed to hedge our exposure to foreign currency denominated monetary assets and liabilities and are not designated as hedging instruments. Accordingly, changes in the fair value of these instruments are recognized in earnings during the period of change.

[0001193125-12-096831:notes:96]
The effect of derivative instruments designated as cash flow hedges recognized in net revenues on our consolidated statements of operations for the three and nine months ended January 27, 2012 and January 28, 2011, respectively, was as follows (in millions):

[0001193125-12-096831:notes:97]
|  |  | Three Months Ended January 27, 2012 |  |  | Three Months Ended January 28, 2011 |  |
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss)Recognized inAOCI |  |  | Gain (Loss)Reclassified fromAOCI intoIncome |  |  | Gain (Loss)Recognizedin AOCI |  |  | Gain (Loss)Reclassified fromAOCI intoIncome |  |
| Foreign exchange forward contracts |  | $ | 11.9 |  |  | $ | 10.5 |  |  | $ | 6.8 |  |  | $ | 4.6 |  |

[0001193125-12-096831:notes:98]
|  |  | Nine Months Ended January 27, 2012 |  |  | Nine Months Ended January 28, 2011 |  |
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss)Recognized inAOCI |  |  | Gain (Loss)Reclassified fromAOCI intoIncome |  |  | Gain (Loss)Recognizedin AOCI |  |  | Gain (Loss)Reclassified fromAOCI intoIncome |  |
| Foreign exchange forward contracts |  | $ | 22.2 |  |  | $ | 18.1 |  |  | $ | 8.8 |  |  | $ | 9.0 |  |

[0001193125-12-096831:notes:99]
The effect of derivative instruments not designated as hedges recognized in other income (expense), net on our consolidated statements of operations for the three and nine months ended January 27, 2012 and January 28, 2011, respectively, was as follows (in millions):

[0001193125-12-096831:notes:100]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Derivatives Not Designated as Hedging Instruments |  | Gain (Loss) Recognized into Income |  |  | Gain (Loss) Recognized into Income |  |
| Foreign exchange forward contracts |  | $ | 10.7 |  |  | $ | (0.2 | ) |  | $ | 24.9 |  |  | $ | (4.4 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-096831:notes:101]
[same as prior period, unchanged from 0001193125-11-330462:notes:100]

[0001193125-12-096831:notes:102]
[same as prior period, unchanged from 0001193125-11-330462:notes:101]

[0001193125-12-096831:notes:103]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 119.6 |  |  | $ | 186.4 |  |  | $ | 424.7 |  |  | $ | 512.5 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 360.3 |  |  |  | 364.8 |  |  |  | 364.0 |  |  |  | 358.8 |  |
| Dilutive potential shares related to employee equity award plans |  |  | 7.6 |  |  |  | 14.7 |  |  |  | 9.1 |  |  |  | 15.3 |  |
| Dilutive impact of assumed conversion of Notes |  |  | 5.8 |  |  |  | 16.9 |  |  |  | 9.3 |  |  |  | 11.9 |  |
| Dilutive impact of warrants |  |  | 0.0 |  |  |  | 9.8 |  |  |  | 2.7 |  |  |  | 4.7 |  |
| Shares used in diluted computation |  |  | 373.7 |  |  |  | 406.2 |  |  |  | 385.1 |  |  |  | 390.7 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.33 |  |  | $ | 0.51 |  |  | $ | 1.17 |  |  | $ | 1.43 |  |
| Diluted |  | $ | 0.32 |  |  | $ | 0.46 |  |  | $ | 1.10 |  |  | $ | 1.31 |  |

[0001193125-12-096831:notes:104]
[same as prior period, unchanged from 0001193125-11-330462:notes:103]

[0001193125-12-096831:notes:105]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Options and RSUs |  |  | 13.5 |  |  |  | 1.0 |  |  |  | 10.9 |  |  |  | 2.8 |  |

[0001193125-12-096831:notes:106]
Dilutive shares outstanding during the three months ended January 27, 2012 do not include any effect resulting from warrants, as their impact would have been anti-dilutive. The Note hedges (as described in Note 9) are not included in the calculation of earnings per share as their effect would have been anti-dilutive. The Note hedges, if exercised upon conversion of the Notes, are expected to reduce approximately 80% of the dilutive effect of the Notes when our stock price is above $31.85 per share.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001193125-12-096831:notes:107]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Balance at beginning of period |  | $ | 56.0 |  |  | $ | 66.2 |  |  | $ | 65.1 |  |  | $ | 69.0 |  |
| Total unrealized gains (losses), net included in other comprehensive income |  |  | (0.7 | ) |  |  | (0.5 | ) |  |  | 0.6 |  |  |  | (1.9 | ) |
| Total realized gains included in earnings |  |  | 0.7 |  |  |  | 0.0 |  |  |  | 0.7 |  |  |  | 0.0 |  |
| Settlements |  |  | (5.0 | ) |  |  | (0.6 | ) |  |  | (15.4 | ) |  |  | (2.0 | ) |
| Balance at end of period |  | $ | 51.0 |  |  | $ | 65.1 |  |  | $ | 51.0 |  |  | $ | 65.1 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0001193125-12-096831:notes:108]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 1,666.3 |  |  | $ | 1,612.1 |  |  | $ | 54.2 |  |  | $ | 0.0 |  |
| Short-term investments |  |  | 2,445.2 |  |  |  | 0.0 |  |  |  | 2,445.2 |  |  |  | 0.0 |  |
| Other current assets |  |  | 9.8 |  |  |  | 5.3 |  |  |  | 4.5 |  |  |  | 0.0 |  |
| Other non-current assets |  |  | 71.0 |  |  |  | 19.0 |  |  |  | 0.0 |  |  |  | 52.0 |  |
| Total |  | $ | 4,192.3 |  |  | $ | 1,636.4 |  |  | $ | 2,503.9 |  |  | $ | 52.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current liabilities |  | $ | 3.8 |  |  | $ | 0.0 |  |  | $ | 3.8 |  |  | $ | 0.0 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-12-096831:notes:109]
| 8. | Financial Instruments and Fair Value |

[0001193125-12-096831:notes:110]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the three levels of inputs to measure fair value:

[0001193125-12-096831:notes:111]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001193125-12-096831:notes:112]
Level 2: Inputs that reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0001193125-12-096831:notes:113]
Level 3: Unobservable inputs that reflect our own assumptions incorporated in valuation techniques used to measure fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0001193125-12-096831:notes:114]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an on-going basis, and consider an inactive market to be one in which there are infrequent or few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty's non-performance risk is considered in measuring the fair values of liabilities and assets, respectively.

[0001193125-12-096831:notes:115]
[same as prior period, unchanged from 0001193125-11-330462:notes:109]

[0001193125-12-096831:notes:116]
The following is a summary of our investments as of January 27, 2012 and April 29, 2011, respectively (in millions):

[0001193125-12-096831:notes:117]
The following table presents the contractual maturities of our debt investments as of January 27, 2012 (in millions):

[0001193125-12-096831:notes:118]
|  |  | AmortizedCost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 821.6 |  |  | $ | 823.6 |  |
| Due in one through five years |  |  | 1,672.0 |  |  |  | 1,675.8 |  |
| Due after ten years* |  |  | 54.4 |  |  |  | 51.0 |  |
|  |  | $ | 2,548.0 |  |  | $ | 2,550.4 |  |

[0001193125-12-096831:notes:119]
[same as prior period, unchanged from 0001193125-11-330462:notes:113]

[0001193125-12-096831:notes:120]
[same as prior period, unchanged from 0001193125-11-330462:notes:114]

[0001193125-12-096831:notes:121]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis as of January 27, 2012 (in millions):

[0001193125-12-096831:notes:122]
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 1,973.8 |  |  | $ | 0.0 |  |  | $ | 1,973.8 |  |  | $ | 0.0 |  |
| U.S. treasuries and government debt securities |  |  | 351.7 |  |  |  | 0.0 |  |  |  | 351.7 |  |  |  | 0.0 |  |
| Commercial paper |  |  | 66.2 |  |  |  | 0.0 |  |  |  | 66.2 |  |  |  | 0.0 |  |
| Certificates of deposit |  |  | 107.7 |  |  |  | 0.0 |  |  |  | 107.7 |  |  |  | 0.0 |  |
| Money market funds |  |  | 1,612.1 |  |  |  | 1,612.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Auction rate securities |  |  | 51.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 51.0 |  |
| Equity funds |  |  | 24.3 |  |  |  | 24.3 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Private equity fund |  |  | 1.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.0 |  |
| Foreign currency contracts |  |  | 4.5 |  |  |  | 0.0 |  |  |  | 4.5 |  |  |  | 0.0 |  |
| Total |  | $ | 4,192.3 |  |  | $ | 1,636.4 |  |  | $ | 2,503.9 |  |  | $ | 52.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | 3.8 |  |  | $ | 0.0 |  |  | $ | 3.8 |  |  | $ | 0.0 |  |

[0001193125-12-096831:notes:123]
[same as prior period, unchanged from 0001193125-11-330462:notes:117]

[0001193125-12-096831:notes:124]
The unrealized losses on our available-for-sale investments in corporate bonds were caused by market value declines as a result of the economic environment, as well as fluctuations in market interest rates. Because the decline in market value is attributable to changes in market conditions and not credit quality, and because we neither intend to sell nor are likely to be required to sell these investments prior to a recovery of par value, we do not consider these investments to be other-than temporarily impaired as of January 27, 2012.

[0001193125-12-096831:notes:125]
The table below provides a reconciliation of the beginning and ending balance of our Level 3 auction rate securities measured at fair value on a recurring basis using significant unobservable inputs as of January 27, 2012 and January 28, 2011, respectively (in millions):

[0001193125-12-096831:notes:126]
All of our auction rate securities (ARSs) are classified as other non-current assets and are backed by pools of student loans guaranteed by the U.S. Department of Education. As of January 27, 2012, we recorded cumulative net temporary impairment charges of $3.4 million in accumulated other comprehensive income (AOCI). Prior to the three months ended October 28, 2011, we estimated the fair value for each individual ARS using an income (discounted cash flow) approach that incorporates both observable and unobservable inputs to discount the expected future cash flows. Key inputs into the discounted cash flow analysis include managements' expectation of when the principal amount will be recovered either through redemption at par, a refinancing event by the issuer, and/or marketability adjustments. Beginning October 28, 2011, we included the market approach to the valuation technique in order to incorporate secondary market activity into our estimated fair value for each individual ARS. This change had no material impact on the valuation of our ARS portfolio. Based on our ability to access our cash and other short-term investments, our expected operating cash flows, and our other sources of cash, we do not intend to sell these investments prior to recovery of value. We will continue to monitor our ARS investments in light of the current debt market environment and evaluate these investments for impairment and classification.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-12-096831:notes:127]
6. Goodwill and Other Intangible Assets, Net

[0001193125-12-096831:notes:128]
Goodwill and other intangible assets, net are summarized as follows (in millions):

[0001193125-12-096831:notes:129]
| Goodwill: |  |  |  |  |
| April 29, 2011 |  | $ | 760.3 |  |
| Additions |  |  | 143.7 |  |
| Adjustments |  |  | 1.2 |  |
| January 27, 2012 |  | $ | 905.2 |  |

[0001193125-12-096831:notes:130]
|  |  | January 27, 2012 |  |  | April 29, 2011 |  |
|  |  | GrossCarryingAmount |  |  | AccumulatedAmortization |  |  | OtherIntangibleAssets, Net |  |  | GrossCarryingAmount |  |  | AccumulatedAmortization |  |  | OtherIntangibleAssets, Net |  |
| Other Intangible Assets, Net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | $ | 282.1 |  |  | $ | (65.0 | ) |  | $ | 217.1 |  |  | $ | 66.1 |  |  | $ | (23.2 | ) |  | $ | 42.9 |  |
| Customer contracts/relationships |  |  | 59.5 |  |  |  | (26.5 | ) |  |  | 33.0 |  |  |  | 12.0 |  |  |  | (4.6 | ) |  |  | 7.4 |  |
| Trademarks and trade names |  |  | 14.7 |  |  |  | (8.7 | ) |  |  | 6.0 |  |  |  | 7.7 |  |  |  | (5.5 | ) |  |  | 2.2 |  |
| Covenants not to compete |  |  | 2.2 |  |  |  | (0.8 | ) |  |  | 1.4 |  |  |  | 0.6 |  |  |  | (0.1 | ) |  |  | 0.5 |  |
| Total other intangible assets |  | $ | 358.5 |  |  | $ | (101.0 | ) |  | $ | 257.5 |  |  | $ | 86.4 |  |  | $ | (33.4 | ) |  | $ | 53.0 |  |

[0001193125-12-096831:notes:131]
Amortization expense for other intangible assets is summarized below (in millions):

[0001193125-12-096831:notes:132]
As of January 27, 2012, future amortization expense related to identifiable intangible assets is as follows (in millions):

[0001193125-12-096831:notes:133]
| Fiscal Year |  | Amount |  |
| Remainder of 2012 |  | $ | 21.4 |  |
| 2013 |  |  | 84.2 |  |
| 2014 |  |  | 52.0 |  |
| 2015 |  |  | 50.7 |  |
| 2016 |  |  | 46.9 |  |
| 2017 |  |  | 2.3 |  |
| Total |  | $ | 257.5 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-096831:notes:134]
| 12. | Income Taxes |

[0001193125-12-096831:notes:135]
[same as prior period, unchanged from 0001193125-11-330462:notes:128]

[0001193125-12-096831:notes:136]
|  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |
| Effective tax rates |  |  | 14.7 | % |  |  | 12.5 | % |

[0001193125-12-096831:notes:137]
Our effective tax rates reflect the impact of a significant amount of our earnings being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate.

[0001193125-12-096831:notes:138]
In January 2012, we reached agreement with the U.S. Internal Revenue Service (IRS) with regards to a tax position taken during prior periods. As a result of the settlement and resulting remeasurement of our tax positions, we recorded a discrete tax expense of $11.7 million, net of federal benefit, during the three and nine months ended January 27, 2012. In addition, we recognized a net increase of $17.4 million to the balance of our unrecognized tax benefits related to prior years as a result of the settlement and remeasurement.

[0001193125-12-096831:notes:139]
As of January 27, 2012, we had $155.5 million of unrecognized tax benefits, of which $104.3 million has been recorded in other long-term liabilities and $96.6 million, including penalties and interest, would affect our provision for income taxes if recognized. During the nine months ended January 27, 2012, there was a gross increase in our unrecognized tax benefits of $8.0 million for tax positions related to the current year, and a gross increase of $20.3 million and gross decrease of $6.0 million for tax positions related to prior years.

[0001193125-12-096831:notes:140]
In accordance with our accounting policy, we recognize accrued interest and penalties related to unrecognized tax benefits as a component of tax expense. Interest and penalties recognized through income tax expense during the three and nine months ended January 27, 2012 and January 28, 2011 were not material.

[0001193125-12-096831:notes:141]
In February 2012, the IRS commenced an examination of our fiscal 2008 through fiscal 2010 income tax returns. We are also under audit by the California Franchise Tax Board for our fiscal 2007 and 2008 California income tax returns. Our open years in U.S. federal jurisdictions are fiscal 2005 and later years. In addition, we are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal year 2000, in that we have tax attribute carryforwards from these years that could be subject to adjustments, if and when utilized.

[0001193125-12-096831:notes:142]
On September 17, 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 from our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. On December 19, 2011, the Danish Tax Tribunal issued a ruling that our Danish subsidiary was not liable for Danish withholding tax. The ruling is subject to appeal to the Danish High Court.

[0001193125-12-096831:notes:143]
We are in various stages of the examination and appeals process in connection with tax audits worldwide and it is difficult to determine when these examinations will be settled. It is reasonably possible that over the next twelve-month period, we may experience an increase or decrease in unrecognized tax benefits. It is not possible to determine either the magnitude or the range of any increase or decrease at this time.

[0001193125-12-096831:notes:144]
In April 2010, our Dutch subsidiary received a favorable tax ruling from the Dutch tax authorities effective May 1, 2010 that replaced the previous Dutch tax ruling which expired on April 30, 2010. This ruling resulted in both a lower level of earnings subject to tax in the Netherlands and an extension of the expiration date to April 30, 2015.

[0001193125-12-096831:notes:145]
On December 17, 2010, the Tax Relief Unemployment Insurance Reauthorization, and Job Creation Act of 2010 (the Act) was signed into law. Under the Act, the federal research credit was retroactively extended for amounts paid or incurred after December 31, 2009, and before January 1, 2012. Unless retroactively extended again, the federal research credit expired on December 31, 2011.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-12-096831:notes:146]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Purchased components |  | $ | 15.6 |  |  | $ | 7.5 |  |
| Work-in-process |  |  | 0.0 |  |  |  | 0.1 |  |
| Finished goods |  |  | 138.2 |  |  |  | 100.9 |  |
| Inventories |  | $ | 153.8 |  |  | $ | 108.5 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-12-096831:notes:147]
[same as prior period, unchanged from 0001193125-11-330462:notes:138]

[0001193125-12-096831:notes:148]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. The first, second and third quarters of fiscal 2012 and 2011 were each 13-week periods.

[0001193125-12-096831:notes:149]
Basis of Presentation — The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2011 contained in our Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 23, 2011. The results of operations for the three and nine months ended January 27, 2012 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001193125-12-096831:notes:150]
[same as prior period, unchanged from 0001193125-11-330462:notes:141]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-12-096831:notes:151]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Land |  | $ | 206.1 |  |  | $ | 204.7 |  |
| Buildings and building improvements |  |  | 417.3 |  |  |  | 406.2 |  |
| Leasehold improvements |  |  | 92.8 |  |  |  | 79.3 |  |
| Computer, production, engineering and other equipment |  |  | 603.1 |  |  |  | 475.5 |  |
| Software |  |  | 360.0 |  |  |  | 270.4 |  |
| Furniture and fixtures |  |  | 70.5 |  |  |  | 61.5 |  |
| Construction-in-progress |  |  | 107.7 |  |  |  | 91.9 |  |
|  |  |  | 1,857.5 |  |  |  | 1,589.5 |  |
| Accumulated depreciation and amortization |  |  | (775.7 | ) |  |  | (677.9 | ) |
| Property and equipment, net |  | $ | 1,081.8 |  |  | $ | 911.6 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001193125-12-096831:notes:152]
[same as prior period, unchanged from 0001193125-11-330462:notes:144]

[0001193125-12-096831:notes:153]
[same as prior period, unchanged from 0001193125-11-330462:notes:145]

[0001193125-12-096831:notes:154]
[same as prior period, unchanged from 0001193125-11-330462:notes:146]

[0001193125-12-096831:notes:155]
[same as prior period, unchanged from 0001193125-11-330462:notes:147]

[0001193125-12-096831:notes:156]
[same as prior period, unchanged from 0001193125-11-330462:notes:148]

[0001193125-12-096831:notes:157]
[same as prior period, unchanged from 0001193125-11-330462:notes:149]

[0001193125-12-096831:notes:158]
[same as prior period, unchanged from 0001193125-11-330462:notes:150]

[0001193125-12-096831:notes:159]
Our product revenues also include revenues from the sale of non-essential software products. Non-essential software products may operate on our hardware systems, but are not considered essential to the functionality of the hardware. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales continue to be subject to the industry-specific software revenue recognition guidance. For arrangements within the scope of the new guidance, a deliverable constitutes a separate unit of accounting when it has standalone value and there are no customer-negotiated refunds or return rights for the delivered elements.

[0001193125-12-096831:notes:160]
[same as prior period, unchanged from 0001193125-11-330462:notes:152]

[0001193125-12-096831:notes:161]
For our non-software deliverables, we recognize revenue based on the new standards and allocate the arrangement consideration based on the relative selling price of the deliverables. For our non-software deliverables, we use BESP as our selling price. For our software entitlements and support services, we generally use VSOE as our selling price. When we are unable to establish selling prices using VSOE for our software entitlements and support services, we use BESP in our allocation of arrangement consideration.

[0001193125-12-096831:notes:162]
[same as prior period, unchanged from 0001193125-11-330462:notes:154]

[0001193125-12-096831:notes:163]
When VSOE cannot be established, we attempt to establish the selling price of each element based on TPE. TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, we typically are not able to determine TPE for our products or services.

[0001193125-12-096831:notes:164]
When we are unable to establish the selling price of our non-software deliverables using VSOE or TPE, we use our BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. BESP is determined for a product or service by considering multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer classes and distribution channels. In determining BESP, we require that the majority of the selling prices fall within a reasonable pricing range, generally evidenced by a majority of such historical transactions falling within a reasonable range.

[0001193125-12-096831:notes:165]
[same as prior period, unchanged from 0001193125-11-330462:notes:157]

[0001193125-12-096831:notes:166]
For sales of software deliverables after April 30, 2010 and for all transactions entered into prior to the first quarter of fiscal year 2011, we recognize revenue based on software revenue recognition guidance. Under the software revenue recognition guidance, we use the residual method to recognize revenue when a multiple element arrangement includes one or more elements to be delivered at a future date and VSOE of fair value of all undelivered elements exists. In the majority of our contracts, the only element that remains undelivered at the time of delivery of the product is software entitlements and maintenance (SEM) and/or service. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the contract fee is recognized as product revenues. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is SEM, the entire arrangement is recognized ratably over the maintenance period.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-12-096831:notes:167]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Accumulated translation adjustments |  | $ | 4.2 |  |  | $ | 11.6 |  |
| Accumulated unrealized gains on available-for-sale investments |  |  | 1.5 |  |  |  | 3.4 |  |
| Accumulated unrealized gains (losses) on derivatives qualifying as cash flow hedges |  |  | 1.9 |  |  |  | (2.2 | ) |
| Accumulated defined benefit obligation adjustments |  |  | (3.0 | ) |  |  | 0.0 |  |
| Total accumulated other comprehensive income |  | $ | 4.6 |  |  | $ | 12.8 |  |


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001193125-12-096831:notes:168]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| United States |  | $ | 2,391.9 |  |  | $ | 3,037.5 |  |
| International |  |  | 2,536.7 |  |  |  | 2,211.8 |  |
| Total cash, cash equivalents, restricted cash and debt investments |  | $ | 4,928.6 |  |  | $ | 5,249.3 |  |


## us-gaap:ScheduleOfCompensationCostForShareBasedPaymentArrangementsAllocationOfShareBasedCompensationCostsByPlanTableTextBlock

[0001193125-12-096831:notes:169]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Employee stock options |  | $ | 13.8 |  |  | $ | 13.8 |  |  | $ | 43.0 |  |  | $ | 39.7 |  |
| RSUs and restricted stock awards |  |  | 42.1 |  |  |  | 23.9 |  |  |  | 115.4 |  |  |  | 61.7 |  |
| ESPP |  |  | 20.8 |  |  |  | 7.3 |  |  |  | 39.4 |  |  |  | 25.6 |  |
| Total stock-based compensation expense |  | $ | 76.7 |  |  | $ | 45.0 |  |  | $ | 197.8 |  |  | $ | 127.0 |  |


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0001193125-12-096831:notes:170]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Net income |  | $ | 119.6 |  |  | $ | 186.4 |  |  | $ | 424.7 |  |  | $ | 512.5 |  |
| Change in currency translation adjustments |  |  | (4.3 | ) |  |  | 0.4 |  |  |  | (7.4 | ) |  |  | 4.7 |  |
| Change in unrealized gains (losses) on available-for-sale investments |  |  | 3.5 |  |  |  | (6.4 | ) |  |  | (1.9 | ) |  |  | (0.1 | ) |
| Change in unrealized gains (losses) on derivatives qualifying as cash flow hedges |  |  | 1.4 |  |  |  | 2.2 |  |  |  | 4.1 |  |  |  | (0.2 | ) |
| Change in defined benefit obligation adjustments |  |  | (3.0 | ) |  |  | 0.0 |  |  |  | (3.0 | ) |  |  | 0.0 |  |
| Comprehensive income |  | $ | 117.2 |  |  | $ | 182.6 |  |  | $ | 416.5 |  |  | $ | 516.9 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-12-096831:notes:171]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Cost of product revenues |  | $ | 1.6 |  |  | $ | 1.0 |  |  | $ | 4.1 |  |  | $ | 2.7 |  |
| Cost of service revenues |  |  | 5.7 |  |  |  | 3.6 |  |  |  | 13.8 |  |  |  | 10.6 |  |
| Sales and marketing |  |  | 37.5 |  |  |  | 21.3 |  |  |  | 96.5 |  |  |  | 59.2 |  |
| Research and development |  |  | 22.8 |  |  |  | 11.3 |  |  |  | 57.0 |  |  |  | 31.6 |  |
| General and administrative |  |  | 9.1 |  |  |  | 7.8 |  |  |  | 26.4 |  |  |  | 22.9 |  |
| Total stock-based compensation expense |  | $ | 76.7 |  |  | $ | 45.0 |  |  | $ | 197.8 |  |  | $ | 127.0 |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001193125-12-096831:notes:172]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| United States |  | $ | 982.6 |  |  | $ | 840.2 |  |
| International |  |  | 99.2 |  |  |  | 71.4 |  |
| Total property and equipment, net |  | $ | 1,081.8 |  |  | $ | 911.6 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001193125-12-096831:notes:173]
|  |  | January 27,2012 |  |  | April 29,2011 |  |
| Auction rate securities |  | $ | 51.0 |  |  | $ | 65.1 |  |
| Restricted cash |  |  | 2.4 |  |  |  | 2.8 |  |
| Deferred tax assets, net |  |  | 183.9 |  |  |  | 213.2 |  |
| Other assets |  |  | 172.1 |  |  |  | 127.6 |  |
| Other non-current assets |  | $ | 409.4 |  |  | $ | 408.7 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-12-096831:notes:174]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Arrow Electronics, Inc. |  | $ | 238.8 |  |  | $ | 223.4 |  |  | $ | 725.9 |  |  | $ | 619.7 |  |
| Avnet, Inc. |  |  | 179.3 |  |  |  | 151.3 |  |  |  | 537.2 |  |  |  | 461.9 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001193125-12-096831:notes:175]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Americas (United States, Canada and Latin America)* |  | $ | 853.7 |  |  | $ | 702.8 |  |  | $ | 2,564.2 |  |  | $ | 2,094.2 |  |
| Europe, Middle East and Africa |  |  | 525.5 |  |  |  | 457.1 |  |  |  | 1,411.1 |  |  |  | 1,232.5 |  |
| Asia Pacific and Japan |  |  | 186.3 |  |  |  | 129.7 |  |  |  | 555.4 |  |  |  | 367.6 |  |
| Net revenues |  | $ | 1,565.5 |  |  | $ | 1,289.6 |  |  | $ | 4,530.7 |  |  | $ | 3,694.3 |  |

[0001193125-12-096831:notes:176]
| * | Americas revenues consist of Americas commercial and U.S. public sector markets. Sales to customers inside the United States comprised $730.5 million and $631.2 million of Americas net revenues during the three months ended January 27, 2012 and January 28, 2011, respectively, and $2,190.2 million and $1,879.9 million of Americas net revenues during the nine months ended January 27, 2012 and January 28, 2011, respectively. |


## us-gaap:ScheduleOfShareBasedCompensationEmployeeStockPurchasePlanActivityTableTextBlock

[0001193125-12-096831:notes:177]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 27,2012 |  |  | January 28,2011 |  |  | January 27,2012 |  |  | January 28,2011 |  |
| Weighted-average fair value per right granted |  | $ | 12.93 |  |  | $ | 16.54 |  |  | $ | 13.34 |  |  | $ | 15.35 |  |
| Shares issued under the ESPP |  |  | 1.5 |  |  |  | 3.2 |  |  |  | 2.6 |  |  |  | 6.0 |  |
| Weighted-average price per share issued |  | $ | 31.03 |  |  | $ | 11.87 |  |  | $ | 34.53 |  |  | $ | 11.50 |  |


## us-gaap:ScheduleOfShareBasedCompensationRestrictedStockUnitsAwardActivityTableTextBlock

[0001193125-12-096831:notes:178]
|  |  | Number ofShares |  |  | Weighted-AverageGrant DateFair Value |  |
| Outstanding at April 29, 2011 |  |  | 10.1 |  |  | $ | 35.79 |  |
| RSUs granted |  |  | 5.3 |  |  |  | 48.84 |  |
| RSUs vested |  |  | (3.1 | ) |  |  | 29.92 |  |
| RSUs forfeitures and cancellations |  |  | (0.7 | ) |  |  | 39.90 |  |
| Outstanding at January 27, 2012 |  |  | 11.6 |  |  |  | 43.10 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-12-096831:notes:179]
|  |  | Numberof Shares |  |  | Weighted-AverageExercisePrice |  |  | Weighted-AverageRemainingContractual Term(Years) |  |  | AggregateIntrinsic Value |  |
| Outstanding at April 29, 2011 |  |  | 24.5 |  |  | $ | 26.62 |  |  |  |  |  |  |  |  |  |
| Options granted |  |  | 2.1 |  |  |  | 51.36 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (3.0 | ) |  |  | 20.98 |  |  |  |  |  |  |  |  |  |
| Options forfeitures and cancellations |  |  | (0.7 | ) |  |  | 35.96 |  |  |  |  |  |  |  |  |  |
| Outstanding at January 27, 2012 |  |  | 22.9 |  |  |  | 29.28 |  |  |  | 3.91 |  |  | $ | 239.6 |  |
| Options vested and expected to vest as of January 27, 2012 |  |  | 22.1 |  |  |  | 28.86 |  |  |  | 3.86 |  |  |  | 236.7 |  |
| Exercisable at January 27, 2012 |  |  | 15.1 |  |  |  | 25.64 |  |  |  | 3.25 |  |  |  | 188.9 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-096831:notes:180]
[same as prior period, unchanged from 0001193125-11-330462:notes:172]

[0001193125-12-096831:notes:181]
We operate in one reportable industry segment: the design, manufacturing, marketing, and technical support of high-performance networked storage solutions. We conduct business globally, and our sales and support activities are managed on a geographic basis. Our management reviews financial information presented on a consolidated basis, accompanied by disaggregated information it receives from its internal management system about revenues by geographic region, based on the location from which the customer relationship is managed, for purposes of allocating resources and evaluating financial performance. We do not allocate costs of revenues, research and development, sales and marketing, or general and administrative expenses to our geographic regions in this internal management system because management does not review operations or operating results, or make planning decisions, below the consolidated entity level.

[0001193125-12-096831:notes:182]
Summarized revenues by geographic region based on our internal management system and utilized by our Chief Executive Officer, who is considered our Chief Operating Decision Maker, is as follows (in millions):

[0001193125-12-096831:notes:183]
As of January 27, 2012 and April 29, 2011, the majority of our assets, excluding cash, cash equivalents, restricted cash, investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents, restricted cash and debt investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0001193125-12-096831:notes:184]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment, net for geographic areas based on the physical location of the assets (in millions):

[0001193125-12-096831:notes:185]
[same as prior period, unchanged from 0001193125-11-330462:notes:177]

[0001193125-12-096831:notes:186]
International sales to a single foreign country that accounted for ten percent or more of net revenues are as follows:

[0001193125-12-096831:notes:187]
[same as prior period, unchanged from 0001193125-11-330462:notes:179]

[0001193125-12-096831:notes:188]
[same as prior period, unchanged from 0001193125-11-330462:notes:180]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-12-096831:notes:189]
[same as prior period, unchanged from 0001193125-11-330462:notes:181]

[0001193125-12-096831:notes:190]
There have been no significant changes in our significant accounting policies as of and for the nine months ended January 27, 2012, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2011.

[0001193125-12-096831:notes:191]
Accounting Standards Recently Adopted

[0001193125-12-096831:notes:192]
[same as prior period, unchanged from 0001193125-11-330462:notes:183]

[0001193125-12-096831:notes:193]
In May 2011, the FASB issued new guidance for fair value measurements to provide a consistent definition of fair value and ensure that the fair value measurement and disclosure requirements are similar between GAAP and International Financial Reporting Standards. The guidance changes certain fair value measurement principles and enhances the disclosure requirements, particularly for level 3 fair value measurements. The guidance is effective for us prospectively beginning in our fourth quarter of fiscal 2012. There will be no impact to our results of operations, financial position and cash flows as the guidance relates only to financial statement presentation.

[0001193125-12-096831:notes:194]
In June 2011, as modified in December 2011, the FASB issued new guidance on the presentation of comprehensive income. Specifically, the new guidance requires an entity to present components of net income and other comprehensive income in one continuous statement, referred to as the statement of comprehensive income, or in two separate, but consecutive statements. The new guidance eliminates the current option to report other comprehensive income and its components in the statement of stockholders' equity. The specific requirement to present items that are reclassified from accumulated other comprehensive income to net income separately within their respective components of net income and other comprehensive income has been deferred. While the new guidance changes the presentation of comprehensive income, there are no changes to the components that are recognized in net income or other comprehensive income under current accounting guidance. This new guidance is effective for us beginning in our first quarter of fiscal 2013 and is required to be applied retrospectively. There will be no impact to our results of operations, financial position and cash flows as the guidance relates only to financial statement presentation.

[0001193125-12-096831:notes:195]
[same as prior period, unchanged from 0001193125-11-330462:notes:184]

[0001193125-12-096831:notes:196]
In December 2011, the FASB issued new guidance that will require us to disclose information about offsetting arrangements associated with financial and derivative instruments to enable users of our financial statements to understand the effect of those arrangements on our financial position. This guidance is effective for us beginning in our first quarter of fiscal 2014 and is required to be applied retrospectively. We are currently evaluating the impact of adoption on our consolidated financial statements.

[0001193125-12-096831:notes:197]
[same as prior period, unchanged from 0001193125-11-330462:notes:187]

[0001193125-12-096831:notes:198]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserve and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefits; stock-based compensation; loss contingencies; investment impairments; income taxes, and fair value measurements. Actual results could differ materially from those estimates.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-12-096831:notes:199]
[same as prior period, unchanged from 0001193125-11-330462:notes:189]

[0001193125-12-096831:notes:200]
[same as prior period, unchanged from 0001193125-11-330462:notes:190]

[0001193125-12-096831:notes:201]
A summary of the activity under our stock option plans and agreements is as follows (in millions, except for the exercise price and contractual term):

[0001193125-12-096831:notes:202]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our stock on that day for all in-the-money options. As of January 27, 2012, the total unrecognized compensation expense related to stock options was $80.8 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.2 years.

[0001193125-12-096831:notes:203]
Additional information related to our stock options is summarized below (in millions, except per share information):

[0001193125-12-096831:notes:204]
Restricted Stock Units

[0001193125-12-096831:notes:205]
[same as prior period, unchanged from 0001193125-11-330462:notes:194]

[0001193125-12-096831:notes:206]
RSUs are converted into common stock upon vesting. Upon the vesting of RSUs, we primarily use the net share settlement approach, where a portion of the shares are withheld and retired as settlement of statutory employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001193125-12-096831:notes:207]
As of January 27, 2012, the total unrecognized compensation expense related to RSUs was $340.8 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.7 years.

[0001193125-12-096831:notes:208]
Employee Stock Purchase Plan

[0001193125-12-096831:notes:209]
Under the Employee Stock Purchase Plan (ESPP), employees are entitled to purchase shares of our common stock at a 15% discount from the quoted market price of our common stock at certain specified dates over a two-year period. Additional information related to our purchase rights issued under the ESPP is provided below (in millions, except per share information):

[0001193125-12-096831:notes:210]
[same as prior period, unchanged from 0001193125-11-330462:notes:199]

[0001193125-12-096831:notes:211]
Stock-based compensation expense included in the condensed consolidated statements of operations for the three and nine months ended January 27, 2012 and January 28, 2011, respectively, is as follows (in millions):

[0001193125-12-096831:notes:212]
[same as prior period, unchanged from 0001193125-11-330462:notes:201]

[0001193125-12-096831:notes:213]
[same as prior period, unchanged from 0001193125-11-330462:notes:202]

[0001193125-12-096831:notes:214]
[same as prior period, unchanged from 0001193125-11-330462:notes:203]

[0001193125-12-096831:notes:215]
The fair value of each award is estimated on the grant date using the Black-Scholes option pricing model, assuming no expected dividends and the following weighted-average assumptions:

[0001193125-12-096831:notes:216]
[same as prior period, unchanged from 0001193125-11-330462:notes:206]

[0001193125-12-096831:notes:217]
During the nine months ended January 27, 2012, 14.6 million shares of our common stock were repurchased as described below. Since the May 13, 2003 inception of our stock repurchase program through January 27, 2012, we repurchased a total of 119.0 million shares of our common stock at an average price of $29.65 per share, for an aggregate purchase price of $3.5 billion. As of January 27, 2012, our Board of Directors had authorized the repurchase of up to $4.0 billion of our common stock under this stock repurchase program. As of January 27, 2012, the remaining authorized amount for stock repurchases under this program was $0.5 billion with no termination date. The stock repurchase program may be suspended or discontinued at any time.

[0001193125-12-096831:notes:218]
[same as prior period, unchanged from 0001193125-11-330462:notes:208]

[0001193125-12-096831:notes:219]
On July 8, 2011, we entered into a collared accelerated share repurchase agreement (ASR) with Bank of America, N.A, under which we prepaid $200.0 million to purchase shares of our common stock. The aggregate number of shares ultimately purchased was determined based on the volume weighted-average share price of our common stock over a specified period of time. The contract was settled in August 2011. The total number of shares repurchased and retired under this ASR was 4.1 million shares at a price of $48.30.

[0001193125-12-096831:notes:220]
On August 19, 2011, we entered into an ASR with Wells Fargo Bank, National Association, under which we prepaid $400.0 million to purchase shares of our common stock. The aggregate number of shares ultimately purchased was determined based on the volume weighted-average share price of our common stock over a specified period of time. The contract was settled in November 2011. The total number of shares repurchased and retired under this ASR was 10.5 million shares at a price of $38.08.

[0001193125-12-096831:notes:221]
The value of the contracts was allocated to the cost of the shares repurchased and to the value of the ASR forward contracts as follows for the nine months ended January 27, 2012 (in millions):

[0001193125-12-096831:notes:222]
Comprehensive Income

[0001193125-12-096831:notes:223]
[same as prior period, unchanged from 0001193125-11-330462:notes:213]

[0001193125-12-096831:notes:224]
[same as prior period, unchanged from 0001193125-11-330462:notes:214]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-12-096831:notes:225]
7. Balance Sheet Details

[0001193125-12-096831:notes:226]
[same as prior period, unchanged from 0001193125-11-330462:notes:216]

[0001193125-12-096831:notes:227]
[same as prior period, unchanged from 0001193125-11-330462:notes:217]

[0001193125-12-096831:notes:228]
[same as prior period, unchanged from 0001193125-11-330462:notes:218]

[0001193125-12-096831:notes:229]
Property and equipment, net (in millions):

[0001193125-12-096831:notes:230]
Software includes capitalized internal-use software development costs. The net book value of computer software is as follows (in millions):

[0001193125-12-096831:notes:231]
[same as prior period, unchanged from 0001193125-11-330462:notes:221]

[0001193125-12-096831:notes:232]
[same as prior period, unchanged from 0001193125-11-330462:notes:222]
