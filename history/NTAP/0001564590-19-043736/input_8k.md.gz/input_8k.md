# NTAP 8-K — 0001564590-19-043224 filed 2019-11-13

## item codes, every 8-K on or before 2019-11-18

- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2019-11-18

- none on or before 2019-11-18

## item 2.02 — earnings release, exhibit 99.1

[0001564590-19-043224:8k_2_02:1]
EX-99.1
2
ntap-ex991_8.htm
EX-99.1

[0001564590-19-043224:8k_2_02:2]
ntap-ex991_8.htm

[0001564590-19-043224:8k_2_02:3]
Exhibit 99.1

[0001564590-19-043224:8k_2_02:4]
NetApp Reports Second Quarter of Fiscal Year 2020 Results

[0001564590-19-043224:8k_2_02:5]
Expanded Gross Margins, Operating Margins and Earnings Per Share Quarter-over-Quarter

[0001564590-19-043224:8k_2_02:6]
| • | All-flash array annualized net revenue run rate of $2.2 billion increased 29% quarter-over-quarter |  |

[0001564590-19-043224:8k_2_02:7]
| • | NetApp™ cloud data services annualized recurring revenue of approximately $72 million, an increase of 167% year-over-year |  |

[0001564590-19-043224:8k_2_02:8]
| • | Consolidated GAAP gross margin of 67.5%, non-GAAP gross margin of 68.6% |  |

[0001564590-19-043224:8k_2_02:9]
| • | GAAP product gross margin of 55.8%, non-GAAP product gross margin of 57.3% |  |

[0001564590-19-043224:8k_2_02:10]
| • | $611 million returned to shareholders in share repurchases and cash dividends |  |

[0001564590-19-043224:8k_2_02:11]
Sunnyvale, Calif.—November 13, 2019—NetApp (NASDAQ: NTAP) today reported financial results for the second quarter of fiscal year 2020, which ended on October 25, 2019.

[0001564590-19-043224:8k_2_02:12]
“Our Q2 FY20 results reflect the strength of our business model and value of our innovation. We delivered gross margin, operating margin, and EPS all solidly ahead of our guidance ranges. We are delivering real business value to customers’ hybrid multicloud environments increasing our strategic relevance and enabling us to reach new buyers, address new workloads and expand our presence with existing customers,” said George Kurian, chief executive officer. “We continue to be disciplined in our spending and have a strong financial model with growing gross margins and operating margins that enable us to return cash to shareholders and invest in the long-term health of our business.”

[0001564590-19-043224:8k_2_02:13]
Second Quarter of Fiscal Year 2020 Financial Results

[0001564590-19-043224:8k_2_02:14]
| • | Net Revenues: $1.37 billion, compared to $1.52 billion* in the second quarter of fiscal 2019 |  |

[0001564590-19-043224:8k_2_02:15]
| • | Net Income: GAAP net income of $243 million, compared to GAAP net income of $241 million in the second quarter of fiscal 2019; non-GAAP net income1 of $257 million, compared to non-GAAP net income of $280 million in the second quarter of fiscal 2019 |  |

[0001564590-19-043224:8k_2_02:16]
| • | Earnings per Share: GAAP net income per share2 of $1.03 compared to GAAP net income per share of $0.91 in the second quarter of fiscal 2019; non-GAAP net income per share of $1.09, compared to non-GAAP net income per share of $1.06 in the second quarter of fiscal 2019 |  |

[0001564590-19-043224:8k_2_02:17]
| • | Cash, Cash Equivalents and Investments: $3.0 billion at the end of the second quarter of fiscal 2020 |  |

[0001564590-19-043224:8k_2_02:18]
| • | Cash Provided By (Used In) Operations: $(53) million, compared to $165 million in the second quarter of fiscal 2019 |  |

[0001564590-19-043224:8k_2_02:19]
| • | Share Repurchase and Dividend: Returned $611 million to shareholders through share repurchases and cash dividends |  |

[0001564590-19-043224:8k_2_02:20]
*Net revenues in the second quarter of fiscal year 2019 included $20 million from enterprise software license agreements which did not repeat in the second quarter of fiscal year 2020.

[0001564590-19-043224:8k_2_02:21]
Third Quarter of Fiscal Year 2020 Financial Outlook

[0001564590-19-043224:8k_2_02:22]
The Company provided the following financial guidance for the third quarter of fiscal year 2020:

[0001564590-19-043224:8k_2_02:23]
| •Net revenues are expected to be in the range of: | $1.390 billion to $1.540 billion |
|  | GAAP | Non-GAAP |
| •Earnings per share is expected to be in the range of: | $0.96 -$1.04 | $1.14 - $1.22 |

[0001564590-19-043224:8k_2_02:24]
Full Fiscal Year 2020 Financial Outlook
The Company updated the following financial guidance for the full fiscal year 2020:

[0001564590-19-043224:8k_2_02:25]
| •Net revenues are expected to decline approximately 8% year-over-year |
|  | GAAP | Non-GAAP |
| •Consolidated gross margins are expected to be in the range of: | 66% - 67% | 67% - 68% |
| •Operating margins are expected to be in the range of: | 18% - 19% | 21% - 22% |

[0001564590-19-043224:8k_2_02:26]
Dividend

[0001564590-19-043224:8k_2_02:27]
Next cash dividend of $0.48 per share to be paid on January 22, 2020, to shareholders of record as of the close of business on January 3, 2020.

[0001564590-19-043224:8k_2_02:28]
Second Quarter of Fiscal Year 2020 Business Highlights

[0001564590-19-043224:8k_2_02:29]
Driving Innovation in the Industry

[0001564590-19-043224:8k_2_02:30]
| • | NetApp announced a series of innovative offerings at VMworld 2019 that enable customers to have simplified, scalable, high-performance infrastructure for any cloud at their fingertips: NetApp HCI for VDI with VMware Horizon 7, NetApp Kubernetes Service (NKS) and NetApp HCI Implementation Service for VMware Private Cloud. |

[0001564590-19-043224:8k_2_02:31]
| • | NetApp unveiled the NetApp EF600 all-flash array—an end-to-end NVMe midrange array that accelerates access to data and empowers companies to rapidly develop new insights for performance-sensitive workloads. |

[0001564590-19-043224:8k_2_02:32]
| • | With NetApp ONTAP™ System Manager 9.6, users can now launch the new ONTAP System Manager GUI, called Optimized GUI, allowing IT generalists to perform day-to-day storage management tasks with a streamlined, simple-to-use interface. |

[0001564590-19-043224:8k_2_02:33]
| • | NetApp unveiled the new and improved NetApp SnapCenter™ 4.2 dashboard, offering significant value that IT generalists and backup administrators can use for day-to-day reporting. |

[0001564590-19-043224:8k_2_02:34]
| • | NetApp announced the 9.6 release of the virtual appliance for Virtual Storage Console (VSC), NetApp VASA Provider and VMware Storage Replication Adapter (SRA) to support the HTML5-based framework of VMware vSphere Client, providing a more simplified and seamless user experience. |

[0001564590-19-043224:8k_2_02:35]
| • | NetApp presented the new end-to-end NVMe for FlexPod™, which enables customers to handle the scalability requirements of next-generation, mission-critical applications. |

[0001564590-19-043224:8k_2_02:36]
| • | NetApp introduced a new memory-accelerated FlexPod powered by NetApp MAX Data, a futuristic NetApp server-side storage technology that works with Intel Optane memory to accelerate applications. |

[0001564590-19-043224:8k_2_02:37]
Notable Awards and Strengthened Partnerships

[0001564590-19-043224:8k_2_02:38]
| • | NetApp was named #1 in the 2019 Gartner Magic Quadrant for Primary Storage3, further demonstrating that NetApp solutions deliver data-driven business outcomes across core, edge and cloud. |

[0001564590-19-043224:8k_2_02:39]
| • | NetApp announced its collaboration with Equinix and Alibaba Cloud through Indonet, connecting NetApp Private Storage for Cloud (NPS for Cloud), Alibaba Cloud and Platform Equinix. This collaboration allows businesses in Indonesia to get the freedom and flexibility to run their applications or workloads and gain full control of their data across the multicloud platform. |

[0001564590-19-043224:8k_2_02:40]
| • | NetApp announced its sponsorship of NVIDIA’s Artificial Intelligence (AI) Champions program for EMEA NVIDIA Partner Network (NPN) and a Vertical Specialized Award for partners who are able to help customers accelerate their AI projects by using joint ONTAP AI solutions from NetApp and NVIDIA. |

[0001564590-19-043224:8k_2_02:41]
| • | NetApp and Broadcom published a new NetApp Verified Architecture: a best practice reference architecture that illustrates an optimally configured VMware installation on NetApp ONTAP 9.6 and Broadcom technology (Emulex 32GB HBAs and Brocade 32GB FC switches). |

[0001564590-19-043224:8k_2_02:42]
| • | NetApp and Rubrik have partnered to integrate Rubrik’s Cloud Data Management platform with NetApp StorageGRID™ to enable enterprises to simplify data lifecycle management at cloud scale. |

[0001564590-19-043224:8k_2_02:43]
Webcast and Conference Call Information

[0001564590-19-043224:8k_2_02:44]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today.

[0001564590-19-043224:8k_2_02:45]
About NetApp

[0001564590-19-043224:8k_2_02:46]
NetApp is the data authority for hybrid cloud. We provide a full range of hybrid cloud data services that simplify management of applications and data across cloud and on-premises environments to accelerate digital transformation. Together with our partners, we empower global organizations to unleash the full potential of their data to expand customer touchpoints, foster greater innovation, and optimize their operations. For more information, visit www.netapp.com. #DataDriven

[0001564590-19-043224:8k_2_02:47]
###

[0001564590-19-043224:8k_2_02:48]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-19-043224:8k_2_02:49]
Footnotes

[0001564590-19-043224:8k_2_02:50]
1Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, and (h) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year.

[0001564590-19-043224:8k_2_02:51]
NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-19-043224:8k_2_02:52]
2GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0001564590-19-043224:8k_2_02:53]
3NetApp named #1 in Gartner’s 2019 Magic Quadrant for Primary Storage, Gartner Magic Quadrant for Primary Storage By Santhosh Rao, John Monroe, Roger W. Cox, Joseph Unsworth, https://www.gartner.com/doc/reprints?id=1-1OI9TL9M&ct=190917&st=sb

[0001564590-19-043224:8k_2_02:54]
NetApp Usage of Non-GAAP Financial Information

[0001564590-19-043224:8k_2_02:55]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-19-043224:8k_2_02:56]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-19-043224:8k_2_02:57]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-19-043224:8k_2_02:58]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-19-043224:8k_2_02:59]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-19-043224:8k_2_02:60]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-19-043224:8k_2_02:61]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-19-043224:8k_2_02:62]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-19-043224:8k_2_02:63]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-19-043224:8k_2_02:64]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-19-043224:8k_2_02:65]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-19-043224:8k_2_02:66]
H. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a

[0001564590-19-043224:8k_2_02:67]
result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual properties from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-19-043224:8k_2_02:68]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-19-043224:8k_2_02:69]
NETAPP, INC.

[0001564590-19-043224:8k_2_02:70]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-19-043224:8k_2_02:71]
(In millions)

[0001564590-19-043224:8k_2_02:72]
(Unaudited)

[0001564590-19-043224:8k_2_02:73]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 2,987 |  |  | $ | 3,899 |  |
| Accounts receivable |  |  | 780 |  |  |  | 1,216 |  |
| Inventories |  |  | 111 |  |  |  | 131 |  |
| Other current assets |  |  | 313 |  |  |  | 364 |  |
| Total current assets |  |  | 4,191 |  |  |  | 5,610 |  |
| Property and equipment, net |  |  | 746 |  |  |  | 759 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,821 |  |  |  | 1,782 |  |
| Other non-current assets |  |  | 714 |  |  |  | 590 |  |
| Total assets |  | $ | 7,472 |  |  | $ | 8,741 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 382 |  |  | $ | 542 |  |
| Accrued expenses |  |  | 606 |  |  |  | 851 |  |
| Commercial paper notes |  |  | 498 |  |  |  | 249 |  |
| Current portion of long-term debt |  |  | — |  |  |  | 400 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,718 |  |  |  | 1,825 |  |
| Total current liabilities |  |  | 3,204 |  |  |  | 3,867 |  |
| Long-term debt |  |  | 1,145 |  |  |  | 1,144 |  |
| Other long-term liabilities |  |  | 837 |  |  |  | 797 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,750 |  |  |  | 1,843 |  |
| Total liabilities |  |  | 6,936 |  |  |  | 7,651 |  |
| Stockholders' equity |  |  | 536 |  |  |  | 1,090 |  |
| Total liabilities and stockholders' equity |  | $ | 7,472 |  |  | $ | 8,741 |  |

[0001564590-19-043224:8k_2_02:74]
NETAPP, INC.

[0001564590-19-043224:8k_2_02:75]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-19-043224:8k_2_02:76]
(In millions, except per share amounts)

[0001564590-19-043224:8k_2_02:77]
(Unaudited)

[0001564590-19-043224:8k_2_02:78]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 771 |  |  | $ | 913 |  |  | $ | 1,415 |  |  | $ | 1,788 |  |
| Software maintenance |  |  | 254 |  |  |  | 236 |  |  |  | 504 |  |  |  | 465 |  |
| Hardware maintenance and other services |  |  | 346 |  |  |  | 368 |  |  |  | 688 |  |  |  | 738 |  |
| Net revenues |  |  | 1,371 |  |  |  | 1,517 |  |  |  | 2,607 |  |  |  | 2,991 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 341 |  |  |  | 428 |  |  |  | 653 |  |  |  | 826 |  |
| Cost of software maintenance |  |  | 11 |  |  |  | 8 |  |  |  | 21 |  |  |  | 15 |  |
| Cost of hardware maintenance and other services |  |  | 94 |  |  |  | 107 |  |  |  | 192 |  |  |  | 213 |  |
| Total cost of revenues |  |  | 446 |  |  |  | 543 |  |  |  | 866 |  |  |  | 1,054 |  |
| Gross profit |  |  | 925 |  |  |  | 974 |  |  |  | 1,741 |  |  |  | 1,937 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 389 |  |  |  | 408 |  |  |  | 794 |  |  |  | 817 |  |
| Research and development |  |  | 209 |  |  |  | 211 |  |  |  | 424 |  |  |  | 419 |  |
| General and administrative |  |  | 69 |  |  |  | 69 |  |  |  | 140 |  |  |  | 142 |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 21 |  |  |  | 19 |  |
| Gain on sale or derecognition of assets |  |  | (38 | ) |  |  | — |  |  |  | (38 | ) |  |  | — |  |
| Total operating expenses |  |  | 629 |  |  |  | 688 |  |  |  | 1,341 |  |  |  | 1,397 |  |
| Income from operations |  |  | 296 |  |  |  | 286 |  |  |  | 400 |  |  |  | 540 |  |
| Other income, net |  |  | 3 |  |  |  | 7 |  |  |  | 18 |  |  |  | 25 |  |
| Income before income taxes |  |  | 299 |  |  |  | 293 |  |  |  | 418 |  |  |  | 565 |  |
| Provision for income taxes |  |  | 56 |  |  |  | 52 |  |  |  | 72 |  |  |  | 41 |  |
| Net income |  | $ | 243 |  |  | $ | 241 |  |  | $ | 346 |  |  | $ | 524 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.03 |  |  | $ | 0.93 |  |  | $ | 1.46 |  |  | $ | 2.02 |  |
| Diluted |  | $ | 1.03 |  |  | $ | 0.91 |  |  | $ | 1.44 |  |  | $ | 1.96 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 235 |  |  |  | 258 |  |  |  | 237 |  |  |  | 260 |  |
| Diluted |  |  | 236 |  |  |  | 264 |  |  |  | 240 |  |  |  | 267 |  |

[0001564590-19-043224:8k_2_02:79]
NETAPP, INC.

[0001564590-19-043224:8k_2_02:80]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-19-043224:8k_2_02:81]
(In millions)

[0001564590-19-043224:8k_2_02:82]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 243 |  |  | $ | 241 |  |  | $ | 346 |  |  | $ | 524 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 50 |  |  |  | 49 |  |  |  | 99 |  |  |  | 98 |  |
| Stock-based compensation |  |  | 40 |  |  |  | 38 |  |  |  | 82 |  |  |  | 78 |  |
| Deferred income taxes |  |  | (16 | ) |  |  | 1 |  |  |  | (23 | ) |  |  | (25 | ) |
| Gain on sale or derecognition of assets |  |  | (38 | ) |  |  | — |  |  |  | (38 | ) |  |  | — |  |
| Other items, net |  |  | 7 |  |  |  | 3 |  |  |  | 13 |  |  |  | 11 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (237 | ) |  |  | (154 | ) |  |  | 435 |  |  |  | 269 |  |
| Inventories |  |  | 5 |  |  |  | 11 |  |  |  | 20 |  |  |  | 36 |  |
| Accounts payable |  |  | 38 |  |  |  | 50 |  |  |  | (157 | ) |  |  | (127 | ) |
| Accrued expenses |  |  | (38 | ) |  |  | 59 |  |  |  | (315 | ) |  |  | (162 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (43 | ) |  |  | (42 | ) |  |  | (197 | ) |  |  | (129 | ) |
| Long-term taxes payable |  |  | (46 | ) |  |  | (68 | ) |  |  | (49 | ) |  |  | (63 | ) |
| Changes in other operating assets and liabilities, net |  |  | (18 | ) |  |  | (23 | ) |  |  | 41 |  |  |  | (19 | ) |
| Net cash provided by (used in) operating activities |  |  | (53 | ) |  |  | 165 |  |  |  | 257 |  |  |  | 491 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 119 |  |  |  | 241 |  |  |  | 1,146 |  |  |  | 489 |  |
| Purchases of property and equipment |  |  | (36 | ) |  |  | (43 | ) |  |  | (68 | ) |  |  | (107 | ) |
| Proceeds from sale of properties |  |  | 96 |  |  |  | — |  |  |  | 96 |  |  |  | — |  |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | (3 | ) |  |  | (56 | ) |  |  | (3 | ) |
| Other investing activities, net |  |  | (1 | ) |  |  | — |  |  |  | (2 | ) |  |  | 2 |  |
| Net cash provided by investing activities |  |  | 178 |  |  |  | 195 |  |  |  | 1,116 |  |  |  | 381 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 1 |  |  |  | 2 |  |  |  | 55 |  |  |  | 65 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (3 | ) |  |  | (5 | ) |  |  | (74 | ) |  |  | (89 | ) |
| Repurchase of common stock |  |  | (500 | ) |  |  | (561 | ) |  |  | (750 | ) |  |  | (1,061 | ) |
| Proceeds from (repayments of) commercial paper notes, net |  |  | 468 |  |  |  | 50 |  |  |  | 249 |  |  |  | (135 | ) |
| Repayment of long-term debt |  |  | (400 | ) |  |  | — |  |  |  | (400 | ) |  |  | — |  |
| Dividends paid |  |  | (111 | ) |  |  | (102 | ) |  |  | (226 | ) |  |  | (207 | ) |
| Other financing activities, net |  |  | — |  |  |  | (1 | ) |  |  | (2 | ) |  |  | (2 | ) |
| Net cash used in financing activities |  |  | (545 | ) |  |  | (617 | ) |  |  | (1,148 | ) |  |  | (1,429 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (2 | ) |  |  | (11 | ) |  |  | (5 | ) |  |  | (25 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | (422 | ) |  |  | (268 | ) |  |  | 220 |  |  |  | (582 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,973 |  |  |  | 2,633 |  |  |  | 2,331 |  |  |  | 2,947 |  |
| End of period |  | $ | 2,551 |  |  | $ | 2,365 |  |  | $ | 2,551 |  |  | $ | 2,365 |  |

[0001564590-19-043224:8k_2_02:83]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q2 FY'20 |  |  | Q1 FY'20 |  |  | Q2 FY'19 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 771 |  |  | $ | 644 |  |  | $ | 913 |  |
| Strategic* |  | $ | 442 |  |  | $ | 337 |  |  | $ | 485 |  |
| Mature* |  | $ | 329 |  |  | $ | 307 |  |  | $ | 428 |  |
| Software Maintenance |  | $ | 254 |  |  | $ | 250 |  |  | $ | 236 |  |
| Hardware Maintenance and Other Services |  | $ | 346 |  |  | $ | 342 |  |  | $ | 368 |  |
| Hardware Maintenance Support Contracts |  | $ | 286 |  |  | $ | 284 |  |  | $ | 303 |  |
| Professional and Other Services |  | $ | 60 |  |  | $ | 58 |  |  | $ | 65 |  |
| Net Revenues |  | $ | 1,371 |  |  | $ | 1,236 |  |  | $ | 1,517 |  |
| * In Q1 FY’20 we made changes to the products and solutions contained in each of the Strategic and Mature product groupings. Strategic now includes All-flash FAS products, including all related add-on hardware and OS software, private cloud solutions, enterprise software license agreements and other optional add-on software products. Mature now includes Hybrid FAS products, including all related add-on hardware and OS software, OEM products, and branded E-Series. Prior to this change, Hybrid FAS and branded E-Series were included in Strategic, while all add-on hardware and OS software were included in Mature. For comparability, Strategic and Mature revenues presented for the prior year period have been recast based on the revised groupings. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'20 Revenue |  |  | % of Q1 FY'20 Revenue |  |  | % of Q2 FY'19 Revenue |  |
| Americas |  |  | 56 | % |  |  | 51 | % |  |  | 57 | % |
| Americas Commercial |  |  | 42 | % |  |  | 38 | % |  |  | 44 | % |
| U.S. Public Sector |  |  | 14 | % |  |  | 13 | % |  |  | 14 | % |
| EMEA |  |  | 29 | % |  |  | 33 | % |  |  | 28 | % |
| Asia Pacific |  |  | 14 | % |  |  | 16 | % |  |  | 15 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'20 Revenue |  |  | % of Q1 FY'20 Revenue |  |  | % of Q2 FY'19 Revenue |  |
| Direct |  |  | 21 | % |  |  | 19 | % |  |  | 23 | % |
| Indirect |  |  | 79 | % |  |  | 81 | % |  |  | 77 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'20 |  |  | Q1 FY'20 |  |  | Q2 FY'19 |  |
| Non-GAAP Gross Margin |  |  | 68.6 | % |  |  | 67.2 | % |  |  | 64.9 | % |
| Product |  |  | 57.3 | % |  |  | 53.4 | % |  |  | 54.1 | % |
| Software Maintenance |  |  | 95.7 | % |  |  | 96.0 | % |  |  | 96.6 | % |
| Hardware Maintenance and Other Services |  |  | 73.7 | % |  |  | 71.9 | % |  |  | 71.5 | % |

[0001564590-19-043224:8k_2_02:84]
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'20 |  |  | Q1 FY'20 |  |  | Q2 FY'19 |  |
| Non-GAAP Income from Operations |  | $ | 309 |  |  | $ | 178 |  |  | $ | 336 |  |
| % of Net Revenues |  |  | 22.5 | % |  |  | 14.4 | % |  |  | 22.1 | % |
| Non-GAAP Income before Income Taxes |  | $ | 312 |  |  | $ | 193 |  |  | $ | 343 |  |
| Non-GAAP Effective Tax Rate |  |  | 17.6 | % |  |  | 18.7 | % |  |  | 18.5 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'20 |  |  | Q1 FY'20 |  |  | Q2 FY'19 |  |
| Non-GAAP Net Income |  | $ | 257 |  |  | $ | 157 |  |  | $ | 280 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 236 |  |  |  | 243 |  |  |  | 264 |  |
| Non-GAAP Income per Share, Diluted |  | $ | 1.09 |  |  | $ | 0.65 |  |  | $ | 1.06 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'20 |  |  | Q1 FY'20 |  |  | Q2 FY'19 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,468 |  |  | $ | 3,510 |  |  | $ | 3,206 |  |
| DSO (days) |  |  | 52 |  |  |  | 40 |  |  |  | 46 |  |
| DIO (days) |  |  | 23 |  |  |  | 25 |  |  |  | 14 |  |
| DPO (days) |  |  | 78 |  |  |  | 75 |  |  |  | 79 |  |
| CCC (days) |  |  | (4 | ) |  |  | (10 | ) |  |  | (19 | ) |
| Inventory Turns |  |  | 16 |  |  |  | 14 |  |  |  | 25 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'20 |  |  | Q1 FY'20 |  |  | Q2 FY'19 |  |
| Net Cash Provided by (used in) Operating Activities |  | $ | (53 | ) |  | $ | 310 |  |  | $ | 165 |  |
| Purchases of Property and Equipment |  | $ | 36 |  |  | $ | 32 |  |  | $ | 43 |  |
| Free Cash Flow |  | $ | (89 | ) |  | $ | 278 |  |  | $ | 122 |  |
| Free Cash Flow as a % of Net Revenues |  |  | (6.5 | )% |  |  | 22.5 | % |  |  | 8.0 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001564590-19-043224:8k_2_02:85]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY20 |  |  | Q1'FY20 |  |  | Q2'FY19 |  |
| NET INCOME |  | $ | 243 |  |  | $ | 103 |  |  | $ | 241 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 11 |  |  |  | 12 |  |
| Stock-based compensation |  |  | 40 |  |  |  | 42 |  |  |  | 38 |  |
| Restructuring charges |  |  | — |  |  |  | 21 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | (38 | ) |  |  | — |  |  |  | — |  |
| Income tax effects |  |  | 1 |  |  |  | (20 | ) |  |  | (11 | ) |
| NON-GAAP NET INCOME |  | $ | 257 |  |  | $ | 157 |  |  | $ | 280 |  |
| COST OF REVENUES |  | $ | 446 |  |  | $ | 420 |  |  | $ | 543 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (11 | ) |  |  | (11 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (3 | ) |  |  | (2 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 431 |  |  | $ | 406 |  |  | $ | 532 |  |
| COST OF PRODUCT REVENUES |  | $ | 341 |  |  | $ | 312 |  |  | $ | 428 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (11 | ) |  |  | (11 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | — |  |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 329 |  |  | $ | 300 |  |  | $ | 419 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 94 |  |  | $ | 98 |  |  | $ | 107 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (2 | ) |  |  | (2 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 91 |  |  | $ | 96 |  |  | $ | 105 |  |
| GROSS PROFIT |  | $ | 925 |  |  | $ | 816 |  |  | $ | 974 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 11 |  |  |  | 9 |  |
| Stock-based compensation |  |  | 4 |  |  |  | 3 |  |  |  | 2 |  |
| NON-GAAP GROSS PROFIT |  | $ | 940 |  |  | $ | 830 |  |  | $ | 985 |  |

[0001564590-19-043224:8k_2_02:86]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY20 |  |  | Q1'FY20 |  |  | Q2'FY19 |  |
| SALES AND MARKETING EXPENSES |  | $ | 389 |  |  | $ | 405 |  |  | $ | 408 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | — |  |  |  | (3 | ) |
| Stock-based compensation |  |  | (17 | ) |  |  | (18 | ) |  |  | (16 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 372 |  |  | $ | 387 |  |  | $ | 389 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 209 |  |  | $ | 215 |  |  | $ | 211 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (13 | ) |  |  | (15 | ) |  |  | (12 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 196 |  |  | $ | 200 |  |  | $ | 199 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 69 |  |  | $ | 71 |  |  | $ | 69 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (6 | ) |  |  | (6 | ) |  |  | (8 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 63 |  |  | $ | 65 |  |  | $ | 61 |  |
| RESTRUCTURING CHARGES |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | — |  |  |  | (21 | ) |  |  | — |  |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | (38 | ) |  | $ | — |  |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale or derecognition of assets |  |  | 38 |  |  |  | — |  |  |  | — |  |
| NON-GAAP GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 629 |  |  | $ | 712 |  |  | $ | 688 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | — |  |  |  | (3 | ) |
| Stock-based compensation |  |  | (36 | ) |  |  | (39 | ) |  |  | (36 | ) |
| Restructuring charges |  |  | — |  |  |  | (21 | ) |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | 38 |  |  |  | — |  |  |  | — |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 631 |  |  | $ | 652 |  |  | $ | 649 |  |

[0001564590-19-043224:8k_2_02:87]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY20 |  |  | Q1'FY20 |  |  | Q2'FY19 |  |
| INCOME FROM OPERATIONS |  | $ | 296 |  |  | $ | 104 |  |  | $ | 286 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 11 |  |  |  | 12 |  |
| Stock-based compensation |  |  | 40 |  |  |  | 42 |  |  |  | 38 |  |
| Restructuring charges |  |  | — |  |  |  | 21 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | (38 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 309 |  |  | $ | 178 |  |  | $ | 336 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 299 |  |  | $ | 119 |  |  | $ | 293 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 11 |  |  |  | 12 |  |
| Stock-based compensation |  |  | 40 |  |  |  | 42 |  |  |  | 38 |  |
| Restructuring charges |  |  | — |  |  |  | 21 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | (38 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 312 |  |  | $ | 193 |  |  | $ | 343 |  |
| PROVISION FOR INCOME TAXES |  | $ | 56 |  |  | $ | 16 |  |  | $ | 52 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | (1 | ) |  |  | 20 |  |  |  | 11 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 55 |  |  | $ | 36 |  |  | $ | 63 |  |
| NET INCOME PER SHARE |  | $ | 1.03 |  |  | $ | 0.42 |  |  | $ | 0.91 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.05 |  |
| Stock-based compensation |  |  | 0.17 |  |  |  | 0.17 |  |  |  | 0.14 |  |
| Restructuring charges |  |  | — |  |  |  | 0.09 |  |  |  | — |  |
| Gain on sale or derecognition of assets |  |  | (0.16 | ) |  |  | — |  |  |  | — |  |
| Income tax effects |  |  | — |  |  |  | (0.08 | ) |  |  | (0.04 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.09 |  |  | $ | 0.65 |  |  | $ | 1.06 |  |

[0001564590-19-043224:8k_2_02:88]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY20 |  |  | Q1'FY20 |  |  | Q2'FY19 |  |
| Gross margin-GAAP |  |  | 67.5 | % |  |  | 66.0 | % |  |  | 64.2 | % |
| Cost of revenues adjustments |  |  | 1.1 | % |  |  | 1.1 | % |  |  | 0.7 | % |
| Gross margin-Non-GAAP |  |  | 68.6 | % |  |  | 67.2 | % |  |  | 64.9 | % |
| GAAP cost of revenues |  | $ | 446 |  |  | $ | 420 |  |  | $ | 543 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (11 | ) |  |  | (11 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (3 | ) |  |  | (2 | ) |
| Non-GAAP cost of revenues |  | $ | 431 |  |  | $ | 406 |  |  | $ | 532 |  |
| Net revenues |  | $ | 1,371 |  |  | $ | 1,236 |  |  | $ | 1,517 |  |

[0001564590-19-043224:8k_2_02:89]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY20 |  |  | Q1'FY20 |  |  | Q2'FY19 |  |
| Product gross margin-GAAP |  |  | 55.8 | % |  |  | 51.6 | % |  |  | 53.1 | % |
| Cost of product revenues adjustments |  |  | 1.6 | % |  |  | 1.9 | % |  |  | 1.0 | % |
| Product gross margin-Non-GAAP |  |  | 57.3 | % |  |  | 53.4 | % |  |  | 54.1 | % |
| GAAP cost of product revenues |  | $ | 341 |  |  | $ | 312 |  |  | $ | 428 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (11 | ) |  |  | (11 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | — |  |
| Non-GAAP cost of product revenues |  | $ | 329 |  |  | $ | 300 |  |  | $ | 419 |  |
| Product revenues |  | $ | 771 |  |  | $ | 644 |  |  | $ | 913 |  |

[0001564590-19-043224:8k_2_02:90]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY20 |  |  | Q1'FY20 |  |  | Q2'FY19 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 72.8 | % |  |  | 71.3 | % |  |  | 70.9 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.9 | % |  |  | 0.6 | % |  |  | 0.5 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 73.7 | % |  |  | 71.9 | % |  |  | 71.5 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 94 |  |  | $ | 98 |  |  | $ | 107 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (2 | ) |  |  | (2 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 91 |  |  | $ | 96 |  |  | $ | 105 |  |
| Hardware maintenance and other services revenues |  | $ | 346 |  |  | $ | 342 |  |  | $ | 368 |  |

[0001564590-19-043224:8k_2_02:91]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q2'FY20 |  |  | Q1'FY20 |  |  | Q2'FY19 |  |
| GAAP effective tax rate |  |  | 18.7 | % |  |  | 13.4 | % |  |  | 17.7 | % |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | (1.1 | )% |  |  | 5.3 | % |  |  | 0.8 | % |
| Non-GAAP effective tax rate |  |  | 17.6 | % |  |  | 18.7 | % |  |  | 18.5 | % |

[0001564590-19-043224:8k_2_02:92]
| RECONCILIATION OF NET CASH PROVIDED BY (USED IN) OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY20 |  |  | Q1'FY20 |  |  | Q2'FY19 |  |
| Net cash provided by (Used in) operating activities |  | $ | (53 | ) |  | $ | 310 |  |  | $ | 165 |  |
| Purchases of property and equipment |  |  | (36 | ) |  |  | (32 | ) |  |  | (43 | ) |
| Free cash flow |  | $ | (89 | ) |  | $ | 278 |  |  | $ | 122 |  |

[0001564590-19-043224:8k_2_02:93]
Some items may not add or recalculate due to rounding.

[0001564590-19-043224:8k_2_02:94]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| THIRD QUARTER FISCAL 2020 |  |
|  |  | Third Quarter |  |
|  |  | Fiscal 2020 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $1.14 - $1.22 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Third Quarter Fiscal 2020: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.04 | ) |
| Stock-based compensation expense |  |  | (0.17 | ) |
| Income tax effects |  |  | 0.03 |  |
| Total Adjustments |  |  | (0.18 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.96 - $1.04 |  |

[0001564590-19-043224:8k_2_02:95]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| FISCAL 2020 |
| (Unaudited) |
|  |  | Fiscal 2020 |
| Gross Margin - Non-GAAP Guidance |  | 67-68% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | (1)% |
| Gross Margin - GAAP Guidance |  | 66-67% |
|  |  | Fiscal 2020 |
| Operating Margin - Non-GAAP Guidance |  | 21-22% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | (1)% |
| Stock-based compensation expense |  | (3)% |
| Gain on sale or derecognition of assets |  | 1% |
| Operating Margin - GAAP Guidance |  | 18-19% |
| Some items may not add or recalculate due to rounding |  |  |

[0001564590-19-043224:8k_2_02:96]
Press Contact:

[0001564590-19-043224:8k_2_02:97]
Amelia Vierra

[0001564590-19-043224:8k_2_02:98]
NetApp

[0001564590-19-043224:8k_2_02:99]
1 408 822 6403

[0001564590-19-043224:8k_2_02:100]
amelia.vierra@netapp.com

[0001564590-19-043224:8k_2_02:101]
Investor Contact:

[0001564590-19-043224:8k_2_02:102]
Lance Berger

[0001564590-19-043224:8k_2_02:103]
NetApp

[0001564590-19-043224:8k_2_02:104]
1 408 822 6628

[0001564590-19-043224:8k_2_02:105]
lance.berger@netapp.com

## item 5.02 — body, verbatim

[0001564590-19-043224:8k_body:1]
Item 5.02     Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001564590-19-043224:8k_body:2]
(b)

[0001564590-19-043224:8k_body:3]
Retirement of Named Executive Officer

[0001564590-19-043224:8k_body:4]
On November 13, 2019, the Company announced that Henri Richard informed the Company of his intent to retire from his position as Executive Vice President, World Wide Field and Customer Operations at the end of the Company’s fiscal year 2020.
