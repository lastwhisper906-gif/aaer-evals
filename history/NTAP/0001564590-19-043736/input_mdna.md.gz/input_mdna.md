# NTAP MD&A — 0001564590-19-043736


## mdna

[0001564590-19-043736:mdna:1]
[same as prior period, unchanged from 0001564590-19-032574:mdna:1]

[0001564590-19-043736:mdna:2]
[same as prior period, unchanged from 0001564590-19-032574:mdna:16]

[0001564590-19-043736:mdna:3]
[same as prior period, unchanged from 0001564590-19-032574:mdna:2]

[0001564590-19-043736:mdna:4]
[same as prior period, unchanged from 0001564590-19-032574:mdna:3]

[0001564590-19-043736:mdna:5]
[same as prior period, unchanged from 0001564590-19-032574:mdna:4]

[0001564590-19-043736:mdna:6]
[same as prior period, unchanged from 0001564590-19-032574:mdna:5]

[0001564590-19-043736:mdna:7]
[same as prior period, unchanged from 0001564590-19-032574:mdna:6]

[0001564590-19-043736:mdna:8]
[same as prior period, unchanged from 0001564590-19-032574:mdna:7]

[0001564590-19-043736:mdna:9]
[same as prior period, unchanged from 0001564590-19-032574:mdna:8]

[0001564590-19-043736:mdna:10]
[same as prior period, unchanged from 0001564590-19-032574:mdna:9]

[0001564590-19-043736:mdna:11]
[same as prior period, unchanged from 0001564590-19-032574:mdna:10]

[0001564590-19-043736:mdna:12]
[same as prior period, unchanged from 0001564590-19-032574:mdna:11]

[0001564590-19-043736:mdna:13]
[same as prior period, unchanged from 0001564590-19-032574:mdna:12]

[0001564590-19-043736:mdna:14]
[same as prior period, unchanged from 0001564590-19-032574:mdna:13]

[0001564590-19-043736:mdna:15]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. As our product portfolio evolves, market dynamics change, and management continues to assess our largest growth opportunities, we periodically change how we group certain products. Beginning in fiscal 2020, Strategic includes All-flash FAS (AFF) products, including all related add-on hardware and operating system (OS) software, private cloud solutions (including SolidFire, converged and hyper-converged infrastructure products, StorageGrid), enterprise software license agreements (ELAs) and other optional add-on software products. Mature now includes Hybrid FAS products, including all related add-on hardware and OS software, original equipment manufacturers (OEM) products, and branded E-Series. Prior to this grouping change, Hybrid FAS products and branded E-Series were included in Strategic, while all add-on hardware and OS software were included in Mature. For comparability, Strategic and Mature revenues presented for the prior year periods have been recast based on the revised groupings.

[0001564590-19-043736:mdna:16]
[same as prior period, unchanged from 0001564590-19-032574:mdna:15]

[0001564590-19-043736:mdna:17]
[same as prior period, unchanged from 0001564590-19-032574:mdna:32]

[0001564590-19-043736:mdna:18]
[same as prior period, unchanged from 0001564590-19-032574:mdna:17]

[0001564590-19-043736:mdna:19]
[same as prior period, unchanged from 0001564590-19-032574:mdna:18]

[0001564590-19-043736:mdna:20]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Net revenues |  | $ | 1,371 |  |  | $ | 1,517 |  |  | $ | 2,607 |  |  | $ | 2,991 |  |
| Gross profit |  | $ | 925 |  |  | $ | 974 |  |  | $ | 1,741 |  |  | $ | 1,937 |  |
| Gross profit margin percentage |  |  | 67 | % |  |  | 64 | % |  |  | 67 | % |  |  | 65 | % |
| Income from operations |  | $ | 296 |  |  | $ | 286 |  |  | $ | 400 |  |  | $ | 540 |  |
| Income from operations as a percentage of net revenues |  |  | 22 | % |  |  | 19 | % |  |  | 15 | % |  |  | 18 | % |
| Net income |  | $ | 243 |  |  | $ | 241 |  |  | $ | 346 |  |  | $ | 524 |  |
| Diluted net income per share |  | $ | 1.03 |  |  | $ | 0.91 |  |  | $ | 1.44 |  |  | $ | 1.96 |  |
| Operating cash flows |  | $ | (53 | ) |  | $ | 165 |  |  | $ | 257 |  |  | $ | 491 |  |

[0001564590-19-043736:mdna:21]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,468 |  |  | $ | 3,668 |  |
| Cash conversion cycle (days) |  |  | (4 | ) |  |  | 3 |  |

[0001564590-19-043736:mdna:22]
[same as prior period, unchanged from 0001564590-19-032574:mdna:21]

[0001564590-19-043736:mdna:23]
During the first six months of fiscal 2020, we repurchased 14 million shares of our common stock at an average price of $55.06 per share, for an aggregate of $750 million. We also declared aggregate cash dividends of $0.96 per share in that period, for which we paid an aggregate of $226 million.

[0001564590-19-043736:mdna:24]
Senior Notes Maturity

[0001564590-19-043736:mdna:25]
On September 27, 2019, we made an aggregate cash payment of $400 million to extinguish our 2.00% Senior Notes at maturity. This repayment was funded through the sale of short-term commercial paper notes issued under our existing program and cash on hand.

[0001564590-19-043736:mdna:26]
Real Estate Transaction

[0001564590-19-043736:mdna:27]
In September 2017, we entered into an agreement to sell certain land and buildings located in Sunnyvale, California, through two separate and independent closings, the first of which was completed in the third quarter of fiscal 2018. The remaining properties, consisting of land, were classified as assets held for sale, and included as other current assets in our condensed consolidated balance sheets as of April 26, 2019. On August 29, 2019, the second closing occurred and we consummated the sale of the land, with a net book value of $53 million, and received cash proceeds of $96 million, resulting in a gain, net of direct selling costs, of $38 million.

[0001564590-19-043736:mdna:28]
[same as prior period, unchanged from 0001564590-19-032574:mdna:29]

[0001564590-19-043736:mdna:29]
[same as prior period, unchanged from 0001564590-19-032574:mdna:30]

[0001564590-19-043736:mdna:30]
[same as prior period, unchanged from 0001564590-19-032574:mdna:31]

[0001564590-19-043736:mdna:31]
[same as prior period, unchanged from 0001564590-19-032574:mdna:33]

[0001564590-19-043736:mdna:32]
See Note 1 – Description of Business and Significant Accounting policies for the impact to our financial statements of the adoption of the accounting standard Leases (ASC 842) in the first quarter of fiscal 2020.

[0001564590-19-043736:mdna:33]
[same as prior period, unchanged from 0001564590-19-032574:mdna:45]

[0001564590-19-043736:mdna:34]
[same as prior period, unchanged from 0001564590-19-032574:mdna:34]

[0001564590-19-043736:mdna:35]
[same as prior period, unchanged from 0001564590-19-032574:mdna:35]

[0001564590-19-043736:mdna:36]
[same as prior period, unchanged from 0001564590-19-032574:mdna:36]

[0001564590-19-043736:mdna:37]
[same as prior period, unchanged from 0001564590-19-032574:mdna:37]

[0001564590-19-043736:mdna:38]
|  |  | Three Months Ended |  |  | Six Months Ended |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 56 |  | % |  | 60 |  | % |  | 54 |  | % |  | 60 |  | % |
| Software maintenance |  |  | 19 |  |  |  | 16 |  |  |  | 19 |  |  |  | 16 |  |  |
| Hardware maintenance and other services |  |  | 25 |  |  |  | 24 |  |  |  | 26 |  |  |  | 25 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 25 |  |  |  | 28 |  |  |  | 25 |  |  |  | 28 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 7 |  |  |  | 7 |  |  |  | 7 |  |  |  | 7 |  |  |
| Gross profit |  |  | 67 |  |  |  | 64 |  |  |  | 67 |  |  |  | 65 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 28 |  |  |  | 27 |  |  |  | 30 |  |  |  | 27 |  |  |
| Research and development |  |  | 15 |  |  |  | 14 |  |  |  | 16 |  |  |  | 14 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |
| Gain on sale or derecognition of assets |  |  | (3 | ) |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |
| Total operating expenses |  |  | 46 |  |  |  | 45 |  |  |  | 51 |  |  |  | 47 |  |  |
| Income from operations |  |  | 22 |  |  |  | 19 |  |  |  | 15 |  |  |  | 18 |  |  |
| Other income, net |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |
| Income before income taxes |  |  | 22 |  |  |  | 19 |  |  |  | 16 |  |  |  | 19 |  |  |
| Provision for income taxes |  |  | 4 |  |  |  | 3 |  |  |  | 3 |  |  |  | 1 |  |  |
| Net income |  |  | 18 |  | % |  | 16 |  | % |  | 13 |  | % |  | 18 |  | % |

[0001564590-19-043736:mdna:39]
[same as prior period, unchanged from 0001564590-19-032574:mdna:39]

[0001564590-19-043736:mdna:40]
[same as prior period, unchanged from 0001564590-19-032574:mdna:40]

[0001564590-19-043736:mdna:41]
[same as prior period, unchanged from 0001564590-19-032574:mdna:41]

[0001564590-19-043736:mdna:42]
Net revenues for the second quarter and first six months of fiscal 2020 were $1,371 million and $2,607 million, respectively, reflecting a decrease of $146 million, or 10%, and $384 million, or 13%, respectively, compared to the corresponding periods of the prior year, primarily reflecting lower product revenues, and to a lesser extent, the unfavorable impact of foreign exchange rate fluctuations in the quarter. Hardware maintenance and other services revenues also decreased compared to the corresponding periods of the prior year, offset by an increase in software maintenance revenues.

[0001564590-19-043736:mdna:43]
Gross profit as a percentage of net revenues for the second quarter and first six months of fiscal 2020 increased by three and a half percentage points and two percentage points, respectively, compared to the corresponding periods in fiscal 2019, primarily reflecting higher margins on product revenues and hardware maintenance and other services revenues. Gross profit margins on product revenues increased by two and a half percentage points in the second quarter of fiscal 2020 and were relatively flat in the first six months of fiscal 2020, compared to the corresponding periods of fiscal 2019. Gross profit margins in both the second quarter and first six months of fiscal 2020 benefitted from a higher mix of All Flash FAS (AFF) product sales and cost reductions. These benefits were partially offset in the second quarter of fiscal 2020, and fully offset in the first six months of fiscal 2020, by high-margin revenue recognized related to the software license components of several ELAs in the corresponding periods of fiscal 2019, which did not repeat in fiscal 2020.

[0001564590-19-043736:mdna:44]
30

[0001564590-19-043736:mdna:45]
Sales and marketing, research and development, and general and administrative expenses for the second quarter and the first six months of fiscal 2020 totaled $667 million, or 49% of net revenues and $1,358 million, or 52% of revenues, respectively, representing an increase of three and a half percentage points and six percentage points, respectively, when compared to the corresponding periods of fiscal 2019, primarily due to lower net revenues in the current year periods.

[0001564590-19-043736:mdna:46]
[same as prior period, unchanged from 0001564590-19-032574:mdna:46]

[0001564590-19-043736:mdna:47]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |
| Net revenues |  | $ | 1,371 |  |  | $ | 1,517 |  |  |  | (10 | )% |  | $ | 2,607 |  |  | $ | 2,991 |  |  |  | (13 | )% |

[0001564590-19-043736:mdna:48]
The decrease in net revenues for the second quarter and first six months of fiscal 2020 compared to the corresponding periods of fiscal 2019 was primarily due to a decrease in product revenues of $142 million and $373 million, respectively. Product revenues as a percentage of net revenues decreased by four percentage points and five and a half percentage points in the second quarter and first six months of fiscal 2020, respectively, compared to the corresponding periods of fiscal 2019.

[0001564590-19-043736:mdna:49]
[same as prior period, unchanged from 0001564590-19-032574:mdna:49]

[0001564590-19-043736:mdna:50]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 24 | % |  |  | 24 | % |  |  | 23 | % |
| Tech Data Corporation |  |  | 21 | % |  |  | 21 | % |  |  | 21 | % |  |  | 19 | % |

[0001564590-19-043736:mdna:51]
[same as prior period, unchanged from 0001564590-19-032574:mdna:51]

[0001564590-19-043736:mdna:52]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |
| Product revenues |  | $ | 771 |  |  | $ | 913 |  |  |  | (16 | )% |  | $ | 1,415 |  |  | $ | 1,788 |  |  |  | (21 | )% |

[0001564590-19-043736:mdna:53]
[same as prior period, unchanged from 0001564590-19-032574:mdna:53]

[0001564590-19-043736:mdna:54]
Under the revised Strategic and Mature product groupings, as described in the Overview section above, product revenues from strategic solutions represented 57% and 55% of product revenues in the second quarter and first six months of fiscal 2020, respectively, compared to 53% and 54% in the corresponding periods of the prior year, respectively. Product revenues from mature solutions represented 43% and 45% of product revenues in the second quarter and first six months of fiscal 2020, respectively, compared to 47% and 46% in the corresponding periods of the prior year, respectively.

[0001564590-19-043736:mdna:55]
Product revenues declined in the second quarter and first six months of fiscal 2020 compared to the corresponding periods of the prior year primarily due less favorable macroeconomic conditions, lower enterprise IT spending and, in the first quarter of fiscal 2020, go-to-market execution issues experienced with some of our largest global customer accounts.

[0001564590-19-043736:mdna:56]
Total product revenues from strategic solutions totaled $442 million in the second quarter of fiscal 2020 reflecting a 9% decrease from $485 million in the second quarter of fiscal 2019. Total product revenues from strategic solutions totaled $779 million in the first six months of fiscal 2020 reflecting a 19% decrease from $960 million in the first six months of fiscal 2019. These decreases were primarily due to a substantial amount of revenue recognized in the prior year periods related to the software license components of several ELAs which did not repeat, a decrease in add-on optional software sales in the current year periods and, for the six month period, decreased sales of AFF products. These decreases were partially offset by an increase in revenues from private cloud solutions in both fiscal 2020 periods and, for the second quarter, increased sales of AFF products.

[0001564590-19-043736:mdna:57]
Total product revenue from mature solutions totaled $329 million in the second quarter of fiscal 2020 reflecting a 23% decrease from $428 million in the second quarter of fiscal 2019. Total product revenue from mature solutions totaled $636 million in the first six months of fiscal 2020 reflecting a 23% decrease from $828 million in the first six months of fiscal 2019. These decreases were primarily due to decreased sales of FAS Hybrid and OEM products, as well as add-on storage, in the current year periods.

[0001564590-19-043736:mdna:58]
31

[0001564590-19-043736:mdna:59]
[same as prior period, unchanged from 0001564590-19-032574:mdna:58]

[0001564590-19-043736:mdna:60]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 254 |  |  | $ | 236 |  |  |  | 8 | % |  | $ | 504 |  |  | $ | 465 |  |  |  | 8 | % |

[0001564590-19-043736:mdna:61]
[same as prior period, unchanged from 0001564590-19-032574:mdna:60]

[0001564590-19-043736:mdna:62]
[same as prior period, unchanged from 0001564590-19-032574:mdna:61]

[0001564590-19-043736:mdna:63]
[same as prior period, unchanged from 0001564590-19-032574:mdna:62]

[0001564590-19-043736:mdna:64]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 346 |  |  | $ | 368 |  |  |  | (6 | )% |  | $ | 688 |  |  | $ | 738 |  |  |  | (7 | )% |

[0001564590-19-043736:mdna:65]
[same as prior period, unchanged from 0001564590-19-032574:mdna:64]

[0001564590-19-043736:mdna:66]
Hardware maintenance contract revenues decreased year over year, at $286 million and $570 million, respectively, for the second quarter and first six months of fiscal 2020, compared to $303 million and $606 million, respectively, for the corresponding periods of the prior year. The decreases were primarily attributable to a decline in average selling price on contracts executed recently.

[0001564590-19-043736:mdna:67]
Professional services and educational and training services revenues were $60 million and $118 million, respectively, for the second quarter and first six months of fiscal 2020, compared to $65 million and $132 million, respectively, for the corresponding periods of the prior year.

[0001564590-19-043736:mdna:68]
[same as prior period, unchanged from 0001564590-19-032574:mdna:67]

[0001564590-19-043736:mdna:69]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| United States, Canada and Latin America (Americas) |  |  | 56 | % |  |  | 57 | % |  |  | 54 | % |  |  | 57 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 29 | % |  |  | 28 | % |  |  | 31 | % |  |  | 29 | % |
| Asia Pacific (APAC) |  |  | 14 | % |  |  | 15 | % |  |  | 15 | % |  |  | 14 | % |

[0001564590-19-043736:mdna:70]
[same as prior period, unchanged from 0001564590-19-032574:mdna:69]

[0001564590-19-043736:mdna:71]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. During the first six months of fiscal 2020, Americas revenues were negatively impacted by general macroeconomic conditions in the region and, in the first quarter of fiscal 2020, go-to-market execution issues with some of our largest customer accounts, which was reflected in the geographic distribution of revenues as a percentage of net revenues in the second quarter and first six months of fiscal 2020 compared to the corresponding periods of fiscal 2019.

[0001564590-19-043736:mdna:72]
[same as prior period, unchanged from 0001564590-19-032574:mdna:71]

[0001564590-19-043736:mdna:73]
[same as prior period, unchanged from 0001564590-19-032574:mdna:72]

[0001564590-19-043736:mdna:74]
[same as prior period, unchanged from 0001564590-19-032574:mdna:73]

[0001564590-19-043736:mdna:75]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |
| Cost of product revenues |  | $ | 341 |  |  | $ | 428 |  |  |  | (20 | )% |  | $ | 653 |  |  | $ | 826 |  |  |  | (21 | )% |

[0001564590-19-043736:mdna:76]
[same as prior period, unchanged from 0001564590-19-032574:mdna:75]

[0001564590-19-043736:mdna:77]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2020 to Fiscal 2019 |  |  | Fiscal 2020 to Fiscal 2019 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | (23 | ) |  |  | (23 | ) |
| Excess and obsolete inventory |  |  | 2 |  |  |  | 1 |  |
| Other |  |  | 1 |  |  |  | 1 |  |
| Total change |  |  | (20 | ) |  |  | (21 | ) |

[0001564590-19-043736:mdna:78]
Cost of product revenues represented 44% and 46% of product revenues for the second quarter and first six months of fiscal 2020, respectively, compared to 47% and 46% for the corresponding periods of fiscal 2019. Materials costs represented 86% and 84% of product costs for the second quarter and first six months of fiscal 2020, respectively, compared to 91% and 89% in the corresponding periods of fiscal 2019.

[0001564590-19-043736:mdna:79]
Materials costs decreased $98 million and $190 million in the second quarter and first six months of fiscal 2020, respectively, compared to the corresponding periods of the prior year, primarily due to a decline in product revenue and, to a lesser extent, a decline in the price of certain product components. The average unit materials costs of both AFF and FAS Hybrid systems decreased in the second quarter and first six months of fiscal 2020 compared to the corresponding periods of fiscal 2019.

[0001564590-19-043736:mdna:80]
Margins on revenue recognized for strategic solutions increased during the second quarter and first six months of fiscal 2020 compared to the corresponding periods of fiscal 2019, while margins for mature solutions were relatively flat.

[0001564590-19-043736:mdna:81]
[same as prior period, unchanged from 0001564590-19-032574:mdna:80]

[0001564590-19-043736:mdna:82]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 11 |  |  | $ | 8 |  |  |  | 38 | % |  | $ | 21 |  |  | $ | 15 |  |  |  | 40 | % |

[0001564590-19-043736:mdna:83]
Cost of software maintenance revenues in dollars were relatively flat in the second quarter and first six months of fiscal 2020 compared to the corresponding periods of fiscal 2019 and represented 4% of software maintenance revenues for second quarter and first six months of fiscal 2020, and 3% for the corresponding periods of fiscal 2019.

[0001564590-19-043736:mdna:84]
[same as prior period, unchanged from 0001564590-19-032574:mdna:83]

[0001564590-19-043736:mdna:85]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 94 |  |  | $ | 107 |  |  |  | (12 | )% |  | $ | 192 |  |  | $ | 213 |  |  |  | (10 | )% |

[0001564590-19-043736:mdna:86]
Cost of hardware maintenance and other services revenues decreased by $13 million, or 12%, and $21 million, or 10%, respectively, for the second quarter and first six months of fiscal 2020 compared to the corresponding periods of fiscal 2019, in line with the decreases in hardware maintenance and other services revenues, and also as a result of cost savings initiatives. Costs represented 27% of hardware maintenance and other services revenues in the second quarter, and 28% in the first six months of fiscal 2020, compared to 29% in the second quarter and first six months of fiscal 2019.

[0001564590-19-043736:mdna:87]
[same as prior period, unchanged from 0001564590-19-032574:mdna:86]

[0001564590-19-043736:mdna:88]
[same as prior period, unchanged from 0001564590-19-032574:mdna:87]

[0001564590-19-043736:mdna:89]
[same as prior period, unchanged from 0001564590-19-032574:mdna:88]

[0001564590-19-043736:mdna:90]
Total compensation costs included in operating expenses decreased by $9 million and $13 million, respectively, or 2%, in the second quarter and first six months of fiscal 2020, compared to the corresponding periods of the prior year primarily due to lower incentive compensation expense and, to a lesser extent, the favorable impact of foreign exchange rate fluctuations, partially offset by higher salaries expense, reflecting a 2% increase in average headcount in the fiscal 2020 periods.

[0001564590-19-043736:mdna:91]
[same as prior period, unchanged from 0001564590-19-032574:mdna:90]

[0001564590-19-043736:mdna:92]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 389 |  |  | $ | 408 |  |  |  | (5 | )% |  | $ | 794 |  |  | $ | 817 |  |  |  | (3 | )% |

[0001564590-19-043736:mdna:93]
[same as prior period, unchanged from 0001564590-19-032574:mdna:92]

[0001564590-19-043736:mdna:94]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2020 to Fiscal 2019 |  |  | Fiscal 2020 to Fiscal 2019 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (1 | ) |  |  | (1 | ) |
| Advertising and marketing promotional expense |  |  | (3 | ) |  |  | (2 | ) |
| Other |  |  | (1 | ) |  |  | — |  |
| Total change |  |  | (5 | ) |  |  | (3 | ) |

[0001564590-19-043736:mdna:95]
Compensation costs decreased slightly for the second quarter and first six months of fiscal 2020 compared to the corresponding periods of the prior year, reflecting a 2% decrease in average headcount in each of the current year periods. Advertising and marketing promotional expense decreased in the second quarter and first six months of fiscal 2020, primarily due to certain annual marketing events being held earlier in the prior year. Sales and marketing expenses in the second quarter and first six months of fiscal 2020 also benefitted slightly from foreign exchange rate fluctuations.

[0001564590-19-043736:mdna:96]
[same as prior period, unchanged from 0001564590-19-032574:mdna:94]

[0001564590-19-043736:mdna:97]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |
| Research and development expenses |  | $ | 209 |  |  | $ | 211 |  |  |  | (1 | )% |  | $ | 424 |  |  | $ | 419 |  |  |  | 1 | % |

[0001564590-19-043736:mdna:98]
[same as prior period, unchanged from 0001564590-19-032574:mdna:96]

[0001564590-19-043736:mdna:99]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2020 to Fiscal 2019 |  |  | Fiscal 2020 to Fiscal 2019 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 1 |  |  |  | 2 |  |
| Development projects and outside services |  |  | (1 | ) |  |  | (1 | ) |
| Other |  |  | (1 | ) |  |  | — |  |
| Total change |  |  | (1 | ) |  |  | 1 |  |

[0001564590-19-043736:mdna:100]
The increase in compensation costs for the second quarter and first six months of fiscal 2020 compared to the corresponding periods in the prior year was attributable to an increase in average headcount of 9% and 8%, respectively, resulting in higher salaries, benefits and stock-based compensation expense, partially offset by lower incentive compensation expense. The increase in headcount reflects our investment in additional engineering resources to support the expansion and enhancement of products and solutions targeted at our most important customer and market opportunities. Development projects and outside services expense for the second quarter and first six months of fiscal 2020 decreased slightly as a result of lower spending on materials and services associated with engineering activities to develop new and enhanced products, due to the timing of new product introductions.

[0001564590-19-043736:mdna:101]
[same as prior period, unchanged from 0001564590-19-032574:mdna:99]

[0001564590-19-043736:mdna:102]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |
| General and administrative expenses |  | $ | 69 |  |  | $ | 69 |  |  |  | — | % |  | $ | 140 |  |  | $ | 142 |  |  |  | (1 | )% |

[0001564590-19-043736:mdna:103]
[same as prior period, unchanged from 0001564590-19-032574:mdna:101]

[0001564590-19-043736:mdna:104]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2020 to Fiscal 2019 |  |  | Fiscal 2020 to Fiscal 2019 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (10 | ) |  |  | (9 | ) |
| Professional and legal fees and outside services |  |  | 13 |  |  |  | 11 |  |
| Facilities and IT support costs |  |  | (6 | ) |  |  | (5 | ) |
| Other |  |  | 3 |  |  |  | 2 |  |
| Total change |  |  | — |  |  |  | (1 | ) |

[0001564590-19-043736:mdna:105]
While average headcount increased in the second quarter and first six months of fiscal 2020 compared to the corresponding periods of the prior year, compensation costs decreased because a greater percentage of employees were located in lower cost geographies. The increases in professional and legal fees and outside services expense in the second quarter and first six months of fiscal 2020 were primarily due to the higher spending levels on business transformation projects, while the decreases in facilities and IT support costs  were primarily due to lower spending levels on IT projects.

[0001564590-19-043736:mdna:106]
[same as prior period, unchanged from 0001564590-19-032574:mdna:104]

[0001564590-19-043736:mdna:107]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |
| Restructuring charges |  | $ | — |  |  | $ | — |  |  | NM |  | $ | 21 |  |  | $ | 19 |  |  | NM |

[0001564590-19-043736:mdna:108]
NM – Not Meaningful

[0001564590-19-043736:mdna:109]
In the first quarter of fiscal 2020, we announced a restructuring plan (the May 2019 Plan) to reduce costs and redirect resources to our highest return activities, which included a reduction in our global workforce of approximately 2%. Charges related to the plan consisted primarily of employee severance-related costs. Substantially all activities under the plan have been completed. See Note 12 – Restructuring Charges of the Notes to Condensed Consolidated Financial Statements for more details.

[0001564590-19-043736:mdna:110]
Gain on sale or derecognition of assets (in millions, except percentages):

[0001564590-19-043736:mdna:111]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |
| Gain on sale or derecognition of assets |  | $ | (38 | ) |  | $ | — |  |  | NM |  | $ | (38 | ) |  | $ | — |  |  | NM |

[0001564590-19-043736:mdna:112]
NM – Not Meaningful

[0001564590-19-043736:mdna:113]
In September 2017, we entered into an agreement to sell certain land and buildings located in Sunnyvale, California, through two separate and independent closings, the first of which was completed in the third quarter of fiscal 2018. The remaining properties, consisting of land, were classified as assets held for sale, and included as other current assets in our condensed consolidated balance sheet as of April 26, 2019. On August 29, 2019, the second closing occurred and we consummated the sale of the land, with a net book value of $53 million, and received cash proceeds of $96 million. resulting in a gain, net of direct selling costs, of $38 million.

[0001564590-19-043736:mdna:114]
[same as prior period, unchanged from 0001564590-19-032574:mdna:107]

[0001564590-19-043736:mdna:115]
[same as prior period, unchanged from 0001564590-19-032574:mdna:109]

[0001564590-19-043736:mdna:116]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |
| Interest income |  | $ | 12 |  |  | $ | 21 |  |  |  | (43 | )% |  | $ | 31 |  |  | $ | 46 |  |  |  | (33 | )% |
| Interest expense |  |  | (12 | ) |  |  | (14 | ) |  |  | (14 | )% |  |  | (27 | ) |  |  | (28 | ) |  |  | (4 | )% |
| Other income, net |  |  | 3 |  |  |  | — |  |  | NM |  |  |  | 14 |  |  |  | 7 |  |  |  | 100 | % |
| Total |  | $ | 3 |  |  | $ | 7 |  |  |  | (57 | )% |  | $ | 18 |  |  | $ | 25 |  |  |  | (28 | )% |

[0001564590-19-043736:mdna:117]
NM – Not Meaningful

[0001564590-19-043736:mdna:118]
Interest income decreased in the second quarter and first six months of fiscal 2020 compared to the corresponding periods of the prior year due to a reduction in size of our investment portfolio as a result of our sale of approximately $1.0 billion of available-for-sale debt securities in the first quarter of fiscal 2020. Other income, net increased in the first six months of fiscal 2020 compared to the corresponding period of fiscal 2019 as a result of the $14 million gain we realized from the sale of these securities, partially offset by differences in foreign exchange gains and losses. Interest expense remained relatively flat in the second quarter and first six months of fiscal 2020 compared to the corresponding periods of the prior year, as we repaid our maturing Senior Notes but increased our average outstanding commercial paper balance.

[0001564590-19-043736:mdna:119]
Provision for Income Taxes (in millions, except percentages):

[0001564590-19-043736:mdna:120]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | % Change |  |
| Provision for income taxes |  | $ | 56 |  |  | $ | 52 |  |  |  | 8 | % |  | $ | 72 |  |  | $ | 41 |  |  |  | 76 | % |

[0001564590-19-043736:mdna:121]
Our effective tax rate for the second quarter of fiscal 2020 was 18.7% compared to 17.7% for the second quarter of fiscal 2019. Our effective tax rate for the first six months of fiscal 2020 was 17.2% compared to 7.3% for the corresponding period of fiscal 2019. Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rate increased for the second quarter of fiscal 2020 compared to the corresponding period of the prior year primarily due to the discrete tax charge on the sale of land in Sunnyvale, California and the differences in discrete benefits for stock-based compensation. Our effective tax rate increased for the first six months of fiscal 2020 compared to the corresponding period in the prior year primarily due to the discrete tax benefits related to the adoption of the new revenue standard in fiscal 2019, and the same items that impacted the second quarter effective tax rate.

[0001564590-19-043736:mdna:122]
[same as prior period, unchanged from 0001564590-19-032574:mdna:115]

[0001564590-19-043736:mdna:123]
During fiscal 2019, we adopted the new revenue accounting standard and, during the six months ended October 26, 2018, we recognized a $34 million discrete tax benefit for adjustments to certain intercompany transactions resulting from the retrospective application of the new revenue accounting standard.

[0001564590-19-043736:mdna:124]
As of October 25, 2019, we had $294 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $246 million would affect our provision for income taxes if recognized, and $251 million has been recorded in other long-term liabilities.

[0001564590-19-043736:mdna:125]
[same as prior period, unchanged from 0001564590-19-032574:mdna:118]

[0001564590-19-043736:mdna:126]
[same as prior period, unchanged from 0001564590-19-032574:mdna:119]

[0001564590-19-043736:mdna:127]
| (In millions, except percentages) |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Cash, cash equivalents and short-term investments |  | $ | 2,987 |  |  | $ | 3,899 |  |
| Principal amount of debt |  | $ | 1,649 |  |  | $ | 1,799 |  |

[0001564590-19-043736:mdna:128]
[same as prior period, unchanged from 0001564590-19-032574:mdna:121]

[0001564590-19-043736:mdna:129]
|  |  | Six Months Ended |  |
| (In millions) |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Net cash provided by operating activities |  | $ | 257 |  |  | $ | 491 |  |
| Net cash provided by investing activities |  |  | 1,116 |  |  |  | 381 |  |
| Net cash used in financing activities |  |  | (1,148 | ) |  |  | (1,429 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (5 | ) |  |  | (25 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 220 |  |  | $ | (582 | ) |

[0001564590-19-043736:mdna:130]
[same as prior period, unchanged from 0001564590-19-032574:mdna:123]

[0001564590-19-043736:mdna:131]
As of October 25, 2019, our cash, cash equivalents and short-term investments were $3.0 billion, a decrease of $0.9 billion from April 26, 2019. The decrease was primarily due to $750 million paid for the repurchase of our common stock, $400 million used for the repayment of our Senior Notes due September 2019, $226 million used for the payment of dividends, and $68 million in purchases of property and equipment, partially offset by $249 million in proceeds from the issuance of commercial paper notes, net, $96 million in proceeds from the sale of properties, and $257 million of cash provided by operating activities. Working capital decreased by $0.7 billion to $1.0 billion as of October 25, 2019 compared to April 26, 2019 primarily due to the decreases in cash, cash equivalents and short-term investments discussed above.

[0001564590-19-043736:mdna:132]
[same as prior period, unchanged from 0001564590-19-032574:mdna:125]

[0001564590-19-043736:mdna:133]
[same as prior period, unchanged from 0001564590-19-032574:mdna:126]

[0001564590-19-043736:mdna:134]
|  |  | Three Months Ended |  |
| (In days) |  | October 25, 2019 |  |  | April 26, 2019 |  |  | October 26, 2018 |  |
| Days sales outstanding (1) |  |  | 52 |  |  |  | 70 |  |  |  | 46 |  |
| Days inventory outstanding (2) |  |  | 23 |  |  |  | 21 |  |  |  | 14 |  |
| Days payables outstanding (3) |  |  | (78 | ) |  |  | (87 | ) |  |  | (79 | ) |
| Cash conversion cycle (4) |  |  | (4 | ) |  |  | 3 |  |  |  | (19 | ) |

[0001564590-19-043736:mdna:135]
[same as prior period, unchanged from 0001564590-19-032574:mdna:128]

[0001564590-19-043736:mdna:136]
| (1) | Days sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on ending accounts receivable and net revenue for each period. DSO is calculated by dividing accounts receivable by average net revenue per day for the current quarter (91 days for each of the quarters presented above). DSO for the second quarter of fiscal 2020 increased compared to the corresponding period of fiscal 2019 due to less favorable shipping linearity and the timing of shipments to certain large customers, while it decreased compared to the fourth quarter of fiscal 2019 due to lower seasonal invoicing levels and more favorable shipping linearity. |

[0001564590-19-043736:mdna:137]
| (2) | Days inventory outstanding, referred to as DIO, measures the average number of days from procurement to sale of our products. DIO is based on ending inventory and cost of revenues for each period. DIO is calculated by dividing ending inventory by average cost of revenues per day for the current quarter. DIO for the second quarter of fiscal 2020 increased compared to the corresponding period of fiscal 2019 as a result of higher levels of on hand inventory and lower cost of goods sold in the current year period, while it was relatively flat compared to the fourth quarter of fiscal 2019. |

[0001564590-19-043736:mdna:138]
| (3) | Days payables outstanding, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and cost of revenues for each period. DPO is calculated by dividing accounts payable by average cost of revenues per day for the current quarter. DPO for the second quarter of fiscal 2020 was relatively consistent with the corresponding period of fiscal 2019, while it decreased compared to the fourth quarter of 2019, primarily due to the timing of purchases from contract manufacturers. |

[0001564590-19-043736:mdna:139]
[same as prior period, unchanged from 0001564590-19-032574:mdna:132]

[0001564590-19-043736:mdna:140]
[same as prior period, unchanged from 0001564590-19-032574:mdna:133]

[0001564590-19-043736:mdna:141]
During the first six months of fiscal 2020, we generated cash from operating activities of $257 million, reflecting net income of $346 million, adjusted by non-cash depreciation and amortization of $99 million, stock-based compensation of $82 million, and a gain on sale of properties of $38 million, compared to $491 million of cash generated from operating activities during the first six months of fiscal 2019.

[0001564590-19-043736:mdna:142]
Changes in assets and liabilities in the first six months of fiscal 2020 included the following:

[0001564590-19-043736:mdna:143]
|  | • | Accounts receivable decreased $435 million, reflecting lower DSO. |

[0001564590-19-043736:mdna:144]
|  | • | Accounts payable decreased $157 million, reflecting lower DPO. |

[0001564590-19-043736:mdna:145]
|  | • | Accrued expenses decreased $315 million, primarily due to employee compensation payouts related to fiscal year 2019 commissions and incentive compensation plans and payments of income taxes. |

[0001564590-19-043736:mdna:146]
|  | • | Deferred revenue and financed unearned services revenue decreased $197 million, primarily due to a decrease in deferred software and hardware maintenance contract revenues reflecting the seasonality of maintenance contract renewal activities. |

[0001564590-19-043736:mdna:147]
[same as prior period, unchanged from 0001564590-19-032574:mdna:140]

[0001564590-19-043736:mdna:148]
[same as prior period, unchanged from 0001564590-19-032574:mdna:141]

[0001564590-19-043736:mdna:149]
During the first six months of fiscal 2020, we generated $1.1 billion from maturities and sales of investments, net of purchases, and paid $68 million for capital expenditures, while during the first six months of fiscal 2019, we generated $489 million from maturities and sales of investments, net of purchases, and paid $107 million for capital expenditures. Additionally, during the first six months of fiscal 2020, we received $96 million for the sale of land in Sunnyvale, California and paid $56 million net to acquire a privately-held company.

[0001564590-19-043736:mdna:150]
[same as prior period, unchanged from 0001564590-19-032574:mdna:143]

[0001564590-19-043736:mdna:151]
During the first six months of fiscal 2020, we used $750 million for the repurchase of fourteen million shares of our common stock, $226 million for the payment of dividends, and $400 million for the repayment of our Senior Notes due September 2019, partially offset by $249 million in proceeds from the issuance of commercial paper notes, net, compared to $1.1 billion used for the repurchase of fourteen million shares of common stock, $207 million used for the payment of dividends, and $135 million used for the repayment of commercial paper notes, net, during the first six months of fiscal 2019.

[0001564590-19-043736:mdna:152]
[same as prior period, unchanged from 0001564590-19-032574:mdna:145]

[0001564590-19-043736:mdna:153]
[same as prior period, unchanged from 0001564590-19-032574:mdna:146]

[0001564590-19-043736:mdna:154]
Our principal sources of liquidity as of October 25, 2019 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001564590-19-043736:mdna:155]
[same as prior period, unchanged from 0001564590-19-032574:mdna:148]

[0001564590-19-043736:mdna:156]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Cash and cash equivalents |  | $ | 2,545 |  |  | $ | 2,325 |  |
| Short-term investments |  |  | 442 |  |  |  | 1,574 |  |
| Total |  | $ | 2,987 |  |  | $ | 3,899 |  |

[0001564590-19-043736:mdna:157]
As of October 25, 2019 and April 26, 2019, $2.9 billion and $3.7 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.1 billion and $0.2 billion, respectively, were available in the U.S. The TCJA imposed a one-time transition tax on substantially all accumulated foreign earnings through December 31, 2017, and generally allows companies to make distributions of foreign earnings without incurring additional federal taxes. As a part of the recognition of the impacts of the TCJA, we have reviewed our projected global cash requirements and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested.

[0001564590-19-043736:mdna:158]
[same as prior period, unchanged from 0001564590-19-032574:mdna:151]

[0001564590-19-043736:mdna:159]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of October 25, 2019.

[0001564590-19-043736:mdna:160]
[same as prior period, unchanged from 0001564590-19-032574:mdna:180]

[0001564590-19-043736:mdna:161]
[same as prior period, unchanged from 0001564590-19-032574:mdna:153]

[0001564590-19-043736:mdna:162]
[same as prior period, unchanged from 0001564590-19-032574:mdna:154]

[0001564590-19-043736:mdna:163]
The following table summarizes the principal amount of our Senior Notes as of October 25, 2019 (in millions):

[0001564590-19-043736:mdna:164]
| 3.375% Senior Notes Due June 2021 |  | $ | 500 |  |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| Total |  | $ | 1,150 |  |

[0001564590-19-043736:mdna:165]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 8 – Financing Arrangements of the Notes to Condensed Consolidated Financial Statements.

[0001564590-19-043736:mdna:166]
Commercial Paper Program and Credit Facility

[0001564590-19-043736:mdna:167]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of October 25, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $499 million, a weighted-average interest rate of 2.20% and maturities ranging from 7 days to 91 days.

[0001564590-19-043736:mdna:168]
In connection with the Program, we have a senior unsecured credit agreement that expires on December 10, 2021. The credit agreement provides a $1.0 billion revolving unsecured credit facility that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes, providing another potential source of liquidity to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement also includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of October 25, 2019, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-19-043736:mdna:169]
[same as prior period, unchanged from 0001564590-19-032574:mdna:161]

[0001564590-19-043736:mdna:170]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2020 to be between $75 million and $100 million.

[0001564590-19-043736:mdna:171]
[same as prior period, unchanged from 0001564590-19-032574:mdna:163]

[0001564590-19-043736:mdna:172]
On November 13, 2019, we declared a cash dividend of $0.48 per share of common stock, payable on January 22, 2020 to holders of record as of the close of business on January 3, 2020.

[0001564590-19-043736:mdna:173]
Our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through October 25, 2019, we repurchased a total of 327 million shares of our common stock at an average price of $38.20 per share, for an aggregate purchase price of $12.5 billion. As of October 25, 2019, the remaining authorized amount for stock repurchases under this program was $1.1 billion.

[0001564590-19-043736:mdna:174]
[same as prior period, unchanged from 0001564590-19-032574:mdna:166]

[0001564590-19-043736:mdna:175]
[same as prior period, unchanged from 0001564590-19-032574:mdna:167]

[0001564590-19-043736:mdna:176]
[same as prior period, unchanged from 0001564590-19-032574:mdna:168]

[0001564590-19-043736:mdna:177]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 25, 2019, we had $447 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-19-043736:mdna:178]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of October 25, 2019, we had $5 million in construction related obligations and $244 million in other purchase obligations.

[0001564590-19-043736:mdna:179]
[same as prior period, unchanged from 0001564590-19-032574:mdna:171]

[0001564590-19-043736:mdna:180]
As of October 25, 2019, our liability for uncertain tax positions was $251 million, including interest, penalties and certain income tax benefits. Due to uncertainties regarding tax audits and their possible outcomes, we are unable to make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-19-043736:mdna:181]
[same as prior period, unchanged from 0001564590-19-032574:mdna:173]

[0001564590-19-043736:mdna:182]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $34 million and $43 million of receivables during the first six months of fiscal 2020 and fiscal 2019, respectively.

[0001564590-19-043736:mdna:183]
[same as prior period, unchanged from 0001564590-19-032574:mdna:175]

[0001564590-19-043736:mdna:184]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of October 25, 2019 and April 26, 2019, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-19-043736:mdna:185]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of October 25, 2019, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-19-043736:mdna:186]
[same as prior period, unchanged from 0001564590-19-032574:mdna:178]

[0001564590-19-043736:mdna:187]
[same as prior period, unchanged from 0001564590-19-032574:mdna:179]

[0001564590-19-043736:mdna:188]
40

[0001564590-19-043736:mdna:189]
Legal Contingencies

[0001564590-19-043736:mdna:190]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 16 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0001564590-19-043736:mdna:191]
41
