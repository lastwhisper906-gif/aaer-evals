# NTAP notes — 0001564590-19-043736


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-19-043736:notes:1]
[same as prior period, unchanged from 0001564590-19-032574:notes:1]

[0001564590-19-043736:notes:2]
[same as prior period, unchanged from 0001564590-19-032574:notes:2]

[0001564590-19-043736:notes:3]
[same as prior period, unchanged from 0001564590-19-032574:notes:3]

[0001564590-19-043736:notes:4]
[same as prior period, unchanged from 0001564590-19-032574:notes:4]

[0001564590-19-043736:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 26, 2019 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 25, 2019 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-19-043736:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-19-043736:notes:7]
[same as prior period, unchanged from 0001564590-19-032574:notes:7]

[0001564590-19-043736:notes:8]
In February 2016, the FASB issued an accounting standards update on financial reporting for leasing arrangements, including requiring lessees to recognize an operating lease with a term greater than one year on their balance sheets as a right-of-use (ROU) asset and corresponding lease liability, measured at the present value of the lease payments. In the first quarter of fiscal 2020, we adopted this new standard using the modified retrospective approach, electing the optional transition approach of not adjusting our comparative period financial statements for the impacts of adoption. We also elected the package of practical expedients that did not require us to reassess existing leases under the new guidance, and the practical expedient to not separate lease and non-lease components for all leases. Adoption of the new standard on April 27, 2019 resulted in the recognition of approximately $149 million of operating lease ROU assets, net of deferred rent and lease restructuring liabilities, $158 million of lease liabilities, and a cumulative-effect adjustment to retained earnings of $6 million on our condensed consolidated balance sheets. Adoption of the standard did not have a material impact on our condensed consolidated statements of operations or condensed consolidated statements of cash flows. Additional information is presented below and in Note 9 – Leases.

[0001564590-19-043736:notes:9]
[same as prior period, unchanged from 0001564590-19-032574:notes:9]

[0001564590-19-043736:notes:10]
[same as prior period, unchanged from 0001564590-19-032574:notes:10]

[0001564590-19-043736:notes:11]
[same as prior period, unchanged from 0001564590-19-032574:notes:11]

[0001564590-19-043736:notes:12]
There have been no other significant changes in our significant accounting policies as of and for the six months ended October 25, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 26, 2019.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-19-043736:notes:13]
[same as prior period, unchanged from 0001564590-19-032574:notes:13]

[0001564590-19-043736:notes:14]
[same as prior period, unchanged from 0001564590-19-032574:notes:14]

[0001564590-19-043736:notes:15]
[same as prior period, unchanged from 0001564590-19-032574:notes:15]

[0001564590-19-043736:notes:16]
[same as prior period, unchanged from 0001564590-19-032574:notes:16]

[0001564590-19-043736:notes:17]
[same as prior period, unchanged from 0001564590-19-032574:notes:17]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-19-043736:notes:18]
[same as prior period, unchanged from 0001564590-19-032574:notes:18]

[0001564590-19-043736:notes:19]
[same as prior period, unchanged from 0001564590-19-032574:notes:19]

[0001564590-19-043736:notes:20]
| Balance as of April 26, 2019 |  | $ | 1,735 |  |
| Additions |  |  | 35 |  |
| Balance as of October 25, 2019 |  | $ | 1,770 |  |

[0001564590-19-043736:notes:21]
[same as prior period, unchanged from 0001564590-19-032574:notes:21]

[0001564590-19-043736:notes:22]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 186 |  |  | $ | (135 | ) |  | $ | 51 |  |  | $ | 160 |  |  | $ | (113 | ) |  | $ | 47 |  |
| Customer contracts/relationships |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 41 |  |  |  | (41 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 186 |  |  | $ | (135 | ) |  | $ | 51 |  |  | $ | 201 |  |  | $ | (154 | ) |  | $ | 47 |  |

[0001564590-19-043736:notes:23]
[same as prior period, unchanged from 0001564590-19-032574:notes:23]

[0001564590-19-043736:notes:24]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Statements of |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | Operations Classification |
| Developed technology |  | $ | 11 |  |  | $ | 9 |  |  | $ | 22 |  |  | $ | 18 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | 7 |  |  | Operating expenses |
| Total |  | $ | 11 |  |  | $ | 12 |  |  | $ | 22 |  |  | $ | 25 |  |  |  |

[0001564590-19-043736:notes:25]
As of October 25, 2019, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-19-043736:notes:26]
| Fiscal Year |  | Amount |  |
| Remainder of 2020 |  | $ | 16 |  |
| 2021 |  |  | 25 |  |
| 2022 |  |  | 9 |  |
| 2023 |  |  | 1 |  |
| Total |  | $ | 51 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-19-043736:notes:27]
[same as prior period, unchanged from 0001564590-19-032574:notes:27]

[0001564590-19-043736:notes:28]
[same as prior period, unchanged from 0001564590-19-032574:notes:28]

[0001564590-19-043736:notes:29]
The following table presents cash and cash equivalents as reported in our condensed consolidated balance sheets, as well as the sum of cash, cash equivalents and restricted cash as reported on our condensed consolidated statements of cash flows:

[0001564590-19-043736:notes:30]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Cash and cash equivalents |  | $ | 2,545 |  |  | $ | 2,325 |  |
| Restricted cash |  |  | 6 |  |  |  | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,551 |  |  | $ | 2,331 |  |

[0001564590-19-043736:notes:31]
[same as prior period, unchanged from 0001564590-19-032574:notes:31]

[0001564590-19-043736:notes:32]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Purchased components |  | $ | 14 |  |  | $ | 8 |  |
| Finished goods |  |  | 97 |  |  |  | 123 |  |
| Inventories |  | $ | 111 |  |  | $ | 131 |  |

[0001564590-19-043736:notes:33]
[same as prior period, unchanged from 0001564590-19-032574:notes:33]

[0001564590-19-043736:notes:34]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Land |  | $ | 104 |  |  | $ | 106 |  |
| Buildings and improvements |  |  | 609 |  |  |  | 605 |  |
| Leasehold improvements |  |  | 86 |  |  |  | 86 |  |
| Computer, production, engineering and other equipment |  |  | 841 |  |  |  | 817 |  |
| Computer software |  |  | 358 |  |  |  | 357 |  |
| Furniture and fixtures |  |  | 106 |  |  |  | 105 |  |
| Construction-in-progress |  |  | 21 |  |  |  | 10 |  |
|  |  |  | 2,125 |  |  |  | 2,086 |  |
| Accumulated depreciation and amortization |  |  | (1,379 | ) |  |  | (1,327 | ) |
| Property and equipment, net |  | $ | 746 |  |  | $ | 759 |  |

[0001564590-19-043736:notes:35]
In September 2017, we entered into an agreement to sell certain land and buildings located in Sunnyvale, California, through two separate and independent closings, the first of which was completed in the third quarter of fiscal 2018. The remaining properties, consisting of land, were classified as assets held for sale, and included as other current assets in our condensed consolidated balance sheets as of April 26, 2019. On August 29, 2019, the second closing occurred and we consummated the sale of the land, with a net book value of $53 million, and received cash proceeds of $96 million, resulting in a gain, net of direct selling costs, of $38 million.

[0001564590-19-043736:notes:36]
[same as prior period, unchanged from 0001564590-19-032574:notes:36]

[0001564590-19-043736:notes:37]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Deferred tax assets |  | $ | 223 |  |  | $ | 201 |  |
| Operating lease ROU assets |  |  | 143 |  |  |  | — |  |
| Other assets |  |  | 348 |  |  |  | 389 |  |
| Other non-current assets |  | $ | 714 |  |  | $ | 590 |  |

[0001564590-19-043736:notes:38]
Other non-current assets as of October 25, 2019 and April 26, 2019 includes $77 million and $78 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited, a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019.

[0001564590-19-043736:notes:39]
[same as prior period, unchanged from 0001564590-19-032574:notes:39]

[0001564590-19-043736:notes:40]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Accrued compensation and benefits |  | $ | 279 |  |  | $ | 433 |  |
| Product warranty liabilities |  |  | 26 |  |  |  | 25 |  |
| Operating lease liabilities |  |  | 49 |  |  |  | — |  |
| Other current liabilities |  |  | 252 |  |  |  | 393 |  |
| Accrued expenses |  | $ | 606 |  |  | $ | 851 |  |

[0001564590-19-043736:notes:41]
[same as prior period, unchanged from 0001564590-19-032574:notes:41]

[0001564590-19-043736:notes:42]
[same as prior period, unchanged from 0001564590-19-032574:notes:42]

[0001564590-19-043736:notes:43]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Balance at beginning of period |  | $ | 39 |  |  | $ | 38 |  |  | $ | 40 |  |  | $ | 40 |  |
| Expense accrued during the period |  |  | 7 |  |  |  | 6 |  |  |  | 12 |  |  |  | 10 |  |
| Warranty costs incurred |  |  | (6 | ) |  |  | (5 | ) |  |  | (12 | ) |  |  | (11 | ) |
| Balance at end of period |  | $ | 40 |  |  | $ | 39 |  |  | $ | 40 |  |  | $ | 39 |  |

[0001564590-19-043736:notes:44]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Accrued expenses |  | $ | 26 |  |  | $ | 25 |  |
| Other long-term liabilities |  |  | 14 |  |  |  | 15 |  |
| Total warranty liabilities |  | $ | 40 |  |  | $ | 40 |  |

[0001564590-19-043736:notes:45]
[same as prior period, unchanged from 0001564590-19-032574:notes:45]

[0001564590-19-043736:notes:46]
[same as prior period, unchanged from 0001564590-19-032574:notes:46]

[0001564590-19-043736:notes:47]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Liability for uncertain tax positions |  | $ | 251 |  |  | $ | 252 |  |
| Income taxes payable |  |  | 399 |  |  |  | 447 |  |
| Product warranty liabilities |  |  | 14 |  |  |  | 15 |  |
| Operating lease liabilities |  |  | 102 |  |  |  | — |  |
| Other liabilities |  |  | 71 |  |  |  | 83 |  |
| Other long-term liabilities |  | $ | 837 |  |  | $ | 797 |  |

[0001564590-19-043736:notes:48]
Other income, net (in millions):

[0001564590-19-043736:notes:49]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Interest income |  | $ | 12 |  |  | $ | 21 |  |  | $ | 31 |  |  | $ | 46 |  |
| Interest expense |  |  | (12 | ) |  |  | (14 | ) |  |  | (27 | ) |  |  | (28 | ) |
| Other income, net |  |  | 3 |  |  |  | — |  |  |  | 14 |  |  |  | 7 |  |
| Total other income, net |  | $ | 3 |  |  | $ | 7 |  |  | $ | 18 |  |  | $ | 25 |  |

[0001564590-19-043736:notes:50]
[same as prior period, unchanged from 0001564590-19-032574:notes:48]

[0001564590-19-043736:notes:51]
Supplemental cash flow information related to our operating leases is included in Note 9 ─ Leases. Non-cash investing activities and other supplemental cash flow information are presented below:

[0001564590-19-043736:notes:52]
|  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 6 |  |  | $ | 7 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 260 |  |  | $ | 104 |  |
| Interest paid |  | $ | 25 |  |  | $ | 26 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-043736:notes:53]
[same as prior period, unchanged from 0001564590-19-032574:notes:51]

[0001564590-19-043736:notes:54]
[same as prior period, unchanged from 0001564590-19-032574:notes:52]

[0001564590-19-043736:notes:55]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. As our product portfolio evolves, market dynamics change, and management continues to assess of our largest growth opportunities, we periodically change how we group certain products. Beginning in fiscal 2020, Strategic includes All-flash FAS (AFF) products, including all related add-on hardware and operating system (OS) software, private cloud solutions (including SolidFire, converged and hyper-converged infrastructure products, StorageGrid), enterprise software license agreements (ELAs) and other optional add-on software products. Mature now includes Hybrid FAS products, including all related add-on hardware and OS software, original equipment manufacturers (OEM) products, and branded E-Series. Prior to this grouping change, Hybrid FAS products and branded E-Series were included in Strategic, while all add-on hardware and OS software were included in Mature. For comparability, Strategic and Mature revenues presented for the prior year periods have been recast based on the revised groupings.

[0001564590-19-043736:notes:56]
[same as prior period, unchanged from 0001564590-19-032574:notes:54]

[0001564590-19-043736:notes:57]
[same as prior period, unchanged from 0001564590-19-032574:notes:55]

[0001564590-19-043736:notes:58]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Product revenues |  | $ | 771 |  |  | $ | 913 |  |  | $ | 1,415 |  |  | $ | 1,788 |  |
| Strategic |  | 442 |  |  | 485 |  |  |  | 779 |  |  |  | 960 |  |
| Mature |  | 329 |  |  | 428 |  |  |  | 636 |  |  |  | 828 |  |
| Software maintenance revenues |  | 254 |  |  | 236 |  |  |  | 504 |  |  | 465 |  |
| Hardware maintenance and other services revenues |  | 346 |  |  | 368 |  |  |  | 688 |  |  |  | 738 |  |
| Hardware maintenance support contracts |  | 286 |  |  | 303 |  |  |  | 570 |  |  |  | 606 |  |
| Professional and other services |  | 60 |  |  | 65 |  |  |  | 118 |  |  |  | 132 |  |
| Net revenues |  | $ | 1,371 |  |  | $ | 1,517 |  |  | $ | 2,607 |  |  | $ | 2,991 |  |

[0001564590-19-043736:notes:59]
Revenues by geographic region are presented in Note 15 – Segment, Geographic, and Significant Customer Information.

[0001564590-19-043736:notes:60]
[same as prior period, unchanged from 0001564590-19-032574:notes:58]

[0001564590-19-043736:notes:61]
[same as prior period, unchanged from 0001564590-19-032574:notes:59]

[0001564590-19-043736:notes:62]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Deferred product revenue |  | $ | 85 |  |  | $ | 84 |  |
| Deferred services revenue |  |  | 3,314 |  |  |  | 3,502 |  |
| Financed unearned services revenue |  |  | 69 |  |  |  | 82 |  |
| Total |  | $ | 3,468 |  |  | $ | 3,668 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,718 |  |  | $ | 1,825 |  |
| Long-term |  |  | 1,750 |  |  |  | 1,843 |  |
| Total |  | $ | 3,468 |  |  | $ | 3,668 |  |

[0001564590-19-043736:notes:63]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 16 – Commitments and Contingencies for additional information related to these arrangements.

[0001564590-19-043736:notes:64]
[same as prior period, unchanged from 0001564590-19-032574:notes:62]

[0001564590-19-043736:notes:65]
|  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Balance at beginning of period |  | $ | 3,668 |  |  | $ | 3,363 |  |
| Additions |  |  | 1,011 |  |  |  | 1,067 |  |
| Revenue recognized during the period |  |  | (1,211 | ) |  |  | (1,224 | ) |
| Balance at end of period |  | $ | 3,468 |  |  | $ | 3,206 |  |

[0001564590-19-043736:notes:66]
During the six months ended October 25, 2019 and October 26, 2018, we recognized $1,045 million and $1,019 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001564590-19-043736:notes:67]
As of October 25, 2019, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,468 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 49% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 26% in the next 13 to 24 months, and the remainder thereafter.

[0001564590-19-043736:notes:68]
[same as prior period, unchanged from 0001564590-19-032574:notes:66]

[0001564590-19-043736:notes:69]
[same as prior period, unchanged from 0001564590-19-032574:notes:67]

[0001564590-19-043736:notes:70]
|  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Balance at beginning of period |  | $ | 172 |  |  | $ | 137 |  |
| Additions |  |  | 32 |  |  |  | 35 |  |
| Expense recognized during the period |  |  | (50 | ) |  |  | (41 | ) |
| Balance at end of period |  | $ | 154 |  |  | $ | 131 |  |

[0001564590-19-043736:notes:71]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Other current assets |  | $ | 66 |  |  | $ | 75 |  |
| Other non-current assets |  |  | 88 |  |  |  | 97 |  |
| Total deferred commissions |  | $ | 154 |  |  | $ | 172 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-19-043736:notes:72]
7. Financial Instruments and Fair Value Measurements

[0001564590-19-043736:notes:73]
[same as prior period, unchanged from 0001564590-19-032574:notes:74]

[0001564590-19-043736:notes:74]
[same as prior period, unchanged from 0001564590-19-032574:notes:75]

[0001564590-19-043736:notes:75]
[same as prior period, unchanged from 0001564590-19-032574:notes:76]

[0001564590-19-043736:notes:76]
[same as prior period, unchanged from 0001564590-19-032574:notes:77]

[0001564590-19-043736:notes:77]
[same as prior period, unchanged from 0001564590-19-032574:notes:78]

[0001564590-19-043736:notes:78]
[same as prior period, unchanged from 0001564590-19-032574:notes:79]

[0001564590-19-043736:notes:79]
[same as prior period, unchanged from 0001564590-19-032574:notes:80]

[0001564590-19-043736:notes:80]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 319 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 320 |  |  | $ | 1,359 |  |  | $ | 2 |  |  | $ | (8 | ) |  | $ | 1,353 |  |
| U.S. Treasury and government debt securities |  |  | 122 |  |  |  | — |  |  |  | — |  |  |  | 122 |  |  |  | 214 |  |  |  | — |  |  |  | (1 | ) |  |  | 213 |  |
| Certificates of deposit |  |  | 150 |  |  |  | — |  |  |  | — |  |  |  | 150 |  |  |  | 117 |  |  |  | — |  |  |  | — |  |  |  | 117 |  |
| Mutual funds |  |  | 40 |  |  |  | — |  |  |  | — |  |  |  | 40 |  |  |  | 35 |  |  |  | — |  |  |  | — |  |  |  | 35 |  |
| Total debt and equity securities |  | $ | 631 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 632 |  |  | $ | 1,725 |  |  | $ | 2 |  |  | $ | (9 | ) |  | $ | 1,718 |  |

[0001564590-19-043736:notes:81]
During the six months ended October 25, 2019, we sold approximately $1.0 billion of corporate bonds held by foreign subsidiaries and recognized a gain on sale of $14 million, which is presented in other income, net on our condensed consolidated statement of operations.

[0001564590-19-043736:notes:82]
The following table presents the contractual maturities of our debt investments as of October 25, 2019 (in millions):

[0001564590-19-043736:notes:83]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 464 |  |  | $ | 464 |  |
| Due after one year through five years |  |  | 122 |  |  |  | 123 |  |
| Due after five years through ten years |  |  | 5 |  |  |  | 5 |  |
|  |  | $ | 591 |  |  | $ | 592 |  |

[0001564590-19-043736:notes:84]
[same as prior period, unchanged from 0001564590-19-032574:notes:86]

[0001564590-19-043736:notes:85]
[same as prior period, unchanged from 0001564590-19-032574:notes:87]

[0001564590-19-043736:notes:86]
[same as prior period, unchanged from 0001564590-19-032574:notes:88]

[0001564590-19-043736:notes:87]
|  |  | October 25, 2019 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,395 |  |  | $ | 2,395 |  |  | $ | — |  |
| Corporate bonds |  |  | 320 |  |  |  | — |  |  |  | 320 |  |
| U.S. Treasury and government debt securities |  |  | 122 |  |  |  | 91 |  |  |  | 31 |  |
| Certificates of deposit |  |  | 150 |  |  |  | — |  |  |  | 150 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 2,987 |  |  | $ | 2,486 |  |  | $ | 501 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 9 |  |  | $ | 9 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 31 |  |  | $ | 31 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0001564590-19-043736:notes:88]
[same as prior period, unchanged from 0001564590-19-032574:notes:90]

[0001564590-19-043736:notes:89]
[same as prior period, unchanged from 0001564590-19-032574:notes:91]

[0001564590-19-043736:notes:90]
[same as prior period, unchanged from 0001564590-19-032574:notes:92]

[0001564590-19-043736:notes:91]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of October 25, 2019 and April 26, 2019, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-19-043736:notes:92]
[same as prior period, unchanged from 0001564590-19-032574:notes:94]

[0001564590-19-043736:notes:93]
As of October 25, 2019 and April 26, 2019, the fair value of our long-term debt was approximately $1,174 million and $1,553 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-19-043736:notes:94]
8. Financing Arrangements

[0001564590-19-043736:notes:95]
Long-Term Debt

[0001564590-19-043736:notes:96]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-19-043736:notes:97]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due September 2019 |  | $ | — |  |  | N/A |  |  | $ | 400 |  |  |  | 2.32 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |  |  | 3.42 | % |  |  | 400 |  |  |  | 3.42 | % |
| Total principal amount |  |  | 1,150 |  |  |  |  |  |  |  | 1,550 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (5 | ) |  |  |  |  |  |  | (6 | ) |  |  |  |  |
| Total senior notes |  |  | 1,145 |  |  |  |  |  |  |  | 1,544 |  |  |  |  |  |
| Less: Current portion of long-term debt |  |  | — |  |  |  |  |  |  |  | (400 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,145 |  |  |  |  |  |  | $ | 1,144 |  |  |  |  |  |

[0001564590-19-043736:notes:98]
N/A – Not Applicable

[0001564590-19-043736:notes:99]
Senior Notes

[0001564590-19-043736:notes:100]
On September 27, 2019, we made an aggregate cash payment of $400 million to extinguish our 2.00% Senior Notes at maturity.

[0001564590-19-043736:notes:101]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017. Interest on these Senior Notes is paid semi-annually in March and September. Our 3.375% Senior Notes and 3.25% Senior Notes, with principal amounts of $500 million and $250 million, respectively, were issued in June 2014 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-19-043736:notes:102]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 25, 2019, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-19-043736:notes:103]
As of October 25, 2019, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-19-043736:notes:104]
| Fiscal Year |  | Amount |  |
| 2022 |  | $ | 500 |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| Total |  | $ | 1,150 |  |

[0001564590-19-043736:notes:105]
Commercial Paper Program and Credit Facility

[0001564590-19-043736:notes:106]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of October 25, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $499 million, a weighted-average interest rate of 2.20% and maturities ranging from 7 days to 91 days. As of April 26, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $249 million, a weighted-average interest rate of 2.73% and maturities ranging from 27 days to 38 days.

[0001564590-19-043736:notes:107]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of October 25, 2019 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0001564590-19-043736:notes:108]
9. Leases

[0001564590-19-043736:notes:109]
[same as prior period, unchanged from 0001564590-19-032574:notes:110]

[0001564590-19-043736:notes:110]
[same as prior period, unchanged from 0001564590-19-032574:notes:111]

[0001564590-19-043736:notes:111]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 25, 2019 |  |
| Operating lease cost |  | $ | 15 |  |  | $ | 29 |  |
| Variable lease cost |  |  | 4 |  |  |  | 8 |  |
| Total lease cost |  | $ | 19 |  |  | $ | 37 |  |

[0001564590-19-043736:notes:112]
[same as prior period, unchanged from 0001564590-19-032574:notes:113]

[0001564590-19-043736:notes:113]
[same as prior period, unchanged from 0001564590-19-032574:notes:114]

[0001564590-19-043736:notes:114]
|  |  |  |  | Six Months Ended |  |
|  |  |  |  | October 25, 2019 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  |  |  | $ | 29 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  |  |  | $ | 21 |  |

[0001564590-19-043736:notes:115]
[same as prior period, unchanged from 0001564590-19-032574:notes:116]

[0001564590-19-043736:notes:116]
|  |  |  |  | October 25, 2019 |  |
| Other non-current assets |  |  |  | $ | 143 |  |
| Total operating lease ROU assets |  |  |  | $ | 143 |  |
| Accrued expenses |  |  |  | $ | 49 |  |
| Other long-term liabilities |  |  |  |  | 102 |  |
| Total operating lease liabilities |  |  |  | $ | 151 |  |
| Weighted Average Remaining Lease Term |  |  |  | 3.9 years |  |
| Weighted Average Discount Rate |  |  |  |  | 2.6 | % |

[0001564590-19-043736:notes:117]
Future minimum operating lease payments as of October 25, 2019 are as follows (in millions):

[0001564590-19-043736:notes:118]
|  |  |  |  | Operating Leases |  |
| Fiscal 2020 (remainder) |  |  |  | $ | 28 |  |
| Fiscal 2021 |  |  |  |  | 46 |  |
| Fiscal 2022 |  |  |  |  | 34 |  |
| Fiscal 2023 |  |  |  |  | 20 |  |
| Fiscal 2024 |  |  |  |  | 14 |  |
| Thereafter |  |  |  |  | 18 |  |
| Total lease payments |  |  |  | $ | 160 |  |
| Less: Interest |  |  |  |  | (9 | ) |
| Total |  |  |  | $ | 151 |  |

[0001564590-19-043736:notes:119]
[same as prior period, unchanged from 0001564590-19-032574:notes:120]

[0001564590-19-043736:notes:120]
|  |  |  |  | Operating Leases |  |
| Fiscal 2020 |  |  |  | $ | 47 |  |
| Fiscal 2021 |  |  |  |  | 38 |  |
| Fiscal 2022 |  |  |  |  | 26 |  |
| Fiscal 2023 |  |  |  |  | 14 |  |
| Fiscal 2024 |  |  |  |  | 10 |  |
| Thereafter |  |  |  |  | 16 |  |
| Total lease payments |  |  |  | $ | 151 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-19-043736:notes:121]
10. Stockholders’ Equity

[0001564590-19-043736:notes:122]
[same as prior period, unchanged from 0001564590-19-032574:notes:123]

[0001564590-19-043736:notes:123]
As of October 25, 2019, we have certain equity incentive awards (awards) outstanding, which include stock options and restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs). Also outstanding are purchase rights under our Employee Stock Purchase Plan (ESPP). During the second quarter of fiscal 2020, the 1999 Stock Option Plan, under which  stock options and RSUs are granted, was extended for a 10 year term.

[0001564590-19-043736:notes:124]
[same as prior period, unchanged from 0001564590-19-032574:notes:125]

[0001564590-19-043736:notes:125]
Less than 1 million options were outstanding as of October 25, 2019 and April 26, 2019.

[0001564590-19-043736:notes:126]
[same as prior period, unchanged from 0001564590-19-032574:notes:127]

[0001564590-19-043736:notes:127]
|  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Intrinsic value of exercises |  | $ | 3 |  |  | $ | 22 |  |
| Proceeds received from exercises |  | $ | 2 |  |  | $ | 17 |  |
| Fair value of options vested |  | $ | — |  |  | $ | 1 |  |

[0001564590-19-043736:notes:128]
[same as prior period, unchanged from 0001564590-19-032574:notes:129]

[0001564590-19-043736:notes:129]
[same as prior period, unchanged from 0001564590-19-032574:notes:130]

[0001564590-19-043736:notes:130]
In the six months ended October 25, 2019, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria, in addition to the service based vesting criteria, such that the PBRSUs cliff-vest at the end of an approximate three year performance period, which began on the date specified in the grant agreements and ends the last day of fiscal 2022. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the current year, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of fiscal 2022. The fair values of these awards were fixed at grant date using a Monte Carlo simulation model. For the remaining PBRSUs granted, the number of shares issued will depend upon our achievement against a cumulative Adjusted Operating Income (AOI) target, as defined in the grant agreements, for the three year period from fiscal 2020 through 2022. The fair values of these awards were established consistent with our methodology for valuing time-based RSUs, while compensation cost is being recognized based on the probable outcome of the performance condition. The aggregate grant date fair value of all PBRSUs granted in the current year was $18 million, which is being recognized to compensation expense over the remaining applicable performance / service periods.

[0001564590-19-043736:notes:131]
[same as prior period, unchanged from 0001564590-19-032574:notes:133]

[0001564590-19-043736:notes:132]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 26, 2019 |  |  | 8 |  |  | $ | 45.68 |  |
| Granted |  |  | 3 |  |  | $ | 52.21 |  |
| Vested |  |  | (3 | ) |  | $ | 37.88 |  |
| Forfeited |  |  | (1 | ) |  | $ | 47.64 |  |
| Outstanding as of October 25, 2019 |  |  | 7 |  |  | $ | 51.25 |  |

[0001564590-19-043736:notes:133]
[same as prior period, unchanged from 0001564590-19-032574:notes:135]

[0001564590-19-043736:notes:134]
|  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 74 |  |  | $ | 89 |  |

[0001564590-19-043736:notes:135]
[same as prior period, unchanged from 0001564590-19-032574:notes:137]

[0001564590-19-043736:notes:136]
[same as prior period, unchanged from 0001564590-19-032574:notes:138]

[0001564590-19-043736:notes:137]
|  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Shares issued under the ESPP |  |  | 1 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 54 |  |  | $ | 49 |  |

[0001564590-19-043736:notes:138]
[same as prior period, unchanged from 0001564590-19-032574:notes:140]

[0001564590-19-043736:notes:139]
[same as prior period, unchanged from 0001564590-19-032574:notes:141]

[0001564590-19-043736:notes:140]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 1 |  |
| Cost of hardware maintenance and other services revenues |  |  | 3 |  |  |  | 2 |  |  |  | 5 |  |  |  | 5 |  |
| Sales and marketing |  |  | 17 |  |  |  | 16 |  |  |  | 35 |  |  |  | 33 |  |
| Research and development |  |  | 13 |  |  |  | 12 |  |  |  | 28 |  |  |  | 24 |  |
| General and administrative |  |  | 6 |  |  |  | 8 |  |  |  | 12 |  |  |  | 15 |  |
| Total stock-based compensation expense |  | $ | 40 |  |  | $ | 38 |  |  | $ | 82 |  |  | $ | 78 |  |
| Income tax benefit for stock-based compensation expense |  | $ | 4 |  |  | $ | 5 |  |  | $ | 8 |  |  | $ | 10 |  |

[0001564590-19-043736:notes:141]
As of October 25, 2019, total unrecognized compensation expense related to our equity awards was $339 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.3 years.

[0001564590-19-043736:notes:142]
[same as prior period, unchanged from 0001564590-19-032574:notes:144]

[0001564590-19-043736:notes:143]
[same as prior period, unchanged from 0001564590-19-032574:notes:145]

[0001564590-19-043736:notes:144]
The following table summarizes activity related to this program for the six months ended October 25, 2019 (in millions, except per share amounts):

[0001564590-19-043736:notes:145]
| Number of shares repurchased |  |  | 14 |  |
| Average price per share |  | $ | 55.06 |  |
| Aggregate purchase price |  | $ | 750 |  |
| Remaining authorization at end of period |  | $ | 1,139 |  |

[0001564590-19-043736:notes:146]
The aggregate purchase price of our stock repurchases for the six months ended October 25, 2019 consisted of $750 million of open market purchases, of which $398 million and $352 million were allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-19-043736:notes:147]
Since the May 13, 2003 inception of our stock repurchase program through October 25, 2019, we repurchased a total of 327 million shares of our common stock at an average price of $38.20 per share, for an aggregate purchase price of $12.5 billion.

[0001564590-19-043736:notes:148]
[same as prior period, unchanged from 0001564590-19-032574:notes:150]

[0001564590-19-043736:notes:149]
[same as prior period, unchanged from 0001564590-19-032574:notes:151]

[0001564590-19-043736:notes:150]
|  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Dividends per share declared |  | $ | 0.96 |  |  | $ | 0.80 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 226 |  |  | $ | 207 |  |
| Dividend payments allocated to retained earnings |  | $ | — |  |  | $ | — |  |

[0001564590-19-043736:notes:151]
On November 13, 2019, we declared a cash dividend of $0.48 per share of common stock, payable on January 22, 2020 to holders of record as of the close of business on January 3, 2020. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-19-043736:notes:152]
[same as prior period, unchanged from 0001564590-19-032574:notes:154]

[0001564590-19-043736:notes:153]
[same as prior period, unchanged from 0001564590-19-032574:notes:155]

[0001564590-19-043736:notes:154]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 26, 2019 |  | $ | (34 | ) |  | $ | (3 | ) |  | $ | (7 | ) |  | $ | 1 |  |  | $ | (43 | ) |
| Other comprehensive income (loss), net of tax |  |  | (2 | ) |  |  | — |  |  |  | 22 |  |  |  | 1 |  |  |  | 21 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | (14 | ) |  |  | — |  |  |  | (14 | ) |
| Total other comprehensive income |  |  | (2 | ) |  |  | — |  |  |  | 8 |  |  |  | 1 |  |  |  | 7 |  |
| Balance as of October 25, 2019 |  | $ | (36 | ) |  | $ | (3 | ) |  | $ | 1 |  |  | $ | 2 |  |  | $ | (36 | ) |

[0001564590-19-043736:notes:155]
During the first six months of fiscal 2020, realized gains of $14 million from the sale of available-for-sale securities were recorded in other income, net on our condensed consolidated statements of operations.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-19-043736:notes:156]
11. Derivatives and Hedging Activities

[0001564590-19-043736:notes:157]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of our agreements with them. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of October 25, 2019 or April 26, 2019. All contracts have a maturity of less than 12 months.

[0001564590-19-043736:notes:158]
[same as prior period, unchanged from 0001564590-19-032574:notes:160]

[0001564590-19-043736:notes:159]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 305 |  |  | $ | 103 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 114 |  |  | $ | 121 |  |
| Forward contracts purchased |  | $ | 145 |  |  | $ | 363 |  |

[0001564590-19-043736:notes:160]
[same as prior period, unchanged from 0001564590-19-032574:notes:162]

[0001564590-19-043736:notes:161]
[same as prior period, unchanged from 0001564590-19-032574:notes:163]

[0001564590-19-043736:notes:162]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
|  |  | Gain (Loss) Recognized in Income |  |  | Gain (Loss) Recognized in Income |  |
| Foreign currency exchange contracts |  | $ | — |  |  | $ | 2 |  |  | $ | (3 | ) |  | $ | 12 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-19-043736:notes:163]
12. Restructuring Charges

[0001564590-19-043736:notes:164]
In the first quarter of fiscal 2020, we announced a restructuring plan (the May 2019 Plan) to reduce costs and redirect resources to our highest return activities, which included a reduction in our global workforce by approximately 2%. Charges related to the plan consisted primarily of employee severance-related costs. Substantially all activities under the plan have been completed.

[0001564590-19-043736:notes:165]
[same as prior period, unchanged from 0001564590-19-032574:notes:167]

[0001564590-19-043736:notes:166]
[same as prior period, unchanged from 0001564590-19-032574:notes:168]

[0001564590-19-043736:notes:167]
|  |  | Six Months Ended |  |  | Six Months Ended |  |  |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  |  |
|  |  | May 2019 Plan |  |  | April 2019 Plan |  |  | November 2016 Plan |  |  | Total |  |  | May 2018 Plan |  |  | November 2016 Plan |  |  | Total |  |  |  |
| Balance at beginning of period |  | $ | — |  |  | $ | 15 |  |  | $ | 4 |  |  | $ | 19 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 6 |  |  |  |
| Net charges |  |  | 21 |  |  |  | — |  |  |  | — |  |  |  | 21 |  |  |  | 19 |  |  |  | — |  |  |  | 19 |  |  |  |
| Cash payments |  |  | (19 | ) |  |  | (12 | ) |  |  | — |  |  |  | (31 | ) |  |  | (17 | ) |  |  | (1 | ) |  |  | (18 | ) |  |  |
| Other |  |  | — |  |  |  | — |  |  |  | (4 | ) |  |  | (4 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  |
| Balance at end of period |  | $ | 2 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 5 |  |  | $ | 2 |  |  | $ | 5 |  |  | $ | 7 |  |  |  |

[0001564590-19-043736:notes:168]
[same as prior period, unchanged from 0001564590-19-032574:notes:170]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-043736:notes:169]
13. Income Taxes

[0001564590-19-043736:notes:170]
[same as prior period, unchanged from 0001564590-19-032574:notes:172]

[0001564590-19-043736:notes:171]
|  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Effective tax rates |  |  | 17.2 | % |  |  | 7.3 | % |

[0001564590-19-043736:notes:172]
Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations, being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory tax rate. The differences in effective tax rates for the six months ended October 25, 2019 and October 26, 2018 were primarily due to discrete tax benefits related to the adoption of the new revenue standard in fiscal 2019, the discrete tax charge on the sale of land in Sunnyvale, California in fiscal 2020 and the differences in discrete benefits for stock-based compensation.

[0001564590-19-043736:notes:173]
[same as prior period, unchanged from 0001564590-19-032574:notes:176]

[0001564590-19-043736:notes:174]
During fiscal 2019, we adopted the new revenue accounting standard and for the six months ended October 26, 2018, we recognized a $34 million discrete tax benefit for adjustments to certain intercompany transactions resulting from the retrospective application of the new revenue accounting standard.

[0001564590-19-043736:notes:175]
As of October 25, 2019, we had $294 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $246 million would affect our provision for income taxes if recognized, and $251 million has been recorded in other long-term liabilities.

[0001564590-19-043736:notes:176]
[same as prior period, unchanged from 0001564590-19-032574:notes:179]

[0001564590-19-043736:notes:177]
[same as prior period, unchanged from 0001564590-19-032574:notes:180]

[0001564590-19-043736:notes:178]
[same as prior period, unchanged from 0001564590-19-032574:notes:181]


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-043736:notes:179]
14. Net Income per Share

[0001564590-19-043736:notes:180]
[same as prior period, unchanged from 0001564590-19-032574:notes:183]

[0001564590-19-043736:notes:181]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 243 |  |  | $ | 241 |  |  | $ | 346 |  |  | $ | 524 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 235 |  |  |  | 258 |  |  |  | 237 |  |  |  | 260 |  |
| Dilutive impact of employee equity award plans |  |  | 1 |  |  |  | 6 |  |  |  | 3 |  |  |  | 7 |  |
| Shares used in diluted computation |  |  | 236 |  |  |  | 264 |  |  |  | 240 |  |  |  | 267 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.03 |  |  | $ | 0.93 |  |  | $ | 1.46 |  |  | $ | 2.02 |  |
| Diluted |  | $ | 1.03 |  |  | $ | 0.91 |  |  | $ | 1.44 |  |  | $ | 1.96 |  |

[0001564590-19-043736:notes:182]
Six million and three million potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for the three and six months ended October 25, 2019, respectively, as their inclusion would have been anti-dilutive, while no potential shares were excluded from the calculation for the three or six months ended October 26, 2018.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-043736:notes:183]
15. Segment, Geographic, and Significant Customer Information

[0001564590-19-043736:notes:184]
[same as prior period, unchanged from 0001564590-19-032574:notes:187]

[0001564590-19-043736:notes:185]
[same as prior period, unchanged from 0001564590-19-032574:notes:188]

[0001564590-19-043736:notes:186]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| United States, Canada and Latin America (Americas) |  | $ | 771 |  |  | $ | 868 |  |  | $ | 1,406 |  |  | $ | 1,711 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 402 |  |  |  | 429 |  |  |  | 804 |  |  |  | 859 |  |
| Asia Pacific (APAC) |  |  | 198 |  |  |  | 220 |  |  |  | 397 |  |  |  | 421 |  |
| Net revenues |  | $ | 1,371 |  |  | $ | 1,517 |  |  | $ | 2,607 |  |  | $ | 2,991 |  |

[0001564590-19-043736:notes:187]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $703 million and $789 million during the three months ended October 25, 2019 and October 26, 2018, respectively, and were $1,277 million and $1,550 million during the six months ended October 25, 2019 and October 26, 2018, respectively.

[0001564590-19-043736:notes:188]
[same as prior period, unchanged from 0001564590-19-032574:notes:191]

[0001564590-19-043736:notes:189]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| U.S. |  | $ | 125 |  |  | $ | 159 |  |
| International |  |  | 2,862 |  |  |  | 3,740 |  |
| Total |  | $ | 2,987 |  |  | $ | 3,899 |  |

[0001564590-19-043736:notes:190]
[same as prior period, unchanged from 0001564590-19-032574:notes:193]

[0001564590-19-043736:notes:191]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| U.S. |  | $ | 559 |  |  | $ | 572 |  |
| International |  |  | 187 |  |  |  | 187 |  |
| Total |  | $ | 746 |  |  | $ | 759 |  |

[0001564590-19-043736:notes:192]
[same as prior period, unchanged from 0001564590-19-032574:notes:195]

[0001564590-19-043736:notes:193]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2019 |  |  | October 26, 2018 |  |  | October 25, 2019 |  |  | October 26, 2018 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 24 | % |  |  | 24 | % |  |  | 23 | % |
| Tech Data Corporation |  |  | 21 | % |  |  | 21 | % |  |  | 21 | % |  |  | 19 | % |

[0001564590-19-043736:notes:194]
[same as prior period, unchanged from 0001564590-19-032574:notes:197]

[0001564590-19-043736:notes:195]
|  |  | October 25, 2019 |  |  | April 26, 2019 |  |
| Arrow Electronics, Inc. |  |  | 11 | % |  |  | 11 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 24 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-043736:notes:196]
16. Commitments and Contingencies

[0001564590-19-043736:notes:197]
Purchase Orders and Other Commitments

[0001564590-19-043736:notes:198]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of October 25, 2019, we had $447 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 25, 2019 and April 26, 2019, such liability amounted to $13 million and $16 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-19-043736:notes:199]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 25, 2019, we had $5 million in construction related obligations and $244 million in other purchase obligations.

[0001564590-19-043736:notes:200]
Financing Guarantees

[0001564590-19-043736:notes:201]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $34 million and $43 million of receivables during the six months ended October 25, 2019 and October 26, 2018, respectively.

[0001564590-19-043736:notes:202]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-19-043736:notes:203]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of October 25, 2019 and April 26, 2019, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-19-043736:notes:204]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 25, 2019, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-19-043736:notes:205]
Legal Contingencies

[0001564590-19-043736:notes:206]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-19-043736:notes:207]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. We believe the complaint is without merit and intend to defend the case vigorously.

[0001564590-19-043736:notes:208]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-19-043736:notes:209]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends.  No material accrual has been recorded as of October 25, 2019 related to such matters.
