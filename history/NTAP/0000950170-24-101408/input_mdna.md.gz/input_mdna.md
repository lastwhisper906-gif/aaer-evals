# NTAP MD&A — 0000950170-24-101408


## mdna

[0000950170-24-101408:mdna:1]
[same as prior period, unchanged from 0000950170-24-023115:mdna:1]

[0000950170-24-101408:mdna:2]
[same as prior period, unchanged from 0000950170-24-023115:mdna:2]

[0000950170-24-101408:mdna:3]
[same as prior period, unchanged from 0000950170-24-023115:mdna:3]

[0000950170-24-101408:mdna:4]
NetApp helps customers make their data infrastructure more seamless, more dynamic, and higher performing. We were incorporated in 1992 and are headquartered in San Jose, California. Building on over three decades of innovation, we combine unified data storage, integrated data services, and CloudOps solutions to make data infrastructure intelligent. Our broad portfolio addresses customer priorities: modernizing legacy infrastructure, improving resiliency against ransomware attacks, and building scalable, high-performance data pipelines for artificial intelligence (AI) workloads.

[0000950170-24-101408:mdna:5]
With NetApp, customers can better leverage their data to accelerate innovation, improve operations, and drive competitive advantage. Our unified data storage delivers flexibility to our customers, enabling them to simply and consistently store any data type and power any workload. As the only enterprise-grade storage service natively embedded in the world’s largest clouds, we power data across AWS, Microsoft Azure, and Google Cloud. Our integrated data services enable active data management, security, protection, governance, and sustainability. Finally, our CloudOps solutions enable adaptive operations across infrastructure, applications, and teams.

[0000950170-24-101408:mdna:6]
[same as prior period, unchanged from 0000950170-24-023115:mdna:6]

[0000950170-24-101408:mdna:7]
Hybrid Cloud offers a unified data storage portfolio of storage management and infrastructure solutions that help customers modernize their data centers. Our Hybrid Cloud portfolio supports structured and unstructured data with unified storage optimized for flash, disk, and cloud storage to handle data-intensive workloads and applications. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.

[0000950170-24-101408:mdna:8]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage and CloudOps services. These solutions and services are generally available on the leading public clouds, including Amazon AWS, Microsoft Azure, and Google Cloud Platform.

[0000950170-24-101408:mdna:9]
[same as prior period, unchanged from 0000950170-24-023115:mdna:15]

[0000950170-24-101408:mdna:10]
During the first three months of fiscal 2025, we repurchased approximately 3 million shares of our common stock at an average price of $120.46 per share, for an aggregate purchase price of $400 million. We also declared aggregate cash dividends of $0.52 per share in that period, for which we paid $107 million.

[0000950170-24-101408:mdna:11]
[same as prior period, unchanged from 0000950170-24-023115:mdna:17]

[0000950170-24-101408:mdna:12]
In the first quarter of fiscal 2025, management approved a restructuring plan to redirect resources to highest return activities and reduce costs. Aggregate charges recorded from the restructuring plan in the first three months of fiscal 2025 totaled $17 million.

[0000950170-24-101408:mdna:13]
[same as prior period, unchanged from 0000950170-24-023115:mdna:20]

[0000950170-24-101408:mdna:14]
Our fiscal year is reported as a 52- or 53-week year that ends on the last Friday in April. Fiscal years 2025 and 2024, ending on April 25, 2025 and April 26, 2024, respectively, are each 52-week years, with 13 weeks in each of their quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0000950170-24-101408:mdna:15]
[same as prior period, unchanged from 0000950170-24-023115:mdna:22]

[0000950170-24-101408:mdna:16]
|  |  | Three Months Ended |  |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  |
| Net revenues: |  |  |  |  |  |  |  |
| Product |  |  | 43 | % |  |  | 41 | % |  |
| Services |  |  | 57 |  |  |  | 59 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product |  |  | 17 |  |  |  | 19 |  |  |
| Cost of services |  |  | 11 |  |  |  | 12 |  |  |
| Gross profit |  |  | 71 |  |  |  | 70 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 31 |  |  |  | 33 |  |  |
| Research and development |  |  | 16 |  |  |  | 17 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | 1 |  |  |  | 2 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |
| Total operating expenses |  |  | 53 |  |  |  | 57 |  |  |
| Income from operations |  |  | 18 |  |  |  | 12 |  |  |
| Other income, net |  |  | 1 |  |  |  | 1 |  |  |
| Income before income taxes |  |  | 19 |  |  |  | 13 |  |  |
| Provision for income taxes |  |  | 3 |  |  |  | 3 |  |  |
| Net income |  |  | 16 | % |  |  | 10 | % |  |

[0000950170-24-101408:mdna:17]
[same as prior period, unchanged from 0000950170-24-023115:mdna:24]

[0000950170-24-101408:mdna:18]
[same as prior period, unchanged from 0000950170-24-023115:mdna:25]

[0000950170-24-101408:mdna:19]
[same as prior period, unchanged from 0000950170-24-023115:mdna:26]

[0000950170-24-101408:mdna:20]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  | % Change |  |
| Net revenues |  | $ | 1,541 |  |  | $ | 1,432 |  |  |  | 8 | % |

[0000950170-24-101408:mdna:21]
The increase in net revenues for the first quarter of fiscal 2025 compared to the corresponding period of fiscal 2024 was due to an increase in product revenues and, to a lesser extent, an increase in services revenues. Product revenues as a percentage of net revenues increased by two percentage points in the first quarter of fiscal 2025 compared to the corresponding period of fiscal 2024.

[0000950170-24-101408:mdna:22]
[same as prior period, unchanged from 0000950170-24-023115:mdna:29]

[0000950170-24-101408:mdna:23]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  | % Change |  |
| Product revenues |  | $ | 669 |  |  | $ | 590 |  |  |  | 13 | % |

[0000950170-24-101408:mdna:24]
[same as prior period, unchanged from 0000950170-24-023115:mdna:31]

[0000950170-24-101408:mdna:25]
In prior periods, we presented the hardware and software components of our GAAP product revenues to illustrate the significance and value of the Company’s software. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. Effective in fiscal 2025, we are no longer presenting the non-GAAP hardware and software components of our product revenues, as management no longer considers them to be key financial measures. The Company’s current strategy is expected to deliver investor value through growth in total revenues, including product revenues, while maintaining operational discipline to drive earnings leverage. While software continues to be the primary value driver of our products, NetApp is primarily focused on driving growth in total product revenues, through the sale of configured storage systems comprised of both hardware and software, with less focus on the pricing of each component. Additionally, the company is considering potential opportunities to simplify pricing for certain products in the future, which may eliminate the existence of separate prices for hardware and software components and/or impact our ability to allocate between them.

[0000950170-24-101408:mdna:26]
26

[0000950170-24-101408:mdna:27]
Product revenues are derived through the sale of our Hybrid Cloud solutions and consist of sales of configured all-flash array systems (including All-Flash FAS A-Series and All-Flash FAS C-Series with capacity flash) and hybrid systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, StorageGrid, OEM products, NetApp HCI and add-on optional software.

[0000950170-24-101408:mdna:28]
Total product revenues increased in the first quarter of fiscal 2025 compared to the corresponding period of the prior year due to higher sales of C-Series all-flash array systems.

[0000950170-24-101408:mdna:29]
[same as prior period, unchanged from 0000950170-24-023115:mdna:36]

[0000950170-24-101408:mdna:30]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  | % Change |  |
| Services revenues |  | $ | 872 |  |  | $ | 842 |  |  |  | 4 | % |
| Support |  |  | 631 |  |  |  | 611 |  |  |  | 3 | % |
| Professional and other services |  |  | 82 |  |  |  | 77 |  |  |  | 6 | % |
| Public cloud |  |  | 159 |  |  |  | 154 |  |  |  | 3 | % |

[0000950170-24-101408:mdna:31]
[same as prior period, unchanged from 0000950170-24-023115:mdna:38]

[0000950170-24-101408:mdna:32]
[same as prior period, unchanged from 0000950170-24-023115:mdna:39]

[0000950170-24-101408:mdna:33]
Support revenues increased in the first quarter of fiscal 2025 compared to the corresponding period of the prior year as a result of a higher aggregate support contract value for our installed base.

[0000950170-24-101408:mdna:34]
Professional and other services revenues increased by $5 million in the first quarter of fiscal 2025 compared to the corresponding period of the prior year.

[0000950170-24-101408:mdna:35]
[same as prior period, unchanged from 0000950170-24-023115:mdna:42]

[0000950170-24-101408:mdna:36]
Public Cloud revenues are derived from the sale of public cloud offerings delivered primarily as-a-service, which include cloud storage and CloudOps services.

[0000950170-24-101408:mdna:37]
Public Cloud revenues increased in the first quarter of fiscal 2025 compared to the corresponding period of the prior year, due to higher customer demand, driven by NetApp’s diversified cloud offerings and an overall growth in the cloud market.

[0000950170-24-101408:mdna:38]
[same as prior period, unchanged from 0000950170-24-023115:mdna:45]

[0000950170-24-101408:mdna:39]
[same as prior period, unchanged from 0000950170-24-023115:mdna:46]

[0000950170-24-101408:mdna:40]
(1) cost of product revenues, composed of (a) cost of Hybrid Cloud product revenues, which includes the costs of manufacturing and shipping our products, inventory write-downs, and warranty costs, and (b) unallocated cost of product revenues, which includes stock-based compensation, and;

[0000950170-24-101408:mdna:41]
[same as prior period, unchanged from 0000950170-24-023115:mdna:49]

[0000950170-24-101408:mdna:42]
[same as prior period, unchanged from 0000950170-24-023115:mdna:50]

[0000950170-24-101408:mdna:43]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  | % Change |  |
| Cost of product revenues |  | $ | 269 |  |  | $ | 265 |  |  |  | 2 | % |
| Hybrid Cloud |  |  | 268 |  |  |  | 264 |  |  |  | 2 | % |
| Unallocated |  |  | 1 |  |  |  | 1 |  |  |  | — | % |

[0000950170-24-101408:mdna:44]
[same as prior period, unchanged from 0000950170-24-023115:mdna:52]

[0000950170-24-101408:mdna:45]
Cost of Hybrid Cloud product revenues represented approximately 40% of product revenues for the first quarter of fiscal 2025 compared to 45% for the corresponding period of fiscal 2024. Materials costs represented 88% of cost of Hybrid Cloud product revenues for both the first quarter of fiscal 2025 and for the corresponding period of fiscal 2024.

[0000950170-24-101408:mdna:46]
Materials costs increased by $4 million in the first quarter of fiscal 2025 compared to the corresponding period of the prior year.

[0000950170-24-101408:mdna:47]
Hybrid Cloud product gross margins increased by approximately five percentage points in the first quarter of fiscal 2025 compared to the corresponding period of the prior year, due to lower component and freight costs.

[0000950170-24-101408:mdna:48]
[same as prior period, unchanged from 0000950170-24-023115:mdna:56]

[0000950170-24-101408:mdna:49]
Unallocated cost of product revenues were relatively flat in the first quarter of fiscal 2025 compared to the corresponding period of the prior year.

[0000950170-24-101408:mdna:50]
[same as prior period, unchanged from 0000950170-24-023115:mdna:58]

[0000950170-24-101408:mdna:51]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  | % Change |  |
| Cost of services revenues |  | $ | 174 |  |  | $ | 171 |  |  |  | 2 | % |
| Support |  |  | 50 |  |  |  | 47 |  |  |  | 6 | % |
| Professional and other services |  |  | 64 |  |  |  | 58 |  |  |  | 10 | % |
| Public cloud |  |  | 46 |  |  |  | 51 |  |  |  | (10 | )% |
| Unallocated |  |  | 14 |  |  |  | 15 |  |  |  | (7 | )% |

[0000950170-24-101408:mdna:52]
[same as prior period, unchanged from 0000950170-24-023115:mdna:60]

[0000950170-24-101408:mdna:53]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, increased in the first quarter of fiscal 2025 compared to the corresponding period of fiscal 2024. Cost of Hybrid Cloud services revenues represented approximately 16% of Hybrid Cloud services revenues in the first quarter of fiscal 2025 compared to 15% for the corresponding period of fiscal 2024.

[0000950170-24-101408:mdna:54]
Hybrid Cloud support gross margins were relatively flat in the first quarter of fiscal 2025 compared to the corresponding period of the prior year. Hybrid Cloud professional and other services gross margins decreased by approximately three percentage points in the first quarter of fiscal 2025 compared to the corresponding period of fiscal 2024 due to the mix of services provided.

[0000950170-24-101408:mdna:55]
[same as prior period, unchanged from 0000950170-24-023115:mdna:64]

[0000950170-24-101408:mdna:56]
Cost of Public Cloud revenues decreased, and Public Cloud gross margins increased by four percentage points, in the first quarter of fiscal 2025 compared to the corresponding period of fiscal 2024, due to cost optimization that included a decrease in fixed assets depreciation.

[0000950170-24-101408:mdna:57]
[same as prior period, unchanged from 0000950170-24-023115:mdna:66]

[0000950170-24-101408:mdna:58]
Unallocated cost of services revenues decreased in the first quarter of fiscal 2025 compared to the corresponding period of the prior year due to certain intangible assets becoming fully amortized during the first quarter of fiscal 2024.

[0000950170-24-101408:mdna:59]
[same as prior period, unchanged from 0000950170-24-023115:mdna:68]

[0000950170-24-101408:mdna:60]
[same as prior period, unchanged from 0000950170-24-023115:mdna:69]

[0000950170-24-101408:mdna:61]
Sales and marketing, research and development, and general and administrative expenses for the first quarter of fiscal 2025 totaled $798 million, or 52% of net revenues, reflecting a decrease of three percentage points, compared to the corresponding period of fiscal 2024, due to the increase in net revenues.

[0000950170-24-101408:mdna:62]
[same as prior period, unchanged from 0000950170-24-023115:mdna:72]

[0000950170-24-101408:mdna:63]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses, totaling $499 million in the first quarter of fiscal 2025, were relatively flat compared to the corresponding period of the prior year.

[0000950170-24-101408:mdna:64]
28

[0000950170-24-101408:mdna:65]
[same as prior period, unchanged from 0000950170-24-023115:mdna:74]

[0000950170-24-101408:mdna:66]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 471 |  |  | $ | 468 |  |  |  | 1 | % |

[0000950170-24-101408:mdna:67]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, facilities and IT support costs, advertising and marketing promotional expense and travel and entertainment expense.

[0000950170-24-101408:mdna:68]
Sales and marketing expenses remained relatively flat in the first quarter of fiscal 2025 compared to the corresponding period of the prior year.

[0000950170-24-101408:mdna:69]
[same as prior period, unchanged from 0000950170-24-023115:mdna:79]

[0000950170-24-101408:mdna:70]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  | % Change |  |
| Research and development expenses |  | $ | 252 |  |  | $ | 247 |  |  |  | 2 | % |

[0000950170-24-101408:mdna:71]
Research and development expenses consist primarily of compensation costs, facilities and IT support costs, depreciation, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs.

[0000950170-24-101408:mdna:72]
The increase in Research and Development expenses consisted of the following (in percentage points of the total change):

[0000950170-24-101408:mdna:73]
|  |  | Three Months Ended |  |
|  |  | Fiscal 2025 to Fiscal 2024 |  |
| Compensation costs |  |  | 1 |  |
| Facilities and IT support costs |  |  | 1 |  |
| Total change |  |  | 2 |  |

[0000950170-24-101408:mdna:74]
[same as prior period, unchanged from 0000950170-24-023115:mdna:85]

[0000950170-24-101408:mdna:75]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  | % Change |  |
| General and administrative expenses |  | $ | 75 |  |  | $ | 74 |  |  |  | 1 | % |

[0000950170-24-101408:mdna:76]
[same as prior period, unchanged from 0000950170-24-023115:mdna:87]

[0000950170-24-101408:mdna:77]
General and administrative expenses remained relatively flat in the first quarter of fiscal 2025 compared to the corresponding period of the prior year.

[0000950170-24-101408:mdna:78]
[same as prior period, unchanged from 0000950170-24-023115:mdna:89]

[0000950170-24-101408:mdna:79]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  | % Change |  |
| Restructuring charges |  | $ | 17 |  |  | $ | 26 |  |  |  | (35 | )% |

[0000950170-24-101408:mdna:80]
In the first quarter of fiscal 2025, management approved and initiated a restructuring plan to redirect resources to highest return activities and reduce costs, which included a reduction of our global workforce by approximately 2%. Charges related to the plan consisted primarily of employee severance-related costs. The activities under the plan are expected to be substantially complete by the second quarter of fiscal 2025.

[0000950170-24-101408:mdna:81]
In the first quarter of fiscal 2024, management approved and initiated a restructuring plan to redirect resources to highest return activities, and to optimize our global office space for our hybrid work model. In connection with the plan, we reduced our global workforce by approximately 1% and terminated certain real estate leases in various countries, resulting in restructuring charges comprised primarily of employee severance-related expenses and lease termination charges. The workforce-related activities under the plan were substantially completed by the end of fiscal 2024.

[0000950170-24-101408:mdna:82]
[same as prior period, unchanged from 0000950170-24-023115:mdna:47]

[0000950170-24-101408:mdna:83]
[same as prior period, unchanged from 0000950170-24-023115:mdna:92]

[0000950170-24-101408:mdna:84]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  | % Change |  |
| Acquisition-related expense |  | $ | 1 |  |  | $ | 3 |  |  |  | (67 | )% |

[0000950170-24-101408:mdna:85]
Acquisition-related expenses decreased by $2 million in the first quarter of fiscal 2025 compared to the corresponding period of the prior year.

[0000950170-24-101408:mdna:86]
[same as prior period, unchanged from 0000950170-24-023115:mdna:95]

[0000950170-24-101408:mdna:87]
[same as prior period, unchanged from 0000950170-24-023115:mdna:96]

[0000950170-24-101408:mdna:88]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  | % Change |  |
| Interest income |  | $ | 36 |  |  | $ | 28 |  |  |  | 29 | % |
| Interest expense |  |  | (16 | ) |  |  | (16 | ) |  |  | — | % |
| Other, net |  |  | (3 | ) |  |  | (4 | ) |  | NM |  |
| Total |  | $ | 17 |  |  | $ | 8 |  |  | NM |  |

[0000950170-24-101408:mdna:89]
[same as prior period, unchanged from 0000950170-24-023115:mdna:98]

[0000950170-24-101408:mdna:90]
Interest income increased in the first quarter of fiscal 2025 compared to the corresponding periods of the prior year, primarily due to higher yields earned on our cash and investments. Interest expense was relatively flat in the first quarter of fiscal 2025 compared to the corresponding period of fiscal 2024.

[0000950170-24-101408:mdna:91]
[same as prior period, unchanged from 0000950170-24-023115:mdna:101]

[0000950170-24-101408:mdna:92]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  | % Change |  |
| Provision for income taxes |  | $ | 51 |  |  | $ | 37 |  |  |  | 38 | % |

[0000950170-24-101408:mdna:93]
Our effective tax rate for the three months ended July 26, 2024 includes an increase in discrete tax benefits related to stock compensation compared to the corresponding period of the prior year. Our effective tax rate for the three months ended July 28, 2023 included a benefit for increased fiscal 2023 foreign tax credits resulting from new IRS guidance released during the first quarter of fiscal 2024, partially offset by an increase in stock compensation for which no tax benefit is recorded.

[0000950170-24-101408:mdna:94]
As of July 26, 2024, we had $221 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $158 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $157 million have been recorded in other long-term liabilities.

[0000950170-24-101408:mdna:95]
[same as prior period, unchanged from 0000950170-24-023115:mdna:108]

[0000950170-24-101408:mdna:96]
| (In millions) |  | July 26, 2024 |  |  | April 26, 2024 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,017 |  |  | $ | 3,252 |  |
| Principal amount of debt |  | $ | 2,400 |  |  | $ | 2,400 |  |

[0000950170-24-101408:mdna:97]
[same as prior period, unchanged from 0000950170-24-023115:mdna:110]

[0000950170-24-101408:mdna:98]
|  |  | Three Months Ended |  |
| (In millions) |  | July 26, 2024 |  |  | July 28, 2023 |  |
| Net cash provided by operating activities |  | $ | 341 |  |  | $ | 453 |  |
| Net cash used in investing activities |  |  | (51 | ) |  |  | (228 | ) |
| Net cash used in financing activities |  |  | (548 | ) |  |  | (521 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 8 |  |  |  | — |  |
| Net change in cash, cash equivalents and restricted cash |  | $ | (250 | ) |  | $ | (296 | ) |

[0000950170-24-101408:mdna:99]
[same as prior period, unchanged from 0000950170-24-023115:mdna:112]

[0000950170-24-101408:mdna:100]
As of July 26, 2024, our cash, cash equivalents and short-term investments were $3.0 billion, which represents a decrease of $235 million during the first three months of fiscal 2025. The decrease was primarily due to $400 million used for the repurchase of our common stock, $107 million used for the payment of dividends and $41 million used for purchases of property and equipment, partially offset by $341 million provided by operating activities. Our net working capital deficit was $191 million as of July 26, 2024, a reduction of $982 million when compared to April 26, 2024, primarily due to the decrease in cash, cash equivalents and short-term investments discussed above and the reclassification of $750 million principal amount of our senior notes from long-term to current liabilities.

[0000950170-24-101408:mdna:101]
[same as prior period, unchanged from 0000950170-24-023115:mdna:114]

[0000950170-24-101408:mdna:102]
During the first three months of fiscal 2025, we generated cash from operating activities of $341 million, reflecting net income of $248 million which was increased by non-cash depreciation and amortization expense of $63 million and non-cash stock-based compensation expense of $85 million, compared to $453 million of cash generated from operating activities during the first three months of fiscal 2024.

[0000950170-24-101408:mdna:103]
Significant changes in assets and liabilities in the first three months of fiscal 2025 included the following:

[0000950170-24-101408:mdna:104]
•
Accounts receivable decreased $335 million, reflecting lower billings and more favorable invoicing linearity in the first three months of fiscal 2025 compared to the last three months of fiscal 2024.

[0000950170-24-101408:mdna:105]
•
Accrued expenses decreased by $221 million, primarily due to employee compensation payouts related to fiscal year 2024 incentive compensation and commissions plans.

[0000950170-24-101408:mdna:106]
•
Deferred revenue and financed unearned services revenue decreased by $92 million, due to a decrease in deferred revenue for software and hardware support contracts.

[0000950170-24-101408:mdna:107]
[same as prior period, unchanged from 0000950170-24-023115:mdna:119]

[0000950170-24-101408:mdna:108]
[same as prior period, unchanged from 0000950170-24-023115:mdna:120]

[0000950170-24-101408:mdna:109]
During the first three months of fiscal 2025, we used $10 million for the purchases of investments, net of maturities and sales, and paid $41 million for capital expenditures, as compared to the same period of fiscal 2024, in which we used $192 million for the purchases of investments, net of maturities and sales, and paid $35 million for capital expenditures.

[0000950170-24-101408:mdna:110]
[same as prior period, unchanged from 0000950170-24-023115:mdna:122]

[0000950170-24-101408:mdna:111]
During the first three months of fiscal 2025, cash flows used in financing activities totaled $548 million and included $400 million for the repurchase of approximately 3 million shares of common stock and $107 million for the payment of dividends. During the first three months of fiscal 2024, cash flows used in financing activities totaled $521 million and included $400 million for the repurchase of approximately 5 million shares of common stock and $106 million for the payment of dividends.

[0000950170-24-101408:mdna:112]
[same as prior period, unchanged from 0000950170-24-023115:mdna:124]

[0000950170-24-101408:mdna:113]
31

[0000950170-24-101408:mdna:114]
[same as prior period, unchanged from 0000950170-24-023115:mdna:125]

[0000950170-24-101408:mdna:115]
Our principal sources of liquidity as of July 26, 2024 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-24-101408:mdna:116]
[same as prior period, unchanged from 0000950170-24-023115:mdna:127]

[0000950170-24-101408:mdna:117]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| Cash and cash equivalents |  | $ | 1,652 |  |  | $ | 1,903 |  |
| Short-term investments |  |  | 1,365 |  |  |  | 1,349 |  |
| Total |  | $ | 3,017 |  |  | $ | 3,252 |  |

[0000950170-24-101408:mdna:118]
As of July 26, 2024 and April 26, 2024, $2.3 billion and $2.1 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.7 billion and $1.2 billion, respectively, were available in the U.S.

[0000950170-24-101408:mdna:119]
[same as prior period, unchanged from 0000950170-24-023115:mdna:130]

[0000950170-24-101408:mdna:120]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of July 26, 2024.

[0000950170-24-101408:mdna:121]
[same as prior period, unchanged from 0000950170-24-023115:mdna:133]

[0000950170-24-101408:mdna:122]
[same as prior period, unchanged from 0000950170-24-023115:mdna:134]

[0000950170-24-101408:mdna:123]
The following table summarizes the principal amount of our Senior Notes as of July 26, 2024 (in millions):

[0000950170-24-101408:mdna:124]
|  |  | Amount |  |
| 3.30% Senior Notes Due September 2024 |  | $ | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,400 |  |

[0000950170-24-101408:mdna:125]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 6 – Financing Arrangements of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1.

[0000950170-24-101408:mdna:126]
Commercial Paper Program and Credit Facility

[0000950170-24-101408:mdna:127]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of July 26, 2024.

[0000950170-24-101408:mdna:128]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of July 26, 2024, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-24-101408:mdna:129]
[same as prior period, unchanged from 0000950170-24-023115:mdna:141]

[0000950170-24-101408:mdna:130]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2025 to be between $100 million and $150 million.

[0000950170-24-101408:mdna:131]
[same as prior period, unchanged from 0000950170-24-023115:mdna:143]

[0000950170-24-101408:mdna:132]
The Tax Cuts and Jobs Act of 2017 imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits that had not previously been subject to U.S. income tax. As of July 26, 2024, outstanding payments related to the transition tax are estimated to be approximately $215 million of which $115 million and $100 million are expected to be paid during fiscal 2025 and fiscal 2026, respectively. Our estimates for future transition tax payments, however, could change with further guidance or review from U.S. federal and state tax authorities or other regulatory bodies.

[0000950170-24-101408:mdna:133]
[same as prior period, unchanged from 0000950170-24-023115:mdna:145]

[0000950170-24-101408:mdna:134]
On August 22, 2024, we declared a cash dividend of $0.52 per share of common stock, payable on October 23, 2024, to holders of record as of the close of business on October 4, 2024.

[0000950170-24-101408:mdna:135]
As of July 26, 2024, our Board of Directors had authorized the repurchase of up to $17.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through July 26, 2024, we repurchased a total of 375 million shares of our common stock at an average price of $42.73 per share, for an aggregate purchase price of $16 billion. As of July 26, 2024, the remaining authorized amount for stock repurchases under this program was $1.1 billion.

[0000950170-24-101408:mdna:136]
[same as prior period, unchanged from 0000950170-24-023115:mdna:148]

[0000950170-24-101408:mdna:137]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled approximately $1.1 billion at July 26, 2024.

[0000950170-24-101408:mdna:138]
33

[0000950170-24-101408:mdna:139]
[same as prior period, unchanged from 0000950170-24-023115:mdna:150]

[0000950170-24-101408:mdna:140]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $19 million of receivables in each of the first three months of fiscal 2025 and fiscal 2024.

[0000950170-24-101408:mdna:141]
[same as prior period, unchanged from 0000950170-24-023115:mdna:152]

[0000950170-24-101408:mdna:142]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of July 26, 2024 and April 26, 2024, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-24-101408:mdna:143]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of July 26, 2024, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-24-101408:mdna:144]
Legal Contingencies

[0000950170-24-101408:mdna:145]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 14 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1.

[0000950170-24-101408:mdna:146]
[same as prior period, unchanged from 0000950170-24-023115:mdna:157]

[0000950170-24-101408:mdna:147]
There have been no material changes to our critical accounting policies and estimates as described in our 2024 Annual Report on Form 10-K.
