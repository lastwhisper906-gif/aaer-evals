# NTAP notes — 0000950170-24-101408


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000950170-24-101408:notes:1]
[same as prior period, unchanged from 0000950170-24-023115:notes:1]

[0000950170-24-101408:notes:2]
[same as prior period, unchanged from 0000950170-24-023115:notes:2]

[0000950170-24-101408:notes:3]
[same as prior period, unchanged from 0000950170-24-023115:notes:3]

[0000950170-24-101408:notes:4]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal years 2025 and 2024, ending on April 25, 2025 and April 26, 2024, respectively, are each 52-week years, with 13 weeks in each quarter.

[0000950170-24-101408:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 26, 2024 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 26, 2024 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0000950170-24-101408:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, the anticipated effects of which have been incorporated, as applicable, into management's estimates as of July 26, 2024.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000950170-24-101408:notes:7]
2. Recent Accounting Pronouncements

[0000950170-24-101408:notes:8]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which expands the disclosures required for income taxes. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The amendment should be applied on a prospective basis while retrospective application is permitted. We are currently evaluating the effect of this pronouncement on our income tax disclosures.

[0000950170-24-101408:notes:9]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires disclosure of incremental segment information on an annual and interim basis. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024 on a retrospective basis. We will adopt the new requirements for our annual periods starting in fiscal 2025 (and interim periods thereafter). We are currently evaluating the effect of this pronouncement, which we expect to result in enhanced financial statement disclosures only.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-24-101408:notes:10]
3. Goodwill and Purchased Intangible Assets, Net

[0000950170-24-101408:notes:11]
Goodwill by reportable segment as of July 26, 2024 is as follows (in millions):

[0000950170-24-101408:notes:12]
[same as prior period, unchanged from 0000950170-24-023115:notes:22]

[0000950170-24-101408:notes:13]
[same as prior period, unchanged from 0000950170-24-023115:notes:23]

[0000950170-24-101408:notes:14]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 163 |  |  | $ | (101 | ) |  | $ | 62 |  |  | $ | 179 |  |  | $ | (108 | ) |  | $ | 71 |  |
| Customer contracts/relationships |  |  | 108 |  |  |  | (61 | ) |  |  | 47 |  |  |  | 114 |  |  |  | (62 | ) |  |  | 52 |  |
| Other purchased intangibles |  |  | 3 |  |  |  | (2 | ) |  |  | 1 |  |  |  | 6 |  |  |  | (5 | ) |  |  | 1 |  |
| Total purchased intangible assets |  | $ | 274 |  |  | $ | (164 | ) |  | $ | 110 |  |  | $ | 299 |  |  | $ | (175 | ) |  | $ | 124 |  |

[0000950170-24-101408:notes:15]
During the first three months of fiscal 2025, we retired approximately $25 million of fully amortized intangible assets.

[0000950170-24-101408:notes:16]
[same as prior period, unchanged from 0000950170-24-023115:notes:26]

[0000950170-24-101408:notes:17]
|  |  | Three Months Ended |  |  | Statements of |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  | IncomeClassification |
| Developed technology |  | $ | 8 |  |  | $ | 9 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 6 |  |  |  | 5 |  |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | 1 |  |  | Operating expenses |
| Total |  | $ | 14 |  |  | $ | 15 |  |  |  |

[0000950170-24-101408:notes:18]
As of July 26, 2024, future amortization expense related to purchased intangible assets is as follows (in millions):

[0000950170-24-101408:notes:19]
| Fiscal Year |  | Amount |  |
| 2025 (remainder) |  | $ | 41 |  |
| 2026 |  |  | 39 |  |
| 2027 |  |  | 29 |  |
| 2028 |  |  | 1 |  |
| Total |  | $ | 110 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-24-101408:notes:20]
4. Supplemental Financial Information

[0000950170-24-101408:notes:21]
[same as prior period, unchanged from 0000950170-24-023115:notes:31]

[0000950170-24-101408:notes:22]
[same as prior period, unchanged from 0000950170-24-023115:notes:32]

[0000950170-24-101408:notes:23]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| Cash and cash equivalents |  | $ | 1,652 |  |  | $ | 1,903 |  |
| Restricted cash |  |  | 7 |  |  |  | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 1,659 |  |  | $ | 1,909 |  |

[0000950170-24-101408:notes:24]
[same as prior period, unchanged from 0000950170-24-023115:notes:34]

[0000950170-24-101408:notes:25]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| Purchased components |  | $ | 166 |  |  | $ | 116 |  |
| Finished goods |  |  | 48 |  |  |  | 70 |  |
| Inventories |  | $ | 214 |  |  | $ | 186 |  |

[0000950170-24-101408:notes:26]
[same as prior period, unchanged from 0000950170-24-023115:notes:36]

[0000950170-24-101408:notes:27]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 370 |  |  |  | 367 |  |
| Leasehold improvements |  |  | 83 |  |  |  | 81 |  |
| Computer, production, engineering and other equipment |  |  | 1,120 |  |  |  | 1,101 |  |
| Computer software |  |  | 344 |  |  |  | 340 |  |
| Furniture and fixtures |  |  | 77 |  |  |  | 77 |  |
| Construction-in-progress |  |  | 66 |  |  |  | 70 |  |
|  |  |  | 2,106 |  |  |  | 2,082 |  |
| Accumulated depreciation and amortization |  |  | (1,512 | ) |  |  | (1,478 | ) |
| Property and equipment, net |  | $ | 594 |  |  | $ | 604 |  |

[0000950170-24-101408:notes:28]
[same as prior period, unchanged from 0000950170-24-023115:notes:38]

[0000950170-24-101408:notes:29]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| Deferred tax assets |  | $ | 913 |  |  | $ | 896 |  |
| Operating lease right-of-use (ROU) assets |  |  | 241 |  |  |  | 247 |  |
| Other assets |  |  | 373 |  |  |  | 360 |  |
| Other non-current assets |  | $ | 1,527 |  |  | $ | 1,503 |  |

[0000950170-24-101408:notes:30]
Other non-current assets as of both July 26, 2024 and April 26, 2024 include $85 million for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies.

[0000950170-24-101408:notes:31]
[same as prior period, unchanged from 0000950170-24-023115:notes:41]

[0000950170-24-101408:notes:32]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| Accrued compensation and benefits |  | $ | 346 |  |  | $ | 538 |  |
| Product warranty liabilities |  |  | 18 |  |  |  | 18 |  |
| Operating lease liabilities |  |  | 39 |  |  |  | 40 |  |
| Other current liabilities |  |  | 390 |  |  |  | 417 |  |
| Accrued expenses |  | $ | 793 |  |  | $ | 1,013 |  |

[0000950170-24-101408:notes:33]
[same as prior period, unchanged from 0000950170-24-023115:notes:43]

[0000950170-24-101408:notes:34]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| Liability for uncertain tax positions |  | $ | 157 |  |  | $ | 153 |  |
| Income taxes payable |  |  | 100 |  |  |  | 100 |  |
| Product warranty liabilities |  |  | 9 |  |  |  | 9 |  |
| Operating lease liabilities |  |  | 216 |  |  |  | 220 |  |
| Other liabilities |  |  | 108 |  |  |  | 103 |  |
| Other long-term liabilities |  | $ | 590 |  |  | $ | 585 |  |

[0000950170-24-101408:notes:35]
[same as prior period, unchanged from 0000950170-24-023115:notes:45]

[0000950170-24-101408:notes:36]
[same as prior period, unchanged from 0000950170-24-023115:notes:46]

[0000950170-24-101408:notes:37]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| Deferred product revenue |  | $ | 57 |  |  | $ | 59 |  |
| Deferred services revenue |  |  | 4,065 |  |  |  | 4,123 |  |
| Financed unearned services revenue |  |  | 47 |  |  |  | 52 |  |
| Total |  | $ | 4,169 |  |  | $ | 4,234 |  |
| Reported as: |  |  |  |  |  |  |
| Short-term |  | $ | 2,133 |  |  | $ | 2,176 |  |
| Long-term |  |  | 2,036 |  |  |  | 2,058 |  |
| Total |  | $ | 4,169 |  |  | $ | 4,234 |  |

[0000950170-24-101408:notes:38]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 14 – Commitments and Contingencies for additional information related to these arrangements.

[0000950170-24-101408:notes:39]
During the three months ended July 26, 2024 and July 28, 2023, we recognized revenue of $670 million and $658 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0000950170-24-101408:notes:40]
Remaining performance obligations

[0000950170-24-101408:notes:41]
As of July 26, 2024, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $4.5 billion. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our remaining performance obligations in the next 12 months and the remainder thereafter.

[0000950170-24-101408:notes:42]
[same as prior period, unchanged from 0000950170-24-023115:notes:52]

[0000950170-24-101408:notes:43]
[same as prior period, unchanged from 0000950170-24-023115:notes:53]

[0000950170-24-101408:notes:44]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| Other current assets |  | $ | 68 |  |  | $ | 69 |  |
| Other non-current assets |  |  | 99 |  |  |  | 100 |  |
| Total deferred commissions |  | $ | 167 |  |  | $ | 169 |  |

[0000950170-24-101408:notes:45]
[same as prior period, unchanged from 0000950170-24-023115:notes:55]

[0000950170-24-101408:notes:46]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |
| Interest income |  | $ | 36 |  |  | $ | 28 |  |
| Interest expense |  |  | (16 | ) |  |  | (16 | ) |
| Other, net |  |  | (3 | ) |  |  | (4 | ) |
| Total other income, net |  | $ | 17 |  |  | $ | 8 |  |

[0000950170-24-101408:notes:47]
[same as prior period, unchanged from 0000950170-24-023115:notes:58]

[0000950170-24-101408:notes:48]
Supplemental cash flow information related to our operating leases is included in Note 7 ─ Leases. Non-cash investing activities and other supplemental cash flow information are presented below:

[0000950170-24-101408:notes:49]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 13 |  |  | $ | 21 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 21 |  |  | $ | 9 |  |
| Interest paid |  | $ | 23 |  |  | $ | 23 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-24-101408:notes:50]
5. Financial Instruments and Fair Value Measurements

[0000950170-24-101408:notes:51]
[same as prior period, unchanged from 0000950170-24-023115:notes:62]

[0000950170-24-101408:notes:52]
[same as prior period, unchanged from 0000950170-24-023115:notes:63]

[0000950170-24-101408:notes:53]
[same as prior period, unchanged from 0000950170-24-023115:notes:64]

[0000950170-24-101408:notes:54]
[same as prior period, unchanged from 0000950170-24-023115:notes:65]

[0000950170-24-101408:notes:55]
[same as prior period, unchanged from 0000950170-24-023115:notes:66]

[0000950170-24-101408:notes:56]
[same as prior period, unchanged from 0000950170-24-023115:notes:67]

[0000950170-24-101408:notes:57]
The following is a summary of our investments at their cost or amortized cost as of July 26, 2024 and April 26, 2024 (in millions):

[0000950170-24-101408:notes:58]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| U.S. Treasury and government debt securities |  | $ | 1,501 |  |  | $ | 1,349 |  |
| Money market funds |  |  | 692 |  |  |  | 1,161 |  |
| Certificates of deposit |  |  | 34 |  |  |  | 12 |  |
| Mutual funds |  |  | 43 |  |  |  | 38 |  |
| Total debt and equity securities |  | $ | 2,270 |  |  | $ | 2,560 |  |

[0000950170-24-101408:notes:59]
[same as prior period, unchanged from 0000950170-24-023115:notes:70]

[0000950170-24-101408:notes:60]
As of July 26, 2024, all our debt investments are due to mature in one year or less.

[0000950170-24-101408:notes:61]
[same as prior period, unchanged from 0000950170-24-023115:notes:72]

[0000950170-24-101408:notes:62]
[same as prior period, unchanged from 0000950170-24-023115:notes:73]

[0000950170-24-101408:notes:63]
|  |  | July 26, 2024 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 790 |  |  | $ | 790 |  |  | $ | — |  |
| Money market funds |  |  | 692 |  |  |  | 692 |  |  |  | — |  |
| Certificates of deposit |  |  | 34 |  |  |  | — |  |  |  | 34 |  |
| U.S. Treasury and government debt securities |  |  | 136 |  |  |  | 136 |  |  |  | — |  |
| Total cash and cash equivalents |  |  | 1,652 |  |  |  | 1,618 |  |  |  | 34 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 1,365 |  |  |  | 1,365 |  |  |  | — |  |
| Total short-term investments |  |  | 1,365 |  |  |  | 1,365 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,017 |  |  | $ | 2,983 |  |  | $ | 34 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 36 |  |  | $ | 36 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0000950170-24-101408:notes:64]
|  |  | April 26, 2024 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 730 |  |  | $ | 730 |  |  | $ | — |  |
| Money market funds |  |  | 1,161 |  |  |  | 1,161 |  |  |  | — |  |
| Certificates of deposit |  |  | 12 |  |  |  | — |  |  |  | 12 |  |
| Total cash and cash equivalents |  |  | 1,903 |  |  |  | 1,891 |  |  |  | 12 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 1,349 |  |  |  | 1,349 |  |  |  | — |  |
| Total short-term investments |  |  | 1,349 |  |  |  | 1,349 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,252 |  |  | $ | 3,240 |  |  | $ | 12 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 32 |  |  | $ | 32 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (13 | ) |  | $ | — |  |  | $ | (13 | ) |

[0000950170-24-101408:notes:65]
[same as prior period, unchanged from 0000950170-24-023115:notes:76]

[0000950170-24-101408:notes:66]
[same as prior period, unchanged from 0000950170-24-023115:notes:77]

[0000950170-24-101408:notes:67]
[same as prior period, unchanged from 0000950170-24-023115:notes:78]

[0000950170-24-101408:notes:68]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of July 26, 2024 and April 26, 2024, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0000950170-24-101408:notes:69]
[same as prior period, unchanged from 0000950170-24-023115:notes:80]

[0000950170-24-101408:notes:70]
As of July 26, 2024 and April 26, 2024, the fair value of our long-term debt, which includes the current portion of long-term debt, was approximately $2,254 million and $2,209 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0000950170-24-101408:notes:71]
6. Financing Arrangements

[0000950170-24-101408:notes:72]
Long-Term Debt

[0000950170-24-101408:notes:73]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0000950170-24-101408:notes:74]
|  |  | Effective Interest Rate |  | July 26, 2024 |  |  | April 26, 2024 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  | $ | 400 |  |  | $ | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,400 |  |  |  | 2,400 |  |
| Unamortized discount and issuance costs |  |  |  |  | (7 | ) |  |  | (8 | ) |
| Total senior notes |  |  |  |  | 2,393 |  |  |  | 2,392 |  |
| Less: Current portion of long-term debt |  |  |  |  | (1,149 | ) |  |  | (400 | ) |
| Total long-term debt |  |  |  | $ | 1,244 |  |  | $ | 1,992 |  |

[0000950170-24-101408:notes:75]
Senior Notes

[0000950170-24-101408:notes:76]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were each issued in June 2020. Interest on each of these Senior Notes is payable semi-annually in June and December. Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September.

[0000950170-24-101408:notes:77]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0000950170-24-101408:notes:78]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 26, 2024, we were in compliance with all covenants associated with the Senior Notes.

[0000950170-24-101408:notes:79]
As of July 26, 2024, our aggregate future principal debt maturities are as follows (in millions):

[0000950170-24-101408:notes:80]
| Fiscal Year |  | Amount |  |
| 2025 (remainder) |  | $ | 400 |  |
| 2026 |  |  | 750 |  |
| 2027 |  |  | — |  |
| 2028 |  |  | 550 |  |
| 2029 |  |  | — |  |
| Thereafter |  |  | 700 |  |
| Total |  | $ | 2,400 |  |

[0000950170-24-101408:notes:81]
Commercial Paper Program and Credit Facility

[0000950170-24-101408:notes:82]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of July 26, 2024 or April 26, 2024.

[0000950170-24-101408:notes:83]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of July 26, 2024, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0000950170-24-101408:notes:84]
7. Leases

[0000950170-24-101408:notes:85]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of July 26, 2024, have remaining lease terms not exceeding 18 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of July 26, 2024, have remaining lease terms not exceeding 4 years. As of July 26, 2024, our automobile leases have remaining lease terms not exceeding 4 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0000950170-24-101408:notes:86]
[same as prior period, unchanged from 0000950170-24-023115:notes:97]

[0000950170-24-101408:notes:87]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |
| Operating lease cost |  | $ | 13 |  |  | $ | 14 |  |
| Variable lease cost |  |  | 4 |  |  |  | 4 |  |
| Total lease cost |  | $ | 17 |  |  | $ | 18 |  |

[0000950170-24-101408:notes:88]
[same as prior period, unchanged from 0000950170-24-023115:notes:99]

[0000950170-24-101408:notes:89]
[same as prior period, unchanged from 0000950170-24-023115:notes:100]

[0000950170-24-101408:notes:90]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 12 |  |  | $ | 14 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  | $ | 3 |  |  | $ | 9 |  |

[0000950170-24-101408:notes:91]
[same as prior period, unchanged from 0000950170-24-023115:notes:102]

[0000950170-24-101408:notes:92]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| Other non-current assets |  | $ | 241 |  |  | $ | 247 |  |
| Total operating lease ROU assets |  | $ | 241 |  |  | $ | 247 |  |
| Accrued expenses |  | $ | 39 |  |  | $ | 40 |  |
| Other long-term liabilities |  |  | 216 |  |  |  | 220 |  |
| Total operating lease liabilities |  | $ | 255 |  |  | $ | 260 |  |
| Weighted Average Remaining Lease Term |  | 9.0 years |  |  | 9.2 years |  |
| Weighted Average Discount Rate |  |  | 3.2 | % |  |  | 3.1 | % |

[0000950170-24-101408:notes:93]
Future minimum operating lease payments as of July 26, 2024, are as follows (in millions):

[0000950170-24-101408:notes:94]
| Fiscal Year |  | Amount |  |
| 2025 (remainder) |  | $ | 34 |  |
| 2026 |  |  | 41 |  |
| 2027 |  |  | 35 |  |
| 2028 |  |  | 31 |  |
| 2029 |  |  | 27 |  |
| Thereafter |  |  | 128 |  |
| Total lease payments |  |  | 296 |  |
| Less: Interest |  |  | (41 | ) |
| Total |  | $ | 255 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000950170-24-101408:notes:95]
8. Stockholders’ Equity

[0000950170-24-101408:notes:96]
[same as prior period, unchanged from 0000950170-24-023115:notes:107]

[0000950170-24-101408:notes:97]
We granted approximately 3 million restricted stock units (RSUs), including performance-based RSUs (PBRSUs), with a weighted average grant date fair value of $128.21 per share during the three months ended July 26, 2024.

[0000950170-24-101408:notes:98]
In the three months ended July 26, 2024, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSUs cliff-vest at the end of a three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the third fiscal year, following the grant date. The number of shares that will be used to calculate the settlement amount for all of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the three months ended July 26, 2024, the number of shares used to calculate the settlement amount will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. For the remaining half of the PBRSUs granted in the three months ended July 26, 2024, the number of shares used to calculate the settlement amount will depend upon the Company's billings result average over the three-year performance period. The billings result average is computed based on achievement against annual billings targets, with each target set at the beginning of the respective fiscal year, during the three-year performance period. Billings for purposes of measuring the performance of these PBRSUs means the total obtained by adding net

[0000950170-24-101408:notes:99]
revenues as reported on the Company's Consolidated Statements of Income to the amount reported as the change in deferred revenue and financed unearned services revenue on the Consolidated Statements of Cash Flows for the applicable measurement period, excluding the impact of fluctuations in foreign currency exchange rates. The aggregate grant date fair value of PBRSUs granted in the current year was $61 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0000950170-24-101408:notes:100]
[same as prior period, unchanged from 0000950170-24-023115:notes:112]

[0000950170-24-101408:notes:101]
[same as prior period, unchanged from 0000950170-24-023115:notes:113]

[0000950170-24-101408:notes:102]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |
| Cost of services revenues |  |  | 6 |  |  |  | 6 |  |
| Sales and marketing |  |  | 35 |  |  |  | 36 |  |
| Research and development |  |  | 31 |  |  |  | 32 |  |
| General and administrative |  |  | 12 |  |  |  | 12 |  |
| Total stock-based compensation expense |  | $ | 85 |  |  | $ | 87 |  |

[0000950170-24-101408:notes:103]
As of July 26, 2024, total unrecognized compensation expense related to equity awards was $846 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.3 years.

[0000950170-24-101408:notes:104]
[same as prior period, unchanged from 0000950170-24-023115:notes:116]

[0000950170-24-101408:notes:105]
As of July 26, 2024, our Board of Directors has authorized the repurchase of up to $17.1 billion of our common stock. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time.

[0000950170-24-101408:notes:106]
The following table summarizes activity related to the stock repurchase program for the three months ended July 26, 2024 (in millions, except for per share amounts):

[0000950170-24-101408:notes:107]
| Number of shares repurchased |  |  | 3 |  |
| Average price per share |  | $ | 120.46 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 16 |  |
| Stock repurchases allocated to retained earnings |  | $ | 384 |  |
| Remaining authorization at end of period |  | $ | 1,102 |  |

[0000950170-24-101408:notes:108]
Since the May 13, 2003 inception of our stock repurchase program through July 26, 2024, we repurchased a total of 375 million shares of our common stock at an average price of $42.73 per share, for an aggregate purchase price of $16 billion.

[0000950170-24-101408:notes:109]
[same as prior period, unchanged from 0000950170-24-023115:notes:121]

[0000950170-24-101408:notes:110]
[same as prior period, unchanged from 0000950170-24-023115:notes:122]

[0000950170-24-101408:notes:111]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |
| Dividends per share declared |  | $ | 0.52 |  |  | $ | 0.50 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 35 |  |  | $ | 68 |  |
| Dividend payments allocated to retained earnings |  | $ | 72 |  |  | $ | 38 |  |

[0000950170-24-101408:notes:112]
On August 22, 2024, we declared a cash dividend of $0.52 per share of common stock, payable on October 23, 2024 to holders of record as of the close of business on October 4, 2024. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0000950170-24-101408:notes:113]
[same as prior period, unchanged from 0000950170-24-023115:notes:125]

[0000950170-24-101408:notes:114]
[same as prior period, unchanged from 0000950170-24-023115:notes:126]

[0000950170-24-101408:notes:115]
|  |  | ForeignCurrencyTranslationAdjustments |  |  | DefinedBenefitObligationAdjustments |  |  | UnrealizedGains(Losses) onDerivativeInstruments |  |  | Total |  |
| Balance as of April 26, 2024 |  | $ | (53 | ) |  | $ | (7 | ) |  | $ | 1 |  |  | $ | (59 | ) |
| Other comprehensive income (loss), net of tax |  |  | 1 |  |  |  | — |  |  |  | (1 | ) |  |  | — |  |
| Total other comprehensive income (loss) |  |  | 1 |  |  |  | — |  |  |  | (1 | ) |  |  | — |  |
| Balance as of July 26, 2024 |  | $ | (52 | ) |  | $ | (7 | ) |  | $ | — |  |  | $ | (59 | ) |

[0000950170-24-101408:notes:116]
[same as prior period, unchanged from 0000950170-24-023115:notes:128]

[0000950170-24-101408:notes:117]
|  |  | Three Months Ended |  |  |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |  | Statements ofIncome Classification |
| Realized gains on cash flow hedges |  | $ | — |  |  | $ | (1 | ) |  | Net revenues |
| Total reclassifications |  | $ | — |  |  | $ | (1 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-24-101408:notes:118]
9. Derivatives and Hedging Activities

[0000950170-24-101408:notes:119]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of July 26, 2024 or April 26, 2024. All contracts have a maturity of less than 12 months.

[0000950170-24-101408:notes:120]
[same as prior period, unchanged from 0000950170-24-023115:notes:132]

[0000950170-24-101408:notes:121]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 108 |  |  | $ | 71 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 1,088 |  |  | $ | 881 |  |
| Forward contracts purchased |  | $ | 12 |  |  | $ | 11 |  |

[0000950170-24-101408:notes:122]
The gain (loss) of cash flow hedges recognized in net revenues is presented in the condensed consolidated statements of comprehensive income and Note 8 – Stockholders’ Equity.

[0000950170-24-101408:notes:123]
[same as prior period, unchanged from 0000950170-24-023115:notes:135]

[0000950170-24-101408:notes:124]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |
|  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 13 |  |  | $ | (4 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-24-101408:notes:125]
10. Restructuring Charges

[0000950170-24-101408:notes:126]
In the first quarter of fiscal 2025, management approved a restructuring plan to redirect resources to highest return activities and reduce costs, which included a reduction of our global workforce by approximately 2%. Charges related to the plan consisted primarily of employee severance-related costs. The activities under the plan were initiated during the first quarter of fiscal 2025 and are expected to be substantially complete by the end of the second quarter of fiscal 2025.

[0000950170-24-101408:notes:127]
In the first quarter of fiscal 2024, management approved a restructuring plan to redirect resources to highest return activities, and to optimize our global office space for our hybrid work model. In connection with the plan, we reduced our global workforce by approximately 1% and terminated certain real estate leases in various countries, resulting in restructuring charges comprised primarily

[0000950170-24-101408:notes:128]
of employee severance related expenses and lease termination charges. The activities under the plan were substantially completed by the end of fiscal 2024.

[0000950170-24-101408:notes:129]
[same as prior period, unchanged from 0000950170-24-023115:notes:140]

[0000950170-24-101408:notes:130]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |
| Balance at beginning of period |  | $ | 10 |  |  | $ | 36 |  |
| Net charges |  |  | 17 |  |  |  | 26 |  |
| Cash payments |  |  | (9 | ) |  |  | (31 | ) |
| Balance at end of period |  | $ | 18 |  |  | $ | 31 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-24-101408:notes:131]
11. Income Taxes

[0000950170-24-101408:notes:132]
[same as prior period, unchanged from 0000950170-24-023115:notes:143]

[0000950170-24-101408:notes:133]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |
| Effective tax rates |  |  | 17.1 | % |  |  | 19.9 | % |

[0000950170-24-101408:notes:134]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. Our effective tax rate for the three months ended July 26, 2024 includes an increase in discrete tax benefits related to stock compensation compared to the corresponding period of the prior year. Our effective tax rate for the three months ended July 28, 2023 includes a benefit for fiscal 2023 foreign tax credits resulting from Internal Revenue Service Notice 2023-55, which was released during the quarter, partially offset by an increase in stock compensation for which no tax benefit is recorded.

[0000950170-24-101408:notes:135]
The Organisation for Economic Co-operation and Development (“OECD”) recently enacted model rules for a new global minimum tax framework known as Pillar Two. These rules have been agreed to by most OECD members. The OECD has since issued administrative guidance providing transition and safe harbor rules around the implementation of Pillar Two rules. On February 1, 2023, the FASB indicated that they believe taxes imposed under Pillar Two is an alternative minimum tax. Accordingly, deferred tax assets and liabilities associated with the minimum tax would not be recognized or adjusted for the estimated future effects of the minimum tax but would be recognized in the period incurred. We are currently subject to Pillar Two rules starting in our fiscal year 2025. As of July 26, 2024, Pillar Two taxes do not have a significant impact on our financial statements, particularly due to the safe harbor relief during the transition period, but we are still closely monitoring developments.

[0000950170-24-101408:notes:136]
[same as prior period, unchanged from 0000950170-24-023115:notes:150]

[0000950170-24-101408:notes:137]
[same as prior period, unchanged from 0000950170-24-023115:notes:151]

[0000950170-24-101408:notes:138]
[same as prior period, unchanged from 0000950170-24-023115:notes:152]

[0000950170-24-101408:notes:139]
As of July 26, 2024, we had $221 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $158 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $157 million have been recorded in other long-term liabilities.


## us-gaap:EarningsPerShareTextBlock

[0000950170-24-101408:notes:140]
12. Net Income per Share

[0000950170-24-101408:notes:141]
[same as prior period, unchanged from 0000950170-24-023115:notes:155]

[0000950170-24-101408:notes:142]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |
| Numerator: |  |  |  |  |  |  |
| Net income |  | $ | 248 |  |  | $ | 149 |  |
| Denominator: |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 206 |  |  |  | 212 |  |
| Dilutive impact of employee equity award plans |  |  | 6 |  |  |  | 4 |  |
| Shares used in diluted computation |  |  | 212 |  |  |  | 216 |  |
| Net Income per Share: |  |  |  |  |  |  |
| Basic |  | $ | 1.20 |  |  | $ | 0.70 |  |
| Diluted |  | $ | 1.17 |  |  | $ | 0.69 |  |

[0000950170-24-101408:notes:143]
One million shares from outstanding employee equity awards were excluded from the diluted net income per share calculations in each of the three months ended July 26, 2024 and July 28, 2023, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-24-101408:notes:144]
13. Segment, Geographic, and Significant Customer Information

[0000950170-24-101408:notes:145]
[same as prior period, unchanged from 0000950170-24-023115:notes:159]

[0000950170-24-101408:notes:146]
Hybrid Cloud offers a unified data storage portfolio of storage management and infrastructure solutions that help customers modernize their data centers. This portfolio supports structured and unstructured data with unified storage optimized for flash, disk, and cloud storage to handle data-intensive workloads and applications. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.

[0000950170-24-101408:notes:147]
[same as prior period, unchanged from 0000950170-24-023115:notes:161]

[0000950170-24-101408:notes:148]
[same as prior period, unchanged from 0000950170-24-023115:notes:162]

[0000950170-24-101408:notes:149]
[same as prior period, unchanged from 0000950170-24-023115:notes:163]

[0000950170-24-101408:notes:150]
|  | Three Months Ended July 26, 2024 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 669 |  |  | $ | — |  |  | $ | 669 |  |
| Support revenues |  | 631 |  |  |  | — |  |  |  | 631 |  |
| Professional and other services revenues |  | 82 |  |  |  | — |  |  |  | 82 |  |
| Public cloud revenues |  | — |  |  |  | 159 |  |  |  | 159 |  |
| Net revenues |  | 1,382 |  |  |  | 159 |  |  |  | 1,541 |  |
| Cost of product revenues |  | 268 |  |  |  | — |  |  |  | 268 |  |
| Cost of support revenues |  | 50 |  |  |  | — |  |  |  | 50 |  |
| Cost of professional and other services revenues |  | 64 |  |  |  | — |  |  |  | 64 |  |
| Cost of public cloud revenues |  | — |  |  |  | 46 |  |  |  | 46 |  |
| Segment cost of revenues |  | 382 |  |  |  | 46 |  |  |  | 428 |  |
| Segment gross profit | $ | 1,000 |  |  | $ | 113 |  |  | $ | 1,113 |  |
| Segment gross margin |  | 72.4 | % |  |  | 71.1 | % |  |  | 72.2 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 15 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,098 |  |
| Total gross margin |  |  |  |  |  |  |  | 71.3 | % |
| 1 Unallocated cost of revenues are composed of $7 million of stock-based compensation expense and $8 million of amortization of intangible assets. |  |

[0000950170-24-101408:notes:151]
|  | Three Months Ended July 28, 2023 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 590 |  |  | $ | — |  |  | $ | 590 |  |
| Support revenues |  | 611 |  |  |  | — |  |  |  | 611 |  |
| Professional and other services revenues |  | 77 |  |  |  | — |  |  |  | 77 |  |
| Public cloud revenues |  | — |  |  |  | 154 |  |  |  | 154 |  |
| Net revenues |  | 1,278 |  |  |  | 154 |  |  |  | 1,432 |  |
| Cost of product revenues |  | 264 |  |  |  | — |  |  |  | 264 |  |
| Cost of support revenues |  | 47 |  |  |  | — |  |  |  | 47 |  |
| Cost of professional and other services revenues |  | 58 |  |  |  | — |  |  |  | 58 |  |
| Cost of public cloud revenues |  | — |  |  |  | 51 |  |  |  | 51 |  |
| Segment cost of revenues |  | 369 |  |  |  | 51 |  |  |  | 420 |  |
| Segment gross profit | $ | 909 |  |  | $ | 103 |  |  | $ | 1,012 |  |
| Segment gross margin |  | 71.1 | % |  |  | 66.9 | % |  |  | 70.7 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 16 |  |
| Total gross profit |  |  |  |  |  |  | $ | 996 |  |
| Total gross margin |  |  |  |  |  |  |  | 69.6 | % |
| 1 Unallocated cost of revenues are composed of $7 million of stock-based compensation expense and $9 million of amortization of intangible assets. |  |

[0000950170-24-101408:notes:152]
[same as prior period, unchanged from 0000950170-24-023115:notes:168]

[0000950170-24-101408:notes:153]
[same as prior period, unchanged from 0000950170-24-023115:notes:169]

[0000950170-24-101408:notes:154]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |
| United States, Canada and Latin America (Americas) |  | $ | 763 |  |  | $ | 754 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 513 |  |  |  | 446 |  |
| Asia Pacific (APAC) |  |  | 265 |  |  |  | 232 |  |
| Net revenues |  | $ | 1,541 |  |  | $ | 1,432 |  |

[0000950170-24-101408:notes:155]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $699 million in each of the three months ended July 26, 2024 and July 28, 2023.

[0000950170-24-101408:notes:156]
[same as prior period, unchanged from 0000950170-24-023115:notes:173]

[0000950170-24-101408:notes:157]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| U.S. |  | $ | 697 |  |  | $ | 1,142 |  |
| International |  |  | 2,320 |  |  |  | 2,110 |  |
| Total |  | $ | 3,017 |  |  | $ | 3,252 |  |

[0000950170-24-101408:notes:158]
[same as prior period, unchanged from 0000950170-24-023115:notes:175]

[0000950170-24-101408:notes:159]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| U.S. |  | $ | 372 |  |  | $ | 378 |  |
| International |  |  | 222 |  |  |  | 226 |  |
| Total |  | $ | 594 |  |  | $ | 604 |  |

[0000950170-24-101408:notes:160]
[same as prior period, unchanged from 0000950170-24-023115:notes:177]

[0000950170-24-101408:notes:161]
[same as prior period, unchanged from 0000950170-24-023115:notes:178]

[0000950170-24-101408:notes:162]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |
| Arrow Electronics, Inc. |  |  | 23 | % |  |  | 24 | % |
| TD Synnex Corporation |  |  | 22 | % |  |  | 21 | % |

[0000950170-24-101408:notes:163]
[same as prior period, unchanged from 0000950170-24-023115:notes:180]

[0000950170-24-101408:notes:164]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| Arrow Electronics, Inc. |  |  | 6 | % |  |  | 10 | % |
| TD Synnex Corporation |  |  | 23 | % |  |  | 26 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-24-101408:notes:165]
14. Commitments and Contingencies

[0000950170-24-101408:notes:166]
Purchase Orders and Other Commitments

[0000950170-24-101408:notes:167]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of July 26, 2024, we had approximately $0.6 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 26, 2024 and April 26, 2024, such liability amounted to $16 million and $20 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0000950170-24-101408:notes:168]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 26, 2024, we had approximately $0.5 billion in other purchase obligations.

[0000950170-24-101408:notes:169]
Financing Guarantees

[0000950170-24-101408:notes:170]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $19 million of receivables in each of the three months ended July 26, 2024 and July 28, 2023.

[0000950170-24-101408:notes:171]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0000950170-24-101408:notes:172]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of July 26, 2024 and April 26, 2024, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-24-101408:notes:173]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 26, 2024, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned

[0000950170-24-101408:notes:174]
services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-24-101408:notes:175]
Legal Contingencies

[0000950170-24-101408:notes:176]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0000950170-24-101408:notes:177]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigation brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0000950170-24-101408:notes:178]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of July 26, 2024 related to such matters.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000950170-24-101408:notes:179]
[same as prior period, unchanged from 0000950170-24-023115:notes:196]

[0000950170-24-101408:notes:180]
[same as prior period, unchanged from 0000950170-24-023115:notes:197]

[0000950170-24-101408:notes:181]
On June 25, 2024, Daniel De Lorenzo, Vice President, Chief Accounting Officer of the Company, entered into a 10b5-1 trading arrangement intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) promulgated under the Exchange Act. The trading arrangement will expire on June 25, 2025, and may be terminated earlier in the limited circumstances defined in the trading arrangement. An aggregate of up to 3,853 shares may be sold pursuant to the trading arrangement.

[0000950170-24-101408:notes:182]
No other directors or executive officers of the Company adopted, modified or terminated any contract, instruction or written plan for the purchase or sale of the Company’s securities that was intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) or any non-Rule 10b5-1 trading arrangement, (as defined in Item 408(c) of Regulation S-K) during the quarterly period covered by this report.
