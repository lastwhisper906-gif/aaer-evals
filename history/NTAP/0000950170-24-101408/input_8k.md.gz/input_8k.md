# NTAP 8-K — 0000950170-24-101383 filed 2024-08-28

## item codes, every 8-K on or before 2024-08-28

- 2024-08-28 0000950170-24-101383 — 2.02, 5.02, 9.01
- 2024-05-30 0000950170-24-066567 — 2.02, 8.01, 9.01
- 2024-04-09 0000950170-24-042957 — 5.02
- 2024-02-29 0000950170-24-023060 — 2.02, 9.01
- 2023-11-28 0000950170-23-066400 — 2.02, 9.01
- 2023-11-16 0000950170-23-064506 — 5.02, 5.03, 9.01
- 2023-09-15 0000950170-23-048229 — 5.02, 5.07, 9.01
- 2023-08-23 0000950170-23-044130 — 2.02, 9.01
- 2023-08-10 0000950170-23-041348 — 5.02
- 2023-05-31 0000950170-23-025324 — 1.01, 2.02, 8.01, 9.01
- 2023-02-22 0000950170-23-003745 — 2.02, 9.01
- 2023-01-31 0001193125-23-019739 — 2.05, 7.01, 9.01
- 2022-11-29 0000950170-22-025793 — 2.02, 9.01
- 2022-11-16 0000950170-22-025317 — 5.02
- 2022-09-14 0000950170-22-018490 — 5.07
- 2022-08-24 0000950170-22-017731 — 2.02, 9.01
- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2024-08-28

- none on or before 2024-08-28

## item 2.02 — earnings release, exhibit 99.1

[0000950170-24-101383:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0000950170-24-101383:8k_2_02:2]
EX-99.1

[0000950170-24-101383:8k_2_02:3]
Exhibit 99.1

[0000950170-24-101383:8k_2_02:4]
NetApp Reports First Quarter of Fiscal Year 2025 Results

[0000950170-24-101383:8k_2_02:5]
Net revenues of $1.54 billion for the first quarter; 8% year-over-year increase

[0000950170-24-101383:8k_2_02:6]
•
All-flash array annualized net revenue run rate1 of $3.4 billion, an increase of 21% year-over-year

[0000950170-24-101383:8k_2_02:7]
•
First party and marketplace cloud storage services revenue grew approximately 40% year-over-year

[0000950170-24-101383:8k_2_02:8]
•
Record first quarter GAAP operating margin of 18%; record first quarter non-GAAP operating margin2 of 26%

[0000950170-24-101383:8k_2_02:9]
•
Record first quarter GAAP net income per share3 of $1.17; record first quarter non-GAAP net income per share2 of $1.56

[0000950170-24-101383:8k_2_02:10]
•
Returned $507 million to stockholders through share repurchases and cash dividends

[0000950170-24-101383:8k_2_02:11]
SAN JOSE, Calif.—August 28, 2024—NetApp (NASDAQ: NTAP), the intelligent data infrastructure company, today reported financial results for the first quarter of fiscal year 2025, which ended on July 26, 2024.

[0000950170-24-101383:8k_2_02:12]
“We started fiscal year 2025 on a high note, delivering strong revenue growth and setting records for first quarter operating margin and EPS. These results are a testament to our strong execution in a continued uncertain macroeconomic environment, our unwavering confidence in the customer benefits of the highly differentiated NetApp intelligent data infrastructure platform, and our disciplined management of the business,” said George Kurian, chief executive officer. “I am confident in our ability to capitalize on this momentum, as we address new market opportunities, extend our leadership position in existing markets, and deliver increasing value for all our stakeholders.”

[0000950170-24-101383:8k_2_02:13]
First Quarter of Fiscal Year 2025 Financial Results

[0000950170-24-101383:8k_2_02:14]
•
Net revenues: $1.54 billion, compared to $1.43 billion in the first quarter of fiscal year 2024; a year-over-year increase of 8%.

[0000950170-24-101383:8k_2_02:15]
o
Hybrid Cloud segment revenue: $1.38 billion, compared to $1.28 billion in the first quarter of fiscal year 2024.

[0000950170-24-101383:8k_2_02:16]
o
Public Cloud segment revenue: $159 million, compared to $154 million in the first quarter of fiscal year 2024.

[0000950170-24-101383:8k_2_02:17]
•
Billings2: $1.45 billion, compared to $1.30 billion in the first quarter of fiscal year 2024; a year-over-year increase of 12%.

[0000950170-24-101383:8k_2_02:18]
•
All-flash array ARR: $3.4 billion, compared to $2.8 billion in the first quarter of fiscal year 2024; a year-over-year increase of 21%.

[0000950170-24-101383:8k_2_02:19]
•
Net income: GAAP net income of $248 million, compared to $149 million in the first quarter of fiscal year 2024; non-GAAP net income of $330 million, compared to $249 million in the first quarter of fiscal year 2024.

[0000950170-24-101383:8k_2_02:20]
•
Earnings per share: GAAP net income per share of $1.17 compared to $0.69 in the first quarter of fiscal year 2024; non-GAAP net income per share of $1.56 compared to $1.15 in the first quarter of fiscal year 2024.

[0000950170-24-101383:8k_2_02:21]
•
Cash, cash equivalents and investments: $3.02 billion at the end of the first quarter of fiscal year 2025.

[0000950170-24-101383:8k_2_02:22]
•
Cash provided by operations: $341 million, compared to $453 million in the first quarter of fiscal year 2024.

[0000950170-24-101383:8k_2_02:23]
•
Share repurchases and dividends: Returned $507 million to stockholders through share repurchases and cash dividends.

[0000950170-24-101383:8k_2_02:24]
Second Quarter of Fiscal Year 2025 Financial Outlook

[0000950170-24-101383:8k_2_02:25]
The Company provided the following financial guidance for the second quarter of fiscal year 2025:

[0000950170-24-101383:8k_2_02:26]
| Net revenues are expected to be in the range of: | $1.565 billion - $1.715 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $1.27 - 1.37 | $1.73 - $1.83 |

[0000950170-24-101383:8k_2_02:27]
Full Fiscal Year 2025 Financial Outlook

[0000950170-24-101383:8k_2_02:28]
The Company provided the following update to financial guidance for the full fiscal year 2025:

[0000950170-24-101383:8k_2_02:29]
| Net revenues are expected to be in the range of: | $6.480 billion - $6.680 billion |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 70% - 71% | 71% - 72% |
| Operating margins are expected to be in the range of: | 20% - 21% | 27% - 28% |
| Earnings per share is expected to be in the range of: | $5.17 - $5.37 | $7.00 - $7.20 |

[0000950170-24-101383:8k_2_02:30]
Dividend

[0000950170-24-101383:8k_2_02:31]
The next cash dividend of $0.52 per share is to be paid on October 23, 2024, to stockholders of record as of the close of business on October 4, 2024.

[0000950170-24-101383:8k_2_02:32]
Chief Financial Officer Retirement

[0000950170-24-101383:8k_2_02:33]
NetApp also announces today that Mike Berry, Executive Vice President and CFO, has given notice of his intent to retire from the company as of May 23, 2025. The company will engage in a comprehensive search for his successor. Mr. Berry will remain in his role until his successor is named and the company has completed the successful transition.

[0000950170-24-101383:8k_2_02:34]
“On behalf of the Board and everyone at NetApp, I would like to thank Mike for his deeply valued partnership and significant contributions to the Company over the last four plus years,” said George Kurian. “Mike has been a great asset to NetApp, having brought with him a wealth of knowledge and insight that helped us to enhance

[0000950170-24-101383:8k_2_02:35]
our strategic focus, strengthen our financial foundation and drive shareholder value. I would like to thank Mike for his service and dedication and wish him all the best in his well-deserved retirement. We are committed to identifying a successor of equal caliber and to ensuring a seamless transition with Mike’s assistance.”

[0000950170-24-101383:8k_2_02:36]
First Quarter of Fiscal Year 2025 Business Highlights

[0000950170-24-101383:8k_2_02:37]
Leading Product Innovation

[0000950170-24-101383:8k_2_02:38]
•
NetApp introduced the new NetApp™ AFF A-Series family of high-performance all-flash arrays that can power the most demanding IT workloads, including GenAI, VMware, and enterprise databases.

[0000950170-24-101383:8k_2_02:39]
•
NetApp announced six new NetApp StorageGRID™ models that enhance the value of large, unstructured data while reducing total cost of ownership, using capacity flash to provide fast object access times.

[0000950170-24-101383:8k_2_02:40]
•
NetApp announced a new cyber vault reference architecture that extends the Company’s data protection capabilities to help protect customer data against advanced cyberthreats.

[0000950170-24-101383:8k_2_02:41]
•
NetApp announced NetApp AIPod™ with Lenovo ThinkSystem servers for NVIDIA OVX, a converged infrastructure that is optimized for GenAI.

[0000950170-24-101383:8k_2_02:42]
•
NetApp announced NetApp BlueXP™ workload factory for Amazon Web Services, Inc. (AWS) deployments. This intelligent data infrastructure service that uses defined industry best practices to automate the planning, provisioning, and management of cloud resources and services for key workloads, including GenAI, VMware Cloud environments, and enterprise databases.

[0000950170-24-101383:8k_2_02:43]
•
NetApp introduced NetApp GenAI Toolkit for Azure, which enables customers to include private enterprise data stored on Azure NetApp Files in their retrieval-augmented generation (RAG) workflows in a secure, programmatic manner.

[0000950170-24-101383:8k_2_02:44]
•
AWS and NetApp released Amazon Bedrock with the Amazon FSx for NetApp ONTAP reference architecture, which provides guidance for customers on how to implement RAG-enabled workflows that bring proprietary data stored on Amazon FSx for NetApp ONTAP into their GenAI data pipelines.

[0000950170-24-101383:8k_2_02:45]
•
NetApp ONTAP™ Autonomous Ransomware Protection with artificial intelligence received the AAA rating from SE Labs, an independently owned and run testing company that assesses security products and services.

[0000950170-24-101383:8k_2_02:46]
•
NetApp announced the general availability of BlueXP ransomware protection, providing a single control plane to intelligently coordinate and execute a comprehensive, workload-centric ransomware defense at the storage layer.

[0000950170-24-101383:8k_2_02:47]
Customer & Partner Momentum

[0000950170-24-101383:8k_2_02:48]
•
Microsoft recognized Capgemini and NetApp with a 2024 Microsoft Partner of the Year Award in the “Migration to Azure” category for the companies’ work in moving a large retail customer in Asia to Azure, including Azure NetApp Files.

[0000950170-24-101383:8k_2_02:49]
•
NetApp signed the Cybersecurity & Infrastructure Security Agency’s Secure by Design Pledge, joining 68 leading software manufacturers in committing to enhanced security measures for their products.

[0000950170-24-101383:8k_2_02:50]
•
NetApp announced an expansion of its relationship with Porsche Motorsport to become its exclusive intelligent data infrastructure partner.

[0000950170-24-101383:8k_2_02:51]
•
NetApp partnered with Dürr Group to accelerate the engineering firm’s cloud journey by implementing a hybrid cloud strategy that uses NetApp ONTAP and BlueXP.

[0000950170-24-101383:8k_2_02:52]
•
ePlus expanded its storage-as-a-service (STaaS) portfolio by launching ePlus STaaS with NetApp Keystone™ to offer flexible subscription models, enhanced support, and scalable storage solutions for on-premises data centers.

[0000950170-24-101383:8k_2_02:53]
•
NetApp announced a new global Distribution Partner Program, designed to equip both Distributors and the Partners they manage for success.

[0000950170-24-101383:8k_2_02:54]
Corporate News and Events

[0000950170-24-101383:8k_2_02:55]
•
NetApp expanded its Global AI Sales Specialist team to position NetApp’s best-in-class solutions in the AI space, partnering with NVIDIA and other key industry players.

[0000950170-24-101383:8k_2_02:56]
•
NetApp and IDC released a report on the evolving landscape of AI4 in the enterprise that provided insights into the successful strategies adopted by leading organizations in their efforts to responsibly scale AI and GenAI workloads.

[0000950170-24-101383:8k_2_02:57]
•
The Spot by NetApp™ team and Dimensional Research conducted a survey to capture relevant data about the current state of automation and the optimization of public cloud infrastructure from the perspective of cloud operations practitioners.5

[0000950170-24-101383:8k_2_02:58]
Awards and Recognition

[0000950170-24-101383:8k_2_02:59]
•
George Kurian was named one of the 25 Most Influential Executives of 2024 by CRN.

[0000950170-24-101383:8k_2_02:60]
•
NetApp was named a leader in the GigaOm Radar for Kubernetes Data Storage report.

[0000950170-24-101383:8k_2_02:61]
•
NetApp was named an outperformer in the GigaOm Radar for Unstructured Data Management report.

[0000950170-24-101383:8k_2_02:62]
•
Spot by NetApp was named a leader and outperformer in the GigaOm Radar for Cloud FinOps report for the third year in a row.

[0000950170-24-101383:8k_2_02:63]
•
Spot by NetApp was named a leader in the GigaOm Radar for Cloud Resource Optimization report for the third year in a row.

[0000950170-24-101383:8k_2_02:64]
•
NetApp was named a Market Leader in File and Object Storage for AI in the 2024 IT Brand Leader Survey covering Enterprise Infrastructure for AI.

[0000950170-24-101383:8k_2_02:65]
•
NetApp AIPod was named a finalist in the AI Infrastructure category of CRN’s 2024 Tech Innovator Awards.

[0000950170-24-101383:8k_2_02:66]
•
NetApp was named on the Forbes Global 2000 list, which ranks companies around the world based on sales, profits, assets, and market value.

[0000950170-24-101383:8k_2_02:67]
•
NetApp was included in Database Trends and Applications’ DBTA 100 2024, a list of forward-thinking companies seeking to expand what’s possible with data for their customers.

[0000950170-24-101383:8k_2_02:68]
•
NetApp was recognized on the USA TODAY second annual America’s Climate Leaders list, which evaluated companies based on their reduction of carbon dioxide emissions between 2020 and 2022.

[0000950170-24-101383:8k_2_02:69]
•
NetApp was named on America’s Greatest Workplaces 2024 list by Newsweek, which is based on surveys of employees about compensation, training and career progression, work-life balance, and company culture.

[0000950170-24-101383:8k_2_02:70]
•
U.S. News named NetApp one of the best companies to work for in the United States, based on quality of pay and benefits, work-life balance, professional development, and physical and psychological comfort.

[0000950170-24-101383:8k_2_02:71]
•
NetApp was named on America’s Best Midsize Companies of 2024 list by TIME, which ranks companies based on positive revenue growth, employee satisfaction, and sustainability transparency.

[0000950170-24-101383:8k_2_02:72]
•
NetApp was named on the Disability:IN 2024 Best Places to Work for Disability Inclusion list, based on the benchmarking of corporate disability inclusion policies and programs.

[0000950170-24-101383:8k_2_02:73]
•
Fullstack Academy concluded that NetApp has the best work-life balance of more than 100 major tech companies based on an analysis of Glassdoor reviews.

[0000950170-24-101383:8k_2_02:74]
•
HotTopics named Gabie Boko, Chief Marketing Officer at NetApp, one of the top 100 Global B2B CMOs of 2024.

[0000950170-24-101383:8k_2_02:75]
•
Twelve women from NetApp were named on the CRN 2024 Women of the Channel list.

[0000950170-24-101383:8k_2_02:76]
•
CRN named Jenni Flinders, SVP of NetApp’s Worldwide Partner Group, on its Power 100 list of the Most Powerful Women of the Channel.

[0000950170-24-101383:8k_2_02:77]
•
Jenni Flinders, SVP of the NetApp Worldwide Partner Group, was named one of the Top 25 Channel Sales Leaders of 2024 by CRN as part of its Top 100 Executives list.

[0000950170-24-101383:8k_2_02:78]
Executive Leadership Announcements

[0000950170-24-101383:8k_2_02:79]
•
NetApp appointed Dallas Olson as Chief Commercial Officer with responsibility for overseeing sales strategy, driving business growth in key areas, including AI and NetApp Keystone through specialist teams.

[0000950170-24-101383:8k_2_02:80]
•
NetApp appointed Mike Sakalas as Vice President of U.S. Enterprise Sales with oversight for the development and execution of NetApp’s enterprise business in the United States.

[0000950170-24-101383:8k_2_02:81]
Webcast and Conference Call Information

[0000950170-24-101383:8k_2_02:82]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today.

[0000950170-24-101383:8k_2_02:83]
market acceptance for our products and services; our ability to maintain our customer, partner, supplier and contract manufacturer relationships on favorable terms and conditions; global political, macroeconomic and market conditions, including inflation, fluctuating interest rates, monetary policy shifts, recession risks, and foreign exchange volatility and the resulting impact on demand for our products; the impact of new or ongoing geopolitical conflicts and sanctions; adoption or changes to laws, regulations standards or policies affecting our operations, products, services, the storage industry, or AI usage; material cybersecurity and other security breaches; the impact of supply chain disruptions on our business operations, financial performance and results of operations; changes in U.S. government spending; changes in overall technology spending by our customers; revenue seasonality; changes in laws or regulations, including those relating to privacy, data protection and information security; the timing of orders and their fulfilment; and our ability to manage our gross profit margins, including managing component costs. These and other equally important factors are described in reports and documents we file from time to time with the Securities and Exchange Commission, including the factors described under the sections titled “Risk Factors” in our most recently submitted annual report on Form 10-K and quarterly report on Form 10-Q. We disclaim any obligation to update information contained in this press release whether as a result of new information, future events, or otherwise.

[0000950170-24-101383:8k_2_02:84]
###

[0000950170-24-101383:8k_2_02:85]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0000950170-24-101383:8k_2_02:86]
Footnotes

[0000950170-24-101383:8k_2_02:87]
1All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0000950170-24-101383:8k_2_02:88]
2Refer to “NetApp Usage of Non-GAAP Financial Information” section below for explanations of consolidated non-GAAP gross margins, non-GAAP operating margins, non-GAAP net income, non-GAAP net income per share, free cash flow, and billings.

[0000950170-24-101383:8k_2_02:89]
3GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0000950170-24-101383:8k_2_02:90]
4IDC White Paper sponsored by NetApp, "Scaling AI Initiatives Responsibly: The Critical Role of an Intelligent Data Infrastructure," Doc #US52048524, May 2024.

[0000950170-24-101383:8k_2_02:91]
5Spot by NetApp Blog, “Research: How cloud practitioners optimize infrastructure in a multi-cloud world,” https://spot.io/blog/research-optimize-multi-cloud-infrastructure/, July 8, 2024.

[0000950170-24-101383:8k_2_02:92]
NetApp Usage of Non-GAAP Financial Information

[0000950170-24-101383:8k_2_02:93]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share.

[0000950170-24-101383:8k_2_02:94]
In prior periods, NetApp presented the hardware and software components of our GAAP product revenues to illustrate the significance and value of the Company’s software. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures.

[0000950170-24-101383:8k_2_02:95]
Effective in fiscal year 2025, NetApp no longer presents the non-GAAP hardware and software components of our product revenues, as management no longer considers them to be key financial measures. The Company’s current strategy is expected to deliver investor value through growth in total revenues, including product revenues, while maintaining operational discipline to drive earnings leverage. While software continues to be the primary value driver of our products, NetApp is primarily focused on driving growth in total product revenues, through the sale of configured storage systems comprised of both hardware and software, with less focus on the pricing of each component.

[0000950170-24-101383:8k_2_02:96]
Additionally, the Company is considering potential opportunities to simplify pricing for certain products in the future, which may eliminate the existence of separate prices for hardware and software components and/or impact our ability to allocate between them.

[0000950170-24-101383:8k_2_02:97]
NetApp believes that the presentation of its non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp’s management uses non-GAAP measures in making operating decisions because it believes that the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0000950170-24-101383:8k_2_02:98]
NetApp believes that the presentation of non-GAAP gross margins, non-GAAP operating margin, non-GAAP effective tax rate, non-GAAP net income, and non-GAAP earnings per share data, provides investors with

[0000950170-24-101383:8k_2_02:99]
supplemental metrics that assist in understanding current results and future prospects, earnings and profitability that are complementary to GAAP metrics. Each of these Non-GAAP metrics is defined as the applicable GAAP metric adjusted to exclude the items defined in A through I below, as applicable, while our Non-GAAP effective tax rate and Non-GAAP net income also reflect a non-GAAP tax provision, as described in item J below, instead of our GAAP tax provision. Non-GAAP net income per share is computed as Non-GAAP net income divided by the diluted number of shares for the applicable period.

[0000950170-24-101383:8k_2_02:100]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0000950170-24-101383:8k_2_02:101]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0000950170-24-101383:8k_2_02:102]
Non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0000950170-24-101383:8k_2_02:103]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0000950170-24-101383:8k_2_02:104]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0000950170-24-101383:8k_2_02:105]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0000950170-24-101383:8k_2_02:106]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0000950170-24-101383:8k_2_02:107]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0000950170-24-101383:8k_2_02:108]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0000950170-24-101383:8k_2_02:109]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0000950170-24-101383:8k_2_02:110]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0000950170-24-101383:8k_2_02:111]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0000950170-24-101383:8k_2_02:112]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such non-recurring costs do not reflect the results of its underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0000950170-24-101383:8k_2_02:113]
J. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as

[0000950170-24-101383:8k_2_02:114]
changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges or benefits resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0000950170-24-101383:8k_2_02:115]
Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures. A detailed reconciliation of our non-GAAP to GAAP results can be found herein.

[0000950170-24-101383:8k_2_02:116]
Constant Currency

[0000950170-24-101383:8k_2_02:117]
In periods in which the impacts of foreign currency exchange rate changes are significant, NetApp presents certain constant currency growth rates or quantifies the impact of foreign currency exchange rate changes on year-over-year fluctuations, including for net revenues, billings, and earnings. This constant currency information assumes the same foreign currency exchange rates that were in effect for the comparable prior-year period were used in translation of the current period results.

[0000950170-24-101383:8k_2_02:118]
About NetApp

[0000950170-24-101383:8k_2_02:119]
NetApp is the intelligent data infrastructure company, combining unified data storage, integrated data services, and CloudOps solutions to turn a world of disruption into opportunity for every customer. NetApp creates silo-free infrastructure, harnessing observability and AI to enable the industry’s best data management. As the only enterprise-grade storage service natively embedded in the world’s biggest clouds, our data storage delivers seamless flexibility. In addition, our data services create a data advantage through superior cyber resilience, governance, and application agility. Our CloudOps solutions provide continuous optimization of performance and

[0000950170-24-101383:8k_2_02:120]
efficiency through observability and AI. No matter the data type, workload, or environment, with NetApp you can transform your data infrastructure to realize your business possibilities.

[0000950170-24-101383:8k_2_02:121]
Learn more at www.netapp.com or follow us on X, LinkedIn, Facebook, and Instagram.

[0000950170-24-101383:8k_2_02:122]
NETAPP, INC.

[0000950170-24-101383:8k_2_02:123]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-24-101383:8k_2_02:124]
(In millions)

[0000950170-24-101383:8k_2_02:125]
(Unaudited)

[0000950170-24-101383:8k_2_02:126]
|  |  | July 26, 2024 |  |  | April 26, 2024 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,017 |  |  | $ | 3,252 |  |
| Accounts receivable |  |  | 679 |  |  |  | 1,007 |  |
| Inventories |  |  | 214 |  |  |  | 186 |  |
| Other current assets |  |  | 411 |  |  |  | 452 |  |
| Total current assets |  |  | 4,321 |  |  |  | 4,897 |  |
| Property and equipment, net |  |  | 594 |  |  |  | 604 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,869 |  |  |  | 2,883 |  |
| Other non-current assets |  |  | 1,527 |  |  |  | 1,503 |  |
| Total assets |  | $ | 9,311 |  |  | $ | 9,887 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 437 |  |  | $ | 517 |  |
| Accrued expenses |  |  | 793 |  |  |  | 1,013 |  |
| Current portion of long-term debt |  |  | 1,149 |  |  |  | 400 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 2,133 |  |  |  | 2,176 |  |
| Total current liabilities |  |  | 4,512 |  |  |  | 4,106 |  |
| Long-term debt |  |  | 1,244 |  |  |  | 1,992 |  |
| Other long-term liabilities |  |  | 590 |  |  |  | 585 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 2,036 |  |  |  | 2,058 |  |
| Total liabilities |  |  | 8,382 |  |  |  | 8,741 |  |
| Stockholders' equity |  |  | 929 |  |  |  | 1,146 |  |
| Total liabilities and stockholders' equity |  | $ | 9,311 |  |  | $ | 9,887 |  |

[0000950170-24-101383:8k_2_02:127]
NETAPP, INC.

[0000950170-24-101383:8k_2_02:128]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-24-101383:8k_2_02:129]
(In millions, except per share amounts)

[0000950170-24-101383:8k_2_02:130]
(Unaudited)

[0000950170-24-101383:8k_2_02:131]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |
| Net revenues: |  |  |  |  |  |  |
| Product |  | $ | 669 |  |  | $ | 590 |  |
| Services |  |  | 872 |  |  |  | 842 |  |
| Net revenues |  |  | 1,541 |  |  |  | 1,432 |  |
| Cost of revenues: |  |  |  |  |  |  |
| Cost of product |  |  | 269 |  |  |  | 265 |  |
| Cost of services |  |  | 174 |  |  |  | 171 |  |
| Total cost of revenues |  |  | 443 |  |  |  | 436 |  |
| Gross profit |  |  | 1,098 |  |  |  | 996 |  |
| Operating expenses: |  |  |  |  |  |  |
| Sales and marketing |  |  | 471 |  |  |  | 468 |  |
| Research and development |  |  | 252 |  |  |  | 247 |  |
| General and administrative |  |  | 75 |  |  |  | 74 |  |
| Restructuring charges |  |  | 17 |  |  |  | 26 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 3 |  |
| Total operating expenses |  |  | 816 |  |  |  | 818 |  |
| Income from operations |  |  | 282 |  |  |  | 178 |  |
| Other income, net |  |  | 17 |  |  |  | 8 |  |
| Income before income taxes |  |  | 299 |  |  |  | 186 |  |
| Provision for income taxes |  |  | 51 |  |  |  | 37 |  |
| Net income |  | $ | 248 |  |  | $ | 149 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 1.20 |  |  | $ | 0.70 |  |
| Diluted |  | $ | 1.17 |  |  | $ | 0.69 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |
| Basic |  |  | 206 |  |  |  | 212 |  |
| Diluted |  |  | 212 |  |  |  | 216 |  |

[0000950170-24-101383:8k_2_02:132]
NETAPP, INC.

[0000950170-24-101383:8k_2_02:133]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-24-101383:8k_2_02:134]
(In millions)

[0000950170-24-101383:8k_2_02:135]
(Unaudited)

[0000950170-24-101383:8k_2_02:136]
|  |  | Three Months Ended |  |
|  |  | July 26, 2024 |  |  | July 28, 2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income |  | $ | 248 |  |  | $ | 149 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 63 |  |  |  | 64 |  |
| Non-cash operating lease cost |  |  | 10 |  |  |  | 11 |  |
| Stock-based compensation |  |  | 85 |  |  |  | 87 |  |
| Deferred income taxes |  |  | (17 | ) |  |  | (6 | ) |
| Other items, net |  |  | (19 | ) |  |  | (2 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |
| Accounts receivable |  |  | 335 |  |  |  | 332 |  |
| Inventories |  |  | (29 | ) |  |  | 37 |  |
| Accounts payable |  |  | (77 | ) |  |  | (56 | ) |
| Accrued expenses |  |  | (221 | ) |  |  | (89 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (92 | ) |  |  | (133 | ) |
| Long-term taxes payable |  |  | 4 |  |  |  | 1 |  |
| Changes in other operating assets and liabilities, net |  |  | 51 |  |  |  | 58 |  |
| Net cash provided by operating activities |  |  | 341 |  |  |  | 453 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of investments, net |  |  | (10 | ) |  |  | (192 | ) |
| Purchases of property and equipment |  |  | (41 | ) |  |  | (35 | ) |
| Other investing activities, net |  |  | — |  |  |  | (1 | ) |
| Net cash used in investing activities |  |  | (51 | ) |  |  | (228 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 55 |  |  |  | 52 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (97 | ) |  |  | (65 | ) |
| Repurchase of common stock |  |  | (400 | ) |  |  | (400 | ) |
| Dividends paid |  |  | (107 | ) |  |  | (106 | ) |
| Other financing activities, net |  |  | 1 |  |  |  | (2 | ) |
| Net cash used in financing activities |  |  | (548 | ) |  |  | (521 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 8 |  |  |  | — |  |
| Net change in cash, cash equivalents and restricted cash |  |  | (250 | ) |  |  | (296 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |
| Beginning of period |  |  | 1,909 |  |  |  | 2,322 |  |
| End of period |  | $ | 1,659 |  |  | $ | 2,026 |  |

[0000950170-24-101383:8k_2_02:137]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| Product |  | $ | 669 |  |  | $ | 806 |  |  | $ | 590 |  |
| Support |  |  | 631 |  |  |  | 623 |  |  |  | 611 |  |
| Professional and Other Services |  |  | 82 |  |  |  | 87 |  |  |  | 77 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,382 |  |  |  | 1,516 |  |  |  | 1,278 |  |
| Public Cloud Segment Net Revenues |  |  | 159 |  |  |  | 152 |  |  |  | 154 |  |
| Net Revenues |  | $ | 1,541 |  |  | $ | 1,668 |  |  | $ | 1,432 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| Product |  | $ | 401 |  |  | $ | 494 |  |  | $ | 326 |  |
| Support |  |  | 581 |  |  |  | 574 |  |  |  | 564 |  |
| Professional and Other Services |  |  | 18 |  |  |  | 20 |  |  |  | 19 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 1,000 |  |  |  | 1,088 |  |  |  | 909 |  |
| Public Cloud Segment Gross Profit |  |  | 113 |  |  |  | 104 |  |  |  | 103 |  |
| Total Segments Gross Profit |  |  | 1,113 |  |  |  | 1,192 |  |  |  | 1,012 |  |
| Amortization of Intangible Assets |  |  | (8 | ) |  |  | (8 | ) |  |  | (9 | ) |
| Stock-based Compensation |  |  | (7 | ) |  |  | (8 | ) |  |  | (7 | ) |
| Unallocated Cost of Revenues |  |  | (15 | ) |  |  | (16 | ) |  |  | (16 | ) |
| Gross Profit |  | $ | 1,098 |  |  | $ | 1,176 |  |  | $ | 996 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| Product |  |  | 59.9 | % |  |  | 61.3 | % |  |  | 55.3 | % |
| Support |  |  | 92.1 | % |  |  | 92.1 | % |  |  | 92.3 | % |
| Professional and Other Services |  |  | 22.0 | % |  |  | 23.0 | % |  |  | 24.7 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 72.4 | % |  |  | 71.8 | % |  |  | 71.1 | % |
| Public Cloud Segment Gross Margin |  |  | 71.1 | % |  |  | 68.4 | % |  |  | 66.9 | % |
| Geographic Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'25 |  |  | % of Q4 FY'24 |  |  | % of Q1 FY'24 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 50 | % |  |  | 51 | % |  |  | 53 | % |
| Americas Commercial |  |  | 39 | % |  |  | 41 | % |  |  | 41 | % |
| U.S. Public Sector |  |  | 11 | % |  |  | 10 | % |  |  | 12 | % |
| EMEA |  |  | 33 | % |  |  | 34 | % |  |  | 31 | % |
| Asia Pacific |  |  | 17 | % |  |  | 15 | % |  |  | 16 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'25 |  |  | % of Q4 FY'24 |  |  | % of Q1 FY'24 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 22 | % |  |  | 24 | % |  |  | 24 | % |
| Indirect |  |  | 78 | % |  |  | 76 | % |  |  | 76 | % |

[0000950170-24-101383:8k_2_02:138]
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| Non-GAAP Income from Operations |  | $ | 399 |  |  | $ | 469 |  |  | $ | 309 |  |
| % of Net Revenues |  |  | 25.9 | % |  |  | 28.1 | % |  |  | 21.6 | % |
| Non-GAAP Income before Income Taxes |  | $ | 416 |  |  | $ | 483 |  |  | $ | 317 |  |
| Non-GAAP Effective Tax Rate |  |  | 20.7 | % |  |  | 20.9 | % |  |  | 21.5 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| Non-GAAP Net Income |  | $ | 330 |  |  | $ | 382 |  |  | $ | 249 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 212 |  |  |  | 212 |  |  |  | 216 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.56 |  |  | $ | 1.80 |  |  | $ | 1.15 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 4,169 |  |  | $ | 4,234 |  |  | $ | 4,182 |  |
| DSO (days) |  |  | 40 |  |  |  | 55 |  |  |  | 41 |  |
| DPO (days) |  |  | 90 |  |  |  | 96 |  |  |  | 72 |  |
| Inventory Turns |  |  | 8 |  |  |  | 11 |  |  |  | 13 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| Net Cash Provided by Operating Activities |  | $ | 341 |  |  | $ | 613 |  |  | $ | 453 |  |
| Purchases of Property and Equipment |  | $ | 41 |  |  | $ | 46 |  |  | $ | 35 |  |
| Free Cash Flow |  | $ | 300 |  |  | $ | 567 |  |  | $ | 418 |  |
| Free Cash Flow as % of Net Revenues |  |  | 19.5 | % |  |  | 34.0 | % |  |  | 29.2 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0000950170-24-101383:8k_2_02:139]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| NET INCOME |  | $ | 248 |  |  | $ | 291 |  |  | $ | 149 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 15 |  |
| Stock-based compensation |  |  | 85 |  |  |  | 88 |  |  |  | 87 |  |
| Restructuring charges |  |  | 17 |  |  |  | — |  |  |  | 26 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |
| Income tax effects |  |  | (35 | ) |  |  | (12 | ) |  |  | (31 | ) |
| NON-GAAP NET INCOME |  | $ | 330 |  |  | $ | 382 |  |  | $ | 249 |  |
| COST OF REVENUES |  | $ | 443 |  |  | $ | 492 |  |  | $ | 436 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (8 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (7 | ) |  |  | (8 | ) |  |  | (7 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 428 |  |  | $ | 476 |  |  | $ | 420 |  |
| COST OF PRODUCT REVENUES |  | $ | 269 |  |  | $ | 314 |  |  | $ | 265 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (1 | ) |  |  | (2 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 268 |  |  | $ | 312 |  |  | $ | 264 |  |
| COST OF SERVICES REVENUES |  | $ | 174 |  |  | $ | 178 |  |  | $ | 171 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (8 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (6 | ) |  |  | (6 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 160 |  |  | $ | 164 |  |  | $ | 156 |  |
| GROSS PROFIT |  | $ | 1,098 |  |  | $ | 1,176 |  |  | $ | 996 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 8 |  |  |  | 8 |  |  |  | 9 |  |
| Stock-based compensation |  |  | 7 |  |  |  | 8 |  |  |  | 7 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,113 |  |  | $ | 1,192 |  |  | $ | 1,012 |  |

[0000950170-24-101383:8k_2_02:140]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| SALES AND MARKETING EXPENSES |  | $ | 471 |  |  | $ | 460 |  |  | $ | 468 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (6 | ) |  |  | (6 | ) |
| Stock-based compensation |  |  | (35 | ) |  |  | (34 | ) |  |  | (36 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 430 |  |  | $ | 420 |  |  | $ | 426 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 252 |  |  | $ | 271 |  |  | $ | 247 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (31 | ) |  |  | (33 | ) |  |  | (32 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 221 |  |  | $ | 238 |  |  | $ | 215 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 75 |  |  | $ | 78 |  |  | $ | 74 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (12 | ) |  |  | (13 | ) |  |  | (12 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 63 |  |  | $ | 65 |  |  | $ | 62 |  |
| RESTRUCTURING CHARGES |  | $ | 17 |  |  | $ | — |  |  | $ | 26 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (17 | ) |  |  | — |  |  |  | (26 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 1 |  |  | $ | 1 |  |  | $ | 3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (1 | ) |  |  | (1 | ) |  |  | (3 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 816 |  |  | $ | 810 |  |  | $ | 818 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (6 | ) |  |  | (6 | ) |
| Stock-based compensation |  |  | (78 | ) |  |  | (80 | ) |  |  | (80 | ) |
| Restructuring charges |  |  | (17 | ) |  |  | — |  |  |  | (26 | ) |
| Acquisition-related expense |  |  | (1 | ) |  |  | (1 | ) |  |  | (3 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 714 |  |  | $ | 723 |  |  | $ | 703 |  |

[0000950170-24-101383:8k_2_02:141]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| INCOME FROM OPERATIONS |  | $ | 282 |  |  | $ | 366 |  |  | $ | 178 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 15 |  |
| Stock-based compensation |  |  | 85 |  |  |  | 88 |  |  |  | 87 |  |
| Restructuring charges |  |  | 17 |  |  |  | — |  |  |  | 26 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 399 |  |  | $ | 469 |  |  | $ | 309 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 299 |  |  | $ | 380 |  |  | $ | 186 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 15 |  |
| Stock-based compensation |  |  | 85 |  |  |  | 88 |  |  |  | 87 |  |
| Restructuring charges |  |  | 17 |  |  |  | — |  |  |  | 26 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 416 |  |  | $ | 483 |  |  | $ | 317 |  |
| PROVISION FOR INCOME TAXES |  | $ | 51 |  |  | $ | 89 |  |  | $ | 37 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 35 |  |  |  | 12 |  |  |  | 31 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 86 |  |  | $ | 101 |  |  | $ | 68 |  |
| NET INCOME PER SHARE |  | $ | 1.17 |  |  | $ | 1.37 |  |  | $ | 0.69 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.07 |  |  |  | 0.07 |  |  |  | 0.07 |  |
| Stock-based compensation |  |  | 0.40 |  |  |  | 0.42 |  |  |  | 0.40 |  |
| Restructuring charges |  |  | 0.08 |  |  |  | — |  |  |  | 0.12 |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | 0.01 |  |
| Income tax effects |  |  | (0.17 | ) |  |  | (0.06 | ) |  |  | (0.14 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.56 |  |  | $ | 1.80 |  |  | $ | 1.15 |  |

[0000950170-24-101383:8k_2_02:142]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| Gross margin-GAAP |  |  | 71.3 | % |  |  | 70.5 | % |  |  | 69.6 | % |
| Cost of revenues adjustments |  |  | 0.9 | % |  |  | 1.0 | % |  |  | 1.1 | % |
| Gross margin-Non-GAAP |  |  | 72.2 | % |  |  | 71.5 | % |  |  | 70.7 | % |
| GAAP cost of revenues |  | $ | 443 |  |  | $ | 492 |  |  | $ | 436 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (8 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (7 | ) |  |  | (8 | ) |  |  | (7 | ) |
| Non-GAAP cost of revenues |  | $ | 428 |  |  | $ | 476 |  |  | $ | 420 |  |
| Net revenues |  | $ | 1,541 |  |  | $ | 1,668 |  |  | $ | 1,432 |  |

[0000950170-24-101383:8k_2_02:143]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| Product gross margin-GAAP |  |  | 59.8 | % |  |  | 61.0 | % |  |  | 55.1 | % |
| Cost of product revenues adjustments |  |  | 0.1 | % |  |  | 0.3 | % |  |  | 0.2 | % |
| Product gross margin-Non-GAAP |  |  | 59.9 | % |  |  | 61.3 | % |  |  | 55.3 | % |
| GAAP cost of product revenues |  | $ | 269 |  |  | $ | 314 |  |  | $ | 265 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (1 | ) |  |  | (2 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 268 |  |  | $ | 312 |  |  | $ | 264 |  |
| Product revenues |  | $ | 669 |  |  | $ | 806 |  |  | $ | 590 |  |

[0000950170-24-101383:8k_2_02:144]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| Services gross margin-GAAP |  |  | 80.0 | % |  |  | 79.4 | % |  |  | 79.7 | % |
| Cost of services revenues adjustments |  |  | 1.7 | % |  |  | 1.6 | % |  |  | 1.8 | % |
| Services gross margin-Non-GAAP |  |  | 81.7 | % |  |  | 81.0 | % |  |  | 81.5 | % |
| GAAP cost of services revenues |  | $ | 174 |  |  | $ | 178 |  |  | $ | 171 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (8 | ) |  |  | (9 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (6 | ) |  |  | (6 | ) |
| Non-GAAP cost of services revenues |  | $ | 160 |  |  | $ | 164 |  |  | $ | 156 |  |
| Services revenues |  | $ | 872 |  |  | $ | 862 |  |  | $ | 842 |  |

[0000950170-24-101383:8k_2_02:145]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| OPERATING MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| Operating margin-GAAP |  |  | 18.3 | % |  |  | 21.9 | % |  |  | 12.4 | % |
| Adjustments: |  |  | 7.6 | % |  |  | 6.2 | % |  |  | 9.1 | % |
| Operating margin-Non-GAAP |  |  | 25.9 | % |  |  | 28.1 | % |  |  | 21.6 | % |
| GAAP income from operations |  | $ | 282 |  |  | $ | 366 |  |  | $ | 178 |  |
| Income from operations adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 15 |  |
| Stock-based compensation |  |  | 85 |  |  |  | 88 |  |  |  | 87 |  |
| Restructuring charges |  |  | 17 |  |  |  | — |  |  |  | 26 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |
| Non-GAAP income from operations |  | $ | 399 |  |  | $ | 469 |  |  | $ | 309 |  |
| Net revenues |  | $ | 1,541 |  |  | $ | 1,668 |  |  | $ | 1,432 |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| GAAP effective tax rate |  |  | 17.1 | % |  |  | 23.4 | % |  |  | 19.9 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 3.6 | % |  |  | (2.5 | )% |  |  | 1.6 | % |
| Non-GAAP effective tax rate |  |  | 20.7 | % |  |  | 20.9 | % |  |  | 21.5 | % |

[0000950170-24-101383:8k_2_02:146]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| Net cash provided by operating activities |  | $ | 341 |  |  | $ | 613 |  |  | $ | 453 |  |
| Purchases of property and equipment |  |  | (41 | ) |  |  | (46 | ) |  |  | (35 | ) |
| Free cash flow |  | $ | 300 |  |  | $ | 567 |  |  | $ | 418 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY25 |  |  | Q4'FY24 |  |  | Q1'FY24 |  |
| Net revenues |  | $ | 1,541 |  |  | $ | 1,668 |  |  | $ | 1,432 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | (92 | ) |  |  | 146 |  |  |  | (133 | ) |
| Billings |  | $ | 1,449 |  |  | $ | 1,814 |  |  | $ | 1,299 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0000950170-24-101383:8k_2_02:147]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| SECOND QUARTER FISCAL 2025 |
|  |  | Second Quarter |
|  |  | Fiscal 2025 |
| GAAP Guidance - Net Income Per Share |  | $1.27 - $1.37 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the Second Quarter Fiscal 2025: |  |  |
| Amortization of intangible assets |  | $0.07 |
| Stock-based compensation expense |  | $0.48 |
| Income tax effects |  | ($0.09) |
| Total Adjustments |  | $0.46 |
| Non-GAAP Guidance - Net Income Per Share |  | $1.73 - $1.83 |

[0000950170-24-101383:8k_2_02:148]
Some items may not add or recalculate due to rounding.

[0000950170-24-101383:8k_2_02:149]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| Fiscal 2025 |
|  |  | Fiscal 2025 |
| Gross Margin - GAAP Guidance |  | 70% - 71% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | 1% |
| Gross Margin - Non-GAAP Guidance |  | 71% - 72% |
| Operating Margin - GAAP Guidance |  | 20% - 21% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | 1% |
| Stock-based compensation expense |  | 6% |
| Operating Margin - Non-GAAP Guidance |  | 27% - 28% |

[0000950170-24-101383:8k_2_02:150]
Some items may not add or recalculate due to rounding.

[0000950170-24-101383:8k_2_02:151]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| Fiscal 2025 |
|  |  | Fiscal 2025 |
| GAAP Guidance - Net Income Per Share |  | $5.17 - $5.37 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2025: |  |  |
| Amortization of intangible assets |  | $0.26 |
| Stock-based compensation expense |  | $1.86 |
| Restructuring charges |  | $0.08 |
| Acquisition-related expenses |  | $0.01 |
| Income tax effects |  | ($0.38) |
| Total Adjustments |  | $1.83 |
| Non-GAAP Guidance - Net Income Per Share |  | $7.00 - $7.20 |

[0000950170-24-101383:8k_2_02:152]
Some items may not add or recalculate due to rounding.

[0000950170-24-101383:8k_2_02:153]
Contacts:

[0000950170-24-101383:8k_2_02:154]
(Press)

[0000950170-24-101383:8k_2_02:155]
Kenya Hayes

[0000950170-24-101383:8k_2_02:156]
1 703 589 7595

[0000950170-24-101383:8k_2_02:157]
kenya.hayes@netapp.com

[0000950170-24-101383:8k_2_02:158]
(Investors)

[0000950170-24-101383:8k_2_02:159]
Kris Newton

[0000950170-24-101383:8k_2_02:160]
1 408 822 3312

[0000950170-24-101383:8k_2_02:161]
kris.newton@netapp.com

## item 5.02 — body, verbatim

[0000950170-24-101383:8k_body:1]
Item 5.02 Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0000950170-24-101383:8k_body:2]
On August 22, 2024, Michael J. Berry informed the Company of his decision to transition from his role of Executive Vice President and Chief Financial Officer by May 23, 2025. Mr. Berry has agreed to assist the Company with an orderly transition of his duties, as well as with the recruiting of a new Chief Financial Officer.
