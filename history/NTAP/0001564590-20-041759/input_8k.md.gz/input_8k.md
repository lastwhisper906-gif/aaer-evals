# NTAP 8-K — 0001564590-20-041346 filed 2020-08-26

## item codes, every 8-K on or before 2020-08-28

- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2020-08-28

- none on or before 2020-08-28

## item 2.02 — earnings release, exhibit 99.1

[0001564590-20-041346:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-20-041346:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-20-041346:8k_2_02:3]
Exhibit 99.1

[0001564590-20-041346:8k_2_02:4]
NetApp Reports First Quarter of Fiscal Year 2021 Results

[0001564590-20-041346:8k_2_02:5]
Net Revenues of $1.30 Billion; Up 5% Year-over-Year

[0001564590-20-041346:8k_2_02:6]
| • | NetApp™ public cloud services annualized recurring revenue of $178 million, an increase of 192% year-over-year |  |

[0001564590-20-041346:8k_2_02:7]
| • | All-flash array annualized net revenue run rate of $2.3 billion, an increase of 34% year-over-year |  |

[0001564590-20-041346:8k_2_02:8]
| • | Billings1 of $1.15 billion, increased 6% year-over-year |  |

[0001564590-20-041346:8k_2_02:9]
| • | Completed Spot and CloudJumper acquisitions, further extending our customer value proposition in the cloud |  |

[0001564590-20-041346:8k_2_02:10]
| • | $107 million returned to shareholders in cash dividend |  |

[0001564590-20-041346:8k_2_02:11]
Sunnyvale, Calif.—August 26, 2020—NetApp (NASDAQ: NTAP) today reported financial results for the first quarter of fiscal year 2021, which ended on July 31, 2020.

[0001564590-20-041346:8k_2_02:12]
“We executed well in the first quarter. Revenue, operating margin and EPS all exceeded our guidance, despite a challenging environment. Enterprises are increasingly prioritizing transformational and hybrid cloud projects, which drove our momentum as customers turn to NetApp to help them achieve these goals,” said George Kurian, chief executive officer. “We are building on a strong foundation of industry-leading data-centric software innovation, trusted customer relationships and an open-ecosystem approach that is strengthened by partnerships with the leading public cloud companies who endorse our Data Fabric Strategy. NetApp is uniquely positioned to help our customers unlock the best of cloud.”

[0001564590-20-041346:8k_2_02:13]
First Quarter of Fiscal Year 2021 Financial Results

[0001564590-20-041346:8k_2_02:14]
| • | Net Revenues: $1.30 billion, compared to $1.24 billion in the first quarter of fiscal year 2020 |  |

[0001564590-20-041346:8k_2_02:15]
| • | Net Income: GAAP net income of $77 million, compared to GAAP net income of $103 million in the first quarter of fiscal year 2020; non-GAAP net income2 of $163 million, compared to non-GAAP net income of $157 million in the first quarter of fiscal year 2020 |  |

[0001564590-20-041346:8k_2_02:16]
| • | Earnings per Share: GAAP net income per share3 of $0.35 compared to GAAP net income per share of $0.42 in the first quarter of fiscal year 2020; non-GAAP net income per share of $0.73, compared to non-GAAP net income per share of $0.65 in the first quarter of fiscal year 2020 |  |

[0001564590-20-041346:8k_2_02:17]
| • | Cash, Cash Equivalents and Investments: $3.77 billion at the end of the first quarter of fiscal year 2021 |  |

[0001564590-20-041346:8k_2_02:18]
| • | Cash Provided by Operations: $240 million, compared to $310 million in the first quarter of fiscal year 2020 |  |

[0001564590-20-041346:8k_2_02:19]
| • | Dividend: Returned $107 million to shareholders through cash dividend |  |

[0001564590-20-041346:8k_2_02:20]
Second Quarter of Fiscal Year 2021 Financial Outlook

[0001564590-20-041346:8k_2_02:21]
The company provided the following financial guidance for the second quarter of fiscal year 2021:

[0001564590-20-041346:8k_2_02:22]
| •Net revenues are expected to be in the range of: | $1.225 billion to $1.375 billion |  |
|  | GAAP | Non-GAAP |
| •Earnings per share is expected to be in the range of: | $0.28 - $0.36 | $0.66 - $0.74 |

[0001564590-20-041346:8k_2_02:23]
Dividend

[0001564590-20-041346:8k_2_02:24]
Next cash dividend of $0.48 per share to be paid on October 28, 2020, to shareholders of record as of the close of business on October 9, 2020.

[0001564590-20-041346:8k_2_02:25]
First Quarter of Fiscal Year 2021 Business Highlights

[0001564590-20-041346:8k_2_02:26]
Delivering Groundbreaking Product Innovations

[0001564590-20-041346:8k_2_02:27]
| • | NetApp announced the latest release of NetApp Active IQ™, which uses advanced artificial intelligence for IT operations (AIOps) to automate the proactive care and optimization of NetApp environments. It adds new interface features, new workloads, and a new customer experience. |

[0001564590-20-041346:8k_2_02:28]
| • | NetApp announced that NetApp HCI now offers a two-node storage cluster, providing a scalable entry point for customer workloads with the latest release of NetApp Element™ 12.0 and NetApp HCI 1.8. |

[0001564590-20-041346:8k_2_02:29]
Strategic Acquisitions and Partnerships

[0001564590-20-041346:8k_2_02:30]
| • | NetApp acquired Spot to establish leadership in application-driven infrastructure (ADI), offering a portfolio of compute and storage services that monitor and analyze the needs of applications and automatically optimize cloud resources |

[0001564590-20-041346:8k_2_02:31]
| • | NetApp acquired a leading virtual desktop infrastructure (VDI) player CloudJumper and launched the new NetApp Virtual Desktop Service, giving customers a simple and secure path to manage current environments alongside their new remote desktop. |

[0001564590-20-041346:8k_2_02:32]
| • | NetApp and Cleondris expanded their partnership to bring to market a simple, seamless disaster recovery experience for NetApp HCI with Cleondris HCI Control Center. |

[0001564590-20-041346:8k_2_02:33]
| • | NetApp and Commvault partnered to create a solution for backing up data with NetApp AFF and NetApp StorageGRID™ using Commvault software. |

[0001564590-20-041346:8k_2_02:34]
| • | NetApp announced support for HashiCorp Vault Enterprise 1.3, a key manager that complies with Key Management Interoperability Protocol (KMIP) and is secure, scalable, and easy to implement for NetApp ONTAP™ software-based and hardware-based data-at-rest encryption. |

[0001564590-20-041346:8k_2_02:35]
| • | NetApp announced a partnership with cnvrg.io, using the cnvrg.io dataset caching tool and NetApp ONTAP AI to deliver an AI and machine language (AI/ML) data science pipeline solution that is streamlined and improves productivity and efficiency. |

[0001564590-20-041346:8k_2_02:36]
| • | The U.S. Department of Veterans Affairs expanded its NetApp FlexPod™ converged infrastructure for remote access environments, enabling additional users and services. NetApp is offering 25TB of NetApp Cloud Volumes Service for Google Cloud free of charge for 90 days for IT teams that are addressing the digital fallout of the COVID-19 pandemic. |

[0001564590-20-041346:8k_2_02:37]
NetApp Growth and Leadership

[0001564590-20-041346:8k_2_02:38]
| • | NetApp is expanding its partner-first approach with updates to the Unified Partner Program to complement and align with its partners’ business capabilities and models. |

[0001564590-20-041346:8k_2_02:39]
| • | NetApp appointed Cesar Cernuda as president of NetApp, reporting to George Kurian and leading global go-to-market operations. |

[0001564590-20-041346:8k_2_02:40]
Webcast and Conference Call Information

[0001564590-20-041346:8k_2_02:41]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:00 p.m. Pacific Time today.

[0001564590-20-041346:8k_2_02:42]
###

[0001564590-20-041346:8k_2_02:43]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-20-041346:8k_2_02:44]
Footnotes

[0001564590-20-041346:8k_2_02:45]
1Refer to the NetApp Usage of Non-GAAP Financial Information section below for an explanation of billings.

[0001564590-20-041346:8k_2_02:46]
2Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) COVID-19 charges and (i) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making

[0001564590-20-041346:8k_2_02:47]
operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-20-041346:8k_2_02:48]
3GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0001564590-20-041346:8k_2_02:49]
NetApp Usage of Non-GAAP Financial Information

[0001564590-20-041346:8k_2_02:50]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share. NetApp also presents the hardware and software components of our GAAP product revenues. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0001564590-20-041346:8k_2_02:51]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations.

[0001564590-20-041346:8k_2_02:52]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-20-041346:8k_2_02:53]
NetApp believes that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0001564590-20-041346:8k_2_02:54]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services

[0001564590-20-041346:8k_2_02:55]
revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it represents the amounts under purchase orders received by us during a given period that have been billed.

[0001564590-20-041346:8k_2_02:56]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-20-041346:8k_2_02:57]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-20-041346:8k_2_02:58]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-20-041346:8k_2_02:59]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-20-041346:8k_2_02:60]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-20-041346:8k_2_02:61]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-20-041346:8k_2_02:62]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-20-041346:8k_2_02:63]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-20-041346:8k_2_02:64]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes

[0001564590-20-041346:8k_2_02:65]
that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-20-041346:8k_2_02:66]
H. COVID-19 charges. NetApp has excluded certain non-recurring expenses incurred as a direct result of the COVID-19 pandemic. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-20-041346:8k_2_02:67]
I. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-20-041346:8k_2_02:68]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-20-041346:8k_2_02:69]
About NetApp

[0001564590-20-041346:8k_2_02:70]
NetApp is the leader in cloud data services, empowering global organizations to change their world with data. Together with our partners, we are the only ones who can help you build your unique data fabric. Simplify hybrid multicloud and securely deliver the right data, services and applications to the right people at the right time. Learn more at www.netapp.com.

[0001564590-20-041346:8k_2_02:71]
NETAPP, INC.

[0001564590-20-041346:8k_2_02:72]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-20-041346:8k_2_02:73]
(In millions)

[0001564590-20-041346:8k_2_02:74]
(Unaudited)

[0001564590-20-041346:8k_2_02:75]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,773 |  |  | $ | 2,882 |  |
| Accounts receivable |  |  | 604 |  |  |  | 973 |  |
| Inventories |  |  | 136 |  |  |  | 145 |  |
| Other current assets |  |  | 304 |  |  |  | 274 |  |
| Total current assets |  |  | 4,817 |  |  |  | 4,274 |  |
| Property and equipment, net |  |  | 737 |  |  |  | 727 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,178 |  |  |  | 1,822 |  |
| Other non-current assets |  |  | 684 |  |  |  | 699 |  |
| Total assets |  | $ | 8,416 |  |  | $ | 7,522 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 396 |  |  | $ | 426 |  |
| Accrued expenses |  |  | 616 |  |  |  | 774 |  |
| Commercial paper notes |  |  | 150 |  |  |  | 522 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,814 |  |  |  | 1,894 |  |
| Total current liabilities |  |  | 2,976 |  |  |  | 3,616 |  |
| Long-term debt |  |  | 2,630 |  |  |  | 1,146 |  |
| Other long-term liabilities |  |  | 720 |  |  |  | 714 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,806 |  |  |  | 1,804 |  |
| Total liabilities |  |  | 8,132 |  |  |  | 7,280 |  |
| Stockholders' equity |  |  | 284 |  |  |  | 242 |  |
| Total liabilities and stockholders' equity |  | $ | 8,416 |  |  | $ | 7,522 |  |

[0001564590-20-041346:8k_2_02:76]
NETAPP, INC.

[0001564590-20-041346:8k_2_02:77]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-20-041346:8k_2_02:78]
(In millions, except per share amounts)

[0001564590-20-041346:8k_2_02:79]
(Unaudited)

[0001564590-20-041346:8k_2_02:80]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Revenues: |  |  |  |  |  |  |  |  |
| Product |  | $ | 627 |  |  | $ | 644 |  |
| Software maintenance |  |  | 301 |  |  |  | 250 |  |
| Hardware maintenance and other services |  |  | 375 |  |  |  | 342 |  |
| Net revenues |  |  | 1,303 |  |  |  | 1,236 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 316 |  |  |  | 312 |  |
| Cost of software maintenance |  |  | 15 |  |  |  | 10 |  |
| Cost of hardware maintenance and other services |  |  | 100 |  |  |  | 98 |  |
| Total cost of revenues |  |  | 431 |  |  |  | 420 |  |
| Gross profit |  |  | 872 |  |  |  | 816 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 429 |  |  |  | 405 |  |
| Research and development |  |  | 233 |  |  |  | 215 |  |
| General and administrative |  |  | 61 |  |  |  | 71 |  |
| Restructuring charges |  |  | 5 |  |  |  | 21 |  |
| Acquisition-related expense |  |  | 8 |  |  |  | — |  |
| Total operating expenses |  |  | 736 |  |  |  | 712 |  |
| Income from operations |  |  | 136 |  |  |  | 104 |  |
| Other income (expense), net |  |  | (32 | ) |  |  | 15 |  |
| Income before income taxes |  |  | 104 |  |  |  | 119 |  |
| Provision for income taxes |  |  | 27 |  |  |  | 16 |  |
| Net income |  | $ | 77 |  |  | $ | 103 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.35 |  |  | $ | 0.43 |  |
| Diluted |  | $ | 0.35 |  |  | $ | 0.42 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |
| Basic |  |  | 221 |  |  |  | 239 |  |
| Diluted |  |  | 222 |  |  |  | 243 |  |

[0001564590-20-041346:8k_2_02:81]
NETAPP, INC.

[0001564590-20-041346:8k_2_02:82]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-20-041346:8k_2_02:83]
(In millions)

[0001564590-20-041346:8k_2_02:84]
(Unaudited)

[0001564590-20-041346:8k_2_02:85]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 77 |  |  | $ | 103 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 49 |  |  |  | 49 |  |
| Non-cash operating lease cost |  |  | 13 |  |  |  | 13 |  |
| Stock-based compensation |  |  | 54 |  |  |  | 42 |  |
| Deferred income taxes |  |  | — |  |  |  | (7 | ) |
| Other items, net |  |  | 25 |  |  |  | (7 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 391 |  |  |  | 672 |  |
| Inventories |  |  | 9 |  |  |  | 15 |  |
| Accounts payable |  |  | (29 | ) |  |  | (195 | ) |
| Accrued expenses |  |  | (186 | ) |  |  | (277 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (158 | ) |  |  | (154 | ) |
| Long-term taxes payable |  |  | 6 |  |  |  | (3 | ) |
| Changes in other operating assets and liabilities, net |  |  | (11 | ) |  |  | 59 |  |
| Net cash provided by operating activities |  |  | 240 |  |  |  | 310 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 85 |  |  |  | 1,027 |  |
| Purchases of property and equipment |  |  | (52 | ) |  |  | (32 | ) |
| Proceeds from sale of properties |  |  | 6 |  |  |  | — |  |
| Acquisitions of businesses, net of cash acquired |  |  | (350 | ) |  |  | (56 | ) |
| Other investing activities, net |  |  | — |  |  |  | (1 | ) |
| Net cash provided by (used in) investing activities |  |  | (311 | ) |  |  | 938 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 48 |  |  |  | 54 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (33 | ) |  |  | (71 | ) |
| Repurchase of common stock |  |  | — |  |  |  | (250 | ) |
| Repayments of commercial paper notes, original maturities of three months or less, net |  |  | (370 | ) |  |  | (219 | ) |
| Issuance of debt, net of issuance costs |  |  | 2,057 |  |  |  | — |  |
| Repayments and extinguishment of debt |  |  | (589 | ) |  |  | — |  |
| Dividends paid |  |  | (107 | ) |  |  | (115 | ) |
| Other financing activities, net |  |  | (3 | ) |  |  | (2 | ) |
| Net cash provided by (used in) financing activities |  |  | 1,003 |  |  |  | (603 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 43 |  |  |  | (3 | ) |
| Net increase in cash, cash equivalents and restricted cash |  |  | 975 |  |  |  | 642 |  |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,666 |  |  |  | 2,331 |  |
| End of period |  | $ | 3,641 |  |  | $ | 2,973 |  |

[0001564590-20-041346:8k_2_02:86]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q1 FY'21 |  |  | Q4 FY'20 |  |  | Q1 FY'20 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 627 |  |  | $ | 793 |  |  | $ | 644 |  |
| Software Maintenance |  | $ | 301 |  |  | $ | 267 |  |  | $ | 250 |  |
| Hardware Maintenance & Other Services |  | $ | 375 |  |  | $ | 341 |  |  | $ | 342 |  |
| Hardware Maintenance Support Contracts |  | $ | 307 |  |  | $ | 279 |  |  | $ | 284 |  |
| Professional and Other Services |  | $ | 68 |  |  | $ | 62 |  |  | $ | 58 |  |
| Net Revenues |  | $ | 1,303 |  |  | $ | 1,401 |  |  | $ | 1,236 |  |
| Product Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 627 |  |  | $ | 793 |  |  | $ | 644 |  |
| Software* |  | $ | 311 |  |  | $ | 407 |  |  | $ | 306 |  |
| Hardware* |  | $ | 316 |  |  | $ | 386 |  |  | $ | 338 |  |
| * Our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation. We have provided a breakdown of our GAAP product revenues into the software and hardware components to display the significance of software included in total product revenues. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'21 Revenue |  |  | % of Q4 FY'20 Revenue |  |  | % of Q1 FY'20 Revenue |  |
| Americas |  |  | 54 | % |  |  | 54 | % |  |  | 51 | % |
| Americas Commercial |  |  | 43 | % |  |  | 43 | % |  |  | 38 | % |
| U.S. Public Sector |  |  | 12 | % |  |  | 11 | % |  |  | 13 | % |
| EMEA |  |  | 29 | % |  |  | 32 | % |  |  | 33 | % |
| Asia Pacific |  |  | 16 | % |  |  | 14 | % |  |  | 16 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'21 Revenue |  |  | % of Q4 FY'20 Revenue |  |  | % of Q1 FY'20 Revenue |  |
| Direct |  |  | 22 | % |  |  | 23 | % |  |  | 19 | % |
| Indirect |  |  | 78 | % |  |  | 77 | % |  |  | 81 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'21 |  |  | Q4 FY'20 |  |  | Q1 FY'20 |  |
| Non-GAAP Gross Margin |  |  | 68.0 | % |  |  | 68.0 | % |  |  | 67.2 | % |
| Product |  |  | 51.4 | % |  |  | 56.4 | % |  |  | 53.4 | % |
| Software Maintenance |  |  | 95.0 | % |  |  | 94.4 | % |  |  | 96.0 | % |
| Hardware Maintenance & Other Services |  |  | 74.1 | % |  |  | 74.5 | % |  |  | 71.9 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'21 |  |  | Q4 FY'20 |  |  | Q1 FY'20 |  |
| Non-GAAP Income from Operations |  | $ | 213 |  |  | $ | 324 |  |  | $ | 178 |  |
| % of Net Revenues |  |  | 16.3 | % |  |  | 23.1 | % |  |  | 14.4 | % |
| Non-GAAP Income before Income Taxes |  | $ | 195 |  |  | $ | 307 |  |  | $ | 193 |  |
| Non-GAAP Effective Tax Rate |  |  | 16.4 | % |  |  | 13.7 | % |  |  | 18.7 | % |

[0001564590-20-041346:8k_2_02:87]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'21 |  |  | Q4 FY'20 |  |  | Q1 FY'20 |  |
| Non-GAAP Net Income |  | $ | 163 |  |  | $ | 265 |  |  | $ | 157 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 222 |  |  |  | 222 |  |  |  | 243 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 0.73 |  |  | $ | 1.19 |  |  | $ | 0.65 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'21 |  |  | Q4 FY'20 |  |  | Q1 FY'20 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,620 |  |  | $ | 3,698 |  |  | $ | 3,510 |  |
| DSO (days) |  |  | 45 |  |  |  | 63 |  |  |  | 40 |  |
| DPO (days) |  |  | 90 |  |  |  | 84 |  |  |  | 75 |  |
| Inventory Turns |  |  | 13 |  |  |  | 13 |  |  |  | 14 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'21 |  |  | Q4 FY'20 |  |  | Q1 FY'20 |  |
| Net Cash Provided by Operating Activities |  | $ | 240 |  |  | $ | 383 |  |  | $ | 310 |  |
| Purchases of Property and Equipment |  | $ | 52 |  |  | $ | 24 |  |  | $ | 32 |  |
| Free Cash Flow |  | $ | 188 |  |  | $ | 359 |  |  | $ | 278 |  |
| Free Cash Flow as % of Net Revenues |  |  | 14.4 | % |  |  | 25.6 | % |  |  | 22.5 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001564590-20-041346:8k_2_02:88]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY21 |  | Q4'FY20 |  | Q1'FY20 |  |
| NET INCOME |  | $ | 77 |  | $ | 196 |  | $ | 103 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 10 |  |  | 9 |  |  | 11 |  |
| Stock-based compensation |  |  | 54 |  |  | 35 |  |  | 42 |  |
| Asset impairment |  |  | — |  |  | 10 |  |  | — |  |
| COVID-19 charges |  |  | — |  |  | 3 |  |  | — |  |
| Restructuring charges |  |  | 5 |  |  | — |  |  | 21 |  |
| Acquisition-related expense |  |  | 8 |  |  | — |  |  | — |  |
| Debt extinguishment costs |  |  | 14 |  |  | — |  |  | — |  |
| Income tax effects |  |  | (16 | ) |  | 12 |  |  | (20 | ) |
| Income tax expenses from integration of acquired companies |  |  | 11 |  |  | — |  |  | — |  |
| NON-GAAP NET INCOME |  | $ | 163 |  | $ | 265 |  | $ | 157 |  |
| COST OF REVENUES |  | $ | 431 |  | $ | 460 |  | $ | 420 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  | (9 | ) |  | (11 | ) |
| Stock-based compensation |  |  | (4 | ) |  | (3 | ) |  | (3 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 417 |  | $ | 448 |  | $ | 406 |  |
| COST OF PRODUCT REVENUES |  | $ | 316 |  | $ | 355 |  | $ | 312 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  | (9 | ) |  | (11 | ) |
| Stock-based compensation |  |  | (1 | ) | — |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 305 |  | $ | 346 |  | $ | 300 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 100 |  | $ | 90 |  | $ | 98 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  | (3 | ) |  | (2 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 97 |  | $ | 87 |  | $ | 96 |  |
| GROSS PROFIT |  | $ | 872 |  | $ | 941 |  | $ | 816 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 10 |  |  | 9 |  |  | 11 |  |
| Stock-based compensation |  |  | 4 |  |  | 3 |  |  | 3 |  |
| NON-GAAP GROSS PROFIT |  | $ | 886 |  | $ | 953 |  | $ | 830 |  |

[0001564590-20-041346:8k_2_02:89]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY21 |  | Q4'FY20 |  | Q1'FY20 |  |
| SALES AND MARKETING EXPENSES |  | $ | 429 |  | $ | 389 |  | $ | 405 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (25 | ) |  | (16 | ) |  | (18 | ) |
| COVID-19 charges |  |  | — |  |  | (3 | ) |  | — |  |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 404 |  | $ | 370 |  | $ | 387 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 233 |  | $ | 212 |  | $ | 215 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (19 | ) |  | (12 | ) |  | (15 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 214 |  | $ | 200 |  | $ | 200 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 61 |  | $ | 63 |  | $ | 71 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (6 | ) |  | (4 | ) |  | (6 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 55 |  | $ | 59 |  | $ | 65 |  |
| RESTRUCTURING CHARGES |  | $ | 5 |  | $ | — |  | $ | 21 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (5 | ) |  | — |  |  | (21 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  | $ | — |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 8 |  | $ | — |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (8 | ) |  | — |  |  | — |  |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  | $ | — |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 736 |  | $ | 664 |  | $ | 712 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (50 | ) |  | (32 | ) |  | (39 | ) |
| COVID-19 charges |  |  | — |  |  | (3 | ) |  | — |  |
| Restructuring charges |  |  | (5 | ) |  | — |  |  | (21 | ) |
| Acquisition-related expense |  |  | (8 | ) |  | — |  |  | — |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 673 |  | $ | 629 |  | $ | 652 |  |

[0001564590-20-041346:8k_2_02:90]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY21 |  | Q4'FY20 |  | Q1'FY20 |  |
| INCOME FROM OPERATIONS |  | $ | 136 |  | $ | 277 |  | $ | 104 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 10 |  |  | 9 |  |  | 11 |  |
| Stock-based compensation |  |  | 54 |  |  | 35 |  |  | 42 |  |
| COVID-19 charges |  |  | — |  |  | 3 |  |  | — |  |
| Restructuring charges |  |  | 5 |  |  | — |  |  | 21 |  |
| Acquisition-related expense |  |  | 8 |  |  | — |  |  | — |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 213 |  | $ | 324 |  | $ | 178 |  |
| OTHER INCOME (EXPENSE), NET |  | $ | (32 | ) | $ | (27 | ) | $ | 15 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Debt extinguishment costs |  |  | 14 |  |  | — |  |  | — |  |
| Asset impairment |  |  | — |  |  | 10 |  |  | — |  |
| NON-GAAP OTHER INCOME (EXPENSE), NET |  | $ | (18 | ) | $ | (17 | ) | $ | 15 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 104 |  | $ | 250 |  | $ | 119 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 10 |  |  | 9 |  |  | 11 |  |
| Stock-based compensation |  |  | 54 |  |  | 35 |  |  | 42 |  |
| Asset impairment |  |  | — |  |  | 10 |  |  | — |  |
| COVID-19 charges |  |  | — |  |  | 3 |  |  | — |  |
| Restructuring charges |  |  | 5 |  | — |  |  | 21 |  |
| Acquisition-related expense |  |  | 8 |  | — |  |  | — |  |
| Debt extinguishment costs |  |  | 14 |  | — |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 195 |  | $ | 307 |  | $ | 193 |  |
| PROVISION FOR INCOME TAXES |  | $ | 27 |  | $ | 54 |  | $ | 16 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 16 |  |  | (12 | ) |  | 20 |  |
| Income tax expenses from integration of acquired companies |  |  | (11 | ) |  | — |  |  |  |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 32 |  | $ | 42 |  | $ | 36 |  |
| NET INCOME PER SHARE |  | $ | 0.35 |  | $ | 0.88 |  | $ | 0.42 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  | 0.04 |  |  | 0.05 |  |
| Stock-based compensation |  |  | 0.24 |  |  | 0.16 |  |  | 0.17 |  |
| Asset impairment |  |  | — |  |  | 0.05 |  |  | — |  |
| COVID-19 charges |  |  | — |  |  | 0.01 |  |  | — |  |
| Restructuring charges |  |  | 0.02 |  | — |  |  | 0.09 |  |
| Acquisition-related expense |  |  | 0.04 |  | — |  |  | — |  |
| Debt extinguishment costs |  |  | 0.06 |  | — |  |  | — |  |
| Income tax effects |  |  | (0.07 | ) |  | 0.05 |  |  | (0.08 | ) |
| Income tax expenses from integration of acquired companies |  |  | 0.05 |  |  | — |  |  | — |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.73 |  | $ | 1.19 |  | $ | 0.65 |  |

[0001564590-20-041346:8k_2_02:91]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY21 |  | Q4'FY20 |  | Q1'FY20 |  |
| Gross margin-GAAP |  |  | 66.9 | % |  | 67.2 | % |  | 66.0 | % |
| Cost of revenues adjustments |  |  | 1.1 | % |  | 0.9 | % |  | 1.1 | % |
| Gross margin-Non-GAAP |  |  | 68.0 | % |  | 68.0 | % |  | 67.2 | % |
| GAAP cost of revenues |  | $ | 431 |  | $ | 460 |  | $ | 420 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  | (9 | ) |  | (11 | ) |
| Stock-based compensation |  |  | (4 | ) |  | (3 | ) |  | (3 | ) |
| Non-GAAP cost of revenues |  | $ | 417 |  | $ | 448 |  | $ | 406 |  |
| Net revenues |  | $ | 1,303 |  | $ | 1,401 |  | $ | 1,236 |  |

[0001564590-20-041346:8k_2_02:92]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY21 |  | Q4'FY20 |  | Q1'FY20 |  |
| Product gross margin-GAAP |  |  | 49.6 | % |  | 55.2 | % |  | 51.6 | % |
| Cost of product revenues adjustments |  |  | 1.8 | % |  | 1.1 | % |  | 1.9 | % |
| Product gross margin-Non-GAAP |  |  | 51.4 | % |  | 56.4 | % |  | 53.4 | % |
| GAAP cost of product revenues |  | $ | 316 |  | $ | 355 |  | $ | 312 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  | (9 | ) |  | (11 | ) |
| Stock-based compensation |  |  | (1 | ) | — |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 305 |  | $ | 346 |  | $ | 300 |  |
| Product revenues |  | $ | 627 |  | $ | 793 |  | $ | 644 |  |

[0001564590-20-041346:8k_2_02:93]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY21 |  | Q4'FY20 |  | Q1'FY20 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 73.3 | % |  | 73.6 | % |  | 71.3 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.8 | % |  | 0.9 | % |  | 0.6 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 74.1 | % |  | 74.5 | % |  | 71.9 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 100 |  | $ | 90 |  | $ | 98 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  | (3 | ) |  | (2 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 97 |  | $ | 87 |  | $ | 96 |  |
| Hardware maintenance and other services revenues |  | $ | 375 |  | $ | 341 |  | $ | 342 |  |

[0001564590-20-041346:8k_2_02:94]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q1'FY21 |  | Q4'FY20 |  | Q1'FY20 |  |
| GAAP effective tax rate |  |  | 26.0 | % |  | 21.6 | % |  | 13.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 1.0 | % |  | (7.9 | )% |  | 5.3 | % |
| Income tax expenses from integration of acquired companies |  |  | (10.6 | )% |  | — | % |  | — | % |
| Non-GAAP effective tax rate |  |  | 16.4 | % |  | 13.7 | % |  | 18.7 | % |

[0001564590-20-041346:8k_2_02:95]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY21 |  | Q4'FY20 |  | Q1'FY20 |  |
| Net cash provided by operating activities |  | $ | 240 |  | $ | 383 |  | $ | 310 |  |
| Purchases of property and equipment |  |  | (52 | ) |  | (24 | ) |  | (32 | ) |
| Free cash flow |  | $ | 188 |  | $ | 359 |  | $ | 278 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY21 |  | Q4'FY20 |  | Q1'FY20 |  |
| Net revenues |  | $ | 1,303 |  | $ | 1,401 |  | $ | 1,236 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | (158 | ) |  | 147 |  |  | (154 | ) |
| Billings |  | $ | 1,145 |  | $ | 1,548 |  | $ | 1,082 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |  |  |  |  |  |  |  |  |  |

[0001564590-20-041346:8k_2_02:96]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| SECOND QUARTER FISCAL 2021 |  |
|  |  | Second Quarter |  |
|  |  | Fiscal 2021 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $0.66 - $0.74 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Second Quarter Fiscal 2021: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.07 | ) |
| Stock-based compensation expense |  |  | (0.20 | ) |
| Restructuring charges |  |  | (0.17 | ) |
| Income tax effects |  |  | 0.06 |  |
| Total Adjustments |  |  | (0.38 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.28 - $0.36 |  |

[0001564590-20-041346:8k_2_02:97]
Some items may not add or recalculate due to rounding.

[0001564590-20-041346:8k_2_02:98]
Press Contact:

[0001564590-20-041346:8k_2_02:99]
Amelia Vierra

[0001564590-20-041346:8k_2_02:100]
NetApp

[0001564590-20-041346:8k_2_02:101]
1 408 822 6403

[0001564590-20-041346:8k_2_02:102]
amelia.vierra@netapp.com

[0001564590-20-041346:8k_2_02:103]
Investor Contact:

[0001564590-20-041346:8k_2_02:104]
Lance Berger

[0001564590-20-041346:8k_2_02:105]
NetApp

[0001564590-20-041346:8k_2_02:106]
1 408 822 6628

[0001564590-20-041346:8k_2_02:107]
lance.berger@netapp.com

## item 5.02 — body, verbatim

[0001564590-20-041346:8k_body:1]
Item 5.02     Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001564590-20-041346:8k_body:2]
(c)

[0001564590-20-041346:8k_body:3]
On August 21, 2020, Scott R. Allen informed the Company of his intent to resign as Senior Vice President, Chief Accounting Officer and as principal accounting officer of the Company, effective September 18, 2020.

[0001564590-20-041346:8k_body:4]
Forward Looking Statements

[0001564590-20-041346:8k_body:5]
This Current Report on Form 8-K contains forward-looking statements within the meaning of Section 27A of the Securities Act of 1933, as amended, and Section 21E of the Securities Exchange Act of 1934, as amended. These statements include expectations regarding the design of the restructuring, the total headcount impacted by the restructuring, the aggregate charges for employee terminations and other costs associated with the restructuring, the related cash expenditures and the timing to recognize these charges. All of these forward-looking statements involve risk and uncertainty. Actual results may differ materially from these statements for a variety of reasons, including, without limitation, the timing and execution of the restructuring. These and other equally important factors are described in reports and documents we file from time to time with the Securities and Exchange Commission, including the factors described under the sections titled “Risk Factors” in our most recently submitted Annual Report on Form 10-K. We disclaim any obligation to update information contained in these forward-looking statements whether as a result of new information, future events, or otherwise.
