# NTAP note change history — 0001564590-20-005025 → 0001564590-20-041759


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-08-28):
[0001564590-20-041759:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 31, 2020, we had $614 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 31, 2020 and April 24, 2020, such liability amounted to $7 million and $6 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2020-02-18, similarity 0.9929):
[0001564590-20-005025:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 24, 2020, we had $486 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 24, 2020 and April 26, 2019, such liability amounted to $10 million and $16 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2020-08-28):
[0001564590-20-041759:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 31, 2020, we had $205 million in other purchase obligations.
  (was, 2020-02-18, similarity 0.8732):
[0001564590-20-005025:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 24, 2020, we had $7 million in construction related obligations and $234 million in other purchase obligations.

- changed (2020-08-28):
[0001564590-20-041759:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $13 million and $14 million of receivables during the three months ended July 31, 2020 and July 26, 2019, respectively.
  (was, 2020-02-18, similarity 0.9896):
[0001564590-20-005025:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $49 million and $54 million of receivables during the nine months ended January 24, 2020 and January 25, 2019, respectively.

- changed (2020-08-28):
[0001564590-20-041759:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of July 31, 2020 and April 24, 2020, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2020-02-18, similarity 0.9969):
[0001564590-20-005025:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of January 24, 2020 and April 26, 2019, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- changed (2020-08-28):
[0001564590-20-041759:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 31, 2020, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.
  (was, 2020-02-18, similarity 0.9961):
[0001564590-20-005025:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 24, 2020, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- changed (2020-08-28):
[0001564590-20-041759:note_history:6]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends.  No material accrual has been recorded as of July 31, 2020 related to such matters.
  (was, 2020-02-18, similarity 0.9961):
[0001564590-20-005025:note_history:6]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends.  No material accrual has been recorded as of January 24, 2020 related to such matters.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-08-28):
[0001564590-20-041759:note_history:7]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2021, ending on April 30, 2021 is a 53-week year, with 14 weeks included in its first quarter and 13 weeks in each subsequent quarter. Fiscal year 2020, which ended on April 24, 2020, was a 52-week year, with 13 weeks in each of its quarters.
  (was, 2020-02-18, similarity 0.7311):
[0001564590-20-005025:note_history:7]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal years 2020 and 2019, ending on April 24, 2020, and April 26, 2019, respectively, are each 52-week years, with 13 weeks in each of their quarters.

- changed (2020-08-28):
[0001564590-20-041759:note_history:8]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2020 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 31, 2020 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2020-02-18, similarity 0.9926):
[0001564590-20-005025:note_history:8]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 26, 2019 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 24, 2020 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- changed (2020-08-28):
[0001564590-20-041759:note_history:9]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates. Management’s estimates include, as applicable, the anticipated impacts of the COVID-19 pandem
  (was, 2020-02-18, similarity 0.9289):
[0001564590-20-005025:note_history:9]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

- removed (2020-08-28):
[0001564590-20-005025:note_history:10]
Accounting Changes

- removed (2020-08-28):
[0001564590-20-005025:note_history:11]
In February 2016, the FASB issued an accounting standards update on financial reporting for leasing arrangements, including requiring lessees to recognize an operating lease with a term greater than one year on their balance sheets as a right-of-use (ROU) asset and corresponding lease liability, measured at the present value of the lease payments. In the first quarter of fiscal 2020, we adopted this new standard using the modified retrospective approach, electing the optional transition approach of not adjusting our comparative period financial statements for the impacts of adoption. We also elected the package of practical expedients that did not require us to reassess existing leases under the new guidance, and the practical expedient to not separate lease and non-lease components for all leases. Adoption of the new standard on April 27, 2019 resulted in the recognition of approximately $149 million of operating lease ROU assets, net of deferred rent and lease restructuring liabilities, $158 million of lease liabilities, and a cumulative-effect adjustment to retained earnings of $6 million on our condensed consolidated balance sheets. Adoption of the standard did not have a material impact on our condensed consolidated statements of operations or condensed consolidated statements of cash flows. Additional information is presented below and in Note 9 – Leases.

- removed (2020-08-28):
[0001564590-20-005025:note_history:12]
Leases − We determine if an arrangement is or contains a lease at inception, and we classify leases as operating or finance leases at commencement. In our condensed consolidated balance sheets, operating lease ROU assets are included in other non-current assets, while finance lease ROU assets are included in property and equipment, net. Lease liabilities for both types of leases are included in accrued expenses and other long-term liabilities. ROU assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over that term.

- removed (2020-08-28):
[0001564590-20-005025:note_history:13]
Operating and finance lease ROU assets and liabilities are recognized at commencement based on the present value of lease payments over the lease term. ROU assets also include any lease payments made prior to lease commencement and exclude lease incentives. The lease term is the noncancelable period of the lease and includes options to extend or terminate the lease when it is reasonably certain that an option will be exercised. As the rate implicit in our leases is typically not readily determinable, in computing the present value of lease payments we generally use our incremental borrowing rate based on information available at the commencement date. Variable lease payments not dependent on an index or rate are expensed as incurred and not included within the calculation of ROU assets and lease liabilities. Lease expense for lease payments is recognized on a straight-line basis over the lease term.

- removed (2020-08-28):
[0001564590-20-005025:note_history:14]
We do not separate non-lease components from lease components for any class of leases, and we do not recognize ROU assets and lease liabilities for leases with a lease term of twelve months or less.

- removed (2020-08-28):
[0001564590-20-005025:note_history:15]
There have been no other significant changes in our significant accounting policies as of and for the nine months ended January 24, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 26, 2019.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-28):
[0001564590-20-041759:note_history:16]
|  |  |  |  |  |  | July 31, 2020 |  |  | April 24, 2020 |  |
|  |  | Effective Interest Rate |  |  | Amount |  |  | Amount |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  | $ | — |  |  | $ | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | — |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | — |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | — |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 1,150 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (20 | ) |  |  | (4 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,630 |  |  | $ | 1,146 |  |
  (was, 2020-02-18, similarity 0.6994):
[0001564590-20-005025:note_history:16]
|  |  |  |  |  |  | January 24, 2020 |  |  | April 26, 2019 |  |
|  |  | Effective Interest Rate |  |  | Amount |  |  | Amount |  |
| 2.00% Senior Notes Due September 2019 |  | 2.32% |  |  | $ | — |  |  | $ | 400 |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  |  | 500 |  |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| Total principal amount |  |  |  |  |  |  | 1,150 |  |  |  | 1,550 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (4 | ) |  |  | (6 | ) |
| Total senior notes |  |  |  |  |  |  | 1,146 |  |  |  | 1,544 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | — |  |  |  | (400 | ) |
| Total long-term debt |  |  |  |  |  | $ | 1,146 |  |  | $ | 1,144 |  |

- added (2020-08-28):
[0001564590-20-041759:note_history:17]
In June 2020, we issued $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, for which we received total proceeds of approximately $2.0 billion, net of discount and issuance costs. Interest on these Senior Notes is payable semi-annually in June and December. On July 27, 2020, we extinguished our 3.375% Senior Notes due June 2021 for an aggregate cash redemption price of $513 million, plus accrued and unpaid interest. As part of the debt extinguishment, we recognized a loss of $14 million, which includes a cash redemption premium of $13 million and the write-off of unamortized discount and issuance costs totaling $1 million. The loss on extinguishment of debt is included in other income (expense), net in our Condensed Consolidated Statement of Operations for the three months ended July 31, 2020.

- added (2020-08-28):
[0001564590-20-041759:note_history:18]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September. Our 3.25% Senior Notes, with a principal amount of $250 million, were issued in December 2012 with interest paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

- changed (2020-08-28):
[0001564590-20-041759:note_history:19]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 31, 2020, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2020-02-18, similarity 0.9946):
[0001564590-20-005025:note_history:19]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 24, 2020, we were in compliance with all covenants associated with the Senior Notes.

- changed (2020-08-28):
[0001564590-20-041759:note_history:20]
As of July 31, 2020, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2020-02-18, similarity 0.973):
[0001564590-20-005025:note_history:20]
As of January 24, 2020, our aggregate future principal debt maturities are as follows (in millions):

- changed (2020-08-28):
[0001564590-20-041759:note_history:21]
| Fiscal Year |  | Amount |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |
  (was, 2020-02-18, similarity 0.8789):
[0001564590-20-005025:note_history:21]
| Fiscal Year |  | Amount |  |
| 2022 |  | $ | 500 |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| Total |  | $ | 1,150 |  |

- changed (2020-08-28):
[0001564590-20-041759:note_history:22]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of July 31, 2020 and April 24, 2020, we had commercial paper notes outstanding with aggregate principal amounts of $150 million and $523 million, respectively, weighted-average interest rates of 1.29% and 2.01%, respectively, and maturities primarily less than three months.
  (was, 2020-02-18, similarity 0.9895):
[0001564590-20-005025:note_history:22]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of January 24, 2020 and April 26, 2019, we had commercial paper notes outstanding with aggregate principal amounts of $694 million and $249 million, respectively, weighted-average interest rates of 1.97% and 2.73%, respectively, and maturities generally less than three months.

- added (2020-08-28):
[0001564590-20-041759:note_history:23]
During the first quarter of fiscal 2021, we received proceeds of $75 million from the issuance, and made repayments of $76 million for the settlement, of commercial paper notes with original maturities greater than three months.

- changed (2020-08-28):
[0001564590-20-041759:note_history:24]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of July 31, 2020 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.
  (was, 2020-02-18, similarity 0.9961):
[0001564590-20-005025:note_history:24]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of January 24, 2020 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

- removed (2020-08-28):
[0001564590-20-005025:note_history:25]
On September 27, 2019, we made an aggregate cash payment of $400 million to extinguish our 2.00% Senior Notes at maturity.

- removed (2020-08-28):
[0001564590-20-005025:note_history:26]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017. Interest on these Senior Notes is paid semi-annually in March and September. Our 3.375% Senior Notes and 3.25% Senior Notes, with principal amounts of $500 million and $250 million, respectively, were issued in June 2014 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-28):
[0001564590-20-041759:note_history:27]
|  |  |  |  |  |  | July 31, 2020 |  |  | April 24, 2020 |  |
|  |  | Effective Interest Rate |  |  | Amount |  |  | Amount |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  | $ | — |  |  | $ | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | — |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | — |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | — |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 1,150 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (20 | ) |  |  | (4 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,630 |  |  | $ | 1,146 |  |
  (was, 2020-02-18, similarity 0.6994):
[0001564590-20-005025:note_history:27]
|  |  |  |  |  |  | January 24, 2020 |  |  | April 26, 2019 |  |
|  |  | Effective Interest Rate |  |  | Amount |  |  | Amount |  |
| 2.00% Senior Notes Due September 2019 |  | 2.32% |  |  | $ | — |  |  | $ | 400 |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  |  | 500 |  |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| Total principal amount |  |  |  |  |  |  | 1,150 |  |  |  | 1,550 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (4 | ) |  |  | (6 | ) |
| Total senior notes |  |  |  |  |  |  | 1,146 |  |  |  | 1,544 |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | — |  |  |  | (400 | ) |
| Total long-term debt |  |  |  |  |  | $ | 1,146 |  |  | $ | 1,144 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-28):
[0001564590-20-041759:note_history:28]
As of July 31, 2020, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2020-02-18, similarity 0.973):
[0001564590-20-005025:note_history:28]
As of January 24, 2020, our aggregate future principal debt maturities are as follows (in millions):

- changed (2020-08-28):
[0001564590-20-041759:note_history:29]
| Fiscal Year |  | Amount |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |
  (was, 2020-02-18, similarity 0.8789):
[0001564590-20-005025:note_history:29]
| Fiscal Year |  | Amount |  |
| 2022 |  | $ | 500 |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| Total |  | $ | 1,150 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-28):
[0001564590-20-041759:note_history:30]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Product revenues |  | $ | 627 |  |  | $ | 644 |  |
| Software maintenance revenues |  | 301 |  |  | 250 |  |
| Hardware maintenance and other services revenues |  |  | 375 |  |  |  | 342 |  |
| Hardware maintenance support contracts |  | 307 |  |  |  | 284 |  |
| Professional and other services |  | 68 |  |  |  | 58 |  |
| Net revenues |  | $ | 1,303 |  |  | $ | 1,236 |  |
  (was, 2020-02-18, similarity 0.7297):
[0001564590-20-005025:note_history:30]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Product revenues |  | $ | 787 |  |  | $ | 967 |  |  | $ | 2,202 |  |  | $ | 2,755 |  |
| Strategic |  | 483 |  |  | 517 |  |  |  | 1,262 |  |  |  | 1,477 |  |
| Mature |  | 304 |  |  | 450 |  |  |  | 940 |  |  |  | 1,278 |  |
| Software maintenance revenues |  | 263 |  |  | 239 |  |  | 767 |  |  | 704 |  |
| Hardware maintenance and other services revenues |  | 354 |  |  | 357 |  |  |  | 1,042 |  |  |  | 1,095 |  |
| Hardware maintenance support contracts |  | 293 |  |  | 292 |  |  | 863 |  |  |  | 898 |  |
| Professional and other services |  | 61 |  |  | 65 |  |  | 179 |  |  |  | 197 |  |
| Net revenues |  | $ | 1,404 |  |  | $ | 1,563 |  |  | $ | 4,011 |  |  | $ | 4,554 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-28):
[0001564590-20-041759:note_history:31]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Product revenues |  | $ | 627 |  |  | $ | 644 |  |
| Software maintenance revenues |  | 301 |  |  | 250 |  |
| Hardware maintenance and other services revenues |  |  | 375 |  |  |  | 342 |  |
| Hardware maintenance support contracts |  | 307 |  |  |  | 284 |  |
| Professional and other services |  | 68 |  |  |  | 58 |  |
| Net revenues |  | $ | 1,303 |  |  | $ | 1,236 |  |
  (was, 2020-02-18, similarity 0.7297):
[0001564590-20-005025:note_history:31]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Product revenues |  | $ | 787 |  |  | $ | 967 |  |  | $ | 2,202 |  |  | $ | 2,755 |  |
| Strategic |  | 483 |  |  | 517 |  |  |  | 1,262 |  |  |  | 1,477 |  |
| Mature |  | 304 |  |  | 450 |  |  |  | 940 |  |  |  | 1,278 |  |
| Software maintenance revenues |  | 263 |  |  | 239 |  |  | 767 |  |  | 704 |  |
| Hardware maintenance and other services revenues |  | 354 |  |  | 357 |  |  |  | 1,042 |  |  |  | 1,095 |  |
| Hardware maintenance support contracts |  | 293 |  |  | 292 |  |  | 863 |  |  |  | 898 |  |
| Professional and other services |  | 61 |  |  | 65 |  |  | 179 |  |  |  | 197 |  |
| Net revenues |  | $ | 1,404 |  |  | $ | 1,563 |  |  | $ | 4,011 |  |  | $ | 4,554 |  |

- changed (2020-08-28):
[0001564590-20-041759:note_history:32]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Deferred product revenue |  | $ | 49 |  |  | $ | 75 |  |
| Deferred services revenue |  |  | 3,520 |  |  |  | 3,567 |  |
| Financed unearned services revenue |  |  | 51 |  |  |  | 56 |  |
| Total |  | $ | 3,620 |  |  | $ | 3,698 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,814 |  |  | $ | 1,894 |  |
| Long-term |  |  | 1,806 |  |  |  | 1,804 |  |
| Total |  | $ | 3,620 |  |  | $ | 3,698 |  |
  (was, 2020-02-18, similarity 0.9906):
[0001564590-20-005025:note_history:32]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Deferred product revenue |  | $ | 73 |  |  | $ | 84 |  |
| Deferred services revenue |  |  | 3,439 |  |  |  | 3,502 |  |
| Financed unearned services revenue |  |  | 61 |  |  |  | 82 |  |
| Total |  | $ | 3,573 |  |  | $ | 3,668 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,795 |  |  | $ | 1,825 |  |
| Long-term |  |  | 1,778 |  |  |  | 1,843 |  |
| Total |  | $ | 3,573 |  |  | $ | 3,668 |  |

- added (2020-08-28):
[0001564590-20-041759:note_history:33]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Balance at beginning of period |  | $ | 3,698 |  |  | $ | 3,668 |  |
| Additions |  |  | 644 |  |  |  | 447 |  |
| Revenue recognized during the period |  |  | (722 | ) |  |  | (605 | ) |
| Balance at end of period |  | $ | 3,620 |  |  | $ | 3,510 |  |

- changed (2020-08-28):
[0001564590-20-041759:note_history:34]
During the three months ended July 31, 2020 and July 26, 2019, we recognized $661 million and $552 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.
  (was, 2020-02-18, similarity 0.9565):
[0001564590-20-005025:note_history:34]
During the nine months ended January 24, 2020 and January 25, 2019, we recognized $1,504 million and $1,410 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

- changed (2020-08-28):
[0001564590-20-041759:note_history:35]
As of July 31, 2020, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,620 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 25% in the next 13 to 24 months, and the remainder thereafter.
  (was, 2020-02-18, similarity 0.9953):
[0001564590-20-005025:note_history:35]
As of January 24, 2020, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,573 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 25% in the next 13 to 24 months, and the remainder thereafter.

- added (2020-08-28):
[0001564590-20-041759:note_history:36]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Balance at beginning of period |  | $ | 156 |  |  | $ | 172 |  |
| Additions |  |  | 21 |  |  |  | 16 |  |
| Expense recognized during the period |  |  | (25 | ) |  |  | (25 | ) |
| Balance at end of period |  | $ | 152 |  |  | $ | 163 |  |

- changed (2020-08-28):
[0001564590-20-041759:note_history:37]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Other current assets |  | $ | 64 |  |  | $ | 67 |  |
| Other non-current assets |  |  | 88 |  |  |  | 89 |  |
| Total deferred commissions |  | $ | 152 |  |  | $ | 156 |  |
  (was, 2020-02-18, similarity 0.9867):
[0001564590-20-005025:note_history:37]
|  |  | January 24, 2020 |  |  | April 26, 2019 |  |
| Other current assets |  | $ | 64 |  |  | $ | 75 |  |
| Other non-current assets |  |  | 88 |  |  |  | 97 |  |
| Total deferred commissions |  | $ | 152 |  |  | $ | 172 |  |

- removed (2020-08-28):
[0001564590-20-005025:note_history:38]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. As our product portfolio evolves, market dynamics change, and management continues to assess our largest growth opportunities, we periodically change how we group certain products. Beginning in fiscal 2020, Strategic includes All-flash FAS (AFF) products, including all related add-on hardware and operating system (OS) software, private cloud solutions (including SolidFire, converged and hyper-converged infrastructure products, StorageGrid), enterprise software license agreements (ELAs) and other optional add-on software products. Mature now includes Hybrid FAS products, including all related add-on hardware and OS software, original equipment manufacturers (OEM) products, and branded E-Series. Prior to this grouping change, Hybrid FAS products and branded E-Series were included in Strategic, while all add-on hardware and OS software were included in Mature. For comparability, Strategic and Mature revenues presented for the prior year periods have been recast based on the revised groupings.

- removed (2020-08-28):
[0001564590-20-005025:note_history:39]
In addition to the sale of our products and solutions, we provide a variety of services to our customers, including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training.

- removed (2020-08-28):
[0001564590-20-005025:note_history:40]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Balance at beginning of period |  | $ | 3,668 |  |  | $ | 3,363 |  |
| Additions |  |  | 1,759 |  |  |  | 1,820 |  |
| Revenue recognized during the period |  |  | (1,854 | ) |  |  | (1,826 | ) |
| Balance at end of period |  | $ | 3,573 |  |  | $ | 3,357 |  |

- removed (2020-08-28):
[0001564590-20-005025:note_history:41]
|  |  | Nine Months Ended |  |
|  |  | January 24, 2020 |  |  | January 25, 2019 |  |
| Balance at beginning of period |  | $ | 172 |  |  | $ | 137 |  |
| Additions |  |  | 52 |  |  |  | 62 |  |
| Expense recognized during the period |  |  | (72 | ) |  |  | (60 | ) |
| Balance at end of period |  | $ | 152 |  |  | $ | 139 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2020-08-28):
[0001564590-20-041759:note_history:42]
17. Subsequent Event

- added (2020-08-28):
[0001564590-20-041759:note_history:43]
On August 25, 2020, we committed to a restructuring plan to optimize our business and fund our biggest opportunities. In connection with the restructuring plan, we expect to reduce our global workforce by approximately 5%. This reduction in workforce will be implemented throughout fiscal 2021. We expect to incur aggregate expenses of $35 million to $40 million for employee terminations and other costs associated with the restructuring plan. We expect that most of these expenses will be cash expenditures and that we will recognize the majority of these expenses in our second quarter of fiscal 2021.
