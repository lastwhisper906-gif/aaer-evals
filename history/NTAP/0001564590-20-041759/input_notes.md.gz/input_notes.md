# NTAP notes — 0001564590-20-041759


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-20-041759:notes:1]
[same as prior period, unchanged from 0001564590-20-005025:notes:1]

[0001564590-20-041759:notes:2]
[same as prior period, unchanged from 0001564590-20-005025:notes:2]

[0001564590-20-041759:notes:3]
[same as prior period, unchanged from 0001564590-20-005025:notes:3]

[0001564590-20-041759:notes:4]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2021, ending on April 30, 2021 is a 53-week year, with 14 weeks included in its first quarter and 13 weeks in each subsequent quarter. Fiscal year 2020, which ended on April 24, 2020, was a 52-week year, with 13 weeks in each of its quarters.

[0001564590-20-041759:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2020 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 31, 2020 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-20-041759:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates. Management’s estimates include, as applicable, the anticipated impacts of the COVID-19 pandem


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-20-041759:notes:7]
2. Recently Adopted Accounting Standards

[0001564590-20-041759:notes:8]
In June 2016, the FASB issued an accounting standards update on the measurement of credit losses on financial instruments. The standard introduces a new model for measuring and recognizing credit losses on financial instruments, requiring financial assets measured at amortized cost basis to be presented at the net amount expected to be collected. It also requires that credit losses be recorded through an allowance for credit losses. On April 25, 2020, we adopted the standard with no material impact to our condensed consolidated financial statements.

[0001564590-20-041759:notes:9]
There have been no other significant changes in our significant accounting policies as of and for the three months ended July 31, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 24, 2020.

[0001564590-20-041759:notes:10]
Recent accounting pronouncements pending adoption not discussed are either not applicable or will not have or are not expected to have a material impact on our consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-20-041759:notes:11]
[same as prior period, unchanged from 0001564590-20-005025:notes:13]

[0001564590-20-041759:notes:12]
Cloud Jumper Corporation Acquisition

[0001564590-20-041759:notes:13]
On April 28, 2020, we acquired all the outstanding shares of privately-held Cloud Jumper Corporation (Cloud Jumper), a provider of  virtual desktop infrastructure and remote desktop services solutions based in North Carolina, for approximately $34 million in cash.

[0001564590-20-041759:notes:14]
[same as prior period, unchanged from 0001564590-20-005025:notes:15]

[0001564590-20-041759:notes:15]
| Developed technology |  | $ | 16 |  |
| Customer contracts/relationships |  |  | 6 |  |
| Goodwill |  |  | 12 |  |
| Other assets |  |  | 1 |  |
| Total assets acquired |  |  | 35 |  |
| Liabilities assumed |  |  | (1 | ) |
| Total purchase price |  | $ | 34 |  |

[0001564590-20-041759:notes:16]
Spot, Inc. Acquisition

[0001564590-20-041759:notes:17]
On July 9, 2020, we acquired all the outstanding shares of privately-held Spot, Inc. (Spot), a provider of compute management cost optimization services on the public clouds based in Israel, for $340 million in cash. The acquisition of Spot will allow us to establish an application driven infrastructure for the continuous optimization of both compute and storage, which we believe will facilitate customers deploying more applications to the cloud.

[0001564590-20-041759:notes:18]
| Cash |  |  | 24 |  |
| Intangible assets |  |  | 84 |  |
| Goodwill |  |  | 248 |  |
| Other assets |  |  | 7 |  |
| Total assets acquired |  |  | 363 |  |
| Liabilities assumed |  |  | (23 | ) |
| Total purchase price |  | $ | 340 |  |

[0001564590-20-041759:notes:19]
The components of the Spot intangible assets acquired were as follows (in millions, except useful life):

[0001564590-20-041759:notes:20]
|  |  |  |  |  |  | Estimated useful life (years) |
| Developed technology |  | $ | 53 |  |  | 5 |
| Customer contracts/relationships |  |  | 28 |  |  | 5 |
| Trade name |  |  | 3 |  |  | 3 |
| Total intangible assets |  | $ | 84 |  |  |  |

[0001564590-20-041759:notes:21]
The acquired assets and assumed liabilities were recorded at their estimated fair values. We determined the estimated fair values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expect to realize revenue synergies, leverage and expand the existing Spot sales channels and product development resources, and utilize the existing workforce. We also anticipate opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated fair value of Spot’s identifiable net assets acquired, and as a result, we have recorded goodwill in connection with this acquisition. The goodwill is not deductible for income tax purposes.

[0001564590-20-041759:notes:22]
The results of operations related to the acquisition of both Spot and Cloud Jumper have been included in our condensed consolidated statements of operations from their respective acquisition dates. Pro forma results of operations have not been presented because the impact from these acquisitions would not have been material to our consolidated results of operations for each of the three months ended July 31, 2020 and July 26, 2019.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-20-041759:notes:23]
[same as prior period, unchanged from 0001564590-20-005025:notes:18]

[0001564590-20-041759:notes:24]
[same as prior period, unchanged from 0001564590-20-005025:notes:19]

[0001564590-20-041759:notes:25]
| Balance as of April 24, 2020 |  | $ | 1,778 |  |
| Additions |  |  | 260 |  |
| Balance as of July 31, 2020 |  | $ | 2,038 |  |

[0001564590-20-041759:notes:26]
[same as prior period, unchanged from 0001564590-20-005025:notes:21]

[0001564590-20-041759:notes:27]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 215 |  |  | $ | (116 | ) |  | $ | 99 |  |  | $ | 192 |  |  | $ | (152 | ) |  | $ | 40 |  |
| Customer contracts/relationships |  |  | 38 |  |  |  | — |  |  |  | 38 |  |  |  | 4 |  |  |  | — |  |  |  | 4 |  |
| Other purchased intangibles |  |  | 3 |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total purchased intangible assets |  | $ | 256 |  |  | $ | (116 | ) |  | $ | 140 |  |  | $ | 196 |  |  | $ | (152 | ) |  | $ | 44 |  |

[0001564590-20-041759:notes:28]
[same as prior period, unchanged from 0001564590-20-005025:notes:23]

[0001564590-20-041759:notes:29]
|  |  | Three Months Ended |  |  | Statements of |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |  | Operations Classification |
| Developed technology |  | $ | 10 |  |  | $ | 11 |  |  | Cost of revenues |

[0001564590-20-041759:notes:30]
As of July 31, 2020, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-20-041759:notes:31]
| Fiscal Year |  | Amount |  |
| Remainder of 2021 |  |  | 38 |  |
| 2022 |  |  | 37 |  |
| 2023 |  |  | 29 |  |
| 2024 |  |  | 17 |  |
| 2025 |  |  | 16 |  |
| 2026 |  |  | 3 |  |
| Total |  | $ | 140 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-20-041759:notes:32]
[same as prior period, unchanged from 0001564590-20-005025:notes:27]

[0001564590-20-041759:notes:33]
[same as prior period, unchanged from 0001564590-20-005025:notes:28]

[0001564590-20-041759:notes:34]
[same as prior period, unchanged from 0001564590-20-005025:notes:29]

[0001564590-20-041759:notes:35]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Cash and cash equivalents |  | $ | 3,633 |  |  | $ | 2,658 |  |
| Restricted cash |  |  | 8 |  |  |  | 8 |  |
| Cash, cash equivalents and restricted cash |  | $ | 3,641 |  |  | $ | 2,666 |  |

[0001564590-20-041759:notes:36]
[same as prior period, unchanged from 0001564590-20-005025:notes:31]

[0001564590-20-041759:notes:37]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Purchased components |  | $ | 25 |  |  | $ | 28 |  |
| Finished goods |  |  | 111 |  |  |  | 117 |  |
| Inventories |  | $ | 136 |  |  | $ | 145 |  |

[0001564590-20-041759:notes:38]
[same as prior period, unchanged from 0001564590-20-005025:notes:33]

[0001564590-20-041759:notes:39]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Land |  | $ | 103 |  |  | $ | 103 |  |
| Buildings and improvements |  |  | 598 |  |  |  | 597 |  |
| Leasehold improvements |  |  | 91 |  |  |  | 89 |  |
| Computer, production, engineering and other equipment |  |  | 834 |  |  |  | 802 |  |
| Computer software |  |  | 359 |  |  |  | 359 |  |
| Furniture and fixtures |  |  | 107 |  |  |  | 106 |  |
| Construction-in-progress |  |  | 38 |  |  |  | 32 |  |
|  |  |  | 2,130 |  |  |  | 2,088 |  |
| Accumulated depreciation and amortization |  |  | (1,393 | ) |  |  | (1,361 | ) |
| Property and equipment, net |  | $ | 737 |  |  | $ | 727 |  |

[0001564590-20-041759:notes:40]
[same as prior period, unchanged from 0001564590-20-005025:notes:36]

[0001564590-20-041759:notes:41]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Deferred tax assets |  | $ | 208 |  |  | $ | 220 |  |
| Operating lease ROU assets |  |  | 135 |  |  |  | 137 |  |
| Other assets |  |  | 341 |  |  |  | 342 |  |
| Other non-current assets |  | $ | 684 |  |  | $ | 699 |  |

[0001564590-20-041759:notes:42]
Other non-current assets as of July 31, 2020 and April 24, 2020 were $68 million and $67 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited, a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019.

[0001564590-20-041759:notes:43]
[same as prior period, unchanged from 0001564590-20-005025:notes:39]

[0001564590-20-041759:notes:44]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Accrued compensation and benefits |  | $ | 254 |  |  | $ | 322 |  |
| Product warranty liabilities |  |  | 24 |  |  |  | 26 |  |
| Operating lease liabilities |  |  | 52 |  |  |  | 51 |  |
| Other current liabilities |  |  | 286 |  |  |  | 375 |  |
| Accrued expenses |  | $ | 616 |  |  | $ | 774 |  |

[0001564590-20-041759:notes:45]
[same as prior period, unchanged from 0001564590-20-005025:notes:41]

[0001564590-20-041759:notes:46]
[same as prior period, unchanged from 0001564590-20-005025:notes:42]

[0001564590-20-041759:notes:47]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Balance at beginning of period |  | $ | 41 |  |  | $ | 40 |  |
| Expense accrued during the period |  |  | 1 |  |  |  | 5 |  |
| Warranty costs incurred |  |  | (5 | ) |  |  | (6 | ) |
| Balance at end of period |  | $ | 37 |  |  | $ | 39 |  |

[0001564590-20-041759:notes:48]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Accrued expenses |  | $ | 24 |  |  | $ | 26 |  |
| Other long-term liabilities |  |  | 13 |  |  |  | 15 |  |
| Total warranty liabilities |  | $ | 37 |  |  | $ | 41 |  |

[0001564590-20-041759:notes:49]
[same as prior period, unchanged from 0001564590-20-005025:notes:45]

[0001564590-20-041759:notes:50]
[same as prior period, unchanged from 0001564590-20-005025:notes:46]

[0001564590-20-041759:notes:51]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Liability for uncertain tax positions |  | $ | 142 |  |  | $ | 136 |  |
| Income taxes payable |  |  | 399 |  |  |  | 399 |  |
| Product warranty liabilities |  |  | 13 |  |  |  | 15 |  |
| Operating lease liabilities |  |  | 90 |  |  |  | 93 |  |
| Other liabilities |  |  | 76 |  |  |  | 71 |  |
| Other long-term liabilities |  | $ | 720 |  |  | $ | 714 |  |

[0001564590-20-041759:notes:52]
Other income (expense), net (in millions):

[0001564590-20-041759:notes:53]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Interest income |  | $ | 3 |  |  | $ | 19 |  |
| Interest expense |  |  | (18 | ) |  |  | (15 | ) |
| Other income (expense), net |  |  | (17 | ) |  |  | 11 |  |
| Total other income (expense), net |  | $ | (32 | ) |  | $ | 15 |  |

[0001564590-20-041759:notes:54]
[same as prior period, unchanged from 0001564590-20-005025:notes:50]

[0001564590-20-041759:notes:55]
[same as prior period, unchanged from 0001564590-20-005025:notes:51]

[0001564590-20-041759:notes:56]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 10 |  |  | $ | 10 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 136 |  |  | $ | 55 |  |
| Interest paid |  | $ | 16 |  |  | $ | 14 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-041759:notes:57]
[same as prior period, unchanged from 0001564590-20-005025:notes:53]

[0001564590-20-041759:notes:58]
[same as prior period, unchanged from 0001564590-20-005025:notes:54]

[0001564590-20-041759:notes:59]
[same as prior period, unchanged from 0001564590-20-005025:notes:57]

[0001564590-20-041759:notes:60]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Product revenues |  | $ | 627 |  |  | $ | 644 |  |
| Software maintenance revenues |  | 301 |  |  | 250 |  |
| Hardware maintenance and other services revenues |  |  | 375 |  |  |  | 342 |  |
| Hardware maintenance support contracts |  | 307 |  |  |  | 284 |  |
| Professional and other services |  | 68 |  |  |  | 58 |  |
| Net revenues |  | $ | 1,303 |  |  | $ | 1,236 |  |

[0001564590-20-041759:notes:61]
[same as prior period, unchanged from 0001564590-20-005025:notes:59]

[0001564590-20-041759:notes:62]
[same as prior period, unchanged from 0001564590-20-005025:notes:60]

[0001564590-20-041759:notes:63]
[same as prior period, unchanged from 0001564590-20-005025:notes:61]

[0001564590-20-041759:notes:64]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Deferred product revenue |  | $ | 49 |  |  | $ | 75 |  |
| Deferred services revenue |  |  | 3,520 |  |  |  | 3,567 |  |
| Financed unearned services revenue |  |  | 51 |  |  |  | 56 |  |
| Total |  | $ | 3,620 |  |  | $ | 3,698 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,814 |  |  | $ | 1,894 |  |
| Long-term |  |  | 1,806 |  |  |  | 1,804 |  |
| Total |  | $ | 3,620 |  |  | $ | 3,698 |  |

[0001564590-20-041759:notes:65]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 16 – Commitments and Contingencies for additional information related to these arrangements.

[0001564590-20-041759:notes:66]
[same as prior period, unchanged from 0001564590-20-005025:notes:64]

[0001564590-20-041759:notes:67]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Balance at beginning of period |  | $ | 3,698 |  |  | $ | 3,668 |  |
| Additions |  |  | 644 |  |  |  | 447 |  |
| Revenue recognized during the period |  |  | (722 | ) |  |  | (605 | ) |
| Balance at end of period |  | $ | 3,620 |  |  | $ | 3,510 |  |

[0001564590-20-041759:notes:68]
During the three months ended July 31, 2020 and July 26, 2019, we recognized $661 million and $552 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001564590-20-041759:notes:69]
As of July 31, 2020, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,620 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 25% in the next 13 to 24 months, and the remainder thereafter.

[0001564590-20-041759:notes:70]
[same as prior period, unchanged from 0001564590-20-005025:notes:68]

[0001564590-20-041759:notes:71]
[same as prior period, unchanged from 0001564590-20-005025:notes:69]

[0001564590-20-041759:notes:72]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Balance at beginning of period |  | $ | 156 |  |  | $ | 172 |  |
| Additions |  |  | 21 |  |  |  | 16 |  |
| Expense recognized during the period |  |  | (25 | ) |  |  | (25 | ) |
| Balance at end of period |  | $ | 152 |  |  | $ | 163 |  |

[0001564590-20-041759:notes:73]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Other current assets |  | $ | 64 |  |  | $ | 67 |  |
| Other non-current assets |  |  | 88 |  |  |  | 89 |  |
| Total deferred commissions |  | $ | 152 |  |  | $ | 156 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-20-041759:notes:74]
[same as prior period, unchanged from 0001564590-20-005025:notes:72]

[0001564590-20-041759:notes:75]
[same as prior period, unchanged from 0001564590-20-005025:notes:73]

[0001564590-20-041759:notes:76]
[same as prior period, unchanged from 0001564590-20-005025:notes:74]

[0001564590-20-041759:notes:77]
[same as prior period, unchanged from 0001564590-20-005025:notes:75]

[0001564590-20-041759:notes:78]
[same as prior period, unchanged from 0001564590-20-005025:notes:76]

[0001564590-20-041759:notes:79]
[same as prior period, unchanged from 0001564590-20-005025:notes:77]

[0001564590-20-041759:notes:80]
[same as prior period, unchanged from 0001564590-20-005025:notes:78]

[0001564590-20-041759:notes:81]
[same as prior period, unchanged from 0001564590-20-005025:notes:79]

[0001564590-20-041759:notes:82]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 111 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 113 |  |  | $ | 155 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 156 |  |
| U.S. Treasury and government debt Securities |  |  | 26 |  |  |  | 1 |  |  |  | — |  |  |  | 27 |  |  |  | 68 |  |  |  | — |  |  |  | — |  |  |  | 68 |  |
| Certificates of deposit |  |  | 116 |  |  |  | — |  |  |  | — |  |  |  | 116 |  |  |  | 158 |  |  |  | — |  |  |  | — |  |  |  | 158 |  |
| Mutual funds |  |  | 37 |  |  |  | — |  |  |  | — |  |  |  | 37 |  |  |  | 33 |  |  |  | — |  |  |  | — |  |  |  | 33 |  |
| Total debt and equity securities |  | $ | 290 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 293 |  |  | $ | 414 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 415 |  |

[0001564590-20-041759:notes:83]
The following table presents the contractual maturities of our debt investments as of July 31, 2020 (in millions):

[0001564590-20-041759:notes:84]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 194 |  |  | $ | 195 |  |
| Due after one year through five years |  |  | 54 |  |  |  | 56 |  |
| Due after five years through ten years |  |  | 5 |  |  |  | 5 |  |
|  |  | $ | 253 |  |  | $ | 256 |  |

[0001564590-20-041759:notes:85]
[same as prior period, unchanged from 0001564590-20-005025:notes:84]

[0001564590-20-041759:notes:86]
[same as prior period, unchanged from 0001564590-20-005025:notes:85]

[0001564590-20-041759:notes:87]
[same as prior period, unchanged from 0001564590-20-005025:notes:86]

[0001564590-20-041759:notes:88]
|  |  | July 31, 2020 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 3,517 |  |  | $ | 3,517 |  |  | $ | — |  |
| Corporate bonds |  |  | 113 |  |  |  | — |  |  |  | 113 |  |
| U.S. Treasury and government debt securities |  |  | 27 |  |  |  | 14 |  |  |  | 13 |  |
| Certificates of deposit |  |  | 116 |  |  |  | — |  |  |  | 116 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,773 |  |  | $ | 3,531 |  |  | $ | 242 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 30 |  |  | $ | 30 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (8 | ) |  | $ | — |  |  | $ | (8 | ) |

[0001564590-20-041759:notes:89]
[same as prior period, unchanged from 0001564590-20-005025:notes:88]

[0001564590-20-041759:notes:90]
[same as prior period, unchanged from 0001564590-20-005025:notes:89]

[0001564590-20-041759:notes:91]
| (3) | Reported as accrued expenses in the condensed consolidated balance sheets |

[0001564590-20-041759:notes:92]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of July 31, 2020 and April 24, 2020, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-20-041759:notes:93]
[same as prior period, unchanged from 0001564590-20-005025:notes:91]

[0001564590-20-041759:notes:94]
As of July 31, 2020 and April 24, 2020, the fair value of our long-term debt was approximately $2,783 million and $1,176 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-20-041759:notes:95]
8. Financing Arrangements

[0001564590-20-041759:notes:96]
Long-Term Debt

[0001564590-20-041759:notes:97]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-20-041759:notes:98]
|  |  |  |  |  |  | July 31, 2020 |  |  | April 24, 2020 |  |
|  |  | Effective Interest Rate |  |  | Amount |  |  | Amount |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  | $ | — |  |  | $ | 500 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  |  | 750 |  |  |  | — |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  |  | 550 |  |  |  | — |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  |  | 700 |  |  |  | — |  |
| Total principal amount |  |  |  |  |  |  | 2,650 |  |  |  | 1,150 |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (20 | ) |  |  | (4 | ) |
| Total long-term debt |  |  |  |  |  | $ | 2,630 |  |  | $ | 1,146 |  |

[0001564590-20-041759:notes:99]
Senior Notes

[0001564590-20-041759:notes:100]
In June 2020, we issued $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, for which we received total proceeds of approximately $2.0 billion, net of discount and issuance costs. Interest on these Senior Notes is payable semi-annually in June and December. On July 27, 2020, we extinguished our 3.375% Senior Notes due June 2021 for an aggregate cash redemption price of $513 million, plus accrued and unpaid interest. As part of the debt extinguishment, we recognized a loss of $14 million, which includes a cash redemption premium of $13 million and the write-off of unamortized discount and issuance costs totaling $1 million. The loss on extinguishment of debt is included in other income (expense), net in our Condensed Consolidated Statement of Operations for the three months ended July 31, 2020.

[0001564590-20-041759:notes:101]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September. Our 3.25% Senior Notes, with a principal amount of $250 million, were issued in December 2012 with interest paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0001564590-20-041759:notes:102]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 31, 2020, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-20-041759:notes:103]
As of July 31, 2020, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-20-041759:notes:104]
| Fiscal Year |  | Amount |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |

[0001564590-20-041759:notes:105]
Commercial Paper Program and Credit Facility

[0001564590-20-041759:notes:106]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of July 31, 2020 and April 24, 2020, we had commercial paper notes outstanding with aggregate principal amounts of $150 million and $523 million, respectively, weighted-average interest rates of 1.29% and 2.01%, respectively, and maturities primarily less than three months.

[0001564590-20-041759:notes:107]
During the first quarter of fiscal 2021, we received proceeds of $75 million from the issuance, and made repayments of $76 million for the settlement, of commercial paper notes with original maturities greater than three months.

[0001564590-20-041759:notes:108]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended in July 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of July 31, 2020 we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0001564590-20-041759:notes:109]
[same as prior period, unchanged from 0001564590-20-005025:notes:106]

[0001564590-20-041759:notes:110]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of July 31, 2020, have remaining lease terms of up to 15 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of July 31, 2020, have remaining lease terms of up to 4 years. As of July 31, 2020, our automobile leases have remaining lease terms of up to 5 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0001564590-20-041759:notes:111]
In June 2020, we entered into a build-to-suit lease agreement for an office building with future undiscounted payments of approximately $67 million. Because the Company does not control the underlying asset during the construction period, the Company is not considered the owner of the asset under construction for accounting purposes. The lease will commence upon completion of the construction of the office building which is expected to be in fiscal 2021. The initial term of the lease is twenty years with options to renew the lease during the lease term. An ROU asset and related lease liability will be measured and recognized in our financial statements in the period the lease commences.

[0001564590-20-041759:notes:112]
[same as prior period, unchanged from 0001564590-20-005025:notes:108]

[0001564590-20-041759:notes:113]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Operating lease cost |  | $ | 14 |  |  | $ | 14 |  |
| Variable lease cost |  |  | 3 |  |  |  | 4 |  |
| Total lease cost |  | $ | 17 |  |  | $ | 18 |  |

[0001564590-20-041759:notes:114]
[same as prior period, unchanged from 0001564590-20-005025:notes:110]

[0001564590-20-041759:notes:115]
[same as prior period, unchanged from 0001564590-20-005025:notes:111]

[0001564590-20-041759:notes:116]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 14 |  |  | $ | 13 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  | $ | 10 |  |  | $ | 6 |  |

[0001564590-20-041759:notes:117]
[same as prior period, unchanged from 0001564590-20-005025:notes:113]

[0001564590-20-041759:notes:118]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Other non-current assets |  | $ | 135 |  |  | $ | 137 |  |
| Total operating lease ROU assets |  | $ | 135 |  |  | $ | 137 |  |
| Accrued expenses |  | $ | 52 |  |  | $ | 51 |  |
| Other long-term liabilities |  |  | 90 |  |  |  | 93 |  |
| Total operating lease liabilities |  | $ | 142 |  |  | $ | 144 |  |
| Weighted Average Remaining Lease Term |  | 3.7 years |  |  | 3.9 years |  |
| Weighted Average Discount Rate |  |  | 2.7 | % |  |  | 2.7 | % |

[0001564590-20-041759:notes:119]
Future minimum operating lease payments as of July 31, 2020, which exclude the undiscounted payments for the build-to-suit lease expected to commence in fiscal 2021, are as follows (in millions):

[0001564590-20-041759:notes:120]
|  |  | Operating Leases |  |
| Fiscal 2021 (remainder) |  | $ | 43 |  |
| Fiscal 2022 |  |  | 45 |  |
| Fiscal 2023 |  |  | 26 |  |
| Fiscal 2024 |  |  | 16 |  |
| Fiscal 2025 |  |  | 9 |  |
| Fiscal 2026 |  |  | 7 |  |
| Thereafter |  |  | 3 |  |
| Total lease payments |  | $ | 149 |  |
| Less: Interest |  |  | (7 | ) |
| Total |  | $ | 142 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-20-041759:notes:121]
[same as prior period, unchanged from 0001564590-20-005025:notes:119]

[0001564590-20-041759:notes:122]
[same as prior period, unchanged from 0001564590-20-005025:notes:120]

[0001564590-20-041759:notes:123]
As of July 31, 2020, we have certain equity incentive awards (awards) outstanding, which include stock options and restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs). Also outstanding are purchase rights under our Employee Stock Purchase Plan (ESPP).

[0001564590-20-041759:notes:124]
[same as prior period, unchanged from 0001564590-20-005025:notes:122]

[0001564590-20-041759:notes:125]
Less than 1 million options were outstanding as of July 31, 2020 and April 24, 2020.

[0001564590-20-041759:notes:126]
[same as prior period, unchanged from 0001564590-20-005025:notes:127]

[0001564590-20-041759:notes:127]
In the three months ended July 31, 2020, we granted PBRSUs to certain of our executives. The PBRSUs have performance-based vesting criteria, in addition to the service based vesting criteria, such that the PBRSUs cliff-vest at the end of an approximate three year performance period, which began on the date specified in the grant agreements and ends on the last day of  the third fiscal year following the grant date. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the performance and service period, will range from 0% to 200% of a target number of shares originally granted. The number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. The fair values of these awards were fixed at grant date using a Monte Carlo simulation model. The aggregate grant date fair value of all PBRSUs granted in the current year was $20 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0001564590-20-041759:notes:128]
[same as prior period, unchanged from 0001564590-20-005025:notes:129]

[0001564590-20-041759:notes:129]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 24, 2020 |  |  | 7 |  |  | $ | 51.40 |  |
| Granted |  |  | 4 |  |  | $ | 39.95 |  |
| Vested |  |  | (2 | ) |  | $ | 43.77 |  |
| Outstanding as of July 31, 2020 |  |  | 9 |  |  | $ | 47.75 |  |

[0001564590-20-041759:notes:130]
[same as prior period, unchanged from 0001564590-20-005025:notes:131]

[0001564590-20-041759:notes:131]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 33 |  |  | $ | 71 |  |

[0001564590-20-041759:notes:132]
[same as prior period, unchanged from 0001564590-20-005025:notes:133]

[0001564590-20-041759:notes:133]
[same as prior period, unchanged from 0001564590-20-005025:notes:134]

[0001564590-20-041759:notes:134]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Shares issued under the ESPP |  |  | 1 |  |  |  | 1 |  |
| Proceeds from issuance of shares |  | $ | 48 |  |  | $ | 54 |  |

[0001564590-20-041759:notes:135]
[same as prior period, unchanged from 0001564590-20-005025:notes:136]

[0001564590-20-041759:notes:136]
[same as prior period, unchanged from 0001564590-20-005025:notes:137]

[0001564590-20-041759:notes:137]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |
| Cost of hardware maintenance and other services revenues |  |  | 3 |  |  |  | 2 |  |
| Sales and marketing |  |  | 25 |  |  |  | 18 |  |
| Research and development |  |  | 19 |  |  |  | 15 |  |
| General and administrative |  |  | 6 |  |  |  | 6 |  |
| Total stock-based compensation expense |  | $ | 54 |  |  | $ | 42 |  |
| Income tax benefit for stock-based compensation expense |  | $ | 4 |  |  | $ | 4 |  |

[0001564590-20-041759:notes:138]
As of July 31, 2020, total unrecognized compensation expense related to our equity awards was $435 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.7 years.

[0001564590-20-041759:notes:139]
[same as prior period, unchanged from 0001564590-20-005025:notes:140]

[0001564590-20-041759:notes:140]
As of July 31, 2020, our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time, and it was suspended in March 2020 due to the economic impact of the COVID-19 pandemic. Accordingly, no share repurchases were executed in the three months ended July 31, 2020.

[0001564590-20-041759:notes:141]
Since the May 13, 2003 inception of our stock repurchase program through July 31, 2020, we repurchased a total of 338 million shares of our common stock at an average price of $38.86 per share, for an aggregate purchase price of $13.1 billion. As of July 31, 2020, the remaining authorized amount for stock repurchases under this program was $477 million.

[0001564590-20-041759:notes:142]
[same as prior period, unchanged from 0001564590-20-005025:notes:146]

[0001564590-20-041759:notes:143]
[same as prior period, unchanged from 0001564590-20-005025:notes:147]

[0001564590-20-041759:notes:144]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Dividends per share declared |  | $ | 0.48 |  |  | $ | 0.48 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 30 |  |  | $ | 115 |  |
| Dividend payments allocated to retained earnings |  | $ | 77 |  |  | $ | — |  |

[0001564590-20-041759:notes:145]
On August 24, 2020, we declared a cash dividend of $0.48 per share of common stock, payable on October 28, 2020 to holders of record as of the close of business on October 9, 2020. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-20-041759:notes:146]
[same as prior period, unchanged from 0001564590-20-005025:notes:150]

[0001564590-20-041759:notes:147]
[same as prior period, unchanged from 0001564590-20-005025:notes:151]

[0001564590-20-041759:notes:148]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 24, 2020 |  | $ | (42 | ) |  | $ | (1 | ) |  | $ | 1 |  |  | $ | — |  |  | $ | (42 | ) |
| Other comprehensive income (loss), net of tax |  |  | 9 |  |  |  | — |  |  |  | 2 |  |  |  | (9 | ) |  |  | 2 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |
| Total other comprehensive income (loss) |  |  | 9 |  |  |  | — |  |  |  | 2 |  |  |  | (8 | ) |  |  | 3 |  |
| Balance as of July 31, 2020 |  | $ | (33 | ) |  | $ | (1 | ) |  | $ | 3 |  |  | $ | (8 | ) |  | $ | (39 | ) |

[0001564590-20-041759:notes:149]
The amounts reclassified out of AOCI are as follows (in millions):

[0001564590-20-041759:notes:150]
|  |  | Three Months Ended |  |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |  |
|  |  | Amounts Reclassified from AOCI |  | Statements of Operations Classification |
| Realized gains on available-for-sale securities |  |  | — |  |  |  | (14 | ) | Other income (expense), net |
| Realized losses on cash flow hedges |  |  | 1 |  |  |  | — |  | Net revenues |
| Total reclassifications |  | $ | 1 |  |  | $ | (14 | ) |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-20-041759:notes:151]
[same as prior period, unchanged from 0001564590-20-005025:notes:154]

[0001564590-20-041759:notes:152]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of our agreements with them. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of July 31, 2020 or April 24, 2020. All contracts have a maturity of less than 12 months.

[0001564590-20-041759:notes:153]
[same as prior period, unchanged from 0001564590-20-005025:notes:156]

[0001564590-20-041759:notes:154]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 123 |  |  | $ | 124 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 339 |  |  | $ | 254 |  |
| Forward contracts purchased |  | $ | 94 |  |  | $ | 108 |  |

[0001564590-20-041759:notes:155]
The effect of cash flow hedges recognized in net revenues is presented in the condensed consolidated statements of comprehensive income and Note 10 – Stockholders’ Equity.

[0001564590-20-041759:notes:156]
The effect of derivative instruments not designated as hedging instruments recognized in other income (expense), net on our condensed consolidated statements of operations was as follows (in millions):

[0001564590-20-041759:notes:157]
|  | Three Months Ended |  |
|  | July 31, 2020 |  |  | July 26, 2019 |  |
|  | Gain (Loss) Recognized in Income |  |
| Foreign currency exchange contracts | $ | 24 |  |  | $ | (3 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-041759:notes:158]
[same as prior period, unchanged from 0001564590-20-005025:notes:161]

[0001564590-20-041759:notes:159]
In the first quarter of fiscal 2021, we executed a restructuring plan (the May 2020 Plan) to reduce costs and redirect resources to our highest return activities, which included a reduction in our global workforce by less than 1%. Charges related to the plan consisted primarily of employee severance-related costs. Substantially all activities under the plan have been completed.

[0001564590-20-041759:notes:160]
Management has previously approved several restructuring actions, including the May 2019 Plan and April 2019 Plan, under which we reduced our global workforce by approximately 2%, and approximately 1%, respectively. Charges related to our restructuring plans consisted primarily of employee severance-related costs. Substantially all activities under the May 2019 Plan were complete as of the end of the second quarter of fiscal 2020, and substantially all activities under the April 2019 Plan were complete as of the end of fiscal 2020.

[0001564590-20-041759:notes:161]
[same as prior period, unchanged from 0001564590-20-005025:notes:164]

[0001564590-20-041759:notes:162]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
|  |  | May 2020 Plan |  |  | May 2019 Plan |  |  | April 2019 Plan |  |  | Total |  |  | May 2019 Plan |  |  | April 2019 Plan |  |  | November 2016 Plan |  |  | Total |  |
| Balance at beginning of period |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 15 |  |  | $ | 4 |  |  | $ | 19 |  |
| Net charges |  |  | 5 |  |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | 21 |  |  |  | — |  |  |  | — |  |  |  | 21 |  |
| Cash payments |  |  | (5 | ) |  |  | — |  |  |  | — |  |  |  | (5 | ) |  |  | (11 | ) |  |  | (9 | ) |  |  | — |  |  |  | (20 | ) |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (4 | ) |  |  | (4 | ) |
| Balance at end of period |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 10 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 16 |  |

[0001564590-20-041759:notes:163]
[same as prior period, unchanged from 0001564590-20-005025:notes:166]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-041759:notes:164]
[same as prior period, unchanged from 0001564590-20-005025:notes:167]

[0001564590-20-041759:notes:165]
[same as prior period, unchanged from 0001564590-20-005025:notes:168]

[0001564590-20-041759:notes:166]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Effective tax rates |  |  | 26.0 | % |  |  | 13.4 | % |

[0001564590-20-041759:notes:167]
Our effective tax rate for the three months ended July 31, 2020 reflects the impact of taxes resulting from the integration of acquired companies. Excluding these acquisition integration-related taxes, our effective tax rate for the first quarter of fiscal 2021 is

[0001564590-20-041759:notes:168]
approximately 16%, which is lower than the United States (U.S.) statutory tax rate due to a significant amount of our earnings being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The remaining differences in effective tax rates for the three months ended July 31, 2020 and July 26, 2019 were primarily due to certain discrete tax expenses, including foreign audit results and differences in discrete tax benefits for stock-based compensation in fiscal 2021.

[0001564590-20-041759:notes:169]
As of July 31, 2020, we had $220 million of gross unrecognized tax benefits, of which $142 million has been recorded in other long-term liabilities. Inclusive of penalties, interest and certain income tax benefits, $142 million would affect our provision for income taxes if recognized.

[0001564590-20-041759:notes:170]
We are currently undergoing various income tax audits in the U.S. and audits in several foreign tax jurisdictions. Transfer pricing calculations are key topics under these audits and are often subject to dispute and appeals.

[0001564590-20-041759:notes:171]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. As a result of uncertainties regarding tax audits and their possible outcomes, an estimate of the range of possible impacts to unrecognized tax benefits in the next twelve months cannot be made at this time.


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-041759:notes:172]
[same as prior period, unchanged from 0001564590-20-005025:notes:177]

[0001564590-20-041759:notes:173]
[same as prior period, unchanged from 0001564590-20-005025:notes:178]

[0001564590-20-041759:notes:174]
|  | Three Months Ended |  |
|  | July 31, 2020 |  |  | July 26, 2019 |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 77 |  |  | $ | 103 |  |
| Denominator: |  |  |  |  |  |  |  |
| Shares used in basic computation |  | 221 |  |  |  | 239 |  |
| Dilutive impact of employee equity award plans |  | 1 |  |  |  | 4 |  |
| Shares used in diluted computation |  | 222 |  |  |  | 243 |  |
| Net Income per Share: |  |  |  |  |  |  |  |
| Basic | $ | 0.35 |  |  | $ | 0.43 |  |
| Diluted | $ | 0.35 |  |  | $ | 0.42 |  |

[0001564590-20-041759:notes:175]
Six million potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for the three months ended July 31, 2020, while less than one million potential shares were excluded from the calculation for the three months ended July 26, 2019, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-041759:notes:176]
[same as prior period, unchanged from 0001564590-20-005025:notes:181]

[0001564590-20-041759:notes:177]
[same as prior period, unchanged from 0001564590-20-005025:notes:182]

[0001564590-20-041759:notes:178]
[same as prior period, unchanged from 0001564590-20-005025:notes:183]

[0001564590-20-041759:notes:179]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| United States, Canada and Latin America (Americas) |  | $ | 709 |  |  | $ | 635 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 383 |  |  |  | 402 |  |
| Asia Pacific (APAC) |  |  | 211 |  |  |  | 199 |  |
| Net revenues |  | $ | 1,303 |  |  | $ | 1,236 |  |

[0001564590-20-041759:notes:180]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $637 million and $574 million during the three months ended July 31, 2020 and July 26, 2019, respectively.

[0001564590-20-041759:notes:181]
[same as prior period, unchanged from 0001564590-20-005025:notes:186]

[0001564590-20-041759:notes:182]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| U.S. |  | $ | 1,339 |  |  | $ | 385 |  |
| International |  |  | 2,434 |  |  |  | 2,497 |  |
| Total |  | $ | 3,773 |  |  | $ | 2,882 |  |

[0001564590-20-041759:notes:183]
[same as prior period, unchanged from 0001564590-20-005025:notes:188]

[0001564590-20-041759:notes:184]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| U.S. |  | $ | 548 |  |  | $ | 540 |  |
| International |  |  | 189 |  |  |  | 187 |  |
| Total |  | $ | 737 |  |  | $ | 727 |  |

[0001564590-20-041759:notes:185]
[same as prior period, unchanged from 0001564590-20-005025:notes:190]

[0001564590-20-041759:notes:186]
|  |  | Three Months Ended |  |
|  |  | July 31, 2020 |  |  | July 26, 2019 |  |
| Arrow Electronics, Inc. |  |  | 23 | % |  |  | 25 | % |
| Tech Data Corporation |  |  | 20 | % |  |  | 20 | % |

[0001564590-20-041759:notes:187]
The following customers accounted for 10% or more of accounts receivable in at least one of the periods presented:

[0001564590-20-041759:notes:188]
|  |  | July 31, 2020 |  |  | April 24, 2020 |  |
| Arrow Electronics, Inc. |  |  | 8 | % |  |  | 13 | % |
| Tech Data Corporation |  |  | 19 | % |  |  | 19 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-041759:notes:189]
16. Commitments and Contingencies

[0001564590-20-041759:notes:190]
Purchase Orders and Other Commitments

[0001564590-20-041759:notes:191]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of July 31, 2020, we had $614 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 31, 2020 and April 24, 2020, such liability amounted to $7 million and $6 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-20-041759:notes:192]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 31, 2020, we had $205 million in other purchase obligations.

[0001564590-20-041759:notes:193]
Financing Guarantees

[0001564590-20-041759:notes:194]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $13 million and $14 million of receivables during the three months ended July 31, 2020 and July 26, 2019, respectively.

[0001564590-20-041759:notes:195]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-20-041759:notes:196]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of July 31, 2020 and April 24, 2020, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-20-041759:notes:197]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 31, 2020, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-20-041759:notes:198]
Legal Contingencies

[0001564590-20-041759:notes:199]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-20-041759:notes:200]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. We believe the complaint is without merit and intend to defend the case vigorously.

[0001564590-20-041759:notes:201]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-20-041759:notes:202]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends.  No material accrual has been recorded as of July 31, 2020 related to such matters.


## us-gaap:SubsequentEventsTextBlock

[0001564590-20-041759:notes:203]
17. Subsequent Event

[0001564590-20-041759:notes:204]
On August 25, 2020, we committed to a restructuring plan to optimize our business and fund our biggest opportunities. In connection with the restructuring plan, we expect to reduce our global workforce by approximately 5%. This reduction in workforce will be implemented throughout fiscal 2021. We expect to incur aggregate expenses of $35 million to $40 million for employee terminations and other costs associated with the restructuring plan. We expect that most of these expenses will be cash expenditures and that we will recognize the majority of these expenses in our second quarter of fiscal 2021.
