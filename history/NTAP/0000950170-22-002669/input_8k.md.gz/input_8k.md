# NTAP 8-K — 0000950170-22-001772 filed 2022-02-23

## item codes, every 8-K on or before 2022-03-02

- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2022-03-02

- none on or before 2022-03-02

## item 2.02 — earnings release, exhibit 99.1

[0000950170-22-001772:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0000950170-22-001772:8k_2_02:2]
EX-99.1

[0000950170-22-001772:8k_2_02:3]
Exhibit 99.1

[0000950170-22-001772:8k_2_02:4]
NetApp reports third quarter of fiscal year 2022 results

[0000950170-22-001772:8k_2_02:5]
Net revenues for the third quarter grew 10% year-over-year to $1.61 billion

[0000950170-22-001772:8k_2_02:6]
•
NetApp™ Public Cloud annualized revenue run rate (ARR)1 increased 98% year-over-year to $469 million

[0000950170-22-001772:8k_2_02:7]
•
All-flash array annualized net revenue run rate2 reached an all-time high of $3.2 billion

[0000950170-22-001772:8k_2_02:8]
•
Product revenue grew 9% year-over-year to $846 million, the fourth consecutive quarter of year-over-year growth

[0000950170-22-001772:8k_2_02:9]
•
Billings3 were $1.76 billion, an increase of 10% year-over-year

[0000950170-22-001772:8k_2_02:10]
•
Increased full fiscal year 2022 revenue and EPS guidance

[0000950170-22-001772:8k_2_02:11]
•
$236 million returned to shareholders in share repurchases and cash dividends

[0000950170-22-001772:8k_2_02:12]
SAN JOSE, Calif.—February 23, 2022—NetApp (NASDAQ: NTAP) today reported financial results for the third quarter of fiscal year 2022, which ended on January 28, 2022.

[0000950170-22-001772:8k_2_02:13]
“Q3 results and positive growth outlook are powered by the alignment of our differentiated technology portfolio with customer priorities for cloud and digital transformation. We have a unique position in solving organizations’ most significant challenges in hybrid, multi-cloud IT,” said George Kurian, chief executive officer. “Our focused execution and effective management of temporary supply chain headwinds enable us to capture our expanding opportunity while investing for continued growth and delivering operating leverage.”

[0000950170-22-001772:8k_2_02:14]
Third quarter of fiscal year 2022 financial results

[0000950170-22-001772:8k_2_02:15]
•
Net revenues: $1.61 billion, compared to $1.47 billion in the third quarter of fiscal year 2021

[0000950170-22-001772:8k_2_02:16]
o
Hybrid Cloud segment revenue: $1.50 billion, compared to $1.42 billion in the third quarter of fiscal year 2021

[0000950170-22-001772:8k_2_02:17]
o
Public Cloud segment revenue: $110 million, compared to $55 million in the third quarter of fiscal year 2021

[0000950170-22-001772:8k_2_02:18]
•
Net income: GAAP net income of $252 million, compared to $182 million in the third quarter of fiscal year 2021; non-GAAP net income4 of $330 million, compared to $250 million in the third quarter of fiscal year 2021

[0000950170-22-001772:8k_2_02:19]
•
Earnings per share: GAAP net income per share5 of $1.10, compared to $0.80 in the third quarter of fiscal year 2021; non-GAAP net income per share of $1.44, compared to $1.10 in the third quarter of fiscal year 2021

[0000950170-22-001772:8k_2_02:20]
•
Cash, cash equivalents and investments: $4.20 billion at the end of the third quarter of fiscal year 2022

[0000950170-22-001772:8k_2_02:21]
•
Cash provided by operations: $260 million, compared to $373 million in the third quarter of fiscal year 2021

[0000950170-22-001772:8k_2_02:22]
•
Share repurchase and dividends: Returned $236 million to shareholders through share repurchases and cash dividends

[0000950170-22-001772:8k_2_02:23]
Fourth quarter of fiscal year 2022 financial outlook

[0000950170-22-001772:8k_2_02:24]
The Company provided the following financial guidance for the fourth quarter of fiscal year 2022:

[0000950170-22-001772:8k_2_02:25]
| Net revenues are expected to be in the range of: | $1.635 billion to $1.735 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $0.90 - $1.00 | $1.21 - $1.31 |

[0000950170-22-001772:8k_2_02:26]
Full fiscal year 2022 financial outlook

[0000950170-22-001772:8k_2_02:27]
The Company provided the following financial guidance update for the full fiscal year 2022:

[0000950170-22-001772:8k_2_02:28]
| Net revenues are expected to grow by: | ~10% |
| Public Cloud ARR is expected to exit the fiscal year in the range of: | $525 million to $545 million |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be: | ~66% | ~67% |
| Operating margins are expected to be: | 18% - 19% | 23% - 24% |
| Effective tax rate is expected to be: | ~18% | ~18% |
| Earnings per share is expected to be in the range of: | $3.87 – $3.97 | $5.07 - $5.17 |

[0000950170-22-001772:8k_2_02:29]
Dividend

[0000950170-22-001772:8k_2_02:30]
The next cash dividend of $0.50 per share is to be paid on April 27, 2022, to shareholders of record as of the close of business on April 8, 2022.

[0000950170-22-001772:8k_2_02:31]
Third quarter of fiscal year 2022 business highlights

[0000950170-22-001772:8k_2_02:32]
Leading product innovation

[0000950170-22-001772:8k_2_02:33]
•
NetApp announced the completion of its acquisition of CloudCheckr™, a leading cloud optimization platform that provides cloud visibility and insights to help customers lower costs, maintain security and compliance, and optimize cloud resources.

[0000950170-22-001772:8k_2_02:34]
•
NetApp introduced the AFF A900 system, the latest evolution of its all-flash storage array portfolio, powered by NetApp ONTAP™ Enterprise Edition.

[0000950170-22-001772:8k_2_02:35]
•
NetApp announced that ONTAP is the first enterprise storage and data management platform to achieve Commercial Solutions for Classified (CSfC) Program validation for a Data-at-Rest (DAR) capability package.

[0000950170-22-001772:8k_2_02:36]
•
NetApp announced that NetApp StorageGRID™ technology became the only object storage solution to earn NF203 Digital Safe and ISO 25051 certifications.

[0000950170-22-001772:8k_2_02:37]
•
NetApp introduced anotherSpot by NetApp service, Ocean for Apache Spark. Data infrastructure teams get the power and flexibility of Apache Spark on Kubernetes without the complexity of managing and tuning infrastructure and workloads.

[0000950170-22-001772:8k_2_02:38]
•
NetApp extended the Ocean suite with a private preview of Ocean CD, which makes it easy to execute deployments quickly and reliably with integrated and automated continuous verification.

[0000950170-22-001772:8k_2_02:39]
•
NetApp announced CloudCheckr Well-Architected Readiness Advisor, which helps managed service providers (MSPs) streamline the delivery of AWS Well-Architected Reviews and helps AWS customers maintain compliance with the AWS Well-Architected Framework.

[0000950170-22-001772:8k_2_02:40]
•
NetAppCloud Backup now supports tiering backups to Amazon S3 Glacier, Glacier Deep Archive, Google Cloud Storage Archive, and Azure Archive Storage, making storing backups in the cloud more cost effective.

[0000950170-22-001772:8k_2_02:41]
•
NetApp enhanced Cloud Backup with Kubernetes-aware backup support to protect the data, settings, and metadata in Kubernetes persistent volumes, making data easily accessible and restorable at a granular level.

[0000950170-22-001772:8k_2_02:42]
Customer and partnership expansions

[0000950170-22-001772:8k_2_02:43]
•
NetApp extended its collaboration with Ducati, committing to an additional 2 years of support to help advance Ducati’s performance in the MotoGP World Championship.

[0000950170-22-001772:8k_2_02:44]
•
Kyndryl and NetApp announced a strategic partnership to deliver critical enterprise data infrastructure to BMW Group.

[0000950170-22-001772:8k_2_02:45]
NetApp awards and recognition

[0000950170-22-001772:8k_2_02:46]
•
AWS named NetApp its 2021 AWS Independent Software Vendor (ISV) Design Partner of the Year–U.S. This award recognizes NetApp’s work in helping customers enable innovation and build solutions that facilitate digital and cloud transformation on the AWS Cloud.

[0000950170-22-001772:8k_2_02:47]
•
NetApp was named as a leader and out-performer in three GigaOm Radar Reports: GigaOm Radar for Cloud File Systems, GigaOm Radar for Enterprise Scale-Out File Systems, and GigaOm Radar for Primary Storage for Large Enterprises.

[0000950170-22-001772:8k_2_02:48]
•
NetApp was named in the CRN 2021 Tech Innovator Awards as a finalist for cloud tools and management, as well as a finalist for container technology.

[0000950170-22-001772:8k_2_02:49]
•
NetApp was named on the list of Best Places to Work for LGBTQ+ Equality 2022 by the Human Rights Campaign Foundation’s Corporate Equality Index.

[0000950170-22-001772:8k_2_02:50]
Executive leadership announcements

[0000950170-22-001772:8k_2_02:51]
•
NetApp announced the appointment of Harv Bhela, chief product officer, to its leadership team to accelerate the ongoing transformation of the company into a multicloud, storage, and data services leader.

[0000950170-22-001772:8k_2_02:52]
•
NetApp announced the appointment of Elizabeth O’Callahan as chief legal officer (CLO) and general counsel.

[0000950170-22-001772:8k_2_02:53]
Webcast and conference call information

[0000950170-22-001772:8k_2_02:54]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:00 p.m. Pacific Time today.

[0000950170-22-001772:8k_2_02:55]
###

[0000950170-22-001772:8k_2_02:56]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0000950170-22-001772:8k_2_02:57]
Footnotes

[0000950170-22-001772:8k_2_02:58]
1Public Cloud annualized revenue run rate (ARR) is calculated as the annualized value of all Public Cloud customer commitments with the assumption that any commitment expiring during the next 12 months will be renewed with its existing terms.

[0000950170-22-001772:8k_2_02:59]
2All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0000950170-22-001772:8k_2_02:60]
3Refer to the NetApp Usage of Non-GAAP Financial Information section below for an explanation of billings.

[0000950170-22-001772:8k_2_02:61]
4Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) gains/losses on the sale of investments in equity securities, (i) debt extinguishment costs, (j) COVID-19 charges and (k) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0000950170-22-001772:8k_2_02:62]
5GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0000950170-22-001772:8k_2_02:63]
NetApp usage of non-GAAP financial information

[0000950170-22-001772:8k_2_02:64]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share. NetApp also presents the hardware and software components of our GAAP product revenues. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software

[0000950170-22-001772:8k_2_02:65]
components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0000950170-22-001772:8k_2_02:66]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations.

[0000950170-22-001772:8k_2_02:67]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0000950170-22-001772:8k_2_02:68]
NetApp believes that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0000950170-22-001772:8k_2_02:69]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0000950170-22-001772:8k_2_02:70]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0000950170-22-001772:8k_2_02:71]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0000950170-22-001772:8k_2_02:72]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of

[0000950170-22-001772:8k_2_02:73]
various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0000950170-22-001772:8k_2_02:74]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0000950170-22-001772:8k_2_02:75]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0000950170-22-001772:8k_2_02:76]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0000950170-22-001772:8k_2_02:77]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0000950170-22-001772:8k_2_02:78]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0000950170-22-001772:8k_2_02:79]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-22-001772:8k_2_02:80]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-22-001772:8k_2_02:81]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-22-001772:8k_2_02:82]
J. COVID-19 charges. NetApp has excluded certain non-recurring expenses incurred as a direct result of the COVID-19 pandemic. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-22-001772:8k_2_02:83]
K. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0000950170-22-001772:8k_2_02:84]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0000950170-22-001772:8k_2_02:85]
About NetApp

[0000950170-22-001772:8k_2_02:86]
In a world full of generalists, NetApp is a specialist. We’re focused on one thing, helping your business get the most out of your data. NetApp brings the enterprise-grade data services you rely on into the cloud, and the simple flexibility of cloud into the data center. Our industry-leading solutions work across diverse customer

[0000950170-22-001772:8k_2_02:87]
environments and the world’s biggest public clouds. As a cloud-led, data-centric software company, only NetApp can help build your unique data fabric, simplify and connect your cloud, and securely deliver the right data, services, and applications to the right people—anytime, anywhere.

[0000950170-22-001772:8k_2_02:88]
NETAPP, INC.

[0000950170-22-001772:8k_2_02:89]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-22-001772:8k_2_02:90]
(In millions)

[0000950170-22-001772:8k_2_02:91]
(Unaudited)

[0000950170-22-001772:8k_2_02:92]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,201 |  |  | $ | 4,596 |  |
| Accounts receivable |  |  | 799 |  |  |  | 945 |  |
| Inventories |  |  | 167 |  |  |  | 114 |  |
| Other current assets |  |  | 346 |  |  |  | 346 |  |
| Total current assets |  |  | 5,513 |  |  |  | 6,001 |  |
| Property and equipment, net |  |  | 575 |  |  |  | 525 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,480 |  |  |  | 2,140 |  |
| Other non-current assets |  |  | 932 |  |  |  | 694 |  |
| Total assets |  | $ | 9,500 |  |  | $ | 9,360 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 432 |  |  | $ | 420 |  |
| Accrued expenses |  |  | 807 |  |  |  | 970 |  |
| Current portion of long-term debt |  |  | 250 |  |  |  | — |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 2,063 |  |  |  | 2,062 |  |
| Total current liabilities |  |  | 3,552 |  |  |  | 3,452 |  |
| Long-term debt |  |  | 2,385 |  |  |  | 2,632 |  |
| Other long-term liabilities |  |  | 775 |  |  |  | 650 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,906 |  |  |  | 1,941 |  |
| Total liabilities |  |  | 8,618 |  |  |  | 8,675 |  |
| Stockholders' equity |  |  | 882 |  |  |  | 685 |  |
| Total liabilities and stockholders' equity |  | $ | 9,500 |  |  | $ | 9,360 |  |

[0000950170-22-001772:8k_2_02:93]
NETAPP, INC.

[0000950170-22-001772:8k_2_02:94]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-22-001772:8k_2_02:95]
(In millions, except per share amounts)

[0000950170-22-001772:8k_2_02:96]
(Unaudited)

[0000950170-22-001772:8k_2_02:97]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 846 |  |  | $ | 775 |  |  | $ | 2,390 |  |  | $ | 2,151 |  |
| Services |  |  | 768 |  |  |  | 695 |  |  |  | 2,248 |  |  |  | 2,038 |  |
| Net revenues |  |  | 1,614 |  |  |  | 1,470 |  |  |  | 4,638 |  |  |  | 4,189 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 407 |  |  |  | 369 |  |  |  | 1,108 |  |  |  | 1,045 |  |
| Cost of services |  |  | 134 |  |  |  | 126 |  |  |  | 399 |  |  |  | 364 |  |
| Total cost of revenues |  |  | 541 |  |  |  | 495 |  |  |  | 1,507 |  |  |  | 1,409 |  |
| Gross profit |  |  | 1,073 |  |  |  | 975 |  |  |  | 3,131 |  |  |  | 2,780 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 461 |  |  |  | 436 |  |  |  | 1,377 |  |  |  | 1,297 |  |
| Research and development |  |  | 220 |  |  |  | 215 |  |  |  | 646 |  |  |  | 660 |  |
| General and administrative |  |  | 65 |  |  |  | 63 |  |  |  | 207 |  |  |  | 191 |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 29 |  |  |  | 42 |  |
| Acquisition-related expense |  |  | 6 |  |  |  | 3 |  |  |  | 8 |  |  |  | 14 |  |
| Total operating expenses |  |  | 752 |  |  |  | 717 |  |  |  | 2,267 |  |  |  | 2,204 |  |
| Income from operations |  |  | 321 |  |  |  | 258 |  |  |  | 864 |  |  |  | 576 |  |
| Other expense, net |  |  | (15 | ) |  |  | (11 | ) |  |  | (41 | ) |  |  | (50 | ) |
| Income before income taxes |  |  | 306 |  |  |  | 247 |  |  |  | 823 |  |  |  | 526 |  |
| Provision for income taxes |  |  | 54 |  |  |  | 65 |  |  |  | 145 |  |  |  | 130 |  |
| Net income |  | $ | 252 |  |  | $ | 182 |  |  | $ | 678 |  |  | $ | 396 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.13 |  |  | $ | 0.82 |  |  | $ | 3.04 |  |  | $ | 1.78 |  |
| Diluted |  | $ | 1.10 |  |  | $ | 0.80 |  |  | $ | 2.96 |  |  | $ | 1.76 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 223 |  |  |  | 223 |  |  |  | 223 |  |  |  | 222 |  |
| Diluted |  |  | 229 |  |  |  | 227 |  |  |  | 229 |  |  |  | 225 |  |

[0000950170-22-001772:8k_2_02:98]
NETAPP, INC.

[0000950170-22-001772:8k_2_02:99]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-22-001772:8k_2_02:100]
(In millions)

[0000950170-22-001772:8k_2_02:101]
(Unaudited)

[0000950170-22-001772:8k_2_02:102]
|  |  | Three Months Ended |  |  | Nine Months Ended |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | January 28, 2022 |  |  | January 29, 2021 |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 252 |  |  | $ | 182 |  |  | $ | 678 |  |  | $ | 396 |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 51 |  |  |  | 54 |  |  |  | 143 |  |  |  | 159 |  |  |
| Non-cash operating lease cost |  |  | 12 |  |  |  | 12 |  |  |  | 40 |  |  |  | 38 |  |  |
| Stock-based compensation |  |  | 64 |  |  |  | 46 |  |  |  | 179 |  |  |  | 149 |  |  |
| Deferred income taxes |  |  | (34 | ) |  |  | (1 | ) |  |  | (66 | ) |  |  | (1 | ) |  |
| Other items, net |  |  | (23 | ) |  |  | 7 |  |  |  | (35 | ) |  |  | 35 |  |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (155 | ) |  |  | 11 |  |  |  | 137 |  |  |  | 208 |  |  |
| Inventories |  |  | (12 | ) |  |  | 10 |  |  |  | (53 | ) |  |  | 39 |  |  |
| Accounts payable |  |  | (1 | ) |  |  | (33 | ) |  |  | 10 |  |  |  | (92 | ) |  |
| Accrued expenses |  |  | (1 | ) |  |  | 8 |  |  |  | (207 | ) |  |  | (61 | ) |  |
| Deferred revenue and financed unearned services revenue |  |  | 143 |  |  |  | 128 |  |  |  | 46 |  |  |  | 10 |  |  |
| Long-term taxes payable |  |  | (1 | ) |  |  | (5 | ) |  |  | (66 | ) |  |  | (51 | ) |  |
| Changes in other operating assets and liabilities, net |  |  | (35 | ) |  |  | (46 | ) |  |  | (6 | ) |  |  | (55 | ) |  |
| Net cash provided by operating activities |  |  | 260 |  |  |  | 373 |  |  |  | 800 |  |  |  | 774 |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 10 |  |  |  | 33 |  |  |  | 36 |  |  |  | 140 |  |  |
| Purchases of property and equipment |  |  | (61 | ) |  |  | (32 | ) |  |  | (158 | ) |  |  | (124 | ) |  |
| Proceeds from sale of properties |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 6 |  |  |
| Acquisitions of businesses, net of cash acquired |  |  | (345 | ) |  |  | — |  |  |  | (359 | ) |  |  | (350 | ) |  |
| Other investing activities, net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 8 |  |  |
| Net cash (used in) provided by investing activities |  |  | (396 | ) |  |  | 1 |  |  |  | (481 | ) |  |  | (320 | ) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 52 |  |  |  | 43 |  |  |  | 105 |  |  |  | 92 |  |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (6 | ) |  |  | (4 | ) |  |  | (69 | ) |  |  | (38 | ) |  |
| Repurchase of common stock |  |  | (125 | ) |  |  | (50 | ) |  |  | (350 | ) |  |  | (50 | ) |  |
| Repayments of commercial paper notes, original maturities of three months or less, net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (420 | ) |  |
| Issuance of debt, net of issuance costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2,057 |  |  |
| Repayments and extinguishment of debt |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (689 | ) |  |
| Dividends paid |  |  | (111 | ) |  |  | (107 | ) |  |  | (335 | ) |  |  | (321 | ) |  |
| Other financing activities, net |  |  | — |  |  |  | (4 | ) |  |  | (2 | ) |  |  | (7 | ) |  |
| Net cash (used in) provided by financing activities |  |  | (190 | ) |  |  | (122 | ) |  |  | (651 | ) |  |  | 624 |  |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (13 | ) |  |  | 26 |  |  |  | (26 | ) |  |  | 70 |  |  |
| Net change in cash, cash equivalents and restricted cash |  |  | (339 | ) |  |  | 278 |  |  |  | (358 | ) |  |  | 1,148 |  |  |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 4,516 |  |  |  | 3,536 |  |  |  | 4,535 |  |  |  | 2,666 |  |  |
| End of period |  | $ | 4,177 |  |  | $ | 3,814 |  |  | $ | 4,177 |  |  | $ | 3,814 |  |  |

[0000950170-22-001772:8k_2_02:103]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
| In the first quarter of fiscal year 2022, the Company introduced two segments for financial reporting purposes: Hybrid Cloud and Public Cloud. Prior period disclosures have been revised for comparability. |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| Product |  | $ | 846 |  |  | $ | 814 |  |  | $ | 775 |  |
| Support |  |  | 586 |  |  |  | 590 |  |  |  | 571 |  |
| Professional and Other Services |  |  | 72 |  |  |  | 75 |  |  |  | 69 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,504 |  |  |  | 1,479 |  |  |  | 1,415 |  |
| Public Cloud Segment Net Revenues |  |  | 110 |  |  |  | 87 |  |  |  | 55 |  |
| Net Revenues |  | $ | 1,614 |  |  | $ | 1,566 |  |  | $ | 1,470 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| Product |  | $ | 442 |  |  | $ | 445 |  |  | $ | 414 |  |
| Support |  |  | 541 |  |  |  | 542 |  |  |  | 522 |  |
| Professional and Other Services |  |  | 26 |  |  |  | 21 |  |  |  | 16 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 1,009 |  |  |  | 1,008 |  |  |  | 952 |  |
| Public Cloud Segment Gross Profit |  |  | 78 |  |  |  | 62 |  |  |  | 38 |  |
| Total Segments Gross Profit |  |  | 1,087 |  |  |  | 1,070 |  |  |  | 990 |  |
| Amortization of Intangible Assets |  |  | (9 | ) |  |  | (7 | ) |  |  | (12 | ) |
| Stock-based Compensation |  |  | (5 | ) |  |  | (4 | ) |  |  | (3 | ) |
| Unallocated Cost of Revenues |  |  | (14 | ) |  |  | (11 | ) |  |  | (15 | ) |
| Gross Profit |  | $ | 1,073 |  |  | $ | 1,059 |  |  | $ | 975 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| Product |  |  | 52.2 | % |  |  | 54.7 | % |  |  | 53.4 | % |
| Support |  |  | 92.3 | % |  |  | 91.9 | % |  |  | 91.4 | % |
| Professional and Other Services |  |  | 36.1 | % |  |  | 28.0 | % |  |  | 23.2 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 67.1 | % |  |  | 68.2 | % |  |  | 67.3 | % |
| Public Cloud Segment Gross Margin |  |  | 70.9 | % |  |  | 71.3 | % |  |  | 69.1 | % |
| Product Revenues |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| Total |  | $ | 846 |  |  | $ | 814 |  |  | $ | 775 |  |
| Software* |  | $ | 507 |  |  | $ | 475 |  |  | $ | 428 |  |
| Hardware* |  | $ | 339 |  |  | $ | 339 |  |  | $ | 347 |  |
| Software and recurring support and public cloud revenue |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| Product - Software |  | $ | 507 |  |  | $ | 475 |  |  | $ | 428 |  |
| Support |  |  | 586 |  |  |  | 590 |  |  |  | 572 |  |
| Public Cloud |  |  | 110 |  |  |  | 87 |  |  |  | 55 |  |
| Software and recurring support and public cloud revenue* |  | $ | 1,203 |  |  | $ | 1,152 |  |  | $ | 1,055 |  |
| Software and recurring support and public cloud revenue as a percentage of net revenues |  |  | 75 | % |  |  | 74 | % |  |  | 72 | % |

[0000950170-22-001772:8k_2_02:104]
| * Our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation. We have provided a breakdown of our GAAP product revenues into the software and hardware components, which are considered non-GAAP measures, to display the significance of software included in total product revenues. Software and recurring support and public cloud revenue is a non-GAAP measure because it includes the software component of our product revenues, but not the hardware component. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'22 |  |  | % of Q2 FY'22 |  |  | % of Q3 FY'21 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 56 | % |  |  | 55 | % |  |  | 53 | % |
| Americas Commercial |  |  | 47 | % |  |  | 43 | % |  |  | 43 | % |
| U.S. Public Sector |  |  | 9 | % |  |  | 12 | % |  |  | 10 | % |
| EMEA |  |  | 32 | % |  |  | 29 | % |  |  | 32 | % |
| Asia Pacific |  |  | 12 | % |  |  | 15 | % |  |  | 15 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'22 |  |  | % of Q2 FY'22 |  |  | % of Q3 FY'21 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 21 | % |  |  | 24 | % |  |  | 24 | % |
| Indirect |  |  | 79 | % |  |  | 76 | % |  |  | 76 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| Non-GAAP Income from Operations |  | $ | 404 |  |  | $ | 374 |  |  | $ | 322 |  |
| % of Net Revenues |  |  | 25.0 | % |  |  | 23.9 | % |  |  | 21.9 | % |
| Non-GAAP Income before Income Taxes |  | $ | 389 |  |  | $ | 360 |  |  | $ | 311 |  |
| Non-GAAP Effective Tax Rate |  |  | 15.2 | % |  |  | 18.9 | % |  |  | 19.6 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| Non-GAAP Net Income |  | $ | 330 |  |  | $ | 292 |  |  | $ | 250 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 229 |  |  |  | 229 |  |  |  | 227 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.44 |  |  | $ | 1.28 |  |  | $ | 1.10 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,969 |  |  | $ | 3,866 |  |  | $ | 3,828 |  |
| DSO (days) |  |  | 45 |  |  |  | 38 |  |  |  | 49 |  |
| DPO (days) |  |  | 73 |  |  |  | 78 |  |  |  | 62 |  |
| Inventory Turns |  |  | 13 |  |  |  | 13 |  |  |  | 19 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| Net Cash Provided by Operating Activities |  | $ | 260 |  |  | $ | 298 |  |  | $ | 373 |  |
| Purchases of Property and Equipment |  | $ | 61 |  |  | $ | 46 |  |  | $ | 32 |  |
| Free Cash Flow |  | $ | 199 |  |  | $ | 252 |  |  | $ | 341 |  |
| Free Cash Flow as % of Net Revenues |  |  | 12.3 | % |  |  | 16.1 | % |  |  | 23.2 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |

[0000950170-22-001772:8k_2_02:105]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| NET INCOME |  | $ | 252 |  |  | $ | 224 |  |  | $ | 182 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 10 |  |  |  | 15 |  |
| Stock-based compensation |  |  | 64 |  |  |  | 62 |  |  |  | 46 |  |
| Restructuring charges |  |  | — |  |  |  | 7 |  |  |  | — |  |
| Acquisition-related expense |  |  | 6 |  |  |  | 1 |  |  |  | 3 |  |
| Income tax effects |  |  | (5 | ) |  |  | (13 | ) |  |  | (13 | ) |
| Income tax expenses from integration of acquired companies |  |  | — |  |  |  | 1 |  |  |  | 17 |  |
| NON-GAAP NET INCOME |  | $ | 330 |  |  | $ | 292 |  |  | $ | 250 |  |
| COST OF REVENUES |  | $ | 541 |  |  | $ | 507 |  |  | $ | 495 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (7 | ) |  |  | (12 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (4 | ) |  |  | (3 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 527 |  |  | $ | 496 |  |  | $ | 480 |  |
| COST OF PRODUCT REVENUES |  | $ | 407 |  |  | $ | 372 |  |  | $ | 369 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  | (2 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 404 |  |  | $ | 369 |  |  | $ | 361 |  |
| COST OF SERVICES REVENUES |  | $ | 134 |  |  | $ | 135 |  |  | $ | 126 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (5 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (3 | ) |  |  | (2 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 123 |  |  | $ | 127 |  |  | $ | 119 |  |
| GROSS PROFIT |  | $ | 1,073 |  |  | $ | 1,059 |  |  | $ | 975 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 7 |  |  |  | 12 |  |
| Stock-based compensation |  |  | 5 |  |  |  | 4 |  |  |  | 3 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,087 |  |  | $ | 1,070 |  |  | $ | 990 |  |

[0000950170-22-001772:8k_2_02:106]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| SALES AND MARKETING EXPENSES |  | $ | 461 |  |  | $ | 465 |  |  | $ | 436 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (4 | ) |  |  | (3 | ) |  |  | (3 | ) |
| Stock-based compensation |  |  | (30 | ) |  |  | (29 | ) |  |  | (21 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 427 |  |  | $ | 433 |  |  | $ | 412 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 220 |  |  | $ | 216 |  |  | $ | 215 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (19 | ) |  |  | (19 | ) |  |  | (15 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 201 |  |  | $ | 197 |  |  | $ | 200 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 65 |  |  | $ | 76 |  |  | $ | 63 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (10 | ) |  |  | (10 | ) |  |  | (7 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 55 |  |  | $ | 66 |  |  | $ | 56 |  |
| RESTRUCTURING CHARGES |  | $ | — |  |  | $ | 7 |  |  | $ | — |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | — |  |  |  | (7 | ) |  |  | — |  |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 6 |  |  | $ | 1 |  |  | $ | 3 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (6 | ) |  |  | (1 | ) |  |  | (3 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 752 |  |  | $ | 765 |  |  | $ | 717 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (4 | ) |  |  | (3 | ) |  |  | (3 | ) |
| Stock-based compensation |  |  | (59 | ) |  |  | (58 | ) |  |  | (43 | ) |
| Restructuring charges |  |  | — |  |  |  | (7 | ) |  |  | — |  |
| Acquisition-related expense |  |  | (6 | ) |  |  | (1 | ) |  |  | (3 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 683 |  |  | $ | 696 |  |  | $ | 668 |  |

[0000950170-22-001772:8k_2_02:107]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| INCOME FROM OPERATIONS |  | $ | 321 |  |  | $ | 294 |  |  | $ | 258 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 10 |  |  |  | 15 |  |
| Stock-based compensation |  |  | 64 |  |  |  | 62 |  |  |  | 46 |  |
| Restructuring charges |  |  | — |  |  |  | 7 |  |  |  | — |  |
| Acquisition-related expense |  |  | 6 |  |  |  | 1 |  |  |  | 3 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 404 |  |  | $ | 374 |  |  | $ | 322 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 306 |  |  | $ | 280 |  |  | $ | 247 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 10 |  |  |  | 15 |  |
| Stock-based compensation |  |  | 64 |  |  |  | 62 |  |  |  | 46 |  |
| Restructuring charges |  |  | — |  |  |  | 7 |  |  |  | — |  |
| Acquisition-related expense |  |  | 6 |  |  |  | 1 |  |  |  | 3 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 389 |  |  | $ | 360 |  |  | $ | 311 |  |
| PROVISION FOR INCOME TAXES |  | $ | 54 |  |  | $ | 56 |  |  | $ | 65 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 5 |  |  |  | 13 |  |  |  | 13 |  |
| Income tax expenses from integration of acquired companies |  |  | — |  |  |  | (1 | ) |  |  | (17 | ) |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 59 |  |  | $ | 68 |  |  | $ | 61 |  |
| NET INCOME PER SHARE |  | $ | 1.10 |  |  | $ | 0.98 |  |  | $ | 0.80 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.06 |  |  |  | 0.04 |  |  |  | 0.07 |  |
| Stock-based compensation |  |  | 0.28 |  |  |  | 0.27 |  |  |  | 0.20 |  |
| Restructuring charges |  |  | — |  |  |  | 0.03 |  |  |  | — |  |
| Acquisition-related expense |  |  | 0.03 |  |  |  | — |  |  |  | 0.01 |  |
| Income tax effects |  |  | (0.02 | ) |  |  | (0.06 | ) |  |  | (0.06 | ) |
| Income tax expenses from integration of acquired companies |  |  | — |  |  |  | — |  |  |  | 0.07 |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.44 |  |  | $ | 1.28 |  |  | $ | 1.10 |  |

[0000950170-22-001772:8k_2_02:108]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| Gross margin-GAAP |  |  | 66.5 | % |  |  | 67.6 | % |  |  | 66.3 | % |
| Cost of revenues adjustments |  |  | 0.9 | % |  |  | 0.7 | % |  |  | 1.0 | % |
| Gross margin-Non-GAAP |  |  | 67.3 | % |  |  | 68.3 | % |  |  | 67.3 | % |
| GAAP cost of revenues |  | $ | 541 |  |  | $ | 507 |  |  | $ | 495 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (7 | ) |  |  | (12 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (4 | ) |  |  | (3 | ) |
| Non-GAAP cost of revenues |  | $ | 527 |  |  | $ | 496 |  |  | $ | 480 |  |
| Net revenues |  | $ | 1,614 |  |  | $ | 1,566 |  |  | $ | 1,470 |  |

[0000950170-22-001772:8k_2_02:109]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| Product gross margin-GAAP |  |  | 51.9 | % |  |  | 54.3 | % |  |  | 52.4 | % |
| Cost of product revenues adjustments |  |  | 0.4 | % |  |  | 0.4 | % |  |  | 1.0 | % |
| Product gross margin-Non-GAAP |  |  | 52.2 | % |  |  | 54.7 | % |  |  | 53.4 | % |
| GAAP cost of product revenues |  | $ | 407 |  |  | $ | 372 |  |  | $ | 369 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  | (2 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 404 |  |  | $ | 369 |  |  | $ | 361 |  |
| Product revenues |  | $ | 846 |  |  | $ | 814 |  |  | $ | 775 |  |

[0000950170-22-001772:8k_2_02:110]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| Services gross margin-GAAP |  |  | 82.6 | % |  |  | 82.0 | % |  |  | 81.9 | % |
| Cost of services revenues adjustment |  |  | 1.4 | % |  |  | 1.1 | % |  |  | 1.0 | % |
| Services gross margin-Non-GAAP |  |  | 84.0 | % |  |  | 83.1 | % |  |  | 82.9 | % |
| GAAP cost of services revenues |  | $ | 134 |  |  | $ | 135 |  |  | $ | 126 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (5 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (3 | ) |  |  | (2 | ) |
| Non-GAAP cost of services revenues |  | $ | 123 |  |  | $ | 127 |  |  | $ | 119 |  |
| Services revenues |  | $ | 768 |  |  | $ | 752 |  |  | $ | 695 |  |

[0000950170-22-001772:8k_2_02:111]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| GAAP effective tax rate |  |  | 17.6 | % |  |  | 20.0 | % |  |  | 26.3 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | (2.5 | )% |  |  | (0.8 | )% |  |  | 0.2 | % |
| Income tax expenses from integration of acquired companies |  |  | — | % |  |  | (0.4 | )% |  |  | (6.9 | )% |
| Non-GAAP effective tax rate |  |  | 15.2 | % |  |  | 18.9 | % |  |  | 19.6 | % |

[0000950170-22-001772:8k_2_02:112]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| Net cash provided by operating activities |  | $ | 260 |  |  | $ | 298 |  |  | $ | 373 |  |
| Purchases of property and equipment |  |  | (61 | ) |  |  | (46 | ) |  |  | (32 | ) |
| Free cash flow |  | $ | 199 |  |  | $ | 252 |  |  | $ | 341 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q3'FY22 |  |  | Q2'FY22 |  |  | Q3'FY21 |  |
| Net revenues |  | $ | 1,614 |  |  | $ | 1,566 |  |  | $ | 1,470 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | 143 |  |  |  | (15 | ) |  |  | 128 |  |
| Billings |  | $ | 1,757 |  |  | $ | 1,551 |  |  | $ | 1,598 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0000950170-22-001772:8k_2_02:113]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FOURTH QUARTER FISCAL 2022 |
|  |  | Fourth Quarter |
|  |  | Fiscal 2022 |
| Non-GAAP Guidance - Net Income Per Share |  | $1.21 - $1.31 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the Fourth Quarter Fiscal 2022: |  |  |
| Amortization of intangible assets |  | ($0.06) |
| Stock-based compensation expense |  | ($0.28) |
| Income tax effects |  | $0.03 |
| Total Adjustments |  | ($0.31) |
| GAAP Guidance - Net Income Per Share |  | $0.90 - $1.00 |

[0000950170-22-001772:8k_2_02:114]
Some items may not add or recalculate due to rounding.

[0000950170-22-001772:8k_2_02:115]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| FISCAL 2022 |
| (Unaudited) |
|  |  | Fiscal 2022 |
| Gross Margin - Non-GAAP Guidance |  |  |
| Adjustment: |  | ~67% |
| Cost of revenues adjustments |  | (1)% |
| Gross Margin - GAAP Guidance |  | ~66% |
|  |  | Fiscal 2022 |
| Operating Margin - Non-GAAP Guidance |  | 23% - 24% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | (1)% |
| Stock-based compensation expense |  | (4)% |
| Operating Margin - GAAP Guidance |  | 18% - 19% |
|  |  | Fiscal 2022 |
| Effective Tax Rate - Non-GAAP Guidance |  | ~18% |
| Adjustment: |  |  |
| Income tax effects |  | -% |
| Effective Tax Rate - GAAP Guidance |  | ~18% |

[0000950170-22-001772:8k_2_02:116]
Some items may not add or recalculate due to rounding.

[0000950170-22-001772:8k_2_02:117]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FISCAL 2022 |
|  |  | Fiscal 2022 |
| Non-GAAP Guidance - Net Income Per Share |  | $5.07 - $5.17 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2022: |  |  |
| Amortization of intangible assets |  | ($0.20) |
| Stock-based compensation expense |  | ($1.07) |
| Litigation Settlement |  | ($0.01) |
| Restructuring charges |  | ($0.13) |
| Acquisition-related expenses |  | ($0.03) |
| Income tax effects |  | $0.24 |
| Total Adjustments |  | ($1.20) |
| GAAP Guidance - Net Income Per Share |  | $3.87 - $3.97 |

[0000950170-22-001772:8k_2_02:118]
Some items may not add or recalculate due to rounding.

[0000950170-22-001772:8k_2_02:119]
Contacts:

[0000950170-22-001772:8k_2_02:120]
(Press)

[0000950170-22-001772:8k_2_02:121]
Chris Drago

[0000950170-22-001772:8k_2_02:122]
1 831 900 8889

[0000950170-22-001772:8k_2_02:123]
chris.drago@netapp.com

[0000950170-22-001772:8k_2_02:124]
(Investors)

[0000950170-22-001772:8k_2_02:125]
Lance Berger

[0000950170-22-001772:8k_2_02:126]
1 408 822 6628

[0000950170-22-001772:8k_2_02:127]
lance.berger@netapp.com
