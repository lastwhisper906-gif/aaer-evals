# NTAP notes — 0000950170-22-002669


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000950170-22-002669:notes:1]
[same as prior period, unchanged from 0000950170-21-005014:notes:1]

[0000950170-22-002669:notes:2]
[same as prior period, unchanged from 0000950170-21-005014:notes:2]

[0000950170-22-002669:notes:3]
[same as prior period, unchanged from 0000950170-21-005014:notes:3]

[0000950170-22-002669:notes:4]
[same as prior period, unchanged from 0000950170-21-005014:notes:4]

[0000950170-22-002669:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 30, 2021 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 28, 2022 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0000950170-22-002669:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee compensation and benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates. Management’s estimates include, as applicable, the anticipated impacts of the COVID-19 pandemic.

[0000950170-22-002669:notes:7]
[same as prior period, unchanged from 0000950170-21-005014:notes:7]

[0000950170-22-002669:notes:8]
[same as prior period, unchanged from 0000950170-21-005014:notes:8]

[0000950170-22-002669:notes:9]
[same as prior period, unchanged from 0000950170-21-005014:notes:9]

[0000950170-22-002669:notes:10]
[same as prior period, unchanged from 0000950170-21-005014:notes:10]

[0000950170-22-002669:notes:11]
[same as prior period, unchanged from 0000950170-21-005014:notes:11]

[0000950170-22-002669:notes:12]
[same as prior period, unchanged from 0000950170-21-005014:notes:12]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000950170-22-002669:notes:13]
2. Recent Accounting Pronouncements

[0000950170-22-002669:notes:14]
In October 2021, the FASB amended certain Topic 805, Business Combinations, guidance to require customer contract assets and liabilities to be recognized consistent with ASC 606 as if the acquiring company had originally executed the acquired company's customer contracts. We early-adopted this guidance in our third quarter of fiscal 2022. The adoption of this update did not have a material impact on our condensed consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-22-002669:notes:15]
[same as prior period, unchanged from 0000950170-21-005014:notes:15]

[0000950170-22-002669:notes:16]
Fiscal 2022 Acquisitions

[0000950170-22-002669:notes:17]
CloudCheckr Inc. Acquisition

[0000950170-22-002669:notes:18]
On November 5, 2021, we acquired all the outstanding shares of privately-held CloudCheckr Inc., ("CloudCheckr") for approximately $347 million in cash. CloudCheckr is a leading cloud optimization platform that provides cloud visibility and insights to lower costs, maintain security and compliance, and optimize cloud resources.

[0000950170-22-002669:notes:19]
The preliminary acquisition-date fair values of the assets acquired and liabilities assumed are as follows (in millions):

[0000950170-22-002669:notes:20]
|  |  | Amount |  |
| Cash |  | $ | 2 |  |
| Intangible assets |  |  | 76 |  |
| Goodwill |  |  | 280 |  |
| Other assets |  |  | 6 |  |
| Total assets acquired |  |  | 364 |  |
| Liabilities assumed |  |  | (17 | ) |
| Total purchase price |  | $ | 347 |  |

[0000950170-22-002669:notes:21]
The components of the intangible assets acquired were as follows (in millions, except useful life):

[0000950170-22-002669:notes:22]
|  |  | Amount |  |  | Estimated useful life(years) |  |
| Developed technology |  | $ | 45 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 30 |  |  |  | 5 |  |
| Trade name |  |  | 1 |  |  |  | 3 |  |
| Total intangible assets |  | $ | 76 |  |  |  |  |

[0000950170-22-002669:notes:23]
[same as prior period, unchanged from 0000950170-21-005014:notes:17]

[0000950170-22-002669:notes:24]
[same as prior period, unchanged from 0000950170-21-005014:notes:18]

[0000950170-22-002669:notes:25]
[same as prior period, unchanged from 0000950170-21-005014:notes:20]

[0000950170-22-002669:notes:26]
The acquired assets and assumed liabilities of Data Mechanics and CloudCheckr were recorded at their estimated fair values. We determined the preliminary estimated fair values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expect to realize incremental revenue by offering continuous cost optimization and managed services from our existing capabilities to help customers improve their cloud resources and realize the benefits of cloud faster and at scale. We also anticipate opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated fair value of their identifiable net assets acquired, and as a result, we have recorded goodwill in connection with both of these acquisitions. The goodwill is not deductible for income tax purposes.

[0000950170-22-002669:notes:27]
The results of operations related to the acquisitions of Data Mechanics and CloudCheckr have been included in our condensed consolidated statements of income from their respective acquisition dates. Pro forma results of operations have not been presented because the impact from these acquisitions was not material to our consolidated results of operations.

[0000950170-22-002669:notes:28]
[same as prior period, unchanged from 0000950170-21-005014:notes:22]

[0000950170-22-002669:notes:29]
[same as prior period, unchanged from 0000950170-21-005014:notes:23]

[0000950170-22-002669:notes:30]
On April 28, 2020, we acquired all the outstanding shares of privately-held Cloud Jumper Corporation ("Cloud Jumper"), a provider of virtual desktop infrastructure and remote desktop services solutions based in North Carolina, for $34 million in cash.

[0000950170-22-002669:notes:31]
[same as prior period, unchanged from 0000950170-21-005014:notes:25]

[0000950170-22-002669:notes:32]
[same as prior period, unchanged from 0000950170-21-005014:notes:26]

[0000950170-22-002669:notes:33]
[same as prior period, unchanged from 0000950170-21-005014:notes:27]

[0000950170-22-002669:notes:34]
On July 9, 2020, we acquired all the outstanding shares of privately-held Spot, Inc. ("Spot"), a provider of compute management cost optimization services on the public clouds based in Israel, for $340 million in cash.

[0000950170-22-002669:notes:35]
[same as prior period, unchanged from 0000950170-21-005014:notes:29]

[0000950170-22-002669:notes:36]
[same as prior period, unchanged from 0000950170-21-005014:notes:30]

[0000950170-22-002669:notes:37]
[same as prior period, unchanged from 0000950170-21-005014:notes:31]

[0000950170-22-002669:notes:38]
[same as prior period, unchanged from 0000950170-21-005014:notes:32]

[0000950170-22-002669:notes:39]
The results of operations related to the acquisitions of Spot and Cloud Jumper have been included in our consolidated statements of income from their respective acquisition dates. Pro forma results of operations have not been presented because the impact from these acquisitions was not material to our consolidated results of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-22-002669:notes:40]
[same as prior period, unchanged from 0000950170-21-005014:notes:34]

[0000950170-22-002669:notes:41]
[same as prior period, unchanged from 0000950170-21-005014:notes:35]

[0000950170-22-002669:notes:42]
|  |  | Amount |  |
| Balance as of April 30, 2021 |  | $ | 2,039 |  |
| Additions |  |  | 291 |  |
| Balance as of January 28, 2022 |  | $ | 2,330 |  |

[0000950170-22-002669:notes:43]
Beginning with the first quarter of fiscal 2022, the Company has two reportable segments: Public Cloud and Hybrid Cloud. As a result, goodwill was allocated to the segments using a relative fair value approach. Goodwill additions of $291 million related to the acquisition of CloudCheckr and Data Mechanics have been allocated to our Public Cloud segment.

[0000950170-22-002669:notes:44]
Goodwill by reportable segment as of January 28, 2022 is as follows (in millions):

[0000950170-22-002669:notes:45]
|  |  | Amount |  |
| Public Cloud |  | $ | 616 |  |
| Hybrid Cloud |  |  | 1,714 |  |
| Total goodwill |  | $ | 2,330 |  |

[0000950170-22-002669:notes:46]
[same as prior period, unchanged from 0000950170-21-005014:notes:40]

[0000950170-22-002669:notes:47]
[same as prior period, unchanged from 0000950170-21-005014:notes:41]

[0000950170-22-002669:notes:48]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 151 |  |  | $ | (56 | ) |  | $ | 95 |  |  | $ | 215 |  |  | $ | (147 | ) |  | $ | 68 |  |
| Customer contracts/relationships |  |  | 68 |  |  |  | (15 | ) |  |  | 53 |  |  |  | 38 |  |  |  | (8 | ) |  |  | 30 |  |
| Other purchased intangibles |  |  | 4 |  |  |  | (2 | ) |  |  | 2 |  |  |  | 3 |  |  |  | — |  |  |  | 3 |  |
| Total purchased intangible assets |  | $ | 223 |  |  | $ | (73 | ) |  | $ | 150 |  |  | $ | 256 |  |  | $ | (155 | ) |  | $ | 101 |  |

[0000950170-22-002669:notes:49]
[same as prior period, unchanged from 0000950170-21-005014:notes:43]

[0000950170-22-002669:notes:50]
[same as prior period, unchanged from 0000950170-21-005014:notes:44]

[0000950170-22-002669:notes:51]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Statements of |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | IncomeClassification |
| Developed technology |  | $ | 9 |  |  | $ | 12 |  |  | $ | 23 |  |  | $ | 34 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 4 |  |  |  | 3 |  |  |  | 7 |  |  |  | 6 |  |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | — |  |  | Operating expenses |
| Total |  | $ | 13 |  |  | $ | 15 |  |  | $ | 32 |  |  | $ | 40 |  |  |  |

[0000950170-22-002669:notes:52]
As of January 28, 2022, future amortization expense related to purchased intangible assets is as follows (in millions):

[0000950170-22-002669:notes:53]
| Fiscal Year |  | Amount |  |
| 2022 (remainder) |  | $ | 14 |  |
| 2023 |  |  | 45 |  |
| 2024 |  |  | 34 |  |
| 2025 |  |  | 35 |  |
| 2026 |  |  | 18 |  |
| 2027 |  |  | 4 |  |
| Total |  | $ | 150 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-22-002669:notes:54]
[same as prior period, unchanged from 0000950170-21-005014:notes:48]

[0000950170-22-002669:notes:55]
[same as prior period, unchanged from 0000950170-21-005014:notes:49]

[0000950170-22-002669:notes:56]
[same as prior period, unchanged from 0000950170-21-005014:notes:50]

[0000950170-22-002669:notes:57]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| Cash and cash equivalents |  | $ | 4,170 |  |  | $ | 4,529 |  |
| Restricted cash |  |  | 7 |  |  |  | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 4,177 |  |  | $ | 4,535 |  |

[0000950170-22-002669:notes:58]
[same as prior period, unchanged from 0000950170-21-005014:notes:52]

[0000950170-22-002669:notes:59]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| Purchased components |  | $ | 97 |  |  | $ | 22 |  |
| Finished goods |  |  | 70 |  |  |  | 92 |  |
| Inventories |  | $ | 167 |  |  | $ | 114 |  |

[0000950170-22-002669:notes:60]
[same as prior period, unchanged from 0000950170-21-005014:notes:54]

[0000950170-22-002669:notes:61]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 352 |  |  |  | 356 |  |
| Leasehold improvements |  |  | 77 |  |  |  | 83 |  |
| Computer, production, engineering and other equipment |  |  | 903 |  |  |  | 869 |  |
| Computer software |  |  | 310 |  |  |  | 305 |  |
| Furniture and fixtures |  |  | 77 |  |  |  | 93 |  |
| Construction-in-progress |  |  | 88 |  |  |  | 46 |  |
|  |  |  | 1,853 |  |  |  | 1,798 |  |
| Accumulated depreciation and amortization |  |  | (1,278 | ) |  |  | (1,273 | ) |
| Property and equipment, net |  | $ | 575 |  |  | $ | 525 |  |

[0000950170-22-002669:notes:62]
[same as prior period, unchanged from 0000950170-21-005014:notes:56]

[0000950170-22-002669:notes:63]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| Deferred tax assets |  | $ | 272 |  |  | $ | 219 |  |
| Operating lease ROU assets |  |  | 308 |  |  |  | 114 |  |
| Other assets |  |  | 352 |  |  |  | 361 |  |
| Other non-current assets |  | $ | 932 |  |  | $ | 694 |  |

[0000950170-22-002669:notes:64]
Other non-current assets as of January 28, 2022 and April 30, 2021 include $75 million and $71 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited, a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019.

[0000950170-22-002669:notes:65]
[same as prior period, unchanged from 0000950170-21-005014:notes:59]

[0000950170-22-002669:notes:66]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| Accrued compensation and benefits |  | $ | 355 |  |  | $ | 505 |  |
| Product warranty liabilities |  |  | 17 |  |  |  | 21 |  |
| Operating lease liabilities |  |  | 48 |  |  |  | 49 |  |
| Other current liabilities |  |  | 387 |  |  |  | 395 |  |
| Accrued expenses |  | $ | 807 |  |  | $ | 970 |  |

[0000950170-22-002669:notes:67]
[same as prior period, unchanged from 0000950170-21-005014:notes:61]

[0000950170-22-002669:notes:68]
[same as prior period, unchanged from 0000950170-21-005014:notes:62]

[0000950170-22-002669:notes:69]
[same as prior period, unchanged from 0000950170-21-005014:notes:63]

[0000950170-22-002669:notes:70]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Balance at beginning of period |  | $ | 28 |  |  | $ | 35 |  |  | $ | 32 |  |  | $ | 41 |  |
| Expense accrued during the period |  |  | 1 |  |  |  | 5 |  |  |  | 7 |  |  |  | 10 |  |
| Warranty costs incurred |  |  | (4 | ) |  |  | (6 | ) |  |  | (14 | ) |  |  | (17 | ) |
| Balance at end of period |  | $ | 25 |  |  | $ | 34 |  |  | $ | 25 |  |  | $ | 34 |  |

[0000950170-22-002669:notes:71]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| Accrued expenses |  | $ | 17 |  |  | $ | 21 |  |
| Other long-term liabilities |  |  | 8 |  |  |  | 11 |  |
| Total warranty liabilities |  | $ | 25 |  |  | $ | 32 |  |

[0000950170-22-002669:notes:72]
[same as prior period, unchanged from 0000950170-21-005014:notes:66]

[0000950170-22-002669:notes:73]
[same as prior period, unchanged from 0000950170-21-005014:notes:67]

[0000950170-22-002669:notes:74]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| Liability for uncertain tax positions |  | $ | 110 |  |  | $ | 127 |  |
| Income taxes payable |  |  | 303 |  |  |  | 351 |  |
| Product warranty liabilities |  |  | 8 |  |  |  | 11 |  |
| Operating lease liabilities |  |  | 269 |  |  |  | 71 |  |
| Other liabilities |  |  | 85 |  |  |  | 90 |  |
| Other long-term liabilities |  | $ | 775 |  |  | $ | 650 |  |

[0000950170-22-002669:notes:75]
[same as prior period, unchanged from 0000950170-21-005014:notes:69]

[0000950170-22-002669:notes:76]
[same as prior period, unchanged from 0000950170-21-005014:notes:70]

[0000950170-22-002669:notes:77]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| Deferred product revenue |  | $ | 49 |  |  | $ | 59 |  |
| Deferred services revenue |  |  | 3,857 |  |  |  | 3,873 |  |
| Financed unearned services revenue |  |  | 63 |  |  |  | 71 |  |
| Total |  | $ | 3,969 |  |  | $ | 4,003 |  |
| Reported as: |  |  |  |  |  |  |
| Short-term |  | $ | 2,063 |  |  | $ | 2,062 |  |
| Long-term |  |  | 1,906 |  |  |  | 1,941 |  |
| Total |  | $ | 3,969 |  |  | $ | 4,003 |  |

[0000950170-22-002669:notes:78]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, Public Cloud, and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 15 – Commitments and Contingencies for additional information related to these arrangements.

[0000950170-22-002669:notes:79]
During the nine months ended January 28, 2022 and January 29, 2021, we recognized revenue of $1,647 million and $1,687 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0000950170-22-002669:notes:80]
As of January 28, 2022, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied approximated our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 52% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 23% in the next 13 to 24 months, and the remainder thereafter.

[0000950170-22-002669:notes:81]
[same as prior period, unchanged from 0000950170-21-005014:notes:77]

[0000950170-22-002669:notes:82]
The following table summarizes deferred commissions balances as reported in our condensed consolidated balance sheets (in millions):

[0000950170-22-002669:notes:83]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| Other current assets |  | $ | 85 |  |  | $ | 86 |  |
| Other non-current assets |  |  | 117 |  |  |  | 111 |  |
| Total deferred commissions |  | $ | 202 |  |  | $ | 197 |  |

[0000950170-22-002669:notes:84]
[same as prior period, unchanged from 0000950170-21-005014:notes:81]

[0000950170-22-002669:notes:85]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Interest income |  | $ | 2 |  |  | $ | 2 |  |  | $ | 5 |  |  | $ | 7 |  |
| Interest expense |  |  | (19 | ) |  |  | (19 | ) |  |  | (55 | ) |  |  | (55 | ) |
| Other income (expense), net |  |  | 2 |  |  |  | 6 |  |  |  | 9 |  |  |  | (2 | ) |
| Total other expense, net |  | $ | (15 | ) |  | $ | (11 | ) |  | $ | (41 | ) |  | $ | (50 | ) |

[0000950170-22-002669:notes:86]
[same as prior period, unchanged from 0000950170-21-005014:notes:83]

[0000950170-22-002669:notes:87]
[same as prior period, unchanged from 0000950170-21-005014:notes:84]

[0000950170-22-002669:notes:88]
|  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 24 |  |  | $ | 11 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 318 |  |  | $ | 309 |  |
| Interest paid |  | $ | 61 |  |  | $ | 51 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-22-002669:notes:89]
[same as prior period, unchanged from 0000950170-21-005014:notes:86]

[0000950170-22-002669:notes:90]
[same as prior period, unchanged from 0000950170-21-005014:notes:87]

[0000950170-22-002669:notes:91]
[same as prior period, unchanged from 0000950170-21-005014:notes:88]

[0000950170-22-002669:notes:92]
[same as prior period, unchanged from 0000950170-21-005014:notes:89]

[0000950170-22-002669:notes:93]
[same as prior period, unchanged from 0000950170-21-005014:notes:90]

[0000950170-22-002669:notes:94]
[same as prior period, unchanged from 0000950170-21-005014:notes:91]

[0000950170-22-002669:notes:95]
[same as prior period, unchanged from 0000950170-21-005014:notes:92]

[0000950170-22-002669:notes:96]
The following is a summary of our investments at their cost or amortized cost for the periods ended January 28, 2022 and April 30, 2021 (in millions):

[0000950170-22-002669:notes:97]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |  |
| Corporate bonds |  | $ | 24 |  |  | $ | 58 |  |  |
| U.S. Treasury and government debt securities |  |  | 7 |  |  |  | 8 |  |  |
| Certificates of deposit |  |  | 59 |  |  |  | 61 |  |  |
| Mutual funds |  |  | 39 |  |  |  | 40 |  |  |
| Total debt and equity securities |  | $ | 129 |  |  | $ | 167 |  |  |

[0000950170-22-002669:notes:98]
[same as prior period, unchanged from 0000950170-21-005014:notes:95]

[0000950170-22-002669:notes:99]
The following table presents the contractual maturities of our debt investments as of January 28, 2022 (in millions):

[0000950170-22-002669:notes:100]
|  |  | Amount |  |
| Due in one year or less |  | $ | 90 |  |
| Due after one year through five years |  |  | — |  |
|  |  | $ | 90 |  |

[0000950170-22-002669:notes:101]
[same as prior period, unchanged from 0000950170-21-005014:notes:98]

[0000950170-22-002669:notes:102]
[same as prior period, unchanged from 0000950170-21-005014:notes:99]

[0000950170-22-002669:notes:103]
[same as prior period, unchanged from 0000950170-21-005014:notes:100]

[0000950170-22-002669:notes:104]
|  |  | January 28, 2022 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 4,111 |  |  | $ | 4,111 |  |  | $ | — |  |
| Corporate bonds |  |  | 24 |  |  |  | — |  |  |  | 24 |  |
| U.S. Treasury and government debt securities |  |  | 7 |  |  |  | 3 |  |  |  | 4 |  |
| Certificates of deposit |  |  | 59 |  |  |  | — |  |  |  | 59 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,201 |  |  | $ | 4,114 |  |  | $ | 87 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 32 |  |  | $ | 32 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (7 | ) |  | $ | — |  |  | $ | (7 | ) |

[0000950170-22-002669:notes:105]
[same as prior period, unchanged from 0000950170-21-005014:notes:102]

[0000950170-22-002669:notes:106]
[same as prior period, unchanged from 0000950170-21-005014:notes:103]

[0000950170-22-002669:notes:107]
[same as prior period, unchanged from 0000950170-21-005014:notes:104]

[0000950170-22-002669:notes:108]
[same as prior period, unchanged from 0000950170-21-005014:notes:105]

[0000950170-22-002669:notes:109]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of January 28, 2022 and April 30, 2021, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0000950170-22-002669:notes:110]
Fair Value of Debt 
As of January 28, 2022 and April 30, 2021, the fair value of our long-term debt was approximately $2,648 million and $2,736 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0000950170-22-002669:notes:111]
7. Financing Arrangements

[0000950170-22-002669:notes:112]
Long-Term Debt

[0000950170-22-002669:notes:113]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0000950170-22-002669:notes:114]
|  |  | Effective Interest Rate |  | January 28, 2022 |  |  | April 30, 2021 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | 250 |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,650 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (15 | ) |  |  | (18 | ) |
| Total senior notes |  |  |  |  | 2,635 |  |  |  | 2,632 |  |
| Less: Current portion of long-term debt |  |  |  |  | (250 | ) |  |  | — |  |
| Total long-term debt |  |  |  | $ | 2,385 |  |  | $ | 2,632 |  |

[0000950170-22-002669:notes:115]
Senior Notes

[0000950170-22-002669:notes:116]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were issued in June 2020. Interest on these Senior Notes is payable semi-annually in June and December.

[0000950170-22-002669:notes:117]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September. Our 3.25% Senior Notes, with a principal amount of $250 million, were issued in December 2012 with interest paid semi-annually in June and December.

[0000950170-22-002669:notes:118]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0000950170-22-002669:notes:119]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 28, 2022, we were in compliance with all covenants associated with the Senior Notes.

[0000950170-22-002669:notes:120]
As of January 28, 2022, our aggregate future principal debt maturities are as follows (in millions):

[0000950170-22-002669:notes:121]
| Fiscal Year |  | Amount |  |
| 2022 (remainder) |  | $ | — |  |
| 2023 |  |  | 250 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |

[0000950170-22-002669:notes:122]
Commercial Paper Program and Credit Facility

[0000950170-22-002669:notes:123]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of January 28, 2022 or April 30, 2021. During the first nine months of fiscal 2021, we received proceeds of $75 million from the issuance, and made repayments of $176 million for the settlement, of commercial paper notes with original maturities greater than three months.

[0000950170-22-002669:notes:124]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 28, 2022, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0000950170-22-002669:notes:125]
[same as prior period, unchanged from 0000950170-21-005014:notes:124]

[0000950170-22-002669:notes:126]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of January 28, 2022, have remaining lease terms not exceeding 20 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of January 28, 2022, have remaining lease terms not exceeding 4 years. As of January 28, 2022, our automobile leases have remaining lease terms not exceeding 4 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0000950170-22-002669:notes:127]
In June 2020, we entered into a build-to-suit lease agreement for an office building located in Wichita, Kansas, with future undiscounted payments of approximately $67 million. Because the Company did not control the underlying asset during the construction period, the Company was not considered the owner of the asset under construction for accounting purposes. The initial term of the lease is twenty years with options to renew the lease during the lease term. The lease commenced during the third quarter of fiscal 2022.

[0000950170-22-002669:notes:128]
In April 2021, we entered into a lease for our new corporate headquarters located in San Jose, California, which is comprised of approximately three hundred thousand square feet of office space and requires future minimum undiscounted payments of

[0000950170-22-002669:notes:129]
approximately $180 million over the initial 11-year lease term. The lease agreement also provides us two successive renewal options, each for five years. The lease commenced during the first quarter of fiscal 2022.

[0000950170-22-002669:notes:130]
[same as prior period, unchanged from 0000950170-21-005014:notes:128]

[0000950170-22-002669:notes:131]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Operating lease cost |  | $ | 15 |  |  | $ | 13 |  |  | $ | 46 |  |  | $ | 41 |  |
| Variable lease cost |  |  | 3 |  |  |  | 3 |  |  |  | 11 |  |  |  | 8 |  |
| Total lease cost |  | $ | 18 |  |  | $ | 16 |  |  | $ | 57 |  |  | $ | 49 |  |

[0000950170-22-002669:notes:132]
[same as prior period, unchanged from 0000950170-21-005014:notes:130]

[0000950170-22-002669:notes:133]
[same as prior period, unchanged from 0000950170-21-005014:notes:131]

[0000950170-22-002669:notes:134]
|  |  |  |  | Nine Months Ended |  |
|  |  |  |  |  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  |  |  |  |  | $ | 41 |  |  | $ | 43 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  |  |  |  |  | $ | 236 |  |  | $ | 19 |  |

[0000950170-22-002669:notes:135]
[same as prior period, unchanged from 0000950170-21-005014:notes:133]

[0000950170-22-002669:notes:136]
|  |  |  |  |  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| Other non-current assets |  |  |  |  |  | $ | 308 |  |  | $ | 114 |  |
| Total operating lease ROU assets |  |  |  |  |  | $ | 308 |  |  | $ | 114 |  |
| Accrued expenses |  |  |  |  |  | $ | 48 |  |  | $ | 49 |  |
| Other long-term liabilities |  |  |  |  |  |  | 269 |  |  |  | 71 |  |
| Total operating lease liabilities |  |  |  |  |  | $ | 317 |  |  | $ | 120 |  |
| Weighted Average Remaining Lease Term |  |  |  |  |  | 9.7 years |  |  | 3.4 years |  |
| Weighted Average Discount Rate |  |  |  |  |  |  | 2.8 | % |  |  | 2.9 | % |

[0000950170-22-002669:notes:137]
Future minimum operating lease payments as of January 28, 2022, are as follows (in millions):

[0000950170-22-002669:notes:138]
| Fiscal Year |  |  |  |  |  | Operating Leases |  |
| 2022 (remainder) |  |  |  |  |  | $ | 15 |  |
| 2023 |  |  |  |  |  |  | 53 |  |
| 2024 |  |  |  |  |  |  | 46 |  |
| 2025 |  |  |  |  |  |  | 37 |  |
| 2026 |  |  |  |  |  |  | 33 |  |
| Thereafter |  |  |  |  |  |  | 182 |  |
| Total lease payments |  |  |  |  |  |  | 366 |  |
| Less: Interest |  |  |  |  |  |  | (49 | ) |
| Total |  |  |  |  |  | $ | 317 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000950170-22-002669:notes:139]
[same as prior period, unchanged from 0000950170-21-005014:notes:137]

[0000950170-22-002669:notes:140]
[same as prior period, unchanged from 0000950170-21-005014:notes:138]

[0000950170-22-002669:notes:141]
As of January 28, 2022, we have certain equity incentive awards outstanding, which include stock options and restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs). Also outstanding are purchase rights under our Employee Stock Purchase Plan (ESPP).

[0000950170-22-002669:notes:142]
[same as prior period, unchanged from 0000950170-21-005014:notes:140]

[0000950170-22-002669:notes:143]
Less than 1 million options were outstanding as of January 28, 2022 and April 30, 2021.

[0000950170-22-002669:notes:144]
[same as prior period, unchanged from 0000950170-21-005014:notes:142]

[0000950170-22-002669:notes:145]
|  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Intrinsic value of exercises |  | $ | 13 |  |  | $ | 4 |  |
| Proceeds received from exercises |  | $ | 1 |  |  | $ | 2 |  |
| Fair value of options vested |  | $ | 4 |  |  | $ | 4 |  |

[0000950170-22-002669:notes:146]
[same as prior period, unchanged from 0000950170-21-005014:notes:144]

[0000950170-22-002669:notes:147]
In the nine months ended January 28, 2022, we granted PBRSUs to certain of our executives. Each PBRSUs has performance-based vesting criteria, in addition to the service-based vesting criteria, such that the PBRSUs cliff-vest at the end of an approximate one, two or three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the first, second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle most of these PBRSUs at the end of the performance and service period will range from 0% to 200% of a target number of shares originally granted. For most of the PBRSUs granted in the nine months ended January 28, 2022, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. The fair values of these TSR performance-based awards were fixed at grant date using a Monte Carlo simulation model. The aggregate grant date fair value of all PBRSUs granted in the current year was $43 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0000950170-22-002669:notes:148]
[same as prior period, unchanged from 0000950170-21-005014:notes:146]

[0000950170-22-002669:notes:149]
|  |  | Number ofShares |  |  | Weighted-AverageGrant Date Fair Value |  |
| Outstanding as of April 30, 2021 |  |  | 9 |  |  | $ | 47.75 |  |
| Granted |  |  | 5 |  |  | $ | 79.41 |  |
| Vested |  |  | (3 | ) |  | $ | 48.50 |  |
| Forfeited |  |  | (1 | ) |  | $ | 57.03 |  |
| Outstanding as of January 28, 2022 |  |  | 10 |  |  | $ | 62.30 |  |

[0000950170-22-002669:notes:150]
[same as prior period, unchanged from 0000950170-21-005014:notes:148]

[0000950170-22-002669:notes:151]
|  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 69 |  |  | $ | 38 |  |

[0000950170-22-002669:notes:152]
[same as prior period, unchanged from 0000950170-21-005014:notes:150]

[0000950170-22-002669:notes:153]
[same as prior period, unchanged from 0000950170-21-005014:notes:151]

[0000950170-22-002669:notes:154]
|  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Shares issued under the ESPP |  |  | 3 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 104 |  |  | $ | 90 |  |

[0000950170-22-002669:notes:155]
[same as prior period, unchanged from 0000950170-21-005014:notes:153]

[0000950170-22-002669:notes:156]
[same as prior period, unchanged from 0000950170-21-005014:notes:154]

[0000950170-22-002669:notes:157]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 3 |  |
| Cost of services revenues |  |  | 4 |  |  |  | 2 |  |  |  | 10 |  |  |  | 7 |  |
| Sales and marketing |  |  | 30 |  |  |  | 21 |  |  |  | 85 |  |  |  | 70 |  |
| Research and development |  |  | 19 |  |  |  | 15 |  |  |  | 53 |  |  |  | 49 |  |
| General and administrative |  |  | 10 |  |  |  | 7 |  |  |  | 28 |  |  |  | 20 |  |
| Total stock-based compensation expense |  | $ | 64 |  |  | $ | 46 |  |  | $ | 179 |  |  | $ | 149 |  |
| Income tax benefit for stock-based compensation expense |  | $ | 6 |  |  | $ | 4 |  |  | $ | 15 |  |  | $ | 12 |  |

[0000950170-22-002669:notes:158]
As of January 28, 2022, total unrecognized compensation expense related to our equity awards was $499 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.3 years.

[0000950170-22-002669:notes:159]
[same as prior period, unchanged from 0000950170-21-005014:notes:157]

[0000950170-22-002669:notes:160]
As of January 28, 2022, our Board of Directors has authorized the repurchase of up to $14.1 billion of our common stock. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time.

[0000950170-22-002669:notes:161]
The following table summarized activity related to the stock repurchase program for the nine months ended January 28, 2022 (in millions, except for per share amounts):

[0000950170-22-002669:notes:162]
| Number of shares repurchased |  |  | 4 |  |
| Average price per share |  | $ | 86.63 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 10 |  |
| Stock repurchases allocated to retained earnings |  | $ | 340 |  |
| Remaining authorization at end of period |  | $ | 502 |  |

[0000950170-22-002669:notes:163]
Since the May 13, 2003 inception of our stock repurchase program through January 28, 2022, we repurchased a total of 344 million shares of our common stock at an average price of $39.58 per share, for an aggregate purchase price of $13.6 billion.

[0000950170-22-002669:notes:164]
[same as prior period, unchanged from 0000950170-21-005014:notes:162]

[0000950170-22-002669:notes:165]
[same as prior period, unchanged from 0000950170-21-005014:notes:163]

[0000950170-22-002669:notes:166]
|  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Dividends per share declared |  | $ | 1.50 |  |  | $ | 1.44 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | — |  |  | $ | 30 |  |
| Dividend payments allocated to retained earnings |  | $ | 335 |  |  | $ | 291 |  |

[0000950170-22-002669:notes:167]
On February 18, 2022, we declared a cash dividend of $0.50 per share of common stock, payable on April 27, 2022 to holders of record as of the close of business on April 8, 2022. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0000950170-22-002669:notes:168]
[same as prior period, unchanged from 0000950170-21-005014:notes:166]

[0000950170-22-002669:notes:169]
[same as prior period, unchanged from 0000950170-21-005014:notes:167]

[0000950170-22-002669:notes:170]
|  |  | ForeignCurrencyTranslationAdjustments |  |  | DefinedBenefitObligationAdjustments |  |  | UnrealizedGains(Losses) on Available-for-SaleSecurities |  |  | UnrealizedGains(Losses) onDerivativeInstruments |  |  | Total |  |
| Balance as of April 30, 2021 |  | $ | (27 | ) |  | $ | (4 | ) |  | $ | 1 |  |  | $ | — |  |  | $ | (30 | ) |
| Other comprehensive income (loss), net of tax |  |  | (11 | ) |  |  | — |  |  |  | (1 | ) |  |  | 6 |  |  |  | (6 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (5 | ) |  |  | (5 | ) |
| Total other comprehensive income (loss) |  |  | (11 | ) |  |  | — |  |  |  | (1 | ) |  |  | 1 |  |  |  | (11 | ) |
| Balance as of January 28, 2022 |  | $ | (38 | ) |  | $ | (4 | ) |  | $ | — |  |  | $ | 1 |  |  | $ | (41 | ) |

[0000950170-22-002669:notes:171]
[same as prior period, unchanged from 0000950170-21-005014:notes:169]

[0000950170-22-002669:notes:172]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | Statements ofIncome Classification |
| Realized (gains) losses on cash flow hedges |  | $ | (4 | ) |  | $ | 3 |  |  | $ | (5 | ) |  | $ | 11 |  |  | Net revenues |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-22-002669:notes:173]
[same as prior period, unchanged from 0000950170-21-005014:notes:171]

[0000950170-22-002669:notes:174]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of January 28, 2022 or April 30, 2021. All contracts have a maturity of less than 12 months.

[0000950170-22-002669:notes:175]
[same as prior period, unchanged from 0000950170-21-005014:notes:173]

[0000950170-22-002669:notes:176]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 134 |  |  | $ | 167 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 556 |  |  | $ | 497 |  |
| Forward contracts purchased |  | $ | 90 |  |  | $ | 117 |  |

[0000950170-22-002669:notes:177]
[same as prior period, unchanged from 0000950170-21-005014:notes:175]

[0000950170-22-002669:notes:178]
[same as prior period, unchanged from 0000950170-21-005014:notes:176]

[0000950170-22-002669:notes:179]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Foreign currency exchange contracts |  | $ | (20 | ) |  | $ | 8 |  |  | $ | (46 | ) |  | $ | 26 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-22-002669:notes:180]
[same as prior period, unchanged from 0000950170-21-005014:notes:178]

[0000950170-22-002669:notes:181]
During the first nine months of fiscal 2022, we executed a restructuring plan to reduce the amount of office space we currently occupy as we allow more employees to continue to work remotely. In connection with the plan, we also reduced our global workforce by approximately 1%. Charges related to the plan consisted primarily of office relocation costs, lease termination fees, and employee severance related costs. Substantially all activities under the plan have been completed.

[0000950170-22-002669:notes:182]
[same as prior period, unchanged from 0000950170-21-005014:notes:180]

[0000950170-22-002669:notes:183]
[same as prior period, unchanged from 0000950170-21-005014:notes:181]

[0000950170-22-002669:notes:184]
|  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Balance at beginning of period |  | $ | 1 |  |  | $ | 1 |  |
| Net charges |  |  | 29 |  |  |  | 42 |  |
| Cash payments |  |  | (30 | ) |  |  | (41 | ) |
| Balance at end of period |  | $ | — |  |  | $ | 2 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-22-002669:notes:185]
[same as prior period, unchanged from 0000950170-21-005014:notes:183]

[0000950170-22-002669:notes:186]
[same as prior period, unchanged from 0000950170-21-005014:notes:184]

[0000950170-22-002669:notes:187]
|  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Effective tax rates |  |  | 17.6 | % |  |  | 24.7 | % |

[0000950170-22-002669:notes:188]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. Our effective tax rate for the nine months ended January 28, 2022 includes the impact of discrete tax benefits for lapses of statute of limitations as well as benefits related to stock-based compensation. The effective tax rate for the nine months ended January 29, 2021 reflects the impact of taxes resulting from the integration of acquired companies and smaller benefits for stock-based compensation as compared to the current year.

[0000950170-22-002669:notes:189]
As of January 28, 2022, we had $217 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $109 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $110 million have been recorded in other long-term liabilities.

[0000950170-22-002669:notes:190]
[same as prior period, unchanged from 0000950170-21-005014:notes:188]

[0000950170-22-002669:notes:191]
[same as prior period, unchanged from 0000950170-21-005014:notes:189]

[0000950170-22-002669:notes:192]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. As a result of uncertainties regarding tax audits and their

[0000950170-22-002669:notes:193]
possible outcomes, an estimate of the range of possible impacts to unrecognized tax benefits in the next twelve months cannot be made at this time.


## us-gaap:EarningsPerShareTextBlock

[0000950170-22-002669:notes:194]
[same as prior period, unchanged from 0000950170-21-005014:notes:191]

[0000950170-22-002669:notes:195]
[same as prior period, unchanged from 0000950170-21-005014:notes:192]

[0000950170-22-002669:notes:196]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 252 |  |  | $ | 182 |  |  | $ | 678 |  |  | $ | 396 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 223 |  |  |  | 223 |  |  |  | 223 |  |  |  | 222 |  |
| Dilutive impact of employee equity award plans |  |  | 6 |  |  |  | 4 |  |  |  | 6 |  |  |  | 3 |  |
| Shares used in diluted computation |  |  | 229 |  |  |  | 227 |  |  |  | 229 |  |  |  | 225 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.13 |  |  | $ | 0.82 |  |  | $ | 3.04 |  |  | $ | 1.78 |  |
| Diluted |  | $ | 1.10 |  |  | $ | 0.80 |  |  | $ | 2.96 |  |  | $ | 1.76 |  |

[0000950170-22-002669:notes:197]
No potential shares from outstanding employee awards were excluded from the diluted net income per share calculation for the three and nine months ended January 28, 2022. No potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for the three months ended January 29, 2021, while five million potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for the nine months ended January 29, 2021, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-22-002669:notes:198]
[same as prior period, unchanged from 0000950170-21-005014:notes:195]

[0000950170-22-002669:notes:199]
[same as prior period, unchanged from 0000950170-21-005014:notes:196]

[0000950170-22-002669:notes:200]
[same as prior period, unchanged from 0000950170-21-005014:notes:197]

[0000950170-22-002669:notes:201]
[same as prior period, unchanged from 0000950170-21-005014:notes:198]

[0000950170-22-002669:notes:202]
[same as prior period, unchanged from 0000950170-21-005014:notes:199]

[0000950170-22-002669:notes:203]
[same as prior period, unchanged from 0000950170-21-005014:notes:200]

[0000950170-22-002669:notes:204]
[same as prior period, unchanged from 0000950170-21-005014:notes:201]

[0000950170-22-002669:notes:205]
|  | Three Months Ended January 28, 2022 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 846 |  |  | $ | — |  |  | $ | 846 |  |
| Support revenues |  | 586 |  |  |  | — |  |  |  | 586 |  |
| Professional and other services revenues |  | 72 |  |  |  | — |  |  |  | 72 |  |
| Public cloud revenues |  | — |  |  |  | 110 |  |  |  | 110 |  |
| Net revenues |  | 1,504 |  |  |  | 110 |  |  |  | 1,614 |  |
| Cost of product revenues |  | 404 |  |  |  | — |  |  |  | 404 |  |
| Cost of support revenues |  | 45 |  |  |  | — |  |  |  | 45 |  |
| Cost of professional and other services revenues |  | 46 |  |  |  | — |  |  |  | 46 |  |
| Cost of public cloud revenues |  | — |  |  |  | 32 |  |  |  | 32 |  |
| Segment cost of revenues |  | 495 |  |  |  | 32 |  |  |  | 527 |  |
| Segment gross profit | $ | 1,009 |  |  | $ | 78 |  |  | $ | 1,087 |  |
| Segment gross margin |  | 67.1 | % |  |  | 70.9 | % |  |  | 67.3 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 14 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,073 |  |
| Total gross margin |  |  |  |  |  |  |  | 66.5 | % |
| 1 Unallocated cost of revenues are composed of $5 million of stock-based compensation expense and $9 million of amortization of intangible assets. |  |

[0000950170-22-002669:notes:206]
|  | Three Months Ended January 29, 2021 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 775 |  |  | $ | — |  |  | $ | 775 |  |
| Support revenues |  | 571 |  |  |  | — |  |  |  | 571 |  |
| Professional and other services revenues |  | 69 |  |  |  | — |  |  |  | 69 |  |
| Public cloud revenues |  | — |  |  |  | 55 |  |  |  | 55 |  |
| Net revenues |  | 1,415 |  |  |  | 55 |  |  |  | 1,470 |  |
| Cost of product revenues |  | 361 |  |  |  | — |  |  |  | 361 |  |
| Cost of support revenues |  | 49 |  |  |  | — |  |  |  | 49 |  |
| Cost of professional and other services revenues |  | 53 |  |  |  | — |  |  |  | 53 |  |
| Cost of public cloud revenues |  | — |  |  |  | 17 |  |  |  | 17 |  |
| Segment cost of revenues |  | 463 |  |  |  | 17 |  |  |  | 480 |  |
| Segment gross profit | $ | 952 |  |  | $ | 38 |  |  | $ | 990 |  |
| Segment gross margin |  | 67.3 | % |  |  | 69.1 | % |  |  | 67.3 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 15 |  |
| Total gross profit |  |  |  |  |  |  | $ | 975 |  |
| Total gross margin |  |  |  |  |  |  |  | 66.3 | % |
| 1 Unallocated cost of revenues are composed of $3 million of stock-based compensation expense and $12 million of amortization of intangible assets. |  |

[0000950170-22-002669:notes:207]
|  | Nine Months Ended January 28, 2022 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 2,390 |  |  | $ | — |  |  | $ | 2,390 |  |
| Support revenues |  | 1,754 |  |  |  | — |  |  |  | 1,754 |  |
| Professional and other services revenues |  | 218 |  |  |  | — |  |  |  | 218 |  |
| Public cloud revenues |  | — |  |  |  | 276 |  |  |  | 276 |  |
| Net revenues |  | 4,362 |  |  |  | 276 |  |  |  | 4,638 |  |
| Cost of product revenues |  | 1,099 |  |  |  | — |  |  |  | 1,099 |  |
| Cost of support revenues |  | 141 |  |  |  | — |  |  |  | 141 |  |
| Cost of professional and other services revenues |  | 151 |  |  |  | — |  |  |  | 151 |  |
| Cost of public cloud revenues |  | — |  |  |  | 80 |  |  |  | 80 |  |
| Segment cost of revenues |  | 1,391 |  |  |  | 80 |  |  |  | 1,471 |  |
| Segment gross profit | $ | 2,971 |  |  | $ | 196 |  |  | $ | 3,167 |  |
| Segment gross margin |  | 68.1 | % |  |  | 71.0 | % |  |  | 68.3 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 36 |  |
| Total gross profit |  |  |  |  |  |  | $ | 3,131 |  |
| Total gross margin |  |  |  |  |  |  |  | 67.5 | % |
| 1 Unallocated cost of revenues are composed of $13 million of stock-based compensation expense and $23 million of amortization of intangible assets. |  |

[0000950170-22-002669:notes:208]
|  | Nine Months Ended January 29, 2021 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 2,151 |  |  | $ | — |  |  | $ | 2,151 |  |
| Support revenues |  | 1,701 |  |  |  | — |  |  |  | 1,701 |  |
| Professional and other services revenues |  | 204 |  |  |  | — |  |  |  | 204 |  |
| Public cloud revenues |  | — |  |  |  | 133 |  |  |  | 133 |  |
| Net revenues |  | 4,056 |  |  |  | 133 |  |  |  | 4,189 |  |
| Cost of product revenues |  | 1,018 |  |  |  | — |  |  |  | 1,018 |  |
| Cost of support revenues |  | 150 |  |  |  | — |  |  |  | 150 |  |
| Cost of professional and other services revenues |  | 151 |  |  |  | — |  |  |  | 151 |  |
| Cost of public cloud revenues |  | — |  |  |  | 46 |  |  |  | 46 |  |
| Segment cost of revenues |  | 1,319 |  |  |  | 46 |  |  |  | 1,365 |  |
| Segment gross profit | $ | 2,737 |  |  | $ | 87 |  |  | $ | 2,824 |  |
| Segment gross margin |  | 67.5 | % |  |  | 65.4 | % |  |  | 67.4 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 44 |  |
| Total gross profit |  |  |  |  |  |  | $ | 2,780 |  |
| Total gross margin |  |  |  |  |  |  |  | 66.4 | % |
| 1 Unallocated cost of revenues are composed of $10 million of stock-based compensation expense and $34 million of amortization of intangible assets. |  |

[0000950170-22-002669:notes:209]
[same as prior period, unchanged from 0000950170-21-005014:notes:206]

[0000950170-22-002669:notes:210]
[same as prior period, unchanged from 0000950170-21-005014:notes:207]

[0000950170-22-002669:notes:211]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| United States, Canada and Latin America (Americas) |  | $ | 902 |  |  | $ | 778 |  |  | $ | 2,556 |  |  | $ | 2,268 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 516 |  |  |  | 474 |  |  |  | 1,431 |  |  |  | 1,279 |  |
| Asia Pacific (APAC) |  |  | 196 |  |  |  | 218 |  |  |  | 651 |  |  |  | 642 |  |
| Net revenues |  | $ | 1,614 |  |  | $ | 1,470 |  |  | $ | 4,638 |  |  | $ | 4,189 |  |

[0000950170-22-002669:notes:212]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $796 million and $693 million during the three months ended January 28, 2022 and January 29, 2021, respectively, and were $2,265 million and $2,035 million during the nine months ended January 28, 2022 and January 29, 2021, respectively.

[0000950170-22-002669:notes:213]
[same as prior period, unchanged from 0000950170-21-005014:notes:210]

[0000950170-22-002669:notes:214]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| U.S. |  | $ | 2,219 |  |  | $ | 2,098 |  |
| International |  |  | 1,982 |  |  |  | 2,498 |  |
| Total |  | $ | 4,201 |  |  | $ | 4,596 |  |

[0000950170-22-002669:notes:215]
[same as prior period, unchanged from 0000950170-21-005014:notes:212]

[0000950170-22-002669:notes:216]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| U.S. |  | $ | 374 |  |  | $ | 340 |  |
| International |  |  | 201 |  |  |  | 185 |  |
| Total |  | $ | 575 |  |  | $ | 525 |  |

[0000950170-22-002669:notes:217]
[same as prior period, unchanged from 0000950170-21-005014:notes:214]

[0000950170-22-002669:notes:218]
[same as prior period, unchanged from 0000950170-21-005014:notes:215]

[0000950170-22-002669:notes:219]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Arrow Electronics, Inc. |  |  | 25 | % |  |  | 24 | % |  |  | 25 | % |  |  | 24 | % |
| Tech Data Corporation |  |  | 21 | % |  |  | 19 | % |  |  | 21 | % |  |  | 20 | % |

[0000950170-22-002669:notes:220]
The following customers accounted for 10% or more of accounts receivable in at least one of the periods presented:

[0000950170-22-002669:notes:221]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| Arrow Electronics, Inc. |  |  | 8 | % |  |  | 10 | % |
| Tech Data Corporation |  |  | 17 | % |  |  | 21 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-22-002669:notes:222]
15. Commitments and Contingencies

[0000950170-22-002669:notes:223]
Purchase Orders and Other Commitments

[0000950170-22-002669:notes:224]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacturing of our products. A significant portion of our reported purchase commitments arising from these agreements consists of firm, non-cancelable, and unconditional commitments. As of January 28, 2022, we had $791 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 28, 2022 and April 30, 2021, such liability amounted to $13 million and $15 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0000950170-22-002669:notes:225]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 28, 2022, we had $354 million in other purchase obligations.

[0000950170-22-002669:notes:226]
Financing Guarantees

[0000950170-22-002669:notes:227]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $48 million and $61 million of receivables during the nine months ended January 28, 2022 and January 29, 2021, respectively.

[0000950170-22-002669:notes:228]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0000950170-22-002669:notes:229]
Some of the leasing agreements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of January 28, 2022 and April 30, 2021, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-22-002669:notes:230]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 28, 2022, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-22-002669:notes:231]
Legal Contingencies

[0000950170-22-002669:notes:232]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0000950170-22-002669:notes:233]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. The defendants' Motion to Dismiss was granted and on February 26, 2021 and the judge entered judgment in favor of NetApp and the other defendants. On March 26, 2021, Plaintiffs filed a notice of appeal. The parties subsequently engaged in settlement discussions, and on July 30, 2021 entered into a Memorandum of Understanding (“MOU”) providing for the settlement of the class action.  Pursuant to the terms of MOU, NetApp has agreed to pay approximately $2.0 million in connection with the settlement, and this amount was accrued during the three months ended July 30, 2021. The parties subsequently executed a stipulation of settlement, which contains no admission of liability, wrongdoing or responsibility by any of the parties, and which provides that the class action will be dismissed with prejudice, with mutual releases by all parties, upon final court approval. On September 24, 2021, plaintiff filed an unopposed motion seeking court approval of the settlement, but no order has issued regarding that motion. The settlement remains subject to court approval.

[0000950170-22-002669:notes:234]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations in U.S. federal courts and before the International Trade Commission (ITC) that were initiated by non-practicing entities. These actions seek monetary damages in U.S. district courts or exclusion and cease-and-desist orders at the ITC. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial, and if a jury or a judge were to find that our products infringe, we could be required to pay significant monetary damages, or it could require us to redesign our products, require us to enter into royalty or licensing agreements, or require us to delay shipping or cease selling certain products, any of which could have a material effect on our operations.

[0000950170-22-002669:notes:235]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of January 28, 2022 related to such matters.


## us-gaap:SubsequentEventsTextBlock

[0000950170-22-002669:notes:236]
16. Subsequent Event

[0000950170-22-002669:notes:237]
On February 18, 2022, we acquired all the outstanding shares of privately-held NeurOps, Inc., which operated under the name Fylamynt, an innovative CloudOps automation technology company that enables customers to build, run, manage and analyze workflows securely in any cloud with little to no code. We are in the process of completing the allocation of approximately $30 million of purchase price among the assets acquired and liabilities assumed.
