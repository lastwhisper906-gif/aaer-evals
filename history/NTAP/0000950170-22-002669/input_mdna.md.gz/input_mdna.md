# NTAP MD&A — 0000950170-22-002669


## mdna

[0000950170-22-002669:mdna:1]
[same as prior period, unchanged from 0000950170-21-005014:mdna:1]

[0000950170-22-002669:mdna:2]
[same as prior period, unchanged from 0000950170-21-005014:mdna:16]

[0000950170-22-002669:mdna:3]
[same as prior period, unchanged from 0000950170-21-005014:mdna:2]

[0000950170-22-002669:mdna:4]
[same as prior period, unchanged from 0000950170-21-005014:mdna:3]

[0000950170-22-002669:mdna:5]
[same as prior period, unchanged from 0000950170-21-005014:mdna:4]

[0000950170-22-002669:mdna:6]
[same as prior period, unchanged from 0000950170-21-005014:mdna:5]

[0000950170-22-002669:mdna:7]
[same as prior period, unchanged from 0000950170-21-005014:mdna:6]

[0000950170-22-002669:mdna:8]
[same as prior period, unchanged from 0000950170-21-005014:mdna:7]

[0000950170-22-002669:mdna:9]
[same as prior period, unchanged from 0000950170-21-005014:mdna:8]

[0000950170-22-002669:mdna:10]
[same as prior period, unchanged from 0000950170-21-005014:mdna:9]

[0000950170-22-002669:mdna:11]
During the first nine months of fiscal 2022, due to the macroeconomic uncertainty caused by COVID-19, we continue to observe certain customers delaying purchases of our products and services, while other customers accelerate or place new orders to address the demands of remote working and digital business. We also experienced certain logistical challenges in delivering our products and services to customers in certain regions, and supply chain constraints. Given uncertainties that exist in the broader technology supply chain, we have begun to invest in inventory and certain longer-term commitments to help mitigate the impact of supply shortages. If supply chain challenges continue it could continue to result in an increase in our cost of revenues.

[0000950170-22-002669:mdna:12]
[same as prior period, unchanged from 0000950170-21-005014:mdna:11]

[0000950170-22-002669:mdna:13]
Russia Sanctions

[0000950170-22-002669:mdna:14]
In February 2022, the U.S. and other countries imposed sanctions on Russia that we expect will impact shipments and ongoing services to customers with operations in Russia and the Ukraine. At this time, we do not anticipate a significant impact to our future results of operations. However, the magnitude and duration of the sanctions remain uncertain. Refer to Part II, Item 1A - Risk Factors for risks we have identified inherent in our international operations.

[0000950170-22-002669:mdna:15]
[same as prior period, unchanged from 0000950170-21-005014:mdna:12]

[0000950170-22-002669:mdna:16]
During the first nine months of fiscal 2022, we repurchased 4 million shares of our common stock at an average price of $86.63 per share, for an aggregate of $350 million. We also declared aggregate cash dividends of $1.50 per share in that period, for which we paid $335 million.

[0000950170-22-002669:mdna:17]
Acquisition

[0000950170-22-002669:mdna:18]
On November 5, 2021, we acquired all the outstanding shares of privately-held CloudCheckr Inc. for $347 million in cash. CloudCheckr is a leading cloud optimization platform that provides cloud visibility and insights to lower costs, maintain security and compliance, and optimize cloud resources.

[0000950170-22-002669:mdna:19]
[same as prior period, unchanged from 0000950170-21-005014:mdna:29]

[0000950170-22-002669:mdna:20]
[same as prior period, unchanged from 0000950170-21-005014:mdna:17]

[0000950170-22-002669:mdna:21]
[same as prior period, unchanged from 0000950170-21-005014:mdna:18]

[0000950170-22-002669:mdna:22]
[same as prior period, unchanged from 0000950170-21-005014:mdna:19]

[0000950170-22-002669:mdna:23]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | January 28, 2022 |  |  | January 29, 2021 |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 52 | % |  |  | 53 | % |  |  | 52 | % |  |  | 51 | % |  |
| Services |  |  | 48 |  |  |  | 47 |  |  |  | 48 |  |  |  | 49 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 25 |  |  |  | 25 |  |  |  | 24 |  |  |  | 25 |  |  |
| Cost of services |  |  | 8 |  |  |  | 9 |  |  |  | 9 |  |  |  | 9 |  |  |
| Gross profit |  |  | 66 |  |  |  | 66 |  |  |  | 68 |  |  |  | 66 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 29 |  |  |  | 30 |  |  |  | 30 |  |  |  | 31 |  |  |
| Research and development |  |  | 14 |  |  |  | 15 |  |  |  | 14 |  |  |  | 16 |  |  |
| General and administrative |  |  | 4 |  |  |  | 4 |  |  |  | 4 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Total operating expenses |  |  | 47 |  |  |  | 49 |  |  |  | 49 |  |  |  | 53 |  |  |
| Income from operations |  |  | 20 |  |  |  | 18 |  |  |  | 19 |  |  |  | 14 |  |  |
| Other expense, net |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |  |
| Income before income taxes |  |  | 19 |  |  |  | 17 |  |  |  | 18 |  |  |  | 13 |  |  |
| Provision for income taxes |  |  | 3 |  |  |  | 4 |  |  |  | 3 |  |  |  | 3 |  |  |
| Net income |  |  | 16 | % |  |  | 12 | % |  |  | 15 | % |  |  | 9 | % |  |

[0000950170-22-002669:mdna:24]
[same as prior period, unchanged from 0000950170-21-005014:mdna:21]

[0000950170-22-002669:mdna:25]
[same as prior period, unchanged from 0000950170-21-005014:mdna:22]

[0000950170-22-002669:mdna:26]
[same as prior period, unchanged from 0000950170-21-005014:mdna:23]

[0000950170-22-002669:mdna:27]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |
| Net revenues |  | $ | 1,614 |  |  | $ | 1,470 |  |  |  | 10 | % |  | $ | 4,638 |  |  | $ | 4,189 |  |  |  | 11 | % |

[0000950170-22-002669:mdna:28]
The increase in net revenues for the third quarter and first nine months of fiscal 2022 compared to the corresponding periods of fiscal 2021 was due to an increase in both product revenues and services revenues. Product revenues as a percentage of net revenues remained relatively flat in the third quarter and first nine months of fiscal 2022, respectively, compared to the corresponding periods of fiscal 2021.

[0000950170-22-002669:mdna:29]
[same as prior period, unchanged from 0000950170-21-005014:mdna:26]

[0000950170-22-002669:mdna:30]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |
| Product revenues |  | $ | 846 |  |  | $ | 775 |  |  |  | 9 | % |  | $ | 2,390 |  |  | $ | 2,151 |  |  |  | 11 | % |
| Hardware (Non-GAAP) |  |  | 338 |  |  |  | 347 |  |  |  | (3 | )% |  |  | 993 |  |  |  | 995 |  |  |  | — | % |
| Software (Non-GAAP) |  |  | 508 |  |  |  | 428 |  |  |  | 19 | % |  |  | 1,397 |  |  |  | 1,156 |  |  |  | 21 | % |

[0000950170-22-002669:mdna:31]
[same as prior period, unchanged from 0000950170-21-005014:mdna:28]

[0000950170-22-002669:mdna:32]
[same as prior period, unchanged from 0000950170-21-005014:mdna:45]

[0000950170-22-002669:mdna:33]
[same as prior period, unchanged from 0000950170-21-005014:mdna:30]

[0000950170-22-002669:mdna:34]
[same as prior period, unchanged from 0000950170-21-005014:mdna:31]

[0000950170-22-002669:mdna:35]
Total product revenues increased in the third quarter and first nine months of fiscal 2022 compared to the corresponding periods of the prior year, primarily driven by an increase in sales of all-flash array systems.

[0000950170-22-002669:mdna:36]
Revenues from the hardware component of product revenues represented 40% and 42% of product revenues in the third quarter and first nine months of fiscal 2022, compared to 45% and 46% of product revenues in the corresponding periods of the prior year. The software component of product revenues represented 60% and 58% of product revenues in the third quarter and first nine months of fiscal 2022, compared to 55% and 54% of product revenues in the corresponding periods of the prior year. The increase in the software component percentage of product revenues in the third quarter and first nine months of fiscal 2022 is primarily due to the mix of systems sold, including a higher mix of all-flash array systems, which contain a higher proportion of software components than other Hybrid Cloud products.

[0000950170-22-002669:mdna:37]
[same as prior period, unchanged from 0000950170-21-005014:mdna:34]

[0000950170-22-002669:mdna:38]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |
| Services revenues |  | $ | 768 |  |  | $ | 695 |  |  |  | 11 | % |  | $ | 2,248 |  |  | $ | 2,038 |  |  |  | 10 | % |
| Support |  |  | 586 |  |  |  | 571 |  |  |  | 3 | % |  |  | 1,754 |  |  |  | 1,701 |  |  |  | 3 | % |
| Professional and other services |  |  | 72 |  |  |  | 69 |  |  |  | 4 | % |  |  | 218 |  |  |  | 204 |  |  |  | 7 | % |
| Public cloud |  |  | 110 |  |  |  | 55 |  |  |  | 100 | % |  |  | 276 |  |  |  | 133 |  |  |  | 108 | % |

[0000950170-22-002669:mdna:39]
[same as prior period, unchanged from 0000950170-21-005014:mdna:36]

[0000950170-22-002669:mdna:40]
[same as prior period, unchanged from 0000950170-21-005014:mdna:37]

[0000950170-22-002669:mdna:41]
Support revenues increased in the third quarter and first nine months of fiscal 2022 compared to the corresponding periods of the prior year, despite an extra week in the first quarter of fiscal 2021 that contributed approximately $40 million of revenues in that period. The increases are primarily due to an increase in our installed base and a higher mix of all-flash systems (which carry a higher support dollar content than our other products) in the current year.

[0000950170-22-002669:mdna:42]
Professional and other services revenues increased in the third quarter and first nine months of fiscal 2022 compared to the corresponding periods of the prior year primarily due to an increase in demand from increased product sales.

[0000950170-22-002669:mdna:43]
[same as prior period, unchanged from 0000950170-21-005014:mdna:40]

[0000950170-22-002669:mdna:44]
[same as prior period, unchanged from 0000950170-21-005014:mdna:41]

[0000950170-22-002669:mdna:45]
Public Cloud revenues increased in the third quarter and first nine months of fiscal 2022 compared to the corresponding periods of the prior year primarily due to strong customer demand for NetApp’s diversified cloud offerings, coupled with overall growth in the cloud market, and the acquisition of CloudCheckr, Inc. early in the third quarter of fiscal 2022. The first nine months of fiscal 2022 also benefitted from the acquisition of Spot, Inc. late in the first quarter of fiscal 2021.

[0000950170-22-002669:mdna:46]
[same as prior period, unchanged from 0000950170-21-005014:mdna:43]

[0000950170-22-002669:mdna:47]
[same as prior period, unchanged from 0000950170-21-005014:mdna:44]

[0000950170-22-002669:mdna:48]
[same as prior period, unchanged from 0000950170-21-005014:mdna:61]

[0000950170-22-002669:mdna:49]
[same as prior period, unchanged from 0000950170-21-005014:mdna:46]

[0000950170-22-002669:mdna:50]
[same as prior period, unchanged from 0000950170-21-005014:mdna:47]

[0000950170-22-002669:mdna:51]
[same as prior period, unchanged from 0000950170-21-005014:mdna:48]

[0000950170-22-002669:mdna:52]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |
| Cost of product revenues |  | $ | 407 |  |  | $ | 369 |  |  |  | 10 | % |  | $ | 1,108 |  |  | $ | 1,045 |  |  |  | 6 | % |
| Hybrid Cloud |  |  | 404 |  |  |  | 361 |  |  |  | 12 | % |  |  | 1,099 |  |  |  | 1,018 |  |  |  | 8 | % |
| Unallocated |  |  | 3 |  |  |  | 8 |  |  |  | (63 | )% |  |  | 9 |  |  |  | 27 |  |  |  | (67 | )% |

[0000950170-22-002669:mdna:53]
[same as prior period, unchanged from 0000950170-21-005014:mdna:50]

[0000950170-22-002669:mdna:54]
Cost of Hybrid Cloud product revenues represented 48% and 46% of product revenues for the third quarter and first nine months of fiscal 2022, respectively, compared to 47% each in the corresponding periods of fiscal 2021. Materials costs represented 94% and 92% of cost of Hybrid Cloud product revenues for the third quarter and first nine months of fiscal 2022, respectively, compared to 89% for each of the corresponding periods of fiscal 2021.

[0000950170-22-002669:mdna:55]
Materials costs increased by approximately $54 million and $93 million in the third quarter and first nine months of fiscal 2022, respectively, compared to the corresponding periods of the prior year, reflecting the increases in product revenues in the current year periods, the mix of systems sold in the respective periods, and higher component and freight costs as a result of COVID-related supply chain challenges.

[0000950170-22-002669:mdna:56]
Hybrid Cloud product gross margins decreased by approximately one percentage point in the third quarter of fiscal 2022 compared to the corresponding period of the prior year, primarily due to the increase in component and freight costs, partially offset by the mix of systems sold, including a higher mix of all-flash array systems which have higher margins than hybrid systems. Hybrid Cloud product gross margins increased by approximately one percentage point in the first nine months of fiscal 2022 compared to the corresponding period of the prior year due to the mix of systems sold, including a higher mix of all-flash array systems which have higher margins than hybrid systems, partially offset by the increase in component and freight costs. We anticipate the increase in component and freight costs related to supply chain challenges will continue to impact gross margins in the fourth quarter of fiscal year 2022 and into fiscal year 2023.

[0000950170-22-002669:mdna:57]
[same as prior period, unchanged from 0000950170-21-005014:mdna:54]

[0000950170-22-002669:mdna:58]
Unallocated cost of product revenues decreased in the third quarter and first nine months of fiscal 2022 compared to the corresponding periods of the prior year due to certain intangible assets becoming fully amortized in the second half of fiscal 2021.

[0000950170-22-002669:mdna:59]
[same as prior period, unchanged from 0000950170-21-005014:mdna:56]

[0000950170-22-002669:mdna:60]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |
| Cost of services revenues |  | $ | 134 |  |  | $ | 126 |  |  |  | 6 | % |  | $ | 399 |  |  | $ | 364 |  |  |  | 10 | % |
| Support |  |  | 45 |  |  |  | 49 |  |  |  | (8 | )% |  |  | 141 |  |  |  | 150 |  |  |  | (6 | )% |
| Professional and other services |  |  | 46 |  |  |  | 53 |  |  |  | (13 | )% |  |  | 151 |  |  |  | 151 |  |  |  | — | % |
| Public cloud |  |  | 32 |  |  |  | 17 |  |  |  | 88 | % |  |  | 80 |  |  |  | 46 |  |  |  | 74 | % |
| Unallocated |  |  | 11 |  |  |  | 7 |  |  |  | 57 | % |  |  | 27 |  |  |  | 17 |  |  |  | 59 | % |

[0000950170-22-002669:mdna:61]
[same as prior period, unchanged from 0000950170-21-005014:mdna:58]

[0000950170-22-002669:mdna:62]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, decreased in the third quarter and first nine months of fiscal 2022 compared to the corresponding periods of fiscal 2021. Cost of Hybrid Cloud services revenues represented 14% and 15% of Hybrid Cloud services revenues in the third quarter and first nine months of fiscal 2022, respectively, and 16% of Hybrid Cloud services revenues in the corresponding periods of the prior year.

[0000950170-22-002669:mdna:63]
Hybrid Cloud support gross margins increased by one percentage point each in the third quarter and first nine months of fiscal 2022 compared to the corresponding periods of the prior year due to growth in support revenues achieved with a consistent cost base. Hybrid Cloud professional services gross margins increased by thirteen percentage points and five percentage points in the third quarter and first nine months of fiscal 2022, respectively, compared to the corresponding periods of the prior year. The increases are primarily due to the mix of services provided.

[0000950170-22-002669:mdna:64]
[same as prior period, unchanged from 0000950170-21-005014:mdna:62]

[0000950170-22-002669:mdna:65]
Cost of Public Cloud revenues increased in the third quarter and first nine months of fiscal 2022 compared to the corresponding periods of fiscal 2021 reflecting the increase in Public Cloud revenues. Public Cloud gross margins increased by two percentage points and six percentage points in the third quarter and first nine months of fiscal 2022, respectively, compared to the corresponding periods of fiscal 2021, reflecting efficiencies from scaling our Public Cloud segment.

[0000950170-22-002669:mdna:66]
[same as prior period, unchanged from 0000950170-21-005014:mdna:64]

[0000950170-22-002669:mdna:67]
Unallocated cost of services revenues increased in the third quarter and first nine months of fiscal 2022 compared to the corresponding periods of the prior year due to our acquisitions of CloudCheckr, Inc. in the third quarter of fiscal 2022 and Spot, Inc. in the first quarter of fiscal 2021, which resulted in higher amortization expense for certain intangible assets.

[0000950170-22-002669:mdna:68]
[same as prior period, unchanged from 0000950170-21-005014:mdna:66]

[0000950170-22-002669:mdna:69]
[same as prior period, unchanged from 0000950170-21-005014:mdna:67]

[0000950170-22-002669:mdna:70]
Sales and marketing, research and development, and general and administrative expenses for the third quarter and first nine months of fiscal 2022 totaled $746 million, or 46% of net revenues, and $2,230 million, or 48% of net revenues, respectively, each reflecting a decrease of three percentage points, compared to the corresponding periods of fiscal 2021 primarily as a result of scaling our cost structure as revenues grow.

[0000950170-22-002669:mdna:71]
[same as prior period, unchanged from 0000950170-21-005014:mdna:69]

[0000950170-22-002669:mdna:72]
Total compensation costs included in operating expenses increased by $14 million, or 3%, in the third quarter of fiscal 2022 compared to the corresponding period of the prior year, primarily due to higher salaries, benefits and stock-based compensation expenses, reflecting a 5% increase in average headcount in the third quarter of fiscal 2022. This increase was partially offset by lower incentive compensation expense.

[0000950170-22-002669:mdna:73]
Total compensation costs included in operating expenses increased by $32 million, or 2%, in the first nine months of fiscal 2022 compared to the corresponding period of the prior year, primarily due to higher salaries, benefits and stock-based compensation expenses, reflecting a 2% increase in average headcount in the first nine months of fiscal 2022. This increase was partially offset by lower incentive compensation expense. Total compensation costs for the first nine months of fiscal 2021 includes the impact of an additional week in the first quarter of fiscal 2021.

[0000950170-22-002669:mdna:74]
[same as prior period, unchanged from 0000950170-21-005014:mdna:72]

[0000950170-22-002669:mdna:75]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 461 |  |  | $ | 436 |  |  |  | 6 | % |  | $ | 1,377 |  |  | $ | 1,297 |  |  |  | 6 | % |

[0000950170-22-002669:mdna:76]
[same as prior period, unchanged from 0000950170-21-005014:mdna:74]

[0000950170-22-002669:mdna:77]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2022 to Fiscal 2021 |  |  | Fiscal 2022 to Fiscal 2021 |  |
| Compensation costs |  |  | 3 |  |  |  | 3 |  |
| Commissions |  |  | 2 |  |  |  | 2 |  |
| Advertising and marketing promotional expense |  |  | — |  |  |  | 1 |  |
| Other |  |  | 1 |  |  |  | — |  |
| Total change |  |  | 6 |  |  |  | 6 |  |

[0000950170-22-002669:mdna:78]
The increase in compensation costs for the third quarter and first nine months of fiscal 2022 compared to the corresponding periods of the prior year reflected an increase in average headcount of approximately 6% and 5%, respectively. The expansion of our sales and marketing teams are expected to support our ability to execute on key market opportunities.

[0000950170-22-002669:mdna:79]
The increase in commissions expense for the third quarter and first nine months of fiscal 2022 compared to the corresponding periods of the prior year primarily reflected the increase in the average headcount of our sales team.

[0000950170-22-002669:mdna:80]
Advertising and marketing promotional expense increased in the first nine months of fiscal 2022 compared to the corresponding period of the prior year, primarily due to higher spending levels on certain projects executed during the first quarter of fiscal 2022.

[0000950170-22-002669:mdna:81]
[same as prior period, unchanged from 0000950170-21-005014:mdna:79]

[0000950170-22-002669:mdna:82]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |
| Research and development expenses |  | $ | 220 |  |  | $ | 215 |  |  |  | 2 | % |  | $ | 646 |  |  | $ | 660 |  |  |  | (2 | )% |

[0000950170-22-002669:mdna:83]
[same as prior period, unchanged from 0000950170-21-005014:mdna:81]

[0000950170-22-002669:mdna:84]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2022 to Fiscal 2021 |  |  | Fiscal 2022 to Fiscal 2021 |  |
| Compensation costs |  |  | — |  |  |  | (3 | ) |
| Development projects and outside services |  |  | 3 |  |  |  | 1 |  |
| Other |  |  | (1 | ) |  |  | — |  |
| Total change |  |  | 2 |  |  |  | (2 | ) |

[0000950170-22-002669:mdna:85]
The decrease in compensation costs for the first nine months of fiscal 2022 compared to the corresponding period in the prior year was attributable to a decrease in average headcount of 3%, primarily resulting from the restructuring plans we implemented in fiscal 2020 which were completed during the first half of fiscal 2021. The increases in development projects and outside services for the third quarter and first nine months of fiscal 2022 compared to the corresponding periods in the prior year were primarily due to the higher spending on certain engineering projects.

[0000950170-22-002669:mdna:86]
[same as prior period, unchanged from 0000950170-21-005014:mdna:84]

[0000950170-22-002669:mdna:87]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |
| General and administrative expenses |  | $ | 65 |  |  | $ | 63 |  |  |  | 3 | % |  | $ | 207 |  |  | $ | 191 |  |  |  | 8 | % |

[0000950170-22-002669:mdna:88]
[same as prior period, unchanged from 0000950170-21-005014:mdna:86]

[0000950170-22-002669:mdna:89]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2022 to Fiscal 2021 |  |  | Fiscal 2022 to Fiscal 2021 |  |
| Compensation costs |  |  | 2 |  |  |  | 4 |  |
| Professional and legal fees and outside services |  |  | 3 |  |  |  | 6 |  |
| Litigation settlement |  |  | — |  |  |  | (3 | ) |
| Facilities and IT support costs |  |  | (2 | ) |  |  | (1 | ) |
| Other |  |  | — |  |  |  | 2 |  |
| Total change |  |  | 3 |  |  |  | 8 |  |

[0000950170-22-002669:mdna:90]
The increases in compensation costs in the third quarter and first nine months of fiscal 2022 compared to the corresponding periods of the prior year were primarily attributable to higher stock-based compensation expense, partially offset by lower incentive compensation expense. The increases in professional and legal fees and outside services expense in the third quarter and first nine months of fiscal 2022 were primarily due to higher spending on business transformation projects and an increase in legal fees. During the first nine months of fiscal 2021, we incurred a litigation settlement charge of approximately $5 million. The decreases in facilities and IT support costs were primarily due to lower spending levels on IT projects.

[0000950170-22-002669:mdna:91]
[same as prior period, unchanged from 0000950170-21-005014:mdna:89]

[0000950170-22-002669:mdna:92]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |
| Restructuring charges |  | $ | — |  |  | $ | — |  |  | NM |  | $ | 29 |  |  | $ | 42 |  |  | NM |

[0000950170-22-002669:mdna:93]
[same as prior period, unchanged from 0000950170-21-005014:mdna:91]

[0000950170-22-002669:mdna:94]
In the first nine months of fiscal 2022, we recognized $29 million in restructuring costs, consisting primarily of lease termination fees, office relocation costs, and employee severance-related costs.

[0000950170-22-002669:mdna:95]
[same as prior period, unchanged from 0000950170-21-005014:mdna:93]

[0000950170-22-002669:mdna:96]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |
| Acquisition-related expense |  | $ | 6 |  |  | $ | 3 |  |  | NM |  | $ | 8 |  |  | $ | 14 |  |  | NM |

[0000950170-22-002669:mdna:97]
[same as prior period, unchanged from 0000950170-21-005014:mdna:95]

[0000950170-22-002669:mdna:98]
Acquisition-related expenses, primarily legal and consulting fees, totaled $6 million and $8 million in the third quarter and first nine months of fiscal 2022, respectively, and were mostly due to our acquisition of CloudCheckr, Inc. in the third quarter of fiscal 2022.

[0000950170-22-002669:mdna:99]
[same as prior period, unchanged from 0000950170-21-005014:mdna:97]

[0000950170-22-002669:mdna:100]
[same as prior period, unchanged from 0000950170-21-005014:mdna:98]

[0000950170-22-002669:mdna:101]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |
| Interest income |  | $ | 2 |  |  | $ | 2 |  |  |  | — | % |  | $ | 5 |  |  | $ | 7 |  |  |  | (29 | )% |
| Interest expense |  |  | (19 | ) |  |  | (19 | ) |  |  | — | % |  |  | (55 | ) |  |  | (55 | ) |  |  | — | % |
| Other income (expense), net |  |  | 2 |  |  |  | 6 |  |  |  | (67 | )% |  |  | 9 |  |  |  | (2 | ) |  |  | (550 | )% |
| Total |  | $ | (15 | ) |  | $ | (11 | ) |  |  | 36 | % |  | $ | (41 | ) |  | $ | (50 | ) |  |  | (18 | )% |

[0000950170-22-002669:mdna:102]
Interest income remained flat in the third quarter of fiscal 2022 compared to the corresponding period of the prior year, while it decreased in the first nine months of fiscal 2022 compared to the corresponding period of the prior year due to both a reduction in the size of our investment portfolio and lower yields earned on the investments. Interest expense remained flat in the third quarter and first nine months of fiscal 2022 compared to the corresponding periods of fiscal 2021.

[0000950170-22-002669:mdna:103]
The differences in other income (expense), net for the third quarter and first nine months of fiscal 2022 as compared to the corresponding periods of the prior year are partially due to foreign exchange gains and losses year-over-year. In the first nine months of fiscal 2021, other income (expense), net includes a $6 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $8 million. This benefit was more than offset by a $14 million loss recognized from the extinguishment of our Senior Notes due June 2021 in the first quarter of fiscal 2021.

[0000950170-22-002669:mdna:104]
[same as prior period, unchanged from 0000950170-21-005014:mdna:102]

[0000950170-22-002669:mdna:105]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |  | January 28, 2022 |  |  | January 29, 2021 |  |  | % Change |  |
| Provision for income taxes |  | $ | 54 |  |  | $ | 65 |  |  |  | (17 | )% |  | $ | 145 |  |  | $ | 130 |  |  |  | 12 | % |

[0000950170-22-002669:mdna:106]
36

[0000950170-22-002669:mdna:107]
Our effective tax rate for the third quarter of fiscal 2022 was 17.6% compared to 26.3% for the third quarter of fiscal 2021. Our effective tax rate for the first nine months of fiscal 2022 was 17.6% compared to 24.7% for the first nine months of fiscal 2021. Our effective tax rates reflect the impact of a significant amount of our earnings being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rate for the third quarter and first nine months of fiscal 2022 decreased compared to the corresponding periods of the prior year due to discrete tax benefits for lapses of statute of limitations as well as increased benefits related to stock-based compensation. Additionally, the corresponding periods of the prior year included tax charges for the integration of acquired companies.

[0000950170-22-002669:mdna:108]
As of January 28, 2022, we had $217 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $109 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $110 million have been recorded in other long-term liabilities.

[0000950170-22-002669:mdna:109]
[same as prior period, unchanged from 0000950170-21-005014:mdna:106]

[0000950170-22-002669:mdna:110]
[same as prior period, unchanged from 0000950170-21-005014:mdna:107]

[0000950170-22-002669:mdna:111]
| (In millions, except percentages) |  | January 28, 2022 |  |  | April 30, 2021 |  |
| Cash, cash equivalents and short-term investments |  | $ | 4,201 |  |  | $ | 4,596 |  |
| Principal amount of debt |  | $ | 2,650 |  |  | $ | 2,650 |  |

[0000950170-22-002669:mdna:112]
[same as prior period, unchanged from 0000950170-21-005014:mdna:109]

[0000950170-22-002669:mdna:113]
|  |  | Nine Months Ended |  |
| (In millions) |  | January 28, 2022 |  |  | January 29, 2021 |  |
| Net cash provided by operating activities |  | $ | 800 |  |  | $ | 774 |  |
| Net cash used in investing activities |  |  | (481 | ) |  |  | (320 | ) |
| Net cash (used in) provided by financing activities |  |  | (651 | ) |  |  | 624 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (26 | ) |  |  | 70 |  |
| Net change in cash, cash equivalents and restricted cash |  | $ | (358 | ) |  | $ | 1,148 |  |

[0000950170-22-002669:mdna:114]
[same as prior period, unchanged from 0000950170-21-005014:mdna:111]

[0000950170-22-002669:mdna:115]
As of January 28, 2022, our cash, cash equivalents and short-term investments were $4.2 billion, which represents a decrease of $395 million for the first nine months of fiscal 2022. During the first nine months of fiscal 2022, we generated $800 million of cash from operating activities, offset by $335 million used for the payment of dividends, $350 million used to repurchase shares of our common stock, $158 million in purchases of property and equipment, and $359 million, net of cash acquired, used for the acquisition of a two privately-held companies. Net working capital was $2.0 billion as of January 28, 2022, a reduction of $588 million when compared to April 30, 2021. The reduction in net working capital is partially due to the reclassification of $250 million principal amount of our senior notes from long-term to current liabilities.

[0000950170-22-002669:mdna:116]
[same as prior period, unchanged from 0000950170-21-005014:mdna:113]

[0000950170-22-002669:mdna:117]
During the first nine months of fiscal 2022, we generated cash from operating activities of $800 million, reflecting net income of $678 million, adjusted by non-cash depreciation and amortization of $143 million and non-cash stock-based compensation expense of $179 million, compared to $774 million of cash generated from operating activities during the first nine months of fiscal 2021.

[0000950170-22-002669:mdna:118]
Significant changes in assets and liabilities in the first nine months of fiscal 2022 included the following:

[0000950170-22-002669:mdna:119]
•
Accounts receivable decreased $137 million, reflecting more favorable shipping linearity in the third quarter of fiscal 2022 compared to the fourth quarter of fiscal 2021.

[0000950170-22-002669:mdna:120]
•
Accrued expenses decreased by $207 million, primarily due to employee compensation payouts related to fiscal year 2021  incentive compensation and commissions plans.

[0000950170-22-002669:mdna:121]
We expect that cash provided by operating activities may materially fluctuate in future periods due to various factors, including fluctuations in our operating results, shipping linearity, accounts receivable collections performance, inventory and supply chain management, vendor payment initiatives, tax benefits or charges from stock-based compensation, and the timing and amount of compensation and other payments.

[0000950170-22-002669:mdna:122]
[same as prior period, unchanged from 0000950170-21-005014:mdna:121]

[0000950170-22-002669:mdna:123]
During the first nine months of fiscal 2022, we generated $36 million from maturities of investments, net of purchases, and paid $158 million for capital expenditures, while during the same period of fiscal 2021, we generated $140 million from maturities and sales of investments, net of purchases, and paid $124 million for capital expenditures. Additionally, during the first nine months of fiscal 2022, we paid $359 million, net of cash acquired for two privately-held companies, as compared to $350 million, net of cash acquired that we paid for two privately-held companies in the first nine months of fiscal 2021.

[0000950170-22-002669:mdna:124]
[same as prior period, unchanged from 0000950170-21-005014:mdna:123]

[0000950170-22-002669:mdna:125]
During the first nine months of fiscal 2022, cash flows used in financing activities totaled $651 million and include $350 million for the repurchase of approximately four million shares of common stock and $335 million for the payment of dividends. During the first nine months of fiscal 2021, cash flows provided by financing activities totaled $624 million, and were primarily due to net cash proceeds of $2.0 billion from the issuance of Senior Notes, partially offset by the use of $513 million for the extinguishment of Senior Notes due June 2021, $420 million for the net repayment of commercial paper notes with original maturities of three months or less, $321 million for the payment of dividends, $176 million for the repayment of commercial paper notes with original maturities of greater than three months, and $50 million for the repurchase of one million shares of common stock.

[0000950170-22-002669:mdna:126]
[same as prior period, unchanged from 0000950170-21-005014:mdna:125]

[0000950170-22-002669:mdna:127]
[same as prior period, unchanged from 0000950170-21-005014:mdna:126]

[0000950170-22-002669:mdna:128]
Our principal sources of liquidity as of January 28, 2022 consisted of cash and cash equivalents, short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-22-002669:mdna:129]
[same as prior period, unchanged from 0000950170-21-005014:mdna:128]

[0000950170-22-002669:mdna:130]
|  |  | January 28, 2022 |  |  | April 30, 2021 |  |
| Cash and cash equivalents |  | $ | 4,170 |  |  | $ | 4,529 |  |
| Short-term investments |  |  | 31 |  |  |  | 67 |  |
| Total |  | $ | 4,201 |  |  | $ | 4,596 |  |

[0000950170-22-002669:mdna:131]
As of January 28, 2022 and April 30, 2021, $2.0 billion and $2.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $2.2 billion and $2.1 billion, respectively, were available in the U.S.

[0000950170-22-002669:mdna:132]
[same as prior period, unchanged from 0000950170-21-005014:mdna:131]

[0000950170-22-002669:mdna:133]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of January 28, 2022.

[0000950170-22-002669:mdna:134]
[same as prior period, unchanged from 0000950170-21-005014:mdna:133]

[0000950170-22-002669:mdna:135]
[same as prior period, unchanged from 0000950170-21-005014:mdna:135]

[0000950170-22-002669:mdna:136]
The following table summarizes the principal amount of our Senior Notes as of January 28, 2022 (in millions):

[0000950170-22-002669:mdna:137]
| 3.25% Senior Notes Due December 2022 |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,650 |  |

[0000950170-22-002669:mdna:138]
[same as prior period, unchanged from 0000950170-21-005014:mdna:138]

[0000950170-22-002669:mdna:139]
Commercial Paper Program and Credit Facility

[0000950170-22-002669:mdna:140]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of January 28, 2022.

[0000950170-22-002669:mdna:141]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 28, 2022, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-22-002669:mdna:142]
[same as prior period, unchanged from 0000950170-21-005014:mdna:142]

[0000950170-22-002669:mdna:143]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2022 to be between $50 million and $100 million.

[0000950170-22-002669:mdna:144]
[same as prior period, unchanged from 0000950170-21-005014:mdna:144]

[0000950170-22-002669:mdna:145]
On February 18, 2022 we declared a cash dividend of $0.50 per share of common stock, payable on April 27, 2022 to holders of record as of the close of business on April 8, 2022.

[0000950170-22-002669:mdna:146]
As of January 28, 2022, our Board of Directors has authorized the repurchase of up to $14.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through January 28, 2022, we repurchased a total of 344 million shares of our common stock at an average price of $39.58 per share, for an aggregate purchase price of $13.6 billion. As of January 28, 2022, the remaining authorized amount for stock repurchases under this program was $0.5 billion.

[0000950170-22-002669:mdna:147]
[same as prior period, unchanged from 0000950170-21-005014:mdna:147]

[0000950170-22-002669:mdna:148]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled approximately $1.1 billion at January 28, 2022.

[0000950170-22-002669:mdna:149]
[same as prior period, unchanged from 0000950170-21-005014:mdna:150]

[0000950170-22-002669:mdna:150]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $48 million and $61 million of receivables during the first nine months of fiscal 2022 and fiscal 2021, respectively.

[0000950170-22-002669:mdna:151]
[same as prior period, unchanged from 0000950170-21-005014:mdna:152]

[0000950170-22-002669:mdna:152]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of January 28, 2022 and April 30, 2021, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-22-002669:mdna:153]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of January 28, 2022, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-22-002669:mdna:154]
Legal Contingencies

[0000950170-22-002669:mdna:155]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0000950170-22-002669:mdna:156]
[same as prior period, unchanged from 0000950170-21-005014:mdna:157]

[0000950170-22-002669:mdna:157]
[same as prior period, unchanged from 0000950170-21-005014:mdna:158]

[0000950170-22-002669:mdna:158]
[same as prior period, unchanged from 0000950170-21-005014:mdna:159]

[0000950170-22-002669:mdna:159]
41
