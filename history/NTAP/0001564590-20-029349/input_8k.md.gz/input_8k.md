# NTAP 8-K — 0001564590-20-027022 filed 2020-05-27

## item codes, every 8-K on or before 2020-06-15

- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2020-06-15

- none on or before 2020-06-15

## item 2.02 — earnings release, exhibit 99.1

[0001564590-20-027022:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-20-027022:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-20-027022:8k_2_02:3]
Exhibit 99.1

[0001564590-20-027022:8k_2_02:4]
NetApp Reports Fourth Quarter and Fiscal Year 2020 Results

[0001564590-20-027022:8k_2_02:5]
Solid Margins, Cash Flow and Operating Leverage;

[0001564590-20-027022:8k_2_02:6]
Net Revenues of $1.40 Billion for the Fourth Quarter and $5.41 Billion for Fiscal Year 2020

[0001564590-20-027022:8k_2_02:7]
| • | NetApp™ cloud data services annualized recurring revenue of approximately $111 million, an increase of 113% year-over-year |  |

[0001564590-20-027022:8k_2_02:8]
| • | All flash array annualized net revenue run rate of $2.6 billion |  |

[0001564590-20-027022:8k_2_02:9]
| • | Consolidated GAAP gross margin of 66.9% in fiscal year 2020; non-GAAP gross margin of 67.9% |  |

[0001564590-20-027022:8k_2_02:10]
| • | $1.06 billion in cash provided by operations in fiscal year 2020; $936 million in free cash flow |  |

[0001564590-20-027022:8k_2_02:11]
| • | $1.85 billion returned to shareholders in share repurchases and cash dividend in fiscal year 2020 |  |

[0001564590-20-027022:8k_2_02:12]
Sunnyvale, Calif.—May 27, 2020—NetApp (NASDAQ: NTAP) today reported financial results for the fourth quarter and fiscal year 2020, which ended on April 24, 2020.

[0001564590-20-027022:8k_2_02:13]
“During this unprecedented situation, our priority has been supporting our employees, customers, partners, and communities. Despite the challenging environment, we delivered solid gross margin, cash flow and operating leverage in the fourth quarter. Our cloud business grew substantially and our new customer acquisition districts again performed well.” said George Kurian, chief executive officer. “The strength and resiliency of our business model enables us to continue to execute our strategy while navigating a range of potential demand environments. While we cannot predict when the world will return to normal, the enduring importance of data is clear. We are confident that the demand for our products and services will be strong as we emerge from this crisis.”

[0001564590-20-027022:8k_2_02:14]
Fourth Quarter of Fiscal Year 2020 Financial Results

[0001564590-20-027022:8k_2_02:15]
| • | Net Revenues: $1.40 billion, compared to $1.59 billion in the fourth quarter of fiscal year 2019 |  |

[0001564590-20-027022:8k_2_02:16]
| • | Net Income: GAAP net income of $196 million, compared to GAAP net income of $396 million in the fourth quarter of fiscal year 2019; non-GAAP net income1 of $265 million, compared to non-GAAP net income of $305 million in the fourth quarter of fiscal year 2019 |  |

[0001564590-20-027022:8k_2_02:17]
| • | Earnings per Share: GAAP net income per share2 of $0.88 compared to GAAP net income per share of $1.59 in the fourth quarter of fiscal year 2019; non-GAAP net income per share of $1.19, compared to non-GAAP net income per share of $1.22 in the fourth quarter of fiscal year 2019 |  |

[0001564590-20-027022:8k_2_02:18]
| • | Cash, Cash Equivalents and Investments: $2.88 billion at the end of the fourth quarter of fiscal year 2020 |  |

[0001564590-20-027022:8k_2_02:19]
| • | Cash Provided by Operations: $383 million, compared to $399 million in the fourth quarter of fiscal year 2019 |  |

[0001564590-20-027022:8k_2_02:20]
| • | Share Repurchase and Dividend: Returned $266 million to shareholders through share repurchases and cash dividends |  |

[0001564590-20-027022:8k_2_02:21]
Fiscal Year 2020 Financial Results

[0001564590-20-027022:8k_2_02:22]
| • | Net Revenues: $5.41 billion, compared to $6.15 billion in fiscal year 2019 |  |

[0001564590-20-027022:8k_2_02:23]
| • | Net Income: GAAP net income of $819 million, compared to GAAP net income of $1.17 billion in fiscal year 2019; non-GAAP net income of $944 million, compared to non-GAAP net income of $1.17 billion in fiscal year 2019 |  |

[0001564590-20-027022:8k_2_02:24]
| • | Earnings per Share: GAAP net income per share of $3.52, compared to GAAP net income per share of $4.51 in fiscal year 2019; non-GAAP net income per share of $4.05, compared to non-GAAP net income per share of $4.52 in fiscal year 2019 |  |

[0001564590-20-027022:8k_2_02:25]
| • | Cash Provided by Operations: $1.06 billion compared to $1.34 billion in fiscal year 2019 |  |

[0001564590-20-027022:8k_2_02:26]
| • | Share Repurchase and Dividend: Returned $1.85 billion to shareholders through share repurchases and cash dividends |  |

[0001564590-20-027022:8k_2_02:27]
First Quarter of Fiscal Year 2021 Financial Outlook

[0001564590-20-027022:8k_2_02:28]
The Company provided the following financial guidance for the first quarter of fiscal year 2021:

[0001564590-20-027022:8k_2_02:29]
| •Net revenues are expected to be in the range of: | $1.090 billion to $1.240 billion |
|  | GAAP | Non-GAAP |
| •Earnings per share is expected to be in the range of: | $0.18 - $0.26 | $0.36 - $0.44 |

[0001564590-20-027022:8k_2_02:30]
Dividend

[0001564590-20-027022:8k_2_02:31]
Next cash dividend of $0.48 per share to be paid on July 29, 2020, to shareholders of record as of the close of business on July 10, 2020.

[0001564590-20-027022:8k_2_02:32]
Fourth Quarter of Fiscal Year 2020 Business Highlights

[0001564590-20-027022:8k_2_02:33]
Growing Partnerships and Innovations with Customers in Mind

[0001564590-20-027022:8k_2_02:34]
| • | NetApp is architecting application-integrated data management for Kubernetes with Project Astra. The company debuted this vision for an enterprise-class data service for stateful, cloud-native applications with any Kubernetes distribution on any cloud. |

[0001564590-20-027022:8k_2_02:35]
| • | NetApp acquired Talon Storage, enhancing NetApp Cloud Volumes and Azure NetApp Files with NetApp Global File Cache for remote office and branch office workers. |

[0001564590-20-027022:8k_2_02:36]
| • | NetApp announced an integrated solution for End User Computing (EUC) remote connected infrastructures with NetApp HCI, NVIDIA, and VMware. |

[0001564590-20-027022:8k_2_02:37]
| • | NetApp launched a clustered architecture consisting of NetApp AFF storage systems and Fujitsu PRIMERGY servers optimized for artificial intelligence (AI) and enterprise machine learning (ML). |

[0001564590-20-027022:8k_2_02:38]
| • | The new NetApp Active IQ™ web UI and mobile app were launched, helping to support customers in avoiding disruptions from unexpected growth. |

[0001564590-20-027022:8k_2_02:39]
NetApp Award-Winning Infrastructure

[0001564590-20-027022:8k_2_02:40]
| • | NetApp was named Google Cloud Technology Partner of the Year for Infrastructure3 for the second consecutive year. The award noted NetApp’s excellence with its data fabric vision. |

[0001564590-20-027022:8k_2_02:41]
| • | IDC released two reports: One notes NetApp as a leader in scale-out, file-based storage with NetApp ONTAP™ AI,4 and the other recognizes NetApp as an industry leader5 that helps customers implement digital transformation in meaningful ways. |

[0001564590-20-027022:8k_2_02:42]
NetApp Provides Support for COVID-19 Crisis

[0001564590-20-027022:8k_2_02:43]
| • | NetApp helps customers respond to the surge in remote work and the strains being put on IT organizations with NetApp Active IQ, which give insight to where customers might be vulnerable to new security threats and makes sure that data and applications are available and performing optimally. |

[0001564590-20-027022:8k_2_02:44]
| • | NetApp has teamed up with Core Scientific and NVIDIA to give COVID-19 researchers complimentary access to cloud connected storage systems and connect their data sets from anywhere and take advantage of powerful AI and genomic tools. |

[0001564590-20-027022:8k_2_02:45]
| • | NetApp teams across the company engaged together to scale infrastructures to support thousands of healthcare customers prepare for COVID-19 and implement solutions to maximize their systems, on a global scale across hundreds of countries. |

[0001564590-20-027022:8k_2_02:46]
| • | NetApp joined forces with 25 other Bay Area companies to give $22 million in funding to organizations helping on the frontlines of the COVID-19 crisis. |

[0001564590-20-027022:8k_2_02:47]
Board of Directors and Management Additions

[0001564590-20-027022:8k_2_02:48]
| • | NetApp appointed Mike Berry as executive vice president and CFO, reporting to CEO George Kurian. |

[0001564590-20-027022:8k_2_02:49]
| • | NetApp appointed Deepak Ahuja to the board of directors, bringing the number of directors on the NetApp board to eight. |

[0001564590-20-027022:8k_2_02:50]
Webcast and Conference Call Information

[0001564590-20-027022:8k_2_02:51]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the

[0001564590-20-027022:8k_2_02:52]
Investor Relations website. An audio replay will be available on the website after 4:00 p.m. Pacific Time today.

[0001564590-20-027022:8k_2_02:53]
###

[0001564590-20-027022:8k_2_02:54]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-20-027022:8k_2_02:55]
Footnotes

[0001564590-20-027022:8k_2_02:56]
1Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) COVID-19 charges and (i) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be

[0001564590-20-027022:8k_2_02:57]
found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-20-027022:8k_2_02:58]
2GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0001564590-20-027022:8k_2_02:59]
3Google Cloud 2019 Partner Awards, https://cloud.google.com/blog/topics/partners/announcing-the-winners-of-our-2019-partner-awards?linkId=85936877.

[0001564590-20-027022:8k_2_02:60]
4IDC, “IDC MarketScape: Worldwide Scale-Out File-Based Storage 2019 Vendor Assessment,” #US45355019e, December 2019.

[0001564590-20-027022:8k_2_02:61]
5IDC, “A New NetApp Is on the Rise,” by Eric Burgener, #US45948920, February 2020.

[0001564590-20-027022:8k_2_02:62]
NetApp Usage of Non-GAAP Financial Information

[0001564590-20-027022:8k_2_02:63]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-20-027022:8k_2_02:64]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-20-027022:8k_2_02:65]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001564590-20-027022:8k_2_02:66]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-20-027022:8k_2_02:67]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-20-027022:8k_2_02:68]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-20-027022:8k_2_02:69]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001564590-20-027022:8k_2_02:70]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-20-027022:8k_2_02:71]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001564590-20-027022:8k_2_02:72]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-20-027022:8k_2_02:73]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-20-027022:8k_2_02:74]
H. COVID-19 charges. NetApp has excluded certain non-recurring expenses incurred as a direct result of the COVID-19 pandemic. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-20-027022:8k_2_02:75]
I. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or

[0001564590-20-027022:8k_2_02:76]
court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-20-027022:8k_2_02:77]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-20-027022:8k_2_02:78]
About NetApp

[0001564590-20-027022:8k_2_02:79]
NetApp is the leader in cloud data services, empowering global organizations to change their world with data. Together with our partners, we are the only ones who can help you build your unique data fabric. Simplify hybrid multicloud and securely deliver the right data, services and applications to the right people at the right time. Learn more at www.netapp.com.

[0001564590-20-027022:8k_2_02:80]
NETAPP, INC.

[0001564590-20-027022:8k_2_02:81]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-20-027022:8k_2_02:82]
(In millions)

[0001564590-20-027022:8k_2_02:83]
(Unaudited)

[0001564590-20-027022:8k_2_02:84]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 2,882 |  |  | $ | 3,899 |  |
| Accounts receivable |  |  | 973 |  |  |  | 1,216 |  |
| Inventories |  |  | 145 |  |  |  | 131 |  |
| Other current assets |  |  | 274 |  |  |  | 364 |  |
| Total current assets |  |  | 4,274 |  |  |  | 5,610 |  |
| Property and equipment, net |  |  | 727 |  |  |  | 759 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,822 |  |  |  | 1,782 |  |
| Other non-current assets |  |  | 699 |  |  |  | 590 |  |
| Total assets |  | $ | 7,522 |  |  | $ | 8,741 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 426 |  |  | $ | 542 |  |
| Accrued expenses |  |  | 774 |  |  |  | 851 |  |
| Commercial paper notes |  |  | 522 |  |  |  | 249 |  |
| Current portion of long-term debt |  |  | — |  |  |  | 400 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,894 |  |  |  | 1,825 |  |
| Total current liabilities |  |  | 3,616 |  |  |  | 3,867 |  |
| Long-term debt |  |  | 1,146 |  |  |  | 1,144 |  |
| Other long-term liabilities |  |  | 714 |  |  |  | 797 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,804 |  |  |  | 1,843 |  |
| Total liabilities |  |  | 7,280 |  |  |  | 7,651 |  |
| Stockholders' equity |  |  | 242 |  |  |  | 1,090 |  |
| Total liabilities and stockholders' equity |  | $ | 7,522 |  |  | $ | 8,741 |  |

[0001564590-20-027022:8k_2_02:85]
NETAPP, INC.

[0001564590-20-027022:8k_2_02:86]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-20-027022:8k_2_02:87]
(In millions, except per share amounts)

[0001564590-20-027022:8k_2_02:88]
(Unaudited)

[0001564590-20-027022:8k_2_02:89]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 793 |  |  | $ | 1,000 |  |  | $ | 2,995 |  |  | $ | 3,755 |  |
| Software maintenance |  |  | 267 |  |  |  | 242 |  |  |  | 1,034 |  |  |  | 946 |  |
| Hardware maintenance and other services |  |  | 341 |  |  |  | 350 |  |  |  | 1,383 |  |  |  | 1,445 |  |
| Net revenues |  |  | 1,401 |  |  |  | 1,592 |  |  |  | 5,412 |  |  |  | 6,146 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 355 |  |  |  | 457 |  |  |  | 1,368 |  |  |  | 1,752 |  |
| Cost of software maintenance |  |  | 15 |  |  |  | 10 |  |  |  | 48 |  |  |  | 35 |  |
| Cost of hardware maintenance and other services |  |  | 90 |  |  |  | 99 |  |  |  | 373 |  |  |  | 414 |  |
| Total cost of revenues |  |  | 460 |  |  |  | 566 |  |  |  | 1,789 |  |  |  | 2,201 |  |
| Gross profit |  |  | 941 |  |  |  | 1,026 |  |  |  | 3,623 |  |  |  | 3,945 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 389 |  |  |  | 439 |  |  |  | 1,585 |  |  |  | 1,657 |  |
| Research and development |  |  | 212 |  |  |  | 205 |  |  |  | 847 |  |  |  | 827 |  |
| General and administrative |  |  | 63 |  |  |  | 69 |  |  |  | 263 |  |  |  | 278 |  |
| Restructuring charges |  |  | — |  |  |  | 16 |  |  |  | 21 |  |  |  | 35 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (73 | ) |  |  | (38 | ) |  |  | (73 | ) |
| Total operating expenses |  |  | 664 |  |  |  | 656 |  |  |  | 2,678 |  |  |  | 2,724 |  |
| Income from operations |  |  | 277 |  |  |  | 370 |  |  |  | 945 |  |  |  | 1,221 |  |
| Other income (expense), net |  |  | (27 | ) |  |  | 14 |  |  |  | (1 | ) |  |  | 47 |  |
| Income before income taxes |  |  | 250 |  |  |  | 384 |  |  |  | 944 |  |  |  | 1,268 |  |
| Provision (benefit) for income taxes |  |  | 54 |  |  |  | (12 | ) |  |  | 125 |  |  |  | 99 |  |
| Net income |  | $ | 196 |  |  | $ | 396 |  |  | $ | 819 |  |  | $ | 1,169 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.89 |  |  | $ | 1.62 |  |  | $ | 3.56 |  |  | $ | 4.60 |  |
| Diluted |  | $ | 0.88 |  |  | $ | 1.59 |  |  | $ | 3.52 |  |  | $ | 4.51 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 220 |  |  |  | 245 |  |  |  | 230 |  |  |  | 254 |  |
| Diluted |  |  | 222 |  |  |  | 249 |  |  |  | 233 |  |  |  | 259 |  |
| Cash dividends declared per share |  | $ | 0.48 |  |  | $ | 0.40 |  |  | $ | 1.92 |  |  | $ | 1.60 |  |

[0001564590-20-027022:8k_2_02:90]
NETAPP, INC.

[0001564590-20-027022:8k_2_02:91]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-20-027022:8k_2_02:92]
(In millions)

[0001564590-20-027022:8k_2_02:93]
(Unaudited)

[0001564590-20-027022:8k_2_02:94]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 196 |  |  | $ | 396 |  |  | $ | 819 |  |  | $ | 1,169 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 47 |  |  |  | 48 |  |  |  | 193 |  |  |  | 197 |  |
| Non-cash operating lease cost |  |  | 12 |  |  |  | — |  |  |  | 51 |  |  |  | — |  |
| Stock-based compensation |  |  | 35 |  |  |  | 37 |  |  |  | 153 |  |  |  | 158 |  |
| Deferred income taxes |  |  | 6 |  |  |  | 18 |  |  |  | (17 | ) |  |  | (3 | ) |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (73 | ) |  |  | (38 | ) |  |  | (73 | ) |
| Other items, net |  |  | 17 |  |  |  | (6 | ) |  |  | 1 |  |  |  | 2 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (156 | ) |  |  | (350 | ) |  |  | 238 |  |  |  | (185 | ) |
| Inventories |  |  | (32 | ) |  |  | (31 | ) |  |  | (14 | ) |  |  | (9 | ) |
| Accounts payable |  |  | 41 |  |  |  | 44 |  |  |  | (117 | ) |  |  | (57 | ) |
| Accrued expenses |  |  | 96 |  |  |  | 127 |  |  |  | (177 | ) |  |  | 42 |  |
| Deferred revenue and financed unearned services revenue |  |  | 147 |  |  |  | 326 |  |  |  | 54 |  |  |  | 343 |  |
| Long-term taxes payable |  |  | (30 | ) |  |  | (104 | ) |  |  | (163 | ) |  |  | (164 | ) |
| Changes in other operating assets and liabilities, net |  |  | 4 |  |  |  | (33 | ) |  |  | 77 |  |  |  | (79 | ) |
| Net cash provided by operating activities |  |  | 383 |  |  |  | 399 |  |  |  | 1,060 |  |  |  | 1,341 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 82 |  |  |  | 215 |  |  |  | 1,370 |  |  |  | 876 |  |
| Purchases of property and equipment |  |  | (24 | ) |  |  | (35 | ) |  |  | (124 | ) |  |  | (173 | ) |
| Proceeds from sale of properties |  |  | — |  |  |  | — |  |  |  | 96 |  |  |  | — |  |
| Acquisitions of businesses, net of cash acquired |  |  | (17 | ) |  |  | — |  |  |  | (73 | ) |  |  | (3 | ) |
| Other investing activities, net |  |  | 1 |  |  |  | 3 |  |  |  | — |  |  |  | 4 |  |
| Net cash provided by investing activities |  |  | 42 |  |  |  | 183 |  |  |  | 1,269 |  |  |  | 704 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | — |  |  |  | 3 |  |  |  | 102 |  |  |  | 121 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (2 | ) |  |  | (4 | ) |  |  | (79 | ) |  |  | (96 | ) |
| Repurchase of common stock |  |  | (161 | ) |  |  | (500 | ) |  |  | (1,411 | ) |  |  | (2,111 | ) |
| Proceeds from (repayments of) commercial paper notes, net |  |  | (170 | ) |  |  | 85 |  |  |  | 273 |  |  |  | (136 | ) |
| Repayment of long-term debt |  |  | — |  |  |  | — |  |  |  | (400 | ) |  |  | — |  |
| Dividends paid |  |  | (105 | ) |  |  | (97 | ) |  |  | (439 | ) |  |  | (403 | ) |
| Other financing activities, net |  |  | (2 | ) |  |  | (1 | ) |  |  | (6 | ) |  |  | (6 | ) |
| Net cash used in financing activities |  |  | (440 | ) |  |  | (514 | ) |  |  | (1,960 | ) |  |  | (2,631 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (30 | ) |  |  | (13 | ) |  |  | (34 | ) |  |  | (30 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | (45 | ) |  |  | 55 |  |  |  | 335 |  |  |  | (616 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,711 |  |  |  | 2,276 |  |  |  | 2,331 |  |  |  | 2,947 |  |
| End of period |  | $ | 2,666 |  |  | $ | 2,331 |  |  | $ | 2,666 |  |  | $ | 2,331 |  |

[0001564590-20-027022:8k_2_02:95]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q4 FY'20 |  |  | Q3 FY'20 |  |  | Q4 FY'19 |  |  | FY 2020 |  |  | FY 2019 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 793 |  |  | $ | 787 |  |  | $ | 1,000 |  |  | $ | 2,995 |  |  | $ | 3,755 |  |
| Strategic* |  | $ | 544 |  |  | $ | 483 |  |  | $ | 623 |  |  | $ | 1,806 |  |  | $ | 2,100 |  |
| Mature* |  | $ | 249 |  |  | $ | 304 |  |  | $ | 377 |  |  | $ | 1,189 |  |  | $ | 1,655 |  |
| Software Maintenance |  | $ | 267 |  |  | $ | 263 |  |  | $ | 242 |  |  | $ | 1,034 |  |  | $ | 946 |  |
| Hardware Maintenance & Other Services |  | $ | 341 |  |  | $ | 354 |  |  | $ | 350 |  |  | $ | 1,383 |  |  | $ | 1,445 |  |
| Hardware Maintenance Support Contracts |  | $ | 279 |  |  | $ | 293 |  |  | $ | 284 |  |  | $ | 1,142 |  |  | $ | 1,182 |  |
| Professional and Other Services |  | $ | 62 |  |  | $ | 61 |  |  | $ | 66 |  |  | $ | 241 |  |  | $ | 263 |  |
| Net Revenues |  | $ | 1,401 |  |  | $ | 1,404 |  |  | $ | 1,592 |  |  | $ | 5,412 |  |  | $ | 6,146 |  |
| * In Q1 FY’20 we made changes to the products and solutions contained in each of the Strategic and Mature product groupings. Strategic now includes All-flash FAS products, including all related add-on hardware and OS software, private cloud solutions, enterprise software license agreements and other optional add-on software products. Mature now includes Hybrid FAS products, including all related add-on hardware and OS software, OEM products, and branded E-Series. Prior to this change, Hybrid FAS and branded E-Series were included in Strategic, while all add-on hardware and OS software were included in Mature. For comparability, Strategic and Mature revenues presented for the prior year period have been recast based on the revised groupings. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'20 Revenue |  |  | % of Q3 FY'20 Revenue |  |  | % of Q4 FY'19 Revenue |  |  | % of FY 2020 Revenue |  |  | % of FY 2019 Revenue |  |
| Americas |  |  | 54 | % |  |  | 50 | % |  |  | 57 | % |  |  | 53 | % |  |  | 56 | % |
| Americas Commercial |  |  | 43 | % |  |  | 39 | % |  |  | 45 | % |  |  | 41 | % |  |  | 44 | % |
| U.S. Public Sector |  |  | 11 | % |  |  | 11 | % |  |  | 11 | % |  |  | 12 | % |  |  | 12 | % |
| EMEA |  |  | 32 | % |  |  | 35 | % |  |  | 29 | % |  |  | 32 | % |  |  | 30 | % |
| Asia Pacific |  |  | 14 | % |  |  | 15 | % |  |  | 14 | % |  |  | 15 | % |  |  | 14 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'20 Revenue |  |  | % of Q3 FY'20 Revenue |  |  | % of Q4 FY'19 Revenue |  |  | % of FY 2020 Revenue |  |  | % of FY 2019 Revenue |  |
| Direct |  |  | 23 | % |  |  | 21 | % |  |  | 24 | % |  |  | 21 | % |  |  | 24 | % |
| Indirect |  |  | 77 | % |  |  | 79 | % |  |  | 76 | % |  |  | 79 | % |  |  | 76 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'20 |  |  | Q3 FY'20 |  |  | Q4 FY'19 |  |  | FY 2020 |  |  | FY 2019 |  |
| Non-GAAP Gross Margin |  |  | 68.0 | % |  |  | 67.8 | % |  |  | 65.2 | % |  |  | 67.9 | % |  |  | 65.0 | % |
| Product |  |  | 56.4 | % |  |  | 55.4 | % |  |  | 55.3 | % |  |  | 55.7 | % |  |  | 54.4 | % |
| Software Maintenance |  |  | 94.4 | % |  |  | 95.4 | % |  |  | 95.9 | % |  |  | 95.4 | % |  |  | 96.3 | % |
| Hardware Maintenance & Other Services |  |  | 74.5 | % |  |  | 74.9 | % |  |  | 72.3 | % |  |  | 73.8 | % |  |  | 72.0 | % |

[0001564590-20-027022:8k_2_02:96]
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'20 |  |  | Q3 FY'20 |  |  | Q4 FY'19 |  |  | FY 2020 |  |  | FY 2019 |  |
| Non-GAAP Income from Operations |  | $ | 324 |  |  | $ | 312 |  |  | $ | 358 |  |  | $ | 1,123 |  |  | $ | 1,387 |  |
| % of Net Revenues |  |  | 23.1 | % |  |  | 22.2 | % |  |  | 22.5 | % |  |  | 20.8 | % |  |  | 22.6 | % |
| Non-GAAP Income before Income Taxes |  | $ | 307 |  |  | $ | 320 |  |  | $ | 372 |  |  | $ | 1,132 |  |  | $ | 1,434 |  |
| Non-GAAP Effective Tax Rate |  |  | 13.7 | % |  |  | 17.2 | % |  |  | 18.1 | % |  |  | 16.6 | % |  |  | 18.4 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'20 |  |  | Q3 FY'20 |  |  | Q4 FY'19 |  |  | FY 2020 |  |  | FY 2019 |  |
| Non-GAAP Net Income |  | $ | 265 |  |  | $ | 265 |  |  | $ | 305 |  |  | $ | 944 |  |  | $ | 1,171 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 222 |  |  |  | 229 |  |  |  | 249 |  |  |  | 233 |  |  |  | 259 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.19 |  |  | $ | 1.16 |  |  | $ | 1.22 |  |  | $ | 4.05 |  |  | $ | 4.52 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'20 |  |  | Q3 FY'20 |  |  | Q4 FY'19 |  |  |  |  |  |  |  |  |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,698 |  |  | $ | 3,573 |  |  | $ | 3,668 |  |  |  |  |  |  |  |  |  |
| DSO (days) |  |  | 63 |  |  |  | 53 |  |  |  | 70 |  |  |  |  |  |  |  |  |  |
| DIO (days) |  |  | 29 |  |  |  | 22 |  |  |  | 21 |  |  |  |  |  |  |  |  |  |
| DPO (days) |  |  | 84 |  |  |  | 75 |  |  |  | 87 |  |  |  |  |  |  |  |  |  |
| CCC (days) |  |  | 8 |  |  |  | 1 |  |  |  | 3 |  |  |  |  |  |  |  |  |  |
| Inventory Turns |  |  | 13 |  |  |  | 16 |  |  |  | 17 |  |  |  |  |  |  |  |  |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY'20 |  |  | Q3 FY'20 |  |  | Q4 FY'19 |  |  | FY 2020 |  |  | FY 2019 |  |
| Net Cash Provided by Operating Activities |  | $ | 383 |  |  | $ | 420 |  |  | $ | 399 |  |  | $ | 1,060 |  |  | $ | 1,341 |  |
| Purchases of Property and Equipment |  | $ | 24 |  |  | $ | 32 |  |  | $ | 35 |  |  | $ | 124 |  |  | $ | 173 |  |
| Free Cash Flow |  | $ | 359 |  |  | $ | 388 |  |  | $ | 364 |  |  | $ | 936 |  |  | $ | 1,168 |  |
| Free Cash Flow as % of Net Revenues |  |  | 25.6 | % |  |  | 27.6 | % |  |  | 22.9 | % |  |  | 17.3 | % |  |  | 19.0 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |

[0001564590-20-027022:8k_2_02:97]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY20 |  |  | Q3'FY20 |  |  | Q4'FY19 |  |  | FY2020 |  |  | FY2019 |  |
| NET INCOME |  | $ | 196 |  |  | $ | 277 |  |  | $ | 396 |  |  | $ | 819 |  |  | $ | 1,169 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 8 |  |  |  | 8 |  |  |  | 39 |  |  |  | 46 |  |
| Stock-based compensation |  |  | 35 |  |  |  | 36 |  |  |  | 37 |  |  |  | 153 |  |  |  | 158 |  |
| Asset impairment |  |  | 10 |  |  |  | — |  |  |  | — |  |  |  | 10 |  |  |  | — |  |
| COVID-19 charges |  |  | 3 |  |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 16 |  |  |  | 21 |  |  |  | 35 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | (73 | ) |  |  | (38 | ) |  |  | (73 | ) |
| Income tax effects |  |  | 12 |  |  |  | (6 | ) |  |  | (31 | ) |  |  | (13 | ) |  |  | (82 | ) |
| Resolution of income tax matters |  |  | — |  |  |  | (50 | ) |  |  | (48 | ) |  |  | (50 | ) |  |  | (48 | ) |
| Income tax benefit of ASC 606 adoption |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (34 | ) |
| NON-GAAP NET INCOME |  | $ | 265 |  |  | $ | 265 |  |  | $ | 305 |  |  | $ | 944 |  |  | $ | 1,171 |  |
| COST OF REVENUES |  | $ | 460 |  |  | $ | 463 |  |  | $ | 566 |  |  | $ | 1,789 |  |  | $ | 2,201 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (8 | ) |  |  | (8 | ) |  |  | (39 | ) |  |  | (36 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (4 | ) |  |  | (13 | ) |  |  | (14 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 448 |  |  | $ | 452 |  |  | $ | 554 |  |  | $ | 1,737 |  |  | $ | 2,151 |  |
| COST OF PRODUCT REVENUES |  | $ | 355 |  |  | $ | 360 |  |  | $ | 457 |  |  | $ | 1,368 |  |  | $ | 1,752 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (8 | ) |  |  | (8 | ) |  |  | (39 | ) |  |  | (36 | ) |
| Stock-based compensation |  |  | — |  |  |  | (1 | ) |  |  | (2 | ) |  |  | (3 | ) |  |  | (4 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 346 |  |  | $ | 351 |  |  | $ | 447 |  |  | $ | 1,326 |  |  | $ | 1,712 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 90 |  |  | $ | 91 |  |  | $ | 99 |  |  | $ | 373 |  |  | $ | 414 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (2 | ) |  |  | (2 | ) |  |  | (10 | ) |  |  | (10 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 87 |  |  | $ | 89 |  |  | $ | 97 |  |  | $ | 363 |  |  | $ | 404 |  |
| GROSS PROFIT |  | $ | 941 |  |  | $ | 941 |  |  | $ | 1,026 |  |  | $ | 3,623 |  |  | $ | 3,945 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 8 |  |  |  | 8 |  |  |  | 39 |  |  |  | 36 |  |
| Stock-based compensation |  |  | 3 |  |  |  | 3 |  |  |  | 4 |  |  |  | 13 |  |  |  | 14 |  |
| NON-GAAP GROSS PROFIT |  | $ | 953 |  |  | $ | 952 |  |  | $ | 1,038 |  |  | $ | 3,675 |  |  | $ | 3,995 |  |

[0001564590-20-027022:8k_2_02:98]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY20 |  |  | Q3'FY20 |  |  | Q4'FY19 |  |  | FY2020 |  |  | FY2019 |  |
| SALES AND MARKETING EXPENSES |  | $ | 389 |  |  | $ | 402 |  |  | $ | 439 |  |  | $ | 1,585 |  |  | $ | 1,657 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (10 | ) |
| Stock-based compensation |  |  | (16 | ) |  |  | (15 | ) |  |  | (15 | ) |  |  | (66 | ) |  |  | (67 | ) |
| COVID-19 charges |  |  | (3 | ) |  |  | — |  |  |  | — |  |  |  | (3 | ) |  |  | — |  |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 370 |  |  | $ | 387 |  |  | $ | 424 |  |  | $ | 1,516 |  |  | $ | 1,580 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 212 |  |  | $ | 211 |  |  | $ | 205 |  |  | $ | 847 |  |  | $ | 827 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (12 | ) |  |  | (13 | ) |  |  | (11 | ) |  |  | (53 | ) |  |  | (48 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 200 |  |  | $ | 198 |  |  | $ | 194 |  |  | $ | 794 |  |  | $ | 779 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 63 |  |  | $ | 60 |  |  | $ | 69 |  |  | $ | 263 |  |  | $ | 278 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (4 | ) |  |  | (5 | ) |  |  | (7 | ) |  |  | (21 | ) |  |  | (29 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 59 |  |  | $ | 55 |  |  | $ | 62 |  |  | $ | 242 |  |  | $ | 249 |  |
| RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | 16 |  |  | $ | 21 |  |  | $ | 35 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | (16 | ) |  |  | (21 | ) |  |  | (35 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  |  | $ | — |  |  | $ | (73 | ) |  | $ | (38 | ) |  | $ | (73 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | 73 |  |  |  | 38 |  |  |  | 73 |  |
| NON-GAAP GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 664 |  |  | $ | 673 |  |  | $ | 656 |  |  | $ | 2,678 |  |  | $ | 2,724 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (10 | ) |
| Stock-based compensation |  |  | (32 | ) |  |  | (33 | ) |  |  | (33 | ) |  |  | (140 | ) |  |  | (144 | ) |
| COVID-19 charges |  |  | (3 | ) |  |  | — |  |  |  | — |  |  |  | (3 | ) |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | (16 | ) |  |  | (21 | ) |  |  | (35 | ) |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | 73 |  |  |  | 38 |  |  |  | 73 |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 629 |  |  | $ | 640 |  |  | $ | 680 |  |  | $ | 2,552 |  |  | $ | 2,608 |  |

[0001564590-20-027022:8k_2_02:99]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY20 |  |  | Q3'FY20 |  |  | Q4'FY19 |  |  | FY2020 |  |  | FY2019 |  |
| INCOME FROM OPERATIONS |  | $ | 277 |  |  | $ | 268 |  |  | $ | 370 |  |  | $ | 945 |  |  | $ | 1,221 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 8 |  |  |  | 8 |  |  |  | 39 |  |  |  | 46 |  |
| Stock-based compensation |  |  | 35 |  |  |  | 36 |  |  |  | 37 |  |  |  | 153 |  |  |  | 158 |  |
| COVID-19 charges |  |  | 3 |  |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 16 |  |  |  | 21 |  |  |  | 35 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | (73 | ) |  |  | (38 | ) |  |  | (73 | ) |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 324 |  |  | $ | 312 |  |  | $ | 358 |  |  | $ | 1,123 |  |  | $ | 1,387 |  |
| OTHER INCOME (EXPENSE), NET |  | $ | (27 | ) |  | $ | 8 |  |  | $ | 14 |  |  | $ | (1 | ) |  | $ | 40 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Asset impairment |  |  | 10 |  |  |  | — |  |  |  | — |  |  |  | 10 |  |  |  | — |  |
| NON-GAAP OTHER INCOME (EXPENSE), NET |  | $ | (17 | ) |  | $ | 8 |  |  | $ | 14 |  |  | $ | 9 |  |  | $ | 40 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 250 |  |  | $ | 276 |  |  | $ | 384 |  |  | $ | 944 |  |  | $ | 1,268 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 8 |  |  |  | 8 |  |  |  | 39 |  |  |  | 46 |  |
| Stock-based compensation |  |  | 35 |  |  |  | 36 |  |  |  | 37 |  |  |  | 153 |  |  |  | 158 |  |
| Asset impairment |  |  | 10 |  |  |  | — |  |  |  | — |  |  |  | 10 |  |  |  | — |  |
| COVID-19 charges |  |  | 3 |  |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 16 |  |  |  | 21 |  |  |  | 35 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | (73 | ) |  |  | (38 | ) |  |  | (73 | ) |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 307 |  |  | $ | 320 |  |  | $ | 372 |  |  | $ | 1,132 |  |  | $ | 1,434 |  |
| PROVISION (BENEFIT) FOR INCOME TAXES |  | $ | 54 |  |  | $ | (1 | ) |  | $ | (12 | ) |  | $ | 125 |  |  | $ | 99 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | (12 | ) |  |  | 6 |  |  |  | 31 |  |  |  | 13 |  |  |  | 82 |  |
| Resolution of income tax matters |  |  | — |  |  |  | 50 |  |  |  | 48 |  |  |  | 50 |  |  |  | 48 |  |
| Income tax benefit of ASC 606 adoption |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 34 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 42 |  |  | $ | 55 |  |  | $ | 67 |  |  | $ | 188 |  |  | $ | 263 |  |
| NET INCOME PER SHARE |  | $ | 0.88 |  |  | $ | 1.21 |  |  | $ | 1.59 |  |  | $ | 3.52 |  |  | $ | 4.51 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.04 |  |  |  | 0.03 |  |  |  | 0.03 |  |  |  | 0.17 |  |  |  | 0.18 |  |
| Stock-based compensation |  |  | 0.16 |  |  |  | 0.16 |  |  |  | 0.15 |  |  |  | 0.66 |  |  |  | 0.61 |  |
| Asset impairment |  |  | 0.05 |  |  |  | — |  |  |  | — |  |  |  | 0.04 |  |  |  | — |  |
| COVID-19 charges |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 0.01 |  |  |  | — |  |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | 0.06 |  |  |  | 0.09 |  |  |  | 0.14 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | (0.29 | ) |  |  | (0.16 | ) |  |  | (0.28 | ) |
| Income tax effects |  |  | 0.05 |  |  |  | (0.03 | ) |  |  | (0.12 | ) |  |  | (0.06 | ) |  |  | (0.32 | ) |
| Resolution of income tax matters |  |  | — |  |  |  | (0.22 | ) |  |  | (0.19 | ) |  |  | (0.21 | ) |  |  | (0.19 | ) |
| Income tax benefit of ASC 606 adoption |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.13 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.19 |  |  | $ | 1.16 |  |  | $ | 1.22 |  |  | $ | 4.05 |  |  | $ | 4.52 |  |

[0001564590-20-027022:8k_2_02:100]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY20 |  |  | Q3'FY20 |  |  | Q4'FY19 |  |  | FY2020 |  |  | FY2019 |  |
| Gross margin-GAAP |  |  | 67.2 | % |  |  | 67.0 | % |  |  | 64.4 | % |  |  | 66.9 | % |  |  | 64.2 | % |
| Cost of revenues adjustments |  |  | 0.9 | % |  |  | 0.8 | % |  |  | 0.8 | % |  |  | 1.0 | % |  |  | 0.8 | % |
| Gross margin-Non-GAAP |  |  | 68.0 | % |  |  | 67.8 | % |  |  | 65.2 | % |  |  | 67.9 | % |  |  | 65.0 | % |
| GAAP cost of revenues |  | $ | 460 |  |  | $ | 463 |  |  | $ | 566 |  |  | $ | 1,789 |  |  | $ | 2,201 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (8 | ) |  |  | (8 | ) |  |  | (39 | ) |  |  | (36 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (3 | ) |  |  | (4 | ) |  |  | (13 | ) |  |  | (14 | ) |
| Non-GAAP cost of revenues |  | $ | 448 |  |  | $ | 452 |  |  | $ | 554 |  |  | $ | 1,737 |  |  | $ | 2,151 |  |
| Net revenues |  | $ | 1,401 |  |  | $ | 1,404 |  |  | $ | 1,592 |  |  | $ | 5,412 |  |  | $ | 6,146 |  |

[0001564590-20-027022:8k_2_02:101]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY20 |  |  | Q3'FY20 |  |  | Q4'FY19 |  |  | FY2020 |  |  | FY2019 |  |
| Product gross margin-GAAP |  |  | 55.2 | % |  |  | 54.3 | % |  |  | 54.3 | % |  |  | 54.3 | % |  |  | 53.3 | % |
| Cost of product revenues adjustments |  |  | 1.1 | % |  |  | 1.1 | % |  |  | 1.0 | % |  |  | 1.4 | % |  |  | 1.1 | % |
| Product gross margin-Non-GAAP |  |  | 56.4 | % |  |  | 55.4 | % |  |  | 55.3 | % |  |  | 55.7 | % |  |  | 54.4 | % |
| GAAP cost of product revenues |  | $ | 355 |  |  | $ | 360 |  |  | $ | 457 |  |  | $ | 1,368 |  |  | $ | 1,752 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (8 | ) |  |  | (8 | ) |  |  | (39 | ) |  |  | (36 | ) |
| Stock-based compensation |  |  | — |  |  |  | (1 | ) |  |  | (2 | ) |  |  | (3 | ) |  |  | (4 | ) |
| Non-GAAP cost of product revenues |  | $ | 346 |  |  | $ | 351 |  |  | $ | 447 |  |  | $ | 1,326 |  |  | $ | 1,712 |  |
| Product revenues |  | $ | 793 |  |  | $ | 787 |  |  | $ | 1,000 |  |  | $ | 2,995 |  |  | $ | 3,755 |  |

[0001564590-20-027022:8k_2_02:102]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY20 |  |  | Q3'FY20 |  |  | Q4'FY19 |  |  | FY2020 |  |  | FY2019 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 73.6 | % |  |  | 74.3 | % |  |  | 71.7 | % |  |  | 73.0 | % |  |  | 71.3 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 0.9 | % |  |  | 0.6 | % |  |  | 0.6 | % |  |  | 0.7 | % |  |  | 0.7 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 74.5 | % |  |  | 74.9 | % |  |  | 72.3 | % |  |  | 73.8 | % |  |  | 72.0 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 90 |  |  | $ | 91 |  |  | $ | 99 |  |  | $ | 373 |  |  | $ | 414 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (2 | ) |  |  | (2 | ) |  |  | (10 | ) |  |  | (10 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 87 |  |  | $ | 89 |  |  | $ | 97 |  |  | $ | 363 |  |  | $ | 404 |  |
| Hardware maintenance and other services revenues |  | $ | 341 |  |  | $ | 354 |  |  | $ | 350 |  |  | $ | 1,383 |  |  | $ | 1,445 |  |

[0001564590-20-027022:8k_2_02:103]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q4'FY20 |  |  | Q3'FY20 |  |  | Q4'FY19 |  |  | FY2020 |  |  | FY2019 |  |
| GAAP effective tax rate |  |  | 21.6 | % |  |  | (0.4 | )% |  |  | (3.1 | )% |  |  | 13.2 | % |  |  | 7.8 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | (7.9 | )% |  |  | 2.0 | % |  |  | 8.3 | % |  |  | (1.1 | )% |  |  | 4.9 | % |
| Resolution of income tax matters |  |  | — | % |  |  | 15.6 | % |  |  | 12.9 | % |  |  | 4.4 | % |  |  | 3.3 | % |
| Income tax benefit of ASC 606 adoption |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | 2.4 | % |
| Non-GAAP effective tax rate |  |  | 13.7 | % |  |  | 17.2 | % |  |  | 18.1 | % |  |  | 16.6 | % |  |  | 18.4 | % |

[0001564590-20-027022:8k_2_02:104]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q4'FY20 |  |  | Q3'FY20 |  |  | Q4'FY19 |  |  | FY2020 |  |  | FY2019 |  |
| Net cash provided by operating activities |  | $ | 383 |  |  | $ | 420 |  |  | $ | 399 |  |  | $ | 1,060 |  |  | $ | 1,341 |  |
| Purchases of property and equipment |  |  | (24 | ) |  |  | (32 | ) |  |  | (35 | ) |  |  | (124 | ) |  |  | (173 | ) |
| Free cash flow |  | $ | 359 |  |  | $ | 388 |  |  | $ | 364 |  |  | $ | 936 |  |  | $ | 1,168 |  |

[0001564590-20-027022:8k_2_02:105]
Some items may not add or recalculate due to rounding.

[0001564590-20-027022:8k_2_02:106]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| FIRST QUARTER FISCAL 2021 |  |
|  |  | First Quarter |  |
|  |  | Fiscal 2021 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $0.36 - $0.44 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the First Quarter Fiscal 2021: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.04 | ) |
| Stock-based compensation expense |  |  | (0.18 | ) |
| Income tax effects |  |  | 0.04 |  |
| Total Adjustments |  |  | (0.18 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.18 - $0.26 |  |

[0001564590-20-027022:8k_2_02:107]
Some items may not add or recalculate due to rounding.

[0001564590-20-027022:8k_2_02:108]
Press Contact:

[0001564590-20-027022:8k_2_02:109]
Amelia Vierra

[0001564590-20-027022:8k_2_02:110]
NetApp

[0001564590-20-027022:8k_2_02:111]
1 408 822 6403

[0001564590-20-027022:8k_2_02:112]
amelia.vierra@netapp.com

[0001564590-20-027022:8k_2_02:113]
Investor Contact:

[0001564590-20-027022:8k_2_02:114]
Lance Berger

[0001564590-20-027022:8k_2_02:115]
NetApp

[0001564590-20-027022:8k_2_02:116]
1 408 822 6628

[0001564590-20-027022:8k_2_02:117]
lance.berger@netapp.com
