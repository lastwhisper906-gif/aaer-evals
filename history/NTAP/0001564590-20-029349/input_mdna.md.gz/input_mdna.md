# NTAP MD&A — 0001564590-20-029349


## mdna

[0001564590-20-029349:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001564590-20-029349:mdna:2]
The following discussion of our financial condition and results of operations should be read together with the financial statements and the accompanying notes set forth under Item 8. – Financial Statements and Supplementary Data. The following discussion also contains trend information and other forward-looking statements that involve a number of risks and uncertainties. The Risk Factors set forth in Item 1A. – Risk Factors are hereby incorporated into the discussion by reference.

[0001564590-20-029349:mdna:3]
Executive Overview

[0001564590-20-029349:mdna:4]
Our Company

[0001564590-20-029349:mdna:5]
NetApp is a leader in hybrid cloud data services. In a world of increasing complexity, we simplify. We help our customers ensure their data and applications are in the right place at the right time with the right characteristics and capabilities in order to achieve new insights and accelerate innovation. Only NetApp delivers everything IT organizations need to build their own unique data fabrics.

[0001564590-20-029349:mdna:6]
NetApp helps customers move from building data centers to building data fabrics. A data fabric simplifies the integration and orchestration of data services across clouds and on-premises to accelerate digital transformation. Only NetApp can deliver the full range of capabilities organizations need for their data fabrics: the power to discover resources, integrate disparate data services, automate operations, optimize over time, and protect and secure data everywhere.

[0001564590-20-029349:mdna:7]
Together with our partners, we empower organizations to unleash the full potential of their data to expand customer touchpoints, foster greater innovation and optimize their operations.

[0001564590-20-029349:mdna:8]
We focus on delivering an exceptional customer experience to become our customers’ preferred data partner. NetApp’s unique approach to data services enables organizations to drive data-driven innovation with the cloud, build clouds to gain speed and agility, and modernize and simplify IT to accelerate critical business applications.

[0001564590-20-029349:mdna:9]
With NetApp products and solutions, customers can:

[0001564590-20-029349:mdna:10]
|  | • | Adopt new cloud-based capabilities by leveraging the best cloud resources for their business and simplify the complexities of managing data across multiple, public clouds and on-premises |

[0001564590-20-029349:mdna:11]
|  | • | Add new capabilities to their current environment by delivering new applications and services faster, and run existing workloads more efficiently with a foundation that brings the power of cloud-native data services on premises |

[0001564590-20-029349:mdna:12]
|  | • | Run their current IT application environment more efficiently by optimizing and future proofing infrastructure with high-performing, cloud-integrated technologies and converged infrastructure. |

[0001564590-20-029349:mdna:13]
We employ a multichannel distribution strategy, selling products and services to end users and service providers through a direct sales force and through channel partners, including value-added resellers, system integrators, original equipment manufacturers (OEMs) and distributors.

[0001564590-20-029349:mdna:14]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. As our product portfolio evolves, market dynamics change, and management continues to assess our largest growth opportunities, we periodically change how we group certain products. Beginning in fiscal 2020, Strategic includes all-flash array products: A-series arrays (AFF), SolidFire, and EF-series, including all related add-on hardware and operating system (OS) software, NetApp HCI, StorageGrid, and optional add-on software products. Mature now includes hybrid and all-disk array products: FAS and E-series, including all related add-on hardware and OS software, and original equipment manufacturers (OEM) products. Prior to this grouping change, Hybrid FAS products and E-Series were included in Strategic, while all add-on hardware and OS software were included in Mature. For comparability, Strategic and Mature revenues presented for the prior year periods have been recast based on the revised groupings.

[0001564590-20-029349:mdna:15]
In addition to our products and solutions, we provide a variety of services to our customers, including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training to help customers most effectively build their unique data fabrics and efficiently manage their data. Revenues generated by our Cloud Data Services offerings are included in software maintenance revenues.

[0001564590-20-029349:mdna:16]
COVID-19

[0001564590-20-029349:mdna:17]
The novel coronavirus, or COVID-19, pandemic and efforts to control its spread have significantly curtailed the movement of people, goods and services worldwide, including in most or all of the regions in which we sell our products and services and conduct our business operations. We have taken precautionary measures intended to minimize the risk of the virus to our employees, our customers, and the communities in which we operate. Since March 2020, the vast majority of our employees have been working remotely and we have suspended business travel.

[0001564590-20-029349:mdna:18]
During the fourth quarter of fiscal 2020, due to increased macroeconomic uncertainty caused by COVID-19, we observed certain customers delay purchases of our products and services, while other customers accelerated or placed new orders to address the

[0001564590-20-029349:mdna:19]
demands of remote working and digital business, though on a net basis the impact to product revenues was unfavorable. We also experienced certain logistical challenges in delivering our products and services to customers in certain regions, and minor supply chain constraints.

[0001564590-20-029349:mdna:20]
We believe our existing balances of cash, cash equivalents and investments, cash generated from operations, and ability to access capital markets and committed lines of credit will be sufficient to satisfy our working capital needs, capital expenditures, dividends, required debt repayments and other liquidity requirements associated with our operations. In March 2020, we suspended our stock repurchase program.

[0001564590-20-029349:mdna:21]
The magnitude and duration of the disruption to our business, and impact to our operational and financial performance, caused by COVID-19 pandemic is uncertain. Refer to Item 1A. – Risk Factors for the significant risks we have identified as a result of the COVID-19 pandemic.

[0001564590-20-029349:mdna:22]
Financial Results and Key Performance Metrics Overview

[0001564590-20-029349:mdna:23]
The following table provides an overview of some of our key financial metrics for each of the last three fiscal years (in millions, except per share amounts and percentages):

[0001564590-20-029349:mdna:24]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Net revenues |  | $ | 5,412 |  |  | $ | 6,146 |  |  | $ | 5,919 |  |
| Gross profit |  | $ | 3,623 |  |  | $ | 3,945 |  |  | $ | 3,709 |  |
| Gross profit margin percentage |  |  | 67 | % |  |  | 64 | % |  |  | 63 | % |
| Income from operations |  | $ | 945 |  |  | $ | 1,221 |  |  | $ | 1,158 |  |
| Income from operations as a percentage of net revenues |  |  | 17 | % |  |  | 20 | % |  |  | 20 | % |
| Provision for income taxes |  | $ | 125 |  |  | $ | 99 |  |  | $ | 1,083 |  |
| Net income |  | $ | 819 |  |  | $ | 1,169 |  |  | $ | 116 |  |
| Diluted net income per share |  | $ | 3.52 |  |  | $ | 4.51 |  |  | $ | 0.42 |  |
| Net cash provided by operating activities |  | $ | 1,060 |  |  | $ | 1,341 |  |  | $ | 1,478 |  |

[0001564590-20-029349:mdna:25]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,698 |  |  | $ | 3,668 |  |

[0001564590-20-029349:mdna:26]
|  | • | Net revenues: Our net revenues decreased 12% in fiscal 2020 compared to fiscal 2019. This was primarily due to a decrease of 20% in product revenues. |

[0001564590-20-029349:mdna:27]
|  | • | Gross profit margin percentage: Our gross profit margin as a percentage of net revenues increased by almost three percentage points in fiscal 2020 compared to fiscal 2019, primarily as a result of software and hardware maintenance revenues representing a higher percentage of total revenues in fiscal 2020, due to the decline in product revenues. |

[0001564590-20-029349:mdna:28]
|  | • | Income from operations as a percentage of net revenues: Our income from operations as a percentage of net revenues decreased by approximately two and a half percentage points in fiscal 2020 compared to fiscal 2019, primarily due to a decrease in net revenues in fiscal 2020, partially offset by a slight decrease in operating expenses. |

[0001564590-20-029349:mdna:29]
|  | • | Provision for income taxes: Our provision for income taxes increased in fiscal 2020 compared to fiscal 2019 primarily as a result of differences in discrete tax impacts in each year. |

[0001564590-20-029349:mdna:30]
|  | • | Net income and Diluted income per share: The decrease in both net income and diluted net income per share in fiscal 2020 compared to fiscal 2019 reflect the factors discussed above. Diluted net income per share was favorably impacted by a 10% decrease in the annual weighted average number of dilutive shares, due to share repurchases. |

[0001564590-20-029349:mdna:31]
|  | • | Operating cash flows: Operating cash flows decreased by 21% in fiscal 2020 compared to fiscal 2019, primarily reflecting lower net income. |

[0001564590-20-029349:mdna:32]
|  | • | Deferred revenue and financed unearned services revenue: Our total deferred revenue and financed unearned services revenue balance was relatively consistent as of both the end of fiscal 2020 and fiscal 2019. |

[0001564590-20-029349:mdna:33]
Stock Repurchase Program and Dividend Activity

[0001564590-20-029349:mdna:34]
During fiscal 2020, we repurchased 25 million shares of our common stock at an average price of $56.34 per share, for an aggregate purchase price of $1.4 billion. We also declared cash dividends of an aggregate of $1.92 per share in fiscal 2020, for which we paid an aggregate of $439 million.

[0001564590-20-029349:mdna:35]
34

[0001564590-20-029349:mdna:36]
Acquisitions

[0001564590-20-029349:mdna:37]
On May 23, 2019, we acquired all the outstanding shares of privately-held Cognigo Research Ltd., a provider of data discovery classification software designed to manage and protect critical data, for $53 million in cash.

[0001564590-20-029349:mdna:38]
On March 6, 2020, we acquired all the outstanding shares of privately-held Talon Storage Solutions, Inc., a provider of next generation software-defined storage solutions, for $23 million in cash.

[0001564590-20-029349:mdna:39]
On April 28, 2020, in the first quarter of fiscal 2021, we acquired all the outstanding shares of privately-held Cloud Jumper Corporation, a provider of virtual desktop infrastructure and remote desktop services solutions, for approximately $34 million in cash.

[0001564590-20-029349:mdna:40]
Restructuring Event

[0001564590-20-029349:mdna:41]
In the first quarter of fiscal 2020, we announced a restructuring plan to reduce costs and redirect resources to our highest return activities, which included a reduction in our global workforce by approximately 2%, and incurred charges of approximately $21 million, consisting primarily of employee severance costs. See Note 13 – Restructuring Charges for additional information.

[0001564590-20-029349:mdna:42]
Adoption of Lease Accounting Standard

[0001564590-20-029349:mdna:43]
In the first quarter of fiscal 2020, we adopted the new accounting standard Leases (ASC 842) using the modified retrospective approach, electing the optional transition method of not adjusting our comparative period financial statements. Adoption of the new standard resulted in the recognition of approximately $149 million of operating lease right-of-use assets, net of deferred rent and restructuring liabilities, and $158 million of lease liabilities on our consolidated balance sheets as of the beginning of fiscal 2020. See Note 10 – Leases in the Notes to Consolidated Financial Statements for additional information.

[0001564590-20-029349:mdna:44]
Senior Notes Maturity

[0001564590-20-029349:mdna:45]
On September 27, 2019, we made an aggregate cash payment of $400 million to extinguish our 2.00% Senior Notes at maturity. This repayment was funded through the sale of short-term commercial paper notes issued under our existing program and cash on hand.

[0001564590-20-029349:mdna:46]
Real Estate Transaction

[0001564590-20-029349:mdna:47]
In September 2017, we entered into an agreement to sell certain land and buildings located in Sunnyvale, California, through two separate and independent closings, the first of which was completed in the third quarter of fiscal 2018. The remaining properties, consisting of land, were classified as assets held for sale, and included as other current assets in our consolidated balance sheets as of April 26, 2019. On August 29, 2019, the second closing occurred and we consummated the sale of the land, with a net book value of $53 million, and received cash proceeds of $96 million, resulting in a gain, net of direct selling costs, of $38 million.

[0001564590-20-029349:mdna:48]
Critical Accounting Policies and Estimates

[0001564590-20-029349:mdna:49]
Our consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (GAAP), which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and liabilities. Our estimates are based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, including the ongoing COVID-19 pandemic, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0001564590-20-029349:mdna:50]
The summary of significant accounting policies is included in Note 1 – Description of Business and Significant Accounting Policies of the Notes to Consolidated Financial Statements. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. The accounting policies described below reflect the significant judgments, estimates and assumptions used in the preparation of the consolidated financial statements.

[0001564590-20-029349:mdna:51]
Revenue Recognition

[0001564590-20-029349:mdna:52]
Our contracts with customers often include the transfer of multiple products and services to the customer. In determining the amount and timing of revenue recognition, we assess which products and services are distinct performance obligations and allocate the transaction price, which may include fixed and/or variable amounts, among each performance obligation on a relative standalone selling price (SSP) basis. The following are the key estimates and assumptions and corresponding uncertainties included in this approach:

[0001564590-20-029349:mdna:53]
35

[0001564590-20-029349:mdna:54]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | We evaluate whether products and services promised in our contracts with customers are distinct performance obligations that should be accounted for separately versus together. |  | • | In certain contracts, the determination of our distinct performance obligations requires significant judgment. As our business and offerings to customers change over time, the products and services we determine to be distinct performance obligations may change. Such changes may adversely impact the amount of revenue and gross margin we report in a particular period. |
| • | In determining the transaction price of our contracts, we estimate variable consideration based on the expected value, primarily relying on our history. In certain situations, we may also use the most likely amount as the basis of our estimate. |  | • | We may have insufficient relevant historical data or other information to arrive at an accurate estimate of variable consideration using either the “expected value” or “most likely amount” method. Additionally, changes in business practices, such as those related to sales returns or marketing programs, may introduce new forms of variable consideration, as well as more complexity and uncertainty in the estimation process. |
| • | In contracts with multiple performance obligations, we establish SSPs based on the price at which products and services are sold separately. If SSPs are not observable through past transactions, we estimate them using available information including, but not limited to, market data and other observable inputs. |  | • | As our business and offerings evolve over time, modifications to our pricing and discounting methodologies, changes in the scope and nature of product and service offerings and/or changes in customer segmentation may result in a lack of consistency, making it difficult to establish and/or maintain SSPs. Changes in SSPs could result in different and unanticipated allocations of revenue in contracts with multiple performance obligations. These factors, among others, may adversely impact the amount of revenue and gross margin we report in a particular period. |

[0001564590-20-029349:mdna:55]
Inventory Valuation and Purchase Order Accruals

[0001564590-20-029349:mdna:56]
Inventories consist primarily of purchased components and finished goods and are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. A provision is recorded when inventory is determined to be in excess of anticipated demand or obsolete in order to adjust inventory to its estimated realizable value. The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our inventories:

[0001564590-20-029349:mdna:57]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | We periodically perform an excess and obsolete analysis of our inventory. Inventories are written down based on excess and obsolete reserves determined primarily on assumptions about future demand forecasts and market conditions. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. |  | • | Although we use our best estimates to forecast future product demand, any significant unanticipated changes in demand, which could be exacerbated by the effects of the COVID-19 pandemic, or obsolescence related to technological developments, new product introductions, customer requirements, competition or other factors could have a significant impact on the valuation of our inventory. If actual market conditions are less favorable than those projected, additional write-downs and other charges against earnings that adversely impact gross margins may be required. If actual market conditions are more favorable, we may realize higher gross profits in the period when the written-down inventory is sold. We are subject to a variety of environmental laws relating to the manufacture of our products. If there are changes to the current regulations, we may be required to make product design changes which may result in excess or obsolete inventory, which could adversely impact our operating results. |

[0001564590-20-029349:mdna:58]
36

[0001564590-20-029349:mdna:59]
| • | We make commitments to our third-party contract manufacturers and other suppliers to manage lead times and meet product forecasts and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on non-cancelable purchase commitments when we believe it is probable that the components will not be utilized in future operations. |  | • | If the actual materials demand is significantly lower than our forecast, we may be required to increase our recorded liabilities for estimated losses on non-cancelable purchase commitments which would adversely impact our operating results. |

[0001564590-20-029349:mdna:60]
Goodwill and Purchased Intangible Assets

[0001564590-20-029349:mdna:61]
We allocate the purchase price of acquisitions to identifiable assets acquired and liabilities assumed at their acquisition date fair values based on established valuation techniques. Goodwill represents the residual value as of the acquisition date, which in most cases is measured as the excess of the purchase consideration transferred over the net of the acquisition date fair values of the assets acquired and liabilities assumed.

[0001564590-20-029349:mdna:62]
The carrying values of purchased intangible assets are reviewed whenever events and circumstances indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. We periodically review the estimated remaining useful lives of our intangible assets. This review may result in impairment charges or shortened useful lives, resulting in charges to our consolidated statements of operations.

[0001564590-20-029349:mdna:63]
We review goodwill for impairment annually and whenever events or changes in circumstances indicate the carrying amount of our reporting unit may exceed its fair value. The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. For our annual goodwill impairment test in the fourth quarter of fiscal 2020, we performed a quantitative test and determined the fair value of our reporting unit substantially exceeded its carrying amount, therefore, found no impairment of goodwill. To date, the impacts of the COVID-19 pandemic have not significantly adversely affected the fair value of our reporting unit.

[0001564590-20-029349:mdna:64]
37

[0001564590-20-029349:mdna:65]
The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our goodwill and purchased intangible assets:

[0001564590-20-029349:mdna:66]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the accounting guidance for the fair value measurement of nonfinancial assets. The valuation of purchased intangible assets is principally based on estimates of the future performance and cash flows expected to be generated by the acquired assets from the acquired business. |  | • | While we employ experts to determine the acquisition date fair value of acquired intangibles, the fair values of assets acquired and liabilities assumed are based on significant management assumptions and estimates, which are inherently uncertain and highly subjective and as a result, actual results may differ from estimates. If different assumptions were to be used, it could materially impact the purchase price allocation. Volatile macroeconomic and market conditions caused by the COVID-19 pandemic have increased the level of uncertainty and subjectivity of certain management assumptions and estimates. |
| • | Evaluations of possible goodwill and purchased intangible asset impairment require us to make judgments and assumptions related to the allocation of our balance sheet and income statement amounts and estimate future cash flows and fair market values of our reporting unit and assets. |  | • | In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill or purchased intangible assets. Assumptions and estimates about expected future cash flows and the fair values of our reporting unit and purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as the adverse impact of unanticipated changes in macroeconomic conditions, such as those related to the COVID-19 pandemic, and technological changes or new product introductions from competitors. They can also be affected by internal factors such as changes in business strategy or in forecasted product life cycles and roadmaps. Our ongoing consideration of these and other factors could result in future impairment charges or accelerated amortization expense, which could adversely affect our operating results. |

[0001564590-20-029349:mdna:67]
Valuation of Investment Securities

[0001564590-20-029349:mdna:68]
Our investments in debt securities are reported at fair value and are subject to periodic impairment review. Unrealized gains and losses related to changes in the fair value of these securities are recognized in accumulated other comprehensive income, net of tax, unless they are determined to be other-than-temporary impairments. The ultimate value realized on these securities is subject to market price volatility until they are sold.

[0001564590-20-029349:mdna:69]
The following are the key estimates and assumptions and corresponding uncertainties for the valuation of our investment securities:

[0001564590-20-029349:mdna:70]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | The estimated fair value of our debt securities, and the associated accounting for unrealized losses is based on an evaluation of current economic and market conditions, the credit rating of the security’s issuer, the length of time and extent the security’s fair value has been below its amortized cost and our ability and intent to hold the security for a period of time sufficient to allow for anticipated recovery in value. If we determine that an investment has an other-than-temporary decline in fair value, we recognize the investment loss in earnings. |  | • | The fair value of our investments in debt securities could decrease significantly from uncertainties in the credit and capital markets, credit rating downgrades and/or solvency of the issuer or decreases in the marketability of the securities, with the ongoing COVID-19 pandemic contributing to these uncertainties. If the fair value of our investments decreases significantly and, if because of changes in our ability and intent to continue to hold the securities or other factors, it is determined to be other-than-temporary, we may incur impairment charges that could adversely affect our results of operations. |

[0001564590-20-029349:mdna:71]
38

[0001564590-20-029349:mdna:72]
Income Taxes

[0001564590-20-029349:mdna:73]
We are subject to income taxes in the United States and numerous foreign jurisdictions. We compute our provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0001564590-20-029349:mdna:74]
The following are the key estimates and assumptions and corresponding uncertainties for our income taxes:

[0001564590-20-029349:mdna:75]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| • | Our income tax provision is based on existing tax law and advanced pricing agreements or letter rulings we have with various tax authorities. |  | • | Our provision for income taxes is subject to volatility and could be adversely impacted by future changes in existing tax laws, such as a change in tax rate, possible U.S. changes to the taxation of earnings of our foreign subsidiaries, and uncertainties as to future renewals of favorable tax agreements and rulings. |
| • | The determination of whether we should record or adjust a valuation allowance against our deferred tax assets is based on assumptions regarding our future profitability. |  | • | Our future profits could differ from current expectations resulting in a change to our determination as to the amount of deferred tax assets that are more likely than not to be realized. We could adjust our valuation allowance with a corresponding impact to the tax provision in the period in which such determination is made. |
| • | The estimates for our uncertain tax positions are based primarily on company specific circumstances, applicable tax laws, tax opinions from outside firms and past results from examinations of our income tax returns. |  | • | Significant judgment is required in evaluating our uncertain tax positions. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome or tax court rulings of these matters will not be different from that which is reflected in our historical tax provisions and accruals. |

[0001564590-20-029349:mdna:76]
New Accounting Standards

[0001564590-20-029349:mdna:77]
See Note 1 – Description of Business and Significant Accounting policies for the impact to our financial statements of the adoption of the accounting standard Leases (ASC 842) in the first quarter of fiscal 2020.

[0001564590-20-029349:mdna:78]
See Note 2 – Recent Accounting Standards Not Yet Effective of the Notes to Consolidated Financial Statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on our financial statements.

[0001564590-20-029349:mdna:79]
39

[0001564590-20-029349:mdna:80]
Results of Operations

[0001564590-20-029349:mdna:81]
Our fiscal year is reported on a 52- or 53-week year that ends on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2020, which ended on April 24, 2020, fiscal year 2019, which ended on April 26, 2019, and fiscal year 2018, which ended on April 27, 2018, were all 52-week years. Unless otherwise stated, references to particular years, quarters, months and periods refer to our fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0001564590-20-029349:mdna:82]
The following table sets forth certain Consolidated Statements of Operations data as a percentage of net revenues for the periods indicated:

[0001564590-20-029349:mdna:83]
|  |  | Fiscal Year |  |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 55 |  | % |  | 61 |  | % |  | 60 |  | % |
| Software maintenance |  |  | 19 |  |  |  | 15 |  |  |  | 15 |  |  |
| Hardware maintenance and other services |  |  | 26 |  |  |  | 24 |  |  |  | 25 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 25 |  |  |  | 29 |  |  |  | 29 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | 1 |  |  |  | — |  |  |
| Cost of hardware maintenance and other services |  |  | 7 |  |  |  | 7 |  |  |  | 8 |  |  |
| Gross profit |  |  | 67 |  |  |  | 64 |  |  |  | 63 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 29 |  |  |  | 27 |  |  |  | 29 |  |  |
| Research and development |  |  | 16 |  |  |  | 13 |  |  |  | 13 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | — |  |  |  | 1 |  |  |  | — |  |  |
| Gain on sale or derecognition of assets |  |  | (1 | ) |  |  | (1 | ) |  |  | (4 | ) |  |
| Total operating expenses |  |  | 49 |  |  |  | 44 |  |  |  | 43 |  |  |
| Income from operations |  |  | 17 |  |  |  | 20 |  |  |  | 20 |  |  |
| Other income (expense), net |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |
| Income before income taxes |  |  | 17 |  |  |  | 21 |  |  |  | 20 |  |  |
| Provision for income taxes |  |  | 2 |  |  |  | 2 |  |  |  | 18 |  |  |
| Net income |  |  | 15 |  | % |  | 19 |  | % |  | 2 |  | % |

[0001564590-20-029349:mdna:84]
Percentages may not add due to rounding

[0001564590-20-029349:mdna:85]
Discussion and Analysis of Results of Operations

[0001564590-20-029349:mdna:86]
Overview — Net revenues for fiscal 2020 were $5,412 million, a decrease of $734 million, or 12% compared to fiscal 2019, reflecting lower product and hardware maintenance and other services revenues, partially offset by higher software maintenance revenues. Product revenues were negatively impacted by a reduction of customer demand due to the COVID-19 pandemic in the fourth quarter of fiscal 2020. Net revenues for fiscal 2019 were $6,146 million, an increase of $227 million, or 4% compared to fiscal 2018, reflecting higher product and software maintenance revenues, partially offset by slightly lower hardware maintenance and other services revenues.

[0001564590-20-029349:mdna:87]
Gross profit as a percentage of net revenues for fiscal 2020 increased by almost three points compared to fiscal 2019, primarily as a result of software and hardware maintenance revenues representing a higher percentage of total revenues in fiscal 2020, due to the decline in product revenues, and, to a lesser extent, slightly higher gross profit margins on product revenues and hardware maintenance and other services revenues. Gross profit margins on product revenues in fiscal 2020 increased one percentage point compared to fiscal 2019, primarily due to a higher mix of AFF product sales in the current year, partially offset by a decrease in high-margin revenue recognized from the software license component of several ELAs. Gross profit as a percentage of net revenues for fiscal 2019 increased by one and a half percentage points compared to fiscal 2018, reflecting higher margins on product revenues and hardware maintenance and other services revenues.

[0001564590-20-029349:mdna:88]
Sales and marketing, research and development, and general and administrative expenses for fiscal 2020 totaled $2,695 million, or 50% of net revenues, representing an increase of five percentage points compared to fiscal 2019, primarily due to lower net revenues in fiscal 2020. Sales and marketing, research and development, and general and administrative expenses for fiscal 2019 totaled $2,762 million, or 45% of net revenues, representing a decrease of two percentage points compared to fiscal 2018, primarily due to higher net revenues in fiscal 2019.

[0001564590-20-029349:mdna:89]
40

[0001564590-20-029349:mdna:90]
Net Revenues (in millions, except percentages):

[0001564590-20-029349:mdna:91]
|  |  |  | Fiscal Year |  |
|  |  |  | 2020 |  |  | 2019 |  |  | % Change |  |  | 2018 |  |  | % Change |  |
| Net revenues |  |  | $ | 5,412 |  |  | $ | 6,146 |  |  |  | (12 | )% |  | $ | 5,919 |  |  |  | 4 | % |

[0001564590-20-029349:mdna:92]
The decrease in net revenues for fiscal 2020 compared to fiscal 2019 was primarily due to a decrease of $760 million in product revenues. Product revenues as a percent of net revenues decreased six percentage points in fiscal 2020 compared to fiscal 2019.

[0001564590-20-029349:mdna:93]
The increase in net revenues for fiscal 2019 compared to fiscal 2018 was primarily due to an increase of $230 million in product revenues. Product revenues as a percent of net revenues increased one and a half percentage points in fiscal 2019 compared to fiscal 2018.

[0001564590-20-029349:mdna:94]
Sales through our indirect channels represented 79%, 76% and 79% of net revenues in fiscal 2020, 2019 and 2018, respectively.

[0001564590-20-029349:mdna:95]
The following customers, each of which is a distributor, accounted for 10% or more of net revenues:

[0001564590-20-029349:mdna:96]
|  |  | Fiscal Year |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Arrow Electronics, Inc. |  |  | 25 | % |  |  | 24 | % |  |  | 23 | % |
| Tech Data Corporation |  |  | 21 | % |  |  | 20 | % |  |  | 20 | % |

[0001564590-20-029349:mdna:97]
Product Revenues (in millions, except percentages):

[0001564590-20-029349:mdna:98]
|  |  |  | Fiscal Year |  |
|  |  |  | 2020 |  |  | 2019 |  |  | % Change |  |  | 2018 |  |  | % Change |  |
| Product revenues |  |  | $ | 2,995 |  |  | $ | 3,755 |  |  |  | (20 | )% |  | $ | 3,525 |  |  |  | 7 | % |

[0001564590-20-029349:mdna:99]
Product revenues are derived through the sale of our strategic and mature solutions, and consist of sales of configured all-flash array and Hybrid systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, NetApp HCI, StorageGrid, OEM products and add-on optional software.

[0001564590-20-029349:mdna:100]
Under the strategic and mature product groupings, as described in the Executive Overview section above, product revenues from strategic solutions represented 60% of product revenues in fiscal 2020, compared to 56% in fiscal 2019. Product revenues from mature solutions represented 40% of product revenues in fiscal 2020, compared to 44% in fiscal 2019.

[0001564590-20-029349:mdna:101]
Product revenues declined in fiscal 2020 compared to the prior year primarily due to less favorable macroeconomic conditions and lower enterprise IT spending throughout fiscal 2020, and go-to-market execution issues experienced in the first quarter of fiscal 2020 with some of our largest global customer accounts. Additionally, in the fourth quarter of fiscal 2020, increasing macroeconomic uncertainty caused by the COVID-19 pandemic contributed to demand weakness, while associated logistical challenges led to delays in deliveries of products and services to certain customers.

[0001564590-20-029349:mdna:102]
Total product revenues from strategic solutions totaled $1,806 million in fiscal 2020, reflecting a 14% decrease from $2,100 million in fiscal 2019, with sales of most product types declining in the current year. A portion of the decrease was also attributable to substantially lower revenues recognized in fiscal 2020 related to the software license component of ELAs, due to a significant decrease in the aggregate value of new ELAs executed during the current year. Total product revenues from mature solutions totaled $1,189 in fiscal 2020, reflecting a 28% decrease from $1,655 million in fiscal 2019, and a decline in sales of most product types, including our Hybrid FAS and OEM products.

[0001564590-20-029349:mdna:103]
Total product revenues from strategic solutions totaled $2,100 million in fiscal 2019, reflecting a 23% increase from $1,709 million in fiscal 2018. This increase was primarily due to over $100 million of revenues from the software license component of several ELAs in fiscal 2019 which were recognized up-front. Comparable ELA revenues were immaterial in fiscal 2018. Revenues generated from the sale of optional add-on software unrelated to ELAs, and NetApp HCI also increased in fiscal 2019. Total product revenue from mature solutions totaled $1,655 million in fiscal 2019 reflecting a 9% decrease from $1,816 million in fiscal 2018, reflecting the movement of customers to our newer products, partially offset by an increase in add-on hardware, and related OS software revenues.

[0001564590-20-029349:mdna:104]
41

[0001564590-20-029349:mdna:105]
Software Maintenance Revenues (in millions, except percentages):

[0001564590-20-029349:mdna:106]
|  |  |  | Fiscal Year |  |
|  |  |  | 2020 |  |  | 2019 |  |  | % Change |  |  | 2018 |  |  | % Change |  |
| Software maintenance revenues |  |  | $ | 1,034 |  |  | $ | 946 |  |  |  | 9 | % |  | $ | 902 |  |  |  | 5 | % |

[0001564590-20-029349:mdna:107]
Software maintenance revenues are associated with contracts which entitle customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, bug fixes and patch releases, as well as internet and telephone access to technical support personnel located in our global support centers.

[0001564590-20-029349:mdna:108]
The growth in software maintenance revenues reflects the higher aggregate contract value of the installed base under software maintenance contracts, which is recognized as revenue ratably over the terms of the underlying contracts.

[0001564590-20-029349:mdna:109]
Hardware Maintenance and Other Services Revenues (in millions, except percentages):

[0001564590-20-029349:mdna:110]
|  |  |  | Fiscal Year |  |
|  |  |  | 2020 |  |  | 2019 |  |  | % Change |  |  | 2018 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  |  | $ | 1,383 |  |  | $ | 1,445 |  |  |  | (4 | )% |  | $ | 1,492 |  |  |  | (3 | )% |

[0001564590-20-029349:mdna:111]
Hardware maintenance and other services revenues include hardware maintenance, professional services and educational and training services revenues.

[0001564590-20-029349:mdna:112]
Hardware maintenance contract revenues were $1,142 million, $1,182 million and $1,214 million in fiscal 2020, 2019 and 2018, respectively, reflecting a year over year decrease of 4% and 3% in fiscal 2020 and fiscal 2019, respectively. These decreases were primarily attributable to a decline in average selling price (ASP) on contracts executed during those years, as well as lower contract renewal rates in fiscal 2019.

[0001564590-20-029349:mdna:113]
Professional services and educational and training services revenues were $241 million, $263 million and $278 million in fiscal 2020, 2019 and 2018, respectively.

[0001564590-20-029349:mdna:114]
Revenues by Geographic Area:

[0001564590-20-029349:mdna:115]
|  |  | Fiscal Year |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| United States, Canada and Latin America (Americas) |  |  | 53 | % |  |  | 56 | % |  |  | 54 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 32 | % |  |  | 30 | % |  |  | 32 | % |
| Asia Pacific (APAC) |  |  | 15 | % |  |  | 14 | % |  |  | 14 | % |

[0001564590-20-029349:mdna:116]
Percentages may not add due to rounding

[0001564590-20-029349:mdna:117]
Americas revenues consist of sales to Americas commercial and United States (U.S.) public sector markets. During fiscal 2020, Americas revenues were negatively impacted by general macroeconomic conditions in the region and go-to-market execution issues with some of our largest customer accounts in the first quarter of fiscal 2020, which was reflected in the geographic distribution of revenues as a percentage of net revenues in fiscal 2020 compared to fiscal 2019. During fiscal 2019, Americas revenues as a percentage of net revenues increased, reflecting higher product revenues due in part to several large ELAs, while EMEA revenues decreased slightly, primarily reflecting the unfavorable impact of foreign exchange rate fluctuations.

[0001564590-20-029349:mdna:118]
Cost of Revenues

[0001564590-20-029349:mdna:119]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping our storage products, amortization of purchased intangible assets, inventory write-downs, and warranty costs, (2) cost of software maintenance, which includes the costs of providing software maintenance and third-party royalty costs and (3) cost of hardware maintenance and other services revenues, which includes costs associated with providing support activities for hardware maintenance, global support partnership programs, professional services and educational and training services.

[0001564590-20-029349:mdna:120]
42

[0001564590-20-029349:mdna:121]
Cost of Product Revenues (in millions, except percentages):

[0001564590-20-029349:mdna:122]
|  |  |  | Fiscal Year |  |
|  |  |  | 2020 |  |  | 2019 |  |  | % Change |  |  | 2018 |  |  | % Change |  |
| Cost of product revenues |  |  | $ | 1,368 |  |  | $ | 1,752 |  |  |  | (22 | )% |  | $ | 1,738 |  |  |  | 1 | % |

[0001564590-20-029349:mdna:123]
The changes in cost of product revenues consisted of the following (in percentage points of the total change):

[0001564590-20-029349:mdna:124]
|  |  | Fiscal 2020 to Fiscal 2019 |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | (22 | ) |  |  | — |  |
| Other |  |  | — |  |  |  | 1 |  |
| Total change |  |  | (22 | ) |  |  | 1 |  |

[0001564590-20-029349:mdna:125]
Cost of product revenues represented 46%, 47% and 49% of product revenues for fiscal 2020, 2019 and 2018, respectively. Materials cost represented 86%, 90% and 91% of product costs for fiscal 2020, 2019 and 2018, respectively.

[0001564590-20-029349:mdna:126]
Materials costs decreased $393 million in fiscal 2020 compared to fiscal 2019, primarily due to a decline in product revenue and, to a lesser extent, a decline in the price of certain product components. Margins on revenue recognized for strategic solutions were higher in fiscal 2020 compared to fiscal 2019, reflecting a decrease in the average unit materials cost of AFF systems, partially offset by less high-margin revenue related to the software license components of several ELAs.  Margins on revenue recognized for mature solutions were relatively flat in fiscal 2020 compared to fiscal 2019, as the benefit from lower average unit materials costs of FAS Hybrid systems was offset by lower average selling prices.

[0001564590-20-029349:mdna:127]
Materials costs decreased $5 million in fiscal 2019 compared to fiscal 2018, primarily due to a decline in the price of certain product components. The average unit materials costs of our systems decreased slightly in fiscal 2019 compared to fiscal 2018. Margins on revenue recognized for strategic solutions were higher in fiscal 2019 compared to fiscal 2018 primarily due to the benefit of high margins realized on the software license components of several ELAs, and, to a lesser extent, higher ASPs. Margins for mature products also increased slightly in fiscal 2019. Foreign exchange rate fluctuations resulted in a slight unfavorable impact to margins in fiscal 2019.

[0001564590-20-029349:mdna:128]
Cost of Software Maintenance Revenues (in millions, except percentages):

[0001564590-20-029349:mdna:129]
|  |  |  | Fiscal Year |  |
|  |  |  | 2020 |  |  | 2019 |  |  | % Change |  |  | 2018 |  |  | % Change |  |
| Cost of software maintenance revenues |  |  | $ | 48 |  |  | $ | 35 |  |  |  | 37 | % |  | $ | 25 |  |  |  | 40 | % |

[0001564590-20-029349:mdna:130]
Cost of software maintenance revenues represented 5%, 4% and 3% of software maintenance revenues for fiscal 2020, 2019 and 2018, respectively.

[0001564590-20-029349:mdna:131]
Cost of Hardware Maintenance and Other Services Revenues (in millions, except percentages):

[0001564590-20-029349:mdna:132]
|  |  |  | Fiscal Year |  |
|  |  |  | 2020 |  |  | 2019 |  |  | % Change |  |  | 2018 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  |  | $ | 373 |  |  | $ | 414 |  |  |  | (10 | )% |  | $ | 447 |  |  |  | (7 | )% |

[0001564590-20-029349:mdna:133]
Cost of hardware maintenance and other services revenues decreased $41 million, or 10%, in fiscal 2020 compared to fiscal 2019, and decreased $33 million, or 7%, in fiscal 2019 compared to fiscal 2018, primarily due to the favorable impact of cost savings initiatives, and the decrease in hardware maintenance and other services revenues. Costs represented 27%, 29% and 30% of hardware maintenance and other services revenues for fiscal 2020, 2019 and 2018, respectively.

[0001564590-20-029349:mdna:134]
Operating Expenses

[0001564590-20-029349:mdna:135]
Sales and Marketing, Research and Development and General and Administrative Expenses

[0001564590-20-029349:mdna:136]
Compensation costs represent the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0001564590-20-029349:mdna:137]
43

[0001564590-20-029349:mdna:138]
Total compensation costs included in operating expenses decreased $22 million, or 1% during fiscal 2020 compared to fiscal 2019, primarily due to lower incentive compensation expenses reflecting lower operating performance against goals, partially offset by higher salaries, reflecting a 3% increase in average headcount.

[0001564590-20-029349:mdna:139]
Total compensation costs included in operating expenses decreased $15 million, or 1% during fiscal 2019 compared to fiscal 2018, primarily due to lower incentive compensation expenses reflecting lower operating performance against goals, and, to a lesser extent, the favorable impact of foreign exchange rate fluctuations, partially offset by higher salaries and benefits expense, reflecting a slight increase in average headcount.

[0001564590-20-029349:mdna:140]
Sales and Marketing (in millions, except percentages):

[0001564590-20-029349:mdna:141]
|  |  |  | Fiscal Year |  |
|  |  |  | 2020 |  |  | 2019 |  |  | % Change |  |  | 2018 |  |  | % Change |  |
| Sales and marketing expenses |  |  | $ | 1,585 |  |  | $ | 1,657 |  |  |  | (4 | )% |  | $ | 1,706 |  |  |  | (3 | )% |

[0001564590-20-029349:mdna:142]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, allocated facilities and IT support costs, advertising and marketing promotional expense and travel and entertainment expense. The changes in sales and marketing expenses consisted of the following:

[0001564590-20-029349:mdna:143]
|  |  | Fiscal 2020 to Fiscal 2019 |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (1 | ) |  |  | (2 | ) |
| Commissions |  |  | (2 | ) |  |  | — |  |
| Facilities and IT support costs |  |  | — |  |  |  | (1 | ) |
| Other |  |  | (1 | ) |  |  | — |  |
| Total change |  |  | (4 | ) |  |  | (3 | ) |

[0001564590-20-029349:mdna:144]
The decrease in compensation costs in fiscal 2020 compared to fiscal 2019 reflects a slight reduction in average headcount, while the decrease in commissions expense was primarily due to lower performance against sales goals. We incurred $3 million of non-recurring expenses in fiscal 2020, primarily due to the cancellation of a major sales event, as a direct result of the COVID-19 pandemic.

[0001564590-20-029349:mdna:145]
The decrease in compensation costs in fiscal 2019 compared to fiscal 2018 reflects a slight reduction in average headcount and, to a lesser extent, the favorable impact of foreign exchange rate fluctuations. Facilities and IT support costs decreased during fiscal 2019 primarily due to cost containment efforts.

[0001564590-20-029349:mdna:146]
Research and Development (in millions, except percentages):

[0001564590-20-029349:mdna:147]
|  |  |  | Fiscal Year |  |
|  |  |  | 2020 |  |  | 2019 |  |  | % Change |  |  | 2018 |  |  | % Change |  |
| Research and development expenses |  |  | $ | 847 |  |  | $ | 827 |  |  |  | 2 | % |  | $ | 783 |  |  |  | 6 | % |

[0001564590-20-029349:mdna:148]
Research and development expenses consist primarily of compensation costs, allocated facilities and IT support costs, depreciation, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs. Changes in research and development expense consisted of the following:

[0001564590-20-029349:mdna:149]
|  |  | Fiscal 2020 to Fiscal 2019 |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 2 |  |  |  | 3 |  |
| Development projects and outside services |  |  | — |  |  |  | 1 |  |
| Facilities and IT support costs |  |  | — |  |  |  | 2 |  |
| Total change |  |  | 2 |  |  |  | 6 |  |

[0001564590-20-029349:mdna:150]
The increases in compensation costs for fiscal 2020 and fiscal 2019, compared to the respective prior years, were attributable to increases in average headcount of 8% and 7%, respectively, resulting in higher salaries and benefits expense. These increases were partially offset by lower incentive compensation plan expense, though to a greater degree in fiscal 2020 than in fiscal 2019. The

[0001564590-20-029349:mdna:151]
44

[0001564590-20-029349:mdna:152]
average headcount increase in each year reflects our ongoing investment in additional engineering resources to support the expansion and enhancement of products and solutions targeted at our most important customer and market opportunities.

[0001564590-20-029349:mdna:153]
Facilities and IT support costs increased in fiscal 2019 in connection with the increase in average headcount, while in fiscal 2020 incremental projects were not funded in an effort to contain costs.

[0001564590-20-029349:mdna:154]
Development projects and outside services expense increased in fiscal 2019 compared to fiscal 2018 as a result of higher spending on materials and services associated with engineering activities to develop new products and enhance the existing portfolio.

[0001564590-20-029349:mdna:155]
General and Administrative (in millions, except percentages):

[0001564590-20-029349:mdna:156]
|  |  |  | Fiscal Year |  |
|  |  |  | 2020 |  |  | 2019 |  |  | % Change |  |  | 2018 |  |  | % Change |  |
| General and administrative expenses |  |  | $ | 263 |  |  | $ | 278 |  |  |  | (5 | )% |  | $ | 280 |  |  |  | (1 | )% |

[0001564590-20-029349:mdna:157]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and allocated facilities and IT support costs. Changes in general and administrative expense consisted of the following:

[0001564590-20-029349:mdna:158]
|  |  | Fiscal 2020 to Fiscal 2019 |  |  | Fiscal 2019 to Fiscal 2018 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (7 | ) |  |  | (3 | ) |
| Professional and legal fees and outside services |  |  | 5 |  |  |  | 1 |  |
| Facilities and IT support costs |  |  | (3 | ) |  |  | — |  |
| Other |  |  | — |  |  |  | 1 |  |
| Total change |  |  | (5 | ) |  |  | (1 | ) |

[0001564590-20-029349:mdna:159]
The decreases in compensation costs for fiscal 2020 and fiscal 2019, compared to the respective prior years, were primarily attributable to lower incentive compensation plan expense and, for fiscal 2020, lower stock-based compensation expense. While average headcount increased in both fiscal 2020 and fiscal 2019, salaries and benefits expense remained relatively flat as a greater percentage of employees were located in lower cost geographies.

[0001564590-20-029349:mdna:160]
The increases in professional and legal fees and outside services expense in fiscal 2020 and fiscal 2019 were due to higher spending levels on projects and outside services.

[0001564590-20-029349:mdna:161]
The decrease in facilities and IT support costs in fiscal 2020 was primarily due to lower spending levels on IT projects.

[0001564590-20-029349:mdna:162]
Restructuring Charges (in millions, except percentages):

[0001564590-20-029349:mdna:163]
|  |  |  | Fiscal Year |
|  |  |  | 2020 |  |  | 2019 |  |  | % Change |  |  | 2018 |  |  | % Change |
| Restructuring charges |  |  | $ | 21 |  |  | $ | 35 |  |  |  | (40 | )% |  | $ | — |  |  | NM |

[0001564590-20-029349:mdna:164]
NM - Not Meaningful

[0001564590-20-029349:mdna:165]
In an effort to reduce our cost structure and redirect resources to our highest return activities, in fiscal years 2020 and 2019, we initiated a number of business realignment plans designed to streamline our business and focus on key strategic opportunities, resulting in aggregate reductions of our global workforce of approximately 2% in fiscal 2020 and less than 3% in fiscal 2019, for which we recognized aggregate charges of $21 million and $35 million, respectively, consisting primarily of employee severance costs. See Note 13 – Restructuring Charges of the Notes to Consolidated Financial Statements for more details regarding our restructuring plans.

[0001564590-20-029349:mdna:166]
Gain on Sale or Derecognition of Assets (in millions, except percentages):

[0001564590-20-029349:mdna:167]
|  |  |  | Fiscal Year |  |
|  |  |  | 2020 |  |  | 2019 |  |  | % Change |  |  | 2018 |  |  | % Change |  |
| Gain on sale or derecognition of assets |  |  | $ | (38 | ) |  | $ | (73 | ) |  |  | (48 | )% |  | $ | (218 | ) |  |  | (67 | )% |

[0001564590-20-029349:mdna:168]
In September 2017, we entered into an agreement to sell certain properties for a total of $306 million, through two separate and independent closings. During fiscal 2018, the first closing occurred, and we consummated the sale of properties with a net book value of $66 million, for cash proceeds of $210 million, resulting in a gain, net of direct selling costs, of $142 million. During the first

[0001564590-20-029349:mdna:169]
quarter of fiscal 2020, the second closing occurred and we consummated the sale of land, with a net book value of $53 million, and received cash proceeds of $96 million, resulting in a gain, net of direct selling costs, of $38 million.

[0001564590-20-029349:mdna:170]
In addition, during fiscal 2018, our continuing involvement with properties subject to a sale-leaseback arrangement entered into in fiscal 2016 ended, and as a result we recorded non-cash sales of properties, extinguished the associated financing obligations and recognized gains of $76 million.

[0001564590-20-029349:mdna:171]
In February 2019, we contributed cash and other assets with a total book value of $7 million to a newly formed joint venture with Lenovo  in exchange for a non-controlling 49% equity interest in the new entity, Lenovo NetApp Technology Limited (“LNTL”). The value of our equity interest was $80 million, resulting in a gain of $73 million in fiscal 2019.

[0001564590-20-029349:mdna:172]
Other Income (Expense), Net (in millions, except percentages)

[0001564590-20-029349:mdna:173]
The components of other income (expense), net were as follows:

[0001564590-20-029349:mdna:174]
|  |  |  | Fiscal Year |  |
|  |  |  | 2020 |  |  | 2019 |  |  | % Change |  |  | 2018 |  |  | % Change |  |
| Interest income |  |  | $ | 48 |  |  | $ | 88 |  |  |  | (45 | )% |  | $ | 79 |  |  |  | 11 | % |
| Interest expense |  |  |  | (55 | ) |  |  | (58 | ) |  |  | (5 | )% |  |  | (62 | ) |  |  | (6 | )% |
| Other income, net |  |  |  | 6 |  |  |  | 17 |  |  |  | (65 | )% |  |  | 24 |  |  |  | (29 | )% |
| Total |  |  | $ | (1 | ) |  | $ | 47 |  |  | NM |  |  | $ | 41 |  |  |  | 15 | % |

[0001564590-20-029349:mdna:175]
NM - Not Meaningful

[0001564590-20-029349:mdna:176]
Interest income decreased during fiscal 2020 compared to fiscal 2019, primarily due to a reduction in the size of our investment portfolio as a result of our sale of approximately $1.0 billion of available-for-sale debt securities in the first quarter of fiscal 2020 and net maturities over the remainder of the year. Interest income increased during fiscal 2019 compared to fiscal 2018, primarily due to a shift in our investment portfolio to higher-yielding investments, partially offset by a decrease in the size of the portfolio.

[0001564590-20-029349:mdna:177]
Interest expense remained relatively flat in fiscal 2020 compared to fiscal 2019 as we repaid our maturing Senior Notes, but increased our average outstanding commercial paper balance. Interest expense decreased slightly during fiscal 2019 compared to fiscal 2018, primarily due to a reduction in the average amount of interest-bearing debt outstanding.

[0001564590-20-029349:mdna:178]
Other income, net decreased during fiscal 2020 compared to fiscal 2019, primarily due to a $10 million impairment of our equity method investment in LNTL and the net unfavorable impact of foreign exchange rate fluctuations in fiscal 2020, partially offset by a $14 million gain we realized from the sale of approximately $1.0 billion of available-for-sale debt securities. The decrease in other income, net during fiscal 2019 compared to fiscal 2018 was primarily attributable to differences in net foreign exchange gains.

[0001564590-20-029349:mdna:179]
Provision for Income Taxes (in millions, except percentages):

[0001564590-20-029349:mdna:180]
|  |  |  | Fiscal Year |  |
|  |  |  | 2020 |  |  | 2019 |  |  | % Change |  |  | 2018 |  |  | % Change |  |
| Provision for income taxes |  |  | $ | 125 |  |  | $ | 99 |  |  |  | 26 | % |  | $ | 1,083 |  |  |  | (91 | )% |

[0001564590-20-029349:mdna:181]
Our effective tax rate for fiscal 2020 was 13.2% compared to an effective tax rate of 7.8% for fiscal 2019, and an effective tax rate of 90.3% for fiscal 2018. Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. Our effective tax rate for fiscal 2020 was higher than the prior year primarily due to the shift in jurisdictional mix of income resulting in a lower foreign rate differential, a higher global minimum tax on intangible income (GMT) provision, and reduced benefit attributable to stock-based compensation.

[0001564590-20-029349:mdna:182]
Key components of the effective tax rate of 13.2% in fiscal 2020 included a benefit of $61 million, or 6.4 percentage points, related to the lapse of statutes of limitations, an expense of $32 million, or 3.4 percentage points, for GMT, a benefit of $40 million, or 4.2 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 21%, a benefit of $16 million, or 1.7 percentage points, from the generation of federal research credits, an expense of $15 million, or 1.6 percentage points, related to transition tax adjustments, and a benefit of $4 million, or 0.4 percentage points, attributable to stock-based compensation.

[0001564590-20-029349:mdna:183]
Key components of the effective tax rate of 7.8% in fiscal 2019 included a benefit of $84 million, or 6.6 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 21%, a benefit of $48 million, or 3.8 percentage points, related to the effects on the resolution of certain income tax examinations, a benefit of $19 million, or 1.5 percentage points, attributable to stock-based compensation, and a benefit of $17 million, or 1.3 percentage points, from the generation of federal research credits.

[0001564590-20-029349:mdna:184]
Key components of the effective tax rate of 90.3% in fiscal 2018 included a one-time transition tax charge on accumulated foreign earnings of approximately $732 million, or 61.0 percentage points, a charge of $108 million, or 9.0 percentage points, related to the remeasurement of deferred tax assets and liabilities due to tax rate changes, offset by a benefit of $108 million, or 9.0 percentage points, from foreign profits taxed at effective tax rates lower than our blended U.S. federal statutory rate of 30.5%, and a tax benefit of $23 million, or 1.9 percentage points, attributable to stock-based compensation.

[0001564590-20-029349:mdna:185]
During fiscal 2020, we recognized a discrete benefit of $61 million related to the lapse of statutes of limitations on our fiscal 2014 and 2015 federal income tax returns. During fiscal 2019, we recognized a discrete benefit of $48 million arising from the effective settlement of an Internal Revenue Service audit for fiscal 2012 and fiscal 2013. In addition, we are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal 2001, in that we have carryforward attributes from these years that could be subject to adjustment in the tax years of utilization.

[0001564590-20-029349:mdna:186]
On December 22, 2017, the Tax Cuts and Jobs Act (TCJA) was enacted into law. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, the imposition of a one-time transition tax on deferred foreign earnings, and the creation of new taxes on certain foreign-sourced earnings. ASC 740, Income Taxes, requires companies to recognize the effect of the tax law changes in the period of enactment. However, the SEC staff issued Staff Accounting Bulletin 118, which allowed companies to record provisional amounts during a measurement period not to extend beyond one year from the TCJA enactment date.

[0001564590-20-029349:mdna:187]
As a result of the U.S. federal corporate income tax rate change, effective as of January 1, 2018, we remeasured our deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future periods. During fiscal 2018, we recorded $108 million of tax expense related to all tax rate changes. Upon finalization of our provisional estimates during the third quarter of fiscal 2019, we recorded tax expense of $6 million related to deferred tax assets for equity-based compensation awards to our executives.

[0001564590-20-029349:mdna:188]
The TCJA imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits not previously subject to U.S. income tax at a rate of 15.5% on earnings to the extent of foreign cash and other liquid assets, and 8% on the remaining earnings. In fiscal 2018, we recorded a $732 million discrete tax expense for the estimated U.S. federal and state income tax impacts of the transition tax. In the third quarter of fiscal 2019, we finalized our computation of the transition tax and recorded a reduction of $5 million to our provisional estimate.

[0001564590-20-029349:mdna:189]
Under the TCJA, the GMT provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. Under U.S. GAAP, companies are allowed to make an accounting policy election to either (i) account for GMT as a component of tax expense in the period in which a company is subject to the rules, or (ii) account for GMT in a company’s measurement of deferred taxes. We have elected to recognize the GMT as a period cost and thus recorded $32 million and $22 million of tax expense for federal and state impacts for fiscal 2020 and fiscal 2019, respectively.

[0001564590-20-029349:mdna:190]
Liquidity, Capital Resources and Cash Requirements

[0001564590-20-029349:mdna:191]
| (In millions, except percentages) |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Cash, cash equivalents and short-term investments |  | $ | 2,882 |  |  | $ | 3,899 |  |
| Principal amount of debt |  | $ | 1,673 |  |  | $ | 1,799 |  |

[0001564590-20-029349:mdna:192]
The following is a summary of our cash flow activities:

[0001564590-20-029349:mdna:193]
|  |  | Fiscal Year |  |
| (In millions) |  | 2020 |  |  | 2019 |  |
| Net cash provided by operating activities |  | $ | 1,060 |  |  | $ | 1,341 |  |
| Net cash provided by investing activities |  |  | 1,269 |  |  |  | 704 |  |
| Net cash used in financing activities |  |  | (1,960 | ) |  |  | (2,631 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (34 | ) |  |  | (30 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 335 |  |  | $ | (616 | ) |

[0001564590-20-029349:mdna:194]
47

[0001564590-20-029349:mdna:195]
As of April 24, 2020, our cash, cash equivalents and short-term investments totaled $2.9 billion, reflecting a decrease of $1.0 billion from April 26, 2019. The decrease was primarily due to $1.4 billion paid for the repurchase of our common stock, $439 million used for the payment of dividends, $400 million used for the repayment of our Senior Notes due September 2019, and $124 million in purchases of property and equipment, partially offset by $273 million in proceeds from the issuance of commercial paper notes, net, $96 million in proceeds from the sale of properties and $1.1 billion of cash provided by operating activities. Working capital decreased by $1.0 billion to $0.7 billion as of April 24, 2020 primarily due to the decreases in cash, cash equivalents and short-term investments discussed above.

[0001564590-20-029349:mdna:196]
Cash Flows from Operating Activities

[0001564590-20-029349:mdna:197]
During fiscal 2020, we generated cash from operating activities of $1.1 billion, reflecting net income of $819 million, adjusted by non-cash depreciation and amortization of $193 million, stock-based compensation of $153 million and a gain on derecognition of assets of $38 million.

[0001564590-20-029349:mdna:198]
Changes in assets and liabilities during fiscal 2020 included the following:

[0001564590-20-029349:mdna:199]
|  | • | Accounts receivable decreased $238 million, reflecting more favorable shipping linearity and lower billings. |

[0001564590-20-029349:mdna:200]
|  | • | Accounts payable decreased $117 million, reflecting the timing of payments to our suppliers. |

[0001564590-20-029349:mdna:201]
|  | • | Accrued expenses decreased $177 million, primarily due to employee compensation payouts related to fiscal 2019 commissions and incentive compensation plans that exceeded fiscal 2020 accruals. |

[0001564590-20-029349:mdna:202]
|  | • | Long-term taxes payable decreased $163 million, primarily due to resolution of income tax matters and transition taxes associated with U.S. tax reform. |

[0001564590-20-029349:mdna:203]
During fiscal 2019, we generated cash from operating activities of $1.3 billion, reflecting net income of $1.2 billion, adjusted by non-cash depreciation and amortization of $197 million, stock-based compensation of $158 million and a gain on derecognition of assets of $73 million.

[0001564590-20-029349:mdna:204]
Changes in assets and liabilities during fiscal 2019 included the following:

[0001564590-20-029349:mdna:205]
|  | • | Accounts receivable increased $185 million, reflecting less favorable shipping linearity and one of our major distributors choosing not to take advantage of an early payment discount. |

[0001564590-20-029349:mdna:206]
|  | • | Deferred revenue and financed unearned services revenue increased $343 million, primarily due to an increase in deferred software and hardware maintenance contract revenue associated with a growing installed base. |

[0001564590-20-029349:mdna:207]
|  | • | Long-term taxes payable decreased $164 million, primarily due to transition taxes associated with U.S. tax reform. |

[0001564590-20-029349:mdna:208]
We expect that cash provided by operating activities may materially fluctuate in future periods due to a number of factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, vendor payment initiatives, tax benefits or charges from stock-based compensation, and the timing and amount of compensation and other payments.

[0001564590-20-029349:mdna:209]
Cash Flows from Investing Activities

[0001564590-20-029349:mdna:210]
During fiscal 2020, we generated $1.4 billion from maturities and sales of investments, net of purchases and paid $124 million for capital expenditures. Additionally, we received $96 million for the sale of land in Sunnyvale, California and paid $73 million to acquire two privately-held companies.

[0001564590-20-029349:mdna:211]
During fiscal 2019, we generated $876 million from maturities and sales of investments, net of purchases, and paid $173 million for capital expenditures.

[0001564590-20-029349:mdna:212]
48

[0001564590-20-029349:mdna:213]
Cash Flows from Financing Activities

[0001564590-20-029349:mdna:214]
During fiscal 2020, we used $1.4 billion for the purchase of 25 million shares of our common stock, $439 million for the payment of dividends, $400 million for the repayment of our Senior Notes due September 2019, partially offset by $273 million in proceeds from the issuance of commercial paper notes, net and $102 million in proceeds from issuance of common stock under employee common stock award plans.

[0001564590-20-029349:mdna:215]
During fiscal 2019, we used $2.1 billion for the repurchase of 29 million shares of our common stock, $403 million for the payment of dividends, and $136 million for the repayment of commercial paper notes, net, partially offset by $121 million in proceeds from issuance of common stock under employee stock purchase plans.

[0001564590-20-029349:mdna:216]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies, and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including potential future issuances of debt, equity or other securities, will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all. For further discussion of factors that could affect our cash flows and liquidity requirements, including the impact of the COVID-19 pandemic, see Item 1A. Risk Factors.

[0001564590-20-029349:mdna:217]
Liquidity

[0001564590-20-029349:mdna:218]
Our principal sources of liquidity as of April 24, 2020 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001564590-20-029349:mdna:219]
Cash, cash equivalents and short-term investments consisted of the following (in millions):

[0001564590-20-029349:mdna:220]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Cash and cash equivalents |  | $ | 2,658 |  |  | $ | 2,325 |  |
| Short-term investments |  |  | 224 |  |  |  | 1,574 |  |
| Total |  | $ | 2,882 |  |  | $ | 3,899 |  |

[0001564590-20-029349:mdna:221]
As of April 24, 2020 and April 26, 2019, $2.5 billion and $3.7 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.4 billion and $0.2 billion, respectively, were available in the U.S. The TCJA imposed a one-time transition tax on substantially all accumulated foreign earnings through December 31, 2017, and generally allows companies to make distributions of foreign earnings without incurring additional federal taxes. As a part of the recognition of the impacts of the TCJA, we have reviewed our projected global cash requirements and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested.

[0001564590-20-029349:mdna:222]
Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, service interest and principal payments on our debt, fund our stock repurchase program, and pay dividends, as and if declared and invest in critical and complimentary technologies through asset purchases and or business acquisitions, including our recently announced definitive agreement to acquire Spot Inc. a provider of compute management and cost optimization services on the public clouds. For more information, see Note 19 – Subsequent Events of the Notes to Consolidated Financial Statements.

[0001564590-20-029349:mdna:223]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of April 24, 2020.

[0001564590-20-029349:mdna:224]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. Based on past performance

[0001564590-20-029349:mdna:225]
49

[0001564590-20-029349:mdna:226]
and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, business acquisitions, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, and other liquidity requirements associated with our operations. We also have an automatic shelf registration statement on file with the Securities and Exchange Commission (SEC). We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001564590-20-029349:mdna:227]
Senior Notes

[0001564590-20-029349:mdna:228]
The following table summarizes the principal amount of our Senior Notes as of April 24, 2020 (in millions):

[0001564590-20-029349:mdna:229]
| 3.375% Senior Notes Due June 2021 |  | $ | 500 |  |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| Total |  | $ | 1,150 |  |

[0001564590-20-029349:mdna:230]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 9 – Financing Arrangements of the Notes to Consolidated Financial Statements.

[0001564590-20-029349:mdna:231]
Commercial Paper Program and Credit Facility

[0001564590-20-029349:mdna:232]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of April 24, 2020, we had commercial paper notes outstanding with an aggregate principal amount of $523 million, a weighted-average interest rate of 2.01% and maturities primarily less than three months.

[0001564590-20-029349:mdna:233]
In connection with the Program, we have a senior unsecured credit agreement that expires on December 10, 2021. The credit agreement provides a $1.0 billion revolving unsecured credit facility that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes, providing another potential source of liquidity to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement also includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of April 24, 2020, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-20-029349:mdna:234]
Capital Expenditure Requirements

[0001564590-20-029349:mdna:235]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for fiscal 2021 to be between $175 million and $225 million.

[0001564590-20-029349:mdna:236]
Dividends and Stock Repurchase Program

[0001564590-20-029349:mdna:237]
On May 26, 2020, we declared a cash dividend of $0.48 per share of common stock, payable on July 29, 2020 to holders of record as of the close of business on July 10, 2020.

[0001564590-20-029349:mdna:238]
As of April 24, 2020, our Board of Directors had authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through April 24, 2020, we repurchased a total of 338 million shares of our common stock at an average price of $38.86 per share, for an aggregate purchase price of $13.1 billion. As of April 24, 2020, the remaining authorized amount for stock repurchases under this program was $0.5 billion.

[0001564590-20-029349:mdna:239]
During the first quarter of fiscal 2021, we announced the suspension of our stock repurchases to strengthen our liquidity position given the uncertainty surrounding the overall impact of the ongoing COVID-19 pandemic. The timing and amount of stock repurchase transactions and future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements.

[0001564590-20-029349:mdna:240]
Contractual Obligations

[0001564590-20-029349:mdna:241]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. The following table summarizes our contractual obligations at April 24, 2020 (in millions):

[0001564590-20-029349:mdna:242]
|  |  |  | 2021 |  |  |  | 2022 |  |  |  | 2023 |  |  |  | 2024 |  |  |  | 2025 |  |  | Thereafter |  |  | Total |  |
| Purchase commitments with contract manufacturers and component suppliers (1) |  | $ | 479 |  |  | $ | 39 |  |  | $ | 42 |  |  | $ | 44 |  |  | $ | 47 |  |  | $ | — |  |  | $ | 651 |  |
| Other purchase obligations (2) |  |  | 133 |  |  |  | 34 |  |  |  | 11 |  |  |  | 7 |  |  |  | 4 |  |  |  | 4 |  |  |  | 193 |  |
| Total off-balance sheet commitments |  |  | 612 |  |  |  | 73 |  |  |  | 53 |  |  |  | 51 |  |  |  | 51 |  |  |  | 4 |  |  |  | 844 |  |
| Commercial paper notes (3) |  |  | 523 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 523 |  |
| Long-term debt obligations (4) |  |  | 38 |  |  |  | 530 |  |  |  | 271 |  |  |  | 13 |  |  |  | 407 |  |  |  | — |  |  |  | 1,259 |  |
| Long-term financing arrangements |  |  | 3 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3 |  |
| Uncertain tax positions (5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 136 |  |
| Total contractual obligations |  | $ | 1,176 |  |  | $ | 603 |  |  | $ | 324 |  |  | $ | 64 |  |  | $ | 458 |  |  | $ | 4 |  |  | $ | 2,765 |  |

[0001564590-20-029349:mdna:243]
| (1) | Contract manufacturer and component supplier commitments consist of obligations for on-hand inventories and non-cancelable purchase orders with our contract manufacturers and component suppliers. We record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers and component suppliers for quantities in excess of our future demand forecasts. As of April 24, 2020, such liability amounted to $6 million and is included in accrued expenses in our consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. |

[0001564590-20-029349:mdna:244]
| (2) | Other purchase obligations represent an estimate of all open purchase orders and contractual obligations associated with our ordinary course of business, excluding inventory commitments with contract manufacturers and component suppliers, for which we have not received the goods or services. Purchase obligations do not include contracts that may be canceled without penalty. Although open purchase orders are considered enforceable and legally binding, the terms generally allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services. |

[0001564590-20-029349:mdna:245]
| (3) | Represents principal payments on our commercial paper notes. |

[0001564590-20-029349:mdna:246]
| (4) | Included in long-term debt are obligations related to our $1.2 billion principal amount of our Senior Notes, of which $500 million is due in June 2021, $250 million is due in December 2022 and $400 million is due in September 2024. Estimated interest payments for our long-term debt, assuming no early retirement of debt obligations, are $109 million for fiscal 2021 through fiscal 2025. |

[0001564590-20-029349:mdna:247]
| (5) | As of April 24, 2020, our liability for uncertain tax positions was $136 million, including interest, penalties and certain income tax benefits, which due to the uncertainty of the timing of future payments, is presented in the total column on a separate line in this table. |

[0001564590-20-029349:mdna:248]
Some of the amounts in the table above are based on management’s estimates and assumptions, including the commitment duration, the possibility of renewal or termination, anticipated actions by management and third parties and other factors. Because these estimates and assumptions are subjective, our actual future obligations may vary from those reflected in the table.

[0001564590-20-029349:mdna:249]
Financing Guarantees

[0001564590-20-029349:mdna:250]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $59 million and $87 million of receivables during fiscal 2020 and 2019, respectively.

[0001564590-20-029349:mdna:251]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-20-029349:mdna:252]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we recognize revenues in accordance with our revenue recognition policy, as updated to reflect the adoption of ASC 606. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of April 24, 2020 and April 26, 2019, the aggregate amount by which such contingencies exceeded the associated

[0001564590-20-029349:mdna:253]
51

[0001564590-20-029349:mdna:254]
liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-20-029349:mdna:255]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of April 24, 2020, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0001564590-20-029349:mdna:256]
Off-Balance Sheet Arrangements

[0001564590-20-029349:mdna:257]
Our off-balance sheet arrangements with suppliers are discussed in the contractual obligations section above. Additionally, we enter into indemnification agreements with third parties in the ordinary course of business. Generally, these indemnification agreements require us to reimburse losses suffered by the third-parties due to various events, such as lawsuits arising from patent or copyright infringement. These indemnification obligations are considered off-balance sheet arrangements under accounting guidance.

[0001564590-20-029349:mdna:258]
Legal Contingencies

[0001564590-20-029349:mdna:259]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 18 – Commitments and Contingencies of the Notes to Consolidated Financial Statements.
