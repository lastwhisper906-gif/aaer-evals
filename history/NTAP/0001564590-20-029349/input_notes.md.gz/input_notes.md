# NTAP notes — 0001564590-20-029349


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001564590-20-029349:notes:1]
The information called for by Part III of this Form 10-K is hereby incorporated by reference from the definitive Proxy Statement for our annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after April 24, 2020.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-20-029349:notes:2]
1. Description of Business and Significant Accounting Policies

[0001564590-20-029349:notes:3]
Description of Business — NetApp, Inc. (we, us, or the Company) provides global organizations the ability to manage and share their data across on-premises, private and public clouds. Together with our partners, we provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.

[0001564590-20-029349:notes:4]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2020, which ended on April 24, 2020, fiscal year 2019, which ended on April 26, 2019, and fiscal year 2018, which ended on April 27, 2018, were all 52-week years. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended on the last Friday of April and the associated quarters, months and periods of those fiscal years.

[0001564590-20-029349:notes:5]
Principles of Consolidation — The consolidated financial statements include the Company and its subsidiaries. Intercompany accounts and transactions are eliminated in consolidation.

[0001564590-20-029349:notes:6]
Accounting Changes

[0001564590-20-029349:notes:7]
In February 2016, the FASB issued an accounting standards update on financial reporting for leasing arrangements, including requiring lessees to recognize an operating lease with a term greater than one year on their balance sheets as a right-of-use (ROU) asset and corresponding lease liability, measured at the present value of the lease payments. In the first quarter of fiscal 2020, we adopted this new standard using the modified retrospective approach, electing the optional transition approach of not adjusting our comparative period financial statements for the impacts of adoption. We also elected the package of practical expedients that did not require us to reassess existing leases under the new guidance, and the practical expedient to not separate lease and non-lease components for all leases. Adoption of the new standard during the first quarter of fiscal 2020 resulted in the recognition of approximately $149 million of operating lease ROU assets, net of deferred rent and lease restructuring liabilities, $158 million of lease liabilities, and a cumulative-effect adjustment to retained earnings of $6 million on our consolidated balance sheets. Adoption of the standard did not have a material impact on our consolidated statements of operations or consolidated statements of cash flows. Additional information is presented below and in Note 10 – Leases.

[0001564590-20-029349:notes:8]
Use of Estimates — The preparation of the consolidated financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, including impacts from the COVID-19 pandemic, the anticipated effects of which have been incorporated, as applicable, into management’s estimates as of and for the year ended April 24, 2020.

[0001564590-20-029349:notes:9]
Cash Equivalents — We consider all highly liquid debt investments with original maturities of three months or less at the time of purchase to be cash equivalents.

[0001564590-20-029349:notes:10]
Available-for-Sale Investments — We classify our investments in debt securities as available-for-sale investments. Debt securities primarily consist of corporate bonds, U.S. Treasury and government debt securities and certificates of deposit. These available-for-sale investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of debt securities sold. These investments are recorded in the consolidated balance sheets at fair value.

[0001564590-20-029349:notes:11]
Unrealized gains and temporary losses, net of related taxes, are included in accumulated other comprehensive income (loss) (AOCI). Upon realization, those amounts are reclassified from AOCI to earnings. The amortization of premiums and discounts on the investments are included in our results of operations. Realized gains and losses on our available-for-sale investments are calculated based on the specific identification method.

[0001564590-20-029349:notes:12]
We classify our investments as current or noncurrent based on the nature of the investments and their availability for use in current operations.

[0001564590-20-029349:notes:13]
Other-than-Temporary Impairments on Investments — All of our available-for-sale investments are subject to periodic impairment review. When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and we assess whether the

[0001564590-20-029349:notes:14]
impairment is other-than-temporary. An impairment is considered other-than-temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of the entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost basis of the security. If impairment is considered other-than-temporary based on condition (i) or (ii) described above, the entire difference between the amortized cost and the fair value of the debt security is recognized in the results of operations. If an impairment is considered other-than-temporary based on condition (iii) described above, the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in earnings, and the amount relating to all other factors is recognized in other comprehensive income (OCI).

[0001564590-20-029349:notes:15]
Inventories — Inventories are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. We write down excess and obsolete inventory based on the difference between the cost of inventory and the estimated net realizable value based upon assumptions about future demand forecasts and market conditions. At the point of a loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts or circumstances do not result in the restoration or increase in that newly established basis. In addition, we record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0001564590-20-029349:notes:16]
Property and Equipment — Property and equipment are recorded at cost.

[0001564590-20-029349:notes:17]
Depreciation and amortization is computed using the straight-line method, generally over the following periods:

[0001564590-20-029349:notes:18]
|  |  | Depreciation Life |
| Buildings and improvements |  | 10 to 40 years |
| Furniture and fixtures |  | 5 years |
| Computer, production, engineering and other equipment |  | 2 to 3 years |
| Computer software |  | 3 to 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |

[0001564590-20-029349:notes:19]
Construction in progress will be depreciated over the estimated useful lives of the respective assets when they are ready for use. We capitalize interest on significant facility assets under construction and on significant software development projects.

[0001564590-20-029349:notes:20]
Software Development Costs — The costs for the development of new software products and substantial enhancements to existing software products are expensed as incurred until technological feasibility has been established, at which time any additional costs would be capitalized in accordance with the accounting guidance for software. Because our current process for developing software is essentially completed concurrently with the establishment of technological feasibility, which occurs upon the completion of a working model, no costs have been capitalized for any of the periods presented.

[0001564590-20-029349:notes:21]
Internal-Use Software Development Costs — We capitalize qualifying costs, which are incurred during the application development stage, for computer software developed or obtained for internal-use and amortize them over the software’s estimated useful life.

[0001564590-20-029349:notes:22]
Business Combinations — We recognize identifiable assets acquired and liabilities assumed at their acquisition date fair values. Goodwill as of the acquisition date is measured as the excess of consideration transferred over the net of the acquisition date fair values of the assets acquired and the liabilities assumed. While we use our best estimates and assumptions as a part of the purchase price allocation process to accurately value assets acquired and liabilities assumed at the acquisition date, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001564590-20-029349:notes:23]
Goodwill and Purchased Intangible Assets — Goodwill is recorded when the consideration paid for an acquisition exceeds the fair value of net tangible and intangible assets acquired. Purchased intangible assets with finite lives are generally amortized on a straight-line basis over their economic lives of three to five years for developed technology, two to five years for customer contracts/relationships, two to three years for covenants not to compete and two to five years for trademarks and trade names as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. In-process research and development is accounted for as an indefinite lived intangible asset and is assessed for potential impairment annually until development is complete or when events or circumstances indicate that their carrying amounts might be impaired. Upon completion of development, in-process research and development is accounted for as a finite-lived intangible asset.

[0001564590-20-029349:notes:24]
The carrying value of goodwill is tested for impairment on an annual basis in the fourth quarter of our fiscal year, or more frequently if we believe indicators of impairment exist. Triggering events for impairment reviews may be indicators such as adverse

[0001564590-20-029349:notes:25]
industry or economic trends, restructuring actions, lower projections of profitability, or a sustained decline in our market capitalization. For the purpose of impairment testing, we have a single reporting unit. The performance of the quantitative impairment test requires comparing the fair value of our reporting unit to its carrying amount, including goodwill. The fair value of our reporting unit is based on our entity level market capitalization, as determined through quoted market prices. An impairment exists if the fair value of our reporting unit is lower than its carrying amount. The impairment loss is measured based on the amount by which the carrying amount of our reporting unit exceeds its fair value, with the recognized loss not to exceed the total amount of goodwill. The fair value of our reporting unit has substantially exceeded its carrying amount in all periods presented.

[0001564590-20-029349:notes:26]
Impairment of Long-Lived Assets — We review the carrying values of long-lived assets whenever events and circumstances, such as reductions in demand, lower projections of profitability, significant changes in the manner of our use of acquired assets, or significant negative industry or economic trends, indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. If this review indicates that there is an impairment, the impaired asset is written down to its fair value, which is typically calculated using: (i) quoted market prices and/or (ii) expected future cash flows utilizing a discount rate. Our estimates regarding future anticipated cash flows, the remaining economic life of the products and technologies, or both, may differ from those used to assess the recoverability of assets. In that event, impairment charges or shortened useful lives of certain long-lived assets may be required, resulting in charges to our consolidated statements of operations when such determinations are made.

[0001564590-20-029349:notes:27]
Derivative Instruments — Our derivative instruments, which are carried at fair value in our consolidated balance sheets, consist of foreign currency exchange contracts as described below:

[0001564590-20-029349:notes:28]
Balance Sheet Hedges — We utilize foreign currency exchange forward and option contracts to hedge against the short-term impact of foreign currency exchange rate fluctuations related to certain foreign currency denominated monetary assets and liabilities, primarily intercompany receivables and payables. These derivative instruments are not designated as hedging instruments and do not subject us to material balance sheet risk due to exchange rate movements because the gains and losses on these contracts are intended to offset the gains and losses in the underlying foreign currency denominated monetary assets and liabilities being hedged, and the net amount is included in earnings.

[0001564590-20-029349:notes:29]
Cash Flow Hedges — We utilize foreign currency exchange forward contracts to hedge foreign currency exchange exposures related to forecasted sales transactions denominated in certain foreign currencies. These derivative instruments are designated and qualify as cash flow hedges and, in general, closely match the underlying forecasted transactions in duration. The effective portion of the contracts’ gains and losses resulting from changes in fair value is recorded in AOCI until the forecasted transaction is recognized in the consolidated statements of operations. When the forecasted transactions occur, we reclassify the related gains or losses on the cash flow hedges into net revenues. If the underlying forecasted transactions do not occur, or it becomes probable that they will not occur within the defined hedge period, the gains or losses on the related cash flow hedges are reclassified from AOCI and recognized immediately in earnings. We measure the effectiveness of hedges of forecasted transactions on a monthly basis by comparing the fair values of the designated foreign currency exchange forward purchase contracts with the fair values of the forecasted transactions. Any ineffective portion of the derivative hedging gain or loss, as well as changes in the fair value of the derivative’s time value (which are excluded from the assessment of hedge effectiveness), are recognized in earnings.

[0001564590-20-029349:notes:30]
Factors that could have an impact on the effectiveness of our hedging programs include the accuracy of forecasts and the volatility of foreign currency markets. These programs reduce, but do not entirely eliminate, the impact of currency exchange movements. Currently, we do not enter into any foreign currency exchange forward contracts to hedge exposures related to firm commitments. Cash flows from our derivative programs are included under operating activities in the consolidated statements of cash flows.

[0001564590-20-029349:notes:31]
Revenue Recognition — We recognize revenue by applying the following five step approach.

[0001564590-20-029349:notes:32]
|  | • | Identification of the contract, or contracts, with a customer — A contract with a customer is within the scope of ASC 606 when it meets all the following criteria: |

[0001564590-20-029349:notes:33]
|  | - | It is enforceable |

[0001564590-20-029349:notes:34]
|  | - | It defines each party’s rights |

[0001564590-20-029349:notes:35]
|  | - | It identifies the payment terms |

[0001564590-20-029349:notes:36]
|  | - | It has commercial substance, and |

[0001564590-20-029349:notes:37]
|  | - | We determine that collection of substantially all consideration for goods or services that will be transferred is probable based on the customer’s intent and ability to pay |

[0001564590-20-029349:notes:38]
|  | • | Identification of the performance obligations in the contract — Performance obligations promised in a contract are identified based on the goods or services (or a bundle of goods and services) that will be transferred to the customer that are distinct. |

[0001564590-20-029349:notes:39]
|  | • | Determination of the transaction price — The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer. |

[0001564590-20-029349:notes:40]
|  | • | Allocation of the transaction price to the performance obligations in the contract — Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation. |

[0001564590-20-029349:notes:41]
|  | • | Recognition of revenue when, or as, we satisfy a performance obligation — We satisfy performance obligations either over time or at a point in time. |

[0001564590-20-029349:notes:42]
Customarily we have a purchase order from or executed contract with our customers that establishes the goods and services to be transferred and the consideration to be received.

[0001564590-20-029349:notes:43]
We combine two or more contracts entered into at or near the same time with the same customer as a single contract if the contracts are negotiated as one package with a single commercial objective, if the amount of consideration to be paid on one contract depends on the price or performance of the other contract or if the goods and services promised in each of the contracts are a single performance obligation.

[0001564590-20-029349:notes:44]
Our contracts with customers may include hardware systems, software licenses, software maintenance, hardware maintenance and other services. Software maintenance contracts entitle our customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, and patch releases. Hardware maintenance services include contracts for extended warranty and technical support with minimum response times. Other services include professional services and customer education and training services.

[0001564590-20-029349:notes:45]
We identify performance obligations in our contracts to be those goods and services that are distinct. A good or service is distinct where the customer can benefit from the good or service either on its own or together with other resources that are readily available from third parties or from us, and is distinct in the context of the contract, where the transfer of the good or service is separately identifiable from other promises in the contract.

[0001564590-20-029349:notes:46]
If a contract includes multiple promised goods or services, we apply judgment to determine whether promised goods or services are distinct. If they are not, we combine the goods and services until we have a distinct performance obligation. A configured storage system inclusive of the operating system (OS) software essential to its functionality is considered a single performance obligation, while optional add-on software is a separate performance obligation. In general, hardware maintenance, software maintenance, and different types of professional services are each separate performance obligations.

[0001564590-20-029349:notes:47]
In certain instances, we enter into enterprise license agreements (ELAs) with our customers which transfer to them the right to deploy an unlimited or capped number of OS or optional add-on software licenses and obligate us to provide software maintenance through the ELA term. In general, we treat the software license component and software maintenance component of ELAs as separate performance obligations.

[0001564590-20-029349:notes:48]
We determine the transaction price of our contracts with customers based on the consideration to which we will be entitled in exchange for transferring goods or services. Consideration promised may include fixed amounts, variable amounts or both. We sell professional services either on a time and materials basis or under fixed price projects.

[0001564590-20-029349:notes:49]
We evaluate variable consideration in arrangements with contract terms such as rights of return, potential penalties and acceptance clauses. We generally use the expected value method, primarily relying on our history, to estimate variable consideration. However, when we believe it to provide a better estimate, we use the most likely amount method. In either case, we consider variable consideration only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recognized will not occur. Reassessments of our variable consideration may occur as historical information changes. Transaction prices are also adjusted for the effects of time value of money if the timing of payments provides either the customer or us a significant benefit of financing.

[0001564590-20-029349:notes:50]
Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation on a relative standalone selling price basis. We determine standalone selling price based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price taking into account available information such as market data and other observable inputs. We regularly review standalone selling prices and maintain internal controls over the establishment and updates of these estimates. Variable consideration is also allocated to the performance obligations. If the terms of variable consideration relate to one performance obligation, it is entirely allocated to that obligation. Otherwise, it is allocated to all the performance obligations in the contract.

[0001564590-20-029349:notes:51]
We typically recognize revenue at a point in time upon the transfer of goods to a customer. Products we transfer at a point in time include our configured hardware systems, OS software licenses, optional add-on software licenses and add-on hardware. Services are typically transferred over time and revenue is recognized based on an appropriate method for measuring our progress toward completion of the performance obligation. Our stand-ready services, including both hardware and software maintenance support, are transferred ratably over the period of the contract. For other services such as our fixed professional services contracts, we use an input

[0001564590-20-029349:notes:52]
method to determine the percentage of completion. That is, we estimate the effort to date versus the expected effort required over the life of the contract.

[0001564590-20-029349:notes:53]
Deferred Commissions – We capitalize sales commissions that are incremental direct costs of obtaining customer contracts for which revenue is not immediately recognized and classify them as current or non-current based on the terms of the related contracts. Capitalized commissions are amortized based on the transfer of goods or services to which they relate, typically over one to three years, and are also periodically reviewed for impairment. Amortization expense is recorded to sales and marketing expense in our consolidated statements of operations.

[0001564590-20-029349:notes:54]
Product Warranties — Estimated future hardware and software warranty costs are recorded as a cost of product revenues at the time of product shipment, based on historical and projected warranty claim rates, historical and projected cost-per-claim and knowledge of specific product failures that are outside our typical experience. Factors that affect our warranty liability include the number of installed units subject to warranty protection, product failure rates, and estimated materials, distribution and labor costs. We assess the adequacy of our warranty accrual each quarter and adjust the amount as considered necessary.

[0001564590-20-029349:notes:55]
Leases − We determine if an arrangement is or contains a lease at inception, and we classify leases as operating or finance leases at commencement. In our consolidated balance sheets, operating lease ROU assets are included in other non-current assets, while finance lease ROU assets are included in property and equipment, net. Lease liabilities for both types of leases are included in accrued expenses and other long-term liabilities. ROU assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over that term.

[0001564590-20-029349:notes:56]
Operating and finance lease ROU assets and liabilities are recognized at commencement based on the present value of lease payments over the lease term. ROU assets also include any lease payments made prior to lease commencement and exclude lease incentives. The lease term is the noncancelable period of the lease and includes options to extend or terminate the lease when it is reasonably certain that an option will be exercised. As the rate implicit in our leases is typically not readily determinable, in computing the present value of lease payments we generally use our incremental borrowing rate based on information available at the commencement date. Variable lease payments not dependent on an index or rate are expensed as incurred and not included within the calculation of ROU assets and lease liabilities. Lease expense for lease payments is recognized on a straight-line basis over the lease term.

[0001564590-20-029349:notes:57]
We do not separate non-lease components from lease components for any class of leases, and we do not recognize ROU assets and lease liabilities for leases with a lease term of twelve months or less.

[0001564590-20-029349:notes:58]
Foreign Currency Translation — For international subsidiaries whose functional currency is the local currency, gains and losses resulting from translation of these foreign currency financial statements into U.S. dollars are recorded in AOCI. For subsidiaries where the functional currency is the U.S. dollar, gains and losses resulting from the process of remeasuring foreign currency financial statements into U.S. dollars are included in other income (expense), net.

[0001564590-20-029349:notes:59]
Benefit Plans — We record actuarial gains and losses associated with defined benefit plans within AOCI and amortize net gains or losses in excess of 10 percent of the greater of the market value of plan assets or the plans' projected benefit obligation on a straight-line basis over the remaining estimated service life of plan participants. The measurement date for all defined benefit plans is our fiscal year end.

[0001564590-20-029349:notes:60]
Stock-Based Compensation — We measure and recognize stock-based compensation for all stock-based awards, including employee stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and rights to purchase shares under our employee stock purchase plan (ESPP), based on their estimated fair value, and recognize the costs in our financial statements using the single option straight-line approach over the requisite service period for the entire award.

[0001564590-20-029349:notes:61]
The fair value of employee time-based RSUs, and PBRSUs that include a performance condition, is equal to the market value of our common stock on the grant date of the award, less the present value of expected dividends during the vesting period, discounted at a risk-free interest rate. The fair value of PBRSUs that include a market condition is measured using a Monte Carlo simulation model on the date of grant.

[0001564590-20-029349:notes:62]
The fair value of time-based RSUs, and PBRSUs that include a market condition, is not remeasured as a result of subsequent stock price fluctuations. The fair value of PBRSUs that include a performance condition is remeasured when there is a change in management’s estimate of expected achievement relative to the performance target, resulting in the recognition of a cumulative adjustment of stock-based compensation expense.

[0001564590-20-029349:notes:63]
Our expected term assumption is based primarily on historical exercise and post-vesting forfeiture experience. Our stock price volatility assumption is based on a combination of our historical and implied volatility. The risk-free interest rates are based upon United States (U.S.) Treasury bills with equivalent expected terms, and the expected dividends are based on our history and expected dividend payouts.

[0001564590-20-029349:notes:64]
We account for forfeitures of stock-based awards as they occur.

[0001564590-20-029349:notes:65]
Income Taxes — Deferred income tax assets and liabilities are provided for temporary differences that will result in tax deductions or income in future periods, as well as the future benefit of tax credit carryforwards. A valuation allowance reduces tax assets to their estimated realizable value.

[0001564590-20-029349:notes:66]
We recognize the tax liability for uncertain income tax positions on the income tax return based on the two-step process prescribed in the interpretation. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. We recognize interest and penalties related to unrecognized tax benefits within the income tax expense line in the accompanying consolidated statements of operations.

[0001564590-20-029349:notes:67]
Net Income per Share — Basic net income per share is computed by dividing income available to common stockholders by the weighted-average number of common shares outstanding. Diluted net income per share is computed giving effect to all dilutive potential shares that were outstanding during the period. Potential dilutive common shares consist primarily of outstanding stock options, shares to be purchased under our employee stock purchase plan and unvested RSUs.

[0001564590-20-029349:notes:68]
Treasury Stock — We account for treasury stock under the cost method. Upon the retirement of treasury stock, we allocate the value of treasury shares between common stock, additional paid-in capital and retained earnings.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-20-029349:notes:69]
3. Concentration of Risk

[0001564590-20-029349:notes:70]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, investments, foreign currency exchange contracts and accounts receivable. Cash equivalents and short-term investments consist primarily of corporate bonds, U.S. Treasury and government debt securities and certificates of deposit, all of which are considered high investment grade. Our policy is to limit the amount of credit exposure through diversification and investment in highly rated securities. We further mitigate concentrations of credit risk in our investments by limiting our investments in the debt securities of a single issuer and by diversifying risk across geographies and type of issuer. The COVID-19 pandemic has led to an increase in market volatility and liquidity challenges for certain companies. However, it has not currently resulted in a material increase in the credit risk associated with our financial instruments.

[0001564590-20-029349:notes:71]
By entering into foreign currency exchange contracts, we have assumed the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and we do not expect any losses as a result of counterparty defaults.

[0001564590-20-029349:notes:72]
We sell our products primarily to large organizations in different industries and geographies. We do not require collateral or other security to support accounts receivable. In addition, we maintain an allowance for potential credit losses. To reduce credit risk, we perform ongoing credit evaluations on our customers’ financial condition. We establish an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information, including the expected impact of macroeconomic disruptions such as the COVID-19 pandemic, and, to date, such losses have been within management’s expectations. Concentrations of credit risk with respect to trade accounts receivable are limited due to the wide variety of customers who are dispersed across many geographic regions.

[0001564590-20-029349:notes:73]
There are no concentrations of business transacted with a particular market that would severely impact our business in the near term. However, we rely on a limited number of suppliers for certain key components and a few key contract manufacturers to manufacture most of our products; any disruption, including as a result of the COVID-19 pandemic, or termination of these arrangements could materially adversely affect our operating results.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-20-029349:notes:74]
4. Business Combinations

[0001564590-20-029349:notes:75]
Fiscal 2020 Acquisitions

[0001564590-20-029349:notes:76]
On March 6, 2020, we acquired all the outstanding shares of privately-held Talon Storage Solutions, Inc., a provider of next generation software-defined storage solutions, for $23 million in cash.

[0001564590-20-029349:notes:77]
The preliminary acquisition date fair values of the assets acquired and liabilities assumed are as follows (in millions):

[0001564590-20-029349:notes:78]
| Cash |  | $ | 2 |  |
| Developed technology intangible asset |  |  | 6 |  |
| Customer contracts/relationships |  |  | 4 |  |
| Other assets |  |  | 4 |  |
| Goodwill |  |  | 13 |  |
| Total assets acquired |  |  | 29 |  |
| Liabilities assumed |  |  | (6 | ) |
| Total purchase price |  | $ | 23 |  |

[0001564590-20-029349:notes:79]
On May 23, 2019, we acquired all the outstanding shares of privately-held Cognigo Research Ltd., a provider of data discovery classification software designed to manage and protect critical data, for $53 million in cash.

[0001564590-20-029349:notes:80]
The acquisition date fair values of the assets acquired and liabilities assumed are as follows (in millions):

[0001564590-20-029349:notes:81]
| Cash |  | $ | 2 |  |
| Developed technology intangible asset |  |  | 26 |  |
| Goodwill |  |  | 30 |  |
| Total assets acquired |  |  | 58 |  |
| Liabilities assumed |  |  | (5 | ) |
| Total purchase price |  | $ | 53 |  |

[0001564590-20-029349:notes:82]
Fiscal 2019 Acquisition

[0001564590-20-029349:notes:83]
On September 17, 2018, we acquired all of the outstanding shares of a privately-held software company for $3 million in cash. Substantially all of the purchase price was recorded to goodwill.

[0001564590-20-029349:notes:84]
Fiscal 2018 Acquisitions

[0001564590-20-029349:notes:85]
On August 4, 2017, we acquired all of the outstanding shares of Greenqloud ehf., a privately-held provider of cloud management software based in Iceland, for $51 million in cash, of which we allocated $10 million to developed technology, $38 million to goodwill, and the remainder to other assets.

[0001564590-20-029349:notes:86]
On June 15, 2017, we acquired all of the outstanding shares of Plexistor Ltd., a privately-held provider of software defined memory architecture based in Israel, for $24 million in cash, of which we allocated $6 million to developed technology, $17 million to goodwill, and the remainder to other assets.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-20-029349:notes:87]
5. Goodwill and Purchased Intangible Assets, Net

[0001564590-20-029349:notes:88]
Goodwill activity is summarized as follows (in millions):

[0001564590-20-029349:notes:89]
| Balance as of April 27, 2018 |  | $ | 1,739 |  |
| Additions |  |  | 3 |  |
| Derecognition |  |  | (7 | ) |
| Balance as of April 26, 2019 |  |  | 1,735 |  |
| Additions |  |  | 43 |  |
| Balance as of April 24, 2020 |  | $ | 1,778 |  |

[0001564590-20-029349:notes:90]
We derecognized goodwill during fiscal 2019 in connection with our contribution of a group of assets to a newly formed joint venture with Lenovo in exchange for a non-controlling ownership interest in the new entity. Refer to Note 6 – Supplemental Financial Information for additional details.

[0001564590-20-029349:notes:91]
Purchased intangible assets, net are summarized below (in millions):

[0001564590-20-029349:notes:92]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 192 |  |  | $ | (152 | ) |  | $ | 40 |  |  | $ | 160 |  |  | $ | (113 | ) |  | $ | 47 |  |
| Customer contracts/relationships |  |  | 4 |  |  |  | — |  |  |  | 4 |  |  |  | 41 |  |  |  | (41 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 196 |  |  | $ | (152 | ) |  | $ | 44 |  |  | $ | 201 |  |  | $ | (154 | ) |  | $ | 47 |  |

[0001564590-20-029349:notes:93]
Amortization expense for purchased intangible assets is summarized below (in millions):

[0001564590-20-029349:notes:94]
|  |  | Year Ended |  |  | Statement of |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |  | Operations Classifications |
| Developed technology |  | $ | 39 |  |  | $ | 36 |  |  | $ | 36 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | — |  |  |  | 10 |  |  |  | 14 |  |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | — |  |  |  | 3 |  |  | Operating expenses |
| Total |  | $ | 39 |  |  | $ | 46 |  |  | $ | 53 |  |  |  |

[0001564590-20-029349:notes:95]
As of April 24, 2020, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-20-029349:notes:96]
| Fiscal Year |  | Amount |
| 2021 |  | 28 |
| 2022 |  | 12 |
| Thereafter |  | 4 |
| Total |  | 44 |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-20-029349:notes:97]
6. Supplemental Financial Information

[0001564590-20-029349:notes:98]
Cash and cash equivalents (in millions):

[0001564590-20-029349:notes:99]
The following table presents cash and cash equivalents as reported in our consolidated balance sheets, as well as the sum of cash, cash equivalents and restricted cash as reported on our consolidated statement of cash flows:

[0001564590-20-029349:notes:100]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Cash and cash equivalents |  | $ | 2,658 |  |  | $ | 2,325 |  |
| Restricted cash |  |  | 8 |  |  |  | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,666 |  |  | $ | 2,331 |  |

[0001564590-20-029349:notes:101]
Inventories (in millions):

[0001564590-20-029349:notes:102]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Purchased components |  | $ | 28 |  |  | $ | 8 |  |
| Finished goods |  |  | 117 |  |  |  | 123 |  |
| Inventories |  | $ | 145 |  |  | $ | 131 |  |

[0001564590-20-029349:notes:103]
Property and equipment, net (in millions):

[0001564590-20-029349:notes:104]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Land |  | $ | 103 |  |  | $ | 106 |  |
| Buildings and improvements |  |  | 597 |  |  |  | 605 |  |
| Leasehold improvements |  |  | 89 |  |  |  | 86 |  |
| Computer, production, engineering and other equipment |  |  | 802 |  |  |  | 817 |  |
| Computer software |  |  | 359 |  |  |  | 357 |  |
| Furniture and fixtures |  |  | 106 |  |  |  | 105 |  |
| Construction-in-progress |  |  | 32 |  |  |  | 10 |  |
|  |  |  | 2,088 |  |  |  | 2,086 |  |
| Accumulated depreciation and amortization |  |  | (1,361 | ) |  |  | (1,327 | ) |
| Property and equipment, net |  | $ | 727 |  |  | $ | 759 |  |

[0001564590-20-029349:notes:105]
In September 2017, we entered into an agreement to sell certain land and buildings located in Sunnyvale, California, with a book value of $118 million, for a total of $306 million, through two separate and independent closings. Upon the completion of the first closing in fiscal 2018, we consummated the sale of properties with a net book value of $66 million for cash proceeds of $210 million, resulting in a gain, net of direct selling costs, of $142 million.     The remaining properties, consisting of land,  were classified as assets held-for-sale, and included as other current assets in our consolidated balance sheets as of April 26, 2019. On August 26, 2019, the second closing occurred and we consummated the sale of the land, with a net book value of $53 million, and received cash proceeds of $96 million, resulting in a gain, net of direct selling costs, of $38 million.

[0001564590-20-029349:notes:106]
Depreciation and amortization expense related to property and equipment, net is summarized below (in millions):

[0001564590-20-029349:notes:107]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Depreciation and amortization expense |  | $ | 154 |  |  | $ | 150 |  |  | $ | 145 |  |

[0001564590-20-029349:notes:108]
Other non-current assets (in millions):

[0001564590-20-029349:notes:109]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Deferred tax assets |  | $ | 220 |  |  | $ | 201 |  |
| Operating lease ROU assets |  |  | 137 |  |  |  | — |  |
| Other assets |  |  | 342 |  |  |  | 389 |  |
| Other non-current assets |  | $ | 699 |  |  | $ | 590 |  |

[0001564590-20-029349:notes:110]
During fiscal 2019, we formed a joint venture with Lenovo (Beijing) Information Technology Ltd. (“Lenovo”) in China and, in February 2019, contributed assets to the newly formed entity, Lenovo NetApp Technology Limited (“LNTL”), in exchange for a non-controlling 49% equity interest. The group of assets we contributed and derecognized met the definition of a business and included cash, fixed assets, customer relationships and an allocation of goodwill, with an aggregate book value of $7 million. The fair value of our equity interest in LNTL of $80 million, based on discounted cash flows, resulted in a non-cash gain of $73 million. We accounted for our ownership interest as an equity method investment and have presented it in Other non-current assets on our consolidated balance sheet. The book value of our investment as of April 24, 2020 and April 26, 2019 was $67 million and $78 million, respectively, reflecting a $10 million other-than-temporary impairment charge recorded to other income (expense), net in the fourth quarter of fiscal 2020 attributable to a decline in growth rate projections for LNTL, in part due to the COVID-19 pandemic.

[0001564590-20-029349:notes:111]
LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. It will also endeavor to localize our products and services, and to develop new joint offerings for the China market by leveraging NetApp and Lenovo technologies.

[0001564590-20-029349:notes:112]
.

[0001564590-20-029349:notes:113]
Accrued expenses (in millions):

[0001564590-20-029349:notes:114]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Accrued compensation and benefits |  | $ | 322 |  |  | $ | 433 |  |
| Product warranty liabilities |  |  | 26 |  |  |  | 25 |  |
| Operating lease liabilities |  |  | 51 |  |  |  | — |  |
| Other current liabilities |  |  | 375 |  |  |  | 393 |  |
| Accrued expenses |  | $ | 774 |  |  | $ | 851 |  |

[0001564590-20-029349:notes:115]
Product warranty liabilities:

[0001564590-20-029349:notes:116]
Equipment and software systems sales include a standard product warranty. The following tables summarize the activity related to product warranty liabilities and their balances as reported in our consolidated balance sheets (in millions):

[0001564590-20-029349:notes:117]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Balance at beginning of period |  | $ | 40 |  |  | $ | 40 |  |
| Expense accrued during the period |  |  | 26 |  |  |  | 22 |  |
| Warranty costs incurred |  |  | (25 | ) |  |  | (22 | ) |
| Balance at end of period |  | $ | 41 |  |  | $ | 40 |  |

[0001564590-20-029349:notes:118]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Accrued expenses |  | $ | 26 |  |  | $ | 25 |  |
| Other long-term liabilities |  |  | 15 |  |  |  | 15 |  |
| Total warranty liabilities |  | $ | 41 |  |  | $ | 40 |  |

[0001564590-20-029349:notes:119]
Warranty expense accrued during the period includes amounts accrued for systems at the time of shipment, adjustments for changes in estimated costs for warranties on systems shipped in the period and changes in estimated costs for warranties on systems shipped in prior periods.

[0001564590-20-029349:notes:120]
Other long-term liabilities (in millions):

[0001564590-20-029349:notes:121]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Liability for uncertain tax positions |  | $ | 136 |  |  | $ | 252 |  |
| Income taxes payable |  |  | 399 |  |  |  | 447 |  |
| Product warranty liabilities |  |  | 15 |  |  |  | 15 |  |
| Operating lease liabilities |  |  | 93 |  |  |  | — |  |
| Other liabilities |  |  | 71 |  |  |  | 83 |  |
| Other long-term liabilities |  | $ | 714 |  |  | $ | 797 |  |

[0001564590-20-029349:notes:122]
Other income (expense), net (in millions):

[0001564590-20-029349:notes:123]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Interest income |  | $ | 48 |  |  | $ | 88 |  |  | $ | 79 |  |
| Interest expense |  |  | (55 | ) |  |  | (58 | ) |  |  | (62 | ) |
| Other income, net |  |  | 6 |  |  |  | 17 |  |  |  | 24 |  |
| Other income (expense), net |  | $ | (1 | ) |  | $ | 47 |  |  | $ | 41 |  |

[0001564590-20-029349:notes:124]
Statements of cash flows additional information (in millions):

[0001564590-20-029349:notes:125]
Non-cash investing and financing activities and supplemental cash flow information are as follows:

[0001564590-20-029349:notes:126]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 15 |  |  | $ | 9 |  |  | $ | 24 |  |
| Non-cash extinguishment of sale-leaseback financing obligations |  | $ | — |  |  | $ | — |  |  | $ | 130 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 276 |  |  | $ | 205 |  |  | $ | 87 |  |
| Interest paid |  | $ | 50 |  |  | $ | 53 |  |  | $ | 58 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-029349:notes:127]
7. Revenue

[0001564590-20-029349:notes:128]
Disaggregation of revenue

[0001564590-20-029349:notes:129]
To provide visibility into our transition from older products to our newer, higher growth products and clarity into the dynamics of our product revenue, we group our products by “Strategic” and “Mature” solutions. As our product portfolio evolves, market dynamics change, and management continues to assess our largest growth opportunities, we periodically change how we group certain products. Beginning in fiscal 2020, Strategic includes all-flash array products: A-series arrays, SolidFire, and EF-series, including all related add-on hardware and operating system (OS) software, NetApp HCI, StorageGrid, and optional add-on software products. Mature now includes hybrid and all-disk array products: FAS and E-series, including all related add-on hardware and OS software, and original equipment manufacturers products. Prior to this grouping change, Hybrid FAS products and E-Series were included in Strategic, while all add-on hardware and OS software were included in Mature. For comparability, Strategic and Mature revenues presented for the prior year periods have been recast based on the revised groupings.

[0001564590-20-029349:notes:130]
In addition to the sale of our products and solutions, we provide a variety of services to our customers, including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training.

[0001564590-20-029349:notes:131]
The following table depicts the disaggregation of revenue by our products and services (in millions):

[0001564590-20-029349:notes:132]
|  | Year Ended |  |
|  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Product revenues | $ | 2,995 |  |  | $ | 3,755 |  |  | $ | 3,525 |  |
| Strategic |  | 1,806 |  |  |  | 2,100 |  |  |  | 1,709 |  |
| Mature |  | 1,189 |  |  |  | 1,655 |  |  |  | 1,816 |  |
| Software maintenance revenues |  | 1,034 |  |  |  | 946 |  |  |  | 902 |  |
| Hardware maintenance and other services revenues |  | 1,383 |  |  |  | 1,445 |  |  |  | 1,492 |  |
| Hardware maintenance support contracts |  | 1,142 |  |  |  | 1,182 |  |  |  | 1,214 |  |
| Professional and other services |  | 241 |  |  |  | 263 |  |  |  | 278 |  |
| Net revenues | $ | 5,412 |  |  | $ | 6,146 |  |  | $ | 5,919 |  |

[0001564590-20-029349:notes:133]
Revenues by geographic region are presented in Note 16 – Segment, Geographic, and Significant Customer Information.

[0001564590-20-029349:notes:134]
Deferred revenue and financed unearned services revenue:

[0001564590-20-029349:notes:135]
The following table summarizes the components of our deferred revenue and financed unearned services balance as reported in our consolidated balance sheets (in millions):

[0001564590-20-029349:notes:136]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Deferred product revenue |  | $ | 75 |  |  | $ | 84 |  |
| Deferred services revenue |  |  | 3,567 |  |  |  | 3,502 |  |
| Financed unearned services revenue |  |  | 56 |  |  |  | 82 |  |
| Total |  | $ | 3,698 |  |  | $ | 3,668 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,894 |  |  | $ | 1,825 |  |
| Long-term |  |  | 1,804 |  |  |  | 1,843 |  |
| Total |  | $ | 3,698 |  |  | $ | 3,668 |  |

[0001564590-20-029349:notes:137]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 18 – Commitments and Contingencies for additional information related to these arrangements.

[0001564590-20-029349:notes:138]
The following tables summarize the activity related to deferred revenue and financed unearned services revenue (in millions):

[0001564590-20-029349:notes:139]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Balance at beginning of period |  | $ | 3,668 |  |  | $ | 3,363 |  |
| Additions |  |  | 2,513 |  |  |  | 2,763 |  |
| Revenue recognized during the period |  |  | (2,483 | ) |  |  | (2,458 | ) |
| Balance at end of period |  | $ | 3,698 |  |  | $ | 3,668 |  |

[0001564590-20-029349:notes:140]
During the years ended April 24, 2020 and April 26, 2019, we recognized $1,822 million and $1,722 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001564590-20-029349:notes:141]
As of April 24, 2020, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $3,698 million, which is equivalent to our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 51% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 25% in the next 13 to 24 months, and the remainder thereafter.

[0001564590-20-029349:notes:142]
Deferred commissions

[0001564590-20-029349:notes:143]
The following tables summarize the activity related to deferred commissions and their balances as reported in our consolidated balance sheets (in millions):

[0001564590-20-029349:notes:144]
|  | Year Ended |  |
|  | April 24, 2020 |  |  | April 26, 2019 |  |
| Balance at beginning of period | $ | 172 |  |  | $ | 137 |  |
| Additions |  | 79 |  |  |  | 112 |  |
| Expense recognized during the period |  | (95 | ) |  |  | (77 | ) |
| Balance at end of period | $ | 156 |  |  | $ | 172 |  |

[0001564590-20-029349:notes:145]
|  | April 24, 2020 |  |  | April 26, 2019 |  |
| Other current assets | $ | 67 |  |  | $ | 75 |  |
| Other non-current assets |  | 89 |  |  |  | 97 |  |
| Total deferred commissions | $ | 156 |  |  | $ | 172 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-20-029349:notes:146]
8. Financial Instruments and Fair Value Measurements

[0001564590-20-029349:notes:147]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis, whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the three levels of inputs to measure fair value:

[0001564590-20-029349:notes:148]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001564590-20-029349:notes:149]
Level 2: Inputs that reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; benchmark yields, reported trades, broker/dealer quotes, inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0001564590-20-029349:notes:150]
Level 3: Unobservable inputs that reflect our own assumptions incorporated in valuation techniques used to measure fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0001564590-20-029349:notes:151]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and consider an inactive market to be one in which there are infrequent or few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty’s non-performance risk is considered in measuring the fair values of liabilities and assets, respectively.

[0001564590-20-029349:notes:152]
Investments

[0001564590-20-029349:notes:153]
The following is a summary of our investments (in millions):

[0001564590-20-029349:notes:154]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 155 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 156 |  |  | $ | 1,359 |  |  | $ | 2 |  |  | $ | (8 | ) |  | $ | 1,353 |  |
| U.S. Treasury and government debt securities |  |  | 68 |  |  |  | — |  |  |  | — |  |  |  | 68 |  |  |  | 214 |  |  |  | — |  |  |  | (1 | ) |  |  | 213 |  |
| Certificates of deposit |  |  | 158 |  |  |  | — |  |  |  | — |  |  |  | 158 |  |  |  | 117 |  |  |  | — |  |  |  | — |  |  |  | 117 |  |
| Mutual funds |  |  | 33 |  |  |  | — |  |  |  | — |  |  |  | 33 |  |  |  | 35 |  |  |  | — |  |  |  | — |  |  |  | 35 |  |
| Total debt and equity securities |  | $ | 414 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 415 |  |  | $ | 1,725 |  |  | $ | 2 |  |  | $ | (9 | ) |  | $ | 1,718 |  |

[0001564590-20-029349:notes:155]
During fiscal 2020, we sold approximately $1.0 billion of corporate bonds held by foreign subsidiaries and recognized a gain on sale of $14 million, which is presented in other income (expense), net on our consolidated statement of operations.

[0001564590-20-029349:notes:156]
The following table presents the contractual maturities of our debt investments as of April 24, 2020 (in millions):

[0001564590-20-029349:notes:157]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 315 |  |  | $ | 315 |  |
| Due after one year through five years |  |  | 61 |  |  |  | 62 |  |
| Due after five years through ten years |  |  | 5 |  |  |  | 5 |  |
|  |  | $ | 381 |  |  | $ | 382 |  |

[0001564590-20-029349:notes:158]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0001564590-20-029349:notes:159]
Fair Value of Financial Instruments

[0001564590-20-029349:notes:160]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis (in millions):

[0001564590-20-029349:notes:161]
|  |  | April 24, 2020 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,500 |  |  | $ | 2,500 |  |  | $ | — |  |
| Corporate bonds |  |  | 156 |  |  |  | — |  |  |  | 156 |  |
| U.S. Treasury and government debt securities |  |  | 68 |  |  |  | 44 |  |  |  | 24 |  |
| Certificates of deposit |  |  | 158 |  |  |  | — |  |  |  | 158 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 2,882 |  |  | $ | 2,544 |  |  | $ | 338 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 27 |  |  | $ | 27 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (2 | ) |  | $ | — |  |  | $ | (2 | ) |

[0001564590-20-029349:notes:162]
|  |  | April 26, 2019 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,216 |  |  | $ | 2,216 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,353 |  |  |  | — |  |  |  | 1,353 |  |
| U.S. Treasury and government debt securities |  |  | 213 |  |  |  | 131 |  |  |  | 82 |  |
| Certificates of deposit |  |  | 117 |  |  |  | — |  |  |  | 117 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,899 |  |  | $ | 2,347 |  |  | $ | 1,552 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 29 |  |  | $ | 29 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0001564590-20-029349:notes:163]
| (1) | Reported as other current assets in the consolidated balance sheets |

[0001564590-20-029349:notes:164]
| (2) | Reported as other non-current assets in the consolidated balance sheets |

[0001564590-20-029349:notes:165]
| (3) | Reported as accrued expenses in the consolidated balance sheets |

[0001564590-20-029349:notes:166]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of April 24, 2020 and April 26, 2019, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-20-029349:notes:167]
Fair Value of Debt

[0001564590-20-029349:notes:168]
As of April 24, 2020 and April 26, 2019, the fair value of our long-term debt was approximately $1,176 million and $1,553 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. The fair value of our commercial paper notes approximated their carrying value. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-20-029349:notes:169]
9. Financing Arrangements

[0001564590-20-029349:notes:170]
Long-Term Debt

[0001564590-20-029349:notes:171]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001564590-20-029349:notes:172]
|  |  |  |  |  |  | April 24, 2020 |  |  | April 26, 2019 |  |  |
|  |  | Effective Interest Rate |  |  | Amount |  |  | Amount |  |  |
| 2.00% Senior Notes Due September 2019 |  | 2.32% |  |  | $ | — |  |  | $ | 400 |  |  |
| 3.375% Senior Notes Due June 2021 |  | 3.54% |  |  |  | 500 |  |  |  | 500 |  |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  |  |  | 250 |  |  |  | 250 |  |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  |  | 400 |  |  |  | 400 |  |  |
| Total principal amount |  |  |  |  |  |  | 1,150 |  |  |  | 1,550 |  |  |
| Unamortized discount and issuance costs |  |  |  |  |  |  | (4 | ) |  |  | (6 | ) |  |
| Total senior notes |  |  |  |  |  |  | 1,146 |  |  |  | 1,544 |  |  |
| Less: Current portion of long-term debt |  |  |  |  |  |  | — |  |  |  | (400 | ) |  |
| Total long-term debt |  |  |  |  |  | $ | 1,146 |  |  | $ | 1,144 |  |  |

[0001564590-20-029349:notes:173]
Senior Notes

[0001564590-20-029349:notes:174]
Our $400 million, 3.30% Senior Notes,  were issued in September 2017 with interest paid semi-annually in March and September. Our 3.375% Senior Notes and 3.25% Senior Notes, with principal amounts of $500 million and $250 million, respectively, were issued in June 2014 and December 2012, respectively. Interest on these Senior Notes is paid semi-annually in June and December. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness. On September 27, 2019, we paid $400 million to extinguish our 2.00% Senior Notes at maturity.

[0001564590-20-029349:notes:175]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of April 24, 2020, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-20-029349:notes:176]
As of April 24, 2020, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-20-029349:notes:177]
| Fiscal Year |  | Amount |  |
| 2022 |  |  | 500 |  |
| 2023 |  |  | 250 |  |
| 2025 |  |  | 400 |  |
| Total |  | $ | 1,150 |  |

[0001564590-20-029349:notes:178]
Commercial Paper Program and Credit Facility

[0001564590-20-029349:notes:179]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended on July 17, 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. As of April 24, 2020 and April 26, 2019, we had commercial paper notes outstanding with an aggregate principal amount of $523 million and $249 million, respectively, weighted-average interest rates of 2.01% and 2.73%, respectively, and maturities primarily less than three months. During fiscal 2020, we received proceeds of $111 million from the issuance, and made repayments of $10 million for the settlement, of commercial paper notes with original maturities greater than three months.

[0001564590-20-029349:notes:180]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders that expires on December 10, 2021. The credit agreement, as amended on July 17, 2017, provides a $1.0 billion revolving unsecured credit facility, with a $50 million letter of credit sub-facility, that serves as a back-up for the Program. Proceeds from the facility may also be used for general corporate purposes to the extent that the credit facility exceeds the outstanding debt issued under the Program. The credit agreement includes options that allow us to request an increase in the facility of up to an additional $300 million and to extend its maturity date for two additional one-year periods, both subject to certain conditions. As of April 24, 2020, we were in compliance with all associated covenants in this agreement. No amounts were drawn against this facility during any of the periods presented.

[0001564590-20-029349:notes:181]
Sale-leaseback Transactions

[0001564590-20-029349:notes:182]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates through December 31, 2017. These properties did not qualify for sale-leaseback accounting and as a result they were accounted for as financing transactions. During fiscal 2018, we terminated leases under the arrangement and recorded a non-cash sale of properties with a net book value of $54 million, the extinguishment of $130 million in financing obligations, and a gain of $76 million. There are no balances remaining on our consolidated balance sheets as of April 24, 2020 or April 26, 2019 associated with this sale-leaseback arrangement.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0001564590-20-029349:notes:183]
10. Leases

[0001564590-20-029349:notes:184]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which represent the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and have remaining lease terms of up to 15 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and have remaining lease terms of up to 4 years, while our automobile leases have remaining lease terms of up to 5 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0001564590-20-029349:notes:185]
The components of lease cost related to our operating leases were as follows (in millions):

[0001564590-20-029349:notes:186]
|  |  | Year Ended |  |  |
|  |  | April 24, 2020 |  |  |
| Operating lease cost |  | $ | 55 |  |  |
| Variable lease cost |  |  | 16 |  |  |
| Total lease cost |  | $ | 71 |  |  |

[0001564590-20-029349:notes:187]
Variable lease cost is primarily attributable to amounts paid to lessors for common area maintenance and utility charges under our real estate leases.

[0001564590-20-029349:notes:188]
The supplemental cash flow information related to our operating leases is as follows (in millions):

[0001564590-20-029349:notes:189]
|  |  | Year Ended |  |  |
|  |  | April 24, 2020 |  |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 56 |  |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  | $ | 41 |  |  |

[0001564590-20-029349:notes:190]
The supplemental balance sheet information related to our operating leases is as follows (in millions, except lease term and discount rate):

[0001564590-20-029349:notes:191]
|  |  | April 24, 2020 |  |  |
| Other non-current assets |  | $ | 137 |  |  |
| Total operating lease ROU assets |  | $ | 137 |  |  |
| Accrued expenses |  | $ | 51 |  |  |
| Other long-term liabilities |  |  | 93 |  |  |
| Total operating lease liabilities |  | $ | 144 |  |  |
| Weighted Average Remaining Lease Term |  | 3.9 years |  |  |
| Weighted Average Discount Rate |  |  | 2.7 | % |  |

[0001564590-20-029349:notes:192]
Future minimum operating lease payments as of April 24, 2020 are as follows (in millions):

[0001564590-20-029349:notes:193]
|  |  | Operating Leases |  |
| Fiscal 2021 |  | $ | 53 |  |
| Fiscal 2022 |  |  | 40 |  |
| Fiscal 2023 |  |  | 23 |  |
| Fiscal 2024 |  |  | 15 |  |
| Fiscal 2025 |  |  | 9 |  |
| Thereafter |  |  | 11 |  |
| Total lease payments |  | $ | 151 |  |
| Less: Interest |  |  | (7 | ) |
| Total |  | $ | 144 |  |

[0001564590-20-029349:notes:194]
Prior to our adoption of the new lease standard, future minimum operating lease payments as of April 26, 2019, which were undiscounted and excluded non-lease components, were as follows (in millions):

[0001564590-20-029349:notes:195]
|  |  | Operating Leases |  |
| Fiscal 2020 |  | $ | 47 |  |
| Fiscal 2021 |  |  | 38 |  |
| Fiscal 2022 |  |  | 26 |  |
| Fiscal 2023 |  |  | 14 |  |
| Fiscal 2024 |  |  | 10 |  |
| Thereafter |  |  | 16 |  |
| Total lease payments |  | $ | 151 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-20-029349:notes:196]
11. Stockholders’ Equity

[0001564590-20-029349:notes:197]
Equity Incentive Programs

[0001564590-20-029349:notes:198]
The 1999 Plan — As most recently amended on September 12, 2019, the 1999 Stock Option Plan (the Plan) comprises five separate equity incentive programs: (i) the Discretionary Option Grant Program under which options may be granted to eligible individuals at a fixed price per share; (ii) the Stock Appreciation Rights Program under which eligible persons may be granted stock appreciation rights that allow individuals to receive the appreciation in fair market value of the shares; (iii) the Stock Issuance Program under which eligible individuals may be issued shares of common stock directly; (iv) the Performance Share and Performance Unit Program under which eligible persons may be granted performance shares or performance units which result in payment to the participant only if performance goals or other vesting criteria are achieved and (v) the Automatic Award Program under which nonemployee board members automatically receive equity grants at designated intervals over their period of board service. In August 2019, the Plan was extended for a 10-year term.

[0001564590-20-029349:notes:199]
Under the Plan, the Board of Directors may grant to employees, nonemployee directors, consultants and independent advisors options to purchase shares of our common stock during their period of service. The exercise price for an incentive stock option and a nonstatutory option cannot be less than 100% of the fair market value of the common stock on the grant date. Options granted under the Plan generally vest over a four-year period. Options granted generally have a term of seven years after the grant date, subject to earlier termination upon the occurrence of certain events. The Plan prohibits the repricing of any outstanding stock option or stock appreciation right after it has been granted or to cancel any outstanding stock option or stock appreciation right and immediately replace it with a new stock option or stock appreciation right with a lower exercise price unless approved by stockholders. RSUs granted under the Plan include time-based RSUs that generally vest over a four-year period with 25% vesting on each anniversary of the grant date. The Compensation Committee of the Board of Directors (the Compensation Committee) has the discretion to use different vesting schedules. In addition, performance-based RSUs may be granted under the Plan and are subject to performance criteria and vesting terms specified by the Compensation Committee.

[0001564590-20-029349:notes:200]
Under the Plan, the number of shares reserved for issuance is reduced by two shares for every share subject to a full value award, which are specified to be grants that are in the form of performance shares and/or performance unit awards, stock, restricted stock or restricted stock units. The Plan (i) limits the number of shares that may be granted pursuant to awards under the Stock Issuance Program to a participant in any calendar year to 1 million, (ii) limits the initial value of performance units a participant may receive to not more than $5 million and (iii) limits the number of performance shares a participant may receive in a calendar year to 1 million.

[0001564590-20-029349:notes:201]
During fiscal 2020, the shares reserved for issuance under the Plan were increased by 4 million shares of common stock. As of April 24, 2020, 27 million shares were available for grant under the Plan.

[0001564590-20-029349:notes:202]
Stock Options

[0001564590-20-029349:notes:203]
As of April 24, 2020 and April 26, 2019, we had less than 1 million stock options outstanding.

[0001564590-20-029349:notes:204]
Additional information related to our stock options is summarized below (in millions):

[0001564590-20-029349:notes:205]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Intrinsic value of exercises |  | $ | 5 |  |  | $ | 31 |  |  | $ | 37 |  |
| Proceeds received from exercises |  | $ | 4 |  |  | $ | 25 |  |  | $ | 88 |  |
| Fair value of options vested |  | $ | 1 |  |  | $ | 2 |  |  | $ | 8 |  |

[0001564590-20-029349:notes:206]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our stock on that day for all in-the-money options.

[0001564590-20-029349:notes:207]
Restricted Stock Units

[0001564590-20-029349:notes:208]
In fiscal 2020, 2019 and 2018, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service based vesting criteria) such that the PBRSU cliff-vests at the end of either an approximate two year or three year performance period, which began on the date specified in the grant agreement and ends on the last day of the second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in fiscal 2020 and 2019, and all of the PBRSUs granted in fiscal 2018, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the applicable period end date. The fair values of these awards were fixed at grant date using a Monte Carlo simulation model. For the remaining PBRSUs granted in fiscal 2020 and 2019, the number of shares issued will depend upon our achievement against a cumulative Adjusted Operating Income (AOI) target, as defined in the grant agreements, for the three-year periods from fiscal 2020 through 2022 and fiscal 2019 through 2021, respectively. The fair values of these PBRSUs were established consistent with our methodology for valuing time-based RSUs, while compensation cost is being recognized based on the probable outcome of the performance condition. The aggregate grant date fair value of all PBRSUs granted in fiscal 2020, 2019 and 2018 was $18 million, $24 million and $20 million, respectively, and these amounts are being recognized to expense over the shorter of the remaining applicable performance or service periods.

[0001564590-20-029349:notes:209]
As of April 24, 2020, April 26, 2019 and April 27, 2018, there were approximately 1 million PBRSUs outstanding.

[0001564590-20-029349:notes:210]
The following table summarizes information related to RSUs, including PBRSUs, (in millions, except for fair value):

[0001564590-20-029349:notes:211]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 28, 2017 |  |  | 11 |  |  | $ | 28.81 |  |
| Granted |  |  | 4 |  |  | $ | 39.74 |  |
| Vested |  |  | (5 | ) |  | $ | 30.59 |  |
| Forfeited |  |  | (1 | ) |  | $ | 29.54 |  |
| Outstanding as of April 27, 2018 |  |  | 9 |  |  | $ | 32.91 |  |
| Granted |  |  | 3 |  |  | $ | 63.40 |  |
| Vested |  |  | (3 | ) |  | $ | 32.02 |  |
| Forfeited |  |  | (1 | ) |  | $ | 36.61 |  |
| Outstanding as of April 26, 2019 |  |  | 8 |  |  | $ | 45.68 |  |
| Granted |  |  | 4 |  |  | $ | 51.39 |  |
| Vested |  |  | (4 | ) |  | $ | 38.87 |  |
| Forfeited |  |  | (1 | ) |  | $ | 48.30 |  |
| Outstanding as of April 24, 2020 |  |  | 7 |  |  | $ | 51.40 |  |

[0001564590-20-029349:notes:212]
We primarily use the net share settlement approach upon vesting, where a portion of the shares are withheld as settlement of employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001564590-20-029349:notes:213]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |  |  | 2 |  |
| Fair value of shares withheld |  | $ | 79 |  |  | $ | 96 |  |  | $ | 75 |  |

[0001564590-20-029349:notes:214]
Employee Stock Purchase Plan

[0001564590-20-029349:notes:215]
Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. On September 12, 2019, the ESPP was amended to increase the shares reserved for issuance by 2 million shares of common stock. As of April 24, 2020, 7 million shares were available for issuance. The following table summarizes activity related to the purchase rights issued under the ESPP (in millions):

[0001564590-20-029349:notes:216]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Shares issued under the ESPP |  |  | 2 |  |  |  | 3 |  |  |  | 4 |  |
| Proceeds from issuance of shares |  | $ | 98 |  |  | $ | 96 |  |  | $ | 85 |  |

[0001564590-20-029349:notes:217]
Stock-Based Compensation Expense

[0001564590-20-029349:notes:218]
Stock-based compensation expense is included in the consolidated statements of operations as follows (in millions):

[0001564590-20-029349:notes:219]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Cost of product revenues |  | $ | 3 |  |  | $ | 4 |  |  | $ | 3 |  |
| Cost of hardware maintenance and other services revenues |  |  | 10 |  |  |  | 10 |  |  |  | 10 |  |
| Sales and marketing |  |  | 66 |  |  |  | 67 |  |  |  | 68 |  |
| Research and development |  |  | 53 |  |  |  | 48 |  |  |  | 49 |  |
| General and administrative |  |  | 21 |  |  |  | 29 |  |  |  | 31 |  |
| Total stock-based compensation expense |  | $ | 153 |  |  | $ | 158 |  |  | $ | 161 |  |
| Income tax benefit for stock-based compensation |  | $ | 15 |  |  | $ | 15 |  |  | $ | 29 |  |

[0001564590-20-029349:notes:220]
As of April 24, 2020, total unrecognized compensation expense related to our equity awards was $280 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.1 years.

[0001564590-20-029349:notes:221]
Valuation Assumptions

[0001564590-20-029349:notes:222]
The valuation of RSUs and ESPP purchase rights and the underlying weighted-average assumptions are summarized as follows:

[0001564590-20-029349:notes:223]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| RSUs: |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 1.7 | % |  |  | 2.6 | % |  |  | 1.4 | % |
| Expected dividend yield |  |  | 2.9 | % |  |  | 2.4 | % |  |  | 2.0 | % |
| Weighted-average fair value per share granted |  | $ | 51.39 |  |  | $ | 63.40 |  |  | $ | 39.74 |  |
| ESPP: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 2.0 | % |  |  | 2.6 | % |  |  | 1.4 | % |
| Expected volatility |  |  | 33 | % |  |  | 31 | % |  |  | 28 | % |
| Expected dividend yield |  |  | 3.1 | % |  |  | 2.4 | % |  |  | 2.0 | % |
| Weighted-average fair value per right granted |  | $ | 10.15 |  |  | $ | 18.07 |  |  | $ | 12.34 |  |

[0001564590-20-029349:notes:224]
Stock Repurchase Program

[0001564590-20-029349:notes:225]
As of April 24, 2020, our Board of Directors has authorized the repurchase of up to $13.6 billion of our common stock under our stock repurchase program. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. In March 2020, we suspended our repurchases under the program due to the economic impact of the COVID-19 pandemic.

[0001564590-20-029349:notes:226]
The following table summarizes activity related to this program (in millions, except per share amounts):

[0001564590-20-029349:notes:227]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Number of shares repurchased |  |  | 25 |  |  |  | 29 |  |  |  | 15 |  |
| Average price per share |  | $ | 56.34 |  |  | $ | 72.87 |  |  | $ | 51.57 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 625 |  |  | $ | 1,002 |  |  | $ | 568 |  |
| Stock repurchases allocated to retained earnings (accumulated deficit) |  | $ | 786 |  |  | $ | 1,109 |  |  | $ | 226 |  |
| Remaining authorization at end of period |  | $ | 477 |  |  | $ | 1,889 |  |  | $ | 4,000 |  |

[0001564590-20-029349:notes:228]
Since the May 13, 2003 inception of our stock repurchase program through April 24, 2020, we repurchased a total of 338 million shares of our common stock at an average price of $38.86 per share, for an aggregate purchase price of $13.1 billion.

[0001564590-20-029349:notes:229]
Preferred Stock

[0001564590-20-029349:notes:230]
Our Board of Directors has the authority to issue up to 5 million shares of preferred stock and to determine the price, rights, preferences, privileges, and restrictions, including voting rights, of those shares without any further vote or action by the stockholders. No shares of preferred stock were issued or outstanding in any period presented.

[0001564590-20-029349:notes:231]
Dividends

[0001564590-20-029349:notes:232]
The following is a summary of our fiscal 2020, 2019 and 2018 activities related to dividends on our common stock (in millions, except per share amounts).

[0001564590-20-029349:notes:233]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Dividends per share declared |  | $ | 1.92 |  |  | $ | 1.60 |  |  | $ | 0.80 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 400 |  |  | $ | 403 |  |  | $ | 106 |  |
| Dividend payments allocated to retained earnings |  | $ | 39 |  |  | $ | — |  |  | $ | 108 |  |

[0001564590-20-029349:notes:234]
On May 26, 2020, we declared a cash dividend of $0.48 per share of common stock, payable on July 29, 2020 to shareholders of record as of the close of business on July 10, 2020. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by the Company to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-20-029349:notes:235]
Accumulated Other Comprehensive Income (Loss)

[0001564590-20-029349:notes:236]
Changes in accumulated other comprehensive income (loss) (AOCI) by component, net of tax, are summarized below (in millions):

[0001564590-20-029349:notes:237]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 27, 2018 |  | $ | (27 | ) |  | $ | — |  |  | $ | (43 | ) |  | $ | — |  |  | $ | (70 | ) |
| OCI before reclassifications, net of tax |  |  | (7 | ) |  |  | (2 | ) |  |  | 36 |  |  |  | 2 |  |  |  | 29 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | (2 | ) |
| Total OCI |  |  | (7 | ) |  |  | (3 | ) |  |  | 36 |  |  |  | 1 |  |  |  | 27 |  |
| Balance as of April 26, 2019 |  |  | (34 | ) |  |  | (3 | ) |  |  | (7 | ) |  |  | 1 |  |  |  | (43 | ) |
| OCI before reclassifications, net of tax |  |  | (8 | ) |  |  | 3 |  |  |  | 22 |  |  |  | 5 |  |  |  | 22 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | (1 | ) |  |  | (14 | ) |  |  | (6 | ) |  |  | (21 | ) |
| Total OCI |  |  | (8 | ) |  |  | 2 |  |  |  | 8 |  |  |  | (1 | ) |  |  | 1 |  |
| Balance as of April 24, 2020 |  | $ | (42 | ) |  | $ | (1 | ) |  | $ | 1 |  |  | $ | — |  |  | $ | (42 | ) |

[0001564590-20-029349:notes:238]
The amounts reclassified out of AOCI are as follows (in millions):

[0001564590-20-029349:notes:239]
|  |  | Year Ended |  |  |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Classification |
| Recognized (gains) losses on defined benefit obligations |  | $ | (2 | ) |  | $ | (2 | ) |  |  | (2 | ) |  | Operating expenses |
| Realized gains on available-for-sale securities |  |  | (14 | ) |  |  | — |  |  |  | — |  |  | Other income (expense), net |
| Realized gains on cash flow hedges |  |  | (6 | ) |  |  | (1 | ) |  |  | — |  |  | Net revenues |
| Total reclassifications |  | $ | (22 | ) |  | $ | (3 | ) |  | $ | (2 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-20-029349:notes:240]
12. Derivatives and Hedging Activities

[0001564590-20-029349:notes:241]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of our agreements with them. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of April 24, 2020 or April 26, 2019. All contracts have a maturity of less than 12 months.

[0001564590-20-029349:notes:242]
The notional amount of our outstanding U.S. dollar equivalent foreign currency exchange forward contracts consisted of the following (in millions):

[0001564590-20-029349:notes:243]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 124 |  |  | $ | 103 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 254 |  |  | $ | 121 |  |
| Forward contracts purchased |  | $ | 108 |  |  | $ | 363 |  |

[0001564590-20-029349:notes:244]
The effect of cash flow hedges recognized in net revenues is presented in the consolidated statements of comprehensive income and Note 11 – Stockholders’ Equity.

[0001564590-20-029349:notes:245]
The effect of derivative instruments not designated as hedging instruments recognized in other income, net on our consolidated statements of operations was as follows (in millions):

[0001564590-20-029349:notes:246]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
|  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | — |  |  | $ | 15 |  |  | $ | (9 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-029349:notes:247]
13. Restructuring Charges

[0001564590-20-029349:notes:248]
In the first quarter of fiscal 2020, we announced a restructuring plan (the May 2019 Plan) to reduce costs and redirect resources to our highest return activities, which included a reduction in our global workforce of approximately 2%. Charges related to the plan consisted primarily of employee severance-related costs. Substantially all activities under the plan have been completed.

[0001564590-20-029349:notes:249]
Management has previously approved several restructuring actions, including the November 2016 Plan, May 2018 Plan and April 2019 Plan, under which we reduced our global workforce by 6%, less than 2%, and approximately 1%, respectively. Charges related to our restructuring plans consisted primarily of employee severance-related costs. Substantially all activities under the November 2016 Plan and the May 2018 Plan were complete as of the end of fiscal 2018 and 2019, respectively. Substantially all activities under the April 2019 Plan were complete as of the end of fiscal 2020.

[0001564590-20-029349:notes:250]
Activities related to our restructuring plans are summarized as follows (in millions):

[0001564590-20-029349:notes:251]
|  |  | May 2019 Plan |  |  | April 2019 Plan |  |  | May 2018 Plan |  |  | November 2016 Plan |  |  | Total |  |
| Balance as of April 28, 2017 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 13 |  |  | $ | 13 |  |
| Net charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Cash payments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (7 | ) |  |  | (7 | ) |
| Balance as of April 27, 2018 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 6 |  |  |  | 6 |  |
| Net charges |  |  | — |  |  |  | 16 |  |  |  | 19 |  |  |  | — |  |  |  | 35 |  |
| Cash payments |  |  | — |  |  |  | (1 | ) |  |  | (19 | ) |  |  | (2 | ) |  |  | (22 | ) |
| Balance as of April 26, 2019 |  |  | — |  |  |  | 15 |  |  |  | — |  |  |  | 4 |  |  |  | 19 |  |
| Net charges |  |  | 21 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 21 |  |
| Cash payments |  |  | (20 | ) |  |  | (15 | ) |  |  | — |  |  |  | — |  |  |  | (35 | ) |
| Other |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (4 | ) |  |  | (4 | ) |
| Balance as of April 24, 2020 |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |

[0001564590-20-029349:notes:252]
Upon adoption of the new lease accounting standard in the first quarter of fiscal 2020, the remaining lease-related liabilities associated with the November 2016 Plan were recognized as a reduction to the lease right-of-use asset recorded at transition.

[0001564590-20-029349:notes:253]
Liabilities for our restructuring activities are included in accrued expenses in our consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-029349:notes:254]
14. Income Taxes

[0001564590-20-029349:notes:255]
Income before income taxes is as follows (in millions):

[0001564590-20-029349:notes:256]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Domestic |  | $ | 379 |  |  | $ | 678 |  |  | $ | 589 |  |
| Foreign |  |  | 565 |  |  |  | 590 |  |  |  | 610 |  |
| Total |  | $ | 944 |  |  | $ | 1,268 |  |  | $ | 1,199 |  |

[0001564590-20-029349:notes:257]
The provision for income taxes consists of the following (in millions):

[0001564590-20-029349:notes:258]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 83 |  |  | $ | 26 |  |  | $ | 764 |  |
| State |  |  | 9 |  |  |  | 27 |  |  |  | 10 |  |
| Foreign |  |  | 50 |  |  |  | 49 |  |  |  | 39 |  |
| Total current |  |  | 142 |  |  |  | 102 |  |  |  | 813 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (26 | ) |  |  | 35 |  |  |  | 239 |  |
| State |  |  | (6 | ) |  |  | (6 | ) |  |  | 27 |  |
| Foreign |  |  | 15 |  |  |  | (32 | ) |  |  | 4 |  |
| Total deferred |  |  | (17 | ) |  |  | (3 | ) |  |  | 270 |  |
| Provision for income taxes |  | $ | 125 |  |  | $ | 99 |  |  | $ | 1,083 |  |

[0001564590-20-029349:notes:259]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0001564590-20-029349:notes:260]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Tax computed at federal statutory rate |  | $ | 198 |  |  | $ | 266 |  |  | $ | 366 |  |
| State income taxes, net of federal benefit |  |  | 10 |  |  |  | 16 |  |  |  | 18 |  |
| Foreign earnings in lower tax jurisdictions (1) |  |  | (40 | ) |  |  | (84 | ) |  |  | (108 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (19 | ) |  |  | (23 | ) |
| Research and development credits |  |  | (16 | ) |  |  | (17 | ) |  |  | (10 | ) |
| Global minimum tax on intangible income |  |  | 32 |  |  |  | 22 |  |  |  | — |  |
| Transition tax and related reserves |  |  | 15 |  |  |  | (5 | ) |  |  | 732 |  |
| Tax rate changes |  |  | — |  |  |  | — |  |  |  | 108 |  |
| Resolution of income tax matters (2) |  |  | (61 | ) |  |  | (48 | ) |  |  | — |  |
| Non-taxable gain on joint venture formation |  |  | — |  |  |  | (14 | ) |  |  | — |  |
| Domestic production activities deduction |  |  | — |  |  |  | (13 | ) |  |  | (7 | ) |
| Other |  |  | (9 | ) |  |  | (5 | ) |  |  | 7 |  |
| Provision for income taxes |  | $ | 125 |  |  | $ | 99 |  |  | $ | 1,083 |  |

[0001564590-20-029349:notes:261]
|  | (1) | For fiscal 2020, 2019 and 2018, we generated foreign earnings in lower tax jurisdictions primarily related to income from our European operations. |

[0001564590-20-029349:notes:262]
|  | (2) | During fiscal 2020, we recognized a tax benefit related to the lapse of statutes of limitations on our fiscal 2014 and 2015 federal income tax returns. During fiscal 2019, the Internal Revenue Service completed the examination of our fiscal 2012 to fiscal 2013 federal income tax returns, and we recognized a tax benefit attributable to the effective settlement and the release of related tax reserves. |

[0001564590-20-029349:notes:263]
On December 22, 2017, the Tax Cuts and Jobs Act (TCJA) was enacted into law. The TCJA made significant changes to the U.S. corporate income tax system including a reduction of the U.S. federal corporate income tax rate from 35% to 21%, the imposition of a one-time transition tax on deferred foreign earnings, and the creation of new taxes on certain foreign-sourced earnings. ASC 740, Income Taxes, requires companies to recognize the effect of the tax law changes in the period of enactment. However, the SEC staff issued Staff Accounting Bulletin 118, which allowed companies to record provisional amounts during a measurement period not to extend beyond one year from the TCJA enactment date.

[0001564590-20-029349:notes:264]
As a result of the U.S. federal corporate income tax rate change, effective as of January 1, 2018, we remeasured our deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future periods. During fiscal 2018, we recorded $108 million of tax expense related to all tax rate changes. Upon finalization of our provisional estimates during fiscal 2019, we recorded tax expense of $6 million related to deferred tax assets for equity-based compensation awards to our executives.

[0001564590-20-029349:notes:265]
The TCJA imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits not previously subject to U.S. income tax at a rate of 15.5% on earnings to the extent of foreign cash and other liquid assets, and 8% on the remaining earnings. In fiscal 2018, we recorded a $732 million discrete tax expense for the estimated U.S. federal and state income tax impacts of the transition tax. In fiscal 2019, we finalized our computation of the transition tax and recorded a reduction of $5 million to our provisional estimate.

[0001564590-20-029349:notes:266]
Under the TCJA, the global minimum tax on intangible income (GMT) provisions impose a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations. Under U.S. GAAP, companies are allowed to make an accounting policy election to either (i) account for GMT as a component of tax expense in the period in which a company is subject to the rules, or (ii) account for GMT in a company’s measurement of deferred taxes. We have elected to recognize the GMT as a period cost and thus recorded $32 million and $22 million of tax expense for federal and state impacts for fiscal 2020 and fiscal 2019, respectively.

[0001564590-20-029349:notes:267]
The components of our deferred tax assets and liabilities are as follows (in millions):

[0001564590-20-029349:notes:268]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Reserves and accruals |  | $ | 72 |  |  | $ | 50 |  |
| Net operating loss and credit carryforwards |  |  | 113 |  |  |  | 139 |  |
| Stock-based compensation |  |  | 15 |  |  |  | 16 |  |
| Deferred revenue |  |  | 242 |  |  |  | 205 |  |
| Other |  |  | 14 |  |  |  | 16 |  |
| Gross deferred tax assets |  |  | 456 |  |  |  | 426 |  |
| Valuation allowance |  |  | (104 | ) |  |  | (123 | ) |
| Deferred tax assets, net of valuation allowance |  |  | 352 |  |  |  | 303 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Prepaids and accruals |  |  | 49 |  |  |  | 31 |  |
| Acquired intangibles |  |  | 40 |  |  |  | 32 |  |
| Property and equipment |  |  | 33 |  |  |  | 31 |  |
| Other |  |  | 20 |  |  |  | 10 |  |
| Total deferred tax liabilities |  |  | 142 |  |  |  | 104 |  |
| Deferred tax assets, net of valuation allowance and deferred tax liabilities |  | $ | 210 |  |  | $ | 199 |  |

[0001564590-20-029349:notes:269]
The valuation allowance decreased by $19 million in fiscal 2020. The decrease is mainly attributable to corresponding changes in deferred tax assets, primarily foreign tax credit carryforwards and certain state tax credit carryforwards.

[0001564590-20-029349:notes:270]
As of April 24, 2020, we have federal net operating loss and tax credit carryforwards of approximately $1 million and $2 million, respectively. In addition, we have gross state net operating loss and tax credit carryforwards of $26 million and $131 million, respectively. The majority of the state credit carryforwards are California research credits which are offset by a valuation allowance as we believe it is more likely than not that these credits will not be utilized. We also have $3 million of foreign net operating losses, and $23 million of foreign tax credit carryforwards where the majority is generated by our Dutch subsidiary which are fully offset by a valuation allowance. Certain acquired net operating loss and credit carryforwards are subject to an annual limitation under Internal Revenue Code Section 382, but are expected to be realized with the exception of those which have a valuation allowance. The federal, state, and foreign net operating loss carryforwards and credits will expire in various years from fiscal 2021 through 2038. The California research credit and Dutch foreign tax credit carryforwards do not expire.

[0001564590-20-029349:notes:271]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001564590-20-029349:notes:272]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Balance at beginning of period |  | $ | 296 |  |  | $ | 348 |  |  | $ | 218 |  |
| Additions based on tax positions related to the current year |  |  | 5 |  |  |  | 11 |  |  |  | 131 |  |
| Additions for tax positions of prior years |  |  | 1 |  |  |  | 26 |  |  |  | — |  |
| Decreases for tax positions of prior years |  |  | (10 | ) |  |  | (35 | ) |  |  | (1 | ) |
| Settlements |  |  | (81 | ) |  |  | (54 | ) |  |  | — |  |
| Balance at end of period |  | $ | 211 |  |  | $ | 296 |  |  | $ | 348 |  |

[0001564590-20-029349:notes:273]
As of April 24, 2020, we had $211 million of gross unrecognized tax benefits, of which $136 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $136 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized. As a result of U.S. tax reform, we recorded provisional gross unrecognized tax benefits of $114 million during fiscal 2018.

[0001564590-20-029349:notes:274]
We recognized a benefit for adjustments to accrued interest and penalties related to unrecognized tax benefits in the income tax provision of approximately $8 million in fiscal 2020, a benefit of $4 million in fiscal 2019 and an expense of $5 million in fiscal 2018. Accrued interest and penalties of $10 million and $18 million were recorded in the consolidated balance sheets as of April 24, 2020 and April 26, 2019, respectively.

[0001564590-20-029349:notes:275]
The tax years that remain subject to examination for our major tax jurisdictions are shown below:

[0001564590-20-029349:notes:276]
Fiscal Years Subject to Examination for Major Tax Jurisdictions at April 24, 2020

[0001564590-20-029349:notes:277]
| 2016 — 2020 |  | United States — federal income tax |
| 2011 — 2020 |  | United States — state and local income tax |
| 2013 — 2020 |  | Australia |
| 2015 — 2020 |  | Germany |
| 2007 — 2020 |  | India |
| 2013 — 2020 |  | Japan |
| 2014 — 2020 |  | The Netherlands |
| 2017 — 2020 |  | United Kingdom |
| 2016 — 2020 |  | Canada |

[0001564590-20-029349:notes:278]
We are currently undergoing various income tax audits in the U.S. and several foreign tax jurisdictions. Transfer pricing calculations are key topics under these audits and are often subject to dispute and appeals. We are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal 2001, in that we have carryforward attributes from these years that could be subject to adjustment in the tax years of utilization.

[0001564590-20-029349:notes:279]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for such withholding tax and filed an appeal with the Danish Tax Tribunal. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012. In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). Parties were heard before the court in October 2017. In March 2018, the Advocate General issued an opinion which was largely in favor of NetApp. The CJEU was not bound by the opinion of the Advocate General and issued its preliminary ruling in February 2019. The CJEU ruling did not preclude the Danish Tax Authorities from imposing withholding tax on distributions based on the benefits of certain European Union directives. The preliminary ruling will be reviewed and may be subjected to additional briefing by the DHC. Once complete, the DHC will then issue its final decision. While the timing and outcome of a final decision on this matter is uncertain, we believe it is more likely than not that our distributions were not subject to withholding tax and we intend to vigorously defend any withholding tax claims by the Danish Tax Authorities.

[0001564590-20-029349:notes:280]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. As a result of uncertainties regarding tax audits and their possible outcomes, an estimate of the range of possible impacts to unrecognized tax benefits in the next twelve months cannot be made at this time.

[0001564590-20-029349:notes:281]
Prior to the passage of the TCJA, we had not provided U.S. income taxes and foreign withholding taxes on the undistributed earnings of foreign subsidiaries because we had intended to indefinitely reinvest such earnings outside the U.S. The TCJA imposed a one-time transition tax on substantially all accumulated foreign earnings through December 31, 2017 and generally allows companies to make distributions of foreign earnings without incurring additional federal taxes. As a part of the provisional estimates recorded during fiscal 2018, we considered the impacts of the TCJA and reviewed our projected global cash requirements and have determined that certain historical and future foreign earnings will no longer be indefinitely reinvested. As of April 24, 2020, we estimate the unrecognized deferred tax liability related to the earnings we expect to be indefinitely reinvested to be immaterial. We will continue to monitor our plans to indefinitely reinvest undistributed earnings of foreign subsidiaries and will assess the related unrecognized deferred tax liability considering our ongoing projected global cash requirements, tax consequences associated with repatriation and any U.S. or foreign government programs designed to influence remittances.


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-029349:notes:282]
15. Net Income per Share

[0001564590-20-029349:notes:283]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0001564590-20-029349:notes:284]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 819 |  |  | $ | 1,169 |  |  | $ | 116 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 230 |  |  |  | 254 |  |  |  | 268 |  |
| Dilutive impact of employee equity award plans |  |  | 3 |  |  |  | 5 |  |  |  | 8 |  |
| Shares used in diluted computation |  |  | 233 |  |  |  | 259 |  |  |  | 276 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.56 |  |  | $ | 4.60 |  |  | $ | 0.43 |  |
| Diluted |  | $ | 3.52 |  |  | $ | 4.51 |  |  | $ | 0.42 |  |

[0001564590-20-029349:notes:285]
Four million potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for fiscal 2020, while one million potential shares were excluded from the calculations for each of fiscal 2019 and 2018, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-029349:notes:286]
16. Segment, Geographic, and Significant Customer Information

[0001564590-20-029349:notes:287]
We operate in one industry segment: the design, manufacturing, marketing, and technical support of high-performance storage and data management solutions. We conduct business globally, and our sales and support activities are managed on a geographic basis. Our management reviews financial information presented on a consolidated basis, accompanied by disaggregated information it receives from our internal management system about revenues by geographic region, based on the location from which the customer relationship is managed, for purposes of allocating resources and evaluating financial performance. We do not allocate costs of revenues, research and development, sales and marketing, or general and administrative expenses to our geographic regions in this internal management reporting because management does not review operations or operating results, or make planning decisions, below the consolidated entity level.

[0001564590-20-029349:notes:288]
Summarized revenues by geographic region based on information from our internal management system and utilized by our Chief Executive Officer, who is considered our Chief Operating Decision Maker, is as follows (in millions):

[0001564590-20-029349:notes:289]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| United States, Canada and Latin America (Americas) |  | $ | 2,863 |  |  | $ | 3,425 |  |  | $ | 3,207 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 1,742 |  |  |  | 1,847 |  |  |  | 1,873 |  |
| Asia Pacific (APAC) |  |  | 807 |  |  |  | 874 |  |  |  | 839 |  |
| Net revenues |  | $ | 5,412 |  |  | $ | 6,146 |  |  | $ | 5,919 |  |

[0001564590-20-029349:notes:290]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $2,584 million, $3,116 million and $2,878 million during fiscal 2020, 2019 and 2018, respectively.

[0001564590-20-029349:notes:291]
The majority of our assets, excluding cash, cash equivalents, short-term investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents and short-term investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0001564590-20-029349:notes:292]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| U.S. |  | $ | 385 |  |  | $ | 159 |  |
| International |  |  | 2,497 |  |  |  | 3,740 |  |
| Total |  | $ | 2,882 |  |  | $ | 3,899 |  |

[0001564590-20-029349:notes:293]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment information for geographic areas based on the physical location of the assets (in millions):

[0001564590-20-029349:notes:294]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| U.S. |  | $ | 540 |  |  | $ | 572 |  |
| International |  |  | 187 |  |  |  | 187 |  |
| Total |  | $ | 727 |  |  | $ | 759 |  |

[0001564590-20-029349:notes:295]
The following customers, each of which is a distributor, accounted for 10% or more of our net revenues:

[0001564590-20-029349:notes:296]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| Arrow Electronics, Inc. |  |  | 25 | % |  |  | 24 | % |  |  | 23 | % |
| Tech Data Corporation |  |  | 21 | % |  |  | 20 | % |  |  | 20 | % |

[0001564590-20-029349:notes:297]
The following customers accounted for 10% or more of accounts receivable:

[0001564590-20-029349:notes:298]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Arrow Electronics, Inc. |  |  | 13 | % |  |  | 11 | % |
| Tech Data Corporation |  |  | 19 | % |  |  | 24 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-20-029349:notes:299]
17. Employee Benefits and Deferred Compensation

[0001564590-20-029349:notes:300]
Employee 401(k) Plan

[0001564590-20-029349:notes:301]
Our 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit. We match 100% of the first 2% of eligible earnings an employee contributes to the 401(k) Plan, and then match 50% of the next 4% of eligible earnings an employee contributes. An employee receives the full 4% match when he/she contributes at least 6% of his/her eligible earnings, up to a maximum calendar year matching contribution of $6,000. Our employer matching contributions to the 401(k) Plan were as follows (in millions):

[0001564590-20-029349:notes:302]
|  |  | Year Ended |  |
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |  | April 27, 2018 |  |
| 401(k) matching contributions |  | $ | 29 |  |  | $ | 29 |  |  | $ | 28 |  |

[0001564590-20-029349:notes:303]
Deferred Compensation Plan

[0001564590-20-029349:notes:304]
We have a non-qualified deferred compensation plan that allows a group of employees within the U.S. to contribute base salary and commissions or incentive compensation on a tax deferred basis in excess of the IRS limits imposed on 401(k) plans. The marketable securities related to these investments are held in a Rabbi Trust. The related deferred compensation plan assets and liabilities under the non-qualified deferred compensation plan were as follows (in millions):

[0001564590-20-029349:notes:305]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Deferred compensation plan assets |  | $ | 33 |  |  | $ | 35 |  |
| Deferred compensation liabilities reported as: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 6 |  |  | $ | 6 |  |
| Other long-term liabilities |  | $ | 27 |  |  | $ | 29 |  |

[0001564590-20-029349:notes:306]
Postretirement Health Care Plan

[0001564590-20-029349:notes:307]
Certain of our executive officers were eligible to participate in our Executive Retirement Medical Plan (the ERM Plan). Prior to its termination in fiscal 2020, the ERM Plan provided, upon retirement, medical benefits beyond the COBRA maximum benefit period to a defined group of senior executives based on minimum age, years of service and position. The ERM Plan was unfunded and there was no minimum funding requirement.

[0001564590-20-029349:notes:308]
In November 2016, we made certain amendments to the ERM Plan, which prior to amendment, provided group health insurance benefits to eligible retirees. Effective January 1, 2017, the amended ERM Plan provided each eligible retiree with a capped reimbursement of premiums for the period from January 1, 2017 through December 31, 2019. During the period from December 31, 2019 through December 31, 2021, participants in the ERM Plan are eligible to receive a lump sum cash payment equal to two years of projected health care costs, or a prorated portion thereof, pursuant to the methodology set forth in the ERM Plan. Such payments were, or will be, made by us outside the ERM Plan as the ERM Plan was terminated on December 31, 2019.

[0001564590-20-029349:notes:309]
Other Defined Benefit Plans

[0001564590-20-029349:notes:310]
We maintain various defined benefit plans to provide termination and postretirement benefits to certain eligible employees outside of the U.S. We also provide disability benefits to certain eligible employees in the U.S. Eligibility is determined based on the terms of our plans and local statutory requirements.

[0001564590-20-029349:notes:311]
Funded Status

[0001564590-20-029349:notes:312]
The funded status of our defined benefit plans, which is recognized in other long-term liabilities in our consolidated balance sheets, was as follows (in millions):

[0001564590-20-029349:notes:313]
|  |  | April 24, 2020 |  |  | April 26, 2019 |  |
| Fair value of plan assets |  | $ | 32 |  |  | $ | 31 |  |
| Benefit obligations |  |  | (59 | ) |  |  | (61 | ) |
| Unfunded obligations |  | $ | (27 | ) |  | $ | (30 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-029349:notes:314]
18. Commitments and Contingencies

[0001564590-20-029349:notes:315]
Purchase Orders and Other Commitments

[0001564590-20-029349:notes:316]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of April 24, 2020, we had $651 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 24, 2020 and April 26, 2019, such liability amounted to $6 million and $16 million, respectively, and is included in accrued expenses in our consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-20-029349:notes:317]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of April 24, 2020, we had $193 million in other purchase obligations.

[0001564590-20-029349:notes:318]
Financing Guarantees

[0001564590-20-029349:notes:319]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $59 million, $87 million and $67 million of receivables during fiscal 2020, 2019 and 2018, respectively.

[0001564590-20-029349:notes:320]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-20-029349:notes:321]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of April 24, 2020 and April 26, 2019, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-20-029349:notes:322]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of April 24, 2020, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0001564590-20-029349:notes:323]
Indemnification Agreements

[0001564590-20-029349:notes:324]
We enter into standard indemnification agreements in the ordinary course of business. Pursuant to these agreements, we agree to defend and indemnify other parties, primarily our customers or business partners or subcontractors, for damages and reasonable costs incurred in any suit or claim brought against them alleging that our products sold to them infringe any U.S. patent, copyright, trade secret, or similar right. If a product becomes the subject of an infringement claim, we may, at our option: (i) replace the product with another non-infringing product that provides substantially similar performance; (ii) modify the infringing product so that it no longer infringes but remains functionally equivalent; (iii) obtain the right for the customer to continue using the product at our expense and for the reseller to continue selling the product; (iv) take back the infringing product and refund to the customer the purchase price paid less depreciation amortized on a straight-line basis. We have not been required to make material payments pursuant to these provisions historically. We have not recorded any liability at April 24, 2020 related to these guarantees since the maximum amount of potential future payments under such guarantees, indemnities and warranties is not determinable, other than as described above.

[0001564590-20-029349:notes:325]
Legal Contingencies

[0001564590-20-029349:notes:326]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-20-029349:notes:327]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. We believe the complaint is without merit and intend to defend the case vigorously.

[0001564590-20-029349:notes:328]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001564590-20-029349:notes:329]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, and overall trends. No material accrual has been recorded as of April 24, 2020 related to such matters.


## us-gaap:SubsequentEventsTextBlock

[0001564590-20-029349:notes:330]
19. Subsequent Event

[0001564590-20-029349:notes:331]
On April 28, 2020, we acquired all the outstanding shares of privately-held Cloud Jumper Corporation, a provider of virtual desktop infrastructure and remote desktop services solutions, for approximately $34 million in cash. We are in the process of completing the purchase price allocation for this acquisition.

[0001564590-20-029349:notes:332]
On June 3, 2020, we entered into a definitive agreement to acquire all the outstanding shares of Spot, Inc. (“Spot”), a privately-held company and provider of compute management and cost optimization services on the public clouds. The acquisition of Spot will allow us to establish an application driven infrastructure for the continuous optimization of both compute and storage, which we believe will facilitate customers deploying more applications to the cloud. The acquisition is subject to the satisfaction of certain regulatory approvals and other customary closing conditions.
