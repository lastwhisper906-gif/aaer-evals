# NTAP MD&A — 0001193125-26-076622


## mdna

[0001193125-26-076622:mdna:1]
[same as prior period, unchanged from 0001193125-25-297237:mdna:1]

[0001193125-26-076622:mdna:2]
[same as prior period, unchanged from 0001193125-25-297237:mdna:2]

[0001193125-26-076622:mdna:3]
[same as prior period, unchanged from 0001193125-25-297237:mdna:3]

[0001193125-26-076622:mdna:4]
[same as prior period, unchanged from 0001193125-25-297237:mdna:4]

[0001193125-26-076622:mdna:5]
[same as prior period, unchanged from 0001193125-25-297237:mdna:5]

[0001193125-26-076622:mdna:6]
[same as prior period, unchanged from 0001193125-25-297237:mdna:6]

[0001193125-26-076622:mdna:7]
[same as prior period, unchanged from 0001193125-25-297237:mdna:7]

[0001193125-26-076622:mdna:8]
[same as prior period, unchanged from 0001193125-25-297237:mdna:8]

[0001193125-26-076622:mdna:9]
[same as prior period, unchanged from 0001193125-25-297237:mdna:9]

[0001193125-26-076622:mdna:10]
[same as prior period, unchanged from 0001193125-25-297237:mdna:10]

[0001193125-26-076622:mdna:11]
[same as prior period, unchanged from 0001193125-25-297237:mdna:11]

[0001193125-26-076622:mdna:12]
During the first nine months of fiscal 2026, we repurchased 7.0 million shares of our common stock at an average price of $107.26 per share, for an aggregate purchase price of $750 million. We also declared aggregate cash dividends of $1.56 per share in that period, for which we paid $310 million.

[0001193125-26-076622:mdna:13]
[same as prior period, unchanged from 0001193125-25-297237:mdna:13]

[0001193125-26-076622:mdna:14]
In the first nine months of fiscal 2026, we approved a restructuring plan to redirect resources to highest return activities and reduce costs. Aggregate charges recorded from restructuring plans during the first nine months of fiscal 2026 totaled $22 million.

[0001193125-26-076622:mdna:15]
[same as prior period, unchanged from 0001193125-25-297237:mdna:15]

[0001193125-26-076622:mdna:16]
[same as prior period, unchanged from 0001193125-25-297237:mdna:16]

[0001193125-26-076622:mdna:17]
26

[0001193125-26-076622:mdna:18]
[same as prior period, unchanged from 0001193125-25-297237:mdna:17]

[0001193125-26-076622:mdna:19]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | January 23, 2026 |  |  | January 24, 2025 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 46 | % |  |  | 46 | % |  |  | 45 | % |  |  | 45 | % |
| Services |  |  | 54 |  |  |  | 54 |  |  |  | 55 |  |  |  | 55 |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 21 |  |  |  | 20 |  |  |  | 20 |  |  |  | 19 |  |
| Cost of services |  |  | 9 |  |  |  | 10 |  |  |  | 9 |  |  |  | 11 |  |
| Gross profit |  |  | 71 |  |  |  | 70 |  |  |  | 71 |  |  |  | 71 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 27 |  |  |  | 27 |  |  |  | 28 |  |  |  | 29 |  |
| Research and development |  |  | 14 |  |  |  | 15 |  |  |  | 15 |  |  |  | 16 |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |
| Restructuring charges |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 1 |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total operating expenses |  |  | 45 |  |  |  | 48 |  |  |  | 48 |  |  |  | 50 |  |
| Income from operations |  |  | 25 |  |  |  | 22 |  |  |  | 23 |  |  |  | 20 |  |
| Other (expense) income, net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1 |  |
| Income before income taxes |  |  | 25 |  |  |  | 23 |  |  |  | 23 |  |  |  | 21 |  |
| Provision for income taxes |  |  | 6 |  |  |  | 4 |  |  |  | 5 |  |  |  | 4 |  |
| Net income |  |  | 19 | % |  |  | 18 | % |  |  | 18 | % |  |  | 17 | % |

[0001193125-26-076622:mdna:20]
[same as prior period, unchanged from 0001193125-25-297237:mdna:19]

[0001193125-26-076622:mdna:21]
[same as prior period, unchanged from 0001193125-25-297237:mdna:20]

[0001193125-26-076622:mdna:22]
[same as prior period, unchanged from 0001193125-25-297237:mdna:21]

[0001193125-26-076622:mdna:23]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |
| Net revenues |  | $ | 1,713 |  |  | $ | 1,641 |  |  |  | 4 | % |  | $ | 4,977 |  |  | $ | 4,840 |  |  |  | 3 | % |

[0001193125-26-076622:mdna:24]
The increase in net revenues for the third quarter and first nine months of fiscal 2026 compared to the corresponding periods of fiscal 2025 was due to an increase in both product and services revenues. Product revenues as a percentage of net revenues remained relatively flat in the third quarter and first nine months of fiscal 2026, as compared to the corresponding periods of fiscal 2025. Fluctuations in foreign currency exchange rates favorably impacted net revenues percentage growth by approximately two percentage points in the third quarter and first nine months of fiscal 2026, compared to the corresponding periods of fiscal 2025.

[0001193125-26-076622:mdna:25]
[same as prior period, unchanged from 0001193125-25-297237:mdna:24]

[0001193125-26-076622:mdna:26]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |
| Product revenues |  | $ | 786 |  |  | $ | 758 |  |  |  | 4 | % |  | $ | 2,228 |  |  | $ | 2,195 |  |  |  | 2 | % |

[0001193125-26-076622:mdna:27]
[same as prior period, unchanged from 0001193125-25-297237:mdna:26]

[0001193125-26-076622:mdna:28]
[same as prior period, unchanged from 0001193125-25-297237:mdna:27]

[0001193125-26-076622:mdna:29]
Total product revenues increased in the third quarter and first nine months of fiscal 2026 compared to the corresponding periods of the prior year primarily due to higher sales of all-flash array systems and the favorable impact from foreign exchange rate fluctuations.

[0001193125-26-076622:mdna:30]
[same as prior period, unchanged from 0001193125-25-297237:mdna:29]

[0001193125-26-076622:mdna:31]
[same as prior period, unchanged from 0001193125-25-297237:mdna:30]

[0001193125-26-076622:mdna:32]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |
| Services revenues |  | $ | 927 |  |  | $ | 883 |  |  |  | 5 | % |  | $ | 2,749 |  |  | $ | 2,645 |  |  |  | 4 | % |
| Support |  |  | 654 |  |  |  | 621 |  |  |  | 5 | % |  |  | 1,948 |  |  |  | 1,887 |  |  |  | 3 | % |
| Professional and other services |  |  | 99 |  |  |  | 88 |  |  |  | 13 | % |  |  | 295 |  |  |  | 257 |  |  |  | 15 | % |
| Public cloud |  |  | 174 |  |  |  | 174 |  |  |  | — | % |  |  | 506 |  |  |  | 501 |  |  |  | 1 | % |

[0001193125-26-076622:mdna:33]
[same as prior period, unchanged from 0001193125-25-297237:mdna:32]

[0001193125-26-076622:mdna:34]
[same as prior period, unchanged from 0001193125-25-297237:mdna:33]

[0001193125-26-076622:mdna:35]
Support revenues increased in the third quarter and first nine months of fiscal 2026 compared to the corresponding periods of the prior year, primarily due to a higher aggregate support contract value for our installed base and the favorable impact from foreign exchange rate fluctuations.

[0001193125-26-076622:mdna:36]
Professional and other services revenues increased in the third quarter and first nine months of fiscal 2026 compared to the corresponding periods of the prior year primarily due to an increase in revenues from our Keystone storage-as-a-service offering.

[0001193125-26-076622:mdna:37]
[same as prior period, unchanged from 0001193125-25-297237:mdna:36]

[0001193125-26-076622:mdna:38]
[same as prior period, unchanged from 0001193125-25-297237:mdna:37]

[0001193125-26-076622:mdna:39]
Public Cloud revenues were flat in the third quarter and increased marginally in the first nine months of fiscal 2026 compared to the corresponding periods of the prior year, due to higher customer demand, driven by NetApp’s diversified cloud offerings and overall growth in the cloud market, offset by the loss of revenue from our Spot by NetApp business which we sold in the fourth quarter of fiscal 2025.

[0001193125-26-076622:mdna:40]
[same as prior period, unchanged from 0001193125-25-297237:mdna:39]

[0001193125-26-076622:mdna:41]
[same as prior period, unchanged from 0001193125-25-297237:mdna:40]

[0001193125-26-076622:mdna:42]
[same as prior period, unchanged from 0001193125-25-297237:mdna:41]

[0001193125-26-076622:mdna:43]
[same as prior period, unchanged from 0001193125-25-297237:mdna:42]

[0001193125-26-076622:mdna:44]
[same as prior period, unchanged from 0001193125-25-297237:mdna:43]

[0001193125-26-076622:mdna:45]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |
| Cost of product revenues |  | $ | 353 |  |  | $ | 330 |  |  |  | 7 | % |  | $ | 976 |  |  | $ | 906 |  |  |  | 8 | % |
| Hybrid Cloud |  |  | 351 |  |  |  | 328 |  |  |  | 7 | % |  |  | 971 |  |  |  | 901 |  |  |  | 8 | % |
| Unallocated |  |  | 2 |  |  |  | 2 |  |  |  | — | % |  |  | 5 |  |  |  | 5 |  |  |  | — | % |

[0001193125-26-076622:mdna:46]
[same as prior period, unchanged from 0001193125-25-297237:mdna:45]

[0001193125-26-076622:mdna:47]
Cost of Hybrid Cloud product revenues represented 45% and 44% of product revenues for the third quarter and first nine months of fiscal 2026, respectively, compared to 43% and 41% for the corresponding periods of the prior year, respectively. Materials costs represented 90% of cost of Hybrid Cloud product revenues for the third quarter and first nine months of fiscal 2026, compared to 89% for the corresponding periods of the prior year.

[0001193125-26-076622:mdna:48]
[same as prior period, unchanged from 0001193125-25-297237:mdna:47]

[0001193125-26-076622:mdna:49]
Materials costs increased by $25 million and $73 million in the third quarter and first nine months of fiscal 2026, respectively, compared to the corresponding periods of the prior year.

[0001193125-26-076622:mdna:50]
Hybrid Cloud product gross margins decreased one percentage point in the third quarter and decreased three percentage points in the first nine months of fiscal 2026 compared to the corresponding periods of the prior year primarily due to higher component costs.

[0001193125-26-076622:mdna:51]
[same as prior period, unchanged from 0001193125-25-297237:mdna:50]

[0001193125-26-076622:mdna:52]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |
| Cost of services revenues |  | $ | 151 |  |  | $ | 166 |  |  |  | (9 | )% |  | $ | 467 |  |  | $ | 514 |  |  |  | (9 | )% |
| Support |  |  | 49 |  |  |  | 48 |  |  |  | 2 | % |  |  | 150 |  |  |  | 149 |  |  |  | 1 | % |
| Professional and other services |  |  | 68 |  |  |  | 63 |  |  |  | 8 | % |  |  | 205 |  |  |  | 191 |  |  |  | 7 | % |
| Public cloud |  |  | 26 |  |  |  | 41 |  |  |  | (37 | )% |  |  | 87 |  |  |  | 131 |  |  |  | (34 | )% |
| Unallocated |  |  | 8 |  |  |  | 14 |  |  |  | (43 | )% |  |  | 25 |  |  |  | 43 |  |  |  | (42 | )% |

[0001193125-26-076622:mdna:53]
[same as prior period, unchanged from 0001193125-25-297237:mdna:52]

[0001193125-26-076622:mdna:54]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, increased in the third quarter and first nine months of fiscal 2026 compared to the corresponding periods of the prior year. Cost of Hybrid Cloud services revenues represented 16% of Hybrid Cloud services revenues for the third quarter and first nine months of fiscal 2026 and the corresponding periods of the prior year.

[0001193125-26-076622:mdna:55]
Hybrid Cloud support gross margins were relatively flat in the third quarter and first nine months of fiscal 2026 compared to the corresponding periods of the prior year. Hybrid Cloud professional and other services gross margins increased by three percentage points in the third quarter of fiscal 2026 and five percentage points in the first nine months of 2026 compared to the corresponding periods of the prior year due primarily to the mix of services provided.

[0001193125-26-076622:mdna:56]
[same as prior period, unchanged from 0001193125-25-297237:mdna:55]

[0001193125-26-076622:mdna:57]
Cost of Public Cloud revenues decreased and gross margins increased by nine percentage points in the third quarter and first nine months of fiscal 2026 compared to the corresponding periods of the prior year. The decrease in cost of Public Cloud revenues and improved gross margins was due to cost optimization that included a decrease in fixed assets depreciation, and the mix of offerings provided which was impacted by the sale of our Spot by NetApp business in the fourth quarter of fiscal 2025.

[0001193125-26-076622:mdna:58]
[same as prior period, unchanged from 0001193125-25-297237:mdna:57]

[0001193125-26-076622:mdna:59]
Unallocated cost of services revenues decreased in the third quarter and first nine months of fiscal 2026 compared to the corresponding periods of the prior year, due to lower intangible asset amortization expense from the derecognition of certain intangible assets as a result of the sale of our Spot by NetApp business during the fourth quarter of fiscal 2025.

[0001193125-26-076622:mdna:60]
[same as prior period, unchanged from 0001193125-25-297237:mdna:59]

[0001193125-26-076622:mdna:61]
[same as prior period, unchanged from 0001193125-25-297237:mdna:60]

[0001193125-26-076622:mdna:62]
Sales and marketing, research and development, and general and administrative expenses for the third quarter and first nine months of fiscal 2026 totaled $778 million, or 45% of net revenues, and $2,370 million, or 48% of net revenues, respectively, reflecting a decrease of two percentage points and one percentage point, respectively, compared to the corresponding periods of the prior year, primarily due to the increase in net revenues.

[0001193125-26-076622:mdna:63]
[same as prior period, unchanged from 0001193125-25-297237:mdna:62]

[0001193125-26-076622:mdna:64]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses in the third quarter and first nine months of fiscal 2026 were relatively flat compared to the corresponding periods of the prior year, despite the unfavorable impact from fluctuations in foreign currency exchange rates.

[0001193125-26-076622:mdna:65]
[same as prior period, unchanged from 0001193125-25-297237:mdna:66]

[0001193125-26-076622:mdna:66]
[same as prior period, unchanged from 0001193125-25-297237:mdna:64]

[0001193125-26-076622:mdna:67]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 455 |  |  | $ | 451 |  |  |  | 1 | % |  | $ | 1,381 |  |  | $ | 1,407 |  |  |  | (2 | )% |

[0001193125-26-076622:mdna:68]
[same as prior period, unchanged from 0001193125-25-297237:mdna:67]

[0001193125-26-076622:mdna:69]
The increase in sales and marketing expenses in the third quarter of fiscal 2026 compared to the corresponding period of the prior year was primarily due to higher commission expenses, partially offset by lower compensation costs.

[0001193125-26-076622:mdna:70]
The decrease in sales and marketing expenses in the first nine months of fiscal 2026 compared to the corresponding period of the prior year was primarily due to lower compensation costs.

[0001193125-26-076622:mdna:71]
[same as prior period, unchanged from 0001193125-25-297237:mdna:69]

[0001193125-26-076622:mdna:72]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |
| Research and development expenses |  | $ | 237 |  |  | $ | 247 |  |  |  | (4 | )% |  | $ | 730 |  |  | $ | 756 |  |  |  | (3 | )% |

[0001193125-26-076622:mdna:73]
[same as prior period, unchanged from 0001193125-25-297237:mdna:71]

[0001193125-26-076622:mdna:74]
Research and development expenses decreased in the third quarter and first nine months of fiscal 2026 compared to the corresponding periods of the prior year, primarily attributable to lower compensation costs and lower spend on engineering projects.

[0001193125-26-076622:mdna:75]
[same as prior period, unchanged from 0001193125-25-297237:mdna:73]

[0001193125-26-076622:mdna:76]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |
| General and administrative expenses |  | $ | 86 |  |  | $ | 74 |  |  |  | 16 | % |  | $ | 259 |  |  | $ | 226 |  |  |  | 15 | % |

[0001193125-26-076622:mdna:77]
[same as prior period, unchanged from 0001193125-25-297237:mdna:75]

[0001193125-26-076622:mdna:78]
General and administrative expenses increased in the third quarter and first nine months of fiscal 2026 compared to the corresponding periods of the prior year, primarily attributable to higher compensation costs and higher spend on professional services.

[0001193125-26-076622:mdna:79]
[same as prior period, unchanged from 0001193125-25-297237:mdna:77]

[0001193125-26-076622:mdna:80]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |
| Restructuring charges |  | $ | (3 | ) |  | $ | 9 |  |  |  | (133 | )% |  | $ | 22 |  |  | $ | 38 |  |  |  | (42 | )% |

[0001193125-26-076622:mdna:81]
In the first nine months of fiscal 2026, we incurred charges related to a restructuring plan previously approved by management in the fourth quarter of fiscal 2025, as well as a restructuring plan approved by management in the second quarter of fiscal 2026 to redirect resources to the highest return activities and reduce costs. The activities under these plans are expected to be substantially complete by the end of fiscal 2026.

[0001193125-26-076622:mdna:82]
In the first nine months of fiscal 2025, management approved restructuring plans to redirect resources to the highest return activities and reduce costs. The activities under these plans were substantially completed by the end of fiscal 2025.

[0001193125-26-076622:mdna:83]
[same as prior period, unchanged from 0001193125-25-297237:mdna:81]

[0001193125-26-076622:mdna:84]
[same as prior period, unchanged from 0001193125-25-297237:mdna:82]

[0001193125-26-076622:mdna:85]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |
| Interest income |  | $ | 25 |  |  | $ | 20 |  |  |  | 25 | % |  | $ | 88 |  |  | $ | 83 |  |  |  | 6 | % |
| Interest expense |  |  | (26 | ) |  |  | (12 | ) |  |  | 117 | % |  |  | (81 | ) |  |  | (43 | ) |  |  | 88 | % |
| Other, net |  |  | — |  |  |  | — |  |  | NM |  |  |  | (19 | ) |  |  | — |  |  | NM |  |
| Total |  | $ | (1 | ) |  | $ | 8 |  |  |  | (113 | )% |  | $ | (12 | ) |  | $ | 40 |  |  |  | (130 | )% |

[0001193125-26-076622:mdna:86]
[same as prior period, unchanged from 0001193125-25-297237:mdna:84]

[0001193125-26-076622:mdna:87]
Interest income increased in the third quarter and first nine months of fiscal 2026 compared to the corresponding periods of the prior year, primarily due to higher average cash and investment balances.

[0001193125-26-076622:mdna:88]
Interest expense increased in the third quarter and first nine months of fiscal 2026 compared to the corresponding periods of the prior year due to a higher average outstanding aggregate principal amount of Senior Notes, with a higher average coupon rate.

[0001193125-26-076622:mdna:89]
The difference in Other, net in the first nine months of fiscal 2026 compared to the corresponding period of the prior year is primarily due to fluctuations in foreign exchange gains and losses year-over-year.

[0001193125-26-076622:mdna:90]
[same as prior period, unchanged from 0001193125-25-297237:mdna:88]

[0001193125-26-076622:mdna:91]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | % Change |  |
| Provision for income taxes |  | $ | 99 |  |  | $ | 71 |  |  |  | 39 | % |  | $ | 258 |  |  | $ | 183 |  |  |  | 41 | % |
| Effective tax rate |  |  | 22.9 | % |  |  | 19.2 | % |  | NM |  |  |  | 22.8 | % |  |  | 17.8 | % |  | NM |  |

[0001193125-26-076622:mdna:92]
[same as prior period, unchanged from 0001193125-25-297237:mdna:90]

[0001193125-26-076622:mdna:93]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate which is offset by non-deductible stock-based compensation and state taxes. Our effective tax rate for the three and nine months ended January 23, 2026 includes a decrease in discrete tax benefits related to stock-based compensation compared to the corresponding periods of the prior year.

[0001193125-26-076622:mdna:94]
As of January 23, 2026, we had $71 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $48 million of net unrecognized tax benefits would affect our provision for income taxes if recognized and have been recorded in other long-term liabilities.

[0001193125-26-076622:mdna:95]
[same as prior period, unchanged from 0001193125-25-297237:mdna:93]

[0001193125-26-076622:mdna:96]
| (In millions) |  | January 23, 2026 |  |  | April 25,2025 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,008 |  |  | $ | 3,846 |  |
| Principal amount of debt |  | $ | 2,500 |  |  | $ | 3,250 |  |

[0001193125-26-076622:mdna:97]
[same as prior period, unchanged from 0001193125-25-297237:mdna:95]

[0001193125-26-076622:mdna:98]
|  |  | Nine Months Ended |  |
| (In millions) |  | January 23, 2026 |  |  | January 24, 2025 |  |
| Net cash provided by operating activities |  | $ | 1,117 |  |  | $ | 831 |  |
| Net cash (used in) provided by investing activities |  |  | (415 | ) |  |  | 460 |  |
| Net cash used in financing activities |  |  | (1,819 | ) |  |  | (1,679 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 3 |  |  |  | (3 | ) |
| Net change in cash, cash equivalents and restricted cash |  | $ | (1,114 | ) |  | $ | (391 | ) |

[0001193125-26-076622:mdna:99]
[same as prior period, unchanged from 0001193125-25-297237:mdna:97]

[0001193125-26-076622:mdna:100]
As of January 23, 2026, our cash, cash equivalents and short-term investments were $3.0 billion, which represents a decrease of $838 million during the first nine months of fiscal 2026. The decrease was primarily due to a $750 million principal repayment of our 1.875% Senior Notes due June 2025, $750 million used for the repurchase of our common stock, $310 million used for the payment of dividends, and $148 million used for purchases of property and equipment, partially offset by $1.1 billion provided by operating activities. Our working capital was $1.4 billion as of January 23, 2026, representing an increase of $213 million compared to April 25, 2025.

[0001193125-26-076622:mdna:101]
[same as prior period, unchanged from 0001193125-25-297237:mdna:99]

[0001193125-26-076622:mdna:102]
During the first nine months of fiscal 2026, cash provided by operating activities reflected net income of $872 million which was increased for non-cash depreciation and amortization expense of $151 million and non-cash stock-based compensation expense of $282 million. During the first nine months of fiscal 2025, cash provided by operating activities reflected net income of $846 million which was increased for non-cash depreciation and amortization expense of $190 million and non-cash stock-based compensation expense of $291 million.

[0001193125-26-076622:mdna:103]
Significant changes in assets and liabilities in the first nine months of fiscal 2026 included the following:

[0001193125-26-076622:mdna:104]
•
Accounts payable decreased by $98 million, primarily reflecting the timing of purchases from, and payments to, our contract manufacturers.

[0001193125-26-076622:mdna:105]
•
Accrued expenses decreased by $248 million, primarily due to employee compensation payments related to our fiscal 2025 incentive compensation plan accrual.

[0001193125-26-076622:mdna:106]
[same as prior period, unchanged from 0001193125-25-297237:mdna:105]

[0001193125-26-076622:mdna:107]
[same as prior period, unchanged from 0001193125-25-297237:mdna:106]

[0001193125-26-076622:mdna:108]
During the first nine months of fiscal 2026, we used $282 million in purchases of investments, net of maturities and sales, and paid $148 million for capital expenditures, as compared to the same period of fiscal 2025, in which we generated $590 million from maturities and sales of investments, net of purchases, and paid $133 million for capital expenditures.

[0001193125-26-076622:mdna:109]
[same as prior period, unchanged from 0001193125-25-297237:mdna:108]

[0001193125-26-076622:mdna:110]
During the first nine months of fiscal 2026, we used $750 million for the principal repayment upon maturity of our 1.875% Senior Notes due in June 2025, $750 million for the repurchase of 7.0 million shares of common stock, and $310 million for the payment of dividends. During the first nine months of fiscal 2025, we used $900 million for the repurchase of 7.4 million shares of common stock, $400 million principal repayment upon maturity of our 3.30% Senior Notes due in September 2024 and $319 million for the payment of dividends.

[0001193125-26-076622:mdna:111]
[same as prior period, unchanged from 0001193125-25-297237:mdna:110]

[0001193125-26-076622:mdna:112]
[same as prior period, unchanged from 0001193125-25-297237:mdna:111]

[0001193125-26-076622:mdna:113]
Our principal sources of liquidity as of January 23, 2026 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0001193125-26-076622:mdna:114]
[same as prior period, unchanged from 0001193125-25-297237:mdna:113]

[0001193125-26-076622:mdna:115]
|  |  | January 23, 2026 |  |  | April 25, 2025 |  |
| Cash and cash equivalents |  | $ | 1,629 |  |  | $ | 2,742 |  |
| Short-term investments |  |  | 1,379 |  |  |  | 1,104 |  |
| Total |  | $ | 3,008 |  |  | $ | 3,846 |  |

[0001193125-26-076622:mdna:116]
As of January 23, 2026 and April 25, 2025, $2.6 billion and $2.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $394 million and $1.3 billion, respectively, were available in the U.S.

[0001193125-26-076622:mdna:117]
[same as prior period, unchanged from 0001193125-25-297237:mdna:117]

[0001193125-26-076622:mdna:118]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counterparties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of January 23, 2026.

[0001193125-26-076622:mdna:119]
[same as prior period, unchanged from 0001193125-25-297237:mdna:119]

[0001193125-26-076622:mdna:120]
[same as prior period, unchanged from 0001193125-25-297237:mdna:120]

[0001193125-26-076622:mdna:121]
The following table summarizes the principal amount of our Senior Notes as of January 23, 2026 (in millions):

[0001193125-26-076622:mdna:122]
|  |  | Amount |  |
| 2.375% Senior Notes Due June 2027 |  | $ | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| 5.50% Senior Notes Due March 2032 |  |  | 625 |  |
| 5.70% Senior Notes Due March 2035 |  |  | 625 |  |
| Total |  | $ | 2,500 |  |

[0001193125-26-076622:mdna:123]
[same as prior period, unchanged from 0001193125-25-297237:mdna:123]

[0001193125-26-076622:mdna:124]
On June 23, 2025, upon maturity, we repaid our 1.875% Senior Notes due June 2025 for an aggregate amount of $757 million, comprised of the principal and unpaid interest.

[0001193125-26-076622:mdna:125]
Commercial Paper Program and Credit Facility

[0001193125-26-076622:mdna:126]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of January 23, 2026.

[0001193125-26-076622:mdna:127]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in March 2025, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on March 5, 2030, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 23, 2026, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0001193125-26-076622:mdna:128]
[same as prior period, unchanged from 0001193125-25-297237:mdna:128]

[0001193125-26-076622:mdna:129]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2026 to be between $50 million and $100 million.

[0001193125-26-076622:mdna:130]
[same as prior period, unchanged from 0001193125-25-297237:mdna:130]

[0001193125-26-076622:mdna:131]
[same as prior period, unchanged from 0001193125-25-297237:mdna:131]

[0001193125-26-076622:mdna:132]
[same as prior period, unchanged from 0001193125-25-297237:mdna:132]

[0001193125-26-076622:mdna:133]
On February 19, 2026, we declared a cash dividend of $0.52 per share of common stock, payable on April 22, 2026, to holders of record as of the close of business on April 3, 2026.

[0001193125-26-076622:mdna:134]
In the first quarter of fiscal 2026, our Board of Directors authorized the repurchase of an additional $1.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. As of January 23, 2026, the remaining authorized amount for stock repurchases under this program was $702 million.

[0001193125-26-076622:mdna:135]
[same as prior period, unchanged from 0001193125-25-297237:mdna:135]

[0001193125-26-076622:mdna:136]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled $1.1 billion as of January 23, 2026.

[0001193125-26-076622:mdna:137]
[same as prior period, unchanged from 0001193125-25-297237:mdna:137]

[0001193125-26-076622:mdna:138]
We enter into financing and leasing contracts through the ordinary course of business. These arrangements and related financing guarantees are described in Note 14 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1. There has been no material change in our financing guarantees as described in our 2025 Annual Report on Form 10-K.

[0001193125-26-076622:mdna:139]
Legal Contingencies

[0001193125-26-076622:mdna:140]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 14 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1.

[0001193125-26-076622:mdna:141]
[same as prior period, unchanged from 0001193125-25-297237:mdna:141]

[0001193125-26-076622:mdna:142]
[same as prior period, unchanged from 0001193125-25-297237:mdna:142]

[0001193125-26-076622:mdna:143]
35
