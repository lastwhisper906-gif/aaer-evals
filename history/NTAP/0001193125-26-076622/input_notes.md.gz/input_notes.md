# NTAP notes — 0001193125-26-076622


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-26-076622:notes:1]
[same as prior period, unchanged from 0001193125-25-297237:notes:1]

[0001193125-26-076622:notes:2]
NetApp, Inc. (we, us, our, NetApp, or the Company) helps customers make their data infrastructure more seamless, more dynamic, and higher performing. We provide a full range of enterprise-class software, systems, and services that customers use to transform their data infrastructures across data types, workloads, and environments to realize business possibilities.

[0001193125-26-076622:notes:3]
[same as prior period, unchanged from 0001193125-25-297237:notes:3]

[0001193125-26-076622:notes:4]
[same as prior period, unchanged from 0001193125-25-297237:notes:4]

[0001193125-26-076622:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 25, 2025 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 23, 2026 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001193125-26-076622:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, the anticipated effects of which have been incorporated, as applicable, into management's estimates as of January 23, 2026.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001193125-26-076622:notes:7]
2. Recent Accounting Pronouncements

[0001193125-26-076622:notes:8]
In September 2025, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software. The ASU simplifies the capitalization guidance by removing all references to prescriptive and sequential software development stages (referred to as “project stages”) throughout ASC 350-40. The ASU is effective for annual periods beginning after December 15, 2027, with early adoption permitted. Adoption of this ASU can be applied prospectively; or following a modified transition approach that is based on the status of each project and whether software costs were capitalized before adoption; or retrospectively. We are currently evaluating the effect of this pronouncement on our consolidated financial statements and disclosures.

[0001193125-26-076622:notes:9]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires additional disclosure of the nature of expenses included in the income statement. The standard requires disclosures about specific types of expenses included in the expense captions presented in the income statement as well as disclosures about selling expenses. This ASU is effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027, with early adoption permitted. The requirements should be applied on a prospective basis while retrospective application is permitted. We are currently evaluating the effect of this pronouncement on our disclosures.

[0001193125-26-076622:notes:10]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which expands the disclosures required for income taxes. While retrospective application is permitted, we will adopt this standard in our Form 10-K for the year ending April 24, 2026 on a prospective basis. Adoption of this new guidance will result in increased disclosures in the notes to our consolidated financial statements.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-26-076622:notes:11]
[same as prior period, unchanged from 0001193125-25-297237:notes:11]

[0001193125-26-076622:notes:12]
Goodwill by reportable segment as of January 23, 2026 is as follows (in millions):

[0001193125-26-076622:notes:13]
|  |  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Balance as of April 25, 2025 |  | $ | 1,714 |  |  | $ | 1,009 |  |  | $ | 2,723 |  |
| Impact of foreign currency translation |  |  | — |  |  |  | 33 |  |  |  | 33 |  |
| Balance as of January 23, 2026 |  | $ | 1,714 |  |  | $ | 1,042 |  |  | $ | 2,756 |  |

[0001193125-26-076622:notes:14]
[same as prior period, unchanged from 0001193125-25-297237:notes:14]

[0001193125-26-076622:notes:15]
|  |  | January 23, 2026 |  |  | April 25, 2025 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 55 |  |  | $ | (41 | ) |  | $ | 14 |  |  | $ | 55 |  |  | $ | (33 | ) |  | $ | 22 |  |
| Customer contracts/relationships |  |  | 50 |  |  |  | (38 | ) |  |  | 12 |  |  |  | 50 |  |  |  | (29 | ) |  |  | 21 |  |
| Other purchased intangibles |  |  | 2 |  |  |  | (2 | ) |  |  | — |  |  |  | 2 |  |  |  | (2 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 107 |  |  | $ | (81 | ) |  | $ | 26 |  |  | $ | 107 |  |  | $ | (64 | ) |  | $ | 43 |  |

[0001193125-26-076622:notes:16]
[same as prior period, unchanged from 0001193125-25-297237:notes:16]

[0001193125-26-076622:notes:17]
|  |  | Three Months Ended |  |  | Nine Months Ended |  | Statements of |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | January 23, 2026 |  |  | January 24, 2025 |  | IncomeClassifications |
| Developed technology |  | $ | 2 |  |  | $ | 8 |  |  | $ | 8 |  |  | $ | 25 |  | Cost of revenues |
| Customer contracts/relationships |  |  | 3 |  |  |  | 5 |  |  |  | 9 |  |  |  | 16 |  | Operating expenses |
| Total |  | $ | 5 |  |  | $ | 13 |  |  | $ | 17 |  |  | $ | 41 |  |  |

[0001193125-26-076622:notes:18]
As of January 23, 2026, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001193125-26-076622:notes:19]
| Fiscal Year |  | Amount |  |
| 2026 (remainder) |  | $ | 4 |  |
| 2027 |  |  | 21 |  |
| 2028 |  |  | 1 |  |
| Total |  | $ | 26 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-26-076622:notes:20]
[same as prior period, unchanged from 0001193125-25-297237:notes:20]

[0001193125-26-076622:notes:21]
[same as prior period, unchanged from 0001193125-25-297237:notes:21]

[0001193125-26-076622:notes:22]
[same as prior period, unchanged from 0001193125-25-297237:notes:22]

[0001193125-26-076622:notes:23]
|  |  | January 23, 2026 |  |  | April 25,2025 |  |
| Cash and cash equivalents |  | $ | 1,629 |  |  | $ | 2,742 |  |
| Restricted cash |  |  | 6 |  |  |  | 7 |  |
| Cash, cash equivalents and restricted cash |  | $ | 1,635 |  |  | $ | 2,749 |  |

[0001193125-26-076622:notes:24]
[same as prior period, unchanged from 0001193125-25-297237:notes:24]

[0001193125-26-076622:notes:25]
|  |  | January 23, 2026 |  |  | April 25,2025 |  |
| Purchased components |  | $ | 32 |  |  | $ | 81 |  |
| Finished goods |  |  | 77 |  |  |  | 105 |  |
| Inventories |  | $ | 109 |  |  | $ | 186 |  |

[0001193125-26-076622:notes:26]
[same as prior period, unchanged from 0001193125-25-297237:notes:26]

[0001193125-26-076622:notes:27]
|  |  | January 23, 2026 |  |  | April 25,2025 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 376 |  |  |  | 374 |  |
| Leasehold improvements |  |  | 114 |  |  |  | 103 |  |
| Computer, production, engineering and other equipment |  |  | 1,241 |  |  |  | 1,172 |  |
| Computer software |  |  | 336 |  |  |  | 329 |  |
| Furniture and fixtures |  |  | 62 |  |  |  | 62 |  |
| Construction-in-progress |  |  | 55 |  |  |  | 49 |  |
|  |  |  | 2,230 |  |  |  | 2,135 |  |
| Accumulated depreciation and amortization |  |  | (1,654 | ) |  |  | (1,572 | ) |
| Property and equipment, net |  | $ | 576 |  |  | $ | 563 |  |

[0001193125-26-076622:notes:28]
[same as prior period, unchanged from 0001193125-25-297237:notes:28]

[0001193125-26-076622:notes:29]
|  |  | January 23, 2026 |  |  | April 25,2025 |  |
| Deferred tax assets |  | $ | 946 |  |  | $ | 994 |  |
| Operating lease right-of-use (ROU) assets |  |  | 231 |  |  |  | 241 |  |
| Other assets |  |  | 440 |  |  |  | 408 |  |
| Other non-current assets |  | $ | 1,617 |  |  | $ | 1,643 |  |

[0001193125-26-076622:notes:30]
Other non-current assets as of January 23, 2026 and April 25, 2025 include $96 million and $92 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies.

[0001193125-26-076622:notes:31]
[same as prior period, unchanged from 0001193125-25-297237:notes:31]

[0001193125-26-076622:notes:32]
|  |  | January 23, 2026 |  |  | April 25,2025 |  |
| Accrued compensation and benefits |  | $ | 376 |  |  | $ | 513 |  |
| Product warranty liabilities |  |  | 16 |  |  |  | 18 |  |
| Operating lease liabilities |  |  | 41 |  |  |  | 40 |  |
| Other current liabilities |  |  | 475 |  |  |  | 551 |  |
| Accrued expenses |  | $ | 908 |  |  | $ | 1,122 |  |

[0001193125-26-076622:notes:33]
[same as prior period, unchanged from 0001193125-25-297237:notes:33]

[0001193125-26-076622:notes:34]
|  |  | January 23, 2026 |  |  | April 25,2025 |  |
| Liability for uncertain tax positions |  | $ | 48 |  |  | $ | 45 |  |
| Product warranty liabilities |  |  | 9 |  |  |  | 9 |  |
| Operating lease liabilities |  |  | 207 |  |  |  | 216 |  |
| Other liabilities |  |  | 111 |  |  |  | 109 |  |
| Other long-term liabilities |  | $ | 375 |  |  | $ | 379 |  |

[0001193125-26-076622:notes:35]
[same as prior period, unchanged from 0001193125-25-297237:notes:35]

[0001193125-26-076622:notes:36]
Deferred revenue primarily represents customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 14 – Commitments and Contingencies for additional information related to these arrangements.

[0001193125-26-076622:notes:37]
During the nine months ended January 23, 2026 and January 24, 2025, we recognized revenue of $1,804 million and $1,737 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0001193125-26-076622:notes:38]
[same as prior period, unchanged from 0001193125-25-297237:notes:38]

[0001193125-26-076622:notes:39]
As of January 23, 2026, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $5.1 billion. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 48% of our remaining performance obligations in the next 12 months and the remainder thereafter.

[0001193125-26-076622:notes:40]
[same as prior period, unchanged from 0001193125-25-297237:notes:40]

[0001193125-26-076622:notes:41]
[same as prior period, unchanged from 0001193125-25-297237:notes:41]

[0001193125-26-076622:notes:42]
|  |  | January 23, 2026 |  |  | April 25,2025 |  |
| Other current assets |  | $ | 63 |  |  | $ | 64 |  |
| Other non-current assets |  |  | 115 |  |  |  | 104 |  |
| Total deferred commissions |  | $ | 178 |  |  | $ | 168 |  |

[0001193125-26-076622:notes:43]
[same as prior period, unchanged from 0001193125-25-297237:notes:43]

[0001193125-26-076622:notes:44]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | January 23, 2026 |  |  | January 24, 2025 |  |
| Interest income |  | $ | 25 |  |  | $ | 20 |  |  | $ | 88 |  |  | $ | 83 |  |
| Interest expense |  |  | (26 | ) |  |  | (12 | ) |  |  | (81 | ) |  |  | (43 | ) |
| Other, net |  |  | — |  |  |  | — |  |  |  | (19 | ) |  |  | — |  |
| Total other (expense) income, net |  | $ | (1 | ) |  | $ | 8 |  |  | $ | (12 | ) |  | $ | 40 |  |

[0001193125-26-076622:notes:45]
[same as prior period, unchanged from 0001193125-25-297237:notes:45]

[0001193125-26-076622:notes:46]
[same as prior period, unchanged from 0001193125-25-297237:notes:46]

[0001193125-26-076622:notes:47]
|  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 12 |  |  | $ | 10 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 330 |  |  | $ | 287 |  |
| Interest paid |  | $ | 74 |  |  | $ | 53 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-26-076622:notes:48]
[same as prior period, unchanged from 0001193125-25-297237:notes:48]

[0001193125-26-076622:notes:49]
[same as prior period, unchanged from 0001193125-25-297237:notes:49]

[0001193125-26-076622:notes:50]
[same as prior period, unchanged from 0001193125-25-297237:notes:50]

[0001193125-26-076622:notes:51]
[same as prior period, unchanged from 0001193125-25-297237:notes:51]

[0001193125-26-076622:notes:52]
[same as prior period, unchanged from 0001193125-25-297237:notes:52]

[0001193125-26-076622:notes:53]
[same as prior period, unchanged from 0001193125-25-297237:notes:53]

[0001193125-26-076622:notes:54]
[same as prior period, unchanged from 0001193125-25-297237:notes:54]

[0001193125-26-076622:notes:55]
The following is a summary of our investments at their cost or amortized cost as of January 23, 2026 and April 25, 2025 (in millions):

[0001193125-26-076622:notes:56]
|  |  | January 23, 2026 |  |  | April 25,2025 |  |
| U.S. Treasury and government debt securities |  | $ | 1,379 |  |  | $ | 2,025 |  |
| Money market funds |  |  | 876 |  |  |  | 1,126 |  |
| Certificates of deposit |  |  | 47 |  |  |  | 24 |  |
| Mutual funds |  |  | 48 |  |  |  | 41 |  |
| Total debt and equity securities |  | $ | 2,350 |  |  | $ | 3,216 |  |

[0001193125-26-076622:notes:57]
[same as prior period, unchanged from 0001193125-25-297237:notes:57]

[0001193125-26-076622:notes:58]
As of January 23, 2026, all our debt investments are due to mature in one year or less.

[0001193125-26-076622:notes:59]
[same as prior period, unchanged from 0001193125-25-297237:notes:59]

[0001193125-26-076622:notes:60]
[same as prior period, unchanged from 0001193125-25-297237:notes:60]

[0001193125-26-076622:notes:61]
|  |  | January 23, 2026 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 706 |  |  | $ | 706 |  |  | $ | — |  |
| Money market funds |  |  | 876 |  |  |  | 876 |  |  |  | — |  |
| Certificates of deposit |  |  | 47 |  |  |  | — |  |  |  | 47 |  |
| Total cash and cash equivalents |  |  | 1,629 |  |  |  | 1,582 |  |  |  | 47 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 1,379 |  |  |  | 1,379 |  |  |  | — |  |
| Total short-term investments |  |  | 1,379 |  |  |  | 1,379 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,008 |  |  | $ | 2,961 |  |  | $ | 47 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 41 |  |  | $ | 41 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 6 |  |  | $ | — |  |  | $ | 6 |  |

[0001193125-26-076622:notes:62]
[same as prior period, unchanged from 0001193125-25-297237:notes:62]

[0001193125-26-076622:notes:63]
[same as prior period, unchanged from 0001193125-25-297237:notes:63]

[0001193125-26-076622:notes:64]
[same as prior period, unchanged from 0001193125-25-297237:notes:64]

[0001193125-26-076622:notes:65]
[same as prior period, unchanged from 0001193125-25-297237:notes:65]

[0001193125-26-076622:notes:66]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of January 23, 2026 and April 25, 2025, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001193125-26-076622:notes:67]
[same as prior period, unchanged from 0001193125-25-297237:notes:67]

[0001193125-26-076622:notes:68]
As of January 23, 2026 and April 25, 2025, the fair value of our long-term debt, which includes the current portion of long-term debt, was $2,486 million and $3,143 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0001193125-26-076622:notes:69]
6. Financing Arrangements

[0001193125-26-076622:notes:70]
Long-Term Debt

[0001193125-26-076622:notes:71]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001193125-26-076622:notes:72]
|  |  | Effective Interest Rate |  | January 23, 2026 |  |  | April 25, 2025 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  | $ | — |  |  | $ | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| 5.50% Senior Notes Due March 2032 |  | 5.71% |  |  | 625 |  |  |  | 625 |  |
| 5.70% Senior Notes Due March 2035 |  | 5.90% |  |  | 625 |  |  |  | 625 |  |
| Total principal amount |  |  |  |  | 2,500 |  |  |  | 3,250 |  |
| Unamortized discount and issuance costs |  |  |  |  | (14 | ) |  |  | (15 | ) |
| Total senior notes |  |  |  |  | 2,486 |  |  |  | 3,235 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (750 | ) |
| Total long-term debt |  |  |  | $ | 2,486 |  |  | $ | 2,485 |  |

[0001193125-26-076622:notes:73]
Senior Notes

[0001193125-26-076622:notes:74]
On June 23, 2025, upon maturity, we repaid the 1.875% Senior Notes due June 2025 for an aggregate amount of $757 million, comprised of the principal and unpaid interest.

[0001193125-26-076622:notes:75]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness. Interest on our Senior Notes is payable semi-annually.

[0001193125-26-076622:notes:76]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 23, 2026, we were in compliance with all covenants associated with the Senior Notes.

[0001193125-26-076622:notes:77]
As of January 23, 2026, our aggregate future principal debt maturities are as follows (in millions):

[0001193125-26-076622:notes:78]
| Fiscal Year |  | Amount |  |
| 2026 |  | $ | — |  |
| 2027 |  |  | — |  |
| 2028 |  |  | 550 |  |
| 2029 |  |  | — |  |
| 2030 |  |  | — |  |
| Thereafter |  |  | 1,950 |  |
| Total |  | $ | 2,500 |  |

[0001193125-26-076622:notes:79]
Commercial Paper Program and Credit Facility

[0001193125-26-076622:notes:80]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of January 23, 2026 or April 25, 2025.

[0001193125-26-076622:notes:81]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in March 2025, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on March 5, 2030, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 23, 2026, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0001193125-26-076622:notes:82]
[same as prior period, unchanged from 0001193125-25-297237:notes:82]

[0001193125-26-076622:notes:83]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of January 23, 2026, have remaining lease terms not exceeding 16 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of January 23, 2026, have remaining lease terms not exceeding 4 years. As of January 23, 2026, our automobile leases have remaining lease terms not exceeding 4 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0001193125-26-076622:notes:84]
[same as prior period, unchanged from 0001193125-25-297237:notes:84]

[0001193125-26-076622:notes:85]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | January 23, 2026 |  |  | January 24, 2025 |  |
| Operating lease cost |  | $ | 12 |  |  | $ | 13 |  |  | $ | 38 |  |  | $ | 38 |  |
| Variable lease cost |  |  | 4 |  |  |  | 3 |  |  |  | 11 |  |  |  | 11 |  |
| Total lease cost |  | $ | 16 |  |  | $ | 16 |  |  | $ | 49 |  |  | $ | 49 |  |

[0001193125-26-076622:notes:86]
[same as prior period, unchanged from 0001193125-25-297237:notes:86]

[0001193125-26-076622:notes:87]
[same as prior period, unchanged from 0001193125-25-297237:notes:87]

[0001193125-26-076622:notes:88]
|  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 37 |  |  | $ | 36 |  |
| ROU assets obtained in exchange for new operating lease obligations |  | $ | 11 |  |  | $ | 18 |  |

[0001193125-26-076622:notes:89]
[same as prior period, unchanged from 0001193125-25-297237:notes:89]

[0001193125-26-076622:notes:90]
|  |  | January 23, 2026 |  |  | April 25, 2025 |  |
| Other non-current assets |  | $ | 231 |  |  | $ | 241 |  |
| Total operating lease ROU assets |  | $ | 231 |  |  | $ | 241 |  |
| Accrued expenses |  | $ | 41 |  |  | $ | 40 |  |
| Other long-term liabilities |  |  | 207 |  |  |  | 216 |  |
| Total operating lease liabilities |  | $ | 248 |  |  | $ | 256 |  |
| Weighted Average Remaining Lease Term |  | 8.0 years |  |  | 8.5 years |  |
| Weighted Average Discount Rate |  |  | 3.5 | % |  |  | 3.4 | % |

[0001193125-26-076622:notes:91]
Future minimum operating lease payments as of January 23, 2026, are as follows (in millions):

[0001193125-26-076622:notes:92]
| Fiscal Year |  |  |  | Amount |  |
| 2026 (remainder) |  |  |  | $ | 13 |  |
| 2027 |  |  |  |  | 47 |  |
| 2028 |  |  |  |  | 41 |  |
| 2029 |  |  |  |  | 36 |  |
| 2030 |  |  |  |  | 31 |  |
| Thereafter |  |  |  |  | 118 |  |
| Total lease payments |  |  |  |  | 286 |  |
| Less: Interest |  |  |  |  | (38 | ) |
| Total |  |  |  | $ | 248 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001193125-26-076622:notes:93]
[same as prior period, unchanged from 0001193125-25-297237:notes:93]

[0001193125-26-076622:notes:94]
[same as prior period, unchanged from 0001193125-25-297237:notes:94]

[0001193125-26-076622:notes:95]
We granted 4 million restricted stock units (RSUs), including performance-based RSUs (PBRSUs), with a weighted average grant date fair value of $105.44 per share during the nine months ended January 23, 2026.

[0001193125-26-076622:notes:96]
In the nine months ended January 23, 2026, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSUs cliff-vest at the end of a three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the third fiscal year, following the grant date. The number of shares that will be used to calculate the settlement amount for all of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the nine months ended January 23, 2026, the number of shares used to calculate the settlement amount will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. For the remaining half of the PBRSUs granted in the nine months ended January 23, 2026, the number of shares used to calculate the settlement amount will depend upon the Company's billings result average over the three-year performance period. The billings result average is computed based on achievement against annual billings targets, with each target set at the beginning of the respective fiscal year, during the three-year performance period. Billings, for purposes of measuring the performance of these PBRSUs, means the total obtained by adding net revenues as reported on the Company's condensed consolidated statements of income to the amount reported as the change in deferred revenue and financed unearned services revenue on the condensed consolidated statements of cash flows for the applicable

[0001193125-26-076622:notes:97]
measurement period, excluding the impact of fluctuations in foreign currency exchange rates. The aggregate grant date fair value of PBRSUs granted in the current year was $63 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0001193125-26-076622:notes:98]
[same as prior period, unchanged from 0001193125-25-297237:notes:98]

[0001193125-26-076622:notes:99]
[same as prior period, unchanged from 0001193125-25-297237:notes:99]

[0001193125-26-076622:notes:100]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | January 23, 2026 |  |  | January 24, 2025 |  |
| Cost of product revenues |  | $ | 2 |  |  | $ | 2 |  |  | $ | 5 |  |  | $ | 5 |  |
| Cost of services revenues |  |  | 6 |  |  |  | 6 |  |  |  | 17 |  |  |  | 18 |  |
| Sales and marketing |  |  | 38 |  |  |  | 44 |  |  |  | 114 |  |  |  | 122 |  |
| Research and development |  |  | 33 |  |  |  | 36 |  |  |  | 92 |  |  |  | 104 |  |
| General and administrative |  |  | 18 |  |  |  | 15 |  |  |  | 54 |  |  |  | 42 |  |
| Total stock-based compensation expense |  | $ | 97 |  |  | $ | 103 |  |  | $ | 282 |  |  | $ | 291 |  |

[0001193125-26-076622:notes:101]
As of January 23, 2026, total unrecognized compensation expense related to equity awards was $706 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.2 years.

[0001193125-26-076622:notes:102]
[same as prior period, unchanged from 0001193125-25-297237:notes:102]

[0001193125-26-076622:notes:103]
[same as prior period, unchanged from 0001193125-25-297237:notes:103]

[0001193125-26-076622:notes:104]
The following table summarizes activity related to the stock repurchase program for the nine months ended January 23, 2026 (in millions, except for per share amounts):

[0001193125-26-076622:notes:105]
| Number of shares repurchased |  |  | 7.0 |  |
| Average price per share |  | $ | 107.26 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 86 |  |
| Stock repurchases allocated to retained earnings |  | $ | 664 |  |
| Remaining authorization at end of period |  | $ | 702 |  |

[0001193125-26-076622:notes:106]
[same as prior period, unchanged from 0001193125-25-297237:notes:106]

[0001193125-26-076622:notes:107]
[same as prior period, unchanged from 0001193125-25-297237:notes:107]

[0001193125-26-076622:notes:108]
|  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |
| Dividends per share declared |  | $ | 1.56 |  |  | $ | 1.56 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 142 |  |  | $ | 130 |  |
| Dividend payments allocated to retained earnings |  | $ | 168 |  |  | $ | 189 |  |

[0001193125-26-076622:notes:109]
On February 19, 2026, we declared a cash dividend of $0.52 per share of common stock, payable on April 22, 2026 to holders of record as of the close of business on April 3, 2026. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-26-076622:notes:110]
[same as prior period, unchanged from 0001193125-25-297237:notes:110]

[0001193125-26-076622:notes:111]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of January 23, 2026 or April 25, 2025. All contracts have a maturity of less than 12 months.

[0001193125-26-076622:notes:112]
[same as prior period, unchanged from 0001193125-25-297237:notes:112]

[0001193125-26-076622:notes:113]
|  |  | January 23, 2026 |  |  | April 25, 2025 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 127 |  |  | $ | 81 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 1,043 |  |  | $ | 790 |  |

[0001193125-26-076622:notes:114]
[same as prior period, unchanged from 0001193125-25-297237:notes:114]

[0001193125-26-076622:notes:115]
[same as prior period, unchanged from 0001193125-25-297237:notes:115]

[0001193125-26-076622:notes:116]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | January 23, 2026 |  |  | January 24, 2025 |  |
|  |  | Gain (Loss) Recognized into Income |  |  | Loss Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 3 |  |  | $ | (36 | ) |  | $ | (6 | ) |  | $ | (22 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-26-076622:notes:117]
[same as prior period, unchanged from 0001193125-25-297237:notes:117]

[0001193125-26-076622:notes:118]
In the first nine months of fiscal 2026, we incurred charges related to a restructuring plan previously approved by management in the fourth quarter of fiscal 2025, as well as a restructuring plan approved by management in the second quarter of fiscal 2026 to redirect resources to the highest return activities and reduce costs. The activities under these plans are expected to be substantially complete by the end of fiscal 2026.

[0001193125-26-076622:notes:119]
In the first nine months of fiscal 2025, management approved restructuring plans to redirect resources to the highest return activities and reduce costs. The activities under these plans were substantially completed by the end of fiscal 2025.

[0001193125-26-076622:notes:120]
[same as prior period, unchanged from 0001193125-25-297237:notes:120]

[0001193125-26-076622:notes:121]
|  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |
| Balance at beginning of period |  | $ | 51 |  |  | $ | 10 |  |
| Net charges |  |  | 22 |  |  |  | 38 |  |
| Cash payments |  |  | (60 | ) |  |  | (29 | ) |
| Balance at end of period |  | $ | 13 |  |  | $ | 19 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-26-076622:notes:122]
[same as prior period, unchanged from 0001193125-25-297237:notes:122]

[0001193125-26-076622:notes:123]
[same as prior period, unchanged from 0001193125-25-297237:notes:123]

[0001193125-26-076622:notes:124]
|  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |
| Effective tax rates |  |  | 22.8 | % |  |  | 17.8 | % |

[0001193125-26-076622:notes:125]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate which is offset by non-deductible stock-based compensation and state taxes. Our effective tax rate for the nine months ended January 23, 2026 includes a decrease in discrete tax benefits related to stock-based compensation compared to the corresponding period of the prior year.

[0001193125-26-076622:notes:126]
On July 4, 2025, the reconciliation bill H.R. 1, referred to as the One Big Beautiful Bill Act (OBBB), was signed into law in the United States. The OBBB contains several changes to corporate taxation including the extension of key provisions of the 2017 Tax Cuts and Jobs Act and modifications to the international tax framework. The legislation has multiple effective dates, with certain provisions effective in our fiscal year 2026 and others phased in through our fiscal year 2027. We are still in the process of evaluating the impact of the OBBB on our financial statements, but an estimate of the tax benefit has been included in our operating results for the nine months ended January 23, 2026. The OBBB did not have a material impact to our income tax provision for the nine months ended January 23, 2026.

[0001193125-26-076622:notes:127]
The Organisation for Economic Co-operation and Development (OECD) introduced an international tax framework under Pillar Two that provides for a global minimum tax of 15% for large multinational companies. We are currently subject to Pillar Two rules enacted in certain foreign jurisdictions in which we operate. As of January 23, 2026, Pillar Two taxes did not have a significant impact on our financial statements, particularly due to the safe harbor relief during the transition period. On January 5, 2026, the OECD issued administrative guidance outlining a framework under which U.S.-parented groups may be excluded from the application of Pillar Two rules through a “side-by-side arrangement.” Each member jurisdiction will need to adopt this guidance into local law, and the timing and manner of adoption may vary. We will continue to monitor U.S. and international legislative developments, including further announcements on the side-by-side arrangement, to assess any potential impacts to our financial statements.

[0001193125-26-076622:notes:128]
[same as prior period, unchanged from 0001193125-25-297237:notes:128]

[0001193125-26-076622:notes:129]
[same as prior period, unchanged from 0001193125-25-297237:notes:129]

[0001193125-26-076622:notes:130]
As of January 23, 2026, we had $71 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $48 million of net unrecognized tax benefits would affect our provision for income taxes if recognized and have been recorded in other long-term liabilities.


## us-gaap:EarningsPerShareTextBlock

[0001193125-26-076622:notes:131]
[same as prior period, unchanged from 0001193125-25-297237:notes:131]

[0001193125-26-076622:notes:132]
[same as prior period, unchanged from 0001193125-25-297237:notes:132]

[0001193125-26-076622:notes:133]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | January 23, 2026 |  |  | January 24, 2025 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 334 |  |  | $ | 299 |  |  | $ | 872 |  |  | $ | 846 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 198 |  |  |  | 204 |  |  |  | 199 |  |  |  | 205 |  |
| Dilutive impact of employee equity award plans |  |  | 2 |  |  |  | 4 |  |  |  | 3 |  |  |  | 5 |  |
| Shares used in diluted computation |  |  | 200 |  |  |  | 208 |  |  |  | 202 |  |  |  | 210 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.69 |  |  | $ | 1.47 |  |  | $ | 4.38 |  |  | $ | 4.13 |  |
| Diluted |  | $ | 1.67 |  |  | $ | 1.44 |  |  | $ | 4.32 |  |  | $ | 4.03 |  |

[0001193125-26-076622:notes:134]
The following table presents the number of potential shares of common stock from outstanding employee equity awards that have been excluded from the computation of diluted net income per share, as their inclusion would have had an anti-dilutive effect, for the periods presented (in millions):

[0001193125-26-076622:notes:135]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | January 23, 2026 |  |  | January 24, 2025 |  |
| Employee equity award plans |  |  | 2 |  |  |  | — |  |  |  | 1 |  |  |  | — |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-26-076622:notes:136]
[same as prior period, unchanged from 0001193125-25-297237:notes:135]

[0001193125-26-076622:notes:137]
[same as prior period, unchanged from 0001193125-25-297237:notes:136]

[0001193125-26-076622:notes:138]
[same as prior period, unchanged from 0001193125-25-297237:notes:137]

[0001193125-26-076622:notes:139]
[same as prior period, unchanged from 0001193125-25-297237:notes:138]

[0001193125-26-076622:notes:140]
[same as prior period, unchanged from 0001193125-25-297237:notes:139]

[0001193125-26-076622:notes:141]
[same as prior period, unchanged from 0001193125-25-297237:notes:140]

[0001193125-26-076622:notes:142]
|  | Three Months Ended January 23, 2026 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Product revenues | $ | 786 |  |  | $ | — |  |  | $ | 786 |  |
| Support revenues |  | 654 |  |  |  | — |  |  |  | 654 |  |
| Professional and other services revenues |  | 99 |  |  |  | — |  |  |  | 99 |  |
| Public cloud revenues |  | — |  |  |  | 174 |  |  |  | 174 |  |
| Net revenues |  | 1,539 |  |  |  | 174 |  |  |  | 1,713 |  |
| Cost of product revenues |  | 351 |  |  |  | — |  |  |  | 351 |  |
| Cost of support revenues |  | 49 |  |  |  | — |  |  |  | 49 |  |
| Cost of professional and other services revenues |  | 68 |  |  |  | — |  |  |  | 68 |  |
| Cost of public cloud revenues |  | — |  |  |  | 26 |  |  |  | 26 |  |
| Segment cost of revenues |  | 468 |  |  |  | 26 |  |  |  | 494 |  |
| Segment gross profit | $ | 1,071 |  |  | $ | 148 |  |  | $ | 1,219 |  |
| Segment gross margin |  | 69.6 | % |  |  | 85.1 | % |  |  | 71.2 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 10 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,209 |  |
| Total gross margin |  |  |  |  |  |  |  | 70.6 | % |
| 1 Unallocated cost of revenues are composed of $8 million of stock-based compensation expense and $2 million of amortization of intangible assets. |  |

[0001193125-26-076622:notes:143]
|  | Three Months Ended January 24, 2025 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Product revenues | $ | 758 |  |  | $ | — |  |  | $ | 758 |  |
| Support revenues |  | 621 |  |  |  | — |  |  |  | 621 |  |
| Professional and other services revenues |  | 88 |  |  |  | — |  |  |  | 88 |  |
| Public cloud revenues |  | — |  |  |  | 174 |  |  |  | 174 |  |
| Net revenues |  | 1,467 |  |  |  | 174 |  |  |  | 1,641 |  |
| Cost of product revenues |  | 328 |  |  |  | — |  |  |  | 328 |  |
| Cost of support revenues |  | 48 |  |  |  | — |  |  |  | 48 |  |
| Cost of professional and other services revenues |  | 63 |  |  |  | — |  |  |  | 63 |  |
| Cost of public cloud revenues |  | — |  |  |  | 41 |  |  |  | 41 |  |
| Segment cost of revenues |  | 439 |  |  |  | 41 |  |  |  | 480 |  |
| Segment gross profit | $ | 1,028 |  |  | $ | 133 |  |  | $ | 1,161 |  |
| Segment gross margin |  | 70.1 | % |  |  | 76.4 | % |  |  | 70.7 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 16 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,145 |  |
| Total gross margin |  |  |  |  |  |  |  | 69.8 | % |
| 1 Unallocated cost of revenues are composed of $8 million of stock-based compensation expense and $8 million of amortization of intangible assets. |  |

[0001193125-26-076622:notes:144]
|  | Nine Months Ended January 23, 2026 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Product revenues | $ | 2,228 |  |  | $ | — |  |  | $ | 2,228 |  |
| Support revenues |  | 1,948 |  |  |  | — |  |  |  | 1,948 |  |
| Professional and other services revenues |  | 295 |  |  |  | — |  |  |  | 295 |  |
| Public cloud revenues |  | — |  |  |  | 506 |  |  |  | 506 |  |
| Net revenues |  | 4,471 |  |  |  | 506 |  |  |  | 4,977 |  |
| Cost of product revenues |  | 971 |  |  |  | — |  |  |  | 971 |  |
| Cost of support revenues |  | 150 |  |  |  | — |  |  |  | 150 |  |
| Cost of professional and other services revenues |  | 205 |  |  |  | — |  |  |  | 205 |  |
| Cost of public cloud revenues |  | — |  |  |  | 87 |  |  |  | 87 |  |
| Segment cost of revenues |  | 1,326 |  |  |  | 87 |  |  |  | 1,413 |  |
| Segment gross profit | $ | 3,145 |  |  | $ | 419 |  |  | $ | 3,564 |  |
| Segment gross margin |  | 70.3 | % |  |  | 82.8 | % |  |  | 71.6 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 30 |  |
| Total gross profit |  |  |  |  |  |  | $ | 3,534 |  |
| Total gross margin |  |  |  |  |  |  |  | 71.0 | % |
| 1 Unallocated cost of revenues are composed of $22 million of stock-based compensation expense and $8 million of amortization of intangible assets. |  |

[0001193125-26-076622:notes:145]
|  | Nine Months Ended January 24, 2025 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Product revenues | $ | 2,195 |  |  | $ | — |  |  | $ | 2,195 |  |
| Support revenues |  | 1,887 |  |  |  | — |  |  |  | 1,887 |  |
| Professional and other services revenues |  | 257 |  |  |  | — |  |  |  | 257 |  |
| Public cloud revenues |  | — |  |  |  | 501 |  |  |  | 501 |  |
| Net revenues |  | 4,339 |  |  |  | 501 |  |  |  | 4,840 |  |
| Cost of product revenues |  | 901 |  |  |  | — |  |  |  | 901 |  |
| Cost of support revenues |  | 149 |  |  |  | — |  |  |  | 149 |  |
| Cost of professional and other services revenues |  | 191 |  |  |  | — |  |  |  | 191 |  |
| Cost of public cloud revenues |  | — |  |  |  | 131 |  |  |  | 131 |  |
| Segment cost of revenues |  | 1,241 |  |  |  | 131 |  |  |  | 1,372 |  |
| Segment gross profit | $ | 3,098 |  |  | $ | 370 |  |  | $ | 3,468 |  |
| Segment gross margin |  | 71.4 | % |  |  | 73.9 | % |  |  | 71.7 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 48 |  |
| Total gross profit |  |  |  |  |  |  | $ | 3,420 |  |
| Total gross margin |  |  |  |  |  |  |  | 70.7 | % |
| 1 Unallocated cost of revenues are composed of $23 million of stock-based compensation expense and $25 million of amortization of intangible assets. |  |

[0001193125-26-076622:notes:146]
[same as prior period, unchanged from 0001193125-25-297237:notes:145]

[0001193125-26-076622:notes:147]
[same as prior period, unchanged from 0001193125-25-297237:notes:146]

[0001193125-26-076622:notes:148]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | January 23, 2026 |  |  | January 24, 2025 |  |
| United States, Canada and Latin America (Americas) |  | $ | 882 |  |  | $ | 833 |  |  | $ | 2,536 |  |  | $ | 2,458 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 585 |  |  |  | 559 |  |  |  | 1,660 |  |  |  | 1,615 |  |
| Asia Pacific (APAC) |  |  | 246 |  |  |  | 249 |  |  |  | 781 |  |  |  | 767 |  |
| Net revenues |  | $ | 1,713 |  |  | $ | 1,641 |  |  | $ | 4,977 |  |  | $ | 4,840 |  |

[0001193125-26-076622:notes:149]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $825 million and $768 million during the three months ended January 23, 2026 and January 24, 2025, respectively, and were $2,391 million and $2,273 million during the nine months ended January 23, 2026 and January 24, 2025, respectively.

[0001193125-26-076622:notes:150]
[same as prior period, unchanged from 0001193125-25-297237:notes:149]

[0001193125-26-076622:notes:151]
|  |  | January 23, 2026 |  |  | April 25, 2025 |  |
| U.S. |  | $ | 394 |  |  | $ | 1,320 |  |
| International |  |  | 2,614 |  |  |  | 2,526 |  |
| Total |  | $ | 3,008 |  |  | $ | 3,846 |  |

[0001193125-26-076622:notes:152]
[same as prior period, unchanged from 0001193125-25-297237:notes:151]

[0001193125-26-076622:notes:153]
|  |  | January 23, 2026 |  |  | April 25, 2025 |  |
| U.S. |  | $ | 357 |  |  | $ | 344 |  |
| International |  |  | 219 |  |  |  | 219 |  |
| Total |  | $ | 576 |  |  | $ | 563 |  |

[0001193125-26-076622:notes:154]
[same as prior period, unchanged from 0001193125-25-297237:notes:153]

[0001193125-26-076622:notes:155]
[same as prior period, unchanged from 0001193125-25-297237:notes:154]

[0001193125-26-076622:notes:156]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | January 23, 2026 |  |  | January 24, 2025 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 20 | % |  |  | 22 | % |  |  | 21 | % |
| TD Synnex Corporation |  |  | 22 | % |  |  | 26 | % |  |  | 22 | % |  |  | 24 | % |

[0001193125-26-076622:notes:157]
[same as prior period, unchanged from 0001193125-25-297237:notes:156]

[0001193125-26-076622:notes:158]
|  |  | January 23, 2026 |  |  | April 25, 2025 |  |
| Arrow Electronics, Inc. |  |  | 14 | % |  |  | 10 | % |
| TD Synnex Corporation |  |  | 23 | % |  |  | 27 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-26-076622:notes:159]
14. Commitments and Contingencies

[0001193125-26-076622:notes:160]
Purchase Orders and Other Commitments

[0001193125-26-076622:notes:161]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of January 23, 2026, we had $0.7 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 23, 2026 and April 25, 2025, such liability amounted to $26 million and $22 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001193125-26-076622:notes:162]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 23, 2026, we had $0.4 billion in other purchase obligations.

[0001193125-26-076622:notes:163]
Financing Guarantees

[0001193125-26-076622:notes:164]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution. We sold $25 million and $42 million of receivables during the nine months ended January 23, 2026 and January 24, 2025, respectively.

[0001193125-26-076622:notes:165]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user.

[0001193125-26-076622:notes:166]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of January 23, 2026 and April 25, 2025, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001193125-26-076622:notes:167]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 23, 2026, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make material payments under these arrangements is remote.

[0001193125-26-076622:notes:168]
Legal Contingencies

[0001193125-26-076622:notes:169]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001193125-26-076622:notes:170]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigation brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001193125-26-076622:notes:171]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of January 23, 2026 related to such matters.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001193125-26-076622:notes:172]
Item 5. Other Information.

[0001193125-26-076622:notes:173]
Insider Adoption or Termination of Trading Arrangements

[0001193125-26-076622:notes:174]
On December 18, 2025, Elizabeth O'Callahan, EVP, Chief Administrative Officer of the Company, entered into a Rule 10b5-1 trading arrangement intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) promulgated under the Exchange Act. The trading arrangement will expire on June 30, 2027, and may be terminated earlier in the limited circumstances defined in the trading arrangement. An aggregate of up to 12,000 shares may be sold pursuant to the trading arrangement.

[0001193125-26-076622:notes:175]
No other directors or executive officers of the Company adopted, modified or terminated any contract, instruction or written plan for the purchase or sale of the Company’s securities that was intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act or any non-Rule 10b5-1 trading arrangement (as defined in Item 408(c) of Regulation S-K), during the quarterly period covered by this report.
