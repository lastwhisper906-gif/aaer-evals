# NTAP 8-K — 0001193125-26-076545 filed 2026-02-26

## item codes, every 8-K on or before 2026-02-26

- 2026-02-26 0001193125-26-076545 — 2.02, 9.01
- 2026-01-12 0001193125-26-010401 — 5.02, 7.01, 9.01
- 2025-11-25 0001193125-25-297164 — 2.02, 9.01
- 2025-09-15 0001193125-25-202408 — 5.02, 5.07, 9.01
- 2025-08-27 0000950170-25-111700 — 2.02, 9.01
- 2025-05-29 0000950170-25-078936 — 2.02, 5.02, 8.01, 9.01
- 2025-03-26 0000950170-25-045244 — 5.02, 7.01, 9.01
- 2025-03-17 0001193125-25-055656 — 1.01, 2.03, 8.01, 9.01
- 2025-03-05 0001193125-25-047187 — 1.01, 2.03, 9.01
- 2025-02-27 0000950170-25-029022 — 2.02, 9.01
- 2025-02-26 0001193125-25-036882 — 5.02, 9.01
- 2025-01-28 0001193125-25-014441 — 5.02, 9.01
- 2024-11-21 0000950170-24-129714 — 2.02, 9.01
- 2024-09-12 0000950170-24-105928 — 5.02, 5.07, 9.01
- 2024-08-28 0000950170-24-101383 — 2.02, 5.02, 9.01
- 2024-05-30 0000950170-24-066567 — 2.02, 8.01, 9.01
- 2024-04-09 0000950170-24-042957 — 5.02
- 2024-02-29 0000950170-24-023060 — 2.02, 9.01
- 2023-11-28 0000950170-23-066400 — 2.02, 9.01
- 2023-11-16 0000950170-23-064506 — 5.02, 5.03, 9.01
- 2023-09-15 0000950170-23-048229 — 5.02, 5.07, 9.01
- 2023-08-23 0000950170-23-044130 — 2.02, 9.01
- 2023-08-10 0000950170-23-041348 — 5.02
- 2023-05-31 0000950170-23-025324 — 1.01, 2.02, 8.01, 9.01
- 2023-02-22 0000950170-23-003745 — 2.02, 9.01
- 2023-01-31 0001193125-23-019739 — 2.05, 7.01, 9.01
- 2022-11-29 0000950170-22-025793 — 2.02, 9.01
- 2022-11-16 0000950170-22-025317 — 5.02
- 2022-09-14 0000950170-22-018490 — 5.07
- 2022-08-24 0000950170-22-017731 — 2.02, 9.01
- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2026-02-26

- none on or before 2026-02-26

## item 2.02 — earnings release, exhibit 99.1

[0001193125-26-076545:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0001193125-26-076545:8k_2_02:2]
EX-99.1

[0001193125-26-076545:8k_2_02:3]
Exhibit 99.1

[0001193125-26-076545:8k_2_02:4]
NetApp Reports Third Quarter of Fiscal Year 2026 Results

[0001193125-26-076545:8k_2_02:5]
Net revenues of $1.71 billion for the third quarter, 4% year-over-year increase;

[0001193125-26-076545:8k_2_02:6]
Third quarter GAAP earnings per share of $1.67; record non-GAAP earnings per share of $2.12

[0001193125-26-076545:8k_2_02:7]
News Summary

[0001193125-26-076545:8k_2_02:8]
•
All-flash array revenue grew 11% year-over-year to a record $1.0 billion in the third quarter, for an annualized net revenue run rate1 of $4.2 billion

[0001193125-26-076545:8k_2_02:9]
•
Public Cloud revenue of $174 million in the third quarter was driven by first-party and marketplace storage services, which grew 27% year-over-year

[0001193125-26-076545:8k_2_02:10]
•
Billings of $1.89 billion in the third quarter grew 10% year-over-year, the ninth consecutive quarter of year-over-year growth

[0001193125-26-076545:8k_2_02:11]
•
Third quarter GAAP operating income of $434 million; record non-GAAP operating income of $533 million

[0001193125-26-076545:8k_2_02:12]
•
Third quarter GAAP operating margin of 25.3%; record third quarter non-GAAP operating margin of 31.1%

[0001193125-26-076545:8k_2_02:13]
•
Returned $303 million to stockholders through share repurchases and cash dividends

[0001193125-26-076545:8k_2_02:14]
SAN JOSE, Calif.—February 26, 2026—NetApp (NASDAQ: NTAP), the Intelligent Data Infrastructure company, today reported financial results for the third quarter of fiscal year 2026, which ended on January 23, 2026.

[0001193125-26-076545:8k_2_02:15]
“We are pleased to announce another strong quarter with accelerating revenue and earnings growth, driven by a record quarter in all-flash array revenue, strong performance in first-party and marketplace cloud storage services, growing leadership in enterprise AI, and operational discipline,” said George Kurian, Chief Executive Officer, NetApp. “Our unified data platform continues to deliver exceptional customer benefits, establishing us as the intelligent data backbone for the AI era. Building on our strong portfolio and momentum, we are well-positioned to drive sustained growth and are confident in our ability to deliver long-term value for our shareholders.”

[0001193125-26-076545:8k_2_02:16]
Third Quarter of Fiscal Year 2026 Financial Results

[0001193125-26-076545:8k_2_02:17]
($ in millions, except earnings per share)

[0001193125-26-076545:8k_2_02:18]
| GAAP Results |  |
|  |  | Q3 FY26 |  |  | Q3 FY25 |  |  | % Change |  |
| Net revenues |  | $ | 1,713 |  |  | $ | 1,641 |  |  |  | 4 | % |
| Hybrid Cloud segment revenue |  | $ | 1,539 |  |  | $ | 1,467 |  |  |  | 5 | % |
| Public Cloud segment revenue |  | $ | 174 |  |  | $ | 174 |  |  |  | — | % |
| Gross profit |  | $ | 1,209 |  |  | $ | 1,145 |  |  |  | 6 | % |
| Net income |  | $ | 334 |  |  | $ | 299 |  |  |  | 12 | % |
| Earnings per share |  | $ | 1.67 |  |  | $ | 1.44 |  |  |  | 16 | % |
| Cash provided by operations |  | $ | 317 |  |  | $ | 385 |  |  |  | (18 | )% |

[0001193125-26-076545:8k_2_02:19]
| Non-GAAP Results |  |
|  |  | Q3 FY26 |  |  | Q3 FY25 |  |  | % Change |  |
| Billings |  | $ | 1,886 |  |  | $ | 1,713 |  |  |  | 10 | % |
| Net revenues |  | $ | 1,713 |  |  | $ | 1,641 |  |  |  | 4 | % |
| Hybrid Cloud segment revenue |  | $ | 1,539 |  |  | $ | 1,467 |  |  |  | 5 | % |
| Public Cloud segment revenue |  | $ | 174 |  |  | $ | 174 |  |  |  | — | % |
| Gross profit |  | $ | 1,219 |  |  | $ | 1,161 |  |  |  | 5 | % |
| Net income |  | $ | 423 |  |  | $ | 397 |  |  |  | 7 | % |
| Earnings per share |  | $ | 2.12 |  |  | $ | 1.91 |  |  |  | 11 | % |
| Full reconciliations between GAAP and non-GAAP measures are provided below. |  |

[0001193125-26-076545:8k_2_02:20]
Constant Currency — Q3 Fiscal Year 2026 versus Q3 Fiscal Year 2025

[0001193125-26-076545:8k_2_02:21]
•
In constant currency, year-over-year, net revenues increased by 2% and billings increased by 8%.

[0001193125-26-076545:8k_2_02:22]
•
The year-over-year fluctuations of GAAP and non-GAAP net income presented in the tables above each include a favorable impact of approximately $21 million from foreign currency exchange rate changes.

[0001193125-26-076545:8k_2_02:23]
•
The year-over-year fluctuations of GAAP and non-GAAP earnings per share presented in the tables above each include a favorable impact of approximately $0.11 from foreign currency exchange rate changes.

[0001193125-26-076545:8k_2_02:24]
| Fourth Quarter of Fiscal Year 2026 Financial Outlook |  |  |  |
| The Company provided the following financial guidance for the fourth quarter of fiscal year 2026: |
| Net revenues are expected to be in the range of: | $1.795 billion – $1.945 billion |
|  | GAAP |  | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 68.5% - 69.5% |  | 69.5% - 70.5% |
| Operating margins are expected to be in the range of: | 25.5% - 26.5% |  | 30.5% - 31.5% |
| Earnings per share is expected to be in the range of: | $1.76 - $1.86 |  | $2.21 - $2.31 |
| Full Fiscal Year 2026 Financial Outlook |  |  |  |
| The Company provided the following financial guidance for the full fiscal year 2026: |  |  |
| Net revenues are expected to be in the range of: | $6.772 billion – $6.922 billion |
|  | GAAP |  | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 69.7% - 70.7% |  | 70.7% - 71.7% |
| Operating margins are expected to be in the range of: | 23.3% - 24.3% |  | 29.3% - 30.3% |
| Earnings per share is expected to be in the range of: | $6.07 - $6.17 |  | $7.92 - $8.02 |

[0001193125-26-076545:8k_2_02:25]
Dividend

[0001193125-26-076545:8k_2_02:26]
The next cash dividend of $0.52 per share is to be paid on April 22, 2026, to stockholders of record as of the close of business on April 3, 2026.

[0001193125-26-076545:8k_2_02:27]
Third Quarter of Fiscal Year 2026 Business Highlights

[0001193125-26-076545:8k_2_02:28]
Leading Product Innovation

[0001193125-26-076545:8k_2_02:29]
•
NetApp introduced agentic AI capabilities in Workload Factory for FSx for NetApp ONTAP™, delivering real-time insights that enable proactive detection and faster, more intelligent operational response.

[0001193125-26-076545:8k_2_02:30]
•
NetApp announced Edge-Aware Caching Insights in Workload Factory, providing centralized visibility into FlexCache relationships to improve performance alignment and efficiency across distributed storage environments.

[0001193125-26-076545:8k_2_02:31]
•
NetApp launched the Amazon EVS Best Practice Advisor in Workload Factory, delivering automated VMware scans and actionable guidance to keep FSx for NetApp ONTAP environments aligned with performance, security, and cost best practices.

[0001193125-26-076545:8k_2_02:32]
•
NetApp announced a new integration enabling Amazon S3 Access Points for Amazon FSx for NetApp ONTAP, allowing enterprises to connect AWS AI, ML, and analytics services directly to NetApp file data in the cloud and on premises without moving data.

[0001193125-26-076545:8k_2_02:33]
•
NetApp announced the general availability of Azure NetApp Files single file restore from backup, enabling customers to restore individual files from a backup vault without restoring an entire volume.

[0001193125-26-076545:8k_2_02:34]
•
NetApp announced the general availability of Azure NetApp Files backup support for large volumes, allowing high-speed, point-in-time backups to low-cost Azure storage to support long-term retention, data protection, and compliance needs.

[0001193125-26-076545:8k_2_02:35]
•
NetApp announced the general availability of cross-zone-region replication for Azure NetApp Files, enabling volume replication across regions and availability zones to enhance disaster recovery and business continuity.

[0001193125-26-076545:8k_2_02:36]
•
NetApp announced the public preview of cache volumes for Azure NetApp Files, introducing cloud-based caching that brings frequently accessed data closer to users to improve performance while reducing WAN latency and bandwidth costs.

[0001193125-26-076545:8k_2_02:37]
•
NetApp announced the public preview of large volume breakthrough mode for Azure NetApp Files, delivering extreme performance and scalability for HPC (high-performance computing) and EDA (Electronic Design Automation) workloads with multi-PiB (Pebibyte) volumes, ultra-high throughput, and dedicated capacity for predictable performance.

[0001193125-26-076545:8k_2_02:38]
•
NetApp introduced the public preview of large volumes up to 7.2 PiB with cool access for Azure NetApp Files, enabling cost-effective, petabyte-scale storage for infrequently accessed data while maintaining predictable enterprise performance.

[0001193125-26-076545:8k_2_02:39]
•
NetApp introduced preview support for Azure NetApp Files in OpenShift Virtualization, enabling fast VM provisioning, instant cloning, and live migration with scalable, predictable storage for enterprise VM workloads.

[0001193125-26-076545:8k_2_02:40]
•
NetApp announced the public preview of Object REST API on Azure NetApp Files, enabling customers to seamlessly integrate Azure NetApp Files data with Microsoft Fabric, Azure AI services, and other Azure offerings without the need to move or replicate data.

[0001193125-26-076545:8k_2_02:41]
•
NetApp introduced the public preview of advanced ransomware protection for Azure NetApp Files, providing proactive threat detection with automatic snapshots and alerts to support rapid response and recovery.

[0001193125-26-076545:8k_2_02:42]
•
NetApp announced block storage support for Google Cloud NetApp Volumes, empowering organizations to seamlessly migrate or extend their on-premises SAN environments to Google Cloud.

[0001193125-26-076545:8k_2_02:43]
•
NetApp introduced an AI-powered VS Code extension for Google Cloud NetApp Volumes, enabling developers to create, configure, and manage storage directly within the IDE using natural language and Copilot to accelerate Infrastructure as Code workflows.

[0001193125-26-076545:8k_2_02:44]
•
NetApp announced zonal high availability for Google Cloud NetApp Volumes in preview, enabling cross-zone replication to improve resilience and business continuity for mission-critical workloads.

[0001193125-26-076545:8k_2_02:45]
Customer and Partner Momentum

[0001193125-26-076545:8k_2_02:46]
•
NetApp was named the 2025 Americas Partner of the Year Software Development Company (SDC) Canada Award winner by Microsoft, recognizing its innovation and success delivering Azure-based solutions through its deep, first-party cloud integration.

[0001193125-26-076545:8k_2_02:47]
Personnel

[0001193125-26-076545:8k_2_02:48]
•
NetApp appointed Willem Hendrickx as Senior Vice President and General Manager for EMEA and LATAM, tasking him with leading regional strategy and growth as customer demand accelerates for AI-driven, hybrid cloud data infrastructure.

[0001193125-26-076545:8k_2_02:49]
•
NetApp welcomed Paul Fipps, President of Global Customer Operations at ServiceNow, to its Board of Directors, where he will help guide strategy and strengthen customer-focused growth and innovation for AI and digital transformation

[0001193125-26-076545:8k_2_02:50]
Awards and Recognition

[0001193125-26-076545:8k_2_02:51]
•
IDC’s Worldwide Quarterly Enterprise Storage Systems Tracker2 showed NetApp ranking among the top three global storage vendors in Q3 2025, as enterprises selectively increased storage investments alongside accelerating AI-driven server spending.

[0001193125-26-076545:8k_2_02:52]
•
NetApp was named a Leader and Fast Mover in GigaOm’s latest Primary Storage Radar, recognizing the strength and momentum of its primary storage platform across enterprise features, innovation, and business criteria.

[0001193125-26-076545:8k_2_02:53]
•
CRN named NetApp one of the 50 Hottest Edge Hardware, Software, and Services Companies as part of its 2025 Edge Computing 100 List, recognizing the NetApp AI Data Engine as a solution that connects, secures and activates data across every cloud, workload, and environment.

[0001193125-26-076545:8k_2_02:54]
•
NetApp was named to CRN’s 2026 Cloud 100 list in the 20 Coolest Cloud Storage Companies category, recognizing its leadership in delivering cloud-native data infrastructure across hyperscalers and on-premises environments.

[0001193125-26-076545:8k_2_02:55]
•
NetApp AFF A-Series/C-Series was named a subcategory winner in CRN’s 2025 Products of the Year awards for Storage: Enterprise-Class, earning top honors for revenue and profit among partner-friendly enterprise storage solutions.

[0001193125-26-076545:8k_2_02:56]
•
In CRN’s 2025 Products of the Year awards, NetApp ONTAP was named a subcategory winner for the Storage: Cloud-Focused category, recognized for driving strong revenue and profit in cloud-focused data management.

[0001193125-26-076545:8k_2_02:57]
•
NetApp placed #109 on Forbes’ 2026 Most Trusted Companies in America list, highlighting its credibility with customers, employees, investors, and the media based on independent trust and perception data.

[0001193125-26-076545:8k_2_02:58]
•
NetApp ranked #206 on Forbes’ 2026 America’s Best Companies list, earning recognition for its balanced performance across business execution, workforce strength, customer trust, and market reputation.

[0001193125-26-076545:8k_2_02:59]
•
NetApp was named to The Wall Street Journal’s 250 Best-Managed Companies of 2025 list, recognized for management effectiveness across customer satisfaction, employee engagement, innovation, social responsibility, and financial performance.

[0001193125-26-076545:8k_2_02:60]
•
Forbes named NetApp #16 on its 2026 America’s Best-in-State Companies list for California, recognizing the company’s strong performance in financial strength, customer satisfaction, and employee engagement.

[0001193125-26-076545:8k_2_02:61]
•
Triangle Business Journal ranked NetApp #28 on its 2025 list of the Triangle’s largest employers, recognizing the company’s significant regional presence with 1,900 local employees, reflecting its continued influence as a leading technology employer in the area.

[0001193125-26-076545:8k_2_02:62]
Webcast and Conference Call Information

[0001193125-26-076545:8k_2_02:63]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today. NetApp uses its website as a tool to disclose important information about NetApp and comply with its disclosure obligations under Regulation Fair Disclosure.

[0001193125-26-076545:8k_2_02:64]
###

[0001193125-26-076545:8k_2_02:65]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001193125-26-076545:8k_2_02:66]
Footnotes

[0001193125-26-076545:8k_2_02:67]
1All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0001193125-26-076545:8k_2_02:68]
2IDC’s Worldwide Quarter Enterprise Storage Systems Tracker: “Server market explodes 61% as storage limps along, The death of the server middleman?”, Ben Wodecki, December 15, 2025.

[0001193125-26-076545:8k_2_02:69]
NetApp Usage of Non-GAAP Financial Information

[0001193125-26-076545:8k_2_02:70]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP gross margins, non-GAAP gross profit, non-GAAP operating income, non-GAAP operating margins, non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share.

[0001193125-26-076545:8k_2_02:71]
NetApp believes that the presentation of its non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp’s management uses non-GAAP measures in making operating decisions because it believes that the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001193125-26-076545:8k_2_02:72]
NetApp believes that the presentation of non-GAAP gross margins, non-GAAP gross profit, non-GAAP operating income, non-GAAP operating margins, non-GAAP effective tax rate, non-GAAP net income, and non-GAAP earnings per share data provides investors with supplemental metrics that assist in understanding current results and future prospects, earnings and profitability that are complementary to GAAP metrics. Each of these non-GAAP metrics is defined as the applicable GAAP metric adjusted to exclude the items defined in A through I below, as applicable, while our non-GAAP effective tax rate and non-GAAP net income also reflect a non-GAAP tax provision, as described in item J below, instead of our GAAP tax provision. GAAP earnings per share and non-GAAP earnings per share are calculated using the net income divided by the diluted number of shares for the applicable period.

[0001193125-26-076545:8k_2_02:73]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001193125-26-076545:8k_2_02:74]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information

[0001193125-26-076545:8k_2_02:75]
to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0001193125-26-076545:8k_2_02:76]
Non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001193125-26-076545:8k_2_02:77]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001193125-26-076545:8k_2_02:78]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001193125-26-076545:8k_2_02:79]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001193125-26-076545:8k_2_02:80]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001193125-26-076545:8k_2_02:81]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0001193125-26-076545:8k_2_02:82]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001193125-26-076545:8k_2_02:83]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001193125-26-076545:8k_2_02:84]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer and/or lose control of assets to a third party. This is inclusive of third-party advisory, legal and other costs that result directly from and are essential to a sale transaction and that would not have been incurred had the decision to sell not been made. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0001193125-26-076545:8k_2_02:85]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0001193125-26-076545:8k_2_02:86]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such non-recurring costs do not reflect the results of its underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0001193125-26-076545:8k_2_02:87]
J. Income tax effects. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges or benefits that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges or benefits resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001193125-26-076545:8k_2_02:88]
Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies. In addition, non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with GAAP. The non-GAAP financial measures are meant to supplement and be viewed in conjunction with GAAP financial measures. A detailed reconciliation of our non-GAAP to GAAP results can be found herein. In the press release and accompanying financial statements and reconciliations, the terms "operating income" and "income from operations" are used interchangeably. Similarly, "earnings per share" and "net income per share" are also used interchangeably.

[0001193125-26-076545:8k_2_02:89]
Constant Currency

[0001193125-26-076545:8k_2_02:90]
In periods in which the impacts of foreign currency exchange rate changes are significant, NetApp presents certain constant currency growth rates or quantifies the impact of foreign currency exchange rate changes on year-over-year fluctuations, including for net revenues, billings, and earnings. This constant currency information assumes that the same foreign currency exchange rates that were in effect for the comparable prior-year period were used in translation of the current period results.

[0001193125-26-076545:8k_2_02:91]
About NetApp

[0001193125-26-076545:8k_2_02:92]
For more than three decades, NetApp has helped the world’s leading organizations navigate change – from the rise of enterprise storage to the intelligent era defined by data and AI. Today, NetApp is the Intelligent Data Infrastructure company, helping customers turn data into a catalyst for innovation, resilience, and growth.

[0001193125-26-076545:8k_2_02:93]
At the heart of that infrastructure is the NetApp data platform – the unified, enterprise-grade, intelligent foundation that connects, protects, and activates data across every cloud, workload, and environment. Built on the proven power of NetApp ONTAP, our leading data management software and OS, and enhanced by automation through the AI Data Engine and AFX, it delivers observability, resilience, and intelligence at scale.

[0001193125-26-076545:8k_2_02:94]
Disaggregated by design, the NetApp data platform separates storage, services, and control so enterprises can modernize faster, scale efficiently, and innovate without lock-in. As the only enterprise storage platform natively embedded in the world’s largest clouds, it gives organizations the freedom to run any workload anywhere with consistent performance, governance, and protection.

[0001193125-26-076545:8k_2_02:95]
With NetApp, data is always ready – ready to defend against threats, ready to power AI, and ready to drive the next breakthrough. That’s why the world’s most forward-thinking enterprises trust NetApp to turn intelligence into advantage.

[0001193125-26-076545:8k_2_02:96]
Learn more at www.netapp.com or follow us on X, LinkedIn, Facebook, and Instagram.

[0001193125-26-076545:8k_2_02:97]
NETAPP, INC.

[0001193125-26-076545:8k_2_02:98]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-26-076545:8k_2_02:99]
($ in millions)

[0001193125-26-076545:8k_2_02:100]
(Unaudited)

[0001193125-26-076545:8k_2_02:101]
|  |  | January 23, 2026 |  |  | April 25, 2025 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,008 |  |  | $ | 3,846 |  |
| Accounts receivable |  |  | 1,314 |  |  |  | 1,246 |  |
| Inventories |  |  | 109 |  |  |  | 186 |  |
| Other current assets |  |  | 565 |  |  |  | 573 |  |
| Total current assets |  |  | 4,996 |  |  |  | 5,851 |  |
| Property and equipment, net |  |  | 576 |  |  |  | 563 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,782 |  |  |  | 2,766 |  |
| Other non-current assets |  |  | 1,617 |  |  |  | 1,643 |  |
| Total assets |  | $ | 9,971 |  |  | $ | 10,823 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 413 |  |  | $ | 511 |  |
| Accrued expenses |  |  | 908 |  |  |  | 1,122 |  |
| Current portion of long-term debt |  |  | — |  |  |  | 750 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 2,273 |  |  |  | 2,279 |  |
| Total current liabilities |  |  | 3,594 |  |  |  | 4,662 |  |
| Long-term debt |  |  | 2,486 |  |  |  | 2,485 |  |
| Other long-term liabilities |  |  | 375 |  |  |  | 379 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 2,358 |  |  |  | 2,257 |  |
| Total liabilities |  |  | 8,813 |  |  |  | 9,783 |  |
| Stockholders' equity |  |  | 1,158 |  |  |  | 1,040 |  |
| Total liabilities and stockholders' equity |  | $ | 9,971 |  |  | $ | 10,823 |  |

[0001193125-26-076545:8k_2_02:102]
NETAPP, INC.

[0001193125-26-076545:8k_2_02:103]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-26-076545:8k_2_02:104]
($ in millions, except net income per share amounts)

[0001193125-26-076545:8k_2_02:105]
(Unaudited)

[0001193125-26-076545:8k_2_02:106]
|  |  | Three Months Ended |  |  | Nine Months Ended |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | January 23, 2026 |  |  | January 24, 2025 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 786 |  |  | $ | 758 |  |  | $ | 2,228 |  |  | $ | 2,195 |  |  |
| Services |  |  | 927 |  |  |  | 883 |  |  |  | 2,749 |  |  |  | 2,645 |  |  |
| Net revenues |  |  | 1,713 |  |  |  | 1,641 |  |  |  | 4,977 |  |  |  | 4,840 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 353 |  |  |  | 330 |  |  |  | 976 |  |  |  | 906 |  |  |
| Cost of services |  |  | 151 |  |  |  | 166 |  |  |  | 467 |  |  |  | 514 |  |  |
| Total cost of revenues |  |  | 504 |  |  |  | 496 |  |  |  | 1,443 |  |  |  | 1,420 |  |  |
| Gross profit |  |  | 1,209 |  |  |  | 1,145 |  |  |  | 3,534 |  |  |  | 3,420 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 455 |  |  |  | 451 |  |  |  | 1,381 |  |  |  | 1,407 |  |  |
| Research and development |  |  | 237 |  |  |  | 247 |  |  |  | 730 |  |  |  | 756 |  |  |
| General and administrative |  |  | 86 |  |  |  | 74 |  |  |  | 259 |  |  |  | 226 |  |  |
| Restructuring charges |  |  | (3 | ) |  |  | 9 |  |  |  | 22 |  |  |  | 38 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | 2 |  |  |  | — |  |  |  | 4 |  |  |
| Total operating expenses |  |  | 775 |  |  |  | 783 |  |  |  | 2,392 |  |  |  | 2,431 |  |  |
| Income from operations |  |  | 434 |  |  |  | 362 |  |  |  | 1,142 |  |  |  | 989 |  |  |
| Other (expense) income, net |  |  | (1 | ) |  |  | 8 |  |  |  | (12 | ) |  |  | 40 |  |  |
| Income before income taxes |  |  | 433 |  |  |  | 370 |  |  |  | 1,130 |  |  |  | 1,029 |  |  |
| Provision for income taxes |  |  | 99 |  |  |  | 71 |  |  |  | 258 |  |  |  | 183 |  |  |
| Net income |  | $ | 334 |  |  | $ | 299 |  |  | $ | 872 |  |  | $ | 846 |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.69 |  |  | $ | 1.47 |  |  | $ | 4.38 |  |  | $ | 4.13 |  |  |
| Diluted |  | $ | 1.67 |  |  | $ | 1.44 |  |  | $ | 4.32 |  |  | $ | 4.03 |  |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 198 |  |  |  | 204 |  |  |  | 199 |  |  |  | 205 |  |  |
| Diluted |  |  | 200 |  |  |  | 208 |  |  |  | 202 |  |  |  | 210 |  |  |

[0001193125-26-076545:8k_2_02:107]
NETAPP, INC.

[0001193125-26-076545:8k_2_02:108]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-26-076545:8k_2_02:109]
($ in millions)

[0001193125-26-076545:8k_2_02:110]
(Unaudited)

[0001193125-26-076545:8k_2_02:111]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2026 |  |  | January 24, 2025 |  |  | January 23, 2026 |  |  | January 24, 2025 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 334 |  |  | $ | 299 |  |  | $ | 872 |  |  | $ | 846 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 48 |  |  |  | 64 |  |  |  | 151 |  |  |  | 190 |  |
| Non-cash operating lease cost |  |  | 11 |  |  |  | 10 |  |  |  | 32 |  |  |  | 31 |  |
| Stock-based compensation |  |  | 97 |  |  |  | 103 |  |  |  | 282 |  |  |  | 291 |  |
| Deferred income taxes |  |  | 29 |  |  |  | (41 | ) |  |  | 48 |  |  |  | (110 | ) |
| Other items, net |  |  | (17 | ) |  |  | (60 | ) |  |  | 58 |  |  |  | (25 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (324 | ) |  |  | (34 | ) |  |  | (63 | ) |  |  | 104 |  |
| Inventories |  |  | 17 |  |  |  | 50 |  |  |  | 77 |  |  |  | (82 | ) |
| Accounts payable |  |  | (25 | ) |  |  | (113 | ) |  |  | (98 | ) |  |  | (77 | ) |
| Accrued expenses |  |  | 29 |  |  |  | (10 | ) |  |  | (248 | ) |  |  | (94 | ) |
| Deferred revenue and financed unearned services revenue |  |  | 173 |  |  |  | 72 |  |  |  | 66 |  |  |  | (92 | ) |
| Long-term taxes payable |  |  | — |  |  |  | 7 |  |  |  | 3 |  |  |  | (84 | ) |
| Changes in other operating assets and liabilities, net |  |  | (55 | ) |  |  | 38 |  |  |  | (63 | ) |  |  | (67 | ) |
| Net cash provided by operating activities |  |  | 317 |  |  |  | 385 |  |  |  | 1,117 |  |  |  | 831 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| (Purchases) redemptions of investments, net |  |  | (437 | ) |  |  | (7 | ) |  |  | (282 | ) |  |  | 590 |  |
| Purchases of property and equipment |  |  | (46 | ) |  |  | (47 | ) |  |  | (148 | ) |  |  | (133 | ) |
| Other investing activities, net |  |  | — |  |  |  | 1 |  |  |  | 15 |  |  |  | 3 |  |
| Net cash (used in) provided by investing activities |  |  | (483 | ) |  |  | (53 | ) |  |  | (415 | ) |  |  | 460 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 49 |  |  |  | 53 |  |  |  | 103 |  |  |  | 108 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (25 | ) |  |  | (36 | ) |  |  | (112 | ) |  |  | (168 | ) |
| Repurchase of common stock |  |  | (200 | ) |  |  | (200 | ) |  |  | (750 | ) |  |  | (900 | ) |
| Repayments and extinguishment of debt |  |  | — |  |  |  | — |  |  |  | (750 | ) |  |  | (400 | ) |
| Dividends paid |  |  | (103 | ) |  |  | (106 | ) |  |  | (310 | ) |  |  | (319 | ) |
| Net cash used in financing activities |  |  | (279 | ) |  |  | (289 | ) |  |  | (1,819 | ) |  |  | (1,679 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 1 |  |  |  | (12 | ) |  |  | 3 |  |  |  | (3 | ) |
| Net change in cash, cash equivalents and restricted cash |  |  | (444 | ) |  |  | 31 |  |  |  | (1,114 | ) |  |  | (391 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,079 |  |  |  | 1,487 |  |  |  | 2,749 |  |  |  | 1,909 |  |
| End of period |  | $ | 1,635 |  |  | $ | 1,518 |  |  | $ | 1,635 |  |  | $ | 1,518 |  |

[0001193125-26-076545:8k_2_02:112]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| ($ in millions, except net income per share amounts) |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| NET INCOME |  | $ | 334 |  |  |  | $ | 299 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 5 |  |  |  |  | 13 |  |
| Stock-based compensation |  |  | 97 |  |  |  |  | 103 |  |
| Restructuring charges |  |  | (3 | ) |  |  |  | 9 |  |
| Acquisition-related expense |  |  | — |  |  |  |  | 2 |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | 3 |  |
| Income tax effects |  |  | (10 | ) |  |  |  | (32 | ) |
| NON-GAAP NET INCOME |  | $ | 423 |  |  |  | $ | 397 |  |
| COST OF REVENUES |  | $ | 504 |  |  |  | $ | 496 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  |  | (8 | ) |
| Stock-based compensation |  |  | (8 | ) |  |  |  | (8 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 494 |  |  |  | $ | 480 |  |
| COST OF PRODUCT REVENUES |  | $ | 353 |  |  |  | $ | 330 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  |  | (2 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 351 |  |  |  | $ | 328 |  |
| COST OF SERVICES REVENUES |  | $ | 151 |  |  |  | $ | 166 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  |  | (8 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  |  | (6 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 143 |  |  |  | $ | 152 |  |
| GROSS PROFIT |  | $ | 1,209 |  |  |  | $ | 1,145 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 2 |  |  |  |  | 8 |  |
| Stock-based compensation |  |  | 8 |  |  |  |  | 8 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,219 |  |  |  | $ | 1,161 |  |

[0001193125-26-076545:8k_2_02:113]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| ($ in millions, except net income per share amounts) |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| SALES AND MARKETING EXPENSES |  | $ | 455 |  |  |  | $ | 451 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (5 | ) |
| Stock-based compensation |  |  | (38 | ) |  |  |  | (44 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 414 |  |  |  | $ | 402 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 237 |  |  |  | $ | 247 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (33 | ) |  |  |  | (36 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 204 |  |  |  | $ | 211 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 86 |  |  |  | $ | 74 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (18 | ) |  |  |  | (15 | ) |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | (3 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 68 |  |  |  | $ | 56 |  |
| RESTRUCTURING CHARGES |  | $ | (3 | ) |  |  | $ | 9 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Restructuring charges |  |  | 3 |  |  |  |  | (9 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | — |  |  |  | $ | 2 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | — |  |  |  |  | (2 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 775 |  |  |  | $ | 783 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (5 | ) |
| Stock-based compensation |  |  | (89 | ) |  |  |  | (95 | ) |
| Restructuring charges |  |  | 3 |  |  |  |  | (9 | ) |
| Acquisition-related expense |  |  | — |  |  |  |  | (2 | ) |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | (3 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 686 |  |  |  | $ | 669 |  |

[0001193125-26-076545:8k_2_02:114]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| ($ in millions, except net income per share amounts) |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| INCOME FROM OPERATIONS |  | $ | 434 |  |  |  | $ | 362 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 5 |  |  |  |  | 13 |  |
| Stock-based compensation |  |  | 97 |  |  |  |  | 103 |  |
| Restructuring charges |  |  | (3 | ) |  |  |  | 9 |  |
| Acquisition-related expense |  |  | — |  |  |  |  | 2 |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | 3 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 533 |  |  |  | $ | 492 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 433 |  |  |  | $ | 370 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 5 |  |  |  |  | 13 |  |
| Stock-based compensation |  |  | 97 |  |  |  |  | 103 |  |
| Restructuring charges |  |  | (3 | ) |  |  |  | 9 |  |
| Acquisition-related expense |  |  | — |  |  |  |  | 2 |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | 3 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 532 |  |  |  | $ | 500 |  |
| PROVISION FOR INCOME TAXES |  | $ | 99 |  |  |  | $ | 71 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Income tax effects |  |  | 10 |  |  |  |  | 32 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 109 |  |  |  | $ | 103 |  |
| NET INCOME PER SHARE |  | $ | 1.67 |  |  |  | $ | 1.44 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.03 |  |  |  |  | 0.06 |  |
| Stock-based compensation |  |  | 0.49 |  |  |  |  | 0.50 |  |
| Restructuring charges |  |  | (0.02 | ) |  |  |  | 0.04 |  |
| Acquisition-related expense |  |  | — |  |  |  |  | 0.01 |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | 0.01 |  |
| Income tax effects |  |  | (0.05 | ) |  |  |  | (0.15 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 2.12 |  |  |  | $ | 1.91 |  |

[0001193125-26-076545:8k_2_02:115]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| Gross margin |  |  | 70.6 | % |  |  |  | 69.8 | % |
| Cost of revenues adjustments |  |  | 0.6 | % |  |  |  | 0.9 | % |
| Non-GAAP Gross margin |  |  | 71.2 | % |  |  |  | 70.7 | % |
| Cost of revenues |  | $ | 504 |  |  |  | $ | 496 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  |  | (8 | ) |
| Stock-based compensation |  |  | (8 | ) |  |  |  | (8 | ) |
| Non-GAAP Cost of revenues |  | $ | 494 |  |  |  | $ | 480 |  |
| Net revenues |  | $ | 1,713 |  |  |  | $ | 1,641 |  |

[0001193125-26-076545:8k_2_02:116]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| Product gross margin |  |  | 55.1 | % |  |  |  | 56.5 | % |
| Cost of product revenues adjustments |  |  | 0.2 | % |  |  |  | 0.2 | % |
| Non-GAAP Product gross margin |  |  | 55.3 | % |  |  |  | 56.7 | % |
| Cost of product revenues |  | $ | 353 |  |  |  | $ | 330 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  |  | (2 | ) |
| Non-GAAP Cost of product revenues |  | $ | 351 |  |  |  | $ | 328 |  |
| Product revenues |  | $ | 786 |  |  |  | $ | 758 |  |

[0001193125-26-076545:8k_2_02:117]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| Services gross margin |  |  | 83.7 | % |  |  |  | 81.2 | % |
| Cost of services revenues adjustments |  |  | 0.9 | % |  |  |  | 1.6 | % |
| Non-GAAP Services gross margin |  |  | 84.6 | % |  |  |  | 82.8 | % |
| Cost of services revenues |  | $ | 151 |  |  |  | $ | 166 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (2 | ) |  |  |  | (8 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  |  | (6 | ) |
| Non-GAAP Cost of services revenues |  | $ | 143 |  |  |  | $ | 152 |  |
| Services revenues |  | $ | 927 |  |  |  | $ | 883 |  |

[0001193125-26-076545:8k_2_02:118]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| OPERATING MARGIN |  |
| ($ in millions) |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| Operating margin |  |  | 25.3 | % |  |  |  | 22.1 | % |
| Adjustments |  |  | 5.8 | % |  |  |  | 7.9 | % |
| Non-GAAP Operating margin |  |  | 31.1 | % |  |  |  | 30.0 | % |
| Income from operations |  | $ | 434 |  |  |  | $ | 362 |  |
| Income from operations adjustments: |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 5 |  |  |  |  | 13 |  |
| Stock-based compensation |  |  | 97 |  |  |  |  | 103 |  |
| Restructuring charges |  |  | (3 | ) |  |  |  | 9 |  |
| Acquisition-related expense |  |  | — |  |  |  |  | 2 |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | 3 |  |
| Non-GAAP Income from operations |  | $ | 533 |  |  |  | $ | 492 |  |
| Net revenues |  | $ | 1,713 |  |  |  | $ | 1,641 |  |

[0001193125-26-076545:8k_2_02:119]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| Effective tax rate |  |  | 22.9 | % |  |  |  | 19.2 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Income tax effects |  |  | (2.4 | )% |  |  |  | 1.4 | % |
| Non-GAAP Effective tax rate |  |  | 20.5 | % |  |  |  | 20.6 | % |

[0001193125-26-076545:8k_2_02:120]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| ($ in millions) |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| Net cash provided by operating activities |  | $ | 317 |  |  |  | $ | 385 |  |
| Purchases of property and equipment |  |  | (46 | ) |  |  |  | (47 | ) |
| Free cash flow |  | $ | 271 |  |  |  | $ | 338 |  |

[0001193125-26-076545:8k_2_02:121]
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| ($ in millions) |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| Net revenues |  | $ | 1,713 |  |  |  | $ | 1,641 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | 173 |  |  |  |  | 72 |  |
| Billings |  | $ | 1,886 |  |  |  | $ | 1,713 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |  |  |  |  |  |  |

[0001193125-26-076545:8k_2_02:122]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| ($ in millions except net income per share, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| Product |  | $ | 786 |  |  |  | $ | 758 |  |
| Support |  |  | 654 |  |  |  |  | 621 |  |
| Professional and Other Services |  |  | 99 |  |  |  |  | 88 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,539 |  |  |  |  | 1,467 |  |
| Public Cloud Segment Net Revenues |  |  | 174 |  |  |  |  | 174 |  |
| Net Revenues |  | $ | 1,713 |  |  |  | $ | 1,641 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| Product |  | $ | 435 |  |  |  | $ | 430 |  |
| Support |  |  | 605 |  |  |  |  | 573 |  |
| Professional and Other Services |  |  | 31 |  |  |  |  | 25 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 1,071 |  |  |  |  | 1,028 |  |
| Public Cloud Segment Gross Profit |  |  | 148 |  |  |  |  | 133 |  |
| Total Segments Gross Profit |  |  | 1,219 |  |  |  |  | 1,161 |  |
| Amortization of Intangible Assets |  |  | (2 | ) |  |  |  | (8 | ) |
| Stock-based Compensation |  |  | (8 | ) |  |  |  | (8 | ) |
| Unallocated Cost of Revenues |  |  | (10 | ) |  |  |  | (16 | ) |
| Gross Profit |  | $ | 1,209 |  |  |  | $ | 1,145 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| Product |  |  | 55.3 | % |  |  |  | 56.7 | % |
| Support |  |  | 92.5 | % |  |  |  | 92.3 | % |
| Professional and Other Services |  |  | 31.3 | % |  |  |  | 28.4 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 69.6 | % |  |  |  | 70.1 | % |
| Public Cloud Segment Gross Margin |  |  | 85.1 | % |  |  |  | 76.4 | % |

[0001193125-26-076545:8k_2_02:123]
| Geographic Mix |  |  |  |  |  |  |  |
|  |  | % of Q3 FY26 |  |  |  | % of Q3 FY25 |  |
|  |  | Revenue |  |  |  | Revenue |  |
| Americas |  |  | 52 | % |  |  |  | 51 | % |
| Americas Commercial |  |  | 42 | % |  |  |  | 41 | % |
| U.S. Public Sector* |  |  | 10 | % |  |  |  | 10 | % |
| EMEA |  |  | 34 | % |  |  |  | 34 | % |
| Asia Pacific |  |  | 14 | % |  |  |  | 15 | % |
| * U.S. Public Sector includes revenue from both 1) the U.S. federal government (“U.S. Fed”) and 2) U.S. state governments, local municipalities and education institutions (“U.S. SLED”). |  |

[0001193125-26-076545:8k_2_02:124]
| Pathways Mix |  |  |  |  |  |  |  |
|  |  | % of Q3 FY26 |  |  |  | % of Q3 FY25 |  |
|  |  | Revenue |  |  |  | Revenue |  |
| Direct |  |  | 24 | % |  |  |  | 21 | % |
| Indirect |  |  | 76 | % |  |  |  | 79 | % |

[0001193125-26-076545:8k_2_02:125]
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| Non-GAAP Income from Operations |  | $ | 533 |  |  |  | $ | 492 |  |
| Operating Margin |  |  | 31.1 | % |  |  |  | 30.0 | % |
| Non-GAAP Income before Income Taxes |  | $ | 532 |  |  |  | $ | 500 |  |
| Non-GAAP Effective Tax Rate |  |  | 20.5 | % |  |  |  | 20.6 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| Non-GAAP Net Income |  | $ | 423 |  |  |  | $ | 397 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 200 |  |  |  |  | 208 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 2.12 |  |  |  | $ | 1.91 |  |

[0001193125-26-076545:8k_2_02:126]
| Select Balance Sheet Items |  |  |  |  |  |  |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 4,631 |  |  |  | $ | 4,122 |  |
| DSO (days) |  |  | 70 |  |  |  |  | 50 |  |
| DPO (days) |  |  | 75 |  |  |  |  | 80 |  |
| Inventory Turns |  |  | 18 |  |  |  |  | 7 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |

[0001193125-26-076545:8k_2_02:127]
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |
|  |  | Q3 FY26 |  |  |  | Q3 FY25 |  |
| Net Cash Provided by Operating Activities |  | $ | 317 |  |  |  | $ | 385 |  |
| Purchases of Property and Equipment |  | $ | 46 |  |  |  | $ | 47 |  |
| Free Cash Flow |  | $ | 271 |  |  |  | $ | 338 |  |
| Free Cash Flow Margin |  |  | 15.8 | % |  |  |  | 20.6 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Free cash flow margin is defined as free cash flow as a percentage of net revenues. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001193125-26-076545:8k_2_02:128]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| FOURTH QUARTER FISCAL 2026 |
|  |  | Fourth Quarter |
|  |  | Fiscal 2026 |
| GAAP Guidance - Gross Margin |  | 68.5% - 69.5% |
| Adjustments: |  |  |
| Cost of revenues adjustments |  | 1% |
| Non-GAAP Guidance - Gross Margin |  | 69.5% - 70.5% |
|  |  | Fourth Quarter |
|  |  | Fiscal 2026 |
| GAAP Guidance - Operating Margin |  | 25.5% - 26.5% |
| Adjustments: |  |  |
| Stock-based compensation expense |  | 5% |
| Non-GAAP Guidance - Operating Margin |  | 30.5% - 31.5% |

[0001193125-26-076545:8k_2_02:129]
Some items may not add or recalculate due to rounding.

[0001193125-26-076545:8k_2_02:130]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| EXPRESSED AS NET INCOME PER SHARE |
| FOURTH QUARTER FISCAL 2026 |
|  |  | Fourth Quarter |
|  |  | Fiscal 2026 |
| GAAP Guidance - Net Income Per Share |  | $1.76 - $1.86 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the Fourth Quarter Fiscal 2026: |  |  |
| Amortization of intangible assets |  | $0.02 |
| Stock-based compensation expense |  | $0.48 |
| Income tax effects |  | ($0.05) |
| Total Adjustments |  | $0.45 |
| Non-GAAP Guidance - Net Income Per Share |  | $2.21 - $2.31 |

[0001193125-26-076545:8k_2_02:131]
Some items may not add or recalculate due to rounding.

[0001193125-26-076545:8k_2_02:132]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| FISCAL 2026 |
|  |  | Fiscal 2026 |
| GAAP Guidance - Gross Margin |  | 69.7% - 70.7% |
| Adjustments: |  |  |
| Cost of revenues adjustments |  | 1% |
| Non-GAAP Guidance - Gross Margin |  | 70.7% - 71.7% |
|  |  | Fiscal 2026 |
| GAAP Guidance - Operating Margin |  | 23.3% - 24.3% |
| Adjustments: |  |  |
| Stock-based compensation expense |  | 6% |
| Non-GAAP Guidance - Operating Margin |  | 29.3% - 30.3% |

[0001193125-26-076545:8k_2_02:133]
Some items may not add or recalculate due to rounding.

[0001193125-26-076545:8k_2_02:134]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| EXPRESSED AS NET INCOME PER SHARE |
| FISCAL 2026 |
|  |  | Fiscal 2026 |
| GAAP Guidance - Net Income Per Share |  | $6.07 - $6.17 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2026: |  |  |
| Amortization of intangible assets |  | $0.10 |
| Stock-based compensation expense |  | $1.88 |
| Restructuring charges |  | $0.11 |
| Income tax effects |  | ($0.24) |
| Total Adjustments |  | $1.85 |
| Non-GAAP Guidance - Net Income Per Share |  | $7.92 - $8.02 |

[0001193125-26-076545:8k_2_02:135]
Some items may not add or recalculate due to rounding.

[0001193125-26-076545:8k_2_02:136]
Contacts:

[0001193125-26-076545:8k_2_02:137]
(Press)

[0001193125-26-076545:8k_2_02:138]
Kenya Hayes

[0001193125-26-076545:8k_2_02:139]
1 703 589 7595

[0001193125-26-076545:8k_2_02:140]
kenya.hayes@netapp.com

[0001193125-26-076545:8k_2_02:141]
(Investors)

[0001193125-26-076545:8k_2_02:142]
Kris Newton

[0001193125-26-076545:8k_2_02:143]
1 408 822 3312

[0001193125-26-076545:8k_2_02:144]
kris.newton@netapp.com
