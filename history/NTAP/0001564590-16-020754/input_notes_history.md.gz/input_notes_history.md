# NTAP note change history — 0001564590-15-011213 → 0001564590-16-014119


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-03-07):
[0001564590-16-014119:note_history:1]
Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $216 million as of January 29, 2016.
  (was, 2015-12-02, similarity 0.961):
[0001564590-15-011213:note_history:1]
Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $204 million as of October 30, 2015.

- changed (2016-03-07):
[0001564590-16-014119:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of January 29, 2016, we had $265 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 29, 2016 and April 24, 2015, such liability amounted to $9 million and $17 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2015-12-02, similarity 0.9859):
[0001564590-15-011213:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of October 30, 2015, we had $262 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 30, 2015 and April 24, 2015, such liability amounted to $12 million and $17 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2016-03-07):
[0001564590-16-014119:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 29, 2016, we had $45 million in construction related obligations and $203 million in other purchase obligations.
  (was, 2015-12-02, similarity 0.9809):
[0001564590-15-011213:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 30, 2015, we had $36 million in construction related obligations and $172 million in other purchase obligations.

- changed (2016-03-07):
[0001564590-16-014119:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $153 million and $145 million of receivables during the nine months ended January 29, 2016 and January 23, 2015, respectively.
  (was, 2015-12-02, similarity 0.9689):
[0001564590-15-011213:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $72 million and $89 million of receivables during the six months ended October 30, 2015 and October 24, 2014, respectively.

- changed (2016-03-07):
[0001564590-16-014119:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of January 29, 2016 and April 24, 2015, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.
  (was, 2015-12-02, similarity 0.9821):
[0001564590-15-011213:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of October 30, 2015 and April 24, 2015, the aggregate amount by which such contingencies exceeded the associated deferred revenue was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

- added (2016-03-07):
[0001564590-16-014119:note_history:6]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 29, 2016, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- changed (2016-03-07):
[0001564590-16-014119:note_history:7]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of January 29, 2016 related to such matters as they are not probable and/or reasonably estimable.
  (was, 2015-12-02, similarity 0.6652):
[0001564590-15-011213:note_history:7]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of October 30, 2015 related to such matters as they are not probable and/or reasonably estimable.

- removed (2016-03-07):
[0001564590-15-011213:note_history:8]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 30, 2015, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-03-07):
[0001564590-16-014119:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income (loss) and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2015 contained in our Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 12, 2015. The results of operations for the three and nine months ended January 29, 2016 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2015-12-02, similarity 0.8922):
[0001564590-15-011213:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income (loss) and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2015 contained in our Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 12, 2015. The results of operations for the three and six months ended October 30, 2015 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- added (2016-03-07):
[0001564590-16-014119:note_history:10]
During the three months ended January 29, 2016, we adopted an accounting standard that simplified the presentation of deferred taxes by requiring deferred tax assets and liabilities to be classified as noncurrent in a classified statement of financial position. We have adopted this accounting standard prospectively. Accordingly, the prior period amounts in our condensed consolidated balance sheets within this Quarterly Report on Form 10-Q were not adjusted to conform to the new accounting standard. The adoption of this accounting standard was not material to our condensed consolidated financial statements.

- changed (2016-03-07):
[0001564590-16-014119:note_history:11]
There have been no significant changes in our significant accounting policies as of and for the nine months ended January 29, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 24, 2015.
  (was, 2015-12-02, similarity 0.9587):
[0001564590-15-011213:note_history:11]
There have been no significant changes in our significant accounting policies as of and for the six months ended October 30, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 24, 2015.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-03-07):
[0001564590-16-014119:note_history:12]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (4 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (6 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,490 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |
  (was, 2015-12-02, similarity 0.9898):
[0001564590-15-011213:note_history:12]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (4 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,489 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |

- changed (2016-03-07):
[0001564590-16-014119:note_history:13]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 29, 2016, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2015-12-02, similarity 0.9891):
[0001564590-15-011213:note_history:13]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 30, 2015, we were in compliance with all covenants associated with the Senior Notes.

- changed (2016-03-07):
[0001564590-16-014119:note_history:14]
As of January 29, 2016, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2015-12-02, similarity 0.9362):
[0001564590-15-011213:note_history:14]
As of October 30, 2015, our aggregate future principal debt maturities are as follows (in millions):

- changed (2016-03-07):
[0001564590-16-014119:note_history:15]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of January 29, 2016, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.
  (was, 2015-12-02, similarity 0.9935):
[0001564590-15-011213:note_history:15]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of October 30, 2015, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

- added (2016-03-07):
[0001564590-16-014119:note_history:16]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 8 |  |  | $ | 16 |  |
| Less: current portion |  |  | (5 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 3 |  |  | $ | 6 |  |

- removed (2016-03-07):
[0001564590-15-011213:note_history:17]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 12 |  |  | $ | 16 |  |
| Less: current portion |  |  | (7 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 5 |  |  | $ | 6 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-03-07):
[0001564590-16-014119:note_history:18]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 8 |  |  | $ | 16 |  |
| Less: current portion |  |  | (5 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 3 |  |  | $ | 6 |  |

- removed (2016-03-07):
[0001564590-15-011213:note_history:19]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 12 |  |  | $ | 16 |  |
| Less: current portion |  |  | (7 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 5 |  |  | $ | 6 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-03-07):
[0001564590-16-014119:note_history:20]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (4 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (6 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,490 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |
  (was, 2015-12-02, similarity 0.9898):
[0001564590-15-011213:note_history:20]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (4 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,489 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-03-07):
[0001564590-16-014119:note_history:21]
As of January 29, 2016, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2015-12-02, similarity 0.9362):
[0001564590-15-011213:note_history:21]
As of October 30, 2015, our aggregate future principal debt maturities are as follows (in millions):


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2016-03-07):
[0001564590-16-014119:note_history:22]
17. Subsequent Events

- added (2016-03-07):
[0001564590-16-014119:note_history:23]
SolidFire Acquisition

- added (2016-03-07):
[0001564590-16-014119:note_history:24]
On February 2, 2016, we acquired all of the outstanding shares of privately-held SolidFire, Inc. (SolidFire), a maker of all-flash storage systems based in Colorado, for $855 million in cash. This acquisition extends our position in the all-flash array market by adding new flash offerings that will enhance our ability to deliver customers all-flash storage with a webscale architecture that simplifies data center operations and enables rapid deployments of new applications.

- added (2016-03-07):
[0001564590-16-014119:note_history:25]
We are still in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation for this acquisition. We currently expect between $100 million and $200 million of the purchase price to be allocated to identifiable intangible assets other than goodwill. A preliminary purchase price allocation will be included in our consolidated financial statements for the year ending April 29, 2016.

- added (2016-03-07):
[0001564590-16-014119:note_history:26]
The following unaudited pro forma condensed combined financial information gives effect to the acquisition of SolidFire as if it were consummated on April 26, 2014. The unaudited pro forma condensed combined financial information is presented for informational purposes only, and is not intended to represent or be indicative of the results of operations of the Company that would have been reported had the acquisition occurred on April 26, 2014 and should not be taken as representative of future consolidated results of operations of the combined company (in millions).

- added (2016-03-07):
[0001564590-16-014119:note_history:27]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Net income |  | $ | 128 |  |  | $ | 153 |  |  | $ | 159 |  |  | $ | 341 |  |

- added (2016-03-07):
[0001564590-16-014119:note_history:28]
Adjustments have been reflected in the unaudited pro forma condensed combined information to include the amortization of identifiable intangible assets, purchase accounting adjustments to deferred revenue, interest expense related to the associated financing arrangement and  costs directly attributable to the acquisition. Pro forma net revenues were not materially different than those presented in the condensed consolidated statements of operations.

- added (2016-03-07):
[0001564590-16-014119:note_history:29]
Short-Term Loan

- added (2016-03-07):
[0001564590-16-014119:note_history:30]
In connection with the acquisition, on February 2, 2016, we entered into a short-term loan of $870 million that matures on November 2, 2016. We may repay the loan before its maturity without penalty; however, we may not reborrow any borrowings that were repaid under the term loan agreement. As specified in the term loan agreement, interest on the outstanding borrowings accrues at an adjusted LIBOR plus a spread (based on our public debt ratings) or, at our option, a base rate. We may, from time to time, elect to convert the outstanding loan from one rate to another. We expect to repay the loan on or before the maturity date using funds generated from our global operations. The loan is subject to the same covenants as our credit facility.

- added (2016-03-07):
[0001564590-16-014119:note_history:31]
Credit Facility Amendment

- added (2016-03-07):
[0001564590-16-014119:note_history:32]
On February 2, 2016, we amended our existing credit facility to increase the unsecured revolving credit facility to $300 million.

- added (2016-03-07):
[0001564590-16-014119:note_history:33]
Restructuring Event

- added (2016-03-07):
[0001564590-16-014119:note_history:34]
On February 17, 2016, we committed to a restructuring and reduction in workforce to streamline our business and reduce operating expenses. In connection with these actions, we expect to reduce our worldwide headcount by approximately 12%. The reduction in workforce will be implemented through the end of the first quarter of fiscal 2017. We expect to incur aggregate charges of approximately $60 million to $70 million for employee terminations and other costs associated with the restructuring, consisting primarily of cash expenditures. The majority of these charges will be recognized in the fourth quarter of fiscal 2016.
