# NTAP notes — 0001564590-16-020754


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-16-020754:notes:1]
1. Description of Business and Significant Accounting Policies

[0001564590-16-020754:notes:2]
Description of Business —NetApp, Inc. (we, us, or the Company) provides software, systems and services to manage and store computer data. We enable enterprises, service providers, governmental organizations, and partners to envision, deploy and evolve their information technology environments and to reduce costs and risk while driving growth and success for their organizations.

[0001564590-16-020754:notes:3]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2016, ended on April 29, 2016, was a 53-week year. Our fiscal years 2015 and 2014, ended on April 24, 2015 and April 25, 2014, respectively, were each 52-week years. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended on the last Friday of April and the associated quarters, months and periods of those fiscal years.

[0001564590-16-020754:notes:4]
Principles of Consolidation — The consolidated financial statements include the Company and its subsidiaries. Intercompany accounts and transactions are eliminated in consolidation.

[0001564590-16-020754:notes:5]
Accounting Change — During fiscal 2016, we adopted an accounting standard that simplified the presentation of deferred taxes by requiring deferred tax assets and liabilities to be classified as noncurrent in a classified statement of financial position. We adopted this accounting standard prospectively. Accordingly, the prior period amounts in our consolidated balance sheets within this Annual Report on Form 10-K were not adjusted to conform to the new accounting standard. The adoption of this accounting standard was not material to our consolidated financial statements.

[0001564590-16-020754:notes:6]
Use of Estimates — The preparation of the consolidated financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-16-020754:notes:7]
Cash Equivalents — We consider all highly liquid debt investments with original maturities of three months or less at the time of purchase to be cash equivalents.

[0001564590-16-020754:notes:8]
Available-for-Sale Investments — We classify our investments in debt securities as available-for-sale investments. Debt securities primarily consist of corporate bonds, U.S. Treasury and government debt securities and certificates of deposit. These available-for-sale investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of debt securities sold. These investments are recorded in the consolidated balance sheets at fair value.

[0001564590-16-020754:notes:9]
Unrealized gains and temporary losses, net of related taxes, are included in accumulated other comprehensive income (loss) (AOCI). Upon realization, those amounts are reclassified from AOCI to earnings. The amortization of premiums and discounts on the investments are included in our results of operations. Realized gains and losses on our available-for-sale investments are calculated based on the specific identification method.

[0001564590-16-020754:notes:10]
We classify our investments as current or noncurrent based on the nature of the investments and their availability for use in current operations.

[0001564590-16-020754:notes:11]
Other-than-Temporary Impairments on Investments — All of our available-for-sale investments are subject to periodic impairment review. When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and we assess whether the impairment is other-than-temporary. An impairment is considered other-than-temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of the entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost basis of the security. If impairment is considered other-than-temporary based on condition (i) or (ii) described above, the entire difference between the amortized cost and the fair value of the debt security is recognized in the results of operations. If an impairment is considered other-than-temporary based on condition (iii) described above, the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in earnings, and the amount relating to all other factors is recognized in other comprehensive income (OCI).

[0001564590-16-020754:notes:12]
Inventories — Inventories are stated at the lower of cost or market, which approximates actual cost on a first-in, first-out basis. We write down excess and obsolete inventory based on the difference between the cost of inventory and the estimated net realizable value based upon assumptions about future demand forecasts and market conditions. At the point of a loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts or circumstances do not result in the restoration or increase in that newly established basis. In addition, we record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0001564590-16-020754:notes:13]
Property and Equipment — Property and equipment are recorded at cost.

[0001564590-16-020754:notes:14]
Depreciation and amortization is computed using the straight-line method, generally over the following periods:

[0001564590-16-020754:notes:15]
|  |  | Depreciation Life |
| Buildings and improvements |  | 10 to 40 years |
| Furniture and fixtures |  | 5 years |
| Computer, production, engineering and other equipment |  | 2 to 3 years |
| Computer software |  | 3 to 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |

[0001564590-16-020754:notes:16]
Construction in progress will be depreciated over the estimated useful lives of the respective assets when they are ready for use. We capitalize interest on significant facility assets under construction and on significant software development projects.

[0001564590-16-020754:notes:17]
Software Development Costs — The costs for the development of new software products and substantial enhancements to existing software products are expensed as incurred until technological feasibility has been established, at which time any additional costs would be capitalized in accordance with the accounting guidance for software. Because our current process for developing software is essentially completed concurrently with the establishment of technological feasibility, which occurs upon the completion of a working model, no costs have been capitalized for any of the periods presented.

[0001564590-16-020754:notes:18]
Internal-Use Software Development Costs — We capitalize qualifying costs, which are incurred during the application development stage, for computer software developed or obtained for internal-use and amortize them over the software’s estimated useful life.

[0001564590-16-020754:notes:19]
Business Combinations — We recognize identifiable assets acquired and liabilities assumed at their acquisition date fair values. Goodwill as of the acquisition date is measured as the excess of consideration transferred over the net of the acquisition date fair values of the assets acquired and the liabilities assumed. While we use our best estimates and assumptions as a part of the purchase price allocation process to accurately value assets acquired and liabilities assumed at the acquisition date, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001564590-16-020754:notes:20]
Goodwill and Purchased Intangible Assets — Goodwill is recorded when the consideration paid for an acquisition exceeds the fair value of net tangible and intangible assets acquired. Purchased intangible assets with finite lives are amortized on a straight-line basis over their economic lives of three to six years for developed technology, two to eight years for customer contracts/relationships, two to three years for covenants not to compete and two to seven years for trademarks and trade names as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. In-process research and development is accounted for as an indefinite lived intangible asset and is assessed for potential impairment annually until development is complete or when events or circumstances indicate that their carrying amounts might be impaired. Upon completion of development, in-process research and development is accounted for as a finite-lived intangible asset.

[0001564590-16-020754:notes:21]
The carrying value of goodwill is tested for impairment on an annual basis in the fourth quarter of our fiscal year, or more frequently if we believe indicators of impairment exist. Triggering events for impairment reviews may be indicators such as adverse industry or economic trends, restructuring actions, lower projections of profitability, or a sustained decline in our market capitalization. The performance of the test involves a two-step process. The first step requires comparing the fair value of each of our reporting units to its carrying amount, including goodwill. We have three reporting units, the fair values of which are determined based on an allocation of our entity level market capitalization, as determined through quoted market prices. A potential impairment exists if the fair value of a reporting unit is lower than its carrying amount. The second step of the process is only performed if a potential impairment exists, and it involves determining the difference between the fair value of the reporting unit’s net assets other than goodwill and the fair value of the reporting unit. If that difference is less than the net book value of goodwill, an impairment exists and is recorded. We have not been required to perform this second step of the process because the fair values of each of our reporting units have substantially exceeded their respective carrying amounts in all periods presented.

[0001564590-16-020754:notes:22]
Impairment of Long-Lived Assets — We review the carrying values of long-lived assets whenever events and circumstances, such as reductions in demand, lower projections of profitability, significant changes in the manner of our use of acquired assets, or significant negative industry or economic trends, indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. If this review indicates that there is an impairment, the impaired asset is written down to its fair value, which is typically calculated using: (i) quoted market prices and/or (ii) expected future cash flows utilizing a discount rate. Our estimates regarding future anticipated cash flows, the remaining economic life of the products and technologies, or both, may differ from those used to assess the recoverability of assets. In that event, impairment charges or shortened useful lives of certain long-lived assets may be required, resulting in charges to our consolidated statements of operations when such determinations are made.

[0001564590-16-020754:notes:23]
Derivative Instruments — Our derivative instruments, which are carried at fair value in our consolidated balance sheets, consist of foreign currency exchange contracts as described below:

[0001564590-16-020754:notes:24]
Balance Sheet Hedges — We utilize foreign currency exchange forward and option contracts to hedge against the short-term impact of foreign currency exchange rate fluctuations related to certain foreign currency denominated monetary assets and liabilities, primarily intercompany receivables and payables. These derivative instruments are not designated as hedging instruments and do not subject us to material balance sheet risk due to exchange rate movements because the gains and losses on these contracts are intended to offset the gains and losses in the underlying foreign currency denominated monetary assets and liabilities being hedged, and the net amount is included in earnings.

[0001564590-16-020754:notes:25]
Cash Flow Hedges — We utilize foreign currency exchange forward contracts to hedge foreign currency exchange exposures related to forecasted sales transactions denominated in certain foreign currencies. These derivative instruments are designated and qualify as cash flow hedges and in general, closely match the underlying forecasted transactions in duration. The effective portion of the contracts’ gains and losses resulting from changes in fair value is recorded in AOCI until the forecasted transaction is recognized in the consolidated statements of operations. When the forecasted transactions occur, we reclassify the related gains or losses on the cash flow hedges into net revenues. If the underlying forecasted transactions do not occur, or it becomes probable that they will not occur within the defined hedge period, the gains or losses on the related cash flow hedges are reclassified from AOCI and recognized immediately in earnings. We measure the effectiveness of hedges of forecasted transactions on a monthly basis by comparing the fair values of the designated foreign currency exchange forward purchase contracts with the fair values of the forecasted transactions. Any ineffective portion of the derivative hedging gain or loss, as well as changes in the fair value of the derivative’s time value (which are excluded from the assessment of hedge effectiveness), are recognized in earnings.

[0001564590-16-020754:notes:26]
Factors that could have an impact on the effectiveness of our hedging programs include the accuracy of forecasts and the volatility of foreign currency markets. These programs reduce, but do not entirely eliminate, the impact of currency exchange movements. Currently, we do not enter into any foreign currency exchange forward contracts to hedge exposures related to firm commitments. Cash flows from our derivative programs are included under operating activities in the consolidated statements of cash flows.

[0001564590-16-020754:notes:27]
Revenue Recognition — We recognize revenue when:

[0001564590-16-020754:notes:28]
|  | · | Persuasive evidence of an arrangement exists. Customarily we have a purchase order and/or contract prior to recognizing revenue on an arrangement from our end users, customers, value-added resellers or distributors. |

[0001564590-16-020754:notes:29]
|  | · | Delivery has occurred. Our product is physically delivered to our customers. We typically do not allow for restocking rights with any of our value-added resellers or distributors. Products shipped with acceptance criteria or return rights are not recognized as revenue until all criteria are achieved. We do not recognize revenue if undelivered products or services exist that are essential to the functionality of the delivered product in an arrangement. |

[0001564590-16-020754:notes:30]
|  | · | The fee is fixed or determinable. Arrangements with payment terms extending beyond our standard terms, conditions and practices are not considered to be fixed or determinable. Revenue from such arrangements is recognized at the earlier of customer payment or when the fees become due and payable. We typically do not allow for price-protection rights with any of our value-added resellers or distributors. |

[0001564590-16-020754:notes:31]
|  | · | Collection is reasonably assured. If there is considerable doubt surrounding the creditworthiness of a customer at the outset of an arrangement, the associated revenue is deferred and recognized upon cash receipt. |

[0001564590-16-020754:notes:32]
The hardware systems and software components essential to the functionality of the hardware systems are considered non-software deliverables and therefore are not subject to industry-specific software revenue recognition guidance.

[0001564590-16-020754:notes:33]
Our product revenues also include revenues from the sale of non-essential software products. Non-essential software sales generally include a perpetual license to our software. Non-essential software sales are subject to the industry-specific software revenue recognition guidance.

[0001564590-16-020754:notes:34]
Our multiple element arrangements may include our systems, software maintenance, hardware maintenance and other services. Software maintenance contracts entitle our customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, and patch releases. Hardware maintenance services include contracts for extended warranty, technical support and minimum response times. Other services include professional services and customer education and training services. Revenues from software maintenance and hardware maintenance services are recognized ratably over the contractual term, generally from one to five years. We also offer extended warranty contracts (which extend our standard parts warranty and may include premium hardware maintenance) at the end of the original warranty term; revenues from these contracts are recognized ratably over their respective contract term. We sell professional services either on a time and materials basis or under fixed price projects; we recognize revenue for these services as they are performed.

[0001564590-16-020754:notes:35]
For multiple element arrangements, we allocate revenue to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement. The selling price for each element is based upon the following selling price hierarchy: vendor specific objective evidence of selling price (VSOE) if available, third party evidence (TPE) if VSOE is not available, or estimated selling price (ESP) if neither VSOE nor TPE are available. ESP is generally evidenced by a majority of historical transactions falling within a reasonable price range. We also consider multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, type of customer and distribution channels. For our non-software deliverables, we generally allocate the arrangement consideration based on the relative selling price of the deliverables using ESP. For our software maintenance services, we generally use VSOE. When we are unable to establish VSOE for our software maintenance services, we use ESP in our allocation of arrangement consideration.

[0001564590-16-020754:notes:36]
VSOE is based upon the normal pricing and discounting practices for those services when sold separately. VSOE is generally evidenced by a substantial majority of historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer type, and other variables in determining VSOE.

[0001564590-16-020754:notes:37]
When VSOE cannot be established, we attempt to establish the selling price of each element based on third party evidence of selling price (TPE). Generally, we are not able to determine TPE because our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained.

[0001564590-16-020754:notes:38]
We regularly review VSOE, TPE, and ESP and maintain internal controls over the establishment and updates of these estimates.

[0001564590-16-020754:notes:39]
For our software deliverables, we use the residual method to recognize revenue when an arrangement includes one or more elements to be delivered at a future date and VSOE of all undelivered elements exists. Typically, only software maintenance, hardware maintenance and/or other services remain undelivered after the product is delivered. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the consideration is recognized as product revenues for delivered elements. If evidence of the fair value of one or more undelivered elements does not exist, all revenue is generally deferred until the earlier of when delivery of those elements occurs or when fair value can be established. In instances where the only undelivered element without fair value is software maintenance, the entire arrangement is recognized ratably over the maintenance period.

[0001564590-16-020754:notes:40]
We record reductions to revenue for estimated sales returns at the time of shipment. Sales returns are estimated based on historical sales returns, current trends, and our expectations regarding future experience. We monitor and analyze the accuracy of sales returns estimates by reviewing actual returns and adjust them for future expectations. Additionally, distributors and retail partners participate in various marketing and other programs, and we record estimated accruals and allowances for these programs. We accrue for these programs based on contractual terms and historical experience. Sales and value added taxes collected from customers and remitted to governmental authorities are presented on a net basis in the accompanying consolidated statements of operations.

[0001564590-16-020754:notes:41]
Product Warranties — Estimated future hardware and software warranty costs are recorded as a cost of product revenues at the time of product shipment, based on historical and projected warranty claim rates, historical and projected cost-per-claim and knowledge of specific product failures that are outside our typical experience. Factors that affect our warranty liability include the number of installed units subject to warranty protection, product failure rates, and estimated materials, distribution and labor costs. We assess the adequacy of our warranty accrual each quarter and adjust the amount as considered necessary.

[0001564590-16-020754:notes:42]
Foreign Currency Translation — For international subsidiaries whose functional currency is the local currency, gains and losses resulting from translation of these foreign currency financial statements into U.S. dollars are recorded in AOCI. For subsidiaries where the functional currency is the U.S. dollar, gains and losses resulting from the process of remeasuring foreign currency financial statements into U.S. dollars are included in other income (expense), net.

[0001564590-16-020754:notes:43]
Benefit Plans — We have a postretirement health care plan and various international defined benefit plans for certain of our employees. We record actuarial gains and losses within AOCI and amortize net gains or losses in excess of 10 percent of the greater of the market value of plan assets or the plans' projected benefit obligation on a straight-line basis over the remaining estimated service life of plan participants. The measurement date for all defined benefit plans is our fiscal year end.

[0001564590-16-020754:notes:44]
Stock-Based Compensation — We measure and recognize stock-based compensation for all stock-based awards, including employee stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and rights to purchase shares under our employee stock purchase plan (ESPP), based on their estimated fair value, and recognize the costs in our financial statements using the single option straight-line approach over the requisite service period for the entire award.

[0001564590-16-020754:notes:45]
The fair value of employee time-based RSUs is equal to the market value of our common stock on the grant date of the award, less the present value of expected dividends during the vesting period, discounted at a risk-free interest rate. The fair value of PBRSUs is measured using a Monte Carlo simulation model on the date of grant.

[0001564590-16-020754:notes:46]
The fair value of each award is estimated on the grant date and is not remeasured as a result of subsequent stock price fluctuations. Our expected term assumption is based primarily on historical exercise and post-vesting forfeiture experience. Our stock price volatility assumption is based on a combination of our historical and implied volatility. The risk-free interest rates are based upon United States Treasury bills with equivalent expected terms, and the expected dividends are based on our history and expected dividend payouts.

[0001564590-16-020754:notes:47]
We estimate the number of stock-based awards that will be forfeited due to employee turnover. Our forfeiture assumption is primarily based on historical experience.

[0001564590-16-020754:notes:48]
Income Taxes — Deferred income tax assets and liabilities are provided for temporary differences that will result in tax deductions or income in future periods, as well as the future benefit of tax credit carryforwards. A valuation allowance reduces tax assets to their estimated realizable value.

[0001564590-16-020754:notes:49]
We recognize the tax liability for uncertain income tax positions on the income tax return based on the two-step process prescribed in the interpretation. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. We recognize interest and penalties related to unrecognized tax benefits within the income tax expense line in the accompanying consolidated statements of operations.

[0001564590-16-020754:notes:50]
Tax attributes related to the exercise of employee stock options are not realized until they result in a reduction of taxes payable. We do not include unrealized stock option attributes as components of our gross deferred tax assets and corresponding valuation allowance disclosures.

[0001564590-16-020754:notes:51]
Net Income per Share — Basic net income per share is computed by dividing income available to common stockholders by the weighted-average number of common shares outstanding. Diluted net income per share is computed giving effect to all dilutive potential shares that were outstanding during the period. Potential dilutive common shares consist primarily of outstanding stock options, shares to be purchased under our employee stock purchase plan and unvested RSUs.

[0001564590-16-020754:notes:52]
Treasury Stock — We account for treasury stock under the cost method. Upon the retirement of treasury stock, we allocate the value of treasury shares between common stock, additional paid-in capital and retained earnings.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001564590-16-020754:notes:53]
2. Concentration of Risk

[0001564590-16-020754:notes:54]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, investments, foreign currency exchange contracts and accounts receivable. Cash equivalents and short-term investments consist primarily of corporate bonds, U.S. Treasury and government debt securities and certificates of deposit, all of which are considered high investment grade. Our policy is to limit the amount of credit exposure through diversification and investment in highly rated securities. We further mitigate concentrations of credit risk in our investments by limiting our investments in the debt securities of a single issuer and by diversifying risk across geographies and type of issuer.

[0001564590-16-020754:notes:55]
By entering into foreign currency exchange contracts, we have assumed the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and we do not expect any losses as a result of counterparty defaults.

[0001564590-16-020754:notes:56]
We sell our products primarily to large organizations in different industries and geographies. We do not require collateral or other security to support accounts receivable. In addition, we maintain an allowance for potential credit losses. To reduce credit risk, we perform ongoing credit evaluations on our customers’ financial condition. We establish an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information and, to date, such losses have been within management’s expectations. Concentrations of credit risk with respect to trade accounts receivable are limited due to the wide variety of customers who are dispersed across many geographic regions.

[0001564590-16-020754:notes:57]
There are no concentrations of business transacted with a particular market that would severely impact our business in the near term. However, we rely on a limited number of suppliers for certain key components and a few key contract manufacturers to manufacture most of our products; any disruption or termination of these arrangements could materially adversely affect our operating results.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-16-020754:notes:58]
4. Statements of Cash Flows Additional Information

[0001564590-16-020754:notes:59]
Non-cash investing activities and supplemental cash flow information are as follows (in millions):

[0001564590-16-020754:notes:60]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 18 |  |  | $ | 12 |  |  | $ | 18 |  |
| Acquisition of software through long-term financing |  | $ | — |  |  | $ | 12 |  |  | $ | 11 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 161 |  |  | $ | 97 |  |  | $ | 58 |  |
| Interest paid |  | $ | 43 |  |  | $ | 33 |  |  | $ | 35 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-16-020754:notes:61]
5. Business Combinations

[0001564590-16-020754:notes:62]
SolidFire Acquisition

[0001564590-16-020754:notes:63]
On February 2, 2016, we acquired all of the outstanding shares of privately-held SolidFire, Inc. (SolidFire), a maker of all-flash storage systems based in Colorado, for $850 million in cash. This acquisition extends our position in the all-flash array market by adding new flash offerings that will enhance our ability to deliver customers all-flash storage with a webscale architecture that simplifies data center operations and enables rapid deployments of new applications.

[0001564590-16-020754:notes:64]
The acquired assets and assumed liabilities were recorded at their estimated fair values. We determined the estimated fair values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expect to realize revenue synergies, leverage and expand the existing SolidFire sales channels and product development resources, and utilize the existing workforce. We also anticipate opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated fair value of SolidFire’s identifiable net assets acquired, and as a result, we have recorded goodwill in connection with this acquisition. The U.S. goodwill is not deductible for income tax purposes.

[0001564590-16-020754:notes:65]
The preliminary fair values of assets acquired and liabilities assumed on the closing date are summarized as follows (in millions):

[0001564590-16-020754:notes:66]
| Cash |  | $ | 8 |  |
| Intangible assets |  |  | 168 |  |
| Goodwill |  |  | 649 |  |
| Other assets |  |  | 56 |  |
| Total assets acquired |  |  | 881 |  |
| Liabilities assumed |  |  | (31 | ) |
| Total purchase price |  | $ | 850 |  |

[0001564590-16-020754:notes:67]
The components of intangible assets acquired were as follows (in millions, except useful life):

[0001564590-16-020754:notes:68]
|  |  |  |  |  |  | Estimated useful life (years) |
| Developed technology |  | $ | 99 |  |  | 5 |
| Customer contracts/relationships |  |  | 41 |  |  | 3 |
| Trade name |  |  | 9 |  |  | 2 |
| Total intangible assets subject to amortization |  |  | 149 |  |  |  |
| In-process research and development |  |  | 19 |  |  | N/A |
| Total intangible assets |  | $ | 168 |  |  |  |

[0001564590-16-020754:notes:69]
N/A - Not applicable

[0001564590-16-020754:notes:70]
In-process research and development was valued with input from valuation specialists using the multi-period excess earnings method under the income approach by discounting forecasted cash flows directly related to the products expected to result from the associated project, net of returns on contributory assets. The in-process development project acquired related to a major new generation of the SolidFire technology platform.

[0001564590-16-020754:notes:71]
The following unaudited pro forma condensed combined financial information gives effect to the acquisition of SolidFire as if it had been consummated on April 26, 2014. The unaudited pro forma condensed combined financial information is presented for informational purposes only, and is not intended to represent or be indicative of the results of operations of the Company that would have been reported had the acquisition occurred on April 26, 2014 and should not be taken as representative of future consolidated results of operations of the combined company (in millions).

[0001564590-16-020754:notes:72]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Net income |  | $ | 219 |  |  | $ | 377 |  |

[0001564590-16-020754:notes:73]
Adjustments have been reflected in the unaudited pro forma condensed combined information to include the amortization of identifiable intangible assets, purchase accounting adjustments to deferred revenue, interest expense related to the associated financing arrangement, costs directly attributable to the acquisition and impacts to our provision for income taxes as a result of the acquisition. Pro forma net revenues were not materially different than those presented in the consolidated statements of operations.

[0001564590-16-020754:notes:74]
Fiscal 2015 Acquisitions

[0001564590-16-020754:notes:75]
On October 27, 2014, we completed the acquisition of certain assets related to Riverbed Technology, Inc.’s SteelStore product line for $79 million in cash. The SteelStore product line supports leading backup applications and cloud providers so that customers have a choice in how they extend their existing data protection infrastructure into the cloud.

[0001564590-16-020754:notes:76]
In addition, on the same date, we acquired certain intangible assets from a privately-held software developer for $6 million in cash.

[0001564590-16-020754:notes:77]
Following are the fair values of net assets acquired as of the closing date (in millions):

[0001564590-16-020754:notes:78]
| Net tangible assets |  | $ | 14 |  |
| Finite-lived intangible assets |  |  | 32 |  |
| Goodwill |  |  | 39 |  |
| Total purchase price |  | $ | 85 |  |

[0001564590-16-020754:notes:79]
The results of operations related to these acquisitions have been included in our consolidated statements of operations from the acquisition date. Pro forma results of operations have not been presented because the acquisitions were not material to our results of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-16-020754:notes:80]
6. Goodwill and Purchased Intangible Assets, Net

[0001564590-16-020754:notes:81]
Goodwill activity is summarized as follows (in millions):

[0001564590-16-020754:notes:82]
| Balance as of April 25, 2014 |  | $ | 988 |  |
| Goodwill acquired |  |  | 39 |  |
| Balance as of April 24, 2015 |  |  | 1,027 |  |
| Goodwill acquired |  |  | 649 |  |
| Balance as of April 29, 2016 |  | $ | 1,676 |  |

[0001564590-16-020754:notes:83]
Purchased intangible assets are summarized below (in millions):

[0001564590-16-020754:notes:84]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 403 |  |  | $ | (289 | ) |  | $ | 114 |  |  | $ | 313 |  |  | $ | (225 | ) |  | $ | 88 |  |
| Customer contracts/relationships |  |  | 46 |  |  |  | (7 | ) |  |  | 39 |  |  |  | 5 |  |  |  | (3 | ) |  |  | 2 |  |
| Other purchased intangibles |  |  | 10 |  |  |  | (2 | ) |  |  | 8 |  |  |  | 3 |  |  |  | (3 | ) |  |  | — |  |
| Total intangible assets subject to amortization |  |  | 459 |  |  |  | (298 | ) |  |  | 161 |  |  |  | 321 |  |  |  | (231 | ) |  |  | 90 |  |
| In-process research and development |  |  | 19 |  |  |  | — |  |  |  | 19 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total purchased intangible assets |  | $ | 478 |  |  | $ | (298 | ) |  | $ | 180 |  |  | $ | 321 |  |  | $ | (231 | ) |  | $ | 90 |  |

[0001564590-16-020754:notes:85]
During fiscal 2016, we recorded a charge of $11 million to fully impair developed technology related to our fiscal 2013 acquisition of CacheIQ as a result of our discontinued use of such technology. The impairment charge is included in accumulated amortization in the table above.

[0001564590-16-020754:notes:86]
Amortization expense for purchased intangible assets is summarized below (in millions):

[0001564590-16-020754:notes:87]
|  |  | Year Ended |  |  | Statement of |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |  | Operations Classifications |
| Developed technology |  | $ | 61 |  |  | $ | 63 |  |  | $ | 57 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 5 |  |  |  | 1 |  |  |  | 1 |  |  | Operating expenses |
| Other purchased intangibles |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  | Operating expenses |
| Total |  | $ | 67 |  |  | $ | 64 |  |  | $ | 59 |  |  |  |

[0001564590-16-020754:notes:88]
As of April 29, 2016, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-16-020754:notes:89]
| Fiscal Year |  | Amount |  |
| 2017 |  | $ | 64 |  |
| 2018 |  |  | 43 |  |
| 2019 |  |  | 35 |  |
| 2020 |  |  | 23 |  |
| 2021 |  |  | 15 |  |
| Total |  | $ | 180 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-16-020754:notes:90]
7. Balance Sheet Details

[0001564590-16-020754:notes:91]
Cash and cash equivalents (in millions):

[0001564590-16-020754:notes:92]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Cash |  | $ | 2,714 |  |  | $ | 1,666 |  |
| Cash equivalents |  |  | 154 |  |  |  | 256 |  |
| Cash and cash equivalents |  | $ | 2,868 |  |  | $ | 1,922 |  |

[0001564590-16-020754:notes:93]
Inventories (in millions):

[0001564590-16-020754:notes:94]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Purchased components |  | $ | 10 |  |  | $ | 36 |  |
| Finished goods |  |  | 88 |  |  |  | 110 |  |
| Inventories |  | $ | 98 |  |  | $ | 146 |  |

[0001564590-16-020754:notes:95]
Other current assets (in millions):

[0001564590-16-020754:notes:96]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Prepaid expenses and other current assets |  | $ | 234 |  |  | $ | 268 |  |
| Deferred tax assets |  |  | — |  |  |  | 254 |  |
| Other current assets |  | $ | 234 |  |  | $ | 522 |  |

[0001564590-16-020754:notes:97]
Property and equipment, net (in millions):

[0001564590-16-020754:notes:98]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Land |  | $ | 215 |  |  | $ | 265 |  |
| Buildings and improvements |  |  | 605 |  |  |  | 607 |  |
| Leasehold improvements |  |  | 106 |  |  |  | 107 |  |
| Computer, production, engineering and other equipment |  |  | 751 |  |  |  | 754 |  |
| Computer software |  |  | 352 |  |  |  | 372 |  |
| Furniture and fixtures |  |  | 88 |  |  |  | 85 |  |
| Construction-in-progress |  |  | 74 |  |  |  | 33 |  |
|  |  |  | 2,191 |  |  |  | 2,223 |  |
| Accumulated depreciation and amortization |  |  | (1,254 | ) |  |  | (1,193 | ) |
| Property and equipment, net |  | $ | 937 |  |  | $ | 1,030 |  |

[0001564590-16-020754:notes:99]
On April 19, 2016, we sold certain buildings and land in Sunnyvale, California which had a net book value of $118 million at the time of sale, for $250 million in cash. As described in Note 10 – Financing Arrangements, certain of the properties did not qualify as sales under accounting standards due to continuing involvement related to leaseback arrangements. The remaining properties, which had a net book value of $51 million and related sales proceeds of $102 million, were recognized as sales, resulting in a gain of $51 million in fiscal 2016.

[0001564590-16-020754:notes:100]
Depreciation and amortization expense related to property and equipment, net is summarized below (in millions):

[0001564590-16-020754:notes:101]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Depreciation and amortization expense |  | $ | 212 |  |  | $ | 243 |  |  | $ | 275 |  |

[0001564590-16-020754:notes:102]
Other non-current assets (in millions):

[0001564590-16-020754:notes:103]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Deferred tax assets |  | $ | 621 |  |  | $ | 256 |  |
| Other assets |  |  | 175 |  |  |  | 225 |  |
| Other non-current assets |  | $ | 796 |  |  | $ | 481 |  |

[0001564590-16-020754:notes:104]
Accrued expenses (in millions):

[0001564590-16-020754:notes:105]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Accrued compensation and benefits |  | $ | 371 |  |  | $ | 359 |  |
| Product warranty liability |  |  | 48 |  |  |  | 58 |  |
| Other current liabilities |  |  | 346 |  |  |  | 284 |  |
| Accrued expenses |  | $ | 765 |  |  | $ | 701 |  |

[0001564590-16-020754:notes:106]
Product warranty liabilities:

[0001564590-16-020754:notes:107]
Equipment and software systems sales include a standard product warranty. The following tables summarize the activity related to product warranty liabilities and their balances as reported in our consolidated balance sheets (in millions):

[0001564590-16-020754:notes:108]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Balance at beginning of period |  | $ | 86 |  |  | $ | 110 |  |
| Expense accrued during the period |  |  | 35 |  |  |  | 35 |  |
| Warranty costs incurred |  |  | (51 | ) |  |  | (59 | ) |
| Balance at end of period |  | $ | 70 |  |  | $ | 86 |  |

[0001564590-16-020754:notes:109]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Accrued expenses |  | $ | 48 |  |  | $ | 58 |  |
| Other long-term liabilities |  |  | 22 |  |  |  | 28 |  |
| Total warranty liabilities |  | $ | 70 |  |  | $ | 86 |  |

[0001564590-16-020754:notes:110]
Warranty expense accrued during the period includes amounts accrued for systems at the time of shipment, adjustments for changes in estimated costs for warranties on systems shipped in the period and changes in estimated costs for warranties on systems shipped in prior periods.

[0001564590-16-020754:notes:111]
Deferred revenue and financed unearned services revenue (in millions):

[0001564590-16-020754:notes:112]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Deferred product revenue |  | $ | 68 |  |  | $ | 17 |  |
| Deferred services revenue |  |  | 3,100 |  |  |  | 3,075 |  |
| Financed unearned services revenue |  |  | 217 |  |  |  | 105 |  |
| Total |  | $ | 3,385 |  |  | $ | 3,197 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,794 |  |  | $ | 1,724 |  |
| Long-term |  |  | 1,591 |  |  |  | 1,473 |  |
| Total |  | $ | 3,385 |  |  | $ | 3,197 |  |

[0001564590-16-020754:notes:113]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 18 for additional information related to these arrangements.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-16-020754:notes:114]
8. Other income (expense), net

[0001564590-16-020754:notes:115]
Other income (expense), net consists of the following (in millions):

[0001564590-16-020754:notes:116]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Interest income |  | $ | 46 |  |  | $ | 37 |  |  | $ | 35 |  |
| Interest expense |  |  | (49 | ) |  |  | (42 | ) |  |  | (36 | ) |
| Other income, net |  |  | — |  |  |  | 2 |  |  |  | 8 |  |
| Total other income (expense), net |  | $ | (3 | ) |  | $ | (3 | ) |  | $ | 7 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-16-020754:notes:117]
9. Financial Instruments and Fair Value Measurements

[0001564590-16-020754:notes:118]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis, whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the three levels of inputs to measure fair value:

[0001564590-16-020754:notes:119]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001564590-16-020754:notes:120]
Level 2: Inputs that reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; benchmark yields, reported trades, broker/dealer quotes, inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0001564590-16-020754:notes:121]
Level 3: Unobservable inputs that reflect our own assumptions incorporated in valuation techniques used to measure fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0001564590-16-020754:notes:122]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and consider an inactive market to be one in which there are infrequent or few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty’s non-performance risk is considered in measuring the fair values of liabilities and assets, respectively.

[0001564590-16-020754:notes:123]
Investments

[0001564590-16-020754:notes:124]
The following is a summary of our investments (in millions):

[0001564590-16-020754:notes:125]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,370 |  |  | $ | 5 |  |  | $ | (1 | ) |  | $ | 1,374 |  |  | $ | 2,249 |  |  | $ | 9 |  |  | $ | — |  |  | $ | 2,258 |  |
| U.S. Treasury and government debt securities |  |  | 878 |  |  |  | 2 |  |  |  | — |  |  |  | 880 |  |  |  | 1,056 |  |  |  | 2 |  |  |  | — |  |  |  | 1,058 |  |
| Foreign government debt securities |  |  | 35 |  |  |  | — |  |  |  | — |  |  |  | 35 |  |  |  | 38 |  |  |  | — |  |  |  | — |  |  |  | 38 |  |
| Commercial paper |  |  | 202 |  |  |  | — |  |  |  | — |  |  |  | 202 |  |  |  | 20 |  |  |  | — |  |  |  | — |  |  |  | 20 |  |
| Certificates of deposit |  |  | 98 |  |  |  | — |  |  |  | — |  |  |  | 98 |  |  |  | 286 |  |  |  | — |  |  |  | — |  |  |  | 286 |  |
| Mutual funds |  |  | 30 |  |  |  | — |  |  |  | — |  |  |  | 30 |  |  |  | 32 |  |  |  | — |  |  |  | — |  |  |  | 32 |  |
| Total debt and equity securities |  | $ | 2,613 |  |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 2,619 |  |  | $ | 3,681 |  |  | $ | 11 |  |  | $ | — |  |  | $ | 3,692 |  |

[0001564590-16-020754:notes:126]
As of April 29, 2016 and April 24, 2015, gross unrealized losses related to individual securities were not significant.

[0001564590-16-020754:notes:127]
The following table presents the contractual maturities of our debt investments as of April 29, 2016 (in millions):

[0001564590-16-020754:notes:128]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 901 |  |  | $ | 902 |  |
| Due after one year through five years |  |  | 1,682 |  |  |  | 1,687 |  |
|  |  | $ | 2,583 |  |  | $ | 2,589 |  |

[0001564590-16-020754:notes:129]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0001564590-16-020754:notes:130]
Fair Value of Financial Instruments

[0001564590-16-020754:notes:131]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis (in millions):

[0001564590-16-020754:notes:132]
|  |  | April 29, 2016 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,714 |  |  | $ | 2,714 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,374 |  |  |  | — |  |  |  | 1,374 |  |
| U.S. Treasury and government debt securities |  |  | 880 |  |  |  | 276 |  |  |  | 604 |  |
| Foreign government debt securities |  |  | 35 |  |  |  | — |  |  |  | 35 |  |
| Commercial paper |  |  | 202 |  |  |  | — |  |  |  | 202 |  |
| Certificates of deposit |  |  | 98 |  |  |  | — |  |  |  | 98 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 5,303 |  |  | $ | 2,990 |  |  | $ | 2,313 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 5 |  |  | $ | 5 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 25 |  |  | $ | 25 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (8 | ) |  | $ | — |  |  | $ | (8 | ) |

[0001564590-16-020754:notes:133]
|  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 1,666 |  |  | $ | 1,666 |  |  | $ | — |  |
| Corporate bonds |  |  | 2,258 |  |  |  | — |  |  |  | 2,258 |  |
| U.S. Treasury and government debt securities |  |  | 1,058 |  |  |  | 145 |  |  |  | 913 |  |
| Foreign government debt securities |  |  | 38 |  |  |  | — |  |  |  | 38 |  |
| Commercial paper |  |  | 20 |  |  |  | — |  |  |  | 20 |  |
| Certificates of deposit |  |  | 286 |  |  |  | — |  |  |  | 286 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 5,326 |  |  | $ | 1,811 |  |  | $ | 3,515 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 3 |  |  | $ | 3 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 29 |  |  | $ | 29 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |

[0001564590-16-020754:notes:134]
| (1) | Reported as other current assets in the consolidated balance sheets |

[0001564590-16-020754:notes:135]
| (2) | Reported as other non-current assets in the consolidated balance sheets |

[0001564590-16-020754:notes:136]
| (3) | Reported as accrued expenses in the consolidated balance sheets |

[0001564590-16-020754:notes:137]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of April 29, 2016 and April 24, 2015, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-16-020754:notes:138]
Fair Value of Long-Term Debt

[0001564590-16-020754:notes:139]
As of April 29, 2016 and April 24, 2015, the fair value of our long-term debt was approximately $1,519 million and $1,524 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-16-020754:notes:140]
10. Financing Arrangements

[0001564590-16-020754:notes:141]
Long-Term Debt

[0001564590-16-020754:notes:142]
The following table summarizes information relating to our long-term debt (in millions, except interest rates):

[0001564590-16-020754:notes:143]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (4 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (6 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,490 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |

[0001564590-16-020754:notes:144]
Senior Notes

[0001564590-16-020754:notes:145]
In June 2014, we issued $500 million aggregate par value of 3.375% Senior Notes due June 15, 2021, and received proceeds of approximately $495 million, net of discount and issuance costs. Our 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $750 million and $250 million, respectively, were issued in December 2012. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any future senior unsecured indebtedness.

[0001564590-16-020754:notes:146]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of April 29, 2016, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-16-020754:notes:147]
As of April 29, 2016, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-16-020754:notes:148]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| Thereafter |  |  | 750 |  |
| Total |  | $ | 1,500 |  |

[0001564590-16-020754:notes:149]
1.75% Convertible Senior Notes due 2013 settled in June 2013

[0001564590-16-020754:notes:150]
On June 10, 2008, we issued $1,265 million aggregate principal amount of 1.75% Convertible Senior Notes (the Convertible Notes) that matured in June 2013. Upon maturity, the Convertible Notes were converted into shares of common stock at a conversion rate of 31.40 shares of common stock per $1,000 principal amount of the Convertible Notes (which represented the effective conversion price of $31.85 per share). Upon conversion in June 2013, the holders received cash for the principal amount of the Convertible Notes and an aggregate of 5 million shares of common stock for the $179 million excess of the conversion value over the principal amount.

[0001564590-16-020754:notes:151]
We separately accounted for the liability and equity components of the Convertible Notes. The initial debt component of the Convertible Notes was valued at $1,017 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 6.31%, with the equity component representing the residual amount of the proceeds of $248 million which was recorded as a debt discount. Issuance costs were allocated pro-rata based on the relative initial carrying amounts of the debt and equity components. As a result, $5 million of the issuance costs was allocated to the equity component of the Convertible Notes, and $21 million of the issuance costs remained classified as other non-current assets. The debt discount and the issuance costs allocated to the debt component were amortized as additional interest expense over the term of the Convertible Notes using the effective interest method.

[0001564590-16-020754:notes:152]
The interest expense recognized on the Convertible Notes consisted of the following (in millions):

[0001564590-16-020754:notes:153]
|  |  | Year Ended |  |
|  |  | April 25, 2014 |  |
| Contractual coupon interest expense |  | $ | 2 |  |
| Amortization of debt discount |  |  | 7 |  |
| Amortization of debt issuance costs |  |  | 1 |  |
| Total interest expense related to Convertible Notes |  | $ | 10 |  |

[0001564590-16-020754:notes:154]
Concurrent with the issuance of the Convertible Notes, we entered into arrangements to buy up to approximately 32 million shares of our common stock, at a price of $31.85 per share. During fiscal 2014, concurrent with the repayment and conversion of the Convertible Notes, we exercised the Convertible Note hedges which were net settled for an aggregate of 4 million shares from the counterparties. We also entered into separate transactions in which we sold warrants to acquire 40 million shares of our common stock at an exercise price of $41.28 per share. During fiscal 2014, 32 million warrants were exercised at a weighted-average price of $43.09 and were net settled with 1 million shares of our common stock, equal to the difference between the market price on the date of exercise and the exercise price of the warrants on their respective exercise dates, and the remaining warrants expired unexercised.

[0001564590-16-020754:notes:155]
Credit Facility

[0001564590-16-020754:notes:156]
In December 2012, as amended in February 2016, we entered into a credit agreement with a syndicated group of lenders that is scheduled to expire on December 21, 2017 and provides for an unsecured $300 million revolving credit facility that is comprised of revolving loans, Eurocurrency loans and/or swingline loans. The credit facility includes a $100 million foreign currency sub-facility, a $50 million letter of credit sub-facility and a $10 million swingline sub-facility available on same-day notice. Available borrowings under the credit facility are reduced by the amount of any outstanding borrowings on the sub-facilities. We may also, subject to certain requirements, request an increase in the facility up to an additional $50 million and request two additional one-year extensions, subject to certain conditions. The proceeds from the facility may be used by us for general corporate purposes.

[0001564590-16-020754:notes:157]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of April 29, 2016, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-16-020754:notes:158]
Short-Term Loan

[0001564590-16-020754:notes:159]
In connection with the SolidFire acquisition, we entered into a short-term loan of $870 million that matures on November 2, 2016, of which we repaid $20 million in fiscal 2016. We may repay the loan before its maturity without penalty; however, we may not reborrow any borrowings that were repaid under the term loan agreement. As specified in the term loan agreement, interest on the outstanding borrowings accrues at an adjusted LIBOR plus a spread (based on our public debt ratings) or, at our option, a base rate. The interest rate on the loan as of April 29, 2016 was 1.57%. We may, from time to time, elect to convert the outstanding loan from one rate to another. We expect to repay the loan in full on or before the maturity date using funds generated from our global operations. The loan is subject to the same covenants as our credit facility.

[0001564590-16-020754:notes:160]
Sale-leaseback Transactions

[0001564590-16-020754:notes:161]
As discussed in Note 7 – Balance Sheet Details, in fiscal 2016 we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, the assets, which had a net book value of $67 million at the date of the transactions, will remain on our consolidated balance sheets and proceeds received by us from these transactions of $148 million are reported as financing obligations. At the end of each respective leaseback period, or when our continuing involvement under the leaseback agreements ends, each transaction will be reported as a non-cash sale of land and buildings and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain on sale of properties.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-16-020754:notes:162]
11. Stockholders’ Equity

[0001564590-16-020754:notes:163]
Equity Incentive Programs

[0001564590-16-020754:notes:164]
The 1999 Plan — As most recently amended on September 11, 2015, the 1999 Stock Option Plan (the Plan) comprises five separate equity incentive programs: (i) the Discretionary Option Grant Program under which options may be granted to eligible individuals at a fixed price per share; (ii) the Stock Appreciation Rights Program under which eligible persons may be granted stock appreciation rights that allow individuals to receive the appreciation in fair market value of the shares; (iii) the Stock Issuance Program under which eligible individuals may be issued shares of common stock directly; (iv) the Performance Share and Performance Unit Program under which eligible persons may be granted performance shares or performance units which result in payment to the participant only if performance goals or other vesting criteria are achieved and (v) the Automatic Award Program under which nonemployee board members automatically receive equity grants at designated intervals over their period of board service. The Plan expires in August 2019.

[0001564590-16-020754:notes:165]
Under the Plan, the Board of Directors may grant to employees, nonemployee directors, consultants and independent advisors options to purchase shares of our common stock during their period of service. The exercise price for an incentive stock option and a nonstatutory option cannot be less than 100% of the fair market value of the common stock on the grant date. Options granted under the Plan generally vest over a four-year period. Options granted generally have a term of seven years after the grant date, subject to earlier termination upon the occurrence of certain events. The Plan prohibits the repricing of any outstanding stock option or stock appreciation right after it has been granted or to cancel any outstanding stock option or stock appreciation right and immediately replace it with a new stock option or stock appreciation right with a lower exercise price unless approved by stockholders. RSUs granted under the Plan include time-based RSUs that generally vest over a four-year period with 25% vesting on each anniversary of the grant date. The Compensation Committee of the Board of Directors (the Compensation Committee) has the discretion to use different vesting schedules. In addition, performance-based RSUs may be granted under the Plan and are subject to performance criteria and vesting terms specified by the Compensation Committee.

[0001564590-16-020754:notes:166]
Under the Plan, the number of shares reserved for issuance is reduced by two shares for every share subject to a full value award, which are specified to be grants that are in the form of performance shares and/or performance unit awards, stock, restricted stock or restricted stock units. The Plan (i) limits the number of shares that may be granted pursuant to awards under the Stock Issuance Program to a participant in any calendar year to 1 million, (ii) limits the initial value of performance units a participant may receive to not more than $5 million and (iii) limits the number of performance shares a participant may receive in a calendar year to 1 million.

[0001564590-16-020754:notes:167]
During fiscal 2016, the shares reserved for issuance under the Plan were increased by approximately 16 million shares. As of April 29, 2016, 23 million shares were available for grant under the Plan.

[0001564590-16-020754:notes:168]
Stock Options

[0001564590-16-020754:notes:169]
The following table summarizes activity related to our stock options (in millions, except for exercise price and contractual term):

[0001564590-16-020754:notes:170]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding at April 26, 2013 |  |  | 19 |  |  | $ | 31.27 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 3 |  |  | $ | 38.26 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (6 | ) |  | $ | 25.83 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (1 | ) |  | $ | 42.47 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 25, 2014 |  |  | 15 |  |  | $ | 34.10 |  |  |  |  |  |  |  |  |  |
| Granted |  |  | 2 |  |  | $ | 36.64 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (5 | ) |  | $ | 25.25 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | — |  |  | $ | 42.42 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 24, 2015 |  |  | 12 |  |  | $ | 37.74 |  |  |  |  |  |  |  |  |  |
| Assumed in acquisition |  |  | 2 |  |  | $ | 5.20 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (2 | ) |  | $ | 19.64 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (3 | ) |  | $ | 38.27 |  |  |  |  |  |  |  |  |  |
| Outstanding as of April 29, 2016 |  |  | 9 |  |  | $ | 34.01 |  |  |  | 3.52 |  |  | $ | 29 |  |
| Vested and expected to vest as of April 29, 2016 |  |  | 9 |  |  | $ | 34.52 |  |  |  | 3.40 |  |  | $ | 26 |  |
| Exercisable as of April 29, 2016 |  |  | 6 |  |  | $ | 39.98 |  |  |  | 2.22 |  |  | $ | 3 |  |

[0001564590-16-020754:notes:171]
The aggregate intrinsic value represents the pre-tax difference between the exercise price of stock options and the quoted market price of our stock on that day for all in-the-money options.

[0001564590-16-020754:notes:172]
Additional information related to our stock options is summarized below (in millions):

[0001564590-16-020754:notes:173]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Intrinsic value of exercises |  | $ | 16 |  |  | $ | 70 |  |  | $ | 91 |  |
| Proceeds received from exercises |  | $ | 27 |  |  | $ | 117 |  |  | $ | 164 |  |
| Fair value of options vested |  | $ | 15 |  |  | $ | 33 |  |  | $ | 45 |  |

[0001564590-16-020754:notes:174]
Restricted Stock Units

[0001564590-16-020754:notes:175]
In fiscal 2016, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service based vesting criteria) such that the PBRSU cliff-vests at the end of either an approximate two year or three year performance period, which began on the date specified in the grant agreement and ends the last day of fiscal 2017 or 2018, respectively. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted, and will depend upon our Total Stockholder Return (TSR) as compared to an index TSR (each expressed as a growth rate percentage) calculated as of the applicable period end date. The fair values of the PBRSUs were fixed at grant date and the related aggregate compensation cost of $20 million is being recognized, adjusted for forfeitures, over the shorter of the remaining applicable performance or service periods. As of April 29, 2016, there were approximately 500 thousand PBRSUs outstanding.

[0001564590-16-020754:notes:176]
In fiscal 2016, 5 million time-based RSUs granted will vest at 50% annually over two years. All other time-based RSUs will vest over four years.

[0001564590-16-020754:notes:177]
The following table summarizes activity related to RSUs, including PBRSUs, (in millions, except for fair value):

[0001564590-16-020754:notes:178]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding at April 26, 2013 |  |  | 13 |  |  | $ | 38.36 |  |
| Granted |  |  | 6 |  |  | $ | 38.61 |  |
| Vested |  |  | (4 | ) |  | $ | 38.48 |  |
| Forfeited |  |  | (2 | ) |  | $ | 39.08 |  |
| Outstanding as of April 25, 2014 |  |  | 13 |  |  | $ | 38.35 |  |
| Granted |  |  | 7 |  |  | $ | 35.80 |  |
| Vested |  |  | (5 | ) |  | $ | 40.14 |  |
| Forfeited |  |  | (2 | ) |  | $ | 37.48 |  |
| Outstanding as of April 24, 2015 |  |  | 13 |  |  | $ | 36.58 |  |
| Granted |  |  | 7 |  |  | $ | 29.26 |  |
| Vested |  |  | (5 | ) |  | $ | 37.72 |  |
| Forfeited |  |  | (2 | ) |  | $ | 34.85 |  |
| Outstanding as of April 29, 2016 |  |  | 13 |  |  | $ | 32.46 |  |

[0001564590-16-020754:notes:179]
We primarily use the net share settlement approach upon vesting, where a portion of the shares are withheld as settlement of statutory employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001564590-16-020754:notes:180]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Shares withheld for taxes |  |  | 2 |  |  |  | 2 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 50 |  |  | $ | 57 |  |  | $ | 58 |  |

[0001564590-16-020754:notes:181]
Employee Stock Purchase Plan

[0001564590-16-020754:notes:182]
Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. On September 11, 2015, the ESPP was amended to increase the shares reserved for issuance by 5 million shares of common stock. As of April 29, 2016, 11 million shares were available for issuance. The following table summarizes activity related to the purchase rights issued under the ESPP (in millions):

[0001564590-16-020754:notes:183]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Shares issued under the ESPP |  |  | 3 |  |  |  | 3 |  |  |  | 4 |  |
| Proceeds from issuance of shares |  | $ | 93 |  |  | $ | 97 |  |  | $ | 95 |  |

[0001564590-16-020754:notes:184]
Stock-Based Compensation Expense

[0001564590-16-020754:notes:185]
Stock-based compensation expense is included in the consolidated statements of operations as follows (in millions):

[0001564590-16-020754:notes:186]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Cost of product revenues |  | $ | 5 |  |  | $ | 6 |  |  | $ | 5 |  |
| Cost of hardware maintenance and other services revenues |  |  | 19 |  |  |  | 16 |  |  |  | 17 |  |
| Sales and marketing |  |  | 110 |  |  |  | 116 |  |  |  | 125 |  |
| Research and development |  |  | 84 |  |  |  | 84 |  |  |  | 88 |  |
| General and administrative |  |  | 42 |  |  |  | 37 |  |  |  | 38 |  |
| Total stock-based compensation expense |  | $ | 260 |  |  | $ | 259 |  |  | $ | 273 |  |

[0001564590-16-020754:notes:187]
As of April 29, 2016, total unrecognized compensation expense related to our equity awards was $310 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 1.8 years.

[0001564590-16-020754:notes:188]
Total income tax benefit associated with employee stock transactions and recognized in stockholders’ equity were as follows (in millions):

[0001564590-16-020754:notes:189]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Income tax benefit associated with employee stock transactions |  | $ | 59 |  |  | $ | 57 |  |  | $ | 40 |  |

[0001564590-16-020754:notes:190]
Valuation Assumptions

[0001564590-16-020754:notes:191]
The valuation of stock options, RSUs and ESPP purchase rights and the underlying weighted-average assumptions are summarized as follows:

[0001564590-16-020754:notes:192]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Stock options: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected term in years |  | N/A |  |  |  | 4.8 |  |  |  | 4.8 |  |
| Risk-free interest rate |  | N/A |  |  |  | 1.6 | % |  |  | 1.1 | % |
| Expected volatility |  | N/A |  |  |  | 29 | % |  |  | 34 | % |
| Expected dividend yield |  | N/A |  |  |  | 1.8 | % |  |  | 1.6 | % |
| Weighted-average fair value per share granted |  | N/A |  |  | $ | 8.24 |  |  | $ | 9.85 |  |
| RSUs: |  |  |  |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 0.6 | % |  |  | 0.6 | % |  |  | 0.5 | % |
| Expected dividend yield |  |  | 2.3 | % |  |  | 1.8 | % |  |  | 1.6 | % |
| Weighted-average fair value per share granted |  | $ | 29.26 |  |  | $ | 35.80 |  |  | $ | 38.61 |  |
| ESPP: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.3 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 0.5 | % |  |  | 0.2 | % |  |  | 0.2 | % |
| Expected volatility |  |  | 27 | % |  |  | 27 | % |  |  | 31 | % |
| Expected dividend yield |  |  | 2.3 | % |  |  | 1.8 | % |  |  | 1.6 | % |
| Weighted-average fair value per right granted |  | $ | 8.18 |  |  | $ | 9.81 |  |  | $ | 10.83 |  |

[0001564590-16-020754:notes:193]
N/A - Not applicable. No options were granted in fiscal 2016.

[0001564590-16-020754:notes:194]
In connection with our acquisition of SolidFire, we assumed all of the then outstanding unvested options to purchase SolidFire common stock and converted those into unvested options to purchase 2 million shares of our common stock. The weighted average assumptions used to value these options, as of the acquisition date, were an expected term of 4.3 years, risk-free interest rate of 1.1%, expected volatility of 31% and expected dividend yield of 3.3%. The weighted average fair value per share of these options was $14.32.

[0001564590-16-020754:notes:195]
Stock Repurchase Program

[0001564590-16-020754:notes:196]
As of April 29, 2016, our Board of Directors has authorized the repurchase of up to $9.6 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management.

[0001564590-16-020754:notes:197]
The following table summarizes activity related to this program (in millions, except per share amounts):

[0001564590-16-020754:notes:198]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Number of shares repurchased |  |  | 33 |  |  |  | 30 |  |  |  | 47 |  |
| Average price per share |  | $ | 28.80 |  |  | $ | 39.30 |  |  | $ | 39.78 |  |
| Aggregate purchase price |  | $ | 960 |  |  | $ | 1,165 |  |  | $ | 1,881 |  |
| Remaining authorization at end of period |  | $ | 1,499 |  |  | $ | 2,460 |  |  | $ | 1,125 |  |

[0001564590-16-020754:notes:199]
The aggregate purchase price of our stock repurchases for fiscal 2016 consisted of $960 million of open market purchases, of which, $763 million and $197 million was allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-16-020754:notes:200]
Since the May 13, 2003 inception of our stock repurchase program through April 29, 2016, we repurchased a total of 247 million shares of our common stock at an average price of $32.85 per share, for an aggregate purchase price of $8.1 billion.

[0001564590-16-020754:notes:201]
Accelerated Share Repurchase Agreement

[0001564590-16-020754:notes:202]
In fiscal 2014, we entered into a collared Accelerated Share Repurchase (ASR) with a third party under which we prepaid $750 million to purchase shares of our common stock. The aggregate number of shares ultimately purchased was determined based on the volume weighted-average share price of our common stock over a specified period of time. This contract settled in fiscal 2014, resulting in the repurchase of 19 million shares, at an average price per share of $39.13. The value of the ASR forward contract was determined to be $14 million, which was recorded as additional paid-in capital.

[0001564590-16-020754:notes:203]
Preferred Stock

[0001564590-16-020754:notes:204]
Our Board of Directors has the authority to issue up to 5 million shares of preferred stock and to determine the price, rights, preferences, privileges, and restrictions, including voting rights, of those shares without any further vote or action by the stockholders. No shares of preferred stock were issued or outstanding in any period presented.

[0001564590-16-020754:notes:205]
Dividends

[0001564590-16-020754:notes:206]
The following is a summary of our fiscal 2016, 2015 and 2014 activities related to dividends on our common stock (in millions, except per share amounts).

[0001564590-16-020754:notes:207]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Dividends per share declared |  | $ | 0.72 |  |  | $ | 0.66 |  |  | $ | 0.60 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 125 |  |  | $ | 52 |  |  | $ | 50 |  |
| Dividend payments allocated to retained earnings |  | $ | 85 |  |  | $ | 156 |  |  | $ | 152 |  |

[0001564590-16-020754:notes:208]
On May 25, 2016, we declared a cash dividend of $0.19 per share of common stock, payable on July 27, 2016 to holders of record as of the close of business on July 18, 2016. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by the Company to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-16-020754:notes:209]
Accumulated Other Comprehensive Income (Loss)

[0001564590-16-020754:notes:210]
Changes in AOCI by component, net of tax, are summarized below (in millions):

[0001564590-16-020754:notes:211]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 25, 2014 |  | $ | 5 |  |  | $ | (5 | ) |  | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |
| OCI before reclassifications, net of tax |  |  | (28 | ) |  |  | (8 | ) |  |  | 2 |  |  |  | 15 |  |  |  | (19 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (14 | ) |  |  | (14 | ) |
| Total OCI |  |  | (28 | ) |  |  | (8 | ) |  |  | 2 |  |  |  | 1 |  |  |  | (33 | ) |
| Balance as of April 24, 2015 |  |  | (23 | ) |  |  | (13 | ) |  |  | 11 |  |  |  | 1 |  |  |  | (24 | ) |
| OCI before reclassifications, net of tax |  |  | 4 |  |  |  | (5 | ) |  |  | (4 | ) |  |  | (4 | ) |  |  | (9 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | 2 |  |  |  | (1 | ) |  |  | 1 |  |  |  | 2 |  |
| Total OCI |  |  | 4 |  |  |  | (3 | ) |  |  | (5 | ) |  |  | (3 | ) |  |  | (7 | ) |
| Balance as of April 29, 2016 |  | $ | (19 | ) |  | $ | (16 | ) |  | $ | 6 |  |  | $ | (2 | ) |  | $ | (31 | ) |

[0001564590-16-020754:notes:212]
The amounts reclassified out of AOCI are as follows (in millions):

[0001564590-16-020754:notes:213]
|  |  | Year Ended |  |  |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |
| Recognized losses on defined benefit obligations |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |  | Operating expenses |
| Realized gains on available-for-sale securities |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  | Other income (expense), net |
| Realized (gains) losses on cash flow hedges |  |  | 1 |  |  |  | (14 | ) |  |  | 2 |  |  | Net revenues |
| Total reclassifications |  | $ | 2 |  |  | $ | (14 | ) |  | $ | 1 |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-16-020754:notes:214]
12. Derivatives and Hedging Activities

[0001564590-16-020754:notes:215]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of April 29, 2016 or April 24, 2015. We did not recognize any gains and losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-16-020754:notes:216]
Over the next 12 months, we expect an immaterial amount of derivative net gains or losses recorded in AOCI as of April 29, 2016 will be reclassified into net revenues. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is six months.

[0001564590-16-020754:notes:217]
The notional amount of our outstanding U.S. dollar equivalent foreign currency exchange forward contracts consisted of the following (in millions):

[0001564590-16-020754:notes:218]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 99 |  |  | $ | 94 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 160 |  |  | $ | 160 |  |
| Forward contracts purchased |  | $ | 396 |  |  | $ | 231 |  |

[0001564590-16-020754:notes:219]
The effect of derivative instruments designated as cash flow hedges recognized in net revenues on our consolidated statements of operations is presented in the consolidated statements of comprehensive income (loss) and Note 11 – Stockholders’ Equity.

[0001564590-16-020754:notes:220]
The effect of derivative instruments not designated as hedging instruments recognized in other income (expense), net on our consolidated statements of operations was as follows (in millions):

[0001564590-16-020754:notes:221]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
|  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | (4 | ) |  | $ | 14 |  |  | $ | 1 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-16-020754:notes:222]
13. Restructuring and Other Charges

[0001564590-16-020754:notes:223]
Beginning in the first quarter of fiscal 2014, management approved several restructuring actions to streamline our business, eliminate costs and redirect resources to our highest return activities. These actions included the May 2013 Plan, the March 2014 Plan, the May 2015 Plan and the March 2016 Plan, under which we reduced our global workforce by approximately 7%, 4%, 3%, and 11%, respectively. We have completed all of these activities, with the exception of the March 2016 Plan, which we expect to complete by the second quarter of fiscal 2017 with no significant additional charges. Restructuring and other charges related to these plans consisted primarily of employee severance-related costs.

[0001564590-16-020754:notes:224]
Activities related to these plans are summarized as follows (in millions):

[0001564590-16-020754:notes:225]
|  |  | March 2016 Plan |  |  | May 2015 Plan |  |  | March 2014 Plan |  |  | May 2013 Plan |  |  | Total |  |
| Balance as of April 26, 2013 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net charges |  |  | — |  |  |  | — |  |  |  | 39 |  |  |  | 49 |  |  |  | 88 |  |
| Cash payments |  |  | — |  |  |  | — |  |  |  | (12 | ) |  |  | (49 | ) |  |  | (61 | ) |
| Balance as of April 25, 2014 |  |  | — |  |  |  | — |  |  |  | 27 |  |  |  | — |  |  |  | 27 |  |
| Net charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Cash payments |  |  | — |  |  |  | — |  |  |  | (27 | ) |  |  | — |  |  |  | (27 | ) |
| Balance as of April 24, 2015 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net charges |  |  | 80 |  |  |  | 28 |  |  |  | — |  |  |  | — |  |  |  | 108 |  |
| Cash payments |  |  | (35 | ) |  |  | (28 | ) |  |  | — |  |  |  | — |  |  |  | (63 | ) |
| Balance as of April 29, 2016 |  | $ | 45 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 45 |  |

[0001564590-16-020754:notes:226]
Liabilities for our restructuring activities are included in accrued expenses in our consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-16-020754:notes:227]
14. Income Taxes

[0001564590-16-020754:notes:228]
Income before income taxes is as follows (in millions):

[0001564590-16-020754:notes:229]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Domestic |  | $ | 88 |  |  | $ | 253 |  |  | $ | 121 |  |
| Foreign |  |  | 257 |  |  |  | 460 |  |  |  | 620 |  |
| Total |  | $ | 345 |  |  | $ | 713 |  |  | $ | 741 |  |

[0001564590-16-020754:notes:230]
Domestic income before taxes is lower than foreign income before taxes due to significant domestic expenses related to the amortization of intangibles, stock-based compensation and restructuring expenses.

[0001564590-16-020754:notes:231]
The provision for income taxes consists of the following (in millions):

[0001564590-16-020754:notes:232]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 180 |  |  | $ | 104 |  |  | $ | 124 |  |
| State |  |  | 14 |  |  |  | 12 |  |  |  | 14 |  |
| Foreign |  |  | 35 |  |  |  | 40 |  |  |  | 41 |  |
| Total current |  |  | 229 |  |  |  | 156 |  |  |  | 179 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (91 | ) |  |  | 8 |  |  |  | (65 | ) |
| State |  |  | (17 | ) |  |  | (3 | ) |  |  | (6 | ) |
| Foreign |  |  | (5 | ) |  |  | (8 | ) |  |  | (5 | ) |
| Total deferred |  |  | (113 | ) |  |  | (3 | ) |  |  | (76 | ) |
| Provision for income taxes |  | $ | 116 |  |  | $ | 153 |  |  | $ | 103 |  |

[0001564590-16-020754:notes:233]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0001564590-16-020754:notes:234]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Tax computed at federal statutory rate |  | $ | 121 |  |  | $ | 250 |  |  | $ | 259 |  |
| State income taxes, net of federal benefit |  |  | (3 | ) |  |  | 5 |  |  |  | 6 |  |
| Foreign earnings in lower tax jurisdictions |  |  | (81 | ) |  |  | (141 | ) |  |  | (163 | ) |
| Stock-based compensation |  |  | 13 |  |  |  | 6 |  |  |  | 10 |  |
| Research and development credits |  |  | (14 | ) |  |  | (14 | ) |  |  | (9 | ) |
| Resolution of income tax examinations |  |  | 20 |  |  |  | 46 |  |  |  | — |  |
| Domestic production activities deduction |  |  | (10 | ) |  |  | (5 | ) |  |  | (6 | ) |
| Tax charge from integration of intellectual property from the SolidFire acquisition |  |  | 64 |  |  |  | — |  |  |  | — |  |
| Other |  |  | 6 |  |  |  | 6 |  |  |  | 6 |  |
| Provision for income taxes |  | $ | 116 |  |  | $ | 153 |  |  | $ | 103 |  |

[0001564590-16-020754:notes:235]
We generated foreign earnings in lower tax jurisdictions primarily related to income from our European operations which are headquartered in the Netherlands. During fiscal 2016, we acquired SolidFire and recorded a tax charge of $64 million related to the integration of SolidFire intellectual property into our worldwide operations.

[0001564590-16-020754:notes:236]
The components of our deferred tax assets and liabilities are as follows (in millions):

[0001564590-16-020754:notes:237]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Reserves and accruals |  | $ | 214 |  |  | $ | 94 |  |
| Acquired intangibles |  |  | — |  |  |  | 44 |  |
| Net operating loss and credit carryforwards |  |  | 72 |  |  |  | 80 |  |
| Stock-based compensation |  |  | 66 |  |  |  | 70 |  |
| Deferred revenue |  |  | 336 |  |  |  | 298 |  |
| Other |  |  | 39 |  |  |  | 27 |  |
| Gross deferred tax assets |  |  | 727 |  |  |  | 613 |  |
| Valuation allowance |  |  | (59 | ) |  |  | (58 | ) |
| Deferred tax assets, net of valuation allowance |  |  | 668 |  |  |  | 555 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Prepaids and accruals |  |  | 3 |  |  |  | 4 |  |
| Acquired intangibles |  |  | 27 |  |  |  | 14 |  |
| Property and equipment |  |  | 14 |  |  |  | 26 |  |
| Other |  |  | 3 |  |  |  | 3 |  |
| Total deferred tax liabilities |  |  | 47 |  |  |  | 47 |  |
| Deferred tax assets, net of valuation allowance and deferred tax liabilities |  | $ | 621 |  |  | $ | 508 |  |

[0001564590-16-020754:notes:238]
Net deferred tax assets consist of the following (in millions):

[0001564590-16-020754:notes:239]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Current deferred tax assets, net |  | $ | — |  |  | $ | 252 |  |
| Non-current deferred tax assets, net |  | $ | 621 |  |  | $ | 256 |  |

[0001564590-16-020754:notes:240]
In the third quarter of fiscal 2016, we adopted new accounting guidance on the balance sheet classification of deferred taxes that requires that all deferred taxes be presented as non-current. We applied this guidance prospectively and, accordingly, we did not reclassify amounts reported as of April 24, 2015.

[0001564590-16-020754:notes:241]
The valuation allowance increased by $1 million and $8 million in fiscal 2016 and 2015, respectively. The increases are mainly attributable to corresponding changes in deferred tax assets, primarily foreign tax credit carryforwards in a foreign jurisdiction and state tax credit carryforwards in certain states.

[0001564590-16-020754:notes:242]
As of April 29, 2016, the federal and state net operating loss carryforwards were approximately $15 million and $31 million, respectively, before applying tax rates for the respective jurisdictions. The federal, state and foreign tax credit carryforwards were approximately $40 million, $131 million and $22 million, respectively. Certain acquired net operating loss and credit carryforwards are subject to an annual limitation under Internal Revenue Code Section 382, but are expected to be realized with the exception of those which have a valuation allowance. The federal and state net operating loss carryforwards and credits will expire in various years from fiscal 2018 through 2036. If realized, $41 million, tax effected, of net operating loss and tax credit carryovers will be recognized as additional paid-in capital. The foreign tax credit carryforward does not expire.

[0001564590-16-020754:notes:243]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001564590-16-020754:notes:244]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Balance at beginning of period |  | $ | 272 |  |  | $ | 236 |  |  | $ | 190 |  |
| Additions based on tax positions related to the current year |  |  | 14 |  |  |  | 22 |  |  |  | 27 |  |
| Additions for tax positions of prior years |  |  | 21 |  |  |  | 101 |  |  |  | 24 |  |
| Decreases for tax positions of prior years |  |  | (39 | ) |  |  | (29 | ) |  |  | (5 | ) |
| Settlements |  |  | (52 | ) |  |  | (58 | ) |  |  | — |  |
| Balance at end of period |  | $ | 216 |  |  | $ | 272 |  |  | $ | 236 |  |

[0001564590-16-020754:notes:245]
As of April 29, 2016, we had $216 million of gross unrecognized tax benefits, of which $164 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $147 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-16-020754:notes:246]
We recognize accrued interest and penalties related to unrecognized tax benefits in the income tax provision. During fiscal 2016, 2015 and 2014, we recognized accrued interest and penalties of approximately $2 million, $4 million and $2 million, respectively in the consolidated statements of operations and $11 million and $9 million, respectively, were recorded in the consolidated balance sheets as of April 29, 2016 and April 24, 2015.

[0001564590-16-020754:notes:247]
The tax years that remain subject to examination for our major tax jurisdictions are shown below:

[0001564590-16-020754:notes:248]
Fiscal Years Subject to Examination for Major Tax Jurisdictions at April 29, 2016

[0001564590-16-020754:notes:249]
| 2012 — 2016 |  | United States — federal income tax |
| 2008 — 2016 |  | United States — state and local income tax |
| 2012 — 2016 |  | Australia |
| 2013 — 2016 |  | Germany |
| 2007 — 2016 |  | India |
| 2010 — 2016 |  | Japan |
| 2012 — 2016 |  | The Netherlands |
| 2013 — 2016 |  | United Kingdom |
| 2008 — 2016 |  | Canada |

[0001564590-16-020754:notes:250]
In addition, we are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal 2001, in that we have carryforward attributes from these years that could be subject to adjustment in the tax years of utilization.

[0001564590-16-020754:notes:251]
In June 2015, the Internal Revenue Service (IRS) signed a closing agreement with respect to transfer pricing arrangements and, in October 2015, completed the examination of our fiscal 2008 to 2010 income tax returns. During fiscal 2016, we recorded a tax charge of $23 million attributable to transfer pricing and other audit settlements and the related re-measurement of uncertain tax positions for tax years subject to future audits. During fiscal 2016, the German tax authority concluded the examination of our fiscal 2009 to 2012 returns. We recorded a $2 million tax benefit for the net impact of the audit adjustments and related release of unrecognized tax benefits.

[0001564590-16-020754:notes:252]
In July 2014, the IRS completed the examination of our fiscal 2005 to 2007 income tax returns upon approval by the Joint Committee of Taxation. During fiscal 2015, we recorded a tax charge of $47 million attributable to the audit settlement and related re-measurements of uncertain tax positions for tax years subject to future audits.

[0001564590-16-020754:notes:253]
We are currently undergoing federal income tax audits in the United States (U.S.) and several foreign tax jurisdictions. Transfer pricing calculations are key issues under audits in various jurisdictions, and are often subject to dispute and appeals. The IRS has concluded the examination of our tax returns for our fiscal years through 2010. The IRS plans to commence the audit of our fiscal 2012 and 2013 returns in fiscal 2017.

[0001564590-16-020754:notes:254]
On September 17, 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 from our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. On December 19, 2011, the Danish Tax Tribunal issued a ruling that our Danish subsidiary was not liable for Danish withholding tax. The Danish tax examination agency appealed to the Danish High Court in March 2012. In February 2016, the Danish High Court referred the case to the European Court of Justice.

[0001564590-16-020754:notes:255]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. Based on current information, we do not expect significant changes to our existing unrecognized tax benefits as of April 29, 2016.

[0001564590-16-020754:notes:256]
As of April 29, 2016, the amount of accumulated unremitted earnings from our foreign subsidiaries is approximately $4 billion. We have not provided U.S. income taxes and foreign withholding taxes on the undistributed earnings of foreign subsidiaries because we intend to permanently reinvest such earnings outside the U.S. If these foreign earnings were to be repatriated in the future, the related U.S. tax liability may be reduced by any foreign income taxes previously paid on these earnings as well as tax attribute carryforwards. We estimate the unrecognized deferred tax liability related to these earnings to be approximately $1 billion as of April 29, 2016.

[0001564590-16-020754:notes:257]
On July 27, 2015, in Altera Corp. v. Commissioner, the U.S. Tax Court issued an opinion related to the treatment of stock-based compensation expense in an intercompany cost-sharing arrangement. A final decision was issued by the Tax Court in December 2015. In February 2016, the Commissioner appealed the Tax Court decision. At this time, the U.S. Department of the Treasury has not withdrawn the requirement to include stock-based compensation from its regulations. Due to the uncertainty surrounding the status of the current regulations, questions related to the scope of potential benefits, and the risk of the Tax Court’s decision being overturned upon appeal, we have not recorded any benefit as of April 29, 2016. We will continue to monitor ongoing developments and potential impacts to our financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001564590-16-020754:notes:258]
15. Net Income per Share

[0001564590-16-020754:notes:259]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0001564590-16-020754:notes:260]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 229 |  |  | $ | 560 |  |  | $ | 638 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 294 |  |  |  | 316 |  |  |  | 340 |  |
| Dilutive impact of employee equity award plans |  |  | 3 |  |  |  | 5 |  |  |  | 7 |  |
| Dilutive impact of assumed conversion of convertible notes |  |  | — |  |  |  | — |  |  |  | 1 |  |
| Shares used in diluted computation |  |  | 297 |  |  |  | 321 |  |  |  | 348 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.78 |  |  | $ | 1.77 |  |  | $ | 1.87 |  |
| Diluted |  | $ | 0.77 |  |  | $ | 1.75 |  |  | $ | 1.83 |  |

[0001564590-16-020754:notes:261]
We have excluded 12 million, 8 million and 6 million weighted-average shares of common stock potentially issuable under employee equity award plans in fiscal 2016, 2015 and 2014, respectively, from the diluted net income per share calculations as their effect would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-16-020754:notes:262]
16. Segment, Geographic, and Significant Customer Information

[0001564590-16-020754:notes:263]
We operate in one industry segment: the design, manufacturing, marketing, and technical support of high-performance storage and data management solutions. We conduct business globally, and our sales and support activities are managed on a geographic basis. Our management reviews financial information presented on a consolidated basis, accompanied by disaggregated information it receives from our internal management system about revenues by geographic region, based on the location from which the customer relationship is managed, for purposes of allocating resources and evaluating financial performance. We do not allocate costs of revenues, research and development, sales and marketing, or general and administrative expenses to our geographic regions in this internal management reporting because management does not review operations or operating results, or make planning decisions, below the consolidated entity level.

[0001564590-16-020754:notes:264]
Summarized revenues by geographic region based on information from our internal management system and utilized by our Chief Executive Officer, who is considered our Chief Operating Decision Maker, is as follows (in millions):

[0001564590-16-020754:notes:265]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| United States, Canada and Latin America (Americas) |  | $ | 3,067 |  |  | $ | 3,447 |  |  | $ | 3,513 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 1,757 |  |  |  | 1,857 |  |  |  | 1,955 |  |
| Asia Pacific (APAC) |  |  | 722 |  |  |  | 819 |  |  |  | 857 |  |
| Net revenues |  | $ | 5,546 |  |  | $ | 6,123 |  |  | $ | 6,325 |  |

[0001564590-16-020754:notes:266]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $2,753 million, $3,096 million and $3,131 million during fiscal 2016, 2015 and 2014, respectively.

[0001564590-16-020754:notes:267]
The majority of our assets, excluding cash, cash equivalents, short-term investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents and short-term investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0001564590-16-020754:notes:268]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| U.S. |  | $ | 513 |  |  | $ | 596 |  |
| International |  |  | 4,790 |  |  |  | 4,730 |  |
| Total |  | $ | 5,303 |  |  | $ | 5,326 |  |

[0001564590-16-020754:notes:269]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment information for geographic areas based on the physical location of the assets (in millions):

[0001564590-16-020754:notes:270]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| U.S. |  | $ | 797 |  |  | $ | 927 |  |
| International |  |  | 140 |  |  |  | 103 |  |
| Total |  | $ | 937 |  |  | $ | 1,030 |  |

[0001564590-16-020754:notes:271]
The following customers, each of which is a distributor, accounted for 10% or more of our net revenues:

[0001564590-16-020754:notes:272]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 23 | % |  |  | 22 | % |
| Avnet, Inc. |  |  | 19 | % |  |  | 16 | % |  |  | 16 | % |

[0001564590-16-020754:notes:273]
The following customers accounted for 10% or more of accounts receivable:

[0001564590-16-020754:notes:274]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Arrow Electronics, Inc. |  |  | 12 | % |  |  | 14 | % |
| Avnet, Inc. |  |  | 15 | % |  |  | 16 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-16-020754:notes:275]
17. Employee Benefits and Deferred Compensation

[0001564590-16-020754:notes:276]
Employee 401(k) Plan

[0001564590-16-020754:notes:277]
Our 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit. We match 100% of the first 2% of eligible earnings an employee contributes to the 401(k) Plan, and then match 50% of the next 4% of eligible earnings an employee contributes. An employee receives the full 4% match when he/she contributes at least 6% of his/her eligible earnings, up to a maximum calendar year matching contribution of $6,000. Our employer matching contributions to the 401(k) Plan were as follows (in millions):

[0001564590-16-020754:notes:278]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| 401(k) matching contributions |  | $ | 35 |  |  | $ | 16 |  |  | $ | 20 |  |

[0001564590-16-020754:notes:279]
Deferred Compensation Plan

[0001564590-16-020754:notes:280]
We have a non-qualified deferred compensation plan that allows a group of employees within the U.S. to contribute base salary and commissions or incentive compensation on a tax deferred basis in excess of the IRS limits imposed on 401(k) plans. The marketable securities related to these investments are held in a Rabbi Trust. The related deferred compensation plan assets and liabilities under the non-qualified deferred compensation plan were as follows (in millions):

[0001564590-16-020754:notes:281]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Deferred compensation plan assets |  | $ | 30 |  |  | $ | 32 |  |
| Deferred compensation liabilities reported as: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 5 |  |  | $ | 3 |  |
| Other long-term liabilities |  | $ | 25 |  |  | $ | 29 |  |

[0001564590-16-020754:notes:282]
Postretirement Health Care Plan

[0001564590-16-020754:notes:283]
Certain of our executive officers are eligible to participate in our Executive Retirement Medical Plan, which upon retirement provides medical coverage beyond the COBRA maximum benefit period to a defined group of senior executives based on minimum age, service and level of responsibility (that is, Executive Vice President or above) as a fully-insured plan. Coverage continues through the duration of the lifetime of the retiree or the retiree’s spouse, whichever is longer. In fiscal 2016, the Compensation Committee closed this plan to the executives eligible for participation as of November 12, 2015. Participation in the plan will not be offered to executives who were not eligible for the plan on that date. There is no funding requirement associated with the plan and none of the benefit obligation was funded as of April 29, 2016. Assumed health care cost trend rates have a significant effect on the amounts reported for the health care plan.

[0001564590-16-020754:notes:284]
International Defined Benefit Plans

[0001564590-16-020754:notes:285]
We maintain various defined benefit plans to provide termination and postretirement benefits to certain eligible employees outside of the U.S. We also provide disability benefits to certain eligible employees in the U.S. Eligibility is determined based on the terms of our plans and local statutory requirements. Assumed discount rates and expected long-term returns on plan assets have significant effects on the amounts reported for the defined benefit plans.

[0001564590-16-020754:notes:286]
Funded Status

[0001564590-16-020754:notes:287]
The funded status of our postretirement health care and international termination and postretirement benefits was as follows (in millions):

[0001564590-16-020754:notes:288]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Fair value of plan assets |  | $ | 24 |  |  | $ | 20 |  |
| Benefit obligations |  |  | (76 | ) |  |  | (60 | ) |
| Unfunded obligations |  | $ | (52 | ) |  | $ | (40 | ) |

[0001564590-16-020754:notes:289]
Amounts recognized in the consolidated balance sheets were as follows (in millions):

[0001564590-16-020754:notes:290]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Other long-term liabilities |  | $ | 52 |  |  | $ | 40 |  |
| AOCI |  | $ | (16 | ) |  | $ | (13 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-16-020754:notes:291]
18. Commitments and Contingencies

[0001564590-16-020754:notes:292]
Operating Leases

[0001564590-16-020754:notes:293]
We lease various equipment, vehicles and office space in the U.S. and internationally.

[0001564590-16-020754:notes:294]
Future annual minimum lease payments under all non-cancelable operating leases with an initial term in excess of one year as of April 29, 2016 are as follows (in millions):

[0001564590-16-020754:notes:295]
|  |  |  | 2017 |  |  |  | 2018 |  |  |  | 2019 |  |  |  | 2020 |  |  |  | 2021 |  |  | Thereafter |  |  | Total |  |
| Operating lease commitments |  | $ | 60 |  |  | $ | 50 |  |  | $ | 39 |  |  | $ | 31 |  |  | $ | 23 |  |  | $ | 50 |  |  | $ | 253 |  |

[0001564590-16-020754:notes:296]
Rent expense under all cancellable and non-cancelable operating leases was $69 million, $67 million and $66 million in fiscal 2016, 2015 and 2014, respectively.

[0001564590-16-020754:notes:297]
Purchase Orders and Other Commitments

[0001564590-16-020754:notes:298]
In the ordinary course of business, we make commitments to third-party contract manufacturers, to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of April 29, 2016, we had $211 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts. As of April 29, 2016 and April 24, 2015, such liability amounted to $7 million and $17 million, respectively, and is included in accrued expenses in our consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-16-020754:notes:299]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of April 29, 2016, we had $37 million in construction related obligations and $152 million in other purchase obligations.

[0001564590-16-020754:notes:300]
During the ordinary course of business, we provide standby letters of credit or other guarantee instruments to third parties as required for certain transactions initiated either by us or our subsidiaries. As of April 29, 2016, our financial guarantees of $14 million that were not recorded on our consolidated balance sheets consisted primarily of standby letters of credit and surety bonds.

[0001564590-16-020754:notes:301]
Financing Guarantees

[0001564590-16-020754:notes:302]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $243 million, $197 million and $296 million of receivables during fiscal 2016, 2015 and 2014, respectively.

[0001564590-16-020754:notes:303]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-16-020754:notes:304]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of April 29, 2016 and April 24, 2015, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001564590-16-020754:notes:305]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of April 29, 2016, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0001564590-16-020754:notes:306]
Indemnification Agreements

[0001564590-16-020754:notes:307]
We enter into standard indemnification agreements in the ordinary course of business. Pursuant to these agreements, we agree to defend and indemnify other parties, primarily our customers or business partners or subcontractors, for damages and reasonable costs incurred in any suit or claim brought against them alleging that our products sold to them infringe any U.S. patent, copyright, trade secret, or similar right. If a product becomes the subject of an infringement claim, we may, at our option: (i) replace the product with another non-infringing product that provides substantially similar performance; (ii) modify the infringing product so that it no longer infringes but remains functionally equivalent; (iii) obtain the right for the customer to continue using the product at our expense and for the reseller to continue selling the product; (iv) take back the infringing product and refund to the customer the purchase price paid less depreciation amortized on a straight-line basis. We have not been required to make material payments pursuant to these provisions historically. We have not recorded any liability at April 29, 2016 related to these guarantees since the maximum amount of potential future payments under such guarantees, indemnities and warranties is not determinable, other than as described above.

[0001564590-16-020754:notes:308]
Legal Contingencies

[0001564590-16-020754:notes:309]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-16-020754:notes:310]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of April 29, 2016 related to such matters as they are not probable and/or reasonably estimable.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001564590-16-020754:notes:311]
Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights.
