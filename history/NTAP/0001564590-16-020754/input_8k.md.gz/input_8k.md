# NTAP 8-K — 0001102624-16-002862 filed 2016-05-25

## item codes, every 8-K on or before 2016-06-22

- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2016-06-22

- none on or before 2016-06-22

## item 2.02 — earnings release, exhibit 99.1

[0001102624-16-002862:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-16-002862:8k_2_02:2]
Exhibit 99.1

[0001102624-16-002862:8k_2_02:3]
| Press Contact: | Investor Contact: |
| Meghan Fintland | Kris Newton |
| NetApp | NetApp |
| 1 408 822 1389 | 1 408 822 3312 |
| meghan.fintland@netapp.com | kris.newton@netapp.com |

[0001102624-16-002862:8k_2_02:4]
NETAPP REPORTS FOURTH QUARTER AND FISCAL YEAR 2016 RESULTS

[0001102624-16-002862:8k_2_02:5]
Net Revenues of $1.38 Billion for the Fourth Quarter and $5.55 Billion for Fiscal Year 2016

[0001102624-16-002862:8k_2_02:6]
| · | NetAppTM clustered Data ONTAP™ node shipments increased in fiscal year 2016 by 85% year-over-year |

[0001102624-16-002862:8k_2_02:7]
| · | All Flash FAS units for fiscal year 2016 grew 345% year-over-year |

[0001102624-16-002862:8k_2_02:8]
| · | Deferred revenue and financed unearned services revenue for fiscal year 2016 up 6% year-over-year |

[0001102624-16-002862:8k_2_02:9]
| · | Authorized an increase in the quarterly cash dividend to $0.19 per share for the first quarter of fiscal year 2017 |

[0001102624-16-002862:8k_2_02:10]
| · | $1.17 billion returned to shareholders in share repurchases and cash dividends; 144% of free cash flow1 in fiscal year 2016 |

[0001102624-16-002862:8k_2_02:11]
Sunnyvale, Calif.—May 25, 2016—NetApp (NASDAQ: NTAP) today reported financial results for the fourth quarter and fiscal year 2016, ended April 29, 2016.

[0001102624-16-002862:8k_2_02:12]
Fourth Quarter Financial Results

[0001102624-16-002862:8k_2_02:13]
Net revenues for the fourth quarter of fiscal year 2016 were $1.38 billion. GAAP net loss for the fourth quarter of fiscal year 2016 was $8 million, or $0.03 loss per share,2 compared to GAAP net income of $135 million, or $0.43 income per share,3 for the comparable period of the prior year. Non-GAAP net income for the fourth quarter of fiscal year 2016 was $157 million, or $0.55 income per share,4 compared to non-GAAP net income of $202 million, or $0.65 income per share, for the comparable period of the prior year.

[0001102624-16-002862:8k_2_02:14]
Fiscal Year 2016 Financial Results

[0001102624-16-002862:8k_2_02:15]
Net revenues for fiscal year 2016 were $5.55 billion. GAAP net income for fiscal year 2016 was $229 million, or $0.77 per share,3 compared to GAAP net income of $560 million, or $1.75 per share, for the comparable period of the prior year. Non-GAAP net income for fiscal year 2016 was $633 million, or $2.13 per share,4 compared to non-GAAP net income of $865 million, or $2.70 per share, for the comparable period of the prior year.

[0001102624-16-002862:8k_2_02:16]
Cash, Cash Equivalents and Investments

[0001102624-16-002862:8k_2_02:17]
NetApp ended fiscal year 2016 with $5.3 billion in total cash, cash equivalents and investments.  During the fourth quarter of fiscal year 2016, the Company generated $345 million in cash from operations and returned $313 million to shareholders through share repurchases and a cash dividend.

[0001102624-16-002862:8k_2_02:18]
The Company will increase the first quarter fiscal year 2017 dividend by 6% to $0.19 per share. The quarterly dividend will be paid on July 27, 2016, to shareholders of record as of the close of business on July 18, 2016.

[0001102624-16-002862:8k_2_02:19]
"We executed well in the fourth quarter and I'm pleased with the progress we are making with our strategic solutions portfolio in addressing customers' needs," said George Kurian, chief executive officer. "We continue to advance our pivot to the growth segments of the market while, at the same time, streamlining the business and reducing our cost base. The team remains sharply focused on disciplined execution and is fully committed to return the company to long-term growth."

[0001102624-16-002862:8k_2_02:20]
Q1 Fiscal Year 2017 Outlook

[0001102624-16-002862:8k_2_02:21]
The Company provided the following financial guidance for the first quarter of fiscal year 2017:

[0001102624-16-002862:8k_2_02:22]
| ● | Net revenues are expected to be in the range of $1.20 billion to $1.35 billion. |

[0001102624-16-002862:8k_2_02:23]
| ● | GAAP earnings per share is expected to be in the range of $0.13 to $0.18 per share. |

[0001102624-16-002862:8k_2_02:24]
| ● | Non-GAAP earnings per share is expected to be in the range of $0.34 to $0.39 per share. |

[0001102624-16-002862:8k_2_02:25]
Business Highlights

[0001102624-16-002862:8k_2_02:26]
| ● | Leading the All-Flash-Array Market |

[0001102624-16-002862:8k_2_02:27]
|  | - | All-flash systems product of the year. Storage Magazine/SearchStorage.com recognize SolidFire's high-capacity SF9605 node as a gold winner in the competitive all-flash systems category. |

[0001102624-16-002862:8k_2_02:28]
|  | - | NetApp and Cisco's FlexPod advantage initiative removes constraints for the modern enterprise data center. An all-flash Converged Infrastructure enables partners such as Citrix to accelerate time-to-market and help customers to fast track their journey to a modern data center. |

[0001102624-16-002862:8k_2_02:29]
|  | - | Increased the performance of data analytics applications by more than 50%. New SANtricity™ software for NetApp EF-Series all-flash and E-Series storage arrays dramatically boosts the performance and value of big data analytics applications. |

[0001102624-16-002862:8k_2_02:30]
|  | - | Faster coding and better performance. New SolidFire Python SDK dramatically reduces the amount of additional time and coding required for integration and orchestration between SolidFire's platform and third-party applications. |

[0001102624-16-002862:8k_2_02:31]
| ● | Customers and Partners Achieve Success Through NetApp |

[0001102624-16-002862:8k_2_02:32]
|  | - | Media companies adopt NetApp StorageGRID™ Webscale. In the past 12 months, media vendors—Aspera, Cantemo, Dalet, OpenText (through CyanGate), Primestream, Signiant, Silvertrak, Spectra Logic, and Vidispine—have validated their Amazon Simple Storage Service (S3) interface with StorageGRID Webscale. |

[0001102624-16-002862:8k_2_02:33]
|  | - | Mansfield Oil delivers new applications and services up to 50% faster with NetApp. Transition to new fully redundant data and disaster recovery center keeps mission-critical data safe and improves customer service by eliminating downtime for core business applications. |

[0001102624-16-002862:8k_2_02:34]
|  | - | DARZ makes secure hybrid cloud and multicloud a reality with NetApp Private Storage (NPS). NPS as a Service from DARZ makes it possible for its customer Helpium to leverage the elasticity, cost and performance benefits of public cloud providers without putting its data—or its business—at risk. |

[0001102624-16-002862:8k_2_02:35]
|  | - | Top-ranked financial fund administrator HedgeServ deploys SolidFire. By delivering scalable storage to keep pace with HedgeServ's business growth and expanded offerings, SolidFire has transformed storage from a significant cost and management burden into an innovation enabler. |

[0001102624-16-002862:8k_2_02:36]
|  | - | Denver Broncos' deploy business-critical applications with NetApp. NetApp FAS systems power the Bronco's entire infrastructure, including data analysis used from draft day to the stadium on game day, as well as to support over 330 events throughout the year. Regardless of location, the Broncos have been able to deploy mobile tablets to players, coaches, managers and support staff enabling them to view footage within hours of a game. |

[0001102624-16-002862:8k_2_02:37]
| ● | Technology and Business Leaders Join NetApp |

[0001102624-16-002862:8k_2_02:38]
|  | - | Ron Pasek, executive vice president, chief financial officer. Pasek manages several finance and business functions while helping drive a portfolio management approach to enable growth. |

[0001102624-16-002862:8k_2_02:39]
|  | - | Henri Richard, executive vice president, worldwide field and customer operations. Richard leads relationships with NetApp's strategic technology partners, resellers, and customers across the globe. |

[0001102624-16-002862:8k_2_02:40]
Webcast and Conference Call Information

[0001102624-16-002862:8k_2_02:41]
NetApp will host a conference call to discuss these results today at 2 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4 p.m. Pacific Time today.

[0001102624-16-002862:8k_2_02:42]
About NetApp

[0001102624-16-002862:8k_2_02:43]
Leading organizations worldwide count on NetApp for software, systems and services to manage and store their data. Customers value our teamwork, expertise and passion for helping them succeed now and into the future. To learn more, visit http://www.netapp.com.

[0001102624-16-002862:8k_2_02:44]
###

[0001102624-16-002862:8k_2_02:45]
NetApp and the NetApp logo are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001102624-16-002862:8k_2_02:46]
1Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less cash used to acquire property and equipment.

[0001102624-16-002862:8k_2_02:47]
2GAAP net loss per share is calculated using the basic number of shares and excludes common stock equivalents because the impact would be anti-dilutive.

[0001102624-16-002862:8k_2_02:48]
3GAAP net income per share is calculated using the diluted number of shares.

[0001102624-16-002862:8k_2_02:49]
4Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) acquisition-related income and expenses, (d) restructuring and other charges, (e) asset impairments, (f) gains/losses on the sale of properties (g) non-cash interest expense associated with our convertible debt, and (h) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp's management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp's ongoing operational performance.

[0001102624-16-002862:8k_2_02:50]
NetApp Usage of Non-GAAP Financial Information

[0001102624-16-002862:8k_2_02:51]
To supplement NetApp's condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results and non-GAAP net income, non-GAAP effective tax rate, non-GAAP inventory turns, and free cash flow; and historical and projected non-GAAP net income per diluted share.

[0001102624-16-002862:8k_2_02:52]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP net income per share data when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. In addition, NetApp believes that the presentation of non-GAAP inventory turns provides useful information to investors and management regarding financial and business trends relating to inventory management based on the operating activities of the periods presented. NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock, after deducting capital expenditures. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for the analysis provided in the statement of cash flows.

[0001102624-16-002862:8k_2_02:53]
NetApp's management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp's ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors' operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001102624-16-002862:8k_2_02:54]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001102624-16-002862:8k_2_02:55]
A. Amortization of intangible assets.  NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001102624-16-002862:8k_2_02:56]
B. Stock-based compensation expenses.  NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001102624-16-002862:8k_2_02:57]
C. Acquisition-related income and expenses.  NetApp excludes acquisition-related income and expenses, including (a) merger termination proceeds, (b) due diligence, legal and other one-time integration charges, (c) the impact of inventory step-ups, and (d) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001102624-16-002862:8k_2_02:58]
D. Restructuring and other charges.  These charges include restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. These items are not ordinarily included in our annual operating plan and related budget due to the unpredictability of the timing and size of these events. We therefore exclude them in our assessment of operational performance.

[0001102624-16-002862:8k_2_02:59]
E. Asset impairments.  These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001102624-16-002862:8k_2_02:60]
F. Gains/losses on the sale of properties.  These are gains/losses from the sale of our properties. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001102624-16-002862:8k_2_02:61]
G. Non-cash interest expense.  These are non-cash charges from the amortization of convertible debt discount and issuance costs. Management does not believe that these charges reflect the underlying performance of our business.

[0001102624-16-002862:8k_2_02:62]
H. Income tax adjustments.  NetApp's non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company's tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual properties from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company's operational performance.

[0001102624-16-002862:8k_2_02:63]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company's results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001102624-16-002862:8k_2_02:64]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  | April 29, 2016 |  | April 24, 2015 |  |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,303 |  |  | $ | 5,326 |  |
| Accounts receivable |  |  | 813 |  |  |  | 779 |  |
| Inventories |  |  | 98 |  |  |  | 146 |  |
| Other current assets |  |  | 234 |  |  |  | 522 |  |
| Total current assets |  |  | 6,448 |  |  |  | 6,773 |  |
| Property and equipment, net |  |  | 937 |  |  |  | 1,030 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,856 |  |  |  | 1,117 |  |
| Other non-current assets |  |  | 796 |  |  |  | 481 |  |
| Total assets |  | $ | 10,037 |  |  | $ | 9,401 |  |

[0001102624-16-002862:8k_2_02:65]
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 254 |  |  | $ | 284 |  |
| Accrued expenses |  |  | 765 |  |  |  | 701 |  |
| Short-term loan |  |  | 849 |  |  |  | - |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,794 |  |  |  | 1,724 |  |
| Total current liabilities |  |  | 3,662 |  |  |  | 2,709 |  |
| Long-term debt |  |  | 1,490 |  |  |  | 1,487 |  |
| Other long-term liabilities |  |  | 413 |  |  |  | 318 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,591 |  |  |  | 1,473 |  |
| Total liabilities |  |  | 7,156 |  |  |  | 5,987 |  |
| Stockholders' equity |  |  | 2,881 |  |  |  | 3,414 |  |
| Total liabilities and stockholders' equity |  | $ | 10,037 |  |  | $ | 9,401 |  |

[0001102624-16-002862:8k_2_02:66]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 757 |  |  | $ | 914 |  |  | $ | 2,986 |  |  | $ | 3,655 |  |
| Software maintenance |  |  | 234 |  |  |  | 227 |  |  |  | 949 |  |  |  | 899 |  |
| Hardware maintenance and other services |  |  | 389 |  |  |  | 399 |  |  |  | 1,611 |  |  |  | 1,569 |  |
| Net revenues |  |  | 1,380 |  |  |  | 1,540 |  |  |  | 5,546 |  |  |  | 6,123 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 424 |  |  |  | 441 |  |  |  | 1,558 |  |  |  | 1,657 |  |
| Cost of software maintenance |  |  | 9 |  |  |  | 10 |  |  |  | 37 |  |  |  | 36 |  |
| Cost of hardware maintenance and other services |  |  | 129 |  |  |  | 154 |  |  |  | 578 |  |  |  | 597 |  |
| Total cost of revenues |  |  | 562 |  |  |  | 605 |  |  |  | 2,173 |  |  |  | 2,290 |  |
| Gross profit |  |  | 818 |  |  |  | 935 |  |  |  | 3,373 |  |  |  | 3,833 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 434 |  |  |  | 470 |  |  |  | 1,792 |  |  |  | 1,913 |  |
| Research and development |  |  | 201 |  |  |  | 233 |  |  |  | 861 |  |  |  | 920 |  |
| General and administrative |  |  | 84 |  |  |  | 71 |  |  |  | 307 |  |  |  | 284 |  |
| Restructuring and other charges |  |  | 80 |  |  |  | - |  |  |  | 108 |  |  |  | - |  |
| Acquisition-related expense |  |  | 6 |  |  |  | - |  |  |  | 8 |  |  |  | - |  |
| Gain on sale of properties |  |  | (51 | ) |  |  | - |  |  |  | (51 | ) |  |  | - |  |
| Total operating expenses |  |  | 754 |  |  |  | 774 |  |  |  | 3,025 |  |  |  | 3,117 |  |
| Income from operations |  |  | 64 |  |  |  | 161 |  |  |  | 348 |  |  |  | 716 |  |
| Other income (expense), net |  |  | (4 | ) |  |  | 3 |  |  |  | (3 | ) |  |  | (3 | ) |
| Income before income taxes |  |  | 60 |  |  |  | 164 |  |  |  | 345 |  |  |  | 713 |  |
| Provision for income taxes |  |  | 68 |  |  |  | 29 |  |  |  | 116 |  |  |  | 153 |  |
| Net income (loss) |  | $ | (8 | ) |  | $ | 135 |  |  | $ | 229 |  |  | $ | 560 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.03 | ) |  | $ | 0.44 |  |  | $ | 0.78 |  |  | $ | 1.77 |  |
| Diluted |  | $ | (0.03 | ) |  | $ | 0.43 |  |  | $ | 0.77 |  |  | $ | 1.75 |  |
| Shares used in net income (loss) per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 284 |  |  |  | 309 |  |  |  | 294 |  |  |  | 316 |  |
| Diluted |  |  | 284 |  |  |  | 313 |  |  |  | 297 |  |  |  | 321 |  |
| Cash dividends declared per share |  | $ | 0.180 |  |  | $ | 0.165 |  |  | $ | 0.720 |  |  | $ | 0.660 |  |

[0001102624-16-002862:8k_2_02:67]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (8 | ) |  | $ | 135 |  |  | $ | 229 |  |  | $ | 560 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 77 |  |  |  | 72 |  |  |  | 279 |  |  |  | 307 |  |
| Stock-based compensation |  |  | 61 |  |  |  | 63 |  |  |  | 260 |  |  |  | 259 |  |
| Excess tax benefit from stock-based compensation |  |  | - |  |  |  | (1 | ) |  |  | (5 | ) |  |  | (55 | ) |
| Gain on sale of properties |  |  | (51 | ) |  |  | - |  |  |  | (51 | ) |  |  | - |  |
| Other, net |  |  | 31 |  |  |  | 2 |  |  |  | (38 | ) |  |  | 32 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (206 | ) |  |  | (112 | ) |  |  | (16 | ) |  |  | 75 |  |
| Inventories |  |  | 5 |  |  |  | (29 | ) |  |  | 49 |  |  |  | (24 | ) |
| Accounts payable |  |  | 60 |  |  |  | 85 |  |  |  | (53 | ) |  |  | 39 |  |
| Accrued expenses |  |  | 108 |  |  |  | 95 |  |  |  | 30 |  |  |  | (67 | ) |
| Deferred revenue and financed unearned services revenue |  |  | 238 |  |  |  | 88 |  |  |  | 186 |  |  |  | 122 |  |
| Changes in other operating assets and liabilities, net |  |  | 30 |  |  |  | (2 | ) |  |  | 104 |  |  |  | 20 |  |
| Net cash provided by operating activities |  |  | 345 |  |  |  | 396 |  |  |  | 974 |  |  |  | 1,268 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | 103 |  |  |  | (686 | ) |  |  | 982 |  |  |  | (645 | ) |
| Purchases of property and equipment |  |  | (35 | ) |  |  | (37 | ) |  |  | (160 | ) |  |  | (175 | ) |
| Proceeds from sale of properties |  |  | 102 |  |  |  | - |  |  |  | 102 |  |  |  | - |  |
| Acquisitions of businesses, net of cash acquired |  |  | (842 | ) |  |  | - |  |  |  | (842 | ) |  |  | (85 | ) |
| Other investing activities, net |  |  | 4 |  |  |  | (1 | ) |  |  | 3 |  |  |  | 2 |  |
| Net cash provided by (used in) investing activities |  |  | (668 | ) |  |  | (724 | ) |  |  | 85 |  |  |  | (903 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | - |  |  |  | 11 |  |  |  | 70 |  |  |  | 157 |  |
| Repurchase of common stock |  |  | (262 | ) |  |  | (246 | ) |  |  | (960 | ) |  |  | (1,165 | ) |
| Excess tax benefit from stock-based compensation |  |  | - |  |  |  | 1 |  |  |  | 5 |  |  |  | 55 |  |
| Proceeds from sale leaseback financing transaction |  |  | 148 |  |  |  | - |  |  |  | 148 |  |  |  | - |  |
| Proceeds from short-term loan |  |  | 870 |  |  |  | - |  |  |  | 870 |  |  |  | - |  |
| Issuance of long-term debt, net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 495 |  |
| Repayment of short-term loan |  |  | (20 | ) |  |  | - |  |  |  | (20 | ) |  |  | - |  |
| Dividends paid |  |  | (51 | ) |  |  | (51 | ) |  |  | (210 | ) |  |  | (208 | ) |
| Other financing activities, net |  |  | (4 | ) |  |  | (1 | ) |  |  | (12 | ) |  |  | (9 | ) |
| Net cash provided by (used in) financing activities |  |  | 681 |  |  |  | (286 | ) |  |  | (109 | ) |  |  | (675 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 15 |  |  |  | (4 | ) |  |  | (4 | ) |  |  | (59 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 373 |  |  |  | (618 | ) |  |  | 946 |  |  |  | (369 | ) |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,495 |  |  |  | 2,540 |  |  |  | 1,922 |  |  |  | 2,291 |  |
| End of period |  | $ | 2,868 |  |  | $ | 1,922 |  |  | $ | 2,868 |  |  | $ | 1,922 |  |

[0001102624-16-002862:8k_2_02:68]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO and Inventory Turns) |  |
| (Unaudited) |  |
|  | Q4 FY'16 |  |  | Q3 FY'16 |  |  | Q4 FY'15 |  |  | FY 2016 |  |  | FY 2015 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 757 |  |  |  | $ | 750 |  |  |  | $ | 914 |  |  |  | $ | 2,986 |  |  |  | $ | 3,655 |  |
| Software Maintenance |  | $ | 234 |  |  |  | $ | 234 |  |  |  | $ | 227 |  |  |  | $ | 949 |  |  |  | $ | 899 |  |
| Hardware Maintenance & Other Services: |  | $ | 389 |  |  |  | $ | 402 |  |  |  | $ | 399 |  |  |  | $ | 1,611 |  |  |  | $ | 1,569 |  |
| Hardware Maintenance Support Contracts |  | $ | 318 |  |  |  | $ | 326 |  |  |  | $ | 323 |  |  |  | $ | 1,316 |  |  |  | $ | 1,253 |  |
| Professional and Other Services |  | $ | 71 |  |  |  | $ | 76 |  |  |  | $ | 77 |  |  |  | $ | 295 |  |  |  | $ | 317 |  |
| Net Revenues |  | $ | 1,380 |  |  |  | $ | 1,386 |  |  |  | $ | 1,540 |  |  |  | $ | 5,546 |  |  |  | $ | 6,123 |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | % of Q4 FY'16 Revenue |  |  | % of Q3 FY'16 Revenue |  |  | % of Q4 FY'15 Revenue |  |  | % of FY 2016 Revenue |  |  | % of FY 2015 Revenue |  |
| Americas |  |  | 54 | % |  |  |  | 54 | % |  |  |  | 57 | % |  |  |  | 55 | % |  |  |  | 56 | % |
| Americas Commercial |  |  | 43 | % |  |  |  | 44 | % |  |  |  | 43 | % |  |  |  | 43 | % |  |  |  | 43 | % |
| U.S. Public Sector |  |  | 12 | % |  |  |  | 10 | % |  |  |  | 14 | % |  |  |  | 12 | % |  |  |  | 13 | % |
| EMEA |  |  | 33 | % |  |  |  | 33 | % |  |  |  | 30 | % |  |  |  | 32 | % |  |  |  | 30 | % |
| Asia Pacific |  |  | 13 | % |  |  |  | 13 | % |  |  |  | 13 | % |  |  |  | 13 | % |  |  |  | 13 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |
|  | % of Q4 FY'16 Revenue |  |  | % of Q3 FY'16 Revenue |  |  | % of Q4 FY'15 Revenue |  |  | % of FY 2016 Revenue |  |  | % of FY 2015 Revenue |  |
| Direct |  |  | 26 | % |  |  |  | 22 | % |  |  |  | 22 | % |  |  |  | 23 | % |  |  |  | 22 | % |
| Indirect |  |  | 74 | % |  |  |  | 78 | % |  |  |  | 78 | % |  |  |  | 77 | % |  |  |  | 78 | % |
| Direct revenues are those sold through our direct sales force and, effective Q1 FY'16, include those sold to service providers. Indirect revenues include those sold through value-added resellers, system integrators, OEMs and distributors. Indirect revenue reflects order fulfillment and is not reflective of who is responsible for the customer relationship. |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Q4 FY'16 |  |  | Q3 FY'16 |  |  | Q4 FY'15 |  |  | FY 2016 |  |  | FY 2015 |  |
| Non-GAAP Gross Margin |  |  | 61.1 | % |  |  |  | 63.1 | % |  |  |  | 62.0 | % |  |  |  | 62.5 | % |  |  |  | 64.0 | % |
| Product |  |  | 46.8 | % |  |  |  | 51.1 | % |  |  |  | 53.4 | % |  |  |  | 50.2 | % |  |  |  | 56.5 | % |
| Software Maintenance |  |  | 96.2 | % |  |  |  | 96.2 | % |  |  |  | 95.8 | % |  |  |  | 96.1 | % |  |  |  | 96.0 | % |
| Hardware Maintenance & Other Services |  |  | 67.9 | % |  |  |  | 66.2 | % |  |  |  | 62.6 | % |  |  |  | 65.7 | % |  |  |  | 63.1 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Q4 FY'16 |  |  | Q3 FY'16 |  |  | Q4 FY'15 |  |  | FY 2016 |  |  | FY 2015 |  |
| Non-GAAP Income from Operations |  | $ | 185 |  |  |  | $ | 244 |  |  |  | $ | 240 |  |  |  | $ | 751 |  |  |  | $ | 1,040 |  |
| % of Net Revenues |  |  | 13.4 | % |  |  |  | 17.6 | % |  |  |  | 15.6 | % |  |  |  | 13.5 | % |  |  |  | 17.0 | % |
| Non-GAAP Income before Income Taxes |  | $ | 181 |  |  |  | $ | 242 |  |  |  | $ | 243 |  |  |  | $ | 748 |  |  |  | $ | 1,036 |  |
| Non-GAAP Effective Tax Rate |  |  | 13.1 | % |  |  |  | 14.9 | % |  |  |  | 16.7 | % |  |  |  | 15.4 | % |  |  |  | 16.5 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Q4 FY'16 |  |  | Q3 FY'16 |  |  | Q4 FY'15 |  |  | FY 2016 |  |  | FY 2015 |  |
| Non-GAAP Net Income |  | $ | 157 |  |  |  | $ | 206 |  |  |  | $ | 202 |  |  |  | $ | 633 |  |  |  | $ | 865 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 287 |  |  |  |  | 296 |  |  |  |  | 313 |  |  |  |  | 297 |  |  |  | $ | 321 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 0.55 |  |  |  | $ | 0.70 |  |  |  | $ | 0.65 |  |  |  | $ | 2.13 |  |  |  | $ | 2.70 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Q4 FY'16 |  |  | Q3 FY'16 |  |  | Q4 FY'15 |  |  |  |  |  |  |  |  |  |  |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,385 |  |  |  | $ | 3,126 |  |  |  | $ | 3,197 |  |  |  |  |  |  |  |  |  |  |  |
| DSO (days) |  |  | 54 |  |  |  |  | 38 |  |  |  |  | 46 |  |  |  |  |  |  |  |  |  |  |  |
| Inventory Turns |  |  | 22 |  |  |  |  | 20 |  |  |  |  | 16 |  |  |  |  |  |  |  |  |  |  |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |  |  |  |  |  |  |  |  |  |  |
| Inventory turns is defined as annualized non-GAAP cost of revenues divided by net inventories. |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Q4 FY'16 |  |  | Q3 FY'16 |  |  | Q4 FY'15 |  |  | FY 2016 |  |  | FY 2015 |  |
| Net Cash Provided by Operating Activities |  | $ | 345 |  |  |  | $ | 355 |  |  |  | $ | 396 |  |  |  | $ | 974 |  |  |  | $ | 1,268 |  |
| Purchases of Property and Equipment |  | $ | 35 |  |  |  | $ | 41 |  |  |  | $ | 37 |  |  |  | $ | 160 |  |  |  | $ | 175 |  |
| Free Cash Flow |  | $ | 310 |  |  |  | $ | 314 |  |  |  | $ | 359 |  |  |  | $ | 814 |  |  |  | $ | 1,093 |  |
| Free Cash Flow as % of Net Revenues |  |  | 22.5 | % |  |  |  | 22.7 | % |  |  |  | 23.3 | % |  |  |  | 14.7 | % |  |  |  | 17.8 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |  |  |  |  |  |  |  |  |  |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001102624-16-002862:8k_2_02:69]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY16 |  |  | Q3'FY16 |  |  | Q4'FY15 |  |  | FY2016 |  |  | FY2015 |  |
| NET INCOME (LOSS) |  | $ | (8 | ) |  | $ | 153 |  |  | $ | 135 |  |  | $ | 229 |  |  | $ | 560 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 25 |  |  |  | 14 |  |  |  | 16 |  |  |  | 67 |  |  |  | 64 |  |
| Stock-based compensation |  |  | 61 |  |  |  | 63 |  |  |  | 63 |  |  |  | 260 |  |  |  | 259 |  |
| Asset impairment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 11 |  |  |  | - |  |
| Restructuring and other charges |  |  | 80 |  |  |  | - |  |  |  | - |  |  |  | 108 |  |  |  | - |  |
| Acquisition-related expense |  |  | 6 |  |  |  | 2 |  |  |  | - |  |  |  | 8 |  |  |  | - |  |
| Gain on sale of properties |  |  | (51 | ) |  |  | - |  |  |  | - |  |  |  | (51 | ) |  |  | - |  |
| Income tax effect of non-GAAP adjustments |  |  | (20 | ) |  |  | (26 | ) |  |  | (11 | ) |  |  | (86 | ) |  |  | (66 | ) |
| Income tax expenses from integration of intellectual properties from acquisitions |  |  | 64 |  |  |  | - |  |  |  | - |  |  |  | 64 |  |  |  | - |  |
| Settlement of income tax audit |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 23 |  |  |  | 47 |  |
| NON-GAAP NET INCOME |  | $ | 157 |  |  | $ | 206 |  |  | $ | 202 |  |  | $ | 633 |  |  | $ | 865 |  |
| COST OF REVENUES |  | $ | 562 |  |  | $ | 531 |  |  | $ | 605 |  |  | $ | 2,173 |  |  | $ | 2,290 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (20 | ) |  |  | (13 | ) |  |  | (16 | ) |  |  | (61 | ) |  |  | (63 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (6 | ) |  |  | (5 | ) |  |  | (24 | ) |  |  | (22 | ) |
| Asset impairment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (11 | ) |  |  | - |  |
| NON-GAAP COST OF REVENUES |  | $ | 537 |  |  | $ | 512 |  |  | $ | 584 |  |  | $ | 2,077 |  |  | $ | 2,205 |  |
| COST OF PRODUCT REVENUES |  | $ | 424 |  |  | $ | 381 |  |  | $ | 441 |  |  | $ | 1,558 |  |  | $ | 1,657 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (20 | ) |  |  | (13 | ) |  |  | (15 | ) |  |  | (61 | ) |  |  | (61 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |  |  | (5 | ) |  |  | (6 | ) |
| Asset impairment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (5 | ) |  |  | - |  |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 403 |  |  | $ | 367 |  |  | $ | 425 |  |  | $ | 1,487 |  |  | $ | 1,591 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 129 |  |  | $ | 141 |  |  | $ | 154 |  |  | $ | 578 |  |  | $ | 597 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | - |  |  |  | - |  |  |  | (1 | ) |  |  | - |  |  |  | (2 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (5 | ) |  |  | (4 | ) |  |  | (19 | ) |  |  | (16 | ) |
| Asset impairment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (6 | ) |  |  | - |  |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 125 |  |  | $ | 136 |  |  | $ | 150 |  |  | $ | 553 |  |  | $ | 579 |  |
| GROSS PROFIT |  | $ | 818 |  |  | $ | 855 |  |  | $ | 935 |  |  | $ | 3,373 |  |  | $ | 3,833 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 20 |  |  |  | 13 |  |  |  | 16 |  |  |  | 61 |  |  |  | 63 |  |
| Stock-based compensation |  |  | 5 |  |  |  | 6 |  |  |  | 5 |  |  |  | 24 |  |  |  | 22 |  |
| Asset impairment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 11 |  |  |  | - |  |
| NON-GAAP GROSS PROFIT |  | $ | 843 |  |  | $ | 874 |  |  | $ | 955 |  |  | $ | 3,469 |  |  | $ | 3,918 |  |
| SALES AND MARKETING EXPENSES |  | $ | 434 |  |  | $ | 418 |  |  | $ | 470 |  |  | $ | 1,792 |  |  | $ | 1,913 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (1 | ) |  |  | - |  |  |  | (6 | ) |  |  | (1 | ) |
| Stock-based compensation |  |  | (26 | ) |  |  | (27 | ) |  |  | (29 | ) |  |  | (110 | ) |  |  | (116 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 403 |  |  | $ | 390 |  |  | $ | 440 |  |  | $ | 1,676 |  |  | $ | 1,796 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 201 |  |  | $ | 200 |  |  | $ | 233 |  |  | $ | 861 |  |  | $ | 920 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (20 | ) |  |  | (20 | ) |  |  | (20 | ) |  |  | (84 | ) |  |  | (84 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 181 |  |  | $ | 180 |  |  | $ | 213 |  |  | $ | 777 |  |  | $ | 835 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 84 |  |  | $ | 70 |  |  | $ | 71 |  |  | $ | 307 |  |  | $ | 284 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (10 | ) |  |  | (10 | ) |  |  | (9 | ) |  |  | (42 | ) |  |  | (37 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 74 |  |  | $ | 60 |  |  | $ | 62 |  |  | $ | 265 |  |  | $ | 247 |  |

[0001102624-16-002862:8k_2_02:70]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY16 |  |  | Q3'FY16 |  |  | Q4'FY15 |  |  | FY2016 |  |  | FY2015 |  |
| RESTRUCTURING AND OTHER CHARGES |  | $ | 80 |  |  | $ | - |  |  | $ | - |  |  | $ | 108 |  |  | $ | - |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  |  | (80 | ) |  |  | - |  |  |  | - |  |  |  | (108 | ) |  |  | - |  |
| NON-GAAP RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 6 |  |  | $ | 2 |  |  | $ | - |  |  | $ | 8 |  |  | $ | - |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (6 | ) |  |  | (2 | ) |  |  | - |  |  |  | (8 | ) |  |  | - |  |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| GAIN ON SALE OF PROPERTIES |  | $ | (51 | ) |  | $ | - |  |  | $ | - |  |  | $ | (51 | ) |  | $ | - |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale of properties |  |  | 51 |  |  |  | - |  |  |  | - |  |  |  | 51 |  |  |  | - |  |
| NON-GAAP GAIN ON SALE OF PROPERTIES |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| OPERATING EXPENSES |  | $ | 754 |  |  | $ | 690 |  |  | $ | 774 |  |  | $ | 3,025 |  |  | $ | 3,117 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (1 | ) |  |  | - |  |  |  | (6 | ) |  |  | (1 | ) |
| Stock-based compensation |  |  | (56 | ) |  |  | (57 | ) |  |  | (58 | ) |  |  | (236 | ) |  |  | (237 | ) |
| Restructuring and other charges |  |  | (80 | ) |  |  | - |  |  |  | - |  |  |  | (108 | ) |  |  | - |  |
| Acquisition-related expense |  |  | (6 | ) |  |  | (2 | ) |  |  | - |  |  |  | (8 | ) |  |  | - |  |
| Gain on sale of properties |  |  | 51 |  |  |  | - |  |  |  | - |  |  |  | 51 |  |  |  | - |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 658 |  |  | $ | 630 |  |  | $ | 715 |  |  | $ | 2,718 |  |  | $ | 2,878 |  |
| INCOME FROM OPERATIONS |  | $ | 64 |  |  | $ | 165 |  |  | $ | 161 |  |  | $ | 348 |  |  | $ | 716 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 25 |  |  |  | 14 |  |  |  | 16 |  |  |  | 67 |  |  |  | 64 |  |
| Stock-based compensation |  |  | 61 |  |  |  | 63 |  |  |  | 63 |  |  |  | 260 |  |  |  | 259 |  |
| Asset impairment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 11 |  |  |  | - |  |
| Restructuring and other charges |  |  | 80 |  |  |  | - |  |  |  | - |  |  |  | 108 |  |  |  | - |  |
| Acquisition-related expense |  |  | 6 |  |  |  | 2 |  |  |  | - |  |  |  | 8 |  |  |  | - |  |
| Gain on sale of properties |  |  | (51 | ) |  |  | - |  |  |  | - |  |  |  | (51 | ) |  |  | - |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 185 |  |  | $ | 244 |  |  | $ | 240 |  |  | $ | 751 |  |  | $ | 1,040 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 60 |  |  | $ | 163 |  |  | $ | 164 |  |  | $ | 345 |  |  | $ | 713 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 25 |  |  |  | 14 |  |  |  | 16 |  |  |  | 67 |  |  |  | 64 |  |
| Stock-based compensation |  |  | 61 |  |  |  | 63 |  |  |  | 63 |  |  |  | 260 |  |  |  | 259 |  |
| Asset impairment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 11 |  |  |  | - |  |
| Restructuring and other charges |  |  | 80 |  |  |  | - |  |  |  | - |  |  |  | 108 |  |  |  | - |  |
| Acquisition-related expense |  |  | 6 |  |  |  | 2 |  |  |  | - |  |  |  | 8 |  |  |  | - |  |
| Gain on sale of properties |  |  | (51 | ) |  |  | - |  |  |  | - |  |  |  | (51 | ) |  |  | - |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 181 |  |  | $ | 242 |  |  | $ | 243 |  |  | $ | 748 |  |  | $ | 1,036 |  |
| PROVISION FOR INCOME TAXES |  | $ | 68 |  |  | $ | 10 |  |  | $ | 29 |  |  | $ | 116 |  |  | $ | 153 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | 20 |  |  |  | 26 |  |  |  | 11 |  |  |  | 86 |  |  |  | 66 |  |
| Income tax expenses from integration of intellectual properties from acquisitions |  |  | (64 | ) |  |  | - |  |  |  | - |  |  |  | (64 | ) |  |  | - |  |
| Settlement of income tax audit |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (23 | ) |  |  | (47 | ) |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 24 |  |  | $ | 36 |  |  | $ | 41 |  |  | $ | 115 |  |  | $ | 171 |  |
| NET INCOME (LOSS) PER SHARE |  | $ | (0.03 | ) |  | $ | 0.52 |  |  | $ | 0.43 |  |  | $ | 0.77 |  |  | $ | 1.75 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.09 |  |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.23 |  |  |  | 0.20 |  |
| Stock-based compensation |  |  | 0.21 |  |  |  | 0.21 |  |  |  | 0.20 |  |  |  | 0.88 |  |  |  | 0.81 |  |
| Asset impairment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.04 |  |  |  | - |  |
| Restructuring and other charges |  |  | 0.28 |  |  |  | - |  |  |  | - |  |  |  | 0.36 |  |  |  | - |  |
| Acquisition-related expense |  |  | 0.02 |  |  |  | 0.01 |  |  |  | - |  |  |  | 0.03 |  |  |  | - |  |
| Gain on sale of properties |  |  | (0.18 | ) |  |  | - |  |  |  | - |  |  |  | (0.17 | ) |  |  | - |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.07 | ) |  |  | (0.09 | ) |  |  | (0.04 | ) |  |  | (0.29 | ) |  |  | (0.21 | ) |
| Income tax expenses from integration of intellectual properties from acquisitions |  |  | 0.23 |  |  |  | - |  |  |  | - |  |  |  | 0.22 |  |  |  | - |  |
| Settlement of income tax audit |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 0.08 |  |  |  | 0.15 |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.55 |  |  | $ | 0.70 |  |  | $ | 0.65 |  |  | $ | 2.13 |  |  | $ | 2.70 |  |

[0001102624-16-002862:8k_2_02:71]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY16 |  |  | Q3'FY16 |  |  | Q4'FY15 |  |  | FY2016 |  |  | FY2015 |  |
| Gross margin-GAAP |  |  | 59.3 | % |  |  | 61.7 | % |  |  | 60.7 | % |  |  | 60.8 | % |  |  | 62.6 | % |
| Cost of revenues adjustments |  |  | 1.8 | % |  |  | 1.4 | % |  |  | 1.3 | % |  |  | 1.7 | % |  |  | 1.4 | % |
| Gross margin-Non-GAAP |  |  | 61.1 | % |  |  | 63.1 | % |  |  | 62.0 | % |  |  | 62.5 | % |  |  | 64.0 | % |
| GAAP cost of revenues |  | $ | 562 |  |  | $ | 531 |  |  | $ | 605 |  |  | $ | 2,173 |  |  | $ | 2,290 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (20 | ) |  |  | (13 | ) |  |  | (16 | ) |  |  | (61 | ) |  |  | (63 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (6 | ) |  |  | (5 | ) |  |  | (24 | ) |  |  | (22 | ) |
| Asset impairment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (11 | ) |  |  | - |  |
| Non-GAAP cost of revenues |  | $ | 537 |  |  | $ | 512 |  |  | $ | 584 |  |  | $ | 2,077 |  |  | $ | 2,205 |  |
| Net revenues |  | $ | 1,380 |  |  | $ | 1,386 |  |  | $ | 1,540 |  |  | $ | 5,546 |  |  | $ | 6,123 |  |

[0001102624-16-002862:8k_2_02:72]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY16 |  |  | Q3'FY16 |  |  | Q4'FY15 |  |  | FY2016 |  |  | FY2015 |  |
| Product gross margin-GAAP |  |  | 44.0 | % |  |  | 49.2 | % |  |  | 51.7 | % |  |  | 47.8 | % |  |  | 54.7 | % |
| Cost of product revenues adjustments |  |  | 2.8 | % |  |  | 1.9 | % |  |  | 1.8 | % |  |  | 2.4 | % |  |  | 1.8 | % |
| Product gross margin-Non-GAAP |  |  | 46.8 | % |  |  | 51.1 | % |  |  | 53.4 | % |  |  | 50.2 | % |  |  | 56.5 | % |
| GAAP cost of product revenues |  | $ | 424 |  |  | $ | 381 |  |  | $ | 441 |  |  | $ | 1,558 |  |  | $ | 1,657 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (20 | ) |  |  | (13 | ) |  |  | (15 | ) |  |  | (61 | ) |  |  | (61 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |  |  | (5 | ) |  |  | (6 | ) |
| Asset impairment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (5 | ) |  |  | - |  |
| Non-GAAP cost of product revenues |  | $ | 403 |  |  | $ | 367 |  |  | $ | 425 |  |  | $ | 1,487 |  |  | $ | 1,591 |  |
| Product revenues |  | $ | 757 |  |  | $ | 750 |  |  | $ | 914 |  |  | $ | 2,986 |  |  | $ | 3,655 |  |

[0001102624-16-002862:8k_2_02:73]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY16 |  |  | Q3'FY16 |  |  | Q4'FY15 |  |  | FY2016 |  |  | FY2015 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 66.8 | % |  |  | 64.9 | % |  |  | 61.6 | % |  |  | 64.1 | % |  |  | 62.0 | % |
| Cost of hardware maintenance and other services revenues adjustments |  |  | 1.0 | % |  |  | 1.2 | % |  |  | 1.0 | % |  |  | 1.6 | % |  |  | 1.2 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 67.9 | % |  |  | 66.2 | % |  |  | 62.6 | % |  |  | 65.7 | % |  |  | 63.1 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 129 |  |  | $ | 141 |  |  | $ | 154 |  |  | $ | 578 |  |  | $ | 597 |  |
| Cost of hardware maintenance and other services revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | - |  |  |  | - |  |  |  | (1 | ) |  |  | - |  |  |  | (2 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (5 | ) |  |  | (4 | ) |  |  | (19 | ) |  |  | (16 | ) |
| Asset impairment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (6 | ) |  |  | - |  |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 125 |  |  | $ | 136 |  |  | $ | 150 |  |  | $ | 553 |  |  | $ | 579 |  |
| Hardware maintenance and other services revenues |  | $ | 389 |  |  | $ | 402 |  |  | $ | 399 |  |  | $ | 1,611 |  |  | $ | 1,569 |  |

[0001102624-16-002862:8k_2_02:74]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q4'FY16 |  |  | Q3'FY16 |  |  | Q4'FY15 |  |  | FY2016 |  |  | FY2015 |  |
| GAAP effective tax rate |  |  | 113.3 | % |  |  | 6.1 | % |  |  | 17.8 | % |  |  | 33.6 | % |  |  | 21.5 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | (64.9 | %) |  |  | 8.8 | % |  |  | (1.1 | %) |  |  | (6.6 | %) |  |  | (0.3 | %) |
| Income tax expenses from integration of intellectual properties from acquisitions |  |  | (35.4 | %) |  |  | - | % |  |  | - | % |  |  | (8.6 | %) |  |  | - | % |
| Settlement of income tax audit |  |  | - | % |  |  | - | % |  |  | - | % |  |  | (3.1 | %) |  |  | (4.6 | %) |
| Non-GAAP effective tax rate |  |  | 13.1 | % |  |  | 14.9 | % |  |  | 16.7 | % |  |  | 15.4 | % |  |  | 16.5 | % |

[0001102624-16-002862:8k_2_02:75]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q4'FY16 |  |  | Q3'FY16 |  |  | Q4'FY15 |  |  | FY2016 |  |  | FY2015 |  |
| Net cash provided by operating activities |  | $ | 345 |  |  | $ | 355 |  |  | $ | 396 |  |  | $ | 974 |  |  | $ | 1,268 |  |
| Purchases of property and equipment |  |  | (35 | ) |  |  | (41 | ) |  |  | (37 | ) |  |  | (160 | ) |  |  | (175 | ) |
| Free cash flow |  | $ | 310 |  |  | $ | 314 |  |  | $ | 359 |  |  | $ | 814 |  |  | $ | 1,093 |  |

[0001102624-16-002862:8k_2_02:76]
| INVENTORY TURNS AND RECONCILIATION OF NON-GAAP TO GAAP |
| COST OF REVENUES USED IN INVENTORY TURNS |
| (In millions, except annualized inventory turns) |
|  |  | Q4'FY16 |  |  | Q3'FY16 |  |  | Q4'FY15 |  |  |
| Annualized inventory turns-GAAP |  |  | 23 |  |  |  | 21 |  |  |  | 17 |  |  |
| Cost of revenues adjustments |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |  |
| Annualized inventory turns-Non-GAAP |  |  | 22 |  |  |  | 20 |  |  |  | 16 |  |  |
| GAAP cost of revenues |  | $ | 562 |  |  | $ | 531 |  |  | $ | 605 |  |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (20 | ) |  |  | (13 | ) |  |  | (16 | ) |  |
| Stock-based compensation |  |  | (5 | ) |  |  | (6 | ) |  |  | (5 | ) |  |
| Non-GAAP cost of revenues |  | $ | 537 |  |  | $ | 512 |  |  | $ | 584 |  |  |
| Inventory |  | $ | 98 |  |  | $ | 102 |  |  | $ | 146 |  |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001102624-16-002862:8k_2_02:77]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| FIRST QUARTER FISCAL 2017 |  |
|  |  | First Quarter |  |
|  |  | Fiscal 2017 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $ | 0.34 - $0.39 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the First Quarter Fiscal 2017: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.04 | ) |
| Stock-based compensation expense |  |  | (0.20 | ) |
| Restructuring and other charges |  |  | (0.01 | ) |
| Income tax effect of non-GAAP adjustments |  |  | 0.04 |  |
| Total Adjustments |  |  | (0.21 | ) |
| GAAP Guidance - Net Income Per Share |  | $ | 0.13 - $0.18 |  |

## item 5.02 — body, verbatim

[0001102624-16-002862:8k_body:1]
Item 5.02.    Departure of Directors or Principal Officers; Election of Directors; Appointment of Principal Officers.

[0001102624-16-002862:8k_body:2]
(c), (d)

[0001102624-16-002862:8k_body:3]
Appointment of President

[0001102624-16-002862:8k_body:4]
On May 20, 2016, the board of directors (the "Board") of the Company appointed George Kurian to the additional role of President of the Company. Mr. Kurian's title is now Chief Executive Officer and President.

[0001102624-16-002862:8k_body:5]
Appointment of New Director

[0001102624-16-002862:8k_body:6]
On May 20, 2016, the Board approved an increase in the number of authorized directors on the Board from nine (9) to ten (10) and appointed Stephen M. Smith as a member of the Board to fill the vacancy created thereby.

[0001102624-16-002862:8k_body:7]
There are no arrangements or understandings between Mr. Smith, on the one hand, and the Company or any other persons, on the other hand, pursuant to which Mr. Smith was selected as a director. There are no related party transactions between the Company and Mr. Smith (or any immediate family member thereof) requiring disclosure under Item 404(a) of Regulation S-K. Mr. Smith does not have any family relationships with any of the Company's directors or executive officers.

[0001102624-16-002862:8k_body:8]
As a non-employee director, Mr. Smith will participate in the non-employee director compensation arrangements described in the Company's definitive proxy statement filed with the Securities and Exchange Commission on July 27, 2015. In addition, it is expected that he will enter into the Company's standard form of director indemnification agreement. The form of the indemnification agreement was filed as Exhibit 10.1 to the Company's Quarterly Report on Form 10-Q for the period ended July 25, 2014, as filed with the SEC on August 28, 2014.

[0001102624-16-002862:8k_body:9]
A copy of the Company's press release announcing the appointment of Mr. Smith to the Board is attached hereto as Exhibit 99.2 and the information set forth therein is incorporated herein by reference.
