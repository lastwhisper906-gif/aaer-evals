# NTAP MD&A — 0001564590-16-020754


## mdna

[0001564590-16-020754:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001564590-16-020754:mdna:2]
The following discussion of our financial condition and results of operations should be read together with the financial statements and the accompanying notes set forth under Item 8. – Financial Statements and Supplementary Data. The following discussion also contains trend information and other forward-looking statements that involve a number of risks and uncertainties. The Risk Factors set forth in Item 1A. – Risk Factors are hereby incorporated into the discussion by reference.

[0001564590-16-020754:mdna:3]
Executive Overview

[0001564590-16-020754:mdna:4]
Our Company

[0001564590-16-020754:mdna:5]
We are a leading global provider of software, systems and services to manage and store customer data. We enable enterprises, service providers, governmental organizations, and partners to envision, deploy and evolve their information technology (IT) environments and to reduce costs and risk while driving growth and success for their organizations.

[0001564590-16-020754:mdna:6]
Data management on the hybrid cloud today is essentially a series of isolated siloes. IT organizations need to harmonize the management of data across all cloud providers, as well as on premises. This is what we call the Data Fabric. Our Data Fabric strategy defines the NetApp technology architecture for hybrid cloud. We offer solutions that help customers seamlessly manage their data across their diverse IT resources, spanning flash, disk, and cloud. Customers have the flexibility to choose the right set of resources to meet the needs of their applications and the freedom to change them whenever they want. Customers are entirely in control of their data, regardless of the cloud that it sits on, regardless of the landscape in which it is deployed.

[0001564590-16-020754:mdna:7]
Our data management and storage offerings help improve business productivity, performance and profitability, while providing investment protection and enhanced asset utilization. We complement our enterprise-class storage solutions with services expertise that maximizes the business benefits our customers gain from deploying our products. In fiscal 2016, we focused on our Data Fabric strategy and the strategic solutions that form the foundation of how we enable customer success in the data-powered digital era.

[0001564590-16-020754:mdna:8]
Our unified scale-out fabric-attached storage (FAS) platform is designed to meet the demanding requirements of shared infrastructures and cloud environments. Our FAS storage platform uses the NetApp Data ONTAP storage operating system to deliver integrated data protection, comprehensive data management, and built-in efficiency software for virtualized, shared infrastructures, cloud computing, and mixed workload business applications. We offer hybrid and all-flash configurations of both FAS and E-Series platforms. Our E-Series high-performance storage area network platform is designed to meet demanding performance and capacity requirements of dedicated workloads, while retaining simplicity and an optimized price to performance ratio.

[0001564590-16-020754:mdna:9]
In February 2016, NetApp completed the acquisition of all-flash startup company SolidFire, Inc., which when combined with our existing all-flash offerings, allows us to offer the industry’s broadest portfolio of all-flash solutions. SolidFire systems target a new class of customer who is masterminding the next-generation data center and wants cloud-like capabilities from their on-premises storage for greater flexibility. These users place a priority on the ability to scale simply and seamlessly.

[0001564590-16-020754:mdna:10]
Our configured systems consist of (1) entry level product platform, which consists of our FAS2000 systems, (2) mid-range product platform, which consists of our legacy FAS3000 systems and our new FAS8020 and FAS8040 systems, and (3) high-end product platform, which consists of our legacy FAS6000 systems and our new FAS8060 and FAS8080 systems.

[0001564590-16-020754:mdna:11]
In addition to our products, we provide a variety of services including software maintenance, hardware maintenance and other services including professional services, global support solutions, and customer education and training to help customers most effectively manage their data.

[0001564590-16-020754:mdna:12]
We employ a multichannel distribution strategy, selling products and services to end users and service providers through a direct sales force and through channel partners, including value-added resellers, system integrators, original equipment manufacturers (OEMs) and distributors.

[0001564590-16-020754:mdna:13]
30

[0001564590-16-020754:mdna:14]
Financial Results and Key Performance Metrics Overview

[0001564590-16-020754:mdna:15]
The following table provides an overview of some of our key financial metrics for each of the last three fiscal years (in millions, except per share amounts, percentages and days sales outstanding):

[0001564590-16-020754:mdna:16]
|  |  | Year Ended |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |
| Net revenues |  | $ | 5,546 |  |  | $ | 6,123 |  |  | $ | 6,325 |  |
| Gross profit |  | $ | 3,373 |  |  | $ | 3,833 |  |  | $ | 3,919 |  |
| Gross profit margin percentage |  |  | 61 | % |  |  | 63 | % |  |  | 62 | % |
| Income from operations |  | $ | 348 |  |  | $ | 716 |  |  | $ | 734 |  |
| Income from operations as a percentage of net revenues |  |  | 6 | % |  |  | 12 | % |  |  | 12 | % |
| Net income |  | $ | 229 |  |  | $ | 560 |  |  | $ | 638 |  |
| Diluted net income per share |  | $ | 0.77 |  |  | $ | 1.75 |  |  | $ | 1.83 |  |
| Operating cash flows |  | $ | 974 |  |  | $ | 1,268 |  |  | $ | 1,350 |  |

[0001564590-16-020754:mdna:17]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,385 |  |  | $ | 3,197 |  |
| Days sales outstanding (DSO) |  |  | 54 |  |  |  | 46 |  |

[0001564590-16-020754:mdna:18]
|  | · | Net revenues: Our net revenues decreased 9% in fiscal 2016 compared to fiscal 2015. This was primarily due to a decrease of 18% in product revenues, which included the impact of foreign currency exchange rate changes, partially offset by a 4% increase in software and hardware maintenance and other services revenues. |

[0001564590-16-020754:mdna:19]
|  | · | Gross profit margin percentage: Our gross profit margin as a percentage of net revenues decreased in fiscal 2016 compared to fiscal 2015 primarily due to a decline in Average Selling Prices (ASPs) largely due to higher discounting and product promotions. |

[0001564590-16-020754:mdna:20]
|  | · | Income from operations as a percentage of net revenues: Our income from operations as a percentage of net revenues decreased in fiscal 2016 compared to fiscal 2015 primarily due to lower product gross margin and restructuring charges. |

[0001564590-16-020754:mdna:21]
|  | · | Net income and Diluted income per share: The 59% and 56% decreases in net income and diluted net income per share, respectively, in fiscal 2016 compared to fiscal 2015 reflect the factors discussed above, as well as an increase in our effective tax rate of 12 percentage points. Partially offsetting these factors, diluted net income per share was favorably impacted by a 7% decrease in the annual weighted average number of dilutive shares, primarily due to share repurchases throughout the year. |

[0001564590-16-020754:mdna:22]
|  | · | Operating cash flows: Operating cash flows decreased $294 million in fiscal 2016, primarily due to lower net income. |

[0001564590-16-020754:mdna:23]
|  | · | Deferred revenue and financed unearned services revenue: Total deferred revenue and financed unearned services revenue increased $188 million, or 6%, in fiscal 2016 compared to fiscal 2015 primarily due to higher software and hardware maintenance contract renewals. |

[0001564590-16-020754:mdna:24]
|  | · | DSO: Days Sales Outstanding (DSO) were 54 in the fourth quarter of fiscal 2016 compared to 46 in the fourth quarter of fiscal 2015 reflecting a higher level of orders in the last month of the fourth quarter in fiscal 2016 than in fiscal 2015. |

[0001564590-16-020754:mdna:25]
Acquisition of SolidFire

[0001564590-16-020754:mdna:26]
On February 2, 2016, we acquired all of the outstanding shares of privately-held SolidFire, Inc. (“SolidFire”), a maker of all-flash storage systems based in Colorado, for $850 million in cash. This acquisition extends our position in the all-flash array market by adding new flash offerings that will enhance our ability to deliver customers all-flash storage with a webscale architecture that simplifies data center operations and enables rapid deployments of new applications. In connection with this acquisition, we entered into an $870 million short-term loan that we expect to repay in full with our global earnings by the beginning of our third quarter of fiscal 2017.

[0001564590-16-020754:mdna:27]
Stock Repurchase Program and Dividend Activity

[0001564590-16-020754:mdna:28]
During fiscal 2016, we repurchased 33 million shares of our common stock at an average price of $28.80 per share, for an aggregate of $960 million. We also declared cash dividends of an aggregate of $0.72 per share in fiscal 2016, for which we paid an aggregate of $210 million.

[0001564590-16-020754:mdna:29]
31

[0001564590-16-020754:mdna:30]
Restructuring Events

[0001564590-16-020754:mdna:31]
In February 2016, we committed to a restructuring and reduction in workforce to streamline our business and reduce operating expenses. In connection with these actions, we reduced our worldwide headcount by approximately 11%, and incurred $80 million of employee severance charges in the fourth quarter of fiscal 2016. The reduction in workforce will be executed through the end of the second quarter of fiscal 2017.

[0001564590-16-020754:mdna:32]
In May 2015, we committed to a restructuring event and reduction in workforce of approximately 3% of our worldwide headcount, for which we recognized charges of $28 million, primarily in the first quarter of fiscal 2016. These activities were substantially completed in the second quarter of fiscal 2016.

[0001564590-16-020754:mdna:33]
Real Estate Transactions

[0001564590-16-020754:mdna:34]
On April 19, 2016, we sold certain buildings and land in Sunnyvale, California which had a net book value of $118 million at the time of sale, for $250 million in cash. Certain of the properties did not qualify as sales under accounting standards due to continuing involvement related to leaseback arrangements. The remaining properties, which had a net book value of $51 million and related sales proceeds of $102 million, were recognized as sales, resulting in a gain of $51 million.

[0001564590-16-020754:mdna:35]
Critical Accounting Policies and Estimates

[0001564590-16-020754:mdna:36]
Our consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (GAAP), which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and liabilities. Our estimates are based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0001564590-16-020754:mdna:37]
The summary of significant accounting policies is included in Note 1 – Description of Business and Significant Accounting Policies of the Notes to Consolidated Financial Statements. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. The accounting policies described below reflect the significant judgments, estimates and assumptions used in the preparation of the consolidated financial statements.

[0001564590-16-020754:mdna:38]
Revenue Recognition, Reserves and Allowances

[0001564590-16-020754:mdna:39]
We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable and collection is reasonably assured. Revenue from the sale of hardware systems and software components essential to the functionality of the hardware systems is recognized in accordance with general revenue recognition accounting guidance. Our product revenues also include revenues from the sale of non-essential software products, which generally includes a perpetual license to our software. Non-essential software sales are subject to industry specific software revenue recognition accounting guidance. Software maintenance and hardware maintenance services revenues are recognized ratably over their contractual terms, generally from one to five years.

[0001564590-16-020754:mdna:40]
For multiple element arrangements, we allocate revenue to the software deliverables and the non-software deliverables as a group based on the relative selling prices of all of the deliverables in the arrangement. For our non-software deliverables, we allocate the arrangement consideration based on the relative selling price of the deliverables using estimated selling price (ESP). For our software maintenance services, we generally use vendor-specific objective evidence of selling price (VSOE). When we are unable to establish VSOE for our software maintenance services, we use ESP in our allocation of arrangement consideration.

[0001564590-16-020754:mdna:41]
The selling price for each element is based upon the following selling price hierarchy: VSOE if available, third party evidence (TPE) if VSOE is not available, or ESP if neither VSOE nor TPE are available. Generally, we are not able to determine TPE because our go-to-market strategy differs from that of our peers and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained.

[0001564590-16-020754:mdna:42]
We record reductions to revenue for estimated sales returns at the time of shipment. We also maintain a separate allowance for doubtful accounts for estimated losses based on our assessment of the collectability of specific customer accounts.

[0001564590-16-020754:mdna:43]
32

[0001564590-16-020754:mdna:44]
The following are the key estimates and assumptions and corresponding uncertainties for recognizing revenue:

[0001564590-16-020754:mdna:45]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| · | We establish VSOE of selling price using the price charged for a deliverable when sold separately and generally evidenced by a substantial majority of historical stand-alone transactions falling within a reasonably narrow range. In addition, we consider major service type, customer type, and other variables in determining VSOE. Our revenue estimates and assumptions are based on our ability to assert and maintain VSOE. ESP is generally evidenced by a majority of historical transactions falling within a reasonable price range. We also consider multiple factors, including, but not limited to, cost of products, gross margin objectives, historical pricing practices, customer type and distribution channels. Our revenue estimates and assumptions are based on our ability to maintain consistent ESP. |  | · | As our business and offerings evolve over time, modifications to our pricing and discounting methodologies, changes in the scope and nature of service offerings and/or changes in customer segmentation may result in a lack of consistency required to establish and/or maintain VSOE or to maintain consistent ESP. Additionally, technological changes resulting in variability in product costs and gross margins may require changes to our ESP model. Changes in ESP may result in a different allocation of revenue to the deliverables in multiple-element arrangements. These factors, among others, may adversely impact the amount of revenue and gross margin we report in a particular period. |
| · | Sales returns are estimated based on historical sales returns, current trends and our expectations regarding future experience. Additionally, distributors and partners participate in various marketing and other programs, and we maintain estimated accruals and allowances for these programs based on contractual terms and historical experience. |  | · | If there is insufficient relevant historical data for determining our sales returns estimates, or if we experience changes in practices related to sales returns or changes in market or competitive conditions resulting in higher than expected return rates, or if actual credits received by our distributors and partners deviate significantly from our estimates, our revenues may be adversely impacted. |

[0001564590-16-020754:mdna:46]
Inventory Valuation and Purchase Order Accruals

[0001564590-16-020754:mdna:47]
Inventories consist primarily of purchased components and finished goods and are stated at the lower of cost or market, which approximates actual cost on a first-in, first-out basis. A provision is recorded when inventory is determined to be in excess of anticipated demand or obsolete in order to adjust inventory to its estimated realizable value. The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our inventories:

[0001564590-16-020754:mdna:48]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| · | We periodically perform an excess and obsolete analysis of our inventory. Inventories are written down based on excess and obsolete reserves determined primarily on assumptions about future demand forecasts and market conditions. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. |  | · | Although we use our best estimates to forecast future product demand, any significant unanticipated changes in demand or obsolescence related to technological developments, new product introductions, customer requirements, competition or other factors could have a significant impact on the valuation of our inventory. If actual market conditions are less favorable than those projected, additional write-downs and other charges against earnings that adversely impact gross margins may be required. If actual market conditions are more favorable, we may realize higher gross profits in the period when the written-down inventory is sold. We are subject to a variety of environmental laws relating to the manufacture of our products. If there are changes to the current regulations, we may be required to make product design changes which may result in excess or obsolete inventory, which could adversely impact our operating results. |
| · | We make commitments to our third-party contract manufacturers and other suppliers to manage lead times and meet product forecasts and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on non-cancelable purchase commitments when we believe it is probable that the components will not be utilized in future operations. |  | · | If the actual materials demand is significantly lower than our forecast, we may be required to increase our recorded liabilities for estimated losses on non-cancelable purchase commitments which would adversely impact our operating results. |

[0001564590-16-020754:mdna:49]
33

[0001564590-16-020754:mdna:50]
Goodwill and Purchased Intangible Assets

[0001564590-16-020754:mdna:51]
We allocate the purchase price of acquisitions to identifiable assets acquired and liabilities assumed at their acquisition date fair values based on established valuation techniques. Goodwill represents the residual value as of the acquisition date, which in most cases is measured as the excess of the purchase consideration transferred over the net of the acquisition date fair values of the assets acquired and liabilities assumed.

[0001564590-16-020754:mdna:52]
The carrying values of purchased intangible assets are reviewed whenever events and circumstances indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. We periodically review the estimated remaining useful lives of our intangible assets. This review may result in impairment charges or shortened useful lives, resulting in charges to our consolidated statements of operations.

[0001564590-16-020754:mdna:53]
We review goodwill for impairment annually and whenever events or changes in circumstances indicate the carrying amount of a reporting unit may be less than its fair value. The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. For our annual goodwill impairment test in the fourth quarter of fiscal 2016, we performed a quantitative test at the reporting unit level and determined the fair value substantially exceeded the carrying amount of each reporting unit and, therefore, found no impairment of goodwill.

[0001564590-16-020754:mdna:54]
The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our goodwill and purchased intangible assets:

[0001564590-16-020754:mdna:55]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| · | The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the accounting guidance for the fair value measurement of nonfinancial assets. The valuation of purchased intangible assets is principally based on estimates of the future performance and cash flows expected to be generated by the acquired assets from the acquired business. |  | · | While we employ experts to determine the acquisition date fair value of acquired intangibles, the fair values of assets acquired and liabilities assumed are based on significant management assumptions and estimates, which are inherently uncertain and highly subjective and as a result, actual results may differ from estimates. If different assumptions were to be used, it could materially impact the purchase price allocation. |
| · | Evaluations of possible goodwill and purchased intangible assets impairment require us to make judgments and assumptions related to the allocation of our balance sheet and income statement amounts and estimate future cash flows and fair market values of our reporting units and assets. |  | · | In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill or purchased intangible assets. Assumptions and estimates about expected future cash flows and the fair values of our goodwill and purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as the adverse impact of unanticipated changes in macroeconomic conditions and technological changes or new product introductions from competitors. They can also be affected by internal factors such as changes in business strategy or in forecasted product life cycles and roadmaps. Our ongoing consideration of these and other factors could result in future impairment charges or accelerated amortization expense, which could adversely affect our operating results. |

[0001564590-16-020754:mdna:56]
Product Warranties

[0001564590-16-020754:mdna:57]
Estimated future hardware and software warranty costs are recorded as a cost of product revenues at the time of product shipment. We assess the adequacy of our warranty accrual each quarter and adjust the amount as considered necessary.

[0001564590-16-020754:mdna:58]
The following are the key estimates and assumptions and corresponding uncertainties for product warranties:

[0001564590-16-020754:mdna:59]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| · | Estimated future software and hardware warranty costs are based on historical and projected warranty claim rates, product failure rates, historical and projected materials and logistics costs, distribution and labor costs and knowledge of specific product failures that are outside of our typical experience. We also evaluate our estimates to assess the adequacy of our warranty liability considering the size of the installed base of products subject to warranty protection and adjust the estimates as necessary. |  | · | Although we engage in product quality programs and processes, if we experience unexpected quality issues resulting in higher failure rates or experience increases in costs to remediate product failures, additional warranty costs may be incurred. Additionally, for new products our warranty liability is based on limited historical experience. If our projections differ from such limited experience, our warranty costs may increase, which could adversely impact our gross margins. |

[0001564590-16-020754:mdna:60]
Valuation of Investment Securities

[0001564590-16-020754:mdna:61]
Our investments in debt securities are reported at fair value and are subject to periodic impairment review. Unrealized gains and losses related to changes in the fair value of these securities are recognized in accumulated other comprehensive income, net of tax, unless they are determined to be other-than-temporary impairments. The ultimate value realized on these securities is subject to market price volatility until they are sold.

[0001564590-16-020754:mdna:62]
The following are the key estimates and assumptions and corresponding uncertainties for the valuation of our investment securities:

[0001564590-16-020754:mdna:63]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| · | The estimated fair value of our debt securities, and the associated accounting for unrealized losses is based on an evaluation of current economic and market conditions, the credit rating of the security’s issuer, the length of time and extent the security’s fair value has been below its amortized cost and our ability and intent to hold the security for a period of time sufficient to allow for anticipated recovery in value. If we determine that an investment has an other-than-temporary decline in fair value, we recognize the investment loss in earnings. |  | · | The fair value of our investments in debt securities could decrease significantly from uncertainties in the credit and capital markets, credit rating downgrades and/or solvency of the issuer, decreases in the marketability of the securities or changes in our ability and intent to continue to hold the securities. If the fair value of our investments decreases significantly and is determined to be other-than-temporary, we may incur impairment charges that could adversely affect our results of operations. |

[0001564590-16-020754:mdna:64]
35

[0001564590-16-020754:mdna:65]
Income Taxes

[0001564590-16-020754:mdna:66]
We are subject to income taxes in the United States and numerous foreign jurisdictions. We compute our provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0001564590-16-020754:mdna:67]
The following are the key estimates and assumptions and corresponding uncertainties for our income taxes:

[0001564590-16-020754:mdna:68]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
| · | Our income tax provision is based on existing tax law and advanced pricing agreements or letter rulings we have with various tax authorities. |  | · | Our provision for income taxes is subject to volatility and could be adversely impacted by future changes in existing tax laws, such as a change in tax rate, possible U.S. changes to the taxation of earnings of our foreign subsidiaries, and uncertainties as to future renewals of favorable tax agreements and rulings. |
| · | Deferred income taxes have not been provided on the undistributed earnings of foreign subsidiaries because these earnings have been indefinitely reinvested and there is no plan in the foreseeable future to initiate any action that would precipitate the payment of income taxes thereon. |  | · | We consider the following matters, among others, in evaluating our plans for indefinite reinvestment: the forecasts, budgets and financial requirements of the parent and subsidiaries for both the long and short term; the tax consequences of a decision to reinvest; and any U.S. and foreign government programs designed to influence remittances. If factors change, future income tax expense and payments may differ significantly from the current period and could materially adversely affect our results of operations. |
| · | The determination of whether we should record or adjust a valuation allowance against our deferred tax assets is based on assumptions regarding our future profitability. |  | · | Our future profits could differ from current expectations resulting in a change to our determination as to the amount of deferred tax assets that are more likely than not to be realized. We could adjust our valuation allowance with a corresponding impact to the tax provision in the period in which such determination is made. |
| · | The estimates for our uncertain tax positions are based primarily on company specific circumstances, applicable tax laws, tax opinions from outside firms and past results from examinations of our income tax returns. |  | · | Significant judgment is required in evaluating our uncertain tax positions. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome or tax court rulings of these matters will not be different from that which is reflected in our historical tax provisions and accruals. |

[0001564590-16-020754:mdna:69]
New Accounting Standards

[0001564590-16-020754:mdna:70]
See Note 3 – Recent Accounting Standards Not Yet Effective of the Notes to Consolidated Financial Statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on our financial statements.

[0001564590-16-020754:mdna:71]
36

[0001564590-16-020754:mdna:72]
Results of Operations

[0001564590-16-020754:mdna:73]
Our fiscal year is reported on a 52- or 53-week year that ends on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Our fiscal year 2016 ended on April 29, 2016 and was a 53-week year. Our fiscal years 2015 and 2014 ended on April 24, 2015 and April 25, 2014, respectively, and were each 52-week years. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0001564590-16-020754:mdna:74]
The following table sets forth certain Consolidated Statements of Operations data as a percentage of net revenues for the periods indicated:

[0001564590-16-020754:mdna:75]
|  |  | Year Ended |  |  |
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |  | April 25, 2014 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 54 |  | % |  | 60 |  | % |  | 62 |  | % |
| Software maintenance |  |  | 17 |  |  |  | 15 |  |  |  | 14 |  |  |
| Hardware maintenance and other services |  |  | 29 |  |  |  | 26 |  |  |  | 23 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 28 |  |  |  | 27 |  |  |  | 28 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | 1 |  |  |  | — |  |  |
| Cost of hardware maintenance and other services |  |  | 10 |  |  |  | 10 |  |  |  | 9 |  |  |
| Gross profit |  |  | 61 |  |  |  | 63 |  |  |  | 62 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 32 |  |  |  | 31 |  |  |  | 30 |  |  |
| Research and development |  |  | 16 |  |  |  | 15 |  |  |  | 15 |  |  |
| General and administrative |  |  | 6 |  |  |  | 5 |  |  |  | 4 |  |  |
| Restructuring and other charges |  |  | 2 |  |  |  | — |  |  |  | 1 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Gain on sale of properties |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |
| Total operating expenses |  |  | 55 |  |  |  | 51 |  |  |  | 50 |  |  |
| Income from operations |  |  | 6 |  |  |  | 12 |  |  |  | 12 |  |  |
| Other income (expense), net |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Income before income taxes |  |  | 6 |  |  |  | 12 |  |  |  | 12 |  |  |
| Provision for income taxes |  |  | 2 |  |  |  | 2 |  |  |  | 2 |  |  |
| Net income |  |  | 4 |  | % |  | 9 |  | % |  | 10 |  | % |

[0001564590-16-020754:mdna:76]
Percentages may not add due to rounding

[0001564590-16-020754:mdna:77]
Discussion and Analysis of Results of Operations

[0001564590-16-020754:mdna:78]
Overview — Net revenues for fiscal 2016 were $5,546 million, a decrease of $577 million, or 9%, compared to fiscal 2015, reflecting lower product revenues, partially offset by an increase in software and hardware maintenance and other services revenues. Net revenues for fiscal 2015 were $6,123 million, down $202 million, or 3%, compared to fiscal 2014, reflecting a decrease in product and software maintenance revenues, partially offset by an increase in hardware maintenance and other services revenues.

[0001564590-16-020754:mdna:79]
Gross profit as a percentage of net revenues decreased 2 percentage points during fiscal 2016 compared to fiscal 2015, reflecting lower margins on product revenues. Gross profit margins on product revenues in fiscal 2016 decreased compared to fiscal 2015 primarily due to higher discounting and product promotions which resulted in the decline in ASPs that outpaced the decline in unit materials costs. Gross profit as a percentage of net revenues increased 1 percentage point during fiscal 2015 compared to fiscal 2014, reflecting higher gross margins on hardware maintenance contract and other services revenues. Gross profit margins on product revenues in fiscal 2015 were relatively flat compared to fiscal 2014 primarily due to lower ASPs for configured systems being offset by lower unit materials cost due to changes in product mix.

[0001564590-16-020754:mdna:80]
Sales and marketing, research and development, and general and administrative expenses for fiscal 2016 totaled $2,960 million, an increase of 3 percentage points as a percentage of net revenues compared to fiscal 2015, primarily due to a lower revenue denominator, partially offset by the benefits of our cost reduction initiatives. Sales and marketing, research and development, and general and administrative expenses for fiscal 2015 totaled $3,117 million, up 2 percentage points as a percentage of net revenues compared to fiscal 2014, primarily due to a slight decrease in costs on a lower revenue denominator.

[0001564590-16-020754:mdna:81]
37

[0001564590-16-020754:mdna:82]
Net Revenues (in millions, except percentages):

[0001564590-16-020754:mdna:83]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2014 |  |  | % Change |  |
| Net revenues |  | $ | 5,546 |  |  | $ | 6,123 |  |  |  | (9 | )% |  | $ | 6,325 |  |  |  | (3 | )% |

[0001564590-16-020754:mdna:84]
The decrease in net revenues for fiscal 2016 was primarily due to a decrease of $669 million in product revenues, partially offset by $92 million increase in total software maintenance and hardware maintenance and other services revenues. Product revenues comprised 54% of net revenues for fiscal 2016, compared to 60% of net revenues for fiscal 2015.

[0001564590-16-020754:mdna:85]
The decrease in net revenues for fiscal 2015 was primarily due to a reduction of $289 million in product revenues, partially offset by $103 million increase in hardware maintenance and other services revenues. Product revenues comprised 60% of net revenues for fiscal 2015, compared to 62% of net revenues for fiscal 2014.

[0001564590-16-020754:mdna:86]
Sales through our indirect channels represented 77%, 78% and 79% of net revenues in fiscal 2016, 2015 and 2014, respectively.

[0001564590-16-020754:mdna:87]
The following customers, each of which is a distributor, accounted for 10% or more of net revenues:

[0001564590-16-020754:mdna:88]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 23 | % |  |  | 22 | % |
| Avnet, Inc. |  |  | 19 | % |  |  | 16 | % |  |  | 16 | % |

[0001564590-16-020754:mdna:89]
Product Revenues (in millions, except percentages):

[0001564590-16-020754:mdna:90]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2014 |  |  | % Change |  |
| Product revenues |  | $ | 2,986 |  |  | $ | 3,655 |  |  |  | (18 | )% |  | $ | 3,944 |  |  |  | (7 | )% |

[0001564590-16-020754:mdna:91]
Product revenues consist of sales of configured systems, which include bundled hardware and software products, and non-configured products, which consist primarily of add-on storage, OEM products and add-on hardware and software products.

[0001564590-16-020754:mdna:92]
Total configured system revenues of $1,885 million decreased by $328 million, or 15%, and systems unit volume decreased by 3% in fiscal 2016, compared to fiscal 2015. Revenues and unit volume decreased from FAS entry level and mid-range systems, partially offset by an increase in revenues and unit volume from FAS high-end systems and E-Series systems (which include our all flash EF systems). ASPs decreased across all FAS systems and E-Series systems platforms due primarily to a combination of higher discounting and product promotions introduced in fiscal 2016. ASPs were also impacted by unfavorable foreign exchange rates, which had an unfavorable impact of approximately 4%, and unfavorable customer and product mix. As a result, overall ASPs of configured systems were lower in fiscal 2016 compared to fiscal 2015.

[0001564590-16-020754:mdna:93]
Non-configured product revenues of $1,101 million decreased by $341 million, or 24%, during fiscal 2016 compared to fiscal 2015. This decrease was primarily due to a decrease of 32% and 36% in add-on storage and OEM revenues, respectively. The decrease in add-on storage reflects higher discounting and unfavorable product mix, as well as the unfavorable impact of foreign exchange rates. The decrease in OEM revenues reflects our move away from OEM products.

[0001564590-16-020754:mdna:94]
Total configured system revenues of $2,213 million decreased by $74 million, or 3%, in fiscal 2015, compared to fiscal 2014. Revenues decreased in FAS entry level, mid-range and high-end systems, partially offset by an increase in E-Series systems. Total configured systems unit volume increased 5% primarily due to a unit volume increase in FAS mid-range, high-end systems and E-Series systems platforms, partially offset by a decrease in unit volume in FAS entry level systems. These changes in unit volume reflect a shift in customer demand to our newer FAS mid-range and high-end systems and higher demand for our E-Series systems, and away from our older FAS entry level systems. ASPs decreased across all FAS systems and E-Series systems platforms due to a combination of newer lower priced products within their respective platforms and unfavorable foreign exchange rates, which had an aggregate negative impact of approximately 2% on configured systems revenues in fiscal 2015 compared to fiscal 2014. As a result, overall ASPs of configured systems were lower in fiscal 2015 compared to fiscal 2014.

[0001564590-16-020754:mdna:95]
Non-configured product revenues of $1,442 million decreased by $215 million, or 13%, during fiscal 2015 compared to fiscal 2014. This decrease was primarily due to a decrease of 32% in add-on storage revenues and a decrease of 20% in OEM revenues, partially offset by a 133% increase in add-on software. The decrease in add-on storage and increase in add-on software are largely due to the change in our pricing strategy that was effective in the fourth quarter of fiscal 2014, whereby we now charge for operating system software for storage capacity but have lowered prices on storage hardware. Non-configured systems revenues were negatively impacted by 1% as a result of unfavorable foreign exchange rates in fiscal 2015, compared to fiscal 2014.

[0001564590-16-020754:mdna:96]
38

[0001564590-16-020754:mdna:97]
Our systems are highly configurable to respond to customer requirements in the open systems storage markets that we serve. This can cause a wide variation in product configurations that can significantly impact revenues, cost of revenues and gross profits. Pricing changes, discounting practices, product competition, foreign currency, unit volumes, customer mix, natural disasters and product materials costs can also impact revenues, cost of revenues and/or gross profits. Disk drive and flash storage materials are a significant component of our storage systems. While our sales price per terabyte historically declines over time, improved system performance, increased capacity and software to manage this increased capacity have an offsetting favorable impact on product revenues.

[0001564590-16-020754:mdna:98]
Software Maintenance Revenues (in millions, except percentages):

[0001564590-16-020754:mdna:99]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2014 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 949 |  |  | $ | 899 |  |  |  | 6 | % |  | $ | 915 |  |  |  | (2 | )% |

[0001564590-16-020754:mdna:100]
Software maintenance revenues are associated with contracts which entitle customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, bug fixes and patch releases, as well as internet and telephone access to technical support personnel located in our global support centers.

[0001564590-16-020754:mdna:101]
The fluctuations in software maintenance revenues reflect fluctuations in the aggregate contract value of the installed base under software maintenance contracts, which is recognized as revenue ratably over the terms of the underlying contracts. Our software maintenance revenues were favorably impacted by a change in our pricing strategy, effective in the fourth quarter of fiscal 2014, such that we now charge for software maintenance services on the storage capacity sold in our configured systems and add-on storage products. We expect this change to continue to result in favorable trends in our software maintenance revenues as a percentage of total revenues. Software maintenance revenues were also favorably impacted by the additional week of deferred revenue amortization in the first quarter of fiscal 2016.

[0001564590-16-020754:mdna:102]
Hardware Maintenance and Other Services Revenues (in millions, except percentages):

[0001564590-16-020754:mdna:103]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2014 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 1,611 |  |  | $ | 1,569 |  |  |  | 3 | % |  | $ | 1,466 |  |  |  | 7 | % |

[0001564590-16-020754:mdna:104]
Hardware maintenance and other services revenues include hardware maintenance, professional services and educational and training services revenues.

[0001564590-16-020754:mdna:105]
Hardware maintenance contract revenues were $1,316 million, $1,253 million and $1,130 million in fiscal 2016, 2015 and 2014, respectively. These revenues increased 5% during fiscal 2016 compared to fiscal 2015 and increased 11% during fiscal 2015 compared to fiscal 2014. These increases are a result of increases in the installed base and aggregate contract values under hardware maintenance contracts, due largely to higher levels of shorter term contract renewals from our existing contract base, as well as in fiscal 2016 the favorable impact of an additional week of deferred revenue amortization in the first quarter. Professional services and educational and training services revenues aggregated to $295 million, $317 million and $336 million in fiscal 2016, 2015 and 2014, respectively.

[0001564590-16-020754:mdna:106]
Revenues by Geographic Area:

[0001564590-16-020754:mdna:107]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| United States, Canada and Latin America (Americas) |  |  | 55 | % |  |  | 56 | % |  |  | 56 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 32 | % |  |  | 30 | % |  |  | 31 | % |
| Asia Pacific (APAC) |  |  | 13 | % |  |  | 13 | % |  |  | 14 | % |

[0001564590-16-020754:mdna:108]
Percentages may not add due to rounding

[0001564590-16-020754:mdna:109]
Americas revenues consist of sales to Americas commercial and United States (U.S.) public sector markets. During fiscal 2016, we experienced declining revenues in all geographic areas, with the largest percentage decline in the Americas U.S. public sector market. During fiscal 2015, Americas revenues were favorably impacted by an increase in revenues from U.S. public sector markets, but unfavorably impacted by lower Americas commercial revenues. EMEA revenues were unfavorably impacted by foreign exchange rates in fiscal 2015 compared to fiscal 2014. During fiscal 2014, Americas revenues were unfavorably impacted by a decrease in sales to the U.S. public sector market.

[0001564590-16-020754:mdna:110]
39

[0001564590-16-020754:mdna:111]
Cost of Revenues

[0001564590-16-020754:mdna:112]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping our storage products, amortization of purchased intangible assets, inventory write-downs, and warranty costs, (2) cost of software maintenance, which includes the costs of providing software maintenance and third-party royalty costs and (3) cost of hardware maintenance and other services revenues, which includes costs associated with providing support activities for hardware maintenance, global support partnership programs, professional services and educational and training services.

[0001564590-16-020754:mdna:113]
Cost of Product Revenues (in millions, except percentages):

[0001564590-16-020754:mdna:114]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2014 |  |  | % Change |  |
| Cost of product revenues |  | $ | 1,558 |  |  | $ | 1,657 |  |  |  | (6 | )% |  | $ | 1,777 |  |  |  | (7 | )% |

[0001564590-16-020754:mdna:115]
The changes in cost of product revenues consisted of the following (in percentage points of the total change):

[0001564590-16-020754:mdna:116]
|  |  | Fiscal 2016 to Fiscal 2015 |  |  | Fiscal 2015 to Fiscal 2014 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | (5 | ) |  |  | (5 | ) |
| Warranty |  |  | — |  |  |  | (2 | ) |
| Other |  |  | (1 | ) |  |  | — |  |
| Total change |  |  | (6 | ) |  |  | (7 | ) |

[0001564590-16-020754:mdna:117]
Cost of product revenues represented 52%, 45% and 45% of product revenues for fiscal 2016, 2015 and 2014, respectively.

[0001564590-16-020754:mdna:118]
Materials cost represented 85%, 85% and 84% of product costs for fiscal 2016, 2015 and 2014, respectively.

[0001564590-16-020754:mdna:119]
Materials cost decreased $85 million in fiscal 2016 compared to fiscal 2015. Materials costs were impacted by a decrease of 3% unit volume for configured systems in fiscal 2016 compared to fiscal 2015. Partially offsetting this impact was an increase in overall materials unit cost for configured systems due to an increase in the average unit materials costs in entry level and high-end FAS configured systems platforms, partially offset by lower average unit materials costs in mid-range FAS systems, due to changes in product mix. The decrease in materials costs also reflects lower add-on storage and OEM product volume.

[0001564590-16-020754:mdna:120]
Materials cost decreased $82 million in fiscal 2015 compared to fiscal 2014. Materials costs were impacted by a 5% unit volume increase in configured systems in fiscal 2015 compared to fiscal 2014. Overall materials unit cost for configured systems decreased due to a decrease in the average unit materials costs in all of our configured systems platforms, except our FAS entry level systems, which increased slightly, due to changes in product mix. The decrease in materials costs also reflects lower OEM product volume and lower costs of add-on storage. Cost of product revenues were also favorably impacted by a $35 million decrease in hardware-related warranty expense due to a combination of a lower installed base subject to warranty and lower estimated warranty cost per unit.

[0001564590-16-020754:mdna:121]
Cost of Software Maintenance Revenues (in millions, except percentages):

[0001564590-16-020754:mdna:122]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2014 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 37 |  |  | $ | 36 |  |  |  | 3 | % |  | $ | 31 |  |  |  | 16 | % |

[0001564590-16-020754:mdna:123]
Cost of software maintenance revenues were relatively flat in fiscal 2016 compared to fiscal 2015. Cost of software maintenance revenues increased in fiscal 2015 compared to fiscal 2014 primarily due to higher third-party royalties. Cost of software maintenance revenues represented 4%, 4% and 3% of software maintenance revenues for fiscal 2016, 2015 and 2014, respectively.

[0001564590-16-020754:mdna:124]
Cost of Hardware Maintenance and Other Services Revenues (in millions, except percentages):

[0001564590-16-020754:mdna:125]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2014 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 578 |  |  | $ | 597 |  |  |  | (3 | )% |  | $ | 598 |  |  |  | — | % |

[0001564590-16-020754:mdna:126]
Cost of hardware maintenance and other services revenues decreased in fiscal 2016 compared to fiscal 2015 due to the favorable impact of cost savings initiatives. Cost of hardware maintenance and other services revenues were relatively flat in fiscal 2015

[0001564590-16-020754:mdna:127]
40

[0001564590-16-020754:mdna:128]
compared to fiscal 2014. Costs represented 36%, 38% and 41% of hardware maintenance and other services revenues for fiscal 2016, 2015 and 2014, respectively.

[0001564590-16-020754:mdna:129]
Operating Expenses

[0001564590-16-020754:mdna:130]
Sales and Marketing, Research and Development and General and Administrative Expenses

[0001564590-16-020754:mdna:131]
Compensation costs comprise the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0001564590-16-020754:mdna:132]
Total compensation costs included in operating expenses decreased $57 million, or 3% during fiscal 2016 compared to fiscal 2015, primarily due to lower salaries and incentive compensation costs, reflecting a 5% decrease in average headcount, lower operating performance against goals and the favorable impact of foreign exchange rate fluctuations.

[0001564590-16-020754:mdna:133]
Total compensation costs included in operating expenses decreased $18 million, or 1% during fiscal 2015 compared to fiscal 2014, primarily due to a decrease in incentive compensation costs, reflecting lower operating performance against goals, and lower stock-based compensation expense.

[0001564590-16-020754:mdna:134]
Sales and Marketing (in millions, except percentages):

[0001564590-16-020754:mdna:135]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2014 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 1,792 |  |  | $ | 1,913 |  |  |  | (6 | )% |  | $ | 1,898 |  |  |  | 1 | % |

[0001564590-16-020754:mdna:136]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, allocated facilities and IT costs, advertising and marketing promotional expense and travel and entertainment expense. The changes in sales and marketing expenses consisted of the following:

[0001564590-16-020754:mdna:137]
|  |  | Fiscal 2016 to Fiscal 2015 |  |  | Fiscal 2015 to Fiscal 2014 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (2 | ) |  |  | (1 | ) |
| Facilities and IT support costs |  |  | (2 | ) |  |  | — |  |
| Other |  |  | (2 | ) |  |  | 2 |  |
| Total change |  |  | (6 | ) |  |  | 1 |  |

[0001564590-16-020754:mdna:138]
The decrease in sales and marketing expenses in fiscal 2016 reflects the approximately 4% favorable impact of fluctuations in foreign exchange rates. Additionally, the decrease in compensation costs during fiscal 2016 reflects lower average headcount from the prior year. Facilities and IT support costs decreased during fiscal 2016 primarily due to cost reduction initiatives.

[0001564590-16-020754:mdna:139]
The decrease in compensation costs during fiscal 2015 is primarily due to lower stock-based compensation and salaries expense, reflecting lower compensation cost per headcount that was partially offset by a 5% increase in headcount. In addition, foreign exchange rate changes resulted in a favorable impact of approximately 2% during fiscal 2015.

[0001564590-16-020754:mdna:140]
Research and Development (in millions, except percentages):

[0001564590-16-020754:mdna:141]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2014 |  |  | % Change |  |
| Research and development expenses |  | $ | 861 |  |  | $ | 920 |  |  |  | (6 | )% |  | $ | 918 |  |  |  | — | % |

[0001564590-16-020754:mdna:142]
Research and development expenses consist primarily of compensation costs, allocated facilities and IT costs, depreciation, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs. Changes in research and development expense consisted of the following:

[0001564590-16-020754:mdna:143]
|  |  | Fiscal 2016 to Fiscal 2015 |  |  | Fiscal 2015 to Fiscal 2014 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (3 | ) |  |  | — |  |
| Facilities and IT support costs |  |  | (1 | ) |  |  | — |  |
| Other |  |  | (2 | ) |  |  | — |  |
| Total change |  |  | (6 | ) |  |  | — |  |

[0001564590-16-020754:mdna:144]
The decrease in compensation costs during fiscal 2016 was primarily due to lower salaries and incentive compensation costs, reflecting a 6% decrease in average headcount. Facilities and IT support costs decreased during fiscal 2016 primarily due to cost reduction initiatives.

[0001564590-16-020754:mdna:145]
Research and development expenses were relatively flat in fiscal 2015 compared to fiscal 2014.

[0001564590-16-020754:mdna:146]
General and Administrative (in millions, except percentages):

[0001564590-16-020754:mdna:147]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2014 |  |  | % Change |  |
| General and administrative expenses |  | $ | 307 |  |  | $ | 284 |  |  |  | 8 | % |  | $ | 281 |  |  |  | 1 | % |

[0001564590-16-020754:mdna:148]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and allocated facilities and IT support costs. Changes in general and administrative expense consisted of the following:

[0001564590-16-020754:mdna:149]
|  |  | Fiscal 2016 to Fiscal 2015 |  |  | Fiscal 2015 to Fiscal 2014 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 4 |  |  |  | (1 | ) |
| Professional and legal fees and outside services |  |  | 7 |  |  |  | 1 |  |
| Facilities and IT support costs |  |  | (3 | ) |  |  | — |  |
| Other |  |  | — |  |  |  | 1 |  |
| Total change |  |  | 8 |  |  |  | 1 |  |

[0001564590-16-020754:mdna:150]
The increase in compensation costs in fiscal 2016 was primarily due to higher stock-based compensation, salaries and benefit costs. The increase in professional and legal fees and outside services expense in fiscal 2016 was primarily due to higher spending levels on consulting fees and projects. Facilities and IT support costs decreased during fiscal 2016 primarily due to cost reduction initiatives.

[0001564590-16-020754:mdna:151]
The decrease in compensation costs during 2015 is primarily due to lower incentive compensation costs, stock-based compensation and benefits expenses, partially offset by higher salaries due to a 5% increase in headcount. The increase in professional and legal fees and outside services during 2015 reflects higher spending levels on contractors and professional services.

[0001564590-16-020754:mdna:152]
Restructuring and Other Charges (in millions, except percentages):

[0001564590-16-020754:mdna:153]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  | 2014 |  |  | % Change |  |
| Restructuring and other charges |  | $ | 108 |  |  |  | — |  |  | NM |  | $ | 88 |  |  |  | (100 | )% |

[0001564590-16-020754:mdna:154]
NM - Not Meaningful

[0001564590-16-020754:mdna:155]
In response to changes in market conditions and market demand for our products, in March 2016, May 2015, March 2014 and May 2013, we initiated business realignment plans designed to streamline our business, reduce our cost structure and focus our resources on key strategic opportunities, resulting in aggregate reductions of our global workforce of approximately 14% and 11% in fiscal 2016 and 2014, respectively, for which we recognized aggregate charges of $108 million and $88 million, consisting primarily of employee severance costs. We have completed all activities under our restructuring plans with the exception of the March 2016 plan, which we expect to complete in the first half of fiscal 2017 with no significant additional costs. See Note 13 – Restructuring and Other Charges of the Notes to Consolidated Financial Statements for more details regarding our restructuring plans.

[0001564590-16-020754:mdna:156]
Acquisition-related Expense (in millions, except percentages):

[0001564590-16-020754:mdna:157]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  | 2014 |  |  | % Change |  |
| Acquisition-related expense |  | $ | 8 |  |  | $ | — |  |  | NM |  | $ | — |  |  |  | — | % |

[0001564590-16-020754:mdna:158]
NM - Not Meaningful

[0001564590-16-020754:mdna:159]
During fiscal 2016, we incurred $8 million of acquisition costs, primarily related to legal and consulting fees, employee severance costs, and asset impairments associated with our acquisition of SolidFire.

[0001564590-16-020754:mdna:160]
Gain on Sale of Properties (in millions, except percentages):

[0001564590-16-020754:mdna:161]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  | 2014 |  |  | % Change |  |
| Gain on sale of properties |  | $ | (51 | ) |  | $ | — |  |  | NM |  | $ | — |  |  |  | — | % |

[0001564590-16-020754:mdna:162]
NM - Not Meaningful

[0001564590-16-020754:mdna:163]
In fiscal 2016, we sold certain properties, which had a net book value of $51 million and related sales proceeds of $102 million, resulting in a gain of $51 million.

[0001564590-16-020754:mdna:164]
Other Income (Expense), Net (in millions, except percentages)

[0001564590-16-020754:mdna:165]
The components of other income (expense), net were as follows:

[0001564590-16-020754:mdna:166]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2014 |  |  | % Change |  |
| Interest income |  | $ | 46 |  |  | $ | 37 |  |  |  | 24 | % |  | $ | 35 |  |  |  | 5 | % |
| Interest expense |  |  | (49 | ) |  |  | (42 | ) |  |  | 17 | % |  |  | (36 | ) |  |  | 16 | % |
| Net gains (losses) recognized on investments |  |  | — |  |  |  | 6 |  |  |  | (100 | )% |  |  | 7 |  |  |  | (16 | )% |
| Net gains (losses) on foreign currency activities |  |  | — |  |  |  | (4 | ) |  |  | (100 | )% |  |  | 1 |  |  | NM |  |
| Total |  | $ | (3 | ) |  | $ | (3 | ) |  |  | — | % |  | $ | 7 |  |  | NM |  |

[0001564590-16-020754:mdna:167]
NM - Not Meaningful

[0001564590-16-020754:mdna:168]
Interest income increased during fiscal 2016 compared to fiscal 2015, and fiscal 2015 compared to fiscal 2014, primarily due to a shift in our investment portfolio to higher-yielding investments.

[0001564590-16-020754:mdna:169]
Interest expense, including the amortization of debt discount and issuance costs, is primarily related to our Senior Notes. In addition, in fiscal 2014, we also incurred interest expense related to our Convertible Notes that matured in June 2013.

[0001564590-16-020754:mdna:170]
Provision for Income Taxes (in millions, except percentages):

[0001564590-16-020754:mdna:171]
|  |  | Fiscal Year |  |
|  |  | 2016 |  |  | 2015 |  |  | % Change |  |  | 2014 |  |  | % Change |  |
| Provision for income taxes |  | $ | 116 |  |  | $ | 153 |  |  |  | (24 | )% |  | $ | 103 |  |  |  | 48 | % |

[0001564590-16-020754:mdna:172]
Our effective tax rate for fiscal 2016 was 33.6% compared to an effective tax rate of 21.5% for fiscal 2015, and an effective tax rate of 13.9% for fiscal 2014. Our effective tax rates reflect our corporate legal entity structure and the global nature of our business with a significant amount of our profits generated and taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The effective tax rates for fiscal 2014 through fiscal 2016 were favorably impacted by the geographic mix of profits. Our effective tax rate for fiscal 2016 increased compared to the prior year primarily as a result of a $64 million income tax charge associated with the integration of SolidFire into our worldwide operations, as well as $20 million in charges related to the settlements of income tax audits, as further discussed below.

[0001564590-16-020754:mdna:173]
The effective tax rate of 33.6% in fiscal 2016 included a benefit of $81 million, or 23.5 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 35%. Other key components of our effective tax rate for the year included a charge of $64 million, or 18.6 percentage points, related to the integration of SolidFire intellectual property into our tax structure, charges of $20 million, or 5.8 percentage points, in connection with the settlement of income tax audits, a benefit of $14 million, or 4.1 percentage points, related to current and prior year research and development credits, a tax charge of $13 million, or 3.8 percentage points, attributable to non-deductible stock-based compensation and a benefit of $10 million, or 2.9 percentage points, related to the domestic production activities deduction.

[0001564590-16-020754:mdna:174]
The effective tax rate of 21.5% in fiscal 2015 included a benefit of $141 million, or 19.8 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 35%. Other key components of our effective tax rate for the year included a benefit of $14 million, or 1.9 percentage points, related to current and prior year research and development credits, a benefit of $5 million, or 0.7 percentage points, related to the domestic production activities deduction, and charges of $46 million, or 6.5 percentage points, in connection with income tax audits.

[0001564590-16-020754:mdna:175]
The effective tax rate of 13.9% in fiscal 2014 included a benefit of $163 million, or 22.0 percentage points, from foreign profits taxed at effective tax rates lower than the U.S. federal statutory rate of 35%. Other key components of our effective tax rate for the year included a benefit of $9 million, or 1.2 percentage points, related to current year research and development credits and a charge of $10 million, or 1.3 percentage points, attributable to non-deductible stock-based compensation and a benefit of $6 million, or 0.8 percentage points, related to the domestic production activities deduction.

[0001564590-16-020754:mdna:176]
In December 2015, the enactment of the Protecting Americans from Tax Hikes Act of 2015 permanently extended the federal research credit which had previously expired on December 31, 2014. As a result of the extension, during fiscal 2016, we recorded a benefit of $10 million related to the current year research credit and a benefit of $4 million related to a prior year credit that we retroactively claimed.

[0001564590-16-020754:mdna:177]
In December 2014, the Tax Increase Prevention Act of 2014 extended the federal research credit for amounts paid or incurred after December 31, 2013 and before January 1, 2015. As a result of the extension, in fiscal 2015 we recorded a benefit of $10 million related to the fiscal 2015 research credit and a benefit of $4 million related to a prior year credit that was retroactively claimed.

[0001564590-16-020754:mdna:178]
In June 2015, the Internal Revenue Service (IRS) signed a closing agreement with respect to transfer pricing arrangements and, in October 2015, completed the examination of our fiscal 2008 to 2010 income tax returns. During fiscal 2016, we recorded a tax charge of $23 million attributable to transfer pricing and other audit settlements and the related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-16-020754:mdna:179]
In July 2014, the IRS completed the examination of our fiscal 2005 to 2007 income tax returns upon approval by the Joint Committee of Taxation. During fiscal 2015, we recorded a tax charge of $47 million attributable to the audit settlement and related re-measurements of uncertain tax positions for tax years subject to future audits.

[0001564590-16-020754:mdna:180]
We are currently undergoing federal income tax audits in the United States and several foreign tax jurisdictions. Transfer pricing calculations are key issues under audits in various jurisdictions, and are often subject to dispute and appeals. Our open years in U.S. federal jurisdictions are fiscal 2012 and later years. In addition, we are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal year 2001, in that we have tax attribute carryforwards from these years that could be subject to adjustments in the tax years of utilization.

[0001564590-16-020754:mdna:181]
On September 17, 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 from our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for withholding tax and filed an appeal with the Danish Tax Tribunal to that effect. On December 19, 2011, the Danish Tax Tribunal issued a ruling that our Danish subsidiary was not liable for Danish withholding tax. The Danish tax examination agency appealed to the Danish High Court in March 2012. In February 2016, the Danish High Court referred the case to the European Court of Justice.

[0001564590-16-020754:mdna:182]
We continue to monitor the progress of ongoing tax controversies and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. Based on current information, we do not expect significant changes to our existing unrecognized tax benefits as of April 29, 2016.

[0001564590-16-020754:mdna:183]
Liquidity, Capital Resources and Cash Requirements

[0001564590-16-020754:mdna:184]
| (In millions, except percentages) |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Cash and cash equivalents and short-term investments |  | $ | 5,303 |  |  | $ | 5,326 |  |
| Principal amount of debt |  | $ | 2,350 |  |  | $ | 1,500 |  |
| Debt as a % of stockholders' equity |  |  | 82 | % |  |  | 44 | % |

[0001564590-16-020754:mdna:185]
44

[0001564590-16-020754:mdna:186]
The following is a summary of our cash flow activities:

[0001564590-16-020754:mdna:187]
|  |  | Fiscal Year |  |
| (In millions) |  | 2016 |  |  | 2015 |  |
| Net cash provided by operating activities |  | $ | 974 |  |  | $ | 1,268 |  |
| Net cash provided by (used in) investing activities |  |  | 85 |  |  |  | (903 | ) |
| Net cash used in financing activities |  |  | (109 | ) |  |  | (675 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (4 | ) |  |  | (59 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 946 |  |  | $ | (369 | ) |

[0001564590-16-020754:mdna:188]
Cash Flows

[0001564590-16-020754:mdna:189]
As of April 29, 2016, our cash, cash equivalents and short-term investments totaled $5.3 billion, reflecting a minimal decrease of $23 million from April 24, 2015. The decrease was primarily due to $960 million in cash paid for the repurchase of our common stock and $210 million in cash used for the payment of dividends, partially offset by $974 million of cash provided by operating activities, $102 million from the sale of properties and $148 million in proceeds from sale-leaseback transactions of certain of properties. Additionally, $870 million of cash was obtained through a short-term loan, which was primarily used to acquire SolidFire. Accounts receivable DSO was 54 days for the fourth quarter of fiscal 2016 compared to 46 days for the fourth quarter of fiscal 2015 reflecting seasonal shipment linearity. Working capital decreased by $1.3 billion to $2.8 billion as of April 29, 2016 primarily as a result of the short-term loan.

[0001564590-16-020754:mdna:190]
Cash Flows from Operating Activities

[0001564590-16-020754:mdna:191]
During fiscal 2016, we generated cash from operating activities of $974 million, reflecting net income of $229 million, adjusted by non-cash depreciation and amortization of $279 million, stock-based compensation of $260 million, partially offset by adjustments for a deferred income tax provision of $113 million and a gain on sale of properties of $51 million.

[0001564590-16-020754:mdna:192]
Changes in assets and liabilities during fiscal 2016 included the following:

[0001564590-16-020754:mdna:193]
|  | · | Other operating assets decreased $109 million, primarily due to decreases in manufacturing-related activities. |

[0001564590-16-020754:mdna:194]
|  | · | Deferred revenue and financed unearned services revenue increased $186 million, primarily due to an increase in maintenance services contract renewals. |

[0001564590-16-020754:mdna:195]
During fiscal 2015, we generated cash from operating activities of $1.3 billion. The primary sources of cash from operating activities during fiscal 2015 consisted of net income of $560 million, adjusted by non-cash depreciation and amortization of $307 million and stock-based compensation of $259 million.

[0001564590-16-020754:mdna:196]
Changes in assets and liabilities during fiscal 2015 included the following:

[0001564590-16-020754:mdna:197]
|  | · | Accounts receivable decreased primarily due to lower invoicing levels. |

[0001564590-16-020754:mdna:198]
|  | · | Accrued expenses decreased primarily due to employee compensation payouts related to fiscal year 2014 incentive compensation plans and restructuring obligations. |

[0001564590-16-020754:mdna:199]
|  | · | Deferred revenue and financed unearned services revenue increased due to an increase in deferred software and hardware maintenance contract revenues. |

[0001564590-16-020754:mdna:200]
We expect that cash provided by operating activities may materially fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, tax benefits or charges from stock-based compensation, and the timing and amount of compensation and other payments.

[0001564590-16-020754:mdna:201]
Cash Flows from Investing Activities

[0001564590-16-020754:mdna:202]
During fiscal 2016, we generated $982 million from maturities and sales of investments, net of purchases, expended $842 million of cash on the SolidFire acquisition, net of cash acquired, paid $160 million for capital expenditures and received $102 million of proceeds from the sale of properties.

[0001564590-16-020754:mdna:203]
During fiscal 2015, we used $645 million for purchases of investments, net of maturities and sales, and paid $175 million for capital expenditures. In addition, we expended $85 million of cash on acquisitions.

[0001564590-16-020754:mdna:204]
Cash Flows from Financing Activities

[0001564590-16-020754:mdna:205]
During fiscal 2016, we borrowed $870 million under a short-term loan which was used primarily to fund the acquisition of SolidFire. We used $960 million for the repurchase of 33 million shares of our common stock, $210 million for the payment of dividends and received $148 million of proceeds under sale-leaseback transactions.

[0001564590-16-020754:mdna:206]
During fiscal 2015, we generated $495 million, net, from the issuance of long-term debt and used $1.2 billion for the repurchase of 30 million shares of our common stock and $208 million for the payment of dividends.

[0001564590-16-020754:mdna:207]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies, and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including potential future issuances of debt, equity or other securities, will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all.

[0001564590-16-020754:mdna:208]
Liquidity

[0001564590-16-020754:mdna:209]
Our principal sources of liquidity as of April 29, 2016 consisted of cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001564590-16-020754:mdna:210]
Cash, cash equivalents and short-term investments consisted of the following (in millions):

[0001564590-16-020754:mdna:211]
|  |  | April 29, 2016 |  |  | April 24, 2015 |  |
| Cash and cash equivalents |  | $ | 2,868 |  |  | $ | 1,922 |  |
| Short-term investments |  |  | 2,435 |  |  |  | 3,404 |  |
| Total |  | $ | 5,303 |  |  | $ | 5,326 |  |

[0001564590-16-020754:mdna:212]
As of April 29, 2016 and April 24, 2015, $4.8 billion and $4.7 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.5 billion and $0.6 billion, respectively, were available in the U.S. Most of the amounts held outside the U.S. can be repatriated to the U.S. but, under current law, would be subject to U.S. federal, state income and foreign withholding taxes. If we were to repatriate foreign earnings to fund cash requirements in the U.S., we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state tax credit carryforwards. However, our intent is to keep these funds permanently reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, and invest in critical or complementary technologies, and service interest and principal payments on our debt.

[0001564590-16-020754:mdna:213]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of April 29, 2016.

[0001564590-16-020754:mdna:214]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, and other liquidity requirements associated with our operations. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties.

[0001564590-16-020754:mdna:215]
46

[0001564590-16-020754:mdna:216]
Senior Notes

[0001564590-16-020754:mdna:217]
The following table summarizes the principal amount of our Senior Notes as of April 29, 2016 (in millions):

[0001564590-16-020754:mdna:218]
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |
| Total |  | $ | 1,500 |  |

[0001564590-16-020754:mdna:219]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 10 – Financing Arrangements of the Notes to Consolidated Financial Statements.

[0001564590-16-020754:mdna:220]
Short-Term Loan

[0001564590-16-020754:mdna:221]
In February 2016, in connection with our acquisition of SolidFire, we entered into a short-term loan that matures on November 2, 2016, that we expect to repay using funds generated by our global operations. As of April 29, 2016, $850 million of the loan principal remained outstanding. The loan is subject to the same covenants as our credit facility described below.

[0001564590-16-020754:mdna:222]
Credit Facility

[0001564590-16-020754:mdna:223]
Our credit facility, under which we may borrow up to $300 million, provides another potential source of liquidity. The credit facility is an unsecured five-year revolving credit facility that terminates on December 21, 2017 if no extensions have been requested by that time, and contains financial covenants requiring us to maintain a maximum leverage ratio and a minimum interest coverage ratio. We may also, subject to certain requirements, request an increase in the facility up to an additional $50 million and request two additional one-year extensions, subject to certain conditions. As of April 29, 2016, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-16-020754:mdna:224]
We also have an automatic shelf registration statement on file with the Securities and Exchange Commission. We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001564590-16-020754:mdna:225]
Capital Expenditure Requirements

[0001564590-16-020754:mdna:226]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for fiscal 2017 to be between $150 million and $200 million.

[0001564590-16-020754:mdna:227]
Dividends and Stock Repurchase Program

[0001564590-16-020754:mdna:228]
On May 25, 2016, we declared a cash dividend of $0.19 per share of common stock, payable on July 27, 2016 to holders of record as of the close of business on July 18, 2016.

[0001564590-16-020754:mdna:229]
As of April 29, 2016, our Board of Directors has authorized the repurchase of up to $9.6 billion of our common stock under our stock repurchase program. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through April 29, 2016, we repurchased a total of 247 million shares of our common stock at an average price of $32.85 per share, for an aggregate purchase price of $8.1 billion. As of April 29, 2016, the remaining authorized amount for stock repurchases under this program was $1.5 billion with no termination date, which we plan to complete by May 2018.

[0001564590-16-020754:mdna:230]
The timing and amount of stock repurchase transactions and future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements.

[0001564590-16-020754:mdna:231]
March 2016 Restructuring Plan

[0001564590-16-020754:mdna:232]
In the fourth quarter of fiscal 2016, we initiated a restructuring plan to streamline our business and reduce operating expenses. We expect to incur approximately $45 million of additional cash expenditures in connection with this plan in the first two quarters of fiscal 2017.

[0001564590-16-020754:mdna:233]
Contractual Obligations

[0001564590-16-020754:mdna:234]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. The following table summarizes our contractual obligations at April 29, 2016 (in millions):

[0001564590-16-020754:mdna:235]
|  |  |  | 2017 |  |  |  | 2018 |  |  |  | 2019 |  |  |  | 2020 |  |  |  | 2021 |  |  | Thereafter |  |  | Total |  |
| Office space and equipment lease commitments |  | $ | 60 |  |  | $ | 50 |  |  | $ | 39 |  |  | $ | 31 |  |  | $ | 23 |  |  | $ | 50 |  |  | $ | 253 |  |
| Purchase commitments with contract manufacturers (1) |  |  | 211 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 211 |  |
| Construction related obligations |  |  | 37 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 37 |  |
| Other purchase obligations (2) |  |  | 88 |  |  |  | 29 |  |  |  | 13 |  |  |  | 7 |  |  |  | 4 |  |  |  | 11 |  |  |  | 152 |  |
| Total off-balance sheet commitments |  |  | 396 |  |  |  | 79 |  |  |  | 52 |  |  |  | 38 |  |  |  | 27 |  |  |  | 61 |  |  |  | 653 |  |
| Short-term loan (3) |  |  | 850 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 850 |  |
| Long-term debt obligations (4) |  |  | 40 |  |  |  | 790 |  |  |  | 25 |  |  |  | 25 |  |  |  | 25 |  |  |  | 775 |  |  |  | 1,680 |  |
| Long-term financing arrangements |  |  | 6 |  |  |  | 3 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 9 |  |
| Sale-leaseback financing obligations (5) |  |  | 19 |  |  |  | 129 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 148 |  |
| Uncertain tax positions (6) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 152 |  |
| Total contractual obligations |  | $ | 1,311 |  |  | $ | 1,001 |  |  | $ | 77 |  |  | $ | 63 |  |  | $ | 52 |  |  | $ | 836 |  |  | $ | 3,492 |  |
| Other Commercial Commitments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Letters of credit |  | $ | 10 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | — |  |  | $ | 14 |  |

[0001564590-16-020754:mdna:236]
| (1) | Contract manufacturer commitments consist of obligations for on-hand inventories and non-cancelable purchase orders with our contract manufacturers. We record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts. As of April 29, 2016, such liability amounted to $7 million and is included in accrued expenses in our consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change. |

[0001564590-16-020754:mdna:237]
| (2) | Purchase obligations represent an estimate of all open purchase orders and contractual obligations associated with our ordinary course of business, in addition to inventory commitments with contract manufacturers, for which we have not received the goods or services. Purchase obligations do not include contracts that may be cancelled without penalty. Although open purchase orders are considered enforceable and legally binding, the terms generally allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services. |

[0001564590-16-020754:mdna:238]
| (3) | Represents principal payments on our short-term loan. Interest payments will vary depending on the timing of repayments of the principal and LIBOR rates. |

[0001564590-16-020754:mdna:239]
| (4) | Included in long-term debt are obligations related to our $1.5 billion principal amount of our Senior Notes, of which $750 million is due in December 2017, $500 million is due in June 2021 and $250 million is due in December 2022. Estimated interest payments for our long-term debt, assuming no early retirement of debt obligations, are $180 million for fiscal 2017 through fiscal 2023. |

[0001564590-16-020754:mdna:240]
| (5) | Sale-leaseback financing obligations are non-cash obligations as discussed below. |

[0001564590-16-020754:mdna:241]
| (6) | As of April 29, 2016, our liability for uncertain tax positions was $152 million, including interest, penalties and offsetting indirect benefits, which due to the uncertainty of the timing of future payments, are presented in the total column on a separate line in this table. |

[0001564590-16-020754:mdna:242]
Some of the amounts in the table above are based on management’s estimates and assumptions, including the commitment duration, the possibility of renewal or termination, anticipated actions by management and third parties and other factors. Because these estimates and assumptions are subjective, our actual future obligations may vary from those reflected in the table.

[0001564590-16-020754:mdna:243]
Sale-leaseback Transaction

[0001564590-16-020754:mdna:244]
In fiscal 2016 we entered into sale-leaseback arrangements of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, the assets, which had a net book value of $67 million at the date of the transactions, will remain on our consolidated balance sheets and proceeds received by us from these transactions of $148 million are reported as financing obligations. At the end of each respective leaseback period, or when our continuing involvement under the leaseback agreements ends, each transaction will be reported as a non-cash sale of land and buildings and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain on sale of properties. These financing obligations are reflected as non-cash obligations in the preceding commitments table.

[0001564590-16-020754:mdna:245]
Financial Guarantee Instruments

[0001564590-16-020754:mdna:246]
In the ordinary course of business, we provide standby letters of credit or other guarantee instruments to third parties as required for certain transactions initiated either by us or our subsidiaries. As of April 29, 2016, our financial guarantees of $14 million that were not recorded on our consolidated balance sheets consisted primarily of standby letters of credit and surety bonds.

[0001564590-16-020754:mdna:247]
48

[0001564590-16-020754:mdna:248]
Financing Guarantees

[0001564590-16-020754:mdna:249]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $243 million and $197 million of receivables during fiscal 2016 and 2015, respectively.

[0001564590-16-020754:mdna:250]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-16-020754:mdna:251]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of April 29, 2016 and April 24, 2015, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001564590-16-020754:mdna:252]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of April 29, 2016, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0001564590-16-020754:mdna:253]
Indemnification Agreements

[0001564590-16-020754:mdna:254]
We enter into indemnification agreements with third parties in the ordinary course of business. Generally, these indemnification agreements require us to reimburse losses suffered by the third-parties due to various events, such as lawsuits arising from patent or copyright infringement. These indemnification obligations are considered off-balance sheet arrangements under accounting guidance.

[0001564590-16-020754:mdna:255]
Legal Contingencies

[0001564590-16-020754:mdna:256]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 18 – Commitments and Contingencies of the Notes to Consolidated Financial Statements.
