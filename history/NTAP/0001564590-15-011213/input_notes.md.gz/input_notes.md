# NTAP notes — 0001564590-15-011213


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-15-011213:notes:1]
[same as prior period, unchanged from 0001564590-15-007795:notes:1]

[0001564590-15-011213:notes:2]
[same as prior period, unchanged from 0001564590-15-007795:notes:2]

[0001564590-15-011213:notes:3]
[same as prior period, unchanged from 0001564590-15-007795:notes:3]

[0001564590-15-011213:notes:4]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2016, ending on April 29, 2016, is a 53-week year, with 14 weeks in its first quarter and 13 weeks in each subsequent quarter. Fiscal year 2015, which ended on April 24, 2015, was a 52-week year, with 13 weeks in each of its quarters.

[0001564590-15-011213:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income (loss) and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2015 contained in our Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 12, 2015. The results of operations for the three and six months ended October 30, 2015 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-15-011213:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-15-011213:notes:7]
There have been no significant changes in our significant accounting policies as of and for the six months ended October 30, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 24, 2015.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-15-011213:notes:8]
[same as prior period, unchanged from 0001564590-15-007795:notes:8]

[0001564590-15-011213:notes:9]
[same as prior period, unchanged from 0001564590-15-007795:notes:9]

[0001564590-15-011213:notes:10]
|  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 15 |  |  | $ | 9 |  |
| Acquisition of software through long-term financing |  | $ | — |  |  | $ | 12 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 94 |  |  | $ | 69 |  |
| Interest paid |  | $ | 20 |  |  | $ | 12 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-15-011213:notes:11]
[same as prior period, unchanged from 0001564590-15-007795:notes:11]

[0001564590-15-011213:notes:12]
[same as prior period, unchanged from 0001564590-15-007795:notes:12]

[0001564590-15-011213:notes:13]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 304 |  |  | $ | (255 | ) |  | $ | 49 |  |  | $ | 313 |  |  | $ | (225 | ) |  | $ | 88 |  |
| Customer contracts/relationships |  |  | 5 |  |  |  | (3 | ) |  |  | 2 |  |  |  | 5 |  |  |  | (3 | ) |  |  | 2 |  |
| Other purchased intangibles |  |  | 1 |  |  |  | (1 | ) |  |  | — |  |  |  | 3 |  |  |  | (3 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 310 |  |  | $ | (259 | ) |  | $ | 51 |  |  | $ | 321 |  |  | $ | (231 | ) |  | $ | 90 |  |

[0001564590-15-011213:notes:14]
During the six months ended October 30, 2015, we recorded a charge of $11 million to fully impair developed technology related to our fiscal 2013 acquisition of CacheIQ as a result of our discontinued use of such technology. The impairment charge is included in accumulated amortization in the table above.

[0001564590-15-011213:notes:15]
[same as prior period, unchanged from 0001564590-15-007795:notes:15]

[0001564590-15-011213:notes:16]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Statement of |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | Operations Classifications |
| Developed technology |  | $ | 14 |  |  | $ | 14 |  |  | $ | 28 |  |  | $ | 29 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  | Operating expenses |
| Total |  | $ | 14 |  |  | $ | 14 |  |  | $ | 28 |  |  | $ | 29 |  |  |  |

[0001564590-15-011213:notes:17]
As of October 30, 2015, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-15-011213:notes:18]
| Fiscal Year |  | Amount |  |
| Remainder of 2016 |  | $ | 27 |  |
| 2017 |  |  | 10 |  |
| 2018 |  |  | 6 |  |
| 2019 |  |  | 5 |  |
| 2020 |  |  | 3 |  |
| Total |  | $ | 51 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-15-011213:notes:19]
[same as prior period, unchanged from 0001564590-15-007795:notes:19]

[0001564590-15-011213:notes:20]
[same as prior period, unchanged from 0001564590-15-007795:notes:20]

[0001564590-15-011213:notes:21]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Cash |  | $ | 2,075 |  |  | $ | 1,666 |  |
| Cash equivalents |  |  | 123 |  |  |  | 256 |  |
| Cash and cash equivalents |  | $ | 2,198 |  |  | $ | 1,922 |  |

[0001564590-15-011213:notes:22]
[same as prior period, unchanged from 0001564590-15-007795:notes:22]

[0001564590-15-011213:notes:23]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Purchased components |  | $ | 35 |  |  | $ | 36 |  |
| Finished goods |  |  | 90 |  |  |  | 110 |  |
| Inventories |  | $ | 125 |  |  | $ | 146 |  |

[0001564590-15-011213:notes:24]
[same as prior period, unchanged from 0001564590-15-007795:notes:24]

[0001564590-15-011213:notes:25]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Prepaid expenses and other current assets |  | $ | 250 |  |  | $ | 268 |  |
| Deferred tax assets |  |  | 305 |  |  |  | 254 |  |
| Other current assets |  | $ | 555 |  |  | $ | 522 |  |

[0001564590-15-011213:notes:26]
[same as prior period, unchanged from 0001564590-15-007795:notes:26]

[0001564590-15-011213:notes:27]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Land |  | $ | 265 |  |  | $ | 265 |  |
| Buildings and improvements |  |  | 606 |  |  |  | 607 |  |
| Leasehold improvements |  |  | 107 |  |  |  | 107 |  |
| Computer, production, engineering and other equipment |  |  | 765 |  |  |  | 754 |  |
| Computer software |  |  | 369 |  |  |  | 372 |  |
| Furniture and fixtures |  |  | 86 |  |  |  | 85 |  |
| Construction-in-progress |  |  | 51 |  |  |  | 33 |  |
|  |  |  | 2,249 |  |  |  | 2,223 |  |
| Accumulated depreciation and amortization |  |  | (1,245 | ) |  |  | (1,193 | ) |
| Property and equipment, net |  | $ | 1,004 |  |  | $ | 1,030 |  |

[0001564590-15-011213:notes:28]
[same as prior period, unchanged from 0001564590-15-007795:notes:28]

[0001564590-15-011213:notes:29]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Deferred tax assets |  | $ | 281 |  |  | $ | 256 |  |
| Other assets |  |  | 191 |  |  |  | 225 |  |
| Other non-current assets |  | $ | 472 |  |  | $ | 481 |  |

[0001564590-15-011213:notes:30]
[same as prior period, unchanged from 0001564590-15-007795:notes:30]

[0001564590-15-011213:notes:31]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Accrued compensation and benefits |  | $ | 281 |  |  | $ | 359 |  |
| Product warranty liability |  |  | 53 |  |  |  | 58 |  |
| Other current liabilities |  |  | 284 |  |  |  | 284 |  |
| Accrued expenses |  | $ | 618 |  |  | $ | 701 |  |

[0001564590-15-011213:notes:32]
[same as prior period, unchanged from 0001564590-15-007795:notes:32]

[0001564590-15-011213:notes:33]
[same as prior period, unchanged from 0001564590-15-007795:notes:33]

[0001564590-15-011213:notes:34]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Balance at beginning of period |  | $ | 81 |  |  | $ | 104 |  |  | $ | 86 |  |  | $ | 110 |  |
| Expense accrued during the period |  |  | 13 |  |  |  | 9 |  |  |  | 22 |  |  |  | 19 |  |
| Warranty costs incurred |  |  | (14 | ) |  |  | (16 | ) |  |  | (28 | ) |  |  | (32 | ) |
| Balance at end of period |  | $ | 80 |  |  | $ | 97 |  |  | $ | 80 |  |  | $ | 97 |  |

[0001564590-15-011213:notes:35]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Accrued expenses |  | $ | 53 |  |  | $ | 58 |  |
| Other long-term liabilities |  |  | 27 |  |  |  | 28 |  |
| Total warranty liabilities |  | $ | 80 |  |  | $ | 86 |  |

[0001564590-15-011213:notes:36]
[same as prior period, unchanged from 0001564590-15-007795:notes:36]

[0001564590-15-011213:notes:37]
[same as prior period, unchanged from 0001564590-15-007795:notes:37]

[0001564590-15-011213:notes:38]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Deferred product revenue |  | $ | 20 |  |  | $ | 17 |  |
| Deferred services revenue |  |  | 2,913 |  |  |  | 3,075 |  |
| Financed unearned services revenue |  |  | 113 |  |  |  | 105 |  |
| Total |  | $ | 3,046 |  |  | $ | 3,197 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,609 |  |  | $ | 1,724 |  |
| Long-term |  |  | 1,437 |  |  |  | 1,473 |  |
| Total |  | $ | 3,046 |  |  | $ | 3,197 |  |

[0001564590-15-011213:notes:39]
[same as prior period, unchanged from 0001564590-15-007795:notes:39]


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-15-011213:notes:40]
6. Other income (expense), net

[0001564590-15-011213:notes:41]
Other income (expense), net consists of the following (in millions):

[0001564590-15-011213:notes:42]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Interest income |  | $ | 11 |  |  | $ | 8 |  |  | $ | 24 |  |  | $ | 16 |  |
| Interest expense |  |  | (12 | ) |  |  | (11 | ) |  |  | (23 | ) |  |  | (20 | ) |
| Other income (expense), net |  |  | — |  |  |  | (1 | ) |  |  | 2 |  |  |  | — |  |
| Total other income (expense), net |  | $ | (1 | ) |  | $ | (4 | ) |  | $ | 3 |  |  | $ | (4 | ) |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-15-011213:notes:43]
[same as prior period, unchanged from 0001564590-15-007795:notes:43]

[0001564590-15-011213:notes:44]
[same as prior period, unchanged from 0001564590-15-007795:notes:44]

[0001564590-15-011213:notes:45]
[same as prior period, unchanged from 0001564590-15-007795:notes:45]

[0001564590-15-011213:notes:46]
[same as prior period, unchanged from 0001564590-15-007795:notes:46]

[0001564590-15-011213:notes:47]
[same as prior period, unchanged from 0001564590-15-007795:notes:47]

[0001564590-15-011213:notes:48]
[same as prior period, unchanged from 0001564590-15-007795:notes:48]

[0001564590-15-011213:notes:49]
[same as prior period, unchanged from 0001564590-15-007795:notes:49]

[0001564590-15-011213:notes:50]
[same as prior period, unchanged from 0001564590-15-007795:notes:50]

[0001564590-15-011213:notes:51]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,614 |  |  | $ | 3 |  |  | $ | (2 | ) |  | $ | 1,615 |  |  | $ | 2,249 |  |  | $ | 9 |  |  | $ | — |  |  | $ | 2,258 |  |
| U.S. Treasury and government debt securities |  |  | 927 |  |  |  | 1 |  |  |  | (1 | ) |  |  | 927 |  |  |  | 1,056 |  |  |  | 2 |  |  |  | — |  |  |  | 1,058 |  |
| Foreign government debt securities |  |  | 44 |  |  |  | — |  |  |  | — |  |  |  | 44 |  |  |  | 38 |  |  |  | — |  |  |  | — |  |  |  | 38 |  |
| Commercial paper |  |  | 44 |  |  |  | — |  |  |  | — |  |  |  | 44 |  |  |  | 20 |  |  |  | — |  |  |  | — |  |  |  | 20 |  |
| Certificates of deposit |  |  | 109 |  |  |  | — |  |  |  | — |  |  |  | 109 |  |  |  | 286 |  |  |  | — |  |  |  | — |  |  |  | 286 |  |
| Mutual funds |  |  | 34 |  |  |  | — |  |  |  | — |  |  |  | 34 |  |  |  | 32 |  |  |  | — |  |  |  | — |  |  |  | 32 |  |
| Total debt and equity securities |  | $ | 2,772 |  |  | $ | 4 |  |  | $ | (3 | ) |  | $ | 2,773 |  |  | $ | 3,681 |  |  | $ | 11 |  |  | $ | — |  |  | $ | 3,692 |  |

[0001564590-15-011213:notes:52]
As of October 30, 2015, gross unrealized losses related to individual securities were not significant.

[0001564590-15-011213:notes:53]
The following table presents the contractual maturities of our debt investments as of October 30, 2015 (in millions):

[0001564590-15-011213:notes:54]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 867 |  |  | $ | 868 |  |
| Due after one year through five years |  |  | 1,871 |  |  |  | 1,871 |  |
|  |  | $ | 2,738 |  |  | $ | 2,739 |  |

[0001564590-15-011213:notes:55]
[same as prior period, unchanged from 0001564590-15-007795:notes:55]

[0001564590-15-011213:notes:56]
[same as prior period, unchanged from 0001564590-15-007795:notes:56]

[0001564590-15-011213:notes:57]
[same as prior period, unchanged from 0001564590-15-007795:notes:57]

[0001564590-15-011213:notes:58]
|  |  | October 30, 2015 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,075 |  |  | $ | 2,075 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,615 |  |  |  | — |  |  |  | 1,615 |  |
| U.S. Treasury and government debt securities |  |  | 927 |  |  |  | 175 |  |  |  | 752 |  |
| Foreign government debt securities |  |  | 44 |  |  |  | — |  |  |  | 44 |  |
| Commercial paper |  |  | 44 |  |  |  | — |  |  |  | 44 |  |
| Certificates of deposit |  |  | 109 |  |  |  | — |  |  |  | 109 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,814 |  |  | $ | 2,250 |  |  | $ | 2,564 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 27 |  |  | $ | 27 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |
| Long-term debt |  | $ | (1,489 | ) |  | $ | — |  |  | $ | (1,489 | ) |

[0001564590-15-011213:notes:59]
[same as prior period, unchanged from 0001564590-15-007795:notes:59]

[0001564590-15-011213:notes:60]
[same as prior period, unchanged from 0001564590-15-007795:notes:60]

[0001564590-15-011213:notes:61]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of October 30, 2015 and April 24, 2015, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-15-011213:notes:62]
[same as prior period, unchanged from 0001564590-15-007795:notes:63]

[0001564590-15-011213:notes:63]
The fair value of our long-term debt was based on observable market prices in a less active market. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-15-011213:notes:64]
8. Financing Arrangements

[0001564590-15-011213:notes:65]
Long-Term Debt

[0001564590-15-011213:notes:66]
The following table summarizes information relating to our long-term debt (in millions, except interest rates):

[0001564590-15-011213:notes:67]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (4 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,489 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |

[0001564590-15-011213:notes:68]
Senior Notes

[0001564590-15-011213:notes:69]
In June 2014, we issued $500 million par value of 3.375% Senior Notes due June 15, 2021, and received proceeds of approximately $495 million, net of discount and issuance costs. Our 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $750 million and $250 million, respectively, were issued in December 2012. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any future senior unsecured indebtedness.

[0001564590-15-011213:notes:70]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 30, 2015, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-15-011213:notes:71]
As of October 30, 2015, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-15-011213:notes:72]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| Thereafter |  |  | 750 |  |
| Total |  | $ | 1,500 |  |

[0001564590-15-011213:notes:73]
Credit Facility

[0001564590-15-011213:notes:74]
In December 2012, we entered into a credit agreement with a syndicated group of lenders that is scheduled to expire on December 21, 2017 and provides for an unsecured $250 million revolving credit facility that is comprised of revolving loans, Eurocurrency loans and/or swingline loans. The credit facility includes a $100 million foreign currency sub-facility, a $50 million letter of credit sub-facility and a $10 million swingline sub-facility available on same-day notice. Available borrowings under the credit facility are reduced by the amount of any outstanding borrowings on the sub-facilities. We may also, subject to certain requirements, request an increase in the facility up to an additional $100 million and request two additional one-year extensions, subject to certain conditions. The proceeds from the facility may be used by us for general corporate purposes.

[0001564590-15-011213:notes:75]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of October 30, 2015, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-15-011213:notes:76]
Other Long-Term Financing Arrangements

[0001564590-15-011213:notes:77]
The following presents the amounts due under other long-term financing arrangements (in millions):

[0001564590-15-011213:notes:78]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 12 |  |  | $ | 16 |  |
| Less: current portion |  |  | (7 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 5 |  |  | $ | 6 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-15-011213:notes:79]
[same as prior period, unchanged from 0001564590-15-007795:notes:80]

[0001564590-15-011213:notes:80]
[same as prior period, unchanged from 0001564590-15-007795:notes:81]

[0001564590-15-011213:notes:81]
As of October 30, 2015, we have outstanding certain equity incentive awards (awards), which include stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and Employee Stock Purchase Plan (ESPP) awards.

[0001564590-15-011213:notes:82]
[same as prior period, unchanged from 0001564590-15-007795:notes:83]

[0001564590-15-011213:notes:83]
The following table summarizes information related to our stock options (in millions, except exercise price and contractual term):

[0001564590-15-011213:notes:84]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 24, 2015 |  |  | 12 |  |  | $ | 37.74 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (1 | ) |  | $ | 22.89 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (2 | ) |  | $ | 38.99 |  |  |  |  |  |  |  |  |  |
| Outstanding as of October 30, 2015 |  |  | 9 |  |  | $ | 38.90 |  |  |  | 2.86 |  |  | $ | 12 |  |
| Vested and expected to vest as of October 30, 2015 |  |  | 9 |  |  | $ | 38.95 |  |  |  | 2.76 |  |  | $ | 12 |  |
| Exercisable as of October 30, 2015 |  |  | 7 |  |  | $ | 39.54 |  |  |  | 2.29 |  |  | $ | 11 |  |

[0001564590-15-011213:notes:85]
[same as prior period, unchanged from 0001564590-15-007795:notes:86]

[0001564590-15-011213:notes:86]
[same as prior period, unchanged from 0001564590-15-007795:notes:87]

[0001564590-15-011213:notes:87]
|  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Intrinsic value of exercises |  | $ | 8 |  |  | $ | 38 |  |
| Proceeds received from exercises |  | $ | 19 |  |  | $ | 65 |  |
| Fair value of options vested |  | $ | 7 |  |  | $ | 19 |  |

[0001564590-15-011213:notes:88]
[same as prior period, unchanged from 0001564590-15-007795:notes:89]

[0001564590-15-011213:notes:89]
In the six months ended October 30, 2015, we granted PBRSUs to certain of our executives, all of which were outstanding at the end of the period. Each PBRSU has performance-based vesting criteria (in addition to the service based vesting criteria) such that the PBRSU cliff-vests at the end of either an approximate two year or three year performance period, which began on the date specified in the grant agreement and ends the last day of fiscal 2017 or 2018, respectively. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted, and will depend upon our Total Stockholder Return (TSR) as compared to an index TSR (each expressed as a growth rate percentage) calculated as of the applicable period end date. The fair values of the PBRSUs were fixed at grant date using a Monte Carlo simulation model and the related aggregate compensation cost of $20 million is being recognized, adjusted for forfeitures, over the shorter of the remaining applicable performance or service periods.

[0001564590-15-011213:notes:90]
RSUs are converted into common stock upon vesting. Time-based RSUs generally vest with only service-based criteria at 25% annually over four years, except for the PBRSUs described above and 4 million time-based RSUs granted in the six months ended October 30, 2015, which will vest at 50% annually over two years.

[0001564590-15-011213:notes:91]
The following table summarizes information related to RSUs, including PBRSUs, (in millions, except for fair value):

[0001564590-15-011213:notes:92]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 24, 2015 |  |  | 13 |  |  | $ | 36.58 |  |
| Granted |  |  | 6 |  |  | $ | 31.32 |  |
| Vested |  |  | (4 | ) |  | $ | 37.70 |  |
| Forfeited |  |  | (2 | ) |  | $ | 35.32 |  |
| Outstanding as of October 30, 2015 |  |  | 13 |  |  | $ | 34.13 |  |

[0001564590-15-011213:notes:93]
[same as prior period, unchanged from 0001564590-15-007795:notes:94]

[0001564590-15-011213:notes:94]
|  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 44 |  |  | $ | 43 |  |

[0001564590-15-011213:notes:95]
[same as prior period, unchanged from 0001564590-15-007795:notes:96]

[0001564590-15-011213:notes:96]
[same as prior period, unchanged from 0001564590-15-007795:notes:97]

[0001564590-15-011213:notes:97]
|  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Shares issued under the ESPP |  |  | 2 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 50 |  |  | $ | 49 |  |

[0001564590-15-011213:notes:98]
[same as prior period, unchanged from 0001564590-15-007795:notes:99]

[0001564590-15-011213:notes:99]
[same as prior period, unchanged from 0001564590-15-007795:notes:100]

[0001564590-15-011213:notes:100]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | 3 |  |
| Cost of hardware maintenance and other services revenues |  |  | 4 |  |  |  | 3 |  |  |  | 10 |  |  |  | 8 |  |
| Sales and marketing |  |  | 26 |  |  |  | 30 |  |  |  | 57 |  |  |  | 57 |  |
| Research and development |  |  | 18 |  |  |  | 22 |  |  |  | 44 |  |  |  | 43 |  |
| General and administrative |  |  | 10 |  |  |  | 11 |  |  |  | 22 |  |  |  | 19 |  |
| Total stock-based compensation expense |  | $ | 59 |  |  | $ | 68 |  |  | $ | 136 |  |  | $ | 130 |  |

[0001564590-15-011213:notes:101]
As of October 30, 2015, total unrecognized compensation expense related to our equity awards was $381 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.0 years.

[0001564590-15-011213:notes:102]
[same as prior period, unchanged from 0001564590-15-007795:notes:103]

[0001564590-15-011213:notes:103]
|  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Income tax benefit associated with employee stock transactions |  | $ | 33 |  |  | $ | 58 |  |

[0001564590-15-011213:notes:104]
[same as prior period, unchanged from 0001564590-15-007795:notes:105]

[0001564590-15-011213:notes:105]
As of October 30, 2015, our Board of Directors has authorized the repurchase of up to $9.6 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management.

[0001564590-15-011213:notes:106]
The following table summarizes activity related to this program for the six months ended October 30, 2015 (in millions, except per share amounts):

[0001564590-15-011213:notes:107]
| Number of shares repurchased |  |  | 19 |  |
| Average price per share |  | $ | 31.70 |  |
| Aggregate purchase price |  | $ | 613 |  |
| Remaining authorization at end of period |  | $ | 1,847 |  |

[0001564590-15-011213:notes:108]
The aggregate purchase price of our stock repurchases for the six months ended October 30, 2015 consisted of $613 million of open market purchases, of which $499 million and $114 million was allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-15-011213:notes:109]
Since the May 13, 2003 inception of our stock repurchase program through October 30, 2015, we repurchased a total of 233 million shares of our common stock at an average price of $33.33 per share, for an aggregate purchase price of $7.8 billion.

[0001564590-15-011213:notes:110]
[same as prior period, unchanged from 0001564590-15-007795:notes:111]

[0001564590-15-011213:notes:111]
[same as prior period, unchanged from 0001564590-15-007795:notes:112]

[0001564590-15-011213:notes:112]
|  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Dividends per share declared |  | $ | 0.360 |  |  | $ | 0.330 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 84 |  |  | $ | 52 |  |
| Dividend payments allocated to retained earnings |  | $ | 23 |  |  | $ | 53 |  |

[0001564590-15-011213:notes:113]
On November 18, 2015, we declared a cash dividend of $0.18 per share of common stock, payable on January 20, 2016 to holders of record as of the close of business on January 8, 2016. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-15-011213:notes:114]
Retained Earnings

[0001564590-15-011213:notes:115]
A reconciliation of retained earnings is as follows (in millions):

[0001564590-15-011213:notes:116]
| Balance as of April 24, 2015 |  | $ | 53 |  |
| Net income |  |  | 84 |  |
| Repurchases of common stock |  |  | (114 | ) |
| Dividends |  |  | (23 | ) |
| Balance as of October 30, 2015 |  | $ | — |  |

[0001564590-15-011213:notes:117]
[same as prior period, unchanged from 0001564590-15-007795:notes:118]

[0001564590-15-011213:notes:118]
Changes in accumulated other comprehensive income (loss) (AOCI) by component, net of tax, are summarized below (in millions):

[0001564590-15-011213:notes:119]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 24, 2015 |  | $ | (23 | ) |  | $ | (13 | ) |  | $ | 11 |  |  | $ | 1 |  |  | $ | (24 | ) |
| OCI before reclassifications, net of tax |  |  | (2 | ) |  |  | — |  |  |  | (9 | ) |  |  | (3 | ) |  |  | (14 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | 2 |  |  |  | (1 | ) |  |  | 2 |  |  |  | 3 |  |
| Total OCI |  |  | (2 | ) |  |  | 2 |  |  |  | (10 | ) |  |  | (1 | ) |  |  | (11 | ) |
| Balance as of October 30, 2015 |  | $ | (25 | ) |  | $ | (11 | ) |  | $ | 1 |  |  | $ | — |  |  | $ | (35 | ) |

[0001564590-15-011213:notes:120]
[same as prior period, unchanged from 0001564590-15-007795:notes:121]

[0001564590-15-011213:notes:121]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |
| Recognized losses on defined benefit obligations |  | $ | 1 |  |  | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | Operating expenses |
| Realized gains on available-for-sale securities |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | — |  |  | Other income (expense), net |
| Realized losses on cash flow hedges |  |  | 1 |  |  |  | 4 |  |  |  | 2 |  |  |  | 6 |  |  | Net revenues |
| Total reclassifications |  | $ | 1 |  |  | $ | 4 |  |  | $ | 3 |  |  | $ | 6 |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-15-011213:notes:122]
[same as prior period, unchanged from 0001564590-15-007795:notes:123]

[0001564590-15-011213:notes:123]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of October 30, 2015 and April 24, 2015. We did not recognize any gains and losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-15-011213:notes:124]
[same as prior period, unchanged from 0001564590-15-007795:notes:125]

[0001564590-15-011213:notes:125]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 137 |  |  | $ | 94 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 159 |  |  | $ | 160 |  |
| Forward contracts purchased |  | $ | 311 |  |  | $ | 231 |  |

[0001564590-15-011213:notes:126]
[same as prior period, unchanged from 0001564590-15-007795:notes:127]

[0001564590-15-011213:notes:127]
The effect of derivative instruments not designated as hedging instruments recognized in other income (expense), net on our condensed consolidated statements of operations was as follows (in millions):

[0001564590-15-011213:notes:128]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |
|  |  | Loss Recognized into Income |  |  | Loss Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | — |  |  | $ | (1 | ) |  | $ | (7 | ) |  | $ | (2 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-15-011213:notes:129]
[same as prior period, unchanged from 0001564590-15-007795:notes:130]

[0001564590-15-011213:notes:130]
In May 2015, we initiated a realignment designed to drive efficiency, eliminate cost and redirect resources to our highest return activities, resulting in a reduction of our global workforce of approximately 3%, as well as other restructuring related activities. These activities were substantially completed in the second quarter of fiscal 2016. Restructuring charges consisted primarily of employee severance-related costs.

[0001564590-15-011213:notes:131]
[same as prior period, unchanged from 0001564590-15-007795:notes:132]

[0001564590-15-011213:notes:132]
|  |  | Six Months Ended October 30, 2015 |  |
|  |  | Employee Severance Related Costs |  |  | Other |  |  | Total |  |
| Balance at beginning of period |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net charges |  |  | 25 |  |  |  | 3 |  |  |  | 28 |  |
| Cash payments |  |  | (22 | ) |  |  | (1 | ) |  |  | (23 | ) |
| Balance at end of period |  | $ | 3 |  |  | $ | 2 |  |  | $ | 5 |  |

[0001564590-15-011213:notes:133]
[same as prior period, unchanged from 0001564590-15-007795:notes:134]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-15-011213:notes:134]
[same as prior period, unchanged from 0001564590-15-007795:notes:135]

[0001564590-15-011213:notes:135]
[same as prior period, unchanged from 0001564590-15-007795:notes:136]

[0001564590-15-011213:notes:136]
|  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Effective tax rates |  |  | 31.1 | % |  |  | 28.8 | % |

[0001564590-15-011213:notes:137]
Our effective tax rates reflect the impact of a significant amount of our earnings being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. In addition, our effective tax rates for the six months ended October 30, 2015 and October 24, 2014 were impacted by adjustments related to income tax audits as discussed below.

[0001564590-15-011213:notes:138]
In June 2015, the Internal Revenue Service (IRS) signed a closing agreement on transfer pricing arrangements and, in October 2015, completed the examination of our fiscal 2008 to 2010 income tax returns. During the three and six months ended October 30, 2015, we recorded discrete charges of $10 million and $23 million, respectively, attributable to transfer pricing and other audit settlements and the related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-15-011213:notes:139]
In July 2014, the IRS completed the examination of our fiscal 2005 to 2007 income tax returns upon approval by the Joint Committee of Taxation. During the six months ended October 24, 2014, we recorded a discrete charge of $47 million attributable to the audit settlements and related re-measurements of uncertain tax positions for tax years subject to future audits.

[0001564590-15-011213:notes:140]
In October 2014, the United Kingdom’s tax authority concluded the examination of our fiscal 2009 to 2012 UK income tax returns. We recorded a $1 million income tax benefit for the net impact of the audit adjustments and related release of uncertain tax positions.

[0001564590-15-011213:notes:141]
[same as prior period, unchanged from 0001564590-15-007795:notes:141]

[0001564590-15-011213:notes:142]
|  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Balance at beginning of period |  | $ | 272 |  |  | $ | 236 |  |
| Additions based on tax positions related to the current year |  |  | 7 |  |  |  | 13 |  |
| Additions for tax positions of prior years |  |  | 20 |  |  |  | 99 |  |
| Decreases for tax positions of prior years |  |  | (38 | ) |  |  | (19 | ) |
| Settlements |  |  | (52 | ) |  |  | (54 | ) |
| Balance at end of period |  | $ | 209 |  |  | $ | 275 |  |

[0001564590-15-011213:notes:143]
As of October 30, 2015, we had $209 million of gross unrecognized tax benefits, of which $158 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $148 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-15-011213:notes:144]
We are currently undergoing income tax audits in the United States (U.S.) and several foreign tax jurisdictions. Transfer pricing calculations are key issues under audits in various jurisdictions, and are often subject to dispute and appeals. The IRS has concluded the examination of our income tax returns for our fiscal years through 2010. We expect the IRS to commence the examination of subsequent years within the next twelve months.

[0001564590-15-011213:notes:145]
[same as prior period, unchanged from 0001564590-15-007795:notes:145]

[0001564590-15-011213:notes:146]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions.

[0001564590-15-011213:notes:147]
On July 27, 2015, in Altera Corp. v. Commissioner, the U.S. Tax Court issued an opinion related to the treatment of stock-based compensation expense in an intercompany cost-sharing arrangement. A final decision has yet to be issued by the Tax Court due to other outstanding issues related to the case. At this time, the U.S. Department of the Treasury has not withdrawn the requirement to include stock-based compensation from its regulations. Due to the uncertainty surrounding the status of the current regulations, questions related to the scope of potential benefits, and the risk of the Tax Court’s decision being overturned upon appeal, we have not recorded any benefit as of October 30, 2015. We will continue to monitor ongoing developments and potential impacts to our financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001564590-15-011213:notes:148]
13. Net Income per Share

[0001564590-15-011213:notes:149]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0001564590-15-011213:notes:150]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 114 |  |  | $ | 160 |  |  | $ | 84 |  |  | $ | 248 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 294 |  |  |  | 318 |  |  |  | 299 |  |  |  | 321 |  |
| Dilutive impact of employee equity award plans |  |  | 2 |  |  |  | 5 |  |  |  | 3 |  |  |  | 5 |  |
| Shares used in diluted computation |  |  | 296 |  |  |  | 323 |  |  |  | 302 |  |  |  | 326 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.39 |  |  | $ | 0.50 |  |  | $ | 0.28 |  |  | $ | 0.77 |  |
| Diluted |  | $ | 0.39 |  |  | $ | 0.49 |  |  | $ | 0.28 |  |  | $ | 0.76 |  |

[0001564590-15-011213:notes:151]
We have excluded 19 million and 7 million weighted-average shares of common stock potentially issuable under employee equity award plans in the three months ended October 30, 2015 and October 24, 2014, respectively, and 14 million and 8 million shares of common stock potentially issuable under employee equity award plans in the six months ended October 30, 2015 and October 24, 2014, respectively, from the diluted net income per share calculations as their effect would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-15-011213:notes:152]
[same as prior period, unchanged from 0001564590-15-007795:notes:152]

[0001564590-15-011213:notes:153]
[same as prior period, unchanged from 0001564590-15-007795:notes:153]

[0001564590-15-011213:notes:154]
[same as prior period, unchanged from 0001564590-15-007795:notes:154]

[0001564590-15-011213:notes:155]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| United States, Canada and Latin America (Americas) |  | $ | 819 |  |  | $ | 906 |  |  | $ | 1,564 |  |  | $ | 1,737 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 430 |  |  |  | 438 |  |  |  | 845 |  |  |  | 883 |  |
| Asia Pacific (APAC) |  |  | 196 |  |  |  | 199 |  |  |  | 371 |  |  |  | 412 |  |
| Net revenues |  | $ | 1,445 |  |  | $ | 1,543 |  |  | $ | 2,780 |  |  | $ | 3,032 |  |

[0001564590-15-011213:notes:156]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $743 million and $817 million during the three months ended October 30, 2015 and October 24, 2014, respectively, and were $1,408 million and $1,563 million during the six months ended October 30, 2015 and October 24, 2014, respectively.

[0001564590-15-011213:notes:157]
[same as prior period, unchanged from 0001564590-15-007795:notes:157]

[0001564590-15-011213:notes:158]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| U.S. |  | $ | 665 |  |  | $ | 596 |  |
| International |  |  | 4,149 |  |  |  | 4,730 |  |
| Total |  | $ | 4,814 |  |  | $ | 5,326 |  |

[0001564590-15-011213:notes:159]
[same as prior period, unchanged from 0001564590-15-007795:notes:159]

[0001564590-15-011213:notes:160]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| U.S. |  | $ | 890 |  |  | $ | 927 |  |
| International |  |  | 114 |  |  |  | 103 |  |
| Total |  | $ | 1,004 |  |  | $ | 1,030 |  |

[0001564590-15-011213:notes:161]
[same as prior period, unchanged from 0001564590-15-007795:notes:161]

[0001564590-15-011213:notes:162]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 24 | % |  |  | 22 | % |  |  | 23 | % |
| Avnet, Inc. |  |  | 19 | % |  |  | 17 | % |  |  | 18 | % |  |  | 17 | % |

[0001564590-15-011213:notes:163]
[same as prior period, unchanged from 0001564590-15-007795:notes:163]

[0001564590-15-011213:notes:164]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Arrow Electronics, Inc. |  |  | 12 | % |  |  | 14 | % |
| Avnet, Inc. |  |  | 14 | % |  |  | 16 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-15-011213:notes:165]
15. Commitments and Contingencies

[0001564590-15-011213:notes:166]
Operating Leases

[0001564590-15-011213:notes:167]
We lease various equipment, vehicles and office space in the U.S. and internationally.

[0001564590-15-011213:notes:168]
Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $204 million as of October 30, 2015.

[0001564590-15-011213:notes:169]
Purchase Orders and Other Commitments

[0001564590-15-011213:notes:170]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of October 30, 2015, we had $262 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 30, 2015 and April 24, 2015, such liability amounted to $12 million and $17 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-15-011213:notes:171]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 30, 2015, we had $36 million in construction related obligations and $172 million in other purchase obligations.

[0001564590-15-011213:notes:172]
Financing Guarantees

[0001564590-15-011213:notes:173]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $72 million and $89 million of receivables during the six months ended October 30, 2015 and October 24, 2014, respectively.

[0001564590-15-011213:notes:174]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-15-011213:notes:175]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of October 30, 2015 and April 24, 2015, the aggregate amount by which such contingencies exceeded the associated deferred revenue was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001564590-15-011213:notes:176]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 30, 2015, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-15-011213:notes:177]
Legal Contingencies

[0001564590-15-011213:notes:178]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict, and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-15-011213:notes:179]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of October 30, 2015 related to such matters as they are not probable and/or reasonably estimable.
