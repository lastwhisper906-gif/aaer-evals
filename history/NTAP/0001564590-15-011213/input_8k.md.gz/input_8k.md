# NTAP 8-K — 0001199073-15-000156 filed 2015-11-18

## item codes, every 8-K on or before 2015-12-02

- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2015-12-02

- none on or before 2015-12-02

## item 2.02 — earnings release, exhibit 99.1

[0001199073-15-000156:8k_2_02:1]
EX-99
2
exh99_1.htm
EXHIBIT 99.1

[0001199073-15-000156:8k_2_02:2]
Exhibit 99.1

[0001199073-15-000156:8k_2_02:3]
Press Contact:                                                                                    Investor Contact:

[0001199073-15-000156:8k_2_02:4]
Meghan Fintland                                                                               Kris Newton

[0001199073-15-000156:8k_2_02:5]
NetApp                                                                                                       NetApp

[0001199073-15-000156:8k_2_02:6]
1 408 822 1389                                                                                       1 408 822 3312

[0001199073-15-000156:8k_2_02:7]
meghan.fintland@netapp.com                                             kris.newton@netapp.com

[0001199073-15-000156:8k_2_02:8]
NETAPP REPORTS SECOND QUARTER FISCAL YEAR 2016 RESULTS

[0001199073-15-000156:8k_2_02:9]
Net Revenues of $1.45 Billion, Up 8% Quarter-over-Quarter; GAAP EPS of $0.39 and Non-GAAP EPS of $0.61

[0001199073-15-000156:8k_2_02:10]
| · | Product revenue of $815 million, Up 23% quarter-over-quarter |

[0001199073-15-000156:8k_2_02:11]
| · | All Flash FAS units grew 246% quarter-over-quarter |

[0001199073-15-000156:8k_2_02:12]
| · | Flash capacity grew 80% quarter-over-quarter |

[0001199073-15-000156:8k_2_02:13]
Sunnyvale, Calif.—November 18, 2015—NetApp (NASDAQ: NTAP) today reported financial results for the second quarter of fiscal year 2016, ended October 30, 2015.

[0001199073-15-000156:8k_2_02:14]
Second Quarter Financial Results

[0001199073-15-000156:8k_2_02:15]
Net revenues for the second quarter of fiscal year 2016 were $1.45 billion. GAAP net income for the second quarter of fiscal year 2016 was $114 million, or $0.39 income per share1 , compared to GAAP net income of $160 million, or $0.49 income per share, for the comparable period of the prior year. Non-GAAP net income for the second quarter of fiscal year 2016 was $181 million, or $0.61 income per share,2 compared to non-GAAP net income of $226 million, or $0.70 income per share, for the comparable period of the prior year.

[0001199073-15-000156:8k_2_02:16]
Cash, Cash Equivalents and Investments

[0001199073-15-000156:8k_2_02:17]
NetApp ended the second quarter of fiscal year 2016 with $4.8 billion in total cash, cash equivalents and investments and generated $145 million in cash from operations. During the second quarter of fiscal year 2016, the Company returned $236 million to shareholders through share repurchases and a cash dividend.

[0001199073-15-000156:8k_2_02:18]
The next dividend in the amount of $0.18 per share will be paid on January 20, 2016, to shareholders of record as of the close of business on January 8, 2016.

[0001199073-15-000156:8k_2_02:19]
"Our Q2 results reflect the progress we are making to pivot NetApp for long-term growth in the data powered digital era. We are moving forward with clarity and speed to better address the changing industry and improve our own execution," said George Kurian, CEO. "Customer wins and partner feedback drive my strong conviction that our industry leading portfolio and differentiated Data Fabric strategy will expand our opportunity and drive long-term growth."

[0001199073-15-000156:8k_2_02:20]
Q3 Fiscal Year 2016 Outlook

[0001199073-15-000156:8k_2_02:21]
The Company provided the following financial guidance for the third quarter of fiscal year 2016:

[0001199073-15-000156:8k_2_02:22]
| · | Net revenues are expected to be in the range of $1.40 billion to $1.50 billion. |

[0001199073-15-000156:8k_2_02:23]
| · | GAAP earnings per share is expected to be in the range of $0.47 to $0.52 per share. |

[0001199073-15-000156:8k_2_02:24]
| · | Non-GAAP earnings per share is expected to be in the range of $0.66 to $0.71 per share. |

[0001199073-15-000156:8k_2_02:25]
Business Highlights

[0001199073-15-000156:8k_2_02:26]
| · | NetApp Accelerates Customer and Partner Journey in Hybrid Cloud and Flash Environments: |

[0001199073-15-000156:8k_2_02:27]
|  | - | Guarantees 3X Performance For All-Flash Workloads. NetApp extended a special offer for buyers of select all-flash systems guaranteeing a 3X increase in enterprise database performance compared to that of traditional, non-flash disk-based systems.3 |

[0001199073-15-000156:8k_2_02:28]
|  | - | Makes the Hybrid Cloud More Secure. NetApp unveiled NetApp OnCommand® Cloud Manager 2.0 and integration with Amazon Simple Storage Service Standard-Infrequent Access (Amazon S3 Standard-IA). |

[0001199073-15-000156:8k_2_02:29]
|  | - | Offers Free Controller Upgrade. Eligible customers who purchase a three-year SupportEdge Premium contract by December 31, 2015 now qualify for a new All-Flash FAS (AFF) controller free of charge as part of the renewal process.4 |

[0001199073-15-000156:8k_2_02:30]
|  | - | Extends Support Price Protection. NetApp enabled customers to extend their standard three-year warranty and support for up to four more years. |

[0001199073-15-000156:8k_2_02:31]
|  | - | Offers New AFF Series Model. The new AFF8080 EX can be set up to address mainstream SAN workloads in as little as 15 minutes. |

[0001199073-15-000156:8k_2_02:32]
|  | - | Expands OpenStack Capabilities. As founder of the OpenStack Manila open-source project, NetApp announced production-ready capabilities for enterprises to easily build or enhance a cloud-ready data center capable of handling business-critical and content-management applications. |

[0001199073-15-000156:8k_2_02:33]
| · | NetApp Insight® Technical Conference Showcases How Data Fabric Increases Customer Success in the Hybrid Cloud: |

[0001199073-15-000156:8k_2_02:34]
|  | - | Data Fabric Solution Essentials. NetApp starter kits make it easier for customers to become hybrid cloud ready and quickly see benefits as they evolve their infrastructures. |

[0001199073-15-000156:8k_2_02:35]
|  | - | Data Fabric Enablement Services. NetApp experts help customers identify optimal workloads for the cloud and gain the architectural design and deployment insights they need for success. |

[0001199073-15-000156:8k_2_02:36]
|  | - | Expansion of Cloud Service Provider Relationships. NetApp is now a Google Cloud Platform Technology Partner, providing tools which integrate to extend reach and functionality. |

[0001199073-15-000156:8k_2_02:37]
| · | NetApp Celebrates Business and Cultural Milestones: |

[0001199073-15-000156:8k_2_02:38]
|  | - | Cisco and NetApp Celebrate Five Years of FlexPod® Customer Success. FlexPod integrated infrastructure solutions deliver unprecedented value to customers with shared revenue of $5.6 billion. |

[0001199073-15-000156:8k_2_02:39]
|  | - | NetApp Named #4 World's Best Multinational Workplaces. For the fifth consecutive year, NetApp's unique culture earned the company a top-five position on this prestigious list by Great Place to Work. |

[0001199073-15-000156:8k_2_02:40]
Webcast and Conference Call Information

[0001199073-15-000156:8k_2_02:41]
NetApp will host a conference call to discuss these results today at 2 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4 p.m. Pacific Time today.

[0001199073-15-000156:8k_2_02:42]
About NetApp

[0001199073-15-000156:8k_2_02:43]
Leading organizations worldwide count on NetApp for software, systems and services to manage and store their data. Customers value our teamwork, expertise and passion for helping them succeed now and into the future. To learn more visit http://www.netapp.com.

[0001199073-15-000156:8k_2_02:44]
###

[0001199073-15-000156:8k_2_02:45]
NetApp, the NetApp logo, FlexPod, NetApp Insight, and OnCommand are trademarks or registered trademarks of NetApp, Inc. in the United States and/or other countries. All other marks are the property of their respective owners.

[0001199073-15-000156:8k_2_02:46]
1Net income per share is calculated using the diluted number of shares.

[0001199073-15-000156:8k_2_02:47]
2Non-GAAP net income excludes, when applicable, the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-reoccurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company's tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) the impact of a temporary lapse of tax law, such as the federal research credit, if such extensions have routinely been granted based on past legislative history and are expected to be reinstated in the near future. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com.

[0001199073-15-000156:8k_2_02:48]
3Terms and conditions are available at www.netapp.com/us/media/netapp-3x-performance-guarantee.pdf.

[0001199073-15-000156:8k_2_02:49]
4Additional information is available at https://mysupport.netapp.com/ecm/ecm_get_file/ECMP12520009.

[0001199073-15-000156:8k_2_02:50]
NetApp Usage of Non-GAAP Financials

[0001199073-15-000156:8k_2_02:51]
The Company refers to the non-GAAP financial measures in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes, when applicable, the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-reoccurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company's tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) the impact of a temporary lapse of tax law, such as the federal research credit, if such extensions have routinely been granted based on past legislative history and are expected to be reinstated in the near future. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods.

[0001199073-15-000156:8k_2_02:52]
We have excluded these items in order to enhance investors' understanding of our ongoing operations. The use of these non-GAAP financial measures has limitations and they should not solely be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we provide non-GAAP financial measures in conjunction with GAAP financial measures.

[0001199073-15-000156:8k_2_02:53]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors' operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation.

[0001199073-15-000156:8k_2_02:54]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,814 |  |  | $ | 5,326 |  |
| Accounts receivable |  |  | 587 |  |  |  | 779 |  |
| Inventories |  |  | 125 |  |  |  | 146 |  |
| Other current assets |  |  | 555 |  |  |  | 522 |  |
| Total current assets |  |  | 6,081 |  |  |  | 6,773 |  |
| Property and equipment, net |  |  | 1,004 |  |  |  | 1,030 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,078 |  |  |  | 1,117 |  |
| Other non-current assets |  |  | 472 |  |  |  | 481 |  |
| Total assets |  | $ | 8,635 |  |  | $ | 9,401 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 226 |  |  | $ | 284 |  |
| Accrued expenses |  |  | 618 |  |  |  | 701 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,609 |  |  |  | 1,724 |  |
| Total current liabilities |  |  | 2,453 |  |  |  | 2,709 |  |
| Long-term debt |  |  | 1,489 |  |  |  | 1,487 |  |
| Other long-term liabilities |  |  | 269 |  |  |  | 318 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,437 |  |  |  | 1,473 |  |
| Total liabilities |  |  | 5,648 |  |  |  | 5,987 |  |
| Stockholders' equity |  |  | 2,987 |  |  |  | 3,414 |  |
| Total liabilities and stockholders' equity |  | $ | 8,635 |  |  | $ | 9,401 |  |

[0001199073-15-000156:8k_2_02:55]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 815 |  |  | $ | 929 |  |  | $ | 1,479 |  |  | $ | 1,812 |  |
| Software maintenance |  |  | 233 |  |  |  | 225 |  |  |  | 481 |  |  |  | 446 |  |
| Hardware maintenance and other services |  |  | 397 |  |  |  | 389 |  |  |  | 820 |  |  |  | 774 |  |
| Net revenues |  |  | 1,445 |  |  |  | 1,543 |  |  |  | 2,780 |  |  |  | 3,032 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 408 |  |  |  | 402 |  |  |  | 753 |  |  |  | 796 |  |
| Cost of software maintenance |  |  | 9 |  |  |  | 9 |  |  |  | 19 |  |  |  | 17 |  |
| Cost of hardware maintenance and other services |  |  | 144 |  |  |  | 149 |  |  |  | 308 |  |  |  | 298 |  |
| Total cost of revenues |  |  | 561 |  |  |  | 560 |  |  |  | 1,080 |  |  |  | 1,111 |  |
| Gross profit |  |  | 884 |  |  |  | 983 |  |  |  | 1,700 |  |  |  | 1,921 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 448 |  |  |  | 488 |  |  |  | 940 |  |  |  | 968 |  |
| Research and development |  |  | 216 |  |  |  | 229 |  |  |  | 460 |  |  |  | 457 |  |
| General and administrative |  |  | 74 |  |  |  | 73 |  |  |  | 153 |  |  |  | 143 |  |
| Restructuring and other charges |  |  | 1 |  |  |  | - |  |  |  | 28 |  |  |  | - |  |
| Total operating expenses |  |  | 739 |  |  |  | 790 |  |  |  | 1,581 |  |  |  | 1,568 |  |
| Income from operations |  |  | 145 |  |  |  | 193 |  |  |  | 119 |  |  |  | 353 |  |
| Other income (expense), net |  |  | (1 | ) |  |  | (4 | ) |  |  | 3 |  |  |  | (4 | ) |
| Income before income taxes |  |  | 144 |  |  |  | 189 |  |  |  | 122 |  |  |  | 349 |  |
| Provision for income taxes |  |  | 30 |  |  |  | 29 |  |  |  | 38 |  |  |  | 101 |  |
| Net income |  | $ | 114 |  |  | $ | 160 |  |  | $ | 84 |  |  | $ | 248 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.39 |  |  | $ | 0.50 |  |  | $ | 0.28 |  |  | $ | 0.77 |  |
| Diluted |  | $ | 0.39 |  |  | $ | 0.49 |  |  | $ | 0.28 |  |  | $ | 0.76 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 294 |  |  |  | 318 |  |  |  | 299 |  |  |  | 321 |  |
| Diluted |  |  | 296 |  |  |  | 323 |  |  |  | 302 |  |  |  | 326 |  |
| Cash dividends declared per share |  | $ | 0.180 |  |  | $ | 0.165 |  |  | $ | 0.360 |  |  | $ | 0.330 |  |

[0001199073-15-000156:8k_2_02:56]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 114 |  |  | $ | 160 |  |  | $ | 84 |  |  | $ | 248 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 67 |  |  |  | 77 |  |  |  | 136 |  |  |  | 155 |  |
| Stock-based compensation |  |  | 59 |  |  |  | 68 |  |  |  | 136 |  |  |  | 130 |  |
| Excess tax benefit from stock-based compensation |  |  | (2 | ) |  |  | (6 | ) |  |  | (4 | ) |  |  | (49 | ) |
| Other, net |  |  | 12 |  |  |  | 4 |  |  |  | (22 | ) |  |  | 50 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (172 | ) |  |  | (49 | ) |  |  | 189 |  |  |  | 222 |  |
| Inventories |  |  | 68 |  |  |  | (3 | ) |  |  | 21 |  |  |  | 15 |  |
| Accounts payable |  |  | (27 | ) |  |  | 30 |  |  |  | (60 | ) |  |  | (32 | ) |
| Accrued expenses |  |  | 31 |  |  |  | 91 |  |  |  | (88 | ) |  |  | (136 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (16 | ) |  |  | (19 | ) |  |  | (137 | ) |  |  | (45 | ) |
| Changes in other operating assets and liabilities, net |  |  | 11 |  |  |  | 28 |  |  |  | 19 |  |  |  | 39 |  |
| Net cash provided by operating activities |  |  | 145 |  |  |  | 381 |  |  |  | 274 |  |  |  | 597 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 10 |  |  |  | 170 |  |  |  | 788 |  |  |  | 361 |  |
| Purchases of property and equipment |  |  | (46 | ) |  |  | (51 | ) |  |  | (84 | ) |  |  | (109 | ) |
| Other investing activities, net |  |  | (2 | ) |  |  | (1 | ) |  |  | - |  |  |  | (1 | ) |
| Net cash provided by (used in) investing activities |  |  | (38 | ) |  |  | 118 |  |  |  | 704 |  |  |  | 251 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 6 |  |  |  | 43 |  |  |  | 25 |  |  |  | 71 |  |
| Repurchase of common stock |  |  | (183 | ) |  |  | (600 | ) |  |  | (613 | ) |  |  | (719 | ) |
| Excess tax benefit from stock-based compensation |  |  | 2 |  |  |  | 6 |  |  |  | 4 |  |  |  | 49 |  |
| Issuance of long-term debt, net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 495 |  |
| Dividends paid |  |  | (53 | ) |  |  | (52 | ) |  |  | (107 | ) |  |  | (105 | ) |
| Other financing activities, net |  |  | (2 | ) |  |  | (2 | ) |  |  | (3 | ) |  |  | (4 | ) |
| Net cash used in financing activities |  |  | (230 | ) |  |  | (605 | ) |  |  | (694 | ) |  |  | (213 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (3 | ) |  |  | (21 | ) |  |  | (8 | ) |  |  | (21 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (126 | ) |  |  | (127 | ) |  |  | 276 |  |  |  | 614 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,324 |  |  |  | 3,032 |  |  |  | 1,922 |  |  |  | 2,291 |  |
| End of period |  | $ | 2,198 |  |  | $ | 2,905 |  |  | $ | 2,198 |  |  | $ | 2,905 |  |

[0001199073-15-000156:8k_2_02:57]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO and Inventory Turns) |  |
| (Unaudited) |  |
|  | Q2 FY'16 |  | Q1 FY'16 |  | Q2 FY'15 |  |
| Revenues |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 815 |  |  | $ | 664 |  |  | $ | 929 |  |
| Software Maintenance |  | $ | 233 |  |  | $ | 248 |  |  | $ | 225 |  |
| Hardware Maintenance & Other Services: |  | $ | 397 |  |  | $ | 423 |  |  | $ | 389 |  |
| Hardware Maintenance Support Contracts |  | $ | 326 |  |  | $ | 346 |  |  | $ | 311 |  |
| Professional and Other Services |  | $ | 71 |  |  | $ | 77 |  |  | $ | 78 |  |
| Net Revenues |  | $ | 1,445 |  |  | $ | 1,335 |  |  | $ | 1,543 |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  | % of Q2 FY'16 Revenue |  | % of Q1 FY'16 Revenue |  | % of Q2 FY'15 Revenue |  |
| Americas |  |  | 57 | % |  |  | 56 | % |  |  | 59 | % |
| Americas Commercial |  |  | 42 | % |  |  | 44 | % |  |  | 42 | % |
| U.S. Public Sector |  |  | 14 | % |  |  | 12 | % |  |  | 17 | % |
| EMEA |  |  | 30 | % |  |  | 31 | % |  |  | 28 | % |
| Asia Pacific |  |  | 14 | % |  |  | 13 | % |  |  | 13 | % |
| Pathways Mix |  |
|  | % of Q2 FY'16 Revenue |  | % of Q1 FY'16 Revenue |  | % of Q2 FY'15 Revenue |  |
| Direct |  |  | 23 | % |  |  | 22 | % |  |  | 21 | % |
| Indirect |  |  | 77 | % |  |  | 77 | % |  |  | 79 | % |
| Direct revenues are those sold through our direct sales force and, effective Q1 FY'16, include those sold to service providers. Indirect revenues include those sold through value-added resellers, system integrators, OEMs and distributors. Indirect revenue reflects order fulfillment and is not reflective of who is responsible for the customer relationship. |  |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Q2 FY'16 |  | Q1 FY'16 |  | Q2 FY'15 |  |
| Non-GAAP Gross Margin |  |  | 62.5 | % |  |  | 63.6 | % |  |  | 65.0 | % |
| Product |  |  | 51.8 | % |  |  | 51.2 | % |  |  | 58.4 | % |
| Software Maintenance |  |  | 96.1 | % |  |  | 96.2 | % |  |  | 96.2 | % |
| Hardware Maintenance & Other Services |  |  | 64.7 | % |  |  | 64.1 | % |  |  | 62.7 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Q2 FY'16 |  | Q1 FY'16 |  | Q2 FY'15 |  |
| Non-GAAP Income from Operations |  | $ | 219 |  |  | $ | 103 |  |  | $ | 275 |  |
| % of Net Revenues |  |  | 15.2 | % |  |  | 7.7 | % |  |  | 17.8 | % |
| Non-GAAP Income before Income Taxes |  | $ | 218 |  |  | $ | 107 |  |  | $ | 271 |  |
| Non-GAAP Effective Tax Rate |  |  | 17.0 | % |  |  | 17.0 | % |  |  | 16.5 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Q2 FY'16 |  | Q1 FY'16 |  | Q2 FY'15 |  |
| Non-GAAP Net Income |  | $ | 181 |  |  | $ | 89 |  |  | $ | 226 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 296 |  |  |  | 308 |  |  |  | 323 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 0.61 |  |  | $ | 0.29 |  |  | $ | 0.70 |  |

[0001199073-15-000156:8k_2_02:58]
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |
|  | Q2 FY'16 |  | Q1 FY'16 |  | Q2 FY'15 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,046 |  |  | $ | 3,066 |  |  | $ | 3,047 |  |
| DSO (days) |  |  | 37 |  |  |  | 30 |  |  |  | 37 |  |
| Inventory Turns |  |  | 17 |  |  |  | 10 |  |  |  | 20 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. Inventory turns is defined as annualized non-GAAP cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Q2 FY'16 |  | Q1 FY'16 |  | Q2 FY'15 |  |
| Net Cash Provided by Operating Activities |  | $ | 145 |  |  | $ | 129 |  |  | $ | 381 |  |
| Purchases of Property and Equipment |  | $ | 46 |  |  | $ | 38 |  |  | $ | 51 |  |
| Free Cash Flow |  | $ | 99 |  |  | $ | 91 |  |  | $ | 330 |  |
| Free Cash Flow as % of Net Revenues |  |  | 6.9 | % |  |  | 6.8 | % |  |  | 21.4 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. Some items may not add or recalculate due to rounding. |  |

[0001199073-15-000156:8k_2_02:59]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY16 |  |  | Q1'FY16 |  |  | Q2'FY15 |  |
| NET INCOME (LOSS) |  | $ | 114 |  |  | $ | (30 | ) |  | $ | 160 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 59 |  |  |  | 77 |  |  |  | 68 |  |
| Asset impairment |  |  | - |  |  |  | 11 |  |  |  | - |  |
| Restructuring and other charges |  |  | 1 |  |  |  | 27 |  |  |  | - |  |
| Income tax effect of non-GAAP adjustments |  |  | (17 | ) |  |  | (23 | ) |  |  | (16 | ) |
| Settlement of income tax audit |  |  | 10 |  |  |  | 13 |  |  |  | - |  |
| NON-GAAP NET INCOME |  | $ | 181 |  |  | $ | 89 |  |  | $ | 226 |  |
| COST OF REVENUES |  | $ | 561 |  |  | $ | 519 |  |  | $ | 560 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14 | ) |  |  | (14 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (8 | ) |  |  | (5 | ) |
| Asset impairment |  |  | - |  |  |  | (11 | ) |  |  | - |  |
| NON-GAAP COST OF REVENUES |  | $ | 542 |  |  | $ | 486 |  |  | $ | 540 |  |
| COST OF PRODUCT REVENUES |  | $ | 408 |  |  | $ | 345 |  |  | $ | 402 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14 | ) |  |  | (14 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (2 | ) |  |  | (2 | ) |
| Asset impairment |  |  | - |  |  |  | (5 | ) |  |  | - |  |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 393 |  |  | $ | 324 |  |  | $ | 387 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 144 |  |  | $ | 164 |  |  | $ | 149 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (4 | ) |  |  | (6 | ) |  |  | (3 | ) |
| Asset impairment |  |  | - |  |  |  | (6 | ) |  |  | - |  |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 140 |  |  | $ | 152 |  |  | $ | 145 |  |
| GROSS PROFIT |  | $ | 884 |  |  | $ | 816 |  |  | $ | 983 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 5 |  |  |  | 8 |  |  |  | 5 |  |
| Asset impairment |  |  | - |  |  |  | 11 |  |  |  | - |  |
| NON-GAAP GROSS PROFIT |  | $ | 903 |  |  | $ | 849 |  |  | $ | 1,002 |  |
| SALES AND MARKETING EXPENSES |  | $ | 448 |  |  | $ | 492 |  |  | $ | 488 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (26 | ) |  |  | (31 | ) |  |  | (30 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 422 |  |  | $ | 461 |  |  | $ | 457 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 216 |  |  | $ | 244 |  |  | $ | 229 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (18 | ) |  |  | (26 | ) |  |  | (22 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 198 |  |  | $ | 218 |  |  | $ | 208 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 74 |  |  | $ | 79 |  |  | $ | 73 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (10 | ) |  |  | (12 | ) |  |  | (11 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 64 |  |  | $ | 67 |  |  | $ | 62 |  |

[0001199073-15-000156:8k_2_02:60]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY16 |  |  | Q1'FY16 |  |  | Q2'FY15 |  |
| RESTRUCTURING AND OTHER CHARGES |  | $ | 1 |  |  | $ | 27 |  |  | $ | - |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  |  | (1 | ) |  |  | (27 | ) |  |  | - |  |
| NON-GAAP RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| OPERATING EXPENSES |  | $ | 739 |  |  | $ | 842 |  |  | $ | 790 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (54 | ) |  |  | (69 | ) |  |  | (63 | ) |
| Restructuring and other charges |  |  | (1 | ) |  |  | (27 | ) |  |  | - |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 684 |  |  | $ | 746 |  |  | $ | 728 |  |
| INCOME (LOSS) FROM OPERATIONS |  | $ | 145 |  |  | $ | (26 | ) |  | $ | 193 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 59 |  |  |  | 77 |  |  |  | 68 |  |
| Asset impairment |  |  | - |  |  |  | 11 |  |  |  | - |  |
| Restructuring and other charges |  |  | 1 |  |  |  | 27 |  |  |  | - |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 219 |  |  | $ | 103 |  |  | $ | 275 |  |
| INCOME (LOSS) BEFORE INCOME TAXES |  | $ | 144 |  |  | $ | (22 | ) |  | $ | 189 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 59 |  |  |  | 77 |  |  |  | 68 |  |
| Asset impairment |  |  | - |  |  |  | 11 |  |  |  | - |  |
| Restructuring and other charges |  |  | 1 |  |  |  | 27 |  |  |  | - |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 218 |  |  | $ | 107 |  |  | $ | 271 |  |
| PROVISION FOR INCOME TAXES |  | $ | 30 |  |  | $ | 8 |  |  | $ | 29 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | 17 |  |  |  | 23 |  |  |  | 16 |  |
| Settlement of income tax audit |  |  | (10 | ) |  |  | (13 | ) |  |  | - |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 37 |  |  | $ | 18 |  |  | $ | 45 |  |
| NET INCOME (LOSS) PER SHARE |  | $ | 0.39 |  |  | $ | (0.10 | ) |  | $ | 0.49 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.04 |  |
| Stock-based compensation |  |  | 0.20 |  |  |  | 0.25 |  |  |  | 0.21 |  |
| Asset impairment |  |  | - |  |  |  | 0.04 |  |  |  | - |  |
| Restructuring and other charges |  |  | - |  |  |  | 0.09 |  |  |  | - |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.06 | ) |  |  | (0.08 | ) |  |  | (0.05 | ) |
| Settlement of income tax audit |  |  | 0.03 |  |  |  | 0.04 |  |  |  | - |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.61 |  |  | $ | 0.29 |  |  | $ | 0.70 |  |

[0001199073-15-000156:8k_2_02:61]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY16 |  |  | Q1'FY16 |  |  | Q2'FY15 |  |
| Gross margin-GAAP |  |  | 61.2 | % |  |  | 61.1 | % |  |  | 63.7 | % |
| Cost of revenues adjustments |  |  | 1.3 | % |  |  | 2.5 | % |  |  | 1.3 | % |
| Gross margin-Non-GAAP |  |  | 62.5 | % |  |  | 63.6 | % |  |  | 65.0 | % |
| GAAP cost of revenues |  | $ | 561 |  |  | $ | 519 |  |  | $ | 560 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14 | ) |  |  | (14 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (8 | ) |  |  | (5 | ) |
| Asset impairment |  |  | - |  |  |  | (11 | ) |  |  | - |  |
| Non-GAAP cost of revenues |  | $ | 542 |  |  | $ | 486 |  |  | $ | 540 |  |
| Net revenues |  | $ | 1,445 |  |  | $ | 1,335 |  |  | $ | 1,543 |  |

[0001199073-15-000156:8k_2_02:62]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY16 |  |  | Q1'FY16 |  |  | Q2'FY15 |  |
| Product gross margin-GAAP |  |  | 49.9 | % |  |  | 48.0 | % |  |  | 56.8 | % |
| Cost of product revenues adjustments |  |  | 1.8 | % |  |  | 3.2 | % |  |  | 1.6 | % |
| Product gross margin-Non-GAAP |  |  | 51.8 | % |  |  | 51.2 | % |  |  | 58.4 | % |
| GAAP cost of product revenues |  | $ | 408 |  |  | $ | 345 |  |  | $ | 402 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14 | ) |  |  | (14 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (2 | ) |  |  | (2 | ) |
| Asset impairment |  |  | - |  |  |  | (5 | ) |  |  | - |  |
| Non-GAAP cost of product revenues |  | $ | 393 |  |  | $ | 324 |  |  | $ | 387 |  |
| Product revenues |  | $ | 815 |  |  | $ | 664 |  |  | $ | 929 |  |

[0001199073-15-000156:8k_2_02:63]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY16 |  |  | Q1'FY16 |  |  | Q2'FY15 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 63.7 | % |  |  | 61.2 | % |  |  | 61.6 | % |
|  | Cost of hardware maintenance and other services revenues adjustments |  |  | 1.0 | % |  |  | 2.8 | % |  |  | 1.2 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 64.7 | % |  |  | 64.1 | % |  |  | 62.7 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 144 |  |  | $ | 164 |  |  | $ | 149 |  |
| Cost of hardware maintenance and other services revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Stock-based compensation |  |  | (4 | ) |  |  | (6 | ) |  |  | (3 | ) |
|  | Asset impairment |  |  | - |  |  |  | (6 | ) |  |  | - |  |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 140 |  |  | $ | 152 |  |  | $ | 145 |  |
| Hardware maintenance and other services revenues |  | $ | 397 |  |  | $ | 423 |  |  | $ | 389 |  |

[0001199073-15-000156:8k_2_02:64]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  | Q2'FY16 |  | Q1'FY16 |  | Q2'FY15 |  |
| GAAP effective tax rate |  |  | 20.8 | % |  |  | (36.4 | %) |  |  | 15.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | 0.8 | % |  |  | 65.5 | % |  |  | 1.1 | % |
| Settlement of income tax audit |  |  | (4.6 | %) |  |  | (12.1 | %) |  |  | - | % |
| Non-GAAP effective tax rate |  |  | 17.0 | % |  |  | 17.0 | % |  |  | 16.5 | % |

[0001199073-15-000156:8k_2_02:65]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  | Q2'FY16 |  | Q1'FY16 |  | Q2'FY15 |  |
| Net cash provided by operating activities |  | $ | 145 |  |  | $ | 129 |  |  | $ | 381 |  |
| Purchases of property and equipment |  |  | (46 | ) |  |  | (38 | ) |  |  | (51 | ) |
| Free cash flow |  | $ | 99 |  |  | $ | 91 |  |  | $ | 330 |  |

[0001199073-15-000156:8k_2_02:66]
| INVENTORY TURNS AND RECONCILIATION OF NON-GAAP TO GAAP |  |
| COST OF REVENUES USED IN INVENTORY TURNS |  |
| (In millions, except annualized inventory turns) |  |
|  |  | Q2'FY16 |  |  | Q1'FY16 |  |  | Q2'FY15 |  |
| Annualized inventory turns-GAAP |  |  | 18 |  |  |  | 11 |  |  |  | 21 |  |
| Cost of revenues adjustments |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Annualized inventory turns-Non-GAAP |  |  | 17 |  |  |  | 10 |  |  |  | 20 |  |
| GAAP cost of revenues |  | $ | 561 |  |  | $ | 519 |  |  | $ | 560 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14 | ) |  |  | (14 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (8 | ) |  |  | (5 | ) |
| Asset impairment |  |  | - |  |  |  | (11 | ) |  |  | - |  |
| Non-GAAP cost of revenues |  | $ | 542 |  |  | $ | 486 |  |  | $ | 540 |  |
| Inventory |  | $ | 125 |  |  | $ | 193 |  |  | $ | 108 |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |

[0001199073-15-000156:8k_2_02:67]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| THIRD QUARTER FISCAL 2016 |
|  |  | Third Quarter |
|  |  | Fiscal 2016 |
| Non-GAAP Guidance - Net Income Per Share |  | $0.66 - $0.71 |
| Adjustments of Specific Items to Net Income Per Share for the Third Quarter Fiscal 2016: |  |  |
|  | Amortization of intangible assets |  | (0.05) |
|  | Stock-based compensation expense |  | (0.19) |
|  | Income tax effect of non-GAAP adjustments |  | 0.05 |
| Total Adjustments |  | (0.19) |
| GAAP Guidance - Net Income Per Share |  | $0.47 - $0.52 |

## item 5.02 — body, verbatim

[0001199073-15-000156:8k_body:1]
Item 5.02  Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001199073-15-000156:8k_body:2]
On November 18, 2015, NetApp, Inc. (the "Company") announced that Robert Salmon has decided to retire from his position as President of the Company, effective as of the end of the Company's fiscal year 2016.
