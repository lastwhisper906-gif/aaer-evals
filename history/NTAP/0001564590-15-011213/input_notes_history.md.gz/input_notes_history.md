# NTAP note change history — 0001564590-15-007795 → 0001564590-15-011213


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-12-02):
[0001564590-15-011213:note_history:1]
Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $204 million as of October 30, 2015.
  (was, 2015-09-08, similarity 0.9639):
[0001564590-15-007795:note_history:1]
Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $205 million as of July 31, 2015.

- changed (2015-12-02):
[0001564590-15-011213:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of October 30, 2015, we had $262 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 30, 2015 and April 24, 2015, such liability amounted to $12 million and $17 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2015-09-08, similarity 0.9889):
[0001564590-15-007795:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of July 31, 2015, we had $262 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 31, 2015 and April 24, 2015, such liability amounted to $16 million and $17 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2015-12-02):
[0001564590-15-011213:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 30, 2015, we had $36 million in construction related obligations and $172 million in other purchase obligations.
  (was, 2015-09-08, similarity 0.9849):
[0001564590-15-007795:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 31, 2015, we had $45 million in construction related obligations and $178 million in other purchase obligations.

- changed (2015-12-02):
[0001564590-15-011213:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $72 million and $89 million of receivables during the six months ended October 30, 2015 and October 24, 2014, respectively.
  (was, 2015-09-08, similarity 0.8587):
[0001564590-15-007795:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $42 million and $52 million, respectively, of receivables during the three months ended July 31, 2015 and July 25, 2014.

- changed (2015-12-02):
[0001564590-15-011213:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of October 30, 2015 and April 24, 2015, the aggregate amount by which such contingencies exceeded the associated deferred revenue was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.
  (was, 2015-09-08, similarity 0.9593):
[0001564590-15-007795:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of July 31, 2015 and April 24, 2015, the aggregate amount by which such contingencies exceeded the associated deferred revenue was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

- added (2015-12-02):
[0001564590-15-011213:note_history:6]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 30, 2015, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- changed (2015-12-02):
[0001564590-15-011213:note_history:7]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of October 30, 2015 related to such matters as they are not probable and/or reasonably estimable.
  (was, 2015-09-08, similarity 0.9753):
[0001564590-15-007795:note_history:7]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of July 31, 2015 related to such matters as they are not probable and/or reasonably estimable.

- removed (2015-12-02):
[0001564590-15-007795:note_history:8]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 31, 2015, we have not been required to make any payments under these arrangements and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-12-02):
[0001564590-15-011213:note_history:9]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2016, ending on April 29, 2016, is a 53-week year, with 14 weeks in its first quarter and 13 weeks in each subsequent quarter. Fiscal year 2015, which ended on April 24, 2015, was a 52-week year, with 13 weeks in each of its quarters.
  (was, 2015-09-08, similarity 0.7203):
[0001564590-15-007795:note_history:9]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2016, ending on April 29, 2016 is a 53-week year, with a 14th week included in its first quarter. Fiscal year 2015, which ended on April 24, 2015, was a 52-week year, with 13 weeks in its first quarter.

- changed (2015-12-02):
[0001564590-15-011213:note_history:10]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income (loss) and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2015 contained in our Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 12, 2015. The results of operations for the three and six months ended October 30, 2015 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2015-09-08, similarity 0.9024):
[0001564590-15-007795:note_history:10]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income (loss) and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2015 contained in our Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 12, 2015. The results of operations for the three months ended July 31, 2015 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- changed (2015-12-02):
[0001564590-15-011213:note_history:11]
There have been no significant changes in our significant accounting policies as of and for the six months ended October 30, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 24, 2015.
  (was, 2015-09-08, similarity 0.9625):
[0001564590-15-007795:note_history:11]
There have been no significant changes in our significant accounting policies as of and for the three months ended July 31, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 24, 2015.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-12-02):
[0001564590-15-011213:note_history:12]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (4 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,489 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |
  (was, 2015-09-08, similarity 0.9919):
[0001564590-15-007795:note_history:12]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (5 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,488 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |

- changed (2015-12-02):
[0001564590-15-011213:note_history:13]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 30, 2015, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2015-09-08, similarity 0.9914):
[0001564590-15-007795:note_history:13]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 31, 2015, we were in compliance with all covenants associated with the Senior Notes.

- changed (2015-12-02):
[0001564590-15-011213:note_history:14]
As of October 30, 2015, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2015-09-08, similarity 0.9405):
[0001564590-15-007795:note_history:14]
As of July 31, 2015, our aggregate future principal debt maturities are as follows (in millions):

- changed (2015-12-02):
[0001564590-15-011213:note_history:15]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of October 30, 2015, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.
  (was, 2015-09-08, similarity 0.9949):
[0001564590-15-007795:note_history:15]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of July 31, 2015, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

- changed (2015-12-02):
[0001564590-15-011213:note_history:16]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 12 |  |  | $ | 16 |  |
| Less: current portion |  |  | (7 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 5 |  |  | $ | 6 |  |
  (was, 2015-09-08, similarity 0.9775):
[0001564590-15-007795:note_history:16]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 14 |  |  | $ | 16 |  |
| Less: current portion |  |  | (9 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 5 |  |  | $ | 6 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-12-02):
[0001564590-15-011213:note_history:17]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 12 |  |  | $ | 16 |  |
| Less: current portion |  |  | (7 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 5 |  |  | $ | 6 |  |
  (was, 2015-09-08, similarity 0.9775):
[0001564590-15-007795:note_history:17]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 14 |  |  | $ | 16 |  |
| Less: current portion |  |  | (9 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 5 |  |  | $ | 6 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-12-02):
[0001564590-15-011213:note_history:18]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (4 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,489 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |
  (was, 2015-09-08, similarity 0.9919):
[0001564590-15-007795:note_history:18]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (5 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,488 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-12-02):
[0001564590-15-011213:note_history:19]
As of October 30, 2015, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2015-09-08, similarity 0.9405):
[0001564590-15-007795:note_history:19]
As of July 31, 2015, our aggregate future principal debt maturities are as follows (in millions):


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2015-12-02):
[0001564590-15-011213:note_history:20]
Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights.
  (was, 2015-09-08, similarity 0.9988):
[0001564590-15-007795:note_history:20]
Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights.
