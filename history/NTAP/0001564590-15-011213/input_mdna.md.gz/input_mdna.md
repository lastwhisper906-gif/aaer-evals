# NTAP MD&A — 0001564590-15-011213


## mdna

[0001564590-15-011213:mdna:1]
Item 2. Management’s Discussion and Analysis of Financial Condition and Results of Operations.

[0001564590-15-011213:mdna:2]
[same as prior period, unchanged from 0001564590-15-007795:mdna:2]

[0001564590-15-011213:mdna:3]
[same as prior period, unchanged from 0001564590-15-007795:mdna:3]

[0001564590-15-011213:mdna:4]
[same as prior period, unchanged from 0001564590-15-007795:mdna:4]

[0001564590-15-011213:mdna:5]
[same as prior period, unchanged from 0001564590-15-007795:mdna:5]

[0001564590-15-011213:mdna:6]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Net revenues |  | $ | 1,445 |  |  | $ | 1,543 |  |  | $ | 2,780 |  |  | $ | 3,032 |  |
| Gross profit |  | $ | 884 |  |  | $ | 983 |  |  | $ | 1,700 |  |  | $ | 1,921 |  |
| Gross profit margin percentage |  |  | 61 | % |  |  | 64 | % |  |  | 61 | % |  |  | 63 | % |
| Income from operations |  | $ | 145 |  |  | $ | 193 |  |  | $ | 119 |  |  | $ | 353 |  |
| Income from operations as a percentage of net revenues |  |  | 10 | % |  |  | 13 | % |  |  | 4 | % |  |  | 12 | % |
| Net income |  | $ | 114 |  |  | $ | 160 |  |  | $ | 84 |  |  | $ | 248 |  |
| Diluted net income per share |  | $ | 0.39 |  |  | $ | 0.49 |  |  | $ | 0.28 |  |  | $ | 0.76 |  |
| Operating cash flows |  | $ | 145 |  |  | $ | 381 |  |  | $ | 274 |  |  | $ | 597 |  |

[0001564590-15-011213:mdna:7]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,046 |  |  | $ | 3,197 |  |
| Days sales outstanding (DSO) |  |  | 37 |  |  |  | 46 |  |

[0001564590-15-011213:mdna:8]
[same as prior period, unchanged from 0001564590-15-007795:mdna:8]

[0001564590-15-011213:mdna:9]
[same as prior period, unchanged from 0001564590-15-007795:mdna:9]

[0001564590-15-011213:mdna:10]
[same as prior period, unchanged from 0001564590-15-007795:mdna:10]

[0001564590-15-011213:mdna:11]
[same as prior period, unchanged from 0001564590-15-007795:mdna:11]

[0001564590-15-011213:mdna:12]
[same as prior period, unchanged from 0001564590-15-007795:mdna:12]

[0001564590-15-011213:mdna:13]
[same as prior period, unchanged from 0001564590-15-007795:mdna:13]

[0001564590-15-011213:mdna:14]
Our fiscal year is reported on a 52- or 53-week year that ends on the last Friday in April. Fiscal year 2016, ending April 29, 2016, is a 53-week year, with its first quarter spanning 14 weeks and each subsequent quarter spanning 13 weeks. Fiscal year 2015, ended April 24, 2015, was a 52-week year, and each of its quarters spanned 13 weeks. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0001564590-15-011213:mdna:15]
23

[0001564590-15-011213:mdna:16]
[same as prior period, unchanged from 0001564590-15-007795:mdna:15]

[0001564590-15-011213:mdna:17]
|  |  | Three Months Ended |  |  | Six Months Ended |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 56 |  | % |  | 60 |  | % |  | 53 |  | % |  | 60 |  | % |
| Software maintenance |  |  | 16 |  |  |  | 15 |  |  |  | 17 |  |  |  | 15 |  |  |
| Hardware maintenance and other services |  |  | 27 |  |  |  | 25 |  |  |  | 29 |  |  |  | 26 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 28 |  |  |  | 26 |  |  |  | 27 |  |  |  | 26 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 10 |  |  |  | 10 |  |  |  | 11 |  |  |  | 10 |  |  |
| Gross profit |  |  | 61 |  |  |  | 64 |  |  |  | 61 |  |  |  | 63 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 31 |  |  |  | 32 |  |  |  | 34 |  |  |  | 32 |  |  |
| Research and development |  |  | 15 |  |  |  | 15 |  |  |  | 17 |  |  |  | 15 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 6 |  |  |  | 5 |  |  |
| Restructuring and other charges |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | — |  |  |
| Total operating expenses |  |  | 51 |  |  |  | 51 |  |  |  | 57 |  |  |  | 52 |  |  |
| Income from operations |  |  | 10 |  |  |  | 13 |  |  |  | 4 |  |  |  | 12 |  |  |
| Other income (expense), net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Income before income taxes |  |  | 10 |  |  |  | 12 |  |  |  | 4 |  |  |  | 12 |  |  |
| Provision for income taxes |  |  | 2 |  |  |  | 2 |  |  |  | 1 |  |  |  | 3 |  |  |
| Net income |  |  | 8 |  | % |  | 10 |  | % |  | 3 |  | % |  | 8 |  | % |

[0001564590-15-011213:mdna:18]
[same as prior period, unchanged from 0001564590-15-007795:mdna:17]

[0001564590-15-011213:mdna:19]
[same as prior period, unchanged from 0001564590-15-007795:mdna:18]

[0001564590-15-011213:mdna:20]
[same as prior period, unchanged from 0001564590-15-007795:mdna:19]

[0001564590-15-011213:mdna:21]
Net revenues for the second quarter and first six months of fiscal 2016 were $1,445 million, reflecting a decrease of $98 million, or 6%, and $2,780 million, reflecting a decrease of $252 million, or 8%, respectively, compared to the corresponding periods of the prior year. Revenues for the second quarter and six months of fiscal 2016 were negatively impacted by foreign exchange rate changes, higher discounting and unfavorable product mix.

[0001564590-15-011213:mdna:22]
Gross profit as a percentage of net revenues decreased 3 and 2 percentage points during the second quarter and first six months of fiscal 2016, respectively, compared to the corresponding periods of the prior year, reflecting the factors discussed above.

[0001564590-15-011213:mdna:23]
Sales and marketing, research and development, and general and administrative expenses for the second quarter and first six months of fiscal 2016 totaled $738 million, or 51% as a percentage of net revenues, and $1,553 million, or 56% as a percentage of net revenues, respectively, compared to $790 million, or 51% as a percentage of net revenues, and $1,568 million, or 52% as a percentage of net revenues, respectively, for the corresponding periods of the prior year. The decrease in expenses in dollars was primarily due to the favorable impact of foreign exchange rate fluctuations and cost containment initiatives, partially offset in the first six months of fiscal 2016 by the additional week in the first quarter of fiscal 2016. In addition, such expenses as a percentage of net revenues were unfavorably impacted by lower revenues in the second quarter and first six months of fiscal 2016 compared to the corresponding periods in the prior year.

[0001564590-15-011213:mdna:24]
[same as prior period, unchanged from 0001564590-15-007795:mdna:23]

[0001564590-15-011213:mdna:25]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |
| Net revenues | $ | 1,445 |  |  | $ | 1,543 |  |  |  | (6 | )% |  | $ | 2,780 |  |  | $ | 3,032 |  |  |  | (8 | )% |

[0001564590-15-011213:mdna:26]
24

[0001564590-15-011213:mdna:27]
The decrease in net revenues for the second quarter of fiscal 2016 was due to a $114 million decrease in product revenues, partially offset by a $16 million increase in the aggregate of software maintenance and hardware maintenance and other services revenues. Product revenues comprised 56% of net revenues for the second quarter of fiscal 2016, compared to 60% for the corresponding period of the prior year.

[0001564590-15-011213:mdna:28]
The decrease in net revenues for the first six months of fiscal 2016 was due to a $333 million decrease in product revenues, partially offset by an $81 million increase in the aggregate of software maintenance and hardware maintenance and other services revenues. Product revenues comprised 53% of net revenues for the first six months of fiscal 2016, compared to 60% for the corresponding period of the prior year.

[0001564590-15-011213:mdna:29]
Sales through our indirect channels represented 77% of net revenues for each of the second quarter and first six months of fiscal 2016, compared to 79% and 78% of net revenues for the corresponding periods of the prior year.

[0001564590-15-011213:mdna:30]
[same as prior period, unchanged from 0001564590-15-007795:mdna:27]

[0001564590-15-011213:mdna:31]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 24 | % |  |  | 22 | % |  |  | 23 | % |
| Avnet, Inc. |  |  | 19 | % |  |  | 17 | % |  |  | 18 | % |  |  | 17 | % |

[0001564590-15-011213:mdna:32]
[same as prior period, unchanged from 0001564590-15-007795:mdna:29]

[0001564590-15-011213:mdna:33]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |
| Product revenues | $ | 815 |  |  | $ | 929 |  |  |  | (12 | )% |  | $ | 1,479 |  |  | $ | 1,812 |  |  |  | (18 | )% |

[0001564590-15-011213:mdna:34]
[same as prior period, unchanged from 0001564590-15-007795:mdna:31]

[0001564590-15-011213:mdna:35]
Total configured system revenues of $523 million decreased by $35 million, or 6%, for the second quarter of fiscal 2016, compared to the corresponding period of the prior year. Revenues decreased in the entry level and mid-range FAS systems platforms, but increased in the high end FAS and the E-series systems platforms. Total configured systems unit volume increased 9% due to unit volume increases in all systems platforms reflecting higher demand for our newer products. Average selling prices (ASPs) for the entry level and mid-range FAS systems platforms decreased and were partially offset by increases in the high end FAS and E-Series systems platforms. The overall ASP for configured systems decreased due to foreign exchange impacts, higher discounting due to competitive pressures and unfavorable product mix.

[0001564590-15-011213:mdna:36]
Non-configured product revenues of $292 million decreased by $79 million, or 21%, during the second quarter of fiscal 2016, compared to the corresponding period of the prior year. This decrease was primarily due to a decrease in OEM product revenues of $41 million, or 36%, reflecting changing business dynamics of our OEM customers, and a decrease in add-on storage revenue of $39 million, or 26%, reflecting lower average pricing for add-on storage equipment and unfavorable product mix.

[0001564590-15-011213:mdna:37]
Total configured system revenues of $917 million decreased by $167 million, or 15%, for the first six months of fiscal 2016, compared to the corresponding period of the prior year. Revenues decreased in all FAS systems platforms, but increased in E-series systems platforms. Total configured systems unit volume decreased 4%, due to a decrease in unit volume across all FAS system platforms, partially offset by a unit volume increase in E-series systems platforms. These changes in unit volume reflect the impact to our business of a storage technology industry in transition as customers drive IT transformation to take advantage of new technologies and architectures, while planning their journey to the hybrid cloud. In addition, the decline in product revenues reflects the transition from products based on our older Data ONTAP 7-mode technology to products based on clustered Data ONTAP technology. Overall ASPs decreased for all configured systems platforms due to foreign exchange impacts, higher discounting due to competitive pressures and unfavorable product mix.

[0001564590-15-011213:mdna:38]
Non-configured product revenues of $563 million decreased $165 million, or 23%, for the first six months of fiscal 2016, compared to the corresponding period of the prior year. This decrease was primarily due to a decrease in OEM product revenues of $79 million, or 34%, and a decrease in add-on storage revenue of $102 million, or 33% each reflecting the factors discussed above.

[0001564590-15-011213:mdna:39]
[same as prior period, unchanged from 0001564590-15-007795:mdna:38]

[0001564590-15-011213:mdna:40]
[same as prior period, unchanged from 0001564590-15-007795:mdna:34]

[0001564590-15-011213:mdna:41]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |
| Software maintenance revenues | $ | 233 |  |  | $ | 225 |  |  |  | 4 | % |  | $ | 481 |  |  | $ | 446 |  |  |  | 8 | % |

[0001564590-15-011213:mdna:42]
[same as prior period, unchanged from 0001564590-15-007795:mdna:36]

[0001564590-15-011213:mdna:43]
The fluctuations in software maintenance revenues reflect fluctuations in the aggregate contract value of the installed base under software maintenance contracts, which is recognized as revenue ratably over the terms of the underlying contracts. Software maintenance contract revenues for the first six months of fiscal 2016 were also favorably impacted by the additional week of deferred revenue amortization in the first quarter of fiscal 2016.

[0001564590-15-011213:mdna:44]
[same as prior period, unchanged from 0001564590-15-007795:mdna:39]

[0001564590-15-011213:mdna:45]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |
| Hardware maintenance and other services revenues | $ | 397 |  |  | $ | 389 |  |  |  | 2 | % |  | $ | 820 |  |  | $ | 774 |  |  |  | 6 | % |

[0001564590-15-011213:mdna:46]
[same as prior period, unchanged from 0001564590-15-007795:mdna:41]

[0001564590-15-011213:mdna:47]
Hardware maintenance contract revenues were $326 million and $311 million for the second quarters of fiscal 2016 and 2015, respectively, reflecting an increase of 5% due to an increase in the installed base and aggregate contract values under hardware maintenance contracts, and higher levels of shorter term contract renewals from our existing contract base, which resulted in a lower weighted average maintenance contract term. Professional services and educational and training services revenues were $71 million and $78 million in aggregate for the second quarters of fiscal 2016 and 2015, respectively.

[0001564590-15-011213:mdna:48]
Hardware maintenance contract revenues were $672 million and $614 million for first six months of fiscal 2016 and 2015, respectively, reflecting an increase of 9% due to the factors discussed above, as well as the favorable impact of an additional week of deferred revenue amortization. Professional services and educational and training services revenues aggregated to $148 million and $161 million for the first six months of fiscal 2016 and 2015, respectively.

[0001564590-15-011213:mdna:49]
[same as prior period, unchanged from 0001564590-15-007795:mdna:43]

[0001564590-15-011213:mdna:50]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | October 30, 2015 |  |  | October 24, 2014 |  |
| United States, Canada and Latin America (Americas) |  |  | 57 | % |  |  | 59 | % |  |  | 56 | % |  |  | 57 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 30 | % |  |  | 28 | % |  |  | 30 | % |  |  | 29 | % |
| Asia Pacific (APAC) |  |  | 14 | % |  |  | 13 | % |  |  | 13 | % |  |  | 14 | % |

[0001564590-15-011213:mdna:51]
[same as prior period, unchanged from 0001564590-15-007795:mdna:45]

[0001564590-15-011213:mdna:52]
Americas revenues consist of sales to Americas commercial and United States public sector (USPS) markets. Our Americas revenues decreased in the second quarter and first six months of fiscal 2016 compared to the corresponding periods in the prior year, due to a decrease in sales to the USPS markets.

[0001564590-15-011213:mdna:53]
[same as prior period, unchanged from 0001564590-15-007795:mdna:47]

[0001564590-15-011213:mdna:54]
[same as prior period, unchanged from 0001564590-15-007795:mdna:48]

[0001564590-15-011213:mdna:55]
[same as prior period, unchanged from 0001564590-15-007795:mdna:56]

[0001564590-15-011213:mdna:56]
[same as prior period, unchanged from 0001564590-15-007795:mdna:49]

[0001564590-15-011213:mdna:57]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |
| Cost of product revenues | $ | 408 |  |  | $ | 402 |  |  |  | 1 | % |  | $ | 753 |  |  | $ | 796 |  |  |  | (5 | )% |

[0001564590-15-011213:mdna:58]
[same as prior period, unchanged from 0001564590-15-007795:mdna:51]

[0001564590-15-011213:mdna:59]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2016 to Fiscal 2015 |  |  | Fiscal 2016 to Fiscal 2015 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | 1 |  |  |  | (7 | ) |
| Warranty |  |  | 1 |  |  |  | — |  |
| Excess and obsolete inventory |  |  | — |  |  |  | 2 |  |
| Other |  |  | (1 | ) |  |  | — |  |
| Total change |  |  | 1 |  |  |  | (5 | ) |

[0001564590-15-011213:mdna:60]
Cost of product revenues represented 50% and 51% of product revenues for the second quarter and first six months of fiscal 2016, respectively, compared to 43% and 44% of product revenues for the corresponding periods of the prior year.

[0001564590-15-011213:mdna:61]
Materials costs represented 86% of product costs for each of the second quarters of fiscal 2016 and 2015, respectively. Materials costs increased slightly in the second quarter of fiscal 2016 compared to the corresponding period of the prior year, as a result of a 9% increase in configured systems unit volume. Increases in average materials costs for high end FAS and E-series systems platforms were offset by decreases in average materials costs for entry level and mid-level FAS series systems platforms, resulting in a slight increase in overall standard materials costs for configured systems. Product materials costs were favorably impacted by a decrease in materials costs on OEM and add-on storage revenues, reflecting lower sales levels and changes in mix in the second quarter of fiscal 2016 compared to the prior year.

[0001564590-15-011213:mdna:62]
Materials costs represented 83% and 86% of product costs for the first six months of fiscal 2016 and 2015, respectively. Materials costs decreased $57 million in the first six months of fiscal 2016 compared to the corresponding period of the prior year. Materials costs were impacted by a 4% unit volume decrease in configured systems. Increases in average materials costs for entry level and high end FAS systems platforms, partially offset by decreases in average materials costs for mid-level FAS and E-series systems platforms, reflected higher component costs of new product offerings. Overall materials unit costs increased due to the factors above, as well as changes in our product mix. Product materials costs were favorably impacted by a decrease in materials costs on OEM and add-on storage revenues, reflecting lower sales levels and changes in mix in the first six months of fiscal 2016 compared to the prior year. The decrease in aggregate materials costs was partially offset by a $5 million increase in write-downs of excess and obsolete inventory in the first six months of fiscal 2016 compared to the corresponding period of the prior year.

[0001564590-15-011213:mdna:63]
[same as prior period, unchanged from 0001564590-15-007795:mdna:58]

[0001564590-15-011213:mdna:64]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |
| Cost of software maintenance revenues | $ | 9 |  |  | $ | 9 |  |  |  | — | % |  | $ | 19 |  |  | $ | 17 |  |  |  | 12 | % |

[0001564590-15-011213:mdna:65]
Cost of software maintenance revenues did not change significantly during the second quarter and first six months of fiscal 2016 compared to the corresponding periods of the prior year. Cost of software maintenance revenues represented 4% of software maintenance revenues for each of the second quarters and first six months of fiscal 2016 and 2015.

[0001564590-15-011213:mdna:66]
[same as prior period, unchanged from 0001564590-15-007795:mdna:61]

[0001564590-15-011213:mdna:67]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues | $ | 144 |  |  | $ | 149 |  |  |  | (3 | )% |  | $ | 308 |  |  | $ | 298 |  |  |  | 3 | % |

[0001564590-15-011213:mdna:68]
Cost of hardware maintenance and other services revenues decreased during the second quarter of fiscal 2016 compared to the corresponding period of the prior year, primarily due to lower spares and contracted services costs. Costs of hardware maintenance and other services revenues increased during the first six months of fiscal 2016 due to higher salaries and benefits and an asset impairment charge recorded in the first quarter of fiscal 2016, partially offset by lower spares and contracted services costs.

[0001564590-15-011213:mdna:69]
[same as prior period, unchanged from 0001564590-15-007795:mdna:73]

[0001564590-15-011213:mdna:70]
[same as prior period, unchanged from 0001564590-15-007795:mdna:64]

[0001564590-15-011213:mdna:71]
[same as prior period, unchanged from 0001564590-15-007795:mdna:65]

[0001564590-15-011213:mdna:72]
[same as prior period, unchanged from 0001564590-15-007795:mdna:66]

[0001564590-15-011213:mdna:73]
Total compensation costs included in operating expenses decreased $27 million, or 6%, for the second quarter of fiscal 2016 compared to the corresponding period of the prior year primarily due to lower salaries and stock-based compensation expenses, reflecting a 3% decrease in average headcount, and the favorable impact of foreign exchange rate fluctuations.

[0001564590-15-011213:mdna:74]
Total compensation costs included in operating expenses increased $27 million, or 3%, for the first six months of fiscal 2016 compared to the corresponding period of the prior year, reflecting higher salaries and related benefits expenses due to the additional week in the first quarter of fiscal 2016, partially offset by the favorable impact of foreign exchange rate fluctuations.

[0001564590-15-011213:mdna:75]
[same as prior period, unchanged from 0001564590-15-007795:mdna:68]

[0001564590-15-011213:mdna:76]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |
| Sales and marketing expenses | $ | 448 |  |  | $ | 488 |  |  |  | (8 | )% |  | $ | 940 |  |  | $ | 968 |  |  |  | (3 | )% |

[0001564590-15-011213:mdna:77]
[same as prior period, unchanged from 0001564590-15-007795:mdna:70]

[0001564590-15-011213:mdna:78]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2016 to Fiscal 2015 |  |  | Fiscal 2016 to Fiscal 2015 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (4 | ) |  |  | — |  |
| Commissions |  |  | (1 | ) |  |  | (1 | ) |
| Outside services |  |  | (1 | ) |  |  | (1 | ) |
| Facilities and IT support costs |  |  | (2 | ) |  |  | (1 | ) |
| Total change |  |  | (8 | ) |  |  | (3 | ) |

[0001564590-15-011213:mdna:79]
The decrease in compensation costs for the second quarter of fiscal 2016 compared to the corresponding period of the prior year was primarily due to lower salaries, stock-based compensation expense and other compensation-related costs attributable in part to the favorable impact of foreign exchange rate fluctuations. Compensation costs for the first six months of fiscal 2016 did not vary significantly from those of the corresponding period in the prior year. The decrease in commissions expense for the second quarter and first six months of fiscal 2016 reflects lower bookings achievement compared to the corresponding periods of the prior year. The decrease in outside services expense reflects lower spending levels on contractors and projects. Facilities and IT support costs decreased primarily due to cost containment efforts.

[0001564590-15-011213:mdna:80]
[same as prior period, unchanged from 0001564590-15-007795:mdna:74]

[0001564590-15-011213:mdna:81]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |
| Research and development expenses | $ | 216 |  |  | $ | 229 |  |  |  | (6 | )% |  | $ | 460 |  |  | $ | 457 |  |  |  | 1 | % |

[0001564590-15-011213:mdna:82]
[same as prior period, unchanged from 0001564590-15-007795:mdna:76]

[0001564590-15-011213:mdna:83]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2016 to Fiscal 2015 |  |  | Fiscal 2016 to Fiscal 2015 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (4 | ) |  |  | 2 |  |
| Depreciation |  |  | (1 | ) |  |  | (1 | ) |
| Facilities and IT support costs |  |  | (1 | ) |  |  | — |  |
| Total change |  |  | (6 | ) |  |  | 1 |  |

[0001564590-15-011213:mdna:84]
28

[0001564590-15-011213:mdna:85]
The decrease in compensation costs for the second quarter of fiscal 2016 compared to the corresponding period of the prior year was primarily due to lower salaries and stock-based compensation expenses, reflecting lower average headcount, partially offset by higher average salaries per employee. The increase in compensation costs in the first six months of fiscal 2016 was primarily due to higher salaries and related benefits expenses and other compensation-related costs as a result of the extra week in the first quarter of fiscal 2016, partially offset by lower average headcount. Depreciation expense decreased primarily due to certain equipment becoming fully depreciated in prior periods. Facilities and IT support costs decreased for the second quarter of fiscal 2016 compared to the second quarter of the prior year primarily due to cost containment efforts.

[0001564590-15-011213:mdna:86]
[same as prior period, unchanged from 0001564590-15-007795:mdna:79]

[0001564590-15-011213:mdna:87]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |
| General and administrative expenses | $ | 74 |  |  | $ | 73 |  |  |  | 1 | % |  | $ | 153 |  |  | $ | 143 |  |  |  | 7 | % |

[0001564590-15-011213:mdna:88]
[same as prior period, unchanged from 0001564590-15-007795:mdna:81]

[0001564590-15-011213:mdna:89]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2016 to Fiscal 2015 |  |  | Fiscal 2016 to Fiscal 2015 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (1 | ) |  |  | 9 |  |
| Professional and legal fees and outside services |  |  | 4 |  |  |  | — |  |
| Facilities and IT support costs |  |  | (2 | ) |  |  | (2 | ) |
| Total change |  |  | 1 |  |  |  | 7 |  |

[0001564590-15-011213:mdna:90]
The decrease in compensation costs for the second quarter of fiscal 2016 compared to the second quarter of the prior year was primarily due to lower incentive compensation costs and stock-based compensation expense. The increase in compensation costs for the first six months of fiscal 2016 compared to the corresponding period of the prior year was primarily due to higher stock-based compensation and salaries and related benefit expenses due to the additional week in the first quarter of fiscal 2016. The increase in professional and legal fees and outside services expense for the second quarter of fiscal 2016 compared to the corresponding period of the prior year was primarily due to higher spending levels on consulting fees. Facilities and IT support costs decreased primarily due to cost containment efforts.

[0001564590-15-011213:mdna:91]
[same as prior period, unchanged from 0001564590-15-007795:mdna:84]

[0001564590-15-011213:mdna:92]
|  | Three Months Ended |  | Six Months Ended |
|  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |
| Restructuring and other charges | $ | 1 |  |  | $ | — |  |  | NM |  | $ | 28 |  |  |  | — |  |  | NM |

[0001564590-15-011213:mdna:93]
NM – Not Meaningful

[0001564590-15-011213:mdna:94]
In May 2015, we committed to a realignment designed to drive efficiency, eliminate cost and redirect resources to highest return activities, resulting in a reduction of our global workforce of approximately 3%. The charges in the first six months of fiscal 2016 consist primarily of employee severance related costs recognized in connection with this plan. Such activities were substantially completed by the end of the second quarter of fiscal 2016. See Note 11 – Restructuring and Other Charges of the Notes to Condensed Consolidated Financial Statements for more details regarding our restructuring plan.

[0001564590-15-011213:mdna:95]
Other Income (Expense), Net (in millions, except percentages)

[0001564590-15-011213:mdna:96]
The components of other income (expense), net were as follows:

[0001564590-15-011213:mdna:97]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |
| Interest income | $ | 11 |  |  | $ | 8 |  |  |  | 38 | % |  | $ | 24 |  |  | $ | 16 |  |  |  | 50 | % |
| Interest expense |  | (12 | ) |  |  | (11 | ) |  |  | 9 | % |  |  | (23 | ) |  |  | (20 | ) |  |  | 15 | % |
| Net gains recognized on investments |  | — |  |  |  | — |  |  | NM |  |  |  | — |  |  |  | 2 |  |  |  | (100 | )% |
| Net gains (losses) on foreign currency activities |  | — |  |  |  | (1 | ) |  |  | (100 | )% |  |  | 2 |  |  |  | (2 | ) |  | NM |  |
| Total | $ | (1 | ) |  | $ | (4 | ) |  |  | (75 | )% |  | $ | 3 |  |  | $ | (4 | ) |  | NM |  |

[0001564590-15-011213:mdna:98]
NM – Not Meaningful

[0001564590-15-011213:mdna:99]
29

[0001564590-15-011213:mdna:100]
The increase in interest income for the second quarter and first six months of fiscal 2016, compared to the corresponding periods of the prior year, was primarily due to a shift in our investment portfolio to higher-yielding investments.

[0001564590-15-011213:mdna:101]
[same as prior period, unchanged from 0001564590-15-007795:mdna:93]

[0001564590-15-011213:mdna:102]
[same as prior period, unchanged from 0001564590-15-007795:mdna:94]

[0001564590-15-011213:mdna:103]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |  | October 30, 2015 |  |  | October 24, 2014 |  |  | % Change |  |
| Provision for income taxes | $ | 30 |  |  | $ | 29 |  |  |  | 3 | % |  | $ | 38 |  |  | $ | 101 |  |  |  | (62 | )% |

[0001564590-15-011213:mdna:104]
Our effective tax rate for the second quarter of fiscal 2016 was 20.8% compared to an effective tax rate of 15.4% for the second quarter of the prior year. Our effective tax rate for the first six months of fiscal 2016 was 31.1% compared to an effective tax rate of 28.8% for the first six months of the prior year. Our effective tax rates reflect our corporate legal entity structure and the global nature of our business with a significant amount of our profits generated and taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The effective tax rates for all periods presented were favorably impacted by the geographic mix of profits. Our effective tax rates increased for the three and six months ended October 30, 2015 compared to the corresponding periods in the prior year primarily as a result of discrete charges related to audit adjustments and lower year-to-date pre-tax profits.

[0001564590-15-011213:mdna:105]
In June 2015, the IRS signed a closing agreement on transfer pricing arrangements and, in October 2015, completed the examination of our fiscal 2008 to 2010 income tax returns. During the three and six months ended October 30, 2015, we recorded discrete charges of $10 million and $23 million, respectively, attributable to transfer pricing and other audit settlements, and the related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-15-011213:mdna:106]
In July 2014, the IRS completed the examination of our fiscal 2005 to 2007 income tax returns upon approval by the Joint Committee of Taxation. During the first six months of fiscal 2015, we recorded a discrete charge of $47 million attributable to the audit settlements and related re-measurements of uncertain tax positions for tax years subject to future audits.

[0001564590-15-011213:mdna:107]
In October 2014, the United Kingdom’s tax authority concluded the examination of our fiscal 2009 to 2012 UK income tax returns. We recorded a $1 million income tax benefit for the net impact of the audit adjustments and related release of uncertain tax positions.

[0001564590-15-011213:mdna:108]
As of October 30, 2015, we had $209 million of gross unrecognized tax benefits, of which $158 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $148 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized. See Note 12 – Income Taxes of the Notes to Condensed Consolidated Financial Statements for more details regarding our unrecognized tax benefits.

[0001564590-15-011213:mdna:109]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions.

[0001564590-15-011213:mdna:110]
[same as prior period, unchanged from 0001564590-15-007795:mdna:101]

[0001564590-15-011213:mdna:111]
| (In millions, except percentages) |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Cash and cash equivalents and short-term investments |  | $ | 4,814 |  |  | $ | 5,326 |  |
| Principal amount of Senior Notes |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Debt as a % of stockholders' equity |  |  | 50 | % |  |  | 44 | % |

[0001564590-15-011213:mdna:112]
[same as prior period, unchanged from 0001564590-15-007795:mdna:103]

[0001564590-15-011213:mdna:113]
|  |  | Six Months Ended |  |
| (In millions) |  | October 30, 2015 |  |  | October 24, 2014 |  |
| Net cash provided by operating activities |  | $ | 274 |  |  | $ | 597 |  |
| Net cash provided by investing activities |  |  | 704 |  |  |  | 251 |  |
| Net cash used in financing activities |  |  | (694 | ) |  |  | (213 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (8 | ) |  |  | (21 | ) |
| Net increase in cash and cash equivalents |  | $ | 276 |  |  | $ | 614 |  |

[0001564590-15-011213:mdna:114]
[same as prior period, unchanged from 0001564590-15-007795:mdna:118]

[0001564590-15-011213:mdna:115]
[same as prior period, unchanged from 0001564590-15-007795:mdna:105]

[0001564590-15-011213:mdna:116]
As of October 30, 2015, our cash, cash equivalents and short-term investments were $4.8 billion, a decrease of $0.5 billion from April 24, 2015. The decrease was primarily due to $613 million in cash paid for the repurchase of our common stock and $107 million in cash paid for the payment of dividends, partially offset by $274 million of cash provided by operating activities in the first six months of fiscal 2016. Accounts receivable DSO were 37 days for the second quarter of fiscal 2016 compared to 46 days for the fourth quarter of fiscal 2015 and 37 for the second quarter of fiscal 2015 reflecting seasonal patterns of shipment linearity. Working capital decreased by $436 million to $3.6 billion as of October 30, 2015 primarily as a result of decreases in cash and cash equivalents and short-term investments and accounts receivable, partially offset by decreases in short-term deferred revenue and financed unearned services revenue and accrued expenses.

[0001564590-15-011213:mdna:117]
[same as prior period, unchanged from 0001564590-15-007795:mdna:107]

[0001564590-15-011213:mdna:118]
During the first six months of fiscal 2016, we generated cash from operating activities of $274 million, reflecting net income of $84 million, adjusted by non-cash depreciation and amortization of $136 million and stock-based compensation of $136 million.

[0001564590-15-011213:mdna:119]
Changes in assets and liabilities during the first six months of fiscal 2016 included the following:

[0001564590-15-011213:mdna:120]
|  | · | Accounts receivable decreased $189 million, primarily due to seasonal patterns in shipment linearity. |

[0001564590-15-011213:mdna:121]
|  | · | Accrued compensation decreased $78 million, primarily due to employee compensation payouts related to fiscal year 2015 commissions and incentive compensation plans. |

[0001564590-15-011213:mdna:122]
|  | · | Deferred revenue and financed unearned services revenue decreased $137 million, as a result of deferred revenue amortization for existing software and hardware maintenance contracts exceeding deferred revenue recorded for new contracts. |

[0001564590-15-011213:mdna:123]
[same as prior period, unchanged from 0001564590-15-007795:mdna:112]

[0001564590-15-011213:mdna:124]
[same as prior period, unchanged from 0001564590-15-007795:mdna:113]

[0001564590-15-011213:mdna:125]
During the first six months of fiscal 2016, we generated $788 million from maturities and sales of investments, net of purchases, and paid $84 million for capital expenditures, compared to $361 million and $109 million, respectively, for the corresponding period of the prior year.

[0001564590-15-011213:mdna:126]
[same as prior period, unchanged from 0001564590-15-007795:mdna:115]

[0001564590-15-011213:mdna:127]
During the first six months of fiscal 2016, we used $613 million for the repurchase of 19 million shares of our common stock and $107 million for the payment of dividends, compared to $719 million used for the repurchase of common stock and $105 million for the payment of dividends for the corresponding period of the prior year.

[0001564590-15-011213:mdna:128]
[same as prior period, unchanged from 0001564590-15-007795:mdna:117]

[0001564590-15-011213:mdna:129]
[same as prior period, unchanged from 0001564590-15-007795:mdna:119]

[0001564590-15-011213:mdna:130]
Our principal sources of liquidity as of October 30, 2015 consisted of cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001564590-15-011213:mdna:131]
[same as prior period, unchanged from 0001564590-15-007795:mdna:133]

[0001564590-15-011213:mdna:132]
[same as prior period, unchanged from 0001564590-15-007795:mdna:121]

[0001564590-15-011213:mdna:133]
|  |  | October 30, 2015 |  |  | April 24, 2015 |  |
| Cash and cash equivalents |  | $ | 2,198 |  |  | $ | 1,922 |  |
| Short-term investments |  |  | 2,616 |  |  |  | 3,404 |  |
| Total |  | $ | 4,814 |  |  | $ | 5,326 |  |

[0001564590-15-011213:mdna:134]
As of October 30, 2015 and April 24, 2015, $4.1 billion and $4.7 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.7 billion and $0.6 billion, respectively, were available in the U.S. Most of the amounts held outside the U.S. can be repatriated to the U.S. but, under current law, would be subject to U.S. federal, state income and foreign withholding taxes. If we were to repatriate foreign earnings to fund cash requirements in the U.S., we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state tax credit carryforwards. However, our intent is to keep these funds permanently reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, and invest in critical or complementary technologies, and service interest and principal payments on our debt.

[0001564590-15-011213:mdna:135]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of October 30, 2015.

[0001564590-15-011213:mdna:136]
[same as prior period, unchanged from 0001564590-15-007795:mdna:125]

[0001564590-15-011213:mdna:137]
[same as prior period, unchanged from 0001564590-15-007795:mdna:126]

[0001564590-15-011213:mdna:138]
The following table summarizes the principal amount of our Senior Notes as of October 30, 2015 (in millions):

[0001564590-15-011213:mdna:139]
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |
| Total |  | $ | 1,500 |  |

[0001564590-15-011213:mdna:140]
[same as prior period, unchanged from 0001564590-15-007795:mdna:129]

[0001564590-15-011213:mdna:141]
Credit Facility

[0001564590-15-011213:mdna:142]
Our credit facility, under which we may borrow up to $250 million, provides another potential source of liquidity. The credit facility is an unsecured five-year revolving credit facility that terminates on December 21, 2017 if no extensions have been requested at that time, and contains financial covenants requiring us to maintain a maximum leverage ratio and a minimum interest coverage ratio. We may also, subject to certain requirements, request an increase in the facility up to an additional $100 million and request two additional one-year extensions, subject to certain conditions. As of October 30, 2015, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-15-011213:mdna:143]
We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001564590-15-011213:mdna:144]
[same as prior period, unchanged from 0001564590-15-007795:mdna:152]

[0001564590-15-011213:mdna:145]
[same as prior period, unchanged from 0001564590-15-007795:mdna:134]

[0001564590-15-011213:mdna:146]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2016 to be between $100 million and $150 million.

[0001564590-15-011213:mdna:147]
[same as prior period, unchanged from 0001564590-15-007795:mdna:136]

[0001564590-15-011213:mdna:148]
On November 18, 2015, we declared a cash dividend of $0.18 per share of common stock, payable on January 20, 2015 to holders of record as of the close of business on January 8, 2015.

[0001564590-15-011213:mdna:149]
As of October 30, 2015, our Board of Directors had authorized the repurchase of up to $9.6 billion of our common stock under our stock repurchase program. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through October 30, 2015, we repurchased a total of 233 million shares of our common stock at an average price of $33.33 per share, for an aggregate purchase price of $7.8 billion. As of October 30, 2015, the remaining authorized amount for stock repurchases under this program was $1.8 billion, with no termination date, which we plan to complete by May 2018, with the first $1 billion expected to be purchased by the end of May 2016.

[0001564590-15-011213:mdna:150]
[same as prior period, unchanged from 0001564590-15-007795:mdna:139]

[0001564590-15-011213:mdna:151]
[same as prior period, unchanged from 0001564590-15-007795:mdna:140]

[0001564590-15-011213:mdna:152]
[same as prior period, unchanged from 0001564590-15-007795:mdna:141]

[0001564590-15-011213:mdna:153]
As of October 30, 2015, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $204 million.

[0001564590-15-011213:mdna:154]
[same as prior period, unchanged from 0001564590-15-007795:mdna:143]

[0001564590-15-011213:mdna:155]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of October 30, 2015, we had $262 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 30, 2015 and April 24, 2015, such liability amounted to $12 million and $17 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-15-011213:mdna:156]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of October 30, 2015, we had $36 million in construction related obligations and $172 million in other purchase obligations.

[0001564590-15-011213:mdna:157]
[same as prior period, unchanged from 0001564590-15-007795:mdna:146]

[0001564590-15-011213:mdna:158]
As of October 30, 2015, our liability for uncertain tax positions was $146 million, including interest, penalties and offsetting indirect benefits. Due to the uncertainty of the timing of future cash payments, we cannot make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-15-011213:mdna:159]
Legal Contingencies

[0001564590-15-011213:mdna:160]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0001564590-15-011213:mdna:161]
[same as prior period, unchanged from 0001564590-15-007795:mdna:150]

[0001564590-15-011213:mdna:162]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control

[0001564590-15-011213:mdna:163]
of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $72 million and $89 million of receivables during the first six months of fiscal 2016 and fiscal 2015, respectively.

[0001564590-15-011213:mdna:164]
[same as prior period, unchanged from 0001564590-15-007795:mdna:154]

[0001564590-15-011213:mdna:165]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of October 30, 2015 and April 24, 2015, the aggregate amount by which such contingencies exceeded the associated deferred revenue was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001564590-15-011213:mdna:166]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of October 30, 2015, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-15-011213:mdna:167]
Indemnification Agreements

[0001564590-15-011213:mdna:168]
[same as prior period, unchanged from 0001564590-15-007795:mdna:157]

[0001564590-15-011213:mdna:169]
34
