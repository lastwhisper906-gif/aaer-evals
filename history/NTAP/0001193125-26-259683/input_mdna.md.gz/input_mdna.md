# NTAP MD&A — 0001193125-26-259683


## mdna

[0001193125-26-259683:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001193125-26-259683:mdna:2]
The following discussion of our financial condition and results of operations should be read together with the financial statements and the accompanying notes set forth under Part II, Item 8. – Financial Statements and Supplementary Data. The following discussion also contains trend information and other forward-looking statements that involve a number of risks and uncertainties. The Risk Factors set forth in Part I, Item 1A. – Risk Factors are hereby incorporated into the discussion by reference.

[0001193125-26-259683:mdna:3]
Executive Overview

[0001193125-26-259683:mdna:4]
Our Company

[0001193125-26-259683:mdna:5]
NetApp is a global leader in Intelligent Data Infrastructure, empowering organizations to realize the full potential of their data in a rapidly evolving digital world. Headquartered in San Jose, California, and serving customers in approximately 150 countries, NetApp delivers innovative solutions that enable seamless data management, protection, and mobility across on-premises, hybrid, and multi-cloud environments.

[0001193125-26-259683:mdna:6]
Our flagship ONTAP® data management software, together with a comprehensive portfolio of all-flash, hybrid-flash, and cloud-native offerings, forms the foundation for customers’ digital transformation initiatives. NetApp’s deep integration with all major public cloud providers—AWS, Microsoft Azure, and Google Cloud—enables our customers to run critical workloads anywhere, with consistent performance, security, and governance.

[0001193125-26-259683:mdna:7]
NetApp's strategic focus is on modernizing data infrastructure, enabling resilient and secure operations, optimizing cloud strategies, and accelerating artificial intelligence (AI) adoption. Through continued investment in innovation, we have expanded our portfolio to include advanced AI-ready infrastructure, Storage-as-a-Service (Keystone), and robust cyber resilience solutions. Our partnerships with leading technology companies and a global ecosystem of channel partners further extend our reach and solution capabilities.

[0001193125-26-259683:mdna:8]
Our operations are organized into two segments: Hybrid Cloud and Public Cloud.

[0001193125-26-259683:mdna:9]
Hybrid Cloud offers a unified data storage portfolio of storage management and infrastructure solutions that helps customers modernize their data centers. Our Hybrid Cloud portfolio accommodates both structured and unstructured data with unified storage optimized for flash, disk, and cloud storage, capable of handling data-intensive workloads and applications. Hybrid Cloud includes software, hardware, and related support, along with professional and other services.

[0001193125-26-259683:mdna:10]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage, data services, and operational services. These services are generally available on the leading public clouds, including AWS, Microsoft Azure, and Google Cloud.

[0001193125-26-259683:mdna:11]
Global Business Environment

[0001193125-26-259683:mdna:12]
Supply Chain

[0001193125-26-259683:mdna:13]
Inflationary pressures and supply chain constraints have impacted our operations beginning in the second half of fiscal 2026. We have experienced increased costs for memory and other components, which have affected our gross margins, and we expect costs will remain elevated, or continue to increase, in the near term. Additionally, the tight supply environment for specific products, which is anticipated to persist, could pose challenges in meeting customer demand for those products.

[0001193125-26-259683:mdna:14]
To address these challenges, we have implemented several strategic actions:

[0001193125-26-259683:mdna:15]
•
We raised our pricing in the fourth quarter of fiscal 2026, in line with market trends. We expect to continue adjusting prices as necessary to offset rising costs and remain aligned with the market. While we aim to match supplier costs with our pricing to customers, we recognize the need to give customers time to adjust to these changes.

[0001193125-26-259683:mdna:16]
•
We are leveraging our relationships with multiple suppliers where available to enable component availability and manage costs effectively. This strategy helps us maintain competitive positions in the market from a pricing standpoint. Our history of successful supplier management positions us well to navigate these challenges.

[0001193125-26-259683:mdna:17]
•
We continue to offer a wide range of solutions to meet various customer needs and priorities. This includes competitive storage options, all-flash solutions, hybrid-flash solutions, public cloud solutions, and our Keystone Storage-as-a-Service offering. By providing diverse options, we aim to align with our customers’ budget priorities and deliver the best value offerings.

[0001193125-26-259683:mdna:18]
These actions are part of our ongoing efforts to mitigate the impact of inflation and supply chain constraints on our operating results. We will continue to monitor these trends and uncertainties and adjust our strategies as needed to maintain our financial performance.

[0001193125-26-259683:mdna:19]
Financial Results and Key Performance Metrics Overview

[0001193125-26-259683:mdna:20]
The following table provides an overview of key financial metrics for the years indicated (in millions, except per share amounts and percentages):

[0001193125-26-259683:mdna:21]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Net revenues |  | $ | 6,925 |  |  | $ | 6,572 |  |  | $ | 6,268 |  |
| Gross profit |  | $ | 4,899 |  |  | $ | 4,613 |  |  | $ | 4,433 |  |
| Gross margin |  |  | 71 | % |  |  | 70 | % |  |  | 71 | % |
| Income from operations |  | $ | 1,674 |  |  | $ | 1,337 |  |  | $ | 1,214 |  |
| Income from operations as a percentage of net revenues |  |  | 24 | % |  |  | 20 | % |  |  | 19 | % |
| Provision for income taxes |  | $ | 372 |  |  | $ | 197 |  |  | $ | 277 |  |
| Net income |  | $ | 1,276 |  |  | $ | 1,186 |  |  | $ | 986 |  |
| Diluted net income per share |  | $ | 6.35 |  |  | $ | 5.67 |  |  | $ | 4.63 |  |
| Net cash provided by operating activities |  | $ | 2,067 |  |  | $ | 1,506 |  |  | $ | 1,685 |  |

[0001193125-26-259683:mdna:22]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Deferred revenue |  | $ | 4,845 |  |  | $ | 4,536 |  |

[0001193125-26-259683:mdna:23]
•
Net revenues: Our net revenues increased 5% in fiscal 2026 compared to fiscal 2025, due to increases in both product revenues and services revenues.

[0001193125-26-259683:mdna:24]
•
Gross margin: Our gross margin increased less than one percentage point in fiscal 2026 compared to fiscal 2025, due to the increase in gross margins on services revenues, partially offset by lower gross margins on product revenues.

[0001193125-26-259683:mdna:25]
•
Income from operations as a percentage of net revenues: Our income from operations as a percentage of net revenues increased by four percentage points in fiscal 2026 compared to fiscal 2025, primarily due to higher net revenues.

[0001193125-26-259683:mdna:26]
•
Provision for income taxes: Our provision for income taxes increased in fiscal 2026 compared to fiscal 2025 primarily due to benefits related to the Internal Revenue Service ("IRS") examination of our fiscal 2018 and 2019 U.S. income tax returns in the prior year.

[0001193125-26-259683:mdna:27]
•
Net income and Diluted net income per share: The increase in both net income and diluted net income per share in fiscal 2026 compared to fiscal 2025 reflect the factors discussed above.

[0001193125-26-259683:mdna:28]
Stock Repurchase Program and Dividend Activity

[0001193125-26-259683:mdna:29]
During fiscal 2026, we repurchased 9.0 million shares of our common stock at an average price of $105.89 per share, for an aggregate purchase price of $950 million. We also declared aggregate cash dividends of $2.08 per share in fiscal 2026, for which we paid a total of $413 million.

[0001193125-26-259683:mdna:30]
Restructuring Events

[0001193125-26-259683:mdna:31]
During fiscal 2026, we executed a restructuring plan and recognized expenses totaling $21 million consisting primarily of employee severance-related costs related to the current year and prior year plans.

[0001193125-26-259683:mdna:32]
Senior Notes Repayment

[0001193125-26-259683:mdna:33]
On June 23, 2025, upon maturity, we repaid the 1.875% Senior Notes due June 2025 for an aggregate amount of $757 million, comprised of the principal and unpaid interest.

[0001193125-26-259683:mdna:34]
Results of Operations

[0001193125-26-259683:mdna:35]
Our fiscal year is reported on a 52- or 53-week year that ends on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal years 2026, 2025 and 2024, which ended on April 24, 2026, April 25, 2025 and April 26, 2024, respectively, are all 52-week years, with 13 weeks in each of their quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to our fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0001193125-26-259683:mdna:36]
The following table sets forth certain consolidated statements of income data as a percentage of net revenues for the periods indicated:

[0001193125-26-259683:mdna:37]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product |  |  | 46 | % |  |  | 46 | % |  |  | 45 | % |
| Services |  |  | 54 |  |  |  | 54 |  |  |  | 55 |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 20 |  |  |  | 20 |  |  |  | 18 |  |
| Cost of services |  |  | 9 |  |  |  | 10 |  |  |  | 11 |  |
| Gross profit |  |  | 71 |  |  |  | 70 |  |  |  | 71 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 27 |  |  |  | 28 |  |  |  | 29 |  |
| Research and development |  |  | 14 |  |  |  | 15 |  |  |  | 16 |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |
| Restructuring charges |  |  | — |  |  |  | 1 |  |  |  | 1 |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |
| Total operating expenses |  |  | 47 |  |  |  | 50 |  |  |  | 51 |  |
| Income from operations |  |  | 24 |  |  |  | 20 |  |  |  | 19 |  |
| Other (expense) income, net |  |  | — |  |  |  | 1 |  |  |  | 1 |  |
| Income before income taxes |  |  | 24 |  |  |  | 21 |  |  |  | 20 |  |
| Provision for income taxes |  |  | 5 |  |  |  | 3 |  |  |  | 4 |  |
| Net income |  |  | 18 | % |  |  | 18 | % |  |  | 16 | % |

[0001193125-26-259683:mdna:38]
Percentages may not add due to rounding

[0001193125-26-259683:mdna:39]
Discussion and Analysis of Results of Operations

[0001193125-26-259683:mdna:40]
Net Revenues (in millions, except percentages):

[0001193125-26-259683:mdna:41]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | % Change |  |  | April 26, 2024 |  |  | % Change |  |
| Net revenues |  | $ | 6,925 |  |  | $ | 6,572 |  |  |  | 5 | % |  | $ | 6,268 |  |  |  | 5 | % |

[0001193125-26-259683:mdna:42]
The increase in net revenues for fiscal 2026 compared to fiscal 2025 was due to an increase in both product revenues and services revenues. Product and services revenues as a percentage of net revenues remained relatively flat in fiscal 2026 as compared to fiscal 2025. Fluctuations in foreign currency exchange rates favorably impacted net revenues percentage growth year-over-year by two percentage points.

[0001193125-26-259683:mdna:43]
The increase in net revenues for fiscal 2025 compared to fiscal 2024 was due to an increase in both product revenues and services revenues. Product revenues as a percentage of net revenues increased by one percentage point in fiscal 2025 compared to fiscal 2024, while services revenues as a percentage of net revenues decreased by one percentage point.

[0001193125-26-259683:mdna:44]
Two customers, each of which is a distributor, accounted for 10% or more of net revenues:

[0001193125-26-259683:mdna:45]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Customer A |  |  | 22 | % |  |  | 21 | % |  |  | 22 | % |
| Customer B |  |  | 21 | % |  |  | 24 | % |  |  | 22 | % |

[0001193125-26-259683:mdna:46]
Product Revenues (in millions, except percentages):

[0001193125-26-259683:mdna:47]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | % Change |  |  | April 26, 2024 |  |  | % Change |  |
| Product revenues |  | $ | 3,194 |  |  | $ | 3,040 |  |  |  | 5 | % |  | $ | 2,849 |  |  |  | 7 | % |

[0001193125-26-259683:mdna:48]
Hybrid Cloud

[0001193125-26-259683:mdna:49]
Product revenues are derived through the sale of our Hybrid Cloud solutions and consist of sales of configured all-flash array systems (including AFF A-Series and AFF C-Series with capacity flash) and hybrid systems (including FAS), which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, StorageGrid, OEM products and add-on optional software.

[0001193125-26-259683:mdna:50]
Total product revenues increased in fiscal 2026 compared to fiscal 2025, primarily due to higher sales of all-flash array systems and the favorable impact from foreign exchange rate fluctuations. Product revenues in fiscal 2026 also benefited from the execution of a multi-year enterprise agreement.

[0001193125-26-259683:mdna:51]
Total product revenues increased in fiscal 2025 compared to fiscal 2024, primarily due to higher sales of all-flash array systems, partially offset by a decrease in sales of hybrid systems.

[0001193125-26-259683:mdna:52]
Services Revenues (in millions, except percentages):

[0001193125-26-259683:mdna:53]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | % Change |  |  | April 26, 2024 |  |  | % Change |  |
| Services revenues |  | $ | 3,731 |  |  | $ | 3,532 |  |  |  | 6 | % |  | $ | 3,419 |  |  |  | 3 | % |
| Support |  |  | 2,636 |  |  |  | 2,512 |  |  |  | 5 | % |  |  | 2,488 |  |  |  | 1 | % |
| Professional and other services |  |  | 407 |  |  |  | 355 |  |  |  | 15 | % |  |  | 320 |  |  |  | 11 | % |
| Public cloud |  |  | 688 |  |  |  | 665 |  |  |  | 3 | % |  |  | 611 |  |  |  | 9 | % |

[0001193125-26-259683:mdna:54]
Hybrid Cloud

[0001193125-26-259683:mdna:55]
Hybrid Cloud services revenues are derived from the sale of: (1) support, which includes both hardware and software support contracts (the latter of which entitle customers to receive unspecified product upgrades and enhancements, bug fixes and patch releases), and (2) professional and other services, which include customer education and training.

[0001193125-26-259683:mdna:56]
Support revenues increased in fiscal 2026 compared to fiscal 2025 primarily due to a higher aggregate support contract value for our installed base and the favorable impact from foreign exchange rate fluctuations. Support revenues increased marginally in fiscal 2025 compared to fiscal 2024.

[0001193125-26-259683:mdna:57]
Professional and other services revenues increased in fiscal 2026 and fiscal 2025 compared to the respective prior years primarily reflecting higher revenues from our Keystone Storage-as-a-Service offering.

[0001193125-26-259683:mdna:58]
Public Cloud

[0001193125-26-259683:mdna:59]
Public Cloud revenues are derived from the sale of public cloud offerings delivered primarily as-a-service, which include cloud storage, data services and operational services.

[0001193125-26-259683:mdna:60]
Public Cloud revenues increased in fiscal 2026 and fiscal 2025 compared to the respective prior years primarily due to higher customer demand, driven by NetApp’s diversified cloud offerings and overall growth in the cloud market. The smaller increase in fiscal 2026 reflects the loss of revenue from our Spot by NetApp business which we sold in the fourth quarter of fiscal 2025.

[0001193125-26-259683:mdna:61]
40

[0001193125-26-259683:mdna:62]
Hybrid Cloud Segment Net Revenues by Storage Category (in millions, except percentages):

[0001193125-26-259683:mdna:63]
The following table presents Hybrid Cloud segment net revenues by storage category for the periods indicated:

[0001193125-26-259683:mdna:64]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Hybrid Cloud segment net revenues |  | $ | 6,237 |  |  | $ | 5,907 |  |  | $ | 5,657 |  |
| All-flash revenues as a percentage of Hybrid Cloud segment net revenues |  |  | 67 | % |  |  | 64 | % |  |  | 58 | % |
| Hybrid-flash and other revenues as a percentage of Hybrid Cloud segment net revenues |  |  | 33 | % |  |  | 36 | % |  |  | 42 | % |

[0001193125-26-259683:mdna:65]
Percentages may not add due to rounding

[0001193125-26-259683:mdna:66]
The increases in all-flash revenues (comprised of all-flash product and related service revenues) as a percentage of total Hybrid Cloud segment net revenues for fiscal 2026 and fiscal 2025 as compared to the respective prior years reflect growing customer demand for our all-flash storage solutions, aided by all-flash market expansion.

[0001193125-26-259683:mdna:67]
Net Revenues by Geographic Area:

[0001193125-26-259683:mdna:68]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| United States, Canada and Latin America (Americas) |  |  | 51 | % |  |  | 51 | % |  |  | 51 | % |
| Americas Commercial |  |  | 41 | % |  |  | 40 | % |  |  | 40 | % |
| U.S. Public Sector |  |  | 10 | % |  |  | 11 | % |  |  | 11 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 34 | % |  |  | 34 | % |  |  | 34 | % |
| Asia Pacific (APAC) |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |

[0001193125-26-259683:mdna:69]
Percentages may not add due to rounding

[0001193125-26-259683:mdna:70]
Sales to United States (U.S.) public sector markets includes revenue from the U.S. federal government and U.S. state governments, local municipalities and education institutions. Demand across geographies was relatively consistent for each fiscal year presented.

[0001193125-26-259683:mdna:71]
Cost of Revenues

[0001193125-26-259683:mdna:72]
Our cost of revenues consists of:

[0001193125-26-259683:mdna:73]
(1) cost of product revenues, composed of (a) cost of Hybrid Cloud product revenues, which includes the costs of manufacturing and shipping our products, inventory write-downs, and warranty costs, and (b) unallocated cost of product revenues, which includes stock-based compensation, and;

[0001193125-26-259683:mdna:74]
(2) cost of services revenues, composed of (a) cost of support revenues, which includes the costs of providing support activities for hardware and software support, global support partnership programs, and third-party royalty costs, (b) cost of professional and other services revenues, constituting the cost of delivering such services which includes depreciation expense, (c) cost of public cloud revenues, constituting the cost of providing our Public Cloud offerings which includes depreciation and amortization expense and third-party datacenter fees, and (d) unallocated cost of services revenues, which includes stock-based compensation and amortization of intangibles.

[0001193125-26-259683:mdna:75]
Cost of Product Revenues (in millions, except percentages):

[0001193125-26-259683:mdna:76]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | % Change |  |  | April 26, 2024 |  |  | % Change |  |
| Cost of product revenues |  | $ | 1,401 |  |  | $ | 1,284 |  |  |  | 9 | % |  | $ | 1,137 |  |  |  | 13 | % |
| Hybrid Cloud |  |  | 1,395 |  |  |  | 1,278 |  |  |  | 9 | % |  |  | 1,131 |  |  |  | 13 | % |
| Unallocated |  |  | 6 |  |  |  | 6 |  |  |  | — | % |  |  | 6 |  |  |  | — | % |

[0001193125-26-259683:mdna:77]
41

[0001193125-26-259683:mdna:78]
Hybrid Cloud

[0001193125-26-259683:mdna:79]
Cost of Hybrid Cloud product revenues represented 44%, 42% and 40% of Hybrid Cloud product revenues in fiscal 2026, 2025 and 2024, respectively. Materials costs represented 91%, 89% and 88% of cost of Hybrid Cloud product revenues in fiscal 2026, 2025 and 2024, respectively.

[0001193125-26-259683:mdna:80]
Materials costs increased by $126 million in fiscal 2026 compared to fiscal 2025 primarily reflecting the increase in product revenues and higher component costs. Materials costs increased by $140 million in fiscal 2025 compared to fiscal 2024 primarily reflecting the increase in product revenues.

[0001193125-26-259683:mdna:81]
Hybrid Cloud product gross margins decreased by two percentage points in fiscal 2026 compared to fiscal 2025 primarily due to higher component costs, partially offset by the favorable impact from a multi-year enterprise agreement. Hybrid Cloud product gross margins decreased by two percentage points in fiscal 2025 compared to fiscal 2024 primarily due to higher component costs.

[0001193125-26-259683:mdna:82]
In response to rising component costs, we raised our prices in the fourth quarter of fiscal 2026, which we expect to support product gross margins in early fiscal 2027. We expect to continue adjusting our pricing as necessary to align with any significant changes in component costs.

[0001193125-26-259683:mdna:83]
Unallocated

[0001193125-26-259683:mdna:84]
Unallocated cost of product revenues were consistent for each fiscal year presented.

[0001193125-26-259683:mdna:85]
Cost of Services Revenues (in millions, except percentages):

[0001193125-26-259683:mdna:86]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | % Change |  |  | April 26, 2024 |  |  | % Change |  |
| Cost of services revenues |  | $ | 625 |  |  | $ | 675 |  |  |  | (7 | )% |  | $ | 698 |  |  |  | (3 | )% |
| Support |  |  | 198 |  |  |  | 197 |  |  |  | 1 | % |  |  | 195 |  |  |  | 1 | % |
| Professional and other services |  |  | 281 |  |  |  | 261 |  |  |  | 8 | % |  |  | 243 |  |  |  | 7 | % |
| Public cloud |  |  | 113 |  |  |  | 165 |  |  |  | (32 | )% |  |  | 203 |  |  |  | (19 | )% |
| Unallocated |  |  | 33 |  |  |  | 52 |  |  |  | (37 | )% |  |  | 57 |  |  |  | (9 | )% |

[0001193125-26-259683:mdna:87]
Hybrid Cloud

[0001193125-26-259683:mdna:88]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, increased in fiscal 2026 and fiscal 2025 compared to the respective prior years reflecting the increase in Hybrid Cloud services revenues. Cost of Hybrid Cloud services revenues represented 16% of Hybrid Cloud services revenues in fiscal 2026, 2025 and 2024.

[0001193125-26-259683:mdna:89]
Hybrid Cloud support gross margins were similar in fiscal 2026, fiscal 2025 and fiscal 2024. Hybrid Cloud professional and other services gross margins increased by five percentage points in fiscal 2026 compared to fiscal 2025 and by two percentage points in fiscal 2025 compared to fiscal 2024 primarily due to the mix of services provided in each year.

[0001193125-26-259683:mdna:90]
Public Cloud

[0001193125-26-259683:mdna:91]
Cost of Public Cloud revenues decreased, while Public Cloud gross margins increased by eight percentage points, in fiscal 2026 and fiscal 2025 compared to the respective prior years. These fluctuations were due to cost optimization that included a decrease in fixed assets depreciation, and the mix of offerings provided which was impacted by the sale of our Spot by NetApp business in the fourth quarter of fiscal 2025.

[0001193125-26-259683:mdna:92]
Unallocated

[0001193125-26-259683:mdna:93]
Unallocated cost of services revenues decreased in fiscal 2026 and fiscal 2025 compared to the respective prior years due to the derecognition of certain intangible assets resulting from the sale of our Spot by NetApp business during the fourth quarter of fiscal 2025.

[0001193125-26-259683:mdna:94]
42

[0001193125-26-259683:mdna:95]
Operating Expenses

[0001193125-26-259683:mdna:96]
Sales and Marketing, Research and Development and General and Administrative Expenses

[0001193125-26-259683:mdna:97]
Sales and marketing, research and development, and general and administrative expenses for fiscal 2026 totaled $3,204 million, or 46% of net revenues, representing a decrease of three percentage points compared to fiscal 2025, primarily due to an increase in net revenues. While fluctuations in foreign currency exchange rates favorably impacted net revenues in fiscal 2026 compared to fiscal 2025, they adversely impacted sales and marketing, research and development and general and administrative expenses.

[0001193125-26-259683:mdna:98]
Sales and marketing, research and development, and general and administrative expenses for fiscal 2025 totaled $3,188 million, or 49% of net revenues, representing a decrease of one percentage point compared to fiscal 2024.

[0001193125-26-259683:mdna:99]
Compensation costs represent the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0001193125-26-259683:mdna:100]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses remained relatively flat in fiscal 2026, 2025 and 2024.

[0001193125-26-259683:mdna:101]
Sales and Marketing (in millions, except percentages):

[0001193125-26-259683:mdna:102]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | % Change |  |  | April 26, 2024 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 1,869 |  |  | $ | 1,865 |  |  |  | — | % |  | $ | 1,828 |  |  |  | 2 | % |

[0001193125-26-259683:mdna:103]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, facilities and IT support costs, advertising and marketing promotional expense and travel and entertainment expense.

[0001193125-26-259683:mdna:104]
Sales and marketing expenses in fiscal 2026 were relatively flat compared to fiscal 2025. The increase in sales and marketing expenses in fiscal 2025 compared to fiscal 2024 was primarily due to an increase in sales commission expenses.

[0001193125-26-259683:mdna:105]
Research and Development (in millions, except percentages):

[0001193125-26-259683:mdna:106]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | % Change |  |  | April 26, 2024 |  |  | % Change |  |
| Research and development expenses |  | $ | 991 |  |  | $ | 1,012 |  |  |  | (2 | )% |  | $ | 1,029 |  |  |  | (2 | )% |

[0001193125-26-259683:mdna:107]
Research and development expenses consist primarily of compensation costs, facilities and IT support costs, depreciation, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs.

[0001193125-26-259683:mdna:108]
The decrease in research and development expenses in fiscal 2026 compared to fiscal 2025 was primarily attributable to lower compensation costs and lower spend on engineering projects. The decrease in research and development expenses in fiscal 2025 compared to fiscal 2024 was primarily due to lower compensation costs.

[0001193125-26-259683:mdna:109]
General and Administrative (in millions, except percentages):

[0001193125-26-259683:mdna:110]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | % Change |  |  | April 26, 2024 |  |  | % Change |  |
| General and administrative expenses |  | $ | 344 |  |  | $ | 311 |  |  |  | 11 | % |  | $ | 308 |  |  |  | 1 | % |

[0001193125-26-259683:mdna:111]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and facilities and IT support costs.

[0001193125-26-259683:mdna:112]
The increase in general and administrative expenses in fiscal 2026 compared to fiscal 2025 was primarily due to increases in all components of compensation costs, predominately salaries and stock-based compensation expense, and higher spend on professional services. General and administrative expenses remained relatively flat in fiscal 2025 compared to fiscal 2024.

[0001193125-26-259683:mdna:113]
Restructuring Charges (in millions, except percentages):

[0001193125-26-259683:mdna:114]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | % Change |  |  | April 26, 2024 |  |  | % Change |  |
| Restructuring charges |  | $ | 21 |  |  | $ | 83 |  |  |  | (75 | )% |  | $ | 44 |  |  |  | 89 | % |

[0001193125-26-259683:mdna:115]
In an effort to reduce our cost structure and redirect resources to our highest return activities, in fiscal 2026, 2025 and 2024, we initiated a number of business realignment plans designed to streamline our business and focus on key strategic opportunities. These plans resulted in aggregate charges of $21 million, $83 million, and $44 million, respectively, consisting primarily of employee severance-related costs. Additionally, the aggregate charges for fiscal 2025 and fiscal 2024 included optimization of our global office space for our hybrid work model. See Note 11 – Restructuring Charges of the Notes to Consolidated Financial Statements included in Part II, Item 8 for more details regarding our restructuring plans.

[0001193125-26-259683:mdna:116]
Other (Expense) Income, Net (in millions, except percentages)

[0001193125-26-259683:mdna:117]
The components of other (expense) income, net were as follows:

[0001193125-26-259683:mdna:118]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | % Change |  |  | April 26, 2024 |  |  | % Change |  |
| Interest income |  | $ | 113 |  |  | $ | 112 |  |  |  | 1 | % |  | $ | 112 |  |  |  | — | % |
| Interest expense |  |  | (109 | ) |  |  | (64 | ) |  |  | 70 | % |  |  | (64 | ) |  |  | — | % |
| Other, net |  |  | (30 | ) |  |  | (2 | ) |  | NM |  |  |  | 1 |  |  | NM |  |
| Total |  | $ | (26 | ) |  | $ | 46 |  |  |  | (157 | )% |  | $ | 49 |  |  |  | (6 | )% |

[0001193125-26-259683:mdna:119]
NM - Not Meaningful

[0001193125-26-259683:mdna:120]
Interest income in fiscal 2026 was relatively flat compared to fiscal 2025. Interest expense increased in fiscal 2026 compared to fiscal 2025 due to a higher average outstanding aggregate principal amount of Senior Notes, with a higher average coupon rate. The difference in Other, net in fiscal 2026 compared to fiscal 2025 is primarily due to fluctuations in foreign exchange gains and losses year-over-year.

[0001193125-26-259683:mdna:121]
Each component of other (expense) income, net was relatively flat in fiscal 2025 compared to fiscal 2024.

[0001193125-26-259683:mdna:122]
Provision for Income Taxes (in millions, except percentages):

[0001193125-26-259683:mdna:123]
Our provision for income taxes and effective tax rates were as follows:

[0001193125-26-259683:mdna:124]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | % Change |  |  | April 26, 2024 |  |  | % Change |  |
| Provision for income taxes |  | $ | 372 |  |  | $ | 197 |  |  |  | 89 | % |  | $ | 277 |  |  |  | (29 | )% |
| Effective tax rate |  |  | 22.6 | % |  |  | 14.2 | % |  | NM |  |  |  | 21.9 | % |  | NM |  |

[0001193125-26-259683:mdna:125]
NM - Not Meaningful

[0001193125-26-259683:mdna:126]
The differences in the effective tax rates between fiscal years were primarily due to fiscal 2025 benefits related to the Internal Revenue Service (“IRS”) substantially completing the examination of our fiscal 2018 and fiscal 2019 U.S. income tax returns, which resulted in the recognition of a tax benefit of $36 million attributable to the release of related tax reserves.

[0001193125-26-259683:mdna:127]
Liquidity, Capital Resources and Cash Requirements

[0001193125-26-259683:mdna:128]
| (In millions) |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,584 |  |  | $ | 3,846 |  |
| Principal amount of debt |  | $ | 2,500 |  |  | $ | 3,250 |  |

[0001193125-26-259683:mdna:129]
44

[0001193125-26-259683:mdna:130]
The following is a summary of our cash flow activities:

[0001193125-26-259683:mdna:131]
|  |  | Year Ended |  |
| (In millions) |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Net cash provided by operating activities |  | $ | 2,067 |  |  | $ | 1,506 |  |
| Net cash (used in) provided by investing activities |  |  | (595 | ) |  |  | 147 |  |
| Net cash used in financing activities |  |  | (2,147 | ) |  |  | (828 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 1 |  |  |  | 15 |  |
| Net change in cash, cash equivalents and restricted cash |  | $ | (674 | ) |  | $ | 840 |  |

[0001193125-26-259683:mdna:132]
As of April 24, 2026, our cash, cash equivalents and short-term investments totaled $3.6 billion, reflecting a decrease of $262 million from April 25, 2025. The decrease was primarily due to a $750 million principal repayment of our 1.875% Senior Notes due June 2025, $950 million used for the repurchase of our common stock, $413 million used for the payment of dividends, and $198 million used for purchases of property and equipment, partially offset by $2.1 billion provided by operating activities. Net working capital was $1.8 billion as of April 24, 2026, an increase of $566 million compared to April 25, 2025.

[0001193125-26-259683:mdna:133]
Cash Flows from Operating Activities

[0001193125-26-259683:mdna:134]
During fiscal 2026, cash provided by operating activities reflected net income of $1.3 billion which was increased for non-cash depreciation and amortization expense of $200 million and non-cash stock-based compensation expense of $382 million.

[0001193125-26-259683:mdna:135]
Significant changes in assets and liabilities during fiscal 2026 included the following:

[0001193125-26-259683:mdna:136]
•
Deferred revenue increased by $281 million, primarily due to an increase in deferred revenue for software and hardware support contracts.

[0001193125-26-259683:mdna:137]
During fiscal 2025, cash provided by operating activities reflected net income of $1.2 billion which was increased for non-cash depreciation and amortization expense of $243 million and non-cash stock-based compensation expense of $386 million.

[0001193125-26-259683:mdna:138]
Significant changes in assets and liabilities during fiscal 2025 included the following:

[0001193125-26-259683:mdna:139]
•
Accounts receivable increased by $219 million, primarily reflecting higher billing in the fourth quarter of fiscal 2025 compared to the fourth quarter of fiscal 2024.

[0001193125-26-259683:mdna:140]
•
Deferred revenue increased by $208 million, primarily due to an increase in deferred revenue for software and hardware support contracts.

[0001193125-26-259683:mdna:141]
•
Long-term taxes payable decreased by $207 million, primarily due to settlements associated with certain IRS tax examinations and changes in prior period tax positions.

[0001193125-26-259683:mdna:142]
We expect that cash provided by operating activities may materially fluctuate in future periods due to a number of factors, including fluctuations in our operating results, shipping linearity, accounts receivable collections performance, inventory and supply chain management, vendor payment initiatives, and the timing and amount of compensation, income taxes and other payments.

[0001193125-26-259683:mdna:143]
Cash Flows from Investing Activities

[0001193125-26-259683:mdna:144]
During fiscal 2026, we used $412 million for the purchases of investments, net of maturities and sales, and paid $198 million for capital expenditures.

[0001193125-26-259683:mdna:145]
During fiscal 2025, we generated $245 million primarily from maturities and sales of investments, net of purchases, and paid $168 million for capital expenditures. Additionally, we received proceeds of $70 million from the sale of our Spot by NetApp business.

[0001193125-26-259683:mdna:146]
45

[0001193125-26-259683:mdna:147]
Cash Flows from Financing Activities

[0001193125-26-259683:mdna:148]
During fiscal 2026, we used $950 million for the repurchase of 9.0 million shares of common stock, $413 million for the payment of dividends and $750 million principal repayment upon maturity.

[0001193125-26-259683:mdna:149]
During fiscal 2025, we used $1.2 billion for the repurchase of 10.2 million shares of common stock, $424 million for the payment of dividends and $400 million principal repayment upon maturity, partially offset by $1.24 billion of net proceeds from the issuance of Senior Notes.

[0001193125-26-259683:mdna:150]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including cash, cash equivalents and short-term investments, cash generated from operations, and our ability to access capital markets and committed credit lines will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months and thereafter for the foreseeable future. We may choose to periodically raise additional debt capital based on certain conditions, including the refinancing of upcoming maturities and/or for potential strategic acquisitions and investments. Our ability to obtain this or any additional financing that we may pursue or need, will depend on, among other things, our business plans, operating performance and the condition of the capital markets at the time we seek financing. We may not be able to obtain such financing on terms acceptable to us or at all. In the event our liquidity is insufficient and we are unable to enter into new financing arrangements, we may be required to curtail spending and implement additional cost saving measures and restructuring actions. We cannot be certain that we will continue to generate cash flows at or above current levels. For a discussion of risks related to our cash flows and liquidity requirements, see Item 1A. Risk Factors.

[0001193125-26-259683:mdna:151]
Liquidity

[0001193125-26-259683:mdna:152]
Our principal sources of liquidity as of April 24, 2026 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our credit facility and commercial paper program.

[0001193125-26-259683:mdna:153]
Cash, cash equivalents and short-term investments consisted of the following (in millions):

[0001193125-26-259683:mdna:154]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Cash and cash equivalents |  | $ | 2,070 |  |  | $ | 2,742 |  |
| Short-term investments |  |  | 1,514 |  |  |  | 1,104 |  |
| Total |  | $ | 3,584 |  |  | $ | 3,846 |  |

[0001193125-26-259683:mdna:155]
As of April 24, 2026 and April 25, 2025, $2.3 billion and $2.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $1.3 billion was available in the U.S as of the end of each fiscal year.

[0001193125-26-259683:mdna:156]
Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies through asset purchases and/or business acquisitions, service interest and principal payments on our debt, fund our stock repurchase program, and pay dividends, as and if declared. In the ordinary course of business, we engage in periodic reviews of opportunities to invest in or acquire companies or units in companies to expand our total addressable market, leverage technological synergies and establish new streams of revenue.

[0001193125-26-259683:mdna:157]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counterparties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of April 24, 2026.

[0001193125-26-259683:mdna:158]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. We also have an automatic

[0001193125-26-259683:mdna:159]
46

[0001193125-26-259683:mdna:160]
shelf registration statement on file with the U.S. Securities and Exchange Commission (SEC). We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001193125-26-259683:mdna:161]
Senior Notes

[0001193125-26-259683:mdna:162]
The following table summarizes the principal amount of our Senior Notes as of April 24, 2026 (in millions):

[0001193125-26-259683:mdna:163]
|  |  | Amount |  |
| 2.375% Senior Notes Due June 2027 |  | $ | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| 5.50% Senior Notes Due March 2032 |  |  | 625 |  |
| 5.70% Senior Notes Due March 2035 |  |  | 625 |  |
| Total |  | $ | 2,500 |  |

[0001193125-26-259683:mdna:164]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 7 – Financing Arrangements of the Notes to Consolidated Financial Statements included in Part II, Item 8.

[0001193125-26-259683:mdna:165]
On June 23, 2025, upon maturity, we repaid the 1.875% Senior Notes due June 2025 for an aggregate amount of $757 million, comprised of the principal and unpaid interest.

[0001193125-26-259683:mdna:166]
Credit Facility and Commercial Paper Program

[0001193125-26-259683:mdna:167]
We have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in March 2025, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on March 5, 2030, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of April 24, 2026, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0001193125-26-259683:mdna:168]
We also have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of April 24, 2026.

[0001193125-26-259683:mdna:169]
Material Capital Expenditure Requirements

[0001193125-26-259683:mdna:170]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects for at least the next 12 months through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the enterprise storage and data management industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements.

[0001193125-26-259683:mdna:171]
Transition Tax Payments

[0001193125-26-259683:mdna:172]
The Tax Cuts and Jobs Act of 2017 imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits that had not previously been subject to U.S. income tax. A final transition tax payment of $179 million was paid during the second quarter of fiscal 2026.

[0001193125-26-259683:mdna:173]
Dividends and Stock Repurchase Program

[0001193125-26-259683:mdna:174]
On May 21, 2026, we declared a cash dividend of $0.52 per share of common stock, payable on July 29, 2026 to holders of record as of the close of business on July 10, 2026.

[0001193125-26-259683:mdna:175]
47

[0001193125-26-259683:mdna:176]
Under our common stock repurchase program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. As of April 24, 2026, the remaining authorized amount for stock repurchases under this program was $0.5 billion. On May 21, 2026 our Board of Directors authorized the repurchase of an additional $1.0 billion of our common stock.

[0001193125-26-259683:mdna:177]
Purchase Commitments

[0001193125-26-259683:mdna:178]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled $1.4 billion at April 24, 2026, of which $1.1 billion is due in fiscal 2027, with the remainder due thereafter.

[0001193125-26-259683:mdna:179]
Legal Contingencies

[0001193125-26-259683:mdna:180]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 16 – Commitments and Contingencies of the Notes to Consolidated Financial Statements included in Part II, Item 8.

[0001193125-26-259683:mdna:181]
Critical Accounting Estimates

[0001193125-26-259683:mdna:182]
Our consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (GAAP), which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and liabilities. Our estimates are based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0001193125-26-259683:mdna:183]
The summary of significant accounting policies is included in Note 1 – Description of Business and Significant Accounting Policies of the Notes to Consolidated Financial Statements included in Part II, Item 8. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, and if changes in the estimate that are reasonably possible could materially impact the financial statements. The accounting policies described below reflect the significant judgments, estimates and assumptions used in the preparation of the consolidated financial statements.

[0001193125-26-259683:mdna:184]
Revenue Recognition

[0001193125-26-259683:mdna:185]
Our contracts with customers often include the transfer of multiple products and services to the customer. In determining the amount and timing of revenue recognition, we assess which products and services are distinct performance obligations and allocate the transaction price, which may include fixed and/or variable amounts, among each performance obligation on a relative standalone selling price (SSP) basis. The following are the key estimates and assumptions and corresponding uncertainties included in this approach:

[0001193125-26-259683:mdna:186]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | We evaluate whether products and services promised in our contracts with customers are distinct performance obligations that should be accounted for separately versus together. |  |  | In certain contracts, the determination of our distinct performance obligations requires significant judgment. As our business and offerings to customers change over time, the products and services we determine to be distinct performance obligations may change. Such changes may adversely impact the amount of revenue and gross margin we report in a particular period. |
|  | In determining the transaction price of our contracts, we estimate variable consideration based on the expected value, primarily relying on our history. In certain situations, we may also use the most likely amount as the basis of our estimate. |  |  | We may have insufficient relevant historical data or other information to arrive at an accurate estimate of variable consideration using either the “expected value” or “most likely amount” method. Additionally, changes in business practices, such as those related to sales returns or marketing programs, |

[0001193125-26-259683:mdna:187]
|  |  |  |  | may introduce new forms of variable consideration, as well as more complexity and uncertainty in the estimation process. |
|  | In contracts with multiple performance obligations, we establish SSPs based on the price at which products and services are sold separately. If SSPs are not observable through past transactions, we estimate them by maximizing the use of observable inputs including pricing strategy, market data, internally-approved pricing guidelines related to the performance obligations and other observable inputs. |  |  | As our business and offerings evolve over time, modifications to our pricing and discounting methodologies, changes in the scope and nature of product and service offerings and/or changes in customer segmentation may result in a lack of consistency, making it difficult to establish and/or maintain SSPs. Changes in SSPs could result in different and unanticipated allocations of revenue in contracts with multiple performance obligations. These factors, among others, may adversely impact the amount of revenue and gross margin we report in a particular period. |

[0001193125-26-259683:mdna:188]
Goodwill and Purchased Intangible Assets

[0001193125-26-259683:mdna:189]
We allocate the purchase price of acquisitions to identifiable assets acquired and liabilities assumed at their acquisition date fair values based on established valuation techniques. Goodwill represents the residual value as of the acquisition date, which in most cases is measured as the excess of the purchase consideration transferred over the net of the acquisition date fair values of the assets acquired and liabilities assumed.

[0001193125-26-259683:mdna:190]
The carrying values of purchased intangible assets are reviewed whenever events and circumstances indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. We periodically review the estimated remaining useful lives of our intangible assets. This review may result in impairment charges or shortened useful lives, resulting in charges to our consolidated statements of income.

[0001193125-26-259683:mdna:191]
We review goodwill for impairment annually and whenever events or changes in circumstances indicate the carrying amount of one of our reporting units may exceed its fair value. The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. For our annual goodwill impairment test in the fourth quarter of fiscal 2026, we performed a qualitative assessment of goodwill impairment by evaluating relevant factors to determine whether it is more likely than not that the fair value of each of our reporting units is less than their carrying values. As a result of the qualitative assessment, we determined the quantitative test was not necessary and there was no impairment of goodwill.

[0001193125-26-259683:mdna:192]
49

[0001193125-26-259683:mdna:193]
The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our goodwill and purchased intangible assets:

[0001193125-26-259683:mdna:194]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the accounting guidance for the fair value measurement of nonfinancial assets.The valuation of purchased intangible assets is principally based on estimates of the future performance and cash flows expected to be generated by the acquired assets from the acquired business. |  |  | While we employ experts to determine the acquisition date fair value of acquired intangibles, the fair values of assets acquired and liabilities assumed are based on significant management assumptions and estimates, which are inherently uncertain and highly subjective and as a result, actual results may differ from estimates. If different assumptions were to be used, it could materially impact the purchase price allocation. |
|  | Evaluations of possible goodwill and purchased intangible asset impairment require us to make judgments and assumptions related to the allocation of our balance sheet and income statement amounts and estimate future cash flows and fair market values of our reporting units and assets. |  |  | In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill or purchased intangible assets. Assumptions and estimates about expected future cash flows and the fair values of our reporting units and purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as the adverse impact of unanticipated changes in macroeconomic conditions, and technological changes or new product introductions from competitors. They can also be affected by internal factors such as changes in business strategy or in forecasted product life cycles and roadmaps. Our ongoing consideration of these and other factors could result in future impairment charges or accelerated amortization expense, which could adversely affect our operating results. |

[0001193125-26-259683:mdna:195]
Income Taxes

[0001193125-26-259683:mdna:196]
We are subject to income taxes in the United States and numerous foreign jurisdictions. We compute our provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets or liabilities are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0001193125-26-259683:mdna:197]
The following are the key estimates and assumptions and corresponding uncertainties for our income taxes:

[0001193125-26-259683:mdna:198]
50

[0001193125-26-259683:mdna:199]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | Our income tax provision is based on existing tax law and advanced pricing agreements or letter rulings we have with various tax authorities. |  |  | Our provision for income taxes is subject to volatility and could be adversely impacted by future changes in existing tax laws, such as a change in tax rate, possible U.S. changes to the taxation of earnings of our foreign subsidiaries, and uncertainties as to future renewals of favorable tax agreements and rulings. |
|  | The determination of whether we should record or adjust a valuation allowance against our deferred tax assets is based on assumptions regarding our future profitability. |  |  | Our future profits could differ from current expectations resulting in a change to our determination as to the amount of deferred tax assets that are more likely than not to be realized. We could adjust our valuation allowance with a corresponding impact to the tax provision in the period in which such determination is made. |
|  | The estimates for our uncertain tax positions are based primarily on company specific circumstances, applicable tax laws, tax opinions from outside firms and past results from examinations of our income tax returns. |  |  | Significant judgment is required in evaluating our uncertain tax positions. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome or tax court rulings of these matters will not be different from that which is reflected in our historical tax provisions and accruals. |
