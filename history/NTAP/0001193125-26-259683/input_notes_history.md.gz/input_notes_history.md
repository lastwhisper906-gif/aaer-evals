# NTAP note change history — 0001193125-25-297237 → 0001193125-26-076622


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-02-26):
[0001193125-26-076622:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of January 23, 2026, we had $0.7 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 23, 2026 and April 25, 2025, such liability amounted to $26 million and $22 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2025-11-25, similarity 0.9862):
[0001193125-25-297237:note_history:1]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of October 24, 2025, we had $0.7 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 24, 2025 and April 25, 2025, such liability amounted to $21 million and $22 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2026-02-26):
[0001193125-26-076622:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 23, 2026, we had $0.4 billion in other purchase obligations.
  (was, 2025-11-25, similarity 0.9778):
[0001193125-25-297237:note_history:2]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 24, 2025, we had $0.5 billion in other purchase obligations.

- changed (2026-02-26):
[0001193125-26-076622:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution. We sold $25 million and $42 million of receivables during the nine months ended January 23, 2026 and January 24, 2025, respectively.
  (was, 2025-11-25, similarity 0.9109):
[0001193125-25-297237:note_history:3]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution. We sold $16 million and $26 million of receivables during the six months ended October 24, 2025 and October 25, 2024, respectively.

- changed (2026-02-26):
[0001193125-26-076622:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of January 23, 2026 and April 25, 2025, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2025-11-25, similarity 0.9901):
[0001193125-25-297237:note_history:4]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of October 24, 2025 and April 25, 2025, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- changed (2026-02-26):
[0001193125-26-076622:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 23, 2026, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make material payments under these arrangements is remote.
  (was, 2025-11-25, similarity 0.7707):
[0001193125-25-297237:note_history:5]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 24, 2025, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make material payments under these arrangements is remote.

- changed (2026-02-26):
[0001193125-26-076622:note_history:6]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.
  (was, 2025-11-25, similarity 0.6813):
[0001193125-25-297237:note_history:6]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a

- changed (2026-02-26):
[0001193125-26-076622:note_history:7]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of January 23, 2026 related to such matters.
  (was, 2025-11-25, similarity 0.9922):
[0001193125-25-297237:note_history:7]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of October 24, 2025 related to such matters.

- removed (2026-02-26):
[0001193125-25-297237:note_history:8]
meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-02-26):
[0001193125-26-076622:note_history:9]
NetApp, Inc. (we, us, our, NetApp, or the Company) helps customers make their data infrastructure more seamless, more dynamic, and higher performing. We provide a full range of enterprise-class software, systems, and services that customers use to transform their data infrastructures across data types, workloads, and environments to realize business possibilities.
  (was, 2025-11-25, similarity 0.9986):
[0001193125-25-297237:note_history:9]
NetApp, Inc. (we, us, our, NetApp, or the Company) helps customers make their data infrastructure more seamless, more dynamic, and higher performing. We provide a full range of enterprise-class software, systems and services that customers use to transform their data infrastructures across data types, workloads, and environments to realize business possibilities.

- changed (2026-02-26):
[0001193125-26-076622:note_history:10]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 25, 2025 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 23, 2026 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2025-11-25, similarity 0.9773):
[0001193125-25-297237:note_history:10]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 25, 2025 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 24, 2025 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- changed (2026-02-26):
[0001193125-26-076622:note_history:11]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, the anticipated effects of which have been incorporated, as applicable, into management's estimates as of January 23, 2026.
  (was, 2025-11-25, similarity 0.992):
[0001193125-25-297237:note_history:11]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, the anticipated effects of which have been incorporated, as applicable, into management's estimates as of October 24, 2025.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-26):
[0001193125-26-076622:note_history:12]
|  |  | Effective Interest Rate |  | January 23, 2026 |  |  | April 25, 2025 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  | $ | — |  |  | $ | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| 5.50% Senior Notes Due March 2032 |  | 5.71% |  |  | 625 |  |  |  | 625 |  |
| 5.70% Senior Notes Due March 2035 |  | 5.90% |  |  | 625 |  |  |  | 625 |  |
| Total principal amount |  |  |  |  | 2,500 |  |  |  | 3,250 |  |
| Unamortized discount and issuance costs |  |  |  |  | (14 | ) |  |  | (15 | ) |
| Total senior notes |  |  |  |  | 2,486 |  |  |  | 3,235 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (750 | ) |
| Total long-term debt |  |  |  | $ | 2,486 |  |  | $ | 2,485 |  |
  (was, 2025-11-25, similarity 0.9893):
[0001193125-25-297237:note_history:12]
|  |  | Effective Interest Rate |  | October 24, 2025 |  |  | April 25, 2025 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  | $ | — |  |  | $ | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| 5.50% Senior Notes Due March 2032 |  | 5.71% |  |  | 625 |  |  |  | 625 |  |
| 5.70% Senior Notes Due March 2035 |  | 5.90% |  |  | 625 |  |  |  | 625 |  |
| Total principal amount |  |  |  |  | 2,500 |  |  |  | 3,250 |  |
| Unamortized discount and issuance costs |  |  |  |  | (14 | ) |  |  | (15 | ) |
| Total senior notes |  |  |  |  | 2,486 |  |  |  | 3,235 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (750 | ) |
| Total long-term debt |  |  |  | $ | 2,486 |  |  | $ | 2,485 |  |

- changed (2026-02-26):
[0001193125-26-076622:note_history:13]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 23, 2026, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2025-11-25, similarity 0.9892):
[0001193125-25-297237:note_history:13]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 24, 2025, we were in compliance with all covenants associated with the Senior Notes.

- changed (2026-02-26):
[0001193125-26-076622:note_history:14]
As of January 23, 2026, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2025-11-25, similarity 0.9362):
[0001193125-25-297237:note_history:14]
As of October 24, 2025, our aggregate future principal debt maturities are as follows (in millions):

- changed (2026-02-26):
[0001193125-26-076622:note_history:15]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of January 23, 2026 or April 25, 2025.
  (was, 2025-11-25, similarity 0.9915):
[0001193125-25-297237:note_history:15]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of October 24, 2025 or April 25, 2025.

- changed (2026-02-26):
[0001193125-26-076622:note_history:16]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in March 2025, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on March 5, 2030, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 23, 2026, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.
  (was, 2025-11-25, similarity 0.9911):
[0001193125-25-297237:note_history:16]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in March 2025, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on March 5, 2030, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of October 24, 2025, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-26):
[0001193125-26-076622:note_history:17]
|  |  | Effective Interest Rate |  | January 23, 2026 |  |  | April 25, 2025 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  | $ | — |  |  | $ | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| 5.50% Senior Notes Due March 2032 |  | 5.71% |  |  | 625 |  |  |  | 625 |  |
| 5.70% Senior Notes Due March 2035 |  | 5.90% |  |  | 625 |  |  |  | 625 |  |
| Total principal amount |  |  |  |  | 2,500 |  |  |  | 3,250 |  |
| Unamortized discount and issuance costs |  |  |  |  | (14 | ) |  |  | (15 | ) |
| Total senior notes |  |  |  |  | 2,486 |  |  |  | 3,235 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (750 | ) |
| Total long-term debt |  |  |  | $ | 2,486 |  |  | $ | 2,485 |  |
  (was, 2025-11-25, similarity 0.9893):
[0001193125-25-297237:note_history:17]
|  |  | Effective Interest Rate |  | October 24, 2025 |  |  | April 25, 2025 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  | $ | — |  |  | $ | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| 5.50% Senior Notes Due March 2032 |  | 5.71% |  |  | 625 |  |  |  | 625 |  |
| 5.70% Senior Notes Due March 2035 |  | 5.90% |  |  | 625 |  |  |  | 625 |  |
| Total principal amount |  |  |  |  | 2,500 |  |  |  | 3,250 |  |
| Unamortized discount and issuance costs |  |  |  |  | (14 | ) |  |  | (15 | ) |
| Total senior notes |  |  |  |  | 2,486 |  |  |  | 3,235 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (750 | ) |
| Total long-term debt |  |  |  | $ | 2,486 |  |  | $ | 2,485 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-26):
[0001193125-26-076622:note_history:18]
As of January 23, 2026, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2025-11-25, similarity 0.9362):
[0001193125-25-297237:note_history:18]
As of October 24, 2025, our aggregate future principal debt maturities are as follows (in millions):
