# NTAP notes — 0001193125-26-259683


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001193125-26-259683:notes:1]
The information called for by Part III of this Form 10-K is hereby incorporated by reference from the definitive Proxy Statement for our annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after April 24, 2026.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001193125-26-259683:notes:2]
Item 1C.  Cybersecurity

[0001193125-26-259683:notes:3]
Risk Management and Strategy

[0001193125-26-259683:notes:4]
The Company regularly assesses risks from cybersecurity threats, monitors its information systems for potential vulnerabilities, and tests those systems pursuant to the Company’s cybersecurity policies, standards, processes and practices, which are integrated into the Company’s overall risk management system. To protect the Company’s information systems from cybersecurity threats, the Company uses various security technologies and tools that help the Company identify, escalate, investigate, manage, resolve and recover from security incidents in a timely manner. These efforts include:

[0001193125-26-259683:notes:5]
•
ongoing collection of threat intelligence and environment awareness through monitoring,

[0001193125-26-259683:notes:6]
•
data protection management and vulnerability monitoring through data loss prevention and exfiltration tools,

[0001193125-26-259683:notes:7]
•
cybersecurity risk management processes and practices,

[0001193125-26-259683:notes:8]
•
control assurance,

[0001193125-26-259683:notes:9]
•
secure development of new products,

[0001193125-26-259683:notes:10]
•
identity and access management,

[0001193125-26-259683:notes:11]
•
incident response, auditing and monitoring, and

[0001193125-26-259683:notes:12]
•
maintaining a 24x7 security operations center to allow for always available incident response.

[0001193125-26-259683:notes:13]
The Company takes a risk-based approach to cybersecurity and has implemented cybersecurity policies throughout its operations that are designed to address cybersecurity threats and incidents. In particular, the Company follows an incident escalation process that is incorporated into its incident and risk management processes. In the event the Company identifies a cybersecurity incident, its senior management, consisting of the Chief Financial Officer, Chief Information Security Officer (CISO), Chief Administrative Officer, and Executive Vice President of Business Technology and Operations review the facts and circumstances involved in such cybersecurity incident, or series of related cybersecurity incidents.

[0001193125-26-259683:notes:14]
The Company partners with third parties to assess the effectiveness of its cybersecurity prevention and response systems and processes, including third-party review of the Company’s Information Security Management System for ISO 27001 controls, assessment of the Company’s cloud products and managed services according to the American Institute of CPAs (AICPA) Service Organization Control (SOC) Audit Type II, and new product validation as part of the Company’s secure development lifecycle. The Company additionally engages third-party providers in support of endpoint detection and responses, data loss prevention efforts, and incident management efforts.

[0001193125-26-259683:notes:15]
To date, the Company is not aware of cybersecurity threats, including as a result of any previous cybersecurity incidents, that have materially affected or are reasonably likely to materially affect the Company, including its business strategy, results of operations or financial condition. For additional discussion of cybersecurity risks and potential related impacts on the Company, refer to the risk factors in Part I, Item 1A – “Risk Factors,” including “If a material cybersecurity or other security breach impacts our services, systems, supply chain, or end-user customer systems, or if stored data is improperly accessed, our business could suffer significant harm.”

[0001193125-26-259683:notes:16]
Governance

[0001193125-26-259683:notes:17]
NetApp's Board of Directors oversees the Company’s risk management process, including cybersecurity risks, directly and through its committees. The Audit Committee of the Board of Directors oversees the Company’s risk management program, which focuses on the most significant risks the Company faces in the short-, intermediate-, and long-term timeframes. The Company’s CISO presents cybersecurity updates to the Audit Committee at least twice a year, and has a standing quarterly private session to update the Audit Committee on any relevant matters, as needed. Such updates include a review of cybersecurity risks affecting the Company, related metrics, and any incidents or issues that require attention from the Audit Committee or Board of Directors. Additionally, the Board of Directors receives a presentation at least annually regarding key developments and topics in cybersecurity from management along with a third party cybersecurity expert.

[0001193125-26-259683:notes:18]
The CISO provides leadership, strategic direction, and oversight for NetApp’s Global Security Risk and Compliance functions and security program. Global Security executives oversee management of risks and track projects progress, remediations, and any issues related to cybersecurity risks.

[0001193125-26-259683:notes:19]
NetApp’s CISO is responsible for leading the assessment and management of cybersecurity risks. The current CISO has over 30 years of experience in IT and information security, including over 16 years with NetApp in roles of increasing seniority, and is a Certified Information Security Auditor, Certified Information Security Manager with ISACA and a Certified Information Systems Security Professional with ISC2. The CISO stays informed on information security risks through regular meetings on key cybersecurity projects and KPIs. Updates are communicated to the Global Security Steering Committee, which provides quarterly reports to the Board of Directors and to the Audit Committee.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001193125-26-259683:notes:20]
1. Description of Business and Significant Accounting Policies

[0001193125-26-259683:notes:21]
Description of Business — NetApp, Inc. (we, us, NetApp, or the Company) empowers organizations to realize the full potential of their data in a rapidly evolving digital world. NetApp delivers innovative solutions that enable seamless data management, protection, and mobility across on-premises, hybrid, and multi-cloud environments.

[0001193125-26-259683:notes:22]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal years 2026, 2025 and 2024, which ended on April 24, 2026, April 25, 2025 and April 26, 2024, respectively, are all 52-week years, with 13 weeks in each of their quarters. Unless otherwise stated, references to particular years, quarters, months, and periods refer to the Company’s fiscal years ended on the last Friday of April and the associated quarters, months, and periods of those fiscal years.

[0001193125-26-259683:notes:23]
Principles of Consolidation — The consolidated financial statements include the Company and its subsidiaries. Intercompany accounts and transactions are eliminated in consolidation.

[0001193125-26-259683:notes:24]
Use of Estimates — The preparation of the consolidated financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes; and fair value measurements. Actual results could differ materially from those estimates, the anticipated effects of which have been incorporated, as applicable, into management’s estimates as of and for the year ended April 24, 2026.

[0001193125-26-259683:notes:25]
Cash Equivalents — We consider all highly liquid debt investments with original maturities of three months or less at the time of purchase to be cash equivalents.

[0001193125-26-259683:notes:26]
Available-for-Sale Investments — We classify our investments in debt securities as available-for-sale investments. Debt securities primarily consist of U.S. Treasury and government debt securities and certificates of deposit. These investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of debt securities sold. These investments are recorded in the consolidated balance sheets at fair value.

[0001193125-26-259683:notes:27]
Unrealized gains and temporary losses, net of related taxes, are included in accumulated other comprehensive income (loss) (AOCI). Upon realization, those amounts are reclassified from AOCI to earnings. The amortization of premiums and discounts on the investments are included in our results of operations. Realized gains and losses are calculated based on the specific identification method.

[0001193125-26-259683:notes:28]
We classify our investments as current or noncurrent based on the nature of the investments and their availability for use in current operations.

[0001193125-26-259683:notes:29]
Impairments on Investments — All of our available-for-sale investments are subject to periodic impairment review. When the fair value of a debt security is less than its amortized cost, we assess what amount of the difference, if any, is caused by expected credit losses. The amount of the difference representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in earnings, and the amount relating to all other factors is recognized in other comprehensive income (OCI). If we intend to sell the security, or if it is more likely than not we will be required to sell the security before recovery of the amortized cost basis, the entire difference between the amortized cost and the fair value of the debt security is recognized in earnings.

[0001193125-26-259683:notes:30]
Inventories — Inventories are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. We write down excess and obsolete inventory based on the difference between the cost of inventory and the estimated net realizable value. Net realizable value is estimated using management’s best estimate of forecasts for future demand and expectations regarding market conditions. At the point of a loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts or circumstances do not result in the restoration or increase in that newly established basis. In addition, we record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0001193125-26-259683:notes:31]
Property and Equipment — Property and equipment are recorded at cost.

[0001193125-26-259683:notes:32]
Depreciation and amortization is computed using the straight-line method, generally over the following periods:

[0001193125-26-259683:notes:33]
|  |  | Depreciation Life |
| Buildings and improvements |  | 10 to 40 years |
| Furniture and fixtures |  | 5 years |
| Computer, production, engineering and other equipment |  | 2 to 3 years |
| Computer software |  | 3 to 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |

[0001193125-26-259683:notes:34]
Construction in progress will be depreciated over the estimated useful lives of the respective assets when they are ready for use. We capitalize interest on significant facility assets under construction and on significant software development projects. Interest capitalized during the periods presented was not material.

[0001193125-26-259683:notes:35]
Software Development Costs — The costs for the development of new software products and substantial enhancements to existing software products are expensed as incurred until technological feasibility has been established, at which time any additional costs would be capitalized in accordance with the accounting guidance for software. Because our current process for developing software is essentially completed concurrently with the establishment of technological feasibility, which occurs upon the completion of a working model, no costs have been capitalized for any of the periods presented.

[0001193125-26-259683:notes:36]
Internal-Use Software Development Costs — We capitalize qualifying costs, which are incurred during the application development stage, for computer software developed or obtained for internal-use to property and equipment, net and amortize them over the software’s estimated useful life.

[0001193125-26-259683:notes:37]
Business Combinations — We recognize identifiable assets acquired and liabilities assumed at their acquisition date fair values, with the exception of contract assets and liabilities, which we recognize in accordance with our revenue recognition policy as if we had originally executed the customer contract. Goodwill as of the acquisition date is measured as the excess of consideration transferred over the net of the acquisition date values of the assets acquired and liabilities assumed. While we use our best estimates and assumptions as a part of the purchase price allocation process to accurately value assets acquired and liabilities assumed at the acquisition date, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of income.

[0001193125-26-259683:notes:38]
Goodwill and Purchased Intangible Assets — Goodwill is recorded when the consideration paid for an acquisition exceeds the value of net tangible and intangible assets acquired. Purchased intangible assets with finite lives are generally amortized on a straight-line basis over their economic lives of three to five years for developed technology, two to five years for customer contracts/relationships, two to three years for covenants not to compete and two to five years for trademarks and trade names as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. In-process research and development is accounted for as an indefinite lived intangible asset and is assessed for potential impairment annually until development is complete or when events or circumstances indicate that their carrying amounts might be impaired. Upon completion of development, in-process research and development is accounted for as a finite-lived intangible asset.

[0001193125-26-259683:notes:39]
The carrying value of goodwill is tested for impairment on an annual basis in the fourth quarter of our fiscal year, or more frequently if we believe indicators of impairment exist. Triggering events for impairment reviews may be indicators such as adverse industry or economic trends, restructuring actions, lower projections of profitability, or a sustained decline in our market capitalization. For the purpose of impairment testing, we have two reporting units, which are the same as our two reportable segments. We initially conduct a qualitative assessment to determine whether it is necessary to perform a quantitative goodwill impairment test. The performance of the quantitative impairment test requires comparing the fair value of each reporting unit to its carrying amount, including goodwill. The fair value of each reporting unit is based on a combination of the income approach and the market approach.

[0001193125-26-259683:notes:40]
Under the income approach, we estimate the fair value of a reporting unit based on the present value of estimated future cash flows. Cash flow projections are based on discrete forecast periods as well as terminal value determinations, and are derived based on forecasted revenue growth rates and operating margins. These cash flow projections are discounted to arrive at the fair value of each reporting unit. The discount rate used is based on the weighted-average cost of capital of comparable public companies adjusted for the relevant risk associated with business specific characteristics and the uncertainty related to the reporting unit's ability to execute on the projected cash flows. Under the market approach, we estimate the fair value based on market multiples of revenue and earnings derived from comparable publicly traded companies with operating and investment characteristics similar to the reporting unit. In addition, we make certain judgments and assumptions in allocating shared assets and liabilities to individual reporting units to determine the carrying amount of each reporting unit. An impairment exists if the fair value of a reporting unit is lower than its carrying amount. The impairment loss is measured based on the amount by which the carrying amount of the reporting unit exceeds its fair value, with the recognized loss not to exceed the total amount of allocated goodwill. We did not recognize any impairment charges on our goodwill in any of the periods presented.

[0001193125-26-259683:notes:41]
Impairment of Long-Lived Assets — We review the carrying values of long-lived assets whenever events and circumstances, such as reductions in demand, lower projections of profitability, significant changes in the manner of our use of acquired assets, or significant negative industry or economic trends, indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. If this review indicates that there is an impairment, the impaired asset is written down to its fair value, which is typically calculated using: (i) quoted market prices and/or (ii) expected future cash flows utilizing a discount rate. Our estimates regarding future anticipated cash flows, the remaining economic life of the products and technologies, or both, may differ materially from actual cash flows and remaining economic life. In that event, impairment charges or shortened useful lives of certain long-lived assets may be required, resulting in charges to our consolidated statements of income when such determinations are made.

[0001193125-26-259683:notes:42]
Derivative Instruments — Our derivative instruments, which are carried at fair value in our consolidated balance sheets, consist of foreign currency exchange contracts as described below:

[0001193125-26-259683:notes:43]
Balance Sheet Hedges — We utilize foreign currency exchange forward contracts to hedge against the short-term impact of foreign currency exchange rate fluctuations related to certain foreign currency denominated monetary assets and liabilities, primarily intercompany receivables and payables. These derivative instruments are not designated as hedging instruments and do not subject us to material balance sheet risk due to exchange rate movements because the gains and losses on these contracts are intended to offset the gains and losses in the underlying foreign currency denominated monetary assets and liabilities being hedged, and the net amount is included in earnings.

[0001193125-26-259683:notes:44]
Cash Flow Hedges — We utilize foreign currency exchange forward contracts to hedge foreign currency exchange exposures related to forecasted sales transactions denominated in certain foreign currencies. These derivative instruments are designated and qualify as cash flow hedges and, in general, closely match the underlying forecasted transactions in duration. The effective portion of the contracts’ gains and losses resulting from changes in fair value is recorded in AOCI until the forecasted transaction is recognized in the consolidated statements of income. When the forecasted transactions occur, we reclassify the related gains or losses on the cash flow hedges into net revenues. If the underlying forecasted transactions do not occur, or it becomes probable that they will not occur within the defined hedge period, the gains or losses on the related cash flow hedges are reclassified from AOCI and recognized immediately in earnings. We measure the effectiveness of hedges of forecasted transactions on a monthly basis by comparing the fair values of the designated foreign currency exchange forward purchase contracts with the fair values of the forecasted transactions.

[0001193125-26-259683:notes:45]
Factors that could have an impact on the effectiveness of our hedging programs include the accuracy of forecasts and the volatility of foreign currency markets. These programs reduce, but do not entirely eliminate, the impact of currency exchange movements. Currently, we do not enter into any foreign currency exchange forward contracts to hedge exposures related to firm commitments. Cash flows from our derivative programs are included under operating activities in the consolidated statements of cash flows.

[0001193125-26-259683:notes:46]
Revenue Recognition — We recognize revenue by applying the following five step approach.

[0001193125-26-259683:notes:47]
•
Identification of the contract, or contracts, with a customer — A contract with a customer is within the scope of ASC 606 when it meets all the following criteria:

[0001193125-26-259683:notes:48]
-
It is enforceable

[0001193125-26-259683:notes:49]
-
It defines each party’s rights

[0001193125-26-259683:notes:50]
-
It identifies the payment terms

[0001193125-26-259683:notes:51]
-
It has commercial substance, and

[0001193125-26-259683:notes:52]
-
We determine that collection of substantially all consideration for goods or services that will be transferred is probable based on the customer’s intent and ability to pay

[0001193125-26-259683:notes:53]
•
Identification of the performance obligations in the contract — Performance obligations promised in a contract are identified based on the goods or services (or a bundle of goods and services) that will be transferred to the customer that are distinct.

[0001193125-26-259683:notes:54]
•
Determination of the transaction price — The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer.

[0001193125-26-259683:notes:55]
•
Allocation of the transaction price to the performance obligations in the contract — Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation.

[0001193125-26-259683:notes:56]
•
Recognition of revenue when, or as, we satisfy a performance obligation — We satisfy performance obligations either over time or at a point in time.

[0001193125-26-259683:notes:57]
Customarily we have a purchase order from or executed contract with our customers that establishes the goods and services to be transferred and the consideration to be received.

[0001193125-26-259683:notes:58]
We combine two or more contracts entered into at or near the same time with the same customer as a single contract if the contracts are negotiated as one package with a single commercial objective, if the amount of consideration to be paid on one contract depends on the price or performance of the other contract or if the goods and services promised in each of the contracts are a single performance obligation.

[0001193125-26-259683:notes:59]
Our contracts with customers may include hardware systems, software licenses, software support, hardware support, public cloud services and other services. Software support contracts entitle our customers to receive unspecified upgrades and enhancements on a when-and-if-available basis, and patch releases. Hardware support services include contracts for extended warranty and technical support with minimum response times. Other services include professional services and customer education and training services.

[0001193125-26-259683:notes:60]
We identify performance obligations in our contracts to be those goods and services that are distinct. A good or service is distinct where the customer can benefit from the good or service either on its own or together with other resources that are readily available from third parties or from us, and is distinct in the context of the contract, where the transfer of the good or service is separately identifiable from other promises in the contract.

[0001193125-26-259683:notes:61]
If a contract includes multiple promised goods or services, we apply judgment to determine whether promised goods or services are distinct. If they are not, we combine the goods and services until we have a distinct performance obligation. For example, a configured storage system inclusive of the operating system (OS) software essential to its functionality is considered a single performance obligation, while optional add-on software is a separate performance obligation. In general, hardware support, software support, and different types of professional services are each separate performance obligations.

[0001193125-26-259683:notes:62]
We determine the transaction price of our contracts with customers based on the consideration to which we will be entitled in exchange for transferring goods or services. Consideration promised may include fixed amounts, variable amounts or both. We sell public cloud services either on a subscription basis or a consumption basis. We sell professional services either on a time and materials basis or under fixed price projects.

[0001193125-26-259683:notes:63]
We evaluate variable consideration in arrangements with contract terms such as rights of return, potential penalties and acceptance clauses. We generally use the expected value method, primarily relying on our history, to estimate variable consideration. However, when we believe it to provide a better estimate, we use the most likely amount method. In either case, we consider variable consideration only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recognized will not occur. Reassessments of our variable consideration may occur as historical information changes. Transaction prices are also adjusted for the effects of time value of money if the timing of payments provides either the customer or us a significant benefit of financing.

[0001193125-26-259683:notes:64]
Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation on a relative standalone selling price basis. We determine standalone selling price based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price by maximizing the use of observable inputs including pricing strategy, market data, internally-approved pricing guidelines related to the performance obligations and other observable inputs. We regularly review standalone selling prices and maintain internal controls over the establishment and updates of these estimates. Variable consideration is also allocated to the performance obligations. If the terms of variable consideration relate to one performance obligation, it is entirely allocated to that obligation. Otherwise, it is allocated to all the performance obligations in the contract.

[0001193125-26-259683:notes:65]
We typically recognize revenue at a point in time upon the transfer of goods to a customer. Products we transfer at a point in time include our configured hardware systems, OS software licenses, optional add-on software licenses and add-on hardware. Services are typically transferred over time and revenue is recognized based on an appropriate method for measuring our progress toward

[0001193125-26-259683:notes:66]
completion of the performance obligation. Our stand-ready services, including both hardware and software support, are transferred ratably over the period of the contract. Our public cloud services are transferred either 1) for subscription arrangements, ratably over the subscription period or 2) for consumption-based arrangements, as actually consumed by the customer. For other services such as our fixed professional services contracts, we use an input method to determine the percentage of completion. That is, we estimate the effort to date versus the expected effort required over the life of the contract.

[0001193125-26-259683:notes:67]
Deferred Commissions — We capitalize sales commissions that are incremental direct costs of obtaining customer contracts for which revenue is not immediately recognized and classify them as current or non-current based on the terms of the related contracts. Capitalized commissions are amortized based on the transfer of goods or services to which they relate, typically over one to four years, and are also periodically reviewed for impairment. Amortization expense is recorded to sales and marketing expense in our consolidated statements of income.

[0001193125-26-259683:notes:68]
Leases — We determine if an arrangement is or contains a lease at inception, and we classify leases as operating or finance leases at commencement. In our consolidated balance sheets, operating lease right-of-use (ROU) assets are included in other non-current assets, while finance lease ROU assets are included in property and equipment, net. Lease liabilities for both types of leases are included in accrued expenses and other long-term liabilities. ROU assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over that term.

[0001193125-26-259683:notes:69]
Operating and finance lease ROU assets and liabilities are recognized at commencement based on the present value of lease payments over the lease term. ROU assets also include any lease payments made prior to lease commencement and exclude lease incentives. The lease term is the noncancelable period of the lease and includes options to extend or terminate the lease when it is reasonably certain that an option will be exercised. As the rate implicit in our leases is typically not readily determinable, in computing the present value of lease payments we generally use our incremental borrowing rate based on information available at the commencement date. Variable lease payments not dependent on an index or rate are expensed as incurred and not included within the calculation of ROU assets and lease liabilities. Lease expense for operating lease payments is recognized on a straight-line basis over the lease term.

[0001193125-26-259683:notes:70]
We do not separate non-lease components from lease components for any class of leases, and we do not recognize ROU assets and lease liabilities for leases with a lease term of twelve months or less.

[0001193125-26-259683:notes:71]
Foreign Currency Translation — For international subsidiaries whose functional currency is the local currency, gains and losses resulting from translation of these foreign currency financial statements into U.S. dollars are recorded in AOCI. For international subsidiaries where the functional currency is the U.S. dollar, gains and losses resulting from the process of remeasuring foreign currency financial statements into U.S. dollars are included in other (expense) income, net.

[0001193125-26-259683:notes:72]
Benefit Plans — We record actuarial gains and losses associated with defined benefit plans within AOCI and amortize net gains or losses in excess of 10 percent of the greater of the market value of plan assets as of the beginning of the fiscal year or the plans' projected benefit obligation on a straight-line basis over the remaining estimated service life of plan participants. The measurement date for all defined benefit plans is our fiscal year end.

[0001193125-26-259683:notes:73]
Stock-Based Compensation — We measure and recognize stock-based compensation for all stock-based awards, including restricted stock units (RSUs), comprising time-based RSUs and performance-based RSUs (PBRSUs), and rights to purchase shares under our employee stock purchase plan (ESPP), based on their estimated fair value, and recognize the costs in our financial statements using the straight-line attribution approach over the requisite service period for the entire award.

[0001193125-26-259683:notes:74]
The fair value of employee time-based RSUs, and PBRSUs that include a performance condition, is equal to the market value of our common stock on the grant date of the award, less the present value of expected dividends during the vesting period, discounted at a risk-free interest rate. The fair value of PBRSUs that include a market condition is measured using a Monte Carlo simulation model on the date of grant.

[0001193125-26-259683:notes:75]
The fair value of time-based RSUs, and PBRSUs that include a market condition, is not remeasured as a result of subsequent stock price fluctuations. When there is a change in management’s estimate of expected achievement relative to the performance target for PBRSUs that include a performance condition, such as our achievement against a billings result average target, the change in estimate results in the recognition of a cumulative adjustment of stock-based compensation expense.

[0001193125-26-259683:notes:76]
Our stock price volatility assumption is based on a combination of our historical and implied volatility. The risk-free interest rates are based upon United States (U.S.) Treasury bills with equivalent expected terms, and the expected dividends are based on our history and expected dividend payouts.

[0001193125-26-259683:notes:77]
We account for forfeitures of stock-based awards as they occur.

[0001193125-26-259683:notes:78]
Income Taxes — Deferred income tax assets and liabilities are provided for temporary differences that will result in tax deductions or income in future periods, as well as the future benefit of tax credit carryforwards. A valuation allowance reduces tax assets to their estimated realizable value.

[0001193125-26-259683:notes:79]
We recognize the tax liability for uncertain income tax positions on the income tax return based on the two-step process prescribed in the interpretation. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. We recognize interest and penalties related to unrecognized tax benefits within the provision for income taxes line on the accompanying consolidated statements of income.

[0001193125-26-259683:notes:80]
Net Income per Share — Basic net income per share is computed by dividing net income by the weighted-average number of common shares outstanding. Diluted net income per share is computed giving effect to the weighted-average number of dilutive potential shares that were outstanding during the period using the treasury stock method. Potential dilutive common shares consist primarily of unvested RSUs and shares to be purchased under our employee stock purchase plan.

[0001193125-26-259683:notes:81]
Treasury Stock — We account for treasury stock under the cost method. Upon the retirement of treasury stock, we allocate the value of treasury shares between common stock, additional paid-in capital and retained earnings.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001193125-26-259683:notes:82]
2. Recent Accounting Pronouncements

[0001193125-26-259683:notes:83]
Recent Accounting Pronouncements Not Yet Adopted

[0001193125-26-259683:notes:84]
In September 2025, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software. The ASU simplifies the capitalization guidance by removing all references to prescriptive and sequential software development stages (referred to as “project stages”) throughout ASC 350-40. The ASU is effective for annual periods beginning after December 15, 2027, with early adoption permitted. Adoption of this ASU can be applied prospectively; or following a modified transition approach that is based on the status of each project and whether software costs were capitalized before adoption; or retrospectively. We are currently evaluating the effect of this pronouncement on our consolidated financial statements and disclosures.

[0001193125-26-259683:notes:85]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires additional disclosure of the nature of expenses included in the income statement. The standard requires disclosures about specific types of expenses included in the expense captions presented in the income statement as well as disclosures about selling expenses. This ASU is effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027, with early adoption permitted. The requirements should be applied on a prospective basis while retrospective application is permitted. We are currently evaluating the effect of this pronouncement on our disclosures.

[0001193125-26-259683:notes:86]
Recently Adopted Accounting Pronouncement

[0001193125-26-259683:notes:87]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which expands the disclosures required for income taxes. This includes the disclosure of specific categories and greater disaggregation within the income tax rate reconciliation as well as disclosure of disaggregated income taxes paid by significant jurisdiction. This ASU is effective for fiscal years beginning after December 15, 2024. We adopted the standard on a prospective basis for fiscal 2026. See Note 12 - Income Taxes for further information.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0001193125-26-259683:notes:88]
3. Concentration of Risk

[0001193125-26-259683:notes:89]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, investments, foreign currency exchange contracts and accounts receivable. We maintain the majority of our cash and cash equivalents with several major financial institutions where the deposits exceed federally insured limits. Cash equivalents and short-term investments consist primarily of money market funds, U.S. Treasury and government debt securities and certificates of deposit, all of which are considered high investment grade. Our policy is to limit the amount of credit exposure through diversification and investment in highly rated securities. We further mitigate concentrations of credit risk in our investments by limiting our investments in the debt securities of a single issuer and by diversifying risk across geographies and type of issuer. General macroeconomic uncertainty has led to an increase in market volatility, however, management believes that the financial institutions that hold our cash, cash equivalents and investments are financially sound and, accordingly, are subject to minimal credit risk.

[0001193125-26-259683:notes:90]
By entering into foreign currency exchange contracts, we have assumed the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and we do not expect any losses as a result of counterparty defaults.

[0001193125-26-259683:notes:91]
We sell our products primarily to large organizations in different industries and geographies. We do not require collateral or other security to support accounts receivable. In addition, we maintain an allowance for potential credit losses. To reduce credit risk, we perform ongoing credit evaluations on our customers’ financial condition. We establish an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information, including the expected impact of macroeconomic disruptions, and, to date, such losses have been within management’s expectations. Concentrations of credit risk with respect to trade accounts receivable are limited due to the wide variety of customers who are dispersed across many geographic regions.

[0001193125-26-259683:notes:92]
There are no concentrations of business transacted with a particular market that would severely impact our business in the near term. However, we rely on a limited number of suppliers for certain key components and a few key contract manufacturers to manufacture most of our products; any disruption, or termination of these arrangements could materially adversely affect our operating results.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-26-259683:notes:93]
4. Goodwill and Purchased Intangible Assets, Net

[0001193125-26-259683:notes:94]
Goodwill activity by reportable segment is summarized as follows (in millions):

[0001193125-26-259683:notes:95]
|  |  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Balance as of April 26, 2024 |  | $ | 1,714 |  |  | $ | 1,045 |  |  | $ | 2,759 |  |
| Derecognition |  |  | — |  |  |  | (36 | ) |  |  | (36 | ) |
| Balance as of April 25, 2025 |  |  | 1,714 |  |  |  | 1,009 |  |  |  | 2,723 |  |
| Impact of foreign currency translation |  |  | — |  |  |  | 49 |  |  |  | 49 |  |
| Balance as of April 24, 2026 |  | $ | 1,714 |  |  | $ | 1,058 |  |  | $ | 2,772 |  |

[0001193125-26-259683:notes:96]
During fiscal 2025, we derecognized a portion of the Public Cloud goodwill in connection with the sale of our cloud optimization and management software business known as Spot by NetApp, which formed part of our Public Cloud reportable segment. See "Gains/losses on the sale or derecognition of assets" section contained in Note 5 – Supplemental Financial Information for additional information related to this derecognition.

[0001193125-26-259683:notes:97]
Purchased intangible assets, net are summarized below (in millions):

[0001193125-26-259683:notes:98]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 55 |  |  | $ | (44 | ) |  | $ | 11 |  |  | $ | 55 |  |  | $ | (33 | ) |  | $ | 22 |  |
| Customer contracts/relationships |  |  | 50 |  |  |  | (39 | ) |  |  | 11 |  |  |  | 50 |  |  |  | (29 | ) |  |  | 21 |  |
| Other purchased intangibles |  |  | 2 |  |  |  | (2 | ) |  |  | — |  |  |  | 2 |  |  |  | (2 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 107 |  |  | $ | (85 | ) |  | $ | 22 |  |  | $ | 107 |  |  | $ | (64 | ) |  | $ | 43 |  |

[0001193125-26-259683:notes:99]
Amortization expense for purchased intangible assets is summarized below (in millions):

[0001193125-26-259683:notes:100]
|  |  | Year Ended |  | Statements of |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  | IncomeClassifications |
| Developed technology |  | $ | 11 |  |  | $ | 28 |  |  | $ | 34 |  | Cost of revenues |
| Customer contracts/relationships |  |  | 10 |  |  |  | 19 |  |  |  | 22 |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | — |  |  |  | 1 |  | Operating expenses |
| Total |  | $ | 21 |  |  | $ | 47 |  |  | $ | 57 |  |  |

[0001193125-26-259683:notes:101]
As of April 24, 2026, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001193125-26-259683:notes:102]
| Fiscal Year |  | Amount |  |
| 2027 |  | $ | 21 |  |
| 2028 |  |  | 1 |  |
| Total |  | $ | 22 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-26-259683:notes:103]
5. Supplemental Financial Information

[0001193125-26-259683:notes:104]
Cash and cash equivalents (in millions):

[0001193125-26-259683:notes:105]
The following table presents cash and cash equivalents as reported in our consolidated balance sheets, as well as the sum of cash, cash equivalents and restricted cash as reported on our consolidated statements of cash flows:

[0001193125-26-259683:notes:106]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Cash and cash equivalents |  | $ | 2,070 |  |  | $ | 2,742 |  |
| Restricted cash |  |  | 5 |  |  |  | 7 |  |
| Cash, cash equivalents and restricted cash |  | $ | 2,075 |  |  | $ | 2,749 |  |

[0001193125-26-259683:notes:107]
Inventories (in millions):

[0001193125-26-259683:notes:108]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Purchased components |  | $ | 14 |  |  | $ | 81 |  |
| Finished goods |  |  | 184 |  |  |  | 105 |  |
| Inventories |  | $ | 198 |  |  | $ | 186 |  |

[0001193125-26-259683:notes:109]
Property and equipment, net (in millions):

[0001193125-26-259683:notes:110]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 377 |  |  |  | 374 |  |
| Leasehold improvements |  |  | 114 |  |  |  | 103 |  |
| Computer, production, engineering and other equipment |  |  | 1,264 |  |  |  | 1,172 |  |
| Computer software |  |  | 66 |  |  |  | 329 |  |
| Furniture and fixtures |  |  | 61 |  |  |  | 62 |  |
| Construction-in-progress |  |  | 58 |  |  |  | 49 |  |
|  |  |  | 1,986 |  |  |  | 2,135 |  |
| Accumulated depreciation and amortization |  |  | (1,394 | ) |  |  | (1,572 | ) |
| Property and equipment, net |  | $ | 592 |  |  | $ | 563 |  |

[0001193125-26-259683:notes:111]
Depreciation and amortization expense related to property and equipment, net is summarized below (in millions):

[0001193125-26-259683:notes:112]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Depreciation and amortization expense |  | $ | 179 |  |  | $ | 196 |  |  | $ | 198 |  |

[0001193125-26-259683:notes:113]
Other non-current assets (in millions):

[0001193125-26-259683:notes:114]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Deferred tax assets |  | $ | 859 |  |  | $ | 994 |  |
| Operating lease right-of-use (ROU) assets |  |  | 228 |  |  |  | 241 |  |
| Other assets |  |  | 495 |  |  |  | 408 |  |
| Other non-current assets |  | $ | 1,582 |  |  | $ | 1,643 |  |

[0001193125-26-259683:notes:115]
Other non-current assets as of April 24, 2026 and April 25, 2025 include $98 million and $92 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of

[0001193125-26-259683:notes:116]
our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies.

[0001193125-26-259683:notes:117]
Accrued expenses (in millions):

[0001193125-26-259683:notes:118]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Accrued compensation and benefits |  | $ | 543 |  |  | $ | 513 |  |
| Income tax payable |  |  | 29 |  |  |  | 146 |  |
| Operating lease liabilities |  |  | 42 |  |  |  | 40 |  |
| Other current liabilities |  |  | 537 |  |  |  | 423 |  |
| Accrued expenses |  | $ | 1,151 |  |  | $ | 1,122 |  |

[0001193125-26-259683:notes:119]
Other long-term liabilities (in millions):

[0001193125-26-259683:notes:120]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Liability for uncertain tax positions |  | $ | 38 |  |  | $ | 45 |  |
| Operating lease liabilities |  |  | 204 |  |  |  | 216 |  |
| Other liabilities |  |  | 118 |  |  |  | 118 |  |
| Other long-term liabilities |  | $ | 360 |  |  | $ | 379 |  |

[0001193125-26-259683:notes:121]
Deferred revenue

[0001193125-26-259683:notes:122]
Deferred revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria, as well as customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services.

[0001193125-26-259683:notes:123]
During the years ended April 24, 2026 and April 25, 2025, we recognized revenue of $2,279 million and $2,176 million, respectively, that was included in the deferred revenue balance at the beginning of the respective periods.

[0001193125-26-259683:notes:124]
Remaining performance obligations

[0001193125-26-259683:notes:125]
As of April 24, 2026, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $5.7 billion. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue 45% of our remaining performance obligations in the next 12 months and the remainder thereafter.

[0001193125-26-259683:notes:126]
Deferred commissions

[0001193125-26-259683:notes:127]
The following table summarizes deferred commissions balances as reported in our consolidated balance sheets (in millions):

[0001193125-26-259683:notes:128]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Other current assets |  | $ | 117 |  |  | $ | 64 |  |
| Other non-current assets |  |  | 152 |  |  |  | 104 |  |
| Total deferred commissions |  | $ | 269 |  |  | $ | 168 |  |

[0001193125-26-259683:notes:129]
During the years ended April 24, 2026 and April 25, 2025, we recognized amortization expense from deferred commissions of $106 million and $123 million, respectively, and there were no impairment charges recognized.

[0001193125-26-259683:notes:130]
Other (expense) income, net (in millions):

[0001193125-26-259683:notes:131]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Interest income |  | $ | 113 |  |  | $ | 112 |  |  | $ | 112 |  |
| Interest expense |  |  | (109 | ) |  |  | (64 | ) |  |  | (64 | ) |
| Other, net |  |  | (30 | ) |  |  | (2 | ) |  |  | 1 |  |
| Total other (expense) income, net |  | $ | (26 | ) |  | $ | 46 |  |  | $ | 49 |  |

[0001193125-26-259683:notes:132]
Statements of cash flows additional information (in millions):

[0001193125-26-259683:notes:133]
Supplemental cash flow information related to our operating leases is included in Note 8 – Leases. Non-cash investing activities and other supplemental cash flow information are presented below:

[0001193125-26-259683:notes:134]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 20 |  |  | $ | 14 |  |  | $ | 16 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 435 |  |  | $ | 412 |  |  | $ | 357 |  |
| Interest paid |  | $ | 109 |  |  | $ | 53 |  |  | $ | 59 |  |

[0001193125-26-259683:notes:135]
Gains/losses on the sale or derecognition of assets

[0001193125-26-259683:notes:136]
During fiscal 2025, we completed the sale of our cloud optimization and management software business known as Spot by NetApp to Flexera Software LLC. Total sale consideration consisted of (i) $70 million in up-front cash consideration and (ii) up to $49 million in cash consideration contingent upon the achievement of certain financial performance metrics during the period from January 1, 2025 through December 31, 2025. We received the up-front cash consideration, recognized $20 million for contingent consideration in other current assets, derecognized the assets and liabilities conveyed to Flexera, and recorded certain transaction costs. No material gain or loss was recorded to our consolidated statements of income.

[0001193125-26-259683:notes:137]
The major classes of assets and liabilities derecognized were (in millions):

[0001193125-26-259683:notes:138]
|  |  | Amount |  |
| Assets: |  |  |  |
| Property and equipment, net |  | $ | 13 |  |
| Goodwill |  |  | 36 |  |
| Purchased intangible assets, net |  |  | 34 |  |
| Total Assets |  |  | 83 |  |
| Liabilities: |  |  |  |
| Short-term deferred revenue |  |  | 1 |  |

[0001193125-26-259683:notes:139]
During fiscal 2026, based on achievement of certain financial performance metrics, we recognized an additional $11 million of contingent consideration in other current assets and a corresponding gain to our consolidated statements of income. We expect to receive the cash from the contingent consideration during fiscal 2027.

[0001193125-26-259683:notes:140]
Financing Transactions

[0001193125-26-259683:notes:141]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third-party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $28 million, $65 million and $67 million of receivables during fiscal 2026, 2025 and 2024, respectively.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-26-259683:notes:142]
6. Financial Instruments and Fair Value Measurements

[0001193125-26-259683:notes:143]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis, whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the three levels of inputs to measure fair value:

[0001193125-26-259683:notes:144]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001193125-26-259683:notes:145]
Level 2: Inputs that reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; benchmark yields, reported trades, broker/dealer quotes, inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0001193125-26-259683:notes:146]
Level 3: Unobservable inputs that reflect our own assumptions incorporated in valuation techniques used to measure fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0001193125-26-259683:notes:147]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and consider an inactive market to be one in which there are infrequent or few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty’s non-performance risk is considered in measuring the fair values of liabilities and assets, respectively.

[0001193125-26-259683:notes:148]
Investments

[0001193125-26-259683:notes:149]
The following is a summary of our investments at their cost or amortized cost as of April 24, 2026 and April 25, 2025 (in millions):

[0001193125-26-259683:notes:150]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| U.S. Treasury and government debt securities |  | $ | 2,112 |  |  | $ | 2,025 |  |
| Money market funds |  |  | 808 |  |  |  | 1,126 |  |
| Certificates of deposit |  |  | 86 |  |  |  | 24 |  |
| Mutual funds |  |  | 49 |  |  |  | 41 |  |
| Total debt and equity securities |  | $ | 3,055 |  |  | $ | 3,216 |  |

[0001193125-26-259683:notes:151]
The fair value of our investments approximates their cost or amortized cost for both periods presented. Investments in mutual funds relate to the non-qualified deferred compensation plan offered to certain employees.

[0001193125-26-259683:notes:152]
As of April 24, 2026, all our debt investments are due to mature in one year or less.

[0001193125-26-259683:notes:153]
Fair Value of Financial Instruments

[0001193125-26-259683:notes:154]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis (in millions):

[0001193125-26-259683:notes:155]
|  |  | April 24, 2026 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 578 |  |  | $ | 578 |  |  | $ | — |  |
| Money market funds |  |  | 808 |  |  |  | 808 |  |  |  | — |  |
| Certificates of deposit |  |  | 86 |  |  |  | — |  |  |  | 86 |  |
| U.S. Treasury and government debt securities |  |  | 598 |  |  |  | 598 |  |  |  | — |  |
| Total cash and cash equivalents |  |  | 2,070 |  |  |  | 1,984 |  |  |  | 86 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 1,514 |  |  |  | 1,514 |  |  |  | — |  |
| Total short-term investments |  |  | 1,514 |  |  |  | 1,514 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,584 |  |  | $ | 3,498 |  |  | $ | 86 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 9 |  |  | $ | 9 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 40 |  |  | $ | 40 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0001193125-26-259683:notes:156]
|  |  | April 25, 2025 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 671 |  |  | $ | 671 |  |  | $ | — |  |
| Money market funds |  |  | 1,126 |  |  |  | 1,126 |  |  |  | — |  |
| Certificates of deposit |  |  | 24 |  |  |  | — |  |  |  | 24 |  |
| U.S. Treasury and government debt securities |  |  | 921 |  |  |  | 921 |  |  |  | — |  |
| Total cash and cash equivalents |  |  | 2,742 |  |  |  | 2,718 |  |  |  | 24 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 1,104 |  |  |  | 1,104 |  |  |  | — |  |
| Total short-term investments |  |  | 1,104 |  |  |  | 1,104 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,846 |  |  | $ | 3,822 |  |  | $ | 24 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 34 |  |  | $ | 34 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (2 | ) |  | $ | — |  |  | $ | (2 | ) |

[0001193125-26-259683:notes:157]
(1)
Reported as other current assets in the consolidated balance sheets

[0001193125-26-259683:notes:158]
(2)
Reported as other non-current assets in the consolidated balance sheets

[0001193125-26-259683:notes:159]
(3)
Reported as accrued expenses in the consolidated balance sheets

[0001193125-26-259683:notes:160]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of April 24, 2026 and April 25, 2025, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001193125-26-259683:notes:161]
Fair Value of Debt

[0001193125-26-259683:notes:162]
As of April 24, 2026 and April 25, 2025, the fair value of our long-term debt, including the current portion, was $2,468 million and $3,143 million, respectively. These fair values of our long-term debt were based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0001193125-26-259683:notes:163]
7. Financing Arrangements

[0001193125-26-259683:notes:164]
Long-Term Debt

[0001193125-26-259683:notes:165]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0001193125-26-259683:notes:166]
|  |  | Effective Interest Rate |  | April 24, 2026 |  |  | April 25, 2025 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  | $ | — |  |  | $ | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| 5.50% Senior Notes Due March 2032 |  | 5.71% |  |  | 625 |  |  |  | 625 |  |
| 5.70% Senior Notes Due March 2035 |  | 5.90% |  |  | 625 |  |  |  | 625 |  |
| Total principal amount |  |  |  |  | 2,500 |  |  |  | 3,250 |  |
| Unamortized discount and issuance costs |  |  |  |  | (13 | ) |  |  | (15 | ) |
| Total senior notes |  |  |  |  | 2,487 |  |  |  | 3,235 |  |
| Less: Current portion of long-term debt |  |  |  |  | — |  |  |  | (750 | ) |
| Total long-term debt |  |  |  | $ | 2,487 |  |  | $ | 2,485 |  |

[0001193125-26-259683:notes:167]
Senior Notes

[0001193125-26-259683:notes:168]
On June 23, 2025, upon maturity, we repaid the 1.875% Senior Notes due June 2025 for an aggregate amount of $757 million, comprised of the principal and unpaid interest.

[0001193125-26-259683:notes:169]
In March 2025, we issued $625 million aggregate principal amount of 5.50% Senior Notes due 2032 and $625 million aggregate principal amount of 5.70% Senior Notes due 2035, for which we received total proceeds of $1.24 billion, net of discount and issuance costs.

[0001193125-26-259683:notes:170]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness. Interest on our Senior Notes is payable semi-annually.

[0001193125-26-259683:notes:171]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of April 24, 2026, we were in compliance with all covenants associated with the Senior Notes.

[0001193125-26-259683:notes:172]
As of April 24, 2026, our aggregate future principal debt maturities are as follows (in millions):

[0001193125-26-259683:notes:173]
| Fiscal Year |  | Amount |  |
| 2027 |  | $ | — |  |
| 2028 |  |  | 550 |  |
| 2029 |  |  | — |  |
| 2030 |  |  | — |  |
| 2031 |  |  | 700 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,500 |  |

[0001193125-26-259683:notes:174]
Credit Facility and Commercial Paper Program

[0001193125-26-259683:notes:175]
We have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in March 2025, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on March 5, 2030, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of April 24, 2026, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0001193125-26-259683:notes:176]
We also have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of April 24, 2026 or April 25, 2025.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0001193125-26-259683:notes:177]
8. Leases

[0001193125-26-259683:notes:178]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of April 24, 2026, have remaining lease terms not exceeding 16 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of April 24, 2026, have remaining lease terms not exceeding 3 years. As of April 24, 2026, our automobile leases have remaining lease terms not exceeding 4 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0001193125-26-259683:notes:179]
The components of lease cost related to our operating leases were as follows (in millions):

[0001193125-26-259683:notes:180]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Operating lease cost |  | $ | 52 |  |  | $ | 51 |  |
| Variable lease cost |  |  | 15 |  |  |  | 15 |  |
| Total lease cost |  | $ | 67 |  |  | $ | 66 |  |

[0001193125-26-259683:notes:181]
Variable lease cost is primarily attributable to amounts paid to lessors for common area maintenance and utility charges under our real estate leases.

[0001193125-26-259683:notes:182]
The supplemental cash flow information related to our operating leases is as follows (in millions):

[0001193125-26-259683:notes:183]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 49 |  |  | $ | 48 |  |
| ROU assets obtained in exchange for new operating lease obligations |  | $ | 29 |  |  | $ | 25 |  |

[0001193125-26-259683:notes:184]
The supplemental balance sheet information related to our operating leases is as follows (in millions, except lease term and discount rate):

[0001193125-26-259683:notes:185]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Other non-current assets |  | $ | 228 |  |  | $ | 241 |  |
| Total operating lease ROU assets |  | $ | 228 |  |  | $ | 241 |  |
| Accrued expenses |  | $ | 42 |  |  | $ | 40 |  |
| Other long-term liabilities |  |  | 204 |  |  |  | 216 |  |
| Total operating lease liabilities |  | $ | 246 |  |  | $ | 256 |  |
| Weighted Average Remaining Lease Term |  | 7.7 years |  |  | 8.5 years |  |
| Weighted Average Discount Rate |  |  | 3.5 | % |  |  | 3.4 | % |

[0001193125-26-259683:notes:186]
Future minimum operating lease payments as of April 24, 2026 are as follows (in millions):

[0001193125-26-259683:notes:187]
| Fiscal Year |  |  |  | Amount |  |
| 2027 |  |  |  | $ | 47 |  |
| 2028 |  |  |  |  | 43 |  |
| 2029 |  |  |  |  | 38 |  |
| 2030 |  |  |  |  | 32 |  |
| 2031 |  |  |  |  | 30 |  |
| Thereafter |  |  |  |  | 93 |  |
| Total lease payments |  |  |  |  | 283 |  |
| Less: Interest |  |  |  |  | (37 | ) |
| Total |  |  |  | $ | 246 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001193125-26-259683:notes:188]
9. Stockholders’ Equity

[0001193125-26-259683:notes:189]
Equity Incentive Programs

[0001193125-26-259683:notes:190]
The 2021 Plan — The 2021 Equity Incentive Plan (the 2021 Plan) was adopted by our Board of Directors and approved by the stockholders on September 10, 2021. The 2021 Plan provides for the granting of restricted stock, restricted stock units, performance awards, incentive stock options, nonstatutory stock options, and stock appreciation rights to our employees, directors, consultants and independent advisors.

[0001193125-26-259683:notes:191]
Under the 2021 Plan, the Board of Directors may grant RSUs which include time-based RSUs that generally vest over a four-year period with 25% vesting on the first anniversary of the grant date and 6.25% vesting quarterly thereafter. In addition, performance-based RSUs are granted under the 2021 Plan and are subject to performance criteria and vesting terms specified by the Compensation Committee.

[0001193125-26-259683:notes:192]
During fiscal 2026, the shares reserved for issuance under the Plan were increased by 5 million shares of common stock. As of April 24, 2026, 14 million shares were available for grant under the 2021 Plan.

[0001193125-26-259683:notes:193]
Restricted Stock Units

[0001193125-26-259683:notes:194]
In fiscal 2026, 2025 and 2024, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSUs cliff-vest at the end of a three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the third fiscal year, following the grant date. The number of shares that will be used to calculate the settlement amount for all of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in fiscal 2026, 2025 and 2024, the number of shares used to calculate the settlement amount will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. For the remaining half of the PBRSUs granted, the number of shares used to calculate the settlement amount will depend upon the Company's billings result average over the three-year performance period. The billings result average is computed based on achievement against annual billings targets, with each target set at the beginning of the respective fiscal year, during the three-year performance period. Billings, for purposes of measuring the performance of these PBRSUs, means the total obtained by adding net revenues as reported on the Company's consolidated statements of income to the amount reported as the change in deferred revenue on the consolidated statements of cash flows for the applicable measurement period, excluding the impact of fluctuations in foreign currency exchange rates. The aggregate grant date fair value of all PBRSUs granted in fiscal 2026, 2025 and 2024 was $64 million, $67 million and $39 million, respectively, and these amounts are being recognized to compensation expense over the remaining performance/service periods.

[0001193125-26-259683:notes:195]
As of April 24, 2026, April 25, 2025 and April 26, 2024, there were approximately 1 million PBRSUs outstanding.

[0001193125-26-259683:notes:196]
The following table summarizes information related to RSUs, including PBRSUs (in millions, except for fair value):

[0001193125-26-259683:notes:197]
|  |  | Number ofShares |  |  | Weighted-AverageGrant Date Fair Value |  |
| Outstanding as of April 28, 2023 |  |  | 12 |  |  | $ | 62.08 |  |
| Granted |  |  | 5 |  |  | $ | 76.46 |  |
| Vested |  |  | (5 | ) |  | $ | 59.32 |  |
| Forfeited |  |  | (1 | ) |  | $ | 65.17 |  |
| Outstanding as of April 26, 2024 |  |  | 11 |  |  | $ | 68.87 |  |
| Granted |  |  | 4 |  |  | $ | 123.45 |  |
| Vested |  |  | (5 | ) |  | $ | 72.07 |  |
| Forfeited |  |  | (2 | ) |  | $ | 78.21 |  |
| Outstanding as of April 25, 2025 |  |  | 8 |  |  | $ | 91.30 |  |
| Granted |  |  | 5 |  |  | $ | 104.74 |  |
| Vested |  |  | (4 | ) |  | $ | 86.44 |  |
| Forfeited |  |  | (1 | ) |  | $ | 89.27 |  |
| Outstanding as of April 24, 2026 |  |  | 8 |  |  | $ | 101.15 |  |

[0001193125-26-259683:notes:198]
We primarily use the net share settlement approach upon vesting, where a portion of the shares are withheld as settlement of employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001193125-26-259683:notes:199]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 2 |  |  |  | 2 |  |
| Fair value of shares withheld |  | $ | 137 |  |  | $ | 199 |  |  | $ | 128 |  |

[0001193125-26-259683:notes:200]
Employee Stock Purchase Plan

[0001193125-26-259683:notes:201]
Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. During fiscal 2026, the ESPP was amended to increase the shares reserved for issuance by 4 million shares of common stock. As of April 24, 2026, 5 million shares were available for issuance. The following table summarizes activity related to the purchase rights issued under the ESPP (in millions):

[0001193125-26-259683:notes:202]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Shares issued under the ESPP |  |  | 1 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 103 |  |  | $ | 108 |  |

[0001193125-26-259683:notes:203]
Stock-Based Compensation Expense

[0001193125-26-259683:notes:204]
Stock-based compensation expense is included in the consolidated statements of income as follows (in millions):

[0001193125-26-259683:notes:205]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Cost of product revenues |  | $ | 6 |  |  | $ | 6 |  |  | $ | 6 |  |
| Cost of services revenues |  |  | 22 |  |  |  | 24 |  |  |  | 23 |  |
| Sales and marketing |  |  | 155 |  |  |  | 162 |  |  |  | 143 |  |
| Research and development |  |  | 126 |  |  |  | 135 |  |  |  | 132 |  |
| General and administrative |  |  | 73 |  |  |  | 59 |  |  |  | 53 |  |
| Total stock-based compensation expense |  | $ | 382 |  |  | $ | 386 |  |  | $ | 357 |  |

[0001193125-26-259683:notes:206]
As of April 24, 2026, total unrecognized compensation expense related to our equity awards was $639 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.2 years.

[0001193125-26-259683:notes:207]
Valuation Assumptions

[0001193125-26-259683:notes:208]
The valuation of RSUs and ESPP purchase rights and the underlying weighted-average assumptions are summarized as follows:

[0001193125-26-259683:notes:209]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| RSUs: |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 3.8 | % |  |  | 4.6 | % |  |  | 4.9 | % |
| Expected dividend yield |  |  | 2.0 | % |  |  | 1.8 | % |  |  | 2.6 | % |
| Weighted-average fair value per share granted |  | $ | 104.74 |  |  | $ | 123.45 |  |  | $ | 76.46 |  |
| ESPP: |  |  |  |  |  |  |  |  |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 4.1 | % |  |  | 5.2 | % |  |  | 4.9 | % |
| Expected volatility |  |  | 36 | % |  |  | 31 | % |  |  | 30 | % |
| Expected dividend yield |  |  | 2.1 | % |  |  | 1.7 | % |  |  | 2.8 | % |
| Weighted-average fair value per right granted |  | $ | 26.42 |  |  | $ | 29.70 |  |  | $ | 17.37 |  |

[0001193125-26-259683:notes:210]
Stock Repurchase Program

[0001193125-26-259683:notes:211]
Under our common stock repurchase program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management.

[0001193125-26-259683:notes:212]
The following table summarizes activity related to the stock repurchase program (in millions, except for per share amounts):

[0001193125-26-259683:notes:213]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Number of shares repurchased |  |  | 9.0 |  |  |  | 10.2 |  |  |  | 11.5 |  |
| Average price per share |  | $ | 105.89 |  |  | $ | 112.55 |  |  | $ | 77.87 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 98 |  |  | $ | 50 |  |  | $ | 102 |  |
| Stock repurchases allocated to retained earnings |  | $ | 852 |  |  | $ | 1,100 |  |  | $ | 798 |  |
| Remaining authorization at end of period |  | $ | 502 |  |  | $ | 352 |  |  | $ | 502 |  |

[0001193125-26-259683:notes:214]
On May 21, 2026, our Board of Directors authorized the repurchase of an additional $1.0 billion of our common stock.

[0001193125-26-259683:notes:215]
Preferred Stock

[0001193125-26-259683:notes:216]
Our Board of Directors has the authority to issue up to 5 million shares of preferred stock and to determine the price, rights, preferences, privileges, and restrictions, including voting rights, of those shares without any further vote or action by the stockholders. No shares of preferred stock were issued or outstanding in any period presented.

[0001193125-26-259683:notes:217]
Dividends

[0001193125-26-259683:notes:218]
The following is a summary of our activities related to dividends on our common stock (in millions, except per share amounts).

[0001193125-26-259683:notes:219]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Dividends per share declared |  | $ | 2.08 |  |  | $ | 2.08 |  |  | $ | 2.00 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 142 |  |  | $ | 130 |  |  | $ | 171 |  |
| Dividend payments allocated to retained earnings |  | $ | 271 |  |  | $ | 294 |  |  | $ | 245 |  |

[0001193125-26-259683:notes:220]
On May 21, 2026, we declared a cash dividend of $0.52 per share of common stock, payable on July 29, 2026 to shareholders of record as of the close of business on July 10, 2026. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by the Company to be legally authorized under the laws of the state in which we are incorporated.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-26-259683:notes:221]
10. Derivatives and Hedging Activities

[0001193125-26-259683:notes:222]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of April 24, 2026 or April 25, 2025. All contracts have a maturity of less than 12 months.

[0001193125-26-259683:notes:223]
The notional amount of our outstanding U.S. dollar equivalent foreign currency exchange forward contracts consisted of the following (in millions):

[0001193125-26-259683:notes:224]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 75 |  |  | $ | 81 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 995 |  |  | $ | 790 |  |
| Forward contracts purchased |  | $ | 13 |  |  | $ | — |  |

[0001193125-26-259683:notes:225]
The effect of cash flow hedges recognized in net revenues is presented in the consolidated statements of comprehensive income.

[0001193125-26-259683:notes:226]
The effect of derivative instruments not designated as hedging instruments recognized in other (expense) income, net on our consolidated statements of income was as follows (in millions):

[0001193125-26-259683:notes:227]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
|  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | (15 | ) |  | $ | 38 |  |  | $ | (59 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-26-259683:notes:228]
11. Restructuring Charges

[0001193125-26-259683:notes:229]
In fiscal 2026, management approved a restructuring plan to redirect resources to the highest return activities and reduce costs. Charges related to the plan consisted primarily of employee severance-related costs. The activities under this plan were substantially complete by the end of fiscal 2026.

[0001193125-26-259683:notes:230]
In fiscal 2025, management approved restructuring plans to redirect resources to the highest return activities and reduce costs. Charges related to the plans consisted primarily of employee severance-related costs and lease termination charges. One of the plans related to the sale of our cloud optimization and management software business known as Spot by NetApp. The activities under these plans were substantially complete by the end of fiscal 2025.

[0001193125-26-259683:notes:231]
In fiscal 2024, management approved restructuring plans to redirect resources to the highest return activities and reduce costs. Charges related to the plans consisted primarily of employee severance-related costs. One of the plans also included termination of certain real estate leases in various countries, resulting in lease termination charges. The activities under these plans were substantially complete by the end of fiscal 2024.

[0001193125-26-259683:notes:232]
Activities related to our restructuring plans are summarized as follows (in millions):

[0001193125-26-259683:notes:233]
|  |  | Total |  |
| Balance as of April 28, 2023 |  | $ | 36 |  |
| Net charges |  |  | 44 |  |
| Cash payments |  |  | (70 | ) |
| Balance as of April 26, 2024 |  |  | 10 |  |
| Net charges |  |  | 83 |  |
| Cash payments |  |  | (42 | ) |
| Balance as of April 25, 2025 |  |  | 51 |  |
| Net charges |  |  | 21 |  |
| Cash payments |  |  | (66 | ) |
| Balance as of April 24, 2026 |  | $ | 6 |  |

[0001193125-26-259683:notes:234]
Liabilities for our restructuring activities are included in accrued expenses in our consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-26-259683:notes:235]
12. Income Taxes

[0001193125-26-259683:notes:236]
Income before income taxes is as follows (in millions):

[0001193125-26-259683:notes:237]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Domestic |  | $ | 718 |  |  | $ | 606 |  |  | $ | 472 |  |
| Foreign |  |  | 930 |  |  |  | 777 |  |  |  | 791 |  |
| Total |  | $ | 1,648 |  |  | $ | 1,383 |  |  | $ | 1,263 |  |

[0001193125-26-259683:notes:238]
The provision for income taxes consists of the following (in millions):

[0001193125-26-259683:notes:239]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Current: |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 83 |  |  | $ | 131 |  |  | $ | 89 |  |
| State |  |  | 24 |  |  |  | 38 |  |  |  | 25 |  |
| Foreign |  |  | 130 |  |  |  | 128 |  |  |  | 110 |  |
| Total current |  |  | 237 |  |  |  | 297 |  |  |  | 224 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 82 |  |  |  | (102 | ) |  |  | 24 |  |
| State |  |  | 12 |  |  |  | (16 | ) |  |  | 6 |  |
| Foreign |  |  | 41 |  |  |  | 18 |  |  |  | 23 |  |
| Total deferred |  |  | 135 |  |  |  | (100 | ) |  |  | 53 |  |
| Provision for income taxes |  | $ | 372 |  |  | $ | 197 |  |  | $ | 277 |  |

[0001193125-26-259683:notes:240]
During the fourth quarter of fiscal 2025, the Internal Revenue Service (“IRS”) substantially completed the examination of our fiscal 2018 and fiscal 2019 U.S. income tax returns, and we recognized a tax benefit of $36 million attributable to the release of related tax reserves.

[0001193125-26-259683:notes:241]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate, in accordance with the guidance in ASU 2023-09, as follows (in millions, except percentages):

[0001193125-26-259683:notes:242]
|  |  | Year Ended April 24, 2026 |  |
|  |  | Tax Effect |  |  | Rate Impact |  |
| Tax computed at federal statutory rate |  | $ | 346 |  |  |  | 21.0 | % |
| State and local income taxes, net of federal benefit (1) |  |  | 30 |  |  |  | 1.8 | % |
| Foreign tax effects: |  |  |  |  |  |  |
| Ireland |  |  |  |  |  |  |
| Statutory tax rate difference between Ireland and U.S. |  |  | (44 | ) |  |  | (2.7 | )% |
| Ireland earnings taxed at rates other than statutory |  |  | 14 |  |  |  | 0.8 | % |
| Other |  |  | 3 |  |  |  | 0.2 | % |
| Cyprus |  |  |  |  |  |  |
| Statutory tax rate difference between Cyprus and U.S. |  |  | (15 | ) |  |  | (0.9 | )% |
| Deduction for qualifying capital |  |  | (21 | ) |  |  | (1.3 | )% |
| Other |  |  | 1 |  |  |  | 0.1 | % |
| Other foreign jurisdictions |  |  | 36 |  |  |  | 2.2 | % |
| Federal: |  |  |  |  |  |  |
| Effect of cross-border tax laws |  |  |  |  |  |  |
| Foreign earnings inclusion, net of credits |  |  | 34 |  |  |  | 2.1 | % |
| Subpart F income, net of credits |  |  | 9 |  |  |  | 0.5 | % |
| Tax credits |  |  |  |  |  |  |
| Research and development credits |  |  | (24 | ) |  |  | (1.4 | )% |
| Nontaxable or nondeductible items |  |  | 2 |  |  |  | 0.1 | % |
| Changes in unrecognized tax benefits |  |  | 3 |  |  |  | 0.2 | % |
| Other |  |  | (2 | ) |  |  | (0.1 | )% |
| Provision for income taxes |  | $ | 372 |  |  |  | 22.6 | % |

[0001193125-26-259683:notes:243]
Percentages may not add due to rounding

[0001193125-26-259683:notes:244]
(1)
State taxes in Illinois, New Jersey, New York, Oregon, and Virginia make up the majority (greater than 50%) of this category.

[0001193125-26-259683:notes:245]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate, in accordance with the guidance prior to adoption of ASU 2023-09, as follows (in millions):

[0001193125-26-259683:notes:246]
|  |  | Year Ended |  |
|  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Tax computed at federal statutory rate |  | $ | 290 |  |  | $ | 265 |  |
| State income taxes, net of federal benefit |  |  | 14 |  |  |  | 22 |  |
| Foreign earnings in lower tax jurisdictions |  |  | (14 | ) |  |  | (40 | ) |
| Stock-based compensation |  |  | (21 | ) |  |  | 12 |  |
| Research and development credits |  |  | (31 | ) |  |  | (22 | ) |
| Benefit for foreign derived intangible income |  |  | (28 | ) |  |  | — |  |
| Global minimum tax on intangible income |  |  | 12 |  |  |  | 46 |  |
| Tax charges (benefits) from integration of acquired companies |  |  | 1 |  |  |  | 4 |  |
| Resolution of income tax matters (1) |  |  | (39 | ) |  |  | (4 | ) |
| Other |  |  | 13 |  |  |  | (6 | ) |
| Provision for income taxes |  | $ | 197 |  |  | $ | 277 |  |

[0001193125-26-259683:notes:247]
(1)
During fiscal 2025, we recognized a tax benefit related to the IRS examination of our fiscal 2018 and fiscal 2019 U.S. income tax returns. During fiscal 2024, we recognized a tax benefit related to the lapse of statute of limitations for certain issues in our fiscal 2020 U.S. tax returns.

[0001193125-26-259683:notes:248]
The components of our deferred tax assets and liabilities are as follows (in millions):

[0001193125-26-259683:notes:249]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Deferred tax assets: |  |  |  |  |  |  |
| Reserves and accruals |  | $ | 114 |  |  | $ | 188 |  |
| Net operating loss and credit carryforwards |  |  | 145 |  |  |  | 138 |  |
| Stock-based compensation |  |  | 25 |  |  |  | 25 |  |
| Deferred revenue |  |  | 267 |  |  |  | 250 |  |
| Acquired intangibles |  |  | 441 |  |  |  | 483 |  |
| Capitalized research and development (1) |  |  | 182 |  |  |  | 198 |  |
| Other |  |  | 6 |  |  |  | 6 |  |
| Gross deferred tax assets |  |  | 1,180 |  |  |  | 1,288 |  |
| Valuation allowance |  |  | (123 | ) |  |  | (119 | ) |
| Deferred tax assets, net of valuation allowance |  |  | 1,057 |  |  |  | 1,169 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Prepaids and accruals |  |  | 104 |  |  |  | 87 |  |
| Acquired intangibles |  |  | 89 |  |  |  | 84 |  |
| Property and equipment |  |  | 33 |  |  |  | 26 |  |
| Other |  |  | 2 |  |  |  | 6 |  |
| Total deferred tax liabilities |  |  | 228 |  |  |  | 203 |  |
| Deferred tax assets, net of valuation allowance and deferred tax liabilities |  | $ | 829 |  |  | $ | 966 |  |

[0001193125-26-259683:notes:250]
(1)
As required under the Tax Cuts and Jobs Act of 2017, research and development expenditures were capitalized and amortized beginning in our fiscal 2023. Effective for fiscal 2026, we are expensing research and development expenditures as permitted by the One Big Beautiful Bill Act (OBBB).

[0001193125-26-259683:notes:251]
The valuation allowance increased by $4 million in fiscal 2026. The increase is mainly attributable to corresponding changes in deferred tax assets, primarily certain foreign tax credit carryforwards.

[0001193125-26-259683:notes:252]
As of April 24, 2026, we have federal net operating loss carryforwards of $6 million. In addition, we have gross state net operating loss and tax credit carryforwards of $1 million and $143 million, respectively. The majority of the state credit carryforwards are California research credits which are offset by a valuation allowance as we believe it is more likely than not that these credits will not be utilized. We also have $16 million of U.S. foreign tax credit carryforwards and $37 million of foreign tax credit carryforwards of which the majority were generated by our Dutch subsidiary and are fully offset by a valuation allowance. Certain acquired net operating loss carryforwards are subject to an annual limitation under Internal Revenue Code Section 382, but are expected to be realized with the exception of those which have a valuation allowance. The state and foreign net operating loss carryforwards and credits will expire in various years from fiscal 2027 through 2042. The federal net operating loss carryforwards, the California research credit, and the Dutch foreign tax credit carryforwards do not expire.

[0001193125-26-259683:notes:253]
The following table summarizes income taxes paid (net of refunds) exceeding 5 percent of total income taxes paid (net of refunds) in the following jurisdictions (in millions):

[0001193125-26-259683:notes:254]
|  |  | Year Ended April 24, 2026 |  |
| U.S. Federal |  | $ | 261 |  |
| U.S. States and Local |  |  | 29 |  |
| Foreign |  |  |  |
| Ireland |  |  | 51 |  |
| Cyprus |  |  | 24 |  |
| Other |  |  | 70 |  |
| Total foreign |  |  | 145 |  |
| Total income taxes paid (net of refunds) |  | $ | 435 |  |

[0001193125-26-259683:notes:255]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0001193125-26-259683:notes:256]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Balance at beginning of period |  | $ | 68 |  |  | $ | 220 |  |  | $ | 222 |  |
| Additions based on tax positions related to the current year |  |  | 7 |  |  |  | 8 |  |  |  | 7 |  |
| Additions for tax positions of prior years |  |  | 3 |  |  |  | 4 |  |  |  | — |  |
| Decreases for tax positions of prior years |  |  | (2 | ) |  |  | (25 | ) |  |  | (2 | ) |
| Settlements |  |  | (8 | ) |  |  | (139 | ) |  |  | (7 | ) |
| Balance at end of period |  | $ | 68 |  |  | $ | 68 |  |  | $ | 220 |  |

[0001193125-26-259683:notes:257]
As of April 24, 2026, we had $68 million of gross unrecognized tax benefits, of which $38 million has been recorded in other long-term liabilities and $8 million has been recorded in other current liabilities. Unrecognized tax benefits of $47 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001193125-26-259683:notes:258]
We recognized expense for increases to accrued interest and penalties related to unrecognized tax benefits in the income tax provision of $2 million, $4 million and $11 million, respectively, in fiscal 2026, fiscal 2025 and fiscal 2024. Accrued interest and penalties of $10 million and $8 million were recorded in the consolidated balance sheets as of April 24, 2026 and April 25, 2025, respectively.

[0001193125-26-259683:notes:259]
On July 4, 2025, the reconciliation bill H.R. 1, referred to as the One Big Beautiful Bill Act (OBBB), was signed into law in the United States. The OBBB contains several changes to corporate taxation including the extension of key provisions of the 2017 Tax Cuts and Jobs Act and modifications to the international tax framework. The legislation has multiple effective dates, with certain provisions effective in our fiscal year 2026 and others phased in through our fiscal year 2027. The OBBB did not have a material impact to our income tax provision for fiscal year 2026.

[0001193125-26-259683:notes:260]
The Organisation for Economic Co-operation and Development (“OECD”) introduced an international tax framework under Pillar Two that provides for a global minimum tax of 15% for large multinational companies. We are currently subject to Pillar Two rules enacted in certain foreign jurisdictions in which we operate. As of April 24, 2026, Pillar Two taxes did not have an impact on our financial statements, particularly due to the safe harbor relief during the transition period. On January 5, 2026, the OECD issued administrative guidance outlining a framework under which U.S.-parented groups may be excluded from the application of Pillar Two rules through a “side-by-side arrangement.” Each member jurisdiction will need to adopt this guidance into local law, and the timing and manner of adoption may vary. We will continue to monitor U.S. and international legislative developments, including further announcements on the side-by-side arrangement, to assess any potential impacts to our financial statements.

[0001193125-26-259683:notes:261]
The tax years that remain subject to examination as of April 24, 2026 for our major tax jurisdictions are shown below:

[0001193125-26-259683:notes:262]
| 2023 — 2026 |  | United States — federal income tax |
| 2020 — 2026 |  | United States — state and local income tax |
| 2020 — 2026 |  | Australia |
| 2022 — 2026 |  | Germany |
| 2007 — 2026 |  | India |
| 2019 — 2026 |  | The Netherlands |
| 2019 — 2026 |  | Canada |
| 2020 — 2026 |  | Japan |
| 2020 — 2026 |  | Cyprus |
| 2023 — 2026 |  | United Kingdom |
| 2024 — 2026 |  | France |
| 2019 — 2026 |  | Israel |
| 2022 — 2026 |  | Ireland |

[0001193125-26-259683:notes:263]
We are currently undergoing various income tax audits in the U.S. and audits in several foreign tax jurisdictions. Transfer pricing calculations are key topics under these audits and are often subject to dispute and appeals.

[0001193125-26-259683:notes:264]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions.

[0001193125-26-259683:notes:265]
As of April 24, 2026, we continue to record a deferred tax liability related to state taxes on unremitted earnings of certain foreign entities as well as a deferred tax liability related to withholding taxes on unremitted earnings of certain foreign entities. We estimate

[0001193125-26-259683:notes:266]
the unrecognized deferred tax liability related to the earnings we expect to be indefinitely reinvested to be immaterial. We will continue to monitor our plans to indefinitely reinvest undistributed earnings of foreign subsidiaries and will assess the related unrecognized deferred tax liability considering our ongoing projected global cash requirements, tax consequences associated with repatriation and any U.S. or foreign government programs designed to influence remittances.


## us-gaap:EarningsPerShareTextBlock

[0001193125-26-259683:notes:267]
13. Net Income per Share

[0001193125-26-259683:notes:268]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0001193125-26-259683:notes:269]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 1,276 |  |  | $ | 1,186 |  |  | $ | 986 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 199 |  |  |  | 204 |  |  |  | 208 |  |
| Dilutive impact of employee equity award plans |  |  | 2 |  |  |  | 5 |  |  |  | 5 |  |
| Shares used in diluted computation |  |  | 201 |  |  |  | 209 |  |  |  | 213 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 6.41 |  |  | $ | 5.81 |  |  | $ | 4.74 |  |
| Diluted |  | $ | 6.35 |  |  | $ | 5.67 |  |  | $ | 4.63 |  |

[0001193125-26-259683:notes:270]
The following table presents the numbers of potential shares of common stock from outstanding employee equity awards that have been excluded from the computation of diluted net income per share, as their inclusion would have had an anti-dilutive effect, for the periods presented (in millions):

[0001193125-26-259683:notes:271]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Employee equity award plans |  |  | 1 |  |  |  | 1 |  |  |  | 2 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-26-259683:notes:272]
14. Segment, Geographic, and Significant Customer Information

[0001193125-26-259683:notes:273]
Our operations are organized into two segments: Hybrid Cloud and Public Cloud. The two segments are based on the information reviewed by our Chief Operating Decision Maker (CODM), who is the Chief Executive Officer, to evaluate results and allocate resources. The CODM measures performance of each segment based on segment revenue and segment gross profit by comparing actual revenue and gross profit results to historical results and previously forecasted financial information. We do not allocate to our segments certain cost of revenues which we manage at the corporate level. These unallocated costs include stock-based compensation and amortization of intangible assets. We do not allocate assets to our segments.

[0001193125-26-259683:notes:274]
Hybrid Cloud offers a unified data storage portfolio of storage management and infrastructure solutions that helps customers modernize their data centers. This portfolio accommodates both structured and unstructured data with unified storage optimized for flash, disk, and cloud storage, capable of handling data-intensive workloads and applications. Hybrid Cloud includes software, hardware, and related support, along with professional and other services.

[0001193125-26-259683:notes:275]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage, data services, and operational services. Public Cloud includes certain reseller arrangements in which the timing of our consideration follows the end user consumption of the reseller services.

[0001193125-26-259683:notes:276]
Segment Revenues and Gross Profit

[0001193125-26-259683:notes:277]
Financial information by segment is as follows (in millions):

[0001193125-26-259683:notes:278]
|  | Year Ended April 24, 2026 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Product revenues | $ | 3,194 |  |  | $ | — |  |  | $ | 3,194 |  |
| Support revenues |  | 2,636 |  |  |  | — |  |  |  | 2,636 |  |
| Professional and other services revenues |  | 407 |  |  |  | — |  |  |  | 407 |  |
| Public cloud revenues |  | — |  |  |  | 688 |  |  |  | 688 |  |
| Net revenues |  | 6,237 |  |  |  | 688 |  |  |  | 6,925 |  |
| Cost of product revenues |  | 1,395 |  |  |  | — |  |  |  | 1,395 |  |
| Cost of support revenues |  | 198 |  |  |  | — |  |  |  | 198 |  |
| Cost of professional and other services revenues |  | 281 |  |  |  | — |  |  |  | 281 |  |
| Cost of public cloud revenues |  | — |  |  |  | 113 |  |  |  | 113 |  |
| Segment cost of revenues |  | 1,874 |  |  |  | 113 |  |  |  | 1,987 |  |
| Segment gross profit | $ | 4,363 |  |  | $ | 575 |  |  | $ | 4,938 |  |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | (39 | ) |
| Operating expenses |  |  |  |  |  |  |  | (3,225 | ) |
| Other expense, net |  |  |  |  |  |  |  | (26 | ) |
| Income before income taxes |  |  |  |  |  |  | $ | 1,648 |  |
| 1 Unallocated cost of revenues are composed of $28 million of stock-based compensation expense and $11 million of amortization of intangible assets. |  |

[0001193125-26-259683:notes:279]
|  | Year Ended April 25, 2025 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Product revenues | $ | 3,040 |  |  | $ | — |  |  | $ | 3,040 |  |
| Support revenues |  | 2,512 |  |  |  | — |  |  |  | 2,512 |  |
| Professional and other services revenues |  | 355 |  |  |  | — |  |  |  | 355 |  |
| Public cloud revenues |  | — |  |  |  | 665 |  |  |  | 665 |  |
| Net revenues |  | 5,907 |  |  |  | 665 |  |  |  | 6,572 |  |
| Cost of product revenues |  | 1,278 |  |  |  | — |  |  |  | 1,278 |  |
| Cost of support revenues |  | 197 |  |  |  | — |  |  |  | 197 |  |
| Cost of professional and other services revenues |  | 261 |  |  |  | — |  |  |  | 261 |  |
| Cost of public cloud revenues |  | — |  |  |  | 165 |  |  |  | 165 |  |
| Segment cost of revenues |  | 1,736 |  |  |  | 165 |  |  |  | 1,901 |  |
| Segment gross profit | $ | 4,171 |  |  | $ | 500 |  |  | $ | 4,671 |  |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | (58 | ) |
| Operating expenses |  |  |  |  |  |  |  | (3,276 | ) |
| Other income, net |  |  |  |  |  |  |  | 46 |  |
| Income before income taxes |  |  |  |  |  |  | $ | 1,383 |  |
| 1 Unallocated cost of revenues are composed of $30 million of stock-based compensation expense and $28 million of amortization of intangible assets. |  |

[0001193125-26-259683:notes:280]
|  | Year Ended April 26, 2024 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Total |  |
| Product revenues | $ | 2,849 |  |  | $ | — |  |  | $ | 2,849 |  |
| Support revenues |  | 2,488 |  |  |  | — |  |  |  | 2,488 |  |
| Professional and other services revenues |  | 320 |  |  |  | — |  |  |  | 320 |  |
| Public cloud revenues |  | — |  |  |  | 611 |  |  |  | 611 |  |
| Net revenues |  | 5,657 |  |  |  | 611 |  |  |  | 6,268 |  |
| Cost of product revenues |  | 1,131 |  |  |  | — |  |  |  | 1,131 |  |
| Cost of support revenues |  | 195 |  |  |  | — |  |  |  | 195 |  |
| Cost of professional and other services revenues |  | 243 |  |  |  | — |  |  |  | 243 |  |
| Cost of public cloud revenues |  | — |  |  |  | 203 |  |  |  | 203 |  |
| Segment cost of revenues |  | 1,569 |  |  |  | 203 |  |  |  | 1,772 |  |
| Segment gross profit | $ | 4,088 |  |  | $ | 408 |  |  | $ | 4,496 |  |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | (63 | ) |
| Operating expenses |  |  |  |  |  |  |  | (3,219 | ) |
| Other income, net |  |  |  |  |  |  |  | 49 |  |
| Income before income taxes |  |  |  |  |  |  | $ | 1,263 |  |
| 1 Unallocated cost of revenues are composed of $29 million of stock-based compensation expense and $34 million of amortization of intangible assets. |  |

[0001193125-26-259683:notes:281]
Hybrid Cloud Segment Net Revenues by Storage Category are as follows (in millions):

[0001193125-26-259683:notes:282]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| All-flash revenues |  | $ | 4,178 |  |  | $ | 3,763 |  |  | $ | 3,262 |  |
| Hybrid-flash and other revenues |  |  | 2,059 |  |  |  | 2,144 |  |  |  | 2,395 |  |
| Hybrid Cloud segment net revenues |  | $ | 6,237 |  |  | $ | 5,907 |  |  | $ | 5,657 |  |

[0001193125-26-259683:notes:283]
Geographical Revenues and Certain Assets

[0001193125-26-259683:notes:284]
Revenues summarized by geographic region are as follows (in millions):

[0001193125-26-259683:notes:285]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| United States, Canada and Latin America (Americas) |  | $ | 3,505 |  |  | $ | 3,347 |  |  | $ | 3,193 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 2,358 |  |  |  | 2,204 |  |  |  | 2,104 |  |
| Asia Pacific (APAC) |  |  | 1,062 |  |  |  | 1,021 |  |  |  | 971 |  |
| Net revenues |  | $ | 6,925 |  |  | $ | 6,572 |  |  | $ | 6,268 |  |

[0001193125-26-259683:notes:286]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $3,293 million, $3,092 million and $2,952 million during fiscal 2026, 2025 and 2024, respectively.

[0001193125-26-259683:notes:287]
The majority of our assets, excluding cash, cash equivalents, short-term investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents and short-term investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0001193125-26-259683:notes:288]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| U.S. |  | $ | 1,322 |  |  | $ | 1,320 |  |
| International |  |  | 2,262 |  |  |  | 2,526 |  |
| Total |  | $ | 3,584 |  |  | $ | 3,846 |  |

[0001193125-26-259683:notes:289]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment information for geographic areas based on the physical location of the assets (in millions):

[0001193125-26-259683:notes:290]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| U.S. |  | $ | 373 |  |  | $ | 344 |  |
| International |  |  | 219 |  |  |  | 219 |  |
| Total |  | $ | 592 |  |  | $ | 563 |  |

[0001193125-26-259683:notes:291]
Significant Customers

[0001193125-26-259683:notes:292]
Two customers, each of which is a distributor, accounted for 10% or more of our net revenues:

[0001193125-26-259683:notes:293]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| Customer A |  |  | 22 | % |  |  | 21 | % |  |  | 22 | % |
| Customer B |  |  | 21 | % |  |  | 24 | % |  |  | 22 | % |

[0001193125-26-259683:notes:294]
Two customers, each of which is a distributor, accounted for 10% or more of accounts receivable:

[0001193125-26-259683:notes:295]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Customer A |  | * |  |  |  | 10 | % |
| Customer B |  |  | 18 | % |  |  | 27 | % |
| * Customer accounted for less than 10% of accounts receivable. |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-26-259683:notes:296]
15. Employee Benefits and Deferred Compensation

[0001193125-26-259683:notes:297]
Employee 401(k) Plan

[0001193125-26-259683:notes:298]
Our 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit. We match 100% of the first 2% of eligible earnings an employee contributes to the 401(k) Plan, and then match 50% of the next 4% of eligible earnings an employee contributes. An employee receives the full 4% match when he/she contributes at least 6% of his/her eligible earnings, up to a maximum calendar year matching contribution of $6,000. Our employer matching contributions to the 401(k) Plan were as follows (in millions):

[0001193125-26-259683:notes:299]
|  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 26, 2024 |  |
| 401(k) matching contributions |  | $ | 29 |  |  | $ | 30 |  |  | $ | 29 |  |

[0001193125-26-259683:notes:300]
Deferred Compensation Plan

[0001193125-26-259683:notes:301]
We have a non-qualified deferred compensation plan that allows a group of employees within the U.S. to contribute base salary and commissions or incentive compensation on a tax deferred basis in excess of the IRS limits imposed on 401(k) plans. The marketable securities related to these investments are held in a Rabbi Trust. The related deferred compensation plan assets and liabilities under the non-qualified deferred compensation plan were as follows (in millions):

[0001193125-26-259683:notes:302]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Deferred compensation plan assets reported as: |  |  |  |  |  |  |
| Other current assets |  | $ | 9 |  |  | $ | 7 |  |
| Other non-current assets |  | $ | 40 |  |  | $ | 34 |  |
| Deferred compensation plan liabilities reported as: |  |  |  |  |  |  |
| Accrued expenses |  | $ | 9 |  |  | $ | 7 |  |
| Other long-term liabilities |  | $ | 40 |  |  | $ | 34 |  |

[0001193125-26-259683:notes:303]
Defined Benefit Plans

[0001193125-26-259683:notes:304]
We maintain various defined benefit plans to provide termination and postretirement benefits to certain eligible employees outside of the U.S. We also provide disability benefits to certain eligible employees in the U.S. Eligibility is determined based on the terms of our plans and local statutory requirements.

[0001193125-26-259683:notes:305]
The funded status of our defined benefit plans, which is recognized in other long-term liabilities in our consolidated balance sheets, was as follows (in millions):

[0001193125-26-259683:notes:306]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Fair value of plan assets |  | $ | 73 |  |  | $ | 66 |  |
| Benefit obligations |  |  | (107 | ) |  |  | (106 | ) |
| Unfunded obligations |  | $ | (34 | ) |  | $ | (40 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-26-259683:notes:307]
16. Commitments and Contingencies

[0001193125-26-259683:notes:308]
Purchase Orders and Other Commitments

[0001193125-26-259683:notes:309]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of April 24, 2026, we had $1.0 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 24, 2026 and April 25, 2025, such liability amounted to $25 million and $22 million, respectively, and is included in accrued expenses in our consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001193125-26-259683:notes:310]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of April 24, 2026, we had $0.4 billion in other purchase obligations.

[0001193125-26-259683:notes:311]
Of the total $1.4 billion in purchase commitments, $1.1 billion is due in fiscal 2027, with the remainder due thereafter.

[0001193125-26-259683:notes:312]
Legal Contingencies

[0001193125-26-259683:notes:313]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001193125-26-259683:notes:314]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigation brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0001193125-26-259683:notes:315]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of April 24, 2026 related to such matters.


## dei:AuditorOpinionTextBlock

[0001193125-26-259683:notes:316]
Opinion on the Financial Statements

[0001193125-26-259683:notes:317]
We have audited the accompanying consolidated balance sheets of NetApp, Inc. and subsidiaries (the "Company") as of April 24, 2026, and April 25, 2025, the related consolidated statements of income, comprehensive income, stockholders' equity, and cash flows, for each of the three years in the period ended April 24, 2026, and the related notes (collectively referred to as the "financial statements"). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of April 24, 2026, and April 25, 2025, and the results of its operations and its cash flows for each of the three years in the period ended April 24, 2026, in conformity with accounting principles generally accepted in the United States of America.

[0001193125-26-259683:notes:318]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of April 24, 2026, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission and our report dated June 5, 2026, expressed an unqualified opinion on the Company's internal control over financial reporting.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001193125-26-259683:notes:319]
Item 9B.  Other Information

[0001193125-26-259683:notes:320]
Insider Adoption or Termination of Trading Arrangements

[0001193125-26-259683:notes:321]
On March 24, 2026, Cesar Cernuda, President of the Company, entered into a Rule 10b5-1 trading arrangement intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) promulgated under the Exchange Act. The trading arrangement will expire on December 31, 2026 and may be terminated earlier in the limited circumstances defined in the trading arrangement, An aggregate of up to 54,681 shares may be sold pursuant to the trading arrangement.

[0001193125-26-259683:notes:322]
No other directors or executive officers of the Company adopted, modified or terminated any contract, instruction or written plan for the purchase or sale of the Company's securities that was intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) or any non-Rule 10b5-1 trading arrangement (as defined in Item 408(c) of Regulation S-K) during the fourth quarter of fiscal 2026.
