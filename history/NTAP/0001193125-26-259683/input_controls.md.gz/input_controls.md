# NTAP 10-K controls and the auditor's report


## auditors_report

[0001193125-26-259683:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001193125-26-259683:auditors_report:2]
To the stockholders and the Board of Directors of NetApp, Inc.

[0001193125-26-259683:auditors_report:3]
Opinion on the Financial Statements

[0001193125-26-259683:auditors_report:4]
We have audited the accompanying consolidated balance sheets of NetApp, Inc. and subsidiaries (the "Company") as of April 24, 2026, and April 25, 2025, the related consolidated statements of income, comprehensive income, stockholders' equity, and cash flows, for each of the three years in the period ended April 24, 2026, and the related notes (collectively referred to as the "financial statements"). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of April 24, 2026, and April 25, 2025, and the results of its operations and its cash flows for each of the three years in the period ended April 24, 2026, in conformity with accounting principles generally accepted in the United States of America.

[0001193125-26-259683:auditors_report:5]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of April 24, 2026, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission and our report dated June 5, 2026, expressed an unqualified opinion on the Company's internal control over financial reporting.

[0001193125-26-259683:auditors_report:6]
Basis for Opinion

[0001193125-26-259683:auditors_report:7]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company's financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001193125-26-259683:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001193125-26-259683:auditors_report:9]
Critical Audit Matter

[0001193125-26-259683:auditors_report:10]
The critical audit matter communicated below is a matter arising from the current-period audit of the financial statements that was communicated or required to be communicated to the audit committee and that (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001193125-26-259683:auditors_report:11]
Revenue — Refer to Notes 1, 5, and 14 to the financial statements

[0001193125-26-259683:auditors_report:12]
Critical Audit Matter Description

[0001193125-26-259683:auditors_report:13]
The Company’s contracts with customers often include the transfer of multiple products and services to the customer, such as hardware systems, software licenses, software support, hardware support, public cloud services and other services. Pursuant to accounting principles generally accepted in the United States of America, the Company is required to evaluate whether each performance obligation represents goods and services that are distinct for purposes of determining the amount and timing of revenue recognition. A good or service is distinct where the customer can benefit from the good or service either on its own or together with other resources that are readily available from third parties or from the Company, and is distinct in the context of the contract, where the transfer of the good or service is separately identifiable from other promises in the contract. The evaluation of performance obligations can require significant judgment in certain contracts and could change the amount of revenue recognized in a given period.

[0001193125-26-259683:auditors_report:14]
We identified the evaluation of performance obligations in certain contracts as a critical audit matter because of the significant judgment management makes in evaluating such contracts and the impact of such judgment on the amount of revenue recognized in a particular period. This required a high degree of auditor judgment and an increased extent of testing.

[0001193125-26-259683:auditors_report:15]
How the Critical Audit Matter Was Addressed in the Audit

[0001193125-26-259683:auditors_report:16]
86

[0001193125-26-259683:auditors_report:17]
Our audit procedures related to the Company’s evaluation of performance obligations for certain contracts included the following, among others:

[0001193125-26-259683:auditors_report:18]
•
We tested the effectiveness of internal controls related to management’s review of contracts to evaluate and determine distinct performance obligations.

[0001193125-26-259683:auditors_report:19]
•
We evaluated management’s significant accounting policies related to revenue recognition for reasonableness and compliance with generally accepted accounting principles.

[0001193125-26-259683:auditors_report:20]
•
We selected a sample of certain contracts with customers and performed the following:

[0001193125-26-259683:auditors_report:21]
o
Obtained and read contract source documents, including master agreements, amendments, and other documents that were part of the contract.

[0001193125-26-259683:auditors_report:22]
o
Evaluated the terms and conditions in the contract source documents and evaluated the appropriateness of management’s application of their accounting policies in the evaluation of performance obligations.

[0001193125-26-259683:auditors_report:23]
/s/ DELOITTE & TOUCHE LLP

[0001193125-26-259683:auditors_report:24]
Raleigh, North Carolina

[0001193125-26-259683:auditors_report:25]
June 5, 2026

[0001193125-26-259683:auditors_report:26]
We have served as the Company's auditor since 1995.

[0001193125-26-259683:auditors_report:27]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001193125-26-259683:auditors_report:28]
To the stockholders and the Board of Directors of NetApp, Inc.

[0001193125-26-259683:auditors_report:29]
Opinion on Internal Control over Financial Reporting

[0001193125-26-259683:auditors_report:30]
We have audited the internal control over financial reporting of NetApp, Inc. and subsidiaries (the "Company") as of April 24, 2026, based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of April 24, 2026, based on criteria established in Internal Control — Integrated Framework (2013) issued by COSO.

[0001193125-26-259683:auditors_report:31]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year ended April 24, 2026, of the Company and our report dated June 5, 2026, expressed an unqualified opinion on those financial statements.

[0001193125-26-259683:auditors_report:32]
Basis for Opinion

[0001193125-26-259683:auditors_report:33]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control Over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001193125-26-259683:auditors_report:34]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001193125-26-259683:auditors_report:35]
Definition and Limitations of Internal Control over Financial Reporting

[0001193125-26-259683:auditors_report:36]
87

[0001193125-26-259683:auditors_report:37]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001193125-26-259683:auditors_report:38]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001193125-26-259683:auditors_report:39]
/s/ DELOITTE & TOUCHE LLP

[0001193125-26-259683:auditors_report:40]
Raleigh, North Carolina

[0001193125-26-259683:auditors_report:41]
June 5, 2026

[0001193125-26-259683:auditors_report:42]
88


## item_9a

[0001193125-26-259683:item_9a:1]
Item 9A.  Controls and Procedures

[0001193125-26-259683:item_9a:2]
(a) Evaluation of Disclosure Controls and Procedures

[0001193125-26-259683:item_9a:3]
The phrase “disclosure controls and procedures” refers to controls and procedures designed to ensure that information required to be disclosed in our reports filed or submitted under the Securities Exchange Act of 1934, as amended (the Exchange Act), such as this Annual Report on Form 10-K, is recorded, processed, summarized and reported within the time periods specified in the rules and forms of the U.S. Securities and Exchange Commission (SEC). Disclosure controls and procedures are also designed to ensure that such information is accumulated and communicated to our management, including our Chief Executive Officer (CEO) and our Chief Financial Officer (CFO), as appropriate to allow timely decisions regarding required disclosure.

[0001193125-26-259683:item_9a:4]
Under the supervision and with the participation of our management, including our CEO and CFO, we carried out an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, as of April 24, 2026, the end of the fiscal period covered by this Annual Report on Form 10-K (the Evaluation Date). Based on this evaluation, our CEO and CFO concluded as of the Evaluation Date that our disclosure controls and procedures were effective such that the information required to be disclosed in our SEC reports (i) is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms and (ii) is accumulated and communicated to our management, including our CEO and CFO, as appropriate to allow timely decisions regarding required disclosure.

[0001193125-26-259683:item_9a:5]
(b) Management’s Report on Internal Control Over Financial Reporting

[0001193125-26-259683:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rule 13a-15(f). Our internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001193125-26-259683:item_9a:7]
Under the supervision and with the participation of our management, including our principal executive officer and principal financial officer, we conducted an evaluation of the effectiveness of our internal control over financial reporting based on the criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this assessment, our management concluded that, as of April 24, 2026, our internal control over financial reporting was effective at the reasonable assurance level based on those criteria.

[0001193125-26-259683:item_9a:8]
The effectiveness of our internal control over financial reporting as of April 24, 2026 has been audited by Deloitte & Touche LLP, an independent registered public accounting firm, as stated in their report, which is included in Part II, Item 8 of this Annual Report on Form 10-K.

[0001193125-26-259683:item_9a:9]
(c) Changes in Internal Control Over Financial Reporting

[0001193125-26-259683:item_9a:10]
There has been no change in our internal control over financial reporting identified in connection with our evaluation required by paragraph (d) of rules 13a-15 and 15d-15 under the Exchange Act that occurred during the fourth quarter of fiscal 2026 that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.
