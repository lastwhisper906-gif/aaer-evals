# NTAP 8-K — 0001193125-26-245196 filed 2026-05-28

## item codes, every 8-K on or before 2026-06-05

- 2026-05-28 0001193125-26-245196 — 2.02, 8.01, 9.01
- 2026-02-26 0001193125-26-076545 — 2.02, 9.01
- 2026-01-12 0001193125-26-010401 — 5.02, 7.01, 9.01
- 2025-11-25 0001193125-25-297164 — 2.02, 9.01
- 2025-09-15 0001193125-25-202408 — 5.02, 5.07, 9.01
- 2025-08-27 0000950170-25-111700 — 2.02, 9.01
- 2025-05-29 0000950170-25-078936 — 2.02, 5.02, 8.01, 9.01
- 2025-03-26 0000950170-25-045244 — 5.02, 7.01, 9.01
- 2025-03-17 0001193125-25-055656 — 1.01, 2.03, 8.01, 9.01
- 2025-03-05 0001193125-25-047187 — 1.01, 2.03, 9.01
- 2025-02-27 0000950170-25-029022 — 2.02, 9.01
- 2025-02-26 0001193125-25-036882 — 5.02, 9.01
- 2025-01-28 0001193125-25-014441 — 5.02, 9.01
- 2024-11-21 0000950170-24-129714 — 2.02, 9.01
- 2024-09-12 0000950170-24-105928 — 5.02, 5.07, 9.01
- 2024-08-28 0000950170-24-101383 — 2.02, 5.02, 9.01
- 2024-05-30 0000950170-24-066567 — 2.02, 8.01, 9.01
- 2024-04-09 0000950170-24-042957 — 5.02
- 2024-02-29 0000950170-24-023060 — 2.02, 9.01
- 2023-11-28 0000950170-23-066400 — 2.02, 9.01
- 2023-11-16 0000950170-23-064506 — 5.02, 5.03, 9.01
- 2023-09-15 0000950170-23-048229 — 5.02, 5.07, 9.01
- 2023-08-23 0000950170-23-044130 — 2.02, 9.01
- 2023-08-10 0000950170-23-041348 — 5.02
- 2023-05-31 0000950170-23-025324 — 1.01, 2.02, 8.01, 9.01
- 2023-02-22 0000950170-23-003745 — 2.02, 9.01
- 2023-01-31 0001193125-23-019739 — 2.05, 7.01, 9.01
- 2022-11-29 0000950170-22-025793 — 2.02, 9.01
- 2022-11-16 0000950170-22-025317 — 5.02
- 2022-09-14 0000950170-22-018490 — 5.07
- 2022-08-24 0000950170-22-017731 — 2.02, 9.01
- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2026-06-05

- none on or before 2026-06-05

## item 2.02 — earnings release, exhibit 99.1

[0001193125-26-245196:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0001193125-26-245196:8k_2_02:2]
EX-99.1

[0001193125-26-245196:8k_2_02:3]
Exhibit 99.1

[0001193125-26-245196:8k_2_02:4]
NetApp Reports Fourth Quarter and Fiscal Year 2026 Results

[0001193125-26-245196:8k_2_02:5]
Delivers record net revenue, gross profit, operating income, cash flow from operations and free cash flow for Q4 and fiscal year 2026;

[0001193125-26-245196:8k_2_02:6]
Fourth quarter net revenues of $1.95 billion, an increase of 12% year-over-year;

[0001193125-26-245196:8k_2_02:7]
Fiscal year 2026 net revenues of $6.93 billion, an increase of 5% year-over-year

[0001193125-26-245196:8k_2_02:8]
News Summary

[0001193125-26-245196:8k_2_02:9]
•
Record all-flash array net revenue of $1.2 billion for the fourth quarter of fiscal year 2026, an increase of 18% year-over-year

[0001193125-26-245196:8k_2_02:10]
•
Record Public Cloud net revenue of $182 million for the fourth quarter of fiscal year 2026, an increase of 11% year-over-year

[0001193125-26-245196:8k_2_02:11]
•
Record billings of $7.21 billion for fiscal year 2026, an increase of 6% year-over-year

[0001193125-26-245196:8k_2_02:12]
•
Returned $1.36 billion to stockholders through share repurchases and cash dividends in fiscal year 2026

[0001193125-26-245196:8k_2_02:13]
SAN JOSE, Calif.—May 28, 2026—NetApp (NASDAQ: NTAP), the Intelligent Data Infrastructure company, today reported financial results for the fourth quarter and fiscal year 2026, which ended on April 24, 2026.

[0001193125-26-245196:8k_2_02:14]
“Fiscal year 2026 was a landmark year for NetApp with record results across revenue, gross profit, operating income, cash flow from operations, and free cash flow. Our industry-leading hybrid cloud, intelligent data infrastructure platform, trusted by the world’s leading organizations, is powering customers’ AI driven transformations, delivering secure, high-performance access to data wherever it resides,” said George Kurian, Chief Executive Officer. “We achieved our target operating margin while launching next-generation AI solutions and expanding strategic partnerships. As enterprises scale their AI ambitions, NetApp’s unified data platform and flexible offerings position us for sustained growth. I am proud of our team’s execution and excited for the opportunities ahead in fiscal year 2027 and beyond.”

[0001193125-26-245196:8k_2_02:15]
Fourth Quarter and Fiscal Year 2026 Financial Results

[0001193125-26-245196:8k_2_02:16]
($ in millions, except earnings per share)

[0001193125-26-245196:8k_2_02:17]
| GAAP Results |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY26 |  |  | Q4 FY25 |  |  | % Change |  |  | FY2026 |  |  | FY2025 |  |  | % Change |  |
| Net revenues |  | $ | 1,948 |  |  | $ | 1,732 |  |  |  | 12 | % |  | $ | 6,925 |  |  | $ | 6,572 |  |  |  | 5 | % |
| Hybrid Cloud segment revenues |  | $ | 1,766 |  |  | $ | 1,568 |  |  |  | 13 | % |  | $ | 6,237 |  |  | $ | 5,907 |  |  |  | 6 | % |
| Public Cloud segment revenues |  | $ | 182 |  |  | $ | 164 |  |  |  | 11 | % |  | $ | 688 |  |  | $ | 665 |  |  |  | 3 | % |
| Gross profit |  | $ | 1,365 |  |  | $ | 1,193 |  |  |  | 14 | % |  | $ | 4,899 |  |  | $ | 4,613 |  |  |  | 6 | % |
| Net income |  | $ | 404 |  |  | $ | 340 |  |  |  | 19 | % |  | $ | 1,276 |  |  | $ | 1,186 |  |  |  | 8 | % |
| Earnings per share |  | $ | 2.03 |  |  | $ | 1.65 |  |  |  | 23 | % |  | $ | 6.35 |  |  | $ | 5.67 |  |  |  | 12 | % |
| Net cash provided by operating activities |  | $ | 950 |  |  | $ | 675 |  |  |  | 41 | % |  | $ | 2,067 |  |  | $ | 1,506 |  |  |  | 37 | % |

[0001193125-26-245196:8k_2_02:18]
| Non-GAAP Results |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY26 |  |  | Q4 FY25 |  |  | % Change |  |  | FY2026 |  |  | FY2025 |  |  | % Change |  |
| Billings |  | $ | 2,163 |  |  | $ | 2,032 |  |  |  | 6 | % |  | $ | 7,206 |  |  | $ | 6,780 |  |  |  | 6 | % |
| Net revenues |  | $ | 1,948 |  |  | $ | 1,732 |  |  |  | 12 | % |  | $ | 6,925 |  |  | $ | 6,572 |  |  |  | 5 | % |
| Hybrid Cloud segment revenues |  | $ | 1,766 |  |  | $ | 1,568 |  |  |  | 13 | % |  | $ | 6,237 |  |  | $ | 5,907 |  |  |  | 6 | % |
| Public Cloud segment revenues |  | $ | 182 |  |  | $ | 164 |  |  |  | 11 | % |  | $ | 688 |  |  | $ | 665 |  |  |  | 3 | % |
| Gross profit |  | $ | 1,374 |  |  | $ | 1,203 |  |  |  | 14 | % |  | $ | 4,938 |  |  | $ | 4,671 |  |  |  | 6 | % |
| Net income |  | $ | 483 |  |  | $ | 397 |  |  |  | 22 | % |  | $ | 1,635 |  |  | $ | 1,516 |  |  |  | 8 | % |
| Earnings per share |  | $ | 2.43 |  |  | $ | 1.93 |  |  |  | 26 | % |  | $ | 8.13 |  |  | $ | 7.25 |  |  |  | 12 | % |
| Free cash flow |  | $ | 900 |  |  | $ | 640 |  |  |  | 41 | % |  | $ | 1,869 |  |  | $ | 1,338 |  |  |  | 40 | % |
| Full reconciliations between GAAP and non-GAAP measures, and explanations related to the usage of non-GAAP measures, are provided below. |  |

[0001193125-26-245196:8k_2_02:19]
Constant Currency — Q4 Fiscal Year 2026 versus Q4 Fiscal Year 2025

[0001193125-26-245196:8k_2_02:20]
•
In constant currency, year-over-year, net revenues increased by 10% and billings increased by 4%.

[0001193125-26-245196:8k_2_02:21]
•
The year-over-year fluctuations of GAAP and non-GAAP net income presented in the tables above each include a favorable impact of approximately $24 million from foreign currency exchange rate changes.

[0001193125-26-245196:8k_2_02:22]
•
The year-over-year fluctuations of GAAP and non-GAAP earnings per share presented in the tables above each include a favorable impact of approximately $0.12 from foreign currency exchange rate changes.

[0001193125-26-245196:8k_2_02:23]
Constant Currency — Fiscal Year 2026 versus Fiscal Year 2025

[0001193125-26-245196:8k_2_02:24]
•
In constant currency, year-over-year, net revenues increased by 4% and billings increased by 4%.

[0001193125-26-245196:8k_2_02:25]
•
The year-over-year fluctuations of GAAP and non-GAAP net income presented in the tables above each include a favorable impact of approximately $65 million from foreign currency exchange rate changes.

[0001193125-26-245196:8k_2_02:26]
•
The year-over-year fluctuations of GAAP and non-GAAP earnings per share presented in the tables above each include a favorable impact of approximately $0.32 from foreign currency exchange rate changes.

[0001193125-26-245196:8k_2_02:27]
| First Quarter of Fiscal Year 2027 Financial Outlook |  |  |  |
| The Company provided the following financial guidance for the first quarter of fiscal year 2027: |
| Net revenues are expected to be in the range of: | $1.750 billion - $1.900 billion |
|  | GAAP |  | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 68.1% - 69.1% |  | 69.1% - 70.1% |
| Operating margins are expected to be in the range of: | 19.4% - 20.4% |  | 28.4% - 29.4% |
| Earnings per share is expected to be in the range of: | $1.35 - $1.45 |  | $2.05 - $2.15 |

[0001193125-26-245196:8k_2_02:28]
| Full Fiscal Year 2027 Financial Outlook |  |  |  |
| The Company provided the following financial guidance for the full fiscal year 2027: |  |  |
| Net revenues are expected to be in the range of: | $7.325 billion - $7.575 billion |
|  | GAAP |  | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 67.5% - 68.5% |  | 68.5% - 69.5% |
| Operating margins are expected to be in the range of: | 22.1% - 23.1% |  | 29.1% - 30.1% |
| Earnings per share is expected to be in the range of: | $6.51 - $6.81 |  | $8.70 - $9.00 |

[0001193125-26-245196:8k_2_02:29]
Dividend

[0001193125-26-245196:8k_2_02:30]
The next cash dividend of $0.52 per share is to be paid on July 29, 2026, to stockholders of record as of the close of business on July 10, 2026.

[0001193125-26-245196:8k_2_02:31]
Fourth Quarter of Fiscal Year 2026 Business Highlights

[0001193125-26-245196:8k_2_02:32]
Leading Product and Cloud Service Innovation

[0001193125-26-245196:8k_2_02:33]
•
NetApp announced new next-generation EF50 and EF80 high-performance storage systems designed to deliver faster throughput, improved efficiency, and scalable performance for demanding workloads like AI, HPC, and databases.

[0001193125-26-245196:8k_2_02:34]
•
NetApp launched the AI Data EngineTM, an end-to-end AI data platform co-engineered with NVIDIA that enables enterprises to find, manage, and prepare data for production AI workloads through a global metadata catalog and integrated ecosystem.

[0001193125-26-245196:8k_2_02:35]
•
NetApp announced the general availability of iSCSI block storage and previews of unified file/block and ONTAPTM-mode for Google Cloud NetApp Volumes, enabling enterprises to run mission-critical workloads in the cloud with high performance, resilience, and simplified operations.

[0001193125-26-245196:8k_2_02:36]
•
NetApp announced the general availability of NetApp Data Migrator, a simple, multicloud data migration service that moves data across environments without specialized expertise.

[0001193125-26-245196:8k_2_02:37]
•
NetApp launched NetApp ConsoleTM Disaster Recovery for Google Cloud NetApp Volumes, providing a simple, low-cost way to protect VMware workloads across on‑premises and cloud environments to reduce the complexity and cost of traditional disaster recovery solutions.

[0001193125-26-245196:8k_2_02:38]
•
NetApp announced the public preview of Azure NetApp Files Elastic zone-redundant storage service level to help customers modernize mission-critical workloads with enterprise resilience, meet availability commitments, and reduce operational overhead.

[0001193125-26-245196:8k_2_02:39]
•
NetApp introduced a public preview integration between Cloud Volumes ONTAPTM and Microsoft OneLake enabling enterprises to run AI and analytics on existing NAS data in place without migration, reducing cost and accelerating time to value.

[0001193125-26-245196:8k_2_02:40]
•
NetApp announced TridentTM 26.02, a new software release that improves Kubernetes scalability and performance through parallelism while adding automation, cloud integrations, and cost-optimizing features like AutoGrow and auto-tiering.

[0001193125-26-245196:8k_2_02:41]
Customer and Partner Momentum

[0001193125-26-245196:8k_2_02:42]
•
NetApp announced an expanded, multi-year collaboration with Google Cloud to deliver secure by design data infrastructure for Google Distributed Cloud environments, enabling AI-driven workloads in highly regulated, air-gapped sovereign and private cloud environments.

[0001193125-26-245196:8k_2_02:43]
•
NetApp announced a partnership with Nutanix to integrate ONTAP-based data infrastructure with the Nutanix Cloud Platform, enabling simplified virtualization modernization, faster migration, and enhanced hybrid multicloud operations.

[0001193125-26-245196:8k_2_02:44]
•
NetApp announced a strategic alliance with Commvault to deliver a closed-loop recovery architecture that combines early ransomware detection signals with an automated, validated recovery workflow at scale.

[0001193125-26-245196:8k_2_02:45]
•
NetApp partnered with Elastio to enhance ransomware resilience by integrating continuous backup inspection and recovery validation into its NetApp Ransomware ResilienceTM Solution for end-to-end, defense-in-depth data protection.

[0001193125-26-245196:8k_2_02:46]
•
NetApp announced that Red Hat OpenShift Virtualization supports Google Cloud NetApp Volumes and NetApp Trident as a generally available option for a unified platform to run and manage virtual machines (VMs) and containers side-by-side.

[0001193125-26-245196:8k_2_02:47]
•
NetApp achieved AWS High Performance Computing Competency for ONTAP, validating its ability to deliver scalable, high-performance storage solutions for HPC workloads on AWS.

[0001193125-26-245196:8k_2_02:48]
•
NetApp collaborated with Enkrypt AI to integrate AI risk insights with data-layer security, enabling real-time, context-aware enforcement of data access decisions to reduce exposure and strengthen AI governance.

[0001193125-26-245196:8k_2_02:49]
•
NetApp expanded its collaboration with Cyera to integrate enterprise data risk intelligence with storage-layer enforcement, enabling real-time, policy-driven access control and automated remediation of sensitive data exposure.

[0001193125-26-245196:8k_2_02:50]
Awards and Recognition

[0001193125-26-245196:8k_2_02:51]
•
For the seventh time, NetApp won the 2026 Google Cloud Infrastructure Modernization Partner of the Year for Storage Award for helping customers modernize infrastructure and run enterprise workloads using Google Cloud NetApp Volumes.

[0001193125-26-245196:8k_2_02:52]
•
NetApp was named a Leader and Fast Mover in GigaOm’s Radar for Globally Distributed File Systems, showcasing FlexCache and ONTAP capabilities for delivering consistent, secure, and high-performance global file access.

[0001193125-26-245196:8k_2_02:53]
•
NetApp AFF A-Series won the Primary Storage category of the Storage Newsletter Awards, which recognized top products in data management, protection, and storage.

[0001193125-26-245196:8k_2_02:54]
Webcast and Conference Call Information

[0001193125-26-245196:8k_2_02:55]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today. NetApp uses its website as a tool to disclose important information about NetApp and comply with its disclosure obligations under Regulation Fair Disclosure.

[0001193125-26-245196:8k_2_02:56]
Actual results may differ materially from these statements for a variety of reasons, including, without limitation, our ability to keep pace with the rapid industry, technological and market trends and changes in the markets in which we operate; our ability to execute our evolved cloud strategy and introduce and gain market acceptance for our products and services; our ability to maintain our customer, partner, supplier and contract manufacturer relationships on favorable terms and conditions; global political, macroeconomic and market conditions, including inflation, fluctuating interest rates, tariffs, changes in trade policy, regulations, monetary policy shifts, recession risks, and foreign exchange volatility and the resulting impact on demand for our products; the impact of new or ongoing geopolitical conflicts and sanctions; adoption or changes to laws, regulations, standards, or policies affecting our operations, products, services, the storage industry, or AI usage; material cybersecurity and other security breaches; the impact of supply chain disruptions on our business operations, financial performance and results of operations; changes and related uncertainty in U.S. government spending or policy, including due to prolonged federal government shutdowns; changes in overall technology spending by our customers; revenue seasonality; changes in laws or regulations, including those relating to privacy, data protection and information security; the timing of orders and their fulfillment; and our ability to manage our gross profit margins, including managing component costs. These and other equally important factors are described in reports and documents we file from time to time with the Securities and Exchange Commission, including the factors described under the sections titled “Risk Factors” in our most recently filed annual report on Form 10-K and quarterly report on Form 10-Q. All statements made in this release are made only as of the date set forth at the beginning of this release. We disclaim any obligation to update information contained in this press release, whether as a result of new information, future events, or otherwise.

[0001193125-26-245196:8k_2_02:57]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001193125-26-245196:8k_2_02:58]
NetApp Usage of Non-GAAP Financial Information

[0001193125-26-245196:8k_2_02:59]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP gross margins, non-GAAP gross profit, non-GAAP operating income, non-GAAP operating margins, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per share.

[0001193125-26-245196:8k_2_02:60]
NetApp believes that the presentation of its non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. Non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0001193125-26-245196:8k_2_02:61]
NetApp believes that the presentation of non-GAAP gross margins, non-GAAP gross profit, non-GAAP operating income, non-GAAP operating margins, non-GAAP effective tax rate, non-GAAP net income, and non-GAAP earnings per share data provides investors with supplemental metrics that assist in understanding current results and future prospects, earnings and profitability that are complementary to GAAP metrics. Each of these non-GAAP metrics is defined as the applicable GAAP metric adjusted to exclude the items defined in A through I below, as applicable, while our non-GAAP effective tax rate and non-GAAP net income also reflect a non-GAAP tax provision, as described in item J below, instead of our GAAP tax provision. GAAP earnings per share and non-GAAP earnings per share are calculated using the net income divided by the diluted number of shares for the applicable period.

[0001193125-26-245196:8k_2_02:62]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to  investors and management because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001193125-26-245196:8k_2_02:63]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to investors and management because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0001193125-26-245196:8k_2_02:64]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001193125-26-245196:8k_2_02:65]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001193125-26-245196:8k_2_02:66]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001193125-26-245196:8k_2_02:67]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0001193125-26-245196:8k_2_02:68]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0001193125-26-245196:8k_2_02:69]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0001193125-26-245196:8k_2_02:70]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001193125-26-245196:8k_2_02:71]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer and/or lose control of assets to a third party. This is inclusive of third-party advisory, legal and other costs that result directly from and are essential to a sale transaction and that would not have been incurred had the decision to sell not been made. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0001193125-26-245196:8k_2_02:72]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0001193125-26-245196:8k_2_02:73]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such non-recurring costs do not reflect the results of its underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0001193125-26-245196:8k_2_02:74]
J. Income tax effects. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges or benefits that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges or benefits resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001193125-26-245196:8k_2_02:75]
Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies. In addition, non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-26-245196:8k_2_02:76]
NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with GAAP. A detailed reconciliation of our non-GAAP to GAAP results can be found herein. In the press release and accompanying financial statements and reconciliations, the terms "operating income" and "income from operations" are used interchangeably. Similarly, "earnings per share" and "net income per share" are also used interchangeably.

[0001193125-26-245196:8k_2_02:77]
Constant Currency

[0001193125-26-245196:8k_2_02:78]
In periods in which the impacts of foreign currency exchange rate changes are significant, NetApp presents certain constant currency growth rates or quantifies the impact of foreign currency exchange rate changes on year-over-year fluctuations, including for net revenues, billings, and earnings. This constant currency information assumes that the same foreign currency exchange rates that were in effect for the comparable prior-year period were used in translation of the current period results.

[0001193125-26-245196:8k_2_02:79]
About NetApp

[0001193125-26-245196:8k_2_02:80]
For more than three decades, NetApp has helped the world’s leading organizations navigate change – from the rise of enterprise storage to the intelligent era defined by data and AI. Today, NetApp is the Intelligent Data Infrastructure company, helping customers turn data into a catalyst for innovation, resilience, and growth.

[0001193125-26-245196:8k_2_02:81]
At the heart of that infrastructure is the NetApp data platform – the unified, enterprise-grade, intelligent foundation that connects, protects, and activates data across every cloud, workload, and environment. Built on the proven power of NetApp ONTAP, our leading data management software and OS, and enhanced by automation through the AI Data Engine and AFX, it delivers observability, resilience, and intelligence at scale.

[0001193125-26-245196:8k_2_02:82]
Disaggregated by design, the NetApp data platform separates storage, services, and control so enterprises can modernize faster, scale efficiently, and innovate without lock-in. As the only enterprise storage platform natively embedded in the world’s largest clouds, it gives organizations the freedom to run any workload anywhere with consistent performance, governance, and protection.

[0001193125-26-245196:8k_2_02:83]
With NetApp, data is always ready – ready to defend against threats, ready to power AI, and ready to drive the next breakthrough. That’s why the world’s most forward-thinking enterprises trust NetApp to turn intelligence into advantage.

[0001193125-26-245196:8k_2_02:84]
Learn more at www.netapp.com or follow us on X, LinkedIn, Facebook, and Instagram.

[0001193125-26-245196:8k_2_02:85]
NETAPP, INC.

[0001193125-26-245196:8k_2_02:86]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-26-245196:8k_2_02:87]
($ in millions)

[0001193125-26-245196:8k_2_02:88]
(Unaudited)

[0001193125-26-245196:8k_2_02:89]
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,584 |  |  | $ | 3,846 |  |
| Accounts receivable |  |  | 1,286 |  |  |  | 1,246 |  |
| Inventories |  |  | 198 |  |  |  | 186 |  |
| Other current assets |  |  | 708 |  |  |  | 573 |  |
| Total current assets |  |  | 5,776 |  |  |  | 5,851 |  |
| Property and equipment, net |  |  | 592 |  |  |  | 563 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,794 |  |  |  | 2,766 |  |
| Other non-current assets |  |  | 1,582 |  |  |  | 1,643 |  |
| Total assets |  | $ | 10,744 |  |  | $ | 10,823 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 550 |  |  | $ | 511 |  |
| Accrued expenses |  |  | 1,151 |  |  |  | 1,122 |  |
| Current portion of long-term debt |  |  | — |  |  |  | 750 |  |
| Short-term deferred revenue |  |  | 2,320 |  |  |  | 2,279 |  |
| Total current liabilities |  |  | 4,021 |  |  |  | 4,662 |  |
| Long-term debt |  |  | 2,487 |  |  |  | 2,485 |  |
| Other long-term liabilities |  |  | 360 |  |  |  | 379 |  |
| Long-term deferred revenue |  |  | 2,525 |  |  |  | 2,257 |  |
| Total liabilities |  |  | 9,393 |  |  |  | 9,783 |  |
| Stockholders' equity |  |  | 1,351 |  |  |  | 1,040 |  |
| Total liabilities and stockholders' equity |  | $ | 10,744 |  |  | $ | 10,823 |  |

[0001193125-26-245196:8k_2_02:90]
NETAPP, INC.

[0001193125-26-245196:8k_2_02:91]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-26-245196:8k_2_02:92]
($ in millions, except net income per share amounts)

[0001193125-26-245196:8k_2_02:93]
(Unaudited)

[0001193125-26-245196:8k_2_02:94]
|  |  | Three Months Ended |  |  | Year Ended |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 24, 2026 |  |  | April 25, 2025 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 966 |  |  | $ | 845 |  |  | $ | 3,194 |  |  | $ | 3,040 |  |  |
| Services |  |  | 982 |  |  |  | 887 |  |  |  | 3,731 |  |  |  | 3,532 |  |  |
| Net revenues |  |  | 1,948 |  |  |  | 1,732 |  |  |  | 6,925 |  |  |  | 6,572 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 425 |  |  |  | 378 |  |  |  | 1,401 |  |  |  | 1,284 |  |  |
| Cost of services |  |  | 158 |  |  |  | 161 |  |  |  | 625 |  |  |  | 675 |  |  |
| Total cost of revenues |  |  | 583 |  |  |  | 539 |  |  |  | 2,026 |  |  |  | 1,959 |  |  |
| Gross profit |  |  | 1,365 |  |  |  | 1,193 |  |  |  | 4,899 |  |  |  | 4,613 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 488 |  |  |  | 458 |  |  |  | 1,869 |  |  |  | 1,865 |  |  |
| Research and development |  |  | 261 |  |  |  | 256 |  |  |  | 991 |  |  |  | 1,012 |  |  |
| General and administrative |  |  | 85 |  |  |  | 85 |  |  |  | 344 |  |  |  | 311 |  |  |
| Restructuring charges |  |  | (1 | ) |  |  | 45 |  |  |  | 21 |  |  |  | 83 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 5 |  |  |
| Total operating expenses |  |  | 833 |  |  |  | 845 |  |  |  | 3,225 |  |  |  | 3,276 |  |  |
| Income from operations |  |  | 532 |  |  |  | 348 |  |  |  | 1,674 |  |  |  | 1,337 |  |  |
| Other (expense) income, net |  |  | (14 | ) |  |  | 6 |  |  |  | (26 | ) |  |  | 46 |  |  |
| Income before income taxes |  |  | 518 |  |  |  | 354 |  |  |  | 1,648 |  |  |  | 1,383 |  |  |
| Provision for income taxes |  |  | 114 |  |  |  | 14 |  |  |  | 372 |  |  |  | 197 |  |  |
| Net income |  | $ | 404 |  |  | $ | 340 |  |  | $ | 1,276 |  |  | $ | 1,186 |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.05 |  |  | $ | 1.67 |  |  | $ | 6.41 |  |  | $ | 5.81 |  |  |
| Diluted |  | $ | 2.03 |  |  | $ | 1.65 |  |  | $ | 6.35 |  |  | $ | 5.67 |  |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 197 |  |  |  | 203 |  |  |  | 199 |  |  |  | 204 |  |  |
| Diluted |  |  | 199 |  |  |  | 206 |  |  |  | 201 |  |  |  | 209 |  |  |

[0001193125-26-245196:8k_2_02:95]
NETAPP, INC.

[0001193125-26-245196:8k_2_02:96]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-26-245196:8k_2_02:97]
($ in millions)

[0001193125-26-245196:8k_2_02:98]
(Unaudited)

[0001193125-26-245196:8k_2_02:99]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 24, 2026 |  |  | April 25, 2025 |  |  | April 24, 2026 |  |  | April 25, 2025 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 404 |  |  | $ | 340 |  |  | $ | 1,276 |  |  | $ | 1,186 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 49 |  |  |  | 53 |  |  |  | 200 |  |  |  | 243 |  |
| Non-cash operating lease cost |  |  | 10 |  |  |  | 10 |  |  |  | 42 |  |  |  | 41 |  |
| Stock-based compensation |  |  | 100 |  |  |  | 95 |  |  |  | 382 |  |  |  | 386 |  |
| Deferred income taxes |  |  | 87 |  |  |  | 10 |  |  |  | 135 |  |  |  | (100 | ) |
| Other items, net |  |  | (3 | ) |  |  | 25 |  |  |  | 55 |  |  |  | — |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 27 |  |  |  | (323 | ) |  |  | (36 | ) |  |  | (219 | ) |
| Inventories |  |  | (89 | ) |  |  | 81 |  |  |  | (12 | ) |  |  | (1 | ) |
| Accounts payable |  |  | 129 |  |  |  | 69 |  |  |  | 31 |  |  |  | (8 | ) |
| Accrued expenses |  |  | 225 |  |  |  | 156 |  |  |  | (23 | ) |  |  | 62 |  |
| Deferred revenue |  |  | 215 |  |  |  | 300 |  |  |  | 281 |  |  |  | 208 |  |
| Long-term taxes payable |  |  | (10 | ) |  |  | (123 | ) |  |  | (7 | ) |  |  | (207 | ) |
| Changes in other operating assets and liabilities, net |  |  | (194 | ) |  |  | (18 | ) |  |  | (257 | ) |  |  | (85 | ) |
| Net cash provided by operating activities |  |  | 950 |  |  |  | 675 |  |  |  | 2,067 |  |  |  | 1,506 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| (Purchases) redemptions of investments, net |  |  | (130 | ) |  |  | (345 | ) |  |  | (412 | ) |  |  | 245 |  |
| Purchases of property and equipment |  |  | (50 | ) |  |  | (35 | ) |  |  | (198 | ) |  |  | (168 | ) |
| Other investing activities, net |  |  | — |  |  |  | 67 |  |  |  | 15 |  |  |  | 70 |  |
| Net cash (used in) provided by investing activities |  |  | (180 | ) |  |  | (313 | ) |  |  | (595 | ) |  |  | 147 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | — |  |  |  | — |  |  |  | 103 |  |  |  | 108 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (25 | ) |  |  | (31 | ) |  |  | (137 | ) |  |  | (199 | ) |
| Repurchase of common stock |  |  | (200 | ) |  |  | (250 | ) |  |  | (950 | ) |  |  | (1,150 | ) |
| Issuances of debt, net of issuance costs |  |  | — |  |  |  | 1,240 |  |  |  | — |  |  |  | 1,240 |  |
| Repayments and extinguishment of debt |  |  | — |  |  |  | — |  |  |  | (750 | ) |  |  | (400 | ) |
| Dividends paid |  |  | (103 | ) |  |  | (105 | ) |  |  | (413 | ) |  |  | (424 | ) |
| Other financing activities, net |  |  | — |  |  |  | (3 | ) |  |  | — |  |  |  | (3 | ) |
| Net cash (used in) provided by financing activities |  |  | (328 | ) |  |  | 851 |  |  |  | (2,147 | ) |  |  | (828 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (2 | ) |  |  | 18 |  |  |  | 1 |  |  |  | 15 |  |
| Net change in cash, cash equivalents and restricted cash |  |  | 440 |  |  |  | 1,231 |  |  |  | (674 | ) |  |  | 840 |  |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 1,635 |  |  |  | 1,518 |  |  |  | 2,749 |  |  |  | 1,909 |  |
| End of period |  | $ | 2,075 |  |  | $ | 2,749 |  |  | $ | 2,075 |  |  | $ | 2,749 |  |

[0001193125-26-245196:8k_2_02:100]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| ($ in millions) |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| NET INCOME |  | $ | 404 |  |  |  | $ | 340 |  |  | $ | 1,276 |  |  | $ | 1,186 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 4 |  |  |  |  | 6 |  |  |  | 21 |  |  |  | 47 |  |
| Stock-based compensation |  |  | 100 |  |  |  |  | 95 |  |  |  | 382 |  |  |  | 386 |  |
| Restructuring charges |  |  | (1 | ) |  |  |  | 45 |  |  |  | 21 |  |  |  | 83 |  |
| Acquisition-related expense |  |  | — |  |  |  |  | 1 |  |  |  | — |  |  |  | 5 |  |
| Gains/losses on the sale or derecognition of assets |  |  | (11 | ) |  |  |  | 1 |  |  |  | (10 | ) |  |  | 7 |  |
| Gain on sale of equity investment |  |  | — |  |  |  |  | (10 | ) |  |  | — |  |  |  | (10 | ) |
| Income tax effects |  |  | (8 | ) |  |  |  | (42 | ) |  |  | (50 | ) |  |  | (149 | ) |
| Resolution of income tax matters |  |  | (5 | ) |  |  |  | (39 | ) |  |  | (5 | ) |  |  | (39 | ) |
| NON-GAAP NET INCOME |  | $ | 483 |  |  |  | $ | 397 |  |  | $ | 1,635 |  |  | $ | 1,516 |  |
| COST OF REVENUES |  | $ | 583 |  |  |  | $ | 539 |  |  | $ | 2,026 |  |  | $ | 1,959 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (3 | ) |  |  | (11 | ) |  |  | (28 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  |  | (7 | ) |  |  | (28 | ) |  |  | (30 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 574 |  |  |  | $ | 529 |  |  | $ | 1,987 |  |  | $ | 1,901 |  |
| COST OF PRODUCT REVENUES |  | $ | 425 |  |  |  | $ | 378 |  |  | $ | 1,401 |  |  | $ | 1,284 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (1 | ) |  |  |  | (1 | ) |  |  | (6 | ) |  |  | (6 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 424 |  |  |  | $ | 377 |  |  | $ | 1,395 |  |  | $ | 1,278 |  |
| COST OF SERVICES REVENUES |  | $ | 158 |  |  |  | $ | 161 |  |  | $ | 625 |  |  | $ | 675 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (3 | ) |  |  | (11 | ) |  |  | (28 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  |  | (6 | ) |  |  | (22 | ) |  |  | (24 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 150 |  |  |  | $ | 152 |  |  | $ | 592 |  |  | $ | 623 |  |
| GROSS PROFIT |  | $ | 1,365 |  |  |  | $ | 1,193 |  |  | $ | 4,899 |  |  | $ | 4,613 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 3 |  |  |  |  | 3 |  |  |  | 11 |  |  |  | 28 |  |
| Stock-based compensation |  |  | 6 |  |  |  |  | 7 |  |  |  | 28 |  |  |  | 30 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,374 |  |  |  | $ | 1,203 |  |  | $ | 4,938 |  |  | $ | 4,671 |  |

[0001193125-26-245196:8k_2_02:101]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| ($ in millions) |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| SALES AND MARKETING EXPENSES |  | $ | 488 |  |  |  | $ | 458 |  |  | $ | 1,869 |  |  | $ | 1,865 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (1 | ) |  |  |  | (3 | ) |  |  | (10 | ) |  |  | (19 | ) |
| Stock-based compensation |  |  | (41 | ) |  |  |  | (40 | ) |  |  | (155 | ) |  |  | (162 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 446 |  |  |  | $ | 415 |  |  | $ | 1,704 |  |  | $ | 1,684 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 261 |  |  |  | $ | 256 |  |  | $ | 991 |  |  | $ | 1,012 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (34 | ) |  |  |  | (31 | ) |  |  | (126 | ) |  |  | (135 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 227 |  |  |  | $ | 225 |  |  | $ | 865 |  |  | $ | 877 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 85 |  |  |  | $ | 85 |  |  | $ | 344 |  |  | $ | 311 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (19 | ) |  |  |  | (17 | ) |  |  | (73 | ) |  |  | (59 | ) |
| Gains/losses on the sale or derecognition of assets |  |  | 11 |  |  |  |  | (1 | ) |  |  | 10 |  |  |  | (4 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 77 |  |  |  | $ | 67 |  |  | $ | 281 |  |  | $ | 248 |  |
| RESTRUCTURING CHARGES |  | $ | (1 | ) |  |  | $ | 45 |  |  | $ | 21 |  |  | $ | 83 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | 1 |  |  |  |  | (45 | ) |  |  | (21 | ) |  |  | (83 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | — |  |  |  | $ | 1 |  |  | $ | — |  |  | $ | 5 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | — |  |  |  |  | (1 | ) |  |  | — |  |  |  | (5 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 833 |  |  |  | $ | 845 |  |  | $ | 3,225 |  |  | $ | 3,276 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (1 | ) |  |  |  | (3 | ) |  |  | (10 | ) |  |  | (19 | ) |
| Stock-based compensation |  |  | (94 | ) |  |  |  | (88 | ) |  |  | (354 | ) |  |  | (356 | ) |
| Restructuring charges |  |  | 1 |  |  |  |  | (45 | ) |  |  | (21 | ) |  |  | (83 | ) |
| Acquisition-related expense |  |  | — |  |  |  |  | (1 | ) |  |  | — |  |  |  | (5 | ) |
| Gains/losses on the sale or derecognition of assets |  |  | 11 |  |  |  |  | (1 | ) |  |  | 10 |  |  |  | (4 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 750 |  |  |  | $ | 707 |  |  | $ | 2,850 |  |  | $ | 2,809 |  |

[0001193125-26-245196:8k_2_02:102]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| ($ in millions, except net income per share) |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| INCOME FROM OPERATIONS |  | $ | 532 |  |  |  | $ | 348 |  |  | $ | 1,674 |  |  | $ | 1,337 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 4 |  |  |  |  | 6 |  |  |  | 21 |  |  |  | 47 |  |
| Stock-based compensation |  |  | 100 |  |  |  |  | 95 |  |  |  | 382 |  |  |  | 386 |  |
| Restructuring charges |  |  | (1 | ) |  |  |  | 45 |  |  |  | 21 |  |  |  | 83 |  |
| Acquisition-related expense |  |  | — |  |  |  |  | 1 |  |  |  | — |  |  |  | 5 |  |
| Gains/losses on the sale or derecognition of assets |  |  | (11 | ) |  |  |  | 1 |  |  |  | (10 | ) |  |  | 4 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 624 |  |  |  | $ | 496 |  |  | $ | 2,088 |  |  | $ | 1,862 |  |
| OTHER (EXPENSE) INCOME, NET |  | $ | (14 | ) |  |  | $ | 6 |  |  | $ | (26 | ) |  | $ | 46 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gains/losses on the sale or derecognition of assets |  |  | — |  |  |  |  | — |  |  |  | — |  |  |  | 3 |  |
| Gain on sale of equity investment |  |  | — |  |  |  |  | (10 | ) |  |  | — |  |  |  | (10 | ) |
| NON-GAAP OTHER (EXPENSE) INCOME, NET |  | $ | (14 | ) |  |  | $ | (4 | ) |  | $ | (26 | ) |  | $ | 39 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 518 |  |  |  | $ | 354 |  |  | $ | 1,648 |  |  | $ | 1,383 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 4 |  |  |  |  | 6 |  |  |  | 21 |  |  |  | 47 |  |
| Stock-based compensation |  |  | 100 |  |  |  |  | 95 |  |  |  | 382 |  |  |  | 386 |  |
| Restructuring charges |  |  | (1 | ) |  |  |  | 45 |  |  |  | 21 |  |  |  | 83 |  |
| Acquisition-related expense |  |  | — |  |  |  |  | 1 |  |  |  | — |  |  |  | 5 |  |
| Gains/losses on the sale or derecognition of assets |  |  | (11 | ) |  |  |  | 1 |  |  |  | (10 | ) |  |  | 7 |  |
| Gain on sale of equity investment |  |  | — |  |  |  |  | (10 | ) |  |  | — |  |  |  | (10 | ) |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 610 |  |  |  | $ | 492 |  |  | $ | 2,062 |  |  | $ | 1,901 |  |
| PROVISION FOR INCOME TAXES |  | $ | 114 |  |  |  | $ | 14 |  |  | $ | 372 |  |  | $ | 197 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 8 |  |  |  |  | 42 |  |  |  | 50 |  |  |  | 149 |  |
| Resolution of income tax matters |  |  | 5 |  |  |  |  | 39 |  |  |  | 5 |  |  |  | 39 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 127 |  |  |  | $ | 95 |  |  | $ | 427 |  |  | $ | 385 |  |
| NET INCOME PER SHARE |  | $ | 2.03 |  |  |  | $ | 1.65 |  |  | $ | 6.35 |  |  | $ | 5.67 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.02 |  |  |  |  | 0.03 |  |  |  | 0.10 |  |  |  | 0.22 |  |
| Stock-based compensation |  |  | 0.50 |  |  |  |  | 0.46 |  |  |  | 1.90 |  |  |  | 1.85 |  |
| Restructuring charges |  |  | (0.01 | ) |  |  |  | 0.22 |  |  |  | 0.10 |  |  |  | 0.40 |  |
| Acquisition-related expense |  |  | — |  |  |  |  | 0.01 |  |  |  | — |  |  |  | 0.03 |  |
| Gains/losses on the sale or derecognition of assets |  |  | (0.05 | ) |  |  |  | — |  |  |  | (0.05 | ) |  |  | 0.03 |  |
| Gain on sale of equity investment |  |  | — |  |  |  |  | (0.05 | ) |  |  | — |  |  |  | (0.05 | ) |
| Income tax effects |  |  | (0.04 | ) |  |  |  | (0.20 | ) |  |  | (0.25 | ) |  |  | (0.71 | ) |
| Resolution of income tax matters |  |  | (0.02 | ) |  |  |  | (0.19 | ) |  |  | (0.02 | ) |  |  | (0.19 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 2.43 |  |  |  | $ | 1.93 |  |  | $ | 8.13 |  |  | $ | 7.25 |  |

[0001193125-26-245196:8k_2_02:103]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| Gross margin |  |  | 70.1 | % |  |  |  | 68.9 | % |  |  | 70.7 | % |  |  | 70.2 | % |
| Cost of revenues adjustments |  |  | 0.4 | % |  |  |  | 0.6 | % |  |  | 0.6 | % |  |  | 0.9 | % |
| Non-GAAP Gross margin |  |  | 70.5 | % |  |  |  | 69.5 | % |  |  | 71.3 | % |  |  | 71.1 | % |
| Cost of revenues |  | $ | 583 |  |  |  | $ | 539 |  |  | $ | 2,026 |  |  | $ | 1,959 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (3 | ) |  |  | (11 | ) |  |  | (28 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  |  | (7 | ) |  |  | (28 | ) |  |  | (30 | ) |
| Non-GAAP Cost of revenues |  | $ | 574 |  |  |  | $ | 529 |  |  | $ | 1,987 |  |  | $ | 1,901 |  |
| Net revenues |  | $ | 1,948 |  |  |  | $ | 1,732 |  |  | $ | 6,925 |  |  | $ | 6,572 |  |

[0001193125-26-245196:8k_2_02:104]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| Product gross margin |  |  | 56.0 | % |  |  |  | 55.3 | % |  |  | 56.1 | % |  |  | 57.8 | % |
| Cost of product revenues adjustments |  |  | 0.1 | % |  |  |  | 0.1 | % |  |  | 0.2 | % |  |  | 0.2 | % |
| Non-GAAP Product gross margin |  |  | 56.1 | % |  |  |  | 55.4 | % |  |  | 56.3 | % |  |  | 58.0 | % |
| Cost of product revenues |  | $ | 425 |  |  |  | $ | 378 |  |  | $ | 1,401 |  |  | $ | 1,284 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (1 | ) |  |  |  | (1 | ) |  |  | (6 | ) |  |  | (6 | ) |
| Non-GAAP Cost of product revenues |  | $ | 424 |  |  |  | $ | 377 |  |  | $ | 1,395 |  |  | $ | 1,278 |  |
| Product revenues |  | $ | 966 |  |  |  | $ | 845 |  |  | $ | 3,194 |  |  | $ | 3,040 |  |

[0001193125-26-245196:8k_2_02:105]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| Services gross margin |  |  | 83.9 | % |  |  |  | 81.8 | % |  |  | 83.2 | % |  |  | 80.9 | % |
| Cost of services revenues adjustments |  |  | 0.8 | % |  |  |  | 1.1 | % |  |  | 0.9 | % |  |  | 1.5 | % |
| Non-GAAP Services gross margin |  |  | 84.7 | % |  |  |  | 82.9 | % |  |  | 84.1 | % |  |  | 82.4 | % |
| Cost of services revenues |  | $ | 158 |  |  |  | $ | 161 |  |  | $ | 625 |  |  | $ | 675 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  |  | (3 | ) |  |  | (11 | ) |  |  | (28 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  |  | (6 | ) |  |  | (22 | ) |  |  | (24 | ) |
| Non-GAAP Cost of services revenues |  | $ | 150 |  |  |  | $ | 152 |  |  | $ | 592 |  |  | $ | 623 |  |
| Services revenues |  | $ | 982 |  |  |  | $ | 887 |  |  | $ | 3,731 |  |  | $ | 3,532 |  |

[0001193125-26-245196:8k_2_02:106]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| OPERATING MARGIN |  |
| ($ in millions) |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| Operating margin |  |  | 27.3 | % |  |  |  | 20.1 | % |  |  | 24.2 | % |  |  | 20.3 | % |
| Adjustments |  |  | 4.7 | % |  |  |  | 8.5 | % |  |  | 6.0 | % |  |  | 8.0 | % |
| Non-GAAP Operating margin |  |  | 32.0 | % |  |  |  | 28.6 | % |  |  | 30.2 | % |  |  | 28.3 | % |
| Income from operations |  | $ | 532 |  |  |  | $ | 348 |  |  | $ | 1,674 |  |  | $ | 1,337 |  |
| Income from operations adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 4 |  |  |  |  | 6 |  |  |  | 21 |  |  |  | 47 |  |
| Stock-based compensation |  |  | 100 |  |  |  |  | 95 |  |  |  | 382 |  |  |  | 386 |  |
| Restructuring charges |  |  | (1 | ) |  |  |  | 45 |  |  |  | 21 |  |  |  | 83 |  |
| Acquisition-related expense |  |  | — |  |  |  |  | 1 |  |  |  | — |  |  |  | 5 |  |
| Gains/losses on the sale or derecognition of assets |  |  | (11 | ) |  |  |  | 1 |  |  |  | (10 | ) |  |  | 4 |  |
| Non-GAAP Income from operations |  | $ | 624 |  |  |  | $ | 496 |  |  | $ | 2,088 |  |  | $ | 1,862 |  |
| Net revenues |  | $ | 1,948 |  |  |  | $ | 1,732 |  |  | $ | 6,925 |  |  | $ | 6,572 |  |

[0001193125-26-245196:8k_2_02:107]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| Effective tax rate |  |  | 22.0 | % |  |  |  | 4.0 | % |  |  | 22.6 | % |  |  | 14.2 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | (2.2 | )% |  |  |  | 4.3 | % |  |  | (2.2 | )% |  |  | 3.2 | % |
| Resolution of income tax matters |  |  | 1.0 | % |  |  |  | 11.0 | % |  |  | 0.3 | % |  |  | 2.8 | % |
| Non-GAAP Effective tax rate |  |  | 20.8 | % |  |  |  | 19.3 | % |  |  | 20.7 | % |  |  | 20.2 | % |

[0001193125-26-245196:8k_2_02:108]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| ($ in millions) |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| Net cash provided by operating activities |  | $ | 950 |  |  |  | $ | 675 |  |  | $ | 2,067 |  |  | $ | 1,506 |  |
| Purchases of property and equipment |  |  | (50 | ) |  |  |  | (35 | ) |  |  | (198 | ) |  |  | (168 | ) |
| Free cash flow |  | $ | 900 |  |  |  | $ | 640 |  |  | $ | 1,869 |  |  | $ | 1,338 |  |

[0001193125-26-245196:8k_2_02:109]
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| ($ in millions) |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| Net revenues |  | $ | 1,948 |  |  |  | $ | 1,732 |  |  | $ | 6,925 |  |  | $ | 6,572 |  |
| Change in deferred revenue* |  |  | 215 |  |  |  |  | 300 |  |  |  | 281 |  |  |  | 208 |  |
| Billings |  | $ | 2,163 |  |  |  | $ | 2,032 |  |  | $ | 7,206 |  |  | $ | 6,780 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0001193125-26-245196:8k_2_02:110]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| ($ in millions, except net income per share, DSO, DPO, and Inventory Turns) |  |
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| Product |  | $ | 966 |  |  |  | $ | 845 |  |  | $ | 3,194 |  |  | $ | 3,040 |  |
| Support |  |  | 688 |  |  |  |  | 625 |  |  |  | 2,636 |  |  |  | 2,512 |  |
| Professional and Other Services |  |  | 112 |  |  |  |  | 98 |  |  |  | 407 |  |  |  | 355 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,766 |  |  |  |  | 1,568 |  |  |  | 6,237 |  |  |  | 5,907 |  |
| Public Cloud Segment Net Revenues |  |  | 182 |  |  |  |  | 164 |  |  |  | 688 |  |  |  | 665 |  |
| Net Revenues |  | $ | 1,948 |  |  |  | $ | 1,732 |  |  | $ | 6,925 |  |  | $ | 6,572 |  |
| Hybrid Cloud Segment Net Revenues by Storage Category |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| All-flash revenues |  | $ | 1,216 |  |  |  | $ | 1,034 |  |  | $ | 4,178 |  |  | $ | 3,763 |  |
| Hybrid-flash and other revenues |  |  | 550 |  |  |  |  | 534 |  |  |  | 2,059 |  |  |  | 2,144 |  |
| Hybrid Cloud Segment Net Revenues |  | $ | 1,766 |  |  |  | $ | 1,568 |  |  | $ | 6,237 |  |  | $ | 5,907 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| Product |  | $ | 542 |  |  |  | $ | 468 |  |  | $ | 1,799 |  |  | $ | 1,762 |  |
| Support |  |  | 640 |  |  |  |  | 577 |  |  |  | 2,438 |  |  |  | 2,315 |  |
| Professional and Other Services |  |  | 36 |  |  |  |  | 28 |  |  |  | 126 |  |  |  | 94 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 1,218 |  |  |  |  | 1,073 |  |  |  | 4,363 |  |  |  | 4,171 |  |
| Public Cloud Segment Gross Profit |  |  | 156 |  |  |  |  | 130 |  |  |  | 575 |  |  |  | 500 |  |
| Total Segments Gross Profit |  |  | 1,374 |  |  |  |  | 1,203 |  |  |  | 4,938 |  |  |  | 4,671 |  |
| Amortization of Intangible Assets |  |  | (3 | ) |  |  |  | (3 | ) |  |  | (11 | ) |  |  | (28 | ) |
| Stock-based Compensation |  |  | (6 | ) |  |  |  | (7 | ) |  |  | (28 | ) |  |  | (30 | ) |
| Unallocated Cost of Revenues |  |  | (9 | ) |  |  |  | (10 | ) |  |  | (39 | ) |  |  | (58 | ) |
| Gross Profit |  | $ | 1,365 |  |  |  | $ | 1,193 |  |  | $ | 4,899 |  |  | $ | 4,613 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| Product |  |  | 56.1 | % |  |  |  | 55.4 | % |  |  | 56.3 | % |  |  | 58.0 | % |
| Support |  |  | 93.0 | % |  |  |  | 92.3 | % |  |  | 92.5 | % |  |  | 92.2 | % |
| Professional and Other Services |  |  | 32.1 | % |  |  |  | 28.6 | % |  |  | 31.0 | % |  |  | 26.5 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 69.0 | % |  |  |  | 68.4 | % |  |  | 70.0 | % |  |  | 70.6 | % |
| Public Cloud Segment Gross Margin |  |  | 85.7 | % |  |  |  | 79.3 | % |  |  | 83.6 | % |  |  | 75.2 | % |

[0001193125-26-245196:8k_2_02:111]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| ($ in millions, except net income per share, DSO, DPO, and Inventory Turns) |  |
| (Unaudited) |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY26 |  |  |  | % of Q4 FY25 |  |  | % of FY 2026 |  |  | % of FY 2025 |  |
|  |  | Revenue |  |  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 50 | % |  |  |  | 51 | % |  |  | 51 | % |  |  | 51 | % |
| Americas Commercial |  |  | 40 | % |  |  |  | 42 | % |  |  | 41 | % |  |  | 40 | % |
| U.S. Public Sector* |  |  | 10 | % |  |  |  | 9 | % |  |  | 10 | % |  |  | 11 | % |
| EMEA |  |  | 36 | % |  |  |  | 34 | % |  |  | 34 | % |  |  | 34 | % |
| Asia Pacific |  |  | 14 | % |  |  |  | 15 | % |  |  | 15 | % |  |  | 15 | % |
| * U.S. Public Sector includes revenue from both 1) the U.S. federal government (“U.S. Fed”) and 2) U.S. state governments, local municipalities and education institutions (“U.S. SLED”). |  |

[0001193125-26-245196:8k_2_02:112]
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY26 |  |  |  | % of Q4 FY25 |  |  | % of FY 2026 |  |  | % of FY 2025 |  |
|  |  | Revenue |  |  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 25 | % |  |  |  | 22 | % |  |  | 24 | % |  |  | 22 | % |
| Indirect |  |  | 75 | % |  |  |  | 78 | % |  |  | 76 | % |  |  | 78 | % |

[0001193125-26-245196:8k_2_02:113]
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| Non-GAAP Income from Operations |  | $ | 624 |  |  |  | $ | 496 |  |  | $ | 2,088 |  |  | $ | 1,862 |  |
| Operating Margin |  |  | 32.0 | % |  |  |  | 28.6 | % |  |  | 30.2 | % |  |  | 28.3 | % |
| Non-GAAP Income before Income Taxes |  | $ | 610 |  |  |  | $ | 492 |  |  | $ | 2,062 |  |  | $ | 1,901 |  |
| Non-GAAP Effective Tax Rate |  |  | 20.8 | % |  |  |  | 19.3 | % |  |  | 20.7 | % |  |  | 20.2 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| Non-GAAP Net Income |  | $ | 483 |  |  |  | $ | 397 |  |  | $ | 1,635 |  |  | $ | 1,516 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 199 |  |  |  |  | 206 |  |  |  | 201 |  |  |  | 209 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 2.43 |  |  |  | $ | 1.93 |  |  | $ | 8.13 |  |  | $ | 7.25 |  |

[0001193125-26-245196:8k_2_02:114]
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  |  |  |  |
| Deferred Revenue |  | $ | 4,845 |  |  |  | $ | 4,536 |  |  |  |  |  |
| DSO (days) |  |  | 60 |  |  |  |  | 65 |  |  |  |  |  |
| DPO (days) |  |  | 86 |  |  |  |  | 86 |  |  |  |  |  |
| Inventory Turns |  |  | 12 |  |  |  |  | 12 |  |  |  |  |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |

[0001193125-26-245196:8k_2_02:115]
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4 FY26 |  |  |  | Q4 FY25 |  |  | FY2026 |  |  | FY2025 |  |
| Net Cash Provided by Operating Activities |  | $ | 950 |  |  |  | $ | 675 |  |  | $ | 2,067 |  |  | $ | 1,506 |  |
| Purchases of Property and Equipment |  | $ | 50 |  |  |  | $ | 35 |  |  | $ | 198 |  |  | $ | 168 |  |
| Free Cash Flow |  | $ | 900 |  |  |  | $ | 640 |  |  | $ | 1,869 |  |  | $ | 1,338 |  |
| Free Cash Flow Margin |  |  | 46.2 | % |  |  |  | 37.0 | % |  |  | 27.0 | % |  |  | 20.4 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Free cash flow margin is defined as free cash flow as a percentage of net revenues. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001193125-26-245196:8k_2_02:116]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| FIRST QUARTER FISCAL 2027 |
|  |  | First Quarter |
|  |  | Fiscal 2027 |
| GAAP Guidance - Gross Margin |  | 68.1% - 69.1% |
| Adjustments: |  |  |
| Cost of revenues adjustments |  | 1% |
| Non-GAAP Guidance - Gross Margin |  | 69.1% - 70.1% |
|  |  | First Quarter |
|  |  | Fiscal 2027 |
| GAAP Guidance - Operating Margin |  | 19.4% - 20.4% |
| Adjustments: |  |  |
| Stock-based compensation expense |  | 6% |
| Restructuring charges |  | 3% |
| Non-GAAP Guidance - Operating Margin |  | 28.4% - 29.4% |
| Some items may not add or recalculate due to rounding. |

[0001193125-26-245196:8k_2_02:117]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| EXPRESSED AS NET INCOME PER SHARE |
| FIRST QUARTER FISCAL 2027 |
|  |  | First Quarter |
|  |  | Fiscal 2027 |
| GAAP Guidance - Net Income Per Share |  | $1.35 - $1.45 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share: |  |  |
| Amortization of intangible assets |  | $0.02 |
| Stock-based compensation expense |  | $0.52 |
| Restructuring charges |  | $0.30 |
| Income tax effects |  | ($0.14) |
| Total Adjustments |  | $0.70 |
| Non-GAAP Guidance - Net Income Per Share |  | $2.05 - $2.15 |
| Some items may not add or recalculate due to rounding. |

[0001193125-26-245196:8k_2_02:118]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| FISCAL 2027 |
|  |  | Fiscal 2027 |
| GAAP Guidance - Gross Margin |  | 67.5% - 68.5% |
| Adjustments: |  |  |
| Cost of revenues adjustments |  | 1% |
| Non-GAAP Guidance - Gross Margin |  | 68.5% - 69.5% |
|  |  | Fiscal 2027 |
| GAAP Guidance - Operating Margin |  | 22.1% - 23.1% |
| Adjustments: |  |  |
| Stock-based compensation expense |  | 6% |
| Restructuring charges |  | 1% |
| Non-GAAP Guidance - Operating Margin |  | 29.1% - 30.1% |
| Some items may not add or recalculate due to rounding. |

[0001193125-26-245196:8k_2_02:119]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| EXPRESSED AS NET INCOME PER SHARE |
| FISCAL 2027 |
|  |  | Fiscal 2027 |
| GAAP Guidance - Net Income Per Share |  | $6.51 - $6.81 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share: |  |  |
| Amortization of intangible assets |  | $0.11 |
| Stock-based compensation expense |  | $2.19 |
| Restructuring charges |  | $0.30 |
| Income tax effects |  | ($0.41) |
| Total Adjustments |  | $2.19 |
| Non-GAAP Guidance - Net Income Per Share |  | $8.70 - $9.00 |
| Some items may not add or recalculate due to rounding. |

[0001193125-26-245196:8k_2_02:120]
Contacts:

[0001193125-26-245196:8k_2_02:121]
(Press)

[0001193125-26-245196:8k_2_02:122]
Kenya Hayes

[0001193125-26-245196:8k_2_02:123]
1 703 589 7595

[0001193125-26-245196:8k_2_02:124]
kenya.hayes@netapp.com

[0001193125-26-245196:8k_2_02:125]
(Investors)

[0001193125-26-245196:8k_2_02:126]
Kris Newton

[0001193125-26-245196:8k_2_02:127]
1 408 822 3312

[0001193125-26-245196:8k_2_02:128]
kris.newton@netapp.com
