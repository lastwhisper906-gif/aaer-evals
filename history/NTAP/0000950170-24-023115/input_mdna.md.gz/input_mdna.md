# NTAP MD&A — 0000950170-24-023115


## mdna

[0000950170-24-023115:mdna:1]
[same as prior period, unchanged from 0000950170-23-067033:mdna:1]

[0000950170-24-023115:mdna:2]
[same as prior period, unchanged from 0000950170-23-067033:mdna:3]

[0000950170-24-023115:mdna:3]
[same as prior period, unchanged from 0000950170-23-067033:mdna:4]

[0000950170-24-023115:mdna:4]
NetApp makes data infrastructure intelligent by combining unified data storage, integrated data services, and CloudOps solutions. We create silo-free infrastructure, and harness observability and artificial intelligence to enable seamless data management across environments to help our customers achieve their business priorities.  No matter the data type, workload, or environment, with NetApp customers can modernize their data infrastructure to support their business objectives.

[0000950170-24-023115:mdna:5]
Our unified data storage delivers flexibility by enabling customers to store any data type and power any workload, simply and consistently on a single storage operating system, optimized for cloud and flash. As the only enterprise-grade storage service natively embedded in the world’s largest clouds, our data storage powers any data across clouds. Our integrated data services enable active data management through superior data security, protection, governance, and sustainability. Our CloudOps solutions enable adaptive operations across infrastructure, applications, and teams.

[0000950170-24-023115:mdna:6]
[same as prior period, unchanged from 0000950170-23-067033:mdna:7]

[0000950170-24-023115:mdna:7]
Hybrid Cloud offers a portfolio of storage management and infrastructure solutions that help customers modernize their data centers with the power of the cloud and modernize applications with a single solution that supports file, block, and object storage. Our Hybrid Cloud portfolio supports structured and unstructured data with unified storage optimized for flash and cloud to handle data-intensive workloads and applications. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.

[0000950170-24-023115:mdna:8]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage and CloudOps services. As the only provider of enterprise-grade storage service natively embedded in the world’s largest clouds, NetApp helps organizations harness the power of their data and application workloads. NetApp’s CloudOps solutions tap into the power of AI to maximize productivity across infrastructure and applications to boost the productivity of teams and reduce costs of operations. These solutions and services are generally available on the leading public clouds, including Amazon AWS, Microsoft Azure, and Google Cloud Platform.

[0000950170-24-023115:mdna:9]
[same as prior period, unchanged from 0000950170-23-067033:mdna:10]

[0000950170-24-023115:mdna:10]
[same as prior period, unchanged from 0000950170-23-067033:mdna:11]

[0000950170-24-023115:mdna:11]
Continuing global economic uncertainty, political conditions and fiscal challenges in the U.S. and abroad have resulted and may continue to result in adverse macroeconomic conditions, including inflation, rising interest rates, foreign exchange volatility, slower growth and possibly a recession. In particular, during the first nine months of fiscal 2024, and throughout fiscal 2023, we experienced a weakened demand environment, characterized by cloud optimizations and increased budget scrutiny, which resulted in smaller deal sizes, longer selling cycles, and delays of some deals.

[0000950170-24-023115:mdna:12]
[same as prior period, unchanged from 0000950170-23-067033:mdna:13]

[0000950170-24-023115:mdna:13]
[same as prior period, unchanged from 0000950170-23-067033:mdna:14]

[0000950170-24-023115:mdna:14]
Supply chain constraints, which substantially began to impact us in the first half of fiscal 2023, led to elevated product component and freight costs during the first nine months of fiscal 2023. Comparatively, in the first nine months of fiscal 2024, the supply chain substantially improved, resulting in lower costs.

[0000950170-24-023115:mdna:15]
[same as prior period, unchanged from 0000950170-23-067033:mdna:16]

[0000950170-24-023115:mdna:16]
During the first nine months of fiscal 2024, we repurchased approximately 11 million shares of our common stock at an average price of $76.03 per share, for an aggregate of $800 million. We also declared aggregate cash dividends of $1.50 per share in that period, for which we paid $312 million.

[0000950170-24-023115:mdna:17]
[same as prior period, unchanged from 0000950170-23-067033:mdna:18]

[0000950170-24-023115:mdna:18]
In the third quarter of fiscal 2024, management approved a restructuring plan to redirect resources to highest return activities and reduce costs. Aggregate charges recorded from restructuring plans in the third quarter and first nine months of fiscal 2024 totaled $13 million and $44 million, respectively.

[0000950170-24-023115:mdna:19]
27

[0000950170-24-023115:mdna:20]
[same as prior period, unchanged from 0000950170-23-067033:mdna:20]

[0000950170-24-023115:mdna:21]
[same as prior period, unchanged from 0000950170-23-067033:mdna:21]

[0000950170-24-023115:mdna:22]
[same as prior period, unchanged from 0000950170-23-067033:mdna:22]

[0000950170-24-023115:mdna:23]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 47 | % |  |  | 45 | % |  |  | 44 | % |  |  | 48 | % |  |
| Services |  |  | 53 |  |  |  | 55 |  |  |  | 56 |  |  |  | 52 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 18 |  |  |  | 24 |  |  |  | 18 |  |  |  | 25 |  |  |
| Cost of services |  |  | 11 |  |  |  | 10 |  |  |  | 11 |  |  |  | 10 |  |  |
| Gross profit |  |  | 72 |  |  |  | 66 |  |  |  | 71 |  |  |  | 66 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 27 |  |  |  | 29 |  |  |  | 30 |  |  |  | 29 |  |  |
| Research and development |  |  | 16 |  |  |  | 15 |  |  |  | 16 |  |  |  | 15 |  |  |
| General and administrative |  |  | 5 |  |  |  | 4 |  |  |  | 5 |  |  |  | 4 |  |  |
| Restructuring charges |  |  | 1 |  |  |  | 6 |  |  |  | 1 |  |  |  | 2 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Total operating expenses |  |  | 49 |  |  |  | 54 |  |  |  | 52 |  |  |  | 51 |  |  |
| Income from operations |  |  | 23 |  |  |  | 11 |  |  |  | 18 |  |  |  | 15 |  |  |
| Other income, net |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |
| Income before income taxes |  |  | 24 |  |  |  | 12 |  |  |  | 19 |  |  |  | 16 |  |  |
| Provision (benefit) for income taxes |  |  | 4 |  |  |  | 7 |  |  |  | 4 |  |  |  | (6 | ) |  |
| Net income |  |  | 19 | % |  |  | 4 | % |  |  | 15 | % |  |  | 22 | % |  |

[0000950170-24-023115:mdna:24]
[same as prior period, unchanged from 0000950170-23-067033:mdna:24]

[0000950170-24-023115:mdna:25]
[same as prior period, unchanged from 0000950170-23-067033:mdna:25]

[0000950170-24-023115:mdna:26]
[same as prior period, unchanged from 0000950170-23-067033:mdna:26]

[0000950170-24-023115:mdna:27]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |
| Net revenues |  | $ | 1,606 |  |  | $ | 1,526 |  |  |  | 5 | % |  | $ | 4,600 |  |  | $ | 4,781 |  |  |  | (4 | )% |

[0000950170-24-023115:mdna:28]
The increase in net revenues for the third quarter of fiscal 2024 compared to the corresponding period of fiscal 2023 was primarily due to an increase in product revenues and, to a lesser extent, an increase in services revenues. The decrease in net revenues for the first nine months of fiscal 2024 compared to the corresponding period of fiscal 2024 was primarily due to a decrease in product revenues, partially offset by an increase in services revenues. Product revenues as a percentage of net revenues increased by two percentage points and decreased by four percentage points in the third quarter and first nine months of fiscal 2024, respectively, compared to the corresponding periods of fiscal 2023.

[0000950170-24-023115:mdna:29]
[same as prior period, unchanged from 0000950170-23-067033:mdna:29]

[0000950170-24-023115:mdna:30]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |
| Product revenues |  | $ | 747 |  |  | $ | 682 |  |  |  | 10 | % |  | $ | 2,043 |  |  | $ | 2,305 |  |  |  | (11 | )% |
| Hardware (Non-GAAP) |  |  | 335 |  |  |  | 292 |  |  |  | 15 | % |  |  | 891 |  |  |  | 945 |  |  |  | (6 | )% |
| Software (Non-GAAP) |  |  | 412 |  |  |  | 390 |  |  |  | 6 | % |  |  | 1,152 |  |  |  | 1,360 |  |  |  | (15 | )% |

[0000950170-24-023115:mdna:31]
[same as prior period, unchanged from 0000950170-23-067033:mdna:32]

[0000950170-24-023115:mdna:32]
[same as prior period, unchanged from 0000950170-23-067033:mdna:33]

[0000950170-24-023115:mdna:33]
[same as prior period, unchanged from 0000950170-23-067033:mdna:34]

[0000950170-24-023115:mdna:34]
Total product revenues increased in the third quarter of fiscal 2024 compared to the corresponding period of the prior year primarily due to higher sales of QLC-flash array systems. Total product revenues decreased in the first nine months of fiscal 2024 compared to the corresponding period of the prior year primarily due to lower sales of hybrid systems as a result of softer customer demand.

[0000950170-24-023115:mdna:35]
Revenues from the hardware component of product revenues represented 45% and 44% of product revenues in the third quarter and first nine months of fiscal 2024, compared to 43% and 41% of product revenues in the corresponding periods of the prior year. The software component of product revenues represented 55% and 56% of product revenues in the third quarter and first nine months of fiscal 2024, compared to 57% and 59% of product revenues in the corresponding periods of the prior year. The decrease in the software component percentage of product revenues in the third quarter and first nine months of fiscal 2024 was primarily due to the mix of systems sold.

[0000950170-24-023115:mdna:36]
[same as prior period, unchanged from 0000950170-23-067033:mdna:37]

[0000950170-24-023115:mdna:37]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |
| Services revenues |  | $ | 859 |  |  | $ | 844 |  |  |  | 2 | % |  | $ | 2,557 |  |  | $ | 2,476 |  |  |  | 3 | % |
| Support |  |  | 631 |  |  |  | 616 |  |  |  | 2 | % |  |  | 1,865 |  |  |  | 1,821 |  |  |  | 2 | % |
| Professional and other services |  |  | 77 |  |  |  | 78 |  |  |  | (1 | )% |  |  | 233 |  |  |  | 231 |  |  |  | 1 | % |
| Public cloud |  |  | 151 |  |  |  | 150 |  |  |  | 1 | % |  |  | 459 |  |  |  | 424 |  |  |  | 8 | % |

[0000950170-24-023115:mdna:38]
[same as prior period, unchanged from 0000950170-23-067033:mdna:39]

[0000950170-24-023115:mdna:39]
[same as prior period, unchanged from 0000950170-23-067033:mdna:40]

[0000950170-24-023115:mdna:40]
Support revenues increased in the third quarter and first nine months of fiscal 2024 compared to the corresponding periods of the prior year as a result of a higher aggregate support contract value for our installed base.

[0000950170-24-023115:mdna:41]
Professional and other services revenues remained relatively flat in the third quarter and first nine months of fiscal 2024 compared to the corresponding periods of the prior year.

[0000950170-24-023115:mdna:42]
[same as prior period, unchanged from 0000950170-23-067033:mdna:43]

[0000950170-24-023115:mdna:43]
Public Cloud revenues are derived from the sale of public cloud offerings primarily delivered as-a-service, which include cloud storage and CloudOps services.

[0000950170-24-023115:mdna:44]
Public Cloud revenues increased in the third quarter and first nine months of fiscal 2024 compared to the corresponding periods of the prior year primarily due to customer demand for NetApp’s diversified cloud offerings, coupled with overall growth in the cloud market.

[0000950170-24-023115:mdna:45]
[same as prior period, unchanged from 0000950170-23-067033:mdna:46]

[0000950170-24-023115:mdna:46]
[same as prior period, unchanged from 0000950170-23-067033:mdna:47]

[0000950170-24-023115:mdna:47]
[same as prior period, unchanged from 0000950170-23-067033:mdna:48]

[0000950170-24-023115:mdna:48]
[same as prior period, unchanged from 0000950170-23-067033:mdna:49]

[0000950170-24-023115:mdna:49]
[same as prior period, unchanged from 0000950170-23-067033:mdna:50]

[0000950170-24-023115:mdna:50]
[same as prior period, unchanged from 0000950170-23-067033:mdna:51]

[0000950170-24-023115:mdna:51]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |
| Cost of product revenues |  | $ | 282 |  |  | $ | 367 |  |  |  | (23 | )% |  | $ | 823 |  |  | $ | 1,182 |  |  |  | (30 | )% |
| Hybrid Cloud |  |  | 280 |  |  |  | 365 |  |  |  | (23 | )% |  |  | 819 |  |  |  | 1,177 |  |  |  | (30 | )% |
| Unallocated |  |  | 2 |  |  |  | 2 |  |  |  | — | % |  |  | 4 |  |  |  | 5 |  |  |  | (20 | )% |

[0000950170-24-023115:mdna:52]
[same as prior period, unchanged from 0000950170-23-067033:mdna:53]

[0000950170-24-023115:mdna:53]
Cost of Hybrid Cloud product revenues represented approximately 37% and 40% of product revenues for the third quarter and first nine months of fiscal 2024 compared to 54% and 51% for the corresponding periods of fiscal 2023. Materials costs represented 89% and 88% of cost of Hybrid Cloud product revenues for the third quarter and first nine months of fiscal 2024, compared to 94% for the corresponding periods of fiscal 2023.

[0000950170-24-023115:mdna:54]
Materials costs decreased by approximately $94 million and $386 million in the third quarter and first nine months of fiscal 2024 compared to the corresponding periods of the prior year, reflecting lower component and freight costs as a result of supply chain improvements. Materials costs were also impacted by the increase in product revenues in the third quarter of fiscal 2024, and the decrease in product revenues in the first nine months of fiscal 2024, compared to the corresponding periods of the prior year.

[0000950170-24-023115:mdna:55]
Hybrid Cloud product gross margins increased by approximately sixteen percentage points and eleven percentage points in the third quarter and first nine months of fiscal 2024, compared to the corresponding periods of the prior year, primarily due to lower component and freight costs.

[0000950170-24-023115:mdna:56]
[same as prior period, unchanged from 0000950170-23-067033:mdna:57]

[0000950170-24-023115:mdna:57]
Unallocated cost of product revenues were relatively flat in the third quarter and first nine months of fiscal 2024 compared to the corresponding periods of the prior year.

[0000950170-24-023115:mdna:58]
[same as prior period, unchanged from 0000950170-23-067033:mdna:59]

[0000950170-24-023115:mdna:59]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |
| Cost of services revenues |  | $ | 173 |  |  | $ | 158 |  |  |  | 9 | % |  | $ | 520 |  |  | $ | 465 |  |  |  | 12 | % |
| Support |  |  | 49 |  |  |  | 44 |  |  |  | 11 | % |  |  | 146 |  |  |  | 132 |  |  |  | 11 | % |
| Professional and other services |  |  | 58 |  |  |  | 50 |  |  |  | 16 | % |  |  | 176 |  |  |  | 156 |  |  |  | 13 | % |
| Public cloud |  |  | 52 |  |  |  | 47 |  |  |  | 11 | % |  |  | 155 |  |  |  | 132 |  |  |  | 17 | % |
| Unallocated |  |  | 14 |  |  |  | 17 |  |  |  | (18 | )% |  |  | 43 |  |  |  | 45 |  |  |  | (4 | )% |

[0000950170-24-023115:mdna:60]
[same as prior period, unchanged from 0000950170-23-067033:mdna:61]

[0000950170-24-023115:mdna:61]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, increased in the third quarter and first nine months of fiscal 2024 compared to the corresponding periods of fiscal 2023. Cost of Hybrid Cloud services revenues represented approximately 15% of Hybrid Cloud services revenues in the third quarter and first nine months of fiscal 2024, compared to 14% for the corresponding periods of fiscal 2023.

[0000950170-24-023115:mdna:62]
[same as prior period, unchanged from 0000950170-23-067033:mdna:63]

[0000950170-24-023115:mdna:63]
Hybrid Cloud support gross margins decreased by less than one percentage point in the third quarter and first nine months of fiscal 2024 compared to the corresponding periods of the prior year. Hybrid Cloud professional and other services gross margins decreased by approximately eleven percentage points and eight percentage points in the third quarter and first nine months of fiscal 2024 compared to the corresponding periods of fiscal 2023, due to the mix of services provided.

[0000950170-24-023115:mdna:64]
[same as prior period, unchanged from 0000950170-23-067033:mdna:65]

[0000950170-24-023115:mdna:65]
Cost of Public Cloud revenues increased in the third quarter and first nine months of fiscal 2024 compared to the corresponding periods of fiscal 2023 reflecting the increase in Public Cloud revenues. Public Cloud gross margins decreased by three percentage points in the third quarter and first nine months of fiscal 2024 compared to the corresponding periods of fiscal 2023, primarily due to the mix of offerings provided.

[0000950170-24-023115:mdna:66]
[same as prior period, unchanged from 0000950170-23-067033:mdna:67]

[0000950170-24-023115:mdna:67]
Unallocated cost of services revenues decreased in the third quarter and first nine months of fiscal 2024 compared to the corresponding periods of the prior year due to certain intangible assets becoming fully amortized during the first quarter of fiscal 2024.

[0000950170-24-023115:mdna:68]
[same as prior period, unchanged from 0000950170-23-067033:mdna:69]

[0000950170-24-023115:mdna:69]
[same as prior period, unchanged from 0000950170-23-067033:mdna:70]

[0000950170-24-023115:mdna:70]
Sales and marketing, research and development, and general and administrative expenses for the third quarter of fiscal 2024 totaled $769 million, or 48% of net revenues, relatively consistent with the corresponding period of fiscal 2023.

[0000950170-24-023115:mdna:71]
Sales and marketing, research and development, and general and administrative expenses for the first nine months of fiscal 2024 totaled $2,356 million, or 51% of net revenues, respectively, reflecting an increase of three percentage points, compared to the corresponding periods of fiscal 2023, primarily due to the decrease in net revenues.

[0000950170-24-023115:mdna:72]
[same as prior period, unchanged from 0000950170-23-067033:mdna:72]

[0000950170-24-023115:mdna:73]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses increased by $32 million, or 7%, and $83 million, or 6%, in the third quarter and first nine months of fiscal 2024, respectively, compared to the corresponding periods of the prior year, primarily due to an increase in incentive compensation expense. This increase was partially offset by lower salaries expense, reflecting average headcount decreases of 11% and 8%, respectively.

[0000950170-24-023115:mdna:74]
[same as prior period, unchanged from 0000950170-23-067033:mdna:74]

[0000950170-24-023115:mdna:75]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 439 |  |  | $ | 450 |  |  |  | (2 | )% |  | $ | 1,368 |  |  | $ | 1,387 |  |  |  | (1 | )% |

[0000950170-24-023115:mdna:76]
[same as prior period, unchanged from 0000950170-23-067033:mdna:76]

[0000950170-24-023115:mdna:77]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2024 to Fiscal 2023 |  |  | Fiscal 2024 to Fiscal 2023 |  |
| Commissions |  |  | (1 | ) |  |  | (2 | ) |
| Other |  |  | (1 | ) |  |  | 1 |  |
| Total change |  |  | (2 | ) |  |  | (1 | ) |

[0000950170-24-023115:mdna:78]
The decrease in commissions expense for the third quarter and first nine months of fiscal 2024 compared to the corresponding periods of the prior year was primarily due to lower performance against sales goals.

[0000950170-24-023115:mdna:79]
[same as prior period, unchanged from 0000950170-23-067033:mdna:81]

[0000950170-24-023115:mdna:80]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |
| Research and development expenses |  | $ | 249 |  |  | $ | 230 |  |  |  | 8 | % |  | $ | 758 |  |  | $ | 713 |  |  |  | 6 | % |

[0000950170-24-023115:mdna:81]
[same as prior period, unchanged from 0000950170-23-067033:mdna:83]

[0000950170-24-023115:mdna:82]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2024 to Fiscal 2023 |  |  | Fiscal 2024 to Fiscal 2023 |  |
| Compensation costs |  |  | 9 |  |  |  | 7 |  |
| Development projects and outside services |  |  | (1 | ) |  |  | (1 | ) |
| Total change |  |  | 8 |  |  |  | 6 |  |

[0000950170-24-023115:mdna:83]
The increase in compensation costs for the third quarter and first nine months of fiscal 2024 compared to the corresponding periods in the prior year was primarily attributable to higher incentive compensation expenses and stock-based compensation, partially offset by lower salaries expense, reflecting decreases in average headcount of 10% and 7%, respectively.

[0000950170-24-023115:mdna:84]
The decrease in development projects and outside services for the third quarter and first nine months of fiscal 2024 compared to the corresponding periods in the prior year was primarily due to the lower spending on certain engineering projects.

[0000950170-24-023115:mdna:85]
[same as prior period, unchanged from 0000950170-23-067033:mdna:87]

[0000950170-24-023115:mdna:86]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |
| General and administrative expenses |  | $ | 81 |  |  | $ | 59 |  |  |  | 37 | % |  | $ | 230 |  |  | $ | 198 |  |  |  | 16 | % |

[0000950170-24-023115:mdna:87]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and facilities and IT support costs.

[0000950170-24-023115:mdna:88]
The increases in general and administrative expenses in the third quarter and the first nine months of fiscal 2024 compared to the corresponding periods of the prior year were primarily attributable to increases in all components of compensation costs, but predominantly incentive compensation expenses. Higher spending levels on projects and outside services also contributed to the increases.

[0000950170-24-023115:mdna:89]
[same as prior period, unchanged from 0000950170-23-067033:mdna:92]

[0000950170-24-023115:mdna:90]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |
| Restructuring charges |  | $ | 13 |  |  | $ | 87 |  |  |  | (85 | )% |  | $ | 44 |  |  | $ | 109 |  |  |  | (60 | )% |

[0000950170-24-023115:mdna:91]
In each of the first and third quarters of fiscal 2024, management approved a restructuring plan to redirect resources to highest return activities and reduce costs. Each plan included a global workforce reduction of approximately 1% for which restructuring charges, comprised of employee severance related expenses, were recorded during the first nine months of fiscal 2024. The plan initiated during the first quarter also included optimization of our global office space for our hybrid work model. In connection with that plan, we terminated certain real estate leases in various countries during the first nine months of fiscal 2024, resulting in restructuring charges primarily comprised of lease termination charges. The activities under these plans are expected to be substantially complete by the end of fiscal 2024..

[0000950170-24-023115:mdna:92]
[same as prior period, unchanged from 0000950170-23-067033:mdna:95]

[0000950170-24-023115:mdna:93]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |
| Acquisition-related expense |  | $ | 3 |  |  | $ | 3 |  |  |  | — | % |  | $ | 9 |  |  | $ | 18 |  |  |  | (50 | )% |

[0000950170-24-023115:mdna:94]
Acquisition-related expenses for the third quarter and first nine months of fiscal 2024 totaled $3 million and $9 million, respectively, and were primarily related to our integration of previous acquisitions.

[0000950170-24-023115:mdna:95]
[same as prior period, unchanged from 0000950170-23-067033:mdna:98]

[0000950170-24-023115:mdna:96]
[same as prior period, unchanged from 0000950170-23-067033:mdna:99]

[0000950170-24-023115:mdna:97]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |
| Interest income |  | $ | 27 |  |  | $ | 21 |  |  |  | 29 | % |  | $ | 80 |  |  | $ | 42 |  |  |  | 90 | % |
| Interest expense |  |  | (17 | ) |  |  | (16 | ) |  |  | 6 | % |  |  | (48 | ) |  |  | (51 | ) |  |  | (6 | )% |
| Other, net |  |  | 6 |  |  |  | — |  |  | NM |  |  |  | 3 |  |  |  | 52 |  |  | NM |  |
| Total |  | $ | 16 |  |  | $ | 5 |  |  | NM |  |  | $ | 35 |  |  | $ | 43 |  |  | NM |  |

[0000950170-24-023115:mdna:98]
[same as prior period, unchanged from 0000950170-23-067033:mdna:101]

[0000950170-24-023115:mdna:99]
Interest income increased in the third quarter and first nine months of fiscal 2024 compared to the corresponding periods of the prior year primarily due to higher yields earned on our cash and investments. Interest expense was relatively flat in the third quarter of fiscal 2024 compared to the corresponding period of fiscal 2023, while it decreased in the first nine months of fiscal 2024 compared to the corresponding period of fiscal 2023 due to the extinguishment of certain senior notes in the second quarter of fiscal 2023.

[0000950170-24-023115:mdna:100]
Other, net for the first nine months of fiscal 2023 includes $21 million of other income for non-refundable, up-front payments from customers in Russia for support contracts, which we were not able to fulfill due to imposed sanctions and for which we have no remaining legal obligation to perform. It also includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million. The remaining differences in Other, net for the third quarter and first nine months of fiscal 2024 as compared to the corresponding periods of the prior year are partially due to foreign exchange gains and losses year-over-year.

[0000950170-24-023115:mdna:101]
[same as prior period, unchanged from 0000950170-23-067033:mdna:104]

[0000950170-24-023115:mdna:102]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | % Change |  |
| Provision (benefit) for income taxes |  | $ | 69 |  |  | $ | 112 |  |  |  | (38 | )% |  | $ | 188 |  |  | $ | (277 | ) |  |  | (168 | )% |

[0000950170-24-023115:mdna:103]
Our effective tax rate for the three and nine months ended January 26, 2024 includes a benefit for increased fiscal 2024 foreign tax credits, partially offset by an increase in stock compensation for which no tax benefit is recorded. The effective tax rate for the three months ended January 27, 2023, includes a discrete tax expense recorded as a result of the Danish Supreme Court ruling received on January 9, 2023. The effective tax rate for the nine months ended January 27, 2023, includes a discrete tax expense recorded as a result of the Danish Supreme Court ruling that was fully offset by a discrete tax benefit resulting from an intra-entity asset transfer of certain intellectual property (“IP”).

[0000950170-24-023115:mdna:104]
During the second quarter of fiscal 2023, we completed an intra-entity asset transfer of certain IP to our international headquarters (the “IP Transfer”). The transaction resulted in a step-up of tax-deductible basis in the transferred assets, and accordingly, created a temporary difference where the tax basis exceeded the financial statement basis of such intangible assets, which resulted in the recognition of a discrete tax benefit and related deferred tax asset of $524 million during the second quarter of fiscal 2023. Management applied significant judgment when determining the fair value of the IP, which serves as the tax basis of the deferred tax asset. With the assistance of third-party valuation specialists, the fair value of the IP was determined principally based on the present value of projected cash flows related to the IP which reflects management’s assumptions regarding projected revenues, expenses and a discount rate. The tax-deductible amortization related to the transferred IP rights will be recognized in future periods and any amortization that is unused in a particular year can be carried forward indefinitely. The deferred tax asset and the tax benefit were measured based on the enacted tax rates expected to apply in the years the asset is expected to be realized. We expect to realize the deferred tax asset resulting from the IP Transfer and will assess the realizability of the deferred tax asset quarterly. Any Organisation for Economic Co-operation and Development’s (“OECD”) actions adopted internationally, could impact our financial results in future periods. The impact of the transaction to net cash provided by or used in operating, investing and financing activities on the condensed consolidated statements of cash flows during the quarter ended October 28, 2022, was not material.

[0000950170-24-023115:mdna:105]
During the third quarter of fiscal 2023, the Danish Supreme Court issued a non-appealable ruling on the distributions declared in 2005 and 2006. The Danish Supreme Court ruled the 2005 dividend was subject to at-source dividend withholding tax while the

[0000950170-24-023115:mdna:106]
smaller 2006 distribution would not be subject to withholding tax. We recorded $69 million of tax expense, which includes $23 million of withholding tax and $46 million of interest, associated with the Danish Supreme Court ruling as a discrete item during the quarter ended January 27, 2023.

[0000950170-24-023115:mdna:107]
As of January 26, 2024, we had $225 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $152 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $152 million have been recorded in other long-term liabilities.

[0000950170-24-023115:mdna:108]
[same as prior period, unchanged from 0000950170-23-067033:mdna:110]

[0000950170-24-023115:mdna:109]
| (In millions) |  | January 26, 2024 |  |  | April 28, 2023 |  |
| Cash, cash equivalents and short-term investments |  | $ | 2,917 |  |  | $ | 3,070 |  |
| Principal amount of debt |  | $ | 2,400 |  |  | $ | 2,400 |  |

[0000950170-24-023115:mdna:110]
[same as prior period, unchanged from 0000950170-23-067033:mdna:112]

[0000950170-24-023115:mdna:111]
|  |  | Nine Months Ended |  |
| (In millions) |  | January 26, 2024 |  |  | January 27, 2023 |  |
| Net cash provided by operating activities |  | $ | 1,072 |  |  | $ | 872 |  |
| Net cash used in investing activities |  |  | (438 | ) |  |  | (1,105 | ) |
| Net cash used in financing activities |  |  | (1,120 | ) |  |  | (1,244 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (10 | ) |  |  | 4 |  |
| Net change in cash, cash equivalents and restricted cash |  | $ | (496 | ) |  | $ | (1,473 | ) |

[0000950170-24-023115:mdna:112]
[same as prior period, unchanged from 0000950170-23-067033:mdna:114]

[0000950170-24-023115:mdna:113]
As of January 26, 2024, our cash, cash equivalents and short-term investments were $2.9 billion, which represents a decrease of $153 million during the first nine months of fiscal 2024. The decrease was primarily due to $800 million used for the repurchase of our common stock, $312 million used for the payment of dividends and $109 million used for purchases of property and equipment, partially offset by $1.1 billion provided by operating activities. Net working capital was $562 million as of January 26, 2024, a reduction of $651 million when compared to April 28, 2023, primarily due to the decrease in cash, cash equivalents and short-term investments discussed above and the reclassification of $400 million principal amount of our senior notes from long-term to current liabilities.

[0000950170-24-023115:mdna:114]
[same as prior period, unchanged from 0000950170-23-067033:mdna:116]

[0000950170-24-023115:mdna:115]
During the first nine months of fiscal 2024, we generated cash from operating activities of $1.1 billion, reflecting net income of $695 million which was increased by non-cash depreciation and amortization expense of $191 million and non-cash stock-based compensation expense of $269 million, compared to $872 million of cash generated from operating activities during the first nine months of fiscal 2023.

[0000950170-24-023115:mdna:116]
Significant changes in assets and liabilities in the first nine months of fiscal 2024 included the following:

[0000950170-24-023115:mdna:117]
•
Accounts receivable decreased $195 million, reflecting lower billings and more favorable invoicing linearity in the first nine months of fiscal 2024 compared to the last nine months of fiscal 2023.

[0000950170-24-023115:mdna:118]
•
Deferred revenue and financed unearned services revenue decreased by $160 million, primarily due to a decrease in deferred revenue for software and hardware support contracts.

[0000950170-24-023115:mdna:119]
[same as prior period, unchanged from 0000950170-23-067033:mdna:121]

[0000950170-24-023115:mdna:120]
[same as prior period, unchanged from 0000950170-23-067033:mdna:122]

[0000950170-24-023115:mdna:121]
During the first nine months of fiscal 2024, we used $329 million for the purchases of investments, net of maturities and sales and paid $109 million for capital expenditures, as compared to the same period of fiscal 2023, in which we used $474 million for the purchases of investments, net of maturities and sales, and paid $200 million for capital expenditures. During the first nine months of fiscal 2023, we paid approximately $491 million, net of cash acquired, for a privately-held company, and received proceeds of $59 million from the sale of one of our minority investments.

[0000950170-24-023115:mdna:122]
[same as prior period, unchanged from 0000950170-23-067033:mdna:124]

[0000950170-24-023115:mdna:123]
During the first nine months of fiscal 2024, cash flows used in financing activities totaled $1.1 billion and included $800 million for the repurchase of approximately 11 million shares of common stock and $312 million for the payment of dividends. During the first nine months of fiscal 2023, cash flows used in financing activities totaled $1.2 billion and included $700 million for the repurchase of approximately ten million shares of common stock, $326 million for the payment of dividends and $250 million to redeem our Senior Notes due in December 2022.

[0000950170-24-023115:mdna:124]
[same as prior period, unchanged from 0000950170-23-067033:mdna:126]

[0000950170-24-023115:mdna:125]
[same as prior period, unchanged from 0000950170-23-067033:mdna:127]

[0000950170-24-023115:mdna:126]
Our principal sources of liquidity as of January 26, 2024 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-24-023115:mdna:127]
[same as prior period, unchanged from 0000950170-23-067033:mdna:129]

[0000950170-24-023115:mdna:128]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |
| Cash and cash equivalents |  | $ | 1,820 |  |  | $ | 2,316 |  |
| Short-term investments |  |  | 1,097 |  |  |  | 754 |  |
| Total |  | $ | 2,917 |  |  | $ | 3,070 |  |

[0000950170-24-023115:mdna:129]
As of January 26, 2024 and April 28, 2023, $2.3 billion and $2.2 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.6 billion and $0.9 billion, respectively, were available in the U.S.

[0000950170-24-023115:mdna:130]
[same as prior period, unchanged from 0000950170-23-067033:mdna:132]

[0000950170-24-023115:mdna:131]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of January 26, 2024.

[0000950170-24-023115:mdna:132]
35

[0000950170-24-023115:mdna:133]
[same as prior period, unchanged from 0000950170-23-067033:mdna:134]

[0000950170-24-023115:mdna:134]
[same as prior period, unchanged from 0000950170-23-067033:mdna:135]

[0000950170-24-023115:mdna:135]
The following table summarizes the principal amount of our Senior Notes as of January 26, 2024 (in millions):

[0000950170-24-023115:mdna:136]
|  |  | Amount |  |
| 3.30% Senior Notes Due September 2024 |  | $ | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,400 |  |

[0000950170-24-023115:mdna:137]
[same as prior period, unchanged from 0000950170-23-067033:mdna:138]

[0000950170-24-023115:mdna:138]
Commercial Paper Program and Credit Facility

[0000950170-24-023115:mdna:139]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of January 26, 2024.

[0000950170-24-023115:mdna:140]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023 primarily to replace the London Interbank Offered Rate (LIBOR) with the Secured Overnight Financing Rate (SOFR) as the basis for establishing the interest rate applicable to certain borrowings under the agreement, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 26, 2024, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-24-023115:mdna:141]
[same as prior period, unchanged from 0000950170-23-067033:mdna:142]

[0000950170-24-023115:mdna:142]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2024 to be between $25 million and $75 million.

[0000950170-24-023115:mdna:143]
[same as prior period, unchanged from 0000950170-23-067033:mdna:144]

[0000950170-24-023115:mdna:144]
The Tax Cuts and Jobs Act of 2017 imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits that had not previously been subject to U.S. income tax. As of January 26, 2024, outstanding payments related to the transition tax are estimated to be approximately $215 million of which $115 million and $100 million are expected to be paid during fiscal 2025 and fiscal 2026, respectively. Our estimates for future transition tax payments, however, could change with further guidance or review from U.S. federal and state tax authorities or other regulatory bodies.

[0000950170-24-023115:mdna:145]
[same as prior period, unchanged from 0000950170-23-067033:mdna:146]

[0000950170-24-023115:mdna:146]
On February 22, 2024, we declared a cash dividend of $0.50 per share of common stock, payable on April 24, 2024, to holders of record as of the close of business on April 5, 2024.

[0000950170-24-023115:mdna:147]
As of January 26, 2024, our Board of Directors had authorized the repurchase of up to $16.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through January 26, 2024, we repurchased a total of 371 million shares of our common stock at an average price of $41.89 per share, for an aggregate purchase price of $15.5 billion. As of January 26, 2024, the remaining authorized amount for stock repurchases under this program was $0.6 billion.

[0000950170-24-023115:mdna:148]
[same as prior period, unchanged from 0000950170-23-067033:mdna:149]

[0000950170-24-023115:mdna:149]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled approximately $0.8 billion at January 26, 2024.

[0000950170-24-023115:mdna:150]
[same as prior period, unchanged from 0000950170-23-067033:mdna:151]

[0000950170-24-023115:mdna:151]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $58 million and $32 million of receivables during the first nine months of fiscal 2024 and fiscal 2023, respectively.

[0000950170-24-023115:mdna:152]
[same as prior period, unchanged from 0000950170-23-067033:mdna:153]

[0000950170-24-023115:mdna:153]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of January 26, 2024 and April 28, 2023, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-24-023115:mdna:154]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of January 26, 2024, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-24-023115:mdna:155]
Legal Contingencies

[0000950170-24-023115:mdna:156]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0000950170-24-023115:mdna:157]
[same as prior period, unchanged from 0000950170-23-067033:mdna:158]

[0000950170-24-023115:mdna:158]
[same as prior period, unchanged from 0000950170-23-067033:mdna:159]

[0000950170-24-023115:mdna:159]
37

[0000950170-24-023115:mdna:160]
[same as prior period, unchanged from 0000950170-23-067033:mdna:160]

[0000950170-24-023115:mdna:161]
38
