# NTAP notes — 0000950170-24-023115


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000950170-24-023115:notes:1]
[same as prior period, unchanged from 0000950170-23-067033:notes:1]

[0000950170-24-023115:notes:2]
NetApp, Inc. (we, us, NetApp, or the Company) makes data infrastructure intelligent by combining unified data storage, integrated data services, and CloudOps solutions. NetApp creates silo-free infrastructure, harnessing observability and artificial intelligence to enable seamless data management. We provide a full range of enterprise-class software, systems and services that customers use to transform their data infrastructures across data types, workloads, and environments to realize business possibilities.

[0000950170-24-023115:notes:3]
[same as prior period, unchanged from 0000950170-23-067033:notes:3]

[0000950170-24-023115:notes:4]
[same as prior period, unchanged from 0000950170-23-067033:notes:4]

[0000950170-24-023115:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 28, 2023 contained in our Annual Report on Form 10-K. The results of operations for the three and nine months ended January 26, 2024 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0000950170-24-023115:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, the anticipated effects of which have been incorporated, as applicable, into management's estimates as of January 26, 2024.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000950170-24-023115:notes:7]
2. Recent Accounting Pronouncements

[0000950170-24-023115:notes:8]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which expands the disclosures required for income taxes. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The amendment should be applied on a prospective basis while retrospective application is permitted. We are currently evaluating the effect of this pronouncement on our income tax disclosures.

[0000950170-24-023115:notes:9]
Although there are other new accounting pronouncements issued or proposed by the FASB that we have adopted or will adopt, as applicable, we do not believe any of these accounting pronouncements had or will have a material impact on our consolidated financial position, operating results, cash flows or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-24-023115:notes:10]
[same as prior period, unchanged from 0000950170-23-067033:notes:9]

[0000950170-24-023115:notes:11]
[same as prior period, unchanged from 0000950170-23-067033:notes:10]

[0000950170-24-023115:notes:12]
[same as prior period, unchanged from 0000950170-23-067033:notes:11]

[0000950170-24-023115:notes:13]
[same as prior period, unchanged from 0000950170-23-067033:notes:12]

[0000950170-24-023115:notes:14]
[same as prior period, unchanged from 0000950170-23-067033:notes:13]

[0000950170-24-023115:notes:15]
[same as prior period, unchanged from 0000950170-23-067033:notes:14]

[0000950170-24-023115:notes:16]
[same as prior period, unchanged from 0000950170-23-067033:notes:15]

[0000950170-24-023115:notes:17]
[same as prior period, unchanged from 0000950170-23-067033:notes:16]

[0000950170-24-023115:notes:18]
[same as prior period, unchanged from 0000950170-23-067033:notes:17]

[0000950170-24-023115:notes:19]
[same as prior period, unchanged from 0000950170-23-067033:notes:18]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-24-023115:notes:20]
[same as prior period, unchanged from 0000950170-23-067033:notes:19]

[0000950170-24-023115:notes:21]
Goodwill by reportable segment as of January 26, 2024 is as follows (in millions):

[0000950170-24-023115:notes:22]
[same as prior period, unchanged from 0000950170-23-067033:notes:21]

[0000950170-24-023115:notes:23]
[same as prior period, unchanged from 0000950170-23-067033:notes:22]

[0000950170-24-023115:notes:24]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 179 |  |  | $ | (100 | ) |  | $ | 79 |  |  | $ | 212 |  |  | $ | (107 | ) |  | $ | 105 |  |
| Customer contracts/relationships |  |  | 114 |  |  |  | (56 | ) |  |  | 58 |  |  |  | 118 |  |  |  | (44 | ) |  |  | 74 |  |
| Other purchased intangibles |  |  | 6 |  |  |  | (5 | ) |  |  | 1 |  |  |  | 6 |  |  |  | (4 | ) |  |  | 2 |  |
| Total purchased intangible assets |  | $ | 299 |  |  | $ | (161 | ) |  | $ | 138 |  |  | $ | 336 |  |  | $ | (155 | ) |  | $ | 181 |  |

[0000950170-24-023115:notes:25]
During the first nine months of fiscal 2024, we retired approximately $37 million of fully amortized intangible assets.

[0000950170-24-023115:notes:26]
[same as prior period, unchanged from 0000950170-23-067033:notes:25]

[0000950170-24-023115:notes:27]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Statements of |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | IncomeClassification |
| Developed technology |  | $ | 9 |  |  | $ | 10 |  |  | $ | 26 |  |  | $ | 31 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 5 |  |  |  | 7 |  |  |  | 16 |  |  |  | 19 |  |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  | Operating expenses |
| Total |  | $ | 14 |  |  | $ | 17 |  |  | $ | 43 |  |  | $ | 51 |  |  |  |

[0000950170-24-023115:notes:28]
As of January 26, 2024, future amortization expense related to purchased intangible assets is as follows (in millions):

[0000950170-24-023115:notes:29]
| Fiscal Year |  | Amount |  |
| 2024 (remainder) |  | $ | 14 |  |
| 2025 |  |  | 55 |  |
| 2026 |  |  | 39 |  |
| 2027 |  |  | 29 |  |
| 2028 |  |  | 1 |  |
| Total |  | $ | 138 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-24-023115:notes:30]
[same as prior period, unchanged from 0000950170-23-067033:notes:29]

[0000950170-24-023115:notes:31]
[same as prior period, unchanged from 0000950170-23-067033:notes:30]

[0000950170-24-023115:notes:32]
[same as prior period, unchanged from 0000950170-23-067033:notes:31]

[0000950170-24-023115:notes:33]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |
| Cash and cash equivalents |  | $ | 1,820 |  |  | $ | 2,316 |  |
| Restricted cash |  |  | 6 |  |  |  | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 1,826 |  |  | $ | 2,322 |  |

[0000950170-24-023115:notes:34]
[same as prior period, unchanged from 0000950170-23-067033:notes:33]

[0000950170-24-023115:notes:35]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |
| Purchased components |  | $ | 77 |  |  | $ | 65 |  |
| Finished goods |  |  | 54 |  |  |  | 102 |  |
| Inventories |  | $ | 131 |  |  | $ | 167 |  |

[0000950170-24-023115:notes:36]
[same as prior period, unchanged from 0000950170-23-067033:notes:35]

[0000950170-24-023115:notes:37]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 368 |  |  |  | 359 |  |
| Leasehold improvements |  |  | 81 |  |  |  | 91 |  |
| Computer, production, engineering and other equipment |  |  | 1,104 |  |  |  | 1,053 |  |
| Computer software |  |  | 336 |  |  |  | 325 |  |
| Furniture and fixtures |  |  | 78 |  |  |  | 84 |  |
| Construction-in-progress |  |  | 56 |  |  |  | 55 |  |
|  |  |  | 2,069 |  |  |  | 2,013 |  |
| Accumulated depreciation and amortization |  |  | (1,462 | ) |  |  | (1,363 | ) |
| Property and equipment, net |  | $ | 607 |  |  | $ | 650 |  |

[0000950170-24-023115:notes:38]
[same as prior period, unchanged from 0000950170-23-067033:notes:37]

[0000950170-24-023115:notes:39]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |
| Deferred tax assets |  | $ | 949 |  |  | $ | 948 |  |
| Operating lease right-of-use (ROU) assets |  |  | 252 |  |  |  | 281 |  |
| Other assets |  |  | 337 |  |  |  | 319 |  |
| Other non-current assets |  | $ | 1,538 |  |  | $ | 1,548 |  |

[0000950170-24-023115:notes:40]
Other non-current assets as of January 26, 2024 and April 28, 2023 include $85 million and $80 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies.

[0000950170-24-023115:notes:41]
[same as prior period, unchanged from 0000950170-23-067033:notes:40]

[0000950170-24-023115:notes:42]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |
| Accrued compensation and benefits |  | $ | 412 |  |  | $ | 363 |  |
| Product warranty liabilities |  |  | 18 |  |  |  | 17 |  |
| Operating lease liabilities |  |  | 40 |  |  |  | 47 |  |
| Other current liabilities |  |  | 406 |  |  |  | 430 |  |
| Accrued expenses |  | $ | 876 |  |  | $ | 857 |  |

[0000950170-24-023115:notes:43]
[same as prior period, unchanged from 0000950170-23-067033:notes:42]

[0000950170-24-023115:notes:44]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |
| Liability for uncertain tax positions |  | $ | 152 |  |  | $ | 144 |  |
| Income taxes payable |  |  | 100 |  |  |  | 215 |  |
| Product warranty liabilities |  |  | 9 |  |  |  | 8 |  |
| Operating lease liabilities |  |  | 225 |  |  |  | 248 |  |
| Other liabilities |  |  | 99 |  |  |  | 93 |  |
| Other long-term liabilities |  | $ | 585 |  |  | $ | 708 |  |

[0000950170-24-023115:notes:45]
[same as prior period, unchanged from 0000950170-23-067033:notes:44]

[0000950170-24-023115:notes:46]
[same as prior period, unchanged from 0000950170-23-067033:notes:45]

[0000950170-24-023115:notes:47]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |
| Deferred product revenue |  | $ | 41 |  |  | $ | 18 |  |
| Deferred services revenue |  |  | 4,035 |  |  |  | 4,247 |  |
| Financed unearned services revenue |  |  | 51 |  |  |  | 48 |  |
| Total |  | $ | 4,127 |  |  | $ | 4,313 |  |
| Reported as: |  |  |  |  |  |  |
| Short-term |  | $ | 2,093 |  |  | $ | 2,218 |  |
| Long-term |  |  | 2,034 |  |  |  | 2,095 |  |
| Total |  | $ | 4,127 |  |  | $ | 4,313 |  |

[0000950170-24-023115:notes:48]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 15 – Commitments and Contingencies for additional information related to these arrangements.

[0000950170-24-023115:notes:49]
During the nine months ended January 26, 2024 and January 27, 2023, we recognized revenue of $1,725 million and $1,751 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0000950170-24-023115:notes:50]
As of January 26, 2024, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied approximated our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as

[0000950170-24-023115:notes:51]
revenue approximately 51% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 24% in the next 13 to 24 months, and the remainder thereafter.

[0000950170-24-023115:notes:52]
[same as prior period, unchanged from 0000950170-23-067033:notes:50]

[0000950170-24-023115:notes:53]
[same as prior period, unchanged from 0000950170-23-067033:notes:51]

[0000950170-24-023115:notes:54]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |
| Other current assets |  | $ | 66 |  |  | $ | 64 |  |
| Other non-current assets |  |  | 97 |  |  |  | 99 |  |
| Total deferred commissions |  | $ | 163 |  |  | $ | 163 |  |

[0000950170-24-023115:notes:55]
[same as prior period, unchanged from 0000950170-23-067033:notes:53]

[0000950170-24-023115:notes:56]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | January 26, 2024 |  |  | January 27, 2023 |  |
| Interest income |  | $ | 27 |  |  | $ | 21 |  |  | $ | 80 |  |  | $ | 42 |  |
| Interest expense |  |  | (17 | ) |  |  | (16 | ) |  |  | (48 | ) |  |  | (51 | ) |
| Other, net |  |  | 6 |  |  |  | — |  |  |  | 3 |  |  |  | 52 |  |
| Total other income, net |  | $ | 16 |  |  | $ | 5 |  |  | $ | 35 |  |  | $ | 43 |  |

[0000950170-24-023115:notes:57]
In the nine months ended January 27, 2023, Other, net includes $21 million of other income for non-refundable, up-front payments from customers in Russia for support contracts, which we were not able to fulfill due to imposed sanctions and for which we have no remaining legal obligation to perform. It also includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million in the first quarter of fiscal 2023.

[0000950170-24-023115:notes:58]
[same as prior period, unchanged from 0000950170-23-067033:notes:56]

[0000950170-24-023115:notes:59]
[same as prior period, unchanged from 0000950170-23-067033:notes:57]

[0000950170-24-023115:notes:60]
|  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 14 |  |  | $ | 19 |  |  |  |
| Liabilities incurred to former owners of acquired business |  | $ | — |  |  | $ | 3 |  |  |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 294 |  |  | $ | 290 |  |  |  |
| Interest paid |  | $ | 53 |  |  | $ | 59 |  |  |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-24-023115:notes:61]
[same as prior period, unchanged from 0000950170-23-067033:notes:59]

[0000950170-24-023115:notes:62]
[same as prior period, unchanged from 0000950170-23-067033:notes:60]

[0000950170-24-023115:notes:63]
[same as prior period, unchanged from 0000950170-23-067033:notes:61]

[0000950170-24-023115:notes:64]
[same as prior period, unchanged from 0000950170-23-067033:notes:62]

[0000950170-24-023115:notes:65]
[same as prior period, unchanged from 0000950170-23-067033:notes:63]

[0000950170-24-023115:notes:66]
[same as prior period, unchanged from 0000950170-23-067033:notes:64]

[0000950170-24-023115:notes:67]
[same as prior period, unchanged from 0000950170-23-067033:notes:65]

[0000950170-24-023115:notes:68]
The following is a summary of our investments at their cost or amortized cost as of January 26, 2024 and April 28, 2023 (in millions):

[0000950170-24-023115:notes:69]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |  |
| U.S. Treasury and government debt securities |  |  | 1,097 |  |  |  | 754 |  |  |
| Money market funds |  |  | 728 |  |  |  | 794 |  |  |
| Certificates of deposit |  |  | 42 |  |  |  | 59 |  |  |
| Mutual funds |  |  | 38 |  |  |  | 36 |  |  |
| Total debt and equity securities |  | $ | 1,905 |  |  | $ | 1,643 |  |  |

[0000950170-24-023115:notes:70]
[same as prior period, unchanged from 0000950170-23-067033:notes:68]

[0000950170-24-023115:notes:71]
As of January 26, 2024, all our debt investments are due to mature in one year or less.

[0000950170-24-023115:notes:72]
[same as prior period, unchanged from 0000950170-23-067033:notes:70]

[0000950170-24-023115:notes:73]
[same as prior period, unchanged from 0000950170-23-067033:notes:71]

[0000950170-24-023115:notes:74]
|  |  | January 26, 2024 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 1,050 |  |  | $ | 1,050 |  |  | $ | — |  |
| Money market funds |  |  | 728 |  |  |  | 728 |  |  |  | — |  |
| Certificates of deposit |  |  | 42 |  |  |  | — |  |  |  | 42 |  |
| Total cash and cash equivalents |  |  | 1,820 |  |  |  | 1,778 |  |  |  | 42 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 1,097 |  |  |  | 1,097 |  |  |  | — |  |
| Total short-term investments |  |  | 1,097 |  |  |  | 1,097 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 2,917 |  |  | $ | 2,875 |  |  | $ | 42 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 32 |  |  | $ | 32 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (12 | ) |  | $ | — |  |  | $ | (12 | ) |

[0000950170-24-023115:notes:75]
[same as prior period, unchanged from 0000950170-23-067033:notes:73]

[0000950170-24-023115:notes:76]
[same as prior period, unchanged from 0000950170-23-067033:notes:74]

[0000950170-24-023115:notes:77]
[same as prior period, unchanged from 0000950170-23-067033:notes:75]

[0000950170-24-023115:notes:78]
[same as prior period, unchanged from 0000950170-23-067033:notes:76]

[0000950170-24-023115:notes:79]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of January 26, 2024 and April 28, 2023, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0000950170-24-023115:notes:80]
[same as prior period, unchanged from 0000950170-23-067033:notes:78]

[0000950170-24-023115:notes:81]
As of January 26, 2024 and April 28, 2023, the fair value of our long-term debt was approximately $2,228 million and $2,206 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0000950170-24-023115:notes:82]
7. Financing Arrangements

[0000950170-24-023115:notes:83]
Long-Term Debt

[0000950170-24-023115:notes:84]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0000950170-24-023115:notes:85]
|  |  | Effective Interest Rate |  | January 26, 2024 |  |  | April 28, 2023 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  | $ | 400 |  |  | $ | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,400 |  |  |  | 2,400 |  |
| Unamortized discount and issuance costs |  |  |  |  | (9 | ) |  |  | (11 | ) |
| Total senior notes |  |  |  |  | 2,391 |  |  |  | 2,389 |  |
| Less: Current portion of long-term debt |  |  |  |  | (400 | ) |  |  | — |  |
| Total long-term debt |  |  |  | $ | 1,991 |  |  | $ | 2,389 |  |

[0000950170-24-023115:notes:86]
Senior Notes

[0000950170-24-023115:notes:87]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were each issued in June 2020. Interest on each of these Senior Notes is payable semi-annually in June and December. Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September.

[0000950170-24-023115:notes:88]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0000950170-24-023115:notes:89]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 26, 2024, we were in compliance with all covenants associated with the Senior Notes.

[0000950170-24-023115:notes:90]
As of January 26, 2024, our aggregate future principal debt maturities are as follows (in millions):

[0000950170-24-023115:notes:91]
| Fiscal Year |  | Amount |  |
| 2024 (remainder) |  | $ | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| 2027 |  |  | — |  |
| 2028 |  |  | 550 |  |
| Thereafter |  |  | 700 |  |
| Total |  | $ | 2,400 |  |

[0000950170-24-023115:notes:92]
Commercial Paper Program and Credit Facility

[0000950170-24-023115:notes:93]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of January 26, 2024 or April 28, 2023.

[0000950170-24-023115:notes:94]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023 primarily to replace the London Interbank Offered Rate (LIBOR) with the Secured Overnight Financing Rate (SOFR) as the basis for establishing the interest rate applicable to certain borrowings under the agreement, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of January 26, 2024, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0000950170-24-023115:notes:95]
[same as prior period, unchanged from 0000950170-23-067033:notes:93]

[0000950170-24-023115:notes:96]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of January 26, 2024, have remaining lease terms not exceeding 19 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of January 26, 2024, have remaining lease terms not exceeding 4 years. As of January 26, 2024, our automobile leases have remaining lease terms not exceeding 4 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0000950170-24-023115:notes:97]
[same as prior period, unchanged from 0000950170-23-067033:notes:95]

[0000950170-24-023115:notes:98]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | January 26, 2024 |  |  | January 27, 2023 |  |
| Operating lease cost |  | $ | 13 |  |  | $ | 15 |  |  | $ | 41 |  |  | $ | 46 |  |
| Variable lease cost |  |  | 3 |  |  |  | 4 |  |  |  | 11 |  |  |  | 12 |  |
| Total lease cost |  | $ | 16 |  |  | $ | 19 |  |  | $ | 52 |  |  | $ | 58 |  |

[0000950170-24-023115:notes:99]
[same as prior period, unchanged from 0000950170-23-067033:notes:97]

[0000950170-24-023115:notes:100]
[same as prior period, unchanged from 0000950170-23-067033:notes:98]

[0000950170-24-023115:notes:101]
|  |  |  |  | Nine Months Ended |  |
|  |  |  |  |  |  | January 26, 2024 |  |  | January 27, 2023 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  |  |  |  |  | $ | 38 |  |  | $ | 41 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  |  |  |  |  | $ | 15 |  |  | $ | 33 |  |

[0000950170-24-023115:notes:102]
[same as prior period, unchanged from 0000950170-23-067033:notes:100]

[0000950170-24-023115:notes:103]
|  |  |  |  |  |  | January 26, 2024 |  |  | April 28, 2023 |  |
| Other non-current assets |  |  |  |  |  | $ | 252 |  |  | $ | 281 |  |
| Total operating lease ROU assets |  |  |  |  |  | $ | 252 |  |  | $ | 281 |  |
| Accrued expenses |  |  |  |  |  | $ | 40 |  |  | $ | 47 |  |
| Other long-term liabilities |  |  |  |  |  |  | 225 |  |  |  | 248 |  |
| Total operating lease liabilities |  |  |  |  |  | $ | 265 |  |  | $ | 295 |  |
| Weighted Average Remaining Lease Term |  |  |  |  |  | 9.4 years |  |  | 9.4 years |  |
| Weighted Average Discount Rate |  |  |  |  |  |  | 3.1 | % |  |  | 3.0 | % |

[0000950170-24-023115:notes:104]
Future minimum operating lease payments as of January 26, 2024, are as follows (in millions):

[0000950170-24-023115:notes:105]
| Fiscal Year |  |  |  |  |  | Amount |  |
| 2024 (remainder) |  |  |  |  |  | $ | 12 |  |
| 2025 |  |  |  |  |  |  | 43 |  |
| 2026 |  |  |  |  |  |  | 37 |  |
| 2027 |  |  |  |  |  |  | 33 |  |
| 2028 |  |  |  |  |  |  | 29 |  |
| Thereafter |  |  |  |  |  |  | 154 |  |
| Total lease payments |  |  |  |  |  |  | 308 |  |
| Less: Interest |  |  |  |  |  |  | (43 | ) |
| Total |  |  |  |  |  | $ | 265 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000950170-24-023115:notes:106]
[same as prior period, unchanged from 0000950170-23-067033:notes:104]

[0000950170-24-023115:notes:107]
[same as prior period, unchanged from 0000950170-23-067033:notes:105]

[0000950170-24-023115:notes:108]
We granted approximately 5 million restricted stock units (RSUs), including performance-based RSUs (PBRSUs), with a weighted average grant date fair value of $75.27 per share during the nine months ended January 26, 2024.

[0000950170-24-023115:notes:109]
[same as prior period, unchanged from 0000950170-23-067033:notes:107]

[0000950170-24-023115:notes:110]
awards. The modification resulted in the elimination of the $4 million liability related to these awards, with a corresponding increase to additional paid-in capital, as presented on the Statements of Stockholders' Equity for the nine months ended January 26, 2024.

[0000950170-24-023115:notes:111]
In the nine months ended January 26, 2024, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSUs cliff-vest at the end of a three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the third fiscal year, following the grant date. The number of shares that will be used to calculate the settlement amount for all of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the nine months ended January 26, 2024, the number of shares used to calculate the settlement amount will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. For the remaining half of the PBRSUs granted in the nine months ended January 26, 2024, the number of shares used to calculate the settlement amount will depend upon the Company's billings result average over the three-year performance period. The billings result average is computed based on achievement against annual billings targets, with each target set at the beginning of the respective fiscal year, during the three-year performance period. Billings for purposes of measuring the performance of these PBRSUs means the total obtained by adding net revenues as reported on the Company's Consolidated Statements of Income to the amount reported as the change in deferred revenue and financed unearned services revenue on the Consolidated Statements of Cash Flows for the applicable measurement period, excluding the impact of fluctuations in foreign currency exchange rates. The aggregate grant date fair value of PBRSUs effectively granted in the current year was $39 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0000950170-24-023115:notes:112]
[same as prior period, unchanged from 0000950170-23-067033:notes:110]

[0000950170-24-023115:notes:113]
[same as prior period, unchanged from 0000950170-23-067033:notes:111]

[0000950170-24-023115:notes:114]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | January 26, 2024 |  |  | January 27, 2023 |  |
| Cost of product revenues |  | $ | 2 |  |  | $ | 2 |  |  | $ | 4 |  |  | $ | 4 |  |
| Cost of services revenues |  |  | 5 |  |  |  | 6 |  |  |  | 17 |  |  |  | 14 |  |
| Sales and marketing |  |  | 36 |  |  |  | 40 |  |  |  | 109 |  |  |  | 103 |  |
| Research and development |  |  | 32 |  |  |  | 32 |  |  |  | 99 |  |  |  | 82 |  |
| General and administrative |  |  | 14 |  |  |  | 13 |  |  |  | 40 |  |  |  | 35 |  |
| Total stock-based compensation expense |  | $ | 89 |  |  | $ | 93 |  |  | $ | 269 |  |  | $ | 238 |  |

[0000950170-24-023115:notes:115]
As of January 26, 2024, total unrecognized compensation expense related to equity awards was $653 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.1 years.

[0000950170-24-023115:notes:116]
[same as prior period, unchanged from 0000950170-23-067033:notes:114]

[0000950170-24-023115:notes:117]
As of January 26, 2024, our Board of Directors has authorized the repurchase of up to $16.1 billion of our common stock. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time.

[0000950170-24-023115:notes:118]
The following table summarizes activity related to the stock repurchase program for the nine months ended January 26, 2024 (in millions, except for per share amounts):

[0000950170-24-023115:notes:119]
| Number of shares repurchased |  |  | 11 |  |
| Average price per share |  | $ | 76.03 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 96 |  |
| Stock repurchases allocated to retained earnings |  | $ | 704 |  |
| Remaining authorization at end of period |  | $ | 602 |  |

[0000950170-24-023115:notes:120]
Since the May 13, 2003 inception of our stock repurchase program through January 26, 2024, we repurchased a total of 371 million shares of our common stock at an average price of $41.89 per share, for an aggregate purchase price of $15.5 billion.

[0000950170-24-023115:notes:121]
[same as prior period, unchanged from 0000950170-23-067033:notes:119]

[0000950170-24-023115:notes:122]
[same as prior period, unchanged from 0000950170-23-067033:notes:120]

[0000950170-24-023115:notes:123]
|  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |
| Dividends per share declared |  | $ | 1.50 |  |  | $ | 1.50 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 171 |  |  | $ | 106 |  |
| Dividend payments allocated to retained earnings |  | $ | 141 |  |  | $ | 220 |  |

[0000950170-24-023115:notes:124]
On February 22, 2024, we declared a cash dividend of $0.50 per share of common stock, payable on April 24, 2024 to holders of record as of the close of business on April 5, 2024. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0000950170-24-023115:notes:125]
[same as prior period, unchanged from 0000950170-23-067033:notes:123]

[0000950170-24-023115:notes:126]
[same as prior period, unchanged from 0000950170-23-067033:notes:124]

[0000950170-24-023115:notes:127]
|  |  | ForeignCurrencyTranslationAdjustments |  |  | DefinedBenefitObligationAdjustments |  |  | UnrealizedGains(Losses) onDerivativeInstruments |  |  | Total |  |
| Balance as of April 28, 2023 |  | $ | (48 | ) |  | $ | (3 | ) |  | $ | — |  |  | $ | (51 | ) |
| Other comprehensive income (loss), net of tax |  |  | (3 | ) |  |  | — |  |  |  | 1 |  |  |  | (2 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  | (2 | ) |
| Total other comprehensive loss |  |  | (3 | ) |  |  | — |  |  |  | (1 | ) |  |  | (4 | ) |
| Balance as of January 26, 2024 |  | $ | (51 | ) |  | $ | (3 | ) |  | $ | (1 | ) |  | $ | (55 | ) |

[0000950170-24-023115:notes:128]
[same as prior period, unchanged from 0000950170-23-067033:notes:126]

[0000950170-24-023115:notes:129]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | Statements ofIncome Classification |
| Realized losses (gains) on cash flow hedges |  | $ | 2 |  |  | $ | 6 |  |  | $ | (2 | ) |  | $ | 2 |  |  | Net revenues |
| Total reclassifications |  | $ | 2 |  |  | $ | 6 |  |  | $ | (2 | ) |  | $ | 2 |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-24-023115:notes:130]
[same as prior period, unchanged from 0000950170-23-067033:notes:128]

[0000950170-24-023115:notes:131]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of January 26, 2024 or April 28, 2023. All contracts have a maturity of less than 12 months.

[0000950170-24-023115:notes:132]
[same as prior period, unchanged from 0000950170-23-067033:notes:130]

[0000950170-24-023115:notes:133]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 115 |  |  | $ | 95 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 747 |  |  | $ | 965 |  |
| Forward contracts purchased |  | $ | 38 |  |  | $ | 96 |  |

[0000950170-24-023115:notes:134]
[same as prior period, unchanged from 0000950170-23-067033:notes:132]

[0000950170-24-023115:notes:135]
[same as prior period, unchanged from 0000950170-23-067033:notes:133]

[0000950170-24-023115:notes:136]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | January 26, 2024 |  |  | January 27, 2023 |  |
| Foreign currency exchange contracts |  | $ | 20 |  |  | $ | 58 |  |  | $ | (29 | ) |  | $ | 2 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-24-023115:notes:137]
[same as prior period, unchanged from 0000950170-23-067033:notes:135]

[0000950170-24-023115:notes:138]
In each of the first and third quarters of fiscal 2024, management approved a restructuring plan to redirect resources to highest return activities and reduce costs. Each plan included a global workforce reduction of approximately 1% for which restructuring charges, comprised of employee severance related expenses, were recorded during the first nine months of fiscal 2024. The plan initiated during the first quarter also included optimization of our global office space for our hybrid work model. In connection with that plan, we terminated certain real estate leases in various countries during the first nine months of fiscal 2024, resulting in restructuring charges primarily comprised of lease termination charges. The activities under these plans are expected to be substantially complete by the end of fiscal 2024.

[0000950170-24-023115:notes:139]
In the first nine months of fiscal 2023, we executed, or continued to execute, restructuring plans to redirect resources to highest return activities, reduce costs and establish our international headquarters in Cork, Ireland. These plans collectively reduced our global workforce by approximately 9%, and resulted in restructuring charges comprised primarily of employee severance-related costs and legal and tax-related professional fees. Activities under these plans were substantially complete by the end of fiscal 2023.

[0000950170-24-023115:notes:140]
[same as prior period, unchanged from 0000950170-23-067033:notes:138]

[0000950170-24-023115:notes:141]
|  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |
| Balance at beginning of period |  | $ | 36 |  |  | $ | 3 |  |
| Net charges |  |  | 44 |  |  |  | 109 |  |
| Cash payments |  |  | (60 | ) |  |  | (22 | ) |
| Balance at end of period |  | $ | 20 |  |  | $ | 90 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-24-023115:notes:142]
[same as prior period, unchanged from 0000950170-23-067033:notes:140]

[0000950170-24-023115:notes:143]
[same as prior period, unchanged from 0000950170-23-067033:notes:141]

[0000950170-24-023115:notes:144]
|  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |
| Effective tax rates |  |  | 21.3 | % |  |  | (36.8 | )% |

[0000950170-24-023115:notes:145]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. Our effective tax rate for the nine months ended January 26, 2024 includes a benefit for fiscal 2024 foreign tax credits resulting from Internal Revenue Service Notice 2023-80, partially offset by an increase in stock compensation for which no tax benefit is recorded. The effective tax rate for the nine months ended January 27, 2023 was primarily driven by a discrete tax benefit of $524 million that resulted from an intra-entity asset transfer of certain intellectual property (“IP”) partially offset by a Danish Supreme Court decision resulting in $69 million of discrete tax expense. Additionally, our effective tax rate for the nine months ended January 27, 2023 includes the capitalization of research and development expenses partially offset by the discrete benefits related to stock-based compensation.

[0000950170-24-023115:notes:146]
During the second quarter of fiscal 2023, we completed an intra-entity asset transfer of certain IP to our international headquarters (the “IP Transfer”). The transaction resulted in a step-up of tax-deductible basis in the transferred assets, and accordingly, created a temporary difference where the tax basis exceeded the financial statement basis of such intangible assets, which resulted in the recognition of a discrete tax benefit and related deferred tax asset of $524 million during the second quarter of fiscal 2023. Management applied significant judgment when determining the fair value of the IP, which serves as the tax basis of the deferred tax asset. With the assistance of third-party valuation specialists, the fair value of the IP was determined principally based on the present value of projected cash flows related to the IP which reflects management’s assumptions regarding projected revenues, expenses and a discount rate. The tax-deductible amortization related to the transferred IP rights will be recognized in future periods and any amortization that is unused in a particular year can be carried forward indefinitely. The deferred tax asset and the tax benefit were

[0000950170-24-023115:notes:147]
measured based on the enacted tax rates expected to apply in the years the asset is expected to be realized. We expect to realize the deferred tax asset resulting from the IP Transfer and will assess the realizability of the deferred tax asset quarterly.

[0000950170-24-023115:notes:148]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We did not believe that our Danish subsidiary was liable for such withholding tax and filed an appeal with the Danish Tax Tribunal, which issued a ruling in favor of NetApp in December 2011. However, following escalations within the Danish judicial system over the course of numerous years, on January 9, 2023, the Danish Supreme Court ruled the 2005 dividend was subject to withholding tax while the smaller 2006 distribution would not be subject to withholding tax. The Danish Supreme Court ruling on the distributions declared in 2005 and 2006 is non-appealable. During the third quarter ended January 27, 2023, we recorded $69 million of discrete tax expense, which includes $23 million of withholding tax and $46 million of interest, associated with the Danish Supreme Court ruling.

[0000950170-24-023115:notes:149]
The Organisation for Economic Co-operation and Development (“OECD”) recently enacted model rules for a new global minimum tax framework known as Pillar Two. These rules have been agreed to by most OECD members. The OECD has since issued administrative guidance providing transition and safe harbor rules around the implementation of Pillar Two rules. On February 1, 2023, the FASB indicated that they believe taxes imposed under Pillar Two is an alternative minimum tax. Accordingly, deferred tax assets and liabilities associated with the minimum tax would not be recognized or adjusted for the estimated future effects of the minimum tax but would be recognized in the period incurred. We will be subject to Pillar Two rules starting in our fiscal year 2025. We do not currently expect Pillar Two taxes to have a significant impact on our financial statements, particularly due to the safe harbor relief during the transition period, but we are still closely monitoring developments.

[0000950170-24-023115:notes:150]
Any OECD actions adopted internationally could impact our financial results in future periods.

[0000950170-24-023115:notes:151]
[same as prior period, unchanged from 0000950170-23-067033:notes:145]

[0000950170-24-023115:notes:152]
[same as prior period, unchanged from 0000950170-23-067033:notes:146]

[0000950170-24-023115:notes:153]
As of January 26, 2024, we had $225 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $152 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $152 million have been recorded in other long-term liabilities.


## us-gaap:EarningsPerShareTextBlock

[0000950170-24-023115:notes:154]
[same as prior period, unchanged from 0000950170-23-067033:notes:148]

[0000950170-24-023115:notes:155]
[same as prior period, unchanged from 0000950170-23-067033:notes:149]

[0000950170-24-023115:notes:156]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | January 26, 2024 |  |  | January 27, 2023 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 313 |  |  | $ | 65 |  |  | $ | 695 |  |  | $ | 1,029 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 206 |  |  |  | 216 |  |  |  | 209 |  |  |  | 218 |  |
| Dilutive impact of employee equity award plans |  |  | 5 |  |  |  | 3 |  |  |  | 4 |  |  |  | 3 |  |
| Shares used in diluted computation |  |  | 211 |  |  |  | 219 |  |  |  | 213 |  |  |  | 221 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.52 |  |  | $ | 0.30 |  |  | $ | 3.33 |  |  | $ | 4.72 |  |
| Diluted |  | $ | 1.48 |  |  | $ | 0.30 |  |  | $ | 3.26 |  |  | $ | 4.66 |  |

[0000950170-24-023115:notes:157]
No potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for the three months ended January 26, 2024, while three million potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for the nine months ended January 26, 2024, as their inclusion would have been anti-dilutive. Six million shares from outstanding employee awards each were excluded from the diluted net income per share calculation for the three and nine months ended January 27, 2023, respectively, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-24-023115:notes:158]
[same as prior period, unchanged from 0000950170-23-067033:notes:152]

[0000950170-24-023115:notes:159]
[same as prior period, unchanged from 0000950170-23-067033:notes:153]

[0000950170-24-023115:notes:160]
Hybrid Cloud offers a portfolio of storage management and infrastructure solutions that help customers modernize their data centers with the power of the cloud and modernize applications with a single solution that supports file, block, and object storage. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.

[0000950170-24-023115:notes:161]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage and CloudOps services. Public Cloud includes certain reseller arrangements in which the timing of our consideration follows the end user consumption of the reseller services.

[0000950170-24-023115:notes:162]
[same as prior period, unchanged from 0000950170-23-067033:notes:156]

[0000950170-24-023115:notes:163]
[same as prior period, unchanged from 0000950170-23-067033:notes:157]

[0000950170-24-023115:notes:164]
|  | Three Months Ended January 26, 2024 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 747 |  |  | $ | — |  |  | $ | 747 |  |
| Support revenues |  | 631 |  |  |  | — |  |  |  | 631 |  |
| Professional and other services revenues |  | 77 |  |  |  | — |  |  |  | 77 |  |
| Public cloud revenues |  | — |  |  |  | 151 |  |  |  | 151 |  |
| Net revenues |  | 1,455 |  |  |  | 151 |  |  |  | 1,606 |  |
| Cost of product revenues |  | 280 |  |  |  | — |  |  |  | 280 |  |
| Cost of support revenues |  | 49 |  |  |  | — |  |  |  | 49 |  |
| Cost of professional and other services revenues |  | 58 |  |  |  | — |  |  |  | 58 |  |
| Cost of public cloud revenues |  | — |  |  |  | 52 |  |  |  | 52 |  |
| Segment cost of revenues |  | 387 |  |  |  | 52 |  |  |  | 439 |  |
| Segment gross profit | $ | 1,068 |  |  | $ | 99 |  |  | $ | 1,167 |  |
| Segment gross margin |  | 73.4 | % |  |  | 65.6 | % |  |  | 72.7 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 16 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,151 |  |
| Total gross margin |  |  |  |  |  |  |  | 71.7 | % |
| 1 Unallocated cost of revenues are composed of $7 million of stock-based compensation expense and $9 million of amortization of intangible assets. |  |

[0000950170-24-023115:notes:165]
|  | Three Months Ended January 27, 2023 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 682 |  |  | $ | — |  |  | $ | 682 |  |
| Support revenues |  | 616 |  |  |  | — |  |  |  | 616 |  |
| Professional and other services revenues |  | 78 |  |  |  | — |  |  |  | 78 |  |
| Public cloud revenues |  | — |  |  |  | 150 |  |  |  | 150 |  |
| Net revenues |  | 1,376 |  |  |  | 150 |  |  |  | 1,526 |  |
| Cost of product revenues |  | 365 |  |  |  | — |  |  |  | 365 |  |
| Cost of support revenues |  | 44 |  |  |  | — |  |  |  | 44 |  |
| Cost of professional and other services revenues |  | 50 |  |  |  | — |  |  |  | 50 |  |
| Cost of public cloud revenues |  | — |  |  |  | 47 |  |  |  | 47 |  |
| Segment cost of revenues |  | 459 |  |  |  | 47 |  |  |  | 506 |  |
| Segment gross profit | $ | 917 |  |  | $ | 103 |  |  | $ | 1,020 |  |
| Segment gross margin |  | 66.6 | % |  |  | 68.7 | % |  |  | 66.8 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 19 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,001 |  |
| Total gross margin |  |  |  |  |  |  |  | 65.6 | % |
| 1 Unallocated cost of revenues are composed of $8 million of stock-based compensation expense and $11 million of amortization of intangible assets. |  |

[0000950170-24-023115:notes:166]
|  | Nine Months Ended January 26, 2024 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 2,043 |  |  | $ | — |  |  | $ | 2,043 |  |
| Support revenues |  | 1,865 |  |  |  | — |  |  |  | 1,865 |  |
| Professional and other services revenues |  | 233 |  |  |  | — |  |  |  | 233 |  |
| Public cloud revenues |  | — |  |  |  | 459 |  |  |  | 459 |  |
| Net revenues |  | 4,141 |  |  |  | 459 |  |  |  | 4,600 |  |
| Cost of product revenues |  | 819 |  |  |  | — |  |  |  | 819 |  |
| Cost of support revenues |  | 146 |  |  |  | — |  |  |  | 146 |  |
| Cost of professional and other services revenues |  | 176 |  |  |  | — |  |  |  | 176 |  |
| Cost of public cloud revenues |  | — |  |  |  | 155 |  |  |  | 155 |  |
| Segment cost of revenues |  | 1,141 |  |  |  | 155 |  |  |  | 1,296 |  |
| Segment gross profit | $ | 3,000 |  |  | $ | 304 |  |  | $ | 3,304 |  |
| Segment gross margin |  | 72.4 | % |  |  | 66.2 | % |  |  | 71.8 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 47 |  |
| Total gross profit |  |  |  |  |  |  | $ | 3,257 |  |
| Total gross margin |  |  |  |  |  |  |  | 70.8 | % |
| 1 Unallocated cost of revenues are composed of $21 million of stock-based compensation expense and $26 million of amortization of intangible assets. |  |

[0000950170-24-023115:notes:167]
|  | Nine Months Ended January 27, 2023 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 2,305 |  |  | $ | — |  |  | $ | 2,305 |  |
| Support revenues |  | 1,821 |  |  |  | — |  |  |  | 1,821 |  |
| Professional and other services revenues |  | 231 |  |  |  | — |  |  |  | 231 |  |
| Public cloud revenues |  | — |  |  |  | 424 |  |  |  | 424 |  |
| Net revenues |  | 4,357 |  |  |  | 424 |  |  |  | 4,781 |  |
| Cost of product revenues |  | 1,177 |  |  |  | — |  |  |  | 1,177 |  |
| Cost of support revenues |  | 132 |  |  |  | — |  |  |  | 132 |  |
| Cost of professional and other services revenues |  | 156 |  |  |  | — |  |  |  | 156 |  |
| Cost of public cloud revenues |  | — |  |  |  | 132 |  |  |  | 132 |  |
| Segment cost of revenues |  | 1,465 |  |  |  | 132 |  |  |  | 1,597 |  |
| Segment gross profit | $ | 2,892 |  |  | $ | 292 |  |  | $ | 3,184 |  |
| Segment gross margin |  | 66.4 | % |  |  | 68.9 | % |  |  | 66.6 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 50 |  |
| Total gross profit |  |  |  |  |  |  | $ | 3,134 |  |
| Total gross margin |  |  |  |  |  |  |  | 65.6 | % |
| 1 Unallocated cost of revenues are composed of $18 million of stock-based compensation expense and $32 million of amortization of intangible assets. |  |

[0000950170-24-023115:notes:168]
[same as prior period, unchanged from 0000950170-23-067033:notes:162]

[0000950170-24-023115:notes:169]
[same as prior period, unchanged from 0000950170-23-067033:notes:163]

[0000950170-24-023115:notes:170]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | January 26, 2024 |  |  | January 27, 2023 |  |
| United States, Canada and Latin America (Americas) |  | $ | 802 |  |  | $ | 781 |  |  | $ | 2,345 |  |  | $ | 2,453 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 567 |  |  |  | 510 |  |  |  | 1,538 |  |  |  | 1,584 |  |
| Asia Pacific (APAC) |  |  | 237 |  |  |  | 235 |  |  |  | 717 |  |  |  | 744 |  |
| Net revenues |  | $ | 1,606 |  |  | $ | 1,526 |  |  | $ | 4,600 |  |  | $ | 4,781 |  |

[0000950170-24-023115:notes:171]
[same as prior period, unchanged from 0000950170-23-067033:notes:165]

[0000950170-24-023115:notes:172]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $744 million and $719 million during the three months ended January 26, 2024 and January 27, 2023, respectively, and were $2,172 million and $2,275 million during the nine months ended January 26, 2024 and January 27, 2023, respectively.

[0000950170-24-023115:notes:173]
[same as prior period, unchanged from 0000950170-23-067033:notes:167]

[0000950170-24-023115:notes:174]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |
| U.S. |  | $ | 574 |  |  | $ | 887 |  |
| International |  |  | 2,343 |  |  |  | 2,183 |  |
| Total |  | $ | 2,917 |  |  | $ | 3,070 |  |

[0000950170-24-023115:notes:175]
[same as prior period, unchanged from 0000950170-23-067033:notes:169]

[0000950170-24-023115:notes:176]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |
| U.S. |  | $ | 376 |  |  | $ | 413 |  |
| International |  |  | 231 |  |  |  | 237 |  |
| Total |  | $ | 607 |  |  | $ | 650 |  |

[0000950170-24-023115:notes:177]
[same as prior period, unchanged from 0000950170-23-067033:notes:171]

[0000950170-24-023115:notes:178]
[same as prior period, unchanged from 0000950170-23-067033:notes:172]

[0000950170-24-023115:notes:179]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 26, 2024 |  |  | January 27, 2023 |  |  | January 26, 2024 |  |  | January 27, 2023 |  |
| Arrow Electronics, Inc. |  |  | 21 | % |  |  | 24 | % |  |  | 22 | % |  |  | 24 | % |
| TD Synnex Corporation (previously presented as Tech Data Corporation) |  |  | 21 | % |  |  | 21 | % |  |  | 21 | % |  |  | 20 | % |

[0000950170-24-023115:notes:180]
The following customers accounted for 10% or more of accounts receivable as of at least one of the dates presented:

[0000950170-24-023115:notes:181]
|  |  | January 26, 2024 |  |  | April 28, 2023 |  |
| Arrow Electronics, Inc. |  |  | 5 | % |  |  | 15 | % |
| TD Synnex Corporation (previously presented as Tech Data Corporation) |  |  | 16 | % |  |  | 19 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-24-023115:notes:182]
15. Commitments and Contingencies

[0000950170-24-023115:notes:183]
Purchase Orders and Other Commitments

[0000950170-24-023115:notes:184]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of January 26, 2024, we had approximately $0.5 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 26, 2024 and April 28, 2023, such liability amounted to $20 million and $15 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0000950170-24-023115:notes:185]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 26, 2024, we had approximately $0.3 billion in other purchase obligations.

[0000950170-24-023115:notes:186]
Financing Guarantees

[0000950170-24-023115:notes:187]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these

[0000950170-24-023115:notes:188]
arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $58 million and $32 million of receivables during the nine months ended January 26, 2024 and January 27, 2023, respectively.

[0000950170-24-023115:notes:189]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0000950170-24-023115:notes:190]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of January 26, 2024 and April 28, 2023, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-24-023115:notes:191]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 26, 2024, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-24-023115:notes:192]
Legal Contingencies

[0000950170-24-023115:notes:193]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0000950170-24-023115:notes:194]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0000950170-24-023115:notes:195]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of January 26, 2024 related to such matters.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000950170-24-023115:notes:196]
[same as prior period, unchanged from 0000950170-23-067033:notes:190]

[0000950170-24-023115:notes:197]
[same as prior period, unchanged from 0000950170-23-067033:notes:191]

[0000950170-24-023115:notes:198]
On December 19, 2023, George Kurian, Chief Executive Officer of the Company, entered into a 10b5-1 trading arrangement intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) promulgated under the Exchange Act. The trading arrangement will expire on December 19, 2025, and may be terminated earlier in the limited circumstances defined in the trading arrangement. An aggregate of up to 153,000 shares may be sold pursuant to the trading arrangement.

[0000950170-24-023115:notes:199]
On December 20, 2023, Elizabeth O'Callahan, EVP, Chief Legal Officer of the Company, entered into a 10b5-1 trading arrangement intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) promulgated under the Exchange Act. The trading arrangement will expire on June 20, 2025, and may be terminated earlier in the limited circumstances defined in the trading arrangement. An aggregate of up to 7,372 shares may be sold pursuant to the trading arrangement.

[0000950170-24-023115:notes:200]
No other directors or executive officers of the Company adopted, modified or terminated any contract, instruction or written plan for the purchase or sale of the Company’s securities that was intended to satisfy the affirmative defense conditions of Rule

[0000950170-24-023115:notes:201]
10b5-1(c) or any non-Rule 10b5-1 trading arrangement, (as defined in Item 408(c) of Regulation S-K) during the quarterly period covered by this report.
