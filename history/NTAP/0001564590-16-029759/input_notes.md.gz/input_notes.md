# NTAP notes — 0001564590-16-029759


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-16-029759:notes:1]
[same as prior period, unchanged from 0001564590-16-024907:notes:1]

[0001564590-16-029759:notes:2]
[same as prior period, unchanged from 0001564590-16-024907:notes:2]

[0001564590-16-029759:notes:3]
[same as prior period, unchanged from 0001564590-16-024907:notes:3]

[0001564590-16-029759:notes:4]
[same as prior period, unchanged from 0001564590-16-024907:notes:4]

[0001564590-16-029759:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2016 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 28, 2016 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-16-029759:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-16-029759:notes:7]
Accounting Change – In the first quarter of fiscal 2017, we early adopted a new accounting standards update that the Financial Accounting Standards Board (FASB) issued in March 2016 that simplifies the accounting for certain aspects of stock-based payments to employees. The new standard requires that certain amendments relevant to us be applied using a modified-retrospective transition method by means of a cumulative-effect adjustment to retained earnings as of the beginning of the period in which the guidance is adopted.

[0001564590-16-029759:notes:8]
[same as prior period, unchanged from 0001564590-16-024907:notes:8]

[0001564590-16-029759:notes:9]
The new standard eliminated the requirement to report excess tax benefits and certain tax deficiencies related to share-based payment transactions as additional paid-in capital. As a result, we recognized $17 million of tax deficiencies in our provision for income taxes, rather than additional paid–in capital, for the six months ended October 28, 2016.

[0001564590-16-029759:notes:10]
[same as prior period, unchanged from 0001564590-16-024907:notes:10]

[0001564590-16-029759:notes:11]
There have been no other significant changes in our significant accounting policies as of and for the six months ended October 28, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2016.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-16-029759:notes:12]
[same as prior period, unchanged from 0001564590-16-024907:notes:12]

[0001564590-16-029759:notes:13]
[same as prior period, unchanged from 0001564590-16-024907:notes:13]

[0001564590-16-029759:notes:14]
|  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 35 |  |  | $ | 15 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 70 |  |  | $ | 94 |  |
| Interest paid |  | $ | 23 |  |  | $ | 20 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-16-029759:notes:15]
[same as prior period, unchanged from 0001564590-16-024907:notes:15]

[0001564590-16-029759:notes:16]
[same as prior period, unchanged from 0001564590-16-024907:notes:16]

[0001564590-16-029759:notes:17]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 148 |  |  | $ | (28 | ) |  | $ | 120 |  |  | $ | 403 |  |  | $ | (289 | ) |  | $ | 114 |  |
| Customer contracts/relationships |  |  | 43 |  |  |  | (11 | ) |  |  | 32 |  |  |  | 46 |  |  |  | (7 | ) |  |  | 39 |  |
| Other purchased intangibles |  |  | 9 |  |  |  | (3 | ) |  |  | 6 |  |  |  | 10 |  |  |  | (2 | ) |  |  | 8 |  |
| Total intangible assets subject to amortization |  |  | 200 |  |  |  | (42 | ) |  |  | 158 |  |  |  | 459 |  |  |  | (298 | ) |  |  | 161 |  |
| In-process research and development |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 19 |  |  |  | — |  |  |  | 19 |  |
| Total purchased intangible assets |  | $ | 200 |  |  | $ | (42 | ) |  | $ | 158 |  |  | $ | 478 |  |  | $ | (298 | ) |  | $ | 180 |  |

[0001564590-16-029759:notes:18]
As of October 28, 2016, the in-process research and development project related to the SolidFire acquisition had been completed, and the associated intangible asset was included in developed technology.

[0001564590-16-029759:notes:19]
[same as prior period, unchanged from 0001564590-16-024907:notes:18]

[0001564590-16-029759:notes:20]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Statement of |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | Operations Classifications |
| Developed technology |  | $ | 7 |  |  | $ | 14 |  |  | $ | 13 |  |  | $ | 28 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 3 |  |  |  | — |  |  |  | 7 |  |  |  | — |  |  | Operating expenses |
| Other purchased intangibles |  |  | 1 |  |  |  | — |  |  |  | 2 |  |  |  | — |  |  | Operating expenses |
| Total |  | $ | 11 |  |  | $ | 14 |  |  | $ | 22 |  |  | $ | 28 |  |  |  |

[0001564590-16-029759:notes:21]
As of October 28, 2016, future amortization expense related to purchased intangible assets subject to amortization is as follows (in millions):

[0001564590-16-029759:notes:22]
| Fiscal Year |  | Amount |  |
| Remainder of 2017 |  | $ | 26 |  |
| 2018 |  |  | 49 |  |
| 2019 |  |  | 42 |  |
| 2020 |  |  | 26 |  |
| 2021 |  |  | 15 |  |
| Total |  | $ | 158 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-16-029759:notes:23]
[same as prior period, unchanged from 0001564590-16-024907:notes:22]

[0001564590-16-029759:notes:24]
[same as prior period, unchanged from 0001564590-16-024907:notes:23]

[0001564590-16-029759:notes:25]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
| Cash |  | $ | 1,876 |  |  | $ | 2,714 |  |
| Cash equivalents |  |  | 237 |  |  |  | 154 |  |
| Cash and cash equivalents |  | $ | 2,113 |  |  | $ | 2,868 |  |

[0001564590-16-029759:notes:26]
[same as prior period, unchanged from 0001564590-16-024907:notes:25]

[0001564590-16-029759:notes:27]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
| Purchased components |  | $ | 10 |  |  | $ | 10 |  |
| Finished goods |  |  | 87 |  |  |  | 88 |  |
| Inventories |  | $ | 97 |  |  | $ | 98 |  |

[0001564590-16-029759:notes:28]
[same as prior period, unchanged from 0001564590-16-024907:notes:27]

[0001564590-16-029759:notes:29]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
| Land |  | $ | 215 |  |  | $ | 215 |  |
| Buildings and improvements |  |  | 605 |  |  |  | 605 |  |
| Leasehold improvements |  |  | 107 |  |  |  | 106 |  |
| Computer, production, engineering and other equipment |  |  | 749 |  |  |  | 751 |  |
| Computer software |  |  | 352 |  |  |  | 352 |  |
| Furniture and fixtures |  |  | 88 |  |  |  | 88 |  |
| Construction-in-progress |  |  | 135 |  |  |  | 74 |  |
|  |  |  | 2,251 |  |  |  | 2,191 |  |
| Accumulated depreciation and amortization |  |  | (1,302 | ) |  |  | (1,254 | ) |
| Property and equipment, net |  | $ | 949 |  |  | $ | 937 |  |

[0001564590-16-029759:notes:30]
[same as prior period, unchanged from 0001564590-16-024907:notes:29]

[0001564590-16-029759:notes:31]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
| Deferred tax assets |  | $ | 590 |  |  | $ | 621 |  |
| Other assets |  |  | 169 |  |  |  | 175 |  |
| Other non-current assets |  | $ | 759 |  |  | $ | 796 |  |

[0001564590-16-029759:notes:32]
[same as prior period, unchanged from 0001564590-16-024907:notes:31]

[0001564590-16-029759:notes:33]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
| Accrued compensation and benefits |  | $ | 288 |  |  | $ | 371 |  |
| Product warranty liability |  |  | 36 |  |  |  | 48 |  |
| Other current liabilities |  |  | 296 |  |  |  | 346 |  |
| Accrued expenses |  | $ | 620 |  |  | $ | 765 |  |

[0001564590-16-029759:notes:34]
[same as prior period, unchanged from 0001564590-16-024907:notes:33]

[0001564590-16-029759:notes:35]
[same as prior period, unchanged from 0001564590-16-024907:notes:34]

[0001564590-16-029759:notes:36]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Balance at beginning of period |  | $ | 61 |  |  | $ | 81 |  |  | $ | 70 |  |  | $ | 86 |  |
| Expense accrued during the period |  |  | 1 |  |  |  | 13 |  |  |  | 5 |  |  |  | 22 |  |
| Warranty costs incurred |  |  | (8 | ) |  |  | (14 | ) |  |  | (21 | ) |  |  | (28 | ) |
| Balance at end of period |  | $ | 54 |  |  | $ | 80 |  |  | $ | 54 |  |  | $ | 80 |  |

[0001564590-16-029759:notes:37]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
| Accrued expenses |  | $ | 36 |  |  | $ | 48 |  |
| Other long-term liabilities |  |  | 18 |  |  |  | 22 |  |
| Total warranty liabilities |  | $ | 54 |  |  | $ | 70 |  |

[0001564590-16-029759:notes:38]
[same as prior period, unchanged from 0001564590-16-024907:notes:37]

[0001564590-16-029759:notes:39]
[same as prior period, unchanged from 0001564590-16-024907:notes:38]

[0001564590-16-029759:notes:40]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
| Deferred product revenue |  | $ | 64 |  |  | $ | 68 |  |
| Deferred services revenue |  |  | 2,928 |  |  |  | 3,100 |  |
| Financed unearned services revenue |  |  | 209 |  |  |  | 217 |  |
| Total |  | $ | 3,201 |  |  | $ | 3,385 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,655 |  |  | $ | 1,794 |  |
| Long-term |  |  | 1,546 |  |  |  | 1,591 |  |
| Total |  | $ | 3,201 |  |  | $ | 3,385 |  |

[0001564590-16-029759:notes:41]
[same as prior period, unchanged from 0001564590-16-024907:notes:40]


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-16-029759:notes:42]
[same as prior period, unchanged from 0001564590-16-024907:notes:41]

[0001564590-16-029759:notes:43]
[same as prior period, unchanged from 0001564590-16-024907:notes:42]

[0001564590-16-029759:notes:44]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Interest income |  | $ | 10 |  |  | $ | 11 |  |  | $ | 21 |  |  | $ | 24 |  |
| Interest expense |  |  | (12 | ) |  |  | (12 | ) |  |  | (27 | ) |  |  | (23 | ) |
| Other income, net |  |  | 2 |  |  |  | — |  |  |  | 5 |  |  |  | 2 |  |
| Total other income (expense), net |  | $ | — |  |  | $ | (1 | ) |  | $ | (1 | ) |  | $ | 3 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-16-029759:notes:45]
[same as prior period, unchanged from 0001564590-16-024907:notes:44]

[0001564590-16-029759:notes:46]
[same as prior period, unchanged from 0001564590-16-024907:notes:45]

[0001564590-16-029759:notes:47]
[same as prior period, unchanged from 0001564590-16-024907:notes:46]

[0001564590-16-029759:notes:48]
[same as prior period, unchanged from 0001564590-16-024907:notes:47]

[0001564590-16-029759:notes:49]
[same as prior period, unchanged from 0001564590-16-024907:notes:48]

[0001564590-16-029759:notes:50]
[same as prior period, unchanged from 0001564590-16-024907:notes:49]

[0001564590-16-029759:notes:51]
[same as prior period, unchanged from 0001564590-16-024907:notes:50]

[0001564590-16-029759:notes:52]
[same as prior period, unchanged from 0001564590-16-024907:notes:51]

[0001564590-16-029759:notes:53]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,234 |  |  | $ | 4 |  |  | $ | (1 | ) |  | $ | 1,237 |  |  | $ | 1,370 |  |  | $ | 5 |  |  | $ | (1 | ) |  | $ | 1,374 |  |
| U.S. Treasury and government debt securities |  |  | 669 |  |  |  | 1 |  |  |  | (1 | ) |  |  | 669 |  |  |  | 878 |  |  |  | 2 |  |  |  | — |  |  |  | 880 |  |
| Foreign government debt securities |  |  | 27 |  |  |  | — |  |  |  | — |  |  |  | 27 |  |  |  | 35 |  |  |  | — |  |  |  | — |  |  |  | 35 |  |
| Commercial paper |  |  | 476 |  |  |  | — |  |  |  | — |  |  |  | 476 |  |  |  | 202 |  |  |  | — |  |  |  | — |  |  |  | 202 |  |
| Certificates of deposit |  |  | 72 |  |  |  | — |  |  |  | — |  |  |  | 72 |  |  |  | 98 |  |  |  | — |  |  |  | — |  |  |  | 98 |  |
| Mutual funds |  |  | 32 |  |  |  | — |  |  |  | — |  |  |  | 32 |  |  |  | 30 |  |  |  | — |  |  |  | — |  |  |  | 30 |  |
| Total debt and equity securities |  | $ | 2,510 |  |  | $ | 5 |  |  | $ | (2 | ) |  | $ | 2,513 |  |  | $ | 2,613 |  |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 2,619 |  |

[0001564590-16-029759:notes:54]
As of October 28, 2016, gross unrealized losses related to individual securities were not significant.

[0001564590-16-029759:notes:55]
The following table presents the contractual maturities of our debt investments as of October 28, 2016 (in millions):

[0001564590-16-029759:notes:56]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,149 |  |  | $ | 1,150 |  |
| Due after one year through five years |  |  | 1,329 |  |  |  | 1,331 |  |
|  |  | $ | 2,478 |  |  | $ | 2,481 |  |

[0001564590-16-029759:notes:57]
[same as prior period, unchanged from 0001564590-16-024907:notes:56]

[0001564590-16-029759:notes:58]
[same as prior period, unchanged from 0001564590-16-024907:notes:57]

[0001564590-16-029759:notes:59]
[same as prior period, unchanged from 0001564590-16-024907:notes:58]

[0001564590-16-029759:notes:60]
|  |  | October 28, 2016 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 1,876 |  |  | $ | 1,876 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,237 |  |  |  | — |  |  |  | 1,237 |  |
| U.S. Treasury and government debt securities |  |  | 669 |  |  |  | 215 |  |  |  | 454 |  |
| Foreign government debt securities |  |  | 27 |  |  |  | — |  |  |  | 27 |  |
| Commercial paper |  |  | 476 |  |  |  | — |  |  |  | 476 |  |
| Certificates of deposit |  |  | 72 |  |  |  | — |  |  |  | 72 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,357 |  |  | $ | 2,091 |  |  | $ | 2,266 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 26 |  |  | $ | 26 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (2 | ) |  | $ | — |  |  | $ | (2 | ) |

[0001564590-16-029759:notes:61]
[same as prior period, unchanged from 0001564590-16-024907:notes:60]

[0001564590-16-029759:notes:62]
[same as prior period, unchanged from 0001564590-16-024907:notes:61]

[0001564590-16-029759:notes:63]
[same as prior period, unchanged from 0001564590-16-024907:notes:62]

[0001564590-16-029759:notes:64]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of October 28, 2016 and April 29, 2016, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-16-029759:notes:65]
[same as prior period, unchanged from 0001564590-16-024907:notes:64]

[0001564590-16-029759:notes:66]
As of October 28, 2016 and April 29, 2016, the fair value of our long-term debt was approximately $1,533 million and $1,519 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-16-029759:notes:67]
8. Financing Arrangements

[0001564590-16-029759:notes:68]
Long-Term Debt

[0001564590-16-029759:notes:69]
The following table summarizes information relating to our long-term debt (in millions, except interest rates):

[0001564590-16-029759:notes:70]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (8 | ) |  |  |  |  |  |  | (10 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,492 |  |  |  |  |  |  | $ | 1,490 |  |  |  |  |  |

[0001564590-16-029759:notes:71]
Senior Notes

[0001564590-16-029759:notes:72]
Our 3.375% Senior Notes, 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $500 million, $750 million and $250 million, respectively, were issued in June 2014, December 2012 and December 2012, respectively. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any future senior unsecured indebtedness.

[0001564590-16-029759:notes:73]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 28, 2016, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-16-029759:notes:74]
As of October 28, 2016, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-16-029759:notes:75]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| Thereafter |  |  | 750 |  |
| Total |  | $ | 1,500 |  |

[0001564590-16-029759:notes:76]
Credit Facility

[0001564590-16-029759:notes:77]
In December 2012, as amended in February 2016, we entered into a credit agreement with a syndicated group of lenders that is scheduled to expire on December 21, 2017 and provides for an unsecured $300 million revolving credit facility that is comprised of revolving loans, Eurocurrency loans and/or swingline loans. The credit facility includes a $100 million foreign currency sub-facility, a $50 million letter of credit sub-facility and a $10 million swingline sub-facility available on same-day notice. Available borrowings under the credit facility are reduced by the amount of any outstanding borrowings on the sub-facilities. We may also, subject to certain requirements, request an increase in the facility up to an additional $50 million and request two additional one-year extensions, subject to certain conditions. The proceeds from the facility may be used by us for general corporate purposes.

[0001564590-16-029759:notes:78]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of October 28, 2016, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-16-029759:notes:79]
Short-Term Loan

[0001564590-16-029759:notes:80]
In February 2016, in connection with the SolidFire acquisition, we entered into a short-term loan of $870 million with a maturity of November 2, 2016. As of October 28, 2016, we have repaid the loan in full and have terminated the related loan agreement.

[0001564590-16-029759:notes:81]
Sale-leaseback Transactions

[0001564590-16-029759:notes:82]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, the assets will remain on our condensed consolidated balance sheets, and proceeds received by us from these transactions are reported as financing obligations. As of October 28, 2016, the balance of these financing obligations was $149 million. At the end of each respective leaseback period, or when our continuing involvement under the leaseback agreements ends, each transaction will be reported as a non-cash sale of land and buildings and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain on sale of properties.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-16-029759:notes:83]
[same as prior period, unchanged from 0001564590-16-024907:notes:82]

[0001564590-16-029759:notes:84]
[same as prior period, unchanged from 0001564590-16-024907:notes:83]

[0001564590-16-029759:notes:85]
As of October 28, 2016, we have outstanding certain equity incentive awards (awards), which include stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and Employee Stock Purchase Plan (ESPP) awards.

[0001564590-16-029759:notes:86]
[same as prior period, unchanged from 0001564590-16-024907:notes:85]

[0001564590-16-029759:notes:87]
[same as prior period, unchanged from 0001564590-16-024907:notes:86]

[0001564590-16-029759:notes:88]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 29, 2016 |  |  | 9 |  |  | $ | 34.01 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (1 | ) |  | $ | 20.83 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (2 | ) |  | $ | 39.23 |  |  |  |  |  |  |  |  |  |
| Outstanding as of October 28, 2016 |  |  | 6 |  |  | $ | 34.37 |  |  |  | 3.49 |  |  | $ | 32 |  |
| Exercisable as of October 28, 2016 |  |  | 4 |  |  | $ | 39.88 |  |  |  | 2.42 |  |  | $ | 7 |  |

[0001564590-16-029759:notes:89]
[same as prior period, unchanged from 0001564590-16-024907:notes:88]

[0001564590-16-029759:notes:90]
[same as prior period, unchanged from 0001564590-16-024907:notes:89]

[0001564590-16-029759:notes:91]
|  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Intrinsic value of exercises |  | $ | 11 |  |  | $ | 8 |  |
| Proceeds received from exercises |  | $ | 20 |  |  | $ | 19 |  |
| Fair value of options vested |  | $ | 9 |  |  | $ | 7 |  |

[0001564590-16-029759:notes:92]
[same as prior period, unchanged from 0001564590-16-024907:notes:91]

[0001564590-16-029759:notes:93]
In the six months ended October 28, 2016, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service based vesting criteria) such that the PBRSU cliff-vests at the end of either an approximate two year or three year performance period, which began on the date specified in the grant agreement and ends the last day of fiscal 2018 or 2019, respectively. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted, and will depend upon our Total Stockholder Return (TSR) as compared to an index TSR (each expressed as a growth rate percentage) calculated as of the applicable period end date. The fair values of the PBRSUs were fixed at grant date using a Monte Carlo simulation model and the related aggregate compensation cost of $15 million is being recognized over the shorter of the remaining applicable performance or service periods.

[0001564590-16-029759:notes:94]
[same as prior period, unchanged from 0001564590-16-024907:notes:93]

[0001564590-16-029759:notes:95]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 29, 2016 |  |  | 13 |  |  | $ | 32.46 |  |
| Granted |  |  | 5 |  |  | $ | 24.10 |  |
| Vested |  |  | (4 | ) |  | $ | 32.86 |  |
| Forfeited |  |  | (2 | ) |  | $ | 32.50 |  |
| Outstanding as of October 28, 2016 |  |  | 12 |  |  | $ | 28.59 |  |

[0001564590-16-029759:notes:96]
[same as prior period, unchanged from 0001564590-16-024907:notes:95]

[0001564590-16-029759:notes:97]
|  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 36 |  |  | $ | 44 |  |

[0001564590-16-029759:notes:98]
[same as prior period, unchanged from 0001564590-16-024907:notes:97]

[0001564590-16-029759:notes:99]
[same as prior period, unchanged from 0001564590-16-024907:notes:98]

[0001564590-16-029759:notes:100]
|  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Shares issued under the ESPP |  |  | 2 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 42 |  |  | $ | 50 |  |

[0001564590-16-029759:notes:101]
[same as prior period, unchanged from 0001564590-16-024907:notes:100]

[0001564590-16-029759:notes:102]
[same as prior period, unchanged from 0001564590-16-024907:notes:101]

[0001564590-16-029759:notes:103]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 3 |  |
| Cost of hardware maintenance and other services revenues |  |  | 3 |  |  |  | 4 |  |  |  | 7 |  |  |  | 10 |  |
| Sales and marketing |  |  | 21 |  |  |  | 26 |  |  |  | 44 |  |  |  | 57 |  |
| Research and development |  |  | 17 |  |  |  | 18 |  |  |  | 32 |  |  |  | 44 |  |
| General and administrative |  |  | 9 |  |  |  | 10 |  |  |  | 18 |  |  |  | 22 |  |
| Total stock-based compensation expense |  | $ | 51 |  |  | $ | 59 |  |  | $ | 103 |  |  | $ | 136 |  |

[0001564590-16-029759:notes:104]
As of October 28, 2016, total unrecognized compensation expense related to our equity awards was $311 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.1 years.

[0001564590-16-029759:notes:105]
[same as prior period, unchanged from 0001564590-16-024907:notes:104]

[0001564590-16-029759:notes:106]
As of October 28, 2016, our Board of Directors has authorized the repurchase of up to $9.6 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management.

[0001564590-16-029759:notes:107]
The following table summarizes activity related to this program for the six months ended October 28, 2016 (in millions, except per share amounts):

[0001564590-16-029759:notes:108]
| Number of shares repurchased |  |  | 11 |  |
| Average price per share |  | $ | 27.60 |  |
| Aggregate purchase price |  | $ | 292 |  |
| Remaining authorization at end of period |  | $ | 1,208 |  |

[0001564590-16-029759:notes:109]
The aggregate purchase price of our stock repurchases for the six months ended October 28, 2016 consisted of $292 million of open market purchases, of which $127 million and $165 million were allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-16-029759:notes:110]
Since the May 13, 2003 inception of our stock repurchase program through October 28, 2016, we repurchased a total of 258 million shares of our common stock at an average price of $32.64 per share, for an aggregate purchase price of $8.4 billion.

[0001564590-16-029759:notes:111]
[same as prior period, unchanged from 0001564590-16-024907:notes:110]

[0001564590-16-029759:notes:112]
[same as prior period, unchanged from 0001564590-16-024907:notes:111]

[0001564590-16-029759:notes:113]
|  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Dividends per share declared |  | $ | 0.38 |  |  | $ | 0.36 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 76 |  |  | $ | 84 |  |
| Dividend payments allocated to retained earnings |  | $ | 29 |  |  | $ | 23 |  |

[0001564590-16-029759:notes:114]
On November 16, 2016, we declared a cash dividend of $0.19 per share of common stock, payable on January 25, 2017 to holders of record as of the close of business on January 6, 2017. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-16-029759:notes:115]
[same as prior period, unchanged from 0001564590-16-024907:notes:114]

[0001564590-16-029759:notes:116]
[same as prior period, unchanged from 0001564590-16-024907:notes:115]

[0001564590-16-029759:notes:117]
| Balance as of April 29, 2016 |  | $ | — |  |
| Cumulative-effect of new accounting principle |  |  | 21 |  |
| Net income |  |  | 173 |  |
| Repurchases of common stock |  |  | (165 | ) |
| Dividends |  |  | (29 | ) |
| Balance as of October 28, 2016 |  | $ | — |  |

[0001564590-16-029759:notes:118]
[same as prior period, unchanged from 0001564590-16-024907:notes:117]

[0001564590-16-029759:notes:119]
[same as prior period, unchanged from 0001564590-16-024907:notes:118]

[0001564590-16-029759:notes:120]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 29, 2016 |  | $ | (19 | ) |  | $ | (16 | ) |  | $ | 6 |  |  | $ | (2 | ) |  | $ | (31 | ) |
| OCI before reclassifications, net of tax |  |  | (11 | ) |  |  | — |  |  |  | (2 | ) |  |  | 3 |  |  |  | (10 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | (1 | ) |  |  | — |  |
| Total OCI |  |  | (11 | ) |  |  | 1 |  |  |  | (2 | ) |  |  | 2 |  |  |  | (10 | ) |
| Balance as of October 28, 2016 |  | $ | (30 | ) |  | $ | (15 | ) |  | $ | 4 |  |  | $ | — |  |  | $ | (41 | ) |

[0001564590-16-029759:notes:121]
[same as prior period, unchanged from 0001564590-16-024907:notes:120]

[0001564590-16-029759:notes:122]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |
| Recognized losses on defined benefit obligations |  | $ | 1 |  |  | 1 |  |  | $ | 1 |  |  | $ | 2 |  |  | Operating expenses |
| Realized gains on available-for-sale securities |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  | Other income (expense), net |
| Realized (gains) losses on cash flow hedges |  |  | (1 | ) |  |  | 1 |  |  |  | (1 | ) |  |  | 2 |  |  | Net revenues |
| Total reclassifications |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 3 |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-16-029759:notes:123]
[same as prior period, unchanged from 0001564590-16-024907:notes:122]

[0001564590-16-029759:notes:124]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of October 28, 2016 and April 29, 2016. We did not recognize any gains and losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-16-029759:notes:125]
[same as prior period, unchanged from 0001564590-16-024907:notes:124]

[0001564590-16-029759:notes:126]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 127 |  |  | $ | 99 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 189 |  |  | $ | 160 |  |
| Forward contracts purchased |  | $ | 281 |  |  | $ | 396 |  |

[0001564590-16-029759:notes:127]
The effect of derivative instruments designated as cash flow hedges recognized in net revenues on our condensed consolidated statements of operations is presented in the condensed consolidated statements of comprehensive income and Note 9 – Stockholders’ Equity.

[0001564590-16-029759:notes:128]
[same as prior period, unchanged from 0001564590-16-024907:notes:127]

[0001564590-16-029759:notes:129]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |
|  |  | Gain Recognized into Income |  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 2 |  |  | $ | — |  |  | $ | 6 |  |  | $ | (7 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-16-029759:notes:130]
[same as prior period, unchanged from 0001564590-16-024907:notes:129]

[0001564590-16-029759:notes:131]
During fiscal 2016, management approved two restructuring actions to streamline our business, eliminate costs and redirect resources to our highest return activities. These actions consisted of the May 2015 Plan and the March 2016 Plan, under which we reduced our global workforce by an aggregate of approximately 14%. These plans have been completed as of October 28, 2016. Restructuring and other charges related to these plans consisted primarily of employee severance-related costs.

[0001564590-16-029759:notes:132]
[same as prior period, unchanged from 0001564590-16-024907:notes:131]

[0001564590-16-029759:notes:133]
|  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Balance at beginning of period |  | $ | 45 |  |  | $ | — |  |
| Net charges |  |  | — |  |  |  | 28 |  |
| Cash payments |  |  | (42 | ) |  |  | (23 | ) |
| Balance at end of period |  | $ | 3 |  |  | $ | 5 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-16-029759:notes:134]
[same as prior period, unchanged from 0001564590-16-024907:notes:133]

[0001564590-16-029759:notes:135]
[same as prior period, unchanged from 0001564590-16-024907:notes:134]

[0001564590-16-029759:notes:136]
|  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Effective tax rates |  |  | 26.1 | % |  |  | 31.1 | % |

[0001564590-16-029759:notes:137]
Our effective tax rates reflect the impact of a significant amount of our earnings, primarily income from our European operations which are headquartered in the Netherlands, being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The differences in effective tax rates for the six months ended October 28, 2016 and October 30, 2015 were primarily a result of differences in year-to-date profits before tax and the impacts of discrete events as described below.

[0001564590-16-029759:notes:138]
During the first quarter of fiscal 2017, we adopted a new accounting standard that simplifies stock-based compensation income tax accounting and presentation within the financial statements. During the six months ended October 28, 2016, we recorded discrete charges of $17 million following the post-adoption rules which require that all excess tax benefits and deficiencies from stock-based compensation be recognized as a component of income tax expense. See Note 1 – Description of Business and Significant Accounting Policies for more details regarding the adoption of this accounting standard.

[0001564590-16-029759:notes:139]
In June 2015, the Internal Revenue Service (IRS) signed a closing agreement on our fiscal 2008 to 2010 transfer pricing arrangements and, in October 2015, completed the examination of our fiscal 2008 to 2010 income tax returns. During the six months ended October 30, 2015, we recorded discrete charges totaling $23 million, attributable to the audit settlements and related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-16-029759:notes:140]
[same as prior period, unchanged from 0001564590-16-024907:notes:139]

[0001564590-16-029759:notes:141]
|  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Balance at beginning of period |  | $ | 216 |  |  | $ | 272 |  |
| Additions based on tax positions related to the current year |  |  | 3 |  |  |  | 7 |  |
| Additions for tax positions of prior years |  |  | 5 |  |  |  | 20 |  |
| Decreases for tax positions of prior years |  |  | — |  |  |  | (38 | ) |
| Settlements |  |  | (12 | ) |  |  | (52 | ) |
| Balance at end of period |  | $ | 212 |  |  | $ | 209 |  |

[0001564590-16-029759:notes:142]
As of October 28, 2016, we had $212 million of gross unrecognized tax benefits, of which $154 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $156 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-16-029759:notes:143]
[same as prior period, unchanged from 0001564590-16-024907:notes:142]

[0001564590-16-029759:notes:144]
[same as prior period, unchanged from 0001564590-16-024907:notes:143]

[0001564590-16-029759:notes:145]
[same as prior period, unchanged from 0001564590-16-024907:notes:144]


## us-gaap:EarningsPerShareTextBlock

[0001564590-16-029759:notes:146]
13. Net Income per Share

[0001564590-16-029759:notes:147]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0001564590-16-029759:notes:148]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 109 |  |  | $ | 114 |  |  | $ | 173 |  |  | $ | 84 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 278 |  |  |  | 294 |  |  |  | 278 |  |  |  | 299 |  |
| Dilutive impact of employee equity award plans |  |  | 6 |  |  |  | 2 |  |  |  | 5 |  |  |  | 3 |  |
| Shares used in diluted computation |  |  | 284 |  |  |  | 296 |  |  |  | 283 |  |  |  | 302 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.39 |  |  | $ | 0.39 |  |  | $ | 0.62 |  |  | $ | 0.28 |  |
| Diluted |  | $ | 0.38 |  |  | $ | 0.39 |  |  | $ | 0.61 |  |  | $ | 0.28 |  |

[0001564590-16-029759:notes:149]
We have excluded 5 million and 19 million weighted-average shares of common stock potentially issuable under employee equity award plans in the three months ended October 28, 2016 and October 30, 2015, respectively, and 10 million and 14 million shares of common stock potentially issuable under employee equity award plans in the six months ended October 28, 2016 and October 30, 2015, respectively, from the diluted net income per share calculations as their effect would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-16-029759:notes:150]
[same as prior period, unchanged from 0001564590-16-024907:notes:149]

[0001564590-16-029759:notes:151]
[same as prior period, unchanged from 0001564590-16-024907:notes:150]

[0001564590-16-029759:notes:152]
[same as prior period, unchanged from 0001564590-16-024907:notes:151]

[0001564590-16-029759:notes:153]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| United States, Canada and Latin America (Americas) |  | $ | 768 |  |  | $ | 819 |  |  | $ | 1,504 |  |  | $ | 1,564 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 396 |  |  |  | 430 |  |  |  | 783 |  |  |  | 845 |  |
| Asia Pacific (APAC) |  |  | 176 |  |  |  | 196 |  |  |  | 347 |  |  |  | 371 |  |
| Net revenues |  | $ | 1,340 |  |  | $ | 1,445 |  |  | $ | 2,634 |  |  | $ | 2,780 |  |

[0001564590-16-029759:notes:154]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $697 million and $743 million during the three months ended October 28, 2016 and October 30, 2015, respectively, and were $1,363 million and $1,408 million during the six months ended October 28, 2016 and October 30, 2015, respectively.

[0001564590-16-029759:notes:155]
[same as prior period, unchanged from 0001564590-16-024907:notes:154]

[0001564590-16-029759:notes:156]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
| U.S. |  | $ | 450 |  |  | $ | 513 |  |
| International |  |  | 3,907 |  |  |  | 4,790 |  |
| Total |  | $ | 4,357 |  |  | $ | 5,303 |  |

[0001564590-16-029759:notes:157]
[same as prior period, unchanged from 0001564590-16-024907:notes:156]

[0001564590-16-029759:notes:158]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
| U.S. |  | $ | 757 |  |  | $ | 797 |  |
| International |  |  | 192 |  |  |  | 140 |  |
| Total |  | $ | 949 |  |  | $ | 937 |  |

[0001564590-16-029759:notes:159]
[same as prior period, unchanged from 0001564590-16-024907:notes:158]

[0001564590-16-029759:notes:160]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Arrow Electronics, Inc. |  |  | 23 | % |  |  | 22 | % |  |  | 21 | % |  |  | 22 | % |
| Avnet, Inc. |  |  | 20 | % |  |  | 19 | % |  |  | 20 | % |  |  | 18 | % |

[0001564590-16-029759:notes:161]
[same as prior period, unchanged from 0001564590-16-024907:notes:160]

[0001564590-16-029759:notes:162]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
| Arrow Electronics, Inc. |  |  | 14 | % |  |  | 12 | % |
| Avnet, Inc. |  |  | 14 | % |  |  | 15 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-16-029759:notes:163]
15. Commitments and Contingencies

[0001564590-16-029759:notes:164]
Operating Leases

[0001564590-16-029759:notes:165]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $238 million as of October 28, 2016.

[0001564590-16-029759:notes:166]
Purchase Orders and Other Commitments

[0001564590-16-029759:notes:167]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of October 28, 2016, we had $291 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 28, 2016 and April 29, 2016, such liability amounted to $4 million and $7 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-16-029759:notes:168]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 28, 2016, we had $15 million in construction related obligations and $231 million in other purchase obligations.

[0001564590-16-029759:notes:169]
Financing Guarantees

[0001564590-16-029759:notes:170]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $108 million and $72 million of receivables during the six months ended October 28, 2016 and October 30, 2015, respectively.

[0001564590-16-029759:notes:171]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-16-029759:notes:172]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of October 28, 2016 and April 29, 2016, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-16-029759:notes:173]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 28, 2016, we have not been required to make any significant payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-16-029759:notes:174]
Legal Contingencies

[0001564590-16-029759:notes:175]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict, and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-16-029759:notes:176]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of October 28, 2016 related to such matters as they are not probable and/or reasonably estimable.


## us-gaap:SubsequentEventsTextBlock

[0001564590-16-029759:notes:177]
16. Subsequent Event

[0001564590-16-029759:notes:178]
On November 3, 2016, we announced a restructuring and reduction in workforce to streamline our core business and reduce operating expenses. In connection with these actions, we expect to reduce our worldwide headcount by approximately 6% and to incur aggregate charges of approximately $50 to $60 million for employee terminations and other costs associated with the restructuring, the majority of which we will recognize in the third quarter of fiscal 2017. We expect to implement these actions through the end of the fourth quarter of fiscal 2017.
