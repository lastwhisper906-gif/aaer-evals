# NTAP MD&A — 0001564590-16-029759


## mdna

[0001564590-16-029759:mdna:1]
[same as prior period, unchanged from 0001564590-16-024907:mdna:1]

[0001564590-16-029759:mdna:2]
[same as prior period, unchanged from 0001564590-16-024907:mdna:2]

[0001564590-16-029759:mdna:3]
[same as prior period, unchanged from 0001564590-16-024907:mdna:3]

[0001564590-16-029759:mdna:4]
[same as prior period, unchanged from 0001564590-16-024907:mdna:4]

[0001564590-16-029759:mdna:5]
[same as prior period, unchanged from 0001564590-16-024907:mdna:5]

[0001564590-16-029759:mdna:6]
In order to provide better visibility into our transition from older products to our newer, higher growth products and greater clarity into the dynamics of our product revenue, rather than grouping our product revenues by hardware platform, we are now grouping them by “Strategic” and “Mature” solutions. Strategic solutions include Clustered ONTAP (formerly named clustered Data OnTap or cDOT), branded E-Series, SolidFire, AltaVault and optional add-on software products. Mature solutions include 7-mode OnTap, add-on hardware and related operating system (OS) software and original equipment manufacturers (OEM) products. Both our Mature and Strategic product lines include a mix of disk, hybrid and all flash storage media.

[0001564590-16-029759:mdna:7]
[same as prior period, unchanged from 0001564590-16-024907:mdna:7]

[0001564590-16-029759:mdna:8]
[same as prior period, unchanged from 0001564590-16-024907:mdna:8]

[0001564590-16-029759:mdna:9]
[same as prior period, unchanged from 0001564590-16-024907:mdna:9]

[0001564590-16-029759:mdna:10]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Net revenues |  | $ | 1,340 |  |  | $ | 1,445 |  |  | $ | 2,634 |  |  | $ | 2,780 |  |
| Gross profit |  | $ | 829 |  |  | $ | 884 |  |  | $ | 1,626 |  |  | $ | 1,700 |  |
| Gross profit margin percentage |  |  | 62 | % |  |  | 61 | % |  |  | 62 | % |  |  | 61 | % |
| Income from operations |  | $ | 142 |  |  | $ | 145 |  |  | $ | 235 |  |  | $ | 119 |  |
| Income from operations as a percentage of net revenues |  |  | 11 | % |  |  | 10 | % |  |  | 9 | % |  |  | 4 | % |
| Net income |  | $ | 109 |  |  | $ | 114 |  |  | $ | 173 |  |  | $ | 84 |  |
| Diluted net income per share |  | $ | 0.38 |  |  | $ | 0.39 |  |  | $ | 0.61 |  |  | $ | 0.28 |  |
| Operating cash flows |  | $ | 158 |  |  | $ | 145 |  |  | $ | 386 |  |  | $ | 274 |  |

[0001564590-16-029759:mdna:11]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,201 |  |  | $ | 3,385 |  |
| Days sales outstanding (DSO) |  |  | 37 |  |  |  | 54 |  |

[0001564590-16-029759:mdna:12]
Subsequent Event

[0001564590-16-029759:mdna:13]
Restructuring Event

[0001564590-16-029759:mdna:14]
On November 3, 2016, we announced a restructuring and reduction in workforce to streamline our business and reduce operating expenses. In connection with these actions, we expect to reduce our worldwide headcount by approximately 6%. The reduction in workforce will be implemented through the end of the fourth quarter of this fiscal year. We expect to incur aggregate charges of approximately $50 to $60 million for employee terminations and other costs associated with the restructuring, consisting primarily of cash expenditures. The majority of these charges will be recognized in the third quarter of fiscal 2017.

[0001564590-16-029759:mdna:15]
[same as prior period, unchanged from 0001564590-16-024907:mdna:12]

[0001564590-16-029759:mdna:16]
[same as prior period, unchanged from 0001564590-16-024907:mdna:13]

[0001564590-16-029759:mdna:17]
23

[0001564590-16-029759:mdna:18]
[same as prior period, unchanged from 0001564590-16-024907:mdna:14]

[0001564590-16-029759:mdna:19]
[same as prior period, unchanged from 0001564590-16-024907:mdna:15]

[0001564590-16-029759:mdna:20]
[same as prior period, unchanged from 0001564590-16-024907:mdna:16]

[0001564590-16-029759:mdna:21]
[same as prior period, unchanged from 0001564590-16-024907:mdna:17]

[0001564590-16-029759:mdna:22]
[same as prior period, unchanged from 0001564590-16-024907:mdna:18]

[0001564590-16-029759:mdna:23]
[same as prior period, unchanged from 0001564590-16-024907:mdna:19]

[0001564590-16-029759:mdna:24]
|  |  | Three Months Ended |  |  | Six Months Ended |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 53 |  | % |  | 56 |  | % |  | 52 |  | % |  | 53 |  | % |
| Software maintenance |  |  | 18 |  |  |  | 16 |  |  |  | 18 |  |  |  | 17 |  |  |
| Hardware maintenance and other services |  |  | 29 |  |  |  | 27 |  |  |  | 30 |  |  |  | 29 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 28 |  |  |  | 28 |  |  |  | 28 |  |  |  | 27 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 10 |  |  |  | 10 |  |  |  | 10 |  |  |  | 11 |  |  |
| Gross profit |  |  | 62 |  |  |  | 61 |  |  |  | 62 |  |  |  | 61 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 31 |  |  |  | 31 |  |  |  | 32 |  |  |  | 34 |  |  |
| Research and development |  |  | 15 |  |  |  | 15 |  |  |  | 15 |  |  |  | 17 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 6 |  |  |
| Restructuring and other charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1 |  |  |
| Total operating expenses |  |  | 51 |  |  |  | 51 |  |  |  | 53 |  |  |  | 57 |  |  |
| Income from operations |  |  | 11 |  |  |  | 10 |  |  |  | 9 |  |  |  | 4 |  |  |
| Other income (expense), net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Income before income taxes |  |  | 11 |  |  |  | 10 |  |  |  | 9 |  |  |  | 4 |  |  |
| Provision for income taxes |  |  | 2 |  |  |  | 2 |  |  |  | 2 |  |  |  | 1 |  |  |
| Net income |  |  | 8 |  | % |  | 8 |  | % |  | 7 |  | % |  | 3 |  | % |

[0001564590-16-029759:mdna:25]
[same as prior period, unchanged from 0001564590-16-024907:mdna:21]

[0001564590-16-029759:mdna:26]
[same as prior period, unchanged from 0001564590-16-024907:mdna:22]

[0001564590-16-029759:mdna:27]
[same as prior period, unchanged from 0001564590-16-024907:mdna:23]

[0001564590-16-029759:mdna:28]
Net revenues for the second quarter and first six months of fiscal 2017 were $1,340 million and $2,364 million, respectively, reflecting a decrease of $105 million, or 7%, and $146 million, or 5%, respectively, compared to the corresponding periods of the prior year. The primary reason for the decreases in the second quarter and the first six months of fiscal 2017 compared to the corresponding periods in the prior year was lower product revenue, largely due to higher discounting in the current periods on both strategic and mature products. Additionally, software and hardware maintenance and other services revenues were lower in the first six months of fiscal 2017 compared to the corresponding period in the prior year due to the impact of having one more week of maintenance revenue amortization in the first quarter of fiscal 2016 compared to fiscal 2017.

[0001564590-16-029759:mdna:29]
24

[0001564590-16-029759:mdna:30]
Gross profit as a percentage of net revenues increased one percentage point for each of the second quarter and first six months of fiscal 2017 compared to the corresponding periods of the prior year, primarily due to higher gross margins on software and hardware maintenance and other services revenues, partially offset by lower gross margins on product revenues.

[0001564590-16-029759:mdna:31]
Sales and marketing, research and development, and general and administrative expenses for the second quarter and first six months of fiscal 2017 totaled $687 million, or 51% of net revenues and $1,391 million, or 53% of net revenues, respectively, compared to $738 million, or 51% of net revenues, and $1,553 million, or 56% of net revenues, respectively, for the corresponding periods of the prior year. The decreases in expenses in dollars were primarily due to a decrease in average headcount as a result of restructuring plans, as well as other cost reduction initiatives, partially offset by additional operating expenses related to the February 2016 acquisition of SolidFire, Inc.

[0001564590-16-029759:mdna:32]
[same as prior period, unchanged from 0001564590-16-024907:mdna:27]

[0001564590-16-029759:mdna:33]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |
| Net revenues |  | $ | 1,340 |  |  | $ | 1,445 |  |  |  | (7 | )% |  | $ | 2,634 |  |  | $ | 2,780 |  |  |  | (5 | )% |

[0001564590-16-029759:mdna:34]
Product revenues decreased in the second quarter of fiscal 2017 compared to the corresponding period in the prior year, while, revenues from software and hardware maintenance and other services were flat. Product revenues represented 53% of net revenues for the second quarter of fiscal 2017 compared to 56% for the corresponding period of the prior year.

[0001564590-16-029759:mdna:35]
Product revenues decreased in the first six months of fiscal 2017 compared to the corresponding period in the prior year. Revenues from software and hardware maintenance and other services of $1,264 million in aggregate for the first six months of fiscal 2017 decreased $37 million, reflecting one more week of maintenance revenue amortization in the first quarter of fiscal 2016. Product revenues represented 52% of net revenues for the first six months of fiscal 2017 compared to 53% for the corresponding periods of the prior year.

[0001564590-16-029759:mdna:36]
[same as prior period, unchanged from 0001564590-16-024907:mdna:30]

[0001564590-16-029759:mdna:37]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Arrow Electronics, Inc. |  |  | 23 | % |  |  | 22 | % |  |  | 21 | % |  |  | 22 | % |
| Avnet, Inc. |  |  | 20 | % |  |  | 19 | % |  |  | 20 | % |  |  | 18 | % |

[0001564590-16-029759:mdna:38]
[same as prior period, unchanged from 0001564590-16-024907:mdna:32]

[0001564590-16-029759:mdna:39]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |
| Product revenues |  | $ | 710 |  |  | $ | 815 |  |  |  | (13 | )% |  | $ | 1,370 |  |  | $ | 1,479 |  |  |  | (7 | )% |

[0001564590-16-029759:mdna:40]
Product revenues are derived through the sale of our strategic and mature solutions, and consist of sales of configured systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, original equipment manufacturer (OEM) products and add-on hardware and software.

[0001564590-16-029759:mdna:41]
Product revenues from strategic solutions represented 62% and 61% of product revenues in the second quarter and first six months of fiscal 2017, respectively, compared to 53% and 51% in the second quarter and first six months of the prior year. Product revenues from mature solutions represented 38% and 39% of product revenues, in the second quarter and first six months of fiscal 2017, respectively, compared to 47% and 49% in the second quarter and first six months of the prior year.

[0001564590-16-029759:mdna:42]
Total product revenues from strategic solutions totaled $439 million in the second quarter of fiscal 2017, reflecting a 1% increase from $434 million in the second quarter of fiscal 2016. This increase was primarily due to a 14% increase in unit volume of Clustered ONTAP systems, partially offset by a decrease in Average Selling Price (ASP) primarily due to shift in mix from high end to mid-range and entry level platforms, as well as higher discounting. Total product revenue from mature solutions totaled $270 million in the second quarter of fiscal 2017, reflecting a 29% decrease from $381 million in the second quarter of fiscal 2016. This decrease was primarily due to a 57% decrease in unit volume of 7-mode systems, as well as a decrease in ASP. In addition, add-on storage and related OS revenues decreased 23%. These fluctuations reflect the on-going trend of movement of customer demand from our older products to our newer products. However, OEM revenue increased 3% due to seasonal demand, which is not expected to be an on-going trend.

[0001564590-16-029759:mdna:43]
Total product revenues from strategic solutions totaled $839 million in the first six months of fiscal 2017, reflecting an 11% increase from $757 million in the first six months of fiscal 2016. This increase was primarily due to a 23% increase in unit volume of Clustered ONTAP systems, partially offset by a decrease in ASP reflecting higher discounting. Total product revenue from mature solutions totaled $531 million in the first six months of fiscal 2017, reflecting a 26% decrease from $722 million in the first six months of fiscal 2016. This decrease was primarily due to a 51% decrease in unit volume of 7-mode systems, as well as a decrease in ASP. In addition, add-on storage and related OS revenues decreased 18% and OEM revenue decreased 5%. These fluctuations are primarily due to the factors discussed above.

[0001564590-16-029759:mdna:44]
[same as prior period, unchanged from 0001564590-16-024907:mdna:37]

[0001564590-16-029759:mdna:45]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 242 |  |  | $ | 233 |  |  |  | 4 | % |  | $ | 483 |  |  | $ | 481 |  |  |  | — | % |

[0001564590-16-029759:mdna:46]
[same as prior period, unchanged from 0001564590-16-024907:mdna:39]

[0001564590-16-029759:mdna:47]
The fluctuations in software maintenance revenues reflect fluctuations in the aggregate contract value of the installed base under software maintenance contracts, which is recognized as revenue ratably over the terms of the underlying contracts.

[0001564590-16-029759:mdna:48]
[same as prior period, unchanged from 0001564590-16-024907:mdna:41]

[0001564590-16-029759:mdna:49]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 388 |  |  | $ | 397 |  |  |  | (2 | )% |  | $ | 781 |  |  | $ | 820 |  |  |  | (5 | )% |

[0001564590-16-029759:mdna:50]
[same as prior period, unchanged from 0001564590-16-024907:mdna:43]

[0001564590-16-029759:mdna:51]
Hardware maintenance contract revenues were $316 million for the second quarter of fiscal 2017 compared to $326 million for the second quarter of fiscal 2016. Professional services and educational and training services revenues were $72 million for the second quarter of fiscal 2017 compared to $71 million in the second quarter of fiscal 2016.

[0001564590-16-029759:mdna:52]
Hardware maintenance contract revenues were $639 million for the first six months of fiscal 2017 compared to $672 million for the first six months of fiscal 2016. The decrease in hardware maintenance contract revenues reflects one more week of maintenance revenue amortization in the first quarter of fiscal 2016 compared to fiscal 2017. Professional services and educational and training services revenues were $142 million for the first six months of fiscal 2017 compared to $148 million in the first six months of fiscal 2016.

[0001564590-16-029759:mdna:53]
[same as prior period, unchanged from 0001564590-16-024907:mdna:45]

[0001564590-16-029759:mdna:54]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| United States, Canada and Latin America (Americas) |  |  | 57 | % |  |  | 57 | % |  |  | 57 | % |  |  | 56 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 30 | % |  |  | 30 | % |  |  | 30 | % |  |  | 30 | % |
| Asia Pacific (APAC) |  |  | 13 | % |  |  | 14 | % |  |  | 13 | % |  |  | 13 | % |

[0001564590-16-029759:mdna:55]
[same as prior period, unchanged from 0001564590-16-024907:mdna:47]

[0001564590-16-029759:mdna:56]
Americas revenues consist of sales to Americas commercial and United States public sector (USPS) markets. Our geographic distribution of revenues as a percentage of net revenues was relatively consistent in the second quarter and first six months of fiscal 2017 compared to the second quarter and first six months of fiscal 2016.

[0001564590-16-029759:mdna:57]
[same as prior period, unchanged from 0001564590-16-024907:mdna:49]

[0001564590-16-029759:mdna:58]
[same as prior period, unchanged from 0001564590-16-024907:mdna:50]

[0001564590-16-029759:mdna:59]
[same as prior period, unchanged from 0001564590-16-024907:mdna:51]

[0001564590-16-029759:mdna:60]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |
| Cost of product revenues |  | $ | 376 |  |  | $ | 408 |  |  |  | (8 | )% |  | $ | 735 |  |  | $ | 753 |  |  |  | (2 | )% |

[0001564590-16-029759:mdna:61]
[same as prior period, unchanged from 0001564590-16-024907:mdna:53]

[0001564590-16-029759:mdna:62]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2017 to Fiscal 2016 |  |  | Fiscal 2017 to Fiscal 2016 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | (1 | ) |  |  | 6 |  |
| Warranty |  |  | (3 | ) |  |  | (2 | ) |
| Amortization of purchased intangible assets |  |  | (2 | ) |  |  | (2 | ) |
| Other |  |  | (2 | ) |  |  | (4 | ) |
| Total change |  |  | (8 | ) |  |  | (2 | ) |

[0001564590-16-029759:mdna:63]
Cost of product revenues represented 53% and 54% of product revenues for the second quarter and first six months of fiscal 2017, respectively, compared to 50% and 51% in the second quarter and first six months of fiscal 2016, respectively.

[0001564590-16-029759:mdna:64]
Materials costs represented 92% of product costs for the second quarter of fiscal 2017 compared to 86% in the second quarter of fiscal 2016, and decreased $6 million from the second quarter of fiscal 2016. Materials costs were impacted by a 21% increase in materials costs related to strategic products, primarily due to higher unit volume for configured Clustered ONTAP systems, partially offset by a 26% decrease in materials costs for mature products reflecting lower volume in 7-Mode systems. Average unit materials costs for Clustered ONTAP increased due to changes in platform and configuration mix, while average unit materials costs for 7-mode systems were relatively flat in the second quarter of fiscal 2017 compared to the corresponding period in the prior year.

[0001564590-16-029759:mdna:65]
Materials costs represented 91% of product costs for the first six months of fiscal 2017 compared to 83% in the first six months of fiscal 2016, and increased $46 million from the first six months of fiscal 2016. Materials costs were impacted by a 34% increase in materials costs related to strategic products, primarily due to an increase in volume for configured Clustered ONTAP systems, partially offset by a 20% decrease in materials costs for mature products reflecting a decrease in volume in 7-Mode systems. Average unit materials costs for both Clustered ONTAP and 7-mode systems increased in the first six months of fiscal 2017 compared to the corresponding period in the prior year, due to a combination of changes in platform and configuration mix.

[0001564590-16-029759:mdna:66]
The combination of changes in ASP, unit materials costs and volumes resulted in lower standard margins for both strategic and mature products in each of the first quarter and first six months of fiscal 2017 compared to the corresponding periods in the prior year.

[0001564590-16-029759:mdna:67]
Cost of product revenues in the second quarter and first six months of fiscal 2017 was also favorably impacted by decreases in warranty expense of $12 million and $17 million, respectively, compared to the corresponding periods in the prior year. The amortization of acquired intangibles in the second quarter and first six months of fiscal 2017 decreased $7 million and $14 million, respectively, compared to the corresponding periods in the prior year due to the impact of certain acquired developed technology being fully amortized by the end of fiscal 2016, partially offset by the amortization of developed technology related to the SolidFire acquisition.

[0001564590-16-029759:mdna:68]
[same as prior period, unchanged from 0001564590-16-024907:mdna:59]

[0001564590-16-029759:mdna:69]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 7 |  |  | $ | 9 |  |  |  | (22 | )% |  | $ | 15 |  |  | $ | 19 |  |  |  | (21 | )% |

[0001564590-16-029759:mdna:70]
Cost of software maintenance revenues decreased in the second quarter and first six months of fiscal 2017 compared to the second quarter and first six months of fiscal 2016. Cost of software maintenance revenues represented 3% of software maintenance revenues for each of the second quarter and first six months of fiscal 2017 compared to 4% of software maintenance revenues for each of the second quarter and first six months of 2016.

[0001564590-16-029759:mdna:71]
[same as prior period, unchanged from 0001564590-16-024907:mdna:74]

[0001564590-16-029759:mdna:72]
[same as prior period, unchanged from 0001564590-16-024907:mdna:62]

[0001564590-16-029759:mdna:73]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 128 |  |  | $ | 144 |  |  |  | (11 | )% |  | $ | 258 |  |  | $ | 308 |  |  |  | (16 | )% |

[0001564590-16-029759:mdna:74]
Cost of hardware maintenance and other services revenues decreased $16 million and $50 million for the second quarter and first six months of fiscal 2017, respectively, compared to the corresponding periods of the prior year, primarily due to the benefits of our cost reduction initiatives. Costs represented 33% of hardware and maintenance and other services revenues in each of the second quarter and first six months of fiscal 2017 compared to 36% and 38% in the second quarter and first six months of fiscal 2016, respectively.

[0001564590-16-029759:mdna:75]
[same as prior period, unchanged from 0001564590-16-024907:mdna:65]

[0001564590-16-029759:mdna:76]
[same as prior period, unchanged from 0001564590-16-024907:mdna:66]

[0001564590-16-029759:mdna:77]
[same as prior period, unchanged from 0001564590-16-024907:mdna:67]

[0001564590-16-029759:mdna:78]
Total compensation costs included in operating expenses decreased $10 million, or 3%, in the second quarter of fiscal 2017 compared to the second quarter of fiscal 2016 primarily due to lower salary and stock-based compensation expenses reflecting a 13% decrease in average headcount as a result of restructuring plans, partially offset by higher incentive compensation expense, reflecting stronger operating performance against goals, and the impact of the SolidFire acquisition.

[0001564590-16-029759:mdna:79]
Total compensation costs included in operating expenses decreased $89 million, or 10%, in the first six months of fiscal 2017 compared to the first six months of fiscal 2016 primarily due to lower salary and stock-based compensation expenses reflecting a 14% decrease in average headcount as a result of restructuring plans and the impact of one more week in the first quarter of fiscal 2016 compared to fiscal 2017, partially offset by higher incentive compensation expense, reflecting stronger operating performance against goals, and increased operating expenses related to the SolidFire acquisition.

[0001564590-16-029759:mdna:80]
[same as prior period, unchanged from 0001564590-16-024907:mdna:69]

[0001564590-16-029759:mdna:81]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 418 |  |  | $ | 448 |  |  |  | (7 | )% |  | $ | 847 |  |  | $ | 940 |  |  |  | (10 | )% |

[0001564590-16-029759:mdna:82]
[same as prior period, unchanged from 0001564590-16-024907:mdna:71]

[0001564590-16-029759:mdna:83]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2017 to Fiscal 2016 |  |  | Fiscal 2017 to Fiscal 2016 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (2 | ) |  |  | (5 | ) |
| Facilities and IT support costs |  |  | (3 | ) |  |  | (3 | ) |
| Other |  |  | (2 | ) |  |  | (2 | ) |
| Total change |  |  | (7 | ) |  |  | (10 | ) |

[0001564590-16-029759:mdna:84]
Compensation costs for the second quarter and the first six months of fiscal 2017 compared to the corresponding periods in the prior year were favorably impacted by lower salary and stock-based compensation expenses due to an 11% decrease in average headcount, but were unfavorably impacted by higher incentive compensation expense. Facilities and IT support costs for the second quarter and first six months of 2017 compared to the corresponding periods of the prior year were favorably impacted by cost containment efforts. In addition, sales and marketing expenses were favorably impacted in the first six months of fiscal 2017 due to the first quarter of fiscal 2016 having one more week than the first quarter of fiscal 2017.

[0001564590-16-029759:mdna:85]
[same as prior period, unchanged from 0001564590-16-024907:mdna:88]

[0001564590-16-029759:mdna:86]
[same as prior period, unchanged from 0001564590-16-024907:mdna:75]

[0001564590-16-029759:mdna:87]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |
| Research and development expenses |  | $ | 200 |  |  | $ | 216 |  |  |  | (7 | )% |  | $ | 407 |  |  | $ | 460 |  |  |  | (12 | )% |

[0001564590-16-029759:mdna:88]
[same as prior period, unchanged from 0001564590-16-024907:mdna:77]

[0001564590-16-029759:mdna:89]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2017 to Fiscal 2016 |  |  | Fiscal 2017 to Fiscal 2016 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (2 | ) |  |  | (8 | ) |
| Development projects and outside services |  |  | (2 | ) |  |  | (1 | ) |
| Facilities and IT support costs |  |  | (1 | ) |  |  | (1 | ) |
| Other |  |  | (2 | ) |  |  | (2 | ) |
| Total change |  |  | (7 | ) |  |  | (12 | ) |

[0001564590-16-029759:mdna:90]
Compensation costs for the second quarter and first six months of fiscal 2017 compared to the corresponding periods of the prior year primarily were favorably impacted by lower salary and stock-based compensation expenses due to a 17% and 19% decrease in average headcount, respectively but were unfavorably impacted by higher incentive compensation expense. Development projects and outside services for the second quarter and first six months of fiscal 2017 compared to the corresponding periods of the prior year were favorably impacted by lower spending on materials and services associated with engineering activities to develop new product lines and enhancements to existing products due to the completion of certain key development projects. Facilities and IT support costs for the second quarter and first six months of 2017 compared to the corresponding periods of the prior year were favorably impacted by cost containment efforts. In addition, research and development expenses were favorably impacted in the first six months of fiscal 2017 due to the first quarter of fiscal 2016 having one more week than the first quarter of fiscal 2017.

[0001564590-16-029759:mdna:91]
[same as prior period, unchanged from 0001564590-16-024907:mdna:80]

[0001564590-16-029759:mdna:92]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |
| General and administrative expenses |  | $ | 69 |  |  | $ | 74 |  |  |  | (7 | )% |  | $ | 137 |  |  | $ | 153 |  |  |  | (10 | )% |

[0001564590-16-029759:mdna:93]
[same as prior period, unchanged from 0001564590-16-024907:mdna:82]

[0001564590-16-029759:mdna:94]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2017 to Fiscal 2016 |  |  | Fiscal 2017 to Fiscal 2016 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | 2 |  |  |  | (6 | ) |
| Professional and legal fees and outside services |  |  | (6 | ) |  |  | (2 | ) |
| Other |  |  | (3 | ) |  |  | (2 | ) |
| Total change |  |  | (7 | ) |  |  | (10 | ) |

[0001564590-16-029759:mdna:95]
Compensation costs for the second quarter and the first six months of fiscal 2017 compared to the second quarter of fiscal 2016 were favorably impacted by lower salary and stock-based compensation expenses due to an 8% decrease in average headcount, but were unfavorably impacted by higher incentive compensation expense. Professional and legal fees and outside services expense for the second quarter and first six months of fiscal 2017 compared to the corresponding periods of the prior year were favorably impacted by lower spending levels on consulting fees and projects. In addition, general and administrative expenses were favorably impacted in the first six months of fiscal 2017 due to the first quarter of fiscal 2016 having one more week than the first quarter of fiscal 2017.

[0001564590-16-029759:mdna:96]
29

[0001564590-16-029759:mdna:97]
[same as prior period, unchanged from 0001564590-16-024907:mdna:85]

[0001564590-16-029759:mdna:98]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  | % Change |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |
| Restructuring and other charges |  | $ | — |  |  | 1 |  |  | (100 | )% |  | $ | — |  |  |  | 28 |  |  |  | (100 | )% |

[0001564590-16-029759:mdna:99]
During fiscal 2016, management approved two restructuring actions to streamline our business, eliminate costs and redirect resources to our highest return activities, which included a restructuring plan announced in May 2015 under which we reduced our global workforce by approximately 3%. Restructuring and other charges related to this plan consisted primarily of employee severance-related costs. See Note 11 – Restructuring and Other Charges of the Notes to Condensed Consolidated Financial Statements for more details regarding our restructuring plans.

[0001564590-16-029759:mdna:100]
[same as prior period, unchanged from 0001564590-16-024907:mdna:89]

[0001564590-16-029759:mdna:101]
[same as prior period, unchanged from 0001564590-16-024907:mdna:90]

[0001564590-16-029759:mdna:102]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |
| Interest income |  | $ | 10 |  |  | $ | 11 |  |  |  | (9 | )% |  | $ | 21 |  |  | $ | 24 |  |  |  | (13 | )% |
| Interest expense |  |  | (12 | ) |  |  | (12 | ) |  |  | — | % |  |  | (27 | ) |  |  | (23 | ) |  |  | 17 | % |
| Other income, net |  |  | 2 |  |  |  | — |  |  | NM |  |  |  | 5 |  |  |  | 2 |  |  |  | 150 | % |
| Total |  | $ | — |  |  | $ | (1 | ) |  |  | (100 | )% |  | $ | (1 | ) |  | $ | 3 |  |  | NM |  |

[0001564590-16-029759:mdna:103]
[same as prior period, unchanged from 0001564590-16-024907:mdna:92]

[0001564590-16-029759:mdna:104]
The decreases in interest income in the second quarter and first six months of fiscal 2017 compared to the corresponding periods of the prior year were primarily due to a decrease in the size of our investment portfolio.

[0001564590-16-029759:mdna:105]
[same as prior period, unchanged from 0001564590-16-024907:mdna:94]

[0001564590-16-029759:mdna:106]
[same as prior period, unchanged from 0001564590-16-024907:mdna:95]

[0001564590-16-029759:mdna:107]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | % Change |  |
| Provision for income taxes |  | $ | 33 |  |  | $ | 30 |  |  |  | 10 | % |  | $ | 61 |  |  | $ | 38 |  |  |  | 61 | % |

[0001564590-16-029759:mdna:108]
Our effective tax rate for the second quarter of fiscal 2017 was 23.2% compared to an effective tax rate of 20.8% for the second quarter of fiscal 2016. Our effective tax rate for the first six months of fiscal 2017 was 26.1% compared to an effective tax rate of 31.1% for the first six months of fiscal 2016. Our effective tax rates reflect our corporate legal entity structure and the global nature of our business, with a significant amount of our profits generated and taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The effective tax rates for all periods presented were favorably impacted by the geographic mix of profits. Our effective tax rates decreased for the first six months of fiscal 2017, compared to the corresponding period in the prior year primarily as a result of differences in the respective periods’ income before taxes, as well as the impacts of discrete events described below.

[0001564590-16-029759:mdna:109]
In the first quarter of fiscal 2017, we adopted a new accounting standard that simplifies stock-based compensation income tax accounting and presentation within the financial statements. During the first six months of fiscal 2017, we recorded a discrete charge of $17 million following the post-adoption rules which require that all excess tax benefits and deficiencies from stock-based compensation be recognized as a component of income tax expense.

[0001564590-16-029759:mdna:110]
In June 2015, the IRS signed a closing agreement on our fiscal 2008 to 2010 transfer pricing arrangements and in October 2015 completed the examination of our fiscal 2008 to 2010 income tax returns. During the first six months of fiscal 2016, we recorded discrete charges totaling $23 million attributable to the audit settlements and related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-16-029759:mdna:111]
As of October 28, 2016, we had $212 million of gross unrecognized tax benefits, of which $154 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $156 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-16-029759:mdna:112]
[same as prior period, unchanged from 0001564590-16-024907:mdna:101]

[0001564590-16-029759:mdna:113]
[same as prior period, unchanged from 0001564590-16-024907:mdna:118]

[0001564590-16-029759:mdna:114]
[same as prior period, unchanged from 0001564590-16-024907:mdna:102]

[0001564590-16-029759:mdna:115]
| (In millions, except percentages) |  | October 28, 2016 |  |  | April 29, 2016 |  |
| Cash, cash equivalents and short-term investments |  | $ | 4,357 |  |  | $ | 5,303 |  |
| Principal amount of debt |  | $ | 1,500 |  |  | $ | 2,350 |  |
| Debt as a percentage of stockholders' equity |  |  | 54 | % |  |  | 82 | % |

[0001564590-16-029759:mdna:116]
The following is a summary of our cash flows:

[0001564590-16-029759:mdna:117]
|  |  | Six Months Ended |  |
| (In millions) |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Net cash provided by operating activities |  | $ | 386 |  |  | $ | 274 |  |
| Net cash provided by investing activities |  |  | 97 |  |  |  | 704 |  |
| Net cash used in financing activities |  |  | (1,225 | ) |  |  | (694 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (13 | ) |  |  | (8 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (755 | ) |  | $ | 276 |  |

[0001564590-16-029759:mdna:118]
[same as prior period, unchanged from 0001564590-16-024907:mdna:106]

[0001564590-16-029759:mdna:119]
As of October 28, 2016, our cash, cash equivalents and short-term investments were $4.4 billion, a decrease of $0.9 billion from April 29, 2016. The decrease was primarily due to $850 million used to repay our short-term loan, $292 million paid for the repurchase of our common stock and $105 million used for the payment of dividends, partially offset by $386 million of cash provided by operating activities. Accounts receivable DSO was 37 days for the second quarter of fiscal 2017 compared to 54 days for the fourth quarter of fiscal 2016 and 37 days for the second quarter of fiscal 2016, reflecting seasonal patterns of shipment linearity. Working capital decreased by $94 million to $2.7 billion as of October 28, 2016 primarily due to a decrease in cash, cash equivalents and short-term investments and accounts receivable, partially offset by the repayment of our short-term loan and a decrease in accrued expenses.

[0001564590-16-029759:mdna:120]
[same as prior period, unchanged from 0001564590-16-024907:mdna:108]

[0001564590-16-029759:mdna:121]
During the first six months of fiscal 2017, we generated cash from operating activities of $386 million, reflecting net income of $173 million, adjusted by non-cash depreciation and amortization of $117 million and stock-based compensation of $103 million, compared to $274 million of cash generated from operating activities during the first six months of 2016.

[0001564590-16-029759:mdna:122]
Changes in assets and liabilities in the first six months of fiscal 2017 included the following:

[0001564590-16-029759:mdna:123]
|  | • | Accounts receivable decreased $264 million, primarily due to lower seasonal invoicing levels in the second quarter of fiscal 2017 compared to the fourth quarter of fiscal 2016. |

[0001564590-16-029759:mdna:124]
|  | • | Accrued compensation decreased $83 million, primarily due to employee compensation payouts related to fiscal year 2016 commissions and incentive compensation plans, as well as payments of restructuring obligations. |

[0001564590-16-029759:mdna:125]
|  | • | Deferred revenue and financed unearned services revenue decreased $179 million, primarily due to a decrease in deferred software and hardware maintenance contract revenues reflecting the seasonality of maintenance contract renewal activities. |

[0001564590-16-029759:mdna:126]
We expect that cash provided by operating activities may materially fluctuate in future periods due to a number of factors, including fluctuations in our operating results, shipment linearity, accounts receivable collections performance, inventory and supply chain management, vendor payment initiatives, tax benefits or charges from stock-based compensation, and the timing and amount of compensation and other payments.

[0001564590-16-029759:mdna:127]
[same as prior period, unchanged from 0001564590-16-024907:mdna:114]

[0001564590-16-029759:mdna:128]
During the first six months of fiscal 2017, we generated $190 million from maturities and sales of investments, net of purchases, and paid $92 million for capital expenditures compared to $788 million and $84 million, respectively, during the first six months of fiscal 2016.

[0001564590-16-029759:mdna:129]
[same as prior period, unchanged from 0001564590-16-024907:mdna:116]

[0001564590-16-029759:mdna:130]
During the first six months of fiscal 2017, we used $850 million to repay our short-term loan, $292 million for the repurchase of 11 million shares of our common stock and $105 million for the payment of dividends, compared to $613 million used for the repurchase of common stock and $107 million for the payment of dividends during the first six months of fiscal 2016.

[0001564590-16-029759:mdna:131]
[same as prior period, unchanged from 0001564590-16-024907:mdna:130]

[0001564590-16-029759:mdna:132]
[same as prior period, unchanged from 0001564590-16-024907:mdna:119]

[0001564590-16-029759:mdna:133]
[same as prior period, unchanged from 0001564590-16-024907:mdna:120]

[0001564590-16-029759:mdna:134]
Our principal sources of liquidity as of October 28, 2016 consisted of cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001564590-16-029759:mdna:135]
[same as prior period, unchanged from 0001564590-16-024907:mdna:122]

[0001564590-16-029759:mdna:136]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
| Cash and cash equivalents |  | $ | 2,113 |  |  | $ | 2,868 |  |
| Short-term investments |  |  | 2,244 |  |  |  | 2,435 |  |
| Total |  | $ | 4,357 |  |  | $ | 5,303 |  |

[0001564590-16-029759:mdna:137]
As of October 28, 2016 and April 29, 2016, $3.9 billion and $4.8 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.5 billion was available in the U.S.as of each of those dates. Most of the amounts held outside the U.S. can be repatriated to the U.S. but, under current law, would be subject to U.S. federal, state income and foreign withholding taxes. If we were to repatriate foreign earnings to fund cash requirements in the U.S., we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state tax credit carryforwards. However, our intent is to keep these funds permanently reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, and invest in critical or complementary technologies, and service interest and principal payments on our debt.

[0001564590-16-029759:mdna:138]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of October 28, 2016.

[0001564590-16-029759:mdna:139]
[same as prior period, unchanged from 0001564590-16-024907:mdna:126]

[0001564590-16-029759:mdna:140]
[same as prior period, unchanged from 0001564590-16-024907:mdna:127]

[0001564590-16-029759:mdna:141]
The following table summarizes the principal amount of our Senior Notes as of October 28, 2016 (in millions):

[0001564590-16-029759:mdna:142]
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |
| Total |  | $ | 1,500 |  |

[0001564590-16-029759:mdna:143]
[same as prior period, unchanged from 0001564590-16-024907:mdna:147]

[0001564590-16-029759:mdna:144]
[same as prior period, unchanged from 0001564590-16-024907:mdna:131]

[0001564590-16-029759:mdna:145]
[same as prior period, unchanged from 0001564590-16-024907:mdna:132]

[0001564590-16-029759:mdna:146]
Credit Facility

[0001564590-16-029759:mdna:147]
Our credit facility, under which we may borrow up to $300 million, provides another potential source of liquidity. The credit facility is an unsecured five-year revolving credit facility that terminates on December 21, 2017 if no extensions have been requested at that time, and contains financial covenants requiring us to maintain a maximum leverage ratio and a minimum interest coverage ratio. We may also, subject to certain requirements, request an increase in the facility up to an additional $50 million and request two additional one-year extensions, subject to certain conditions. As of October 28, 2016, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-16-029759:mdna:148]
Restructuring Activities

[0001564590-16-029759:mdna:149]
On November 3, 2016, we announced a restructuring and reduction in workforce to streamline our business and reduce operating expenses. In connection with these actions, we expect to reduce our worldwide headcount by approximately 6%. The reduction in workforce will be implemented through the end of the fourth quarter of this fiscal year. We expect to incur aggregate charges of approximately $50 to $60 million for employee terminations and other costs associated with the restructuring, consisting primarily of cash expenditures. The majority of these charges will be recognized in the third quarter of fiscal 2017.

[0001564590-16-029759:mdna:150]
[same as prior period, unchanged from 0001564590-16-024907:mdna:135]

[0001564590-16-029759:mdna:151]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2017 to be between $75 and $100 million.

[0001564590-16-029759:mdna:152]
[same as prior period, unchanged from 0001564590-16-024907:mdna:137]

[0001564590-16-029759:mdna:153]
On November 16, 2016, we declared a cash dividend of $0.19 per share of common stock, payable on January 25, 2017 to holders of record as of the close of business on January 6, 2017.

[0001564590-16-029759:mdna:154]
As of October 28, 2016, our Board of Directors had authorized the repurchase of up to $9.6 billion of our common stock under our stock repurchase program. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through October 28, 2016, we repurchased a total of 258 million shares of our common stock at an average price of $32.64 per share, for an aggregate purchase price of $8.4 billion. As of October 28, 2016, the remaining authorized amount for stock repurchases under this program was $1.2 billion, with no termination date, which we plan to complete by May 2018.

[0001564590-16-029759:mdna:155]
[same as prior period, unchanged from 0001564590-16-024907:mdna:140]

[0001564590-16-029759:mdna:156]
[same as prior period, unchanged from 0001564590-16-024907:mdna:141]

[0001564590-16-029759:mdna:157]
[same as prior period, unchanged from 0001564590-16-024907:mdna:142]

[0001564590-16-029759:mdna:158]
As of October 28, 2016, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $238 million.

[0001564590-16-029759:mdna:159]
[same as prior period, unchanged from 0001564590-16-024907:mdna:161]

[0001564590-16-029759:mdna:160]
[same as prior period, unchanged from 0001564590-16-024907:mdna:144]

[0001564590-16-029759:mdna:161]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of October 28, 2016, we had $291 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-16-029759:mdna:162]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of October 28, 2016, we had $15 million in construction-related obligations and $231 million in other purchase obligations.

[0001564590-16-029759:mdna:163]
[same as prior period, unchanged from 0001564590-16-024907:mdna:148]

[0001564590-16-029759:mdna:164]
As of October 28, 2016, our liability for uncertain tax positions was $144 million, including interest, penalties and offsetting indirect benefits. Due to the uncertainty of the timing of future cash payments, we cannot make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-16-029759:mdna:165]
[same as prior period, unchanged from 0001564590-16-024907:mdna:150]

[0001564590-16-029759:mdna:166]
In fiscal 2016, we entered into sale-leaseback arrangements of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, the assets will remain on our condensed consolidated balance sheets and proceeds received by us from these transactions are reported as financing obligations. As of October 28, 2016, the balance of these financing obligations was $149 million. At the end of each respective leaseback period, or when our continuing involvement under the leaseback agreements ends, each transaction will be reported as a non-cash sale of land and buildings and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain on sale of properties.

[0001564590-16-029759:mdna:167]
[same as prior period, unchanged from 0001564590-16-024907:mdna:152]

[0001564590-16-029759:mdna:168]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $108 million and $72 million of receivables during the first six months of fiscal 2017 and fiscal 2016, respectively.

[0001564590-16-029759:mdna:169]
[same as prior period, unchanged from 0001564590-16-024907:mdna:154]

[0001564590-16-029759:mdna:170]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of October 28, 2016 and April 29, 2016, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0001564590-16-029759:mdna:171]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of October 28, 2016, we have not been required

[0001564590-16-029759:mdna:172]
34

[0001564590-16-029759:mdna:173]
to make any significant payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-16-029759:mdna:174]
[same as prior period, unchanged from 0001564590-16-024907:mdna:157]

[0001564590-16-029759:mdna:175]
[same as prior period, unchanged from 0001564590-16-024907:mdna:158]

[0001564590-16-029759:mdna:176]
Legal Contingencies

[0001564590-16-029759:mdna:177]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0001564590-16-029759:mdna:178]
35
