# NTAP 8-K — 0001564590-16-029385 filed 2016-11-16

## item codes, every 8-K on or before 2016-12-02

- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2016-12-02

- none on or before 2016-12-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-16-029385:8k_2_02:1]
EX-99.1
2
ntap-ex991_6.htm
EX-99.1

[0001564590-16-029385:8k_2_02:2]
ntap-ex991_6.htm

[0001564590-16-029385:8k_2_02:3]
Exhibit 99.1

[0001564590-16-029385:8k_2_02:4]
NETAPP REPORTS SECOND QUARTER FISCAL YEAR 2017 RESULTS

[0001564590-16-029385:8k_2_02:5]
Net Revenues of $1.34 Billion; Up 4% Quarter-over-Quarter;

[0001564590-16-029385:8k_2_02:6]
GAAP EPS of $0.38 and Non-GAAP EPS of $0.60

[0001564590-16-029385:8k_2_02:7]
| • | All flash array annualized net revenue run rate exceeded $1 billion |

[0001564590-16-029385:8k_2_02:8]
| • | Over 200 petabytes of flash shipped |

[0001564590-16-029385:8k_2_02:9]
| • | Clustered Data ONTAP™ deployed on 86% of systems shipped |

[0001564590-16-029385:8k_2_02:10]
| • | $169 million returned to shareholders in share repurchases and cash dividends |

[0001564590-16-029385:8k_2_02:11]
Sunnyvale, Calif.—November 16, 2016—NetApp (NASDAQ: NTAP) today reported financial results for the second quarter fiscal year 2017, ended October 28, 2016.

[0001564590-16-029385:8k_2_02:12]
Second Quarter Financial Results

[0001564590-16-029385:8k_2_02:13]
Net revenues for the second quarter of fiscal year 2017 were $1.34 billion. GAAP net income for the second quarter of fiscal year 2017 was $109 million, or $0.38 per share,1 compared to GAAP net income of $114 million, or $0.39 per share, for the comparable period of the prior year. Non-GAAP net income for the second quarter of fiscal year 2017 was $169 million, or $0.60 per share,2 compared to non-GAAP net income of $181 million, or $0.61 per share, for the comparable period of the prior year.

[0001564590-16-029385:8k_2_02:14]
Cash, Cash Equivalents and Investments

[0001564590-16-029385:8k_2_02:15]
NetApp ended the second quarter of fiscal year 2017 with $4.4 billion in total cash, cash equivalents and investments. During the second quarter of fiscal year 2017, the Company generated $158 million in cash from operations and returned $169 million to shareholders through share repurchases and a cash dividend.

[0001564590-16-029385:8k_2_02:16]
The Company announced the next cash dividend of $0.19 per share. The quarterly dividend will be paid on January 25, 2017, to shareholders of record as of the close of business on January 6, 2017.

[0001564590-16-029385:8k_2_02:17]
“Our second quarter results are evidence of our ability to maintain a high level of execution while streamlining the business and pivoting to the growth areas of the market,” said George Kurian, chief executive officer. “Our market-leading innovations in flash, next-generation data centers and hybrid cloud, coupled with a sharp focus on operational discipline, position NetApp to lead in the digital era.”

[0001564590-16-029385:8k_2_02:18]
Q3 Fiscal Year 2017 Outlook

[0001564590-16-029385:8k_2_02:19]
The Company provided the following financial guidance for the third quarter of fiscal year 2017:

[0001564590-16-029385:8k_2_02:20]
| • | Net revenues are expected to be in the range of $1.325 billion to $1.475 billion. |

[0001564590-16-029385:8k_2_02:21]
| • | GAAP earnings per share is expected to be in the range of $0.41 to $0.46 per share. |

[0001564590-16-029385:8k_2_02:22]
| • | Non-GAAP earnings per share is expected to be in the range of $0.72 to $0.77 per share. |

[0001564590-16-029385:8k_2_02:23]
Business Highlights

[0001564590-16-029385:8k_2_02:24]
| • | Increasing Flash Momentum |

[0001564590-16-029385:8k_2_02:25]
|  | - | NetApp Recognized as a Leader in Gartner Magic Quadrant for Solid-State Arrays. NetApp named a Leader in the 2016 Gartner Magic Quadrant for Solid-State Arrays, based on the ability to execute and the completeness of vision. According to Gartner, Leaders execute well against their current vision and are well positioned for tomorrow.3 |

[0001564590-16-029385:8k_2_02:26]
|  | - | NetApp Takes Top Honors for Customer Implementation, Brand Leadership at Flash Memory Summit 2016. NetApp’s SolidFire™ deployment was recognized for customer innovation at Internet Solutions and NetApp swept all six brand leadership categories for all-flash NAS and unified SAN/NAS arrays in the 2016 Brand Leader Survey. |

[0001564590-16-029385:8k_2_02:27]
| • | Simplifying Data Management with New Solutions |

[0001564590-16-029385:8k_2_02:28]
|  | - | New NetApp Software and Flash Systems Simplify Data Management. NetApp ONTAP software, flash systems and expanded public cloud support for Microsoft Azure provide the modern foundation to help customers maximize the value of data in the hybrid cloud. |

[0001564590-16-029385:8k_2_02:29]
|  | - | NetApp Boosts Performance, Lowers Cost of Data Analytics Applications for Midsize Businesses, Remote Offices. NetApp SANtricity™ software and the entry-level E2800 all-flash array deliver affordable performance and simplify the process of extracting value from third platform data. |

[0001564590-16-029385:8k_2_02:30]
| • | Delivering Positive Customer Outcomes |

[0001564590-16-029385:8k_2_02:31]
|  | - | UZ Leuven Speeds Collaboration of 17 Hospitals with NetApp Flash. This hospital network teams with NetApp to move, manage, and protect 6PB of critical patient data and was able to roll out new features across 17 hospitals within business hours with no downtime. |

[0001564590-16-029385:8k_2_02:32]
|  | - | Inland Northwest Health Services/Engage Protects Critical Patient Data, Boosts Care with NetApp. NetApp helped the technology arm for this healthcare provider create a new cloud service based on AltaVault™ that allows it to easily and affordably secure critical customer data. |

[0001564590-16-029385:8k_2_02:33]
|  | - | Buzinessware Fuels its On-demand Managed Infrastructure with NetApp SolidFire All-Flash Storage. Buzinessware, a Middle Eastern hosting and cloud service provider, teams with NetApp to deliver the exact level of performance required for each customer application and is able to make changes to performance and capacity on the fly without any disruption. |

[0001564590-16-029385:8k_2_02:34]
|  | - | RapidScale Accelerates Enterprise Profitability with NetApp. NetApp’s All Flash FAS gives RapidScale, a cloud service provider, a solid foundation to support its 100% annual growth, helping to preserve profit margins through storage efficiency, administration, and time savings. |

[0001564590-16-029385:8k_2_02:35]
|  | - | TechnologyOne Selects NetApp to Improve Profitability and Efficiency of Its SaaS Cloud Offering. NetApp enabled Australia’s largest enterprise software company to respond to changing customer needs by adopting a multi-cloud approach without increasing costs or complexity. |

[0001564590-16-029385:8k_2_02:36]
Webcast and Conference Call Information

[0001564590-16-029385:8k_2_02:37]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:30 p.m. Pacific Time today.

[0001564590-16-029385:8k_2_02:38]
About NetApp

[0001564590-16-029385:8k_2_02:39]
Leading organizations worldwide count on NetApp for software, systems and services to manage and store their data. Customers value our teamwork, expertise and passion for helping them succeed now and into the future. To learn more, visit www.netapp.com.

[0001564590-16-029385:8k_2_02:40]
###

[0001564590-16-029385:8k_2_02:41]
NetApp and the NetApp logo and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. Other company and product names may be trademarks of their respective owners.

[0001564590-16-029385:8k_2_02:42]
1 GAAP earnings per share is calculated using the diluted number of shares.

[0001564590-16-029385:8k_2_02:43]
2Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) acquisition-related expenses, (d) restructuring and other charges, (e) asset impairments, (f) gains/losses on the sale of properties, and (g) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0001564590-16-029385:8k_2_02:44]
3Gartner Research Methodologies, Gartner Magic Quadrant, www.gartner.com/technology/research/methodologies/research_mq.jsp

[0001564590-16-029385:8k_2_02:45]
Gartner, Magic Quadrant for Solid-State Arrays, Valdis Filks, Joseph Unsworth, Arun Chandrasekaran, 22 August 2016

[0001564590-16-029385:8k_2_02:46]
NetApp Usage of Non-GAAP Financial Information

[0001564590-16-029385:8k_2_02:47]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, and free cash flow, and historical and projected non-GAAP earnings per diluted share.

[0001564590-16-029385:8k_2_02:48]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp believes

[0001564590-16-029385:8k_2_02:49]
that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock, after deducting capital expenditures. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0001564590-16-029385:8k_2_02:50]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001564590-16-029385:8k_2_02:51]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0001564590-16-029385:8k_2_02:52]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0001564590-16-029385:8k_2_02:53]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0001564590-16-029385:8k_2_02:54]
C. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP

[0001564590-16-029385:8k_2_02:55]
measures, primarily because they are not related to our ongoing business or cost base and, therefore, cannot be relied upon for future planning and forecasting.

[0001564590-16-029385:8k_2_02:56]
D. Restructuring and other charges. These charges include restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. These items are not ordinarily included in our annual operating plan and related budget due to the unpredictability of the timing and size of these events. We therefore exclude them in our assessment of operational performance.

[0001564590-16-029385:8k_2_02:57]
E. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0001564590-16-029385:8k_2_02:58]
F. Gains/losses on the sale of properties. These are gains/losses from the sale of our properties. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, cannot be relied upon for future planning or forecasting.

[0001564590-16-029385:8k_2_02:59]
G. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual properties from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0001564590-16-029385:8k_2_02:60]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by

[0001564590-16-029385:8k_2_02:61]
other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0001564590-16-029385:8k_2_02:62]
NETAPP, INC.

[0001564590-16-029385:8k_2_02:63]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-16-029385:8k_2_02:64]
(In millions)

[0001564590-16-029385:8k_2_02:65]
(Unaudited)

[0001564590-16-029385:8k_2_02:66]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,357 |  |  | $ | 5,303 |  |
| Accounts receivable |  |  | 547 |  |  |  | 813 |  |
| Inventories |  |  | 97 |  |  |  | 98 |  |
| Other current assets |  |  | 219 |  |  |  | 234 |  |
| Total current assets |  |  | 5,220 |  |  |  | 6,448 |  |
| Property and equipment, net |  |  | 949 |  |  |  | 937 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,834 |  |  |  | 1,856 |  |
| Other non-current assets |  |  | 759 |  |  |  | 796 |  |
| Total assets |  | $ | 8,762 |  |  | $ | 10,037 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 253 |  |  | $ | 254 |  |
| Accrued expenses |  |  | 620 |  |  |  | 765 |  |
| Short-term loan |  |  | — |  |  |  | 849 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,655 |  |  |  | 1,794 |  |
| Total current liabilities |  |  | 2,528 |  |  |  | 3,662 |  |
| Long-term debt |  |  | 1,492 |  |  |  | 1,490 |  |
| Other long-term liabilities |  |  | 407 |  |  |  | 413 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,546 |  |  |  | 1,591 |  |
| Total liabilities |  |  | 5,973 |  |  |  | 7,156 |  |
| Stockholders' equity |  |  | 2,789 |  |  |  | 2,881 |  |
| Total liabilities and stockholders' equity |  | $ | 8,762 |  |  | $ | 10,037 |  |

[0001564590-16-029385:8k_2_02:67]
NETAPP, INC.

[0001564590-16-029385:8k_2_02:68]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-16-029385:8k_2_02:69]
(In millions, except per share amounts)

[0001564590-16-029385:8k_2_02:70]
(Unaudited)

[0001564590-16-029385:8k_2_02:71]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 710 |  |  | $ | 815 |  |  | $ | 1,370 |  |  | $ | 1,479 |  |
| Software maintenance |  |  | 242 |  |  |  | 233 |  |  |  | 483 |  |  |  | 481 |  |
| Hardware maintenance and other services |  |  | 388 |  |  |  | 397 |  |  |  | 781 |  |  |  | 820 |  |
| Net revenues |  |  | 1,340 |  |  |  | 1,445 |  |  |  | 2,634 |  |  |  | 2,780 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 376 |  |  |  | 408 |  |  |  | 735 |  |  |  | 753 |  |
| Cost of software maintenance |  |  | 7 |  |  |  | 9 |  |  |  | 15 |  |  |  | 19 |  |
| Cost of hardware maintenance and other services |  |  | 128 |  |  |  | 144 |  |  |  | 258 |  |  |  | 308 |  |
| Total cost of revenues |  |  | 511 |  |  |  | 561 |  |  |  | 1,008 |  |  |  | 1,080 |  |
| Gross profit |  |  | 829 |  |  |  | 884 |  |  |  | 1,626 |  |  |  | 1,700 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 418 |  |  |  | 448 |  |  |  | 847 |  |  |  | 940 |  |
| Research and development |  |  | 200 |  |  |  | 216 |  |  |  | 407 |  |  |  | 460 |  |
| General and administrative |  |  | 69 |  |  |  | 74 |  |  |  | 137 |  |  |  | 153 |  |
| Restructuring and other charges |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 28 |  |
| Total operating expenses |  |  | 687 |  |  |  | 739 |  |  |  | 1,391 |  |  |  | 1,581 |  |
| Income from operations |  |  | 142 |  |  |  | 145 |  |  |  | 235 |  |  |  | 119 |  |
| Other income (expense), net |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |  |  | 3 |  |
| Income before income taxes |  |  | 142 |  |  |  | 144 |  |  |  | 234 |  |  |  | 122 |  |
| Provision for income taxes |  |  | 33 |  |  |  | 30 |  |  |  | 61 |  |  |  | 38 |  |
| Net income |  | $ | 109 |  |  | $ | 114 |  |  | $ | 173 |  |  | $ | 84 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.39 |  |  | $ | 0.39 |  |  | $ | 0.62 |  |  | $ | 0.28 |  |
| Diluted |  | $ | 0.38 |  |  | $ | 0.39 |  |  | $ | 0.61 |  |  | $ | 0.28 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 278 |  |  |  | 294 |  |  |  | 278 |  |  |  | 299 |  |
| Diluted |  |  | 284 |  |  |  | 296 |  |  |  | 283 |  |  |  | 302 |  |
| Cash dividends declared per share |  | $ | 0.190 |  |  | $ | 0.180 |  |  | $ | 0.380 |  |  | $ | 0.360 |  |

[0001564590-16-029385:8k_2_02:72]
NETAPP, INC.

[0001564590-16-029385:8k_2_02:73]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-16-029385:8k_2_02:74]
(In millions)

[0001564590-16-029385:8k_2_02:75]
(Unaudited)

[0001564590-16-029385:8k_2_02:76]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 28, 2016 |  |  | October 30, 2015 |  |  | October 28, 2016 |  |  | October 30, 2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 109 |  |  | $ | 114 |  |  | $ | 173 |  |  | $ | 84 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 57 |  |  |  | 67 |  |  |  | 117 |  |  |  | 136 |  |
| Stock-based compensation |  |  | 51 |  |  |  | 59 |  |  |  | 103 |  |  |  | 136 |  |
| Other non-cash items, net |  |  | 1 |  |  |  | (16 | ) |  |  | 13 |  |  |  | (52 | ) |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (47 | ) |  |  | (172 | ) |  |  | 264 |  |  |  | 189 |  |
| Inventories |  |  | (16 | ) |  |  | 68 |  |  |  | 1 |  |  |  | 21 |  |
| Accounts payable |  |  | 17 |  |  |  | (27 | ) |  |  | (13 | ) |  |  | (60 | ) |
| Accrued expenses |  |  | 60 |  |  |  | 31 |  |  |  | (138 | ) |  |  | (88 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (96 | ) |  |  | (16 | ) |  |  | (179 | ) |  |  | (137 | ) |
| Changes in other operating assets and liabilities, net |  |  | 22 |  |  |  | 37 |  |  |  | 45 |  |  |  | 45 |  |
| Net cash provided by operating activities |  |  | 158 |  |  |  | 145 |  |  |  | 386 |  |  |  | 274 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | (123 | ) |  |  | 10 |  |  |  | 190 |  |  |  | 788 |  |
| Purchases of property and equipment |  |  | (56 | ) |  |  | (46 | ) |  |  | (92 | ) |  |  | (84 | ) |
| Other investing activities, net |  |  | — |  |  |  | (2 | ) |  |  | (1 | ) |  |  | — |  |
| Net cash provided by (used in) investing activities |  |  | (179 | ) |  |  | (38 | ) |  |  | 97 |  |  |  | 704 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock under employee stock award plans |  |  | 16 |  |  |  | 6 |  |  |  | 25 |  |  |  | 25 |  |
| Repurchase of common stock |  |  | (117 | ) |  |  | (183 | ) |  |  | (292 | ) |  |  | (613 | ) |
| Repayment of short-term loan |  |  | — |  |  |  | — |  |  |  | (850 | ) |  |  | — |  |
| Dividends paid |  |  | (52 | ) |  |  | (53 | ) |  |  | (105 | ) |  |  | (107 | ) |
| Other financing activities, net |  |  | (1 | ) |  |  | — |  |  |  | (3 | ) |  |  | 1 |  |
| Net cash used in financing activities |  |  | (154 | ) |  |  | (230 | ) |  |  | (1,225 | ) |  |  | (694 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (6 | ) |  |  | (3 | ) |  |  | (13 | ) |  |  | (8 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (181 | ) |  |  | (126 | ) |  |  | (755 | ) |  |  | 276 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,294 |  |  |  | 2,324 |  |  |  | 2,868 |  |  |  | 1,922 |  |
| End of period |  | $ | 2,113 |  |  | $ | 2,198 |  |  | $ | 2,113 |  |  | $ | 2,198 |  |

[0001564590-16-029385:8k_2_02:77]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DIO, DPO, CCC and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q2 FY'17 |  |  | Q1 FY'17 |  |  | Q2 FY'16 |  |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 710 |  |  | $ | 660 |  |  | $ | 815 |  |
| Strategic |  | $ | 439 |  |  | $ | 400 |  |  | $ | 434 |  |
| Mature |  | $ | 271 |  |  | $ | 260 |  |  | $ | 381 |  |
| Software Maintenance |  | $ | 242 |  |  | $ | 241 |  |  | $ | 233 |  |
| Hardware Maintenance and Other Services: |  | $ | 388 |  |  | $ | 393 |  |  | $ | 397 |  |
| Hardware Maintenance Support Contracts |  | $ | 316 |  |  | $ | 323 |  |  | $ | 326 |  |
| Professional and Other Services |  | $ | 72 |  |  | $ | 70 |  |  | $ | 71 |  |
| Net Revenues |  | $ | 1,340 |  |  | $ | 1,294 |  |  | $ | 1,445 |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'17 Revenue |  |  | % of Q1 FY'17 Revenue |  |  | % of Q2 FY'16 Revenue |  |
| Americas |  |  | 57 | % |  |  | 57 | % |  |  | 57 | % |
| Americas Commercial |  |  | 42 | % |  |  | 44 | % |  |  | 42 | % |
| U.S. Public Sector |  |  | 16 | % |  |  | 13 | % |  |  | 14 | % |
| EMEA |  |  | 30 | % |  |  | 30 | % |  |  | 30 | % |
| Asia Pacific |  |  | 13 | % |  |  | 13 | % |  |  | 14 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'17 Revenue |  |  | % of Q1 FY'17 Revenue |  |  | % of Q2 FY'16 Revenue |  |
| Direct |  |  | 22 | % |  |  | 23 | % |  |  | 23 | % |
| Indirect |  |  | 78 | % |  |  | 77 | % |  |  | 77 | % |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'17 |  |  | Q1 FY'17 |  |  | Q2 FY'16 |  |
| Non-GAAP Gross Margin |  |  | 62.7 | % |  |  | 62.4 | % |  |  | 62.5 | % |
| Product |  |  | 48.2 | % |  |  | 46.7 | % |  |  | 51.8 | % |
| Software Maintenance |  |  | 97.1 | % |  |  | 96.7 | % |  |  | 96.1 | % |
| Hardware Maintenance and Other Services |  |  | 67.8 | % |  |  | 67.9 | % |  |  | 64.7 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'17 |  |  | Q1 FY'17 |  |  | Q2 FY'16 |  |
| Non-GAAP Income from Operations |  | $ | 204 |  |  | $ | 156 |  |  | $ | 219 |  |
| % of Net Revenues |  |  | 15.2 | % |  |  | 12.1 | % |  |  | 15.2 | % |
| Non-GAAP Income before Income Taxes |  | $ | 204 |  |  | $ | 155 |  |  | $ | 218 |  |
| Non-GAAP Effective Tax Rate |  |  | 17.3 | % |  |  | 16.6 | % |  |  | 17.0 | % |

[0001564590-16-029385:8k_2_02:78]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'17 |  |  | Q1 FY'17 |  |  | Q2 FY'16 |  |
| Non-GAAP Net Income |  | $ | 169 |  |  | $ | 129 |  |  | $ | 181 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 284 |  |  |  | 282 |  |  |  | 296 |  |
| Non-GAAP Income per Share, Diluted |  | $ | 0.60 |  |  | $ | 0.46 |  |  | $ | 0.61 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'17 |  |  | Q1 FY'17 |  |  | Q2 FY'16 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,201 |  |  | $ | 3,300 |  |  | $ | 3,046 |  |
| DSO (days) |  |  | 37 |  |  |  | 35 |  |  |  | 37 |  |
| DIO (days) |  |  | 17 |  |  |  | 15 |  |  |  | 20 |  |
| DPO (days) |  |  | 45 |  |  |  | 44 |  |  |  | 37 |  |
| CCC (days) |  |  | 9 |  |  |  | 6 |  |  |  | 21 |  |
| Inventory Turns |  |  | 21 |  |  |  | 25 |  |  |  | 18 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days inventory outstanding (DIO) is defined as net inventories divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Cash conversion cycle (CCC) is defined as DSO plus DIO minus DPO. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q2 FY'17 |  |  | Q1 FY'17 |  |  | Q2 FY'16 |  |
| Net Cash Provided by Operating Activities |  | $ | 158 |  |  | $ | 228 |  |  | $ | 145 |  |
| Purchases of Property and Equipment |  | $ | 56 |  |  | $ | 36 |  |  | $ | 46 |  |
| Free Cash Flow |  | $ | 102 |  |  | $ | 192 |  |  | $ | 99 |  |
| Free Cash Flow as a % of Net Revenues |  |  | 7.6 | % |  |  | 14.8 | % |  |  | 6.9 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001564590-16-029385:8k_2_02:79]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY17 |  |  | Q1'FY17 |  |  | Q2'FY16 |  |
| NET INCOME |  | $ | 109 |  |  | $ | 64 |  |  | $ | 114 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 11 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 51 |  |  |  | 52 |  |  |  | 59 |  |
| Restructuring and other charges |  |  | — |  |  |  | — |  |  |  | 1 |  |
| Income tax effect of non-GAAP adjustments |  |  | (2 | ) |  |  | 2 |  |  |  | (17 | ) |
| Settlement of income tax audit |  |  | — |  |  |  | — |  |  |  | 10 |  |
| NON-GAAP NET INCOME |  | $ | 169 |  |  | $ | 129 |  |  | $ | 181 |  |
| COST OF REVENUES |  | $ | 511 |  |  | $ | 497 |  |  | $ | 561 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (6 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (5 | ) |  |  | (5 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 500 |  |  | $ | 486 |  |  | $ | 542 |  |
| COST OF PRODUCT REVENUES |  | $ | 376 |  |  | $ | 359 |  |  | $ | 408 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (6 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 368 |  |  | $ | 352 |  |  | $ | 393 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 128 |  |  | $ | 130 |  |  | $ | 144 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (4 | ) |  |  | (4 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 125 |  |  | $ | 126 |  |  | $ | 140 |  |
| GROSS PROFIT |  | $ | 829 |  |  | $ | 797 |  |  | $ | 884 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 7 |  |  |  | 6 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 4 |  |  |  | 5 |  |  |  | 5 |  |
| NON-GAAP GROSS PROFIT |  | $ | 840 |  |  | $ | 808 |  |  | $ | 903 |  |

[0001564590-16-029385:8k_2_02:80]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY17 |  |  | Q1'FY17 |  |  | Q2'FY16 |  |
| SALES AND MARKETING EXPENSES |  | $ | 418 |  |  | $ | 429 |  |  | $ | 448 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (4 | ) |  |  | (5 | ) |  |  | — |  |
| Stock-based compensation |  |  | (21 | ) |  |  | (23 | ) |  |  | (26 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 393 |  |  | $ | 401 |  |  | $ | 422 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 200 |  |  | $ | 207 |  |  | $ | 216 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (17 | ) |  |  | (15 | ) |  |  | (18 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 183 |  |  | $ | 192 |  |  | $ | 198 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 69 |  |  | $ | 68 |  |  | $ | 74 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (9 | ) |  |  | (9 | ) |  |  | (10 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 60 |  |  | $ | 59 |  |  | $ | 64 |  |
| RESTRUCTURING AND OTHER CHARGES |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| NON-GAAP RESTRUCTURING AND OTHER CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 687 |  |  | $ | 704 |  |  | $ | 739 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (4 | ) |  |  | (5 | ) |  |  | — |  |
| Stock-based compensation |  |  | (47 | ) |  |  | (47 | ) |  |  | (54 | ) |
| Restructuring and other charges |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 636 |  |  | $ | 652 |  |  | $ | 684 |  |

[0001564590-16-029385:8k_2_02:81]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY17 |  |  | Q1'FY17 |  |  | Q2'FY16 |  |
| INCOME FROM OPERATIONS |  | $ | 142 |  |  | $ | 93 |  |  | $ | 145 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 11 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 51 |  |  |  | 52 |  |  |  | 59 |  |
| Restructuring and other charges |  |  | — |  |  |  | — |  |  |  | 1 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 204 |  |  | $ | 156 |  |  | $ | 219 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 142 |  |  | $ | 92 |  |  | $ | 144 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 11 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 51 |  |  |  | 52 |  |  |  | 59 |  |
| Restructuring and other charges |  |  | — |  |  |  | — |  |  |  | 1 |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 204 |  |  | $ | 155 |  |  | $ | 218 |  |
| PROVISION FOR INCOME TAXES |  | $ | 33 |  |  | $ | 28 |  |  | $ | 30 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | 2 |  |  |  | (2 | ) |  |  | 17 |  |
| Settlement of income tax audit |  |  | — |  |  |  | — |  |  |  | (10 | ) |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 35 |  |  | $ | 26 |  |  | $ | 37 |  |
| NET INCOME PER SHARE |  | $ | 0.38 |  |  | $ | 0.23 |  |  | $ | 0.39 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.04 |  |  |  | 0.04 |  |  |  | 0.05 |  |
| Stock-based compensation |  |  | 0.18 |  |  |  | 0.18 |  |  |  | 0.20 |  |
| Restructuring and other charges |  |  | — |  |  |  | — |  |  |  | — |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.01 | ) |  |  | 0.01 |  |  |  | (0.06 | ) |
| Settlement of income tax audit |  |  | — |  |  |  | — |  |  |  | 0.03 |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.60 |  |  | $ | 0.46 |  |  | $ | 0.61 |  |

[0001564590-16-029385:8k_2_02:82]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY17 |  |  | Q1'FY17 |  |  | Q2'FY16 |  |
| Gross margin-GAAP |  |  | 61.9 | % |  |  | 61.6 | % |  |  | 61.2 | % |
| Cost of revenues adjustments |  |  | 0.8 | % |  |  | 0.9 | % |  |  | 1.3 | % |
| Gross margin-Non-GAAP |  |  | 62.7 | % |  |  | 62.4 | % |  |  | 62.5 | % |
| GAAP cost of revenues |  | $ | 511 |  |  | $ | 497 |  |  | $ | 561 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (6 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (5 | ) |  |  | (5 | ) |
| Non-GAAP cost of revenues |  | $ | 500 |  |  | $ | 486 |  |  | $ | 542 |  |
| Net revenues |  | $ | 1,340 |  |  | $ | 1,294 |  |  | $ | 1,445 |  |

[0001564590-16-029385:8k_2_02:83]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY17 |  |  | Q1'FY17 |  |  | Q2'FY16 |  |
| Product gross margin-GAAP |  |  | 47.0 | % |  |  | 45.6 | % |  |  | 49.9 | % |
| Cost of product revenues adjustments |  |  | 1.1 | % |  |  | 1.1 | % |  |  | 1.8 | % |
| Product gross margin-Non-GAAP |  |  | 48.2 | % |  |  | 46.7 | % |  |  | 51.8 | % |
| GAAP cost of product revenues |  | $ | 376 |  |  | $ | 359 |  |  | $ | 408 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (6 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 368 |  |  | $ | 352 |  |  | $ | 393 |  |
| Product revenues |  | $ | 710 |  |  | $ | 660 |  |  | $ | 815 |  |

[0001564590-16-029385:8k_2_02:84]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY17 |  |  | Q1'FY17 |  |  | Q2'FY16 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 67.0 | % |  |  | 66.9 | % |  |  | 63.7 | % |
| Cost of hardware maintenance and other services revenues adjustments |  |  | 0.8 | % |  |  | 1.0 | % |  |  | 1.0 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 67.8 | % |  |  | 67.9 | % |  |  | 64.7 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 128 |  |  | $ | 130 |  |  | $ | 144 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (3 | ) |  |  | (4 | ) |  |  | (4 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 125 |  |  | $ | 126 |  |  | $ | 140 |  |
| Hardware maintenance and other services revenues |  | $ | 388 |  |  | $ | 393 |  |  | $ | 397 |  |

[0001564590-16-029385:8k_2_02:85]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q2'FY17 |  |  | Q1'FY17 |  |  | Q2'FY16 |  |
| GAAP effective tax rate |  |  | 23.2 | % |  |  | 30.4 | % |  |  | 20.8 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | (5.9 | )% |  |  | (13.8 | )% |  |  | 0.8 | % |
| Settlement of income tax audit |  |  | — | % |  |  | — | % |  |  | (4.6 | )% |
| Non-GAAP effective tax rate |  |  | 17.3 | % |  |  | 16.6 | % |  |  | 17.0 | % |

[0001564590-16-029385:8k_2_02:86]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY17 |  |  | Q1'FY17 |  |  | Q2'FY16 |  |
| Net cash provided by operating activities |  | $ | 158 |  |  | $ | 228 |  |  | $ | 145 |  |
| Purchases of property and equipment |  |  | (56 | ) |  |  | (36 | ) |  |  | (46 | ) |
| Free cash flow |  | $ | 102 |  |  | $ | 192 |  |  | $ | 99 |  |

[0001564590-16-029385:8k_2_02:87]
Some items may not add or recalculate due to rounding.

[0001564590-16-029385:8k_2_02:88]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| THIRD QUARTER FISCAL 2017 |  |
|  |  | Third Quarter |  |
|  |  | Fiscal 2017 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $0.72 - $0.77 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Third Quarter Fiscal 2017: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.05 | ) |
| Stock-based compensation expense |  |  | (0.17 | ) |
| Restructuring and other charges |  |  | (0.18 | ) |
| Gain on sale of properties |  |  | 0.03 |  |
| Income tax effect of non-GAAP adjustments |  |  | 0.06 |  |
| Total Adjustments |  |  | (0.31 | ) |
| GAAP Guidance - Net Income Per Share |  | $0.41 - $0.46 |  |

[0001564590-16-029385:8k_2_02:89]
Press Contact:

[0001564590-16-029385:8k_2_02:90]
Judy Radlinsky

[0001564590-16-029385:8k_2_02:91]
NetApp

[0001564590-16-029385:8k_2_02:92]
1 408 822 6527

[0001564590-16-029385:8k_2_02:93]
judy.radlinsky@netapp.com

[0001564590-16-029385:8k_2_02:94]
Investor Contact:

[0001564590-16-029385:8k_2_02:95]
Kris Newton

[0001564590-16-029385:8k_2_02:96]
NetApp

[0001564590-16-029385:8k_2_02:97]
1 408 822 3312

[0001564590-16-029385:8k_2_02:98]
kris.newton@netapp.com
