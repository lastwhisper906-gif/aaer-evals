# NTAP note change history — 0001564590-16-024907 → 0001564590-16-029759


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-12-02):
[0001564590-16-029759:note_history:1]
We lease various equipment, vehicles and office space in the U.S. and internationally. Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $238 million as of October 28, 2016.
  (was, 2016-09-02, similarity 0.75):
[0001564590-16-024907:note_history:1]
Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $258 million as of July 29, 2016.

- changed (2016-12-02):
[0001564590-16-029759:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of October 28, 2016, we had $291 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 28, 2016 and April 29, 2016, such liability amounted to $4 million and $7 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.
  (was, 2016-09-02, similarity 0.9889):
[0001564590-16-024907:note_history:2]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of July 29, 2016, we had $249 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 29, 2016 and April 29, 2016, such liability amounted to $5 million and $7 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- changed (2016-12-02):
[0001564590-16-029759:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 28, 2016, we had $15 million in construction related obligations and $231 million in other purchase obligations.
  (was, 2016-09-02, similarity 0.9849):
[0001564590-16-024907:note_history:3]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 29, 2016, we had $41 million in construction related obligations and $246 million in other purchase obligations.

- changed (2016-12-02):
[0001564590-16-029759:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $108 million and $72 million of receivables during the six months ended October 28, 2016 and October 30, 2015, respectively.
  (was, 2016-09-02, similarity 0.9713):
[0001564590-16-024907:note_history:4]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $76 million and $42 million of receivables during the three months ended July 29, 2016 and July 31, 2015, respectively.

- changed (2016-12-02):
[0001564590-16-029759:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of October 28, 2016 and April 29, 2016, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.
  (was, 2016-09-02, similarity 0.7867):
[0001564590-16-024907:note_history:5]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of July 29, 2016 and April 29, 2016, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

- added (2016-12-02):
[0001564590-16-029759:note_history:6]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 28, 2016, we have not been required to make any significant payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- changed (2016-12-02):
[0001564590-16-029759:note_history:7]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of October 28, 2016 related to such matters as they are not probable and/or reasonably estimable.
  (was, 2016-09-02, similarity 0.9753):
[0001564590-16-024907:note_history:7]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of July 29, 2016 related to such matters as they are not probable and/or reasonably estimable.

- removed (2016-12-02):
[0001564590-16-024907:note_history:8]
We lease various equipment, vehicles and office space in the U.S. and internationally.

- removed (2016-12-02):
[0001564590-16-024907:note_history:9]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 29, 2016, we have not been required to make any significant payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-12-02):
[0001564590-16-029759:note_history:10]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2016 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 28, 2016 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2016-09-02, similarity 0.8732):
[0001564590-16-024907:note_history:10]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income (loss) and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2016 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 29, 2016 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- changed (2016-12-02):
[0001564590-16-029759:note_history:11]
Accounting Change – In the first quarter of fiscal 2017, we early adopted a new accounting standards update that the Financial Accounting Standards Board (FASB) issued in March 2016 that simplifies the accounting for certain aspects of stock-based payments to employees. The new standard requires that certain amendments relevant to us be applied using a modified-retrospective transition method by means of a cumulative-effect adjustment to retained earnings as of the beginning of the period in which the guidance is adopted.
  (was, 2016-09-02, similarity 0.9539):
[0001564590-16-024907:note_history:11]
Accounting Change – In the three months ended July 29, 2016, we early adopted a new accounting standards update that the Financial Accounting Standards Board (FASB) issued in March 2016 that simplifies the accounting for certain aspects of stock-based payments to employees. The new standard requires that certain amendments relevant to us be applied using a modified-retrospective transition method by means of a cumulative-effect adjustment to retained earnings as of the beginning of the period in which the guidance is adopted.

- changed (2016-12-02):
[0001564590-16-029759:note_history:12]
The new standard eliminated the requirement to report excess tax benefits and certain tax deficiencies related to share-based payment transactions as additional paid-in capital. As a result, we recognized $17 million of tax deficiencies in our provision for income taxes, rather than additional paid–in capital, for the six months ended October 28, 2016.
  (was, 2016-09-02, similarity 0.9322):
[0001564590-16-024907:note_history:12]
The new standard eliminated the requirement to report excess tax benefits and certain tax deficiencies related to share-based payment transactions as additional paid-in capital. As a result, we recognized $13 million of tax deficiencies in our provision for income taxes, rather than additional paid–in capital, for the three months ended July 29, 2016.

- changed (2016-12-02):
[0001564590-16-029759:note_history:13]
There have been no other significant changes in our significant accounting policies as of and for the six months ended October 28, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2016.
  (was, 2016-09-02, similarity 0.9634):
[0001564590-16-024907:note_history:13]
There have been no other significant changes in our significant accounting policies as of and for the three months ended July 29, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 29, 2016.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-12-02):
[0001564590-16-029759:note_history:14]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (8 | ) |  |  |  |  |  |  | (10 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,492 |  |  |  |  |  |  | $ | 1,490 |  |  |  |  |  |
  (was, 2016-09-02, similarity 0.8559):
[0001564590-16-024907:note_history:14]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (9 | ) |  |  |  |  |  |  | (10 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,491 |  |  |  |  |  |  | $ | 1,490 |  |  |  |  |  |

- changed (2016-12-02):
[0001564590-16-029759:note_history:15]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 28, 2016, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2016-09-02, similarity 0.9915):
[0001564590-16-024907:note_history:15]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 29, 2016, we were in compliance with all covenants associated with the Senior Notes.

- changed (2016-12-02):
[0001564590-16-029759:note_history:16]
As of October 28, 2016, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2016-09-02, similarity 0.9405):
[0001564590-16-024907:note_history:16]
As of July 29, 2016, our aggregate future principal debt maturities are as follows (in millions):

- changed (2016-12-02):
[0001564590-16-029759:note_history:17]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of October 28, 2016, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.
  (was, 2016-09-02, similarity 0.9949):
[0001564590-16-024907:note_history:17]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of July 29, 2016, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

- changed (2016-12-02):
[0001564590-16-029759:note_history:18]
In February 2016, in connection with the SolidFire acquisition, we entered into a short-term loan of $870 million with a maturity of November 2, 2016. As of October 28, 2016, we have repaid the loan in full and have terminated the related loan agreement.
  (was, 2016-09-02, similarity 0.9766):
[0001564590-16-024907:note_history:18]
In February 2016, in connection with the SolidFire acquisition, we entered into a short-term loan of $870 million with a maturity of November 2, 2016. As of July 29, 2016, we have repaid the loan in full and have terminated the related loan agreement.

- changed (2016-12-02):
[0001564590-16-029759:note_history:19]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, the assets will remain on our condensed consolidated balance sheets, and proceeds received by us from these transactions are reported as financing obligations. As of October 28, 2016, the balance of these financing obligations was $149 million. At the end of each respective leaseback period, or when our continuing involvement under the leaseback agreements ends, each transaction will be reported as a non-cash sale of land and buildings and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain on sale of properties.
  (was, 2016-09-02, similarity 0.9954):
[0001564590-16-024907:note_history:19]
In fiscal 2016, we entered into a sale-leaseback arrangement of certain of our land and buildings, under which we leased back certain of our properties rent free over lease terms ending at various dates ranging from March 31, 2017 to December 31, 2017, unless terminated early by us. Due to the existence of a prohibited form of continuing involvement, these properties did not qualify for sale-leaseback accounting and as a result they have been accounted for as financing transactions under lease accounting standards. Under the financing method, the assets will remain on our condensed consolidated balance sheets, and proceeds received by us from these transactions are reported as financing obligations. As of July 29, 2016, the balance of these financing obligations was $149 million. At the end of each respective leaseback period, or when our continuing involvement under the leaseback agreements ends, each transaction will be reported as a non-cash sale of land and buildings and extinguishment of financing obligations, and the difference between the then net book value of the properties and the unamortized balance of the financing obligations will be recognized as a gain on sale of properties.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-12-02):
[0001564590-16-029759:note_history:20]
|  |  | October 28, 2016 |  |  | April 29, 2016 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due December 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due June 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due December 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (8 | ) |  |  |  |  |  |  | (10 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,492 |  |  |  |  |  |  | $ | 1,490 |  |  |  |  |  |
  (was, 2016-09-02, similarity 0.8559):
[0001564590-16-024907:note_history:20]
|  |  | July 29, 2016 |  |  | April 29, 2016 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Unamortized discount and issuance costs |  |  | (9 | ) |  |  |  |  |  |  | (10 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,491 |  |  |  |  |  |  | $ | 1,490 |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-12-02):
[0001564590-16-029759:note_history:21]
As of October 28, 2016, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2016-09-02, similarity 0.9405):
[0001564590-16-024907:note_history:21]
As of July 29, 2016, our aggregate future principal debt maturities are as follows (in millions):


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2016-12-02):
[0001564590-16-029759:note_history:22]
16. Subsequent Event

- added (2016-12-02):
[0001564590-16-029759:note_history:23]
On November 3, 2016, we announced a restructuring and reduction in workforce to streamline our core business and reduce operating expenses. In connection with these actions, we expect to reduce our worldwide headcount by approximately 6% and to incur aggregate charges of approximately $50 to $60 million for employee terminations and other costs associated with the restructuring, the majority of which we will recognize in the third quarter of fiscal 2017. We expect to implement these actions through the end of the fourth quarter of fiscal 2017.
