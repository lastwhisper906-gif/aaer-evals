# NTAP 8-K — 0000950170-23-066400 filed 2023-11-28

## item codes, every 8-K on or before 2023-11-30

- 2023-11-28 0000950170-23-066400 — 2.02, 9.01
- 2023-11-16 0000950170-23-064506 — 5.02, 5.03, 9.01
- 2023-09-15 0000950170-23-048229 — 5.02, 5.07, 9.01
- 2023-08-23 0000950170-23-044130 — 2.02, 9.01
- 2023-08-10 0000950170-23-041348 — 5.02
- 2023-05-31 0000950170-23-025324 — 1.01, 2.02, 8.01, 9.01
- 2023-02-22 0000950170-23-003745 — 2.02, 9.01
- 2023-01-31 0001193125-23-019739 — 2.05, 7.01, 9.01
- 2022-11-29 0000950170-22-025793 — 2.02, 9.01
- 2022-11-16 0000950170-22-025317 — 5.02
- 2022-09-14 0000950170-22-018490 — 5.07
- 2022-08-24 0000950170-22-017731 — 2.02, 9.01
- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2023-11-30

- none on or before 2023-11-30

## item 2.02 — earnings release, exhibit 99.1

[0000950170-23-066400:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0000950170-23-066400:8k_2_02:2]
EX-99.1

[0000950170-23-066400:8k_2_02:3]
Exhibit 99.1

[0000950170-23-066400:8k_2_02:4]
NetApp reports second quarter of fiscal year 2024 results

[0000950170-23-066400:8k_2_02:5]
Net revenues of $1.56 billion for the second quarter

[0000950170-23-066400:8k_2_02:6]
•
Introduced substantial innovation including the ASA C-Series, the extension of the Company’s Ransomware Recovery Guarantee, and performance and availability guarantees for NetApp Keystone storage as a service

[0000950170-23-066400:8k_2_02:7]
•
Record Q2 GAAP consolidated gross margins of 71%; record non-GAAP consolidated gross margins1 of 72%

[0000950170-23-066400:8k_2_02:8]
•
Q2 GAAP operating margins of 20%; record non-GAAP operating margins1 of 27%

[0000950170-23-066400:8k_2_02:9]
•
Q2 GAAP net income per share2 of $1.10; record non-GAAP net income3 per share of $1.58

[0000950170-23-066400:8k_2_02:10]
•
$403 million returned to stockholders in share repurchases and cash dividends in the second quarter

[0000950170-23-066400:8k_2_02:11]
SAN JOSE, Calif.—November 28, 2023—NetApp (NASDAQ: NTAP), the intelligent data infrastructure company, today reported financial results for the second quarter of fiscal year 2024, which ended on October 27, 2023.

[0000950170-23-066400:8k_2_02:12]
“We delivered another strong quarter, with revenue above the midpoint of our guidance and all-time highs for gross margins, operating margins, and EPS,” said George Kurian, chief executive officer. “We are at the forefront of the evolution of the storage industry, helping our customers turn disruption into opportunity. Our modern approach to intelligent data infrastructure helps customers operate with seamless flexibility to deploy new applications, unify their data for AI, and simplify data protection in a world of limited IT resources, rapid data growth, and increased cybersecurity threats.”

[0000950170-23-066400:8k_2_02:13]
Second quarter of fiscal year 2024 financial results

[0000950170-23-066400:8k_2_02:14]
•
Net revenues: $1.56 billion, compared to $1.66 billion in the second quarter of fiscal year 2023; a year-over-year decrease of 6%, or 8% in constant currency4.

[0000950170-23-066400:8k_2_02:15]
o
Hybrid Cloud segment revenue: $1.41 billion, compared to $1.52 billion in the second quarter of fiscal year 2023.

[0000950170-23-066400:8k_2_02:16]
o
Public Cloud segment revenue: $154 million, compared to $142 million in the second quarter of fiscal year 2023.

[0000950170-23-066400:8k_2_02:17]
•
Billings1: $1.45 billion, compared to $1.60 billion in the second quarter of fiscal year 2023; a year-over-year decrease of 9%, or 11% in constant currency.

[0000950170-23-066400:8k_2_02:18]
•
NetApp Public Cloud annualized revenue run rate (ARR)5: $609 million, compared to $603 million in the second quarter of fiscal year 2023; a year-over-year increase of 1%.

[0000950170-23-066400:8k_2_02:19]
•
All-flash array ARR6: $3.2 billion, compared to $3.1 billion in the second quarter of fiscal year 2023; a year-over-year increase of 1%.

[0000950170-23-066400:8k_2_02:20]
•
Net income: GAAP net income of $233 million, compared to $750 million in the second quarter of fiscal year 2023; non-GAAP net income3 of $334 million, compared to $326 million in the second quarter of fiscal year 2023. The year-over-year fluctuations in GAAP and Non-GAAP net income each include a favorable impact of approximately $15 million from foreign currency exchange rate changes.

[0000950170-23-066400:8k_2_02:21]
•
Earnings per share: GAAP net income per share of $1.10 compared to $3.41 in the second quarter of fiscal year 2023; non-GAAP net income per share of $1.58 compared to $1.48 in the second quarter of fiscal year 2023. The year-over-year fluctuations in GAAP and Non-GAAP net income per share each include a favorable impact of approximately $0.07 from foreign currency exchange rate changes.

[0000950170-23-066400:8k_2_02:22]
•
Cash, cash equivalents and investments: $2.62 billion at the end of the second quarter of fiscal year 2024.

[0000950170-23-066400:8k_2_02:23]
•
Cash provided by operations: $135 million, compared to $214 million in the second quarter of fiscal year 2023.

[0000950170-23-066400:8k_2_02:24]
•
Share repurchase and dividends: Returned $403 million to stockholders through share repurchases and cash dividends.

[0000950170-23-066400:8k_2_02:25]
Third quarter of fiscal year 2024 financial outlook

[0000950170-23-066400:8k_2_02:26]
The Company provided the following financial guidance for the third quarter of fiscal year 2024:

[0000950170-23-066400:8k_2_02:27]
| Net revenues are expected to be in the range of: | $1.51 billion - $1.67 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $1.17 - $1.27 | $1.64 - $1.74 |

[0000950170-23-066400:8k_2_02:28]
Full fiscal year 2024 financial outlook

[0000950170-23-066400:8k_2_02:29]
The Company provided an update to their financial guidance for the full fiscal year 2024:

[0000950170-23-066400:8k_2_02:30]
| Net revenues are expected to be down approximately 2% year-over-year |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be: | ~70% | ~71% |
| Operating margins are expected to be: | ~19% | ~26% |
| Earnings per share is expected to be in the range of: | $4.15 - $4.35 | $6.05 - $6.25 |

[0000950170-23-066400:8k_2_02:31]
Dividend

[0000950170-23-066400:8k_2_02:32]
The next cash dividend of $0.50 per share is to be paid on January 24, 2024, to stockholders of record as of the close of business on January 5, 2024.

[0000950170-23-066400:8k_2_02:33]
Second quarter of fiscal year 2024 business highlights

[0000950170-23-066400:8k_2_02:34]
Leading product innovation

[0000950170-23-066400:8k_2_02:35]
•
NetApp announced that the AFF C-Series has been added to the NetApp™ONTAP™ AI architecture to improve affordability and sustainability.

[0000950170-23-066400:8k_2_02:36]
•
NetApp launched the NetApp ASA C-Series family, which builds on the success of the NetApp AFF C-Series and brings the benefits of AFF C-Series to block storage.

[0000950170-23-066400:8k_2_02:37]
•
NetApp extended its Ransomware Recovery Guarantee, making it available for all on-premises NetApp ONTAP based storage systems, including NetApp AFF, ASA, and FAS.

[0000950170-23-066400:8k_2_02:38]
•
NetApp introduced its Ransomware Recovery Assurance Service, which validates a customer’s ability to recover data quickly by using NetApp Snapshot™. The service also provides a dedicated team to assist in data recovery if an attack occurs.

[0000950170-23-066400:8k_2_02:39]
•
NetApp announced that NetApp Keystone™ storage as a service now offers a comprehensive program to keep storage operations running efficiently with new Performance and Availability Guarantees.

[0000950170-23-066400:8k_2_02:40]
•
NetApp announced that its BlueXP™ disaster recovery service is available for public preview, providing simple, low-cost disaster protection for VMware workloads.

[0000950170-23-066400:8k_2_02:41]
•
NetApp updated the NetApp Astra™Control product family, delivering Kubernetes ransomware protection with immutable backups.

[0000950170-23-066400:8k_2_02:42]
•
Spot by NetApp announced the general availability of Spot Connect, which works to revolutionize cloud operations by automating workflows.

[0000950170-23-066400:8k_2_02:43]
Customer and partner momentum

[0000950170-23-066400:8k_2_02:44]
•
NetApp introduced its new joint bare-metal-as-a-service (BMaaS) solution, NetApp Storage on Equinix Metal, which is delivered through NetApp Keystone.

[0000950170-23-066400:8k_2_02:45]
•
NetApp and Google Cloud extended their partnership with the introduction of Google Cloud NetApp Volumes, a fully managed, first-party service on Google Cloud based on NetApp ONTAP data management software and cloud services.

[0000950170-23-066400:8k_2_02:46]
•
NetApp announced the availability of the Standard service level of Google Cloud NetApp Volumes, expanding the offering to address a greater range of workloads more cost-effectively.

[0000950170-23-066400:8k_2_02:47]
•
NetApp and Google announced support for Google Cloud’s Vertex AI with Google Cloud NetApp Volumes for hybrid generative AI applications.

[0000950170-23-066400:8k_2_02:48]
•
NetApp announced cross-protocol AI pipelines on Amazon FSx for NetApp ONTAP with support for SageMaker Studio notebooks, as well as Kafka and Spark, by using either NFS or Amazon S3 protocols.

[0000950170-23-066400:8k_2_02:49]
•
NetApp announced the addition of unified file and object access through the ONTAP S3 API on Amazon FSx for NetApp ONTAP. With this access, customers can lower overall TCO by taking advantage of VPC peering to connect to VMware Cloud on AWS.

[0000950170-23-066400:8k_2_02:50]
•
NetApp announced enhanced capacity scaling, enhanced performance for Oracle databases, and support for transparent automated tiering of data to the Azure Cool Blob tier for improved cost savings on Microsoft Azure NetApp Files.

[0000950170-23-066400:8k_2_02:51]
•
Spot by NetApp achieved AWS Spot EC2 Service Ready status, validating Spot’s commitment to deliver a reliable and seamless experience for users by leveraging AWS Spot Instances.

[0000950170-23-066400:8k_2_02:52]
•
Spot by NetApp announced that Spot Eco for Azure now supports Cloud Solution Provider accounts with programmatic access through Azure app registrations.

[0000950170-23-066400:8k_2_02:53]
•
NetApp launched its updated Partner Sphere Program, further strengthening NetApp’s partner-first culture of collaboration and innovation to capture greater market share.

[0000950170-23-066400:8k_2_02:54]
•
NetApp announced the renewal of its partnership agreement with Ducati Corse for the 2023 through 2025 seasons and named NetApp the team’s Official Data Infrastructure Partner.

[0000950170-23-066400:8k_2_02:55]
Corporate news and events

[0000950170-23-066400:8k_2_02:56]
•
NetApp released its 2023 ESG Report, detailing our environmental, social, and governance (ESG) strategies, activities, progress, metrics, and performance for our global operations for the fiscal year ending April 28, 2023.

[0000950170-23-066400:8k_2_02:57]
•
NetApp released its 2023 Data Complexity Report, which explores companies’ growing needs for unified data storage.

[0000950170-23-066400:8k_2_02:58]
•
NetApp hosted the NetApp INSIGHT™2023 conference, where CEO George Kurian’s keynote presented NetApp’s vision for intelligent data infrastructure and unveiled new block storage offerings to extend its unified data storage portfolio.

[0000950170-23-066400:8k_2_02:59]
Awards and recognition

[0000950170-23-066400:8k_2_02:60]
•
NetApp was awarded a Gold ranking by EcoVadis.

[0000950170-23-066400:8k_2_02:61]
•
NetApp won the Google Cloud Technology Partner of the Year for “Infrastructure Storage” and “Marketplace Infrastructure.”

[0000950170-23-066400:8k_2_02:62]
•
NetApp won a 2023 TSIA STAR Award in “Innovation in Customer Portals that Improve the Digital Customer Experience.”

[0000950170-23-066400:8k_2_02:63]
•
NetApp won “Cloud Security Innovation of the Year” at the Cybersecurity Breakthrough Awards.

[0000950170-23-066400:8k_2_02:64]
•
NetApp was named one of the “World’s Most Trustworthy Companies” by Newsweek.

[0000950170-23-066400:8k_2_02:65]
•
NetApp was included in Newsweek’s “America’s Greenest Companies” list.

[0000950170-23-066400:8k_2_02:66]
•
NetApp was recognized as a leader in the “2023 Gartner Magic Quadrant for Primary Storage,” scoring the highest in Hybrid Cloud IT Operations and Containers Use Case.

[0000950170-23-066400:8k_2_02:67]
•
GigaOm listed NetApp as a leader and fast mover for data storage security posture (DSSP) and ransomware.

[0000950170-23-066400:8k_2_02:68]
•
GigaOm recognized NetApp BlueXP as a leader and outperformer in unstructured data management.

[0000950170-23-066400:8k_2_02:69]
•
Spot by NetApp was recognized as a leader and outperformer in the “GigaOm 2023 Radar for Cloud Management Platforms.”

[0000950170-23-066400:8k_2_02:70]
•
NetApp was listed as a Leader and Outperformer in GigaOm’s “2023 Radar for Cloud Observability” report.

[0000950170-23-066400:8k_2_02:71]
•
CRN listed the NetApp ASA family, FlexPod™, and Google Cloud NetApp Volumes as finalists for the publication’s “Products of the Year.”

[0000950170-23-066400:8k_2_02:72]
•
NetApp’s Jenni Flinders, senior vice president, Worldwide Partner Organization, was named a finalist for the CRN Woman of the Year Awards.

[0000950170-23-066400:8k_2_02:73]
Webcast and conference call information

[0000950170-23-066400:8k_2_02:74]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on

[0000950170-23-066400:8k_2_02:75]
the Investor Relations website. An audio replay will be available on the website after 4:00 p.m. Pacific Time today.

[0000950170-23-066400:8k_2_02:76]
###

[0000950170-23-066400:8k_2_02:77]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0000950170-23-066400:8k_2_02:78]
Footnotes

[0000950170-23-066400:8k_2_02:79]
1Refer to NetApp Usage of non-GAAP Financial Information section below for explanations of consolidated non-GAAP gross margins, non-GAAP operating margins, free cash flow and billings.

[0000950170-23-066400:8k_2_02:80]
2GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0000950170-23-066400:8k_2_02:81]
3Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) gains/losses on the sale of investments in equity securities, (i) debt extinguishment costs, and (j) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes that the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0000950170-23-066400:8k_2_02:82]
4Refer to the Constant Currency section below for an explanation of constant currency growth rates and the impact of foreign currency exchange rate changes on year-over-year fluctuations in earnings.

[0000950170-23-066400:8k_2_02:83]
5Public Cloud annualized revenue run rate (ARR) is calculated as the annualized value of all Public Cloud customer commitments with the assumption that any commitment expiring during the next 12 months will be renewed with its existing terms.

[0000950170-23-066400:8k_2_02:84]
6All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0000950170-23-066400:8k_2_02:85]
NetApp usage of non-GAAP financial information

[0000950170-23-066400:8k_2_02:86]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share. NetApp also presents the hardware and software components of our GAAP product revenues. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily

[0000950170-23-066400:8k_2_02:87]
based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0000950170-23-066400:8k_2_02:88]
NetApp believes that the presentation of non-GAAP gross margins, non-GAAP operating margins, non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations.

[0000950170-23-066400:8k_2_02:89]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0000950170-23-066400:8k_2_02:90]
NetApp believes that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0000950170-23-066400:8k_2_02:91]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0000950170-23-066400:8k_2_02:92]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0000950170-23-066400:8k_2_02:93]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0000950170-23-066400:8k_2_02:94]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of

[0000950170-23-066400:8k_2_02:95]
various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0000950170-23-066400:8k_2_02:96]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0000950170-23-066400:8k_2_02:97]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0000950170-23-066400:8k_2_02:98]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0000950170-23-066400:8k_2_02:99]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0000950170-23-066400:8k_2_02:100]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0000950170-23-066400:8k_2_02:101]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-23-066400:8k_2_02:102]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-23-066400:8k_2_02:103]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-23-066400:8k_2_02:104]
J. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges or benefits resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0000950170-23-066400:8k_2_02:105]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0000950170-23-066400:8k_2_02:106]
Constant Currency

[0000950170-23-066400:8k_2_02:107]
In periods in which the impacts of foreign currency exchange rate changes are significant, NetApp presents certain constant currency growth rates or quantifies the impact of foreign currency exchange rate changes on year-over-year fluctuations, including for net revenues, billings, and earnings. This constant currency information assumes the same foreign currency exchange rates that were in effect for the comparable prior-year period were used in translation of the current period results.

[0000950170-23-066400:8k_2_02:108]
About NetApp

[0000950170-23-066400:8k_2_02:109]
NetApp is the intelligent data infrastructure company combining unified data storage, integrated data services, and CloudOps solutions to turn a world of disruption into opportunity for every customer. NetApp creates silo-free infrastructure, then harnesses observability and AI, to enable the best data management. As the only enterprise-grade storage service natively embedded in the world’s biggest clouds, our data storage delivers seamless flexibility and our data services create a data advantage through superior cyber-resilience, governance, and applications agility. Our CloudOps solutions provide continuous optimization of performance and efficiency through observability and AI. No matter the data type, workload, or environment, transform your data infrastructure to realize your business possibilities with NetApp. Learn more at www.netapp.com or follow us on X, LinkedIn, Facebook, and Instagram.

[0000950170-23-066400:8k_2_02:110]
NETAPP, INC.

[0000950170-23-066400:8k_2_02:111]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-23-066400:8k_2_02:112]
(In millions)

[0000950170-23-066400:8k_2_02:113]
(Unaudited)

[0000950170-23-066400:8k_2_02:114]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 2,620 |  |  | $ | 3,070 |  |
| Accounts receivable |  |  | 787 |  |  |  | 987 |  |
| Inventories |  |  | 122 |  |  |  | 167 |  |
| Other current assets |  |  | 464 |  |  |  | 456 |  |
| Total current assets |  |  | 3,993 |  |  |  | 4,680 |  |
| Property and equipment, net |  |  | 623 |  |  |  | 650 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,911 |  |  |  | 2,940 |  |
| Other non-current assets |  |  | 1,546 |  |  |  | 1,548 |  |
| Total assets |  | $ | 9,073 |  |  | $ | 9,818 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 411 |  |  | $ | 392 |  |
| Accrued expenses |  |  | 919 |  |  |  | 857 |  |
| Current portion of long-term debt |  |  | 400 |  |  |  | — |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 2,003 |  |  |  | 2,218 |  |
| Total current liabilities |  |  | 3,733 |  |  |  | 3,467 |  |
| Long-term debt |  |  | 1,991 |  |  |  | 2,389 |  |
| Other long-term liabilities |  |  | 580 |  |  |  | 708 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,999 |  |  |  | 2,095 |  |
| Total liabilities |  |  | 8,303 |  |  |  | 8,659 |  |
| Stockholders' equity |  |  | 770 |  |  |  | 1,159 |  |
| Total liabilities and stockholders' equity |  | $ | 9,073 |  |  | $ | 9,818 |  |

[0000950170-23-066400:8k_2_02:115]
NETAPP, INC.

[0000950170-23-066400:8k_2_02:116]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-23-066400:8k_2_02:117]
(In millions, except per share amounts)

[0000950170-23-066400:8k_2_02:118]
(Unaudited)

[0000950170-23-066400:8k_2_02:119]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | October 27, 2023 |  |  | October 28, 2022 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 706 |  |  | $ | 837 |  |  | $ | 1,296 |  |  | $ | 1,623 |  |
| Services |  |  | 856 |  |  |  | 826 |  |  |  | 1,698 |  |  |  | 1,632 |  |
| Net revenues |  |  | 1,562 |  |  |  | 1,663 |  |  |  | 2,994 |  |  |  | 3,255 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 276 |  |  |  | 418 |  |  |  | 541 |  |  |  | 815 |  |
| Cost of services |  |  | 176 |  |  |  | 158 |  |  |  | 347 |  |  |  | 307 |  |
| Total cost of revenues |  |  | 452 |  |  |  | 576 |  |  |  | 888 |  |  |  | 1,122 |  |
| Gross profit |  |  | 1,110 |  |  |  | 1,087 |  |  |  | 2,106 |  |  |  | 2,133 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 461 |  |  |  | 479 |  |  |  | 929 |  |  |  | 937 |  |
| Research and development |  |  | 262 |  |  |  | 243 |  |  |  | 509 |  |  |  | 483 |  |
| General and administrative |  |  | 75 |  |  |  | 67 |  |  |  | 149 |  |  |  | 139 |  |
| Restructuring charges |  |  | 5 |  |  |  | 11 |  |  |  | 31 |  |  |  | 22 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 5 |  |  |  | 6 |  |  |  | 15 |  |
| Total operating expenses |  |  | 806 |  |  |  | 805 |  |  |  | 1,624 |  |  |  | 1,596 |  |
| Income from operations |  |  | 304 |  |  |  | 282 |  |  |  | 482 |  |  |  | 537 |  |
| Other income, net |  |  | 11 |  |  |  | 23 |  |  |  | 19 |  |  |  | 38 |  |
| Income before income taxes |  |  | 315 |  |  |  | 305 |  |  |  | 501 |  |  |  | 575 |  |
| Provision (benefit) for income taxes |  |  | 82 |  |  |  | (445 | ) |  |  | 119 |  |  |  | (389 | ) |
| Net income |  | $ | 233 |  |  | $ | 750 |  |  | $ | 382 |  |  | $ | 964 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.12 |  |  | $ | 3.46 |  |  | $ | 1.82 |  |  | $ | 4.40 |  |
| Diluted |  | $ | 1.10 |  |  | $ | 3.41 |  |  | $ | 1.79 |  |  | $ | 4.34 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 208 |  |  |  | 217 |  |  |  | 210 |  |  |  | 219 |  |
| Diluted |  |  | 211 |  |  |  | 220 |  |  |  | 214 |  |  |  | 222 |  |

[0000950170-23-066400:8k_2_02:120]
NETAPP, INC.

[0000950170-23-066400:8k_2_02:121]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-23-066400:8k_2_02:122]
(In millions)

[0000950170-23-066400:8k_2_02:123]
(Unaudited)

[0000950170-23-066400:8k_2_02:124]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | October 27, 2023 |  |  | October 28, 2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 233 |  |  | $ | 750 |  |  | $ | 382 |  |  | $ | 964 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 64 |  |  |  | 59 |  |  |  | 128 |  |  |  | 117 |  |
| Non-cash operating lease cost |  |  | 12 |  |  |  | 13 |  |  |  | 23 |  |  |  | 27 |  |
| Stock-based compensation |  |  | 93 |  |  |  | 78 |  |  |  | 180 |  |  |  | 145 |  |
| Deferred income taxes |  |  | (7 | ) |  |  | (555 | ) |  |  | (13 | ) |  |  | (570 | ) |
| Other items, net |  |  | (25 | ) |  |  | (61 | ) |  |  | (27 | ) |  |  | (127 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (147 | ) |  |  | (51 | ) |  |  | 185 |  |  |  | 313 |  |
| Inventories |  |  | 9 |  |  |  | (12 | ) |  |  | 46 |  |  |  | (40 | ) |
| Accounts payable |  |  | 70 |  |  |  | 62 |  |  |  | 14 |  |  |  | (28 | ) |
| Accrued expenses |  |  | 137 |  |  |  | 100 |  |  |  | 48 |  |  |  | (108 | ) |
| Deferred revenue and financed unearned services revenue |  |  | (108 | ) |  |  | (61 | ) |  |  | (241 | ) |  |  | (93 | ) |
| Long-term taxes payable |  |  | (111 | ) |  |  | (85 | ) |  |  | (110 | ) |  |  | (84 | ) |
| Changes in other operating assets and liabilities, net |  |  | (85 | ) |  |  | (23 | ) |  |  | (27 | ) |  |  | (21 | ) |
| Net cash provided by operating activities |  |  | 135 |  |  |  | 214 |  |  |  | 588 |  |  |  | 495 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | 264 |  |  |  | (211 | ) |  |  | 72 |  |  |  | (342 | ) |
| Purchases of property and equipment |  |  | (38 | ) |  |  | (77 | ) |  |  | (73 | ) |  |  | (142 | ) |
| Acquisitions of businesses, net of cash acquired |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (491 | ) |
| Other investing activities, net |  |  | 1 |  |  |  | — |  |  |  | — |  |  |  | 59 |  |
| Net cash provided by (used in) investing activities |  |  | 227 |  |  |  | (288 | ) |  |  | (1 | ) |  |  | (916 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | — |  |  |  | — |  |  |  | 52 |  |  |  | 54 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (20 | ) |  |  | (11 | ) |  |  | (85 | ) |  |  | (63 | ) |
| Repurchase of common stock |  |  | (300 | ) |  |  | (150 | ) |  |  | (700 | ) |  |  | (500 | ) |
| Repayments and extinguishment of debt |  |  | — |  |  |  | (250 | ) |  |  | — |  |  |  | (250 | ) |
| Dividends paid |  |  | (103 | ) |  |  | (108 | ) |  |  | (209 | ) |  |  | (218 | ) |
| Other financing activities, net |  |  | 2 |  |  |  | (1 | ) |  |  | — |  |  |  | (2 | ) |
| Net cash used in financing activities |  |  | (421 | ) |  |  | (520 | ) |  |  | (942 | ) |  |  | (979 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (26 | ) |  |  | (25 | ) |  |  | (26 | ) |  |  | (43 | ) |
| Net change in cash, cash equivalents and restricted cash |  |  | (85 | ) |  |  | (619 | ) |  |  | (381 | ) |  |  | (1,443 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,026 |  |  |  | 3,295 |  |  |  | 2,322 |  |  |  | 4,119 |  |
| End of period |  | $ | 1,941 |  |  | $ | 2,676 |  |  | $ | 1,941 |  |  | $ | 2,676 |  |

[0000950170-23-066400:8k_2_02:125]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| Product |  | $ | 706 |  |  | $ | 590 |  |  | $ | 837 |  |
| Support |  |  | 623 |  |  |  | 611 |  |  |  | 607 |  |
| Professional and Other Services |  |  | 79 |  |  |  | 77 |  |  |  | 77 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,408 |  |  |  | 1,278 |  |  |  | 1,521 |  |
| Public Cloud Segment Net Revenues |  |  | 154 |  |  |  | 154 |  |  |  | 142 |  |
| Net Revenues |  | $ | 1,562 |  |  | $ | 1,432 |  |  | $ | 1,663 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| Product |  | $ | 431 |  |  | $ | 326 |  |  | $ | 420 |  |
| Support |  |  | 573 |  |  |  | 564 |  |  |  | 562 |  |
| Professional and Other Services |  |  | 19 |  |  |  | 19 |  |  |  | 23 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 1,023 |  |  |  | 909 |  |  |  | 1,005 |  |
| Public Cloud Segment Gross Profit |  |  | 102 |  |  |  | 103 |  |  |  | 97 |  |
| Total Segments Gross Profit |  |  | 1,125 |  |  |  | 1,012 |  |  |  | 1,102 |  |
| Amortization of Intangible Assets |  |  | (8 | ) |  |  | (9 | ) |  |  | (10 | ) |
| Stock-based Compensation |  |  | (7 | ) |  |  | (7 | ) |  |  | (5 | ) |
| Unallocated Cost of Revenues |  |  | (15 | ) |  |  | (16 | ) |  |  | (15 | ) |
| Gross Profit |  | $ | 1,110 |  |  | $ | 996 |  |  | $ | 1,087 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| Product |  |  | 61.0 | % |  |  | 55.3 | % |  |  | 50.2 | % |
| Support |  |  | 92.0 | % |  |  | 92.3 | % |  |  | 92.6 | % |
| Professional and Other Services |  |  | 24.1 | % |  |  | 24.7 | % |  |  | 29.9 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 72.7 | % |  |  | 71.1 | % |  |  | 66.1 | % |
| Public Cloud Segment Gross Margin |  |  | 66.2 | % |  |  | 66.9 | % |  |  | 68.3 | % |
| Product Revenues |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| Total |  | $ | 706 |  |  | $ | 590 |  |  | $ | 837 |  |
| Software* |  | $ | 398 |  |  | $ | 342 |  |  | $ | 495 |  |
| Hardware* |  | $ | 308 |  |  | $ | 248 |  |  | $ | 342 |  |
| Software and recurring support and public cloud revenue |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| Product - Software |  | $ | 398 |  |  | $ | 342 |  |  | $ | 495 |  |
| Support |  |  | 623 |  |  |  | 611 |  |  |  | 607 |  |
| Public Cloud |  |  | 154 |  |  |  | 154 |  |  |  | 142 |  |
| Software and recurring support and public cloud revenue* |  | $ | 1,175 |  |  | $ | 1,107 |  |  | $ | 1,244 |  |
| Software and recurring support and public cloud revenue as a percentage of net revenues |  |  | 75 | % |  |  | 77 | % |  |  | 75 | % |
| * Our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation. We have provided a breakdown of our GAAP product revenues into the software and hardware components, which are considered non-GAAP measures, to display the significance of software included in total product revenues. Software and recurring support and public cloud revenue is a non-GAAP measure because it includes the software component of our product revenues, but not the hardware component. |  |

[0000950170-23-066400:8k_2_02:126]
| Geographic Mix** |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'24 |  |  | % of Q1 FY'24 |  |  | % of Q2 FY'23 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 50 | % |  |  | 53 | % |  |  | 51 | % |
| Americas Commercial |  |  | 37 | % |  |  | 41 | % |  |  | 37 | % |
| U.S. Public Sector |  |  | 13 | % |  |  | 12 | % |  |  | 14 | % |
| EMEA |  |  | 34 | % |  |  | 31 | % |  |  | 34 | % |
| Asia Pacific |  |  | 16 | % |  |  | 16 | % |  |  | 15 | % |
| ** Effective in Q1 FY'24, management began evaluating revenues by geographic region based on the location to which products and services are delivered, rather than based on the location from which the customer relationship is managed. Prior year percentages have been conformed to the current year presentation. |  |
| Pathways Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'24 |  |  | % of Q1 FY'24 |  |  | % of Q2 FY'23 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 23 | % |  |  | 24 | % |  |  | 23 | % |
| Indirect |  |  | 77 | % |  |  | 76 | % |  |  | 77 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| Non-GAAP Income from Operations |  | $ | 419 |  |  | $ | 309 |  |  | $ | 393 |  |
| % of Net Revenues |  |  | 26.8 | % |  |  | 21.6 | % |  |  | 23.6 | % |
| Non-GAAP Income before Income Taxes |  | $ | 425 |  |  | $ | 317 |  |  | $ | 416 |  |
| Non-GAAP Effective Tax Rate |  |  | 21.4 | % |  |  | 21.5 | % |  |  | 21.6 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| Non-GAAP Net Income |  | $ | 334 |  |  | $ | 249 |  |  | $ | 326 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 211 |  |  |  | 216 |  |  |  | 220 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.58 |  |  | $ | 1.15 |  |  | $ | 1.48 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 4,002 |  |  | $ | 4,182 |  |  | $ | 4,051 |  |
| DSO (days) |  |  | 46 |  |  |  | 41 |  |  |  | 50 |  |
| DPO (days) |  |  | 83 |  |  |  | 72 |  |  |  | 92 |  |
| Inventory Turns |  |  | 15 |  |  |  | 13 |  |  |  | 9 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |  |  |  |  |  |  |  |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |  |  |  |  |  |  |  |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |  |  |  |  |  |  |  |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| Net Cash Provided by Operating Activities |  | $ | 135 |  |  | $ | 453 |  |  | $ | 214 |  |
| Purchases of Property and Equipment |  | $ | 38 |  |  | $ | 35 |  |  | $ | 77 |  |
| Free Cash Flow |  | $ | 97 |  |  | $ | 418 |  |  | $ | 137 |  |
| Free Cash Flow as % of Net Revenues |  |  | 6.2 | % |  |  | 29.2 | % |  |  | 8.2 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |  |  |  |  |  |  |  |  |

[0000950170-23-066400:8k_2_02:127]
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |

[0000950170-23-066400:8k_2_02:128]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| NET INCOME |  | $ | 233 |  |  | $ | 149 |  |  | $ | 750 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 15 |  |  |  | 17 |  |
| Stock-based compensation |  |  | 93 |  |  |  | 87 |  |  |  | 78 |  |
| Restructuring charges |  |  | 5 |  |  |  | 26 |  |  |  | 11 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 3 |  |  |  | 5 |  |
| Litigation settlements |  |  | (5 | ) |  |  | — |  |  |  | — |  |
| Income tax effects |  |  | (9 | ) |  |  | (31 | ) |  |  | (11 | ) |
| Income tax benefit from intra-entity intellectual property transfer |  |  | — |  |  |  | — |  |  |  | (524 | ) |
| NON-GAAP NET INCOME |  | $ | 334 |  |  | $ | 249 |  |  | $ | 326 |  |
| COST OF REVENUES |  | $ | 452 |  |  | $ | 436 |  |  | $ | 576 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (9 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (7 | ) |  |  | (7 | ) |  |  | (5 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 437 |  |  | $ | 420 |  |  | $ | 561 |  |
| COST OF PRODUCT REVENUES |  | $ | 276 |  |  | $ | 265 |  |  | $ | 418 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 275 |  |  | $ | 264 |  |  | $ | 417 |  |
| COST OF SERVICES REVENUES |  | $ | 176 |  |  | $ | 171 |  |  | $ | 158 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (9 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (6 | ) |  |  | (4 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 162 |  |  | $ | 156 |  |  | $ | 144 |  |
| GROSS PROFIT |  | $ | 1,110 |  |  | $ | 996 |  |  | $ | 1,087 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 8 |  |  |  | 9 |  |  |  | 10 |  |
| Stock-based compensation |  |  | 7 |  |  |  | 7 |  |  |  | 5 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,125 |  |  | $ | 1,012 |  |  | $ | 1,102 |  |

[0000950170-23-066400:8k_2_02:129]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| SALES AND MARKETING EXPENSES |  | $ | 461 |  |  | $ | 468 |  |  | $ | 479 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (6 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (37 | ) |  |  | (36 | ) |  |  | (35 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 418 |  |  | $ | 426 |  |  | $ | 437 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 262 |  |  | $ | 247 |  |  | $ | 243 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (35 | ) |  |  | (32 | ) |  |  | (26 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 227 |  |  | $ | 215 |  |  | $ | 217 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 75 |  |  | $ | 74 |  |  | $ | 67 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (14 | ) |  |  | (12 | ) |  |  | (12 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 61 |  |  | $ | 62 |  |  | $ | 55 |  |
| RESTRUCTURING CHARGES |  | $ | 5 |  |  | $ | 26 |  |  | $ | 11 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (5 | ) |  |  | (26 | ) |  |  | (11 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 3 |  |  | $ | 3 |  |  | $ | 5 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (3 | ) |  |  | (3 | ) |  |  | (5 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 806 |  |  | $ | 818 |  |  | $ | 805 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (6 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (86 | ) |  |  | (80 | ) |  |  | (73 | ) |
| Restructuring charges |  |  | (5 | ) |  |  | (26 | ) |  |  | (11 | ) |
| Acquisition-related expense |  |  | (3 | ) |  |  | (3 | ) |  |  | (5 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 706 |  |  | $ | 703 |  |  | $ | 709 |  |

[0000950170-23-066400:8k_2_02:130]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| INCOME FROM OPERATIONS |  | $ | 304 |  |  | $ | 178 |  |  | $ | 282 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 15 |  |  |  | 17 |  |
| Stock-based compensation |  |  | 93 |  |  |  | 87 |  |  |  | 78 |  |
| Restructuring charges |  |  | 5 |  |  |  | 26 |  |  |  | 11 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 3 |  |  |  | 5 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 419 |  |  | $ | 309 |  |  | $ | 393 |  |
| OTHER INCOME, NET |  | $ | 11 |  |  | $ | 8 |  |  | $ | 23 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Litigation settlements |  |  | (5 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP OTHER INCOME, NET |  | $ | 6 |  |  | $ | 8 |  |  | $ | 23 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 315 |  |  | $ | 186 |  |  | $ | 305 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 15 |  |  |  | 17 |  |
| Stock-based compensation |  |  | 93 |  |  |  | 87 |  |  |  | 78 |  |
| Restructuring charges |  |  | 5 |  |  |  | 26 |  |  |  | 11 |  |
| Acquisition-related expense |  |  | 3 |  |  |  | 3 |  |  |  | 5 |  |
| Litigation settlements |  |  | (5 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 425 |  |  | $ | 317 |  |  | $ | 416 |  |
| PROVISION (BENEFIT) FOR INCOME TAXES |  | $ | 82 |  |  | $ | 37 |  |  | $ | (445 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 9 |  |  |  | 31 |  |  |  | 11 |  |
| Income tax benefit from intra-entity intellectual property transfer |  |  | — |  |  |  | — |  |  |  | 524 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 91 |  |  | $ | 68 |  |  | $ | 90 |  |
| NET INCOME PER SHARE |  | $ | 1.10 |  |  | $ | 0.69 |  |  | $ | 3.41 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.07 |  |  |  | 0.07 |  |  |  | 0.08 |  |
| Stock-based compensation |  |  | 0.44 |  |  |  | 0.40 |  |  |  | 0.35 |  |
| Restructuring charges |  |  | 0.02 |  |  |  | 0.12 |  |  |  | 0.05 |  |
| Acquisition-related expense |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.02 |  |
| Litigation settlements |  |  | (0.02 | ) |  |  | — |  |  |  | — |  |
| Income tax effects |  |  | (0.04 | ) |  |  | (0.14 | ) |  |  | (0.05 | ) |
| Income tax benefit from intra-entity intellectual property transfer |  |  | — |  |  |  | — |  |  |  | (2.38 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.58 |  |  | $ | 1.15 |  |  | $ | 1.48 |  |

[0000950170-23-066400:8k_2_02:131]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| Gross margin-GAAP |  |  | 71.1 | % |  |  | 69.6 | % |  |  | 65.4 | % |
| Cost of revenues adjustments |  |  | 1.0 | % |  |  | 1.1 | % |  |  | 0.9 | % |
| Gross margin-Non-GAAP |  |  | 72.0 | % |  |  | 70.7 | % |  |  | 66.3 | % |
| GAAP cost of revenues |  | $ | 452 |  |  | $ | 436 |  |  | $ | 576 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (9 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (7 | ) |  |  | (7 | ) |  |  | (5 | ) |
| Non-GAAP cost of revenues |  | $ | 437 |  |  | $ | 420 |  |  | $ | 561 |  |
| Net revenues |  | $ | 1,562 |  |  | $ | 1,432 |  |  | $ | 1,663 |  |

[0000950170-23-066400:8k_2_02:132]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| Product gross margin-GAAP |  |  | 60.9 | % |  |  | 55.1 | % |  |  | 50.1 | % |
| Cost of product revenues adjustments |  |  | 0.1 | % |  |  | 0.2 | % |  |  | 0.1 | % |
| Product gross margin-Non-GAAP |  |  | 61.0 | % |  |  | 55.3 | % |  |  | 50.2 | % |
| GAAP cost of product revenues |  | $ | 276 |  |  | $ | 265 |  |  | $ | 418 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 275 |  |  | $ | 264 |  |  | $ | 417 |  |
| Product revenues |  | $ | 706 |  |  | $ | 590 |  |  | $ | 837 |  |

[0000950170-23-066400:8k_2_02:133]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| Services gross margin-GAAP |  |  | 79.4 | % |  |  | 79.7 | % |  |  | 80.9 | % |
| Cost of services revenues adjustments |  |  | 1.6 | % |  |  | 1.8 | % |  |  | 1.7 | % |
| Services gross margin-Non-GAAP |  |  | 81.1 | % |  |  | 81.5 | % |  |  | 82.6 | % |
| GAAP cost of services revenues |  | $ | 176 |  |  | $ | 171 |  |  | $ | 158 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (8 | ) |  |  | (9 | ) |  |  | (10 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (6 | ) |  |  | (4 | ) |
| Non-GAAP cost of services revenues |  | $ | 162 |  |  | $ | 156 |  |  | $ | 144 |  |
| Services revenues |  | $ | 856 |  |  | $ | 842 |  |  | $ | 826 |  |

[0000950170-23-066400:8k_2_02:134]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| GAAP effective tax rate |  |  | 26.0 | % |  |  | 19.9 | % |  |  | (145.9 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | (4.6 | )% |  |  | 1.6 | % |  |  | 41.6 | % |
| Income tax benefit from intra-entity intellectual property transfer |  |  | — | % |  |  | — | % |  |  | 126.0 | % |
| Non-GAAP effective tax rate |  |  | 21.4 | % |  |  | 21.5 | % |  |  | 21.6 | % |

[0000950170-23-066400:8k_2_02:135]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| Net cash provided by operating activities |  | $ | 135 |  |  | $ | 453 |  |  | $ | 214 |  |
| Purchases of property and equipment |  |  | (38 | ) |  |  | (35 | ) |  |  | (77 | ) |
| Free cash flow |  | $ | 97 |  |  | $ | 418 |  |  | $ | 137 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY24 |  |  | Q1'FY24 |  |  | Q2'FY23 |  |
| Net revenues |  | $ | 1,562 |  |  | $ | 1,432 |  |  | $ | 1,663 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | (108 | ) |  |  | (133 | ) |  |  | (61 | ) |
| Billings |  | $ | 1,454 |  |  | $ | 1,299 |  |  | $ | 1,602 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0000950170-23-066400:8k_2_02:136]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| THIRD QUARTER FISCAL 2024 |
|  |  | Third Quarter |
|  |  | Fiscal 2024 |
| Non-GAAP Guidance - Net Income Per Share |  | $1.64-$1.74 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the Third Quarter Fiscal 2024: |  |  |
| Amortization of intangible assets |  | ($0.07) |
| Stock-based compensation expense |  | ($0.44) |
| Income tax effects |  | $0.04 |
| Total Adjustments |  | ($0.47) |
| GAAP Guidance - Net Income Per Share |  | $1.17-$1.27 |

[0000950170-23-066400:8k_2_02:137]
Some items may not add or recalculate due to rounding.

[0000950170-23-066400:8k_2_02:138]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| Fiscal 2024 |
|  |  | Fiscal 2024 |
| Gross Margin - Non-GAAP Guidance |  | ~71% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | (1)% |
| Gross Margin - GAAP Guidance |  | ~70% |
|  |  | Fiscal 2024 |
| Operating Margin - Non-GAAP Guidance |  | ~26% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | (1)% |
| Stock-based compensation expense |  | (6)% |
| Operating Margin - GAAP Guidance |  | ~19% |

[0000950170-23-066400:8k_2_02:139]
Some items may not add or recalculate due to rounding.

[0000950170-23-066400:8k_2_02:140]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| Fiscal 2024 |
|  |  | Fiscal 2024 |
| Non-GAAP Guidance - Net Income Per Share |  | $6.05-$6.25 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2024: |  |  |
| Amortization of intangible assets |  | ($0.27) |
| Stock-based compensation expense |  | ($1.73) |
| Restructuring charges |  | ($0.15) |
| Acquisition-related expenses |  | ($0.03) |
| Litigation Settlement |  | $0.02 |
| Income tax effects |  | $0.26 |
| Total Adjustments |  | ($1.90) |
| GAAP Guidance - Net Income Per Share |  | $4.15-$4.35 |

[0000950170-23-066400:8k_2_02:141]
Some items may not add or recalculate due to rounding.

[0000950170-23-066400:8k_2_02:142]
Contacts:

[0000950170-23-066400:8k_2_02:143]
(Press)

[0000950170-23-066400:8k_2_02:144]
Kenya Hayes

[0000950170-23-066400:8k_2_02:145]
1 703 589 7595

[0000950170-23-066400:8k_2_02:146]
kenya.hayes@netapp.com

[0000950170-23-066400:8k_2_02:147]
(Investors)

[0000950170-23-066400:8k_2_02:148]
Kris Newton

[0000950170-23-066400:8k_2_02:149]
1 408 822 3312

[0000950170-23-066400:8k_2_02:150]
kris.newton@netapp.com
