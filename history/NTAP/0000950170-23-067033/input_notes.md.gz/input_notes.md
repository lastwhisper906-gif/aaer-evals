# NTAP notes — 0000950170-23-067033


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000950170-23-067033:notes:1]
[same as prior period, unchanged from 0000950170-23-045061:notes:1]

[0000950170-23-067033:notes:2]
[same as prior period, unchanged from 0000950170-23-045061:notes:2]

[0000950170-23-067033:notes:3]
[same as prior period, unchanged from 0000950170-23-045061:notes:3]

[0000950170-23-067033:notes:4]
[same as prior period, unchanged from 0000950170-23-045061:notes:4]

[0000950170-23-067033:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 28, 2023 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 27, 2023 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0000950170-23-067033:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, the anticipated effects of which have been incorporated, as applicable, into management's estimates as of October 27, 2023.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000950170-23-067033:notes:7]
2. Recent Accounting Pronouncements

[0000950170-23-067033:notes:8]
Although there are new accounting pronouncements issued or proposed by the FASB that we have adopted or will adopt, as applicable, we do not believe any of these accounting pronouncements had or will have a material impact on our consolidated financial position, operating results, cash flows or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-23-067033:notes:9]
[same as prior period, unchanged from 0000950170-23-045061:notes:9]

[0000950170-23-067033:notes:10]
[same as prior period, unchanged from 0000950170-23-045061:notes:10]

[0000950170-23-067033:notes:11]
[same as prior period, unchanged from 0000950170-23-045061:notes:11]

[0000950170-23-067033:notes:12]
[same as prior period, unchanged from 0000950170-23-045061:notes:12]

[0000950170-23-067033:notes:13]
[same as prior period, unchanged from 0000950170-23-045061:notes:13]

[0000950170-23-067033:notes:14]
[same as prior period, unchanged from 0000950170-23-045061:notes:14]

[0000950170-23-067033:notes:15]
[same as prior period, unchanged from 0000950170-23-045061:notes:15]

[0000950170-23-067033:notes:16]
[same as prior period, unchanged from 0000950170-23-045061:notes:16]

[0000950170-23-067033:notes:17]
[same as prior period, unchanged from 0000950170-23-045061:notes:17]

[0000950170-23-067033:notes:18]
[same as prior period, unchanged from 0000950170-23-045061:notes:18]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-23-067033:notes:19]
[same as prior period, unchanged from 0000950170-23-045061:notes:19]

[0000950170-23-067033:notes:20]
Goodwill by reportable segment as of October 27, 2023 is as follows (in millions):

[0000950170-23-067033:notes:21]
[same as prior period, unchanged from 0000950170-23-045061:notes:21]

[0000950170-23-067033:notes:22]
[same as prior period, unchanged from 0000950170-23-045061:notes:22]

[0000950170-23-067033:notes:23]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 179 |  |  | $ | (91 | ) |  | $ | 88 |  |  | $ | 212 |  |  | $ | (107 | ) |  | $ | 105 |  |
| Customer contracts/relationships |  |  | 114 |  |  |  | (51 | ) |  |  | 63 |  |  |  | 118 |  |  |  | (44 | ) |  |  | 74 |  |
| Other purchased intangibles |  |  | 6 |  |  |  | (5 | ) |  |  | 1 |  |  |  | 6 |  |  |  | (4 | ) |  |  | 2 |  |
| Total purchased intangible assets |  | $ | 299 |  |  | $ | (147 | ) |  | $ | 152 |  |  | $ | 336 |  |  | $ | (155 | ) |  | $ | 181 |  |

[0000950170-23-067033:notes:24]
During the first six months of fiscal 2024, we retired approximately $37 million of fully amortized intangible assets.

[0000950170-23-067033:notes:25]
[same as prior period, unchanged from 0000950170-23-045061:notes:25]

[0000950170-23-067033:notes:26]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Statements of |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | IncomeClassification |
| Developed technology |  | $ | 8 |  |  | $ | 11 |  |  | $ | 17 |  |  | $ | 21 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 6 |  |  |  | 6 |  |  |  | 11 |  |  |  | 12 |  |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  | Operating expenses |
| Total |  | $ | 14 |  |  | $ | 17 |  |  | $ | 29 |  |  | $ | 34 |  |  |  |

[0000950170-23-067033:notes:27]
As of October 27, 2023, future amortization expense related to purchased intangible assets is as follows (in millions):

[0000950170-23-067033:notes:28]
| Fiscal Year |  | Amount |  |
| 2024 (remainder) |  | $ | 28 |  |
| 2025 |  |  | 55 |  |
| 2026 |  |  | 39 |  |
| 2027 |  |  | 29 |  |
| 2028 |  |  | 1 |  |
| Total |  | $ | 152 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-23-067033:notes:29]
[same as prior period, unchanged from 0000950170-23-045061:notes:29]

[0000950170-23-067033:notes:30]
[same as prior period, unchanged from 0000950170-23-045061:notes:30]

[0000950170-23-067033:notes:31]
[same as prior period, unchanged from 0000950170-23-045061:notes:31]

[0000950170-23-067033:notes:32]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| Cash and cash equivalents |  | $ | 1,934 |  |  | $ | 2,316 |  |
| Restricted cash |  |  | 7 |  |  |  | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 1,941 |  |  | $ | 2,322 |  |

[0000950170-23-067033:notes:33]
[same as prior period, unchanged from 0000950170-23-045061:notes:33]

[0000950170-23-067033:notes:34]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| Purchased components |  | $ | 52 |  |  | $ | 65 |  |
| Finished goods |  |  | 70 |  |  |  | 102 |  |
| Inventories |  | $ | 122 |  |  | $ | 167 |  |

[0000950170-23-067033:notes:35]
[same as prior period, unchanged from 0000950170-23-045061:notes:35]

[0000950170-23-067033:notes:36]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 367 |  |  |  | 359 |  |
| Leasehold improvements |  |  | 81 |  |  |  | 91 |  |
| Computer, production, engineering and other equipment |  |  | 1,085 |  |  |  | 1,053 |  |
| Computer software |  |  | 332 |  |  |  | 325 |  |
| Furniture and fixtures |  |  | 77 |  |  |  | 84 |  |
| Construction-in-progress |  |  | 59 |  |  |  | 55 |  |
|  |  |  | 2,047 |  |  |  | 2,013 |  |
| Accumulated depreciation and amortization |  |  | (1,424 | ) |  |  | (1,363 | ) |
| Property and equipment, net |  | $ | 623 |  |  | $ | 650 |  |

[0000950170-23-067033:notes:37]
[same as prior period, unchanged from 0000950170-23-045061:notes:37]

[0000950170-23-067033:notes:38]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| Deferred tax assets |  | $ | 960 |  |  | $ | 948 |  |
| Operating lease right-of-use (ROU) assets |  |  | 260 |  |  |  | 281 |  |
| Other assets |  |  | 326 |  |  |  | 319 |  |
| Other non-current assets |  | $ | 1,546 |  |  | $ | 1,548 |  |

[0000950170-23-067033:notes:39]
Other non-current assets as of October 27, 2023 and April 28, 2023 include $83 million and $80 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies.

[0000950170-23-067033:notes:40]
[same as prior period, unchanged from 0000950170-23-045061:notes:40]

[0000950170-23-067033:notes:41]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| Accrued compensation and benefits |  | $ | 413 |  |  | $ | 363 |  |
| Product warranty liabilities |  |  | 18 |  |  |  | 17 |  |
| Operating lease liabilities |  |  | 41 |  |  |  | 47 |  |
| Other current liabilities |  |  | 447 |  |  |  | 430 |  |
| Accrued expenses |  | $ | 919 |  |  | $ | 857 |  |

[0000950170-23-067033:notes:42]
[same as prior period, unchanged from 0000950170-23-045061:notes:42]

[0000950170-23-067033:notes:43]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| Liability for uncertain tax positions |  | $ | 148 |  |  | $ | 144 |  |
| Income taxes payable |  |  | 100 |  |  |  | 215 |  |
| Product warranty liabilities |  |  | 8 |  |  |  | 8 |  |
| Operating lease liabilities |  |  | 230 |  |  |  | 248 |  |
| Other liabilities |  |  | 94 |  |  |  | 93 |  |
| Other long-term liabilities |  | $ | 580 |  |  | $ | 708 |  |

[0000950170-23-067033:notes:44]
[same as prior period, unchanged from 0000950170-23-045061:notes:44]

[0000950170-23-067033:notes:45]
[same as prior period, unchanged from 0000950170-23-045061:notes:45]

[0000950170-23-067033:notes:46]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| Deferred product revenue |  | $ | 36 |  |  | $ | 18 |  |
| Deferred services revenue |  |  | 3,923 |  |  |  | 4,247 |  |
| Financed unearned services revenue |  |  | 43 |  |  |  | 48 |  |
| Total |  | $ | 4,002 |  |  | $ | 4,313 |  |
| Reported as: |  |  |  |  |  |  |
| Short-term |  | $ | 2,003 |  |  | $ | 2,218 |  |
| Long-term |  |  | 1,999 |  |  |  | 2,095 |  |
| Total |  | $ | 4,002 |  |  | $ | 4,313 |  |

[0000950170-23-067033:notes:47]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 15 – Commitments and Contingencies for additional information related to these arrangements.

[0000950170-23-067033:notes:48]
During the six months ended October 27, 2023 and October 28, 2022, we recognized revenue of $1,258 million and $1,280 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0000950170-23-067033:notes:49]
As of October 27, 2023, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied approximated our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 25% in the next 13 to 24 months, and the remainder thereafter.

[0000950170-23-067033:notes:50]
[same as prior period, unchanged from 0000950170-23-045061:notes:50]

[0000950170-23-067033:notes:51]
[same as prior period, unchanged from 0000950170-23-045061:notes:51]

[0000950170-23-067033:notes:52]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| Other current assets |  | $ | 64 |  |  | $ | 64 |  |
| Other non-current assets |  |  | 96 |  |  |  | 99 |  |
| Total deferred commissions |  | $ | 160 |  |  | $ | 163 |  |

[0000950170-23-067033:notes:53]
[same as prior period, unchanged from 0000950170-23-045061:notes:53]

[0000950170-23-067033:notes:54]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | October 27, 2023 |  |  | October 28, 2022 |  |
| Interest income |  | $ | 25 |  |  | $ | 14 |  |  | $ | 53 |  |  | $ | 21 |  |
| Interest expense |  |  | (15 | ) |  |  | (17 | ) |  |  | (31 | ) |  |  | (35 | ) |
| Other, net |  |  | 1 |  |  |  | 26 |  |  |  | (3 | ) |  |  | 52 |  |
| Total other income, net |  | $ | 11 |  |  | $ | 23 |  |  | $ | 19 |  |  | $ | 38 |  |

[0000950170-23-067033:notes:55]
In the second quarter of fiscal 2023, Other, net includes $21 million of other income for non-refundable, up-front payments from customers in Russia for support contracts, which we were not able to fulfill due to imposed sanctions and for which we have no remaining legal obligation to perform. During the six months ended October 28, 2022, Other, net also includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million in the first quarter of fiscal 2023.

[0000950170-23-067033:notes:56]
[same as prior period, unchanged from 0000950170-23-045061:notes:56]

[0000950170-23-067033:notes:57]
[same as prior period, unchanged from 0000950170-23-045061:notes:57]

[0000950170-23-067033:notes:58]
|  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 18 |  |  | $ | 27 |  |  |  |
| Liabilities incurred to former owners of acquired business |  | $ | — |  |  | $ | 3 |  |  |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 222 |  |  | $ | 203 |  |  |  |
| Interest paid |  | $ | 30 |  |  | $ | 36 |  |  |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-23-067033:notes:59]
[same as prior period, unchanged from 0000950170-23-045061:notes:59]

[0000950170-23-067033:notes:60]
[same as prior period, unchanged from 0000950170-23-045061:notes:60]

[0000950170-23-067033:notes:61]
[same as prior period, unchanged from 0000950170-23-045061:notes:61]

[0000950170-23-067033:notes:62]
[same as prior period, unchanged from 0000950170-23-045061:notes:62]

[0000950170-23-067033:notes:63]
[same as prior period, unchanged from 0000950170-23-045061:notes:63]

[0000950170-23-067033:notes:64]
[same as prior period, unchanged from 0000950170-23-045061:notes:64]

[0000950170-23-067033:notes:65]
[same as prior period, unchanged from 0000950170-23-045061:notes:65]

[0000950170-23-067033:notes:66]
The following is a summary of our investments at their cost or amortized cost as of October 27, 2023 and April 28, 2023 (in millions):

[0000950170-23-067033:notes:67]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |  |
| U.S. Treasury and government debt securities |  |  | 800 |  |  |  | 754 |  |  |
| Money market funds |  |  | 365 |  |  |  | 794 |  |  |
| Certificates of deposit |  |  | 43 |  |  |  | 59 |  |  |
| Mutual funds |  |  | 34 |  |  |  | 36 |  |  |
| Total debt and equity securities |  | $ | 1,242 |  |  | $ | 1,643 |  |  |

[0000950170-23-067033:notes:68]
[same as prior period, unchanged from 0000950170-23-045061:notes:68]

[0000950170-23-067033:notes:69]
As of October 27, 2023, all our debt investments are due to mature in one year or less.

[0000950170-23-067033:notes:70]
[same as prior period, unchanged from 0000950170-23-045061:notes:70]

[0000950170-23-067033:notes:71]
[same as prior period, unchanged from 0000950170-23-045061:notes:71]

[0000950170-23-067033:notes:72]
|  |  | October 27, 2023 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 1,412 |  |  | $ | 1,412 |  |  | $ | — |  |
| Money market funds |  |  | 365 |  |  |  | 365 |  |  |  | — |  |
| Certificates of deposit |  |  | 43 |  |  |  | — |  |  |  | 43 |  |
| U.S. Treasury and government debt securities |  |  | 114 |  |  |  | 114 |  |  |  | — |  |
| Total cash and cash equivalents |  |  | 1,934 |  |  |  | 1,891 |  |  |  | 43 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 686 |  |  |  | 686 |  |  |  | — |  |
| Total short-term investments |  |  | 686 |  |  |  | 686 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 2,620 |  |  | $ | 2,577 |  |  | $ | 43 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 28 |  |  | $ | 28 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (7 | ) |  | $ | — |  |  | $ | (7 | ) |

[0000950170-23-067033:notes:73]
[same as prior period, unchanged from 0000950170-23-045061:notes:73]

[0000950170-23-067033:notes:74]
[same as prior period, unchanged from 0000950170-23-045061:notes:74]

[0000950170-23-067033:notes:75]
[same as prior period, unchanged from 0000950170-23-045061:notes:75]

[0000950170-23-067033:notes:76]
[same as prior period, unchanged from 0000950170-23-045061:notes:76]

[0000950170-23-067033:notes:77]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of October 27, 2023 and April 28, 2023, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0000950170-23-067033:notes:78]
[same as prior period, unchanged from 0000950170-23-045061:notes:78]

[0000950170-23-067033:notes:79]
As of October 27, 2023 and April 28, 2023, the fair value of our long-term debt was approximately $2,140 million and $2,206 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0000950170-23-067033:notes:80]
7. Financing Arrangements

[0000950170-23-067033:notes:81]
Long-Term Debt

[0000950170-23-067033:notes:82]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0000950170-23-067033:notes:83]
|  |  | Effective Interest Rate |  | October 27, 2023 |  |  | April 28, 2023 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  | $ | 400 |  |  | $ | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,400 |  |  |  | 2,400 |  |
| Unamortized discount and issuance costs |  |  |  |  | (9 | ) |  |  | (11 | ) |
| Total senior notes |  |  |  |  | 2,391 |  |  |  | 2,389 |  |
| Less: Current portion of long-term debt |  |  |  |  | (400 | ) |  |  | — |  |
| Total long-term debt |  |  |  | $ | 1,991 |  |  | $ | 2,389 |  |

[0000950170-23-067033:notes:84]
Senior Notes

[0000950170-23-067033:notes:85]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were each issued in June 2020. Interest on each of these Senior Notes is payable semi-annually in June and December. Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September.

[0000950170-23-067033:notes:86]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0000950170-23-067033:notes:87]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 27, 2023, we were in compliance with all covenants associated with the Senior Notes.

[0000950170-23-067033:notes:88]
As of October 27, 2023, our aggregate future principal debt maturities are as follows (in millions):

[0000950170-23-067033:notes:89]
| Fiscal Year |  | Amount |  |
| 2024 (remainder) |  | $ | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| 2027 |  |  | — |  |
| 2028 |  |  | 550 |  |
| Thereafter |  |  | 700 |  |
| Total |  | $ | 2,400 |  |

[0000950170-23-067033:notes:90]
Commercial Paper Program and Credit Facility

[0000950170-23-067033:notes:91]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of October 27, 2023 or April 28, 2023.

[0000950170-23-067033:notes:92]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023 primarily to replace the London Interbank Offered Rate (LIBOR) with the Secured Overnight Financing Rate (SOFR) as the basis for establishing the interest rate applicable to certain borrowings under the agreement, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of October 27, 2023, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0000950170-23-067033:notes:93]
[same as prior period, unchanged from 0000950170-23-045061:notes:93]

[0000950170-23-067033:notes:94]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of October 27, 2023, have remaining lease terms not exceeding 19 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of October 27, 2023, have remaining lease terms not exceeding 4 years. As of October 27, 2023, our automobile leases have remaining lease terms not exceeding 4 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0000950170-23-067033:notes:95]
[same as prior period, unchanged from 0000950170-23-045061:notes:95]

[0000950170-23-067033:notes:96]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | October 27, 2023 |  |  | October 28, 2022 |  |
| Operating lease cost |  | $ | 14 |  |  | $ | 16 |  |  | $ | 28 |  |  | $ | 31 |  |
| Variable lease cost |  |  | 4 |  |  |  | 4 |  |  |  | 8 |  |  |  | 8 |  |
| Total lease cost |  | $ | 18 |  |  | $ | 20 |  |  | $ | 36 |  |  | $ | 39 |  |

[0000950170-23-067033:notes:97]
[same as prior period, unchanged from 0000950170-23-045061:notes:97]

[0000950170-23-067033:notes:98]
[same as prior period, unchanged from 0000950170-23-045061:notes:98]

[0000950170-23-067033:notes:99]
|  |  |  |  | Six Months Ended |  |
|  |  |  |  |  |  | October 27, 2023 |  |  | October 28, 2022 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  |  |  |  |  | $ | 26 |  |  | $ | 29 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  |  |  |  |  | $ | 13 |  |  | $ | 31 |  |

[0000950170-23-067033:notes:100]
[same as prior period, unchanged from 0000950170-23-045061:notes:100]

[0000950170-23-067033:notes:101]
|  |  |  |  |  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| Other non-current assets |  |  |  |  |  | $ | 260 |  |  | $ | 281 |  |
| Total operating lease ROU assets |  |  |  |  |  | $ | 260 |  |  | $ | 281 |  |
| Accrued expenses |  |  |  |  |  | $ | 41 |  |  | $ | 47 |  |
| Other long-term liabilities |  |  |  |  |  |  | 230 |  |  |  | 248 |  |
| Total operating lease liabilities |  |  |  |  |  | $ | 271 |  |  | $ | 295 |  |
| Weighted Average Remaining Lease Term |  |  |  |  |  | 9.5 years |  |  | 9.4 years |  |
| Weighted Average Discount Rate |  |  |  |  |  |  | 3.0 | % |  |  | 3.0 | % |

[0000950170-23-067033:notes:102]
Future minimum operating lease payments as of October 27, 2023, are as follows (in millions):

[0000950170-23-067033:notes:103]
| Fiscal Year |  |  |  |  |  | Amount |  |
| 2024 (remainder) |  |  |  |  |  | $ | 24 |  |
| 2025 |  |  |  |  |  |  | 42 |  |
| 2026 |  |  |  |  |  |  | 36 |  |
| 2027 |  |  |  |  |  |  | 32 |  |
| 2028 |  |  |  |  |  |  | 29 |  |
| Thereafter |  |  |  |  |  |  | 153 |  |
| Total lease payments |  |  |  |  |  |  | 316 |  |
| Less: Interest |  |  |  |  |  |  | (45 | ) |
| Total |  |  |  |  |  | $ | 271 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000950170-23-067033:notes:104]
[same as prior period, unchanged from 0000950170-23-045061:notes:104]

[0000950170-23-067033:notes:105]
[same as prior period, unchanged from 0000950170-23-045061:notes:105]

[0000950170-23-067033:notes:106]
We granted approximately 5 million restricted stock units (RSUs), including performance-based RSUs (PBRSUs), with a weighted average grant date fair value of $75.14 per share during the six months ended October 27, 2023.

[0000950170-23-067033:notes:107]
In the first quarter of fiscal 2024, due to an insufficient number of remaining shares available for issuance under the 2021 Equity Incentive Plan (the 2021 Plan), most of the awards granted in that period were subject to cash settlement upon vesting, and accounted for as liability awards. However, in the second quarter of fiscal 2024, stockholders approved an increase in the number of shares available for issuance under the 2021 Plan, and these awards, by their terms, automatically became share-settled, equity-classified

[0000950170-23-067033:notes:108]
awards. The modification resulted in the elimination of the $4 million liability related to these awards, with a corresponding increase to additional paid-in capital, as presented on the Statements of Stockholders' Equity.

[0000950170-23-067033:notes:109]
In the six months ended October 27, 2023, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSUs cliff-vest at the end of a three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the third fiscal year, following the grant date. The number of shares that will be used to calculate the settlement amount for all of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the six months ended October 27, 2023, the number of shares used to calculate the settlement amount will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. For the remaining half of the PBRSUs granted in the six months ended October 27, 2023, the number of shares used to calculate the settlement amount will depend upon the Company's billings result average over the three-year performance period as compared to a predetermined billings target. Billings for purposes of measuring the performance of these PBRSUs means the total obtained by adding net revenues as reported on the Company's Consolidated Statements of Income to the amount reported as the change in deferred revenue and financed unearned services revenue on the Consolidated Statements of Cash Flows for the applicable measurement period, excluding the impact of fluctuations in foreign currency exchange rates. The aggregate grant date fair value of PBRSUs effectively granted in the current year was $39 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0000950170-23-067033:notes:110]
[same as prior period, unchanged from 0000950170-23-045061:notes:109]

[0000950170-23-067033:notes:111]
[same as prior period, unchanged from 0000950170-23-045061:notes:110]

[0000950170-23-067033:notes:112]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | October 27, 2023 |  |  | October 28, 2022 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |
| Cost of services revenues |  |  | 6 |  |  |  | 4 |  |  |  | 12 |  |  |  | 8 |  |
| Sales and marketing |  |  | 37 |  |  |  | 35 |  |  |  | 73 |  |  |  | 63 |  |
| Research and development |  |  | 35 |  |  |  | 26 |  |  |  | 67 |  |  |  | 50 |  |
| General and administrative |  |  | 14 |  |  |  | 12 |  |  |  | 26 |  |  |  | 22 |  |
| Total stock-based compensation expense |  | $ | 93 |  |  | $ | 78 |  |  | $ | 180 |  |  | $ | 145 |  |

[0000950170-23-067033:notes:113]
As of October 27, 2023, total unrecognized compensation expense related to equity awards was $751 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.3 years.

[0000950170-23-067033:notes:114]
[same as prior period, unchanged from 0000950170-23-045061:notes:114]

[0000950170-23-067033:notes:115]
As of October 27, 2023, our Board of Directors has authorized the repurchase of up to $16.1 billion of our common stock. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time.

[0000950170-23-067033:notes:116]
The following table summarizes activity related to the stock repurchase program for the six months ended October 27, 2023 (in millions, except for per share amounts):

[0000950170-23-067033:notes:117]
| Number of shares repurchased |  |  | 9 |  |
| Average price per share |  | $ | 75.12 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 91 |  |
| Stock repurchases allocated to retained earnings |  | $ | 609 |  |
| Remaining authorization at end of period |  | $ | 702 |  |

[0000950170-23-067033:notes:118]
Since the May 13, 2003 inception of our stock repurchase program through October 27, 2023, we repurchased a total of 369 million shares of our common stock at an average price of $41.75 per share, for an aggregate purchase price of $15.4 billion.

[0000950170-23-067033:notes:119]
[same as prior period, unchanged from 0000950170-23-045061:notes:119]

[0000950170-23-067033:notes:120]
[same as prior period, unchanged from 0000950170-23-045061:notes:120]

[0000950170-23-067033:notes:121]
|  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |
| Dividends per share declared |  | $ | 1.00 |  |  | $ | 1.00 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 171 |  |  | $ | 106 |  |
| Dividend payments allocated to retained earnings |  | $ | 38 |  |  | $ | 112 |  |

[0000950170-23-067033:notes:122]
On November 21, 2023, we declared a cash dividend of $0.50 per share of common stock, payable on January 24, 2024 to holders of record as of the close of business on January 5, 2024. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0000950170-23-067033:notes:123]
[same as prior period, unchanged from 0000950170-23-045061:notes:123]

[0000950170-23-067033:notes:124]
[same as prior period, unchanged from 0000950170-23-045061:notes:124]

[0000950170-23-067033:notes:125]
|  |  | ForeignCurrencyTranslationAdjustments |  |  | DefinedBenefitObligationAdjustments |  |  | UnrealizedGains(Losses) onDerivativeInstruments |  |  | Total |  |
| Balance as of April 28, 2023 |  | $ | (48 | ) |  | $ | (3 | ) |  | $ | — |  |  | $ | (51 | ) |
| Other comprehensive income (loss), net of tax |  |  | (5 | ) |  |  | — |  |  |  | 5 |  |  |  | — |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | (4 | ) |  |  | (4 | ) |
| Total other comprehensive income (loss) |  |  | (5 | ) |  |  | — |  |  |  | 1 |  |  |  | (4 | ) |
| Balance as of October 27, 2023 |  | $ | (53 | ) |  | $ | (3 | ) |  | $ | 1 |  |  | $ | (55 | ) |

[0000950170-23-067033:notes:126]
[same as prior period, unchanged from 0000950170-23-045061:notes:126]

[0000950170-23-067033:notes:127]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | Statements ofIncome Classification |
| Realized gains on cash flow hedges |  | $ | (3 | ) |  | $ | (3 | ) |  | $ | (4 | ) |  | $ | (4 | ) |  | Net revenues |
| Total reclassifications |  | $ | (3 | ) |  | $ | (3 | ) |  | $ | (4 | ) |  | $ | (4 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-23-067033:notes:128]
[same as prior period, unchanged from 0000950170-23-045061:notes:128]

[0000950170-23-067033:notes:129]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of October 27, 2023 or April 28, 2023. All contracts have a maturity of less than 12 months.

[0000950170-23-067033:notes:130]
[same as prior period, unchanged from 0000950170-23-045061:notes:130]

[0000950170-23-067033:notes:131]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 132 |  |  | $ | 95 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 745 |  |  | $ | 965 |  |
| Forward contracts purchased |  | $ | 46 |  |  | $ | 96 |  |

[0000950170-23-067033:notes:132]
[same as prior period, unchanged from 0000950170-23-045061:notes:132]

[0000950170-23-067033:notes:133]
[same as prior period, unchanged from 0000950170-23-045061:notes:133]

[0000950170-23-067033:notes:134]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | October 27, 2023 |  |  | October 28, 2022 |  |
| Foreign currency exchange contracts |  | $ | (45 | ) |  | $ | (34 | ) |  | $ | (49 | ) |  | $ | (55 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-23-067033:notes:135]
[same as prior period, unchanged from 0000950170-23-045061:notes:135]

[0000950170-23-067033:notes:136]
In the first six months of fiscal 2024, we executed a restructuring plan to redirect resources to highest return activities, and to optimize our global office space for our hybrid work model. In connection with the plan, we reduced our global workforce by approximately 1% and terminated certain real estate leases in various countries, resulting in restructuring charges comprised primarily of employee severance-related expenses and lease termination charges. The workforce related activities under the plan are substantially complete.

[0000950170-23-067033:notes:137]
In the first six months of fiscal 2023, we executed, or continued to execute, restructuring plans to redirect resources to highest return activities and to establish our international headquarters in Cork, Ireland, which included a reduction in our global workforce of less than 1% and resulted in restructuring charges comprised primarily of employee severance-related costs and legal and tax-related professional fees. Substantially all activities under these plans were complete as of the end of fiscal 2023.

[0000950170-23-067033:notes:138]
[same as prior period, unchanged from 0000950170-23-045061:notes:138]

[0000950170-23-067033:notes:139]
|  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |
| Balance at beginning of period |  | $ | 36 |  |  | $ | 1 |  |
| Net charges |  |  | 31 |  |  |  | 22 |  |
| Cash payments |  |  | (46 | ) |  |  | (14 | ) |
| Balance at end of period |  | $ | 21 |  |  | $ | 9 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-067033:notes:140]
[same as prior period, unchanged from 0000950170-23-045061:notes:140]

[0000950170-23-067033:notes:141]
[same as prior period, unchanged from 0000950170-23-045061:notes:141]

[0000950170-23-067033:notes:142]
|  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |
| Effective tax rates |  |  | 23.8 | % |  |  | (67.7 | )% |

[0000950170-23-067033:notes:143]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. Our effective tax rate for the six months ended October 27, 2023 includes benefits for fiscal 2023 foreign tax credits resulting from Internal Revenue Service Notice 2023-55, partially offset by an increase in stock compensation for which no tax benefit is currently recorded as compared to the prior period. The effective tax rate for the six months ended October 28, 2022 was primarily driven by a discrete tax benefit of $524 million that resulted from an intra-entity asset transfer of certain intellectual property (“IP”).

[0000950170-23-067033:notes:144]
During the second quarter of fiscal 2023, we completed an intra-entity asset transfer of certain IP to our international headquarters (the “IP Transfer”). The transaction resulted in a step-up of tax-deductible basis in the transferred assets, and accordingly, created a temporary difference where the tax basis exceeded the financial statement basis of such intangible assets, which resulted in the recognition of a discrete tax benefit and related deferred tax asset of $524 million during the second quarter of fiscal 2023. Management applied significant judgment when determining the fair value of the IP, which serves as the tax basis of the deferred tax asset. With the assistance of third-party valuation specialists, the fair value of the IP was determined principally based on the present value of projected cash flows related to the IP which reflects management’s assumptions regarding projected revenues, expenses and a discount rate. The tax-deductible amortization related to the transferred IP rights will be recognized in future periods and any amortization that is unused in a particular year can be carried forward indefinitely. The deferred tax asset and the tax benefit were measured based on the enacted tax rates expected to apply in the years the asset is expected to be realized. We expect to realize the deferred tax asset resulting from the IP Transfer and will assess the realizability of the deferred tax asset quarterly. Any Organisation for Economic Co-operation and Development’s (“OECD”) actions adopted internationally, could impact our financial results in future periods.

[0000950170-23-067033:notes:145]
[same as prior period, unchanged from 0000950170-23-045061:notes:144]

[0000950170-23-067033:notes:146]
[same as prior period, unchanged from 0000950170-23-045061:notes:145]

[0000950170-23-067033:notes:147]
As of October 27, 2023, we had $223 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $149 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $148 million have been recorded in other long-term liabilities.


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-067033:notes:148]
[same as prior period, unchanged from 0000950170-23-045061:notes:147]

[0000950170-23-067033:notes:149]
[same as prior period, unchanged from 0000950170-23-045061:notes:148]

[0000950170-23-067033:notes:150]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | October 27, 2023 |  |  | October 28, 2022 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 233 |  |  | $ | 750 |  |  | $ | 382 |  |  | $ | 964 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 208 |  |  |  | 217 |  |  |  | 210 |  |  |  | 219 |  |
| Dilutive impact of employee equity award plans |  |  | 3 |  |  |  | 3 |  |  |  | 4 |  |  |  | 3 |  |
| Shares used in diluted computation |  |  | 211 |  |  |  | 220 |  |  |  | 214 |  |  |  | 222 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.12 |  |  | $ | 3.46 |  |  | $ | 1.82 |  |  | $ | 4.40 |  |
| Diluted |  | $ | 1.10 |  |  | $ | 3.41 |  |  | $ | 1.79 |  |  | $ | 4.34 |  |

[0000950170-23-067033:notes:151]
Three million and four million shares from outstanding employee awards were excluded from the diluted net income per share calculation for the three and six months ended October 27, 2023, respectively, while six million and five million shares from outstanding employee awards each were excluded from the diluted net income per share calculation for the three and six months ended October 28, 2022, respectively, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-067033:notes:152]
[same as prior period, unchanged from 0000950170-23-045061:notes:151]

[0000950170-23-067033:notes:153]
[same as prior period, unchanged from 0000950170-23-045061:notes:152]

[0000950170-23-067033:notes:154]
[same as prior period, unchanged from 0000950170-23-045061:notes:153]

[0000950170-23-067033:notes:155]
[same as prior period, unchanged from 0000950170-23-045061:notes:154]

[0000950170-23-067033:notes:156]
[same as prior period, unchanged from 0000950170-23-045061:notes:155]

[0000950170-23-067033:notes:157]
[same as prior period, unchanged from 0000950170-23-045061:notes:156]

[0000950170-23-067033:notes:158]
|  | Three Months Ended October 27, 2023 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 706 |  |  | $ | — |  |  | $ | 706 |  |
| Support revenues |  | 623 |  |  |  | — |  |  |  | 623 |  |
| Professional and other services revenues |  | 79 |  |  |  | — |  |  |  | 79 |  |
| Public cloud revenues |  | — |  |  |  | 154 |  |  |  | 154 |  |
| Net revenues |  | 1,408 |  |  |  | 154 |  |  |  | 1,562 |  |
| Cost of product revenues |  | 275 |  |  |  | — |  |  |  | 275 |  |
| Cost of support revenues |  | 50 |  |  |  | — |  |  |  | 50 |  |
| Cost of professional and other services revenues |  | 60 |  |  |  | — |  |  |  | 60 |  |
| Cost of public cloud revenues |  | — |  |  |  | 52 |  |  |  | 52 |  |
| Segment cost of revenues |  | 385 |  |  |  | 52 |  |  |  | 437 |  |
| Segment gross profit | $ | 1,023 |  |  | $ | 102 |  |  | $ | 1,125 |  |
| Segment gross margin |  | 72.7 | % |  |  | 66.2 | % |  |  | 72.0 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 15 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,110 |  |
| Total gross margin |  |  |  |  |  |  |  | 71.1 | % |
| 1 Unallocated cost of revenues are composed of $7 million of stock-based compensation expense and $8 million of amortization of intangible assets. |  |

[0000950170-23-067033:notes:159]
|  | Three Months Ended October 28, 2022 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 837 |  |  | $ | — |  |  | $ | 837 |  |
| Support revenues |  | 607 |  |  |  | — |  |  |  | 607 |  |
| Professional and other services revenues |  | 77 |  |  |  | — |  |  |  | 77 |  |
| Public cloud revenues |  | — |  |  |  | 142 |  |  |  | 142 |  |
| Net revenues |  | 1,521 |  |  |  | 142 |  |  |  | 1,663 |  |
| Cost of product revenues |  | 417 |  |  |  | — |  |  |  | 417 |  |
| Cost of support revenues |  | 45 |  |  |  | — |  |  |  | 45 |  |
| Cost of professional and other services revenues |  | 54 |  |  |  | — |  |  |  | 54 |  |
| Cost of public cloud revenues |  | — |  |  |  | 45 |  |  |  | 45 |  |
| Segment cost of revenues |  | 516 |  |  |  | 45 |  |  |  | 561 |  |
| Segment gross profit | $ | 1,005 |  |  | $ | 97 |  |  | $ | 1,102 |  |
| Segment gross margin |  | 66.1 | % |  |  | 68.3 | % |  |  | 66.3 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 15 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,087 |  |
| Total gross margin |  |  |  |  |  |  |  | 65.4 | % |
| 1 Unallocated cost of revenues are composed of $5 million of stock-based compensation expense and $10 million of amortization of intangible assets. |  |

[0000950170-23-067033:notes:160]
|  | Six Months Ended October 27, 2023 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 1,296 |  |  | $ | — |  |  | $ | 1,296 |  |
| Support revenues |  | 1,234 |  |  |  | — |  |  |  | 1,234 |  |
| Professional and other services revenues |  | 156 |  |  |  | — |  |  |  | 156 |  |
| Public cloud revenues |  | — |  |  |  | 308 |  |  |  | 308 |  |
| Net revenues |  | 2,686 |  |  |  | 308 |  |  |  | 2,994 |  |
| Cost of product revenues |  | 539 |  |  |  | — |  |  |  | 539 |  |
| Cost of support revenues |  | 97 |  |  |  | — |  |  |  | 97 |  |
| Cost of professional and other services revenues |  | 118 |  |  |  | — |  |  |  | 118 |  |
| Cost of public cloud revenues |  | — |  |  |  | 103 |  |  |  | 103 |  |
| Segment cost of revenues |  | 754 |  |  |  | 103 |  |  |  | 857 |  |
| Segment gross profit | $ | 1,932 |  |  | $ | 205 |  |  | $ | 2,137 |  |
| Segment gross margin |  | 71.9 | % |  |  | 66.6 | % |  |  | 71.4 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 31 |  |
| Total gross profit |  |  |  |  |  |  | $ | 2,106 |  |
| Total gross margin |  |  |  |  |  |  |  | 70.3 | % |
| 1 Unallocated cost of revenues are composed of $14 million of stock-based compensation expense and $17 million of amortization of intangible assets. |  |

[0000950170-23-067033:notes:161]
|  | Six Months Ended October 28, 2022 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 1,623 |  |  | $ | — |  |  | $ | 1,623 |  |
| Support revenues |  | 1,205 |  |  |  | — |  |  |  | 1,205 |  |
| Professional and other services revenues |  | 153 |  |  |  | — |  |  |  | 153 |  |
| Public cloud revenues |  | — |  |  |  | 274 |  |  |  | 274 |  |
| Net revenues |  | 2,981 |  |  |  | 274 |  |  |  | 3,255 |  |
| Cost of product revenues |  | 812 |  |  |  | — |  |  |  | 812 |  |
| Cost of support revenues |  | 88 |  |  |  | — |  |  |  | 88 |  |
| Cost of professional and other services revenues |  | 106 |  |  |  | — |  |  |  | 106 |  |
| Cost of public cloud revenues |  | — |  |  |  | 85 |  |  |  | 85 |  |
| Segment cost of revenues |  | 1,006 |  |  |  | 85 |  |  |  | 1,091 |  |
| Segment gross profit | $ | 1,975 |  |  | $ | 189 |  |  | $ | 2,164 |  |
| Segment gross margin |  | 66.3 | % |  |  | 69.0 | % |  |  | 66.5 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 31 |  |
| Total gross profit |  |  |  |  |  |  | $ | 2,133 |  |
| Total gross margin |  |  |  |  |  |  |  | 65.5 | % |
| 1 Unallocated cost of revenues are composed of $10 million of stock-based compensation expense and $21 million of amortization of intangible assets. |  |

[0000950170-23-067033:notes:162]
[same as prior period, unchanged from 0000950170-23-045061:notes:159]

[0000950170-23-067033:notes:163]
[same as prior period, unchanged from 0000950170-23-045061:notes:160]

[0000950170-23-067033:notes:164]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | October 27, 2023 |  |  | October 28, 2022 |  |
| United States, Canada and Latin America (Americas) |  | $ | 789 |  |  | $ | 845 |  |  | $ | 1,543 |  |  | $ | 1,672 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 525 |  |  |  | 565 |  |  |  | 971 |  |  |  | 1,074 |  |
| Asia Pacific (APAC) |  |  | 248 |  |  |  | 253 |  |  |  | 480 |  |  |  | 509 |  |
| Net revenues |  | $ | 1,562 |  |  | $ | 1,663 |  |  | $ | 2,994 |  |  | $ | 3,255 |  |

[0000950170-23-067033:notes:165]
Effective in the first quarter of fiscal 2024, management began evaluating revenues by geographic region based on the location to which products and services are delivered, rather than based on the location from which the customer relationship is managed. Prior year numbers have been recast to conform to the current year presentation.

[0000950170-23-067033:notes:166]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $729 million and $784 million during the three months ended October 27, 2023 and October 28, 2022, respectively, and were $1,427 million and $1,556 million during the six months ended October 27, 2023 and October 28, 2022, respectively.

[0000950170-23-067033:notes:167]
[same as prior period, unchanged from 0000950170-23-045061:notes:163]

[0000950170-23-067033:notes:168]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| U.S. |  | $ | 458 |  |  | $ | 887 |  |
| International |  |  | 2,162 |  |  |  | 2,183 |  |
| Total |  | $ | 2,620 |  |  | $ | 3,070 |  |

[0000950170-23-067033:notes:169]
[same as prior period, unchanged from 0000950170-23-045061:notes:165]

[0000950170-23-067033:notes:170]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| U.S. |  | $ | 390 |  |  | $ | 413 |  |
| International |  |  | 233 |  |  |  | 237 |  |
| Total |  | $ | 623 |  |  | $ | 650 |  |

[0000950170-23-067033:notes:171]
[same as prior period, unchanged from 0000950170-23-045061:notes:167]

[0000950170-23-067033:notes:172]
[same as prior period, unchanged from 0000950170-23-045061:notes:168]

[0000950170-23-067033:notes:173]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | October 27, 2023 |  |  | October 28, 2022 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 24 | % |  |  | 23 | % |  |  | 25 | % |
| TD Synnex Corporation (previously presented as Tech Data Corporation) |  |  | 22 | % |  |  | 20 | % |  |  | 21 | % |  |  | 20 | % |

[0000950170-23-067033:notes:174]
[same as prior period, unchanged from 0000950170-23-045061:notes:170]

[0000950170-23-067033:notes:175]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| Arrow Electronics, Inc. |  |  | 10 | % |  |  | 15 | % |
| TD Synnex Corporation (previously presented as Tech Data Corporation) |  |  | 21 | % |  |  | 19 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-067033:notes:176]
15. Commitments and Contingencies

[0000950170-23-067033:notes:177]
Purchase Orders and Other Commitments

[0000950170-23-067033:notes:178]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of October 27, 2023, we had approximately $0.4 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 27, 2023 and April 28, 2023, such liability amounted to $17 million and $15 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0000950170-23-067033:notes:179]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 27, 2023, we had approximately $0.3 billion in other purchase obligations.

[0000950170-23-067033:notes:180]
Financing Guarantees

[0000950170-23-067033:notes:181]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $27 million and $10 million of receivables during the six months ended October 27, 2023 and October 28, 2022, respectively.

[0000950170-23-067033:notes:182]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0000950170-23-067033:notes:183]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of October 27, 2023 and April 28, 2023, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-23-067033:notes:184]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 27, 2023, we have not

[0000950170-23-067033:notes:185]
been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-23-067033:notes:186]
Legal Contingencies

[0000950170-23-067033:notes:187]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0000950170-23-067033:notes:188]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0000950170-23-067033:notes:189]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of October 27, 2023 related to such matters.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000950170-23-067033:notes:190]
[same as prior period, unchanged from 0000950170-23-045061:notes:185]

[0000950170-23-067033:notes:191]
[same as prior period, unchanged from 0000950170-23-045061:notes:186]

[0000950170-23-067033:notes:192]
On September 9, 2023, The Berry Family Trust, a trust affiliated with Michael J. Berry, Chief Financial Officer of the Company, entered into a 10b5-1 trading arrangement intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) promulgated under the Exchange Act. The trading arrangement will expire on December 11, 2024, and may be terminated earlier in the limited circumstances defined in the trading arrangement. An aggregate of 75,000 shares may be sold pursuant to the trading arrangement.

[0000950170-23-067033:notes:193]
No other directors or executive officers of the Company adopted, modified or terminated any contract, instruction or written plan for the purchase or sale of the Company’s securities that was intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) or any non-Rule 10b5-1 trading arrangement, (as defined in Item 408(c) of Regulation S-K) during the quarterly period covered by this report.
