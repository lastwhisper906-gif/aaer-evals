# NTAP MD&A — 0000950170-23-067033


## mdna

[0000950170-23-067033:mdna:1]
[same as prior period, unchanged from 0000950170-23-045061:mdna:1]

[0000950170-23-067033:mdna:2]
[same as prior period, unchanged from 0000950170-23-045061:mdna:50]

[0000950170-23-067033:mdna:3]
[same as prior period, unchanged from 0000950170-23-045061:mdna:2]

[0000950170-23-067033:mdna:4]
[same as prior period, unchanged from 0000950170-23-045061:mdna:3]

[0000950170-23-067033:mdna:5]
[same as prior period, unchanged from 0000950170-23-045061:mdna:4]

[0000950170-23-067033:mdna:6]
[same as prior period, unchanged from 0000950170-23-045061:mdna:5]

[0000950170-23-067033:mdna:7]
[same as prior period, unchanged from 0000950170-23-045061:mdna:6]

[0000950170-23-067033:mdna:8]
[same as prior period, unchanged from 0000950170-23-045061:mdna:7]

[0000950170-23-067033:mdna:9]
[same as prior period, unchanged from 0000950170-23-045061:mdna:8]

[0000950170-23-067033:mdna:10]
[same as prior period, unchanged from 0000950170-23-045061:mdna:9]

[0000950170-23-067033:mdna:11]
[same as prior period, unchanged from 0000950170-23-045061:mdna:10]

[0000950170-23-067033:mdna:12]
Continuing global economic uncertainty, political conditions and fiscal challenges in the U.S. and abroad have resulted and may continue to result in adverse macroeconomic conditions, including inflation, rising interest rates, foreign exchange volatility, slower growth and possibly a recession. In particular, during the first six months of fiscal 2024, and throughout fiscal 2023, we experienced a weakened demand environment, characterized by cloud optimizations and increased budget scrutiny, which resulted in smaller deal sizes, longer selling cycles, and delays of some deals.

[0000950170-23-067033:mdna:13]
[same as prior period, unchanged from 0000950170-23-045061:mdna:12]

[0000950170-23-067033:mdna:14]
[same as prior period, unchanged from 0000950170-23-045061:mdna:13]

[0000950170-23-067033:mdna:15]
Supply chain constraints, which substantially began to impact us in the first half of fiscal 2023, led to elevated product component and freight costs during the first six months of fiscal 2023. Comparatively, in the first six months of fiscal 2024, the supply chain substantially improved, resulting in lower costs.

[0000950170-23-067033:mdna:16]
[same as prior period, unchanged from 0000950170-23-045061:mdna:15]

[0000950170-23-067033:mdna:17]
During the first six months of fiscal 2024, we repurchased approximately 9 million shares of our common stock at an average price of $75.12 per share, for an aggregate of $700 million. We also declared aggregate cash dividends of $1.00 per share in that period, for which we paid $209 million.

[0000950170-23-067033:mdna:18]
[same as prior period, unchanged from 0000950170-23-045061:mdna:17]

[0000950170-23-067033:mdna:19]
In the first six months of fiscal 2024, we executed a restructuring plan to redirect resources to highest return activities and optimize our global office space for our hybrid work model. Aggregate restructuring charges incurred under the plan during the second quarter and first six months of fiscal 2024 totaled $5 million and $31 million, respectively.

[0000950170-23-067033:mdna:20]
[same as prior period, unchanged from 0000950170-23-045061:mdna:19]

[0000950170-23-067033:mdna:21]
[same as prior period, unchanged from 0000950170-23-045061:mdna:20]

[0000950170-23-067033:mdna:22]
[same as prior period, unchanged from 0000950170-23-045061:mdna:21]

[0000950170-23-067033:mdna:23]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 45 | % |  |  | 50 | % |  |  | 43 | % |  |  | 50 | % |  |
| Services |  |  | 55 |  |  |  | 50 |  |  |  | 57 |  |  |  | 50 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 18 |  |  |  | 25 |  |  |  | 18 |  |  |  | 25 |  |  |
| Cost of services |  |  | 11 |  |  |  | 10 |  |  |  | 12 |  |  |  | 9 |  |  |
| Gross profit |  |  | 71 |  |  |  | 65 |  |  |  | 70 |  |  |  | 66 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 30 |  |  |  | 29 |  |  |  | 31 |  |  |  | 29 |  |  |
| Research and development |  |  | 17 |  |  |  | 15 |  |  |  | 17 |  |  |  | 15 |  |  |
| General and administrative |  |  | 5 |  |  |  | 4 |  |  |  | 5 |  |  |  | 4 |  |  |
| Restructuring charges |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Total operating expenses |  |  | 52 |  |  |  | 48 |  |  |  | 54 |  |  |  | 49 |  |  |
| Income from operations |  |  | 19 |  |  |  | 17 |  |  |  | 16 |  |  |  | 16 |  |  |
| Other income, net |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |
| Income before income taxes |  |  | 20 |  |  |  | 18 |  |  |  | 17 |  |  |  | 18 |  |  |
| Provision (benefit) for income taxes |  |  | 5 |  |  |  | (27 | ) |  |  | 4 |  |  |  | (12 | ) |  |
| Net income |  |  | 15 | % |  |  | 45 | % |  |  | 13 | % |  |  | 30 | % |  |

[0000950170-23-067033:mdna:24]
[same as prior period, unchanged from 0000950170-23-045061:mdna:23]

[0000950170-23-067033:mdna:25]
[same as prior period, unchanged from 0000950170-23-045061:mdna:24]

[0000950170-23-067033:mdna:26]
[same as prior period, unchanged from 0000950170-23-045061:mdna:25]

[0000950170-23-067033:mdna:27]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |
| Net revenues |  | $ | 1,562 |  |  | $ | 1,663 |  |  |  | (6 | )% |  | $ | 2,994 |  |  | $ | 3,255 |  |  |  | (8 | )% |

[0000950170-23-067033:mdna:28]
The decrease in net revenues for the second quarter and first six months of fiscal 2024 compared to the corresponding periods of fiscal 2023 was primarily due to a decrease in product revenues, partially offset by an increase in services revenues. Product revenues as a percentage of net revenues decreased by five percentage points and seven percentage points in the second quarter and first six months of fiscal 2024, respectively, compared to the corresponding periods of fiscal 2023. Fluctuations in foreign currency exchange rates favorably impacted net revenues percent change by approximately one percentage point in both the second quarter and first six months of fiscal 2024 compared to the corresponding periods of fiscal 2023.

[0000950170-23-067033:mdna:29]
[same as prior period, unchanged from 0000950170-23-045061:mdna:28]

[0000950170-23-067033:mdna:30]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |
| Product revenues |  | $ | 706 |  |  | $ | 837 |  |  |  | (16 | )% |  | $ | 1,296 |  |  | $ | 1,623 |  |  |  | (20 | )% |
| Hardware (Non-GAAP) |  |  | 308 |  |  |  | 342 |  |  |  | (10 | )% |  |  | 556 |  |  |  | 652 |  |  |  | (15 | )% |
| Software (Non-GAAP) |  |  | 398 |  |  |  | 495 |  |  |  | (20 | )% |  |  | 740 |  |  |  | 971 |  |  |  | (24 | )% |

[0000950170-23-067033:mdna:31]
[same as prior period, unchanged from 0000950170-23-045061:mdna:85]

[0000950170-23-067033:mdna:32]
[same as prior period, unchanged from 0000950170-23-045061:mdna:30]

[0000950170-23-067033:mdna:33]
Product revenues are derived through the sale of our Hybrid Cloud solutions and consist of sales of configured all-flash array systems (including All-Flash FAS and QLC-Flash FAS) and hybrid systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, StorageGrid, OEM products, NetApp HCI and add-on optional software.

[0000950170-23-067033:mdna:34]
[same as prior period, unchanged from 0000950170-23-045061:mdna:34]

[0000950170-23-067033:mdna:35]
Total product revenues decreased in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of the prior year primarily due to lower sales of all-flash array and hybrid systems as a result of softening customer demand, and despite the slightly favorable impact from foreign exchange rate fluctuations.

[0000950170-23-067033:mdna:36]
Revenues from the hardware component of product revenues represented 44% and 43% of product revenues in the second quarter and first six months of fiscal 2024, compared to 41% and 40% of product revenues in the corresponding periods of the prior year. The software component of product revenues represented 56% and 57% of product revenues in the second quarter and first six months of fiscal 2024, compared to 59% and 60% of product revenues in the corresponding periods of the prior year. The decrease in the software component percentage of product revenues in the second quarter and first six months of fiscal 2024 was primarily due to the mix of systems sold.

[0000950170-23-067033:mdna:37]
[same as prior period, unchanged from 0000950170-23-045061:mdna:37]

[0000950170-23-067033:mdna:38]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |
| Services revenues |  | $ | 856 |  |  | $ | 826 |  |  |  | 4 | % |  | $ | 1,698 |  |  | $ | 1,632 |  |  |  | 4 | % |
| Support |  |  | 623 |  |  |  | 607 |  |  |  | 3 | % |  |  | 1,234 |  |  |  | 1,205 |  |  |  | 2 | % |
| Professional and other services |  |  | 79 |  |  |  | 77 |  |  |  | 3 | % |  |  | 156 |  |  |  | 153 |  |  |  | 2 | % |
| Public cloud |  |  | 154 |  |  |  | 142 |  |  |  | 8 | % |  |  | 308 |  |  |  | 274 |  |  |  | 12 | % |

[0000950170-23-067033:mdna:39]
[same as prior period, unchanged from 0000950170-23-045061:mdna:39]

[0000950170-23-067033:mdna:40]
[same as prior period, unchanged from 0000950170-23-045061:mdna:40]

[0000950170-23-067033:mdna:41]
Support revenues increased in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of the prior year as a result of a higher aggregate support contract value for our installed base.

[0000950170-23-067033:mdna:42]
Professional and other services revenues increased slightly in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of the prior year.

[0000950170-23-067033:mdna:43]
[same as prior period, unchanged from 0000950170-23-045061:mdna:43]

[0000950170-23-067033:mdna:44]
[same as prior period, unchanged from 0000950170-23-045061:mdna:44]

[0000950170-23-067033:mdna:45]
Public Cloud revenues increased in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of the prior year primarily due to customer demand for NetApp’s diversified cloud offerings, coupled with overall growth in the cloud market.

[0000950170-23-067033:mdna:46]
[same as prior period, unchanged from 0000950170-23-045061:mdna:46]

[0000950170-23-067033:mdna:47]
[same as prior period, unchanged from 0000950170-23-045061:mdna:47]

[0000950170-23-067033:mdna:48]
[same as prior period, unchanged from 0000950170-23-045061:mdna:103]

[0000950170-23-067033:mdna:49]
[same as prior period, unchanged from 0000950170-23-045061:mdna:48]

[0000950170-23-067033:mdna:50]
[same as prior period, unchanged from 0000950170-23-045061:mdna:49]

[0000950170-23-067033:mdna:51]
[same as prior period, unchanged from 0000950170-23-045061:mdna:51]

[0000950170-23-067033:mdna:52]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |
| Cost of product revenues |  | $ | 276 |  |  | $ | 418 |  |  |  | (34 | )% |  | $ | 541 |  |  | $ | 815 |  |  |  | (34 | )% |
| Hybrid Cloud |  |  | 275 |  |  |  | 417 |  |  |  | (34 | )% |  |  | 539 |  |  |  | 812 |  |  |  | (34 | )% |
| Unallocated |  |  | 1 |  |  |  | 1 |  |  |  | — | % |  |  | 2 |  |  |  | 3 |  |  |  | (33 | )% |

[0000950170-23-067033:mdna:53]
[same as prior period, unchanged from 0000950170-23-045061:mdna:53]

[0000950170-23-067033:mdna:54]
Cost of Hybrid Cloud product revenues represented approximately 39% and 42% of product revenues for the second quarter and first six months of fiscal 2024 compared to 50% for the corresponding periods of fiscal 2023. Materials costs represented 86% and 87% of cost of Hybrid Cloud product revenues for the second quarter and first six months of fiscal 2024, compared to 95% and 94% for the corresponding periods of fiscal 2023.

[0000950170-23-067033:mdna:55]
Materials costs decreased by approximately $158 million and $292 million in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of the prior year, reflecting the decrease in product revenues and lower component and freight costs as a result of supply chain improvements.

[0000950170-23-067033:mdna:56]
Hybrid Cloud product gross margins increased by approximately eleven percentage points and eight percentage points in the second quarter and first six months of fiscal 2024, compared to the corresponding periods of the prior year, primarily due to lower component and freight costs and, to a lesser extent, the favorable impacts of fluctuations in foreign currency exchange rates on product revenues.

[0000950170-23-067033:mdna:57]
[same as prior period, unchanged from 0000950170-23-045061:mdna:57]

[0000950170-23-067033:mdna:58]
Unallocated cost of product revenues decreased in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of the prior year due to certain intangible assets becoming fully amortized during the first quarter of fiscal 2023.

[0000950170-23-067033:mdna:59]
[same as prior period, unchanged from 0000950170-23-045061:mdna:59]

[0000950170-23-067033:mdna:60]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |
| Cost of services revenues |  | $ | 176 |  |  | $ | 158 |  |  |  | 11 | % |  | $ | 347 |  |  | $ | 307 |  |  |  | 13 | % |
| Support |  |  | 50 |  |  |  | 45 |  |  |  | 11 | % |  |  | 97 |  |  |  | 88 |  |  |  | 10 | % |
| Professional and other services |  |  | 60 |  |  |  | 54 |  |  |  | 11 | % |  |  | 118 |  |  |  | 106 |  |  |  | 11 | % |
| Public cloud |  |  | 52 |  |  |  | 45 |  |  |  | 16 | % |  |  | 103 |  |  |  | 85 |  |  |  | 21 | % |
| Unallocated |  |  | 14 |  |  |  | 14 |  |  |  | — | % |  |  | 29 |  |  |  | 28 |  |  |  | 4 | % |

[0000950170-23-067033:mdna:61]
[same as prior period, unchanged from 0000950170-23-045061:mdna:61]

[0000950170-23-067033:mdna:62]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, increased in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of fiscal 2023. Cost of Hybrid Cloud services revenues represented approximately 16% and 15% of Hybrid Cloud services revenues in the second quarter and first six months of fiscal 2024, compared to 14% for the corresponding periods of fiscal 2023.

[0000950170-23-067033:mdna:63]
30

[0000950170-23-067033:mdna:64]
Hybrid Cloud support gross margins decreased by less than one percentage point in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of the prior year. Hybrid Cloud professional and other services gross margins decreased by approximately six percentage points in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of fiscal 2023, due to the mix of services provided.

[0000950170-23-067033:mdna:65]
[same as prior period, unchanged from 0000950170-23-045061:mdna:64]

[0000950170-23-067033:mdna:66]
Cost of Public Cloud revenues increased in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of fiscal 2023 reflecting the increase in Public Cloud revenues. Public Cloud gross margins decreased by two percentage points in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of fiscal 2023, primarily due to the mix of offerings provided.

[0000950170-23-067033:mdna:67]
[same as prior period, unchanged from 0000950170-23-045061:mdna:66]

[0000950170-23-067033:mdna:68]
Unallocated cost of services revenues were relatively flat in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of the prior year.

[0000950170-23-067033:mdna:69]
[same as prior period, unchanged from 0000950170-23-045061:mdna:68]

[0000950170-23-067033:mdna:70]
[same as prior period, unchanged from 0000950170-23-045061:mdna:69]

[0000950170-23-067033:mdna:71]
Sales and marketing, research and development, and general and administrative expenses for the second quarter and first six months of fiscal 2024 totaled $798 million, or 51% of net revenues, and $1,587 million, or 53% of net revenues, respectively, reflecting an increase of four percentage points and five percentage points, respectively, compared to the corresponding periods of fiscal 2023, primarily due to the decrease in net revenues.

[0000950170-23-067033:mdna:72]
[same as prior period, unchanged from 0000950170-23-045061:mdna:71]

[0000950170-23-067033:mdna:73]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses increased by $32 million, or 7%, and $50 million, or 5%, in the second quarter and first six months of fiscal 2024, respectively, compared to the corresponding periods of the prior year, primarily due to increases in stock-based compensation and incentive compensation expenses. Stock-based compensation expense in the first six months of fiscal 2024 also included incremental expense related to the reset and rollover mechanism of our employee stock purchase plan. These increases were partially offset by lower salaries expense, reflecting average headcount decreases of 9% and 6%, respectively.

[0000950170-23-067033:mdna:74]
[same as prior period, unchanged from 0000950170-23-045061:mdna:73]

[0000950170-23-067033:mdna:75]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 461 |  |  | $ | 479 |  |  |  | (4 | )% |  | $ | 929 |  |  | $ | 937 |  |  |  | (1 | )% |

[0000950170-23-067033:mdna:76]
[same as prior period, unchanged from 0000950170-23-045061:mdna:75]

[0000950170-23-067033:mdna:77]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2024 to Fiscal 2023 |  |  | Fiscal 2024 to Fiscal 2023 |  |
| Compensation costs |  |  | — |  |  |  | 1 |  |
| Commissions |  |  | (4 | ) |  |  | (2 | ) |
| Total change |  |  | (4 | ) |  |  | (1 | ) |

[0000950170-23-067033:mdna:78]
Compensation costs remained relatively flat in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of the prior year.

[0000950170-23-067033:mdna:79]
The decrease in commissions expense for the second quarter and first six months of fiscal 2024 compared to the corresponding periods of the prior year was primarily due to lower performance against sales goals.

[0000950170-23-067033:mdna:80]
31

[0000950170-23-067033:mdna:81]
[same as prior period, unchanged from 0000950170-23-045061:mdna:80]

[0000950170-23-067033:mdna:82]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |
| Research and development expenses |  | $ | 262 |  |  | $ | 243 |  |  |  | 8 | % |  | $ | 509 |  |  | $ | 483 |  |  |  | 5 | % |

[0000950170-23-067033:mdna:83]
[same as prior period, unchanged from 0000950170-23-045061:mdna:82]

[0000950170-23-067033:mdna:84]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2024 to Fiscal 2023 |  |  | Fiscal 2024 to Fiscal 2023 |  |
| Compensation costs |  |  | 9 |  |  |  | 6 |  |
| Development projects and outside services |  |  | (1 | ) |  |  | (1 | ) |
| Total change |  |  | 8 |  |  |  | 5 |  |

[0000950170-23-067033:mdna:85]
The increase in compensation costs for the second quarter and first six months of fiscal 2024 compared to the corresponding periods in the prior year was primarily attributable to higher incentive compensation expenses and stock-based compensation, partially offset by lower salaries expense, reflecting decreases in average headcount of 8% and 5%, respectively.

[0000950170-23-067033:mdna:86]
The decrease in development projects and outside services for the second quarter and first six months of fiscal 2024 compared to the corresponding periods in the prior year was primarily due to the lower spending on certain engineering projects.

[0000950170-23-067033:mdna:87]
[same as prior period, unchanged from 0000950170-23-045061:mdna:87]

[0000950170-23-067033:mdna:88]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |
| General and administrative expenses |  | $ | 75 |  |  | $ | 67 |  |  |  | 12 | % |  | $ | 149 |  |  | $ | 139 |  |  |  | 7 | % |

[0000950170-23-067033:mdna:89]
[same as prior period, unchanged from 0000950170-23-045061:mdna:89]

[0000950170-23-067033:mdna:90]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Fiscal 2024 to Fiscal 2023 |  |  | Fiscal 2024 to Fiscal 2023 |  |
| Compensation costs |  |  | 13 |  |  |  | 9 |  |
| Other |  |  | (1 | ) |  |  | (2 | ) |
| Total change |  |  | 12 |  |  |  | 7 |  |

[0000950170-23-067033:mdna:91]
The increase in compensation costs in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of the prior year was attributable to higher expenses for all components of compensation costs, but predominantly higher incentive compensation expenses.

[0000950170-23-067033:mdna:92]
[same as prior period, unchanged from 0000950170-23-045061:mdna:93]

[0000950170-23-067033:mdna:93]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |
| Restructuring charges |  | $ | 5 |  |  | $ | 11 |  |  |  | (55 | )% |  | $ | 31 |  |  | $ | 22 |  |  |  | 41 | % |

[0000950170-23-067033:mdna:94]
In the first six months of fiscal 2024, we executed a restructuring plan to redirect resources to highest return activities, and to optimize our global office space for our hybrid work model. In connection with the plan, we reduced our global workforce by approximately 1% and terminated certain real estate leases in various countries, resulting in restructuring charges comprised primarily of employee severance-related expenses and lease termination charges. The workforce related activities under the plan are substantially complete.

[0000950170-23-067033:mdna:95]
[same as prior period, unchanged from 0000950170-23-045061:mdna:96]

[0000950170-23-067033:mdna:96]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |
| Acquisition-related expense |  | $ | 3 |  |  | $ | 5 |  |  |  | (40 | )% |  | $ | 6 |  |  | $ | 15 |  |  |  | (60 | )% |

[0000950170-23-067033:mdna:97]
Acquisition-related expenses for the second quarter and first six months of fiscal 2024 totaled $3 million and $6 million, respectively, and were primarily related to our integration of previous acquisitions.

[0000950170-23-067033:mdna:98]
[same as prior period, unchanged from 0000950170-23-045061:mdna:99]

[0000950170-23-067033:mdna:99]
[same as prior period, unchanged from 0000950170-23-045061:mdna:100]

[0000950170-23-067033:mdna:100]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |
| Interest income |  | $ | 25 |  |  | $ | 14 |  |  |  | 79 | % |  | $ | 53 |  |  | $ | 21 |  |  |  | 152 | % |
| Interest expense |  |  | (15 | ) |  |  | (17 | ) |  |  | (12 | )% |  |  | (31 | ) |  |  | (35 | ) |  |  | (11 | )% |
| Other, net |  |  | 1 |  |  |  | 26 |  |  | NM |  |  |  | (3 | ) |  |  | 52 |  |  | NM |  |
| Total |  | $ | 11 |  |  | $ | 23 |  |  | NM |  |  | $ | 19 |  |  | $ | 38 |  |  | NM |  |

[0000950170-23-067033:mdna:101]
[same as prior period, unchanged from 0000950170-23-045061:mdna:102]

[0000950170-23-067033:mdna:102]
Interest income increased in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of the prior year primarily due to higher yields earned on our cash and investments. Interest expense decreased in the second quarter and first six months of fiscal 2024 compared to the corresponding periods of fiscal 2023 due to the extinguishment of certain senior notes in the second quarter of fiscal 2023.

[0000950170-23-067033:mdna:103]
In the second quarter of fiscal 2023, Other, net includes $21 million of other income for non-refundable, up-front payments from customers in Russia for support contracts, which we were not able to fulfill due to imposed sanctions and for which we have no remaining legal obligation to perform. Other, net for the first six months of fiscal 2023 also includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million. The remaining differences in Other, net for the second quarter and first six months of fiscal 2024 as compared to the corresponding periods of the prior year are partially due to foreign exchange gains and losses year-over-year.

[0000950170-23-067033:mdna:104]
[same as prior period, unchanged from 0000950170-23-045061:mdna:106]

[0000950170-23-067033:mdna:105]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |  | October 27, 2023 |  |  | October 28, 2022 |  |  | % Change |  |
| Provision (benefit) for income taxes |  | $ | 82 |  |  | $ | (445 | ) |  |  | (118 | )% |  | $ | 119 |  |  | $ | (389 | ) |  |  | (131 | )% |

[0000950170-23-067033:mdna:106]
Our effective tax rate for the three and six months ended October 27, 2023 includes benefits for increased fiscal 2023 foreign tax credits, partially offset by an increase in stock compensation for which no tax benefit is currently recorded. The effective tax rate for the three and six months ended October 28, 2022, includes a discrete tax benefit resulting from an intra-entity asset transfer of certain intellectual property (“IP”).

[0000950170-23-067033:mdna:107]
During the second quarter of fiscal 2023, we completed an intra-entity asset transfer of certain IP to our international headquarters (the “IP Transfer”). The transaction resulted in a step-up of tax-deductible basis in the transferred assets, and accordingly, created a temporary difference where the tax basis exceeded the financial statement basis of such intangible assets, which resulted in the recognition of a discrete tax benefit and related deferred tax asset of $524 million during the second quarter of fiscal 2023. Management applied significant judgment when determining the fair value of the IP, which serves as the tax basis of the deferred tax asset. With the assistance of third-party valuation specialists, the fair value of the IP was determined principally based on the present value of projected cash flows related to the IP which reflects management’s assumptions regarding projected revenues, expenses and a discount rate. The tax-deductible amortization related to the transferred IP rights will be recognized in future periods and any amortization that is unused in a particular year can be carried forward indefinitely. The deferred tax asset and the tax benefit were measured based on the enacted tax rates expected to apply in the years the asset is expected to be realized. We expect to realize the deferred tax asset resulting from the IP Transfer and will assess the realizability of the deferred tax asset quarterly. Any Organisation for Economic Co-operation and Development’s (“OECD”) actions adopted internationally, could impact our financial results in future

[0000950170-23-067033:mdna:108]
periods. The impact of the transaction to net cash provided by or used in operating, investing and financing activities on the condensed consolidated statements of cash flows during the quarter ended October 28, 2022, was not material.

[0000950170-23-067033:mdna:109]
As of October 27, 2023, we had $223 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $149 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $148 million have been recorded in other long-term liabilities.

[0000950170-23-067033:mdna:110]
[same as prior period, unchanged from 0000950170-23-045061:mdna:110]

[0000950170-23-067033:mdna:111]
| (In millions) |  | October 27, 2023 |  |  | April 28, 2023 |  |
| Cash, cash equivalents and short-term investments |  | $ | 2,620 |  |  | $ | 3,070 |  |
| Principal amount of debt |  | $ | 2,400 |  |  | $ | 2,400 |  |

[0000950170-23-067033:mdna:112]
[same as prior period, unchanged from 0000950170-23-045061:mdna:112]

[0000950170-23-067033:mdna:113]
|  |  | Six Months Ended |  |
| (In millions) |  | October 27, 2023 |  |  | October 28, 2022 |  |
| Net cash provided by operating activities |  | $ | 588 |  |  | $ | 495 |  |
| Net cash used in investing activities |  |  | (1 | ) |  |  | (916 | ) |
| Net cash used in financing activities |  |  | (942 | ) |  |  | (979 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (26 | ) |  |  | (43 | ) |
| Net change in cash, cash equivalents and restricted cash |  | $ | (381 | ) |  | $ | (1,443 | ) |

[0000950170-23-067033:mdna:114]
[same as prior period, unchanged from 0000950170-23-045061:mdna:114]

[0000950170-23-067033:mdna:115]
As of October 27, 2023, our cash, cash equivalents and short-term investments were $2.6 billion, which represents a decrease of $450 million during the first six months of fiscal 2024. The decrease was primarily due to $700 million used for the repurchase of our common stock, $209 million used for the payment of dividends and $73 million used for purchases of property and equipment, partially offset by $588 million provided by operating activities. Net working capital was $0.3 billion as of October 27, 2023, a reduction of $953 million when compared to April 28, 2023, primarily due to the decrease in cash, cash equivalents and short-term investments discussed above and the reclassification of $400 million principal amount of our senior notes from long-term to current liabilities.

[0000950170-23-067033:mdna:116]
[same as prior period, unchanged from 0000950170-23-045061:mdna:116]

[0000950170-23-067033:mdna:117]
During the first six months of fiscal 2024, we generated cash from operating activities of $588 million, reflecting net income of $382 million which was increased by non-cash depreciation and amortization expense of $128 million and non-cash stock-based compensation expense of $180 million, compared to $495 million of cash generated from operating activities during the first six months of fiscal 2023.

[0000950170-23-067033:mdna:118]
Significant changes in assets and liabilities in the first six months of fiscal 2024 included the following:

[0000950170-23-067033:mdna:119]
•
Accounts receivable decreased $185 million, reflecting lower billings and more favorable invoicing linearity in the first six months of fiscal 2024 compared to the last six months of fiscal 2023.

[0000950170-23-067033:mdna:120]
•
Deferred revenue and financed unearned services revenue decreased by $241 million, primarily due to a decrease in deferred revenue for software and hardware support contracts, reflecting the seasonality of support contract renewal activities.

[0000950170-23-067033:mdna:121]
[same as prior period, unchanged from 0000950170-23-045061:mdna:122]

[0000950170-23-067033:mdna:122]
[same as prior period, unchanged from 0000950170-23-045061:mdna:123]

[0000950170-23-067033:mdna:123]
During the first six months of fiscal 2024, we generated $72 million from maturities and sales of investments, net of purchases and paid $73 million for capital expenditures, as compared to the same period of fiscal 2023, in which we used $342 million for the purchases of investments, net of maturities and sales, and paid $142 million for capital expenditures. During the first six months of fiscal 2023, we paid approximately $491 million, net of cash acquired, for a privately-held company, and received proceeds of $59 million from the sale of one of our minority investments.

[0000950170-23-067033:mdna:124]
[same as prior period, unchanged from 0000950170-23-045061:mdna:125]

[0000950170-23-067033:mdna:125]
During the first six months of fiscal 2024, cash flows used in financing activities totaled $942 million and included $700 million for the repurchase of approximately 9 million shares of common stock and $209 million for the payment of dividends. During the first six months of fiscal 2023, cash flows used in financing activities totaled $979 million and included $500 million for the repurchase of approximately 7 million shares of common stock, $218 million for the payment of dividends and $250 million to redeem our Senior Notes due in December 2022.

[0000950170-23-067033:mdna:126]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including cash, cash equivalents and short-term investments, cash generated from operations, and our ability to access capital markets and committed credit lines will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months and thereafter for the foreseeable future. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all. For further discussion of factors that could affect our cash flows and liquidity requirements, see Item 1A. Risk Factors.

[0000950170-23-067033:mdna:127]
[same as prior period, unchanged from 0000950170-23-045061:mdna:128]

[0000950170-23-067033:mdna:128]
Our principal sources of liquidity as of October 27, 2023 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-23-067033:mdna:129]
[same as prior period, unchanged from 0000950170-23-045061:mdna:130]

[0000950170-23-067033:mdna:130]
|  |  | October 27, 2023 |  |  | April 28, 2023 |  |
| Cash and cash equivalents |  | $ | 1,934 |  |  | $ | 2,316 |  |
| Short-term investments |  |  | 686 |  |  |  | 754 |  |
| Total |  | $ | 2,620 |  |  | $ | 3,070 |  |

[0000950170-23-067033:mdna:131]
As of October 27, 2023 and April 28, 2023, $2.2 billion of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.4 billion and $0.9 billion, respectively, were available in the U.S.

[0000950170-23-067033:mdna:132]
[same as prior period, unchanged from 0000950170-23-045061:mdna:133]

[0000950170-23-067033:mdna:133]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of October 27, 2023.

[0000950170-23-067033:mdna:134]
[same as prior period, unchanged from 0000950170-23-045061:mdna:135]

[0000950170-23-067033:mdna:135]
[same as prior period, unchanged from 0000950170-23-045061:mdna:136]

[0000950170-23-067033:mdna:136]
The following table summarizes the principal amount of our Senior Notes as of October 27, 2023 (in millions):

[0000950170-23-067033:mdna:137]
|  |  | Amount |  |
| 3.30% Senior Notes Due September 2024 |  | $ | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,400 |  |

[0000950170-23-067033:mdna:138]
[same as prior period, unchanged from 0000950170-23-045061:mdna:139]

[0000950170-23-067033:mdna:139]
Commercial Paper Program and Credit Facility

[0000950170-23-067033:mdna:140]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of October 27, 2023.

[0000950170-23-067033:mdna:141]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023 primarily to replace the London Interbank Offered Rate (LIBOR) with the Secured Overnight Financing Rate (SOFR) as the basis for establishing the interest rate applicable to certain borrowings under the agreement, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of October 27, 2023, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-23-067033:mdna:142]
[same as prior period, unchanged from 0000950170-23-045061:mdna:143]

[0000950170-23-067033:mdna:143]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2024 to be between $85 million and $135 million.

[0000950170-23-067033:mdna:144]
[same as prior period, unchanged from 0000950170-23-045061:mdna:145]

[0000950170-23-067033:mdna:145]
The Tax Cuts and Jobs Act of 2017 imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits that had not previously been subject to U.S. income tax. As of October 27, 2023, outstanding payments related to the transition tax are estimated to be approximately $215 million of which $115 million and $100 million are expected to be paid during fiscal 2025 and fiscal 2026, respectively. Our estimates for future transition tax payments, however, could change with further guidance or review from U.S. federal and state tax authorities or other regulatory bodies.

[0000950170-23-067033:mdna:146]
[same as prior period, unchanged from 0000950170-23-045061:mdna:147]

[0000950170-23-067033:mdna:147]
On November 21, 2023, we declared a cash dividend of $0.50 per share of common stock, payable on January 24, 2024, to holders of record as of the close of business on January 5, 2024.

[0000950170-23-067033:mdna:148]
As of October 27, 2023, our Board of Directors had authorized the repurchase of up to $16.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through October 27, 2023, we repurchased a total of 369 million shares of our common stock at an average price of $41.75 per share, for an aggregate purchase price of $15.4 billion. As of October 27, 2023, the remaining authorized amount for stock repurchases under this program was $0.7 billion.

[0000950170-23-067033:mdna:149]
[same as prior period, unchanged from 0000950170-23-045061:mdna:150]

[0000950170-23-067033:mdna:150]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled approximately $0.7 billion at October 27, 2023.

[0000950170-23-067033:mdna:151]
[same as prior period, unchanged from 0000950170-23-045061:mdna:152]

[0000950170-23-067033:mdna:152]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $27 million and $10 million of receivables during the first six months of fiscal 2024 and fiscal 2023, respectively.

[0000950170-23-067033:mdna:153]
[same as prior period, unchanged from 0000950170-23-045061:mdna:154]

[0000950170-23-067033:mdna:154]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of October 27, 2023 and April 28, 2023, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-23-067033:mdna:155]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of October 27, 2023, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-23-067033:mdna:156]
Legal Contingencies

[0000950170-23-067033:mdna:157]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0000950170-23-067033:mdna:158]
[same as prior period, unchanged from 0000950170-23-045061:mdna:160]

[0000950170-23-067033:mdna:159]
[same as prior period, unchanged from 0000950170-23-045061:mdna:161]

[0000950170-23-067033:mdna:160]
[same as prior period, unchanged from 0000950170-23-045061:mdna:162]
