# NTAP note change history — 0001564590-15-000944 → 0001564590-15-007795


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-09-08):
[0001564590-15-007795:note_history:1]
Operating Leases
  (was, 2015-02-25, similarity 0.7442):
[0001564590-15-000944:note_history:1]
Operating Lease Commitments

- added (2015-09-08):
[0001564590-15-007795:note_history:2]
We lease various equipment, vehicles and office space in the U.S. and internationally.

- changed (2015-09-08):
[0001564590-15-007795:note_history:3]
Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $205 million as of July 31, 2015.
  (was, 2015-02-25, similarity 0.6921):
[0001564590-15-000944:note_history:3]
We lease various equipment, vehicles and office space in the U.S. and internationally. As of January 23, 2015, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $203.2 million.

- added (2015-09-08):
[0001564590-15-007795:note_history:4]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of July 31, 2015, we had $262 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 31, 2015 and April 24, 2015, such liability amounted to $16 million and $17 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

- added (2015-09-08):
[0001564590-15-007795:note_history:5]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 31, 2015, we had $45 million in construction related obligations and $178 million in other purchase obligations.

- added (2015-09-08):
[0001564590-15-007795:note_history:6]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $42 million and $52 million, respectively, of receivables during the three months ended July 31, 2015 and July 25, 2014.

- added (2015-09-08):
[0001564590-15-007795:note_history:7]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

- added (2015-09-08):
[0001564590-15-007795:note_history:8]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of July 31, 2015 and April 24, 2015, the aggregate amount by which such contingencies exceeded the associated deferred revenue was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

- added (2015-09-08):
[0001564590-15-007795:note_history:9]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 31, 2015, we have not been required to make any payments under these arrangements and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

- changed (2015-09-08):
[0001564590-15-007795:note_history:10]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of July 31, 2015 related to such matters as they are not probable and/or reasonably estimable.
  (was, 2015-02-25, similarity 0.9843):
[0001564590-15-000944:note_history:10]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of January 23, 2015 related to such matters as they are not probable and/or reasonably estimable.

- removed (2015-09-08):
[0001564590-15-000944:note_history:11]
In the ordinary course of business we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on purchased components to the extent we believe it is probable that such components will not be utilized in future operations. To the extent that product forecasts are not achieved, our commitments and associated accruals may change. As of January 23, 2015, we had $274.6 million in non-cancelable purchase commitments with our contract manufacturers and component suppliers. In addition, we recorded a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers for quantities in excess of our future demand forecasts through a charge to cost of product revenues. As of January 23, 2015 and April 25, 2014, such liability amounted to $9.4 million and $11.5 million, respectively, and is included in other current liabilities in our condensed consolidated balance sheets.

- removed (2015-09-08):
[0001564590-15-000944:note_history:12]
In addition to commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 23, 2015, we had $68.8 million in capital purchase commitments and $192.2 million in other purchase commitments.

- removed (2015-09-08):
[0001564590-15-000944:note_history:13]
Product Warranties

- removed (2015-09-08):
[0001564590-15-000944:note_history:14]
We generally provide customers a warranty on software of ninety days and a warranty on hardware of three years. The following tables summarize the activity related to product warranty liabilities and their balances as reported in our condensed consolidated balance sheets (in millions):

- removed (2015-09-08):
[0001564590-15-000944:note_history:15]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 23, 2015 |  |  | January 24, 2014 |  |  | January 23, 2015 |  |  | January 24, 2014 |  |
| Balance at beginning of period |  | $ | 96.6 |  |  | $ | 116.0 |  |  | $ | 110.0 |  |  | $ | 117.2 |  |
| Expense accrued during the period |  |  | 3.1 |  |  |  | 21.1 |  |  |  | 21.9 |  |  |  | 59.4 |  |
| Warranty costs incurred |  |  | (12.2 | ) |  |  | (20.0 | ) |  |  | (44.4 | ) |  |  | (59.5 | ) |
| Balance at end of period |  | $ | 87.5 |  |  | $ | 117.1 |  |  | $ | 87.5 |  |  | $ | 117.1 |  |

- removed (2015-09-08):
[0001564590-15-000944:note_history:16]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Other current liabilities |  | $ | 59.5 |  |  | $ | 73.0 |  |
| Other long-term liabilities |  |  | 28.0 |  |  |  | 37.0 |  |
| Total |  | $ | 87.5 |  |  | $ | 110.0 |  |

- removed (2015-09-08):
[0001564590-15-000944:note_history:17]
Some of our customers have entered into recourse and non-recourse financing leasing arrangements using third-party financing companies, and in some situations, we enter into customer financing arrangements for our products and services that are contemporaneously sold on a recourse or non-recourse basis to third-party financing companies. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Under the terms of the non-recourse leases, we do not have any continuing obligations or liabilities to the third-party financing companies. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services. As of January 23, 2015 and April 25, 2014, the aggregate amount by which such contingencies exceeded the associated deferred revenue was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2015-09-08):
[0001564590-15-007795:note_history:18]
NetApp, Inc. (we, us, or the Company) provides software, systems and services to manage and store computer data. We enable enterprises, service providers, governmental organizations, and partners to envision, deploy and evolve their information technology environments and to reduce costs and risk while driving growth and success for their organizations.

- added (2015-09-08):
[0001564590-15-007795:note_history:19]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2016, ending on April 29, 2016 is a 53-week year, with a 14th week included in its first quarter. Fiscal year 2015, which ended on April 24, 2015, was a 52-week year, with 13 weeks in its first quarter.

- changed (2015-09-08):
[0001564590-15-007795:note_history:20]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income (loss) and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2015 contained in our Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 12, 2015. The results of operations for the three months ended July 31, 2015 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.
  (was, 2015-02-25, similarity 0.9904):
[0001564590-15-000944:note_history:20]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 25, 2014 contained in our Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 17, 2014. The results of operations for the three and nine months ended January 23, 2015 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

- changed (2015-09-08):
[0001564590-15-007795:note_history:21]
There have been no significant changes in our significant accounting policies as of and for the three months ended July 31, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 24, 2015.
  (was, 2015-02-25, similarity 0.9724):
[0001564590-15-000944:note_history:21]
There have been no significant changes in our significant accounting policies as of and for the nine months ended January 23, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 25, 2014.

- removed (2015-09-08):
[0001564590-15-000944:note_history:22]
NetApp, Inc. (we, us, or the Company) is a global provider of innovative storage and data management software, systems and services. Our storage solutions help customers create the flexible, efficient and highly available IT infrastructures they need to support their organizations. We are a storage and data management provider to enterprises of all sizes, service providers, governmental organizations and original equipment manufacturers.

- removed (2015-09-08):
[0001564590-15-000944:note_history:23]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. Each quarter of fiscal 2015 and 2014 is a 13-week period.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-09-08):
[0001564590-15-007795:note_history:24]
The following table summarizes information relating to our long-term debt (in millions, except interest rates):
  (was, 2015-02-25, similarity 0.731):
[0001564590-15-000944:note_history:24]
The following table summarizes the carrying value of our long-term debt (in millions):

- changed (2015-09-08):
[0001564590-15-007795:note_history:25]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (5 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,488 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |
  (was, 2015-02-25, similarity 0.885):
[0001564590-15-000944:note_history:25]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500.0 |  |  |  | 3.54 | % |  |  | — |  |  | N/A |  |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500.0 |  |  |  |  |  |  |  | 1,000.0 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.3 | ) |  |  |  |  |  |  | (4.5 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,494.7 |  |  |  |  |  |  | $ | 995.5 |  |  |  |  |  |

- changed (2015-09-08):
[0001564590-15-007795:note_history:26]
In June 2014, we issued $500 million par value of 3.375% Senior Notes due June 15, 2021, and received proceeds of approximately $495 million, net of discount and issuance costs. Our 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $750 million and $250 million, respectively, were issued in December 2012. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any future senior unsecured indebtedness.
  (was, 2015-02-25, similarity 0.8287):
[0001564590-15-000944:note_history:26]
On June 5, 2014 we issued $500.0 million aggregate par value of 3.375% Senior Notes, with a maturity date of June 15, 2021, and received proceeds of approximately $494.7 million, net of discount and issuance costs, which will be used for general corporate purposes, including possible stock repurchases, dividends, capital expenditures, working capital and potential acquisitions and strategic transactions. Our 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $750.0 million and $250.0 million, respectively, were issued in December 2012. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any future senior unsecured indebtedness.

- changed (2015-09-08):
[0001564590-15-007795:note_history:27]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 31, 2015, we were in compliance with all covenants associated with the Senior Notes.
  (was, 2015-02-25, similarity 0.9937):
[0001564590-15-000944:note_history:27]
We may redeem the Senior Notes in whole or in part at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 23, 2015, we were in compliance with all covenants associated with the Senior Notes.

- changed (2015-09-08):
[0001564590-15-007795:note_history:28]
As of July 31, 2015, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2015-02-25, similarity 0.973):
[0001564590-15-000944:note_history:28]
As of January 23, 2015, our aggregate future principal debt maturities are as follows (in millions):

- changed (2015-09-08):
[0001564590-15-007795:note_history:29]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| Thereafter |  |  | 750 |  |
| Total |  | $ | 1,500 |  |
  (was, 2015-02-25, similarity 0.8532):
[0001564590-15-000944:note_history:29]
| Fiscal Year |  |  |  |  |  | Amount |  |
| 2018 |  |  |  |  |  | $ | 750.0 |  |
| Thereafter |  |  |  |  |  |  | 750.0 |  |
| Total |  |  |  |  |  | $ | 1,500.0 |  |

- changed (2015-09-08):
[0001564590-15-007795:note_history:30]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of July 31, 2015, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.
  (was, 2015-02-25, similarity 0.9968):
[0001564590-15-000944:note_history:30]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of January 23, 2015, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

- changed (2015-09-08):
[0001564590-15-007795:note_history:31]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 14 |  |  | $ | 16 |  |
| Less: current portion |  |  | (9 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 5 |  |  | $ | 6 |  |
  (was, 2015-02-25, similarity 0.9898):
[0001564590-15-000944:note_history:31]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Other long-term financing arrangements |  | $ | 17.6 |  |  | $ | 13.1 |  |
| Less: current portion |  |  | (9.4 | ) |  |  | (6.6 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 8.2 |  |  | $ | 6.5 |  |

- removed (2015-09-08):
[0001564590-15-000944:note_history:32]
__________________

- removed (2015-09-08):
[0001564590-15-000944:note_history:33]
N/A - Not Applicable


## us-gaap:DebtPolicyTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2015-09-08):
[0001564590-15-007795:note_history:34]
The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-09-08):
[0001564590-15-007795:note_history:35]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 14 |  |  | $ | 16 |  |
| Less: current portion |  |  | (9 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 5 |  |  | $ | 6 |  |
  (was, 2015-02-25, similarity 0.9898):
[0001564590-15-000944:note_history:35]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
| Other long-term financing arrangements |  | $ | 17.6 |  |  | $ | 13.1 |  |
| Less: current portion |  |  | (9.4 | ) |  |  | (6.6 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 8.2 |  |  | $ | 6.5 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-09-08):
[0001564590-15-007795:note_history:36]
The following table summarizes information relating to our long-term debt (in millions, except interest rates):
  (was, 2015-02-25, similarity 0.731):
[0001564590-15-000944:note_history:36]
The following table summarizes the carrying value of our long-term debt (in millions):

- changed (2015-09-08):
[0001564590-15-007795:note_history:37]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (5 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,488 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |
  (was, 2015-02-25, similarity 0.885):
[0001564590-15-000944:note_history:37]
|  |  | January 23, 2015 |  |  | April 25, 2014 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750.0 |  |  |  | 2.25 | % |  | $ | 750.0 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500.0 |  |  |  | 3.54 | % |  |  | — |  |  | N/A |  |
| 3.25% Senior Notes Due 2022 |  |  | 250.0 |  |  |  | 3.43 | % |  |  | 250.0 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500.0 |  |  |  |  |  |  |  | 1,000.0 |  |  |  |  |  |
| Less: Unamortized discount |  |  | (5.3 | ) |  |  |  |  |  |  | (4.5 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,494.7 |  |  |  |  |  |  | $ | 995.5 |  |  |  |  |  |

- removed (2015-09-08):
[0001564590-15-000944:note_history:38]
__________________

- removed (2015-09-08):
[0001564590-15-000944:note_history:39]
N/A - Not Applicable


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-09-08):
[0001564590-15-007795:note_history:40]
As of July 31, 2015, our aggregate future principal debt maturities are as follows (in millions):
  (was, 2015-02-25, similarity 0.973):
[0001564590-15-000944:note_history:40]
As of January 23, 2015, our aggregate future principal debt maturities are as follows (in millions):

- changed (2015-09-08):
[0001564590-15-007795:note_history:41]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| Thereafter |  |  | 750 |  |
| Total |  | $ | 1,500 |  |
  (was, 2015-02-25, similarity 0.8532):
[0001564590-15-000944:note_history:41]
| Fiscal Year |  |  |  |  |  | Amount |  |
| 2018 |  |  |  |  |  | $ | 750.0 |  |
| Thereafter |  |  |  |  |  |  | 750.0 |  |
| Total |  |  |  |  |  | $ | 1,500.0 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2015-09-08):
[0001564590-15-007795:note_history:42]
Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights.
  (was, 2015-02-25, similarity 0.8747):
[0001564590-15-000944:note_history:42]
Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. We defer revenue associated with these advance payments until the related refund rights expire and we perform the services.
