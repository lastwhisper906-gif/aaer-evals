# NTAP MD&A — 0001564590-15-007795


## mdna

[0001564590-15-007795:mdna:1]
[same as prior period, unchanged from 0001564590-15-000944:mdna:1]

[0001564590-15-007795:mdna:2]
[same as prior period, unchanged from 0001564590-15-000944:mdna:26]

[0001564590-15-007795:mdna:3]
[same as prior period, unchanged from 0001564590-15-000944:mdna:44]

[0001564590-15-007795:mdna:4]
[same as prior period, unchanged from 0001564590-15-000944:mdna:45]

[0001564590-15-007795:mdna:5]
[same as prior period, unchanged from 0001564590-15-000944:mdna:46]

[0001564590-15-007795:mdna:6]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Net revenues |  | $ | 1,335 |  |  | $ | 1,489 |  |
| Gross profit |  | $ | 816 |  |  | $ | 938 |  |
| Gross profit margin percentage |  |  | 61 | % |  |  | 63 | % |
| Income (loss) from operations |  | $ | (26 | ) |  | $ | 160 |  |
| Income (loss) from operations as a percentage of net revenues |  |  | (2 | )% |  |  | 11 | % |
| Net income (loss) |  | $ | (30 | ) |  | $ | 88 |  |
| Diluted net income (loss) per share |  | $ | (0.10 | ) |  | $ | 0.27 |  |
| Operating cash flows |  | $ | 129 |  |  | $ | 216 |  |

[0001564590-15-007795:mdna:7]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,066 |  |  | $ | 3,197 |  |
| Days sales outstanding (DSO) |  |  | 30 |  |  |  | 46 |  |

[0001564590-15-007795:mdna:8]
[same as prior period, unchanged from 0001564590-15-000944:mdna:49]

[0001564590-15-007795:mdna:9]
[same as prior period, unchanged from 0001564590-15-000944:mdna:50]

[0001564590-15-007795:mdna:10]
The summary of our significant accounting policies is included under Item 7 – Management’s Discussion and Analysis of Financial Condition and Results of Operations of our 2015 Form 10-K. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. There have been no material changes to the critical accounting policies and estimates as filed in such report.

[0001564590-15-007795:mdna:11]
[same as prior period, unchanged from 0001564590-15-000944:mdna:52]

[0001564590-15-007795:mdna:12]
See Note 2 – Recent Accounting Standards Not Yet Effective of the Notes to Condensed Consolidated Financial Statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on our financial statements.

[0001564590-15-007795:mdna:13]
[same as prior period, unchanged from 0001564590-15-000944:mdna:54]

[0001564590-15-007795:mdna:14]
Our fiscal year is reported on a 52- or 53-week year that ends on the last Friday in April. Fiscal year 2016, ending April 29, 2016, is a 53-week year, and the first quarter of that period spanned 14 weeks. Fiscal year 2015, ended April 24, 2015, was a 52-week year, and the first quarter of that period spanned 13 weeks. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0001564590-15-007795:mdna:15]
[same as prior period, unchanged from 0001564590-15-000944:mdna:55]

[0001564590-15-007795:mdna:16]
|  |  | Three Months Ended |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |
| Product |  |  | 50 |  | % |  | 59 |  | % |
| Software maintenance |  |  | 19 |  |  |  | 15 |  |  |
| Hardware maintenance and other services |  |  | 32 |  |  |  | 26 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 26 |  |  |  | 26 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 12 |  |  |  | 10 |  |  |
| Gross profit |  |  | 61 |  |  |  | 63 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 37 |  |  |  | 32 |  |  |
| Research and development |  |  | 18 |  |  |  | 15 |  |  |
| General and administrative |  |  | 6 |  |  |  | 5 |  |  |
| Restructuring and other charges |  | 2 |  |  |  | — |  |  |
| Total operating expenses |  |  | 63 |  |  |  | 52 |  |  |
| Income (loss) from operations |  |  | (2 | ) |  |  | 11 |  |  |
| Other income, net |  |  | — |  |  |  | — |  |  |
| Income (loss) before income taxes |  |  | (2 | ) |  |  | 11 |  |  |
| Provision for income taxes |  |  | 1 |  |  |  | 5 |  |  |
| Net income (loss) |  |  | (2 | ) | % |  | 6 |  | % |

[0001564590-15-007795:mdna:17]
[same as prior period, unchanged from 0001564590-15-000944:mdna:89]

[0001564590-15-007795:mdna:18]
[same as prior period, unchanged from 0001564590-15-000944:mdna:57]

[0001564590-15-007795:mdna:19]
[same as prior period, unchanged from 0001564590-15-000944:mdna:58]

[0001564590-15-007795:mdna:20]
Net revenues for the first quarter of fiscal 2016 were $1,335 million, a decrease of $154 million, or 10%, compared to the first quarter of fiscal 2015, reflecting a decrease in product revenues, partially offset by an increase in software maintenance revenues and hardware maintenance and other services revenues. Net revenues were negatively impacted by foreign exchange rate changes, but were favorably impacted by the 14th week in the first quarter of fiscal 2016.

[0001564590-15-007795:mdna:21]
Gross profit as a percentage of net revenues decreased 2 percentage points during the first quarter of fiscal 2016 compared to the first quarter of fiscal 2015, reflecting lower gross margins on product and hardware maintenance and other services revenues, in part due to an aggregate $11 million charge to total cost of revenues related to the impairment of a developed technology intangible asset. The gross profit margin on product revenues during the first quarter of fiscal 2016 was 7 percentage points lower than the first quarter of fiscal 2015, primarily due to unfavorable foreign exchange rate impacts, lower unit volume, unfavorable product mix and higher discounting, as well as $5 million of the aforementioned impairment charge that was allocated to cost of product revenues. The gross profit margins on software maintenance and hardware maintenance and other service revenues was relatively flat in the first quarter of fiscal 2016 compared to the first quarter of fiscal 2015 despite $6 million of the aforementioned impairment charge that was allocated to cost of hardware maintenance and other services revenues.

[0001564590-15-007795:mdna:22]
Sales and marketing, research and development, and general and administrative expenses for the first quarter of fiscal 2016 totaled $815 million, or 61% as a percentage of net revenues compared to $778 million, or 52% as a percentage of net revenues for the first quarter of fiscal 2015. The increase in expenses was primarily due to expenses associated with the extra week in the first quarter of fiscal 2016, partially offset by the favorable impact of foreign exchange rate fluctuations. In addition, such expenses as a percentage of net revenues was unfavorably impacted by lower revenues in the first quarter of fiscal 2016 compared to the first quarter of fiscal 2015.

[0001564590-15-007795:mdna:23]
[same as prior period, unchanged from 0001564590-15-000944:mdna:62]

[0001564590-15-007795:mdna:24]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  | % Change |  |
| Net revenues |  | $ | 1,335 |  |  | $ | 1,489 |  |  |  | (10 | )% |

[0001564590-15-007795:mdna:25]
The decrease in net revenues for the first quarter of fiscal 2016 was due to a decrease in product revenues of $219 million, partially offset by a $27 million increase in software maintenance revenues and a $38 million increase in hardware maintenance and other services revenues. Product revenues comprised 50% of net revenues for the first quarter of fiscal 2016, compared to 59% for the first quarter of fiscal 2015.

[0001564590-15-007795:mdna:26]
Sales through our indirect channels represented 77% of net revenues for the first quarter of fiscal 2016, compared to 76% of net revenues for the first quarter of fiscal 2015.

[0001564590-15-007795:mdna:27]
[same as prior period, unchanged from 0001564590-15-000944:mdna:67]

[0001564590-15-007795:mdna:28]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 22 | % |
| Avnet, Inc. |  |  | 18 | % |  |  | 16 | % |

[0001564590-15-007795:mdna:29]
[same as prior period, unchanged from 0001564590-15-000944:mdna:69]

[0001564590-15-007795:mdna:30]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  | % Change |  |
| Product revenues |  | $ | 664 |  |  | $ | 883 |  |  |  | (25 | )% |

[0001564590-15-007795:mdna:31]
Product revenues consist of sales of configured systems, which include bundled hardware and software products, and non-configured products, which consist primarily of add-on storage, original equipment manufacturer (OEM) products and add-on hardware and software products.

[0001564590-15-007795:mdna:32]
Total configured system revenues of $393 million decreased by $133 million, or 25%, for the first quarter of fiscal 2016, compared to the first quarter of fiscal 2015. Revenues decreased in all FAS systems platforms, and were flat for E-Series systems. Total configured systems unit volume decreased 9% primarily due to unit volume decreases in all of the FAS systems platforms, partially offset by an increase in E-Series systems. These changes in unit volume reflect the impact to our business of a storage technology industry in transition as customers drive IT transformations to take advantage of new technologies and architectures while planning their journey to the hybrid cloud. In addition, the decline in product revenues reflects the transition from products based on our older Data ONTAP 7-mode technology to products based on clustered Data ONTAP technology. Average selling prices (ASPs) decreased across all FAS and E-Series systems platforms due to foreign exchange rate headwinds and higher discounting due to competitive pressures.

[0001564590-15-007795:mdna:33]
Non-configured product revenues of $270 million decreased by $86 million, or 24%, during the first quarter of fiscal 2016, compared to the first quarter of fiscal 2015. This decrease was primarily due to a decrease of $62 million, or 40%, in add-on storage revenues, reflecting the factors described above, and a decrease of $37 million, or 33%, in OEM revenues, reflecting anticipated lower levels of this source of revenue.

[0001564590-15-007795:mdna:34]
Software Maintenance Revenues (in millions, except percentages):

[0001564590-15-007795:mdna:35]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  | % Change |  |
| Software maintenance revenues |  | $ | 248 |  |  | $ | 221 |  |  |  | 12 | % |

[0001564590-15-007795:mdna:36]
Software maintenance revenues are associated with contracts which entitle customers to receive unspecified product upgrades and enhancements on a when-and-if-available basis, bug fixes and patch releases, as well as internet and telephone access to technical support personnel located in our global support centers.

[0001564590-15-007795:mdna:37]
The fluctuations in software maintenance revenues reflect fluctuations in the aggregate contract value of the installed base under software maintenance contracts, which is recognized as revenue ratably over the terms of the underlying contracts. Software maintenance contract revenues were favorably impacted by the additional week of deferred revenue amortization in the first quarter of fiscal 2016.

[0001564590-15-007795:mdna:38]
25

[0001564590-15-007795:mdna:39]
Hardware Maintenance and Other Services Revenues (in millions, except percentages):

[0001564590-15-007795:mdna:40]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  | % Change |  |
| Hardware maintenance and other services revenues |  | $ | 423 |  |  | $ | 385 |  |  |  | 10 | % |

[0001564590-15-007795:mdna:41]
Hardware maintenance and other services revenues include hardware maintenance, professional services, and educational and training services revenues.

[0001564590-15-007795:mdna:42]
Hardware maintenance contract revenues were $346 million and $303 million for the first quarters of fiscal 2016 and 2015, respectively, reflecting an increase of $43 million, or 14%, due to an increase in the installed base and aggregate contract values under hardware maintenance contracts. In addition, hardware maintenance contract revenues were favorably impacted by the additional week of deferred revenue amortization in the first quarter of fiscal 2016 and higher levels of shorter term contract renewals from our existing contract base, resulting in a lower weighted average maintenance contract term. Professional services and educational and training services revenues aggregated to $77 million and $83 million for the first quarters of fiscal 2016 and 2015, respectively.

[0001564590-15-007795:mdna:43]
[same as prior period, unchanged from 0001564590-15-000944:mdna:86]

[0001564590-15-007795:mdna:44]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| United States, Canada and Latin America (Americas) |  |  | 56 | % |  |  | 56 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 31 | % |  |  | 30 | % |
| Asia Pacific (APAC) |  |  | 13 | % |  |  | 14 | % |

[0001564590-15-007795:mdna:45]
Percentages may not add due to rounding

[0001564590-15-007795:mdna:46]
Americas revenues consist of sales to Americas commercial and United States (U.S.) public sector markets. Our geographic revenues as a percentage of net revenues were relatively consistent in the first quarter of fiscal 2016 compared to the first quarter of 2015.

[0001564590-15-007795:mdna:47]
[same as prior period, unchanged from 0001564590-15-000944:mdna:91]

[0001564590-15-007795:mdna:48]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping our storage products, amortization of purchased intangible assets, inventory write-downs, and warranty costs, (2) cost of software maintenance, which includes the costs of providing software maintenance and third-party royalty costs and (3) cost of hardware maintenance and other services revenues, which includes costs associated with providing support activities for hardware maintenance, global support partnership programs, professional services and educational and training services.

[0001564590-15-007795:mdna:49]
[same as prior period, unchanged from 0001564590-15-000944:mdna:95]

[0001564590-15-007795:mdna:50]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  | % Change |  |
| Cost of product revenues |  | $ | 345 |  |  | $ | 394 |  |  |  | (12 | )% |

[0001564590-15-007795:mdna:51]
[same as prior period, unchanged from 0001564590-15-000944:mdna:97]

[0001564590-15-007795:mdna:52]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2016 to Fiscal 2015 |  |  |
|  |  | Percentage Change Points |  |  |
| Materials costs |  |  | (16 | ) |  |
| Excess and obsolete inventory |  |  | 3 |  |  |
| Asset impairment |  |  | 1 |  |  |
| Total change |  |  | (12 | ) |  |

[0001564590-15-007795:mdna:53]
Cost of product revenues represented 52% and 45% of product revenues for the first quarters of fiscal 2016 and 2015, respectively.

[0001564590-15-007795:mdna:54]
Materials costs represented 79% and 85% of product costs for the first quarters of fiscal 2016 and 2015, respectively.

[0001564590-15-007795:mdna:55]
Materials costs decreased $62 million in the first quarter of fiscal 2016 compared to the first quarter of fiscal 2015. Materials costs were impacted by a 9% unit volume decrease in configured systems in the first quarter of fiscal 2016 compared to the first quarter of fiscal 2015. Despite an increase in average materials costs for all FAS systems platforms, reflecting higher component costs of newer product offerings, overall materials unit costs declined due to changes in our product mix. The decrease in materials costs also reflects

[0001564590-15-007795:mdna:56]
[same as prior period, unchanged from 0001564590-15-000944:mdna:75]

[0001564590-15-007795:mdna:57]
lower materials costs on OEM and add-on storage revenues. The decrease in aggregate materials costs was partially offset by a $7 million increase in write-downs of excess and obsolete inventory in the first quarter of fiscal 2016 compared to the first quarter of 2015 and a $5 million charge to cost of product revenues related to the impairment in the first quarter of fiscal 2016 of developed technology purchased in connection with our fiscal 2013 acquisition of CacheIQ.

[0001564590-15-007795:mdna:58]
Cost of Software Maintenance Revenues (in millions, except percentages):

[0001564590-15-007795:mdna:59]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  | % Change |  |
| Cost of software maintenance revenues |  | $ | 10 |  |  | $ | 8 |  |  |  | 25 | % |

[0001564590-15-007795:mdna:60]
Cost of software maintenance revenues increased primarily due to higher third-party royalties in the first quarter of fiscal 2016 compared to the first quarter of fiscal 2015. Cost of software maintenance revenues represented 4% of software maintenance revenues for each of the first quarters of fiscal 2016 and 2015.

[0001564590-15-007795:mdna:61]
Cost of Hardware Maintenance and Other Services Revenues (in millions, except percentages):

[0001564590-15-007795:mdna:62]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues |  | $ | 164 |  |  | $ | 149 |  |  |  | 10 | % |

[0001564590-15-007795:mdna:63]
Cost of hardware maintenance and other services revenues increased during the first quarter of fiscal 2016 compared to the first quarter of fiscal 2015, due to a $10 million increase in salaries and benefits in the first quarter of fiscal 2016 compared to the first quarter of fiscal 2015 and a $6 million charge to cost of hardware maintenance and other services revenues related to the impairment in the first quarter of fiscal 2016 of developed technology discussed above.

[0001564590-15-007795:mdna:64]
[same as prior period, unchanged from 0001564590-15-000944:mdna:108]

[0001564590-15-007795:mdna:65]
[same as prior period, unchanged from 0001564590-15-000944:mdna:109]

[0001564590-15-007795:mdna:66]
[same as prior period, unchanged from 0001564590-15-000944:mdna:110]

[0001564590-15-007795:mdna:67]
Total compensation costs included in operating expenses increased $55 million, or 13%, in the first quarter of fiscal 2016 compared to the first quarter of fiscal 2015, primarily due to the additional week in the first quarter of fiscal 2016, higher stock-based compensation expense and higher incentive compensation costs reflecting stronger operating performance against goals.

[0001564590-15-007795:mdna:68]
[same as prior period, unchanged from 0001564590-15-000944:mdna:112]

[0001564590-15-007795:mdna:69]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 492 |  |  | $ | 480 |  |  |  | 3 | % |

[0001564590-15-007795:mdna:70]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, allocated facilities and information technology (IT) costs, advertising and marketing promotional expense and travel and entertainment expense. The changes in sales and marketing expenses consisted of the following:

[0001564590-15-007795:mdna:71]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2016 to Fiscal 2015 |  |  |
|  |  | Percentage Change Points |  |  |
| Compensation costs |  |  | 5 |  |  |
| Commissions |  |  | (1 | ) |  |
| Other |  |  | (1 | ) |  |
| Total change |  |  | 3 |  |  |

[0001564590-15-007795:mdna:72]
The increase in compensation costs for the first quarter of fiscal 2016, compared to the first quarter of fiscal 2015, is primarily due to higher salaries, benefits and other compensation-related costs reflecting the additional week in the first quarter of fiscal 2016 and a 2% increase in headcount, partially offset by a favorable impact from changes in foreign exchange rates. The decrease in commissions expense for the first quarter of fiscal 2016 reflects lower bookings achievement compared to the first quarter of fiscal 2015.

[0001564590-15-007795:mdna:73]
27

[0001564590-15-007795:mdna:74]
[same as prior period, unchanged from 0001564590-15-000944:mdna:117]

[0001564590-15-007795:mdna:75]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  | % Change |  |
| Research and development expenses |  | $ | 244 |  |  | $ | 228 |  |  |  | 7 | % |

[0001564590-15-007795:mdna:76]
Research and development expenses consist primarily of compensation costs, allocated facilities and IT costs, depreciation, equipment and software-related costs, prototypes, non-recurring engineering charges and other outside services costs. Changes in research and development expense consisted of the following:

[0001564590-15-007795:mdna:77]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2016 to Fiscal 2015 |  |  |
|  |  | Percentage Change Points |  |  |
| Compensation costs |  |  | 8 |  |  |
| Depreciation |  |  | (1 | ) |  |
| Total change |  |  | 7 |  |  |

[0001564590-15-007795:mdna:78]
The increase in compensation costs during the first quarter of fiscal 2016, compared to the first quarter of fiscal 2015, is primarily due to higher salaries and related benefits expenses as a result of the additional week in the first quarter of 2016. Depreciation expense decreased due to certain equipment becoming fully depreciated since the first quarter of 2015.

[0001564590-15-007795:mdna:79]
[same as prior period, unchanged from 0001564590-15-000944:mdna:123]

[0001564590-15-007795:mdna:80]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  | % Change |  |
| General and administrative expenses |  | $ | 79 |  |  | $ | 70 |  |  |  | 13 | % |

[0001564590-15-007795:mdna:81]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and allocated facilities and IT support costs. Changes in general and administrative expense consisted of the following:

[0001564590-15-007795:mdna:82]
|  |  | Three Months Ended |  |  |
|  |  | Fiscal 2016 to Fiscal 2015 |  |  |
|  |  | Percentage Change Points |  |  |
| Compensation costs |  |  | 20 |  |  |
| Professional and legal fees and outside services |  |  | (3 | ) |  |
| Facilities and IT support costs |  |  | (1 | ) |  |
| Other |  |  | (3 | ) |  |
| Total change |  |  | 13 |  |  |

[0001564590-15-007795:mdna:83]
The increase in compensation costs for the first quarter of fiscal 2016, compared to the first quarter of fiscal 2015, is primarily due to higher stock-based compensation and salaries and related benefits expenses as a result of the additional week in the first quarter of 2016. The decrease in professional and legal fees and outside services expense reflects lower spending levels on contractors and professional services.

[0001564590-15-007795:mdna:84]
[same as prior period, unchanged from 0001564590-15-000944:mdna:128]

[0001564590-15-007795:mdna:85]
|  |  | Three Months Ended |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  | % Change |
| Restructuring and other charges |  | $ | 27 |  |  |  | — |  |  | NM |

[0001564590-15-007795:mdna:86]
[same as prior period, unchanged from 0001564590-15-000944:mdna:144]

[0001564590-15-007795:mdna:87]
In May 2015, we committed to a realignment designed to drive efficiency, eliminate cost and redirect resources to highest return activities, resulting in a reduction of our global workforce of approximately 3%. The charges in the first quarter of fiscal 2016 consist primarily of employee severance related costs recognized in connection with this plan. We expect such activities to be substantially completed by the end of the second quarter of fiscal 2016, with no significant additional charges. See Note 11 – Restructuring and Other Charges of the Notes to Condensed Consolidated Financial Statements for more details regarding our restructuring plan.

[0001564590-15-007795:mdna:88]
Other Income, Net (in millions, except percentages)

[0001564590-15-007795:mdna:89]
The components of other income, net were as follows:

[0001564590-15-007795:mdna:90]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  | % Change |  |
| Interest income |  | $ | 13 |  |  | $ | 8 |  |  |  | 63 | % |
| Interest expense |  |  | (11 | ) |  |  | (9 | ) |  |  | 22 | % |
| Net gains recognized on investments |  |  | — |  |  |  | 2 |  |  |  | (100 | )% |
| Net gains (losses) on foreign currency activities |  |  | 2 |  |  |  | (1 | ) |  | NM |  |
| Total |  | $ | 4 |  |  | $ | — |  |  | NM |  |

[0001564590-15-007795:mdna:91]
NM - Not Meaningful

[0001564590-15-007795:mdna:92]
The increase in interest income during the first quarter of fiscal 2016, compared to the first quarter of fiscal 2015, was primarily due to a shift in our investment portfolio to higher-yielding investments compared to the first quarter of fiscal 2015.

[0001564590-15-007795:mdna:93]
Interest expense, which includes the amortization of debt discount and issuance costs, is primarily related to our Senior Notes.

[0001564590-15-007795:mdna:94]
[same as prior period, unchanged from 0001564590-15-000944:mdna:146]

[0001564590-15-007795:mdna:95]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  | % Change |  |
| Provision for income taxes |  | $ | 8 |  |  | $ | 72 |  |  |  | (89 | )% |

[0001564590-15-007795:mdna:96]
Our effective tax rate for the first quarter of fiscal 2016 was (36.4)% compared to an effective tax rate of 44.6% for the first quarter of fiscal 2015. Our effective tax rates reflect our corporate legal entity structure and the global nature of our business with a significant amount of our profits generated and taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The effective tax rates during the first quarters of fiscal 2016 and 2015, respectively, were favorably impacted by the geographic mix of profits. Our effective tax rates for each of the first quarters of fiscal 2016 and fiscal 2015 were also impacted by discrete provision charges related to the Internal Revenue Service (IRS) audit adjustments discussed below.

[0001564590-15-007795:mdna:97]
In June 2015, the IRS signed a closing agreement on transfer pricing arrangements for our fiscal 2008 to 2010 income tax returns. During the first quarter of fiscal 2016, we recorded a discrete expense of $13 million attributable to the transfer pricing audit adjustment and related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-15-007795:mdna:98]
In July 2014, the IRS completed the examination of our fiscal 2005 to 2007 income tax returns upon approval by the Joint Committee of Taxation. During the first quarter of fiscal 2015, we recorded a discrete expense of $47 million attributable to the audit settlement and related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-15-007795:mdna:99]
As of July 31, 2015, we had $243 million of gross unrecognized tax benefits, of which $193 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $148 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized. During the first quarter of fiscal 2016, there was an increase in our unrecognized tax benefits of $4 million for tax positions related to the current year, a gross increase of $19 million and a gross decrease, including statute lapses, of $5 million for tax positions related to prior years. We also recorded a gross decrease of $47 million related to settlements with taxing authorities during the period.

[0001564590-15-007795:mdna:100]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. Given the uncertainties involved in all tax audits, we estimate a potential decrease in our unrecognized tax benefit balance of up to $47 million may occur within the next 12 months associated with the potential settlements and statute lapses.

[0001564590-15-007795:mdna:101]
[same as prior period, unchanged from 0001564590-15-000944:mdna:155]

[0001564590-15-007795:mdna:102]
| (In millions, except percentages) |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Cash and cash equivalents and short-term investments |  | $ | 4,950 |  |  | $ | 5,326 |  |
| Principal amount of Senior Notes |  |  | 1,500 |  |  |  | 1,500 |  |
| Debt as a % of stockholders' equity |  |  | 50 | % |  |  | 44 | % |

[0001564590-15-007795:mdna:103]
[same as prior period, unchanged from 0001564590-15-000944:mdna:157]

[0001564590-15-007795:mdna:104]
|  |  | Three Months Ended |  |
| (In millions) |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Net cash provided by operating activities |  | $ | 129 |  |  | $ | 216 |  |
| Net cash provided by investing activities |  |  | 742 |  |  |  | 133 |  |
| Net cash provided by (used in) financing activities |  |  | (464 | ) |  |  | 392 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (5 | ) |  |  | — |  |
| Net increase in cash and cash equivalents |  | $ | 402 |  |  | $ | 741 |  |

[0001564590-15-007795:mdna:105]
[same as prior period, unchanged from 0001564590-15-000944:mdna:159]

[0001564590-15-007795:mdna:106]
As of July 31, 2015, our cash, cash equivalents and short-term investments were $5.0 billion, a decrease of $0.4 billion from April 24, 2015. The decrease was primarily due to $430 million in cash paid for the repurchase of our common stock, partially offset by $129 million of cash provided by operating activities. Accounts receivable DSO decreased to 30 days for the first quarter of fiscal 2016 compared to 46 days for the fourth quarter of fiscal 2015 and 36 for the first quarter of fiscal 2015, reflecting improvements in shipment linearity and an extra week of collections in the first quarter of fiscal 2016. Working capital decreased by $425 million to $3.6 billion as of July 31, 2015 primarily as a result of decreases in accounts receivable and cash, cash equivalents and short-term investments, partially offset by lower accrued compensation and short-term deferred revenue and financed unearned services revenue.

[0001564590-15-007795:mdna:107]
[same as prior period, unchanged from 0001564590-15-000944:mdna:161]

[0001564590-15-007795:mdna:108]
During the first quarter of fiscal 2016, we generated cash from operating activities of $129 million, reflecting a net loss of $30 million, offset by adjustments of non-cash depreciation and amortization of $69 million and stock-based compensation of $77 million.

[0001564590-15-007795:mdna:109]
Changes in assets and liabilities during the first quarter of fiscal 2016 included the following:

[0001564590-15-007795:mdna:110]
|  | · | Accounts receivable decreased $361 million, primarily due to lower seasonal invoicing levels in the first quarter of fiscal 2016 compared to the fourth quarter in fiscal 2015. |

[0001564590-15-007795:mdna:111]
|  | · | Accrued compensation decreased $101 million, primarily due to employee compensation payouts related to fiscal year 2015 commissions and incentive compensation plans. |

[0001564590-15-007795:mdna:112]
[same as prior period, unchanged from 0001564590-15-000944:mdna:166]

[0001564590-15-007795:mdna:113]
[same as prior period, unchanged from 0001564590-15-000944:mdna:167]

[0001564590-15-007795:mdna:114]
During the first quarter of fiscal 2016, we generated $778 million from maturities and sales of investments, net of purchases, and paid $38 million for capital expenditures, compared to $191 million and $58 million, respectively, in the first quarter of fiscal 2015.

[0001564590-15-007795:mdna:115]
[same as prior period, unchanged from 0001564590-15-000944:mdna:169]

[0001564590-15-007795:mdna:116]
During the first quarter of fiscal 2016, we used $430 million for the repurchase of 13 million shares of our common stock and $54 million for the payment of dividends, compared to $119 million used for the repurchase of common stock and $53 million for the payment of dividends in the first quarter of fiscal 2015.

[0001564590-15-007795:mdna:117]
[same as prior period, unchanged from 0001564590-15-000944:mdna:171]

[0001564590-15-007795:mdna:118]
[same as prior period, unchanged from 0001564590-15-000944:mdna:131]

[0001564590-15-007795:mdna:119]
[same as prior period, unchanged from 0001564590-15-000944:mdna:172]

[0001564590-15-007795:mdna:120]
Our principal sources of liquidity as of July 31, 2015 consisted of cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001564590-15-007795:mdna:121]
Cash, cash equivalents and short-term investments consisted of the following (in millions):

[0001564590-15-007795:mdna:122]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Cash and cash equivalents |  | $ | 2,324 |  |  | $ | 1,922 |  |
| Short-term investments |  |  | 2,626 |  |  |  | 3,404 |  |
| Total |  | $ | 4,950 |  |  | $ | 5,326 |  |

[0001564590-15-007795:mdna:123]
As of July 31, 2015 and April 24, 2015, $4.6 billion and $4.7 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.4 billion and $0.6 billion, respectively, were available in the U.S. Most of the amounts held outside the U.S. can be repatriated to the U.S. but, under current law, would be subject to U.S. federal, state income and foreign withholding taxes. If we were to repatriate foreign earnings to fund cash requirements in the U.S., we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state tax credit carryforwards. However, our intent is to keep these funds permanently reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, and invest in critical or complementary technologies, and service interest and principal payments on our debt.

[0001564590-15-007795:mdna:124]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of July 31, 2015.

[0001564590-15-007795:mdna:125]
[same as prior period, unchanged from 0001564590-15-000944:mdna:179]

[0001564590-15-007795:mdna:126]
[same as prior period, unchanged from 0001564590-15-000944:mdna:180]

[0001564590-15-007795:mdna:127]
The following table summarizes the principal amount of our Senior Notes as of July 31, 2015 (in millions):

[0001564590-15-007795:mdna:128]
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |
| Total |  | $ | 1,500 |  |

[0001564590-15-007795:mdna:129]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 8 – Financing Arrangements of the Notes to Condensed Consolidated Financial Statements.

[0001564590-15-007795:mdna:130]
Credit Facility

[0001564590-15-007795:mdna:131]
Our credit facility, under which we may borrow up to $250 million, provides another potential source of liquidity. The credit facility is an unsecured five-year revolving credit facility that terminates on December 21, 2017 if no extensions have been requested at that time, and contains financial covenants requiring us to maintain a maximum leverage ratio and a minimum interest coverage ratio. We may also, subject to certain requirements, request an increase in the facility up to an additional $100 million and request two additional one-year extensions, subject to certain conditions. As of July 31, 2015, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-15-007795:mdna:132]
[same as prior period, unchanged from 0001564590-15-000944:mdna:186]

[0001564590-15-007795:mdna:133]
[same as prior period, unchanged from 0001564590-15-000944:mdna:149]

[0001564590-15-007795:mdna:134]
[same as prior period, unchanged from 0001564590-15-000944:mdna:187]

[0001564590-15-007795:mdna:135]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2016 to be between $150 million and $200 million.

[0001564590-15-007795:mdna:136]
[same as prior period, unchanged from 0001564590-15-000944:mdna:189]

[0001564590-15-007795:mdna:137]
On August 19, 2015, we declared a cash dividend of $0.18 per share of common stock, payable on October 21, 2015 to holders of record as of the close of business on October 9, 2015.

[0001564590-15-007795:mdna:138]
As of July 31, 2015, our Board of Directors had authorized the repurchase of up to $9.6 billion of our common stock under our stock repurchase program. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through July 31, 2015, we repurchased a total of 227 million shares of our common stock at an average price of $33.42 per share, for an aggregate purchase price of $7.6 billion. As of July 31, 2015, the remaining authorized amount for stock repurchases under this program was $2.0 billion, with no termination date, which we plan to complete by May 2018, with the first $1 billion expected to be purchased by the end of May 2016.

[0001564590-15-007795:mdna:139]
[same as prior period, unchanged from 0001564590-15-000944:mdna:193]

[0001564590-15-007795:mdna:140]
[same as prior period, unchanged from 0001564590-15-000944:mdna:194]

[0001564590-15-007795:mdna:141]
[same as prior period, unchanged from 0001564590-15-000944:mdna:195]

[0001564590-15-007795:mdna:142]
As of July 31, 2015, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $205 million.

[0001564590-15-007795:mdna:143]
[same as prior period, unchanged from 0001564590-15-000944:mdna:197]

[0001564590-15-007795:mdna:144]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of July 31, 2015, we had $262 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 31, 2015 and April 24, 2015, such liability amounted to $16 million and $17 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-15-007795:mdna:145]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of July 31, 2015, we had $45 million in construction related obligations and $178 million in other purchase obligations.

[0001564590-15-007795:mdna:146]
[same as prior period, unchanged from 0001564590-15-000944:mdna:200]

[0001564590-15-007795:mdna:147]
As of July 31, 2015, our liability for uncertain tax positions was $180 million, including interest, penalties and offsetting indirect benefits. Due to the uncertainty of the timing of future cash payments, we cannot make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-15-007795:mdna:148]
Legal Contingencies

[0001564590-15-007795:mdna:149]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0001564590-15-007795:mdna:150]
Financing Guarantees

[0001564590-15-007795:mdna:151]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these

[0001564590-15-007795:mdna:152]
32

[0001564590-15-007795:mdna:153]
financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $42 million and $52 million, respectively, of receivables during the first quarters of fiscal 2016 and 2015.

[0001564590-15-007795:mdna:154]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-15-007795:mdna:155]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of July 31, 2015 and April 24, 2015, the aggregate amount by which such contingencies exceeded the associated deferred revenue was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001564590-15-007795:mdna:156]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of July 31, 2015, we have not been required to make any payments under these arrangements and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-15-007795:mdna:157]
[same as prior period, unchanged from 0001564590-15-000944:mdna:207]

[0001564590-15-007795:mdna:158]
[same as prior period, unchanged from 0001564590-15-000944:mdna:177]
