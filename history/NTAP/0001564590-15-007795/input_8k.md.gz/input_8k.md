# NTAP 8-K — 0001102624-15-001340 filed 2015-08-19

## item codes, every 8-K on or before 2015-09-08

- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2015-09-08

- none on or before 2015-09-08

## item 2.02 — earnings release, exhibit 99.1

[0001102624-15-001340:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-15-001340:8k_2_02:2]
exh99_1.htm

[0001102624-15-001340:8k_2_02:3]
Exhibit 99.1

[0001102624-15-001340:8k_2_02:4]
| Press Contact: | Investor Contact: |
| Meghan Fintland | Kris Newton |
| NetApp | NetApp |
| 1 408 822 1389 | 1 408 822 3312 |
| meghan.fintland@netapp.com | kris.newton@netapp.com |

[0001102624-15-001340:8k_2_02:5]
NETAPP REPORTS FIRST QUARTER OF FISCAL YEAR 2016 RESULTS

[0001102624-15-001340:8k_2_02:6]
Net Revenues of $1.34 Billion for the First Quarter

[0001102624-15-001340:8k_2_02:7]
| · | NetApp® clustered Data ONTAP® node shipments increased 114% year-over-year; 13th consecutive quarter of triple-digit growth. |

[0001102624-15-001340:8k_2_02:8]
| · | All Flash FAS units grew 137% year-over-year; 5th consecutive quarter of triple-digit growth. |

[0001102624-15-001340:8k_2_02:9]
| · | $484 million returned to shareholders in share repurchases and cash dividends. |

[0001102624-15-001340:8k_2_02:10]
Sunnyvale, Calif.—August 19, 2015—NetApp (NASDAQ: NTAP) today reported financial results for the first quarter of fiscal year 2016, ended July 31, 2015.

[0001102624-15-001340:8k_2_02:11]
First Quarter Financial Results

[0001102624-15-001340:8k_2_02:12]
Net revenues for the first quarter of fiscal year 2016 were $1.34 billion. GAAP net loss for the first quarter of fiscal year 2016 was $30 million, or $0.10 per share,1 compared to GAAP net income of $88 million, or $0.27 per share,2 for the comparable period of the prior year. Non-GAAP net income for the first quarter of fiscal year 2016 was $89 million, or $0.29 per share,3 compared to non-GAAP net income of $198 million, or $0.60 per share, for the comparable period of the prior year.

[0001102624-15-001340:8k_2_02:13]
Cash, Cash Equivalents and Investments

[0001102624-15-001340:8k_2_02:14]
NetApp ended the first quarter of fiscal year 2016 with $5.0 billion in total cash, cash equivalents and investments and generated $129 million in cash from operations. During the first quarter of fiscal year 2016, the Company returned $484 million to shareholders through share repurchases and a cash dividend.

[0001102624-15-001340:8k_2_02:15]
The next dividend in the amount of $0.18 per share will be paid on October 21, 2015, to shareholders of record as of the close of business on October 9, 2015.

[0001102624-15-001340:8k_2_02:16]
“The IT industry as a whole is going through fundamental change as enterprises transform themselves with digital capabilities. Data is at the heart of these transformations and where NetApp has a profoundly important role to play with our differentiated vision for data management,” said George Kurian, CEO. “Our first fiscal quarter marks the beginning of a new chapter for NetApp. In the next phase of our journey, we are pivoting to better address the changing industry, to improving our own execution and to enhancing value for our shareholders.”

[0001102624-15-001340:8k_2_02:17]
Q2 Fiscal Year 2016 Outlook

[0001102624-15-001340:8k_2_02:18]
The Company provided the following financial guidance for the second quarter of fiscal year 2016:

[0001102624-15-001340:8k_2_02:19]
| · | Net revenues are expected to be in the range of $1.40 billion to $1.50 billion. |

[0001102624-15-001340:8k_2_02:20]
| · | GAAP earnings per share is expected to be in the range of $0.35 to $0.40 per share. |

[0001102624-15-001340:8k_2_02:21]
| · | Non-GAAP earnings per share is expected to be in the range of $0.55 to $0.60 per share. |

[0001102624-15-001340:8k_2_02:22]
Business Highlights

[0001102624-15-001340:8k_2_02:23]
| · | NetApp Expands All Flash FAS Solutions to Support Seamless Data Movement from Flash to Disk to Cloud: |

[0001102624-15-001340:8k_2_02:24]
|  | - | Delivers Most Complete All Flash Offering for the Enterprise. With the NetApp All Flash FAS8000 series, customers benefit from built-in data protection, multiprotocol support, scale-out performance, and seamless data movement from flash to disk to cloud. Other features include quality of service, multi-tenancy and NetApp’s best-in-class application integration for simplified configuration and management of SQL and Oracle databases, virtualized servers and VDI workloads. |

[0001102624-15-001340:8k_2_02:25]
|  | - | Flash Essentials Innovations. The All Flash FAS products incorporate software optimizations derived from the NetApp advanced technology development lab. These innovations include a flash-optimized read data path, inline compression, and zero-based inline deduplication. Flash Essentials innovations are included in clustered Data ONTAP. |

[0001102624-15-001340:8k_2_02:26]
|  | - | NetApp OnCommand® Performance Manager 2.0. The new software release gives users a comprehensive dashboard to evaluate All Flash FAS performance automatically and troubleshoot issues to maintain optimal system operation. |

[0001102624-15-001340:8k_2_02:27]
| · | NetApp Expands Solutions and Services in Support of Hybrid Cloud Strategy: |

[0001102624-15-001340:8k_2_02:28]
|  | - | The New AltaVault™ Solutions and Services Help Customers Unlock Cloud Economics. NetApp AltaVault, cloud-integrated storage solutions and services, provides customers with the ability to backup data quickly to any cloud at up to 90% less cost than on-premises solutions. AltaVault supports NetApp’s vision for hybrid cloud data management, which gives customers the confidence that, no matter where their data lives, they can control, integrate, move, secure and consistently manage it. |

[0001102624-15-001340:8k_2_02:29]
Webcast and Conference Call Information

[0001102624-15-001340:8k_2_02:30]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4:00 p.m. Pacific Time today.

[0001102624-15-001340:8k_2_02:31]
About NetApp

[0001102624-15-001340:8k_2_02:32]
Leading organizations worldwide count on NetApp for software, systems and services to manage and store their data. Customers value our teamwork, expertise and passion for helping them succeed now and into the future.

[0001102624-15-001340:8k_2_02:33]
###

[0001102624-15-001340:8k_2_02:34]
NetApp, the NetApp logo, AltaVault, Data ONTAP and OnCommand are trademarks or registered trademarks of NetApp, Inc. in the United States and/or other countries. All other marks are the property of their respective owners.

[0001102624-15-001340:8k_2_02:35]
1GAAP net loss per share is calculated using the basic number of shares and excludes common stock equivalents because the impact would be anti-dilutive.

[0001102624-15-001340:8k_2_02:36]
2GAAP net income per share is calculated using the diluted number of shares.

[0001102624-15-001340:8k_2_02:37]
3Non-GAAP net income excludes, when applicable, the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-reoccurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) the impact of a temporary lapse of tax law, such as the federal research credit, if such extensions have routinely been granted based on past legislative history and are expected to be reinstated in the near future. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com.

[0001102624-15-001340:8k_2_02:38]
NetApp Usage of Non-GAAP Financials

[0001102624-15-001340:8k_2_02:39]
The Company refers to the non-GAAP financial measures in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes, when applicable, the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-reoccurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) the impact of a temporary lapse of tax law, such as the federal research credit, if such extensions have routinely been granted based on past legislative history and are expected to be reinstated in the near future. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods.

[0001102624-15-001340:8k_2_02:40]
We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has limitations and they should not solely be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we provide non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-15-001340:8k_2_02:41]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation.

[0001102624-15-001340:8k_2_02:42]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,950 |  |  | $ | 5,326 |  |
| Accounts receivable |  |  | 415 |  |  |  | 779 |  |
| Inventories |  |  | 193 |  |  |  | 146 |  |
| Other current assets |  |  | 561 |  |  |  | 522 |  |
| Total current assets |  |  | 6,119 |  |  |  | 6,773 |  |
| Property and equipment, net |  |  | 1,011 |  |  |  | 1,030 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,091 |  |  |  | 1,117 |  |
| Other non-current assets |  |  | 476 |  |  |  | 481 |  |
| Total assets |  | $ | 8,697 |  |  | $ | 9,401 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 249 |  |  | $ | 284 |  |
| Accrued expenses |  |  | 592 |  |  |  | 701 |  |
| Short-term deferred revenue |  |  | 1,639 |  |  |  | 1,724 |  |
| Total current liabilities |  |  | 2,480 |  |  |  | 2,709 |  |
| Long-term debt |  |  | 1,488 |  |  |  | 1,487 |  |
| Other long-term liabilities |  |  | 302 |  |  |  | 318 |  |
| Long-term deferred revenue |  |  | 1,427 |  |  |  | 1,473 |  |
| Total liabilities |  |  | 5,697 |  |  |  | 5,987 |  |
| Stockholders' equity |  |  | 3,000 |  |  |  | 3,414 |  |
| Total liabilities and stockholders' equity |  | $ | 8,697 |  |  | $ | 9,401 |  |

[0001102624-15-001340:8k_2_02:43]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Revenues: |  |  |  |  |  |  |
| Product |  | $ | 664 |  |  | $ | 883 |  |
| Software maintenance |  |  | 248 |  |  |  | 221 |  |
| Hardware maintenance and other services |  |  | 423 |  |  |  | 385 |  |
| Net revenues |  |  | 1,335 |  |  |  | 1,489 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 345 |  |  |  | 394 |  |
| Cost of software maintenance |  |  | 10 |  |  |  | 8 |  |
| Cost of hardware maintenance and other services |  |  | 164 |  |  |  | 149 |  |
| Total cost of revenues |  |  | 519 |  |  |  | 551 |  |
| Gross profit |  |  | 816 |  |  |  | 938 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 492 |  |  |  | 480 |  |
| Research and development |  |  | 244 |  |  |  | 228 |  |
| General and administrative |  |  | 79 |  |  |  | 70 |  |
| Restructuring and other charges |  |  | 27 |  |  |  | - |  |
| Total operating expenses |  |  | 842 |  |  |  | 778 |  |
| Income (loss) from operations |  |  | (26 | ) |  |  | 160 |  |
| Other income, net |  |  | 4 |  |  |  | - |  |
| Income (loss) before income taxes |  |  | (22 | ) |  |  | 160 |  |
| Provision for income taxes |  |  | 8 |  |  |  | 72 |  |
| Net income (loss) |  | $ | (30 | ) |  | $ | 88 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.10 | ) |  | $ | 0.27 |  |
| Diluted |  | $ | (0.10 | ) |  | $ | 0.27 |  |
| Shares used in net income (loss) per share calculations: |  |  |  |  |  |  |  |  |
| Basic |  |  | 304 |  |  |  | 323 |  |
| Diluted |  |  | 304 |  |  |  | 329 |  |
| Cash dividends declared per share |  | $ | 0.180 |  |  | $ | 0.165 |  |

[0001102624-15-001340:8k_2_02:44]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income (loss) |  | $ | (30 | ) |  | $ | 88 |  |
| Adjustments to reconcile net income (loss) to net cash provided |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 69 |  |  |  | 78 |  |
| Stock-based compensation |  |  | 77 |  |  |  | 62 |  |
| Excess tax benefit from stock-based compensation |  |  | (2 | ) |  |  | (43 | ) |
| Other, net |  |  | (34 | ) |  |  | 46 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 361 |  |  |  | 271 |  |
| Inventories |  |  | (47 | ) |  |  | 18 |  |
| Accounts payable |  |  | (33 | ) |  |  | (62 | ) |
| Accrued expenses |  |  | (119 | ) |  |  | (227 | ) |
| Deferred revenue |  |  | (121 | ) |  |  | (26 | ) |
| Changes in other operating assets and liabilities, net |  |  | 8 |  |  |  | 11 |  |
| Net cash provided by operating activities |  |  | 129 |  |  |  | 216 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 778 |  |  |  | 191 |  |
| Purchases of property and equipment |  |  | (38 | ) |  |  | (58 | ) |
| Other investing activities, net |  |  | 2 |  |  |  | - |  |
| Net cash provided by investing activities |  |  | 742 |  |  |  | 133 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 19 |  |  |  | 28 |  |
| Repurchase of common stock |  |  | (430 | ) |  |  | (119 | ) |
| Excess tax benefit from stock-based compensation |  |  | 2 |  |  |  | 43 |  |
| Issuance of long-term debt, net |  |  | - |  |  |  | 495 |  |
| Dividends paid |  |  | (54 | ) |  |  | (53 | ) |
| Other financing activities, net |  |  | (1 | ) |  |  | (2 | ) |
| Net cash provided by (used in) financing activities |  |  | (464 | ) |  |  | 392 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (5 | ) |  |  | - |  |
| Net increase in cash and cash equivalents |  |  | 402 |  |  |  | 741 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 1,922 |  |  |  | 2,291 |  |
| End of period |  | $ | 2,324 |  |  | $ | 3,032 |  |

[0001102624-15-001340:8k_2_02:45]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q1 FY'16 |  |  | Q4 FY'15 |  |  | Q1 FY'15 |  |
| Revenues |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 664 |  |  | $ | 914 |  |  | $ | 883 |  |
| Software Maintenance |  | $ | 248 |  |  | $ | 227 |  |  | $ | 221 |  |
| Hardware Maintenance & Other Services: |  | $ | 423 |  |  | $ | 399 |  |  | $ | 385 |  |
| Hardware Maintenance Support Contracts |  | $ | 346 |  |  | $ | 323 |  |  | $ | 303 |  |
| Professional & Other Services |  | $ | 77 |  |  | $ | 77 |  |  | $ | 83 |  |
| Net Revenues |  | $ | 1,335 |  |  | $ | 1,540 |  |  | $ | 1,489 |  |
| Software Maintenance revenue was formerly called Software Entitlements & Maintenance (SEM) revenue. |  |
| Hardware Maintenance & Other Services revenue was formerly called Services revenue. |  |

[0001102624-15-001340:8k_2_02:46]
| Geographic Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'16 Revenue |  |  | % of Q4 FY'15 Revenue |  |  | % of Q1 FY'15 Revenue |  |
| Americas |  |  | 56 | % |  |  | 57 | % |  |  | 56 | % |
| Americas Commercial |  |  | 44 | % |  |  | 43 | % |  |  | 44 | % |
| U.S. Public Sector |  |  | 12 | % |  |  | 14 | % |  |  | 12 | % |
| EMEA |  |  | 31 | % |  |  | 30 | % |  |  | 30 | % |
| Asia Pacific |  |  | 13 | % |  |  | 13 | % |  |  | 14 | % |

[0001102624-15-001340:8k_2_02:47]
| Pathways Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'16 Revenue |  |  | % of Q4 FY'15 Revenue |  |  | % of Q1 FY’15 Revenue |  |
| Direct |  |  | 22 | % |  |  | 22 | % |  |  | 24 | % |
| Indirect |  |  | 77 | % |  |  | 78 | % |  |  | 76 | % |

[0001102624-15-001340:8k_2_02:48]
Direct revenues are those sold through our direct sales force and, effective Q1 FY'16, include those sold to service providers. Previously, sales to service providers were included in indirect revenues. All periods presented have been recast to reflect this change in presentation. Indirect revenues include those sold through value-added resellers, system integrators, OEMs and distributors. Indirect revenue reflects order fulfillment and is not reflective of who is responsible for the customer relationship.

[0001102624-15-001340:8k_2_02:49]
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'16 |  |  | Q4 FY'15 |  |  | Q1 FY'15 |  |
| Non-GAAP Gross Margin |  |  | 63.6 | % |  |  | 62.0 | % |  |  | 64.3 | % |
| Product |  |  | 51.2 | % |  |  | 53.4 | % |  |  | 57.1 | % |
| Software Maintenance |  |  | 96.2 | % |  |  | 95.8 | % |  |  | 96.3 | % |
| Hardware Maintenance & Other Services |  |  | 64.1 | % |  |  | 62.6 | % |  |  | 62.7 | % |

[0001102624-15-001340:8k_2_02:50]
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |
|  |  | Q1 FY'16 |  |  | Q4 FY'15 |  |  | Q1 FY'15 |  |
| Non-GAAP Income from Operations |  | $ | 103 |  |  | $ | 240 |  |  | $ | 237 |  |
| % of Net Revenues |  |  | 7.7 | % |  |  | 15.6 | % |  |  | 15.9 | % |
| Non-GAAP Income before Income Taxes |  | $ | 107 |  |  | $ | 243 |  |  | $ | 237 |  |
| Non-GAAP Effective Tax Rate |  |  | 17.0 | % |  |  | 16.7 | % |  |  | 16.5 | % |

[0001102624-15-001340:8k_2_02:51]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'16 |  |  | Q4 FY'15 |  |  | Q1 FY'15 |  |
| Non-GAAP Net Income |  | $ | 89 |  |  | $ | 202 |  |  | $ | 198 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 308 |  |  |  | 313 |  |  |  | 329 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 0.29 |  |  | $ | 0.65 |  |  | $ | 0.60 |  |

[0001102624-15-001340:8k_2_02:52]
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'16 |  |  | Q4 FY'15 |  |  | Q1 FY'15 |  |
| Deferred Revenue |  | $ | 3,066 |  |  | $ | 3,197 |  |  | $ | 3,076 |  |
| DSO (days) |  |  | 30 |  |  |  | 46 |  |  |  | 36 |  |
| Inventory Turns |  |  | 10 |  |  |  | 16 |  |  |  | 20 |  |

[0001102624-15-001340:8k_2_02:53]
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |
| Inventory turns is defined as annualized non-GAAP cost of revenues divided by net inventories. |

[0001102624-15-001340:8k_2_02:54]
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |
|  |  | Q1 FY'16 |  |  | Q4 FY'15 |  |  | Q1 FY'15 |  |
| Net Cash Provided by Operating Activities |  | $ | 129 |  |  | $ | 396 |  |  | $ | 216 |  |
| Purchases of Property and Equipment |  | $ | 38 |  |  | $ | 37 |  |  | $ | 58 |  |
| Free Cash Flow |  | $ | 91 |  |  | $ | 359 |  |  | $ | 157 |  |
| Free Cash Flow as % of Net Revenues |  |  | 6.8 | % |  |  | 23.3 | % |  |  | 10.5 | % |

[0001102624-15-001340:8k_2_02:55]
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |
| Some items may not add or recalculate due to rounding. |

[0001102624-15-001340:8k_2_02:56]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY16 |  |  | Q4'FY15 |  |  | Q1'FY15 |  |
| NET INCOME (LOSS) |  | $ | (30 | ) |  | $ | 135 |  |  | $ | 88 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 16 |  |  |  | 15 |  |
| Stock-based compensation |  |  | 77 |  |  |  | 63 |  |  |  | 62 |  |
| Asset impairment |  |  | 11 |  |  |  | - |  |  |  | - |  |
| Restructuring and other charges |  |  | 27 |  |  |  | - |  |  |  | - |  |
| Income tax effect of non-GAAP adjustments |  |  | (23 | ) |  |  | (11 | ) |  |  | (15 | ) |
| Settlement of income tax audit |  |  | 13 |  |  |  | - |  |  |  | 47 |  |
| NON-GAAP NET INCOME |  | $ | 89 |  |  | $ | 202 |  |  | $ | 198 |  |
| COST OF REVENUES |  | $ | 519 |  |  | $ | 605 |  |  | $ | 551 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14 | ) |  |  | (16 | ) |  |  | (15 | ) |
| Stock-based compensation |  |  | (8 | ) |  |  | (5 | ) |  |  | (6 | ) |
| Asset impairment |  |  | (11 | ) |  |  | - |  |  |  | - |  |
| NON-GAAP COST OF REVENUES |  | $ | 486 |  |  | $ | 584 |  |  | $ | 531 |  |
| COST OF PRODUCT REVENUES |  | $ | 345 |  |  | $ | 441 |  |  | $ | 394 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14 | ) |  |  | (15 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (2 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Asset impairment |  |  | (5 | ) |  |  | - |  |  |  | - |  |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 324 |  |  | $ | 425 |  |  | $ | 379 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 164 |  |  | $ | 154 |  |  | $ | 149 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | - |  |  |  | (1 | ) |  |  | (1 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (4 | ) |  |  | (5 | ) |
| Asset impairment |  |  | (6 | ) |  |  | - |  |  |  | - |  |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 152 |  |  | $ | 150 |  |  | $ | 144 |  |
| GROSS PROFIT |  | $ | 816 |  |  | $ | 935 |  |  | $ | 938 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 16 |  |  |  | 15 |  |
| Stock-based compensation |  |  | 8 |  |  |  | 5 |  |  |  | 6 |  |
| Asset impairment |  |  | 11 |  |  |  | - |  |  |  | - |  |
| NON-GAAP GROSS PROFIT |  | $ | 849 |  |  | $ | 955 |  |  | $ | 958 |  |
| SALES AND MARKETING EXPENSES |  | $ | 492 |  |  | $ | 470 |  |  | $ | 480 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (31 | ) |  |  | (29 | ) |  |  | (27 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 461 |  |  | $ | 440 |  |  | $ | 453 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 244 |  |  | $ | 233 |  |  | $ | 228 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (26 | ) |  |  | (20 | ) |  |  | (21 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 218 |  |  | $ | 213 |  |  | $ | 207 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 79 |  |  | $ | 71 |  |  | $ | 70 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (12 | ) |  |  | (9 | ) |  |  | (8 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 67 |  |  | $ | 62 |  |  | $ | 62 |  |

[0001102624-15-001340:8k_2_02:57]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY16 |  |  | Q4'FY15 |  |  | Q1'FY15 |  |
| RESTRUCTURING AND OTHER CHARGES |  | $ | 27 |  |  | $ | - |  |  | $ | - |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  |  | (27 | ) |  |  | - |  |  |  | - |  |
| NON-GAAP RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| OPERATING EXPENSES |  | $ | 842 |  |  | $ | 774 |  |  | $ | 778 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (69 | ) |  |  | (58 | ) |  |  | (56 | ) |
| Restructuring and other charges |  |  | (27 | ) |  |  | - |  |  |  | - |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 746 |  |  | $ | 715 |  |  | $ | 722 |  |
| INCOME (LOSS) FROM OPERATIONS |  | $ | (26 | ) |  | $ | 161 |  |  | $ | 160 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 16 |  |  |  | 15 |  |
| Stock-based compensation |  |  | 77 |  |  |  | 63 |  |  |  | 62 |  |
| Asset impairment |  |  | 11 |  |  |  | - |  |  |  | - |  |
| Restructuring and other charges |  |  | 27 |  |  |  | - |  |  |  | - |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 103 |  |  | $ | 240 |  |  | $ | 237 |  |
| INCOME (LOSS) BEFORE INCOME TAXES |  | $ | (22 | ) |  | $ | 164 |  |  | $ | 160 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 16 |  |  |  | 15 |  |
| Stock-based compensation |  |  | 77 |  |  |  | 63 |  |  |  | 62 |  |
| Asset impairment |  |  | 11 |  |  |  | - |  |  |  | - |  |
| Restructuring and other charges |  |  | 27 |  |  |  | - |  |  |  | - |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 107 |  |  | $ | 243 |  |  | $ | 237 |  |
| PROVISION FOR INCOME TAXES |  | $ | 8 |  |  | $ | 29 |  |  | $ | 72 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | 23 |  |  |  | 11 |  |  |  | 15 |  |
| Settlement of income tax audit |  |  | (13 | ) |  |  | - |  |  |  | (47 | ) |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 18 |  |  | $ | 41 |  |  | $ | 39 |  |
| NET INCOME (LOSS) PER SHARE |  | $ | (0.10 | ) |  | $ | 0.43 |  |  | $ | 0.27 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.04 |  |
| Stock-based compensation |  |  | 0.25 |  |  |  | 0.20 |  |  |  | 0.19 |  |
| Asset impairment |  |  | 0.04 |  |  |  | - |  |  |  | - |  |
| Restructuring and other charges |  |  | 0.09 |  |  |  | - |  |  |  | - |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.08 | ) |  |  | (0.04 | ) |  |  | (0.04 | ) |
| Settlement of income tax audit |  |  | 0.04 |  |  |  | - |  |  |  | 0.14 |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.29 |  |  | $ | 0.65 |  |  | $ | 0.60 |  |

[0001102624-15-001340:8k_2_02:58]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY16 |  |  | Q4'FY15 |  |  | Q1'FY15 |  |
| Gross margin-GAAP |  |  | 61.1 | % |  |  | 60.7 | % |  |  | 63.0 | % |
| Cost of revenues adjustments |  |  | 2.5 | % |  |  | 1.3 | % |  |  | 1.4 | % |
| Gross margin-Non-GAAP |  |  | 63.6 | % |  |  | 62.0 | % |  |  | 64.3 | % |
| GAAP cost of revenues |  | $ | 519 |  |  | $ | 605 |  |  | $ | 551 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14 | ) |  |  | (16 | ) |  |  | (15 | ) |
| Stock-based compensation |  |  | (8 | ) |  |  | (5 | ) |  |  | (6 | ) |
| Asset impairment |  |  | (11 | ) |  |  | - |  |  |  | - |  |
| Non-GAAP cost of revenues |  | $ | 486 |  |  | $ | 584 |  |  | $ | 531 |  |
| Net revenues |  | $ | 1,335 |  |  | $ | 1,540 |  |  | $ | 1,489 |  |

[0001102624-15-001340:8k_2_02:59]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY16 |  |  | Q4'FY15 |  |  | Q1'FY15 |  |
| Product gross margin-GAAP |  |  | 48.0 | % |  |  | 51.7 | % |  |  | 55.3 | % |
| Cost of product revenues adjustments |  |  | 3.2 | % |  |  | 1.8 | % |  |  | 1.7 | % |
| Product gross margin-Non-GAAP |  |  | 51.2 | % |  |  | 53.4 | % |  |  | 57.1 | % |
| GAAP cost of product revenues |  | $ | 345 |  |  | $ | 441 |  |  | $ | 394 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14 | ) |  |  | (15 | ) |  |  | (14 | ) |
| Stock-based compensation |  |  | (2 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Asset impairment |  |  | (5 | ) |  |  | - |  |  |  | - |  |
| Non-GAAP cost of product revenues |  | $ | 324 |  |  | $ | 425 |  |  | $ | 379 |  |
| Product revenues |  | $ | 664 |  |  | $ | 914 |  |  | $ | 883 |  |

[0001102624-15-001340:8k_2_02:60]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY16 |  |  | Q4'FY15 |  |  | Q1'FY15 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 61.2 | % |  |  | 61.6 | % |  |  | 61.4 | % |
| Cost of hardware maintenance and other services revenues adjustments |  |  | 2.8 | % |  |  | 1.0 | % |  |  | 1.3 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 64.1 | % |  |  | 62.6 | % |  |  | 62.7 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 164 |  |  | $ | 154 |  |  | $ | 149 |  |
| Cost of hardware maintenance and other services revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | - |  |  |  | (1 | ) |  |  | (1 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (4 | ) |  |  | (5 | ) |
| Asset impairment |  |  | (6 | ) |  |  | - |  |  |  | - |  |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 152 |  |  | $ | 150 |  |  | $ | 144 |  |
| Hardware maintenance and other services revenues |  | $ | 423 |  |  | $ | 399 |  |  | $ | 385 |  |

[0001102624-15-001340:8k_2_02:61]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q1'FY16 |  |  | Q4'FY15 |  |  | Q1'FY15 |  |
| GAAP effective tax rate |  |  | (36.4 | %) |  |  | 17.8 | % |  |  | 44.6 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | 65.5 | % |  |  | (1.1 | %) |  |  | (8.1 | %) |
| Settlement of income tax audit |  |  | (12.1 | %) |  |  | - | % |  |  | (20.0 | %) |
| Non-GAAP effective tax rate |  |  | 17.0 | % |  |  | 16.7 | % |  |  | 16.5 | % |

[0001102624-15-001340:8k_2_02:62]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY16 |  |  | Q4'FY15 |  |  | Q1'FY15 |  |
| Net cash provided by operating activities |  | $ | 129 |  |  | $ | 396 |  |  | $ | 216 |  |
| Purchases of property and equipment |  |  | (38 | ) |  |  | (37 | ) |  |  | (58 | ) |
| Free cash flow |  | $ | 91 |  |  | $ | 359 |  |  | $ | 157 |  |

[0001102624-15-001340:8k_2_02:63]
| INVENTORY TURNS AND RECONCILIATION OF NON-GAAP TO GAAP |  |
| COST OF REVENUES USED IN INVENTORY TURNS |  |
| (In millions, except annualized inventory turns) |  |
|  |  | Q1'FY16 |  |  | Q4'FY15 |  |  | Q1'FY15 |  |
| Annualized inventory turns-GAAP |  |  | 11 |  |  |  | 17 |  |  |  | 21 |  |
| Cost of revenues adjustments |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Annualized inventory turns-Non-GAAP |  |  | 10 |  |  |  | 16 |  |  |  | 20 |  |
| GAAP cost of revenues |  | $ | 519 |  |  | $ | 605 |  |  | $ | 551 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (14 | ) |  |  | (16 | ) |  |  | (15 | ) |
| Stock-based compensation |  |  | (8 | ) |  |  | (5 | ) |  |  | (6 | ) |
| Asset impairment |  |  | (11 | ) |  |  | - |  |  |  | - |  |
| Non-GAAP cost of revenues |  | $ | 486 |  |  | $ | 584 |  |  | $ | 531 |  |
| Inventory |  | $ | 193 |  |  | $ | 146 |  |  | $ | 104 |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |

[0001102624-15-001340:8k_2_02:64]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |  |
| EXPRESSED AS EARNINGS PER SHARE |  |
| SECOND QUARTER FISCAL 2016 |  |
|  |  | Second Quarter |  |
|  |  | Fiscal 2016 |  |
| Non-GAAP Guidance - Net Income Per Share |  | $ | 0.55 - $0.60 |  |
| Adjustments of Specific Items to Net Income |  |  |  |  |
| Per Share for the Second Quarter Fiscal 2016: |  |  |  |  |
| Amortization of intangible assets |  |  | (0.05 | ) |
| Stock-based compensation expense |  |  | (0.20 | ) |
| Income tax effect of non-GAAP adjustments |  |  | 0.05 |  |
| Total Adjustments |  |  | (0.20 | ) |
| GAAP Guidance - Net Income Per Share |  | $ | 0.35 - $0.40 |  |
