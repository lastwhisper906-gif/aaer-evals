# NTAP notes — 0001564590-15-007795


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-15-007795:notes:1]
[same as prior period, unchanged from 0001564590-15-000944:notes:1]

[0001564590-15-007795:notes:2]
NetApp, Inc. (we, us, or the Company) provides software, systems and services to manage and store computer data. We enable enterprises, service providers, governmental organizations, and partners to envision, deploy and evolve their information technology environments and to reduce costs and risk while driving growth and success for their organizations.

[0001564590-15-007795:notes:3]
[same as prior period, unchanged from 0001564590-15-000944:notes:3]

[0001564590-15-007795:notes:4]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2016, ending on April 29, 2016 is a 53-week year, with a 14th week included in its first quarter. Fiscal year 2015, which ended on April 24, 2015, was a 52-week year, with 13 weeks in its first quarter.

[0001564590-15-007795:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income (loss) and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2015 contained in our Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 12, 2015. The results of operations for the three months ended July 31, 2015 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-15-007795:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-15-007795:notes:7]
There have been no significant changes in our significant accounting policies as of and for the three months ended July 31, 2015, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 24, 2015.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-15-007795:notes:8]
[same as prior period, unchanged from 0001564590-15-000944:notes:8]

[0001564590-15-007795:notes:9]
[same as prior period, unchanged from 0001564590-15-000944:notes:9]

[0001564590-15-007795:notes:10]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 13 |  |  | $ | 12 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 40 |  |  | $ | 68 |  |
| Interest paid |  | $ | 20 |  |  | $ | 12 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-15-007795:notes:11]
4. Purchased Intangible Assets, Net

[0001564590-15-007795:notes:12]
Purchased intangible assets, net are summarized below (in millions):

[0001564590-15-007795:notes:13]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 304 |  |  | $ | (242 | ) |  | $ | 62 |  |  | $ | 313 |  |  | $ | (225 | ) |  | $ | 88 |  |
| Customer contracts/relationships |  |  | 5 |  |  |  | (3 | ) |  |  | 2 |  |  |  | 5 |  |  |  | (3 | ) |  |  | 2 |  |
| Other purchased intangibles |  |  | 1 |  |  |  | (1 | ) |  |  | — |  |  |  | 3 |  |  |  | (3 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 310 |  |  | $ | (246 | ) |  | $ | 64 |  |  | $ | 321 |  |  | $ | (231 | ) |  | $ | 90 |  |

[0001564590-15-007795:notes:14]
In the three months ended July 31, 2015, we recorded a charge of $11 million to fully impair developed technology related to our fiscal 2013 acquisition of CacheIQ as a result of our discontinued use of such technology. The impairment charge is included in accumulated amortization in the table above.

[0001564590-15-007795:notes:15]
Amortization expense for purchased intangible assets is summarized below (in millions):

[0001564590-15-007795:notes:16]
|  |  | Three Months Ended |  |  | Statement of |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  | Operations Classifications |
| Developed technology |  | $ | 14 |  |  | $ | 15 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | — |  |  |  | — |  |  | Operating expenses |
| Total |  | $ | 14 |  |  | $ | 15 |  |  |  |

[0001564590-15-007795:notes:17]
As of July 31, 2015, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-15-007795:notes:18]
| Fiscal Year |  | Amount |  |
| Remainder of 2016 |  | $ | 40 |  |
| 2017 |  |  | 10 |  |
| 2018 |  |  | 6 |  |
| 2019 |  |  | 5 |  |
| 2020 |  |  | 3 |  |
| Total |  | $ | 64 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-15-007795:notes:19]
5. Balance Sheet Details

[0001564590-15-007795:notes:20]
[same as prior period, unchanged from 0001564590-15-000944:notes:27]

[0001564590-15-007795:notes:21]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Cash |  | $ | 2,120 |  |  | $ | 1,666 |  |
| Cash equivalents |  |  | 204 |  |  |  | 256 |  |
| Cash and cash equivalents |  | $ | 2,324 |  |  | $ | 1,922 |  |

[0001564590-15-007795:notes:22]
[same as prior period, unchanged from 0001564590-15-000944:notes:29]

[0001564590-15-007795:notes:23]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Purchased components |  | $ | 63 |  |  | $ | 36 |  |
| Finished goods |  |  | 130 |  |  |  | 110 |  |
| Inventories |  | $ | 193 |  |  | $ | 146 |  |

[0001564590-15-007795:notes:24]
[same as prior period, unchanged from 0001564590-15-000944:notes:31]

[0001564590-15-007795:notes:25]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Prepaid expenses and other current assets |  | $ | 271 |  |  | $ | 268 |  |
| Deferred tax assets |  |  | 290 |  |  |  | 254 |  |
| Other current assets |  | $ | 561 |  |  | $ | 522 |  |

[0001564590-15-007795:notes:26]
[same as prior period, unchanged from 0001564590-15-000944:notes:33]

[0001564590-15-007795:notes:27]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Land |  | $ | 265 |  |  | $ | 265 |  |
| Buildings and improvements |  |  | 606 |  |  |  | 607 |  |
| Leasehold improvements |  |  | 109 |  |  |  | 107 |  |
| Computer, production, engineering and other equipment |  |  | 759 |  |  |  | 754 |  |
| Computer software |  |  | 369 |  |  |  | 372 |  |
| Furniture and fixtures |  |  | 85 |  |  |  | 85 |  |
| Construction-in-progress |  |  | 38 |  |  |  | 33 |  |
|  |  |  | 2,231 |  |  |  | 2,223 |  |
| Accumulated depreciation and amortization |  |  | (1,220 | ) |  |  | (1,193 | ) |
| Property and equipment, net |  | $ | 1,011 |  |  | $ | 1,030 |  |

[0001564590-15-007795:notes:28]
[same as prior period, unchanged from 0001564590-15-000944:notes:37]

[0001564590-15-007795:notes:29]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Deferred tax assets |  | $ | 273 |  |  | $ | 256 |  |
| Other assets |  |  | 203 |  |  |  | 225 |  |
| Other non-current assets |  | $ | 476 |  |  | $ | 481 |  |

[0001564590-15-007795:notes:30]
Accrued expenses (in millions):

[0001564590-15-007795:notes:31]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Accrued compensation and benefits |  | $ | 258 |  |  | $ | 359 |  |
| Product warranty liability |  |  | 54 |  |  |  | 58 |  |
| Other current liabilities |  |  | 280 |  |  |  | 284 |  |
| Accrued expenses |  | $ | 592 |  |  | $ | 701 |  |

[0001564590-15-007795:notes:32]
Product warranty liabilities:

[0001564590-15-007795:notes:33]
Equipment and software systems sales include a standard product warranty. The following tables summarize the activity related to product warranty liabilities and their balances as reported in our condensed consolidated balance sheets (in millions):

[0001564590-15-007795:notes:34]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Balance at beginning of period |  | $ | 86 |  |  | $ | 110 |  |
| Expense accrued during the period |  |  | 9 |  |  |  | 10 |  |
| Warranty costs incurred |  |  | (14 | ) |  |  | (16 | ) |
| Balance at end of period |  | $ | 81 |  |  | $ | 104 |  |

[0001564590-15-007795:notes:35]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Accrued expenses |  | $ | 54 |  |  | $ | 58 |  |
| Other long-term liabilities |  |  | 27 |  |  |  | 28 |  |
| Total warranty liabilities |  | $ | 81 |  |  | $ | 86 |  |

[0001564590-15-007795:notes:36]
Warranty expense accrued during the period includes amounts accrued for systems at the time of shipment, adjustments for changes in estimated costs for warranties on systems shipped in the period and changes in estimated costs for warranties on systems shipped in prior periods.

[0001564590-15-007795:notes:37]
Deferred revenue and financed unearned services revenue (in millions):

[0001564590-15-007795:notes:38]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Deferred product revenue |  | $ | 25 |  |  | $ | 17 |  |
| Deferred services revenue |  |  | 2,934 |  |  |  | 3,075 |  |
| Financed unearned services revenue |  |  | 107 |  |  |  | 105 |  |
| Total |  | $ | 3,066 |  |  | $ | 3,197 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,639 |  |  | $ | 1,724 |  |
| Long-term |  |  | 1,427 |  |  |  | 1,473 |  |
| Total |  | $ | 3,066 |  |  | $ | 3,197 |  |

[0001564590-15-007795:notes:39]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 15 for additional information related to these arrangements.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-15-007795:notes:40]
6. Other income, net

[0001564590-15-007795:notes:41]
Other income, net consists of the following (in millions):

[0001564590-15-007795:notes:42]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Interest income |  | $ | 13 |  |  | $ | 8 |  |
| Interest expense |  |  | (11 | ) |  |  | (9 | ) |
| Other income, net |  |  | 2 |  |  |  | 1 |  |
| Total other income, net |  | $ | 4 |  |  | $ | — |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-15-007795:notes:43]
[same as prior period, unchanged from 0001564590-15-000944:notes:41]

[0001564590-15-007795:notes:44]
[same as prior period, unchanged from 0001564590-15-000944:notes:42]

[0001564590-15-007795:notes:45]
[same as prior period, unchanged from 0001564590-15-000944:notes:43]

[0001564590-15-007795:notes:46]
[same as prior period, unchanged from 0001564590-15-000944:notes:44]

[0001564590-15-007795:notes:47]
[same as prior period, unchanged from 0001564590-15-000944:notes:45]

[0001564590-15-007795:notes:48]
[same as prior period, unchanged from 0001564590-15-000944:notes:46]

[0001564590-15-007795:notes:49]
[same as prior period, unchanged from 0001564590-15-000944:notes:47]

[0001564590-15-007795:notes:50]
[same as prior period, unchanged from 0001564590-15-000944:notes:48]

[0001564590-15-007795:notes:51]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,712 |  |  | $ | 3 |  |  | $ | (2 | ) |  | $ | 1,713 |  |  | $ | 2,249 |  |  | $ | 9 |  |  | $ | — |  |  | $ | 2,258 |  |
| U.S. Treasury and government debt securities |  |  | 838 |  |  |  | 1 |  |  |  | — |  |  |  | 839 |  |  |  | 1,056 |  |  |  | 2 |  |  |  | — |  |  |  | 1,058 |  |
| Foreign government debt securities |  |  | 44 |  |  |  | — |  |  |  | — |  |  |  | 44 |  |  |  | 38 |  |  |  | — |  |  |  | — |  |  |  | 38 |  |
| Commercial paper |  |  | 25 |  |  |  | — |  |  |  | — |  |  |  | 25 |  |  |  | 20 |  |  |  | — |  |  |  | — |  |  |  | 20 |  |
| Certificates of deposit |  |  | 209 |  |  |  | — |  |  |  | — |  |  |  | 209 |  |  |  | 286 |  |  |  | — |  |  |  | — |  |  |  | 286 |  |
| Mutual funds |  |  | 34 |  |  |  | — |  |  |  | — |  |  |  | 34 |  |  |  | 32 |  |  |  | — |  |  |  | — |  |  |  | 32 |  |
| Total debt and equity securities |  | $ | 2,862 |  |  | $ | 4 |  |  | $ | (2 | ) |  | $ | 2,864 |  |  | $ | 3,681 |  |  | $ | 11 |  |  | $ | — |  |  | $ | 3,692 |  |

[0001564590-15-007795:notes:52]
As of July 31, 2015, gross unrealized losses related to individual securities were not significant.

[0001564590-15-007795:notes:53]
The following table presents the contractual maturities of our debt investments as of July 31, 2015 (in millions):

[0001564590-15-007795:notes:54]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 1,024 |  |  | $ | 1,025 |  |
| Due after one year through five years |  |  | 1,804 |  |  |  | 1,805 |  |
|  |  | $ | 2,828 |  |  | $ | 2,830 |  |

[0001564590-15-007795:notes:55]
[same as prior period, unchanged from 0001564590-15-000944:notes:53]

[0001564590-15-007795:notes:56]
[same as prior period, unchanged from 0001564590-15-000944:notes:54]

[0001564590-15-007795:notes:57]
[same as prior period, unchanged from 0001564590-15-000944:notes:55]

[0001564590-15-007795:notes:58]
|  |  | July 31, 2015 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,120 |  |  | $ | 2,120 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,713 |  |  |  | — |  |  |  | 1,713 |  |
| U.S. Treasury and government debt securities |  |  | 839 |  |  |  | 138 |  |  |  | 701 |  |
| Foreign government debt securities |  |  | 44 |  |  |  | — |  |  |  | 44 |  |
| Commercial paper |  |  | 25 |  |  |  | — |  |  |  | 25 |  |
| Certificates of deposit |  |  | 209 |  |  |  | — |  |  |  | 209 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,950 |  |  | $ | 2,258 |  |  | $ | 2,692 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 27 |  |  | $ | 27 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (2 | ) |  | $ | — |  |  | $ | (2 | ) |
| Long-term debt |  | $ | (1,489 | ) |  | $ | — |  |  | $ | (1,489 | ) |

[0001564590-15-007795:notes:59]
| (1) | Reported as other current assets in the condensed consolidated balance sheets |

[0001564590-15-007795:notes:60]
| (2) | Reported as other non-current assets in the condensed consolidated balance sheets |

[0001564590-15-007795:notes:61]
| (3) | Reported as accrued expenses in the condensed consolidated balance sheets |

[0001564590-15-007795:notes:62]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 financial instruments. As of July 31, 2015 and April 24, 2015, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-15-007795:notes:63]
Fair Value of Long-Term Debt

[0001564590-15-007795:notes:64]
The fair value of our long-term debt was based on observable market prices in a less active market and discounted cash flow models that take into consideration variables such as credit-rating and interest rate changes. All of our debt obligations are categorized as Level 2 instruments.


## us-gaap:DebtDisclosureTextBlock

[0001564590-15-007795:notes:65]
8. Financing Arrangements

[0001564590-15-007795:notes:66]
Long-term Debt

[0001564590-15-007795:notes:67]
The following table summarizes information relating to our long-term debt (in millions, except interest rates):

[0001564590-15-007795:notes:68]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (5 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (7 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,488 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |

[0001564590-15-007795:notes:69]
Senior Notes

[0001564590-15-007795:notes:70]
In June 2014, we issued $500 million par value of 3.375% Senior Notes due June 15, 2021, and received proceeds of approximately $495 million, net of discount and issuance costs. Our 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $750 million and $250 million, respectively, were issued in December 2012. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any future senior unsecured indebtedness.

[0001564590-15-007795:notes:71]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 31, 2015, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-15-007795:notes:72]
As of July 31, 2015, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-15-007795:notes:73]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| Thereafter |  |  | 750 |  |
| Total |  | $ | 1,500 |  |

[0001564590-15-007795:notes:74]
Credit Facility

[0001564590-15-007795:notes:75]
In December 2012, we entered into a credit agreement with a syndicated group of lenders that is scheduled to expire on December 21, 2017 and provides for an unsecured $250 million revolving credit facility that is comprised of revolving loans, Eurocurrency loans and/or swingline loans. The credit facility includes a $100 million foreign currency sub-facility, a $50 million letter of credit sub-facility and a $10 million swingline sub-facility available on same-day notice. Available borrowings under the credit facility are reduced by the amount of any outstanding borrowings on the sub-facilities. We may also, subject to certain requirements, request an increase in the facility up to an additional $100 million and request two additional one-year extensions, subject to certain conditions. The proceeds from the facility may be used by us for general corporate purposes.

[0001564590-15-007795:notes:76]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of July 31, 2015, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-15-007795:notes:77]
Other Long-Term Financing Arrangements

[0001564590-15-007795:notes:78]
The following presents the amounts due under other long-term financing arrangements (in millions):

[0001564590-15-007795:notes:79]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 14 |  |  | $ | 16 |  |
| Less: current portion |  |  | (9 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 5 |  |  | $ | 6 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-15-007795:notes:80]
[same as prior period, unchanged from 0001564590-15-000944:notes:82]

[0001564590-15-007795:notes:81]
Equity Incentive Awards

[0001564590-15-007795:notes:82]
As of July 31, 2015, we have outstanding certain equity incentive awards (awards), which include stock options, restricted stock units (RSUs), which have been granted in the form of time-based RSUs and performance-based RSUs (PBRSUs), and Employee Stock Purchase Plan (ESPP) awards.

[0001564590-15-007795:notes:83]
[same as prior period, unchanged from 0001564590-15-000944:notes:83]

[0001564590-15-007795:notes:84]
[same as prior period, unchanged from 0001564590-15-000944:notes:84]

[0001564590-15-007795:notes:85]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 24, 2015 |  |  | 12 |  |  | $ | 37.74 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (1 | ) |  | $ | 23.37 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (1 | ) |  | $ | 37.67 |  |  |  |  |  |  |  |  |  |
| Outstanding as of July 31, 2015 |  |  | 10 |  |  | $ | 38.18 |  |  |  | 3.04 |  |  | $ | 13 |  |
| Vested and expected to vest as of July 31, 2015 |  |  | 10 |  |  | $ | 38.23 |  |  |  | 2.92 |  |  | $ | 13 |  |
| Exercisable as of July 31, 2015 |  |  | 8 |  |  | $ | 38.74 |  |  |  | 2.35 |  |  | $ | 13 |  |

[0001564590-15-007795:notes:86]
[same as prior period, unchanged from 0001564590-15-000944:notes:86]

[0001564590-15-007795:notes:87]
[same as prior period, unchanged from 0001564590-15-000944:notes:87]

[0001564590-15-007795:notes:88]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Intrinsic value of exercises |  | $ | 3 |  |  | $ | 7 |  |
| Proceeds received from exercises |  | $ | 7 |  |  | $ | 13 |  |
| Fair value of options vested |  | $ | 6 |  |  | $ | 9 |  |

[0001564590-15-007795:notes:89]
[same as prior period, unchanged from 0001564590-15-000944:notes:89]

[0001564590-15-007795:notes:90]
In the three months ended July 31, 2015, we granted PBRSUs to certain of our executives, all of which were outstanding at the end of the period. Each PBRSU has performance-based vesting criteria (in addition to the service based vesting criteria) such that the PBRSU cliff-vests at the end of either a two year or three year performance period, which begins the first day of fiscal 2016 and ends the last day of fiscal 2017 or 2018, respectively. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted, and will depend upon our Total Stockholder Return (TSR) as compared to an index TSR (each expressed as a growth rate percentage) calculated as of the applicable period end date. The fair value of the PBRSUs was fixed at grant date using a Monte Carlo simulation model and the related aggregate compensation cost of $15 million will be recognized, adjusted for forfeitures, over the shorter of the remaining performance or service period.

[0001564590-15-007795:notes:91]
RSUs are converted into common stock upon vesting. Time-based RSUs generally vest with only service-based criteria at 25% annually over four years, except for the PBRSUs described above and 4 million time-based RSUs granted in the three months ended July 31, 2015, which will vest at 50% annually over two years.

[0001564590-15-007795:notes:92]
The following table summarizes activity for the three months ended July 31, 2015 related to RSUs, including PBRSUs, (in millions, except for fair value):

[0001564590-15-007795:notes:93]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 24, 2015 |  |  | 13 |  |  | $ | 36.58 |  |
| Granted |  |  | 5 |  |  | $ | 31.38 |  |
| Vested |  |  | (3 | ) |  | $ | 37.48 |  |
| Forfeited |  |  | (1 | ) |  | $ | 35.95 |  |
| Outstanding as of July 31, 2015 |  |  | 14 |  |  | $ | 34.54 |  |

[0001564590-15-007795:notes:94]
We primarily use the net share settlement approach upon vesting, where a portion of the shares are withheld as settlement of statutory employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0001564590-15-007795:notes:95]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 38 |  |  | $ | 34 |  |

[0001564590-15-007795:notes:96]
[same as prior period, unchanged from 0001564590-15-000944:notes:94]

[0001564590-15-007795:notes:97]
The following table summarizes activity related to the purchase rights issued under the ESPP (in millions):

[0001564590-15-007795:notes:98]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Shares issued under the ESPP |  |  | 2 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 50 |  |  | $ | 49 |  |

[0001564590-15-007795:notes:99]
[same as prior period, unchanged from 0001564590-15-000944:notes:97]

[0001564590-15-007795:notes:100]
[same as prior period, unchanged from 0001564590-15-000944:notes:98]

[0001564590-15-007795:notes:101]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Cost of product revenues |  | $ | 2 |  |  | $ | 1 |  |
| Cost of hardware maintenance and other services revenues |  |  | 6 |  |  |  | 5 |  |
| Sales and marketing |  |  | 31 |  |  |  | 27 |  |
| Research and development |  |  | 26 |  |  |  | 21 |  |
| General and administrative |  |  | 12 |  |  |  | 8 |  |
| Total stock-based compensation expense |  | $ | 77 |  |  | $ | 62 |  |

[0001564590-15-007795:notes:102]
As of July 31, 2015, total unrecognized compensation expense related to our equity awards was $426 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.2 years.

[0001564590-15-007795:notes:103]
[same as prior period, unchanged from 0001564590-15-000944:notes:101]

[0001564590-15-007795:notes:104]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Income tax benefit associated with employee stock transactions |  | $ | 14 |  |  | $ | 43 |  |

[0001564590-15-007795:notes:105]
[same as prior period, unchanged from 0001564590-15-000944:notes:103]

[0001564590-15-007795:notes:106]
As of July 31, 2015, our Board of Directors has authorized the repurchase of up to $9.6 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management.

[0001564590-15-007795:notes:107]
The following table summarizes activity related to this program for the three months ended July 31, 2015 (in millions, except per share information):

[0001564590-15-007795:notes:108]
| Number of shares repurchased |  |  | 13 |  |
| Average price per share |  | $ | 32.35 |  |
| Aggregate purchase price |  | $ | 430 |  |
| Remaining authorization at end of period |  | $ | 2,030 |  |

[0001564590-15-007795:notes:109]
The aggregate purchase price of our stock repurchases for the three months ended July 31, 2015 consisted of $430 million of open market purchases, of which $376 million and $54 million was allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-15-007795:notes:110]
Since the May 13, 2003 inception of our stock repurchase program through July 31, 2015, we repurchased a total of 227 million shares of our common stock at an average price of $33.42 per share, for an aggregate purchase price of $7.6 billion.

[0001564590-15-007795:notes:111]
[same as prior period, unchanged from 0001564590-15-000944:notes:109]

[0001564590-15-007795:notes:112]
[same as prior period, unchanged from 0001564590-15-000944:notes:110]

[0001564590-15-007795:notes:113]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Dividends per share declared |  | $ | 0.180 |  |  | $ | 0.165 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 54 |  |  | $ | — |  |
| Dividend payments allocated to retained earnings |  | $ | — |  |  | $ | 53 |  |

[0001564590-15-007795:notes:114]
On August 19 2015, we declared a cash dividend of $0.18 per share of common stock, payable on October 21, 2015 to holders of record as of the close of business on October 9, 2015. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by the Company to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-15-007795:notes:115]
Retained Earnings (Accumulated Deficit)

[0001564590-15-007795:notes:116]
A reconciliation of retained earnings (accumulated deficit) for the three months ended July 31, 2015 is as follows (in millions):

[0001564590-15-007795:notes:117]
| Balance as of April 24, 2015 |  | $ | 53 |  |
| Net loss |  |  | (30 | ) |
| Repurchases of common stock |  |  | (54 | ) |
| Balance as of July 31, 2015 |  | $ | (31 | ) |

[0001564590-15-007795:notes:118]
Accumulated Other Comprehensive Income (Loss)

[0001564590-15-007795:notes:119]
Changes in accumulated other comprehensive income (loss) (AOCI) by component, net of tax, for the three months ended July 31, 2015 are summarized below (in millions):

[0001564590-15-007795:notes:120]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 24, 2015 |  | $ | (23 | ) |  | $ | (13 | ) |  | $ | 11 |  |  | $ | 1 |  |  | $ | (24 | ) |
| OCI before reclassifications, net of tax |  |  | (1 | ) |  |  | — |  |  |  | (9 | ) |  |  | (2 | ) |  |  | (12 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 2 |  |
| Total OCI |  |  | (1 | ) |  |  | 1 |  |  |  | (9 | ) |  |  | (1 | ) |  |  | (10 | ) |
| Balance as of July 31, 2015 |  | $ | (24 | ) |  | $ | (12 | ) |  | $ | 2 |  |  | $ | — |  |  | $ | (34 | ) |

[0001564590-15-007795:notes:121]
[same as prior period, unchanged from 0001564590-15-000944:notes:119]

[0001564590-15-007795:notes:122]
|  |  | Three Months Ended |  |  |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |
| Recognized losses on defined benefit obligations |  | $ | 1 |  |  | $ | — |  |  | Operating expenses |
| Realized losses on cash flow hedges |  |  | 1 |  |  |  | 2 |  |  | Net revenues |
| Total reclassifications |  | $ | 2 |  |  | $ | 2 |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-15-007795:notes:123]
[same as prior period, unchanged from 0001564590-15-000944:notes:121]

[0001564590-15-007795:notes:124]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of July 31, 2015 and April 24, 2015. We did not recognize any gains and losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-15-007795:notes:125]
The notional amount of our outstanding U.S. dollar equivalent foreign currency exchange forward contracts consisted of the following (in millions):

[0001564590-15-007795:notes:126]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 104 |  |  | $ | 94 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 134 |  |  | $ | 160 |  |
| Forward contracts purchased |  | $ | 290 |  |  | $ | 231 |  |

[0001564590-15-007795:notes:127]
The effect of derivative instruments designated as cash flow hedges recognized in net revenues on our condensed consolidated statements of operations is presented in the condensed consolidated statements of comprehensive income (loss) and Note 9 – Stockholders’ Equity.

[0001564590-15-007795:notes:128]
The effect of derivative instruments not designated as hedging instruments recognized in other income, net on our condensed consolidated statements of operations was as follows (in millions):

[0001564590-15-007795:notes:129]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
|  |  | Loss Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | (7 | ) |  | $ | (1 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-15-007795:notes:130]
[same as prior period, unchanged from 0001564590-15-000944:notes:128]

[0001564590-15-007795:notes:131]
In May 2015, we initiated a realignment designed to drive efficiency, eliminate cost and redirect resources to our highest return activities, resulting in a reduction of our global workforce of approximately 3%, as well as other restructuring related activities. We expect these activities to be substantially completed by the end of the second quarter of fiscal 2016, with no significant additional charges. Restructuring charges consisted primarily of employee severance-related costs.

[0001564590-15-007795:notes:132]
Activities related to this plan are summarized as follows (in millions):

[0001564590-15-007795:notes:133]
|  |  | Employee Severance Related Costs |  |  | Other |  |  | Total |  |
| Balance at beginning of period |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net charges |  |  | 26 |  |  |  | 1 |  |  |  | 27 |  |
| Cash payments |  |  | (11 | ) |  |  | — |  |  |  | (11 | ) |
| Balance at end of period |  | $ | 15 |  |  | $ | 1 |  |  | $ | 16 |  |

[0001564590-15-007795:notes:134]
The liability for our restructuring plan is included in accrued expenses in our condensed consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-15-007795:notes:135]
[same as prior period, unchanged from 0001564590-15-000944:notes:133]

[0001564590-15-007795:notes:136]
[same as prior period, unchanged from 0001564590-15-000944:notes:134]

[0001564590-15-007795:notes:137]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Effective tax rates |  |  | (36.4 | )% |  |  | 44.6 | % |

[0001564590-15-007795:notes:138]
Our effective tax rates reflect the impact of a significant amount of our earnings being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. In addition, our effective tax rates for the three months ended July 31, 2015 and July 25, 2014 were impacted by adjustments related to income tax audits as discussed below.

[0001564590-15-007795:notes:139]
In June 2015, the Internal Revenue Service (IRS) signed a closing agreement on transfer pricing arrangements for our fiscal 2008 to 2010 income tax returns. During the three months ended July 31, 2015, we recorded a discrete expense of $13 million attributable to the transfer pricing audit adjustments and related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-15-007795:notes:140]
In July 2014, the IRS completed the examination of our fiscal 2005 to 2007 income tax returns upon approval by the Joint Committee of Taxation. During the three months ended July 25, 2014, we recorded a discrete expense of $47 million attributable to the audit settlement and related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-15-007795:notes:141]
[same as prior period, unchanged from 0001564590-15-000944:notes:140]

[0001564590-15-007795:notes:142]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Balance at beginning of period |  | $ | 272 |  |  | $ | 236 |  |
| Additions based on tax positions related to the current year |  |  | 4 |  |  |  | 7 |  |
| Additions for tax positions of prior years |  |  | 19 |  |  |  | 99 |  |
| Decreases for tax positions of prior years |  |  | (5 | ) |  |  | (19 | ) |
| Settlements |  |  | (47 | ) |  |  | (46 | ) |
| Balance at end of period |  | $ | 243 |  |  | $ | 277 |  |

[0001564590-15-007795:notes:143]
As of July 31, 2015, we had $243 million of gross unrecognized tax benefits, of which $193 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $148 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-15-007795:notes:144]
We are currently undergoing federal income tax audits in the United States (U.S.) and several foreign tax jurisdictions. Transfer pricing calculations are key issues under audits in various jurisdictions, and are often subject to dispute and appeals. The IRS is currently auditing our fiscal 2008 to 2010 income tax returns. In June 2015, the IRS signed a closing agreement on transfer pricing arrangements for the audit period. We expect the IRS examination team to complete their field audit of remaining issues within the next twelve months. However, final resolution may occur beyond the next twelve months should we choose to appeal the IRS examination team’s audit findings. We expect the IRS field exam team to issue a formal Notice of Proposed Audit Adjustment on one issue under dispute in the second quarter of our fiscal year 2016. While we believe our tax returns reflect the correct tax treatment of the issue under dispute, no assurance can be given that the final tax outcome will not differ from our position. Such differences could potentially result in additional tax expense of up to $10 million.

[0001564590-15-007795:notes:145]
[same as prior period, unchanged from 0001564590-15-000944:notes:144]

[0001564590-15-007795:notes:146]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. Given the uncertainties involved in all tax audits, we estimate a potential decrease in our unrecognized tax benefit balance of up to $47 million may occur within the next 12 months associated with the potential settlements and statute lapses.

[0001564590-15-007795:notes:147]
On July 27, 2015, in Altera Corp. v. Commissioner, the U.S. Tax Court issued an opinion related to the treatment of stock-based compensation expense in an intercompany cost-sharing arrangement. A final decision has yet to be issued by the Tax Court due to other outstanding issues related to the case. At this time, the U.S. Department of the Treasury has not withdrawn the requirement to include stock-based compensation from its regulations. Due to the uncertainty surrounding the status of the current regulations, questions related to the scope of potential benefits, and the risk of the Tax Court’s decision being overturned upon appeal, we have not recorded any benefit as of July 31, 2015. We will continue to monitor ongoing developments and potential impacts to our financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001564590-15-007795:notes:148]
13. Net Income (Loss) per Share

[0001564590-15-007795:notes:149]
The following is a calculation of basic and diluted net income (loss) per share (in millions, except per share amounts):

[0001564590-15-007795:notes:150]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (30 | ) |  | $ | 88 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 304 |  |  |  | 323 |  |
| Dilutive impact of employee equity award plans |  |  | — |  |  |  | 6 |  |
| Shares used in diluted computation |  |  | 304 |  |  |  | 329 |  |
| Net Income (Loss) per Share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | (0.10 | ) |  | $ | 0.27 |  |
| Diluted |  | $ | (0.10 | ) |  | $ | 0.27 |  |

[0001564590-15-007795:notes:151]
We have excluded 31 million and 8 million weighted-average shares of common stock potentially issuable under employee equity award plans in the three months ended July 31, 2015 and July 25, 2014, respectively, from the diluted net income (loss) per share calculations as their effect would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-15-007795:notes:152]
[same as prior period, unchanged from 0001564590-15-000944:notes:151]

[0001564590-15-007795:notes:153]
[same as prior period, unchanged from 0001564590-15-000944:notes:152]

[0001564590-15-007795:notes:154]
[same as prior period, unchanged from 0001564590-15-000944:notes:153]

[0001564590-15-007795:notes:155]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| United States, Canada and Latin America (Americas) |  | $ | 745 |  |  | $ | 831 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 415 |  |  |  | 445 |  |
| Asia Pacific (APAC) |  |  | 175 |  |  |  | 213 |  |
| Net revenues |  | $ | 1,335 |  |  | $ | 1,489 |  |

[0001564590-15-007795:notes:156]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $665 million and $746 million during the three months ended July 31, 2015 and July 25, 2014, respectively.

[0001564590-15-007795:notes:157]
The majority of our assets, excluding cash, cash equivalents, short-term investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents and short-term investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0001564590-15-007795:notes:158]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| U.S. |  | $ | 395 |  |  | $ | 596 |  |
| International |  |  | 4,555 |  |  |  | 4,730 |  |
| Total |  | $ | 4,950 |  |  | $ | 5,326 |  |

[0001564590-15-007795:notes:159]
[same as prior period, unchanged from 0001564590-15-000944:notes:158]

[0001564590-15-007795:notes:160]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| U.S. |  | $ | 905 |  |  | $ | 927 |  |
| International |  |  | 106 |  |  |  | 103 |  |
| Total |  | $ | 1,011 |  |  | $ | 1,030 |  |

[0001564590-15-007795:notes:161]
[same as prior period, unchanged from 0001564590-15-000944:notes:160]

[0001564590-15-007795:notes:162]
|  |  | Three Months Ended |  |
|  |  | July 31, 2015 |  |  | July 25, 2014 |  |
| Arrow Electronics, Inc. |  |  | 22 | % |  |  | 22 | % |
| Avnet, Inc. |  |  | 18 | % |  |  | 16 | % |

[0001564590-15-007795:notes:163]
The following customers accounted for 10% or more of accounts receivable:

[0001564590-15-007795:notes:164]
|  |  | July 31, 2015 |  |  | April 24, 2015 |  |
| Arrow Electronics, Inc. |  | N/A |  |  |  | 14 | % |
| Avnet, Inc. |  |  | 11 | % |  |  | 16 | % |

[0001564590-15-007795:notes:165]
__________________

[0001564590-15-007795:notes:166]
N/A - Not Applicable


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-15-007795:notes:167]
15. Commitments and Contingencies

[0001564590-15-007795:notes:168]
Operating Leases

[0001564590-15-007795:notes:169]
We lease various equipment, vehicles and office space in the U.S. and internationally.

[0001564590-15-007795:notes:170]
Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $205 million as of July 31, 2015.

[0001564590-15-007795:notes:171]
Purchase Orders and Other Commitments

[0001564590-15-007795:notes:172]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of July 31, 2015, we had $262 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 31, 2015 and April 24, 2015, such liability amounted to $16 million and $17 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-15-007795:notes:173]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 31, 2015, we had $45 million in construction related obligations and $178 million in other purchase obligations.

[0001564590-15-007795:notes:174]
Financing Guarantees

[0001564590-15-007795:notes:175]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $42 million and $52 million, respectively, of receivables during the three months ended July 31, 2015 and July 25, 2014.

[0001564590-15-007795:notes:176]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-15-007795:notes:177]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance, and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of July 31, 2015 and April 24, 2015, the aggregate amount by which such contingencies exceeded the associated deferred revenue was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001564590-15-007795:notes:178]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 31, 2015, we have not been required to make any payments under these arrangements and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-15-007795:notes:179]
Legal Contingencies

[0001564590-15-007795:notes:180]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict, and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-15-007795:notes:181]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of July 31, 2015 related to such matters as they are not probable and/or reasonably estimable.
