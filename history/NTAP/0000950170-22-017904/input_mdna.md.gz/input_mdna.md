# NTAP MD&A — 0000950170-22-017904


## mdna

[0000950170-22-017904:mdna:1]
[same as prior period, unchanged from 0000950170-22-002669:mdna:1]

[0000950170-22-017904:mdna:2]
25

[0000950170-22-017904:mdna:3]
[same as prior period, unchanged from 0000950170-22-002669:mdna:3]

[0000950170-22-017904:mdna:4]
[same as prior period, unchanged from 0000950170-22-002669:mdna:4]

[0000950170-22-017904:mdna:5]
NetApp is a global cloud-led, data-centric software company that gives organizations the freedom to put data to work in the applications that elevate their business. We help our customers get the most out of their data with industry-leading public cloud services, and hybrid cloud solutions. Building on a rich history of innovation, we give customers the freedom to manage applications and data across hybrid multicloud environments. No matter where a customer’s data is or how the business uses it, NetApp helps to bring it together in a data fabric. For nearly three decades, NetApp has supported customers to accelerate their unique data fabrics and extend their workflows into a hybrid cloud environment with the right tools and right capabilities.

[0000950170-22-017904:mdna:6]
Our operations are organized into two segments: Hybrid Cloud and Public Cloud.

[0000950170-22-017904:mdna:7]
Hybrid Cloud offers a portfolio of storage management and infrastructure solutions that help customers recast their data centers with the power of cloud. This portfolio is designed to operate with public clouds to unlock the potential of hybrid, multi-cloud operations. We offer a broad portfolio of cloud-connected all-flash, hybrid-flash, and object storage systems, powered by intelligent data management software. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.

[0000950170-22-017904:mdna:8]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage and data services, and cloud operations services. Our enterprise-class solutions and services enable customers to control and manage storage in the cloud, consume high-performance storage services for primary workloads, and optimize cloud environments for cost and efficiency. These solutions and services are generally available on the leading public clouds, including Microsoft Azure, Google Cloud Platform and Amazon AWS.

[0000950170-22-017904:mdna:9]
Global Business Environment

[0000950170-22-017904:mdna:10]
Macroeconomic Conditions

[0000950170-22-017904:mdna:11]
Continuing global economic uncertainty, political conditions and fiscal challenges in the U.S. and abroad could result in adverse macroeconomic conditions, including inflation, slower growth or recession. In particular, during the first quarter of fiscal 2023, we continued to experience inflationary pressure and constraints in our supply chain.

[0000950170-22-017904:mdna:12]
Ongoing supply chain constraints, which substantially began to impact us in the second half of fiscal 2022, led to higher product component and freight costs in the first quarter of fiscal 2023 than incurred in the first quarter of fiscal 2022, and increased our cost of revenues. Supply chain constraints also delayed our ability to fulfill certain customer orders during the current quarter. Given the uncertainties that exist in the broader technology supply chain, we have continued to invest in inventory and certain longer-term commitments to help mitigate the impact of supply shortages.

[0000950170-22-017904:mdna:13]
If these macroeconomic uncertainties or supply chain challenges persist or worsen throughout the remainder of fiscal 2023, we may observe reduced customer demand for our offerings, increased competition for critical components, challenges fulfilling certain customer orders or continued increases in component and freight costs which could impact our operating results, including our ability to achieve historical levels of revenue growth.

[0000950170-22-017904:mdna:14]
[same as prior period, unchanged from 0000950170-22-002669:mdna:9]

[0000950170-22-017904:mdna:15]
The COVID-19 pandemic and efforts to control its spread have significantly curtailed the movement of people, goods and services worldwide, including in many of the regions in which we sell our products and services and conduct our business operations. We have taken precautionary measures intended to minimize the risk of the virus to our employees, our customers, and the communities in which we operate. Since March 2020, the vast majority of our employees have been working remotely and we have limited business travel.

[0000950170-22-017904:mdna:16]
[same as prior period, unchanged from 0000950170-22-002669:mdna:13]

[0000950170-22-017904:mdna:17]
Beginning in February 2022, in response to Russian military actions in Ukraine, the U.S. and other countries imposed sanctions on Russia, and we suspended business operations, including sales, support on existing contracts and professional services, in Russia and Belarus. The impact of these actions was not significant to our results for the first quarter of fiscal 2023. However, their ultimate magnitude and duration remain uncertain, and we will continue to closely monitor their potential impacts to our business.

[0000950170-22-017904:mdna:18]
The magnitude and duration of the disruption to our business, and impact to our operational and financial performance of the factors above remain uncertain. Refer to Part II, Item 1A. – Risk Factors for the significant risks we have identified related to the global business environment.

[0000950170-22-017904:mdna:19]
[same as prior period, unchanged from 0000950170-22-002669:mdna:15]

[0000950170-22-017904:mdna:20]
26

[0000950170-22-017904:mdna:21]
During the first three months of fiscal 2023, we repurchased 5 million shares of our common stock at an average price of $67.26 per share, for an aggregate of $350 million. We also declared aggregate cash dividends of $0.50 per share in that period, for which we paid $110 million.

[0000950170-22-017904:mdna:22]
[same as prior period, unchanged from 0000950170-22-002669:mdna:17]

[0000950170-22-017904:mdna:23]
On May 20, 2022, we acquired all the outstanding shares of privately-held Instaclustr, Inc., a leading platform provider of fully managed open-source database, pipeline and workflow applications delivered as-a-service, for approximately $498 million.

[0000950170-22-017904:mdna:24]
Restructuring Events

[0000950170-22-017904:mdna:25]
In the first quarter of fiscal 2023, we executed a restructuring plan to redirect resources to highest return activities, and also continued restructuring activities related to the establishment of an international headquarters in Cork, Ireland. Aggregate restructuring charges incurred under these two plans during the quarter totaled $11 million.

[0000950170-22-017904:mdna:26]
[same as prior period, unchanged from 0000950170-22-002669:mdna:20]

[0000950170-22-017904:mdna:27]
Our fiscal year is reported as a 52- or 53-week year that ends on the last Friday in April. Fiscal years 2023 and 2022, ending on April 28, 2023 and April 29, 2022, respectively, are each 52-week years, with 13 weeks in each of their quarters. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0000950170-22-017904:mdna:28]
[same as prior period, unchanged from 0000950170-22-002669:mdna:22]

[0000950170-22-017904:mdna:29]
|  |  | Three Months Ended |  |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  |
| Net revenues: |  |  |  |  |  |  |  |
| Product |  |  | 49 | % |  |  | 50 | % |  |
| Services |  |  | 51 |  |  |  | 50 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Cost of product |  |  | 25 |  |  |  | 23 |  |  |
| Cost of services |  |  | 9 |  |  |  | 9 |  |  |
| Gross profit |  |  | 66 |  |  |  | 69 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 29 |  |  |  | 31 |  |  |
| Research and development |  |  | 15 |  |  |  | 14 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | 1 |  |  |  | 2 |  |  |
| Acquisition-related expense |  |  | 1 |  |  |  | — |  |  |
| Total operating expenses |  |  | 50 |  |  |  | 51 |  |  |
| Income from operations |  |  | 16 |  |  |  | 17 |  |  |
| Other income (expense), net |  |  | 1 |  |  |  | (1 | ) |  |
| Income before income taxes |  |  | 17 |  |  |  | 16 |  |  |
| Provision for income taxes |  |  | 4 |  |  |  | 2 |  |  |
| Net income |  |  | 13 | % |  |  | 14 | % |  |

[0000950170-22-017904:mdna:30]
[same as prior period, unchanged from 0000950170-22-002669:mdna:24]

[0000950170-22-017904:mdna:31]
[same as prior period, unchanged from 0000950170-22-002669:mdna:25]

[0000950170-22-017904:mdna:32]
[same as prior period, unchanged from 0000950170-22-002669:mdna:26]

[0000950170-22-017904:mdna:33]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  | % Change |  |
| Net revenues |  | $ | 1,592 |  |  | $ | 1,458 |  |  |  | 9 | % |

[0000950170-22-017904:mdna:34]
The increase in net revenues for the first quarter of fiscal 2023 compared to the corresponding period of fiscal 2022 was due to an increase in both product revenues and services revenues. Product revenues as a percentage of net revenues decreased by less than one percentage point in the first quarter of fiscal 2023, compared to the corresponding period of fiscal 2022. Fluctuations in foreign

[0000950170-22-017904:mdna:35]
currency exchange rates adversely impacted net revenues percent growth by approximately four percentage points in the first quarter of fiscal 2023, compared to the corresponding period of fiscal 2022.

[0000950170-22-017904:mdna:36]
[same as prior period, unchanged from 0000950170-22-002669:mdna:29]

[0000950170-22-017904:mdna:37]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  | % Change |  |
| Product revenues |  | $ | 786 |  |  | $ | 730 |  |  |  | 8 | % |
| Hardware (Non-GAAP) |  |  | 310 |  |  |  | 316 |  |  |  | (2 | )% |
| Software (Non-GAAP) |  |  | 476 |  |  |  | 414 |  |  |  | 15 | % |

[0000950170-22-017904:mdna:38]
[same as prior period, unchanged from 0000950170-22-002669:mdna:31]

[0000950170-22-017904:mdna:39]
Product revenues consist of sales of configured all-flash array and hybrid systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, NetApp HCI, StorageGrid, OEM products and add-on optional software.

[0000950170-22-017904:mdna:40]
In order to provide visibility into the value created by our software innovation and R&D investment, we disclose the software and hardware components of our product revenues. Software product revenues include the operating system software and optional add-on software solutions attached to our systems across our entire product set, while hardware product revenues include the non-software component of our systems across the entire set. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, the hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0000950170-22-017904:mdna:41]
Total product revenues increased in the first quarter of fiscal 2023 compared to the corresponding period of the prior year, primarily driven by an increase in sales of all-flash array systems, despite an unfavorable impact from foreign exchange rate fluctuations.

[0000950170-22-017904:mdna:42]
Revenues from the hardware component of product revenues represented 39% of product revenues in the first quarter of fiscal 2023, compared to 43% of product revenues in the corresponding period of the prior year. The software component of product revenues represented 61% of product revenues in the first quarter of fiscal 2023, compared to 57% of product revenues in the corresponding period of the prior year. The increase in the software component percentage of product revenues in the first quarter of fiscal 2023 was primarily due to the mix of systems sold, including a higher mix of all-flash array systems, which contain a higher proportion of software components than other Hybrid Cloud products.

[0000950170-22-017904:mdna:43]
[same as prior period, unchanged from 0000950170-22-002669:mdna:37]

[0000950170-22-017904:mdna:44]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  | % Change |  |
| Services revenues |  | $ | 806 |  |  | $ | 728 |  |  |  | 11 | % |
| Support |  |  | 598 |  |  |  | 578 |  |  |  | 3 | % |
| Professional and other services |  |  | 76 |  |  |  | 71 |  |  |  | 7 | % |
| Public cloud |  |  | 132 |  |  |  | 79 |  |  |  | 67 | % |

[0000950170-22-017904:mdna:45]
[same as prior period, unchanged from 0000950170-22-002669:mdna:39]

[0000950170-22-017904:mdna:46]
[same as prior period, unchanged from 0000950170-22-002669:mdna:40]

[0000950170-22-017904:mdna:47]
Support revenues increased in the first quarter of fiscal 2023 compared to the corresponding period of the prior year, primarily due to growth in sales of all-flash systems (which carry a higher support dollar content than our other products) and a higher aggregate support contract value for our installed based in the current year.

[0000950170-22-017904:mdna:48]
Professional and other services revenues increased in the first quarter of fiscal 2023 compared to the corresponding period of the prior year primarily due to an increase in demand from increased product sales.

[0000950170-22-017904:mdna:49]
[same as prior period, unchanged from 0000950170-22-002669:mdna:43]

[0000950170-22-017904:mdna:50]
Public Cloud revenues are derived from the sale of public cloud offerings primarily delivered as-a-service, which include cloud storage and data services, and cloud operations services.

[0000950170-22-017904:mdna:51]
Public Cloud revenues increased in the first quarter of fiscal 2023 compared to the corresponding period of the prior year primarily due to strong customer demand for NetApp’s diversified cloud offerings, coupled with overall growth in the cloud market, and the acquisition of Instaclustr early in the first quarter of fiscal 2023 and CloudCheckr in the third quarter of fiscal 2022.

[0000950170-22-017904:mdna:52]
[same as prior period, unchanged from 0000950170-22-002669:mdna:46]

[0000950170-22-017904:mdna:53]
[same as prior period, unchanged from 0000950170-22-002669:mdna:47]

[0000950170-22-017904:mdna:54]
[same as prior period, unchanged from 0000950170-22-002669:mdna:49]

[0000950170-22-017904:mdna:55]
[same as prior period, unchanged from 0000950170-22-002669:mdna:50]

[0000950170-22-017904:mdna:56]
[same as prior period, unchanged from 0000950170-22-002669:mdna:51]

[0000950170-22-017904:mdna:57]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  | % Change |  |
| Cost of product revenues |  | $ | 397 |  |  | $ | 329 |  |  |  | 21 | % |
| Hybrid Cloud |  |  | 395 |  |  |  | 326 |  |  |  | 21 | % |
| Unallocated |  |  | 2 |  |  |  | 3 |  |  |  | (33 | )% |

[0000950170-22-017904:mdna:58]
[same as prior period, unchanged from 0000950170-22-002669:mdna:53]

[0000950170-22-017904:mdna:59]
Cost of Hybrid Cloud product revenues represented 50% of product revenues for the first quarter of fiscal 2023, compared to 45% for the first quarter of fiscal 2022. Materials costs represented 93% of cost of Hybrid Cloud product revenues for the first quarter of fiscal 2023, compared to 91% of the corresponding period of fiscal 2022.

[0000950170-22-017904:mdna:60]
Materials costs increased by approximately $57 million in the first quarter of fiscal 2023, compared to the corresponding period of the prior year, reflecting the increases in product revenues, the mix of systems sold, and higher component and freight costs as a result of COVID-19 related supply chain challenges.

[0000950170-22-017904:mdna:61]
Hybrid Cloud product gross margins decreased by approximately six percentage points in the first quarter of fiscal 2023 compared to the corresponding period of the prior year, primarily due to the increase in component and freight costs and, to a lesser extent, the adverse impact of fluctuations in foreign currency exchange rates. These decreases were partially offset by the mix of systems sold, including a higher mix of all-flash array systems which have higher margins than hybrid systems.

[0000950170-22-017904:mdna:62]
[same as prior period, unchanged from 0000950170-22-002669:mdna:57]

[0000950170-22-017904:mdna:63]
Unallocated cost of product revenues was relatively flat in the first quarter of fiscal 2023 compared to the corresponding period of the prior year.

[0000950170-22-017904:mdna:64]
[same as prior period, unchanged from 0000950170-22-002669:mdna:59]

[0000950170-22-017904:mdna:65]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  | % Change |  |
| Cost of services revenues |  | $ | 149 |  |  | $ | 130 |  |  |  | 15 | % |
| Support |  |  | 43 |  |  |  | 48 |  |  |  | (10 | )% |
| Professional and other services |  |  | 52 |  |  |  | 51 |  |  |  | 2 | % |
| Public cloud |  |  | 40 |  |  |  | 23 |  |  |  | 74 | % |
| Unallocated |  |  | 14 |  |  |  | 8 |  |  |  | 75 | % |

[0000950170-22-017904:mdna:66]
[same as prior period, unchanged from 0000950170-22-002669:mdna:61]

[0000950170-22-017904:mdna:67]
[same as prior period, unchanged from 0000950170-22-002669:mdna:2]

[0000950170-22-017904:mdna:68]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, decreased in the first quarter of fiscal 2023 compared to the corresponding period of fiscal 2022. Cost of Hybrid Cloud services revenues represented 14% of Hybrid Cloud services revenues in the first quarter of fiscal 2023, compared to 15% of the corresponding period of fiscal 2022.

[0000950170-22-017904:mdna:69]
Hybrid Cloud support gross margins increased by one percentage point in the first quarter of fiscal 2023 compared to the corresponding period of the prior year due to growth in support revenues achieved with a slightly reduced cost base resulting from  operational efficiencies. Hybrid Cloud professional services gross margins increased by three percentage points in the first quarter of fiscal 2023 compared to the corresponding period of the prior year due to the mix of services provided.

[0000950170-22-017904:mdna:70]
[same as prior period, unchanged from 0000950170-22-002669:mdna:64]

[0000950170-22-017904:mdna:71]
Cost of Public Cloud revenues increased in the first quarter of fiscal 2023 compared to the corresponding period of fiscal 2022 reflecting the increase in Public Cloud revenues. Public Cloud gross margins decreased by one percentage point in the first quarter of fiscal 2023, compared to the corresponding period of fiscal 2022, primarily due to the mix of offerings provided.

[0000950170-22-017904:mdna:72]
[same as prior period, unchanged from 0000950170-22-002669:mdna:66]

[0000950170-22-017904:mdna:73]
Unallocated cost of services revenues increased in the first quarter of fiscal 2023 compared to the corresponding period of the prior year due to our acquisitions of Instaclustr in the first quarter of fiscal 2023 and CloudCheckr in the third quarter of fiscal 2022, which resulted in higher amortization expense from acquired intangible assets.

[0000950170-22-017904:mdna:74]
[same as prior period, unchanged from 0000950170-22-002669:mdna:68]

[0000950170-22-017904:mdna:75]
[same as prior period, unchanged from 0000950170-22-002669:mdna:69]

[0000950170-22-017904:mdna:76]
Sales and marketing, research and development, and general and administrative expenses for the first quarter of fiscal 2023 totaled $770 million, or 48% of net revenues, reflecting a decrease of two percentage points, compared to the corresponding period of fiscal 2022, primarily as a result of scaling our cost structure as revenues grow. While net revenues were adversely impacted by fluctuations in foreign currency exchange rates in the first quarter of fiscal 2023 compared to the first quarter of fiscal 2022, operating expenses were favorably impacted.

[0000950170-22-017904:mdna:77]
[same as prior period, unchanged from 0000950170-22-002669:mdna:71]

[0000950170-22-017904:mdna:78]
Total compensation costs included in operating expenses increased by $56 million, or 13%, in the first quarter of fiscal 2023 compared to the corresponding period of the prior year, primarily as a result of a 9% increase in average headcount.

[0000950170-22-017904:mdna:79]
[same as prior period, unchanged from 0000950170-22-002669:mdna:74]

[0000950170-22-017904:mdna:80]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 458 |  |  | $ | 451 |  |  |  | 2 | % |

[0000950170-22-017904:mdna:81]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, facilities and IT support costs, advertising and marketing promotional expense and travel and entertainment expense. The changes in sales and marketing expenses consisted of the following (in percentage points of the total change):

[0000950170-22-017904:mdna:82]
|  |  |  | Three Months Ended |  |
|  |  |  | Fiscal 2023 to Fiscal 2022 |  |
| Compensation costs |  |  |  | 5 |  |
| Commissions |  |  |  | (3 | ) |
| Travel and entertainment |  |  |  | 1 |  |
| Other |  |  |  | (1 | ) |
| Total change |  |  |  | 2 |  |

[0000950170-22-017904:mdna:83]
The increase in compensation costs for the first quarter of fiscal 2023 compared to the corresponding period of the prior year reflected an increase in average headcount of approximately 8%. The expansion of our sales and marketing teams are expected to support our ability to execute on key market opportunities.

[0000950170-22-017904:mdna:84]
The decrease in commissions expense for the first quarter of fiscal 2023 compared to the corresponding period of the prior year was primarily due to lower performance against sales goals.

[0000950170-22-017904:mdna:85]
Travel and entertainment expense increased in the first quarter of fiscal 2023 compared to the corresponding period of the prior year as COVID-19 related travel restrictions eased.

[0000950170-22-017904:mdna:86]
[same as prior period, unchanged from 0000950170-22-002669:mdna:81]

[0000950170-22-017904:mdna:87]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  | % Change |  |
| Research and development expenses |  | $ | 240 |  |  | $ | 210 |  |  |  | 14 | % |

[0000950170-22-017904:mdna:88]
Research and development expenses consist primarily of compensation costs, facilities and IT support costs, depreciation, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs. Changes in research and development expense consisted of the following (in percentage points of the total change):

[0000950170-22-017904:mdna:89]
|  |  |  | Three Months Ended |  |
|  |  |  | Fiscal 2023 to Fiscal 2022 |  |
| Compensation costs |  |  |  | 14 |  |
| Development projects and outside services |  |  |  | 2 |  |
| Other |  |  |  | (2 | ) |
| Total change |  |  |  | 14 |  |

[0000950170-22-017904:mdna:90]
The increase in compensation costs for the first quarter of fiscal 2023 compared to the corresponding period in the prior year was primarily attributable to an increase in average headcount of 12%. The expansion of our research and development teams are expected to support our ability to continue expanding and enhancing our portfolio offerings. The increase in development projects and outside services for the first quarter of fiscal 2023 compared to the corresponding period in the prior year was primarily due to the higher spending on certain engineering projects.

[0000950170-22-017904:mdna:91]
[same as prior period, unchanged from 0000950170-22-002669:mdna:86]

[0000950170-22-017904:mdna:92]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  | % Change |  |
| General and administrative expenses |  | $ | 72 |  |  | $ | 66 |  |  |  | 9 | % |

[0000950170-22-017904:mdna:93]
[same as prior period, unchanged from 0000950170-22-002669:mdna:88]

[0000950170-22-017904:mdna:94]
|  |  |  | Three Months Ended |  |
|  |  |  | Fiscal 2023 to Fiscal 2022 |  |
| Compensation costs |  |  |  | 8 |  |
| Professional and legal fees and outside services |  |  |  | 4 |  |
| Facilities and IT support costs |  |  |  | (2 | ) |
| Other |  |  |  | (1 | ) |
| Total change |  |  |  | 9 |  |

[0000950170-22-017904:mdna:95]
The increase in compensation costs in the first quarter of fiscal 2023 compared to the corresponding period of the prior year was primarily attributable to an increase in average headcount of 9%. The increase in professional and legal fees and outside services expense in the first quarter of fiscal 2023 was primarily due to higher spending on business transformation projects and an increase in legal fees. The decrease in facilities and IT support costs was primarily due to lower spending levels on IT projects.

[0000950170-22-017904:mdna:96]
[same as prior period, unchanged from 0000950170-22-002669:mdna:91]

[0000950170-22-017904:mdna:97]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  | % Change |  |
| Restructuring charges |  | $ | 11 |  |  | $ | 22 |  |  |  | (50 | )% |

[0000950170-22-017904:mdna:98]
In the first quarter of fiscal 2023, we executed a restructuring plan to redirect resources to highest return activities, which included a reduction in our global workforce of less than 1%, and consisted primarily of employee severance-related costs. We also continued

[0000950170-22-017904:mdna:99]
[same as prior period, unchanged from 0000950170-22-002669:mdna:32]

[0000950170-22-017904:mdna:100]
restructuring activities related to the establishment of an international headquarters in Cork, Ireland, for which we incurred charges primarily for legal and tax-related consulting.

[0000950170-22-017904:mdna:101]
[same as prior period, unchanged from 0000950170-22-002669:mdna:95]

[0000950170-22-017904:mdna:102]
|  |  | Three Months Ended |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  | % Change |
| Acquisition-related expense |  | $ | 10 |  |  | $ | 1 |  |  | NM |

[0000950170-22-017904:mdna:103]
[same as prior period, unchanged from 0000950170-22-002669:mdna:93]

[0000950170-22-017904:mdna:104]
Acquisition-related expenses, primarily legal and consulting fees, totaled $10 million in the first quarter of fiscal 2023 and were primarily related to our acquisition of Instaclustr, Inc.

[0000950170-22-017904:mdna:105]
Other Income (Expense), Net (in millions, except percentages)

[0000950170-22-017904:mdna:106]
The components of other income (expense), net were as follows:

[0000950170-22-017904:mdna:107]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  | % Change |  |
| Interest income |  | $ | 7 |  |  | $ | 2 |  |  |  | 250 | % |
| Interest expense |  |  | (18 | ) |  |  | (18 | ) |  |  | — | % |
| Other, net |  |  | 26 |  |  |  | 4 |  |  |  | 550 | % |
| Total |  | $ | 15 |  |  | $ | (12 | ) |  | NM |  |

[0000950170-22-017904:mdna:108]
[same as prior period, unchanged from 0000950170-22-002669:mdna:97]

[0000950170-22-017904:mdna:109]
Interest income increased in the first quarter of fiscal 2023 compared to the corresponding period of the prior year due primarily to higher yields earned on our cash and investments. Interest expense remained flat in the first quarter of fiscal 2023 compared to the corresponding period of fiscal 2022.

[0000950170-22-017904:mdna:110]
In the first quarter of fiscal 2023, Other, net includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million. The remaining differences in Other, net for the first quarter of fiscal 2022 as compared to the corresponding period of the prior year are partially due to foreign exchange gains and losses year-over-year.

[0000950170-22-017904:mdna:111]
[same as prior period, unchanged from 0000950170-22-002669:mdna:104]

[0000950170-22-017904:mdna:112]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  | % Change |  |
| Provision for income taxes |  | $ | 56 |  |  | $ | 35 |  |  |  | 60 | % |

[0000950170-22-017904:mdna:113]
Our effective tax rate for the first quarter of fiscal 2023 was 21% compared to 15% for the first quarter of fiscal 2022. Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. Our effective tax rate for the first quarter of fiscal 2023 increased from the prior year primarily due to the capitalization of research and development expenses. Under the Tax Cuts and Jobs Act of 2017, costs incurred beginning in our fiscal 2023 are to be amortized over five or 15 years depending on where the research activities are conducted. Additionally, our effective tax rate for the first quarter of fiscal 2023 includes the impact of discrete benefits related to stock-based compensation. The effective tax rate for the first quarter of fiscal 2022 includes the impact of discrete tax benefits for lapses of statute of limitations as well as larger benefits related to stock-based compensation as compared to the current year.

[0000950170-22-017904:mdna:114]
As of July 29, 2022, we had $224 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $137 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $137 million have been recorded in other long-term liabilities.

[0000950170-22-017904:mdna:115]
[same as prior period, unchanged from 0000950170-22-002669:mdna:110]

[0000950170-22-017904:mdna:116]
| (In millions, except percentages) |  | July 29, 2022 |  |  | April 29, 2022 |  |
| Cash, cash equivalents and short-term investments |  | $ | 3,439 |  |  | $ | 4,134 |  |
| Principal amount of debt |  | $ | 2,650 |  |  | $ | 2,650 |  |

[0000950170-22-017904:mdna:117]
[same as prior period, unchanged from 0000950170-22-002669:mdna:112]

[0000950170-22-017904:mdna:118]
|  |  | Three Months Ended |  |
| (In millions) |  | July 29, 2022 |  |  | July 30, 2021 |  |
| Net cash provided by operating activities |  | $ | 281 |  |  | $ | 242 |  |
| Net cash used in investing activities |  |  | (628 | ) |  |  | (54 | ) |
| Net cash used in financing activities |  |  | (459 | ) |  |  | (218 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (18 | ) |  |  | (5 | ) |
| Net change in cash, cash equivalents and restricted cash |  | $ | (824 | ) |  | $ | (35 | ) |

[0000950170-22-017904:mdna:119]
[same as prior period, unchanged from 0000950170-22-002669:mdna:114]

[0000950170-22-017904:mdna:120]
As of July 29, 2022, our cash, cash equivalents and short-term investments were $3.4 billion, which represents a decrease of $695 million for the first quarter of fiscal 2023. The decrease was primarily due to $491 million, net of cash acquired, used for the acquisition of a privately-held company, $350 million paid for the repurchase of our common stock, and $110 million used for the payment of dividends, partially offset by $281 million provided by operating activities. Net working capital was $1.3 billion as of July 29, 2022, a reduction of $645 million when compared to April 29, 2022 primarily due to the decreases in cash, cash equivalents and short-term investments discussed above.

[0000950170-22-017904:mdna:121]
[same as prior period, unchanged from 0000950170-22-002669:mdna:116]

[0000950170-22-017904:mdna:122]
During the first three months of fiscal 2023, we generated cash from operating activities of $281 million, reflecting net income of $214 million, adjusted by non-cash depreciation and amortization of $58 million and non-cash stock-based compensation expense of $67 million, compared to $242 million of cash generated from operating activities during the first three months of fiscal 2022.

[0000950170-22-017904:mdna:123]
Significant changes in assets and liabilities in the first three months of fiscal 2023 included the following:

[0000950170-22-017904:mdna:124]
•
Accounts receivable decreased $364 million, reflecting more favorable shipping linearity and typical lower billings in the first quarter of fiscal 2023 compared to the fourth quarter of fiscal 2022.

[0000950170-22-017904:mdna:125]
•
Accrued expenses decreased by $208 million, primarily due to employee compensation payouts related to fiscal year 2022  incentive compensation and commissions plans.

[0000950170-22-017904:mdna:126]
•
Accounts payable decreased by $90 million, reflecting typical lower purchases and the timing of payments to our suppliers in the first quarter of fiscal 2023 compared to the fourth quarter of fiscal 2022.

[0000950170-22-017904:mdna:127]
We expect that cash provided by operating activities may materially fluctuate in future periods due to a number of factors, including fluctuations in our operating results, shipping linearity, accounts receivable collections performance, inventory and supply chain management, vendor payment initiatives, tax benefits or charges from stock-based compensation, and the timing and amount of compensation and other payments.

[0000950170-22-017904:mdna:128]
[same as prior period, unchanged from 0000950170-22-002669:mdna:122]

[0000950170-22-017904:mdna:129]
During the first three months of fiscal 2023, we used $131 million for the purchases of investments, net of maturities and sales, and paid $65 million for capital expenditures, as compared to the same period of fiscal 2022, in which we generated $11 million from maturities and sales of investments, net of purchases, and paid $51 million for capital expenditures. During the first three months of fiscal 2023, we paid approximately $491 million, net of cash acquired for a privately-held company, as compared to $14 million, net of cash acquired, that we paid for a privately-held company in the first three months of fiscal 2022. Additionally, we received proceeds of $59 million from the sale of one of our minority investments.

[0000950170-22-017904:mdna:130]
[same as prior period, unchanged from 0000950170-22-002669:mdna:124]

[0000950170-22-017904:mdna:131]
During the first three months of fiscal 2023, cash flows used in financing activities totaled $459 million and include $350 million for the repurchase of approximately 5.2 million shares of common stock and $110 million for the payment of dividends. During the first three months of fiscal 2022, cash flows used in financing activities totaled $218 million and included $100 million for the repurchase of 1.2 million shares of common stock and $112 million for the payment of dividends.

[0000950170-22-017904:mdna:132]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including cash, cash equivalents and short-term investments, cash generated from operations, and our ability to access capital markets and committed credit lines will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all. For further discussion of factors that could affect our cash flows and liquidity requirements, including the impact of the COVID-19 pandemic, see Part II, Item 1A. Risk Factors.

[0000950170-22-017904:mdna:133]
[same as prior period, unchanged from 0000950170-22-002669:mdna:127]

[0000950170-22-017904:mdna:134]
Our principal sources of liquidity as of July 29, 2022 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-22-017904:mdna:135]
[same as prior period, unchanged from 0000950170-22-002669:mdna:129]

[0000950170-22-017904:mdna:136]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| Cash and cash equivalents |  | $ | 3,288 |  |  | $ | 4,112 |  |
| Short-term investments |  |  | 151 |  |  |  | 22 |  |
| Total |  | $ | 3,439 |  |  | $ | 4,134 |  |

[0000950170-22-017904:mdna:137]
As of July 29, 2022 and April 29, 2022, $2.0 billion and $2.3 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $1.4 billion and $1.8 billion, respectively, were available in the U.S.

[0000950170-22-017904:mdna:138]
[same as prior period, unchanged from 0000950170-22-002669:mdna:132]

[0000950170-22-017904:mdna:139]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of July 29, 2022.

[0000950170-22-017904:mdna:140]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. We also have an automatic shelf registration statement on file with the U.S. Securities and Exchange Commission (SEC). We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0000950170-22-017904:mdna:141]
[same as prior period, unchanged from 0000950170-22-002669:mdna:135]

[0000950170-22-017904:mdna:142]
The following table summarizes the principal amount of our Senior Notes as of July 29, 2022 (in millions):

[0000950170-22-017904:mdna:143]
| 3.25% Senior Notes Due December 2022 |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,650 |  |

[0000950170-22-017904:mdna:144]
[same as prior period, unchanged from 0000950170-22-002669:mdna:138]

[0000950170-22-017904:mdna:145]
In August 2022, we called for redemption of the aggregate principal amount of 3.25% Senior Notes due December 2022. The aggregate redemption price to be paid is $252 million, comprised of the principal amount of the notes and accrued interest. The redemption date is September 15, 2022.

[0000950170-22-017904:mdna:146]
Commercial Paper Program and Credit Facility

[0000950170-22-017904:mdna:147]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of July 29, 2022.

[0000950170-22-017904:mdna:148]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of July 29, 2022, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-22-017904:mdna:149]
[same as prior period, unchanged from 0000950170-22-002669:mdna:142]

[0000950170-22-017904:mdna:150]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2023 to be between $200 million and $300 million.

[0000950170-22-017904:mdna:151]
[same as prior period, unchanged from 0000950170-22-002669:mdna:144]

[0000950170-22-017904:mdna:152]
On August 22, 2022, we declared a cash dividend of $0.50 per share of common stock, payable on October 26, 2022 to holders of record as of the close of business on October 7, 2022.

[0000950170-22-017904:mdna:153]
As of July 29, 2022, our Board of Directors had authorized the repurchase of up to $15.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through July 29, 2022, we repurchased a total of 352 million shares of our common stock at an average price of $40.35 per share, for an aggregate purchase price of $14.2 billion. As of July 29, 2022, the remaining authorized amount for stock repurchases under this program was $0.9 billion.

[0000950170-22-017904:mdna:154]
[same as prior period, unchanged from 0000950170-22-002669:mdna:147]

[0000950170-22-017904:mdna:155]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled approximately $1.2 billion at July 29, 2022.

[0000950170-22-017904:mdna:156]
[same as prior period, unchanged from 0000950170-22-002669:mdna:149]

[0000950170-22-017904:mdna:157]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $3 million and $17 million of receivables during the first three months of fiscal 2023 and fiscal 2022, respectively.

[0000950170-22-017904:mdna:158]
35

[0000950170-22-017904:mdna:159]
[same as prior period, unchanged from 0000950170-22-002669:mdna:151]

[0000950170-22-017904:mdna:160]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of July 29, 2022 and April 29, 2022, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-22-017904:mdna:161]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of July 29, 2022, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-22-017904:mdna:162]
Legal Contingencies

[0000950170-22-017904:mdna:163]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 15 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0000950170-22-017904:mdna:164]
[same as prior period, unchanged from 0000950170-22-002669:mdna:156]

[0000950170-22-017904:mdna:165]
Our condensed consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (GAAP), which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and liabilities. Our estimates are based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, including the ongoing COVID-19 pandemic, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0000950170-22-017904:mdna:166]
The summary of significant accounting policies is included under Item 7 – Management’s Discussion and Analysis of Financial Condition and Results of Operations of our fiscal 2022 Form 10-K. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. There have been no material changes to the critical accounting policies and estimates as filed in such report.
