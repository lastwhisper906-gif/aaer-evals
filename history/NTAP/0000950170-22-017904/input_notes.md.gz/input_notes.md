# NTAP notes — 0000950170-22-017904


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000950170-22-017904:notes:1]
[same as prior period, unchanged from 0000950170-22-002669:notes:1]

[0000950170-22-017904:notes:2]
[same as prior period, unchanged from 0000950170-22-002669:notes:2]

[0000950170-22-017904:notes:3]
[same as prior period, unchanged from 0000950170-22-002669:notes:3]

[0000950170-22-017904:notes:4]
Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal years 2023 and 2022, ending on April 28, 2023, and April 29, 2022, respectively, are each 52-week years, with 13 weeks in each quarter.

[0000950170-22-017904:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 29, 2022 contained in our Annual Report on Form 10-K. The results of operations for the three months ended July 29, 2022 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0000950170-22-017904:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates. Management’s estimates include, as applicable, the anticipated impacts of the COVID-19 pandemic.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000950170-22-017904:notes:7]
2. Recent Accounting Pronouncements

[0000950170-22-017904:notes:8]
Although there are new accounting pronouncements issued or proposed by the FASB that we have adopted or will adopt, as applicable, we do not believe any of these accounting pronouncements had or will have a material impact on our consolidated financial position, operating results, cash flows or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-22-017904:notes:9]
[same as prior period, unchanged from 0000950170-22-002669:notes:15]

[0000950170-22-017904:notes:10]
Fiscal 2023 Acquisition

[0000950170-22-017904:notes:11]
Instaclustr Inc. Acquisition

[0000950170-22-017904:notes:12]
On May 20, 2022, we acquired all the outstanding shares of privately-held Instaclustr Inc., (Instaclustr) for approximately $498 million. Instaclustr is a leading platform provider of fully managed open-source database, pipeline and workflow applications delivered as-a-service.

[0000950170-22-017904:notes:13]
The preliminary acquisition-date values of the assets acquired and liabilities assumed are as follows (in millions):

[0000950170-22-017904:notes:14]
|  |  | Amount |  |
| Cash |  | $ | 4 |  |
| Intangible assets |  |  | 107 |  |
| Goodwill |  |  | 421 |  |
| Other assets |  |  | 15 |  |
| Total assets acquired |  |  | 547 |  |
| Liabilities assumed |  |  | (49 | ) |
| Total purchase price |  | $ | 498 |  |

[0000950170-22-017904:notes:15]
[same as prior period, unchanged from 0000950170-22-002669:notes:21]

[0000950170-22-017904:notes:16]
|  |  | Amount |  |  | Estimated useful life(years) |  |
| Developed technology |  | $ | 55 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 50 |  |  |  | 5 |  |
| Trade name |  |  | 2 |  |  |  | 3 |  |
| Total intangible assets |  | $ | 107 |  |  |  |  |

[0000950170-22-017904:notes:17]
The acquired net assets and assumed debt of Instaclustr were recorded at their estimated values. We determined the estimated values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expect to realize revenue synergies and anticipate opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated value of their identifiable net assets acquired, and as a result, we have recorded goodwill in connection with the acquisition. The goodwill is not deductible for income tax purposes.

[0000950170-22-017904:notes:18]
The results of operations related to the acquisition of Instaclustr have been included in our condensed consolidated statements of income from the acquisition date. Pro forma results of operations have not been presented because the impact from the acquisition was not material to our consolidated results of operations.

[0000950170-22-017904:notes:19]
[same as prior period, unchanged from 0000950170-22-002669:notes:16]

[0000950170-22-017904:notes:20]
Fylamynt Acquisition

[0000950170-22-017904:notes:21]
On February 18, 2022, we acquired all the outstanding shares of privately-held NeurOps Inc. (which operated under the name "Fylamynt") for approximately $27 million in cash, of which $22 million was paid at closing. The purchase price includes $5 million related to an indemnity holdback provision, of which $4 million is expected to be paid within 12 months from the acquisition date. Fylamynt is an innovative CloudOps automation technology company that enables customers to build, run, manage and analyze workflows securely in any cloud with little to no code.

[0000950170-22-017904:notes:22]
The preliminary acquisition-date values of the assets acquired are as follows (in millions):

[0000950170-22-017904:notes:23]
|  |  | Amount |  |
| Cash |  | $ | 1 |  |
| Developed technology |  |  | 6 |  |
| Goodwill |  |  | 20 |  |
| Total assets acquired |  |  | 27 |  |
| Total purchase price |  | $ | 27 |  |

[0000950170-22-017904:notes:24]
CloudCheckr Acquisition

[0000950170-22-017904:notes:25]
On November 5, 2021, we acquired all the outstanding shares of privately-held CloudCheckr Inc. (CloudCheckr) for approximately $347 million in cash. CloudCheckr is a leading cloud optimization platform that provides cloud visibility and insights to lower costs, maintain security and compliance, and optimize cloud resources.

[0000950170-22-017904:notes:26]
The acquisition-date values of the assets acquired and liabilities assumed are as follows (in millions):

[0000950170-22-017904:notes:27]
|  |  | Amount |  |
| Cash |  | $ | 2 |  |
| Intangible assets |  |  | 76 |  |
| Goodwill |  |  | 276 |  |
| Other assets |  |  | 6 |  |
| Total assets acquired |  |  | 360 |  |
| Liabilities assumed |  |  | (13 | ) |
| Total purchase price |  | $ | 347 |  |

[0000950170-22-017904:notes:28]
[same as prior period, unchanged from 0000950170-22-002669:notes:22]

[0000950170-22-017904:notes:29]
Data Mechanics Acquisition

[0000950170-22-017904:notes:30]
[same as prior period, unchanged from 0000950170-22-002669:notes:24]

[0000950170-22-017904:notes:31]
[same as prior period, unchanged from 0000950170-22-002669:notes:25]

[0000950170-22-017904:notes:32]
The acquired assets and assumed liabilities of Fylamynt, CloudCheckr and Data Mechanics were recorded at their estimated values. We determined the estimated values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expect to realize incremental revenue by offering continuous cost optimization and managed services from our existing capabilities to help customers improve their cloud resources and realize the benefits of cloud faster and at scale. We also anticipate opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated fair value of their identifiable net assets acquired, and as a result, we have recorded goodwill in connection with these acquisitions. The goodwill is not deductible for income tax purposes.

[0000950170-22-017904:notes:33]
The results of operations related to the acquisitions of Fylamynt, CloudCheckr and Data Mechanics have been included in our consolidated statements of income from their respective acquisition dates. Pro forma results of operations have not been presented because the impact from these acquisitions was not material to our consolidated results of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-22-017904:notes:34]
[same as prior period, unchanged from 0000950170-22-002669:notes:40]

[0000950170-22-017904:notes:35]
[same as prior period, unchanged from 0000950170-22-002669:notes:41]

[0000950170-22-017904:notes:36]
|  |  | Amount |  |
| Balance as of April 29, 2022 |  | $ | 2,346 |  |
| Additions |  |  | 421 |  |
| Balance as of July 29, 2022 |  | $ | 2,767 |  |

[0000950170-22-017904:notes:37]
The goodwill addition of $421 million related to the acquisition of Instaclustr has been allocated to our Public Cloud segment.

[0000950170-22-017904:notes:38]
Goodwill by reportable segment as of July 29, 2022 is as follows (in millions):

[0000950170-22-017904:notes:39]
|  |  | Amount |  |
| Hybrid Cloud |  | $ | 1,714 |  |
| Public Cloud |  |  | 1,053 |  |
| Total goodwill |  | $ | 2,767 |  |

[0000950170-22-017904:notes:40]
[same as prior period, unchanged from 0000950170-22-002669:notes:47]

[0000950170-22-017904:notes:41]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 212 |  |  | $ | (76 | ) |  | $ | 136 |  |  | $ | 157 |  |  | $ | (65 | ) |  | $ | 92 |  |
| Customer contracts/relationships |  |  | 118 |  |  |  | (25 | ) |  |  | 93 |  |  |  | 68 |  |  |  | (20 | ) |  |  | 48 |  |
| Other purchased intangibles |  |  | 6 |  |  |  | (3 | ) |  |  | 3 |  |  |  | 4 |  |  |  | (2 | ) |  |  | 2 |  |
| Total purchased intangible assets |  | $ | 336 |  |  | $ | (104 | ) |  | $ | 232 |  |  | $ | 229 |  |  | $ | (87 | ) |  | $ | 142 |  |

[0000950170-22-017904:notes:42]
[same as prior period, unchanged from 0000950170-22-002669:notes:50]

[0000950170-22-017904:notes:43]
|  |  | Three Months Ended |  |  | Statements of |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  | IncomeClassification |
| Developed technology |  | $ | 10 |  |  | $ | 7 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 6 |  |  |  | 1 |  |  | Operating expenses |
| Other purchased intangibles |  |  | 1 |  |  |  | 1 |  |  | Operating expenses |
| Total |  | $ | 17 |  |  | $ | 9 |  |  |  |

[0000950170-22-017904:notes:44]
As of July 29, 2022, future amortization expense related to purchased intangible assets is as follows (in millions):

[0000950170-22-017904:notes:45]
| Fiscal Year |  | Amount |  |
| 2023 (remainder) |  | $ | 51 |  |
| 2024 |  |  | 57 |  |
| 2025 |  |  | 55 |  |
| 2026 |  |  | 39 |  |
| 2027 |  |  | 29 |  |
| 2028 |  |  | 1 |  |
| Total |  | $ | 232 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-22-017904:notes:46]
[same as prior period, unchanged from 0000950170-22-002669:notes:54]

[0000950170-22-017904:notes:47]
Cash and cash equivalents (in millions):

[0000950170-22-017904:notes:48]
[same as prior period, unchanged from 0000950170-22-002669:notes:56]

[0000950170-22-017904:notes:49]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| Cash and cash equivalents |  | $ | 3,288 |  |  | $ | 4,112 |  |
| Restricted cash |  |  | 7 |  |  |  | 7 |  |
| Cash, cash equivalents and restricted cash |  | $ | 3,295 |  |  | $ | 4,119 |  |

[0000950170-22-017904:notes:50]
[same as prior period, unchanged from 0000950170-22-002669:notes:58]

[0000950170-22-017904:notes:51]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| Purchased components |  | $ | 145 |  |  | $ | 131 |  |
| Finished goods |  |  | 87 |  |  |  | 73 |  |
| Inventories |  | $ | 232 |  |  | $ | 204 |  |

[0000950170-22-017904:notes:52]
[same as prior period, unchanged from 0000950170-22-002669:notes:60]

[0000950170-22-017904:notes:53]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 354 |  |  |  | 353 |  |
| Leasehold improvements |  |  | 93 |  |  |  | 92 |  |
| Computer, production, engineering and other equipment |  |  | 944 |  |  |  | 904 |  |
| Computer software |  |  | 321 |  |  |  | 316 |  |
| Furniture and fixtures |  |  | 77 |  |  |  | 76 |  |
| Construction-in-progress |  |  | 67 |  |  |  | 65 |  |
|  |  |  | 1,902 |  |  |  | 1,852 |  |
| Accumulated depreciation and amortization |  |  | (1,280 | ) |  |  | (1,250 | ) |
| Property and equipment, net |  | $ | 622 |  |  | $ | 602 |  |

[0000950170-22-017904:notes:54]
[same as prior period, unchanged from 0000950170-22-002669:notes:62]

[0000950170-22-017904:notes:55]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| Deferred tax assets |  | $ | 377 |  |  | $ | 362 |  |
| Operating lease ROU assets |  |  | 318 |  |  |  | 294 |  |
| Other assets |  |  | 306 |  |  |  | 335 |  |
| Other non-current assets |  | $ | 1,001 |  |  | $ | 991 |  |

[0000950170-22-017904:notes:56]
Other non-current assets as of July 29, 2022 and April 29, 2022 include $75 million and $73 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies. Our sales to LNTL are conducted on terms equivalent to those prevailing in an arm’s length transaction.

[0000950170-22-017904:notes:57]
[same as prior period, unchanged from 0000950170-22-002669:notes:65]

[0000950170-22-017904:notes:58]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| Accrued compensation and benefits |  | $ | 282 |  |  | $ | 462 |  |
| Product warranty liabilities |  |  | 17 |  |  |  | 17 |  |
| Operating lease liabilities |  |  | 50 |  |  |  | 47 |  |
| Other current liabilities |  |  | 373 |  |  |  | 399 |  |
| Accrued expenses |  | $ | 722 |  |  | $ | 925 |  |

[0000950170-22-017904:notes:59]
[same as prior period, unchanged from 0000950170-22-002669:notes:73]

[0000950170-22-017904:notes:60]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| Liability for uncertain tax positions |  | $ | 137 |  |  | $ | 131 |  |
| Income taxes payable |  |  | 303 |  |  |  | 303 |  |
| Product warranty liabilities |  |  | 9 |  |  |  | 9 |  |
| Operating lease liabilities |  |  | 278 |  |  |  | 257 |  |
| Other liabilities |  |  | 116 |  |  |  | 88 |  |
| Other long-term liabilities |  | $ | 843 |  |  | $ | 788 |  |

[0000950170-22-017904:notes:61]
[same as prior period, unchanged from 0000950170-22-002669:notes:75]

[0000950170-22-017904:notes:62]
The following table summarizes the components of our deferred revenue and financed unearned services revenue balance as reported in our condensed consolidated balance sheets (in millions):

[0000950170-22-017904:notes:63]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| Deferred product revenue |  | $ | 36 |  |  | $ | 31 |  |
| Deferred services revenue |  |  | 4,079 |  |  |  | 4,140 |  |
| Financed unearned services revenue |  |  | 55 |  |  |  | 61 |  |
| Total |  | $ | 4,170 |  |  | $ | 4,232 |  |
| Reported as: |  |  |  |  |  |  |
| Short-term |  | $ | 2,088 |  |  | $ | 2,171 |  |
| Long-term |  |  | 2,082 |  |  |  | 2,061 |  |
| Total |  | $ | 4,170 |  |  | $ | 4,232 |  |

[0000950170-22-017904:notes:64]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 15 – Commitments and Contingencies for additional information related to these arrangements.

[0000950170-22-017904:notes:65]
During the three months ended July 29, 2022 and July 30, 2021, we recognized revenue of $706 million and $617 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0000950170-22-017904:notes:66]
As of July 29, 2022, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied approximated our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as

[0000950170-22-017904:notes:67]
revenue approximately 50% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 23% in the next 13 to 24 months, and the remainder thereafter.

[0000950170-22-017904:notes:68]
[same as prior period, unchanged from 0000950170-22-002669:notes:81]

[0000950170-22-017904:notes:69]
[same as prior period, unchanged from 0000950170-22-002669:notes:82]

[0000950170-22-017904:notes:70]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| Other current assets |  | $ | 83 |  |  | $ | 80 |  |
| Other non-current assets |  |  | 111 |  |  |  | 117 |  |
| Total deferred commissions |  | $ | 194 |  |  | $ | 197 |  |

[0000950170-22-017904:notes:71]
Other income (expense), net (in millions):

[0000950170-22-017904:notes:72]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |
| Interest income |  | $ | 7 |  |  | $ | 2 |  |
| Interest expense |  |  | (18 | ) |  |  | (18 | ) |
| Other, net |  |  | 26 |  |  |  | 4 |  |
| Total other income (expense), net |  | $ | 15 |  |  | $ | (12 | ) |

[0000950170-22-017904:notes:73]
In the first quarter of fiscal 2023, Other, net includes a $32 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $59 million.

[0000950170-22-017904:notes:74]
[same as prior period, unchanged from 0000950170-22-002669:notes:86]

[0000950170-22-017904:notes:75]
Supplemental cash flow information related to our operating leases is included in Note 8 ─ Leases. Non-cash investing and financing activities and other supplemental cash flow information are presented below:

[0000950170-22-017904:notes:76]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 20 |  |  | $ | 15 |  |  |  |
| Liabilities incurred to former owners of acquired business |  | $ | 3 |  |  | $ | — |  |  |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 12 |  |  | $ | 17 |  |  |  |
| Interest paid |  | $ | 27 |  |  | $ | 27 |  |  |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-22-017904:notes:77]
[same as prior period, unchanged from 0000950170-22-002669:notes:89]

[0000950170-22-017904:notes:78]
[same as prior period, unchanged from 0000950170-22-002669:notes:90]

[0000950170-22-017904:notes:79]
[same as prior period, unchanged from 0000950170-22-002669:notes:91]

[0000950170-22-017904:notes:80]
[same as prior period, unchanged from 0000950170-22-002669:notes:92]

[0000950170-22-017904:notes:81]
[same as prior period, unchanged from 0000950170-22-002669:notes:93]

[0000950170-22-017904:notes:82]
[same as prior period, unchanged from 0000950170-22-002669:notes:94]

[0000950170-22-017904:notes:83]
[same as prior period, unchanged from 0000950170-22-002669:notes:95]

[0000950170-22-017904:notes:84]
The following is a summary of our investments at their cost or amortized cost for the periods ended July 29, 2022 and April 29, 2022 (in millions):

[0000950170-22-017904:notes:85]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |  |
| Corporate bonds |  | $ | 9 |  |  | $ | 9 |  |  |
| U.S. Treasury and government debt securities |  |  | 142 |  |  |  | 13 |  |  |
| Certificates of deposit |  |  | 69 |  |  |  | 71 |  |  |
| Mutual funds |  |  | 38 |  |  |  | 36 |  |  |
| Total debt and equity securities |  | $ | 258 |  |  | $ | 129 |  |  |

[0000950170-22-017904:notes:86]
[same as prior period, unchanged from 0000950170-22-002669:notes:98]

[0000950170-22-017904:notes:87]
As of July 29, 2022, all our debt investments are due to mature in one year or less.

[0000950170-22-017904:notes:88]
[same as prior period, unchanged from 0000950170-22-002669:notes:102]

[0000950170-22-017904:notes:89]
[same as prior period, unchanged from 0000950170-22-002669:notes:103]

[0000950170-22-017904:notes:90]
|  |  | July 29, 2022 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 3,219 |  |  | $ | 3,219 |  |  | $ | — |  |
| Corporate bonds |  |  | 9 |  |  |  | — |  |  |  | 9 |  |
| U.S. Treasury and government debt securities |  |  | 142 |  |  |  | 142 |  |  |  | — |  |
| Certificates of deposit |  |  | 69 |  |  |  | — |  |  |  | 69 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 3,439 |  |  | $ | 3,361 |  |  | $ | 78 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 31 |  |  | $ | 31 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (13 | ) |  | $ | — |  |  | $ | (13 | ) |

[0000950170-22-017904:notes:91]
|  |  | April 29, 2022 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 4,041 |  |  | $ | 4,041 |  |  | $ | — |  |
| Corporate bonds |  |  | 9 |  |  |  | — |  |  |  | 9 |  |
| U.S. Treasury and government debt securities |  |  | 13 |  |  |  | 13 |  |  |  | — |  |
| Certificates of deposit |  |  | 71 |  |  |  | — |  |  |  | 71 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,134 |  |  | $ | 4,054 |  |  | $ | 80 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 30 |  |  | $ | 30 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (29 | ) |  | $ | — |  |  | $ | (29 | ) |

[0000950170-22-017904:notes:92]
[same as prior period, unchanged from 0000950170-22-002669:notes:106]

[0000950170-22-017904:notes:93]
[same as prior period, unchanged from 0000950170-22-002669:notes:107]

[0000950170-22-017904:notes:94]
[same as prior period, unchanged from 0000950170-22-002669:notes:108]

[0000950170-22-017904:notes:95]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt

[0000950170-22-017904:notes:96]
instruments. As of July 29, 2022 and April 29, 2022, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0000950170-22-017904:notes:97]
Fair Value of Debt

[0000950170-22-017904:notes:98]
As of July 29, 2022 and April 29, 2022, the fair value of our long-term debt was approximately $2,472 million and $2,491 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0000950170-22-017904:notes:99]
7. Financing Arrangements

[0000950170-22-017904:notes:100]
Long-Term Debt

[0000950170-22-017904:notes:101]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0000950170-22-017904:notes:102]
|  |  | Effective Interest Rate |  | July 29, 2022 |  |  | April 29, 2022 |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | 250 |  |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,650 |  |  |  | 2,650 |  |
| Unamortized discount and issuance costs |  |  |  |  | (13 | ) |  |  | (14 | ) |
| Total senior notes |  |  |  |  | 2,637 |  |  |  | 2,636 |  |
| Less: Current portion of long-term debt |  |  |  |  | (250 | ) |  |  | (250 | ) |
| Total long-term debt |  |  |  | $ | 2,387 |  |  | $ | 2,386 |  |

[0000950170-22-017904:notes:103]
Senior Notes

[0000950170-22-017904:notes:104]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were issued in June 2020. Interest on these Senior Notes is payable semi-annually in June and December.

[0000950170-22-017904:notes:105]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September. Our 3.25% Senior Notes, with a principal amount of $250 million, were issued in December 2012 with interest paid semi-annually in June and December.

[0000950170-22-017904:notes:106]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0000950170-22-017904:notes:107]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of July 29, 2022, we were in compliance with all covenants associated with the Senior Notes.

[0000950170-22-017904:notes:108]
In August 2022, we called for redemption of the aggregate principal amount of 3.25% Senior Notes due December 2022. The aggregate redemption price to be paid is $252 million, comprised of the principal and unpaid interest. The redemption date is September 15, 2022.

[0000950170-22-017904:notes:109]
As of July 29, 2022, our aggregate future principal debt maturities are as follows (in millions):

[0000950170-22-017904:notes:110]
| Fiscal Year |  | Amount |  |
| 2023 (remainder) |  | $ | 250 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| 2027 |  |  | — |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |

[0000950170-22-017904:notes:111]
Commercial Paper Program and Credit Facility

[0000950170-22-017904:notes:112]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of July 29, 2022 or April 29, 2022.

[0000950170-22-017904:notes:113]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in January 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of July 29, 2022, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0000950170-22-017904:notes:114]
[same as prior period, unchanged from 0000950170-22-002669:notes:125]

[0000950170-22-017904:notes:115]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of July 29, 2022, have remaining lease terms not exceeding 19 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of July 29, 2022, have remaining lease terms not exceeding 4 years. As of July 29, 2022, our automobile leases have remaining lease terms not exceeding 4 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0000950170-22-017904:notes:116]
[same as prior period, unchanged from 0000950170-22-002669:notes:130]

[0000950170-22-017904:notes:117]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |
| Operating lease cost |  | $ | 15 |  |  | $ | 15 |  |
| Variable lease cost |  |  | 4 |  |  |  | 4 |  |
| Total lease cost |  | $ | 19 |  |  | $ | 19 |  |

[0000950170-22-017904:notes:118]
[same as prior period, unchanged from 0000950170-22-002669:notes:132]

[0000950170-22-017904:notes:119]
[same as prior period, unchanged from 0000950170-22-002669:notes:133]

[0000950170-22-017904:notes:120]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 14 |  |  | $ | 13 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  | $ | 38 |  |  | $ | 159 |  |

[0000950170-22-017904:notes:121]
[same as prior period, unchanged from 0000950170-22-002669:notes:135]

[0000950170-22-017904:notes:122]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| Other non-current assets |  | $ | 318 |  |  | $ | 294 |  |
| Total operating lease ROU assets |  | $ | 318 |  |  | $ | 294 |  |
| Accrued expenses |  | $ | 50 |  |  | $ | 47 |  |
| Other long-term liabilities |  |  | 278 |  |  |  | 257 |  |
| Total operating lease liabilities |  | $ | 328 |  |  | $ | 304 |  |
| Weighted Average Remaining Lease Term |  | 9.6 years |  |  | 9.6 years |  |
| Weighted Average Discount Rate |  |  | 2.9 | % |  |  | 2.8 | % |

[0000950170-22-017904:notes:123]
Future minimum operating lease payments as of July 29, 2022, are as follows (in millions):

[0000950170-22-017904:notes:124]
| Fiscal Year |  | Operating Leases |  |
| 2023 (remainder) |  | $ | 44 |  |
| 2024 |  |  | 52 |  |
| 2025 |  |  | 42 |  |
| 2026 |  |  | 37 |  |
| 2027 |  |  | 33 |  |
| Thereafter |  |  | 175 |  |
| Total lease payments |  |  | 383 |  |
| Less: Interest |  |  | (55 | ) |
| Total |  | $ | 328 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000950170-22-017904:notes:125]
[same as prior period, unchanged from 0000950170-22-002669:notes:139]

[0000950170-22-017904:notes:126]
[same as prior period, unchanged from 0000950170-22-002669:notes:146]

[0000950170-22-017904:notes:127]
We granted approximately 5 million restricted stock units (RSUs) with a weighted average grant date fair value of $58.42 per share, including performance-based RSUs (PBRSUs), during the three months ended July 29, 2022. In the three months ended July 29, 2022, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSUs cliff-vest at the end of an approximate one, two or three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the first, second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle most of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the three months ended July 29, 2022, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. The fair values of these TSR performance-based awards were fixed at grant date using a Monte Carlo simulation model. For the remaining half of the PBRSUs granted in the three months ended July 29, 2022, the number of shares issued will depend upon the Company's billings result average over the three-year performance period as compared to a predetermined billings target. Billings for purposes of measuring the performance of these PBRSUs means the total obtained by adding net revenues as reported on the Company's Consolidated Statements of Income to the amount reported as the change in deferred revenue and financed unearned services revenue on the Consolidated Statements of Cash Flows for the applicable measurement period, excluding the impact of fluctuations in foreign currency exchange rates. The fair values of these billings PBRSUs were established consistent with our methodology for valuing time-based RSUs, while compensation cost is being recognized based on the probable outcome of the performance condition. The aggregate grant date fair value of PBRSUs effectively granted in the current year was $27 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0000950170-22-017904:notes:128]
[same as prior period, unchanged from 0000950170-22-002669:notes:155]

[0000950170-22-017904:notes:129]
[same as prior period, unchanged from 0000950170-22-002669:notes:156]

[0000950170-22-017904:notes:130]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 1 |  |
| Cost of services revenues |  |  | 4 |  |  |  | 2 |  |
| Sales and marketing |  |  | 28 |  |  |  | 26 |  |
| Research and development |  |  | 24 |  |  |  | 16 |  |
| General and administrative |  |  | 10 |  |  |  | 8 |  |
| Total stock-based compensation expense |  | $ | 67 |  |  | $ | 53 |  |

[0000950170-22-017904:notes:131]
As of July 29, 2022, total unrecognized compensation expense related to our equity awards was $746 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.6 years.

[0000950170-22-017904:notes:132]
[same as prior period, unchanged from 0000950170-22-002669:notes:159]

[0000950170-22-017904:notes:133]
As of July 29, 2022, our Board of Directors has authorized the repurchase of up to $15.1 billion of our common stock. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time.

[0000950170-22-017904:notes:134]
The following table summarizes activity related to the stock repurchase program for the three months ended July 29, 2022 (in millions, except for per share amounts):

[0000950170-22-017904:notes:135]
| Number of shares repurchased |  |  | 5 |  |
| Average price per share |  | $ | 67.26 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 18 |  |
| Stock repurchases allocated to retained earnings |  | $ | 332 |  |
| Remaining authorization at end of period |  | $ | 902 |  |

[0000950170-22-017904:notes:136]
Since the May 13, 2003 inception of our stock repurchase program through July 29, 2022, we repurchased a total of 352 million shares of our common stock at an average price of $40.35 per share, for an aggregate purchase price of $14.2 billion.

[0000950170-22-017904:notes:137]
[same as prior period, unchanged from 0000950170-22-002669:notes:164]

[0000950170-22-017904:notes:138]
[same as prior period, unchanged from 0000950170-22-002669:notes:165]

[0000950170-22-017904:notes:139]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |
| Dividends per share declared |  | $ | 0.50 |  |  | $ | 0.50 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 106 |  |  | $ | — |  |
| Dividend payments allocated to retained earnings |  | $ | 4 |  |  | $ | 112 |  |

[0000950170-22-017904:notes:140]
On August 22, 2022, we declared a cash dividend of $0.50 per share of common stock, payable on October 26, 2022 to holders of record as of the close of business on October 7, 2022. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0000950170-22-017904:notes:141]
[same as prior period, unchanged from 0000950170-22-002669:notes:168]

[0000950170-22-017904:notes:142]
[same as prior period, unchanged from 0000950170-22-002669:notes:169]

[0000950170-22-017904:notes:143]
|  |  | ForeignCurrencyTranslationAdjustments |  |  | DefinedBenefitObligationAdjustments |  |  | UnrealizedGains(Losses) onDerivativeInstruments |  |  | Total |  |
| Balance as of April 29, 2022 |  | $ | (44 | ) |  | $ | (1 | ) |  | $ | 1 |  |  | $ | (44 | ) |
| Other comprehensive income (loss), net of tax |  |  | (3 | ) |  |  | — |  |  |  | — |  |  |  | (3 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |
| Total other comprehensive income (loss) |  |  | (3 | ) |  |  | — |  |  |  | (1 | ) |  |  | (4 | ) |
| Balance as of July 29, 2022 |  | $ | (47 | ) |  | $ | (1 | ) |  | $ | — |  |  | $ | (48 | ) |

[0000950170-22-017904:notes:144]
[same as prior period, unchanged from 0000950170-22-002669:notes:171]

[0000950170-22-017904:notes:145]
|  |  | Three Months Ended |  |  |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  | Statements ofIncome Classification |
| Realized gains on cash flow hedges |  | $ | (1 | ) |  | $ | — |  |  | Net revenues |
| Total reclassifications |  | $ | (1 | ) |  | $ | — |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-22-017904:notes:146]
[same as prior period, unchanged from 0000950170-22-002669:notes:173]

[0000950170-22-017904:notes:147]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of July 29, 2022 or April 29, 2022. All contracts have a maturity of less than 12 months.

[0000950170-22-017904:notes:148]
[same as prior period, unchanged from 0000950170-22-002669:notes:175]

[0000950170-22-017904:notes:149]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 115 |  |  | $ | 78 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 708 |  |  | $ | 841 |  |
| Forward contracts purchased |  | $ | 139 |  |  | $ | 129 |  |

[0000950170-22-017904:notes:150]
[same as prior period, unchanged from 0000950170-22-002669:notes:177]

[0000950170-22-017904:notes:151]
[same as prior period, unchanged from 0000950170-22-002669:notes:178]

[0000950170-22-017904:notes:152]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |
| Foreign currency exchange contracts |  | $ | (21 | ) |  | $ | 9 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-22-017904:notes:153]
[same as prior period, unchanged from 0000950170-22-002669:notes:180]

[0000950170-22-017904:notes:154]
In the first three months of fiscal 2023, we executed a restructuring plan to redirect resources to highest return activities, which included a reduction in our global workforce of less than 1%, and consisted primarily of employee severance-related costs.

[0000950170-22-017904:notes:155]
We also continued activities related to the establishment of an international headquarters in Cork, Ireland, during the first three months of fiscal 2023, and incurred restructuring charges consisting primarily of legal and tax-related professional fees. Activities under this plan, for which we expect to incur additional charges, will continue during the remainder of fiscal 2023.

[0000950170-22-017904:notes:156]
During the first three months of fiscal 2022, we executed a restructuring plan to reduce the amount of office space we occupied as we allow more employees to work remotely. In connection with the plan, we also reduced our global workforce by approximately 1%. Charges related to the plan consisted primarily of office relocation costs, lease termination fees, and employee severance-related costs. Substantially all activities under the plan had been completed by the end of fiscal 2022.

[0000950170-22-017904:notes:157]
[same as prior period, unchanged from 0000950170-22-002669:notes:183]

[0000950170-22-017904:notes:158]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |
| Balance at beginning of period |  | $ | 1 |  |  | $ | 1 |  |
| Net charges |  |  | 11 |  |  |  | 22 |  |
| Cash payments |  |  | (3 | ) |  |  | (17 | ) |
| Balance at end of period |  | $ | 9 |  |  | $ | 6 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-22-017904:notes:159]
[same as prior period, unchanged from 0000950170-22-002669:notes:185]

[0000950170-22-017904:notes:160]
[same as prior period, unchanged from 0000950170-22-002669:notes:186]

[0000950170-22-017904:notes:161]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |
| Effective tax rates |  |  | 20.7 | % |  |  | 14.8 | % |

[0000950170-22-017904:notes:162]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. Our effective tax rate for the three months ended July 29, 2022 increased from the prior year primarily due to the capitalization of research and development expenses. Under the Tax Cuts and Jobs Act of 2017, costs incurred beginning in our fiscal 2023 are to be amortized over five or 15 years depending on where the research activities are conducted. Additionally, our effective tax rate for the three months ended July 29, 2022 includes the impact of discrete benefits related to stock-based compensation. The effective tax rate for the three months ended July 30, 2021 includes the impact of discrete tax benefits for lapses of statute of limitations as well as larger benefits related to stock-based compensation as compared to the current year.

[0000950170-22-017904:notes:163]
As of July 29, 2022, we had $224 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $137 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $137 million have been recorded in other long-term liabilities.

[0000950170-22-017904:notes:164]
[same as prior period, unchanged from 0000950170-22-002669:notes:190]

[0000950170-22-017904:notes:165]
[same as prior period, unchanged from 0000950170-22-002669:notes:191]

[0000950170-22-017904:notes:166]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. As a result of uncertainties regarding tax audits and their possible outcomes, an estimate of the range of possible impacts to unrecognized tax benefits in the next twelve months cannot be made at this time.


## us-gaap:EarningsPerShareTextBlock

[0000950170-22-017904:notes:167]
[same as prior period, unchanged from 0000950170-22-002669:notes:194]

[0000950170-22-017904:notes:168]
[same as prior period, unchanged from 0000950170-22-002669:notes:195]

[0000950170-22-017904:notes:169]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |
| Numerator: |  |  |  |  |  |  |
| Net income |  | $ | 214 |  |  | $ | 202 |  |
| Denominator: |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 220 |  |  |  | 223 |  |
| Dilutive impact of employee equity award plans |  |  | 4 |  |  |  | 6 |  |
| Shares used in diluted computation |  |  | 224 |  |  |  | 229 |  |
| Net Income per Share: |  |  |  |  |  |  |
| Basic |  | $ | 0.97 |  |  | $ | 0.91 |  |
| Diluted |  | $ | 0.96 |  |  | $ | 0.88 |  |

[0000950170-22-017904:notes:170]
Five million shares from outstanding employee awards were excluded from the diluted net income per share calculation for the  three months ended July 29, 2022, as their inclusion would have been anti-dilutive. No potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for the three months ended July 30, 2021.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-22-017904:notes:171]
[same as prior period, unchanged from 0000950170-22-002669:notes:198]

[0000950170-22-017904:notes:172]
Our operations are organized into two segments: Hybrid Cloud and Public Cloud. The two segments are based on the information reviewed by our Chief Operating Decision Maker (CODM), who is the Chief Executive Officer, to evaluate results and allocate resources. The CODM measures performance of each segment based on segment revenue and segment gross profit. We do not allocate to our segments certain cost of revenues which we manage at the corporate level. These unallocated costs include stock-based compensation and amortization of intangible assets. We do not allocate assets to our segments.

[0000950170-22-017904:notes:173]
Hybrid Cloud offers a portfolio of storage and infrastructure solutions that help customers recast their data centers with the power of cloud. This portfolio is designed to operate with public clouds to unlock the potential of hybrid, multi-cloud operations. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.

[0000950170-22-017904:notes:174]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage and data services, and cloud operations services.

[0000950170-22-017904:notes:175]
[same as prior period, unchanged from 0000950170-22-002669:notes:203]

[0000950170-22-017904:notes:176]
[same as prior period, unchanged from 0000950170-22-002669:notes:204]

[0000950170-22-017904:notes:177]
|  | Three Months Ended July 29, 2022 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 786 |  |  | $ | — |  |  | $ | 786 |  |
| Support revenues |  | 598 |  |  |  | — |  |  |  | 598 |  |
| Professional and other services revenues |  | 76 |  |  |  | — |  |  |  | 76 |  |
| Public cloud revenues |  | — |  |  |  | 132 |  |  |  | 132 |  |
| Net revenues |  | 1,460 |  |  |  | 132 |  |  |  | 1,592 |  |
| Cost of product revenues |  | 395 |  |  |  | — |  |  |  | 395 |  |
| Cost of support revenues |  | 43 |  |  |  | — |  |  |  | 43 |  |
| Cost of professional and other services revenues |  | 52 |  |  |  | — |  |  |  | 52 |  |
| Cost of public cloud revenues |  | — |  |  |  | 40 |  |  |  | 40 |  |
| Segment cost of revenues |  | 490 |  |  |  | 40 |  |  |  | 530 |  |
| Segment gross profit | $ | 970 |  |  | $ | 92 |  |  | $ | 1,062 |  |
| Segment gross margin |  | 66.4 | % |  |  | 69.7 | % |  |  | 66.7 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 16 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,046 |  |
| Total gross margin |  |  |  |  |  |  |  | 65.7 | % |
| 1 Unallocated cost of revenues are composed of $5 million of stock-based compensation expense and $11 million of amortization of intangible assets. |  |

[0000950170-22-017904:notes:178]
|  | Three Months Ended July 30, 2021 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 730 |  |  | $ | — |  |  | $ | 730 |  |
| Support revenues |  | 578 |  |  |  | — |  |  |  | 578 |  |
| Professional and other services revenues |  | 71 |  |  |  | — |  |  |  | 71 |  |
| Public cloud revenues |  | — |  |  |  | 79 |  |  |  | 79 |  |
| Net revenues |  | 1,379 |  |  |  | 79 |  |  |  | 1,458 |  |
| Cost of product revenues |  | 326 |  |  |  | — |  |  |  | 326 |  |
| Cost of support revenues |  | 48 |  |  |  | — |  |  |  | 48 |  |
| Cost of professional and other services revenues |  | 51 |  |  |  | — |  |  |  | 51 |  |
| Cost of public cloud revenues |  | — |  |  |  | 23 |  |  |  | 23 |  |
| Segment cost of revenues |  | 425 |  |  |  | 23 |  |  |  | 448 |  |
| Segment gross profit | $ | 954 |  |  | $ | 56 |  |  | $ | 1,010 |  |
| Segment gross margin |  | 69.2 | % |  |  | 70.9 | % |  |  | 69.3 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 11 |  |
| Total gross profit |  |  |  |  |  |  | $ | 999 |  |
| Total gross margin |  |  |  |  |  |  |  | 68.5 | % |
| 1 Unallocated cost of revenues are composed of $4 million of stock-based compensation expense and $7 million of amortization of intangible assets. |  |

[0000950170-22-017904:notes:179]
[same as prior period, unchanged from 0000950170-22-002669:notes:209]

[0000950170-22-017904:notes:180]
[same as prior period, unchanged from 0000950170-22-002669:notes:210]

[0000950170-22-017904:notes:181]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |
| United States, Canada and Latin America (Americas) |  | $ | 856 |  |  | $ | 786 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 500 |  |  |  | 454 |  |
| Asia Pacific (APAC) |  |  | 236 |  |  |  | 218 |  |
| Net revenues |  | $ | 1,592 |  |  | $ | 1,458 |  |

[0000950170-22-017904:notes:182]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $758 million and $696 million during the three months ended July 29, 2022 and July 30, 2021, respectively.

[0000950170-22-017904:notes:183]
The majority of our assets, excluding cash, cash equivalents, short-term investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents and short-term investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0000950170-22-017904:notes:184]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| U.S. |  | $ | 1,441 |  |  | $ | 1,820 |  |
| International |  |  | 1,998 |  |  |  | 2,314 |  |
| Total |  | $ | 3,439 |  |  | $ | 4,134 |  |

[0000950170-22-017904:notes:185]
[same as prior period, unchanged from 0000950170-22-002669:notes:215]

[0000950170-22-017904:notes:186]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| U.S. |  | $ | 399 |  |  | $ | 392 |  |
| International |  |  | 223 |  |  |  | 210 |  |
| Total |  | $ | 622 |  |  | $ | 602 |  |

[0000950170-22-017904:notes:187]
[same as prior period, unchanged from 0000950170-22-002669:notes:217]

[0000950170-22-017904:notes:188]
[same as prior period, unchanged from 0000950170-22-002669:notes:218]

[0000950170-22-017904:notes:189]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |
| Arrow Electronics, Inc. |  |  | 25 | % |  |  | 24 | % |
| Tech Data Corporation |  |  | 21 | % |  |  | 20 | % |

[0000950170-22-017904:notes:190]
[same as prior period, unchanged from 0000950170-22-002669:notes:220]

[0000950170-22-017904:notes:191]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| Arrow Electronics, Inc. |  |  | 12 | % |  |  | 10 | % |
| Tech Data Corporation |  |  | 15 | % |  |  | 19 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-22-017904:notes:192]
15. Commitments and Contingencies

[0000950170-22-017904:notes:193]
Purchase Orders and Other Commitments

[0000950170-22-017904:notes:194]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of July 29, 2022, we had approximately $0.9 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 29, 2022 and April 29, 2022, such liability amounted to $23 million and $18 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0000950170-22-017904:notes:195]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of July 29, 2022, we had approximately $0.3 billion in other purchase obligations.

[0000950170-22-017904:notes:196]
Financing Guarantees

[0000950170-22-017904:notes:197]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $3 million and $17 million of receivables during the three months ended July 29, 2022 and July 30, 2021, respectively.

[0000950170-22-017904:notes:198]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0000950170-22-017904:notes:199]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of July 29, 2022 and April 29, 2022, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-22-017904:notes:200]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of July 29, 2022, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-22-017904:notes:201]
Legal Contingencies

[0000950170-22-017904:notes:202]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0000950170-22-017904:notes:203]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. The defendants' Motion to Dismiss was granted and on February 26, 2021 and the judge entered judgment in favor of NetApp and the other defendants. On March 26, 2021, plaintiffs filed a notice of appeal. The parties subsequently engaged in settlement discussions, and on July 30, 2021 entered into a Memorandum of Understanding (MOU) providing for the settlement of the class action.  Pursuant to the terms of the MOU, NetApp has agreed to pay approximately $2.0 million in connection with the settlement, and this amount was accrued during the three months ended July 30, 2021. The parties subsequently executed a stipulation of settlement, which contains no admission of liability, wrongdoing or responsibility by any of the parties, and which provides that the class action will be dismissed with prejudice, with mutual releases by all parties, upon final court approval. On September 24, 2021, plaintiff filed an unopposed motion seeking court approval of the settlement. On May 2, 2022, the court preliminarily approved the settlement, subject to further consideration at a final approval hearing, which is scheduled to be held on September 1, 2022. The court’s approval of settlement will remain preliminary pending the outcome of the final approval hearing.

[0000950170-22-017904:notes:204]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0000950170-22-017904:notes:205]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of July 29, 2022 related to such matters.
