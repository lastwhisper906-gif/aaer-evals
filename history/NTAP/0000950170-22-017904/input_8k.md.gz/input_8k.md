# NTAP 8-K — 0000950170-22-017731 filed 2022-08-24

## item codes, every 8-K on or before 2022-08-30

- 2022-08-24 0000950170-22-017731 — 2.02, 9.01
- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2022-08-30

- none on or before 2022-08-30

## item 2.02 — earnings release, exhibit 99.1

[0000950170-22-017731:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0000950170-22-017731:8k_2_02:2]
EX-99.1

[0000950170-22-017731:8k_2_02:3]
Exhibit 99.1

[0000950170-22-017731:8k_2_02:4]
NetApp reports first quarter of fiscal year 2023 results

[0000950170-22-017731:8k_2_02:5]
Delivers company record for Q1 billings, revenue, gross profit dollars, operating income, and EPS

[0000950170-22-017731:8k_2_02:6]
•
Net revenues for the first quarter grew 9% year-over-year to $1.59 billion, 13% in constant currency1

[0000950170-22-017731:8k_2_02:7]
•
Q1 product revenue grew 8% year-over-year to $786 million, the sixth consecutive quarter of year-over-year growth

[0000950170-22-017731:8k_2_02:8]
•
Q1 billings2 were $1.56 billion, an increase of 13% year-over-year, 18% in constant currency

[0000950170-22-017731:8k_2_02:9]
•
NetApp™ Public Cloud annualized revenue run rate (ARR)3increased 73% year-over-year to $584 million

[0000950170-22-017731:8k_2_02:10]
•
All-flash array ARR4 increased 7% year-over-year to $3.0 billion

[0000950170-22-017731:8k_2_02:11]
•
$460 million returned to shareholders in share repurchases and cash dividends

[0000950170-22-017731:8k_2_02:12]
SAN JOSE, Calif.—August 24, 2022—NetApp (NASDAQ: NTAP) today reported financial results for the first quarter of fiscal year 2023, which ended on July 29, 2022.

[0000950170-22-017731:8k_2_02:13]
“We delivered a great start to the year, fueled by broad-based demand across our portfolio and geographies, setting all-time Q1 company highs for billings, revenue, gross profit dollars, operating income and EPS,” said George Kurian, chief executive officer. “Our solutions are aligned with our customer’s top priorities helping them reduce cost, risk and complexity for their digital and cloud transformations.  This is evidenced by the strong growth of our revenue, billings and profitability.”

[0000950170-22-017731:8k_2_02:14]
First quarter of fiscal year 2023 financial results

[0000950170-22-017731:8k_2_02:15]
•
Net revenues: $1.59 billion, compared to $1.46 billion in the first quarter of fiscal year 2022

[0000950170-22-017731:8k_2_02:16]
o
Hybrid Cloud segment revenue: $1.46 billion, compared to $1.38 billion in the first quarter of fiscal year 2022

[0000950170-22-017731:8k_2_02:17]
o
Public Cloud segment revenue: $132 million, compared to $79 million in the first quarter of fiscal year 2022

[0000950170-22-017731:8k_2_02:18]
•
Net income: GAAP net income of $214 million, compared to $202 million in the first quarter of fiscal year 2022; non-GAAP net income5 of $269 million, compared to $263 million in the first quarter of fiscal year 2022

[0000950170-22-017731:8k_2_02:19]
•
Earnings per share: GAAP net income per share6 of $0.96, compared to $0.88 in the first quarter of fiscal year 2022; non-GAAP net income per share of $1.20, compared to $1.15 in the first quarter of fiscal year 2022

[0000950170-22-017731:8k_2_02:20]
•
Cash, cash equivalents and investments: $3.44 billion at the end of the first quarter of fiscal year 2023

[0000950170-22-017731:8k_2_02:21]
•
Cash provided by operations: $281 million, compared to $242 million in the first quarter of fiscal year 2022

[0000950170-22-017731:8k_2_02:22]
•
Share repurchase and dividends: Returned $460 million to shareholders through share repurchases and cash dividends

[0000950170-22-017731:8k_2_02:23]
Second quarter of fiscal year 2023 financial outlook

[0000950170-22-017731:8k_2_02:24]
The Company provided the following financial guidance for the second quarter of fiscal year 2023:

[0000950170-22-017731:8k_2_02:25]
| Net revenues are expected to be in the range of: | $1.595 billion to $1.745 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $0.93 - $1.03 | $1.28 - $1.38 |

[0000950170-22-017731:8k_2_02:26]
Full fiscal year 2023 financial outlook

[0000950170-22-017731:8k_2_02:27]
The Company provided the following financial guidance for the full fiscal year 2023:

[0000950170-22-017731:8k_2_02:28]
| Net revenues are expected to grow in the range of: | 6% to 8% |
| Public Cloud ARR is expected to exit the fiscal year in the range of: | $780 million to $820 million |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 65% - 66% | 66% - 67% |
| Operating margins are expected to be in the range of: | 18% - 19% | 23% - 24% |
| Earnings per share is expected to be in the range of: | $4.09 - $4.29 | $5.40 - $5.60 |

[0000950170-22-017731:8k_2_02:29]
Dividend

[0000950170-22-017731:8k_2_02:30]
The next cash dividend of $0.50 per share is to be paid on October 26, 2022, to shareholders of record as of the close of business on October 7, 2022.

[0000950170-22-017731:8k_2_02:31]
First quarter of fiscal year 2023 business highlights

[0000950170-22-017731:8k_2_02:32]
Leading product innovation

[0000950170-22-017731:8k_2_02:33]
•
NetApp announced the general availability of Spot PC by NetApp, a managed cloud desktop-as-a-service solution with security, automation, observability, and optimization.

[0000950170-22-017731:8k_2_02:34]
•
NetApp announced the general availability of Spot Security, delivering continuous, automated security to all users.

[0000950170-22-017731:8k_2_02:35]
•
NetApp announced updates to Delight, the free cross-platform monitoring UI for Spark, with a new, more intuitive user interface.

[0000950170-22-017731:8k_2_02:36]
•
NetApp announced the general availability of Ocean for Apache Spark on Google Cloud.

[0000950170-22-017731:8k_2_02:37]
•
NetApp completed its acquisition of Instaclustr, a leading platform provider of fully managed open-source database, pipeline, and workflow applications delivered as a service.

[0000950170-22-017731:8k_2_02:38]
•
NetApp announced new capabilities to simplify hybrid cloud operations, including improved ransomware protection, hybrid cloud storage as a service in a single subscription with Keystone™, improved unified

[0000950170-22-017731:8k_2_02:39]
management in a single user interface with Cloud Manager, and collaboration with VMware to help transition workloads to the cloud.

[0000950170-22-017731:8k_2_02:40]
•
NetApp enhanced StorageGRID™ with updates including integration with Google Cloud, security, compliance enhancements, faster performance for analytical workloads, and more.

[0000950170-22-017731:8k_2_02:41]
•
NetApp announced the general availability of FlexPod™ XCS, leveraging its integration into the Cisco Intersight cloud operations platform.

[0000950170-22-017731:8k_2_02:42]
Customer and partner momentum

[0000950170-22-017731:8k_2_02:43]
•
NetApp and NVIDIA extended their partnership to accelerate HPC and AI with turnkey supercomputing infrastructure, announcing that NetApp EF600 all-flash NVMe storage combined with the BeeGFS parallel file system is now certified for NVIDIA DGX SuperPOD.

[0000950170-22-017731:8k_2_02:44]
•
NetApp and Kyndryl announced a global alliance to help customers unlock insights from data stored on premises, in the cloud, and in edge computing environments.

[0000950170-22-017731:8k_2_02:45]
•
NetApp announced that it is now an AWS Government ISV Competency Partner for Public Sector.

[0000950170-22-017731:8k_2_02:46]
•
NetApp and Alluxio collaborated to help customers adapt to new requirements for modernizing data architecture with low-touch operations for analytics, machine learning, and AI.

[0000950170-22-017731:8k_2_02:47]
Corporate news and events

[0000950170-22-017731:8k_2_02:48]
•
NetApp announced the winners of its annual Asia-Pacific (APAC) Partner Excellence Award7 at the NetApp Partner Summit 2022.

[0000950170-22-017731:8k_2_02:49]
•
NetApp announced that Spot by NetApp joined the FinOps Foundation as a Premier Member.

[0000950170-22-017731:8k_2_02:50]
NetApp awards and recognition

[0000950170-22-017731:8k_2_02:51]
•
An IDC study of Spot by NetApp8 customers found significant ROI, productivity, and time-to-market benefits, including an average 696% three-year ROI and a 21% reduction in Public Cloud spending.

[0000950170-22-017731:8k_2_02:52]
•
NetApp announced that NetApp AI won a 2022 AI Breakthrough Award for Best Overall Computer Vision.

[0000950170-22-017731:8k_2_02:53]
•
NetApp was named to CRN’s Software-Defined Data Center 50 List for 2022.9

[0000950170-22-017731:8k_2_02:54]
•
NetApp was listed as a recipient of the CRN Health and Wellbeing Recognition Award10 for the Women & Diversity in Channel Awards 2022.

[0000950170-22-017731:8k_2_02:55]
•
NetApp was named among the companies that scored 100% on Disability:IN’s Disability Equality Index 2022 Best Places to Work.11

[0000950170-22-017731:8k_2_02:56]
Executive appointments

[0000950170-22-017731:8k_2_02:57]
•
NetApp announced the appointments of Giovanna Sangiorgi and Srivatsan (Sri) Vaiyakarnam to its go-to-market leadership team as part of the ongoing evolution of NetApp’s sales organization to accelerate cloud-led growth.

[0000950170-22-017731:8k_2_02:58]
Webcast and conference call information

[0000950170-22-017731:8k_2_02:59]
NetApp will host a conference call to discuss these results today at 2:00 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on

[0000950170-22-017731:8k_2_02:60]
the Investor Relations website. An audio replay will be available on the website after 4:00 p.m. Pacific Time today.

[0000950170-22-017731:8k_2_02:61]
###

[0000950170-22-017731:8k_2_02:62]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0000950170-22-017731:8k_2_02:63]
Footnotes

[0000950170-22-017731:8k_2_02:64]
1Refer to the Constant Currency section below for an explanation of constant currency growth rates.

[0000950170-22-017731:8k_2_02:65]
2Refer to the NetApp Usage of Non-GAAP Financial Information section below for an explanation of billings.

[0000950170-22-017731:8k_2_02:66]
3Public Cloud annualized revenue run rate (ARR) is calculated as the annualized value of all Public Cloud customer commitments with the assumption that any commitment expiring during the next 12 months will be renewed with its existing terms.

[0000950170-22-017731:8k_2_02:67]
4All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0000950170-22-017731:8k_2_02:68]
5Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) gains/losses on the sale of investments in equity securities, (i) debt extinguishment costs, and (j) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes that the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0000950170-22-017731:8k_2_02:69]
6GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0000950170-22-017731:8k_2_02:70]
7Channel Life Australia, Catherine Knowles, June 21, 2022.  NetApp announces winners of APAC Partner Excellence Awards (channellife.com.au).

[0000950170-22-017731:8k_2_02:71]
8IDC, Courtney Wilson, May 23, 2022. IDC Study Highlights Spot Customer Benefits.

[0000950170-22-017731:8k_2_02:72]
9CRN Data Center News, O’Ryan Johnson, June 7, 2022. 25 Hot Software-Defined Data Center Infrastructure Companies: 2022 SDDC 50.

[0000950170-22-017731:8k_2_02:73]
10CRN Health and Wellbeing Recognition Award, July 22, 2022. Women & Diversity in Channel Awards 2022—SHORTLIST ANNOUNCED! (channelweb.co.uk).

[0000950170-22-017731:8k_2_02:74]
11Disability:IN’s Disability Equality Index 2022. 2022 Best Places to Work (disabilityin.org).

[0000950170-22-017731:8k_2_02:75]
NetApp usage of non-GAAP financial information

[0000950170-22-017731:8k_2_02:76]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share. NetApp also presents the hardware and software components of our GAAP product revenues. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0000950170-22-017731:8k_2_02:77]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations.

[0000950170-22-017731:8k_2_02:78]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0000950170-22-017731:8k_2_02:79]
NetApp believes that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0000950170-22-017731:8k_2_02:80]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0000950170-22-017731:8k_2_02:81]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0000950170-22-017731:8k_2_02:82]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0000950170-22-017731:8k_2_02:83]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0000950170-22-017731:8k_2_02:84]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0000950170-22-017731:8k_2_02:85]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0000950170-22-017731:8k_2_02:86]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0000950170-22-017731:8k_2_02:87]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0000950170-22-017731:8k_2_02:88]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0000950170-22-017731:8k_2_02:89]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-22-017731:8k_2_02:90]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-22-017731:8k_2_02:91]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-22-017731:8k_2_02:92]
J. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0000950170-22-017731:8k_2_02:93]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0000950170-22-017731:8k_2_02:94]
Constant Currency

[0000950170-22-017731:8k_2_02:95]
Constant currency net revenues growth is defined as net revenues for a given period restated at the comparative period's foreign currency exchange rates measured against the comparative period's net revenues. Constant currency billings growth is defined as billings for a given period computed using net revenues for that period restated at the comparative period’s foreign currency exchange rates, measured against the comparative period’s billings.

[0000950170-22-017731:8k_2_02:96]
About NetApp

[0000950170-22-017731:8k_2_02:97]
NetApp is a global, cloud-led, data-centric software company that empowers organizations to lead with data in the age of accelerated digital transformation. The company provides systems, software, and cloud services

[0000950170-22-017731:8k_2_02:98]
that enable them to run their applications optimally from data center to cloud, whether they are developing in the cloud, moving to the cloud, or creating their own cloudlike experiences on premises. With solutions that perform across diverse environments, NetApp helps organizations build their own data fabric and securely deliver the right data, services, and applications to the right people—anytime, anywhere. Learn more at www.netapp.com or follow us on Twitter, LinkedIn, Facebook, and Instagram.

[0000950170-22-017731:8k_2_02:99]
NETAPP, INC.

[0000950170-22-017731:8k_2_02:100]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-22-017731:8k_2_02:101]
(In millions)

[0000950170-22-017731:8k_2_02:102]
(Unaudited)

[0000950170-22-017731:8k_2_02:103]
|  |  | July 29, 2022 |  |  | April 29, 2022 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 3,439 |  |  | $ | 4,134 |  |
| Accounts receivable |  |  | 865 |  |  |  | 1,230 |  |
| Inventories |  |  | 232 |  |  |  | 204 |  |
| Other current assets |  |  | 386 |  |  |  | 377 |  |
| Total current assets |  |  | 4,922 |  |  |  | 5,945 |  |
| Property and equipment, net |  |  | 622 |  |  |  | 602 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,999 |  |  |  | 2,488 |  |
| Other non-current assets |  |  | 1,001 |  |  |  | 991 |  |
| Total assets |  | $ | 9,544 |  |  | $ | 10,026 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 515 |  |  | $ | 607 |  |
| Accrued expenses |  |  | 722 |  |  |  | 925 |  |
| Current portion of long-term debt |  |  | 250 |  |  |  | 250 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 2,088 |  |  |  | 2,171 |  |
| Total current liabilities |  |  | 3,575 |  |  |  | 3,953 |  |
| Long-term debt |  |  | 2,387 |  |  |  | 2,386 |  |
| Other long-term liabilities |  |  | 843 |  |  |  | 788 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 2,082 |  |  |  | 2,061 |  |
| Total liabilities |  |  | 8,887 |  |  |  | 9,188 |  |
| Stockholders' equity |  |  | 657 |  |  |  | 838 |  |
| Total liabilities and stockholders' equity |  | $ | 9,544 |  |  | $ | 10,026 |  |

[0000950170-22-017731:8k_2_02:104]
NETAPP, INC.

[0000950170-22-017731:8k_2_02:105]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-22-017731:8k_2_02:106]
(In millions, except per share amounts)

[0000950170-22-017731:8k_2_02:107]
(Unaudited)

[0000950170-22-017731:8k_2_02:108]
|  |  | Three Months Ended |  |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |
| Net revenues: |  |  |  |  |  |  |
| Product |  | $ | 786 |  |  | $ | 730 |  |
| Services |  |  | 806 |  |  |  | 728 |  |
| Net revenues |  |  | 1,592 |  |  |  | 1,458 |  |
| Cost of revenues: |  |  |  |  |  |  |
| Cost of product |  |  | 397 |  |  |  | 329 |  |
| Cost of services |  |  | 149 |  |  |  | 130 |  |
| Total cost of revenues |  |  | 546 |  |  |  | 459 |  |
| Gross profit |  |  | 1,046 |  |  |  | 999 |  |
| Operating expenses: |  |  |  |  |  |  |
| Sales and marketing |  |  | 458 |  |  |  | 451 |  |
| Research and development |  |  | 240 |  |  |  | 210 |  |
| General and administrative |  |  | 72 |  |  |  | 66 |  |
| Restructuring charges |  |  | 11 |  |  |  | 22 |  |
| Acquisition-related expense |  |  | 10 |  |  |  | 1 |  |
| Total operating expenses |  |  | 791 |  |  |  | 750 |  |
| Income from operations |  |  | 255 |  |  |  | 249 |  |
| Other income (expense), net |  |  | 15 |  |  |  | (12 | ) |
| Income before income taxes |  |  | 270 |  |  |  | 237 |  |
| Provision for income taxes |  |  | 56 |  |  |  | 35 |  |
| Net income |  | $ | 214 |  |  | $ | 202 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.97 |  |  | $ | 0.91 |  |
| Diluted |  | $ | 0.96 |  |  | $ | 0.88 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |
| Basic |  |  | 220 |  |  |  | 223 |  |
| Diluted |  |  | 224 |  |  |  | 229 |  |

[0000950170-22-017731:8k_2_02:109]
NETAPP, INC.

[0000950170-22-017731:8k_2_02:110]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-22-017731:8k_2_02:111]
(In millions)

[0000950170-22-017731:8k_2_02:112]
(Unaudited)

[0000950170-22-017731:8k_2_02:113]
|  |  | Three Months Ended |
|  |  | July 29, 2022 |  |  | July 30, 2021 |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income |  | $ | 214 |  |  | $ | 202 |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 58 |  |  |  | 46 |  |  |
| Non-cash operating lease cost |  |  | 14 |  |  |  | 13 |  |  |
| Stock-based compensation |  |  | 67 |  |  |  | 53 |  |  |
| Deferred income taxes |  |  | (15 | ) |  |  | (15 | ) |  |
| Other items, net |  |  | (66 | ) |  |  | 4 |  |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 364 |  |  |  | 287 |  |  |
| Inventories |  |  | (28 | ) |  |  | 6 |  |  |
| Accounts payable |  |  | (90 | ) |  |  | (51 | ) |  |
| Accrued expenses |  |  | (208 | ) |  |  | (242 | ) |  |
| Deferred revenue and financed unearned services revenue |  |  | (32 | ) |  |  | (82 | ) |  |
| Long-term taxes payable |  |  | 1 |  |  |  | (8 | ) |  |
| Changes in other operating assets and liabilities, net |  |  | 2 |  |  |  | 29 |  |  |
| Net cash provided by operating activities |  |  | 281 |  |  |  | 242 |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| (Purchases) redemptions of investments, net |  |  | (131 | ) |  |  | 11 |  |  |
| Purchases of property and equipment |  |  | (65 | ) |  |  | (51 | ) |  |
| Acquisitions of businesses, net of cash acquired |  |  | (491 | ) |  |  | (14 | ) |  |
| Other investing activities, net |  |  | 59 |  |  |  | — |  |  |
| Net cash used in investing activities |  |  | (628 | ) |  |  | (54 | ) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | 54 |  |  |  | 53 |  |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (52 | ) |  |  | (57 | ) |  |
| Repurchase of common stock |  |  | (350 | ) |  |  | (100 | ) |  |
| Dividends paid |  |  | (110 | ) |  |  | (112 | ) |  |
| Other financing activities, net |  |  | (1 | ) |  |  | (2 | ) |  |
| Net cash used in financing activities |  |  | (459 | ) |  |  | (218 | ) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (18 | ) |  |  | (5 | ) |  |
| Net change in cash, cash equivalents and restricted cash |  |  | (824 | ) |  |  | (35 | ) |  |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |
| Beginning of period |  |  | 4,119 |  |  |  | 4,535 |  |  |
| End of period |  | $ | 3,295 |  |  | $ | 4,500 |  |  |

[0000950170-22-017731:8k_2_02:114]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |

[0000950170-22-017731:8k_2_02:115]
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| Product |  | $ | 786 |  |  | $ | 894 |  |  | $ | 730 |  |
| Support |  |  | 598 |  |  |  | 590 |  |  |  | 578 |  |
| Professional and Other Services |  |  | 76 |  |  |  | 76 |  |  |  | 71 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,460 |  |  |  | 1,560 |  |  |  | 1,379 |  |
| Public Cloud Segment Net Revenues |  |  | 132 |  |  |  | 120 |  |  |  | 79 |  |
| Net Revenues |  | $ | 1,592 |  |  | $ | 1,680 |  |  | $ | 1,458 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| Product |  | $ | 391 |  |  | $ | 452 |  |  | $ | 404 |  |
| Support |  |  | 555 |  |  |  | 547 |  |  |  | 530 |  |
| Professional and Other Services |  |  | 24 |  |  |  | 22 |  |  |  | 20 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 970 |  |  |  | 1,021 |  |  |  | 954 |  |
| Public Cloud Segment Gross Profit |  |  | 92 |  |  |  | 82 |  |  |  | 56 |  |
| Total Segments Gross Profit |  |  | 1,062 |  |  |  | 1,103 |  |  |  | 1,010 |  |
| Amortization of Intangible Assets |  |  | (11 | ) |  |  | (10 | ) |  |  | (7 | ) |
| Stock-based Compensation |  |  | (5 | ) |  |  | (4 | ) |  |  | (4 | ) |
| Unallocated Cost of Revenues |  |  | (16 | ) |  |  | (14 | ) |  |  | (11 | ) |
| Gross Profit |  | $ | 1,046 |  |  | $ | 1,089 |  |  | $ | 999 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| Product |  |  | 49.7 | % |  |  | 50.6 | % |  |  | 55.3 | % |
| Support |  |  | 92.8 | % |  |  | 92.7 | % |  |  | 91.7 | % |
| Professional and Other Services |  |  | 31.6 | % |  |  | 28.9 | % |  |  | 28.2 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 66.4 | % |  |  | 65.4 | % |  |  | 69.2 | % |
| Public Cloud Segment Gross Margin |  |  | 69.7 | % |  |  | 68.3 | % |  |  | 70.9 | % |
| Product Revenues |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| Total |  | $ | 786 |  |  | $ | 894 |  |  | $ | 730 |  |
| Software* |  | $ | 476 |  |  | $ | 530 |  |  | $ | 414 |  |
| Hardware* |  | $ | 310 |  |  | $ | 364 |  |  | $ | 316 |  |
| Software and recurring support and public cloud revenue |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| Product - Software |  | $ | 476 |  |  | $ | 530 |  |  | $ | 414 |  |
| Support |  |  | 598 |  |  |  | 590 |  |  |  | 578 |  |
| Public Cloud |  |  | 132 |  |  |  | 120 |  |  |  | 79 |  |
| Software and recurring support and public cloud revenue* |  | $ | 1,206 |  |  | $ | 1,240 |  |  | $ | 1,071 |  |
| Software and recurring support and public cloud revenue as a percentage of net revenues |  |  | 76 | % |  |  | 74 | % |  |  | 73 | % |
| * Our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation. We have provided a breakdown of our GAAP product revenues into the software and hardware components, which are considered non-GAAP measures, to display the significance of software included in total product revenues. Software and recurring support and public cloud revenue is a non-GAAP measure because it includes the software component of our product revenues, but not the hardware component. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |

[0000950170-22-017731:8k_2_02:116]
|  |  | % of Q1 FY'23 |  |  | % of Q4 FY'22 |  |  | % of Q1 FY'22 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 54 | % |  |  | 54 | % |  |  | 54 | % |
| Americas Commercial |  |  | 42 | % |  |  | 45 | % |  |  | 43 | % |
| U.S. Public Sector |  |  | 12 | % |  |  | 9 | % |  |  | 11 | % |
| EMEA |  |  | 31 | % |  |  | 32 | % |  |  | 31 | % |
| Asia Pacific |  |  | 15 | % |  |  | 14 | % |  |  | 15 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q1 FY'23 |  |  | % of Q4 FY'22 |  |  | % of Q1 FY'22 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 21 | % |  |  | 24 | % |  |  | 23 | % |
| Indirect |  |  | 79 | % |  |  | 76 | % |  |  | 77 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| Non-GAAP Income from Operations |  | $ | 360 |  |  | $ | 382 |  |  | $ | 336 |  |
| % of Net Revenues |  |  | 22.6 | % |  |  | 22.7 | % |  |  | 23.0 | % |
| Non-GAAP Income before Income Taxes |  | $ | 343 |  |  | $ | 361 |  |  | $ | 324 |  |
| Non-GAAP Effective Tax Rate |  |  | 21.6 | % |  |  | 10.2 | % |  |  | 18.8 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| Non-GAAP Net Income |  | $ | 269 |  |  | $ | 324 |  |  | $ | 263 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 224 |  |  |  | 228 |  |  |  | 229 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.20 |  |  | $ | 1.42 |  |  | $ | 1.15 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 4,170 |  |  | $ | 4,232 |  |  | $ | 3,904 |  |
| DSO (days) |  |  | 49 |  |  |  | 67 |  |  |  | 41 |  |
| DPO (days) |  |  | 86 |  |  |  | 93 |  |  |  | 73 |  |
| Inventory Turns |  |  | 9 |  |  |  | 12 |  |  |  | 17 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| Net Cash Provided by Operating Activities |  | $ | 281 |  |  | $ | 411 |  |  | $ | 242 |  |
| Purchases of Property and Equipment |  | $ | 65 |  |  | $ | 68 |  |  | $ | 51 |  |
| Free Cash Flow |  | $ | 216 |  |  | $ | 343 |  |  | $ | 191 |  |
| Free Cash Flow as % of Net Revenues |  |  | 13.6 | % |  |  | 20.4 | % |  |  | 13.1 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0000950170-22-017731:8k_2_02:117]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| NET INCOME |  | $ | 214 |  |  | $ | 259 |  |  | $ | 202 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 17 |  |  |  | 14 |  |  |  | 9 |  |
| Stock-based compensation |  |  | 67 |  |  |  | 66 |  |  |  | 53 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 2 |  |
| Restructuring charges |  |  | 11 |  |  |  | 4 |  |  |  | 22 |  |
| Acquisition-related expense |  |  | 10 |  |  |  | 5 |  |  |  | 1 |  |
| Gain on sale of equity investment |  |  | (32 | ) |  |  | — |  |  |  | — |  |
| Income tax effects |  |  | (18 | ) |  |  | (24 | ) |  |  | (26 | ) |
| NON-GAAP NET INCOME |  | $ | 269 |  |  | $ | 324 |  |  | $ | 263 |  |
| COST OF REVENUES |  | $ | 546 |  |  | $ | 591 |  |  | $ | 459 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (11 | ) |  |  | (10 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (4 | ) |  |  | (4 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 530 |  |  | $ | 577 |  |  | $ | 448 |  |
| COST OF PRODUCT REVENUES |  | $ | 397 |  |  | $ | 446 |  |  | $ | 329 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (1 | ) |  |  | (3 | ) |  |  | (2 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 395 |  |  | $ | 442 |  |  | $ | 326 |  |
| COST OF SERVICES REVENUES |  | $ | 149 |  |  | $ | 145 |  |  | $ | 130 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (7 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (3 | ) |  |  | (3 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 135 |  |  | $ | 135 |  |  | $ | 122 |  |
| GROSS PROFIT |  | $ | 1,046 |  |  | $ | 1,089 |  |  | $ | 999 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 11 |  |  |  | 10 |  |  |  | 7 |  |
| Stock-based compensation |  |  | 5 |  |  |  | 4 |  |  |  | 4 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,062 |  |  | $ | 1,103 |  |  | $ | 1,010 |  |

[0000950170-22-017731:8k_2_02:118]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| SALES AND MARKETING EXPENSES |  | $ | 458 |  |  | $ | 480 |  |  | $ | 451 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (4 | ) |  |  | (2 | ) |
| Stock-based compensation |  |  | (28 | ) |  |  | (30 | ) |  |  | (26 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 424 |  |  | $ | 446 |  |  | $ | 423 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 240 |  |  | $ | 235 |  |  | $ | 210 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (24 | ) |  |  | (22 | ) |  |  | (15 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 216 |  |  | $ | 213 |  |  | $ | 195 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 72 |  |  | $ | 72 |  |  | $ | 66 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (10 | ) |  |  | (10 | ) |  |  | (8 | ) |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | (2 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 62 |  |  | $ | 62 |  |  | $ | 56 |  |
| RESTRUCTURING CHARGES |  | $ | 11 |  |  | $ | 4 |  |  | $ | 22 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (11 | ) |  |  | (4 | ) |  |  | (22 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 10 |  |  | $ | 5 |  |  | $ | 1 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (10 | ) |  |  | (5 | ) |  |  | (1 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 791 |  |  | $ | 796 |  |  | $ | 750 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (6 | ) |  |  | (4 | ) |  |  | (2 | ) |
| Stock-based compensation |  |  | (62 | ) |  |  | (62 | ) |  |  | (49 | ) |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | (2 | ) |
| Restructuring charges |  |  | (11 | ) |  |  | (4 | ) |  |  | (22 | ) |
| Acquisition-related expense |  |  | (10 | ) |  |  | (5 | ) |  |  | (1 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 702 |  |  | $ | 721 |  |  | $ | 674 |  |

[0000950170-22-017731:8k_2_02:119]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| INCOME FROM OPERATIONS |  | $ | 255 |  |  | $ | 293 |  |  | $ | 249 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 17 |  |  |  | 14 |  |  |  | 9 |  |
| Stock-based compensation |  |  | 67 |  |  |  | 66 |  |  |  | 53 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 2 |  |
| Restructuring charges |  |  | 11 |  |  |  | 4 |  |  |  | 22 |  |
| Acquisition-related expense |  |  | 10 |  |  |  | 5 |  |  |  | 1 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 360 |  |  | $ | 382 |  |  | $ | 336 |  |
| OTHER INCOME (EXPENSE), NET |  | $ | 15 |  |  | $ | (21 | ) |  | $ | (12 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Gain on sale of equity investment |  |  | (32 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP OTHER INCOME (EXPENSE), NET |  | $ | (17 | ) |  | $ | (21 | ) |  | $ | (12 | ) |
| INCOME BEFORE INCOME TAXES |  | $ | 270 |  |  | $ | 272 |  |  | $ | 237 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 17 |  |  |  | 14 |  |  |  | 9 |  |
| Stock-based compensation |  |  | 67 |  |  |  | 66 |  |  |  | 53 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 2 |  |
| Restructuring charges |  |  | 11 |  |  |  | 4 |  |  |  | 22 |  |
| Acquisition-related expense |  |  | 10 |  |  |  | 5 |  |  |  | 1 |  |
| Gain on sale of equity investment |  |  | (32 | ) |  |  | — |  |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 343 |  |  | $ | 361 |  |  | $ | 324 |  |
| PROVISION FOR INCOME TAXES |  | $ | 56 |  |  | $ | 13 |  |  | $ | 35 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 18 |  |  |  | 24 |  |  |  | 26 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 74 |  |  | $ | 37 |  |  | $ | 61 |  |
| NET INCOME PER SHARE |  | $ | 0.96 |  |  | $ | 1.14 |  |  | $ | 0.88 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.08 |  |  |  | 0.06 |  |  |  | 0.04 |  |
| Stock-based compensation |  |  | 0.30 |  |  |  | 0.29 |  |  |  | 0.23 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | 0.01 |  |
| Restructuring charges |  |  | 0.05 |  |  |  | 0.02 |  |  |  | 0.10 |  |
| Acquisition-related expense |  |  | 0.04 |  |  |  | 0.02 |  |  |  | — |  |
| Gain on sale of equity investment |  |  | (0.14 | ) |  |  | — |  |  |  | — |  |
| Income tax effects |  |  | (0.08 | ) |  |  | (0.11 | ) |  |  | (0.11 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.20 |  |  | $ | 1.42 |  |  | $ | 1.15 |  |

[0000950170-22-017731:8k_2_02:120]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| Gross margin-GAAP |  |  | 65.7 | % |  |  | 64.8 | % |  |  | 68.5 | % |
| Cost of revenues adjustments |  |  | 1.0 | % |  |  | 0.8 | % |  |  | 0.8 | % |
| Gross margin-Non-GAAP |  |  | 66.7 | % |  |  | 65.7 | % |  |  | 69.3 | % |
| GAAP cost of revenues |  | $ | 546 |  |  | $ | 591 |  |  | $ | 459 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (11 | ) |  |  | (10 | ) |  |  | (7 | ) |
| Stock-based compensation |  |  | (5 | ) |  |  | (4 | ) |  |  | (4 | ) |
| Non-GAAP cost of revenues |  | $ | 530 |  |  | $ | 577 |  |  | $ | 448 |  |
| Net revenues |  | $ | 1,592 |  |  | $ | 1,680 |  |  | $ | 1,458 |  |

[0000950170-22-017731:8k_2_02:121]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| Product gross margin-GAAP |  |  | 49.5 | % |  |  | 50.1 | % |  |  | 54.9 | % |
| Cost of product revenues adjustments |  |  | 0.3 | % |  |  | 0.4 | % |  |  | 0.4 | % |
| Product gross margin-Non-GAAP |  |  | 49.7 | % |  |  | 50.6 | % |  |  | 55.3 | % |
| GAAP cost of product revenues |  | $ | 397 |  |  | $ | 446 |  |  | $ | 329 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (1 | ) |  |  | (3 | ) |  |  | (2 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 395 |  |  | $ | 442 |  |  | $ | 326 |  |
| Product revenues |  | $ | 786 |  |  | $ | 894 |  |  | $ | 730 |  |

[0000950170-22-017731:8k_2_02:122]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| Services gross margin-GAAP |  |  | 81.5 | % |  |  | 81.6 | % |  |  | 82.1 | % |
| Cost of services revenues adjustments |  |  | 1.7 | % |  |  | 1.3 | % |  |  | 1.1 | % |
| Services gross margin-Non-GAAP |  |  | 83.3 | % |  |  | 82.8 | % |  |  | 83.2 | % |
| GAAP cost of services revenues |  | $ | 149 |  |  | $ | 145 |  |  | $ | 130 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (7 | ) |  |  | (5 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (3 | ) |  |  | (3 | ) |
| Non-GAAP cost of services revenues |  | $ | 135 |  |  | $ | 135 |  |  | $ | 122 |  |
| Services revenues |  | $ | 806 |  |  | $ | 786 |  |  | $ | 728 |  |

[0000950170-22-017731:8k_2_02:123]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| GAAP effective tax rate |  |  | 20.7 | % |  |  | 4.8 | % |  |  | 14.8 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 0.8 | % |  |  | 5.5 | % |  |  | 4.1 | % |
| Non-GAAP effective tax rate |  |  | 21.6 | % |  |  | 10.2 | % |  |  | 18.8 | % |

[0000950170-22-017731:8k_2_02:124]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| Net cash provided by operating activities |  | $ | 281 |  |  | $ | 411 |  |  | $ | 242 |  |
| Purchases of property and equipment |  |  | (65 | ) |  |  | (68 | ) |  |  | (51 | ) |
| Free cash flow |  | $ | 216 |  |  | $ | 343 |  |  | $ | 191 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q1'FY23 |  |  | Q4'FY22 |  |  | Q1'FY22 |  |
| Net revenues |  | $ | 1,592 |  |  | $ | 1,680 |  |  | $ | 1,458 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | (32 | ) |  |  | 338 |  |  |  | (82 | ) |
| Billings |  | $ | 1,560 |  |  | $ | 2,018 |  |  | $ | 1,376 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0000950170-22-017731:8k_2_02:125]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| SECOND QUARTER FISCAL 2023 |
|  |  | Second Quarter |
|  |  | Fiscal 2023 |
| Non-GAAP Guidance - Net Income Per Share |  | $1.28 - $1.38 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the Second Quarter Fiscal 2023: |  |  |
| Amortization of intangible assets |  | ($0.08) |
| Stock-based compensation expense |  | ($0.33) |
| Income tax effects |  | $0.06 |
| Total Adjustments |  | ($0.35) |
| GAAP Guidance - Net Income Per Share |  | $0.93 - $1.03 |

[0000950170-22-017731:8k_2_02:126]
Some items may not add or recalculate due to rounding.

[0000950170-22-017731:8k_2_02:127]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| FISCAL 2023 |
|  |  | Fiscal 2023 |
| Gross Margin - Non-GAAP Guidance |  | 66% - 67% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | (1)% |
| Gross Margin - GAAP Guidance |  | 65% - 66% |
|  |  | Fiscal 2023 |
| Operating Margin - Non-GAAP Guidance |  | 23% - 24% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | (1)% |
| Stock-based compensation expense |  | (4)% |
| Operating Margin - GAAP Guidance |  | 18% - 19% |

[0000950170-22-017731:8k_2_02:128]
Some items may not add or recalculate due to rounding.

[0000950170-22-017731:8k_2_02:129]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FISCAL 2023 |
|  |  | Fiscal 2023 |
| Non-GAAP Guidance - Net Income Per Share |  | $5.40 - $5.60 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2023: |  |  |
| Amortization of intangible assets |  | ($0.31) |
| Stock-based compensation expense |  | ($1.33) |
| Restructuring charges |  | ($0.05) |
| Acquisition-related expenses |  | ($0.04) |
| Gain on sale of equity investment |  | $0.14 |
| Income tax effects |  | $0.28 |
| Total Adjustments |  | ($1.31) |
| GAAP Guidance - Net Income Per Share |  | $4.09 - $4.29 |

[0000950170-22-017731:8k_2_02:130]
Some items may not add or recalculate due to rounding.

[0000950170-22-017731:8k_2_02:131]
Contacts:

[0000950170-22-017731:8k_2_02:132]
(Press)

[0000950170-22-017731:8k_2_02:133]
Chris Drago

[0000950170-22-017731:8k_2_02:134]
1 831 900 8889

[0000950170-22-017731:8k_2_02:135]
chris.drago@netapp.com

[0000950170-22-017731:8k_2_02:136]
(Investors)

[0000950170-22-017731:8k_2_02:137]
Lance Berger

[0000950170-22-017731:8k_2_02:138]
1 408 822 6628

[0000950170-22-017731:8k_2_02:139]
lance.berger@netapp.com
