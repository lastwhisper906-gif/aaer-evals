# NTAP notes — 0001564590-16-014119


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001564590-16-014119:notes:1]
[same as prior period, unchanged from 0001564590-15-011213:notes:1]

[0001564590-16-014119:notes:2]
[same as prior period, unchanged from 0001564590-15-011213:notes:2]

[0001564590-16-014119:notes:3]
[same as prior period, unchanged from 0001564590-15-011213:notes:3]

[0001564590-16-014119:notes:4]
[same as prior period, unchanged from 0001564590-15-011213:notes:4]

[0001564590-16-014119:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income (loss) and cash flows for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and in accordance with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 24, 2015 contained in our Annual Report on Form 10-K filed with the Securities and Exchange Commission on June 12, 2015. The results of operations for the three and nine months ended January 29, 2016 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0001564590-16-014119:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation and purchase order accruals; valuation of goodwill and intangibles; restructuring reserves; product warranties; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates.

[0001564590-16-014119:notes:7]
During the three months ended January 29, 2016, we adopted an accounting standard that simplified the presentation of deferred taxes by requiring deferred tax assets and liabilities to be classified as noncurrent in a classified statement of financial position. We have adopted this accounting standard prospectively. Accordingly, the prior period amounts in our condensed consolidated balance sheets within this Quarterly Report on Form 10-Q were not adjusted to conform to the new accounting standard. The adoption of this accounting standard was not material to our condensed consolidated financial statements.

[0001564590-16-014119:notes:8]
There have been no significant changes in our significant accounting policies as of and for the nine months ended January 29, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended April 24, 2015.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001564590-16-014119:notes:9]
[same as prior period, unchanged from 0001564590-15-011213:notes:8]

[0001564590-16-014119:notes:10]
[same as prior period, unchanged from 0001564590-15-011213:notes:9]

[0001564590-16-014119:notes:11]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 14 |  |  | $ | 12 |  |
| Acquisition of software through long-term financing |  | $ | — |  |  | $ | 12 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 113 |  |  | $ | 89 |  |
| Interest paid |  | $ | 40 |  |  | $ | 33 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-16-014119:notes:12]
4. Business Combinations

[0001564590-16-014119:notes:13]
On October 27, 2014, we completed the acquisition of certain assets related to Riverbed Technology, Inc.’s SteelStore product line for $79 million in cash. The SteelStore product line supports leading backup applications and cloud providers so that customers have a choice in how they extend their existing data protection infrastructure into the cloud.

[0001564590-16-014119:notes:14]
In addition, on the same date, we acquired certain intangible assets from a privately-held software developer for $6 million in cash.

[0001564590-16-014119:notes:15]
Following are the fair values of net assets acquired as of the closing date (in millions):

[0001564590-16-014119:notes:16]
| Tangible net assets |  | $ | 14 |  |
| Finite-lived intangible assets |  |  | 32 |  |
| Goodwill |  |  | 39 |  |
| Total purchase price |  | $ | 85 |  |

[0001564590-16-014119:notes:17]
The results of operations related to these acquisitions have been included in our condensed consolidated statements of operations from the acquisition date. Pro forma results of operations have not been presented because the acquisitions were not material to our results of operations.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-16-014119:notes:18]
5. Purchased Intangible Assets, Net

[0001564590-16-014119:notes:19]
[same as prior period, unchanged from 0001564590-15-011213:notes:12]

[0001564590-16-014119:notes:20]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 304 |  |  | $ | (268 | ) |  | $ | 36 |  |  | $ | 313 |  |  | $ | (225 | ) |  | $ | 88 |  |
| Customer contracts/relationships |  |  | 5 |  |  |  | (4 | ) |  |  | 1 |  |  |  | 5 |  |  |  | (3 | ) |  |  | 2 |  |
| Other purchased intangibles |  |  | 1 |  |  |  | (1 | ) |  |  | — |  |  |  | 3 |  |  |  | (3 | ) |  |  | — |  |
| Total purchased intangible assets |  | $ | 310 |  |  | $ | (273 | ) |  | $ | 37 |  |  | $ | 321 |  |  | $ | (231 | ) |  | $ | 90 |  |

[0001564590-16-014119:notes:21]
During the nine months ended January 29, 2016, we recorded a charge of $11 million to fully impair developed technology related to our fiscal 2013 acquisition of CacheIQ as a result of our discontinued use of such technology. The impairment charge is included in accumulated amortization in the table above.

[0001564590-16-014119:notes:22]
[same as prior period, unchanged from 0001564590-15-011213:notes:15]

[0001564590-16-014119:notes:23]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Statement of |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | Operations Classifications |
| Developed technology |  | $ | 13 |  |  | $ | 18 |  |  | $ | 41 |  |  | $ | 47 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  | Operating expenses |
| Total |  | $ | 14 |  |  | $ | 19 |  |  | $ | 42 |  |  | $ | 48 |  |  |  |

[0001564590-16-014119:notes:24]
As of January 29, 2016, future amortization expense related to purchased intangible assets is as follows (in millions):

[0001564590-16-014119:notes:25]
| Fiscal Year |  | Amount |  |
| Remainder of 2016 |  | $ | 13 |  |
| 2017 |  |  | 10 |  |
| 2018 |  |  | 6 |  |
| 2019 |  |  | 5 |  |
| 2020 |  |  | 3 |  |
| Total |  | $ | 37 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-16-014119:notes:26]
6. Balance Sheet Details

[0001564590-16-014119:notes:27]
[same as prior period, unchanged from 0001564590-15-011213:notes:20]

[0001564590-16-014119:notes:28]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Cash |  | $ | 2,347 |  |  | $ | 1,666 |  |
| Cash equivalents |  |  | 148 |  |  |  | 256 |  |
| Cash and cash equivalents |  | $ | 2,495 |  |  | $ | 1,922 |  |

[0001564590-16-014119:notes:29]
[same as prior period, unchanged from 0001564590-15-011213:notes:22]

[0001564590-16-014119:notes:30]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Purchased components |  | $ | 25 |  |  | $ | 36 |  |
| Finished goods |  |  | 77 |  |  |  | 110 |  |
| Inventories |  | $ | 102 |  |  | $ | 146 |  |

[0001564590-16-014119:notes:31]
[same as prior period, unchanged from 0001564590-15-011213:notes:24]

[0001564590-16-014119:notes:32]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Prepaid expenses and other current assets |  | $ | 354 |  |  | $ | 268 |  |
| Deferred tax assets |  |  | — |  |  |  | 254 |  |
| Other current assets |  | $ | 354 |  |  | $ | 522 |  |

[0001564590-16-014119:notes:33]
[same as prior period, unchanged from 0001564590-15-011213:notes:26]

[0001564590-16-014119:notes:34]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Land |  | $ | 181 |  |  | $ | 265 |  |
| Buildings and improvements |  |  | 543 |  |  |  | 607 |  |
| Leasehold improvements |  |  | 103 |  |  |  | 107 |  |
| Computer, production, engineering and other equipment |  |  | 751 |  |  |  | 754 |  |
| Computer software |  |  | 351 |  |  |  | 372 |  |
| Furniture and fixtures |  |  | 83 |  |  |  | 85 |  |
| Construction-in-progress |  |  | 63 |  |  |  | 33 |  |
|  |  |  | 2,075 |  |  |  | 2,223 |  |
| Accumulated depreciation and amortization |  |  | (1,202 | ) |  |  | (1,193 | ) |
| Property and equipment, net |  | $ | 873 |  |  | $ | 1,030 |  |

[0001564590-16-014119:notes:35]
During the three months ended January 29, 2016, we reported certain land and buildings previously reported as property and equipment, net as assets held-for-sale because we expect to sell them within the next twelve months. The net carrying value of these assets was $117 million as of January 29, 2016 and is included in other current assets in the condensed consolidated balance sheets.

[0001564590-16-014119:notes:36]
[same as prior period, unchanged from 0001564590-15-011213:notes:28]

[0001564590-16-014119:notes:37]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Deferred tax assets |  | $ | 605 |  |  | $ | 256 |  |
| Other assets |  |  | 179 |  |  |  | 225 |  |
| Other non-current assets |  | $ | 784 |  |  | $ | 481 |  |

[0001564590-16-014119:notes:38]
[same as prior period, unchanged from 0001564590-15-011213:notes:30]

[0001564590-16-014119:notes:39]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Accrued compensation and benefits |  | $ | 274 |  |  | $ | 359 |  |
| Product warranty liability |  |  | 49 |  |  |  | 58 |  |
| Other current liabilities |  |  | 294 |  |  |  | 284 |  |
| Accrued expenses |  | $ | 617 |  |  | $ | 701 |  |

[0001564590-16-014119:notes:40]
[same as prior period, unchanged from 0001564590-15-011213:notes:32]

[0001564590-16-014119:notes:41]
[same as prior period, unchanged from 0001564590-15-011213:notes:33]

[0001564590-16-014119:notes:42]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Balance at beginning of period |  | $ | 80 |  |  | $ | 97 |  |  | $ | 86 |  |  | $ | 110 |  |
| Expense accrued during the period |  |  | 5 |  |  |  | 3 |  |  |  | 27 |  |  |  | 22 |  |
| Warranty costs incurred |  |  | (12 | ) |  |  | (12 | ) |  |  | (40 | ) |  |  | (44 | ) |
| Balance at end of period |  | $ | 73 |  |  | $ | 88 |  |  | $ | 73 |  |  | $ | 88 |  |

[0001564590-16-014119:notes:43]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Accrued expenses |  | $ | 49 |  |  | $ | 58 |  |
| Other long-term liabilities |  |  | 24 |  |  |  | 28 |  |
| Total warranty liabilities |  | $ | 73 |  |  | $ | 86 |  |

[0001564590-16-014119:notes:44]
[same as prior period, unchanged from 0001564590-15-011213:notes:36]

[0001564590-16-014119:notes:45]
[same as prior period, unchanged from 0001564590-15-011213:notes:37]

[0001564590-16-014119:notes:46]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Deferred product revenue |  | $ | 48 |  |  | $ | 17 |  |
| Deferred services revenue |  |  | 2,905 |  |  |  | 3,075 |  |
| Financed unearned services revenue |  |  | 172 |  |  |  | 105 |  |
| Total |  | $ | 3,125 |  |  | $ | 3,197 |  |
| Reported as: |  |  |  |  |  |  |  |  |
| Short-term |  | $ | 1,684 |  |  | $ | 1,724 |  |
| Long-term |  |  | 1,441 |  |  |  | 1,473 |  |
| Total |  | $ | 3,125 |  |  | $ | 3,197 |  |

[0001564590-16-014119:notes:47]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware maintenance contracts and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 16 for additional information related to these arrangements.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001564590-16-014119:notes:48]
7. Other income (expense), net

[0001564590-16-014119:notes:49]
[same as prior period, unchanged from 0001564590-15-011213:notes:41]

[0001564590-16-014119:notes:50]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Interest income |  | $ | 11 |  |  | $ | 9 |  |  | $ | 35 |  |  | $ | 25 |  |
| Interest expense |  |  | (11 | ) |  |  | (11 | ) |  |  | (34 | ) |  |  | (31 | ) |
| Other expense, net |  |  | (2 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Total other income (expense), net |  | $ | (2 | ) |  | $ | (2 | ) |  | $ | 1 |  |  | $ | (6 | ) |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001564590-16-014119:notes:51]
8. Financial Instruments and Fair Value Measurements

[0001564590-16-014119:notes:52]
[same as prior period, unchanged from 0001564590-15-011213:notes:44]

[0001564590-16-014119:notes:53]
[same as prior period, unchanged from 0001564590-15-011213:notes:45]

[0001564590-16-014119:notes:54]
[same as prior period, unchanged from 0001564590-15-011213:notes:46]

[0001564590-16-014119:notes:55]
[same as prior period, unchanged from 0001564590-15-011213:notes:47]

[0001564590-16-014119:notes:56]
[same as prior period, unchanged from 0001564590-15-011213:notes:48]

[0001564590-16-014119:notes:57]
[same as prior period, unchanged from 0001564590-15-011213:notes:49]

[0001564590-16-014119:notes:58]
[same as prior period, unchanged from 0001564590-15-011213:notes:50]

[0001564590-16-014119:notes:59]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
|  |  | Cost or |  |  |  |  |  | Estimated |  |  | Cost or |  |  |  |  |  | Estimated |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
|  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,496 |  |  | $ | 2 |  |  | $ | (4 | ) |  | $ | 1,494 |  |  | $ | 2,249 |  |  | $ | 9 |  |  | $ | — |  |  | $ | 2,258 |  |
| U.S. Treasury and government debt securities |  |  | 1,019 |  |  |  | 1 |  |  |  | — |  |  |  | 1,020 |  |  |  | 1,056 |  |  |  | 2 |  |  |  | — |  |  |  | 1,058 |  |
| Foreign government debt securities |  |  | 39 |  |  |  | — |  |  |  | — |  |  |  | 39 |  |  |  | 38 |  |  |  | — |  |  |  | — |  |  |  | 38 |  |
| Commercial paper |  |  | 7 |  |  |  | — |  |  |  | — |  |  |  | 7 |  |  |  | 20 |  |  |  | — |  |  |  | — |  |  |  | 20 |  |
| Certificates of deposit |  |  | 116 |  |  |  | — |  |  |  | — |  |  |  | 116 |  |  |  | 286 |  |  |  | — |  |  |  | — |  |  |  | 286 |  |
| Mutual funds |  |  | 29 |  |  |  | — |  |  |  | — |  |  |  | 29 |  |  |  | 32 |  |  |  | — |  |  |  | — |  |  |  | 32 |  |
| Total debt and equity securities |  | $ | 2,706 |  |  | $ | 3 |  |  | $ | (4 | ) |  | $ | 2,705 |  |  | $ | 3,681 |  |  | $ | 11 |  |  | $ | — |  |  | $ | 3,692 |  |

[0001564590-16-014119:notes:60]
As of January 29, 2016, gross unrealized losses related to individual securities were not significant.

[0001564590-16-014119:notes:61]
The following table presents the contractual maturities of our debt investments as of January 29, 2016 (in millions):

[0001564590-16-014119:notes:62]
|  |  | Amortized Cost |  |  | Fair Value |  |
| Due in one year or less |  | $ | 839 |  |  | $ | 839 |  |
| Due after one year through five years |  |  | 1,838 |  |  |  | 1,837 |  |
|  |  | $ | 2,677 |  |  | $ | 2,676 |  |

[0001564590-16-014119:notes:63]
[same as prior period, unchanged from 0001564590-15-011213:notes:55]

[0001564590-16-014119:notes:64]
[same as prior period, unchanged from 0001564590-15-011213:notes:56]

[0001564590-16-014119:notes:65]
[same as prior period, unchanged from 0001564590-15-011213:notes:57]

[0001564590-16-014119:notes:66]
|  |  | January 29, 2016 |  |
|  |  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 2,347 |  |  | $ | 2,347 |  |  | $ | — |  |
| Corporate bonds |  |  | 1,494 |  |  |  | — |  |  |  | 1,494 |  |
| U.S. Treasury and government debt securities |  |  | 1,020 |  |  |  | 325 |  |  |  | 695 |  |
| Foreign government debt securities |  |  | 39 |  |  |  | — |  |  |  | 39 |  |
| Commercial paper |  |  | 7 |  |  |  | — |  |  |  | 7 |  |
| Certificates of deposit |  |  | 116 |  |  |  | — |  |  |  | 116 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 5,023 |  |  | $ | 2,672 |  |  | $ | 2,351 |  |
| Other items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 5 |  |  | $ | 5 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 24 |  |  | $ | 24 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 5 |  |  | $ | — |  |  | $ | 5 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |
| Long-term debt |  | $ | (1,492 | ) |  | $ | — |  |  | $ | (1,492 | ) |

[0001564590-16-014119:notes:67]
[same as prior period, unchanged from 0001564590-15-011213:notes:59]

[0001564590-16-014119:notes:68]
[same as prior period, unchanged from 0001564590-15-011213:notes:60]

[0001564590-16-014119:notes:69]
| (3) | Reported as accrued expenses in the condensed consolidated balance sheets |

[0001564590-16-014119:notes:70]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of January 29, 2016 and April 24, 2015, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0001564590-16-014119:notes:71]
[same as prior period, unchanged from 0001564590-15-011213:notes:62]

[0001564590-16-014119:notes:72]
[same as prior period, unchanged from 0001564590-15-011213:notes:63]


## us-gaap:DebtDisclosureTextBlock

[0001564590-16-014119:notes:73]
9. Financing Arrangements

[0001564590-16-014119:notes:74]
Long-Term Debt

[0001564590-16-014119:notes:75]
The following table summarizes information relating to our long-term debt (in millions, except interest rates):

[0001564590-16-014119:notes:76]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
|  |  |  |  |  |  | Effective |  |  |  |  |  |  | Effective |  |
|  |  | Amount |  |  | Interest Rate |  |  | Amount |  |  | Interest Rate |  |
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |  |  | 2.25 | % |  | $ | 750 |  |  |  | 2.25 | % |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |  |  | 3.54 | % |  |  | 500 |  |  |  | 3.54 | % |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |  |  | 3.43 | % |  |  | 250 |  |  |  | 3.43 | % |
| Total principal amount |  |  | 1,500 |  |  |  |  |  |  |  | 1,500 |  |  |  |  |  |
| Less: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unamortized discount |  |  | (4 | ) |  |  |  |  |  |  | (5 | ) |  |  |  |  |
| Unamortized issuance costs |  |  | (6 | ) |  |  |  |  |  |  | (8 | ) |  |  |  |  |
| Total long-term debt |  | $ | 1,490 |  |  |  |  |  |  | $ | 1,487 |  |  |  |  |  |

[0001564590-16-014119:notes:77]
Senior Notes

[0001564590-16-014119:notes:78]
In June 2014, we issued $500 million par value of 3.375% Senior Notes due June 15, 2021, and received proceeds of approximately $495 million, net of discount and issuance costs. Our 2.00% Senior Notes and 3.25% Senior Notes, with a par value of $750 million and $250 million, respectively, were issued in December 2012. We collectively refer to such long-term debt as our Senior Notes. Interest on our Senior Notes is paid semi-annually on June 15 and December 15. Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any future senior unsecured indebtedness.

[0001564590-16-014119:notes:79]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of January 29, 2016, we were in compliance with all covenants associated with the Senior Notes.

[0001564590-16-014119:notes:80]
As of January 29, 2016, our aggregate future principal debt maturities are as follows (in millions):

[0001564590-16-014119:notes:81]
| Fiscal Year |  | Amount |  |
| 2018 |  | $ | 750 |  |
| Thereafter |  |  | 750 |  |
| Total |  | $ | 1,500 |  |

[0001564590-16-014119:notes:82]
Credit Facility

[0001564590-16-014119:notes:83]
In December 2012, we entered into a credit agreement with a syndicated group of lenders that is scheduled to expire on December 21, 2017 and provides for an unsecured $250 million revolving credit facility that is comprised of revolving loans, Eurocurrency loans and/or swingline loans. The credit facility includes a $100 million foreign currency sub-facility, a $50 million letter of credit sub-facility and a $10 million swingline sub-facility available on same-day notice. Available borrowings under the credit facility are reduced by the amount of any outstanding borrowings on the sub-facilities. We may also, subject to certain requirements, request an increase in the facility up to an additional $100 million and request two additional one-year extensions, subject to certain conditions. The proceeds from the facility may be used by us for general corporate purposes.

[0001564590-16-014119:notes:84]
Borrowings under the facility, except for swingline loans, accrue interest in arrears at an alternate base rate as defined in the credit agreement or, at our option, an adjusted London Interbank Offered Rate (LIBOR) plus in each case, a spread (based on our public debt ratings and the type of loan) ranging from 0.2% to 1.2%. Swingline borrowings accrue interest at an alternate base rate. In addition, we are required to pay fees to maintain the credit facility, whether or not we have outstanding borrowings. The facility contains financial covenants requiring us to maintain a maximum leverage ratio of not more than 3.0:1.0 and a minimum interest coverage ratio of not less than 3.5:1.0. The facility contains customary affirmative and negative covenants, including covenants that limit our ability to incur debt secured by liens on assets or indebtedness of our subsidiaries and to consolidate, merge or sell all or substantially all of our assets. As of January 29, 2016, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-16-014119:notes:85]
Other Long-Term Financing Arrangements

[0001564590-16-014119:notes:86]
The following presents the amounts due under other long-term financing arrangements (in millions):

[0001564590-16-014119:notes:87]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Other long-term financing arrangements |  | $ | 8 |  |  | $ | 16 |  |
| Less: current portion |  |  | (5 | ) |  |  | (10 | ) |
| Non-current portion of other long-term financing arrangements |  | $ | 3 |  |  | $ | 6 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001564590-16-014119:notes:88]
10. Stockholders’ Equity

[0001564590-16-014119:notes:89]
[same as prior period, unchanged from 0001564590-15-011213:notes:80]

[0001564590-16-014119:notes:90]
As of January 29, 2016, we have outstanding certain equity incentive awards (awards), which include stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and Employee Stock Purchase Plan (ESPP) awards.

[0001564590-16-014119:notes:91]
[same as prior period, unchanged from 0001564590-15-011213:notes:82]

[0001564590-16-014119:notes:92]
[same as prior period, unchanged from 0001564590-15-011213:notes:83]

[0001564590-16-014119:notes:93]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (Years) |  |  | Aggregate Intrinsic Value |  |
| Outstanding as of April 24, 2015 |  |  | 12 |  |  | $ | 37.74 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (1 | ) |  | $ | 21.15 |  |  |  |  |  |  |  |  |  |
| Forfeited and expired |  |  | (3 | ) |  | $ | 39.11 |  |  |  |  |  |  |  |  |  |
| Outstanding as of January 29, 2016 |  |  | 8 |  |  | $ | 39.68 |  |  |  | 2.64 |  |  | $ | 1 |  |
| Vested and expected to vest as of January 29, 2016 |  |  | 8 |  |  | $ | 39.73 |  |  |  | 2.55 |  |  | $ | 1 |  |
| Exercisable as of January 29, 2016 |  |  | 7 |  |  | $ | 40.29 |  |  |  | 2.17 |  |  | $ | 1 |  |

[0001564590-16-014119:notes:94]
[same as prior period, unchanged from 0001564590-15-011213:notes:85]

[0001564590-16-014119:notes:95]
[same as prior period, unchanged from 0001564590-15-011213:notes:86]

[0001564590-16-014119:notes:96]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Intrinsic value of exercises |  | $ | 12 |  |  | $ | 61 |  |
| Proceeds received from exercises |  | $ | 24 |  |  | $ | 100 |  |
| Fair value of options vested |  | $ | 10 |  |  | $ | 26 |  |

[0001564590-16-014119:notes:97]
[same as prior period, unchanged from 0001564590-15-011213:notes:88]

[0001564590-16-014119:notes:98]
In the nine months ended January 29, 2016, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service based vesting criteria) such that the PBRSU cliff-vests at the end of either an approximate two year or three year performance period, which began on the date specified in the grant agreement and ends the last day of fiscal 2017 or 2018, respectively. The number of shares of common stock that will be issued to settle the PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted, and will depend upon our Total Stockholder Return (TSR) as compared to an index TSR (each expressed as a growth rate percentage) calculated as of the applicable period end date. The fair values of the PBRSUs were fixed at grant date using a Monte Carlo simulation model and the related aggregate compensation cost of $20 million is being recognized, adjusted for forfeitures, over the shorter of the remaining applicable performance or service periods.

[0001564590-16-014119:notes:99]
RSUs are converted into common stock upon vesting. Time-based RSUs generally vest with only service-based criteria at 25% annually over four years, except for the PBRSUs described above and 4 million time-based RSUs granted in the nine months ended January 29, 2016, which will vest at 50% annually over two years.

[0001564590-16-014119:notes:100]
[same as prior period, unchanged from 0001564590-15-011213:notes:91]

[0001564590-16-014119:notes:101]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Outstanding as of April 24, 2015 |  |  | 13 |  |  | $ | 36.58 |  |
| Granted |  |  | 6 |  |  | $ | 30.49 |  |
| Vested |  |  | (5 | ) |  | $ | 37.67 |  |
| Forfeited |  |  | (2 | ) |  | $ | 35.08 |  |
| Outstanding as of January 29, 2016 |  |  | 12 |  |  | $ | 33.46 |  |

[0001564590-16-014119:notes:102]
[same as prior period, unchanged from 0001564590-15-011213:notes:93]

[0001564590-16-014119:notes:103]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Shares withheld for taxes |  |  | 2 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 47 |  |  | $ | 51 |  |

[0001564590-16-014119:notes:104]
[same as prior period, unchanged from 0001564590-15-011213:notes:95]

[0001564590-16-014119:notes:105]
[same as prior period, unchanged from 0001564590-15-011213:notes:96]

[0001564590-16-014119:notes:106]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Shares issued under the ESPP |  |  | 3 |  |  |  | 3 |  |
| Proceeds from issuance of shares |  | $ | 93 |  |  | $ | 97 |  |

[0001564590-16-014119:notes:107]
[same as prior period, unchanged from 0001564590-15-011213:notes:98]

[0001564590-16-014119:notes:108]
[same as prior period, unchanged from 0001564590-15-011213:notes:99]

[0001564590-16-014119:notes:109]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Cost of product revenues |  | $ | 1 |  |  | $ | 2 |  |  | $ | 4 |  |  | $ | 5 |  |
| Cost of hardware maintenance and other services revenues |  |  | 5 |  |  |  | 4 |  |  |  | 15 |  |  |  | 12 |  |
| Sales and marketing |  |  | 27 |  |  |  | 30 |  |  |  | 84 |  |  |  | 87 |  |
| Research and development |  |  | 20 |  |  |  | 21 |  |  |  | 64 |  |  |  | 64 |  |
| General and administrative |  |  | 10 |  |  |  | 9 |  |  |  | 32 |  |  |  | 28 |  |
| Total stock-based compensation expense |  | $ | 63 |  |  | $ | 66 |  |  | $ | 199 |  |  | $ | 196 |  |

[0001564590-16-014119:notes:110]
As of January 29, 2016, total unrecognized compensation expense related to our equity awards was $341 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 1.9 years.

[0001564590-16-014119:notes:111]
[same as prior period, unchanged from 0001564590-15-011213:notes:102]

[0001564590-16-014119:notes:112]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Income tax benefit associated with employee stock transactions |  | $ | 37 |  |  | $ | 54 |  |

[0001564590-16-014119:notes:113]
[same as prior period, unchanged from 0001564590-15-011213:notes:104]

[0001564590-16-014119:notes:114]
As of January 29, 2016, our Board of Directors has authorized the repurchase of up to $9.6 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management.

[0001564590-16-014119:notes:115]
The following table summarizes activity related to this program for the nine months ended January 29, 2016 (in millions, except per share amounts):

[0001564590-16-014119:notes:116]
| Number of shares repurchased |  |  | 23 |  |
| Average price per share |  | $ | 30.75 |  |
| Aggregate purchase price |  | $ | 698 |  |
| Remaining authorization at end of period |  | $ | 1,762 |  |

[0001564590-16-014119:notes:117]
The aggregate purchase price of our stock repurchases for the nine months ended January 29, 2016 consisted of $698 million of open market purchases, of which $534 million and $164 million was allocated to additional paid-in capital and retained earnings, respectively.

[0001564590-16-014119:notes:118]
Since the May 13, 2003 inception of our stock repurchase program through January 29, 2016, we repurchased a total of 237 million shares of our common stock at an average price of $33.22 per share, for an aggregate purchase price of $7.9 billion.

[0001564590-16-014119:notes:119]
[same as prior period, unchanged from 0001564590-15-011213:notes:110]

[0001564590-16-014119:notes:120]
[same as prior period, unchanged from 0001564590-15-011213:notes:111]

[0001564590-16-014119:notes:121]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Dividends per share declared |  | $ | 0.540 |  |  | $ | 0.495 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 84 |  |  | $ | 52 |  |
| Dividend payments allocated to retained earnings |  | $ | 75 |  |  | $ | 105 |  |

[0001564590-16-014119:notes:122]
On February 17, 2016, we declared a cash dividend of $0.18 per share of common stock, payable on April 27, 2016 to holders of record as of the close of business on April 8, 2016. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0001564590-16-014119:notes:123]
[same as prior period, unchanged from 0001564590-15-011213:notes:114]

[0001564590-16-014119:notes:124]
[same as prior period, unchanged from 0001564590-15-011213:notes:115]

[0001564590-16-014119:notes:125]
| Balance as of April 24, 2015 |  | $ | 53 |  |
| Net income |  |  | 237 |  |
| Repurchases of common stock |  |  | (164 | ) |
| Dividends |  |  | (75 | ) |
| Balance as of January 29, 2016 |  | $ | 51 |  |

[0001564590-16-014119:notes:126]
[same as prior period, unchanged from 0001564590-15-011213:notes:117]

[0001564590-16-014119:notes:127]
[same as prior period, unchanged from 0001564590-15-011213:notes:118]

[0001564590-16-014119:notes:128]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Obligation Adjustments |  |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Total |  |
| Balance as of April 24, 2015 |  | $ | (23 | ) |  | $ | (13 | ) |  | $ | 11 |  |  | $ | 1 |  |  | $ | (24 | ) |
| OCI before reclassifications, net of tax |  |  | (7 | ) |  |  | — |  |  |  | (11 | ) |  |  | — |  |  |  | (18 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | 2 |  |  |  | (1 | ) |  |  | — |  |  |  | 1 |  |
| Total OCI |  |  | (7 | ) |  |  | 2 |  |  |  | (12 | ) |  |  | — |  |  |  | (17 | ) |
| Balance as of January 29, 2016 |  | $ | (30 | ) |  | $ | (11 | ) |  | $ | (1 | ) |  | $ | 1 |  |  | $ | (41 | ) |

[0001564590-16-014119:notes:129]
[same as prior period, unchanged from 0001564590-15-011213:notes:120]

[0001564590-16-014119:notes:130]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  |  |
|  |  | Amounts Reclassified from AOCI |  |  | Amounts Reclassified from AOCI |  |  | Statements of Operations Location |
| Recognized losses on defined benefit obligations |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | Operating expenses |
| Realized gains on available-for-sale securities |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | — |  |  | Other income (expense), net |
| Realized gains on cash flow hedges |  |  | (2 | ) |  |  | (15 | ) |  |  | — |  |  |  | (9 | ) |  | Net revenues |
| Total reclassifications |  | $ | (2 | ) |  | $ | (15 | ) |  | $ | 1 |  |  | $ | (9 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-16-014119:notes:131]
11. Derivatives and Hedging Activities

[0001564590-16-014119:notes:132]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of January 29, 2016 and April 24, 2015. We did not recognize any gains and losses in earnings due to hedge ineffectiveness for any period presented. All contracts have a maturity of less than six months.

[0001564590-16-014119:notes:133]
[same as prior period, unchanged from 0001564590-15-011213:notes:124]

[0001564590-16-014119:notes:134]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Cash Flow Hedges |  |  |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 160 |  |  | $ | 94 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 149 |  |  | $ | 160 |  |
| Forward contracts purchased |  | $ | 339 |  |  | $ | 231 |  |

[0001564590-16-014119:notes:135]
The effect of derivative instruments designated as cash flow hedges recognized in net revenues on our condensed consolidated statements of operations is presented in the condensed consolidated statements of comprehensive income (loss) and Note 10 – Stockholders’ Equity.

[0001564590-16-014119:notes:136]
[same as prior period, unchanged from 0001564590-15-011213:notes:127]

[0001564590-16-014119:notes:137]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
|  |  | Gain Recognized into Income |  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 1 |  |  | $ | 11 |  |  | $ | (6 | ) |  | $ | 9 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-16-014119:notes:138]
12. Restructuring and Other Charges

[0001564590-16-014119:notes:139]
[same as prior period, unchanged from 0001564590-15-011213:notes:130]

[0001564590-16-014119:notes:140]
[same as prior period, unchanged from 0001564590-15-011213:notes:131]

[0001564590-16-014119:notes:141]
|  |  | Nine Months Ended January 29, 2016 |  |
|  |  | Employee Severance Related Costs |  |  | Other |  |  | Total |  |
| Balance at beginning of period |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net charges |  |  | 25 |  |  |  | 3 |  |  |  | 28 |  |
| Cash payments |  |  | (25 | ) |  |  | (3 | ) |  |  | (28 | ) |
| Balance at end of period |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-16-014119:notes:142]
13. Income Taxes

[0001564590-16-014119:notes:143]
[same as prior period, unchanged from 0001564590-15-011213:notes:135]

[0001564590-16-014119:notes:144]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Effective tax rates |  |  | 16.8 | % |  |  | 22.5 | % |

[0001564590-16-014119:notes:145]
Our effective tax rates reflect the impact of a significant amount of our earnings being taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. In addition, our effective tax rates for the nine months ended January 29, 2016 and January 23, 2015 were impacted by extensions of the federal research credit and adjustments related to income tax audits as discussed below.

[0001564590-16-014119:notes:146]
In December 2015, the federal research credit, which had previously expired on December 31, 2014, was permanently extended. As a result, during the nine months ended January 29, 2016, we recorded a benefit of $7 million related to the current year research credit and a discrete benefit of $4 million related to a prior year credit that we retroactively claimed.

[0001564590-16-014119:notes:147]
In December 2014, the federal research credit was retroactively extended for amounts paid or incurred after December 31, 2013 and before January 1, 2015. As a result of the extension, during the nine months ended January 23, 2015, we recorded a benefit of $6 million related to the fiscal 2015 research credit and a discrete benefit of $4 million related to a prior year credit that we retroactively claimed.

[0001564590-16-014119:notes:148]
In June 2015, the Internal Revenue Service (IRS) signed a closing agreement on transfer pricing arrangements and, in October 2015, completed the examination of our fiscal 2008 to 2010 income tax returns. During the nine months ended January 29, 2016, we recorded discrete charges totaling $23 million attributable to transfer pricing and other audit settlements and the related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-16-014119:notes:149]
In July 2014, the IRS completed the examination of our fiscal 2005 to 2007 income tax returns upon approval by the Joint Committee of Taxation. During the nine months ended January 23, 2015, we recorded a discrete charge of $47 million attributable to the audit settlements and related re-measurements of uncertain tax positions for tax years subject to future audits.

[0001564590-16-014119:notes:150]
[same as prior period, unchanged from 0001564590-15-011213:notes:141]

[0001564590-16-014119:notes:151]
|  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Balance at beginning of period |  | $ | 272 |  |  | $ | 236 |  |
| Additions based on tax positions related to the current year |  |  | 13 |  |  |  | 19 |  |
| Additions for tax positions of prior years |  |  | 21 |  |  |  | 102 |  |
| Decreases for tax positions of prior years |  |  | (38 | ) |  |  | (24 | ) |
| Settlements |  |  | (52 | ) |  |  | (58 | ) |
| Balance at end of period |  | $ | 216 |  |  | $ | 275 |  |

[0001564590-16-014119:notes:152]
As of January 29, 2016, we had $216 million of gross unrecognized tax benefits, of which $160 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $153 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0001564590-16-014119:notes:153]
We are currently undergoing income tax audits in the United States (U.S.) and several foreign tax jurisdictions. Transfer pricing calculations are key issues under audits in various jurisdictions, and are often subject to dispute and appeals. The IRS has concluded the examination of our income tax returns for our fiscal years through 2010. We expect the IRS to commence the examination of later years within the next twelve months.

[0001564590-16-014119:notes:154]
[same as prior period, unchanged from 0001564590-15-011213:notes:145]

[0001564590-16-014119:notes:155]
[same as prior period, unchanged from 0001564590-15-011213:notes:146]

[0001564590-16-014119:notes:156]
On July 27, 2015, in Altera Corp. v. Commissioner, the U.S. Tax Court issued an opinion related to the treatment of stock-based compensation expense in an intercompany cost-sharing arrangement. A final decision was issued by the Tax Court in December 2015. In February 2016, the Commissioner appealed the Tax Court decision. At this time, the U.S. Department of the Treasury has not withdrawn the requirement to include stock-based compensation from its regulations. Due to the uncertainty surrounding the status of the current regulations, questions related to the scope of potential benefits, and the risk of the Tax Court’s decision being overturned upon appeal, we have not recorded any benefit as of January 29, 2016. We will continue to monitor ongoing developments and potential impacts to our financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001564590-16-014119:notes:157]
14. Net Income per Share

[0001564590-16-014119:notes:158]
[same as prior period, unchanged from 0001564590-15-011213:notes:149]

[0001564590-16-014119:notes:159]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 153 |  |  | $ | 177 |  |  | $ | 237 |  |  | $ | 425 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 293 |  |  |  | 312 |  |  |  | 297 |  |  |  | 318 |  |
| Dilutive impact of employee equity award plans |  |  | 3 |  |  |  | 5 |  |  |  | 3 |  |  |  | 5 |  |
| Shares used in diluted computation |  |  | 296 |  |  |  | 317 |  |  |  | 300 |  |  |  | 323 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.52 |  |  | $ | 0.57 |  |  | $ | 0.80 |  |  | $ | 1.34 |  |
| Diluted |  | $ | 0.52 |  |  | $ | 0.56 |  |  | $ | 0.79 |  |  | $ | 1.31 |  |

[0001564590-16-014119:notes:160]
We have excluded 11 million and 7 million weighted-average shares of common stock potentially issuable under employee equity award plans in the three months ended January 29, 2016 and January 23, 2015, respectively, and 13 million and 8 million shares of common stock potentially issuable under employee equity award plans in the nine months ended January 29, 2016 and January 23, 2015, respectively, from the diluted net income per share calculations as their effect would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-16-014119:notes:161]
15. Segment, Geographic, and Significant Customer Information

[0001564590-16-014119:notes:162]
[same as prior period, unchanged from 0001564590-15-011213:notes:153]

[0001564590-16-014119:notes:163]
[same as prior period, unchanged from 0001564590-15-011213:notes:154]

[0001564590-16-014119:notes:164]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| United States, Canada and Latin America (Americas) |  | $ | 752 |  |  | $ | 837 |  |  | $ | 2,316 |  |  | $ | 2,574 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 456 |  |  |  | 509 |  |  |  | 1,301 |  |  |  | 1,392 |  |
| Asia Pacific (APAC) |  |  | 178 |  |  |  | 205 |  |  |  | 549 |  |  |  | 617 |  |
| Net revenues |  | $ | 1,386 |  |  | $ | 1,551 |  |  | $ | 4,166 |  |  | $ | 4,583 |  |

[0001564590-16-014119:notes:165]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $664 million and $747 million during the three months ended January 29, 2016 and January 23, 2015, respectively, and were $2,072 million and $2,310 million during the nine months ended January 29, 2016 and January 23, 2015, respectively.

[0001564590-16-014119:notes:166]
[same as prior period, unchanged from 0001564590-15-011213:notes:157]

[0001564590-16-014119:notes:167]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| U.S. |  | $ | 598 |  |  | $ | 596 |  |
| International |  |  | 4,425 |  |  |  | 4,730 |  |
| Total |  | $ | 5,023 |  |  | $ | 5,326 |  |

[0001564590-16-014119:notes:168]
[same as prior period, unchanged from 0001564590-15-011213:notes:159]

[0001564590-16-014119:notes:169]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| U.S. |  | $ | 750 |  |  | $ | 927 |  |
| International |  |  | 123 |  |  |  | 103 |  |
| Total |  | $ | 873 |  |  | $ | 1,030 |  |

[0001564590-16-014119:notes:170]
[same as prior period, unchanged from 0001564590-15-011213:notes:161]

[0001564590-16-014119:notes:171]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Arrow Electronics, Inc. |  |  | 21 | % |  |  | 22 | % |  |  | 22 | % |  |  | 23 | % |
| Avnet, Inc. |  |  | 19 | % |  |  | 16 | % |  |  | 19 | % |  |  | 16 | % |

[0001564590-16-014119:notes:172]
[same as prior period, unchanged from 0001564590-15-011213:notes:163]

[0001564590-16-014119:notes:173]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Arrow Electronics, Inc. |  | N/A |  |  |  | 14 | % |
| Avnet, Inc. |  |  | 12 | % |  |  | 16 | % |

[0001564590-16-014119:notes:174]
N/A - Not applicable


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-16-014119:notes:175]
16. Commitments and Contingencies

[0001564590-16-014119:notes:176]
Operating Leases

[0001564590-16-014119:notes:177]
We lease various equipment, vehicles and office space in the U.S. and internationally.

[0001564590-16-014119:notes:178]
Future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $216 million as of January 29, 2016.

[0001564590-16-014119:notes:179]
Purchase Orders and Other Commitments

[0001564590-16-014119:notes:180]
In the ordinary course of business, we make commitments to third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of January 29, 2016, we had $265 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 29, 2016 and April 24, 2015, such liability amounted to $9 million and $17 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-16-014119:notes:181]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of January 29, 2016, we had $45 million in construction related obligations and $203 million in other purchase obligations.

[0001564590-16-014119:notes:182]
Financing Guarantees

[0001564590-16-014119:notes:183]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $153 million and $145 million of receivables during the nine months ended January 29, 2016 and January 23, 2015, respectively.

[0001564590-16-014119:notes:184]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0001564590-16-014119:notes:185]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of January 29, 2016 and April 24, 2015, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001564590-16-014119:notes:186]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of January 29, 2016, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-16-014119:notes:187]
Legal Contingencies

[0001564590-16-014119:notes:188]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict, and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0001564590-16-014119:notes:189]
We are subject to various legal proceedings and claims that arise in the normal course of business. No accrual has been recorded as of January 29, 2016 related to such matters as they are not probable and/or reasonably estimable.


## us-gaap:SubsequentEventsTextBlock

[0001564590-16-014119:notes:190]
17. Subsequent Events

[0001564590-16-014119:notes:191]
SolidFire Acquisition

[0001564590-16-014119:notes:192]
On February 2, 2016, we acquired all of the outstanding shares of privately-held SolidFire, Inc. (SolidFire), a maker of all-flash storage systems based in Colorado, for $855 million in cash. This acquisition extends our position in the all-flash array market by adding new flash offerings that will enhance our ability to deliver customers all-flash storage with a webscale architecture that simplifies data center operations and enables rapid deployments of new applications.

[0001564590-16-014119:notes:193]
We are still in the process of evaluating the business combination accounting considerations, including the consideration transferred and the initial purchase price allocation for this acquisition. We currently expect between $100 million and $200 million of the purchase price to be allocated to identifiable intangible assets other than goodwill. A preliminary purchase price allocation will be included in our consolidated financial statements for the year ending April 29, 2016.

[0001564590-16-014119:notes:194]
The following unaudited pro forma condensed combined financial information gives effect to the acquisition of SolidFire as if it were consummated on April 26, 2014. The unaudited pro forma condensed combined financial information is presented for informational purposes only, and is not intended to represent or be indicative of the results of operations of the Company that would have been reported had the acquisition occurred on April 26, 2014 and should not be taken as representative of future consolidated results of operations of the combined company (in millions).

[0001564590-16-014119:notes:195]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Net income |  | $ | 128 |  |  | $ | 153 |  |  | $ | 159 |  |  | $ | 341 |  |

[0001564590-16-014119:notes:196]
Adjustments have been reflected in the unaudited pro forma condensed combined information to include the amortization of identifiable intangible assets, purchase accounting adjustments to deferred revenue, interest expense related to the associated financing arrangement and  costs directly attributable to the acquisition. Pro forma net revenues were not materially different than those presented in the condensed consolidated statements of operations.

[0001564590-16-014119:notes:197]
Short-Term Loan

[0001564590-16-014119:notes:198]
In connection with the acquisition, on February 2, 2016, we entered into a short-term loan of $870 million that matures on November 2, 2016. We may repay the loan before its maturity without penalty; however, we may not reborrow any borrowings that were repaid under the term loan agreement. As specified in the term loan agreement, interest on the outstanding borrowings accrues at an adjusted LIBOR plus a spread (based on our public debt ratings) or, at our option, a base rate. We may, from time to time, elect to convert the outstanding loan from one rate to another. We expect to repay the loan on or before the maturity date using funds generated from our global operations. The loan is subject to the same covenants as our credit facility.

[0001564590-16-014119:notes:199]
Credit Facility Amendment

[0001564590-16-014119:notes:200]
On February 2, 2016, we amended our existing credit facility to increase the unsecured revolving credit facility to $300 million.

[0001564590-16-014119:notes:201]
Restructuring Event

[0001564590-16-014119:notes:202]
On February 17, 2016, we committed to a restructuring and reduction in workforce to streamline our business and reduce operating expenses. In connection with these actions, we expect to reduce our worldwide headcount by approximately 12%. The reduction in workforce will be implemented through the end of the first quarter of fiscal 2017. We expect to incur aggregate charges of approximately $60 million to $70 million for employee terminations and other costs associated with the restructuring, consisting primarily of cash expenditures. The majority of these charges will be recognized in the fourth quarter of fiscal 2016.
