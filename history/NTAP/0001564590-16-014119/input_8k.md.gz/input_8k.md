# NTAP 8-K — 0001102624-16-002144 filed 2016-02-17

## item codes, every 8-K on or before 2016-03-07

- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2016-03-07

- none on or before 2016-03-07

## item 2.02 — earnings release, exhibit 99.1

[0001102624-16-002144:8k_2_02:1]
EX-99.1
2
exh99_1.htm
EXHIBIT 99.1

[0001102624-16-002144:8k_2_02:2]
Exhibit 99.1

[0001102624-16-002144:8k_2_02:3]
|  | Press Contact: | Investor Contact: |
|  | Meghan Fintland | Kris Newton |
|  | NetApp | NetApp |
|  | 1 408 822 1389 | 1 408 822 3312 |
|  | meghan.fintland@netapp.com | kris.newton@netapp.com |

[0001102624-16-002144:8k_2_02:4]
NETAPP REPORTS THIRD QUARTER FISCAL YEAR 2016 RESULTS

[0001102624-16-002144:8k_2_02:5]
Net Revenues of $1.39 Billion; GAAP EPS of $0.52 and Non-GAAP EPS of $0.70

[0001102624-16-002144:8k_2_02:6]
| · | Announced acquisition of SolidFire™ |

[0001102624-16-002144:8k_2_02:7]
| · | NetApp™ clustered Data ONTAP™ node shipments increased 69% year over year |

[0001102624-16-002144:8k_2_02:8]
| · | Free cash flow of $314 million dollars; 23% of net revenues |

[0001102624-16-002144:8k_2_02:9]
| · | Initiated transformation program to reduce cost structure of the company |

[0001102624-16-002144:8k_2_02:10]
Sunnyvale, Calif.—February 17, 2016—NetApp (NASDAQ: NTAP) today reported financial results for the third quarter of fiscal year 2016, ended January 29, 2016.

[0001102624-16-002144:8k_2_02:11]
Third Quarter Financial Results

[0001102624-16-002144:8k_2_02:12]
Net revenues for the third quarter of fiscal year 2016 were $1.39 billion. GAAP net income for the third quarter of fiscal year 2016 was $153 million, or $0.52 income per share1 , compared to GAAP net income of $177 million, or $0.56 income per share, for the comparable period of the prior year. Non-GAAP net income for the third quarter of fiscal year 2016 was $206 million, or $0.70 income per share,2 compared to non-GAAP net income of $238 million, or $0.75 income per share, for the comparable period of the prior year.

[0001102624-16-002144:8k_2_02:13]
Cash, Cash Equivalents and Investments

[0001102624-16-002144:8k_2_02:14]
NetApp ended the third quarter of fiscal year 2016 with $5.0 billion in total cash, cash equivalents and investments and generated $355 million in cash from operations. During the third quarter of fiscal year 2016, the Company returned $137 million to shareholders through share repurchases and a cash dividend.

[0001102624-16-002144:8k_2_02:15]
The next dividend in the amount of $0.18 per common share will be paid on April 27, 2016, to shareholders of record as of the close of business on April 8, 2016.

[0001102624-16-002144:8k_2_02:16]
"NetApp's third quarter results demonstrate good progress in advancing our strategy and strong operational execution despite the challenging macroeconomic environment," said George Kurian, CEO. "To position NetApp for long-term success, we launched a transformation program designed to streamline the business and reduce our cost structure, while at the same time, maintaining our ability to invest in strategic opportunities. We are confident that we have the right strategy to further pivot the company toward the growth areas of the market and deliver long-term value."

[0001102624-16-002144:8k_2_02:17]
Q4 Fiscal Year 2016 Outlook

[0001102624-16-002144:8k_2_02:18]
The Company provided the following financial guidance for the fourth quarter of fiscal year 2016:

[0001102624-16-002144:8k_2_02:19]
| · | Net revenues are expected to be in the range of $1.35 billion to $1.50 billion. |

[0001102624-16-002144:8k_2_02:20]
| · | GAAP earnings per share is expected to be in the range of $0.12 to $0.21 per share. |

[0001102624-16-002144:8k_2_02:21]
| · | Non-GAAP earnings per share is expected to be in the range of $0.55 to $0.60 per share. |

[0001102624-16-002144:8k_2_02:22]
Business Highlights

[0001102624-16-002144:8k_2_02:23]
| · | NetApp Is the Clear Technology Leader in the All-Flash-Array Market |

[0001102624-16-002144:8k_2_02:24]
|  | - | Accelerates customer adoption of all-flash data centers with SolidFire. With the acquisition of SolidFire, NetApp now has all-flash offerings that address each of the three largest all-flash-array market segments. SolidFire combines the performance and economics of all-flash storage with a webscale architecture that radically simplifies data center operations and enables rapid deployments of new applications. SolidFire products will be incorporated into the strategy for the Data Fabric enabled by NetApp, delivering seamless management across flash, disk and cloud resources. |

[0001102624-16-002144:8k_2_02:25]
|  | - | NetApp flash storage improves student and faculty experience. With NetApp solutions, Western Oregon University (WOU) speeds educational, operational and financial decisions, while enhancing online collaboration benefits. |

[0001102624-16-002144:8k_2_02:26]
|  | - | Performance of flash at the price of disk. NetApp's new software efficiency technology and higher capacity drives within the NetApp All Flash FAS array series make it now possible for customers to reduce capacity requirements by as much as 30:1. |

[0001102624-16-002144:8k_2_02:27]
| · | The Data Fabric Vision Is Extended with New Solutions, Services and Partnerships NetApp provides customers with the enterprise data protection that they need to confidently embrace the hybrid cloud. With NetApp SnapCenter™, StorageGRID™ Webscale, NetApp Private Storage, NetApp MetroCluster ™ and NetApp SnapMirror™ disaster recovery solutions; as well as Commvault IntelliSnap, NetApp customers can now build a new generation of hybrid cloud services designed to move, manage, and protect data. |

[0001102624-16-002144:8k_2_02:28]
Webcast and Conference Call Information

[0001102624-16-002144:8k_2_02:29]
NetApp will host a conference call to discuss these results today at 2 p.m. Pacific Time. To access the live webcast of this event, visit the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables and other information related to the call will be posted on the Investor Relations website. An audio replay will also be available on the website after 4 p.m. Pacific Time today.

[0001102624-16-002144:8k_2_02:30]
About NetApp

[0001102624-16-002144:8k_2_02:31]
Leading organizations worldwide count on NetApp for software, systems and services to manage and store their data. Customers value our teamwork, expertise and passion for helping them succeed now and into the future. To learn more, visit http://www.netapp.com.

[0001102624-16-002144:8k_2_02:32]
###

[0001102624-16-002144:8k_2_02:33]
NetApp and the NetApp logo are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0001102624-16-002144:8k_2_02:34]
1Net income per share is calculated using the diluted number of shares.

[0001102624-16-002144:8k_2_02:35]
2Non-GAAP net income excludes, when applicable, the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-reoccurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company's tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) the impact of a temporary lapse of tax law, such as the federal research credit, if such extensions have routinely been granted based on past legislative history and are expected to be reinstated in the near future. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods presented. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com.

[0001102624-16-002144:8k_2_02:36]
NetApp Usage of Non-GAAP Financials

[0001102624-16-002144:8k_2_02:37]
The Company refers to the non-GAAP financial measures in making operating decisions because they provide meaningful supplemental information regarding the Company's ongoing operational performance. Non-GAAP net income excludes, when applicable, the amortization of intangible assets, stock-based compensation, acquisition-related income and expenses, restructuring and other charges, asset impairments, non-cash interest expense associated with our debt, net losses or gains on investments, and our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-reoccurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company's tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) the impact of a temporary lapse of tax law, such as the federal research credit, if such extensions have routinely been granted based on past legislative history and are expected to be reinstated in the near future. Non-GAAP earnings per share is calculated using the diluted number of shares for all periods.

[0001102624-16-002144:8k_2_02:38]
We have excluded these items in order to enhance investors' understanding of our ongoing operations. The use of these non-GAAP financial measures has limitations and they should not solely be used to evaluate our Company without reference to their corresponding GAAP financial measures. As such, we provide non-GAAP financial measures in conjunction with GAAP financial measures.

[0001102624-16-002144:8k_2_02:39]
These non-GAAP financial measures are used to: (1) measure Company performance against historical results, (2) facilitate comparisons to our competitors' operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure Company performance for the purposes of determining employee incentive plan compensation.

[0001102624-16-002144:8k_2_02:40]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 5,023 |  |  | $ | 5,326 |  |
| Accounts receivable |  |  | 585 |  |  |  | 779 |  |
| Inventories |  |  | 102 |  |  |  | 146 |  |
| Other current assets |  |  | 354 |  |  |  | 522 |  |
| Total current assets |  |  | 6,064 |  |  |  | 6,773 |  |
| Property and equipment, net |  |  | 873 |  |  |  | 1,030 |  |
| Goodwill and purchased intangible assets, net |  |  | 1,064 |  |  |  | 1,117 |  |
| Other non-current assets |  |  | 784 |  |  |  | 481 |  |
| Total assets |  | $ | 8,785 |  |  | $ | 9,401 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 175 |  |  | $ | 284 |  |
| Accrued expenses |  |  | 617 |  |  |  | 701 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 1,684 |  |  |  | 1,724 |  |
| Total current liabilities |  |  | 2,476 |  |  |  | 2,709 |  |
| Long-term debt |  |  | 1,490 |  |  |  | 1,487 |  |
| Other long-term liabilities |  |  | 268 |  |  |  | 318 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 1,442 |  |  |  | 1,473 |  |
| Total liabilities |  |  | 5,676 |  |  |  | 5,987 |  |
| Stockholders' equity |  |  | 3,109 |  |  |  | 3,414 |  |
| Total liabilities and stockholders' equity |  | $ | 8,785 |  |  | $ | 9,401 |  |

[0001102624-16-002144:8k_2_02:41]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  |
| (In millions, except per share amounts) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 750 |  |  | $ | 929 |  |  | $ | 2,229 |  |  | $ | 2,741 |  |
| Software maintenance |  |  | 234 |  |  |  | 226 |  |  |  | 715 |  |  |  | 672 |  |
| Hardware maintenance and other services |  |  | 402 |  |  |  | 396 |  |  |  | 1,222 |  |  |  | 1,170 |  |
| Net revenues |  |  | 1,386 |  |  |  | 1,551 |  |  |  | 4,166 |  |  |  | 4,583 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 381 |  |  |  | 420 |  |  |  | 1,134 |  |  |  | 1,216 |  |
| Cost of software maintenance |  |  | 9 |  |  |  | 9 |  |  |  | 28 |  |  |  | 26 |  |
| Cost of hardware maintenance and other services |  |  | 141 |  |  |  | 145 |  |  |  | 449 |  |  |  | 443 |  |
| Total cost of revenues |  |  | 531 |  |  |  | 574 |  |  |  | 1,611 |  |  |  | 1,685 |  |
| Gross profit |  |  | 855 |  |  |  | 977 |  |  |  | 2,555 |  |  |  | 2,898 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 418 |  |  |  | 475 |  |  |  | 1,358 |  |  |  | 1,443 |  |
| Research and development |  |  | 200 |  |  |  | 230 |  |  |  | 660 |  |  |  | 687 |  |
| General and administrative |  |  | 70 |  |  |  | 70 |  |  |  | 223 |  |  |  | 213 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | 28 |  |  |  | - |  |
| Acquisition-related expense |  |  | 2 |  |  |  | - |  |  |  | 2 |  |  |  | - |  |
| Total operating expenses |  |  | 690 |  |  |  | 775 |  |  |  | 2,271 |  |  |  | 2,343 |  |
| Income from operations |  |  | 165 |  |  |  | 202 |  |  |  | 284 |  |  |  | 555 |  |
| Other income (expense), net |  |  | (2 | ) |  |  | (2 | ) |  |  | 1 |  |  |  | (6 | ) |
| Income before income taxes |  |  | 163 |  |  |  | 200 |  |  |  | 285 |  |  |  | 549 |  |
| Provision for income taxes |  |  | 10 |  |  |  | 23 |  |  |  | 48 |  |  |  | 124 |  |
| Net income |  | $ | 153 |  |  | $ | 177 |  |  | $ | 237 |  |  | $ | 425 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.52 |  |  | $ | 0.57 |  |  | $ | 0.80 |  |  | $ | 1.34 |  |
| Diluted |  | $ | 0.52 |  |  | $ | 0.56 |  |  | $ | 0.79 |  |  | $ | 1.31 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 293 |  |  |  | 312 |  |  |  | 297 |  |  |  | 318 |  |
| Diluted |  |  | 296 |  |  |  | 317 |  |  |  | 300 |  |  |  | 323 |  |
| Cash dividends declared per share |  | $ | 0.180 |  |  | $ | 0.165 |  |  | $ | 0.540 |  |  | $ | 0.495 |  |

[0001102624-16-002144:8k_2_02:42]
| NETAPP, INC. |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  |
| (In millions) |  |
| (Unaudited) |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 153 |  |  | $ | 177 |  |  | $ | 237 |  |  | $ | 425 |  |
| Adjustments to reconcile net income to net cash provided |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 66 |  |  |  | 80 |  |  |  | 202 |  |  |  | 235 |  |
| Stock-based compensation |  |  | 63 |  |  |  | 66 |  |  |  | 199 |  |  |  | 196 |  |
| Excess tax benefit from stock-based compensation |  |  | (1 | ) |  |  | (5 | ) |  |  | (5 | ) |  |  | (54 | ) |
| Other, net |  |  | (21 | ) |  |  | (20 | ) |  |  | (69 | ) |  |  | 30 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1 |  |  |  | (35 | ) |  |  | 190 |  |  |  | 187 |  |
| Inventories |  |  | 23 |  |  |  | (10 | ) |  |  | 44 |  |  |  | 5 |  |
| Accounts payable |  |  | (53 | ) |  |  | (14 | ) |  |  | (113 | ) |  |  | (46 | ) |
| Accrued expenses |  |  | 10 |  |  |  | (26 | ) |  |  | (78 | ) |  |  | (162 | ) |
| Deferred revenue and financed unearned services revenue |  |  | 85 |  |  |  | 79 |  |  |  | (52 | ) |  |  | 34 |  |
| Changes in other operating assets and liabilities, net |  |  | 29 |  |  |  | (17 | ) |  |  | 74 |  |  |  | 22 |  |
| Net cash provided by operating activities |  |  | 355 |  |  |  | 275 |  |  |  | 629 |  |  |  | 872 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions (purchases) of investments, net |  |  | 91 |  |  |  | (320 | ) |  |  | 879 |  |  |  | 41 |  |
| Purchases of property and equipment |  |  | (41 | ) |  |  | (29 | ) |  |  | (125 | ) |  |  | (138 | ) |
| Acquisitions of businesses |  |  | - |  |  |  | (85 | ) |  |  | - |  |  |  | (85 | ) |
| Other investing activities, net |  |  | (1 | ) |  |  | 4 |  |  |  | (1 | ) |  |  | 3 |  |
| Net cash provided by (used in) investing activities |  |  | 49 |  |  |  | (430 | ) |  |  | 753 |  |  |  | (179 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Issuance of common stock |  |  | 45 |  |  |  | 75 |  |  |  | 70 |  |  |  | 146 |  |
| Repurchase of common stock |  |  | (85 | ) |  |  | (200 | ) |  |  | (698 | ) |  |  | (919 | ) |
| Excess tax benefit from stock-based compensation |  |  | 1 |  |  |  | 5 |  |  |  | 5 |  |  |  | 54 |  |
| Issuance of long-term debt, net |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 495 |  |
| Dividends paid |  |  | (52 | ) |  |  | (52 | ) |  |  | (159 | ) |  |  | (157 | ) |
| Other financing activities, net |  |  | (5 | ) |  |  | (4 | ) |  |  | (8 | ) |  |  | (8 | ) |
| Net cash used in financing activities |  |  | (96 | ) |  |  | (176 | ) |  |  | (790 | ) |  |  | (389 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (11 | ) |  |  | (34 | ) |  |  | (19 | ) |  |  | (55 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 297 |  |  |  | (365 | ) |  |  | 573 |  |  |  | 249 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 2,198 |  |  |  | 2,905 |  |  |  | 1,922 |  |  |  | 2,291 |  |
| End of period |  | $ | 2,495 |  |  | $ | 2,540 |  |  | $ | 2,495 |  |  | $ | 2,540 |  |

[0001102624-16-002144:8k_2_02:43]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO and Inventory Turns) |  |
| (Unaudited) |  |
|  |  | Q3 FY'16 |  |  | Q2 FY'16 |  |  | Q3 FY'15 |  |
| Revenues |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 750 |  |  | $ | 815 |  |  | $ | 929 |  |
| Software Maintenance |  | $ | 234 |  |  | $ | 233 |  |  | $ | 226 |  |
| Hardware Maintenance & Other Services: |  | $ | 402 |  |  | $ | 397 |  |  | $ | 396 |  |
| Hardware Maintenance Support Contracts |  | $ | 326 |  |  | $ | 326 |  |  | $ | 316 |  |
| Professional and Other Services |  | $ | 76 |  |  | $ | 71 |  |  | $ | 80 |  |
| Net Revenues |  | $ | 1,386 |  |  | $ | 1,445 |  |  | $ | 1,551 |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q3 FY'16 Revenue |  |  | % of Q2 FY'16 Revenue |  |  | % of Q3 FY'15 Revenue |  |
| Americas |  |  | 54 | % |  |  | 57 | % |  |  | 54 | % |
| Americas Commercial |  |  | 44 | % |  |  | 42 | % |  |  | 44 | % |
| U.S. Public Sector |  |  | 10 | % |  |  | 14 | % |  |  | 10 | % |
| EMEA |  |  | 33 | % |  |  | 30 | % |  |  | 33 | % |
| Asia Pacific |  |  | 13 | % |  |  | 14 | % |  |  | 13 | % |
| Pathways Mix |  |
|  |  | % of Q3 FY'16 Revenue |  |  | % of Q2 FY'16 Revenue |  |  | % of Q3 FY'15 Revenue |  |
| Direct |  |  | 22 | % |  |  | 23 | % |  |  | 21 | % |
| Indirect |  |  | 78 | % |  |  | 77 | % |  |  | 79 | % |
| Direct revenues are those sold through our direct sales force and, effective Q1 FY'16, include those sold to service providers. Indirect revenues include those sold through value-added resellers, system integrators, OEMs and distributors. Indirect revenue reflects order fulfillment and is not reflective of who is responsible for the customer relationship. |  |
| Non-GAAP Gross Margins |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'16 |  |  | Q2 FY'16 |  |  | Q3 FY'15 |  |
| Non-GAAP Gross Margin |  |  | 63.1 | % |  |  | 62.5 | % |  |  | 64.6 | % |
| Product |  |  | 51.1 | % |  |  | 51.8 | % |  |  | 57.0 | % |
| Software Maintenance |  |  | 96.2 | % |  |  | 96.1 | % |  |  | 95.9 | % |
| Hardware Maintenance & Other Services |  |  | 66.2 | % |  |  | 64.7 | % |  |  | 64.5 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'16 |  |  | Q2 FY'16 |  |  | Q3 FY'15 |  |
| Non-GAAP Income from Operations |  | $ | 244 |  |  | $ | 219 |  |  | $ | 288 |  |
| % of Net Revenues |  |  | 17.6 | % |  |  | 15.2 | % |  |  | 18.5 | % |
| Non-GAAP Income before Income Taxes |  | $ | 242 |  |  | $ | 218 |  |  | $ | 285 |  |
| Non-GAAP Effective Tax Rate |  |  | 14.9 | % |  |  | 17.0 | % |  |  | 16.5 | % |

[0001102624-16-002144:8k_2_02:44]
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'16 |  |  | Q2 FY'16 |  |  | Q3 FY'15 |  |
| Non-GAAP Net Income |  | $ | 206 |  |  | $ | 181 |  |  | $ | 238 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 296 |  |  |  | 296 |  |  |  | 317 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 0.70 |  |  | $ | 0.61 |  |  | $ | 0.75 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'16 |  |  | Q2 FY'16 |  |  | Q3 FY'15 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 3,126 |  |  | $ | 3,046 |  |  | $ | 3,110 |  |
| DSO (days) |  |  | 38 |  |  |  | 37 |  |  |  | 39 |  |
| Inventory Turns |  |  | 20 |  |  |  | 17 |  |  |  | 19 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized non-GAAP cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q3 FY'16 |  |  | Q2 FY'16 |  |  | Q3 FY'15 |  |
| Net Cash Provided by Operating Activities |  | $ | 355 |  |  | $ | 145 |  |  | $ | 275 |  |
| Purchases of Property and Equipment |  | $ | 41 |  |  | $ | 46 |  |  | $ | 29 |  |
| Free Cash Flow |  | $ | 314 |  |  | $ | 99 |  |  | $ | 246 |  |
| Free Cash Flow as % of Net Revenues |  |  | 22.7 | % |  |  | 6.9 | % |  |  | 15.9 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0001102624-16-002144:8k_2_02:45]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY16 |  |  | Q2'FY16 |  |  | Q3'FY15 |  |
| NET INCOME |  | $ | 153 |  |  | $ | 114 |  |  | $ | 177 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 19 |  |
| Stock-based compensation |  |  | 63 |  |  |  | 59 |  |  |  | 66 |  |
| Restructuring and other charges |  |  | - |  |  |  | 1 |  |  |  | - |  |
| Acquisition-related expense |  |  | 2 |  |  |  | - |  |  |  | - |  |
| Income tax effect of non-GAAP adjustments |  |  | (26 | ) |  |  | (17 | ) |  |  | (24 | ) |
| Settlement of income tax audit |  |  | - |  |  |  | 10 |  |  |  | - |  |
| NON-GAAP NET INCOME |  | $ | 206 |  |  | $ | 181 |  |  | $ | 238 |  |
| COST OF REVENUES |  | $ | 531 |  |  | $ | 561 |  |  | $ | 574 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (13 | ) |  |  | (14 | ) |  |  | (18 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (5 | ) |  |  | (6 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 512 |  |  | $ | 542 |  |  | $ | 550 |  |
| COST OF PRODUCT REVENUES |  | $ | 381 |  |  | $ | 408 |  |  | $ | 420 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (13 | ) |  |  | (14 | ) |  |  | (18 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (2 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 367 |  |  | $ | 393 |  |  | $ | 400 |  |
| COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 141 |  |  | $ | 144 |  |  | $ | 145 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (5 | ) |  |  | (4 | ) |  |  | (4 | ) |
| NON-GAAP COST OF HARDWARE MAINTENANCE AND OTHER SERVICES REVENUES |  | $ | 136 |  |  | $ | 140 |  |  | $ | 140 |  |
| GROSS PROFIT |  | $ | 855 |  |  | $ | 884 |  |  | $ | 977 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 13 |  |  |  | 14 |  |  |  | 18 |  |
| Stock-based compensation |  |  | 6 |  |  |  | 5 |  |  |  | 6 |  |
| NON-GAAP GROSS PROFIT |  | $ | 874 |  |  | $ | 903 |  |  | $ | 1,002 |  |
| SALES AND MARKETING EXPENSES |  | $ | 418 |  |  | $ | 448 |  |  | $ | 475 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (1 | ) |  |  | - |  |  |  | (1 | ) |
| Stock-based compensation |  |  | (27 | ) |  |  | (26 | ) |  |  | (30 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 390 |  |  | $ | 422 |  |  | $ | 445 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 200 |  |  | $ | 216 |  |  | $ | 230 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (20 | ) |  |  | (18 | ) |  |  | (21 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 180 |  |  | $ | 198 |  |  | $ | 208 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 70 |  |  | $ | 74 |  |  | $ | 70 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (10 | ) |  |  | (10 | ) |  |  | (9 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 60 |  |  | $ | 64 |  |  | $ | 61 |  |

[0001102624-16-002144:8k_2_02:46]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q3'FY16 |  |  | Q2'FY16 |  |  | Q3'FY15 |  |
| RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | 1 |  |  | $ | - |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other charges |  |  | - |  |  |  | (1 | ) |  |  | - |  |
| NON-GAAP RESTRUCTURING AND OTHER CHARGES |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 2 |  |  | $ | - |  |  | $ | - |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (2 | ) |  |  | - |  |  |  | - |  |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| OPERATING EXPENSES |  | $ | 690 |  |  | $ | 739 |  |  | $ | 775 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (1 | ) |  |  | - |  |  |  | (1 | ) |
| Stock-based compensation |  |  | (57 | ) |  |  | (54 | ) |  |  | (60 | ) |
| Restructuring and other charges |  |  | - |  |  |  | (1 | ) |  |  | - |  |
| Acquisition-related expense |  |  | (2 | ) |  |  | - |  |  |  | - |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 630 |  |  | $ | 684 |  |  | $ | 714 |  |
| INCOME FROM OPERATIONS |  | $ | 165 |  |  | $ | 145 |  |  | $ | 202 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 19 |  |
| Stock-based compensation |  |  | 63 |  |  |  | 59 |  |  |  | 66 |  |
| Restructuring and other charges |  |  | - |  |  |  | 1 |  |  |  | - |  |
| Acquisition-related expense |  |  | 2 |  |  |  | - |  |  |  | - |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 244 |  |  | $ | 219 |  |  | $ | 288 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 163 |  |  | $ | 144 |  |  | $ | 200 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 19 |  |
| Stock-based compensation |  |  | 63 |  |  |  | 59 |  |  |  | 66 |  |
| Restructuring and other charges |  |  | - |  |  |  | 1 |  |  |  | - |  |
| Acquisition-related expense |  |  | 2 |  |  |  | - |  |  |  | - |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 242 |  |  | $ | 218 |  |  | $ | 285 |  |
| PROVISION FOR INCOME TAXES |  | $ | 10 |  |  | $ | 30 |  |  | $ | 23 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effect of non-GAAP adjustments |  |  | 26 |  |  |  | 17 |  |  |  | 24 |  |
| Settlement of income tax audit |  |  | - |  |  |  | (10 | ) |  |  | - |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 36 |  |  | $ | 37 |  |  | $ | 47 |  |
| NET INCOME PER SHARE |  | $ | 0.52 |  |  | $ | 0.39 |  |  | $ | 0.56 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.05 |  |  |  | 0.05 |  |  |  | 0.06 |  |
| Stock-based compensation |  |  | 0.21 |  |  |  | 0.20 |  |  |  | 0.21 |  |
| Restructuring and other charges |  |  | - |  |  |  | - |  |  |  | - |  |
| Acquisition-related expense |  |  | 0.01 |  |  |  | - |  |  |  | - |  |
| Income tax effect of non-GAAP adjustments |  |  | (0.09 | ) |  |  | (0.06 | ) |  |  | (0.07 | ) |
| Settlement of income tax audit |  |  | - |  |  |  | 0.03 |  |  |  | - |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 0.70 |  |  | $ | 0.61 |  |  | $ | 0.75 |  |

[0001102624-16-002144:8k_2_02:47]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY16 |  |  | Q2'FY16 |  |  | Q3'FY15 |  |
| Gross margin-GAAP |  |  | 61.7 | % |  |  | 61.2 | % |  |  | 63.0 | % |
| Cost of revenues adjustments |  |  | 1.4 | % |  |  | 1.3 | % |  |  | 1.6 | % |
| Gross margin-Non-GAAP |  |  | 63.1 | % |  |  | 62.5 | % |  |  | 64.6 | % |
| GAAP cost of revenues |  | $ | 531 |  |  | $ | 561 |  |  | $ | 574 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (13 | ) |  |  | (14 | ) |  |  | (18 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (5 | ) |  |  | (6 | ) |
| Non-GAAP cost of revenues |  | $ | 512 |  |  | $ | 542 |  |  | $ | 550 |  |
| Net revenues |  | $ | 1,386 |  |  | $ | 1,445 |  |  | $ | 1,551 |  |

[0001102624-16-002144:8k_2_02:48]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY16 |  |  | Q2'FY16 |  |  | Q3'FY15 |  |
| Product gross margin-GAAP |  |  | 49.2 | % |  |  | 49.9 | % |  |  | 54.9 | % |
| Cost of product revenues adjustments |  |  | 1.9 | % |  |  | 1.8 | % |  |  | 2.1 | % |
| Product gross margin-Non-GAAP |  |  | 51.1 | % |  |  | 51.8 | % |  |  | 57.0 | % |
| GAAP cost of product revenues |  | $ | 381 |  |  | $ | 408 |  |  | $ | 420 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (13 | ) |  |  | (14 | ) |  |  | (18 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (2 | ) |
| Non-GAAP cost of product revenues |  | $ | 367 |  |  | $ | 393 |  |  | $ | 400 |  |
| Product revenues |  | $ | 750 |  |  | $ | 815 |  |  | $ | 929 |  |

[0001102624-16-002144:8k_2_02:49]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| HARDWARE MAINTENANCE AND OTHER SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q3'FY16 |  |  | Q2'FY16 |  |  | Q3'FY15 |  |
| Hardware maintenance and other services gross margin-GAAP |  |  | 64.9 | % |  |  | 63.7 | % |  |  | 63.3 | % |
| Cost of hardware maintenance and other services revenues adjustment |  |  | 1.2 | % |  |  | 1.0 | % |  |  | 1.2 | % |
| Hardware maintenance and other services gross margin-Non-GAAP |  |  | 66.2 | % |  |  | 64.7 | % |  |  | 64.5 | % |
| GAAP cost of hardware maintenance and other services revenues |  | $ | 141 |  |  | $ | 144 |  |  | $ | 145 |  |
| Cost of hardware maintenance and other services revenues adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (5 | ) |  |  | (4 | ) |  |  | (4 | ) |
| Non-GAAP cost of hardware maintenance and other services revenues |  | $ | 136 |  |  | $ | 140 |  |  | $ | 140 |  |
| Hardware maintenance and other services revenues |  | $ | 402 |  |  | $ | 397 |  |  | $ | 396 |  |

[0001102624-16-002144:8k_2_02:50]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q3'FY16 |  |  | Q2'FY16 |  |  | Q3'FY15 |  |
| GAAP effective tax rate |  |  | 6.1 | % |  |  | 20.8 | % |  |  | 11.6 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Tax effect of non-GAAP adjustments |  |  | 8.8 | % |  |  | 0.8 | % |  |  | 4.9 | % |
| Settlement of income tax audit |  |  | - | % |  |  | (4.6 | %) |  |  | - | % |
| Non-GAAP effective tax rate |  |  | 14.9 | % |  |  | 17.0 | % |  |  | 16.5 | % |

[0001102624-16-002144:8k_2_02:51]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q3'FY16 |  |  | Q2'FY16 |  |  | Q3'FY15 |  |
| Net cash provided by operating activities |  | $ | 355 |  |  | $ | 145 |  |  | $ | 275 |  |
| Purchases of property and equipment |  |  | (41 | ) |  |  | (46 | ) |  |  | (29 | ) |
| Free cash flow |  | $ | 314 |  |  | $ | 99 |  |  | $ | 246 |  |

[0001102624-16-002144:8k_2_02:52]
| INVENTORY TURNS AND RECONCILIATION OF NON-GAAP TO GAAP |  |
| COST OF REVENUES USED IN INVENTORY TURNS |  |
| (In millions, except annualized inventory turns) |  |
|  |  | Q3'FY16 |  |  | Q2'FY16 |  |  | Q3'FY15 |  |
| Annualized inventory turns-GAAP |  |  | 21 |  |  |  | 18 |  |  |  | 19 |  |
| Cost of revenues adjustments |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Annualized inventory turns-Non-GAAP |  |  | 20 |  |  |  | 17 |  |  |  | 19 |  |
| GAAP cost of revenues |  | $ | 531 |  |  | $ | 561 |  |  | $ | 574 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (13 | ) |  |  | (14 | ) |  |  | (18 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (5 | ) |  |  | (6 | ) |
| Non-GAAP cost of revenues |  | $ | 512 |  |  | $ | 542 |  |  | $ | 550 |  |
| Inventory |  | $ | 102 |  |  | $ | 125 |  |  | $ | 118 |  |
| Some items may not add or recalculate due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |

[0001102624-16-002144:8k_2_02:53]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FOURTH QUARTER FISCAL 2016 |
|  | Fourth Quarter |
|  | Fiscal 2016 |
| Non-GAAP Guidance - Net Income Per Share | $0.55 - $0.60 |
| Adjustments of Specific Items to Net Income |  |
| Per Share for the Fourth Quarter Fiscal 2016: |  |
| Amortization of intangible assets | (0.08) |
| Stock-based compensation expense | (0.21) |
| Restructuring and other charges | (0.24) - (0.20) |
| Acquisition-related expense | (0.01) |
| Income tax effect of non-GAAP adjustments | 0.11 |
| Total Adjustments | (0.43) - (0.39) |
| GAAP Guidance - Net Income Per Share | $0.12 - $0.21 |
