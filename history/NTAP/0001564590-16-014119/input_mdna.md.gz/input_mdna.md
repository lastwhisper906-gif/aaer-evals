# NTAP MD&A — 0001564590-16-014119


## mdna

[0001564590-16-014119:mdna:1]
[same as prior period, unchanged from 0001564590-15-011213:mdna:1]

[0001564590-16-014119:mdna:2]
[same as prior period, unchanged from 0001564590-15-011213:mdna:15]

[0001564590-16-014119:mdna:3]
[same as prior period, unchanged from 0001564590-15-011213:mdna:3]

[0001564590-16-014119:mdna:4]
[same as prior period, unchanged from 0001564590-15-011213:mdna:4]

[0001564590-16-014119:mdna:5]
[same as prior period, unchanged from 0001564590-15-011213:mdna:5]

[0001564590-16-014119:mdna:6]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Net revenues |  | $ | 1,386 |  |  | $ | 1,551 |  |  | $ | 4,166 |  |  | $ | 4,583 |  |
| Gross profit |  | $ | 855 |  |  | $ | 977 |  |  | $ | 2,555 |  |  | $ | 2,898 |  |
| Gross profit margin percentage |  |  | 62 | % |  |  | 63 | % |  |  | 61 | % |  |  | 63 | % |
| Income from operations |  | $ | 165 |  |  | $ | 202 |  |  | $ | 284 |  |  | $ | 555 |  |
| Income from operations as a percentage of net revenues |  |  | 12 | % |  |  | 13 | % |  |  | 7 | % |  |  | 12 | % |
| Net income |  | $ | 153 |  |  | $ | 177 |  |  | $ | 237 |  |  | $ | 425 |  |
| Diluted net income per share |  | $ | 0.52 |  |  | $ | 0.56 |  |  | $ | 0.79 |  |  | $ | 1.31 |  |
| Operating cash flows |  | $ | 355 |  |  | $ | 275 |  |  | $ | 629 |  |  | $ | 872 |  |

[0001564590-16-014119:mdna:7]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 3,125 |  |  | $ | 3,197 |  |
| Days sales outstanding (DSO) |  |  | 38 |  |  |  | 46 |  |

[0001564590-16-014119:mdna:8]
Subsequent Events

[0001564590-16-014119:mdna:9]
Acquisition of SolidFire

[0001564590-16-014119:mdna:10]
On February 2, 2016, we acquired all of the outstanding shares of privately-held SolidFire, Inc. (SolidFire), a maker of all-flash storage systems based in Colorado, for $855 million in cash. This acquisition extends our position in the all-flash array market by adding new flash offerings that will enhance our ability to deliver customers all-flash storage with a webscale architecture that simplifies data center operations and enables rapid deployments of new applications.

[0001564590-16-014119:mdna:11]
The acquisition is expected to have an immaterial impact on net revenues, but is expected to have an unfavorable impact of approximately $50 million on income from operations in the fourth quarter of fiscal year 2016.

[0001564590-16-014119:mdna:12]
In connection with this acquisition, we entered into an $870 million short-term loan that we expect to repay with our global earnings by the beginning of our third quarter of fiscal 2017.

[0001564590-16-014119:mdna:13]
Restructuring Event

[0001564590-16-014119:mdna:14]
On February 17, 2016, we committed to a restructuring and reduction in workforce to streamline our business and reduce operating expenses. In connection with these actions, we expect to reduce our worldwide headcount by approximately 12%. The reduction in workforce will be implemented through the end of the first quarter of fiscal 2017. We expect to incur aggregate charges of approximately $60 to $70 million for employee terminations and other costs associated with the restructuring, consisting primarily of cash expenditures. The majority of these charges will be recognized in the fourth quarter of fiscal 2016.

[0001564590-16-014119:mdna:15]
[same as prior period, unchanged from 0001564590-15-011213:mdna:8]

[0001564590-16-014119:mdna:16]
[same as prior period, unchanged from 0001564590-15-011213:mdna:9]

[0001564590-16-014119:mdna:17]
[same as prior period, unchanged from 0001564590-15-011213:mdna:10]

[0001564590-16-014119:mdna:18]
[same as prior period, unchanged from 0001564590-15-011213:mdna:11]

[0001564590-16-014119:mdna:19]
[same as prior period, unchanged from 0001564590-15-011213:mdna:12]

[0001564590-16-014119:mdna:20]
[same as prior period, unchanged from 0001564590-15-011213:mdna:13]

[0001564590-16-014119:mdna:21]
[same as prior period, unchanged from 0001564590-15-011213:mdna:14]

[0001564590-16-014119:mdna:22]
[same as prior period, unchanged from 0001564590-15-011213:mdna:16]

[0001564590-16-014119:mdna:23]
|  |  | Three Months Ended |  |  | Nine Months Ended |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 54 |  | % |  | 60 |  | % |  | 54 |  | % |  | 60 |  | % |
| Software maintenance |  |  | 17 |  |  |  | 15 |  |  |  | 17 |  |  |  | 15 |  |  |
| Hardware maintenance and other services |  |  | 29 |  |  |  | 26 |  |  |  | 29 |  |  |  | 26 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 27 |  |  |  | 27 |  |  |  | 27 |  |  |  | 27 |  |  |
| Cost of software maintenance |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |
| Cost of hardware maintenance and other services |  |  | 10 |  |  |  | 9 |  |  |  | 11 |  |  |  | 10 |  |  |
| Gross profit |  |  | 62 |  |  |  | 63 |  |  |  | 61 |  |  |  | 63 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 30 |  |  |  | 31 |  |  |  | 33 |  |  |  | 32 |  |  |
| Research and development |  |  | 14 |  |  |  | 15 |  |  |  | 16 |  |  |  | 15 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring and other charges |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | — |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Total operating expenses |  |  | 50 |  |  |  | 50 |  |  |  | 55 |  |  |  | 51 |  |  |
| Income from operations |  |  | 12 |  |  |  | 13 |  |  |  | 7 |  |  |  | 12 |  |  |
| Other income (expense), net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Income before income taxes |  |  | 12 |  |  |  | 13 |  |  |  | 7 |  |  |  | 12 |  |  |
| Provision for income taxes |  |  | 1 |  |  |  | 2 |  |  |  | 1 |  |  |  | 3 |  |  |
| Net income |  |  | 11 |  | % |  | 11 |  | % |  | 6 |  | % |  | 9 |  | % |

[0001564590-16-014119:mdna:24]
[same as prior period, unchanged from 0001564590-15-011213:mdna:18]

[0001564590-16-014119:mdna:25]
[same as prior period, unchanged from 0001564590-15-011213:mdna:19]

[0001564590-16-014119:mdna:26]
[same as prior period, unchanged from 0001564590-15-011213:mdna:20]

[0001564590-16-014119:mdna:27]
Net revenues for the third quarter and first nine months of fiscal 2016 were $1,386 million, reflecting a decrease of $165 million, or 11%, and $4,166 million, reflecting a decrease of $417 million, or 9%, respectively, compared to the corresponding periods of the prior year. Revenues for the third quarter and first nine months of fiscal 2016 were negatively impacted by foreign exchange rate changes, higher discounting, the lengthening of deal cycles due to macroeconomic uncertainty and unfavorable product mix.

[0001564590-16-014119:mdna:28]
Gross profit as a percentage of net revenues decreased 1 and 2 percentage points during the third quarter and first nine months of fiscal 2016, respectively, compared to the corresponding periods of the prior year, primarily due to foreign exchange rate changes and higher discounting.

[0001564590-16-014119:mdna:29]
[same as prior period, unchanged from 0001564590-15-011213:mdna:39]

[0001564590-16-014119:mdna:30]
Sales and marketing, research and development, and general and administrative expenses for the third quarter and first nine months of fiscal 2016 totaled $688 million, or 50% as a percentage of net revenues, and $2,241 million, or 54% as a percentage of net revenues, respectively, compared to $775 million, or 50% as a percentage of net revenues, and $2,343 million, or 51% as a percentage of net revenues, respectively, for the corresponding periods of the prior year. The decrease in expenses in dollars was primarily due to lower headcount and related compensation costs and the favorable impact of changes in foreign exchange rates, partially offset in the first nine months of fiscal 2016 by the additional week in the first quarter of fiscal 2016.

[0001564590-16-014119:mdna:31]
[same as prior period, unchanged from 0001564590-15-011213:mdna:24]

[0001564590-16-014119:mdna:32]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |
| Net revenues | $ | 1,386 |  |  | $ | 1,551 |  |  |  | (11 | )% |  | $ | 4,166 |  |  | $ | 4,583 |  |  |  | (9 | )% |

[0001564590-16-014119:mdna:33]
The decrease in net revenues for the third quarter of fiscal 2016 was due to a decrease of $179 million, or 19%, in product revenues, while revenues from software and hardware maintenance and other services revenues in aggregate increased $14 million. Product revenues comprised 54% of net revenues for the third quarter of fiscal 2016, compared to 60% for the corresponding period of the prior year.

[0001564590-16-014119:mdna:34]
The decrease in net revenues for the first nine months of fiscal 2016 was due to a decrease of $512 million, or 19%, in product revenues, partially offset by an increase of $95 million, or 5%, in the aggregate of software and hardware maintenance and other services revenues. Product revenues comprised 54% of net revenues for the first nine months of fiscal 2016, compared to 60% for the corresponding period of the prior year.

[0001564590-16-014119:mdna:35]
[same as prior period, unchanged from 0001564590-15-011213:mdna:30]

[0001564590-16-014119:mdna:36]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Arrow Electronics, Inc. |  |  | 21 | % |  |  | 22 | % |  |  | 22 | % |  |  | 23 | % |
| Avnet, Inc. |  |  | 19 | % |  |  | 16 | % |  |  | 19 | % |  |  | 16 | % |

[0001564590-16-014119:mdna:37]
[same as prior period, unchanged from 0001564590-15-011213:mdna:32]

[0001564590-16-014119:mdna:38]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |
| Product revenues | $ | 750 |  |  | $ | 929 |  |  |  | (19 | )% |  | $ | 2,229 |  |  | $ | 2,741 |  |  |  | (19 | )% |

[0001564590-16-014119:mdna:39]
[same as prior period, unchanged from 0001564590-15-011213:mdna:34]

[0001564590-16-014119:mdna:40]
Total configured system revenues of $463 million decreased by $90 million, or 16%, for the third quarter of fiscal 2016, compared to the corresponding period of the prior year. Revenues decreased in the entry level and mid-range FAS and E-Series systems platforms, but increased in the high-end FAS platforms. Total configured systems unit volume decreased 11% due to unit volume decreases in entry level and mid-range FAS platforms, partially offset by increases in the high end FAS and E-Series platforms, These changes in unit volume reflect the impact to our business of a storage technology industry in transition as customers drive IT transformation to take advantage of new technologies and architectures, while planning their journey to the hybrid cloud. In addition, the decline in product revenues reflects the transition from products based on our older Data ONTAP 7-mode technology to products based on clustered Data ONTAP technology. Average selling prices (ASPs) decreased across all FAS and E-Series platforms due primarily to higher discounting due to competitive pressures and unfavorable product mix.

[0001564590-16-014119:mdna:41]
Non-configured product revenues of $287 million decreased by $89 million, or 24%, during the third quarter of fiscal 2016, compared to the corresponding period of the prior year. This decrease was primarily due to a decrease of $51 million, or 34%, in add-on storage revenues, reflecting higher discounting, and a decrease of $32 million, or 27%, in OEM revenue, reflecting changing business dynamics of our OEM customers.

[0001564590-16-014119:mdna:42]
Total configured system revenues of $1,380 million decreased by $257 million, or 16%, for the first nine months of fiscal 2016, compared to the corresponding period of the prior year. Revenues decreased across all FAS systems platforms, but increased in E-Series systems platforms. Total configured systems unit volume decreased 7%, due to a decrease in unit volume in entry level and mid-range FAS system platforms, partially offset by an increase in high end FAS and E-Series systems platforms. These changes in

[0001564590-16-014119:mdna:43]
[same as prior period, unchanged from 0001564590-15-011213:mdna:55]

[0001564590-16-014119:mdna:44]
unit volume reflect the impact of the factors discussed above. Overall ASPs decreased over all configured systems platforms due to higher discounting and unfavorable product mix.

[0001564590-16-014119:mdna:45]
Non-configured product revenues of $849 million decreased by $255 million, or 23%, during the first nine months of fiscal 2016, compared to the corresponding period of the prior year. This decrease was primarily due to a decrease of $152 million, or 33%, in add-on storage revenues and a decrease of $111 million, or 31%, in OEM revenue, both decreases reflecting the respective factors discussed above.

[0001564590-16-014119:mdna:46]
[same as prior period, unchanged from 0001564590-15-011213:mdna:40]

[0001564590-16-014119:mdna:47]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |
| Software maintenance revenues | $ | 234 |  |  | $ | 226 |  |  |  | 4 | % |  | $ | 715 |  |  | $ | 672 |  |  |  | 6 | % |

[0001564590-16-014119:mdna:48]
[same as prior period, unchanged from 0001564590-15-011213:mdna:42]

[0001564590-16-014119:mdna:49]
The fluctuations in software maintenance revenues reflect fluctuations in the aggregate contract value of the installed base under software maintenance contracts, which is recognized as revenue ratably over the terms of the underlying contracts. Software maintenance contract revenues for the first nine months of fiscal 2016 were also favorably impacted by the additional week of deferred revenue amortization in the first quarter of fiscal 2016.

[0001564590-16-014119:mdna:50]
[same as prior period, unchanged from 0001564590-15-011213:mdna:44]

[0001564590-16-014119:mdna:51]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |
| Hardware maintenance and other services revenues | $ | 402 |  |  | $ | 396 |  |  |  | 2 | % |  | $ | 1,222 |  |  | $ | 1,170 |  |  |  | 4 | % |

[0001564590-16-014119:mdna:52]
[same as prior period, unchanged from 0001564590-15-011213:mdna:46]

[0001564590-16-014119:mdna:53]
Hardware maintenance contract revenues were $326 million and $316 million for the third quarters of fiscal 2016 and 2015, respectively, reflecting an increase of 3% due primarily to higher levels of shorter term contract renewals from our existing contract base. Professional services and educational and training services revenues were $76 million and $80 million in aggregate for the third quarters of fiscal 2016 and 2015, respectively.

[0001564590-16-014119:mdna:54]
Hardware maintenance contract revenues were $998 million and $930 million for first nine months of fiscal 2016 and 2015, respectively, due primarily to the contract renewals discussed above, as well as the favorable impact of an additional week of deferred revenue amortization in the first quarter of fiscal 2016. Professional services and educational and training services revenues aggregated to $224 million and $241 million for the first nine months of fiscal 2016 and 2015, respectively.

[0001564590-16-014119:mdna:55]
[same as prior period, unchanged from 0001564590-15-011213:mdna:49]

[0001564590-16-014119:mdna:56]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | January 29, 2016 |  |  | January 23, 2015 |  |
| United States, Canada and Latin America (Americas) |  |  | 54 | % |  |  | 54 | % |  |  | 56 | % |  |  | 56 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 33 | % |  |  | 33 | % |  |  | 31 | % |  |  | 30 | % |
| Asia Pacific (APAC) |  |  | 13 | % |  |  | 13 | % |  |  | 13 | % |  |  | 13 | % |

[0001564590-16-014119:mdna:57]
[same as prior period, unchanged from 0001564590-15-011213:mdna:51]

[0001564590-16-014119:mdna:58]
Americas revenues consist of sales to Americas commercial and United States public sector (USPS) markets. Our Americas revenues decreased in the third quarter and first nine months of fiscal 2016 compared to the corresponding periods in the prior year, primarily due to lower sales to the USPS market.

[0001564590-16-014119:mdna:59]
[same as prior period, unchanged from 0001564590-15-011213:mdna:53]

[0001564590-16-014119:mdna:60]
Our cost of revenues consists of three elements: (1) cost of product revenues, which includes the costs of manufacturing and shipping our storage products, amortization of purchased intangible assets, inventory write-downs, and warranty costs, (2) cost of software maintenance, which includes the costs of providing software maintenance and third-party royalty costs and (3) cost of

[0001564590-16-014119:mdna:61]
[same as prior period, unchanged from 0001564590-15-011213:mdna:69]

[0001564590-16-014119:mdna:62]
hardware maintenance and other services revenues, which includes costs associated with providing support activities for hardware maintenance, global support partnership programs, professional services and educational and training services.

[0001564590-16-014119:mdna:63]
[same as prior period, unchanged from 0001564590-15-011213:mdna:56]

[0001564590-16-014119:mdna:64]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |
| Cost of product revenues | $ | 381 |  |  | $ | 420 |  |  |  | (9 | )% |  | $ | 1,134 |  |  | $ | 1,216 |  |  |  | (7 | )% |

[0001564590-16-014119:mdna:65]
[same as prior period, unchanged from 0001564590-15-011213:mdna:58]

[0001564590-16-014119:mdna:66]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2016 to Fiscal 2015 |  |  | Fiscal 2016 to Fiscal 2015 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Materials costs |  |  | (6 | ) |  |  | (7 | ) |
| Excess and obsolete inventory |  |  | — |  |  |  | 1 |  |
| Other |  |  | (3 | ) |  |  | (1 | ) |
| Total change |  |  | (9 | ) |  |  | (7 | ) |

[0001564590-16-014119:mdna:67]
Cost of product revenues represented 51% of product revenues for each of the third quarter and first nine months of fiscal 2016, compared to 45% and 44% of product revenues for the corresponding periods of the prior year.

[0001564590-16-014119:mdna:68]
Materials costs represented 88% and 86% of product costs for the third quarters of fiscal 2016 and 2015, respectively. Materials costs decreased $26 million, or 7%, in the third quarter of fiscal 2016 compared to the corresponding period of the prior year, primarily due to an 11% decrease in configured systems unit volume, partially offset by an increase of 14% in average unit materials costs for configured systems. This was a result of increases in average materials costs across all systems platforms reflecting higher average costs of newer products. Product materials costs were favorably impacted by a decrease in materials costs for non-configured products due to lower sales levels and favorable product mix.

[0001564590-16-014119:mdna:69]
Materials costs represented 84% and 86% of product costs for the first nine months of fiscal 2016 and 2015, respectively. Materials costs decreased $83 million, or 8%, in the first nine months of fiscal 2016 compared to the corresponding period of the prior year. Materials costs were impacted by a 7% decrease in configured systems unit volume, partially offset by an increase of 7% in average unit materials costs for configured systems. This was a result of increases in average materials costs for entry level and high end FAS systems, partially offset by decreases in mid-level FAS and E-series systems average materials costs, reflecting the higher average costs of newer products. Product materials costs were also favorably impacted by a decrease in materials costs for add-on storage and OEM due to lower sales levels and favorable product mix.

[0001564590-16-014119:mdna:70]
[same as prior period, unchanged from 0001564590-15-011213:mdna:63]

[0001564590-16-014119:mdna:71]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |
| Cost of software maintenance revenues | $ | 9 |  |  | $ | 9 |  |  |  | — | % |  | $ | 28 |  |  | $ | 26 |  |  |  | 8 | % |

[0001564590-16-014119:mdna:72]
Cost of software maintenance revenues were flat during the third quarter compared to the corresponding period of the prior year, and increased 8% during the first nine months of fiscal 2016 compared to the corresponding periods of the prior year. Cost of software maintenance revenues represented 4% of software maintenance revenues for each of the third quarters and first nine months of fiscal 2016 and 2015.

[0001564590-16-014119:mdna:73]
[same as prior period, unchanged from 0001564590-15-011213:mdna:66]

[0001564590-16-014119:mdna:74]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |
| Cost of hardware maintenance and other services revenues | $ | 141 |  |  | $ | 145 |  |  |  | (3 | )% |  | $ | 449 |  |  | $ | 443 |  |  |  | 1 | % |

[0001564590-16-014119:mdna:75]
Cost of hardware maintenance and other services revenues decreased slightly during the third quarter of fiscal 2016 compared to the corresponding period of the prior year, primarily due to cost savings initiatives and lower spares costs. Costs of hardware maintenance and other services revenues were relatively flat during the first nine months of fiscal 2016 compared to the corresponding period of the prior year.

[0001564590-16-014119:mdna:76]
[same as prior period, unchanged from 0001564590-15-011213:mdna:84]

[0001564590-16-014119:mdna:77]
[same as prior period, unchanged from 0001564590-15-011213:mdna:70]

[0001564590-16-014119:mdna:78]
[same as prior period, unchanged from 0001564590-15-011213:mdna:71]

[0001564590-16-014119:mdna:79]
[same as prior period, unchanged from 0001564590-15-011213:mdna:72]

[0001564590-16-014119:mdna:80]
Total compensation costs included in operating expenses decreased $40 million, or 9%, for the third quarter of fiscal 2016 compared to the corresponding period of the prior year primarily due to lower salaries and incentive compensation costs, reflecting a 6% decrease in average headcount, and the favorable impact of foreign exchange rate fluctuations.

[0001564590-16-014119:mdna:81]
Total compensation costs included in operating expenses decreased $13 million, or 1%, for the first nine months of fiscal 2016 compared to the corresponding period of the prior year, reflecting lower salaries and incentive compensation costs due to lower average headcount, partially offset by the impact of the additional week in the first quarter of fiscal 2016.

[0001564590-16-014119:mdna:82]
[same as prior period, unchanged from 0001564590-15-011213:mdna:75]

[0001564590-16-014119:mdna:83]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |
| Sales and marketing expenses | $ | 418 |  |  | $ | 475 |  |  |  | (12 | )% |  | $ | 1,358 |  |  | $ | 1,443 |  |  |  | (6 | )% |

[0001564590-16-014119:mdna:84]
[same as prior period, unchanged from 0001564590-15-011213:mdna:77]

[0001564590-16-014119:mdna:85]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2016 to Fiscal 2015 |  |  | Fiscal 2016 to Fiscal 2015 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (4 | ) |  |  | (1 | ) |
| Commissions |  |  | — |  |  |  | (1 | ) |
| Outside services |  |  | (2 | ) |  |  | (1 | ) |
| Facilities and IT support costs |  |  | (3 | ) |  |  | (2 | ) |
| Other |  |  | (3 | ) |  |  | (1 | ) |
| Total change |  |  | (12 | ) |  |  | (6 | ) |

[0001564590-16-014119:mdna:86]
The decrease in sales and marketing expenses for each period presented reflects the favorable impact of fluctuations in foreign exchange rates. Additionally, the decrease in compensation costs reflects lower headcounts from the prior year. The decrease in commissions expense for the first nine months of fiscal 2016 reflects lower bookings achievement compared to the corresponding period of the prior year. The decrease in outside services expense reflects lower spending levels on contractors and projects. Facilities and IT support costs decreased primarily due to cost containment efforts.

[0001564590-16-014119:mdna:87]
[same as prior period, unchanged from 0001564590-15-011213:mdna:80]

[0001564590-16-014119:mdna:88]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |
| Research and development expenses | $ | 200 |  |  | $ | 230 |  |  |  | (13 | )% |  | $ | 660 |  |  | $ | 687 |  |  |  | (4 | )% |

[0001564590-16-014119:mdna:89]
[same as prior period, unchanged from 0001564590-15-011213:mdna:82]

[0001564590-16-014119:mdna:90]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2016 to Fiscal 2015 |  |  | Fiscal 2016 to Fiscal 2015 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (8 | ) |  |  | (1 | ) |
| Depreciation |  |  | (1 | ) |  |  | (1 | ) |
| Facilities and IT support costs |  |  | (2 | ) |  |  | (1 | ) |
| Other |  |  | (2 | ) |  |  | (1 | ) |
| Total change |  |  | (13 | ) |  |  | (4 | ) |

[0001564590-16-014119:mdna:91]
[same as prior period, unchanged from 0001564590-15-011213:mdna:99]

[0001564590-16-014119:mdna:92]
The decrease in compensation costs for the third quarter and first nine months of fiscal 2016 compared to the corresponding periods of the prior year was primarily due to lower salaries and incentive compensation costs, reflecting lower average headcount. Depreciation expense decreased primarily due to certain equipment becoming fully depreciated in prior periods. Facilities and IT support costs decreased for the third quarter and first nine months of fiscal 2016 compared to the corresponding periods of the prior year primarily due to cost containment efforts.

[0001564590-16-014119:mdna:93]
[same as prior period, unchanged from 0001564590-15-011213:mdna:86]

[0001564590-16-014119:mdna:94]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |
| General and administrative expenses | $ | 70 |  |  | $ | 70 |  |  |  | — | % |  | $ | 223 |  |  | $ | 213 |  |  |  | 5 | % |

[0001564590-16-014119:mdna:95]
[same as prior period, unchanged from 0001564590-15-011213:mdna:88]

[0001564590-16-014119:mdna:96]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Fiscal 2016 to Fiscal 2015 |  |  | Fiscal 2016 to Fiscal 2015 |  |
|  |  | Percentage Change Points |  |  | Percentage Change Points |  |
| Compensation costs |  |  | (5 | ) |  |  | 4 |  |
| Professional and legal fees and outside services |  |  | 9 |  |  |  | 3 |  |
| Facilities and IT support costs |  |  | (4 | ) |  |  | (2 | ) |
| Total change |  |  | — |  |  |  | 5 |  |

[0001564590-16-014119:mdna:97]
The decrease in compensation costs for the third quarter of fiscal 2016 compared to the third quarter of the prior year was primarily due to lower incentive compensation costs and lower salaries. The increase in compensation costs for the first nine months of fiscal 2016 compared to the corresponding period of the prior year was primarily due to higher stock-based compensation, salaries and benefit costs due to the additional week in the first quarter of fiscal 2016. The increase in professional and legal fees and outside services expense for the third quarter of fiscal 2016 compared to the corresponding period of the prior year was primarily due to higher spending levels on consulting fees and projects. Facilities and IT support costs decreased primarily due to cost containment efforts.

[0001564590-16-014119:mdna:98]
[same as prior period, unchanged from 0001564590-15-011213:mdna:91]

[0001564590-16-014119:mdna:99]
|  | Three Months Ended |  |  | Nine Months Ended |
|  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |
| Restructuring and other charges | $ | — |  |  | $ | — |  |  |  | — | % |  | $ | 28 |  |  |  | — |  |  | NM |

[0001564590-16-014119:mdna:100]
[same as prior period, unchanged from 0001564590-15-011213:mdna:93]

[0001564590-16-014119:mdna:101]
In May 2015, we committed to a realignment designed to drive efficiency, eliminate cost and redirect resources to highest return activities, resulting in a reduction of our global workforce of approximately 3%. The charges in the first nine months of fiscal 2016 consist primarily of employee severance related costs recognized in connection with this plan. Such activities were substantially completed by the end of the second quarter of fiscal 2016. See Note 12 – Restructuring and Other Charges of the Notes to Condensed Consolidated Financial Statements for more details regarding our restructuring plan.

[0001564590-16-014119:mdna:102]
Acquisition-related expense (in millions, except percentages):

[0001564590-16-014119:mdna:103]
|  | Three Months Ended |  | Nine Months Ended |
|  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |
| Acquisition-related expense | $ | 2 |  |  | $ | — |  |  | NM |  | $ | 2 |  |  | $ | — |  |  | NM |

[0001564590-16-014119:mdna:104]
[same as prior period, unchanged from 0001564590-15-011213:mdna:98]

[0001564590-16-014119:mdna:105]
[same as prior period, unchanged from 0001564590-15-011213:mdna:114]

[0001564590-16-014119:mdna:106]
During the third quarter of fiscal 2016, we incurred $2 million of acquisition costs, primarily related to legal and consulting fees associated with our acquisition of SolidFire. See Note 17 – Subsequent Event of the Notes to Condensed Consolidated Financial Statements for more information.

[0001564590-16-014119:mdna:107]
[same as prior period, unchanged from 0001564590-15-011213:mdna:95]

[0001564590-16-014119:mdna:108]
[same as prior period, unchanged from 0001564590-15-011213:mdna:96]

[0001564590-16-014119:mdna:109]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |
| Interest income | $ | 11 |  |  | $ | 9 |  |  |  | 22 | % |  | $ | 35 |  |  | $ | 25 |  |  |  | 40 | % |
| Interest expense |  | (11 | ) |  |  | (11 | ) |  |  | — | % |  |  | (34 | ) |  |  | (31 | ) |  |  | 10 | % |
| Net gains (losses) recognized on investments |  | (1 | ) |  |  | 2 |  |  | NM |  |  |  | (2 | ) |  |  | 4 |  |  | NM |  |
| Net gains (losses) on foreign currency activities |  | (1 | ) |  |  | (2 | ) |  |  | (50 | )% |  |  | 2 |  |  |  | (4 | ) |  | NM |  |
| Total | $ | (2 | ) |  | $ | (2 | ) |  |  | — | % |  | $ | 1 |  |  | $ | (6 | ) |  | NM |  |

[0001564590-16-014119:mdna:110]
NM – Not Meaningful

[0001564590-16-014119:mdna:111]
The increase in interest income for the third quarter and first nine months of fiscal 2016, compared to the corresponding periods of the prior year, was primarily due to a shift in our investment portfolio to higher-yielding investments.

[0001564590-16-014119:mdna:112]
[same as prior period, unchanged from 0001564590-15-011213:mdna:101]

[0001564590-16-014119:mdna:113]
[same as prior period, unchanged from 0001564590-15-011213:mdna:102]

[0001564590-16-014119:mdna:114]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |  | January 29, 2016 |  |  | January 23, 2015 |  |  | % Change |  |
| Provision for income taxes | $ | 10 |  |  | $ | 23 |  |  |  | (57 | )% |  | $ | 48 |  |  | $ | 124 |  |  |  | (61 | )% |

[0001564590-16-014119:mdna:115]
Our effective tax rate for the third quarter of fiscal 2016 was 6.1% compared to an effective tax rate of 11.7% for the third quarter of the prior year. Our effective tax rate for the first nine months of fiscal 2016 was 16.8% compared to an effective tax rate of 22.5% for the first nine months of the prior year. Our effective tax rates reflect our corporate legal entity structure and the global nature of our business with a significant amount of our profits generated and taxed in foreign jurisdictions at rates below the U.S. statutory tax rate. The effective tax rates for all periods presented were favorably impacted by the geographic mix of profits. Our effective tax rates decreased for the three and nine months ended January 29, 2016 compared to the corresponding periods in the prior year primarily as a result of discrete charges related to audit adjustments and changes in the geographic mix of year-to-date pre-tax profits.

[0001564590-16-014119:mdna:116]
In December 2015, the enactment of the Protecting Americans from Tax Hikes Act of 2015 permanently extended the federal research credit which had previously expired on December 31, 2014. As a result of the extension, during the three and nine months ended January 29, 2016, we recorded a benefit of $7 million related to the current year research credit and a discrete benefit of $4 million related to a prior year credit that we retroactively claimed.

[0001564590-16-014119:mdna:117]
In June 2015, the IRS signed a closing agreement on transfer pricing arrangements and, in October 2015, completed the examination of our fiscal 2008 to 2010 income tax returns. During the nine months ended January 29, 2016, we recorded discrete charges totaling $23 million attributable to transfer pricing and other audit settlements, and the related re-measurement of uncertain tax positions for tax years subject to future audits.

[0001564590-16-014119:mdna:118]
In July 2014, the IRS completed the examination of our fiscal 2005 to 2007 income tax returns upon approval by the Joint Committee of Taxation. During the first nine months of fiscal 2015, we recorded a discrete charge of $47 million attributable to the audit settlements and related re-measurements of uncertain tax positions for tax years subject to future audits.

[0001564590-16-014119:mdna:119]
As of January 29, 2016, we had $216 million of gross unrecognized tax benefits, of which $160 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $153 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized. See Note 13 – Income Taxes of the Notes to Condensed Consolidated Financial Statements for more details regarding our unrecognized tax benefits.

[0001564590-16-014119:mdna:120]
[same as prior period, unchanged from 0001564590-15-011213:mdna:109]

[0001564590-16-014119:mdna:121]
[same as prior period, unchanged from 0001564590-15-011213:mdna:131]

[0001564590-16-014119:mdna:122]
[same as prior period, unchanged from 0001564590-15-011213:mdna:110]

[0001564590-16-014119:mdna:123]
| (In millions, except percentages) |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Cash and cash equivalents and short-term investments |  | $ | 5,023 |  |  | $ | 5,326 |  |
| Principal amount of Senior Notes |  | $ | 1,500 |  |  | $ | 1,500 |  |
| Debt as a % of stockholders' equity |  |  | 48 | % |  |  | 44 | % |

[0001564590-16-014119:mdna:124]
[same as prior period, unchanged from 0001564590-15-011213:mdna:112]

[0001564590-16-014119:mdna:125]
|  |  | Nine Months Ended |  |
| (In millions) |  | January 29, 2016 |  |  | January 23, 2015 |  |
| Net cash provided by operating activities |  | $ | 629 |  |  | $ | 872 |  |
| Net cash provided by (used in) investing activities |  |  | 753 |  |  |  | (179 | ) |
| Net cash used in financing activities |  |  | (790 | ) |  |  | (389 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (19 | ) |  |  | (55 | ) |
| Net increase in cash and cash equivalents |  | $ | 573 |  |  | $ | 249 |  |

[0001564590-16-014119:mdna:126]
[same as prior period, unchanged from 0001564590-15-011213:mdna:115]

[0001564590-16-014119:mdna:127]
As of January 29, 2016, our cash, cash equivalents and short-term investments were $5.0 billion, a decrease of $0.3 billion from April 24, 2015. The decrease was primarily due to $698 million in cash paid for the repurchase of our common stock and $159 million in cash paid for the payment of dividends, partially offset by $629 million of cash provided by operating activities in the first nine months of fiscal 2016. Accounts receivable DSO was 38 days for the third quarter of fiscal 2016 compared to 46 days for the fourth quarter of fiscal 2015 and 39 for the third quarter of fiscal 2015 reflecting seasonal patterns of shipment linearity. Working capital decreased during the first nine months of fiscal 2016 by $476 million to $3.6 billion as of January 29, 2016 primarily as a result of a decrease in cash and cash equivalents and short-term investments and accounts receivable.

[0001564590-16-014119:mdna:128]
[same as prior period, unchanged from 0001564590-15-011213:mdna:117]

[0001564590-16-014119:mdna:129]
During the first nine months of fiscal 2016, we generated cash from operating activities of $629 million, reflecting net income of $237 million, adjusted by non-cash depreciation and amortization of $202 million and stock-based compensation of $199 million.

[0001564590-16-014119:mdna:130]
Changes in assets and liabilities during the first nine months of fiscal 2016 included the following:

[0001564590-16-014119:mdna:131]
|  | · | Accounts receivable decreased $190 million, primarily due to seasonal patterns in shipment linearity. |

[0001564590-16-014119:mdna:132]
|  | · | Accounts payable increased $113 million, primarily due to lower inventory purchases towards the end of the period. |

[0001564590-16-014119:mdna:133]
[same as prior period, unchanged from 0001564590-15-011213:mdna:123]

[0001564590-16-014119:mdna:134]
[same as prior period, unchanged from 0001564590-15-011213:mdna:124]

[0001564590-16-014119:mdna:135]
During the first nine months of fiscal 2016, we generated $879 million from maturities and sales of investments, net of purchases, and paid $125 million for capital expenditures, compared to $41 million and $138 million, respectively, for the corresponding period of the prior year.

[0001564590-16-014119:mdna:136]
[same as prior period, unchanged from 0001564590-15-011213:mdna:126]

[0001564590-16-014119:mdna:137]
During the first nine months of fiscal 2016, we used $698 million for the repurchase of 23 million shares of our common stock and $159 million for the payment of dividends, compared to $919 million used for the repurchase of common stock and $157 million for the payment of dividends for the corresponding period of the prior year.

[0001564590-16-014119:mdna:138]
[same as prior period, unchanged from 0001564590-15-011213:mdna:144]

[0001564590-16-014119:mdna:139]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies, including SolidFire, and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including potential future issuances of debt, equity or other securities, will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all.

[0001564590-16-014119:mdna:140]
[same as prior period, unchanged from 0001564590-15-011213:mdna:129]

[0001564590-16-014119:mdna:141]
Our principal sources of liquidity as of January 29, 2016 consisted of cash, cash equivalents and short-term investments, as well as cash we expect to generate from operations.

[0001564590-16-014119:mdna:142]
[same as prior period, unchanged from 0001564590-15-011213:mdna:132]

[0001564590-16-014119:mdna:143]
|  |  | January 29, 2016 |  |  | April 24, 2015 |  |
| Cash and cash equivalents |  | $ | 2,495 |  |  | $ | 1,922 |  |
| Short-term investments |  |  | 2,528 |  |  |  | 3,404 |  |
| Total |  | $ | 5,023 |  |  | $ | 5,326 |  |

[0001564590-16-014119:mdna:144]
As of January 29, 2016 and April 24, 2015, $4.4 billion and $4.7 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.6 billion were available in the U.S. at the end of each period. Most of the amounts held outside the U.S. can be repatriated to the U.S. but, under current law, would be subject to U.S. federal, state income and foreign withholding taxes. If we were to repatriate foreign earnings to fund cash requirements in the U.S., we would incur U.S. federal and state income taxes reduced by the current amount of our U.S. federal and state tax credit carryforwards. However, our intent is to keep these funds permanently reinvested outside of the U.S., and our current plans do not contemplate a need to repatriate them to fund our U.S. operations. Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, and invest in critical or complementary technologies, and service interest and principal payments on our debt.

[0001564590-16-014119:mdna:145]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of January 29, 2016.

[0001564590-16-014119:mdna:146]
[same as prior period, unchanged from 0001564590-15-011213:mdna:136]

[0001564590-16-014119:mdna:147]
[same as prior period, unchanged from 0001564590-15-011213:mdna:137]

[0001564590-16-014119:mdna:148]
The following table summarizes the principal amount of our Senior Notes as of January 29, 2016 (in millions):

[0001564590-16-014119:mdna:149]
| 2.00% Senior Notes Due 2017 |  | $ | 750 |  |
| 3.375% Senior Notes Due 2021 |  |  | 500 |  |
| 3.25% Senior Notes Due 2022 |  |  | 250 |  |
| Total |  | $ | 1,500 |  |

[0001564590-16-014119:mdna:150]
33

[0001564590-16-014119:mdna:151]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 9 – Financing Arrangements of the Notes to Condensed Consolidated Financial Statements.

[0001564590-16-014119:mdna:152]
Credit Facility

[0001564590-16-014119:mdna:153]
Our credit facility, under which we may borrow up to $250 million, provides another potential source of liquidity. The credit facility is an unsecured five-year revolving credit facility that terminates on December 21, 2017 if no extensions have been requested at that time, and contains financial covenants requiring us to maintain a maximum leverage ratio and a minimum interest coverage ratio. We may also, subject to certain requirements, request an increase in the facility up to an additional $100 million and request two additional one-year extensions, subject to certain conditions. As of January 29, 2016, no borrowings were outstanding under the facility and we were in compliance with all covenants associated with the facility.

[0001564590-16-014119:mdna:154]
We also have an automatic shelf registration statement on file with the Securities and Exchange Commission. We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0001564590-16-014119:mdna:155]
On February 2, 2016, we amended our existing credit facility to increase the unsecured revolving credit facility to $300 million.

[0001564590-16-014119:mdna:156]
Acquisition of SolidFire

[0001564590-16-014119:mdna:157]
On February 2, 2016, we acquired all of the outstanding shares of privately-held SolidFire, Inc. (“SolidFire”), a maker of all-flash storage systems based in Colorado, for $855 million in cash. In connection with this acquisition, we entered into an $870 million short-term loan that we expect to repay with our global earnings by the beginning of our third quarter of fiscal 2017.

[0001564590-16-014119:mdna:158]
Restructuring Activities

[0001564590-16-014119:mdna:159]
On February 17, 2016, we committed to a restructuring and reduction in workforce to streamline our business and reduce operating expenses. In connection with these actions, we expect to reduce our worldwide headcount by approximately 12%. The reduction in workforce will be implemented through the end of the first quarter of fiscal 2017. We expect to incur aggregate charges of approximately $60 to $70 million for employee terminations and other costs associated with the restructuring, consisting primarily of cash expenditures. The majority of these charges will be recognized in the fourth quarter of fiscal 2016.

[0001564590-16-014119:mdna:160]
[same as prior period, unchanged from 0001564590-15-011213:mdna:145]

[0001564590-16-014119:mdna:161]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2016 to be between $25 million and $75 million.

[0001564590-16-014119:mdna:162]
[same as prior period, unchanged from 0001564590-15-011213:mdna:147]

[0001564590-16-014119:mdna:163]
On February 17, 2016, we declared a cash dividend of $0.18 per share of common stock, payable on April 27, 2016 to holders of record as of the close of business on April 8, 2016.

[0001564590-16-014119:mdna:164]
As of January 29, 2016, our Board of Directors had authorized the repurchase of up to $9.6 billion of our common stock under our stock repurchase program. Under this program, we can purchase shares of our outstanding common stock through open market and privately negotiated transactions at prices deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through January 29, 2016, we repurchased a total of 237 million shares of our common stock at an average price of $33.22 per share, for an aggregate purchase price of $7.9 billion. As of January 29, 2016, the remaining authorized amount for stock repurchases under this program was $1.8 billion, with no termination date, which we plan to complete by May 2018, with the first $1 billion expected to be purchased by the end of May 2016.

[0001564590-16-014119:mdna:165]
[same as prior period, unchanged from 0001564590-15-011213:mdna:150]

[0001564590-16-014119:mdna:166]
[same as prior period, unchanged from 0001564590-15-011213:mdna:151]

[0001564590-16-014119:mdna:167]
[same as prior period, unchanged from 0001564590-15-011213:mdna:152]

[0001564590-16-014119:mdna:168]
As of January 29, 2016, future annual minimum lease payments under non-cancelable operating leases with an initial term in excess of one year totaled $216 million.

[0001564590-16-014119:mdna:169]
[same as prior period, unchanged from 0001564590-15-011213:mdna:154]

[0001564590-16-014119:mdna:170]
In the ordinary course of business, we make commitments to our third-party contract manufacturers to manage manufacturer lead times and meet product forecasts, and to other parties to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of January 29, 2016, we had $265 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 29, 2016 and April 24, 2015, such liability amounted to $9 million and $17 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0001564590-16-014119:mdna:171]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and construction related obligations associated with our ordinary course of business for which we have not received goods or services. As of January 29, 2016, we had $45 million in construction related obligations and $203 million in other purchase obligations.

[0001564590-16-014119:mdna:172]
[same as prior period, unchanged from 0001564590-15-011213:mdna:157]

[0001564590-16-014119:mdna:173]
As of January 29, 2016, our liability for uncertain tax positions was $148 million, including interest, penalties and offsetting indirect benefits. Due to the uncertainty of the timing of future cash payments, we cannot make reasonably reliable estimates of the period of cash settlement with the taxing authorities.

[0001564590-16-014119:mdna:174]
Legal Contingencies

[0001564590-16-014119:mdna:175]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 16 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements.

[0001564590-16-014119:mdna:176]
[same as prior period, unchanged from 0001564590-15-011213:mdna:161]

[0001564590-16-014119:mdna:177]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $153 million and $145 million of receivables during the first nine months of fiscal 2016 and fiscal 2015, respectively.

[0001564590-16-014119:mdna:178]
[same as prior period, unchanged from 0001564590-15-011213:mdna:164]

[0001564590-16-014119:mdna:179]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases, we defer revenues subject to the industry-specific software revenue recognition guidance and recognize revenues for non-software deliverables in accordance with our multiple deliverable revenue arrangement policy. In connection with certain recourse financing arrangements, we receive advance payments associated with undelivered elements that are subject to customer refund rights. As of January 29, 2016 and April 24, 2015, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced material losses under our lease financing programs or other financing arrangements.

[0001564590-16-014119:mdna:180]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of January 29, 2016, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0001564590-16-014119:mdna:181]
[same as prior period, unchanged from 0001564590-15-011213:mdna:167]

[0001564590-16-014119:mdna:182]
[same as prior period, unchanged from 0001564590-15-011213:mdna:168]

[0001564590-16-014119:mdna:183]
35
