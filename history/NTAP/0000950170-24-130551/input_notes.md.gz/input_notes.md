# NTAP notes — 0000950170-24-130551


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000950170-24-130551:notes:1]
[same as prior period, unchanged from 0000950170-24-101408:notes:1]

[0000950170-24-130551:notes:2]
[same as prior period, unchanged from 0000950170-24-101408:notes:2]

[0000950170-24-130551:notes:3]
[same as prior period, unchanged from 0000950170-24-101408:notes:3]

[0000950170-24-130551:notes:4]
[same as prior period, unchanged from 0000950170-24-101408:notes:4]

[0000950170-24-130551:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared by the Company, and reflect all adjustments, consisting only of normal recurring adjustments, that are, in the opinion of management, necessary for the fair presentation of our financial position, results of operations, comprehensive income, cash flows and stockholders’ equity for the interim periods presented. The statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information. Accordingly, these statements do not include all information and footnotes required by GAAP for annual consolidated financial statements, and should be read in conjunction with our audited consolidated financial statements as of and for the fiscal year ended April 26, 2024 contained in our Annual Report on Form 10-K. The results of operations for the three and six months ended October 25, 2024 are not necessarily indicative of the operating results to be expected for the full fiscal year or future operating periods.

[0000950170-24-130551:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, the anticipated effects of which have been incorporated, as applicable, into management's estimates as of October 25, 2024.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000950170-24-130551:notes:7]
2. Recent Accounting Pronouncements

[0000950170-24-130551:notes:8]
In November 2024, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update ("ASU") 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires additional disclosure of the nature of expenses included in the income statement. The standard requires disclosures about specific types of expenses included in the expense captions presented in the income statement as well as disclosures about selling expenses. This ASU is effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027, with early adoption permitted. The requirements should be applied on a prospective basis while retrospective application is permitted. We are currently evaluating the effect of this pronouncement on our disclosures.

[0000950170-24-130551:notes:9]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which expands the disclosures required for income taxes. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The amendment should be applied on a prospective basis while retrospective application is permitted. We are currently evaluating the effect of this pronouncement on our income tax disclosures.

[0000950170-24-130551:notes:10]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which requires disclosure of incremental segment information on an annual and interim basis. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024 on a retrospective basis. We will adopt the new requirements for our annual periods starting in fiscal 2025 (and interim periods thereafter). We are currently evaluating the effect of this pronouncement, which we expect to result in enhanced financial statement disclosures only.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-24-130551:notes:11]
[same as prior period, unchanged from 0000950170-24-101408:notes:10]

[0000950170-24-130551:notes:12]
Goodwill by reportable segment as of October 25, 2024 is as follows (in millions):

[0000950170-24-130551:notes:13]
[same as prior period, unchanged from 0000950170-24-101408:notes:12]

[0000950170-24-130551:notes:14]
[same as prior period, unchanged from 0000950170-24-101408:notes:13]

[0000950170-24-130551:notes:15]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 163 |  |  | $ | (109 | ) |  | $ | 54 |  |  | $ | 179 |  |  | $ | (108 | ) |  | $ | 71 |  |
| Customer contracts/relationships |  |  | 108 |  |  |  | (67 | ) |  |  | 41 |  |  |  | 114 |  |  |  | (62 | ) |  |  | 52 |  |
| Other purchased intangibles |  |  | 3 |  |  |  | (2 | ) |  |  | 1 |  |  |  | 6 |  |  |  | (5 | ) |  |  | 1 |  |
| Total purchased intangible assets |  | $ | 274 |  |  | $ | (178 | ) |  | $ | 96 |  |  | $ | 299 |  |  | $ | (175 | ) |  | $ | 124 |  |

[0000950170-24-130551:notes:16]
During the first six months of fiscal 2025, we retired approximately $25 million of fully amortized intangible assets.

[0000950170-24-130551:notes:17]
[same as prior period, unchanged from 0000950170-24-101408:notes:16]

[0000950170-24-130551:notes:18]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Statements of |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | IncomeClassification |
| Developed technology |  | $ | 9 |  |  | $ | 8 |  |  | $ | 17 |  |  | $ | 17 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 5 |  |  |  | 6 |  |  |  | 11 |  |  |  | 11 |  |  | Operating expenses |
| Other purchased intangibles |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1 |  |  | Operating expenses |
| Total |  | $ | 14 |  |  | $ | 14 |  |  | $ | 28 |  |  | $ | 29 |  |  |  |

[0000950170-24-130551:notes:19]
As of October 25, 2024, future amortization expense related to purchased intangible assets is as follows (in millions):

[0000950170-24-130551:notes:20]
| Fiscal Year |  | Amount |  |
| 2025 (remainder) |  | $ | 27 |  |
| 2026 |  |  | 39 |  |
| 2027 |  |  | 29 |  |
| 2028 |  |  | 1 |  |
| Total |  | $ | 96 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-24-130551:notes:21]
[same as prior period, unchanged from 0000950170-24-101408:notes:20]

[0000950170-24-130551:notes:22]
[same as prior period, unchanged from 0000950170-24-101408:notes:21]

[0000950170-24-130551:notes:23]
[same as prior period, unchanged from 0000950170-24-101408:notes:22]

[0000950170-24-130551:notes:24]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| Cash and cash equivalents |  | $ | 1,478 |  |  | $ | 1,903 |  |
| Restricted cash |  |  | 9 |  |  |  | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 1,487 |  |  | $ | 1,909 |  |

[0000950170-24-130551:notes:25]
[same as prior period, unchanged from 0000950170-24-101408:notes:24]

[0000950170-24-130551:notes:26]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| Purchased components |  | $ | 229 |  |  | $ | 116 |  |
| Finished goods |  |  | 88 |  |  |  | 70 |  |
| Inventories |  | $ | 317 |  |  | $ | 186 |  |

[0000950170-24-130551:notes:27]
[same as prior period, unchanged from 0000950170-24-101408:notes:26]

[0000950170-24-130551:notes:28]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 371 |  |  |  | 367 |  |
| Leasehold improvements |  |  | 86 |  |  |  | 81 |  |
| Computer, production, engineering and other equipment |  |  | 1,141 |  |  |  | 1,101 |  |
| Computer software |  |  | 349 |  |  |  | 340 |  |
| Furniture and fixtures |  |  | 67 |  |  |  | 77 |  |
| Construction-in-progress |  |  | 68 |  |  |  | 70 |  |
|  |  |  | 2,128 |  |  |  | 2,082 |  |
| Accumulated depreciation and amortization |  |  | (1,535 | ) |  |  | (1,478 | ) |
| Property and equipment, net |  | $ | 593 |  |  | $ | 604 |  |

[0000950170-24-130551:notes:29]
[same as prior period, unchanged from 0000950170-24-101408:notes:28]

[0000950170-24-130551:notes:30]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| Deferred tax assets |  | $ | 966 |  |  | $ | 896 |  |
| Operating lease right-of-use (ROU) assets |  |  | 242 |  |  |  | 247 |  |
| Other assets |  |  | 409 |  |  |  | 360 |  |
| Other non-current assets |  | $ | 1,617 |  |  | $ | 1,503 |  |

[0000950170-24-130551:notes:31]
Other non-current assets as of October 25, 2024 and April 26, 2024 include $87 million and $85 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies.

[0000950170-24-130551:notes:32]
[same as prior period, unchanged from 0000950170-24-101408:notes:31]

[0000950170-24-130551:notes:33]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| Accrued compensation and benefits |  | $ | 423 |  |  | $ | 538 |  |
| Product warranty liabilities |  |  | 18 |  |  |  | 18 |  |
| Operating lease liabilities |  |  | 41 |  |  |  | 40 |  |
| Other current liabilities |  |  | 487 |  |  |  | 417 |  |
| Accrued expenses |  | $ | 969 |  |  | $ | 1,013 |  |

[0000950170-24-130551:notes:34]
[same as prior period, unchanged from 0000950170-24-101408:notes:33]

[0000950170-24-130551:notes:35]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| Liability for uncertain tax positions |  | $ | 161 |  |  | $ | 153 |  |
| Income taxes payable |  |  | — |  |  |  | 100 |  |
| Product warranty liabilities |  |  | 9 |  |  |  | 9 |  |
| Operating lease liabilities |  |  | 216 |  |  |  | 220 |  |
| Other liabilities |  |  | 110 |  |  |  | 103 |  |
| Other long-term liabilities |  | $ | 496 |  |  | $ | 585 |  |

[0000950170-24-130551:notes:36]
[same as prior period, unchanged from 0000950170-24-101408:notes:35]

[0000950170-24-130551:notes:37]
[same as prior period, unchanged from 0000950170-24-101408:notes:36]

[0000950170-24-130551:notes:38]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| Deferred product revenue |  | $ | 57 |  |  | $ | 59 |  |
| Deferred services revenue |  |  | 4,001 |  |  |  | 4,123 |  |
| Financed unearned services revenue |  |  | 42 |  |  |  | 52 |  |
| Total |  | $ | 4,100 |  |  | $ | 4,234 |  |
| Reported as: |  |  |  |  |  |  |
| Short-term |  | $ | 2,045 |  |  | $ | 2,176 |  |
| Long-term |  |  | 2,055 |  |  |  | 2,058 |  |
| Total |  | $ | 4,100 |  |  | $ | 4,234 |  |

[0000950170-24-130551:notes:39]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 14 – Commitments and Contingencies for additional information related to these arrangements.

[0000950170-24-130551:notes:40]
During the six months ended October 25, 2024 and October 27, 2023, we recognized revenue of $1,264 million and $1,258 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0000950170-24-130551:notes:41]
[same as prior period, unchanged from 0000950170-24-101408:notes:40]

[0000950170-24-130551:notes:42]
As of October 25, 2024, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied was $4.4 billion. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 49% of our remaining performance obligations in the next 12 months and the remainder thereafter.

[0000950170-24-130551:notes:43]
[same as prior period, unchanged from 0000950170-24-101408:notes:42]

[0000950170-24-130551:notes:44]
[same as prior period, unchanged from 0000950170-24-101408:notes:43]

[0000950170-24-130551:notes:45]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| Other current assets |  | $ | 67 |  |  | $ | 69 |  |
| Other non-current assets |  |  | 102 |  |  |  | 100 |  |
| Total deferred commissions |  | $ | 169 |  |  | $ | 169 |  |

[0000950170-24-130551:notes:46]
[same as prior period, unchanged from 0000950170-24-101408:notes:45]

[0000950170-24-130551:notes:47]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | October 25, 2024 |  |  | October 27, 2023 |  |
| Interest income |  | $ | 27 |  |  | $ | 25 |  |  | $ | 63 |  |  | $ | 53 |  |
| Interest expense |  |  | (15 | ) |  |  | (15 | ) |  |  | (31 | ) |  |  | (31 | ) |
| Other, net |  |  | 3 |  |  |  | 1 |  |  |  | — |  |  |  | (3 | ) |
| Total other income, net |  | $ | 15 |  |  | $ | 11 |  |  | $ | 32 |  |  | $ | 19 |  |

[0000950170-24-130551:notes:48]
[same as prior period, unchanged from 0000950170-24-101408:notes:47]

[0000950170-24-130551:notes:49]
[same as prior period, unchanged from 0000950170-24-101408:notes:48]

[0000950170-24-130551:notes:50]
|  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 16 |  |  | $ | 18 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 222 |  |  | $ | 222 |  |
| Interest paid |  | $ | 30 |  |  | $ | 30 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-24-130551:notes:51]
[same as prior period, unchanged from 0000950170-24-101408:notes:50]

[0000950170-24-130551:notes:52]
[same as prior period, unchanged from 0000950170-24-101408:notes:51]

[0000950170-24-130551:notes:53]
[same as prior period, unchanged from 0000950170-24-101408:notes:52]

[0000950170-24-130551:notes:54]
[same as prior period, unchanged from 0000950170-24-101408:notes:53]

[0000950170-24-130551:notes:55]
[same as prior period, unchanged from 0000950170-24-101408:notes:54]

[0000950170-24-130551:notes:56]
[same as prior period, unchanged from 0000950170-24-101408:notes:55]

[0000950170-24-130551:notes:57]
[same as prior period, unchanged from 0000950170-24-101408:notes:56]

[0000950170-24-130551:notes:58]
The following is a summary of our investments at their cost or amortized cost as of October 25, 2024 and April 26, 2024 (in millions):

[0000950170-24-130551:notes:59]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| U.S. Treasury and government debt securities |  | $ | 744 |  |  | $ | 1,349 |  |
| Money market funds |  |  | 707 |  |  |  | 1,161 |  |
| Certificates of deposit |  |  | 14 |  |  |  | 12 |  |
| Mutual funds |  |  | 43 |  |  |  | 38 |  |
| Total debt and equity securities |  | $ | 1,508 |  |  | $ | 2,560 |  |

[0000950170-24-130551:notes:60]
[same as prior period, unchanged from 0000950170-24-101408:notes:59]

[0000950170-24-130551:notes:61]
As of October 25, 2024, all our debt investments are due to mature in one year or less.

[0000950170-24-130551:notes:62]
[same as prior period, unchanged from 0000950170-24-101408:notes:61]

[0000950170-24-130551:notes:63]
[same as prior period, unchanged from 0000950170-24-101408:notes:62]

[0000950170-24-130551:notes:64]
|  |  | October 25, 2024 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 757 |  |  | $ | 757 |  |  | $ | — |  |
| Money market funds |  |  | 707 |  |  |  | 707 |  |  |  | — |  |
| Certificates of deposit |  |  | 14 |  |  |  | — |  |  |  | 14 |  |
| Total cash and cash equivalents |  |  | 1,478 |  |  |  | 1,464 |  |  |  | 14 |  |
| Short-term investments: |  |  |  |  |  |  |  |  |  |
| U.S. Treasury and government debt securities |  |  | 744 |  |  |  | 744 |  |  |  | — |  |
| Total short-term investments |  |  | 744 |  |  |  | 744 |  |  |  | — |  |
| Total cash, cash equivalents and short-term investments |  | $ | 2,222 |  |  | $ | 2,208 |  |  | $ | 14 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 36 |  |  | $ | 36 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (27 | ) |  | $ | — |  |  | $ | (27 | ) |

[0000950170-24-130551:notes:65]
[same as prior period, unchanged from 0000950170-24-101408:notes:64]

[0000950170-24-130551:notes:66]
[same as prior period, unchanged from 0000950170-24-101408:notes:65]

[0000950170-24-130551:notes:67]
[same as prior period, unchanged from 0000950170-24-101408:notes:66]

[0000950170-24-130551:notes:68]
[same as prior period, unchanged from 0000950170-24-101408:notes:67]

[0000950170-24-130551:notes:69]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of October 25, 2024 and April 26, 2024, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0000950170-24-130551:notes:70]
[same as prior period, unchanged from 0000950170-24-101408:notes:69]

[0000950170-24-130551:notes:71]
As of October 25, 2024 and April 26, 2024, the fair value of our long-term debt, which includes the current portion of long-term debt, was approximately $1,881 million and $2,209 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0000950170-24-130551:notes:72]
6. Financing Arrangements

[0000950170-24-130551:notes:73]
Long-Term Debt

[0000950170-24-130551:notes:74]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0000950170-24-130551:notes:75]
|  |  | Effective Interest Rate |  | October 25, 2024 |  |  | April 26, 2024 |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  | $ | — |  |  | $ | 400 |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |
| Total principal amount |  |  |  |  | 2,000 |  |  |  | 2,400 |  |
| Unamortized discount and issuance costs |  |  |  |  | (7 | ) |  |  | (8 | ) |
| Total senior notes |  |  |  |  | 1,993 |  |  |  | 2,392 |  |
| Less: Current portion of long-term debt |  |  |  |  | (749 | ) |  |  | (400 | ) |
| Total long-term debt |  |  |  | $ | 1,244 |  |  | $ | 1,992 |  |

[0000950170-24-130551:notes:76]
Senior Notes

[0000950170-24-130551:notes:77]
On September 30, 2024, upon maturity, we repaid the 3.30% Senior Notes due September 2024 for an aggregate amount of $407 million, comprised of the principal and unpaid interest. Interest on our outstanding Senior Notes is payable semi-annually in June and December.

[0000950170-24-130551:notes:78]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0000950170-24-130551:notes:79]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of October 25, 2024, we were in compliance with all covenants associated with the Senior Notes.

[0000950170-24-130551:notes:80]
As of October 25, 2024, our aggregate future principal debt maturities are as follows (in millions):

[0000950170-24-130551:notes:81]
| Fiscal Year |  | Amount |  |
| 2025 (remainder) |  | $ | — |  |
| 2026 |  |  | 750 |  |
| 2027 |  |  | — |  |
| 2028 |  |  | 550 |  |
| 2029 |  |  | — |  |
| Thereafter |  |  | 700 |  |
| Total |  | $ | 2,000 |  |

[0000950170-24-130551:notes:82]
Commercial Paper Program and Credit Facility

[0000950170-24-130551:notes:83]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of October 25, 2024 or April 26, 2024.

[0000950170-24-130551:notes:84]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of October 25, 2024, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0000950170-24-130551:notes:85]
[same as prior period, unchanged from 0000950170-24-101408:notes:84]

[0000950170-24-130551:notes:86]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of October 25, 2024, have remaining lease terms not exceeding 18 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of October 25, 2024, have remaining lease terms not exceeding 4 years. As of October 25, 2024, our automobile leases have remaining lease terms not exceeding 4 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0000950170-24-130551:notes:87]
[same as prior period, unchanged from 0000950170-24-101408:notes:86]

[0000950170-24-130551:notes:88]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | October 25, 2024 |  |  | October 27, 2023 |  |
| Operating lease cost |  | $ | 12 |  |  | $ | 14 |  |  | $ | 25 |  |  | $ | 28 |  |
| Variable lease cost |  |  | 4 |  |  |  | 4 |  |  |  | 8 |  |  |  | 8 |  |
| Total lease cost |  | $ | 16 |  |  | $ | 18 |  |  | $ | 33 |  |  | $ | 36 |  |

[0000950170-24-130551:notes:89]
[same as prior period, unchanged from 0000950170-24-101408:notes:88]

[0000950170-24-130551:notes:90]
[same as prior period, unchanged from 0000950170-24-101408:notes:89]

[0000950170-24-130551:notes:91]
|  |  |  |  | Six Months Ended |  |
|  |  |  |  |  |  | October 25, 2024 |  |  | October 27, 2023 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  |  |  |  |  | $ | 24 |  |  | $ | 26 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  |  |  |  |  | $ | 6 |  |  | $ | 13 |  |

[0000950170-24-130551:notes:92]
[same as prior period, unchanged from 0000950170-24-101408:notes:91]

[0000950170-24-130551:notes:93]
|  |  |  |  |  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| Other non-current assets |  |  |  |  |  | $ | 242 |  |  | $ | 247 |  |
| Total operating lease ROU assets |  |  |  |  |  | $ | 242 |  |  | $ | 247 |  |
| Accrued expenses |  |  |  |  |  | $ | 41 |  |  | $ | 40 |  |
| Other long-term liabilities |  |  |  |  |  |  | 216 |  |  |  | 220 |  |
| Total operating lease liabilities |  |  |  |  |  | $ | 257 |  |  | $ | 260 |  |
| Weighted Average Remaining Lease Term |  |  |  |  |  | 8.7 years |  |  | 9.2 years |  |
| Weighted Average Discount Rate |  |  |  |  |  |  | 3.3 | % |  |  | 3.1 | % |

[0000950170-24-130551:notes:94]
Future minimum operating lease payments as of October 25, 2024, are as follows (in millions):

[0000950170-24-130551:notes:95]
| Fiscal Year |  |  |  |  |  | Amount |  |
| 2025 (remainder) |  |  |  |  |  | $ | 24 |  |
| 2026 |  |  |  |  |  |  | 45 |  |
| 2027 |  |  |  |  |  |  | 39 |  |
| 2028 |  |  |  |  |  |  | 32 |  |
| 2029 |  |  |  |  |  |  | 28 |  |
| Thereafter |  |  |  |  |  |  | 128 |  |
| Total lease payments |  |  |  |  |  |  | 296 |  |
| Less: Interest |  |  |  |  |  |  | (39 | ) |
| Total |  |  |  |  |  | $ | 257 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000950170-24-130551:notes:96]
[same as prior period, unchanged from 0000950170-24-101408:notes:95]

[0000950170-24-130551:notes:97]
[same as prior period, unchanged from 0000950170-24-101408:notes:96]

[0000950170-24-130551:notes:98]
We granted approximately 3 million restricted stock units (RSUs), including performance-based RSUs (PBRSUs), with a weighted average grant date fair value of $127.61 per share during the six months ended October 25, 2024.

[0000950170-24-130551:notes:99]
In the six months ended October 25, 2024, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSUs cliff-vest at the end of a three year performance period, which began on the date specified in the grant agreements and typically ends on the last day of the third fiscal year, following the grant date. The number of shares that will be used to calculate the settlement amount for all of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For half of the PBRSUs granted in the six months ended October 25, 2024, the number of shares used to calculate the settlement amount will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. For the remaining half of the PBRSUs granted in the six months ended October 25, 2024, the number of shares used to calculate the settlement amount will depend upon the Company's billings result average over the three-year performance period. The billings result average is computed based on achievement against annual billings targets, with each target set at the beginning of the respective fiscal year, during the

[0000950170-24-130551:notes:100]
three-year performance period. Billings for purposes of measuring the performance of these PBRSUs means the total obtained by adding net revenues as reported on the Company's Consolidated Statements of Income to the amount reported as the change in deferred revenue and financed unearned services revenue on the Consolidated Statements of Cash Flows for the applicable measurement period, excluding the impact of fluctuations in foreign currency exchange rates. The aggregate grant date fair value of PBRSUs granted in the current year was $62 million, which is being recognized to compensation expense over the remaining performance / service periods.

[0000950170-24-130551:notes:101]
[same as prior period, unchanged from 0000950170-24-101408:notes:100]

[0000950170-24-130551:notes:102]
[same as prior period, unchanged from 0000950170-24-101408:notes:101]

[0000950170-24-130551:notes:103]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | October 25, 2024 |  |  | October 27, 2023 |  |
| Cost of product revenues |  | $ | 2 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 2 |  |
| Cost of services revenues |  |  | 6 |  |  |  | 6 |  |  |  | 12 |  |  |  | 12 |  |
| Sales and marketing |  |  | 43 |  |  |  | 37 |  |  |  | 78 |  |  |  | 73 |  |
| Research and development |  |  | 37 |  |  |  | 35 |  |  |  | 68 |  |  |  | 67 |  |
| General and administrative |  |  | 15 |  |  |  | 14 |  |  |  | 27 |  |  |  | 26 |  |
| Total stock-based compensation expense |  | $ | 103 |  |  | $ | 93 |  |  | $ | 188 |  |  | $ | 180 |  |

[0000950170-24-130551:notes:104]
As of October 25, 2024, total unrecognized compensation expense related to equity awards was $764 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.2 years.

[0000950170-24-130551:notes:105]
[same as prior period, unchanged from 0000950170-24-101408:notes:104]

[0000950170-24-130551:notes:106]
In the first quarter of fiscal 2025, our Board of Directors authorized the repurchase of an additional $1.0 billion of our common stock. As of October 25, 2024, our Board of Directors has authorized cumulative repurchases of up to $17.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time.

[0000950170-24-130551:notes:107]
The following table summarizes activity related to the stock repurchase program for the six months ended October 25, 2024 (in millions, except for per share amounts):

[0000950170-24-130551:notes:108]
| Number of shares repurchased |  |  | 5.8 |  |
| Average price per share |  | $ | 121.58 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 28 |  |
| Stock repurchases allocated to retained earnings |  | $ | 672 |  |
| Remaining authorization at end of period |  | $ | 802 |  |

[0000950170-24-130551:notes:109]
Since the May 13, 2003 inception of our stock repurchase program through October 25, 2024, we repurchased a total of 377 million shares of our common stock at an average price of $43.25 per share, for an aggregate purchase price of $16.3 billion.

[0000950170-24-130551:notes:110]
[same as prior period, unchanged from 0000950170-24-101408:notes:109]

[0000950170-24-130551:notes:111]
[same as prior period, unchanged from 0000950170-24-101408:notes:110]

[0000950170-24-130551:notes:112]
|  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |
| Dividends per share declared |  | $ | 1.04 |  |  | $ | 1.00 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | 130 |  |  | $ | 171 |  |
| Dividend payments allocated to retained earnings |  | $ | 83 |  |  | $ | 38 |  |

[0000950170-24-130551:notes:113]
On November 19, 2024, we declared a cash dividend of $0.52 per share of common stock, payable on January 22, 2025 to holders of record as of the close of business on January 3, 2025. The timing and amount of future dividends will depend on market conditions, corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by us to be legally authorized under the laws of the state in which we are incorporated.

[0000950170-24-130551:notes:114]
[same as prior period, unchanged from 0000950170-24-101408:notes:113]

[0000950170-24-130551:notes:115]
[same as prior period, unchanged from 0000950170-24-101408:notes:114]

[0000950170-24-130551:notes:116]
|  |  | ForeignCurrencyTranslationAdjustments |  |  | DefinedBenefitObligationAdjustments |  |  | UnrealizedGains(Losses) on Available-for-SaleSecurities |  |  | UnrealizedGains(Losses) onDerivativeInstruments |  |  | Total |  |
| Balance as of April 26, 2024 |  | $ | (53 | ) |  | $ | (7 | ) |  | $ | — |  |  | $ | 1 |  |  | $ | (59 | ) |
| Other comprehensive income (loss), net of tax |  |  | 4 |  |  |  | — |  |  |  | 1 |  |  |  | (3 | ) |  |  | 2 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | 2 |  |
| Total other comprehensive income (loss) |  |  | 4 |  |  |  | — |  |  |  | 1 |  |  |  | (1 | ) |  |  | 4 |  |
| Balance as of October 25, 2024 |  | $ | (49 | ) |  | $ | (7 | ) |  | $ | 1 |  |  | $ | — |  |  | $ | (55 | ) |

[0000950170-24-130551:notes:117]
[same as prior period, unchanged from 0000950170-24-101408:notes:116]

[0000950170-24-130551:notes:118]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | Statements ofIncome Classification |
| Realized losses (gains) on cash flow hedges |  | $ | 2 |  |  | $ | (3 | ) |  | $ | 2 |  |  | $ | (4 | ) |  | Net revenues |
| Total reclassifications |  | $ | 2 |  |  | $ | (3 | ) |  | $ | 2 |  |  | $ | (4 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-24-130551:notes:119]
[same as prior period, unchanged from 0000950170-24-101408:notes:118]

[0000950170-24-130551:notes:120]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our condensed consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of October 25, 2024 or April 26, 2024. All contracts have a maturity of less than 12 months.

[0000950170-24-130551:notes:121]
[same as prior period, unchanged from 0000950170-24-101408:notes:120]

[0000950170-24-130551:notes:122]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 128 |  |  | $ | 71 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 920 |  |  | $ | 881 |  |
| Forward contracts purchased |  | $ | 12 |  |  | $ | 11 |  |

[0000950170-24-130551:notes:123]
[same as prior period, unchanged from 0000950170-24-101408:notes:122]

[0000950170-24-130551:notes:124]
[same as prior period, unchanged from 0000950170-24-101408:notes:123]

[0000950170-24-130551:notes:125]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | October 25, 2024 |  |  | October 27, 2023 |  |
|  |  | Gain (Loss) Recognized into Income |  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | 1 |  |  | $ | (45 | ) |  | $ | 14 |  |  | $ | (49 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-24-130551:notes:126]
[same as prior period, unchanged from 0000950170-24-101408:notes:125]

[0000950170-24-130551:notes:127]
In the first six months of fiscal 2025, management approved restructuring plans to redirect resources to the highest return activities and reduce costs. These plans collectively reduced our global workforce by approximately 2% for which restructuring charges, comprised of employee severance related expenses, were recorded during the first six months of fiscal 2025. The activities under these plans were initiated during the first six months of fiscal 2025 and are expected to be substantially complete by the end of fiscal 2025. Charges related to these plans consist primarily of employee severance-related costs.

[0000950170-24-130551:notes:128]
In the first six months of fiscal 2024, management executed a restructuring plan to redirect resources to highest return activities, and to optimize our global office space for our hybrid work model. In connection with the plan, we reduced our global workforce by approximately 1% and terminated certain real estate leases in various countries, resulting in restructuring charges comprised primarily of employee severance related expenses and lease termination charges. The activities under the plan were substantially completed by the end of fiscal 2024.

[0000950170-24-130551:notes:129]
[same as prior period, unchanged from 0000950170-24-101408:notes:129]

[0000950170-24-130551:notes:130]
|  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |
| Balance at beginning of period |  | $ | 10 |  |  | $ | 36 |  |
| Net charges |  |  | 29 |  |  |  | 31 |  |
| Cash payments |  |  | (22 | ) |  |  | (46 | ) |
| Balance at end of period |  | $ | 17 |  |  | $ | 21 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-24-130551:notes:131]
[same as prior period, unchanged from 0000950170-24-101408:notes:131]

[0000950170-24-130551:notes:132]
[same as prior period, unchanged from 0000950170-24-101408:notes:132]

[0000950170-24-130551:notes:133]
|  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |
| Effective tax rates |  |  | 17.0 | % |  |  | 23.8 | % |

[0000950170-24-130551:notes:134]
Our effective tax rate reflects the impact of a significant amount of earnings being taxed in foreign jurisdictions at rates below the United States (U.S.) statutory rate. Our effective tax rate for the six months ended October 25, 2024 includes an increase in discrete tax benefits related to stock compensation compared to the corresponding period of the prior year. Our effective tax rate for the six months ended October 27, 2023 included benefits for fiscal 2023 foreign tax credits resulting from legislative guidance for that period, partially offset by an increase in stock compensation for which no tax benefit is recorded.

[0000950170-24-130551:notes:135]
The Organisation for Economic Co-operation and Development (“OECD”) recently enacted model rules for a new global minimum tax framework known as Pillar Two. These rules have been agreed to by most OECD members. The OECD has since issued administrative guidance providing transition and safe harbor rules around the implementation of Pillar Two rules. On February 1, 2023, the FASB indicated that they believe taxes imposed under Pillar Two is an alternative minimum tax. Accordingly, deferred tax assets and liabilities associated with the minimum tax would not be recognized or adjusted for the estimated future effects of the minimum tax but would be recognized in the period incurred. We are currently subject to Pillar Two rules starting in our fiscal year 2025. As of October 25, 2024, Pillar Two taxes do not have a significant impact on our financial statements, particularly due to the safe harbor relief during the transition period, but we are still closely monitoring developments.

[0000950170-24-130551:notes:136]
[same as prior period, unchanged from 0000950170-24-101408:notes:136]

[0000950170-24-130551:notes:137]
[same as prior period, unchanged from 0000950170-24-101408:notes:137]

[0000950170-24-130551:notes:138]
[same as prior period, unchanged from 0000950170-24-101408:notes:138]

[0000950170-24-130551:notes:139]
As of October 25, 2024, we had $223 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $162 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $161 million have been recorded in other long-term liabilities.


## us-gaap:EarningsPerShareTextBlock

[0000950170-24-130551:notes:140]
[same as prior period, unchanged from 0000950170-24-101408:notes:140]

[0000950170-24-130551:notes:141]
[same as prior period, unchanged from 0000950170-24-101408:notes:141]

[0000950170-24-130551:notes:142]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | October 25, 2024 |  |  | October 27, 2023 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 299 |  |  | $ | 233 |  |  | $ | 547 |  |  | $ | 382 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 204 |  |  |  | 208 |  |  |  | 205 |  |  |  | 210 |  |
| Dilutive impact of employee equity award plans |  |  | 6 |  |  |  | 3 |  |  |  | 6 |  |  |  | 4 |  |
| Shares used in diluted computation |  |  | 210 |  |  |  | 211 |  |  |  | 211 |  |  |  | 214 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.47 |  |  | $ | 1.12 |  |  | $ | 2.67 |  |  | $ | 1.82 |  |
| Diluted |  | $ | 1.42 |  |  | $ | 1.10 |  |  | $ | 2.59 |  |  | $ | 1.79 |  |

[0000950170-24-130551:notes:143]
No potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculation for the three and six months ended October 25, 2024, respectively, while three million and four million shares from outstanding employee equity awards were excluded from the diluted net income per share calculation for the three and six months ended October 27, 2023, respectively, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-24-130551:notes:144]
[same as prior period, unchanged from 0000950170-24-101408:notes:144]

[0000950170-24-130551:notes:145]
[same as prior period, unchanged from 0000950170-24-101408:notes:145]

[0000950170-24-130551:notes:146]
[same as prior period, unchanged from 0000950170-24-101408:notes:146]

[0000950170-24-130551:notes:147]
[same as prior period, unchanged from 0000950170-24-101408:notes:147]

[0000950170-24-130551:notes:148]
[same as prior period, unchanged from 0000950170-24-101408:notes:148]

[0000950170-24-130551:notes:149]
[same as prior period, unchanged from 0000950170-24-101408:notes:149]

[0000950170-24-130551:notes:150]
|  | Three Months Ended October 25, 2024 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 768 |  |  | $ | — |  |  | $ | 768 |  |
| Support revenues |  | 635 |  |  |  | — |  |  |  | 635 |  |
| Professional and other services revenues |  | 87 |  |  |  | — |  |  |  | 87 |  |
| Public cloud revenues |  | — |  |  |  | 168 |  |  |  | 168 |  |
| Net revenues |  | 1,490 |  |  |  | 168 |  |  |  | 1,658 |  |
| Cost of product revenues |  | 305 |  |  |  | — |  |  |  | 305 |  |
| Cost of support revenues |  | 51 |  |  |  | — |  |  |  | 51 |  |
| Cost of professional and other services revenues |  | 64 |  |  |  | — |  |  |  | 64 |  |
| Cost of public cloud revenues |  | — |  |  |  | 44 |  |  |  | 44 |  |
| Segment cost of revenues |  | 420 |  |  |  | 44 |  |  |  | 464 |  |
| Segment gross profit | $ | 1,070 |  |  | $ | 124 |  |  | $ | 1,194 |  |
| Segment gross margin |  | 71.8 | % |  |  | 73.8 | % |  |  | 72.0 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 17 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,177 |  |
| Total gross margin |  |  |  |  |  |  |  | 71.0 | % |
| 1 Unallocated cost of revenues are composed of $8 million of stock-based compensation expense and $9 million of amortization of intangible assets. |  |

[0000950170-24-130551:notes:151]
|  | Three Months Ended October 27, 2023 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 706 |  |  | $ | — |  |  | $ | 706 |  |
| Support revenues |  | 623 |  |  |  | — |  |  |  | 623 |  |
| Professional and other services revenues |  | 79 |  |  |  | — |  |  |  | 79 |  |
| Public cloud revenues |  | — |  |  |  | 154 |  |  |  | 154 |  |
| Net revenues |  | 1,408 |  |  |  | 154 |  |  |  | 1,562 |  |
| Cost of product revenues |  | 275 |  |  |  | — |  |  |  | 275 |  |
| Cost of support revenues |  | 50 |  |  |  | — |  |  |  | 50 |  |
| Cost of professional and other services revenues |  | 60 |  |  |  | — |  |  |  | 60 |  |
| Cost of public cloud revenues |  | — |  |  |  | 52 |  |  |  | 52 |  |
| Segment cost of revenues |  | 385 |  |  |  | 52 |  |  |  | 437 |  |
| Segment gross profit | $ | 1,023 |  |  | $ | 102 |  |  | $ | 1,125 |  |
| Segment gross margin |  | 72.7 | % |  |  | 66.2 | % |  |  | 72.0 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 15 |  |
| Total gross profit |  |  |  |  |  |  | $ | 1,110 |  |
| Total gross margin |  |  |  |  |  |  |  | 71.1 | % |
| 1 Unallocated cost of revenues are composed of $7 million of stock-based compensation expense and $8 million of amortization of intangible assets. |  |

[0000950170-24-130551:notes:152]
|  | Six Months Ended October 25, 2024 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 1,437 |  |  | $ | — |  |  | $ | 1,437 |  |
| Support revenues |  | 1,266 |  |  |  | — |  |  |  | 1,266 |  |
| Professional and other services revenues |  | 169 |  |  |  | — |  |  |  | 169 |  |
| Public cloud revenues |  | — |  |  |  | 327 |  |  |  | 327 |  |
| Net revenues |  | 2,872 |  |  |  | 327 |  |  |  | 3,199 |  |
| Cost of product revenues |  | 573 |  |  |  | — |  |  |  | 573 |  |
| Cost of support revenues |  | 101 |  |  |  | — |  |  |  | 101 |  |
| Cost of professional and other services revenues |  | 128 |  |  |  | — |  |  |  | 128 |  |
| Cost of public cloud revenues |  | — |  |  |  | 90 |  |  |  | 90 |  |
| Segment cost of revenues |  | 802 |  |  |  | 90 |  |  |  | 892 |  |
| Segment gross profit | $ | 2,070 |  |  | $ | 237 |  |  | $ | 2,307 |  |
| Segment gross margin |  | 72.1 | % |  |  | 72.5 | % |  |  | 72.1 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 32 |  |
| Total gross profit |  |  |  |  |  |  | $ | 2,275 |  |
| Total gross margin |  |  |  |  |  |  |  | 71.1 | % |
| 1 Unallocated cost of revenues are composed of $15 million of stock-based compensation expense and $17 million of amortization of intangible assets. |  |

[0000950170-24-130551:notes:153]
|  | Six Months Ended October 27, 2023 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 1,296 |  |  | $ | — |  |  | $ | 1,296 |  |
| Support revenues |  | 1,234 |  |  |  | — |  |  |  | 1,234 |  |
| Professional and other services revenues |  | 156 |  |  |  | — |  |  |  | 156 |  |
| Public cloud revenues |  | — |  |  |  | 308 |  |  |  | 308 |  |
| Net revenues |  | 2,686 |  |  |  | 308 |  |  |  | 2,994 |  |
| Cost of product revenues |  | 539 |  |  |  | — |  |  |  | 539 |  |
| Cost of support revenues |  | 97 |  |  |  | — |  |  |  | 97 |  |
| Cost of professional and other services revenues |  | 118 |  |  |  | — |  |  |  | 118 |  |
| Cost of public cloud revenues |  | — |  |  |  | 103 |  |  |  | 103 |  |
| Segment cost of revenues |  | 754 |  |  |  | 103 |  |  |  | 857 |  |
| Segment gross profit | $ | 1,932 |  |  | $ | 205 |  |  | $ | 2,137 |  |
| Segment gross margin |  | 71.9 | % |  |  | 66.6 | % |  |  | 71.4 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 31 |  |
| Total gross profit |  |  |  |  |  |  | $ | 2,106 |  |
| Total gross margin |  |  |  |  |  |  |  | 70.3 | % |
| 1 Unallocated cost of revenues are composed of $14 million of stock-based compensation expense and $17 million of amortization of intangible assets. |  |

[0000950170-24-130551:notes:154]
[same as prior period, unchanged from 0000950170-24-101408:notes:152]

[0000950170-24-130551:notes:155]
[same as prior period, unchanged from 0000950170-24-101408:notes:153]

[0000950170-24-130551:notes:156]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | October 25, 2024 |  |  | October 27, 2023 |  |
| United States, Canada and Latin America (Americas) |  | $ | 862 |  |  | $ | 789 |  |  | $ | 1,625 |  |  | $ | 1,543 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 543 |  |  |  | 525 |  |  |  | 1,056 |  |  |  | 971 |  |
| Asia Pacific (APAC) |  |  | 253 |  |  |  | 248 |  |  |  | 518 |  |  |  | 480 |  |
| Net revenues |  | $ | 1,658 |  |  | $ | 1,562 |  |  | $ | 3,199 |  |  | $ | 2,994 |  |

[0000950170-24-130551:notes:157]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $807 million and $729 million during the three months ended October 25, 2024 and October 27, 2023, respectively, and were $1,506 million and $1,427 million during the six months ended October 25, 2024 and October 27, 2023, respectively.

[0000950170-24-130551:notes:158]
[same as prior period, unchanged from 0000950170-24-101408:notes:156]

[0000950170-24-130551:notes:159]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| U.S. |  | $ | 311 |  |  | $ | 1,142 |  |
| International |  |  | 1,911 |  |  |  | 2,110 |  |
| Total |  | $ | 2,222 |  |  | $ | 3,252 |  |

[0000950170-24-130551:notes:160]
[same as prior period, unchanged from 0000950170-24-101408:notes:158]

[0000950170-24-130551:notes:161]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| U.S. |  | $ | 369 |  |  | $ | 378 |  |
| International |  |  | 224 |  |  |  | 226 |  |
| Total |  | $ | 593 |  |  | $ | 604 |  |

[0000950170-24-130551:notes:162]
[same as prior period, unchanged from 0000950170-24-101408:notes:160]

[0000950170-24-130551:notes:163]
[same as prior period, unchanged from 0000950170-24-101408:notes:161]

[0000950170-24-130551:notes:164]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | October 25, 2024 |  |  | October 27, 2023 |  |
| Arrow Electronics, Inc. |  |  | 21 | % |  |  | 22 | % |  |  | 22 | % |  |  | 23 | % |
| TD Synnex Corporation |  |  | 24 | % |  |  | 22 | % |  |  | 23 | % |  |  | 21 | % |

[0000950170-24-130551:notes:165]
[same as prior period, unchanged from 0000950170-24-101408:notes:163]

[0000950170-24-130551:notes:166]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| Arrow Electronics, Inc. |  |  | 7 | % |  |  | 10 | % |
| TD Synnex Corporation |  |  | 26 | % |  |  | 26 | % |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-24-130551:notes:167]
14. Commitments and Contingencies

[0000950170-24-130551:notes:168]
Purchase Orders and Other Commitments

[0000950170-24-130551:notes:169]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of October 25, 2024, we had approximately $0.5 billion in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 25, 2024 and April 26, 2024, such liability amounted to $17 million and $20 million, respectively, and is included in accrued expenses in our condensed consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0000950170-24-130551:notes:170]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of October 25, 2024, we had approximately $0.4 billion in other purchase obligations.

[0000950170-24-130551:notes:171]
Financing Guarantees

[0000950170-24-130551:notes:172]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our condensed consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $26 million and $27 million of receivables during the six months ended October 25, 2024 and October 27, 2023, respectively.

[0000950170-24-130551:notes:173]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0000950170-24-130551:notes:174]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of October 25, 2024 and April 26, 2024, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-24-130551:notes:175]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of October 25, 2024, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make material payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our condensed consolidated balance sheets.

[0000950170-24-130551:notes:176]
Legal Contingencies

[0000950170-24-130551:notes:177]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0000950170-24-130551:notes:178]
We are subject to various legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigation brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0000950170-24-130551:notes:179]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of October 25, 2024 related to such matters.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000950170-24-130551:notes:180]
[same as prior period, unchanged from 0000950170-24-101408:notes:179]

[0000950170-24-130551:notes:181]
[same as prior period, unchanged from 0000950170-24-101408:notes:180]

[0000950170-24-130551:notes:182]
On September 5, 2024, The Berry Family Trust, a trust affiliated with Michael J. Berry, Chief Financial Officer of the Company, entered into a 10b5-1 trading arrangement intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) promulgated under the Exchange Act. The trading arrangement will expire on July 7, 2025, and may be terminated earlier in the limited circumstances defined in the trading arrangement. An aggregate of up to 95,000 shares may be sold pursuant to the trading arrangement.

[0000950170-24-130551:notes:183]
No other directors or executive officers of the Company adopted, modified or terminated any contract, instruction or written plan for the purchase or sale of the Company’s securities that was intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) or any non-Rule 10b5-1 trading arrangement (as defined in Item 408(c) of Regulation S-K), during the quarterly period covered by this report.
