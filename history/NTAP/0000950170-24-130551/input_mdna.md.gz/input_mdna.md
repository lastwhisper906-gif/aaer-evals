# NTAP MD&A — 0000950170-24-130551


## mdna

[0000950170-24-130551:mdna:1]
[same as prior period, unchanged from 0000950170-24-101408:mdna:1]

[0000950170-24-130551:mdna:2]
[same as prior period, unchanged from 0000950170-24-101408:mdna:2]

[0000950170-24-130551:mdna:3]
[same as prior period, unchanged from 0000950170-24-101408:mdna:3]

[0000950170-24-130551:mdna:4]
[same as prior period, unchanged from 0000950170-24-101408:mdna:4]

[0000950170-24-130551:mdna:5]
[same as prior period, unchanged from 0000950170-24-101408:mdna:5]

[0000950170-24-130551:mdna:6]
[same as prior period, unchanged from 0000950170-24-101408:mdna:6]

[0000950170-24-130551:mdna:7]
[same as prior period, unchanged from 0000950170-24-101408:mdna:7]

[0000950170-24-130551:mdna:8]
[same as prior period, unchanged from 0000950170-24-101408:mdna:8]

[0000950170-24-130551:mdna:9]
[same as prior period, unchanged from 0000950170-24-101408:mdna:9]

[0000950170-24-130551:mdna:10]
During the first six months of fiscal 2025, we repurchased approximately 5.8 million shares of our common stock at an average price of $121.58 per share, for an aggregate purchase price of $700 million. We also declared aggregate cash dividends of $1.04 per share in that period, for which we paid $213 million.

[0000950170-24-130551:mdna:11]
[same as prior period, unchanged from 0000950170-24-101408:mdna:11]

[0000950170-24-130551:mdna:12]
In the first six months of fiscal 2025, we approved restructuring plans to redirect resources to highest return activities and reduce costs. Aggregate charges recorded from the restructuring plans during the second quarter and first six months of fiscal 2025 totaled $12 million and $29 million, respectively.

[0000950170-24-130551:mdna:13]
[same as prior period, unchanged from 0000950170-24-101408:mdna:13]

[0000950170-24-130551:mdna:14]
[same as prior period, unchanged from 0000950170-24-101408:mdna:14]

[0000950170-24-130551:mdna:15]
27

[0000950170-24-130551:mdna:16]
[same as prior period, unchanged from 0000950170-24-101408:mdna:15]

[0000950170-24-130551:mdna:17]
|  |  | Three Months Ended |  |  | Six Months Ended |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 46 | % |  |  | 45 | % |  |  | 45 | % |  |  | 43 | % |  |
| Services |  |  | 54 |  |  |  | 55 |  |  |  | 55 |  |  |  | 57 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 19 |  |  |  | 18 |  |  |  | 18 |  |  |  | 18 |  |  |
| Cost of services |  |  | 10 |  |  |  | 11 |  |  |  | 11 |  |  |  | 12 |  |  |
| Gross profit |  |  | 71 |  |  |  | 71 |  |  |  | 71 |  |  |  | 70 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 29 |  |  |  | 30 |  |  |  | 30 |  |  |  | 31 |  |  |
| Research and development |  |  | 16 |  |  |  | 17 |  |  |  | 16 |  |  |  | 17 |  |  |
| General and administrative |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Total operating expenses |  |  | 50 |  |  |  | 52 |  |  |  | 52 |  |  |  | 54 |  |  |
| Income from operations |  |  | 21 |  |  |  | 19 |  |  |  | 20 |  |  |  | 16 |  |  |
| Other income, net |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |
| Income before income taxes |  |  | 22 |  |  |  | 20 |  |  |  | 21 |  |  |  | 17 |  |  |
| Provision for income taxes |  |  | 4 |  |  |  | 5 |  |  |  | 4 |  |  |  | 4 |  |  |
| Net income |  |  | 18 | % |  |  | 15 | % |  |  | 17 | % |  |  | 13 | % |  |

[0000950170-24-130551:mdna:18]
[same as prior period, unchanged from 0000950170-24-101408:mdna:17]

[0000950170-24-130551:mdna:19]
[same as prior period, unchanged from 0000950170-24-101408:mdna:18]

[0000950170-24-130551:mdna:20]
[same as prior period, unchanged from 0000950170-24-101408:mdna:19]

[0000950170-24-130551:mdna:21]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |
| Net revenues |  | $ | 1,658 |  |  | $ | 1,562 |  |  |  | 6 | % |  | $ | 3,199 |  |  | $ | 2,994 |  |  |  | 7 | % |

[0000950170-24-130551:mdna:22]
The increase in net revenues for the second quarter and first six months of fiscal 2025 compared to the corresponding periods of fiscal 2024 was due to an increase in product revenues and, to a lesser extent, an increase in services revenues. Product revenues as a percentage of net revenues increased by one percentage point and two percentage points, respectively, in the second quarter and first six months of fiscal 2025 compared to the corresponding periods of fiscal 2024.

[0000950170-24-130551:mdna:23]
[same as prior period, unchanged from 0000950170-24-101408:mdna:22]

[0000950170-24-130551:mdna:24]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |
| Product revenues |  | $ | 768 |  |  | $ | 706 |  |  |  | 9 | % |  | $ | 1,437 |  |  | $ | 1,296 |  |  |  | 11 | % |

[0000950170-24-130551:mdna:25]
[same as prior period, unchanged from 0000950170-24-101408:mdna:24]

[0000950170-24-130551:mdna:26]
In prior periods, we presented the hardware and software components of our GAAP product revenues to illustrate the significance and value of the Company’s software. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. Effective in fiscal 2025, we are no longer presenting the non-GAAP hardware and software components of our product revenues, as management no longer considers them to be key financial measures. The Company’s current strategy is expected to deliver investor value through growth in total revenues, including product revenues, while maintaining operational discipline to drive earnings leverage. While software continues to be the primary value driver of our products, NetApp is primarily focused on driving growth in total product revenues, through the sale of configured storage systems comprised of both hardware and software, with less focus on the pricing of each component. Additionally, the Company is considering potential opportunities to simplify pricing for certain products in the future, which may eliminate the existence of separate prices for hardware and software components and/or impact our ability to allocate between them.

[0000950170-24-130551:mdna:27]
[same as prior period, unchanged from 0000950170-24-101408:mdna:27]

[0000950170-24-130551:mdna:28]
Total product revenues increased in the second quarter and first six months of fiscal 2025 compared to the corresponding periods of the prior year due to higher sales of C-Series all-flash array systems.

[0000950170-24-130551:mdna:29]
[same as prior period, unchanged from 0000950170-24-101408:mdna:29]

[0000950170-24-130551:mdna:30]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |
| Services revenues |  | $ | 890 |  |  | $ | 856 |  |  |  | 4 | % |  | $ | 1,762 |  |  | $ | 1,698 |  |  |  | 4 | % |
| Support |  |  | 635 |  |  |  | 623 |  |  |  | 2 | % |  |  | 1,266 |  |  |  | 1,234 |  |  |  | 3 | % |
| Professional and other services |  |  | 87 |  |  |  | 79 |  |  |  | 10 | % |  |  | 169 |  |  |  | 156 |  |  |  | 8 | % |
| Public cloud |  |  | 168 |  |  |  | 154 |  |  |  | 9 | % |  |  | 327 |  |  |  | 308 |  |  |  | 6 | % |

[0000950170-24-130551:mdna:31]
[same as prior period, unchanged from 0000950170-24-101408:mdna:31]

[0000950170-24-130551:mdna:32]
[same as prior period, unchanged from 0000950170-24-101408:mdna:32]

[0000950170-24-130551:mdna:33]
Support revenues increased in the second quarter and first six months of fiscal 2025 compared to the corresponding periods of the prior year as a result of a higher aggregate support contract value for our installed base.

[0000950170-24-130551:mdna:34]
Professional and other services revenues increased by $8 million and $13 million in the second quarter and first six months of fiscal 2025, respectively, compared to the corresponding periods of the prior year.

[0000950170-24-130551:mdna:35]
[same as prior period, unchanged from 0000950170-24-101408:mdna:35]

[0000950170-24-130551:mdna:36]
[same as prior period, unchanged from 0000950170-24-101408:mdna:36]

[0000950170-24-130551:mdna:37]
Public Cloud revenues increased in the second quarter and first six months of fiscal 2025 compared to the corresponding periods                                                                                                         of the prior year, due to higher customer demand, driven by NetApp’s diversified cloud offerings and an overall growth in the cloud market.

[0000950170-24-130551:mdna:38]
[same as prior period, unchanged from 0000950170-24-101408:mdna:38]

[0000950170-24-130551:mdna:39]
[same as prior period, unchanged from 0000950170-24-101408:mdna:39]

[0000950170-24-130551:mdna:40]
[same as prior period, unchanged from 0000950170-24-101408:mdna:40]

[0000950170-24-130551:mdna:41]
(2) cost of services revenues, composed of (a) cost of support revenues, which includes the costs of providing support activities for hardware and software support, global support partnership programs, and third party royalty costs, (b) cost of professional and other services revenues, (c) cost of public cloud revenues, constituting the cost of providing our Public Cloud offerings, which includes depreciation and amortization expense and third party datacenter fees, and (d) unallocated cost of services revenues, which includes stock-based compensation and amortization of intangibles.

[0000950170-24-130551:mdna:42]
[same as prior period, unchanged from 0000950170-24-101408:mdna:42]

[0000950170-24-130551:mdna:43]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |
| Cost of product revenues |  | $ | 307 |  |  | $ | 276 |  |  |  | 11 | % |  | $ | 576 |  |  | $ | 541 |  |  |  | 6 | % |
| Hybrid Cloud |  |  | 305 |  |  |  | 275 |  |  |  | 11 | % |  |  | 573 |  |  |  | 539 |  |  |  | 6 | % |
| Unallocated |  |  | 2 |  |  |  | 1 |  |  |  | 100 | % |  |  | 3 |  |  |  | 2 |  |  |  | 50 | % |

[0000950170-24-130551:mdna:44]
[same as prior period, unchanged from 0000950170-24-101408:mdna:82]

[0000950170-24-130551:mdna:45]
[same as prior period, unchanged from 0000950170-24-101408:mdna:44]

[0000950170-24-130551:mdna:46]
Cost of Hybrid Cloud product revenues represented approximately 40% of product revenues for the second quarter and first six months of fiscal 2025 compared to 39% and 42%, respectively, for the corresponding periods of fiscal 2024. Materials costs represented 89% of cost of Hybrid Cloud product revenues for the second quarter and first six months of fiscal 2025, compared to 86% and 87%, respectively, for the corresponding periods of fiscal 2024.

[0000950170-24-130551:mdna:47]
Materials costs increased by $34 million and $38 million, respectively, in the second quarter and first six months of fiscal 2025 compared to the corresponding periods of the prior year.

[0000950170-24-130551:mdna:48]
Hybrid Cloud product gross margins remained relatively flat in the second quarter of fiscal 2025 compared to the corresponding period of the prior year. Hybrid Cloud product gross margins increased by approximately two percentage points in the first six months of fiscal 2025 compared to the corresponding period of the prior year, primarily due to lower component and freight costs.

[0000950170-24-130551:mdna:49]
[same as prior period, unchanged from 0000950170-24-101408:mdna:48]

[0000950170-24-130551:mdna:50]
Unallocated cost of product revenues were relatively flat in the second quarter and first six months of fiscal 2025 compared to the corresponding periods of the prior year.

[0000950170-24-130551:mdna:51]
[same as prior period, unchanged from 0000950170-24-101408:mdna:50]

[0000950170-24-130551:mdna:52]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |
| Cost of services revenues |  | $ | 174 |  |  | $ | 176 |  |  |  | (1 | )% |  | $ | 348 |  |  | $ | 347 |  |  |  | — | % |
| Support |  |  | 51 |  |  |  | 50 |  |  |  | 2 | % |  |  | 101 |  |  |  | 97 |  |  |  | 4 | % |
| Professional and other services |  |  | 64 |  |  |  | 60 |  |  |  | 7 | % |  |  | 128 |  |  |  | 118 |  |  |  | 8 | % |
| Public cloud |  |  | 44 |  |  |  | 52 |  |  |  | (15 | )% |  |  | 90 |  |  |  | 103 |  |  |  | (13 | )% |
| Unallocated |  |  | 15 |  |  |  | 14 |  |  |  | 7 | % |  |  | 29 |  |  |  | 29 |  |  |  | — | % |

[0000950170-24-130551:mdna:53]
[same as prior period, unchanged from 0000950170-24-101408:mdna:52]

[0000950170-24-130551:mdna:54]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, increased in the second quarter and first six months of fiscal 2025 compared to the corresponding periods of fiscal 2024. Cost of Hybrid Cloud services revenues represented approximately 16% of Hybrid Cloud services revenues for the second quarter and first six months of fiscal 2025 compared to 16% and 15%, respectively, for the corresponding periods of fiscal 2024.

[0000950170-24-130551:mdna:55]
Hybrid Cloud support gross margins were relatively flat in the second quarter and first six months of fiscal 2025 compared to the corresponding periods of the prior year. Hybrid Cloud professional and other services gross margins increased by approximately two percentage points in the second quarter of fiscal 2025 compared to the corresponding period of fiscal 2024 due to the mix of services provided. Hybrid Cloud professional and other services gross margins remained relatively flat in the first six months of fiscal 2025 compared to the corresponding period of fiscal 2024.

[0000950170-24-130551:mdna:56]
[same as prior period, unchanged from 0000950170-24-101408:mdna:55]

[0000950170-24-130551:mdna:57]
Cost of Public Cloud revenues decreased in each the second quarter and first six months of fiscal 2025. Public Cloud gross margins increased by eight percentage points and six percentage points, respectively, in the second quarter and first six months of fiscal 2025 compared to the corresponding periods of fiscal 2024. The decrease in cost of Public Cloud revenues and improved gross margins was due to cost optimization that included a decrease in fixed assets depreciation, and the mix of offerings provided.

[0000950170-24-130551:mdna:58]
[same as prior period, unchanged from 0000950170-24-101408:mdna:57]

[0000950170-24-130551:mdna:59]
Unallocated cost of services revenues were relatively flat in the second quarter and first six months of fiscal 2025 compared to the corresponding periods of the prior year.

[0000950170-24-130551:mdna:60]
30

[0000950170-24-130551:mdna:61]
[same as prior period, unchanged from 0000950170-24-101408:mdna:59]

[0000950170-24-130551:mdna:62]
[same as prior period, unchanged from 0000950170-24-101408:mdna:60]

[0000950170-24-130551:mdna:63]
Sales and marketing, research and development, and general and administrative expenses for the second quarter and first six months of fiscal 2025 totaled $819 million, or 49% of net revenues, and $1,617 million, or 51% of net revenues, respectively, each reflecting a decrease of two percentage points compared to the corresponding periods of fiscal 2024, primarily due to the increase in net revenues.

[0000950170-24-130551:mdna:64]
[same as prior period, unchanged from 0000950170-24-101408:mdna:62]

[0000950170-24-130551:mdna:65]
Total compensation costs included in sales and marketing, research and development and general and administrative expenses in the second quarter and first six months of fiscal 2025, were relatively flat compared to the corresponding periods of the prior year.

[0000950170-24-130551:mdna:66]
[same as prior period, unchanged from 0000950170-24-101408:mdna:65]

[0000950170-24-130551:mdna:67]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |
| Sales and marketing expenses |  | $ | 485 |  |  | $ | 461 |  |  |  | 5 | % |  | $ | 956 |  |  | $ | 929 |  |  |  | 3 | % |

[0000950170-24-130551:mdna:68]
[same as prior period, unchanged from 0000950170-24-101408:mdna:67]

[0000950170-24-130551:mdna:69]
The increases in sales and marketing expenses in the second quarter and first six months of fiscal 2025 compared to the corresponding periods of the prior year were primarily due to an increase in sales commissions expenses.

[0000950170-24-130551:mdna:70]
[same as prior period, unchanged from 0000950170-24-101408:mdna:69]

[0000950170-24-130551:mdna:71]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |
| Research and development expenses |  | $ | 257 |  |  | $ | 262 |  |  |  | (2 | )% |  | $ | 509 |  |  | $ | 509 |  |  |  | — | % |

[0000950170-24-130551:mdna:72]
[same as prior period, unchanged from 0000950170-24-101408:mdna:71]

[0000950170-24-130551:mdna:73]
The decrease in research and development expenses in the second quarter of fiscal 2025 compared to the corresponding period of the prior year was due to lower compensation costs driven by lower incentive compensation expense, partially offset by higher expenses in other components of compensation costs.

[0000950170-24-130551:mdna:74]
Research and development expenses remained relatively flat in the first six months of fiscal 2025 compared to the corresponding period of the prior year.

[0000950170-24-130551:mdna:75]
[same as prior period, unchanged from 0000950170-24-101408:mdna:74]

[0000950170-24-130551:mdna:76]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |
| General and administrative expenses |  | $ | 77 |  |  | $ | 75 |  |  |  | 3 | % |  | $ | 152 |  |  | $ | 149 |  |  |  | 2 | % |

[0000950170-24-130551:mdna:77]
[same as prior period, unchanged from 0000950170-24-101408:mdna:76]

[0000950170-24-130551:mdna:78]
General and administrative expenses remained relatively flat in the second quarter and first six months of fiscal 2025 compared to the corresponding periods of the prior year.

[0000950170-24-130551:mdna:79]
[same as prior period, unchanged from 0000950170-24-101408:mdna:78]

[0000950170-24-130551:mdna:80]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |
| Restructuring charges |  | $ | 12 |  |  | $ | 5 |  |  |  | 140 | % |  | $ | 29 |  |  | $ | 31 |  |  |  | (6 | )% |

[0000950170-24-130551:mdna:81]
[same as prior period, unchanged from 0000950170-24-101408:mdna:113]

[0000950170-24-130551:mdna:82]
In the first six months of fiscal 2025, management approved restructuring plans to redirect resources to highest return activities and reduce costs, which included a reduction of our global workforce by approximately 2%. Charges related to the plans consisted primarily of employee severance-related costs. The activities under the plans are expected to be substantially complete by the end of fiscal 2025.

[0000950170-24-130551:mdna:83]
In the first six months of fiscal 2024, management executed a restructuring plan to redirect resources to highest return activities, and to optimize our global office space for our hybrid work model. In connection with the plan, we reduced our global workforce by approximately 1% and terminated certain real estate leases in various countries, resulting in restructuring charges comprised primarily of employee severance-related expenses and lease termination charges. The activities under the plan were substantially complete by the end of fiscal 2024.

[0000950170-24-130551:mdna:84]
[same as prior period, unchanged from 0000950170-24-101408:mdna:83]

[0000950170-24-130551:mdna:85]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |
| Acquisition-related expense |  | $ | 1 |  |  | $ | 3 |  |  |  | (67 | )% |  | $ | 2 |  |  | $ | 6 |  |  |  | (67 | )% |

[0000950170-24-130551:mdna:86]
Acquisition-related expenses decreased by $2 million and $4 million, respectively, in the second quarter and first six months of fiscal 2025 compared to the corresponding periods of the prior year.

[0000950170-24-130551:mdna:87]
[same as prior period, unchanged from 0000950170-24-101408:mdna:86]

[0000950170-24-130551:mdna:88]
[same as prior period, unchanged from 0000950170-24-101408:mdna:87]

[0000950170-24-130551:mdna:89]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |
| Interest income |  | $ | 27 |  |  | $ | 25 |  |  |  | 8 | % |  | $ | 63 |  |  | $ | 53 |  |  |  | 19 | % |
| Interest expense |  |  | (15 | ) |  |  | (15 | ) |  |  | — | % |  |  | (31 | ) |  |  | (31 | ) |  |  | — | % |
| Other, net |  |  | 3 |  |  |  | 1 |  |  | NM |  |  |  | — |  |  |  | (3 | ) |  | NM |  |
| Total |  | $ | 15 |  |  | $ | 11 |  |  | NM |  |  | $ | 32 |  |  | $ | 19 |  |  | NM |  |

[0000950170-24-130551:mdna:90]
[same as prior period, unchanged from 0000950170-24-101408:mdna:89]

[0000950170-24-130551:mdna:91]
Interest income increased in the second quarter and first six months of fiscal 2025 compared to the corresponding periods of the prior year, primarily due to higher yields earned on our cash and investments. Interest expense was relatively flat in the second quarter and first six months of fiscal 2025 compared to the corresponding periods of fiscal 2024.

[0000950170-24-130551:mdna:92]
[same as prior period, unchanged from 0000950170-24-101408:mdna:91]

[0000950170-24-130551:mdna:93]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | % Change |  |
| Provision for income taxes |  | $ | 61 |  |  | $ | 82 |  |  |  | (26 | )% |  | $ | 112 |  |  | $ | 119 |  |  |  | (6 | )% |

[0000950170-24-130551:mdna:94]
Our effective tax rate for the three and six months ended October 25, 2024 includes an increase in discrete tax benefits related to stock compensation compared to the corresponding periods of the prior year. Our effective tax rate for the three and six months ended October 27, 2023 included a benefit for increased fiscal 2023 foreign tax credits resulting from legislative guidance for those periods partially offset by an increase in stock compensation for which no tax benefit is recorded.

[0000950170-24-130551:mdna:95]
As of October 25, 2024, we had $223 million of gross unrecognized tax benefits. Inclusive of penalties, interest and certain income tax benefits, $162 million would affect our provision for income taxes if recognized. Net unrecognized tax benefits of $161 million have been recorded in other long-term liabilities.

[0000950170-24-130551:mdna:96]
[same as prior period, unchanged from 0000950170-24-101408:mdna:95]

[0000950170-24-130551:mdna:97]
| (In millions) |  | October 25, 2024 |  |  | April 26, 2024 |  |
| Cash, cash equivalents and short-term investments |  | $ | 2,222 |  |  | $ | 3,252 |  |
| Principal amount of debt |  | $ | 2,000 |  |  | $ | 2,400 |  |

[0000950170-24-130551:mdna:98]
32

[0000950170-24-130551:mdna:99]
[same as prior period, unchanged from 0000950170-24-101408:mdna:97]

[0000950170-24-130551:mdna:100]
|  |  | Six Months Ended |  |
| (In millions) |  | October 25, 2024 |  |  | October 27, 2023 |  |
| Net cash provided by operating activities |  | $ | 446 |  |  | $ | 588 |  |
| Net cash provided by (used in) investing activities |  |  | 513 |  |  |  | (1 | ) |
| Net cash used in financing activities |  |  | (1,390 | ) |  |  | (942 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 9 |  |  |  | (26 | ) |
| Net change in cash, cash equivalents and restricted cash |  | $ | (422 | ) |  | $ | (381 | ) |

[0000950170-24-130551:mdna:101]
[same as prior period, unchanged from 0000950170-24-101408:mdna:99]

[0000950170-24-130551:mdna:102]
As of October 25, 2024, our cash, cash equivalents and short-term investments were $2.2 billion, which represents a decrease of $1.0 billion during the first six months of fiscal 2025. The decrease was primarily due to $700 million used for the repurchase of our common stock, a $400 million principal repayment of our 3.30% Senior Notes due September 2024, $213 million used for the payment of dividends, $132 million used for payment of taxes related to net share settlement of stock awards and $86 million used for purchases of property and equipment, partially offset by $446 million provided by operating activities. Our net working capital deficit was $378 million as of October 25, 2024, a reduction of $1.2 billion when compared to April 26, 2024, primarily due to the decrease in cash, cash equivalents and short-term investments discussed above and the reclassification of $750 million principal amount of our Senior Notes from long-term to current liabilities.

[0000950170-24-130551:mdna:103]
[same as prior period, unchanged from 0000950170-24-101408:mdna:101]

[0000950170-24-130551:mdna:104]
During the first six months of fiscal 2025, we generated cash from operating activities of $446 million, reflecting net income of $547 million which was adjusted for non-cash depreciation and amortization expense of $126 million and non-cash stock-based compensation expense of $188 million, compared to $588 million of cash generated from operating activities during the first six months of fiscal 2024.

[0000950170-24-130551:mdna:105]
Significant changes in assets and liabilities in the first six months of fiscal 2025 included the following:

[0000950170-24-130551:mdna:106]
•
Accounts receivable decreased $138 million, reflecting lower billings in the first six months of fiscal 2025 compared to the last six months of fiscal 2024.

[0000950170-24-130551:mdna:107]
•
Inventory increased by $132 million, primarily due to higher raw materials purchases.

[0000950170-24-130551:mdna:108]
•
Deferred revenue and financed unearned services revenue decreased by $164 million, due to a decrease in deferred revenue for software and hardware support contracts.

[0000950170-24-130551:mdna:109]
[same as prior period, unchanged from 0000950170-24-101408:mdna:107]

[0000950170-24-130551:mdna:110]
[same as prior period, unchanged from 0000950170-24-101408:mdna:108]

[0000950170-24-130551:mdna:111]
During the first six months of fiscal 2025, we generated $597 million from maturities and sales of investments, net of purchases and paid $86 million for capital expenditures, as compared to the same period of fiscal 2024, in which we generated $72 million from maturities and sales of investments, net of purchases, and paid $73 million for capital expenditures.

[0000950170-24-130551:mdna:112]
[same as prior period, unchanged from 0000950170-24-101408:mdna:110]

[0000950170-24-130551:mdna:113]
During the first six months of fiscal 2025, cash flows used in financing activities totaled $1.4 billion and included $700 million for the repurchase of approximately 6 million shares of common stock, $400 million principal repayment upon maturity of our 3.30% Senior Notes due in September 2024 and $213 million for the payment of dividends. During the first six months of fiscal 2024, cash flows used in financing activities totaled $942 million and included $700 million for the repurchase of approximately 9 million shares of common stock and $209 million for the payment of dividends.

[0000950170-24-130551:mdna:114]
[same as prior period, unchanged from 0000950170-24-101408:mdna:112]

[0000950170-24-130551:mdna:115]
[same as prior period, unchanged from 0000950170-24-101408:mdna:114]

[0000950170-24-130551:mdna:116]
Our principal sources of liquidity as of October 25, 2024 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-24-130551:mdna:117]
[same as prior period, unchanged from 0000950170-24-101408:mdna:116]

[0000950170-24-130551:mdna:118]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| Cash and cash equivalents |  | $ | 1,478 |  |  | $ | 1,903 |  |
| Short-term investments |  |  | 744 |  |  |  | 1,349 |  |
| Total |  | $ | 2,222 |  |  | $ | 3,252 |  |

[0000950170-24-130551:mdna:119]
As of October 25, 2024 and April 26, 2024, $1.9 billion and $2.1 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $0.3 billion and $1.2 billion, respectively, were available in the U.S.

[0000950170-24-130551:mdna:120]
[same as prior period, unchanged from 0000950170-24-101408:mdna:119]

[0000950170-24-130551:mdna:121]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of October 25, 2024.

[0000950170-24-130551:mdna:122]
[same as prior period, unchanged from 0000950170-24-101408:mdna:121]

[0000950170-24-130551:mdna:123]
[same as prior period, unchanged from 0000950170-24-101408:mdna:122]

[0000950170-24-130551:mdna:124]
The following table summarizes the principal amount of our Senior Notes as of October 25, 2024 (in millions):

[0000950170-24-130551:mdna:125]
|  |  | Amount |  |
| 1.875% Senior Notes Due June 2025 |  | $ | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,000 |  |

[0000950170-24-130551:mdna:126]
[same as prior period, unchanged from 0000950170-24-101408:mdna:125]

[0000950170-24-130551:mdna:127]
On September 30, 2024, upon maturity, we repaid our 3.30% Senior Notes due September 2024 for an aggregate amount of $407 million, comprised of the principal and unpaid interest.

[0000950170-24-130551:mdna:128]
Commercial Paper Program and Credit Facility

[0000950170-24-130551:mdna:129]
We have a commercial paper program (the “Program”), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of October 25, 2024.

[0000950170-24-130551:mdna:130]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in May 2023, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of October 25, 2024, we were compliant with all associated covenants in the agreement. No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-24-130551:mdna:131]
[same as prior period, unchanged from 0000950170-24-101408:mdna:129]

[0000950170-24-130551:mdna:132]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for the remainder of fiscal 2025 to be between $50 million and $100 million.

[0000950170-24-130551:mdna:133]
[same as prior period, unchanged from 0000950170-24-101408:mdna:131]

[0000950170-24-130551:mdna:134]
The Tax Cuts and Jobs Act of 2017 imposed a mandatory, one-time transition tax on accumulated foreign earnings and profits that had not previously been subject to U.S. income tax. As of October 25, 2024, the outstanding payment related to the transition tax is estimated to be approximately $100 million which is expected to be paid during fiscal 2026. Our estimates for future transition tax payments, however, could change with further guidance or review from U.S. federal and state tax authorities or other regulatory bodies.

[0000950170-24-130551:mdna:135]
[same as prior period, unchanged from 0000950170-24-101408:mdna:133]

[0000950170-24-130551:mdna:136]
On November 19, 2024, we declared a cash dividend of $0.52 per share of common stock, payable on January 22, 2025, to holders of record as of the close of business on January 3, 2025.

[0000950170-24-130551:mdna:137]
In the first quarter of fiscal 2025, our Board of Directors authorized the repurchase of an additional $1.0 billion of our common stock. As of October 25, 2024, our Board of Directors had authorized cumulative repurchases of up to $17.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through October 25, 2024, we repurchased a total of 377 million shares of our common stock at an average price of $43.25 per share, for an aggregate purchase price of $16.3 billion. As of October 25, 2024, the remaining authorized amount for stock repurchases under this program was $0.8 billion.

[0000950170-24-130551:mdna:138]
[same as prior period, unchanged from 0000950170-24-101408:mdna:136]

[0000950170-24-130551:mdna:139]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled approximately $0.9 billion at October 25, 2024.

[0000950170-24-130551:mdna:140]
[same as prior period, unchanged from 0000950170-24-101408:mdna:139]

[0000950170-24-130551:mdna:141]
We have and continue to enter into financing and leasing contracts through the ordinary course of business. These arrangements and related financing guarantees are described in Note 14 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1. There has been no material change in our financing guarantees as described in our 2024 Annual Report on Form 10-K.

[0000950170-24-130551:mdna:142]
Legal Contingencies

[0000950170-24-130551:mdna:143]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 14 – Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1.

[0000950170-24-130551:mdna:144]
[same as prior period, unchanged from 0000950170-24-101408:mdna:146]

[0000950170-24-130551:mdna:145]
[same as prior period, unchanged from 0000950170-24-101408:mdna:147]

[0000950170-24-130551:mdna:146]
36
