# NTAP 8-K — 0000950170-24-129714 filed 2024-11-21

## item codes, every 8-K on or before 2024-11-25

- 2024-11-21 0000950170-24-129714 — 2.02, 9.01
- 2024-09-12 0000950170-24-105928 — 5.02, 5.07, 9.01
- 2024-08-28 0000950170-24-101383 — 2.02, 5.02, 9.01
- 2024-05-30 0000950170-24-066567 — 2.02, 8.01, 9.01
- 2024-04-09 0000950170-24-042957 — 5.02
- 2024-02-29 0000950170-24-023060 — 2.02, 9.01
- 2023-11-28 0000950170-23-066400 — 2.02, 9.01
- 2023-11-16 0000950170-23-064506 — 5.02, 5.03, 9.01
- 2023-09-15 0000950170-23-048229 — 5.02, 5.07, 9.01
- 2023-08-23 0000950170-23-044130 — 2.02, 9.01
- 2023-08-10 0000950170-23-041348 — 5.02
- 2023-05-31 0000950170-23-025324 — 1.01, 2.02, 8.01, 9.01
- 2023-02-22 0000950170-23-003745 — 2.02, 9.01
- 2023-01-31 0001193125-23-019739 — 2.05, 7.01, 9.01
- 2022-11-29 0000950170-22-025793 — 2.02, 9.01
- 2022-11-16 0000950170-22-025317 — 5.02
- 2022-09-14 0000950170-22-018490 — 5.07
- 2022-08-24 0000950170-22-017731 — 2.02, 9.01
- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2024-11-25

- none on or before 2024-11-25

## item 2.02 — earnings release, exhibit 99.1

[0000950170-24-129714:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0000950170-24-129714:8k_2_02:2]
EX-99.1

[0000950170-24-129714:8k_2_02:3]
Exhibit 99.1

[0000950170-24-129714:8k_2_02:4]
NetApp Reports Second Quarter of Fiscal Year 2025 Results

[0000950170-24-129714:8k_2_02:5]
Net revenues of $1.66 billion for the second quarter; 6% year-over-year increase

[0000950170-24-129714:8k_2_02:6]
•
Record all-flash array annualized net revenue run rate1 of $3.8 billion, an increase of 19% year-over-year

[0000950170-24-129714:8k_2_02:7]
•
First party and marketplace cloud storage services revenue grew approximately 43% year-over-year

[0000950170-24-129714:8k_2_02:8]
•
Second quarter GAAP operating margin of 21%; record second quarter non-GAAP operating margin2 of 29%

[0000950170-24-129714:8k_2_02:9]
•
Second quarter GAAP net income per share3 of $1.42; record second quarter non-GAAP net income per share2 of $1.87

[0000950170-24-129714:8k_2_02:10]
•
Returned $406 million to stockholders through share repurchases and cash dividends

[0000950170-24-129714:8k_2_02:11]
SAN JOSE, Calif.—November 21, 2024—NetApp (NASDAQ: NTAP), the intelligent data infrastructure company, today reported financial results for the second quarter of fiscal year 2025, which ended on October 25, 2024.

[0000950170-24-129714:8k_2_02:12]
“Our strong Q2 performance was driven by another record-breaking quarter in all-flash storage and strong performance in first party and marketplace cloud storage services,” said George Kurian, chief executive officer. “Broad-based customer preference for our intelligent data infrastructure platform and visionary approach for a data-driven future has enabled us to outgrow the market and take share from competitors. Our focus and momentum fuel my confidence in our ability to deliver outstanding results for customers and shareholders.”

[0000950170-24-129714:8k_2_02:13]
Second Quarter of Fiscal Year 2025 Financial Results

[0000950170-24-129714:8k_2_02:14]
•
Net revenues: $1.66 billion, compared to $1.56 billion in the second quarter of fiscal year 2024; a year-over-year increase of 6%.

[0000950170-24-129714:8k_2_02:15]
o
Hybrid Cloud segment revenue: $1.49 billion, compared to $1.41 billion in the second quarter of fiscal year 2024.

[0000950170-24-129714:8k_2_02:16]
o
Public Cloud segment revenue: $168 million, compared to $154 million in the second quarter of fiscal year 2024.

[0000950170-24-129714:8k_2_02:17]
•
Billings2: $1.59 billion, compared to $1.45 billion in the second quarter of fiscal year 2024; a year-over-year increase of 9%.

[0000950170-24-129714:8k_2_02:18]
•
All-flash array ARR: $3.8 billion, compared to $3.2 billion in the second quarter of fiscal year 2024; a year-over-year increase of 19%.

[0000950170-24-129714:8k_2_02:19]
•
Net income: GAAP net income of $299 million, compared to $233 million in the second quarter of fiscal year 2024; non-GAAP net income of $392 million, compared to $334 million in the second quarter of fiscal year 2024.

[0000950170-24-129714:8k_2_02:20]
•
Earnings per share: GAAP net income per share of $1.42, compared to $1.10 in the second quarter of fiscal year 2024; non-GAAP net income per share of $1.87, compared to $1.58 in the second quarter of fiscal year 2024.

[0000950170-24-129714:8k_2_02:21]
•
Cash, cash equivalents and investments: $2.22 billion at the end of the second quarter of fiscal year 2025.

[0000950170-24-129714:8k_2_02:22]
•
Cash provided by operations: $105 million, compared to $135 million in the second quarter of fiscal year 2024.

[0000950170-24-129714:8k_2_02:23]
•
Share repurchases and dividends: Returned $406 million to stockholders through share repurchases and cash dividends.

[0000950170-24-129714:8k_2_02:24]
Third Quarter of Fiscal Year 2025 Financial Outlook

[0000950170-24-129714:8k_2_02:25]
The Company provided the following financial guidance for the third quarter of fiscal year 2025:

[0000950170-24-129714:8k_2_02:26]
| Net revenues are expected to be in the range of: | $1.610 billion - $1.760 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $1.41 - $1.51 | $1.85 - $1.95 |

[0000950170-24-129714:8k_2_02:27]
Full Fiscal Year 2025 Financial Outlook

[0000950170-24-129714:8k_2_02:28]
The Company provided the following update to financial guidance for the full fiscal year 2025:

[0000950170-24-129714:8k_2_02:29]
| Net revenues are expected to be in the range of: | $6.540 billion - $6.740 billion |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 70% - 71% | 71% - 72% |
| Operating margins are expected to be in the range of: | 21% - 21.5% | 28% - 28.5% |
| Earnings per share is expected to be in the range of: | $5.48 - $5.68 | $7.20 - $7.40 |

[0000950170-24-129714:8k_2_02:30]
Dividend

[0000950170-24-129714:8k_2_02:31]
The next cash dividend of $0.52 per share is to be paid on January 22, 2025, to stockholders of record as of the close of business on January 3, 2025.

[0000950170-24-129714:8k_2_02:32]
Second Quarter of Fiscal Year 2025 Business Highlights

[0000950170-24-129714:8k_2_02:33]
Leading Product Innovation

[0000950170-24-129714:8k_2_02:34]
•
NetApp launched the new all-flash NetApp™ ASA A-Series storage systems to enable simplicity, powerful high-end capabilities, and affordability for enterprise block storage.

[0000950170-24-129714:8k_2_02:35]
•
NetApp introduced new midrange and high-end NetApp FAS hybrid flash storage arrays, which deliver affordable, yet high-performing backup storage and enable a secure cyber vault for recovery from ransomware attacks.

[0000950170-24-129714:8k_2_02:36]
•
NetApp announced its vision to accelerate AI innovation, including beginning the process of NVIDIA DGX SuperPOD Storage Certification for NetApp ONTAP™, the creation of a global metadata namespace, a vision for a disaggregated storage architecture for ONTAP, and direct integration of AI data pipelines in the cloud and on-premises.

[0000950170-24-129714:8k_2_02:37]
•
NetApp unveiled new integrations with NVIDIA AI software, combining NVIDIA NeMo Retriever and NIM microservices with intelligent data infrastructure to accelerate enterprise retrieval-augmented generation (RAG) and to power agentic AI.

[0000950170-24-129714:8k_2_02:38]
•
NetApp announced enhancements to its cyber resilience offerings, including the general availability of NetApp ONTAP Autonomous Ransomware Protection with AI and integrations of NetApp BlueXP™ ransomware protection with Splunk security information and event management (SIEM).

[0000950170-24-129714:8k_2_02:39]
•
NetApp Keystone™ storage as a service (STaaS) incorporates NetApp Cloud Insights into a single subscription model for comprehensive infrastructure intelligence. Customers get the flexibility to purchase the power of real-time analytics and monitoring for their entire environment—both Keystone and non Keystone systems—through a single Keystone subscription.

[0000950170-24-129714:8k_2_02:40]
•
NetApp announced that customers can now extend NetApp SnapMirror™ replication to integrate on-premises data with knowledge bases and to improve developer efficiency and data protection.

[0000950170-24-129714:8k_2_02:41]
•
The FlexPod™ platform, a joint solution from NetApp and Cisco, integrated NetApp AFF A-Series systems to enhance performance and efficiency in data centers. With this integration, FlexPod delivers up to 2x greater performance than before, broad workload support, and advanced security features while maintaining reliable, scalable infrastructure for mission-critical applications.

[0000950170-24-129714:8k_2_02:42]
•
NetApp announced the general availability of NetApp AIPod™ with Lenovo for NVIDIA OVX, designed for enterprises that aim to harness generative AI and RAG capabilities to boost productivity, to streamline operations, and to unlock new revenue opportunities.

[0000950170-24-129714:8k_2_02:43]
•
NetApp updated NetApp Cloud Volumes ONTAP to include NetApp ONTAP Autonomous Ransomware Protection with AI (ARP/AI) and write once read many (WORM) capabilities at no additional cost, strengthening IT teams’ ability to fight ransomware attacks.

[0000950170-24-129714:8k_2_02:44]
•
Google Cloud NetApp Volumes was made generally available in all 40 Google Cloud regions at the Flex service level, enabling customers to efficiently manage enterprise workloads with advanced data management capabilities and customer-managed encryption keys for enhanced data control.

[0000950170-24-129714:8k_2_02:45]
•
NetApp announced the general availability of petabyte-scale volumes and auto-tiering for Google Cloud NetApp Volumes.

[0000950170-24-129714:8k_2_02:46]
•
Spot by NetApp™ announced the addition of Shuffle Data Store for Spot Ocean™ for Apache Spark™, enabling AWS customers to enhance resilience and efficiency in data preparation pipelines by externally persisting shuffle data.

[0000950170-24-129714:8k_2_02:47]
Customer and Partner Momentum

[0000950170-24-129714:8k_2_02:48]
•
NetApp announced the expansion of its strategic partnership with Google Cloud, integrating unified data storage and intelligent services into the Google Distributed Cloud architecture, empowering organizations to use AI-ready infrastructure while maintaining high standards for security and strict regulatory compliance.

[0000950170-24-129714:8k_2_02:49]
•
NetApp announced the expansion of its long-standing relationship with AWS, signing a Strategic Collaboration Agreement to benefit joint customers by accelerating generative AI efforts, by simplifying transactions, and by delivering CloudOps value.

[0000950170-24-129714:8k_2_02:50]
•
NetApp announced new capabilities that support VMware Cloud Foundation deployments, enabling customers to use NetApp solutions to right-size IT environments and to run VMware workloads efficiently.

[0000950170-24-129714:8k_2_02:51]
•
NetApp was selected as the primary storage vendor for Anaplan, a business planning and decision-making platform, supporting its consolidation of public and private cloud deployments to simplify data management and to enable AI-focused solutions.

[0000950170-24-129714:8k_2_02:52]
•
Aruba, a contributor of web hosting, domain registration, and email account services, selected NetApp as its preferred data infrastructure provider.

[0000950170-24-129714:8k_2_02:53]
•
NetApp was selected as the preferred data infrastructure provider for the San Jose Sharks, an NHL team that uses NetApp technology to run data operations to support the team’s use of digital media.

[0000950170-24-129714:8k_2_02:54]
•
Domino Data Labs selected Amazon FSx for NetApp ONTAP as the underlying storage for Domino Datasets that run on the Domino Cloud platform to provide cost-effective performance, scalability, and the ability to accelerate model development.

[0000950170-24-129714:8k_2_02:55]
•
NVIDIA announced plans to partner with U.S. technology leaders to help organizations create custom AI applications by using the latest NVIDIA NIM Agent Blueprints and NVIDIA NeMo and NVIDIA NIM microservices. NetApp is among the partners to advance their data and AI platforms with NVIDIA NIM.

[0000950170-24-129714:8k_2_02:56]
•
Carahsoft Technology entered into a distributor agreement with NetApp to serve the U.S. Public Sector, making NetApp offerings available through Carahsoft’s reseller partners and its NASA Solutions for Enterprise-Wide Procurement V and National Association of State Procurement Officials ValuePoint contracts.

[0000950170-24-129714:8k_2_02:57]
•
F5 and NetApp announced an expanded collaboration to accelerate and to streamline enterprise AI capabilities by using secure multicloud networking solutions from F5 and the NetApp suite of data management solutions.

[0000950170-24-129714:8k_2_02:58]
•
NetApp has partnered with DataNeuron to simplify and to reduce the cost of developing and scaling generative AI pipelines through a no-code platform that integrates retrieval-augmented generation and fine-tuning technologies for customized, efficient AI solutions.

[0000950170-24-129714:8k_2_02:59]
Corporate News and Events

[0000950170-24-129714:8k_2_02:60]
•
Cadence Design Systems announced that NetApp was among the industry leaders to be a founding member of the Cadence Giving Foundation Fem.AI Alliance, a group that is committed to driving change towards a more representative tech and AI workforce.

[0000950170-24-129714:8k_2_02:61]
•
NetApp released its Fiscal Year 2024 Environmental, Social, and Governance (ESG) Impact Report, showcasing the company’s progress toward sustainability goals, decarbonization targets, and cutting-edge innovations in packaging and community engagement.

[0000950170-24-129714:8k_2_02:62]
Awards and Recognition

[0000950170-24-129714:8k_2_02:63]
•
NetApp AIPod won the AI Infrastructure Award as part of the CRN 2024 Tech Innovator Awards, recognizing the converged infrastructure solution for how it reduces cost and complexity.

[0000950170-24-129714:8k_2_02:64]
•
NetApp AFF C-Series was named as a finalist for the CRN 2024 Products of the Year list in the Enterprise Storage category, and NetApp hybrid cloud suite was named as a finalist in the Hybrid Cloud Infrastructure category.

[0000950170-24-129714:8k_2_02:65]
•
NetApp was recognized as a Leaderin the 2024 Gartner Magic Quadrant for Primary Storage Platforms, marking the 12th consecutive year of this acknowledgment and highlighting NetApp’s commitment to innovation and its vision for a comprehensive hybrid cloud storage infrastructure.

[0000950170-24-129714:8k_2_02:66]
•
GigaOm named NetApp as a Leader in the cloud-native globally distributed file system market.

[0000950170-24-129714:8k_2_02:67]
•
NetApp was named on the Newsweek America’s Greenest Companies 2025 list, which highlights companies committed to reducing their environmental impact in key areas such as greenhouse gas emissions, water management, and waste reduction.

[0000950170-24-129714:8k_2_02:68]
•
NetApp was listed on the Newsweek America’s Most Reliable Companies 2025 list, highlighting the company’s ease of doing business, value for the money, consistency of deliverables, and reputation for dependability.

[0000950170-24-129714:8k_2_02:69]
•
NetApp was named as a major player in the first IDC MarketScape: Asia/Pacific (Excluding Japan) Cloud Cost and Capacity Optimization 2024 Vendor Assessment.4

[0000950170-24-129714:8k_2_02:70]
Executive Leadership Announcements

[0000950170-24-129714:8k_2_02:71]
•
NetApp appointed Gus Shahin as Executive Vice President of Business Technology and Operations. Shahin will lead critical business operations that are expected to accelerate growth across the company.

[0000950170-24-129714:8k_2_02:72]
•
NetApp appointed Mike Richardson as Vice President of U.S. Solutions Engineering. Richardson will provide strategic leadership and oversight for the NetApp Solutions Engineering organization across North America Sales to align with evolving customer needs and business goals.

[0000950170-24-129714:8k_2_02:73]
Webcast and Conference Call Information

[0000950170-24-129714:8k_2_02:74]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today.

[0000950170-24-129714:8k_2_02:75]
to laws, regulations standards or policies affecting our operations, products, services, the storage industry, or AI usage; material cybersecurity and other security breaches; the impact of supply chain disruptions on our business operations, financial performance and results of operations; changes in U.S. government spending; changes in overall technology spending by our customers; revenue seasonality; changes in laws or regulations, including those relating to privacy, data protection and information security; the timing of orders and their fulfilment; and our ability to manage our gross profit margins, including managing component costs. These and other equally important factors are described in reports and documents we file from time to time with the Securities and Exchange Commission, including the factors described under the sections titled “Risk Factors” in our most recently submitted annual report on Form 10-K and quarterly report on Form 10-Q. We disclaim any obligation to update information contained in this press release whether as a result of new information, future events, or otherwise.

[0000950170-24-129714:8k_2_02:76]
###

[0000950170-24-129714:8k_2_02:77]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0000950170-24-129714:8k_2_02:78]
Footnotes

[0000950170-24-129714:8k_2_02:79]
1All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0000950170-24-129714:8k_2_02:80]
2Refer to “NetApp Usage of Non-GAAP Financial Information” section below for explanations of consolidated non-GAAP gross margins, non-GAAP operating margins, non-GAAP net income, non-GAAP net income per share, free cash flow, and billings.

[0000950170-24-129714:8k_2_02:81]
3GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0000950170-24-129714:8k_2_02:82]
4IDC MarketScape: “Asia/Pacific (Excluding Japan), Cloud Cost and Capacity Optimization 2024 Vendor Assessment,” Doc #AP51801624, Daphne Chung and Shouvik Nag, September 2024.

[0000950170-24-129714:8k_2_02:83]
NetApp Usage of Non-GAAP Financial Information

[0000950170-24-129714:8k_2_02:84]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with certain

[0000950170-24-129714:8k_2_02:85]
non-GAAP measures, including, but not limited to, historical non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share.

[0000950170-24-129714:8k_2_02:86]
In prior periods, NetApp presented the hardware and software components of our GAAP product revenues to illustrate the significance and value of the Company’s software. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures.

[0000950170-24-129714:8k_2_02:87]
Effective in fiscal year 2025, NetApp no longer presents the non-GAAP hardware and software components of our product revenues, as management no longer considers them to be key financial measures. The Company’s current strategy is expected to deliver investor value through growth in total revenues, including product revenues, while maintaining operational discipline to drive earnings leverage. While software continues to be the primary value driver of our products, NetApp is primarily focused on driving growth in total product revenues, through the sale of configured storage systems comprised of both hardware and software, with less focus on the pricing of each component.

[0000950170-24-129714:8k_2_02:88]
Additionally, the Company is considering potential opportunities to simplify pricing for certain products in the future, which may eliminate the existence of separate prices for hardware and software components and/or impact our ability to allocate between them.

[0000950170-24-129714:8k_2_02:89]
NetApp believes that the presentation of its non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. NetApp’s management uses non-GAAP measures in making operating decisions because it believes that the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0000950170-24-129714:8k_2_02:90]
NetApp believes that the presentation of non-GAAP gross margins, non-GAAP operating margin, non-GAAP effective tax rate, non-GAAP net income, and non-GAAP earnings per share data, provides investors with supplemental metrics that assist in understanding current results and future prospects, earnings and profitability that are complementary to GAAP metrics. Each of these Non-GAAP metrics is defined as the applicable GAAP metric adjusted to exclude the items defined in A through I below, as applicable, while our Non-GAAP effective tax rate and Non-GAAP net income also reflect a non-GAAP tax provision, as described in item J below, instead of our GAAP tax provision. Non-GAAP net income per share is computed as Non-GAAP net income divided by the diluted number of shares for the applicable period.

[0000950170-24-129714:8k_2_02:91]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0000950170-24-129714:8k_2_02:92]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0000950170-24-129714:8k_2_02:93]
Non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0000950170-24-129714:8k_2_02:94]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0000950170-24-129714:8k_2_02:95]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0000950170-24-129714:8k_2_02:96]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0000950170-24-129714:8k_2_02:97]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0000950170-24-129714:8k_2_02:98]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend

[0000950170-24-129714:8k_2_02:99]
to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0000950170-24-129714:8k_2_02:100]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0000950170-24-129714:8k_2_02:101]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0000950170-24-129714:8k_2_02:102]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer and/or lose control of assets to a third party. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0000950170-24-129714:8k_2_02:103]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0000950170-24-129714:8k_2_02:104]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such non-recurring costs do not reflect the results of its underlying, ongoing business and, therefore, are less useful for future planning and forecasting.

[0000950170-24-129714:8k_2_02:105]
J. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges or benefits that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges or benefits resulting from the integration of intellectual property from acquisitions. Management believes that the

[0000950170-24-129714:8k_2_02:106]
use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0000950170-24-129714:8k_2_02:107]
Non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures. A detailed reconciliation of our non-GAAP to GAAP results can be found herein.

[0000950170-24-129714:8k_2_02:108]
Constant Currency

[0000950170-24-129714:8k_2_02:109]
In periods in which the impacts of foreign currency exchange rate changes are significant, NetApp presents certain constant currency growth rates or quantifies the impact of foreign currency exchange rate changes on year-over-year fluctuations, including for net revenues, billings, and earnings. This constant currency information assumes the same foreign currency exchange rates that were in effect for the comparable prior-year period were used in translation of the current period results.

[0000950170-24-129714:8k_2_02:110]
About NetApp

[0000950170-24-129714:8k_2_02:111]
NetApp is the intelligent data infrastructure company, combining unified data storage, integrated data services, and CloudOps solutions to turn a world of disruption into opportunity for every customer. NetApp creates silo-free infrastructure, harnessing observability and AI to enable the industry’s best data management. As the only enterprise-grade storage service natively embedded in the world’s biggest clouds, our data storage delivers seamless flexibility. In addition, our data services create a data advantage through superior cyber resilience, governance, and application agility. Our CloudOps solutions provide continuous optimization of performance and efficiency through observability and AI. No matter the data type, workload, or environment, with NetApp you can transform your data infrastructure to realize your business possibilities.

[0000950170-24-129714:8k_2_02:112]
Learn more at www.netapp.com or follow us on X, LinkedIn, Facebook, and Instagram.

[0000950170-24-129714:8k_2_02:113]
NETAPP, INC.

[0000950170-24-129714:8k_2_02:114]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-24-129714:8k_2_02:115]
(In millions)

[0000950170-24-129714:8k_2_02:116]
(Unaudited)

[0000950170-24-129714:8k_2_02:117]
|  |  | October 25, 2024 |  |  | April 26, 2024 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 2,222 |  |  | $ | 3,252 |  |
| Accounts receivable |  |  | 873 |  |  |  | 1,007 |  |
| Inventories |  |  | 317 |  |  |  | 186 |  |
| Other current assets |  |  | 527 |  |  |  | 452 |  |
| Total current assets |  |  | 3,939 |  |  |  | 4,897 |  |
| Property and equipment, net |  |  | 593 |  |  |  | 604 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,855 |  |  |  | 2,883 |  |
| Other non-current assets |  |  | 1,617 |  |  |  | 1,503 |  |
| Total assets |  | $ | 9,004 |  |  | $ | 9,887 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 554 |  |  | $ | 517 |  |
| Accrued expenses |  |  | 969 |  |  |  | 1,013 |  |
| Current portion of long-term debt |  |  | 749 |  |  |  | 400 |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 2,045 |  |  |  | 2,176 |  |
| Total current liabilities |  |  | 4,317 |  |  |  | 4,106 |  |
| Long-term debt |  |  | 1,244 |  |  |  | 1,992 |  |
| Other long-term liabilities |  |  | 496 |  |  |  | 585 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 2,055 |  |  |  | 2,058 |  |
| Total liabilities |  |  | 8,112 |  |  |  | 8,741 |  |
| Stockholders' equity |  |  | 892 |  |  |  | 1,146 |  |
| Total liabilities and stockholders' equity |  | $ | 9,004 |  |  | $ | 9,887 |  |

[0000950170-24-129714:8k_2_02:118]
NETAPP, INC.

[0000950170-24-129714:8k_2_02:119]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-24-129714:8k_2_02:120]
(In millions, except per share amounts)

[0000950170-24-129714:8k_2_02:121]
(Unaudited)

[0000950170-24-129714:8k_2_02:122]
|  |  | Three Months Ended |  |  | Six Months Ended |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | October 25, 2024 |  |  | October 27, 2023 |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 768 |  |  | $ | 706 |  |  | $ | 1,437 |  |  | $ | 1,296 |  |  |
| Services |  |  | 890 |  |  |  | 856 |  |  |  | 1,762 |  |  |  | 1,698 |  |  |
| Net revenues |  |  | 1,658 |  |  |  | 1,562 |  |  |  | 3,199 |  |  |  | 2,994 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 307 |  |  |  | 276 |  |  |  | 576 |  |  |  | 541 |  |  |
| Cost of services |  |  | 174 |  |  |  | 176 |  |  |  | 348 |  |  |  | 347 |  |  |
| Total cost of revenues |  |  | 481 |  |  |  | 452 |  |  |  | 924 |  |  |  | 888 |  |  |
| Gross profit |  |  | 1,177 |  |  |  | 1,110 |  |  |  | 2,275 |  |  |  | 2,106 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 485 |  |  |  | 461 |  |  |  | 956 |  |  |  | 929 |  |  |
| Research and development |  |  | 257 |  |  |  | 262 |  |  |  | 509 |  |  |  | 509 |  |  |
| General and administrative |  |  | 77 |  |  |  | 75 |  |  |  | 152 |  |  |  | 149 |  |  |
| Restructuring charges |  |  | 12 |  |  |  | 5 |  |  |  | 29 |  |  |  | 31 |  |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 3 |  |  |  | 2 |  |  |  | 6 |  |  |
| Total operating expenses |  |  | 832 |  |  |  | 806 |  |  |  | 1,648 |  |  |  | 1,624 |  |  |
| Income from operations |  |  | 345 |  |  |  | 304 |  |  |  | 627 |  |  |  | 482 |  |  |
| Other income, net |  |  | 15 |  |  |  | 11 |  |  |  | 32 |  |  |  | 19 |  |  |
| Income before income taxes |  |  | 360 |  |  |  | 315 |  |  |  | 659 |  |  |  | 501 |  |  |
| Provision for income taxes |  |  | 61 |  |  |  | 82 |  |  |  | 112 |  |  |  | 119 |  |  |
| Net income |  | $ | 299 |  |  | $ | 233 |  |  | $ | 547 |  |  | $ | 382 |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.47 |  |  | $ | 1.12 |  |  | $ | 2.67 |  |  | $ | 1.82 |  |  |
| Diluted |  | $ | 1.42 |  |  | $ | 1.10 |  |  | $ | 2.59 |  |  | $ | 1.79 |  |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 204 |  |  |  | 208 |  |  |  | 205 |  |  |  | 210 |  |  |
| Diluted |  |  | 210 |  |  |  | 211 |  |  |  | 211 |  |  |  | 214 |  |  |

[0000950170-24-129714:8k_2_02:123]
NETAPP, INC.

[0000950170-24-129714:8k_2_02:124]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-24-129714:8k_2_02:125]
(In millions)

[0000950170-24-129714:8k_2_02:126]
(Unaudited)

[0000950170-24-129714:8k_2_02:127]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | October 25, 2024 |  |  | October 27, 2023 |  |  | October 25, 2024 |  |  | October 27, 2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 299 |  |  | $ | 233 |  |  | $ | 547 |  |  | $ | 382 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 63 |  |  |  | 64 |  |  |  | 126 |  |  |  | 128 |  |
| Non-cash operating lease cost |  |  | 11 |  |  |  | 12 |  |  |  | 21 |  |  |  | 23 |  |
| Stock-based compensation |  |  | 103 |  |  |  | 93 |  |  |  | 188 |  |  |  | 180 |  |
| Deferred income taxes |  |  | (52 | ) |  |  | (7 | ) |  |  | (69 | ) |  |  | (13 | ) |
| Other items, net |  |  | 54 |  |  |  | (25 | ) |  |  | 35 |  |  |  | (27 | ) |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (197 | ) |  |  | (147 | ) |  |  | 138 |  |  |  | 185 |  |
| Inventories |  |  | (103 | ) |  |  | 9 |  |  |  | (132 | ) |  |  | 46 |  |
| Accounts payable |  |  | 113 |  |  |  | 70 |  |  |  | 36 |  |  |  | 14 |  |
| Accrued expenses |  |  | 137 |  |  |  | 137 |  |  |  | (84 | ) |  |  | 48 |  |
| Deferred revenue and financed unearned services revenue |  |  | (72 | ) |  |  | (108 | ) |  |  | (164 | ) |  |  | (241 | ) |
| Long-term taxes payable |  |  | (95 | ) |  |  | (111 | ) |  |  | (91 | ) |  |  | (110 | ) |
| Changes in other operating assets and liabilities, net |  |  | (156 | ) |  |  | (85 | ) |  |  | (105 | ) |  |  | (27 | ) |
| Net cash provided by operating activities |  |  | 105 |  |  |  | 135 |  |  |  | 446 |  |  |  | 588 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 607 |  |  |  | 264 |  |  |  | 597 |  |  |  | 72 |  |
| Purchases of property and equipment |  |  | (45 | ) |  |  | (38 | ) |  |  | (86 | ) |  |  | (73 | ) |
| Other investing activities, net |  |  | 2 |  |  |  | 1 |  |  |  | 2 |  |  |  | — |  |
| Net cash provided by (used in) investing activities |  |  | 564 |  |  |  | 227 |  |  |  | 513 |  |  |  | (1 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | — |  |  |  | — |  |  |  | 55 |  |  |  | 52 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (35 | ) |  |  | (20 | ) |  |  | (132 | ) |  |  | (85 | ) |
| Repurchase of common stock |  |  | (300 | ) |  |  | (300 | ) |  |  | (700 | ) |  |  | (700 | ) |
| Repayments and extinguishment of debt |  |  | (400 | ) |  |  | — |  |  |  | (400 | ) |  |  | — |  |
| Dividends paid |  |  | (106 | ) |  |  | (103 | ) |  |  | (213 | ) |  |  | (209 | ) |
| Other financing activities, net |  |  | (1 | ) |  |  | 2 |  |  |  | — |  |  |  | — |  |
| Net cash used in financing activities |  |  | (842 | ) |  |  | (421 | ) |  |  | (1,390 | ) |  |  | (942 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | 1 |  |  |  | (26 | ) |  |  | 9 |  |  |  | (26 | ) |
| Net change in cash, cash equivalents and restricted cash |  |  | (172 | ) |  |  | (85 | ) |  |  | (422 | ) |  |  | (381 | ) |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 1,659 |  |  |  | 2,026 |  |  |  | 1,909 |  |  |  | 2,322 |  |
| End of period |  | $ | 1,487 |  |  | $ | 1,941 |  |  | $ | 1,487 |  |  | $ | 1,941 |  |

[0000950170-24-129714:8k_2_02:128]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |
| (Unaudited) |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| Product |  | $ | 768 |  |  | $ | 669 |  |  | $ | 706 |  |
| Support |  |  | 635 |  |  |  | 631 |  |  |  | 623 |  |
| Professional and Other Services |  |  | 87 |  |  |  | 82 |  |  |  | 79 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,490 |  |  |  | 1,382 |  |  |  | 1,408 |  |
| Public Cloud Segment Net Revenues |  |  | 168 |  |  |  | 159 |  |  |  | 154 |  |
| Net Revenues |  | $ | 1,658 |  |  | $ | 1,541 |  |  | $ | 1,562 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| Product |  | $ | 463 |  |  | $ | 401 |  |  | $ | 431 |  |
| Support |  |  | 584 |  |  |  | 581 |  |  |  | 573 |  |
| Professional and Other Services |  |  | 23 |  |  |  | 18 |  |  |  | 19 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 1,070 |  |  |  | 1,000 |  |  |  | 1,023 |  |
| Public Cloud Segment Gross Profit |  |  | 124 |  |  |  | 113 |  |  |  | 102 |  |
| Total Segments Gross Profit |  |  | 1,194 |  |  |  | 1,113 |  |  |  | 1,125 |  |
| Amortization of Intangible Assets |  |  | (9 | ) |  |  | (8 | ) |  |  | (8 | ) |
| Stock-based Compensation |  |  | (8 | ) |  |  | (7 | ) |  |  | (7 | ) |
| Unallocated Cost of Revenues |  |  | (17 | ) |  |  | (15 | ) |  |  | (15 | ) |
| Gross Profit |  | $ | 1,177 |  |  | $ | 1,098 |  |  | $ | 1,110 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| Product |  |  | 60.3 | % |  |  | 59.9 | % |  |  | 61.0 | % |
| Support |  |  | 92.0 | % |  |  | 92.1 | % |  |  | 92.0 | % |
| Professional and Other Services |  |  | 26.4 | % |  |  | 22.0 | % |  |  | 24.1 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 71.8 | % |  |  | 72.4 | % |  |  | 72.7 | % |
| Public Cloud Segment Gross Margin |  |  | 73.8 | % |  |  | 71.1 | % |  |  | 66.2 | % |
| Geographic Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'25 |  |  | % of Q1 FY'25 |  |  | % of Q2 FY'24 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 52 | % |  |  | 50 | % |  |  | 50 | % |
| Americas Commercial |  |  | 38 | % |  |  | 39 | % |  |  | 37 | % |
| U.S. Public Sector |  |  | 14 | % |  |  | 11 | % |  |  | 13 | % |
| EMEA |  |  | 33 | % |  |  | 33 | % |  |  | 34 | % |
| Asia Pacific |  |  | 15 | % |  |  | 17 | % |  |  | 16 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |
|  |  | % of Q2 FY'25 |  |  | % of Q1 FY'25 |  |  | % of Q2 FY'24 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 23 | % |  |  | 22 | % |  |  | 23 | % |
| Indirect |  |  | 77 | % |  |  | 78 | % |  |  | 77 | % |

[0000950170-24-129714:8k_2_02:129]
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| Non-GAAP Income from Operations |  | $ | 475 |  |  | $ | 399 |  |  | $ | 419 |  |
| % of Net Revenues |  |  | 28.6 | % |  |  | 25.9 | % |  |  | 26.8 | % |
| Non-GAAP Income before Income Taxes |  | $ | 493 |  |  | $ | 416 |  |  | $ | 425 |  |
| Non-GAAP Effective Tax Rate |  |  | 20.5 | % |  |  | 20.7 | % |  |  | 21.4 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| Non-GAAP Net Income |  | $ | 392 |  |  | $ | 330 |  |  | $ | 334 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 210 |  |  |  | 212 |  |  |  | 211 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.87 |  |  | $ | 1.56 |  |  | $ | 1.58 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 4,100 |  |  | $ | 4,169 |  |  | $ | 4,002 |  |
| DSO (days) |  |  | 48 |  |  |  | 40 |  |  |  | 46 |  |
| DPO (days) |  |  | 105 |  |  |  | 90 |  |  |  | 83 |  |
| Inventory Turns |  |  | 6 |  |  |  | 8 |  |  |  | 15 |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| Net Cash Provided by Operating Activities |  | $ | 105 |  |  | $ | 341 |  |  | $ | 135 |  |
| Purchases of Property and Equipment |  | $ | 45 |  |  | $ | 41 |  |  | $ | 38 |  |
| Free Cash Flow |  | $ | 60 |  |  | $ | 300 |  |  | $ | 97 |  |
| Free Cash Flow as % of Net Revenues |  |  | 3.6 | % |  |  | 19.5 | % |  |  | 6.2 | % |
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |
| Some items may not add or recalculate due to rounding. |  |

[0000950170-24-129714:8k_2_02:130]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| NET INCOME |  | $ | 299 |  |  | $ | 248 |  |  | $ | 233 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 103 |  |  |  | 85 |  |  |  | 93 |  |
| Restructuring charges |  |  | 12 |  |  |  | 17 |  |  |  | 5 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |
| Gains/losses on the sale or derecognition of assets |  |  | 3 |  |  |  | — |  |  |  | — |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | (5 | ) |
| Income tax effects |  |  | (40 | ) |  |  | (35 | ) |  |  | (9 | ) |
| NON-GAAP NET INCOME |  | $ | 392 |  |  | $ | 330 |  |  | $ | 334 |  |
| COST OF REVENUES |  | $ | 481 |  |  | $ | 443 |  |  | $ | 452 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (8 | ) |  |  | (8 | ) |
| Stock-based compensation |  |  | (8 | ) |  |  | (7 | ) |  |  | (7 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 464 |  |  | $ | 428 |  |  | $ | 437 |  |
| COST OF PRODUCT REVENUES |  | $ | 307 |  |  | $ | 269 |  |  | $ | 276 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (1 | ) |  |  | (1 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 305 |  |  | $ | 268 |  |  | $ | 275 |  |
| COST OF SERVICES REVENUES |  | $ | 174 |  |  | $ | 174 |  |  | $ | 176 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (8 | ) |  |  | (8 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (6 | ) |  |  | (6 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 159 |  |  | $ | 160 |  |  | $ | 162 |  |
| GROSS PROFIT |  | $ | 1,177 |  |  | $ | 1,098 |  |  | $ | 1,110 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 9 |  |  |  | 8 |  |  |  | 8 |  |
| Stock-based compensation |  |  | 8 |  |  |  | 7 |  |  |  | 7 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,194 |  |  | $ | 1,113 |  |  | $ | 1,125 |  |

[0000950170-24-129714:8k_2_02:131]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| SALES AND MARKETING EXPENSES |  | $ | 485 |  |  | $ | 471 |  |  | $ | 461 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (6 | ) |  |  | (6 | ) |
| Stock-based compensation |  |  | (43 | ) |  |  | (35 | ) |  |  | (37 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 437 |  |  | $ | 430 |  |  | $ | 418 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 257 |  |  | $ | 252 |  |  | $ | 262 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (37 | ) |  |  | (31 | ) |  |  | (35 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 220 |  |  | $ | 221 |  |  | $ | 227 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 77 |  |  | $ | 75 |  |  | $ | 75 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (15 | ) |  |  | (12 | ) |  |  | (14 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 62 |  |  | $ | 63 |  |  | $ | 61 |  |
| RESTRUCTURING CHARGES |  | $ | 12 |  |  | $ | 17 |  |  | $ | 5 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (12 | ) |  |  | (17 | ) |  |  | (5 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 1 |  |  | $ | 1 |  |  | $ | 3 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (1 | ) |  |  | (1 | ) |  |  | (3 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 832 |  |  | $ | 816 |  |  | $ | 806 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (5 | ) |  |  | (6 | ) |  |  | (6 | ) |
| Stock-based compensation |  |  | (95 | ) |  |  | (78 | ) |  |  | (86 | ) |
| Restructuring charges |  |  | (12 | ) |  |  | (17 | ) |  |  | (5 | ) |
| Acquisition-related expense |  |  | (1 | ) |  |  | (1 | ) |  |  | (3 | ) |
| NON-GAAP OPERATING EXPENSES |  | $ | 719 |  |  | $ | 714 |  |  | $ | 706 |  |

[0000950170-24-129714:8k_2_02:132]
| NETAPP, INC. |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| INCOME FROM OPERATIONS |  | $ | 345 |  |  | $ | 282 |  |  | $ | 304 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 103 |  |  |  | 85 |  |  |  | 93 |  |
| Restructuring charges |  |  | 12 |  |  |  | 17 |  |  |  | 5 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 475 |  |  | $ | 399 |  |  | $ | 419 |  |
| OTHER INCOME, NET |  | $ | 15 |  |  | $ | 17 |  |  | $ | 11 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Gains/losses on the sale or derecognition of assets |  |  | 3 |  |  |  | — |  |  |  | — |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | (5 | ) |
| NON-GAAP OTHER INCOME, NET |  | $ | 18 |  |  | $ | 17 |  |  | $ | 6 |  |
| INCOME BEFORE INCOME TAXES |  | $ | 360 |  |  | $ | 299 |  |  | $ | 315 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 103 |  |  |  | 85 |  |  |  | 93 |  |
| Restructuring charges |  |  | 12 |  |  |  | 17 |  |  |  | 5 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | (5 | ) |
| Gains/losses on the sale or derecognition of assets |  |  | 3 |  |  |  | — |  |  |  | — |  |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 493 |  |  | $ | 416 |  |  | $ | 425 |  |
| PROVISION FOR INCOME TAXES |  | $ | 61 |  |  | $ | 51 |  |  | $ | 82 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 40 |  |  |  | 35 |  |  |  | 9 |  |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 101 |  |  | $ | 86 |  |  | $ | 91 |  |
| NET INCOME PER SHARE |  | $ | 1.42 |  |  | $ | 1.17 |  |  | $ | 1.10 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.07 |  |  |  | 0.07 |  |  |  | 0.07 |  |
| Stock-based compensation |  |  | 0.49 |  |  |  | 0.40 |  |  |  | 0.44 |  |
| Restructuring charges |  |  | 0.06 |  |  |  | 0.08 |  |  |  | 0.02 |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | 0.01 |  |
| Gains/losses on the sale or derecognition of assets |  |  | 0.01 |  |  |  | — |  |  |  | — |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | (0.02 | ) |
| Income tax effects |  |  | (0.19 | ) |  |  | (0.17 | ) |  |  | (0.04 | ) |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.87 |  |  | $ | 1.56 |  |  | $ | 1.58 |  |

[0000950170-24-129714:8k_2_02:133]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| Gross margin-GAAP |  |  | 71.0 | % |  |  | 71.3 | % |  |  | 71.1 | % |
| Cost of revenues adjustments |  |  | 1.0 | % |  |  | 0.9 | % |  |  | 1.0 | % |
| Gross margin-Non-GAAP |  |  | 72.0 | % |  |  | 72.2 | % |  |  | 72.0 | % |
| GAAP cost of revenues |  | $ | 481 |  |  | $ | 443 |  |  | $ | 452 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (8 | ) |  |  | (8 | ) |
| Stock-based compensation |  |  | (8 | ) |  |  | (7 | ) |  |  | (7 | ) |
| Non-GAAP cost of revenues |  | $ | 464 |  |  | $ | 428 |  |  | $ | 437 |  |
| Net revenues |  | $ | 1,658 |  |  | $ | 1,541 |  |  | $ | 1,562 |  |

[0000950170-24-129714:8k_2_02:134]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| Product gross margin-GAAP |  |  | 60.0 | % |  |  | 59.8 | % |  |  | 60.9 | % |
| Cost of product revenues adjustments |  |  | 0.3 | % |  |  | 0.1 | % |  |  | 0.1 | % |
| Product gross margin-Non-GAAP |  |  | 60.3 | % |  |  | 59.9 | % |  |  | 61.0 | % |
| GAAP cost of product revenues |  | $ | 307 |  |  | $ | 269 |  |  | $ | 276 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (2 | ) |  |  | (1 | ) |  |  | (1 | ) |
| Non-GAAP cost of product revenues |  | $ | 305 |  |  | $ | 268 |  |  | $ | 275 |  |
| Product revenues |  | $ | 768 |  |  | $ | 669 |  |  | $ | 706 |  |

[0000950170-24-129714:8k_2_02:135]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| Services gross margin-GAAP |  |  | 80.4 | % |  |  | 80.0 | % |  |  | 79.4 | % |
| Cost of services revenues adjustments |  |  | 1.7 | % |  |  | 1.7 | % |  |  | 1.6 | % |
| Services gross margin-Non-GAAP |  |  | 82.1 | % |  |  | 81.7 | % |  |  | 81.1 | % |
| GAAP cost of services revenues |  | $ | 174 |  |  | $ | 174 |  |  | $ | 176 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (9 | ) |  |  | (8 | ) |  |  | (8 | ) |
| Stock-based compensation |  |  | (6 | ) |  |  | (6 | ) |  |  | (6 | ) |
| Non-GAAP cost of services revenues |  | $ | 159 |  |  | $ | 160 |  |  | $ | 162 |  |
| Services revenues |  | $ | 890 |  |  | $ | 872 |  |  | $ | 856 |  |

[0000950170-24-129714:8k_2_02:136]
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| OPERATING MARGIN |  |
| ($ in millions) |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| Operating margin-GAAP |  |  | 20.8 | % |  |  | 18.3 | % |  |  | 19.5 | % |
| Adjustments: |  |  | 7.8 | % |  |  | 7.6 | % |  |  | 7.4 | % |
| Operating margin-Non-GAAP |  |  | 28.6 | % |  |  | 25.9 | % |  |  | 26.8 | % |
| GAAP income from operations |  | $ | 345 |  |  | $ | 282 |  |  | $ | 304 |  |
| Income from operations adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 14 |  |  |  | 14 |  |
| Stock-based compensation |  |  | 103 |  |  |  | 85 |  |  |  | 93 |  |
| Restructuring charges |  |  | 12 |  |  |  | 17 |  |  |  | 5 |  |
| Acquisition-related expense |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |
| Non-GAAP income from operations |  | $ | 475 |  |  | $ | 399 |  |  | $ | 419 |  |
| Net revenues |  | $ | 1,658 |  |  | $ | 1,541 |  |  | $ | 1,562 |  |
| RECONCILIATION OF GAAP TO NON-GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| GAAP effective tax rate |  |  | 16.9 | % |  |  | 17.1 | % |  |  | 26.0 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 3.6 | % |  |  | 3.6 | % |  |  | (4.6 | )% |
| Non-GAAP effective tax rate |  |  | 20.5 | % |  |  | 20.7 | % |  |  | 21.4 | % |

[0000950170-24-129714:8k_2_02:137]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| Net cash provided by operating activities |  | $ | 105 |  |  | $ | 341 |  |  | $ | 135 |  |
| Purchases of property and equipment |  |  | (45 | ) |  |  | (41 | ) |  |  | (38 | ) |
| Free cash flow |  | $ | 60 |  |  | $ | 300 |  |  | $ | 97 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q2'FY25 |  |  | Q1'FY25 |  |  | Q2'FY24 |  |
| Net revenues |  | $ | 1,658 |  |  | $ | 1,541 |  |  | $ | 1,562 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | (72 | ) |  |  | (92 | ) |  |  | (108 | ) |
| Billings |  | $ | 1,586 |  |  | $ | 1,449 |  |  | $ | 1,454 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0000950170-24-129714:8k_2_02:138]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| THIRD QUARTER FISCAL 2025 |
|  |  | Third Quarter |
|  |  | Fiscal 2025 |
| GAAP Guidance - Net Income Per Share |  | $1.41 - $1.51 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the Third Quarter Fiscal 2025: |  |  |
| Amortization of intangible assets |  | $0.07 |
| Stock-based compensation expense |  | $0.48 |
| Income tax effects |  | ($0.11) |
| Total Adjustments |  | $0.44 |
| Non-GAAP Guidance - Net Income Per Share |  | $1.85 - $1.95 |

[0000950170-24-129714:8k_2_02:139]
Some items may not add or recalculate due to rounding.

[0000950170-24-129714:8k_2_02:140]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| Fiscal 2025 |
|  |  | Fiscal 2025 |
| Gross Margin - GAAP Guidance |  | 70% - 71% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | 1% |
| Gross Margin - Non-GAAP Guidance |  | 71% - 72% |
| Operating Margin - GAAP Guidance |  | 21% - 21.5% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | 1% |
| Stock-based compensation expense |  | 6% |
| Operating Margin - Non-GAAP Guidance |  | 28% - 28.5% |

[0000950170-24-129714:8k_2_02:141]
Some items may not add or recalculate due to rounding.

[0000950170-24-129714:8k_2_02:142]
| NETAPP, INC. |
| RECONCILIATION OF GAAP GUIDANCE TO NON-GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| Fiscal 2025 |
|  |  | Fiscal 2025 |
| GAAP Guidance - Net Income Per Share |  | $5.48 - $5.68 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2025: |  |  |
| Amortization of intangible assets |  | $0.26 |
| Stock-based compensation expense |  | $1.87 |
| Restructuring charges |  | $0.14 |
| Acquisition-related expenses |  | $0.01 |
| Gains/losses on the sale or derecognition of assets |  | $0.01 |
| Income tax effects |  | ($0.57) |
| Total Adjustments |  | $1.72 |
| Non-GAAP Guidance - Net Income Per Share |  | $7.20 - $7.40 |

[0000950170-24-129714:8k_2_02:143]
Some items may not add or recalculate due to rounding.

[0000950170-24-129714:8k_2_02:144]
Contacts:

[0000950170-24-129714:8k_2_02:145]
(Press)

[0000950170-24-129714:8k_2_02:146]
Kenya Hayes

[0000950170-24-129714:8k_2_02:147]
1 703 589 7595

[0000950170-24-129714:8k_2_02:148]
kenya.hayes@netapp.com

[0000950170-24-129714:8k_2_02:149]
(Investors)

[0000950170-24-129714:8k_2_02:150]
Kris Newton

[0000950170-24-129714:8k_2_02:151]
1 408 822 3312

[0000950170-24-129714:8k_2_02:152]
kris.newton@netapp.com
