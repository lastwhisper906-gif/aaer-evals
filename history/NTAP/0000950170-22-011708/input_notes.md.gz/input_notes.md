# NTAP notes — 0000950170-22-011708


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000950170-22-011708:notes:1]
The information called for by Part III of this Form 10-K is hereby incorporated by reference from the definitive Proxy Statement for our annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after April 29, 2022.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000950170-22-011708:notes:2]
1. Description of Business and Significant Accounting Policies

[0000950170-22-011708:notes:3]
Description of Business — NetApp, Inc. (we, us, or the Company) is a global cloud-led, data-centric software company that provides organizations the ability to manage and share their data across on-premises, private and public clouds. We provide a full range of enterprise-class software, systems and services solutions that customers use to modernize their infrastructures, build next generation data centers and harness the power of hybrid clouds.

[0000950170-22-011708:notes:4]
Fiscal Year — Our fiscal year is reported on a 52- or 53-week year ending on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2022, which ended on April 29, 2022, and fiscal year 2020, which ended on April 24, 2020 were both 52-week years. Fiscal year 2021, ending on April 30, 2021 was a 53-week year, with 14 weeks included in its first quarter and 13 weeks in each subsequent quarter. Unless otherwise stated, references to particular years, quarters, months and periods refer to the Company’s fiscal years ended on the last Friday of April and the associated quarters, months and periods of those fiscal years.

[0000950170-22-011708:notes:5]
Principles of Consolidation — The consolidated financial statements include the Company and its subsidiaries. Intercompany accounts and transactions are eliminated in consolidation.

[0000950170-22-011708:notes:6]
Use of Estimates — The preparation of the consolidated financial statements in conformity with accounting principles generally accepted in the United States of America (GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Such estimates include, but are not limited to, revenue recognition, reserves and allowances; inventory valuation; valuation of goodwill and intangibles; restructuring reserves; employee benefit accruals; stock-based compensation; loss contingencies; investment impairments; income taxes and fair value measurements. Actual results could differ materially from those estimates, including impacts from the COVID-19 pandemic, the anticipated effects of which have been incorporated, as applicable, into management’s estimates as of and for the year ended April 29, 2022.

[0000950170-22-011708:notes:7]
Cash Equivalents — We consider all highly liquid debt investments with original maturities of three months or less at the time of purchase to be cash equivalents.

[0000950170-22-011708:notes:8]
Available-for-Sale Investments — We classify our investments in debt securities as available-for-sale investments. Debt securities primarily consist of corporate bonds, U.S. Treasury and government debt securities and certificates of deposit. These investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of debt securities sold. These investments are recorded in the consolidated balance sheets at fair value.

[0000950170-22-011708:notes:9]
Unrealized gains and temporary losses, net of related taxes, are included in accumulated other comprehensive income (loss) (AOCI). Upon realization, those amounts are reclassified from AOCI to earnings. The amortization of premiums and discounts on the investments are included in our results of operations. Realized gains and losses are calculated based on the specific identification method.

[0000950170-22-011708:notes:10]
We classify our investments as current or noncurrent based on the nature of the investments and their availability for use in current operations.

[0000950170-22-011708:notes:11]
Other-than-Temporary Impairments on Investments — All of our available-for-sale investments are subject to periodic impairment review. When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and we assess whether the impairment is other-than-temporary. An impairment is considered other-than-temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of the entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost basis of the security. If impairment is considered other-than-temporary based on condition (i) or (ii) described above, the entire difference between the amortized cost and the fair value of the debt security is recognized in the results of operations. If an impairment is considered other-than-temporary based on condition (iii) described above, the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in earnings, and the amount relating to all other factors is recognized in other comprehensive income (OCI).

[0000950170-22-011708:notes:12]
Inventories — Inventories are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. We write down excess and obsolete inventory based on the difference between the cost of inventory and the estimated net realizable value. Net realizable value is estimated using management’s best estimate of forecasts for future demand and expectations regarding market conditions. At the point of a loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts or circumstances do not result in the restoration or increase in that newly established basis. In addition, we record a liability for firm, non-cancelable and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with our valuation of excess and obsolete inventory.

[0000950170-22-011708:notes:13]
Property and Equipment — Property and equipment are recorded at cost.

[0000950170-22-011708:notes:14]
Depreciation and amortization is computed using the straight-line method, generally over the following periods:

[0000950170-22-011708:notes:15]
|  |  | Depreciation Life |
| Buildings and improvements |  | 10 to 40 years |
| Furniture and fixtures |  | 5 years |
| Computer, production, engineering and other equipment |  | 2 to 3 years |
| Computer software |  | 3 to 5 years |
| Leasehold improvements |  | Shorter of remaining lease term or useful life |

[0000950170-22-011708:notes:16]
Construction in progress will be depreciated over the estimated useful lives of the respective assets when they are ready for use. We capitalize interest on significant facility assets under construction and on significant software development projects. Interest capitalized during the periods presented was not material.

[0000950170-22-011708:notes:17]
Software Development Costs — The costs for the development of new software products and substantial enhancements to existing software products are expensed as incurred until technological feasibility has been established, at which time any additional costs would be capitalized in accordance with the accounting guidance for software. Because our current process for developing software is essentially completed concurrently with the establishment of technological feasibility, which occurs upon the completion of a working model, no costs have been capitalized for any of the periods presented.

[0000950170-22-011708:notes:18]
Internal-Use Software Development Costs — We capitalize qualifying costs, which are incurred during the application development stage, for computer software developed or obtained for internal-use and amortize them over the software’s estimated useful life.

[0000950170-22-011708:notes:19]
Business Combinations — We recognize identifiable assets acquired and liabilities assumed at their acquisition date fair values, with the exception of contract assets and liabilities, which beginning in fiscal 2022, we recognize in accordance with our revenue recognition policy as if we had originally executed the customer contract. Goodwill as of the acquisition date is measured as the excess of consideration transferred over the net of the acquisition date values of the assets acquired and liabilities assumed. While we use our best estimates and assumptions as a part of the purchase price allocation process to accurately value assets acquired and liabilities assumed at the acquisition date, our estimates are inherently uncertain and subject to refinement. As a result, during the measurement period, which may be up to one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed, with the corresponding offset to goodwill to the extent that we identify adjustments to the preliminary purchase price allocation. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of income.

[0000950170-22-011708:notes:20]
Goodwill and Purchased Intangible Assets — Goodwill is recorded when the consideration paid for an acquisition exceeds the value of net tangible and intangible assets acquired. Purchased intangible assets with finite lives are generally amortized on a straight-line basis over their economic lives of three to five years for developed technology, two to five years for customer contracts/relationships, two to three years for covenants not to compete and two to five years for trademarks and trade names as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. In-process research and development is accounted for as an indefinite lived intangible asset and is assessed for potential impairment annually until development is complete or when events or circumstances indicate that their carrying amounts might be impaired. Upon completion of development, in-process research and development is accounted for as a finite-lived intangible asset.

[0000950170-22-011708:notes:21]
The carrying value of goodwill is tested for impairment on an annual basis in the fourth quarter of our fiscal year, or more frequently if we believe indicators of impairment exist. Triggering events for impairment reviews may be indicators such as adverse industry or economic trends, restructuring actions, lower projections of profitability, or a sustained decline in our market capitalization. For the purpose of impairment testing, we have two reporting units, which are the same as our two reportable segments. We initially conduct a qualitative assessment to determine whether it is necessary to perform a quantitative goodwill impairment test. The performance of the quantitative impairment test requires comparing the fair value of each reporting unit to its carrying amount, including goodwill. The fair value of each reporting unit is based on a combination of the income approach and the market approach.

[0000950170-22-011708:notes:22]
Under the income approach, we estimate the fair value of a reporting unit based on the present value of estimated future cash flows. Cash flow projections are based on discrete forecast periods as well as terminal value determinations, and are derived based on forecasted revenue growth rates and operating margins. These cash flow projections are discounted to arrive at the fair value of each reporting unit. The discount rate used is based on the weighted-average cost of capital of comparable public companies adjusted for the relevant risk associated with business specific characteristics and the uncertainty related to the reporting unit's ability to execute on the projected cash flows. Under the market approach, we estimate the fair value based on market multiples of revenue and earnings derived from comparable publicly traded companies with operating and investment characteristics similar to the reporting unit. In addition, we make certain judgments and assumptions in allocating shared assets and liabilities to individual reporting units to determine the carrying amount of each reporting unit. An impairment exists if the fair value of a reporting unit is lower than its carrying amount. The impairment loss is measured based on the amount by which the carrying amount of the reporting unit exceeds its fair value, with the recognized loss not to exceed the total amount of allocated goodwill. The fair value of each reporting unit has substantially exceeded its carrying amount in all periods presented.

[0000950170-22-011708:notes:23]
Impairment of Long-Lived Assets — We review the carrying values of long-lived assets whenever events and circumstances, such as reductions in demand, lower projections of profitability, significant changes in the manner of our use of acquired assets, or significant negative industry or economic trends, indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. If this review indicates that there is an impairment, the impaired asset is written down to its fair value, which is typically calculated using: (i) quoted market prices and/or (ii) expected future cash flows utilizing a discount rate. Our estimates regarding future anticipated cash flows, the remaining economic life of the products and technologies, or both, may differ materially from actual cash flows and remaining economic life. In that event, impairment charges or shortened useful lives of certain long-lived assets may be required, resulting in charges to our consolidated statements of income when such determinations are made.

[0000950170-22-011708:notes:24]
Derivative Instruments — Our derivative instruments, which are carried at fair value in our consolidated balance sheets, consist of foreign currency exchange contracts as described below:

[0000950170-22-011708:notes:25]
Balance Sheet Hedges — We utilize foreign currency exchange forward and option contracts to hedge against the short-term impact of foreign currency exchange rate fluctuations related to certain foreign currency denominated monetary assets and liabilities, primarily intercompany receivables and payables. These derivative instruments are not designated as hedging instruments and do not subject us to material balance sheet risk due to exchange rate movements because the gains and losses on these contracts are intended to offset the gains and losses in the underlying foreign currency denominated monetary assets and liabilities being hedged, and the net amount is included in earnings.

[0000950170-22-011708:notes:26]
Cash Flow Hedges — We utilize foreign currency exchange forward contracts to hedge foreign currency exchange exposures related to forecasted sales transactions denominated in certain foreign currencies. These derivative instruments are designated and qualify as cash flow hedges and, in general, closely match the underlying forecasted transactions in duration. The effective portion of the contracts’ gains and losses resulting from changes in fair value is recorded in AOCI until the forecasted transaction is recognized in the consolidated statements of income. When the forecasted transactions occur, we reclassify the related gains or losses on the cash flow hedges into net revenues. If the underlying forecasted transactions do not occur, or it becomes probable that they will not occur within the defined hedge period, the gains or losses on the related cash flow hedges are reclassified from AOCI and recognized immediately in earnings. We measure the effectiveness of hedges of forecasted transactions on a monthly basis by comparing the fair values of the designated foreign currency exchange forward purchase contracts with the fair values of the forecasted transactions.

[0000950170-22-011708:notes:27]
Factors that could have an impact on the effectiveness of our hedging programs include the accuracy of forecasts and the volatility of foreign currency markets. These programs reduce, but do not entirely eliminate, the impact of currency exchange movements. Currently, we do not enter into any foreign currency exchange forward contracts to hedge exposures related to firm commitments. Cash flows from our derivative programs are included under operating activities in the consolidated statements of cash flows.

[0000950170-22-011708:notes:28]
Revenue Recognition — We recognize revenue by applying the following five step approach.

[0000950170-22-011708:notes:29]
•
Identification of the contract, or contracts, with a customer — A contract with a customer is within the scope of ASC 606 when it meets all the following criteria:

[0000950170-22-011708:notes:30]
-
It is enforceable

[0000950170-22-011708:notes:31]
-
It defines each party’s rights

[0000950170-22-011708:notes:32]
-
It identifies the payment terms

[0000950170-22-011708:notes:33]
-
It has commercial substance, and

[0000950170-22-011708:notes:34]
-
We determine that collection of substantially all consideration for goods or services that will be transferred is probable based on the customer’s intent and ability to pay

[0000950170-22-011708:notes:35]
•
Identification of the performance obligations in the contract — Performance obligations promised in a contract are identified based on the goods or services (or a bundle of goods and services) that will be transferred to the customer that are distinct.

[0000950170-22-011708:notes:36]
•
Determination of the transaction price — The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer.

[0000950170-22-011708:notes:37]
•
Allocation of the transaction price to the performance obligations in the contract — Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation.

[0000950170-22-011708:notes:38]
•
Recognition of revenue when, or as, we satisfy a performance obligation — We satisfy performance obligations either over time or at a point in time.

[0000950170-22-011708:notes:39]
Customarily we have a purchase order from or executed contract with our customers that establishes the goods and services to be transferred and the consideration to be received.

[0000950170-22-011708:notes:40]
We combine two or more contracts entered into at or near the same time with the same customer as a single contract if the contracts are negotiated as one package with a single commercial objective, if the amount of consideration to be paid on one contract depends on the price or performance of the other contract or if the goods and services promised in each of the contracts are a single performance obligation.

[0000950170-22-011708:notes:41]
Our contracts with customers may include hardware systems, software licenses, software support, hardware support, public cloud services and other services. Software support contracts entitle our customers to receive unspecified upgrades and enhancements on a when-and-if-available basis, and patch releases. Hardware support services include contracts for extended warranty and technical support with minimum response times. Other services include professional services and customer education and training services.

[0000950170-22-011708:notes:42]
We identify performance obligations in our contracts to be those goods and services that are distinct. A good or service is distinct where the customer can benefit from the good or service either on its own or together with other resources that are readily available from third parties or from us, and is distinct in the context of the contract, where the transfer of the good or service is separately identifiable from other promises in the contract.

[0000950170-22-011708:notes:43]
If a contract includes multiple promised goods or services, we apply judgment to determine whether promised goods or services are distinct. If they are not, we combine the goods and services until we have a distinct performance obligation. A configured storage system inclusive of the operating system (OS) software essential to its functionality is considered a single performance obligation, while optional add-on software is a separate performance obligation. In general, hardware support, software support, and different types of professional services are each separate performance obligations.

[0000950170-22-011708:notes:44]
In certain instances, we enter into enterprise license agreements (ELAs) with our customers which transfer to them the right to deploy an unlimited or capped number of OS or optional add-on software licenses and obligate us to provide software support through the ELA term. In general, we treat the software license component and software support component of ELAs as separate performance obligations.

[0000950170-22-011708:notes:45]
We determine the transaction price of our contracts with customers based on the consideration to which we will be entitled in exchange for transferring goods or services. Consideration promised may include fixed amounts, variable amounts or both. We sell public cloud services either on a subscription basis or a consumption basis. We sell professional services either on a time and materials basis or under fixed price projects.

[0000950170-22-011708:notes:46]
We evaluate variable consideration in arrangements with contract terms such as rights of return, potential penalties and acceptance clauses. We generally use the expected value method, primarily relying on our history, to estimate variable consideration. However, when we believe it to provide a better estimate, we use the most likely amount method. In either case, we consider variable consideration only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recognized will not occur. Reassessments of our variable consideration may occur as historical information changes. Transaction prices are also adjusted for the effects of time value of money if the timing of payments provides either the customer or us a significant benefit of financing.

[0000950170-22-011708:notes:47]
Contracts that contain multiple performance obligations require an allocation of the transaction price to each performance obligation on a relative standalone selling price basis. We determine standalone selling price based on the price at which the performance obligation is sold separately. If the standalone selling price is not observable through past transactions, we estimate the standalone selling price by maximizing the use of observable inputs including pricing strategy, market data, internally-approved pricing guidelines related to the performance obligations and other observable inputs. We regularly review standalone selling prices and maintain internal controls over the establishment and updates of these estimates. Variable consideration is also allocated to the

[0000950170-22-011708:notes:48]
performance obligations. If the terms of variable consideration relate to one performance obligation, it is entirely allocated to that obligation. Otherwise, it is allocated to all the performance obligations in the contract.

[0000950170-22-011708:notes:49]
We typically recognize revenue at a point in time upon the transfer of goods to a customer. Products we transfer at a point in time include our configured hardware systems, OS software licenses, optional add-on software licenses and add-on hardware. Services are typically transferred over time and revenue is recognized based on an appropriate method for measuring our progress toward completion of the performance obligation. Our stand-ready services, including both hardware and software support, are transferred ratably over the period of the contract. Our public cloud services are transferred either 1) for subscription arrangements, ratably over the subscription period or 2) for consumption-based arrangements, as actually consumed by the customer. For other services such as our fixed professional services contracts, we use an input method to determine the percentage of completion. That is, we estimate the effort to date versus the expected effort required over the life of the contract.

[0000950170-22-011708:notes:50]
Deferred Commissions — We capitalize sales commissions that are incremental direct costs of obtaining customer contracts for which revenue is not immediately recognized and classify them as current or non-current based on the terms of the related contracts. Capitalized commissions are amortized based on the transfer of goods or services to which they relate, typically over one to three years, and are also periodically reviewed for impairment. Amortization expense is recorded to sales and marketing expense in our consolidated statements of income.

[0000950170-22-011708:notes:51]
Leases — We determine if an arrangement is or contains a lease at inception, and we classify leases as operating or finance leases at commencement. In our consolidated balance sheets, operating lease right-of-use (ROU) assets are included in other non-current assets, while finance lease ROU assets are included in property and equipment, net. Lease liabilities for both types of leases are included in accrued expenses and other long-term liabilities. ROU assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over that term.

[0000950170-22-011708:notes:52]
Operating and finance lease ROU assets and liabilities are recognized at commencement based on the present value of lease payments over the lease term. ROU assets also include any lease payments made prior to lease commencement and exclude lease incentives. The lease term is the noncancelable period of the lease and includes options to extend or terminate the lease when it is reasonably certain that an option will be exercised. As the rate implicit in our leases is typically not readily determinable, in computing the present value of lease payments we generally use our incremental borrowing rate based on information available at the commencement date. Variable lease payments not dependent on an index or rate are expensed as incurred and not included within the calculation of ROU assets and lease liabilities. Lease expense for operating lease payments is recognized on a straight-line basis over the lease term.

[0000950170-22-011708:notes:53]
We do not separate non-lease components from lease components for any class of leases, and we do not recognize ROU assets and lease liabilities for leases with a lease term of twelve months or less.

[0000950170-22-011708:notes:54]
Foreign Currency Translation — For international subsidiaries whose functional currency is the local currency, gains and losses resulting from translation of these foreign currency financial statements into U.S. dollars are recorded in AOCI. For international subsidiaries where the functional currency is the U.S. dollar, gains and losses resulting from the process of remeasuring foreign currency financial statements into U.S. dollars are included in other (expense) income, net.

[0000950170-22-011708:notes:55]
Benefit Plans — We record actuarial gains and losses associated with defined benefit plans within AOCI and amortize net gains or losses in excess of 10 percent of the greater of the market value of plan assets or the plans' projected benefit obligation on a straight-line basis over the remaining estimated service life of plan participants. The measurement date for all defined benefit plans is our fiscal year end.

[0000950170-22-011708:notes:56]
Stock-Based Compensation — We measure and recognize stock-based compensation for all stock-based awards, including employee stock options, restricted stock units (RSUs), including time-based RSUs and performance-based RSUs (PBRSUs), and rights to purchase shares under our employee stock purchase plan (ESPP), based on their estimated fair value, and recognize the costs in our financial statements using the single option straight-line approach over the requisite service period for the entire award.

[0000950170-22-011708:notes:57]
The fair value of employee time-based RSUs, and PBRSUs that include a performance condition, is equal to the market value of our common stock on the grant date of the award, less the present value of expected dividends during the vesting period, discounted at a risk-free interest rate. The fair value of PBRSUs that include a market condition is measured using a Monte Carlo simulation model on the date of grant.

[0000950170-22-011708:notes:58]
The fair value of time-based RSUs, and PBRSUs that include a market condition, is not remeasured as a result of subsequent stock price fluctuations. When there is a change in management’s estimate of expected achievement relative to the performance target for PBRSUs that include a performance condition, such as our achievement against a cumulative Adjusted Operating Income target, the change in estimate results in the recognition of a cumulative adjustment of stock-based compensation expense.

[0000950170-22-011708:notes:59]
Our expected term assumption is based primarily on historical exercise and post-vesting forfeiture experience. Our stock price volatility assumption is based on a combination of our historical and implied volatility. The risk-free interest rates are based upon United States (U.S.) Treasury bills with equivalent expected terms, and the expected dividends are based on our history and expected dividend payouts.

[0000950170-22-011708:notes:60]
We account for forfeitures of stock-based awards as they occur.

[0000950170-22-011708:notes:61]
Income Taxes — Deferred income tax assets and liabilities are provided for temporary differences that will result in tax deductions or income in future periods, as well as the future benefit of tax credit carryforwards. A valuation allowance reduces tax assets to their estimated realizable value.

[0000950170-22-011708:notes:62]
We recognize the tax liability for uncertain income tax positions on the income tax return based on the two-step process prescribed in the interpretation. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. We recognize interest and penalties related to unrecognized tax benefits within the provision for income taxes line on the accompanying consolidated statements of income.

[0000950170-22-011708:notes:63]
Net Income per Share — Basic net income per share is computed by dividing net income by the weighted-average number of common shares outstanding. Diluted net income per share is computed giving effect to the weighted-average number of dilutive potential shares that were outstanding during the period using the treasury stock method. Potential dilutive common shares consist primarily of outstanding stock options, shares to be purchased under our employee stock purchase plan and unvested RSUs.

[0000950170-22-011708:notes:64]
Treasury Stock — We account for treasury stock under the cost method. Upon the retirement of treasury stock, we allocate the value of treasury shares between common stock, additional paid-in capital and retained earnings.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000950170-22-011708:notes:65]
2. Recent Accounting Pronouncements

[0000950170-22-011708:notes:66]
In October 2021, the FASB amended certain Topic 805, Business Combinations, guidance to require customer contract assets and liabilities to be recognized consistent with ASC 606 as if the acquiring company had originally executed the acquired company's customer contracts. We early-adopted this guidance in fiscal 2022. The adoption of this update did not have a material impact on our consolidated financial statements.

[0000950170-22-011708:notes:67]
Although there are several other new accounting pronouncements issued or proposed by the FASB that we have adopted or will adopt, as applicable, we do not believe any of these accounting pronouncements had or will have a material impact on our consolidated financial position, operating results, cash flows or disclosures.


## us-gaap:ConcentrationRiskDisclosureTextBlock

[0000950170-22-011708:notes:68]
3. Concentration of Risk

[0000950170-22-011708:notes:69]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash equivalents, investments, foreign currency exchange contracts and accounts receivable. Cash equivalents and short-term investments consist primarily of corporate bonds, U.S. Treasury and government debt securities and certificates of deposit, all of which are considered high investment grade. Our policy is to limit the amount of credit exposure through diversification and investment in highly rated securities. We further mitigate concentrations of credit risk in our investments by limiting our investments in the debt securities of a single issuer and by diversifying risk across geographies and type of issuer. The COVID-19 pandemic has led to an increase in market volatility and liquidity challenges for certain companies. However, it has not currently resulted in a material increase in the credit risk associated with our financial instruments.

[0000950170-22-011708:notes:70]
By entering into foreign currency exchange contracts, we have assumed the risk that might arise from the possible inability of counterparties to meet the terms of their contracts. The counterparties to these contracts are major multinational commercial banks, and we do not expect any losses as a result of counterparty defaults.

[0000950170-22-011708:notes:71]
We sell our products primarily to large organizations in different industries and geographies. We do not require collateral or other security to support accounts receivable. In addition, we maintain an allowance for potential credit losses. To reduce credit risk, we perform ongoing credit evaluations on our customers’ financial condition. We establish an allowance for doubtful accounts based upon factors surrounding the credit risk of customers, historical trends and other information, including the expected impact of macroeconomic disruptions such as the COVID-19 pandemic, and, to date, such losses have been within management’s expectations. Concentrations of credit risk with respect to trade accounts receivable are limited due to the wide variety of customers who are dispersed across many geographic regions.

[0000950170-22-011708:notes:72]
There are no concentrations of business transacted with a particular market that would severely impact our business in the near term. However, we rely on a limited number of suppliers for certain key components and a few key contract manufacturers to

[0000950170-22-011708:notes:73]
manufacture most of our products; any disruption, including as a result of the COVID-19 pandemic, or termination of these arrangements could materially adversely affect our operating results.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-22-011708:notes:74]
4. Business Combinations

[0000950170-22-011708:notes:75]
Fiscal 2022 Acquisitions

[0000950170-22-011708:notes:76]
Fylamynt Acquisition

[0000950170-22-011708:notes:77]
On February 18, 2022, we acquired all the outstanding shares of privately-held NeurOps Inc. (which operated under the name "Fylamynt") for approximately $27 million in cash, of which $22 million was paid at closing. The purchase price includes $5 million related to an indemnity holdback provision, of which $4 million is expected to be paid within 12 months from the acquisition date. Fylamynt is an innovative CloudOps automation technology company that enables customers to build, run, manage and analyze workflows securely in any cloud with little to no code.

[0000950170-22-011708:notes:78]
The preliminary acquisition-date values of the assets acquired are as follows (in millions):

[0000950170-22-011708:notes:79]
|  |  | Amount |  |
| Cash |  | $ | 1 |  |
| Developed technology |  |  | 6 |  |
| Goodwill |  |  | 20 |  |
| Total assets acquired |  |  | 27 |  |
| Total purchase price |  | $ | 27 |  |

[0000950170-22-011708:notes:80]
CloudCheckr Acquisition

[0000950170-22-011708:notes:81]
On November 5, 2021, we acquired all the outstanding shares of privately-held CloudCheckr Inc., (CloudCheckr) for approximately $347 million in cash. CloudCheckr is a leading cloud optimization platform that provides cloud visibility and insights to lower costs, maintain security and compliance, and optimize cloud resources.

[0000950170-22-011708:notes:82]
The acquisition-date values of the assets acquired and liabilities assumed are as follows (in millions):

[0000950170-22-011708:notes:83]
|  |  | Amount |  |
| Cash |  | $ | 2 |  |
| Intangible assets |  |  | 76 |  |
| Goodwill |  |  | 276 |  |
| Other assets |  |  | 6 |  |
| Total assets acquired |  |  | 360 |  |
| Liabilities assumed |  |  | (13 | ) |
| Total purchase price |  | $ | 347 |  |

[0000950170-22-011708:notes:84]
The components of the intangible assets acquired were as follows (in millions, except useful life):

[0000950170-22-011708:notes:85]
|  |  | Amount |  |  | Estimated useful life(years) |  |
| Developed technology |  | $ | 45 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 30 |  |  |  | 5 |  |
| Trade name |  |  | 1 |  |  |  | 3 |  |
| Total intangible assets |  | $ | 76 |  |  |  |  |

[0000950170-22-011708:notes:86]
Data Mechanics Acquisition

[0000950170-22-011708:notes:87]
On June 18, 2021, we acquired all the outstanding shares of privately-held Data Mechanics Inc., a provider of managed platforms for big data processing and cloud analytics headquartered in Paris, France, for approximately $15 million in cash.

[0000950170-22-011708:notes:88]
|  |  | Amount |  |
| Cash |  | $ | 1 |  |
| Developed technology |  |  | 5 |  |
| Goodwill |  |  | 11 |  |
| Total assets acquired |  |  | 17 |  |
| Liabilities assumed |  |  | (2 | ) |
| Total purchase price |  | $ | 15 |  |

[0000950170-22-011708:notes:89]
The acquired assets and assumed liabilities of Fylamynt, CloudCheckr and Data Mechanics were recorded at their estimated values. We determined the estimated values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expect to realize incremental revenue by offering continuous cost optimization and managed services from our existing capabilities to help customers improve their cloud resources and realize the benefits of cloud faster and at scale. We also anticipate opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated fair value of their identifiable net assets acquired, and as a result, we have recorded goodwill in connection with these acquisitions. The goodwill is not deductible for income tax purposes.

[0000950170-22-011708:notes:90]
The results of operations related to the acquisitions of Fylamynt, CloudCheckr and Data Mechanics have been included in our consolidated statements of income from their respective acquisition dates. Pro forma results of operations have not been presented because the impact from these acquisitions was not material to our consolidated results of operations.

[0000950170-22-011708:notes:91]
Fiscal 2021 Acquisitions

[0000950170-22-011708:notes:92]
Spot, Inc. Acquisition

[0000950170-22-011708:notes:93]
On July 9, 2020, we acquired all the outstanding shares of privately-held Spot, Inc. (Spot), a provider of compute management cost optimization services on the public clouds based in Israel, for $340 million in cash.

[0000950170-22-011708:notes:94]
The acquisition date fair values of the assets acquired and liabilities assumed are as follows (in millions):

[0000950170-22-011708:notes:95]
|  |  | Amount |  |
| Cash |  | $ | 24 |  |
| Intangible assets |  |  | 84 |  |
| Goodwill |  |  | 249 |  |
| Other assets |  |  | 6 |  |
| Total assets acquired |  |  | 363 |  |
| Liabilities assumed |  |  | (23 | ) |
| Total purchase price |  | $ | 340 |  |

[0000950170-22-011708:notes:96]
The components of the Spot intangible assets acquired were as follows (in millions, except useful life):

[0000950170-22-011708:notes:97]
|  |  | Amount |  |  | Estimated useful life(years) |  |
| Developed technology |  | $ | 53 |  |  |  | 5 |  |
| Customer contracts/relationships |  |  | 28 |  |  |  | 5 |  |
| Trade name |  |  | 3 |  |  |  | 3 |  |
| Total intangible assets |  | $ | 84 |  |  |  |  |

[0000950170-22-011708:notes:98]
Cloud Jumper Corporation Acquisition

[0000950170-22-011708:notes:99]
On April 28, 2020, we acquired all the outstanding shares of privately-held Cloud Jumper Corporation (Cloud Jumper), a provider of virtual desktop infrastructure and remote desktop services solutions based in North Carolina, for $34 million in cash.

[0000950170-22-011708:notes:100]
|  |  | Amount |  |
| Developed technology |  | $ | 16 |  |
| Customer contracts/relationships |  |  | 6 |  |
| Goodwill |  |  | 12 |  |
| Other assets |  |  | 1 |  |
| Total assets acquired |  |  | 35 |  |
| Liabilities assumed |  |  | (1 | ) |
| Total purchase price |  | $ | 34 |  |

[0000950170-22-011708:notes:101]
The acquired assets and assumed liabilities of Spot and Cloud Jumper were recorded at their estimated fair values. We determined the estimated fair values with the assistance of valuations and appraisals performed by third party specialists and estimates made by management. We expect to realize revenue synergies, leverage and expand the existing Spot and Cloud Jumper sales channels and product development resources, and utilize their existing workforces. We also anticipate opportunities for growth through the ability to leverage additional future products and capabilities. These factors, among others, contributed to a purchase price in excess of the estimated fair value of their identifiable net assets acquired, and as a result, we have recorded goodwill in connection with both of these acquisitions. The goodwill is not deductible for income tax purposes.

[0000950170-22-011708:notes:102]
The results of operations related to the acquisition of both Spot and Cloud Jumper have been included in our consolidated statements of income from their respective acquisition dates. Pro forma results of operations have not been presented because the impact from these acquisitions would not have been material to our consolidated results of operations.

[0000950170-22-011708:notes:103]
Fiscal 2020 Acquisitions

[0000950170-22-011708:notes:104]
Talon Storage Solutions, Inc. Acquisition

[0000950170-22-011708:notes:105]
On March 6, 2020, we acquired all the outstanding shares of privately-held Talon Storage Solutions, Inc., a provider of next generation software-defined storage solutions, for $23 million in cash.

[0000950170-22-011708:notes:106]
|  |  | Amount |  |
| Cash |  | $ | 2 |  |
| Developed technology intangible asset |  |  | 6 |  |
| Customer contracts/relationships |  |  | 4 |  |
| Other assets |  |  | 4 |  |
| Goodwill |  |  | 13 |  |
| Total assets acquired |  |  | 29 |  |
| Liabilities assumed |  |  | (6 | ) |
| Total purchase price |  | $ | 23 |  |

[0000950170-22-011708:notes:107]
Cognigo Research Ltd. Acquisition

[0000950170-22-011708:notes:108]
On May 23, 2019, we acquired all the outstanding shares of privately-held Cognigo Research Ltd., a provider of data discovery classification software designed to manage and protect critical data, for $53 million in cash.

[0000950170-22-011708:notes:109]
|  |  | Amount |  |
| Cash |  | $ | 2 |  |
| Developed technology intangible asset |  |  | 26 |  |
| Goodwill |  |  | 30 |  |
| Total assets acquired |  |  | 58 |  |
| Liabilities assumed |  |  | (5 | ) |
| Total purchase price |  | $ | 53 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-22-011708:notes:110]
5. Goodwill and Purchased Intangible Assets, Net

[0000950170-22-011708:notes:111]
Goodwill activity is summarized as follows (in millions):

[0000950170-22-011708:notes:112]
|  |  | Amount |  |
| Balance as of April 24, 2020 |  | $ | 1,778 |  |
| Additions |  |  | 261 |  |
| Balance as of April 30, 2021 |  |  | 2,039 |  |
| Additions |  |  | 307 |  |
| Balance as of April 29, 2022 |  | $ | 2,346 |  |

[0000950170-22-011708:notes:113]
Beginning with the first quarter of fiscal 2022, the Company has two reportable segments: Hybrid Cloud and Public Cloud. As a result, goodwill was allocated to the segments using a relative fair value approach. Goodwill additions of $307 million related to the acquisitions of Fylamynt, CloudCheckr and Data Mechanics have been allocated to our Public Cloud segment.

[0000950170-22-011708:notes:114]
Goodwill by reportable segment as of April 29, 2022 is as follows (in millions):

[0000950170-22-011708:notes:115]
|  |  | Amount |  |
| Hybrid Cloud |  | $ | 1,714 |  |
| Public Cloud |  |  | 632 |  |
| Total goodwill |  | $ | 2,346 |  |

[0000950170-22-011708:notes:116]
As a result of the realignment, the Company performed an interim quantitative goodwill impairment test for its reporting units as of July 30, 2021, which did not result in any goodwill impairment charges.

[0000950170-22-011708:notes:117]
Purchased intangible assets, net are summarized below (in millions):

[0000950170-22-011708:notes:118]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
|  |  | Gross |  |  | Accumulated |  |  | Net |  |  | Gross |  |  | Accumulated |  |  | Net |  |
|  |  | Assets |  |  | Amortization |  |  | Assets |  |  | Assets |  |  | Amortization |  |  | Assets |  |
| Developed technology |  | $ | 157 |  |  | $ | (65 | ) |  | $ | 92 |  |  | $ | 215 |  |  | $ | (147 | ) |  | $ | 68 |  |
| Customer contracts/relationships |  |  | 68 |  |  |  | (20 | ) |  |  | 48 |  |  |  | 38 |  |  |  | (8 | ) |  |  | 30 |  |
| Other purchased intangibles |  |  | 4 |  |  |  | (2 | ) |  |  | 2 |  |  |  | 3 |  |  |  | — |  |  |  | 3 |  |
| Total purchased intangible assets |  | $ | 229 |  |  | $ | (87 | ) |  | $ | 142 |  |  | $ | 256 |  |  | $ | (155 | ) |  | $ | 101 |  |

[0000950170-22-011708:notes:119]
During fiscal 2022, we retired approximately $114 million of fully amortized developed technology intangible assets.

[0000950170-22-011708:notes:120]
Amortization expense for purchased intangible assets is summarized below (in millions):

[0000950170-22-011708:notes:121]
|  |  | Year Ended |  |  | Statements of |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | IncomeClassifications |
| Developed technology |  | $ | 33 |  |  | $ | 41 |  |  | $ | 39 |  |  | Cost of revenues |
| Customer contracts/relationships |  |  | 11 |  |  |  | 8 |  |  |  | — |  |  | Operating expenses |
| Other purchased intangibles |  |  | 2 |  |  |  | — |  |  |  | — |  |  | Operating expenses |
| Total |  | $ | 46 |  |  | $ | 49 |  |  | $ | 39 |  |  |  |

[0000950170-22-011708:notes:122]
As of April 29, 2022, future amortization expense related to purchased intangible assets is as follows (in millions):

[0000950170-22-011708:notes:123]
| Fiscal Year |  | Amount |  |
| 2023 |  | $ | 47 |  |
| 2024 |  |  | 36 |  |
| 2025 |  |  | 33 |  |
| 2026 |  |  | 18 |  |
| 2027 |  |  | 8 |  |
| Total |  | $ | 142 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-22-011708:notes:124]
6. Supplemental Financial Information

[0000950170-22-011708:notes:125]
Cash and cash equivalents (in millions):

[0000950170-22-011708:notes:126]
The following table presents cash and cash equivalents as reported in our consolidated balance sheets, as well as the sum of cash, cash equivalents and restricted cash as reported on our consolidated statements of cash flows:

[0000950170-22-011708:notes:127]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Cash and cash equivalents |  | $ | 4,112 |  |  | $ | 4,529 |  |
| Restricted cash |  |  | 7 |  |  |  | 6 |  |
| Cash, cash equivalents and restricted cash |  | $ | 4,119 |  |  | $ | 4,535 |  |

[0000950170-22-011708:notes:128]
Inventories (in millions):

[0000950170-22-011708:notes:129]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Purchased components |  | $ | 131 |  |  | $ | 22 |  |
| Finished goods |  |  | 73 |  |  |  | 92 |  |
| Inventories |  | $ | 204 |  |  | $ | 114 |  |

[0000950170-22-011708:notes:130]
Property and equipment, net (in millions):

[0000950170-22-011708:notes:131]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Land |  | $ | 46 |  |  | $ | 46 |  |
| Buildings and improvements |  |  | 353 |  |  |  | 356 |  |
| Leasehold improvements |  |  | 92 |  |  |  | 83 |  |
| Computer, production, engineering and other equipment |  |  | 904 |  |  |  | 869 |  |
| Computer software |  |  | 316 |  |  |  | 305 |  |
| Furniture and fixtures |  |  | 76 |  |  |  | 93 |  |
| Construction-in-progress |  |  | 65 |  |  |  | 46 |  |
|  |  |  | 1,852 |  |  |  | 1,798 |  |
| Accumulated depreciation and amortization |  |  | (1,250 | ) |  |  | (1,273 | ) |
| Property and equipment, net |  | $ | 602 |  |  | $ | 525 |  |

[0000950170-22-011708:notes:132]
In April 2021, we sold our corporate headquarters located in Sunnyvale, California, consisting primarily of land, buildings and improvements, for cash proceeds of $365 million. The assets sold had a net book value totaling $210 million. To facilitate an orderly transition to a new location, we executed short-term lease agreements with the buyer to lease back these properties. The agreed lease payments were below market rates and as a result we recognized an asset of $7 million for the difference between the fair value of the leases and the agreed lease payments. The cash proceeds, less direct selling costs, plus the fair value of the below-market leases, resulted in a net gain on the sale of these properties of $156 million.

[0000950170-22-011708:notes:133]
Depreciation and amortization expense related to property and equipment, net is summarized below (in millions):

[0000950170-22-011708:notes:134]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24,2020 |  |
| Depreciation and amortization expense |  | $ | 148 |  |  | $ | 158 |  |  | $ | 154 |  |

[0000950170-22-011708:notes:135]
Other non-current assets (in millions):

[0000950170-22-011708:notes:136]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Deferred tax assets |  | $ | 362 |  |  | $ | 219 |  |
| Operating lease ROU assets |  |  | 294 |  |  |  | 114 |  |
| Other assets |  |  | 335 |  |  |  | 361 |  |
| Other non-current assets |  | $ | 991 |  |  | $ | 694 |  |

[0000950170-22-011708:notes:137]
Other non-current assets as of April 29, 2022 and April 30, 2021 include $73 million and $71 million, respectively, for our 49% non-controlling equity interest in Lenovo NetApp Technology Limited (LNTL), a China-based entity that we formed with Lenovo (Beijing) Information Technology Ltd. in fiscal 2019. LNTL is integral to our sales channel strategy in China, acting as a distributor of our offerings to customers headquartered there, and involved in certain OEM sales to Lenovo. LNTL is also focused on localizing our products and services, and developing new joint offerings for the China market by leveraging NetApp and Lenovo technologies. Our sales to LNTL are conducted on terms equivalent to those prevailing in an arm’s length transaction.

[0000950170-22-011708:notes:138]
Accrued expenses (in millions):

[0000950170-22-011708:notes:139]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Accrued compensation and benefits |  | $ | 462 |  |  | $ | 505 |  |
| Product warranty liabilities |  |  | 17 |  |  |  | 21 |  |
| Operating lease liabilities |  |  | 47 |  |  |  | 49 |  |
| Other current liabilities |  |  | 399 |  |  |  | 395 |  |
| Accrued expenses |  | $ | 925 |  |  | $ | 970 |  |

[0000950170-22-011708:notes:140]
Product warranty liabilities:

[0000950170-22-011708:notes:141]
Equipment and software systems sales include a standard product warranty. Estimated future hardware and software warranty costs are recorded as a cost of product revenues at the time of product shipment, based on historical and projected warranty claim rates, historical and projected cost-per-claim and knowledge of specific product failures that are outside our typical experience.

[0000950170-22-011708:notes:142]
The following tables summarize the activity related to product warranty liabilities and their balances as reported in our consolidated balance sheets (in millions):

[0000950170-22-011708:notes:143]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Balance at beginning of period |  | $ | 32 |  |  | $ | 41 |  |  | $ | 40 |  |
| Expense accrued during the period |  |  | 13 |  |  |  | 13 |  |  |  | 26 |  |
| Warranty costs incurred |  |  | (19 | ) |  |  | (22 | ) |  |  | (25 | ) |
| Balance at end of period |  | $ | 26 |  |  | $ | 32 |  |  | $ | 41 |  |

[0000950170-22-011708:notes:144]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Accrued expenses |  | $ | 17 |  |  | $ | 21 |  |
| Other long-term liabilities |  |  | 9 |  |  |  | 11 |  |
| Total warranty liabilities |  | $ | 26 |  |  | $ | 32 |  |

[0000950170-22-011708:notes:145]
Warranty expense recognized during the period includes amounts accrued for systems at the time of shipment, adjustments for changes in estimated costs for warranties on systems shipped in the period and changes in estimated costs for warranties on systems shipped in prior periods.

[0000950170-22-011708:notes:146]
Other long-term liabilities (in millions):

[0000950170-22-011708:notes:147]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Liability for uncertain tax positions |  | $ | 131 |  |  | $ | 127 |  |
| Income taxes payable |  |  | 303 |  |  |  | 351 |  |
| Product warranty liabilities |  |  | 9 |  |  |  | 11 |  |
| Operating lease liabilities |  |  | 257 |  |  |  | 71 |  |
| Other liabilities |  |  | 88 |  |  |  | 90 |  |
| Other long-term liabilities |  | $ | 788 |  |  | $ | 650 |  |

[0000950170-22-011708:notes:148]
Deferred revenue and financed unearned services revenue

[0000950170-22-011708:notes:149]
The following table summarizes the components of our deferred revenue and financed unearned services balance as reported in our  consolidated balance sheets (in millions):

[0000950170-22-011708:notes:150]
|  | April 29, 2022 |  |  | April 30, 2021 |  |
| Deferred product revenue | $ | 31 |  |  | $ | 59 |  |
| Deferred services revenue |  | 4,140 |  |  |  | 3,873 |  |
| Financed unearned services revenue |  | 61 |  |  |  | 71 |  |
| Total | $ | 4,232 |  |  | $ | 4,003 |  |
| Reported as: |  |  |  |  |  |
| Short-term | $ | 2,171 |  |  | $ | 2,062 |  |
| Long-term |  | 2,061 |  |  |  | 1,941 |  |
| Total | $ | 4,232 |  |  | $ | 4,003 |  |

[0000950170-22-011708:notes:151]
Deferred product revenue represents unrecognized revenue related to undelivered product commitments and other product deliveries that have not met all revenue recognition criteria. Deferred services revenue represents customer payments made in advance for services, which include software and hardware support contracts, certain public cloud services and other services. Financed unearned services revenue represents undelivered services for which cash has been received under certain third-party financing arrangements. See Note 17 – Commitments and Contingencies for additional information related to these arrangements.

[0000950170-22-011708:notes:152]
During the years ended April 29, 2022 and April 30, 2021, we recognized revenue of $2,062 million and $1,894 million, respectively, that was included in the deferred revenue and financed unearned services revenue balance at the beginning of the respective periods.

[0000950170-22-011708:notes:153]
As of April 29, 2022, the aggregate amount of the transaction price allocated to the remaining performance obligations related to customer contracts that are unsatisfied or partially unsatisfied approximated our deferred revenue and unearned services revenue balance. Because customer orders are typically placed on an as-needed basis, and cancellable without penalty prior to shipment, orders in backlog may not be a meaningful indicator of future revenue and have not been included in this amount. We expect to recognize as revenue approximately 51% of our deferred revenue and financed unearned services revenue balance in the next 12 months, approximately 23% in the next 13 to 24 months, and the remainder thereafter.

[0000950170-22-011708:notes:154]
Deferred commissions

[0000950170-22-011708:notes:155]
The following table summarizes deferred commissions balances as reported in our consolidated balance sheets (in millions):

[0000950170-22-011708:notes:156]
|  | April 29, 2022 |  |  | April 30, 2021 |  |
| Other current assets | $ | 80 |  |  | $ | 86 |  |
| Other non-current assets |  | 117 |  |  |  | 111 |  |
| Total deferred commissions | $ | 197 |  |  | $ | 197 |  |

[0000950170-22-011708:notes:157]
During the years ended April 29, 2022 and April 30, 2021, we recognized amortization expense from deferred commissions of $146 million and $101 million, respectively, and there were no impairment charges recognized.

[0000950170-22-011708:notes:158]
Other expense, net (in millions):

[0000950170-22-011708:notes:159]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Interest income |  | $ | 7 |  |  | $ | 9 |  |  | $ | 48 |  |
| Interest expense |  |  | (73 | ) |  |  | (74 | ) |  |  | (55 | ) |
| Other, net |  |  | 4 |  |  |  | (4 | ) |  |  | 6 |  |
| Other expense, net |  | $ | (62 | ) |  | $ | (69 | ) |  | $ | (1 | ) |

[0000950170-22-011708:notes:160]
Statements of cash flows additional information (in millions):

[0000950170-22-011708:notes:161]
Supplemental cash flow information related to our operating leases is included in Note 9 – Leases. Non-cash investing and other supplemental cash flow information are presented below:

[0000950170-22-011708:notes:162]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Non-cash Investing and Financing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures incurred but not paid |  | $ | 22 |  |  | $ | 15 |  |  | $ | 15 |  |
| Indemnity holdback related to business combination |  | $ | 5 |  |  | $ | — |  |  | $ | — |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |  |
| Income taxes paid, net of refunds |  | $ | 398 |  |  | $ | 338 |  |  | $ | 276 |  |
| Interest paid |  | $ | 67 |  |  | $ | 57 |  |  | $ | 50 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000950170-22-011708:notes:163]
7. Financial Instruments and Fair Value Measurements

[0000950170-22-011708:notes:164]
The accounting guidance for fair value measurements provides a framework for measuring fair value on either a recurring or nonrecurring basis, whereby the inputs used in valuation techniques are assigned a hierarchical level. The following are the three levels of inputs to measure fair value:

[0000950170-22-011708:notes:165]
Level 1: Observable inputs that reflect quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0000950170-22-011708:notes:166]
Level 2: Inputs that reflect quoted prices for identical assets or liabilities in less active markets; quoted prices for similar assets or liabilities in active markets; benchmark yields, reported trades, broker/dealer quotes, inputs other than quoted prices that are observable for the assets or liabilities; or inputs that are derived principally from or corroborated by observable market data by correlation or other means.

[0000950170-22-011708:notes:167]
Level 3: Unobservable inputs that reflect our own assumptions incorporated in valuation techniques used to measure fair value. These assumptions are required to be consistent with market participant assumptions that are reasonably available.

[0000950170-22-011708:notes:168]
We consider an active market to be one in which transactions for the asset or liability occur with sufficient frequency and volume to provide pricing information on an ongoing basis, and consider an inactive market to be one in which there are infrequent or few transactions for the asset or liability, the prices are not current, or price quotations vary substantially either over time or among market makers. Where appropriate, our own or the counterparty’s non-performance risk is considered in measuring the fair values of liabilities and assets, respectively.

[0000950170-22-011708:notes:169]
Investments

[0000950170-22-011708:notes:170]
The following is a summary of our investments at their cost or amortized cost for the years ended April 29, 2022 and April 30, 2021 (in millions):

[0000950170-22-011708:notes:171]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Corporate bonds |  | $ | 9 |  |  | $ | 58 |  |
| U.S. Treasury and government debt securities |  |  | 13 |  |  |  | 8 |  |
| Certificates of deposit |  |  | 71 |  |  |  | 61 |  |
| Mutual funds |  |  | 36 |  |  |  | 40 |  |
| Total debt and equity securities |  | $ | 129 |  |  | $ | 167 |  |

[0000950170-22-011708:notes:172]
The fair value of our investments approximates their cost or amortized cost for both periods presented. Investments in mutual funds relate to the non-qualified deferred compensation plan offered to certain employees.

[0000950170-22-011708:notes:173]
As of April 29, 2022, all our debt investments are due to mature in one year or less.

[0000950170-22-011708:notes:174]
Fair Value of Financial Instruments

[0000950170-22-011708:notes:175]
The following table summarizes our financial assets and liabilities measured at fair value on a recurring basis (in millions):

[0000950170-22-011708:notes:176]
|  |  | April 29, 2022 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 4,041 |  |  | $ | 4,041 |  |  | $ | — |  |
| Corporate bonds |  |  | 9 |  |  |  | — |  |  |  | 9 |  |
| U.S. Treasury and government debt securities |  |  | 13 |  |  |  | 13 |  |  |  | — |  |
| Certificates of deposit |  |  | 71 |  |  |  | — |  |  |  | 71 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,134 |  |  | $ | 4,054 |  |  | $ | 80 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 30 |  |  | $ | 30 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (29 | ) |  | $ | — |  |  | $ | (29 | ) |

[0000950170-22-011708:notes:177]
|  |  | April 30, 2021 |  |
|  |  |  |  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Total |  |  | Level 1 |  |  | Level 2 |  |
| Cash |  | $ | 4,468 |  |  | $ | 4,468 |  |  | $ | — |  |
| Corporate bonds |  |  | 59 |  |  |  | — |  |  |  | 59 |  |
| U.S. Treasury and government debt securities |  |  | 8 |  |  |  | 4 |  |  |  | 4 |  |
| Certificates of deposit |  |  | 61 |  |  |  | — |  |  |  | 61 |  |
| Total cash, cash equivalents and short-term investments |  | $ | 4,596 |  |  | $ | 4,472 |  |  | $ | 124 |  |
| Other items: |  |  |  |  |  |  |  |  |  |
| Mutual funds (1) |  | $ | 8 |  |  | $ | 8 |  |  | $ | — |  |
| Mutual funds (2) |  | $ | 32 |  |  | $ | 32 |  |  | $ | — |  |
| Foreign currency exchange contracts assets (1) |  | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |
| Foreign currency exchange contracts liabilities (3) |  | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |

[0000950170-22-011708:notes:178]
(1)
Reported as other current assets in the consolidated balance sheets

[0000950170-22-011708:notes:179]
(2)
Reported as other non-current assets in the consolidated balance sheets

[0000950170-22-011708:notes:180]
(3)
Reported as accrued expenses in the consolidated balance sheets

[0000950170-22-011708:notes:181]
Our Level 2 debt instruments are held by a custodian who prices some of the investments using standard inputs in various asset price models or obtains investment prices from third-party pricing providers that incorporate standard inputs in various asset price models. These pricing providers utilize the most recent observable market information in pricing these securities or, if specific prices are not available for these securities, use other observable inputs like market transactions involving identical or comparable securities. We review Level 2 inputs and fair value for reasonableness and the values may be further validated by comparison to multiple independent pricing sources. In addition, we review third-party pricing provider models, key inputs and assumptions and understand the pricing processes at our third-party providers in determining the overall reasonableness of the fair value of our Level 2 debt instruments. As of April 29, 2022 and April 30, 2021, we have not made any adjustments to the prices obtained from our third-party pricing providers.

[0000950170-22-011708:notes:182]
Fair Value of Debt

[0000950170-22-011708:notes:183]
As of April 29, 2022 and April 30, 2021, the fair value of our long-term debt was approximately $2,491 million and $2,736 million, respectively. The fair value of our long-term debt was based on observable market prices in a less active market.


## us-gaap:DebtDisclosureTextBlock

[0000950170-22-011708:notes:184]
8. Financing Arrangements

[0000950170-22-011708:notes:185]
Long-Term Debt

[0000950170-22-011708:notes:186]
The following table summarizes information relating to our long-term debt, which we collectively refer to as our Senior Notes (in millions, except interest rates):

[0000950170-22-011708:notes:187]
|  |  | Effective Interest Rate |  | April 29, 2022 |  |  | April 30, 2021 |  |  |
| 3.25% Senior Notes Due December 2022 |  | 3.43% |  | $ | 250 |  |  | $ | 250 |  |  |
| 3.30% Senior Notes Due September 2024 |  | 3.42% |  |  | 400 |  |  |  | 400 |  |  |
| 1.875% Senior Notes Due June 2025 |  | 2.03% |  |  | 750 |  |  |  | 750 |  |  |
| 2.375% Senior Notes Due June 2027 |  | 2.51% |  |  | 550 |  |  |  | 550 |  |  |
| 2.70% Senior Notes Due June 2030 |  | 2.81% |  |  | 700 |  |  |  | 700 |  |  |
| Total principal amount |  |  |  |  | 2,650 |  |  |  | 2,650 |  |  |
| Unamortized discount and issuance costs |  |  |  |  | (14 | ) |  |  | (18 | ) |  |
| Total senior notes |  |  |  |  | 2,636 |  |  |  | 2,632 |  |  |
| Less: Current portion of long-term debt |  |  |  |  | (250 | ) |  |  | — |  |  |
| Total long-term debt |  |  |  | $ | 2,386 |  |  | $ | 2,632 |  |  |

[0000950170-22-011708:notes:188]
Senior Notes

[0000950170-22-011708:notes:189]
Our $750 million aggregate principal amount of 1.875% Senior Notes due 2025, $550 million aggregate principal amount of 2.375% Senior Notes due 2027 and $700 million aggregate principal amount of 2.70% Senior Notes due 2030, were issued in June 2020. Interest on these Senior Notes is payable semi-annually in June and December.

[0000950170-22-011708:notes:190]
Our 3.30% Senior Notes, with a principal amount of $400 million, were issued in September 2017 with interest paid semi-annually in March and September. Our 3.25% Senior Notes, with a principal amount of $250 million, were issued in December 2012 with interest paid semi-annually in June and December.

[0000950170-22-011708:notes:191]
Our Senior Notes, which are unsecured, unsubordinated obligations, rank equally in right of payment with any existing and future senior unsecured indebtedness.

[0000950170-22-011708:notes:192]
We may redeem the Senior Notes in whole or in part, at any time at our option at specified redemption prices. In addition, upon the occurrence of certain change of control triggering events, we may be required to repurchase the Senior Notes under specified terms. The Senior Notes also include covenants that limit our ability to incur debt secured by liens on assets or on shares of stock or indebtedness of our subsidiaries; to engage in certain sale and lease-back transactions; and to consolidate, merge or sell all or substantially all of our assets. As of April 29, 2022, we were in compliance with all covenants associated with the Senior Notes.

[0000950170-22-011708:notes:193]
As of April 29, 2022, our aggregate future principal debt maturities are as follows (in millions):

[0000950170-22-011708:notes:194]
| Fiscal Year |  | Amount |  |
| 2023 |  | $ | 250 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | 400 |  |
| 2026 |  |  | 750 |  |
| Thereafter |  |  | 1,250 |  |
| Total |  | $ | 2,650 |  |

[0000950170-22-011708:notes:195]
Commercial Paper Program and Credit Facility

[0000950170-22-011708:notes:196]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program, as amended in July 2017, may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. There were no commercial paper notes outstanding as of April 29, 2022 or April 30, 2021.  During fiscal year 2021, we received proceeds of $75 million from the issuance, and made repayments of $176 million for the settlement, of commercial paper notes with original maturities greater than three months.

[0000950170-22-011708:notes:197]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended in January 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of April 29, 2022, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.


## ntap:LesseeOperatingAndFinanceLeasesDisclosureTextBlock

[0000950170-22-011708:notes:198]
. Leases

[0000950170-22-011708:notes:199]
We lease real estate, equipment and automobiles in the U.S. and internationally. Our real estate leases, which are responsible for the majority of our aggregate ROU asset and liability balances, include leases for office space, data centers and other facilities, and as of April 29, 2022, have remaining lease terms not exceeding 20 years. Some of these leases contain options that allow us to extend or terminate the lease agreement. Our equipment leases are primarily for servers and networking equipment and as of April 29, 2022, have remaining lease terms not exceeding 4 years. As of April 29, 2022, our automobile leases have remaining lease terms not exceeding 4 years. All our leases are classified as operating leases except for certain immaterial equipment finance leases.

[0000950170-22-011708:notes:200]
In June 2020, we entered into a build-to-suit lease agreement for an office building with future undiscounted payments of approximately $67 million. Because the Company did not control the underlying asset during the construction period, the Company was not considered the owner of the asset under construction for accounting purposes. The initial term of the lease is twenty years with options to renew the lease during the lease term. The lease commenced during the third quarter of fiscal 2022.

[0000950170-22-011708:notes:201]
In April 2021, we entered into a lease for our new corporate headquarters located in San Jose, California, which is comprised of approximately three hundred thousand square feet of office space and requires future minimum undiscounted payments of

[0000950170-22-011708:notes:202]
approximately $180 million over the initial 11-year lease term. The lease agreement also provides us two successive renewal options, each for five years. The lease commenced during the first quarter of fiscal 2022.

[0000950170-22-011708:notes:203]
The components of lease cost related to our operating leases were as follows (in millions):

[0000950170-22-011708:notes:204]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Operating lease cost |  | $ | 61 |  |  | $ | 55 |  |
| Variable lease cost |  |  | 15 |  |  |  | 11 |  |
| Total lease cost |  | $ | 76 |  |  | $ | 66 |  |

[0000950170-22-011708:notes:205]
Variable lease cost is primarily attributable to amounts paid to lessors for common area maintenance and utility charges under our real estate leases.

[0000950170-22-011708:notes:206]
The supplemental cash flow information related to our operating leases is as follows (in millions):

[0000950170-22-011708:notes:207]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 56 |  |  | $ | 57 |  |
| Right-of-use assets obtained in exchange for new operating lease obligations |  | $ | 236 |  |  | $ | 31 |  |

[0000950170-22-011708:notes:208]
The supplemental balance sheet information related to our operating leases is as follows (in millions, except lease term and discount rate):

[0000950170-22-011708:notes:209]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Other non-current assets |  | $ | 294 |  |  | $ | 114 |  |
| Total operating lease ROU assets |  | $ | 294 |  |  | $ | 114 |  |
| Accrued expenses |  | $ | 47 |  |  | $ | 49 |  |
| Other long-term liabilities |  |  | 257 |  |  |  | 71 |  |
| Total operating lease liabilities |  | $ | 304 |  |  | $ | 120 |  |
| Weighted Average Remaining Lease Term |  | 9.6 years |  |  | 3.4 years |  |
| Weighted Average Discount Rate |  |  | 2.8 | % |  |  | 2.9 | % |

[0000950170-22-011708:notes:210]
Future minimum operating lease payments as of April 29, 2022 are as follows (in millions):

[0000950170-22-011708:notes:211]
| Fiscal Year |  |  |  | Amount |  |
| 2023 |  |  |  | $ | 54 |  |
| 2024 |  |  |  |  | 46 |  |
| 2025 |  |  |  |  | 38 |  |
| 2026 |  |  |  |  | 33 |  |
| 2027 |  |  |  |  | 29 |  |
| Thereafter |  |  |  |  | 152 |  |
| Total lease payments |  |  |  |  | 352 |  |
| Less: Interest |  |  |  |  | (48 | ) |
| Total |  |  |  | $ | 304 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0000950170-22-011708:notes:212]
10. Stockholders’ Equity

[0000950170-22-011708:notes:213]
Equity Incentive Programs

[0000950170-22-011708:notes:214]
The 2021 Plan — The 2021 Equity Incentive Plan (the 2021 Plan) was adopted by our Board of Directors and approved by the stockholders on September 10, 2021. The 2021 Plan replaced the 1999 Stock Option Plan (the 1999 Plan), and the 1999 Plan terminated effective as of September 11, 2021, except that the 1999 Plan will continue to govern awards outstanding thereunder as of the date of such plan’s termination and such awards will continue in force and effect until terminated pursuant to their terms. The 2021

[0000950170-22-011708:notes:215]
Plan provides for the granting of incentive stock options, nonstatutory stock options, stock appreciation rights, restricted stock, restricted stock units, and performance awards to our employees, directors, and consultants.

[0000950170-22-011708:notes:216]
Under the 2021 Plan, the Board of Directors may grant to employees, nonemployee directors, consultants and independent advisors options to purchase shares of our common stock during their period of service. The exercise price for an incentive stock option and a nonstatutory option cannot be less than 100% of the fair market value of the common stock on the grant date. The 2021 Plan prohibits the repricing of any outstanding stock option or stock appreciation right after it has been granted or to cancel any outstanding stock option or stock appreciation right and immediately replace it with a new stock option or stock appreciation right with a lower exercise price unless approved by stockholders. RSUs granted under the 2021 Plan include time-based RSUs that generally vest over a four-year period with 25% vesting on the first anniversary of the grant date and 6.25% vesting quarterly thereafter. The Compensation Committee of the Board of Directors (the Compensation Committee) has the discretion to use different vesting schedules. In addition, performance-based RSUs may be granted under the Plan and are subject to performance criteria and vesting terms specified by the Compensation Committee.

[0000950170-22-011708:notes:217]
As of April 29, 2022, 8 million shares were available for grant under the Plan.

[0000950170-22-011708:notes:218]
Stock Options

[0000950170-22-011708:notes:219]
Less than 1 million stock options were outstanding as of April 29, 2022 and April 30, 2021.

[0000950170-22-011708:notes:220]
Additional information related to our stock options is summarized below (in millions):

[0000950170-22-011708:notes:221]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Intrinsic value of exercises |  | $ | 14 |  |  | $ | 11 |  |  | $ | 5 |  |
| Proceeds received from exercises |  | $ | 1 |  |  | $ | 8 |  |  | $ | 4 |  |
| Fair value of options vested |  | $ | 5 |  |  | $ | 5 |  |  | $ | 1 |  |

[0000950170-22-011708:notes:222]
Restricted Stock Units

[0000950170-22-011708:notes:223]
In fiscal 2022, 2021 and 2020, we granted PBRSUs to certain of our executives. Each PBRSU has performance-based vesting criteria (in addition to the service-based vesting criteria) such that the PBRSU cliff-vests at the end of either an approximate one, two or three year performance period, which began on the date specified in the grant agreement and typically ends on the last day of the first, second or third fiscal year, respectively, following the grant date. The number of shares of common stock that will be issued to settle most of these PBRSUs at the end of the applicable performance and service period will range from 0% to 200% of a target number of shares originally granted. For most of the PBRSUs granted in fiscal 2022 and fiscal 2021 and half of the PBRSUs granted in fiscal 2020, the number of shares issued will depend upon our Total Stockholder Return (TSR) as compared to the TSR of a specified group of benchmark peer companies (each expressed as a growth rate percentage) calculated as of the end of the performance period. The fair values of these awards were fixed at grant date using a Monte Carlo simulation model. For the remaining PBRSUs granted in fiscal 2020, the number of shares issued depended upon our achievement against a cumulative Adjusted Operating Income (AOI) target, as defined in the grant agreements, for the three-year periods from fiscal 2020 through 2022. The fair values of these AOI PBRSUs were established consistent with our methodology for valuing time-based RSUs, while compensation cost was recognized based on the probable outcome of the performance condition. The aggregate grant date fair value of all PBRSUs granted in fiscal 2022, 2021 and 2020 was $59 million, $27 million and $18 million, respectively, and these amounts are being recognized to expense over the shorter of the remaining applicable performance or service periods.

[0000950170-22-011708:notes:224]
As of April 29, 2022, April 30, 2021 and April 24, 2020, there were approximately 1 million PBRSUs outstanding.

[0000950170-22-011708:notes:225]
The following table summarizes information related to RSUs, including PBRSUs, (in millions, except for fair value):

[0000950170-22-011708:notes:226]
|  |  | Number ofShares |  |  | Weighted-AverageGrant Date Fair Value |  |
| Outstanding as of April 26, 2019 |  |  | 8 |  |  | $ | 45.68 |  |
| Granted |  |  | 4 |  |  | $ | 51.39 |  |
| Vested |  |  | (4 | ) |  | $ | 38.87 |  |
| Forfeited |  |  | (1 | ) |  | $ | 48.30 |  |
| Outstanding as of April 24, 2020 |  |  | 7 |  |  | $ | 51.40 |  |
| Granted |  |  | 6 |  |  | $ | 42.46 |  |
| Vested |  |  | (3 | ) |  | $ | 44.74 |  |
| Forfeited |  |  | (1 | ) |  | $ | 51.20 |  |
| Outstanding as of April 30, 2021 |  |  | 9 |  |  | $ | 47.75 |  |
| Granted |  |  | 5 |  |  | $ | 80.40 |  |
| Vested |  |  | (3 | ) |  | $ | 48.91 |  |
| Forfeited |  |  | (1 | ) |  | $ | 57.46 |  |
| Outstanding as of April 29, 2022 |  |  | 10 |  |  | $ | 64.09 |  |

[0000950170-22-011708:notes:227]
We primarily use the net share settlement approach upon vesting, where a portion of the shares are withheld as settlement of employee withholding taxes, which decreases the shares issued to the employee by a corresponding value. The number and value of the shares netted for employee taxes are summarized in the table below (in millions):

[0000950170-22-011708:notes:228]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Shares withheld for taxes |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |
| Fair value of shares withheld |  | $ | 74 |  |  | $ | 42 |  |  | $ | 79 |  |

[0000950170-22-011708:notes:229]
Employee Stock Purchase Plan

[0000950170-22-011708:notes:230]
Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. On September 10, 2021, the ESPP was amended to increase the shares reserved for issuance by 3 million shares of common stock. As of April 29, 2022, 5 million shares were available for issuance. The following table summarizes activity related to the purchase rights issued under the ESPP (in millions):

[0000950170-22-011708:notes:231]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Shares issued under the ESPP |  |  | 3 |  |  |  | 2 |  |  |  | 2 |  |
| Proceeds from issuance of shares |  | $ | 104 |  |  | $ | 90 |  |  | $ | 98 |  |

[0000950170-22-011708:notes:232]
Stock-Based Compensation Expense

[0000950170-22-011708:notes:233]
Stock-based compensation expense is included in the consolidated statements of income as follows (in millions):

[0000950170-22-011708:notes:234]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Cost of product revenues |  | $ | 4 |  |  | $ | 4 |  |  | $ | 3 |  |
| Cost of hardware support and other services revenues |  |  | 13 |  |  |  | 10 |  |  |  | 10 |  |
| Sales and marketing |  |  | 115 |  |  |  | 92 |  |  |  | 66 |  |
| Research and development |  |  | 75 |  |  |  | 64 |  |  |  | 53 |  |
| General and administrative |  |  | 38 |  |  |  | 27 |  |  |  | 21 |  |
| Total stock-based compensation expense |  | $ | 245 |  |  | $ | 197 |  |  | $ | 153 |  |

[0000950170-22-011708:notes:235]
As of April 29, 2022, total unrecognized compensation expense related to our equity awards was $475 million, which is expected to be recognized on a straight-line basis over a weighted-average remaining service period of 2.2 years.

[0000950170-22-011708:notes:236]
Valuation Assumptions

[0000950170-22-011708:notes:237]
The valuation of RSUs and ESPP purchase rights and the underlying weighted-average assumptions are summarized as follows:

[0000950170-22-011708:notes:238]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| RSUs: |  |  |  |  |  |  |  |  |  |
| Risk-free interest rate |  |  | 0.5 | % |  |  | 0.2 | % |  |  | 1.7 | % |
| Expected dividend yield |  |  | 2.4 | % |  |  | 4.4 | % |  |  | 2.9 | % |
| Weighted-average fair value per share granted |  | $ | 80.40 |  |  | $ | 42.46 |  |  | $ | 51.39 |  |
| ESPP: |  |  |  |  |  |  |  |  |  |
| Expected term in years |  |  | 1.2 |  |  |  | 1.2 |  |  |  | 1.2 |  |
| Risk-free interest rate |  |  | 0.2 | % |  |  | 0.2 | % |  |  | 2.0 | % |
| Expected volatility |  |  | 37 | % |  |  | 47 | % |  |  | 33 | % |
| Expected dividend yield |  |  | 2.4 | % |  |  | 4.4 | % |  |  | 3.1 | % |
| Weighted-average fair value per right granted |  | $ | 24.75 |  |  | $ | 10.08 |  |  | $ | 10.15 |  |

[0000950170-22-011708:notes:239]
Stock Repurchase Program

[0000950170-22-011708:notes:240]
As of April 29, 2022, our Board of Directors has authorized the repurchase of up to $15.1 billion of our common stock. Under this program, which we may suspend or discontinue at any time, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. In March 2020, we suspended our repurchases under the program due to the economic impact of the COVID-19 pandemic. We reinitiated our stock repurchase program during the third quarter of fiscal year 2021.

[0000950170-22-011708:notes:241]
The following table summarizes activity related to this program (in millions, except per share amounts):

[0000950170-22-011708:notes:242]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Number of shares repurchased |  |  | 7 |  |  |  | 2 |  |  |  | 25 |  |
| Average price per share |  | $ | 84.49 |  |  | $ | 67.61 |  |  | $ | 56.34 |  |
| Stock repurchases allocated to additional paid-in capital |  | $ | 20 |  |  | $ | 3 |  |  | $ | 625 |  |
| Stock repurchases allocated to retained earnings |  | $ | 580 |  |  | $ | 122 |  |  | $ | 786 |  |
| Remaining authorization at end of period |  | $ | 1,252 |  |  | $ | 352 |  |  | $ | 477 |  |

[0000950170-22-011708:notes:243]
Since the May 13, 2003 inception of our stock repurchase program through April 29, 2022, we repurchased a total of 347 million shares of our common stock at an average price of $39.95 per share, for an aggregate purchase price of $13.9 billion.

[0000950170-22-011708:notes:244]
Preferred Stock

[0000950170-22-011708:notes:245]
Our Board of Directors has the authority to issue up to 5 million shares of preferred stock and to determine the price, rights, preferences, privileges, and restrictions, including voting rights, of those shares without any further vote or action by the stockholders. No shares of preferred stock were issued or outstanding in any period presented.

[0000950170-22-011708:notes:246]
Dividends

[0000950170-22-011708:notes:247]
The following is a summary of our fiscal 2022, 2021 and 2020 activities related to dividends on our common stock (in millions, except per share amounts).

[0000950170-22-011708:notes:248]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Dividends per share declared |  | $ | 2.00 |  |  | $ | 1.92 |  |  | $ | 1.92 |  |
| Dividend payments allocated to additional paid-in capital |  | $ | — |  |  | $ | 30 |  |  | $ | 400 |  |
| Dividend payments allocated to retained earnings |  | $ | 446 |  |  | $ | 397 |  |  | $ | 39 |  |

[0000950170-22-011708:notes:249]
On May 27, 2022, we declared a cash dividend of $0.50 per share of common stock, payable on July 27, 2022 to shareholders of record as of the close of business on July 8, 2022. The timing and amount of future dividends will depend on market conditions,

[0000950170-22-011708:notes:250]
corporate business and financial considerations and regulatory requirements. All dividends declared have been determined by the Company to be legally authorized under the laws of the state in which we are incorporated.

[0000950170-22-011708:notes:251]
Accumulated Other Comprehensive Income (Loss)

[0000950170-22-011708:notes:252]
Changes in accumulated other comprehensive income (loss) (AOCI) by component, net of tax, are summarized below (in millions):

[0000950170-22-011708:notes:253]
|  |  | ForeignCurrencyTranslationAdjustments |  |  | DefinedBenefitObligationAdjustments |  |  | UnrealizedGains(Losses) on Available-for-SaleSecurities |  |  | UnrealizedGains(Losses) onCash Flow Hedges |  |  | Total |  |
| Balance as of April 26, 2019 |  | $ | (34 | ) |  | $ | (3 | ) |  | $ | (7 | ) |  | $ | 1 |  |  | $ | (43 | ) |
| OCI before reclassifications, net of tax |  |  | (8 | ) |  |  | 3 |  |  |  | 22 |  |  |  | 5 |  |  |  | 22 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | (1 | ) |  |  | (14 | ) |  |  | (6 | ) |  |  | (21 | ) |
| Total OCI |  |  | (8 | ) |  |  | 2 |  |  |  | 8 |  |  |  | (1 | ) |  |  | 1 |  |
| Balance as of April 24, 2020 |  |  | (42 | ) |  |  | (1 | ) |  |  | 1 |  |  |  | — |  |  |  | (42 | ) |
| OCI before reclassifications, net of tax |  |  | 15 |  |  |  | (3 | ) |  |  | — |  |  |  | (11 | ) |  |  | 1 |  |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 11 |  |  |  | 11 |  |
| Total OCI |  |  | 15 |  |  |  | (3 | ) |  |  | — |  |  |  | — |  |  |  | 12 |  |
| Balance as of April 30, 2021 |  |  | (27 | ) |  |  | (4 | ) |  |  | 1 |  |  |  | — |  |  |  | (30 | ) |
| OCI before reclassifications, net of tax |  |  | (17 | ) |  |  | 3 |  |  |  | (1 | ) |  |  | 8 |  |  |  | (7 | ) |
| Amounts reclassified from AOCI, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (7 | ) |  |  | (7 | ) |
| Total OCI |  |  | (17 | ) |  |  | 3 |  |  |  | (1 | ) |  |  | 1 |  |  |  | (14 | ) |
| Balance as of April 29, 2022 |  | $ | (44 | ) |  | $ | (1 | ) |  | $ | — |  |  | $ | 1 |  |  | $ | (44 | ) |

[0000950170-22-011708:notes:254]
The amounts reclassified out of AOCI are as follows (in millions):

[0000950170-22-011708:notes:255]
|  |  | Year Ended |  |  | Statements of Income |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |  | Classification |
| Recognized gains on defined benefit obligations |  | $ | — |  |  | $ | — |  |  | $ | (2 | ) |  | Operating expenses |
| Realized gains on available-for-sale securities |  |  | — |  |  |  | — |  |  |  | (14 | ) |  | Other expense, net |
| Realized losses (gains) on cash flow hedges |  |  | (7 | ) |  |  | 11 |  |  |  | (6 | ) |  | Net revenues |
| Total reclassifications |  | $ | (7 | ) |  | $ | 11 |  |  | $ | (22 | ) |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-22-011708:notes:256]
11. Derivatives and Hedging Activities

[0000950170-22-011708:notes:257]
We use derivative instruments to manage exposures to foreign currency risk. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates. The maximum length of time over which forecasted foreign currency denominated revenues are hedged is 12 months. The program is not designated for trading or speculative purposes. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet their obligations under the terms of our agreements. We seek to mitigate such risk by limiting our counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored on an ongoing basis. We also have in place master netting arrangements to mitigate the credit risk of our counterparties and to potentially reduce our losses due to counterparty nonperformance. We present our derivative instruments as net amounts in our consolidated balance sheets. The gross and net fair value amounts of such instruments were not material as of April 29, 2022 or April 30, 2021. All contracts have a maturity of less than 12 months.

[0000950170-22-011708:notes:258]
The notional amount of our outstanding U.S. dollar equivalent foreign currency exchange forward contracts consisted of the following (in millions):

[0000950170-22-011708:notes:259]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Cash Flow Hedges |  |  |  |  |  |  |
| Forward contracts purchased |  | $ | 78 |  |  | $ | 167 |  |
| Balance Sheet Contracts |  |  |  |  |  |  |
| Forward contracts sold |  | $ | 841 |  |  | $ | 497 |  |
| Forward contracts purchased |  | $ | 129 |  |  | $ | 117 |  |

[0000950170-22-011708:notes:260]
The effect of cash flow hedges recognized in net revenues is presented in the consolidated statements of comprehensive income and Note 10 – Stockholders’ Equity.

[0000950170-22-011708:notes:261]
The effect of derivative instruments not designated as hedging instruments recognized in other expense, net on our consolidated statements of income was as follows (in millions):

[0000950170-22-011708:notes:262]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
|  |  | Gain (Loss) Recognized into Income |  |
| Foreign currency exchange contracts |  | $ | (91 | ) |  | $ | 20 |  |  | $ | — |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-22-011708:notes:263]
12. Restructuring Charges

[0000950170-22-011708:notes:264]
In the fourth quarter of fiscal 2022, we initiated the establishment of an international headquarters in Cork, Ireland, and incurred restructuring charges consisting primarily of legal and tax-related consulting fees. Activities under this plan, for which we expect to incur additional charges, will continue in fiscal 2023.

[0000950170-22-011708:notes:265]
In the first quarter of fiscal 2022, we executed a restructuring plan to reduce the amount of office space we occupy as we allow more employees to continue to work remotely. In connection with the plan, we also reduced our global workforce by approximately 1%. Charges related to the plan consisted primarily of office relocation costs, lease termination fees, and employee severance related costs. Substantially all activities under the plan have been completed.

[0000950170-22-011708:notes:266]
Management has previously approved several restructuring actions in fiscal 2021 and fiscal 2020, under which we reduced our global workforce by approximately 6% and 2%, respectively. Charges related to these restructuring plans consisted primarily of employee severance-related costs. Substantially all activities under these plans were completed as of the end of fiscal 2021.

[0000950170-22-011708:notes:267]
Activities related to our restructuring plans are summarized as follows (in millions):

[0000950170-22-011708:notes:268]
|  |  | Total |  |
| Balance as of April 26, 2019 |  | $ | 19 |  |
| Net charges |  |  | 21 |  |
| Cash payments |  |  | (35 | ) |
| Other |  |  | (4 | ) |
| Balance as of April 24, 2020 |  |  | 1 |  |
| Net charges |  |  | 42 |  |
| Cash payments |  |  | (42 | ) |
| Balance as of April 30, 2021 |  |  | 1 |  |
| Net charges |  |  | 33 |  |
| Cash payments |  |  | (31 | ) |
| Balance as of April 29, 2022 |  | $ | 3 |  |

[0000950170-22-011708:notes:269]
Liabilities for our restructuring activities are included in accrued expenses in our consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-22-011708:notes:270]
13. Income Taxes

[0000950170-22-011708:notes:271]
Income before income taxes is as follows (in millions):

[0000950170-22-011708:notes:272]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Domestic |  | $ | 546 |  |  | $ | 433 |  |  | $ | 379 |  |
| Foreign |  |  | 549 |  |  |  | 529 |  |  |  | 565 |  |
| Total |  | $ | 1,095 |  |  | $ | 962 |  |  | $ | 944 |  |

[0000950170-22-011708:notes:273]
The provision for income taxes consists of the following (in millions):

[0000950170-22-011708:notes:274]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Current: |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 187 |  |  | $ | 82 |  |  | $ | 83 |  |
| State |  |  | 55 |  |  |  | 22 |  |  |  | 9 |  |
| Foreign |  |  | 60 |  |  |  | 134 |  |  |  | 50 |  |
| Total current |  |  | 302 |  |  |  | 238 |  |  |  | 142 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (125 | ) |  |  | 6 |  |  |  | (26 | ) |
| State |  |  | (27 | ) |  |  | 2 |  |  |  | (6 | ) |
| Foreign |  |  | 8 |  |  |  | (14 | ) |  |  | 15 |  |
| Total deferred |  |  | (144 | ) |  |  | (6 | ) |  |  | (17 | ) |
| Provision for income taxes |  | $ | 158 |  |  | $ | 232 |  |  | $ | 125 |  |

[0000950170-22-011708:notes:275]
The provision for income taxes differs from the amount computed by applying the statutory federal income tax rate as follows (in millions):

[0000950170-22-011708:notes:276]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Tax computed at federal statutory rate |  | $ | 230 |  |  | $ | 202 |  |  | $ | 198 |  |
| State income taxes, net of federal benefit |  |  | 15 |  |  |  | 23 |  |  |  | 10 |  |
| Foreign earnings in lower tax jurisdictions |  |  | (46 | ) |  |  | (26 | ) |  |  | (40 | ) |
| Stock-based compensation |  |  | (8 | ) |  |  | 6 |  |  |  | (4 | ) |
| Research and development credits |  |  | (18 | ) |  |  | (13 | ) |  |  | (16 | ) |
| Benefit for foreign derived intangible income |  |  | (49 | ) |  |  | (2 | ) |  |  | (4 | ) |
| Global minimum tax on intangible income |  |  | 1 |  |  |  | 19 |  |  |  | 32 |  |
| Transition tax and related reserves |  |  | 1 |  |  |  | 1 |  |  |  | 15 |  |
| Tax charge from integration of acquired companies |  |  | 23 |  |  |  | 35 |  |  |  | — |  |
| Resolution of income tax matters (1) |  |  | (3 | ) |  |  | (6 | ) |  |  | (61 | ) |
| Other |  |  | 12 |  |  |  | (7 | ) |  |  | (5 | ) |
| Provision for income taxes |  | $ | 158 |  |  | $ | 232 |  |  | $ | 125 |  |

[0000950170-22-011708:notes:277]
(1)
During fiscal 2022, we recognized a tax benefit related to the lapse of statute of limitations for certain issues in our fiscal 2012 and 2013 state income tax returns. During fiscal 2021, we recognized a tax benefit related to the lapse of statutes of limitations for certain issues on our fiscal 2016 and 2017 federal income tax returns. During fiscal 2020, we recognized a tax benefit related to the lapse of statutes of limitations on our fiscal 2014 and 2015 federal income tax returns.

[0000950170-22-011708:notes:278]
The components of our deferred tax assets and liabilities are as follows (in millions):

[0000950170-22-011708:notes:279]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Deferred tax assets: |  |  |  |  |  |  |
| Reserves and accruals |  | $ | 267 |  |  | $ | 65 |  |
| Net operating loss and credit carryforwards |  |  | 121 |  |  |  | 115 |  |
| Stock-based compensation |  |  | 23 |  |  |  | 18 |  |
| Deferred revenue and financed unearned services revenue |  |  | 235 |  |  |  | 226 |  |
| Other |  |  | 6 |  |  |  | 20 |  |
| Gross deferred tax assets |  |  | 652 |  |  |  | 444 |  |
| Valuation allowance |  |  | (111 | ) |  |  | (107 | ) |
| Deferred tax assets, net of valuation allowance |  |  | 541 |  |  |  | 337 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Prepaids and accruals |  |  | 108 |  |  |  | 51 |  |
| Acquired intangibles |  |  | 48 |  |  |  | 28 |  |
| Property and equipment |  |  | 39 |  |  |  | 31 |  |
| Other |  |  | 7 |  |  |  | 24 |  |
| Total deferred tax liabilities |  |  | 202 |  |  |  | 134 |  |
| Deferred tax assets, net of valuation allowance and deferred tax liabilities |  | $ | 339 |  |  | $ | 203 |  |

[0000950170-22-011708:notes:280]
The valuation allowance increased by $4 million in fiscal 2022. The increase is mainly attributable to corresponding changes in deferred tax assets, primarily certain state tax credit carryforwards.

[0000950170-22-011708:notes:281]
As of April 29, 2022, we have federal net operating loss carryforwards of approximately $10 million. In addition, we have gross state net operating loss and tax credit carryforwards of $33 million and $133 million, respectively. The majority of the state credit carryforwards are California research credits which are offset by a valuation allowance as we believe it is more likely than not that these credits will not be utilized. We also have $4 million of foreign net operating losses, and $29 million of foreign tax credit carryforwards where the majority is generated by our Dutch subsidiary which are fully offset by a valuation allowance. Certain acquired net operating loss carryforwards are subject to an annual limitation under Internal Revenue Code Section 382, but are expected to be realized with the exception of those which have a valuation allowance. The state and foreign net operating loss carryforwards and credits will expire in various years from fiscal 2023 through 2042. The federal net operating loss carryforwards, the California research credit and the Dutch foreign tax credit carryforwards do not expire.

[0000950170-22-011708:notes:282]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0000950170-22-011708:notes:283]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Balance at beginning of period |  | $ | 221 |  |  | $ | 211 |  |  | $ | 296 |  |
| Additions based on tax positions related to the current year |  |  | 11 |  |  |  | 7 |  |  |  | 5 |  |
| Additions for tax positions of prior years |  |  | — |  |  |  | 11 |  |  |  | 1 |  |
| Decreases for tax positions of prior years |  |  | (2 | ) |  |  | — |  |  |  | (10 | ) |
| Settlements |  |  | (10 | ) |  |  | (8 | ) |  |  | (81 | ) |
| Balance at end of period |  | $ | 220 |  |  | $ | 221 |  |  | $ | 211 |  |

[0000950170-22-011708:notes:284]
As of April 29, 2022, we had $220 million of gross unrecognized tax benefits, of which $131 million has been recorded in other long-term liabilities. Unrecognized tax benefits of $130 million, including penalties, interest and indirect benefits, would affect our provision for income taxes if recognized.

[0000950170-22-011708:notes:285]
We recognized expense for increases to accrued interest and penalties related to unrecognized tax benefits in the income tax provision of approximately $4 million in fiscal 2022 and $1 million in fiscal 2021, and we recognized a benefit of $8 million in fiscal 2020. Accrued interest and penalties of $15 million and $11 million were recorded in the consolidated balance sheets as of April 29, 2022 and April 30, 2021, respectively.

[0000950170-22-011708:notes:286]
The tax years that remain subject to examination for our major tax jurisdictions are shown below:

[0000950170-22-011708:notes:287]
Fiscal Years Subject to Examination for Major Tax Jurisdictions at April 29, 2022

[0000950170-22-011708:notes:288]
| 2016 — 2022 |  | United States — federal income tax |
| 2018 — 2022 |  | United States — state and local income tax |
| 2020 — 2022 |  | Australia |
| 2015 — 2022 |  | Germany |
| 2007 — 2022 |  | India |
| 2017 — 2022 |  | The Netherlands |
| 2016 — 2022 |  | Canada |

[0000950170-22-011708:notes:289]
We are currently undergoing various income tax audits in the U.S. and several foreign tax jurisdictions. Transfer pricing calculations are key topics under these audits and are often subject to dispute and appeals. We are effectively subject to federal tax examination adjustments for tax years ended on or after fiscal 2001, in that we have carryforward attributes from these years that could be subject to adjustment in the tax years of utilization.

[0000950170-22-011708:notes:290]
In September 2010, the Danish Tax Authorities issued a decision concluding that distributions declared in 2005 and 2006 by our Danish subsidiary were subject to Danish at-source dividend withholding tax. We do not believe that our Danish subsidiary is liable for such withholding tax and filed an appeal with the Danish Tax Tribunal. In December 2011, the Danish Tax Tribunal issued a ruling in favor of NetApp. The Danish tax examination agency appealed this decision at the Danish High Court (DHC) in March 2012. In February 2016, the DHC requested a preliminary ruling from the Court of Justice of the European Union (CJEU). In March 2018, the Advocate General issued an opinion which was largely in favor of NetApp. The CJEU was not bound by the opinion of the Advocate General and issued its preliminary ruling in February 2019. The CJEU ruling did not preclude the Danish Tax Authorities from imposing withholding tax on distributions based on the benefits of certain European Union directives. On May 3, 2021, the DHC reached a decision resulting in NetApp prevailing on the predominate distribution made in 2005. The smaller distribution made in

[0000950170-22-011708:notes:291]
2006 was ruled in favor of the Danish Tax Authorities. On May 28, 2021, the Danish Tax Authorities appealed the DHC decision to the Danish Supreme Court. We believe it is more likely than not that our distributions were not subject to withholding tax and we will continue to support our position in the appeals process with the Danish Supreme Court.

[0000950170-22-011708:notes:292]
We continue to monitor the progress of ongoing discussions with tax authorities and the impact, if any, of the expected expiration of the statute of limitations in various taxing jurisdictions. We engage in continuous discussion and negotiation with taxing authorities regarding tax matters in multiple jurisdictions. We believe that within the next 12 months, it is reasonably possible that either certain audits will conclude, certain statutes of limitations will lapse, or both. As a result of uncertainties regarding tax audits and their possible outcomes, an estimate of the range of possible impacts to unrecognized tax benefits in the next twelve months cannot be made at this time.

[0000950170-22-011708:notes:293]
As of April 29, 2022, we continue to record a deferred tax liability related to state taxes on unremitted earnings of certain foreign entities. We estimate the unrecognized deferred tax liability related to the earnings we expect to be indefinitely reinvested to be immaterial. We will continue to monitor our plans to indefinitely reinvest undistributed earnings of foreign subsidiaries and will assess the related unrecognized deferred tax liability considering our ongoing projected global cash requirements, tax consequences associated with repatriation and any U.S. or foreign government programs designed to influence remittances.


## us-gaap:EarningsPerShareTextBlock

[0000950170-22-011708:notes:294]
14. Net Income per Share

[0000950170-22-011708:notes:295]
The following is a calculation of basic and diluted net income per share (in millions, except per share amounts):

[0000950170-22-011708:notes:296]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Numerator: |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 937 |  |  | $ | 730 |  |  | $ | 819 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Shares used in basic computation |  |  | 223 |  |  |  | 222 |  |  |  | 230 |  |
| Dilutive impact of employee equity award plans |  |  | 6 |  |  |  | 4 |  |  |  | 3 |  |
| Shares used in diluted computation |  |  | 229 |  |  |  | 226 |  |  |  | 233 |  |
| Net Income per Share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 4.20 |  |  | $ | 3.29 |  |  | $ | 3.56 |  |
| Diluted |  | $ | 4.09 |  |  | $ | 3.23 |  |  | $ | 3.52 |  |

[0000950170-22-011708:notes:297]
While no potential shares from outstanding employee awards were excluded from the diluted net income per share calculation for fiscal 2022, four million potential shares from outstanding employee equity awards were excluded from the diluted net income per share calculations for each of fiscal 2021 and 2020, as their inclusion would have been anti-dilutive.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-22-011708:notes:298]
15. Segment, Geographic, and Significant Customer Information

[0000950170-22-011708:notes:299]
Effective July 30, 2021, our Chief Operating Decision Maker (CODM), who is our Chief Executive Officer, realigned internal reporting and began using financial information for components of our business, organized based on category of product/solution, to evaluate performance and allocate resources. This resulted in the creation of two operating segments and two reportable segments for financial reporting purposes: Hybrid Cloud and Public Cloud. The CODM measures performance of each segment based on segment revenue and segment gross profit. We do not allocate to our segments certain cost of revenues which we manage at the corporate level. These unallocated costs include stock-based compensation and amortization of intangible assets. We do not allocate assets to our segments.

[0000950170-22-011708:notes:300]
Hybrid Cloud offers a portfolio of storage and infrastructure solutions that help customers recast their data centers with the power of cloud. This portfolio is designed to operate with public clouds to unlock the potential of hybrid, multi-cloud operations. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.

[0000950170-22-011708:notes:301]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage and data services, and cloud operations services. Public Cloud includes certain reseller arrangements in which the timing of our consideration follows the end user consumption of the reseller services.

[0000950170-22-011708:notes:302]
Financial information for the prior periods have been updated to conform to the current year presentation of two segments.

[0000950170-22-011708:notes:303]
Segment Revenues and Gross Profit

[0000950170-22-011708:notes:304]
Financial information by segment is as follows (in millions, except percentages):

[0000950170-22-011708:notes:305]
|  | Year Ended April 29, 2022 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 3,284 |  |  | $ | — |  |  | $ | 3,284 |  |
| Support revenues |  | 2,344 |  |  |  | — |  |  |  | 2,344 |  |
| Professional and other services revenues |  | 294 |  |  |  | — |  |  |  | 294 |  |
| Public cloud revenues |  | — |  |  |  | 396 |  |  |  | 396 |  |
| Net revenues |  | 5,922 |  |  |  | 396 |  |  |  | 6,318 |  |
| Cost of product revenues |  | 1,541 |  |  |  | — |  |  |  | 1,541 |  |
| Cost of support revenues |  | 184 |  |  |  | — |  |  |  | 184 |  |
| Cost of professional and other services revenues |  | 205 |  |  |  | — |  |  |  | 205 |  |
| Cost of public cloud revenues |  | — |  |  |  | 118 |  |  |  | 118 |  |
| Segment cost of revenues |  | 1,930 |  |  |  | 118 |  |  |  | 2,048 |  |
| Segment gross profit | $ | 3,992 |  |  | $ | 278 |  |  | $ | 4,270 |  |
| Segment gross margin |  | 67.4 | % |  |  | 70.2 | % |  |  | 67.6 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 50 |  |
| Total gross profit |  |  |  |  |  |  | $ | 4,220 |  |
| Total gross margin |  |  |  |  |  |  |  | 66.8 | % |
| 1 Unallocated cost of revenues are composed of $17 million of stock-based compensation expense and $33 million of amortization of intangible assets. |  |

[0000950170-22-011708:notes:306]
|  | Year Ended April 30, 2021 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 2,991 |  |  | $ | — |  |  | $ | 2,991 |  |
| Support revenues |  | 2,277 |  |  |  | — |  |  |  | 2,277 |  |
| Professional and other services revenues |  | 277 |  |  |  | — |  |  |  | 277 |  |
| Public cloud revenues |  | — |  |  |  | 199 |  |  |  | 199 |  |
| Net revenues |  | 5,545 |  |  |  | 199 |  |  |  | 5,744 |  |
| Cost of product revenues |  | 1,402 |  |  |  | — |  |  |  | 1,402 |  |
| Cost of support revenues |  | 201 |  |  |  | — |  |  |  | 201 |  |
| Cost of professional and other services revenues |  | 206 |  |  |  | — |  |  |  | 206 |  |
| Cost of public cloud revenues |  | — |  |  |  | 65 |  |  |  | 65 |  |
| Segment cost of revenues |  | 1,809 |  |  |  | 65 |  |  |  | 1,874 |  |
| Segment gross profit | $ | 3,736 |  |  | $ | 134 |  |  | $ | 3,870 |  |
| Segment gross margin |  | 67.4 | % |  |  | 67.3 | % |  |  | 67.4 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 55 |  |
| Total gross profit |  |  |  |  |  |  | $ | 3,815 |  |
| Total gross margin |  |  |  |  |  |  |  | 66.4 | % |
| 1 Unallocated cost of revenues are composed of $14 million of stock-based compensation expense and $41 million of amortization of intangible assets. |  |

[0000950170-22-011708:notes:307]
|  | Year Ended April 24, 2020 |  |
|  | Hybrid Cloud |  |  | Public Cloud |  |  | Consolidated |  |
| Product revenues | $ | 2,995 |  |  | $ | — |  |  | $ | 2,995 |  |
| Support revenues |  | 2,114 |  |  |  | — |  |  |  | 2,114 |  |
| Professional and other services revenues |  | 241 |  |  |  | — |  |  |  | 241 |  |
| Public cloud revenues |  | — |  |  |  | 62 |  |  |  | 62 |  |
| Net revenues |  | 5,350 |  |  |  | 62 |  |  |  | 5,412 |  |
| Cost of product revenues |  | 1,326 |  |  |  | — |  |  |  | 1,326 |  |
| Cost of support revenues |  | 188 |  |  |  | — |  |  |  | 188 |  |
| Cost of professional and other services revenues |  | 188 |  |  |  | — |  |  |  | 188 |  |
| Cost of public cloud revenues |  | — |  |  |  | 35 |  |  |  | 35 |  |
| Segment cost of revenues |  | 1,702 |  |  |  | 35 |  |  |  | 1,737 |  |
| Segment gross profit | $ | 3,648 |  |  | $ | 27 |  |  | $ | 3,675 |  |
| Segment gross margin |  | 68.2 | % |  |  | 43.5 | % |  |  | 67.9 | % |
| Unallocated cost of revenues1 |  |  |  |  |  |  |  | 52 |  |
| Total gross profit |  |  |  |  |  |  | $ | 3,623 |  |
| Total gross margin |  |  |  |  |  |  |  | 66.9 | % |
| 1 Unallocated cost of revenues are composed of $13 million of stock-based compensation expense and $39 million of amortization of intangible assets. |  |

[0000950170-22-011708:notes:308]
Geographical Revenues and Certain Assets

[0000950170-22-011708:notes:309]
Revenues summarized by geographic region are as follows (in millions):

[0000950170-22-011708:notes:310]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| United States, Canada and Latin America (Americas) |  | $ | 3,460 |  |  | $ | 3,097 |  |  | $ | 2,863 |  |
| Europe, Middle East and Africa (EMEA) |  |  | 1,979 |  |  |  | 1,775 |  |  |  | 1,742 |  |
| Asia Pacific (APAC) |  |  | 879 |  |  |  | 872 |  |  |  | 807 |  |
| Net revenues |  | $ | 6,318 |  |  | $ | 5,744 |  |  | $ | 5,412 |  |

[0000950170-22-011708:notes:311]
Americas revenues consist of sales to Americas commercial and U.S. public sector markets. Sales to customers inside the U.S. were $3,041 million, $2,784 million and $2,584 million during fiscal 2022, 2021 and 2020, respectively.

[0000950170-22-011708:notes:312]
The majority of our assets, excluding cash, cash equivalents, short-term investments and accounts receivable, were attributable to our domestic operations. The following table presents cash, cash equivalents and short-term investments held in the U.S. and internationally in various foreign subsidiaries (in millions):

[0000950170-22-011708:notes:313]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| U.S. |  | $ | 1,820 |  |  | $ | 2,098 |  |
| International |  |  | 2,314 |  |  |  | 2,498 |  |
| Total |  | $ | 4,134 |  |  | $ | 4,596 |  |

[0000950170-22-011708:notes:314]
With the exception of property and equipment, we do not identify or allocate our long-lived assets by geographic area. The following table presents property and equipment information for geographic areas based on the physical location of the assets (in millions):

[0000950170-22-011708:notes:315]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| U.S. |  | $ | 392 |  |  | $ | 340 |  |
| International |  |  | 210 |  |  |  | 185 |  |
| Total |  | $ | 602 |  |  | $ | 525 |  |

[0000950170-22-011708:notes:316]
Significant Customers

[0000950170-22-011708:notes:317]
The following customers, each of which is a distributor, accounted for 10% or more of our net revenues:

[0000950170-22-011708:notes:318]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 24 | % |  |  | 25 | % |
| Tech Data Corporation |  |  | 21 | % |  |  | 20 | % |  |  | 21 | % |

[0000950170-22-011708:notes:319]
The following customers accounted for 10% or more of accounts receivable:

[0000950170-22-011708:notes:320]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Arrow Electronics, Inc. |  |  | 10 | % |  |  | 10 | % |
| Tech Data Corporation |  |  | 19 | % |  |  | 21 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-22-011708:notes:321]
16. Employee Benefits and Deferred Compensation

[0000950170-22-011708:notes:322]
Employee 401(k) Plan

[0000950170-22-011708:notes:323]
Our 401(k) Plan is a deferred salary arrangement under Section 401(k) of the Internal Revenue Code. Under the 401(k) Plan, participating U.S. employees may defer a portion of their pre-tax earnings, up to the IRS annual contribution limit. We match 100% of the first 2% of eligible earnings an employee contributes to the 401(k) Plan, and then match 50% of the next 4% of eligible earnings an employee contributes. An employee receives the full 4% match when he/she contributes at least 6% of his/her eligible earnings, up

[0000950170-22-011708:notes:324]
to a maximum calendar year matching contribution of $6,000. Our employer matching contributions to the 401(k) Plan were as follows (in millions):

[0000950170-22-011708:notes:325]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| 401(k) matching contributions |  | $ | 31 |  |  | $ | 29 |  |  | $ | 29 |  |

[0000950170-22-011708:notes:326]
Deferred Compensation Plan

[0000950170-22-011708:notes:327]
We have a non-qualified deferred compensation plan that allows a group of employees within the U.S. to contribute base salary and commissions or incentive compensation on a tax deferred basis in excess of the IRS limits imposed on 401(k) plans. The marketable securities related to these investments are held in a Rabbi Trust. The related deferred compensation plan assets and liabilities under the non-qualified deferred compensation plan were as follows (in millions):

[0000950170-22-011708:notes:328]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Deferred compensation plan assets |  | $ | 36 |  |  | $ | 40 |  |
| Deferred compensation liabilities reported as: |  |  |  |  |  |  |
| Accrued expenses |  | $ | 6 |  |  | $ | 8 |  |
| Other long-term liabilities |  | $ | 30 |  |  | $ | 32 |  |

[0000950170-22-011708:notes:329]
Defined Benefit Plans

[0000950170-22-011708:notes:330]
We maintain various defined benefit plans to provide termination and postretirement benefits to certain eligible employees outside of the U.S. We also provide disability benefits to certain eligible employees in the U.S. Eligibility is determined based on the terms of our plans and local statutory requirements.

[0000950170-22-011708:notes:331]
The funded status of our defined benefit plans, which is recognized in other long-term liabilities in our consolidated balance sheets, was as follows (in millions):

[0000950170-22-011708:notes:332]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Fair value of plan assets |  | $ | 39 |  |  | $ | 38 |  |
| Benefit obligations |  |  | (69 | ) |  |  | (72 | ) |
| Unfunded obligations |  | $ | (30 | ) |  | $ | (34 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-22-011708:notes:333]
17. Commitments and Contingencies

[0000950170-22-011708:notes:334]
Purchase Orders and Other Commitments

[0000950170-22-011708:notes:335]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. A significant portion of our reported purchase commitments arising from these agreements consist of firm, non-cancelable, and unconditional commitments. As of April 29, 2022, we had $894 million in non-cancelable purchase commitments for inventory. We record a liability for firm, non-cancelable and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 29, 2022 and April 30, 2021, such liability amounted to $18 million and $15 million, respectively, and is included in accrued expenses in our consolidated balance sheets. To the extent that such forecasts are not achieved, our commitments and associated accruals may change.

[0000950170-22-011708:notes:336]
In addition to inventory commitments with contract manufacturers and component suppliers, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. As of April 29, 2022, we had $296 million in other purchase obligations.

[0000950170-22-011708:notes:337]
Of the total $1.2 billion in purchase commitments, $0.9 billion is due in fiscal 2023, with the remainder due thereafter.

[0000950170-22-011708:notes:338]
Financing Guarantees

[0000950170-22-011708:notes:339]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true

[0000950170-22-011708:notes:340]
sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. Provided all other revenue recognition criteria have been met, we recognize product revenues for these arrangements, net of any payment discounts from financing transactions, upon product acceptance. We sold $59 million, $102 million and $59 million of receivables during fiscal 2022, 2021 and 2020, respectively.

[0000950170-22-011708:notes:341]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user and we recognize revenue upon delivery to the end-user customer, if all other revenue recognition criteria have been met.

[0000950170-22-011708:notes:342]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. Where we provide a guarantee for recourse leases and collectability is probable, we account for these transactions as sales type leases. If collectability is not probable, the cash received is recorded as a deposit liability and revenue is deferred until the arrangement is deemed collectible. For leases that we are not a party to, other than providing recourse, we recognize revenue when control is transferred. As of April 29, 2022 and April 30, 2021, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-22-011708:notes:343]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid financing payments under such arrangements. As of April 29, 2022, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0000950170-22-011708:notes:344]
Legal Contingencies

[0000950170-22-011708:notes:345]
When a loss is considered probable and reasonably estimable, we record a liability in the amount of our best estimate for the ultimate loss. However, the likelihood of a loss with respect to a particular contingency is often difficult to predict and determining a meaningful estimate of the loss or a range of loss may not be practicable based on the information available and the potential effect of future events and decisions by third parties that will determine the ultimate resolution of the contingency.

[0000950170-22-011708:notes:346]
On August 14, 2019, a purported securities class action lawsuit was filed in the United States District Court for the Northern District of California, naming as defendants NetApp and certain of our executive officers. The complaint alleges that the defendants violated Section 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and SEC Rule 10b-5, by making materially false or misleading statements with respect to our financial guidance for fiscal 2020, as provided on May 22, 2019. Members of the alleged class are purchasers of the Company’s stock between May 22, 2019 and August 1, 2019, the date we provided revised financial guidance for fiscal 2020. The complaint alleges unspecified damages based on the decline in the market price of our shares following the issuance of the revised guidance on August 1, 2019. The defendants' Motion to Dismiss was granted and on February 26, 2021 and the judge entered judgment in favor of NetApp and the other defendants. On March 26, 2021, plaintiffs filed a notice of appeal. The parties subsequently engaged in settlement discussions, and on July 30, 2021 entered into a Memorandum of Understanding (MOU) providing for the settlement of the class action. Pursuant to the terms of the MOU, NetApp has agreed to pay approximately $2.0 million in connection with the settlement, and this amount was accrued during the three months ended July 30, 2021. The parties subsequently executed a stipulation of settlement, which contains no admission of liability, wrongdoing or responsibility by any of the parties, and which provides that the class action will be dismissed with prejudice, with mutual releases by all parties, upon final court approval. On September 24, 2021, plaintiff filed an unopposed motion seeking court approval of the settlement. On May 2, 2022, the court preliminarily approved the settlement, subject to further consideration at a final approval hearing, which is scheduled to be held on September 1, 2022.  The court’s approval of settlement will remain preliminary pending the outcome of the final approval hearing.

[0000950170-22-011708:notes:347]
We are subject to various other legal proceedings and claims that arise in the normal course of business. We may, from time to time, receive claims that we are infringing third parties’ intellectual property rights, including claims for alleged patent infringement brought by non-practicing entities. We are currently involved in patent litigations brought by non-practicing entities and other third parties. We believe we have strong arguments that our products do not infringe and/or the asserted patents are invalid, and we intend to vigorously defend against the plaintiffs’ claims. However, there is no guarantee that we will prevail at trial and if a jury were to find that our products infringe, we could be required to pay significant monetary damages, and may cause product shipment delays or stoppages, require us to redesign our products, or require us to enter into royalty or licensing agreements.

[0000950170-22-011708:notes:348]
Although management at present believes that the ultimate outcome of these proceedings, individually and in the aggregate, will not materially harm our financial position, results of operations, cash flows, or overall trends, legal proceedings are subject to inherent uncertainties, and unfavorable rulings or other events could occur. Unfavorable resolutions could include significant monetary damages. In addition, in matters for which injunctive relief or other conduct remedies are sought, unfavorable resolutions could include an injunction or other order prohibiting us from selling one or more products at all or in particular ways or requiring other remedies. An unfavorable outcome may result in a material adverse impact on our business, results of operations, financial position, cash flows and overall trends. No material accrual has been recorded as of April 29, 2022 related to such matters.


## us-gaap:SubsequentEventsTextBlock

[0000950170-22-011708:notes:349]
18. Subsequent Event

[0000950170-22-011708:notes:350]
On May 20, 2022, we acquired all the outstanding shares of privately-held Instaclustr, Inc., a leading platform provider of fully managed open-source database, pipeline and workflow applications delivered as a service. We are in the process of completing the allocation of approximately $500 million of cash purchase price among the assets acquired and liabilities assumed.
