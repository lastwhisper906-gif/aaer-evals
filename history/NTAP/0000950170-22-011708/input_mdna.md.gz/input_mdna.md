# NTAP MD&A — 0000950170-22-011708


## mdna

[0000950170-22-011708:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000950170-22-011708:mdna:2]
The following discussion of our financial condition and results of operations should be read together with the financial statements and the accompanying notes set forth under Item 8. – Financial Statements and Supplementary Data. The following discussion also contains trend information and other forward-looking statements that involve a number of risks and uncertainties. The Risk Factors set forth in Item 1A. – Risk Factors are hereby incorporated into the discussion by reference.

[0000950170-22-011708:mdna:3]
Executive Overview

[0000950170-22-011708:mdna:4]
Our Company

[0000950170-22-011708:mdna:5]
NetApp is a global cloud-led, data-centric software company that gives organizations the freedom to put data to work in the applications that elevate their business. We help our customers get the most out of their data with industry-leading public cloud services, and hybrid cloud solutions. Building on a rich history of innovation, we give customers the freedom to manage applications and data across hybrid multicloud environments. No matter where a customer’s data is or how the business uses it, NetApp helps to bring it together in a data fabric. For nearly three decades, NetApp has supported customers to accelerate their unique data fabrics and extend their workflows into a hybrid cloud environment with the right tools and right capabilities.

[0000950170-22-011708:mdna:6]
As our products and solutions portfolios evolve, market dynamics change, and management continues to assess our largest opportunities, we periodically change how we manage our business. As of the end of our first quarter of fiscal 2022, our Chief Operating Decision Maker (CODM), who is our Chief Executive Officer, realigned internal reporting and began using financial information for components of our business, organized based on category of product/solution, to evaluate performance and allocate resources. This resulted in the creation of two reportable segments for financial reporting purposes: Hybrid Cloud and Public Cloud. Our CODM measures the performance of each segment based on segment revenue and segment gross profit.

[0000950170-22-011708:mdna:7]
Hybrid Cloud offers a portfolio of storage management and infrastructure solutions that help customers recast their data centers with the power of cloud. This portfolio is designed to operate with public clouds to unlock the potential of hybrid, multi-cloud operations. We offer a broad portfolio of cloud-connected all-flash, hybrid-flash, and object storage systems, powered by intelligent data management software. Hybrid Cloud is composed of software, hardware, and related support, as well as professional and other services.

[0000950170-22-011708:mdna:8]
Public Cloud offers a portfolio of products delivered primarily as-a-service, including related support. This portfolio includes cloud storage and data services, and cloud operations services. Our enterprise-class solutions and services enable customers to control and manage storage in the cloud, consume high-performance storage services for primary workloads, and optimize cloud environments for cost and efficiency. These solutions and services are generally available on the leading public clouds, including Microsoft Azure, Google Cloud Platform and Amazon AWS.

[0000950170-22-011708:mdna:9]
Global Business Environment

[0000950170-22-011708:mdna:10]
Macroeconomic Conditions

[0000950170-22-011708:mdna:11]
Continuing global economic uncertainty, political conditions and fiscal challenges in the U.S. and abroad could result in adverse macroeconomic conditions, including inflation, slower growth or recession. In particular, in fiscal 2022, we experienced inflationary pressure and constraints in our supply chain.

[0000950170-22-011708:mdna:12]
Supply chain constraints, particularly in the second half of fiscal 2022, led to higher product component and freight costs which increased our cost of revenues. Supply chain constraints also delayed our ability to fulfill certain customer orders during the fiscal year. Given the uncertainties that exist in the broader technology supply chain, we are continuing to invest in inventory and certain longer-term commitments to help mitigate the impact of supply shortages.

[0000950170-22-011708:mdna:13]
If these macroeconomic uncertainties or supply chain challenges persist or worsen in fiscal 2023, we may observe reduced customer demand for our offerings, increased competition for critical components, challenges fulfilling certain customer orders or continued increases in component and freight costs which could impact our operating results, including our ability to achieve historical levels of revenue growth.

[0000950170-22-011708:mdna:14]
COVID-19

[0000950170-22-011708:mdna:15]
The COVID-19 pandemic and efforts to control its spread have significantly curtailed the movement of people, goods and services worldwide, including in many of the regions in which we sell our products and services and conduct our business operations. We have taken precautionary measures intended to minimize the risk of the virus to our employees, our customers, and the communities in which we operate. Since March 2020, the vast majority of our employees have been working remotely and we have limited business

[0000950170-22-011708:mdna:16]
travel. As a result of COVID-19, we continued to observe certain customers delaying purchases of our products and services, while other customers accelerated or placed new orders to address the demands of remote working and digital business.

[0000950170-22-011708:mdna:17]
Russia Sanctions

[0000950170-22-011708:mdna:18]
Beginning in February 2022, in response to Russian military actions in Ukraine, the U.S. and other countries imposed sanctions on Russia, and we suspended business operations, including sales, support on existing contracts and professional services, in Russia and Belarus. The impact of these actions was not significant to our fiscal 2022 financial results. However, their ultimate magnitude and duration remain uncertain, and we will continue to closely monitor their potential impacts to our business.

[0000950170-22-011708:mdna:19]
The magnitude and duration of the disruption to our business, and impact to our operational and financial performance of the factors above remain uncertain. Refer to Item 1A. – Risk Factors for the significant risks we have identified related to the global business environment.

[0000950170-22-011708:mdna:20]
Financial Results and Key Performance Metrics Overview

[0000950170-22-011708:mdna:21]
The following table provides an overview of key financial metrics for each of the last three fiscal years (in millions, except per share amounts and percentages):

[0000950170-22-011708:mdna:22]
|  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 24, 2020 |  |
| Net revenues |  | $ | 6,318 |  |  | $ | 5,744 |  |  | $ | 5,412 |  |
| Gross profit |  | $ | 4,220 |  |  | $ | 3,815 |  |  | $ | 3,623 |  |
| Gross profit margin percentage |  |  | 67 | % |  |  | 66 | % |  |  | 67 | % |
| Income from operations |  | $ | 1,157 |  |  | $ | 1,031 |  |  | $ | 945 |  |
| Income from operations as a percentage of net revenues |  |  | 18 | % |  |  | 18 | % |  |  | 17 | % |
| Provision for income taxes |  | $ | 158 |  |  | $ | 232 |  |  | $ | 125 |  |
| Net income |  | $ | 937 |  |  | $ | 730 |  |  | $ | 819 |  |
| Diluted net income per share |  | $ | 4.09 |  |  | $ | 3.23 |  |  | $ | 3.52 |  |
| Net cash provided by operating activities |  | $ | 1,211 |  |  | $ | 1,333 |  |  | $ | 1,060 |  |

[0000950170-22-011708:mdna:23]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Deferred revenue and financed unearned services revenue |  | $ | 4,232 |  |  | $ | 4,003 |  |

[0000950170-22-011708:mdna:24]
•
Net revenues: Our net revenues increased 10% in fiscal 2022 compared to fiscal 2021, due to an increase in both product revenues and services revenues, with the latter primarily driven by an increase in public cloud revenues.

[0000950170-22-011708:mdna:25]
•
Gross profit margin percentage: Our gross profit margin as a percentage of net revenues increased less than one percentage point in fiscal 2022 compared to fiscal 2021 primarily due to a slight increase in gross profit margins on product revenues.

[0000950170-22-011708:mdna:26]
•
Income from operations as a percentage of net revenues: Our income from operations as a percentage of net revenues increased by less than one percentage point in fiscal 2022 compared to fiscal 2021, primarily due to a slightly higher gross profit margin percentage and lower sales and marketing, research and development, and general and administrative expenses as a percentage of net revenues, partially offset by the gain on sale of certain properties in fiscal 2021 that did not recur in fiscal 2022.

[0000950170-22-011708:mdna:27]
•
Provision for income taxes: Our provision for income taxes decreased in fiscal 2022 compared to fiscal 2021 primarily due to  one-time benefits in fiscal 2022 related to the prepayment of certain intercompany expenses.

[0000950170-22-011708:mdna:28]
•
Net income and Diluted net income per share: The increase in both net income and diluted net income per share in fiscal 2022 compared to fiscal 2021 reflect the factors discussed above. Higher net income and increased share repurchases in fiscal year 2022 compared to fiscal 2021 favorably impacted diluted net income per share.

[0000950170-22-011708:mdna:29]
•
Operating cash flows: Operating cash flows decreased by 8% in fiscal 2022 compared to fiscal 2021, primarily reflecting the timing of accounts receivables billings and collections and employee compensation payments, partially offset by higher net income.

[0000950170-22-011708:mdna:30]
•
Deferred revenue and financed unearned services revenue: Total deferred revenue and financed unearned services revenue increased $229 million, or 6%, as of fiscal 2022 compared to fiscal 2021 due to an increase in the aggregate contract value under software and hardware support contracts, primarily reflecting a higher mix of all-flash systems which carry a higher support dollar content than our other products.

[0000950170-22-011708:mdna:31]
35

[0000950170-22-011708:mdna:32]
Stock Repurchase Program and Dividend Activity

[0000950170-22-011708:mdna:33]
During fiscal 2022, we repurchased approximately 7 million shares of our common stock at an average price of $84.49 per share, for an aggregate purchase price of $600 million. We also declared aggregate cash dividends of $2.00 per share in fiscal 2022, for which we paid a total of $446 million.

[0000950170-22-011708:mdna:34]
Acquisitions

[0000950170-22-011708:mdna:35]
On May 20, 2022, in the first quarter of fiscal 2023, we acquired all the outstanding shares of privately-held Instaclustr, Inc., a leading platform provider of fully managed open-source database, pipeline and workflow applications delivered as a service, for approximately $500 million.

[0000950170-22-011708:mdna:36]
On February 18, 2022, we acquired all the outstanding shares of privately-held NeurOps Inc. (which operated under the name "Fylamynt"), for approximately $27 million. Fylamynt is an innovative CloudOps automation technology company that enables customers to build, run, manage and analyze workflows securely in any cloud with little to no code.

[0000950170-22-011708:mdna:37]
On November 5, 2021, we acquired all the outstanding shares of privately-held CloudCheckr Inc., (CloudCheckr) for approximately $347 million. CloudCheckr is a leading cloud optimization platform that provides cloud visibility and insights to lower costs, maintain security and compliance, and optimize cloud resources.

[0000950170-22-011708:mdna:38]
On June 18, 2021, we acquired all the outstanding shares of privately-held Data Mechanics Inc., a provider of managed platforms for big data processing and cloud analytics, for approximately $15 million.

[0000950170-22-011708:mdna:39]
Restructuring Events

[0000950170-22-011708:mdna:40]
During fiscal 2022, we executed several restructuring plans and recognized expenses totaling $33 million consisting primarily of lease termination fees, office relocation costs, and employee severance-related costs.

[0000950170-22-011708:mdna:41]
Results of Operations

[0000950170-22-011708:mdna:42]
Our fiscal year is reported on a 52- or 53-week year that ends on the last Friday in April. An additional week is included in the first fiscal quarter approximately every six years to realign fiscal months with calendar months. Fiscal year 2022, which ended on April 29, 2022, and fiscal year 2020, which ended on April 24, 2020 were both 52-week years. Fiscal year 2021, which ended on April 30, 2021 was a 53-week year, with 14 weeks included in its first quarter and 13 weeks in each subsequent quarter. Unless otherwise stated, references to particular years, quarters, months and periods refer to our fiscal years ended in April and the associated quarters, months and periods of those fiscal years.

[0000950170-22-011708:mdna:43]
The following table sets forth certain Consolidated Statements of Income data as a percentage of net revenues for the periods indicated:

[0000950170-22-011708:mdna:44]
|  |  | Fiscal Year |  |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 52 | % |  |  | 52 | % |  |  | 55 | % |  |
| Services |  |  | 48 |  |  |  | 48 |  |  |  | 45 |  |  |
| Net revenues |  |  | 100 |  |  |  | 100 |  |  |  | 100 |  |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 25 |  |  |  | 25 |  |  |  | 25 |  |  |
| Cost of services |  |  | 9 |  |  |  | 9 |  |  |  | 8 |  |  |
| Gross profit |  |  | 67 |  |  |  | 66 |  |  |  | 67 |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 29 |  |  |  | 30 |  |  |  | 29 |  |  |
| Research and development |  |  | 14 |  |  |  | 15 |  |  |  | 16 |  |  |
| General and administrative |  |  | 4 |  |  |  | 4 |  |  |  | 5 |  |  |
| Restructuring charges |  |  | 1 |  |  |  | 1 |  |  |  | — |  |  |
| Acquisition-related expense |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (3 | ) |  |  | (1 | ) |  |
| Total operating expenses |  |  | 48 |  |  |  | 48 |  |  |  | 49 |  |  |
| Income from operations |  |  | 18 |  |  |  | 18 |  |  |  | 17 |  |  |
| Other expense, net |  |  | (1 | ) |  |  | (1 | ) |  |  | — |  |  |
| Income before income taxes |  |  | 17 |  |  |  | 17 |  |  |  | 17 |  |  |
| Provision for income taxes |  |  | 3 |  |  |  | 4 |  |  |  | 2 |  |  |
| Net income |  |  | 15 | % |  |  | 13 | % |  |  | 15 | % |  |

[0000950170-22-011708:mdna:45]
Percentages may not add due to rounding

[0000950170-22-011708:mdna:46]
Discussion and Analysis of Results of Operations

[0000950170-22-011708:mdna:47]
Net Revenues (in millions, except percentages):

[0000950170-22-011708:mdna:48]
|  |  |  | Fiscal Year |  |
|  |  |  | 2022 |  |  | 2021 |  |  | % Change |  |  | 2020 |  |  | % Change |  |
| Net revenues |  |  | $ | 6,318 |  |  | $ | 5,744 |  |  |  | 10 | % |  | $ | 5,412 |  |  |  | 6 | % |

[0000950170-22-011708:mdna:49]
The increase in net revenues for fiscal 2022 compared to fiscal 2021 was due to an increase in both product revenues and services revenues, with revenues increasing despite the additional week in fiscal 2021. Product revenues and services revenues as a percentage of net revenues both remained relatively consistent in fiscal 2022 compared to fiscal 2021.

[0000950170-22-011708:mdna:50]
The increase in net revenues for fiscal 2021 compared to fiscal 2020 was primarily due to an increase in services revenues, which benefited from an additional week in the first quarter of fiscal 2021, while product revenues were relatively flat. Product revenues as a percentage of net revenues decreased by approximately three percentage points compared to fiscal 2020. Fluctuations in foreign currency exchange rates benefited net revenues by approximately one percentage point for fiscal 2021 compared to fiscal 2020.

[0000950170-22-011708:mdna:51]
Sales through our indirect channels represented 77%, 77% and 79% of net revenues in fiscal 2022, 2021 and 2020, respectively.

[0000950170-22-011708:mdna:52]
The following customers, each of which is a distributor, accounted for 10% or more of net revenues:

[0000950170-22-011708:mdna:53]
37

[0000950170-22-011708:mdna:54]
|  |  | Fiscal Year |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Arrow Electronics, Inc. |  |  | 24 | % |  |  | 24 | % |  |  | 25 | % |
| Tech Data Corporation |  |  | 21 | % |  |  | 20 | % |  |  | 21 | % |

[0000950170-22-011708:mdna:55]
Product Revenues (in millions, except percentages):

[0000950170-22-011708:mdna:56]
|  |  |  | Fiscal Year |  |
|  |  |  | 2022 |  |  | 2021 |  |  | % Change |  |  | 2020 |  |  | % Change |  |
| Product revenues |  |  | $ | 3,284 |  |  | $ | 2,991 |  |  |  | 10 | % |  | $ | 2,995 |  |  |  | — | % |
| Hardware (Non-GAAP) |  |  |  | 1,358 |  |  |  | 1,355 |  |  |  | — | % |  |  | 1,541 |  |  |  | (12 | )% |
| Software (Non-GAAP) |  |  |  | 1,926 |  |  |  | 1,636 |  |  |  | 18 | % |  |  | 1,454 |  |  |  | 13 | % |

[0000950170-22-011708:mdna:57]
Hybrid Cloud

[0000950170-22-011708:mdna:58]
Product revenues are derived through the sale of our Hybrid Cloud solutions and consist of sales of configured all-flash array and hybrid systems, which are bundled hardware and software products, as well as add-on flash, disk and/or hybrid storage and related OS, NetApp HCI, StorageGrid, OEM products and add-on optional software.

[0000950170-22-011708:mdna:59]
In order to provide visibility into the value created by our software innovation and R&D investment, we disclose the software and hardware components of our product revenues. Software product revenues includes the OS software and optional add-on software solutions attached to our systems across our entire product set, while hardware product revenues include the non-software component of our systems across the entire set. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, the hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0000950170-22-011708:mdna:60]
Total product revenues increased in fiscal 2022 compared to fiscal 2021, primarily driven by an increase in sales of all-flash array systems and, to a lesser extent, an increase in sales of StorageGrid, partially offset by a decrease in sales of NetApp HCI. Supply chain challenges related to the COVID-19 pandemic impeded our ability to fulfill certain customer orders in fiscal 2022, particularly in the fourth quarter.

[0000950170-22-011708:mdna:61]
Total product revenues were relatively flat in fiscal 2021 compared to fiscal 2020, suffering from less favorable macroeconomic conditions through most of fiscal 2021, in part due to the economic uncertainty caused by the COVID-19 pandemic, but then improving in the last quarter of fiscal 2021. Sales of all-flash array systems increased in fiscal 2021, though this increase was offset by a decline in sales of our other products. Fluctuations in foreign currency exchange rates benefited product revenues by approximately one percentage point for fiscal 2021 compared to fiscal 2020.

[0000950170-22-011708:mdna:62]
Revenues from the hardware component of product revenues represented 41%, 45% and 51% of product revenues in fiscal 2022, 2021 and 2020, respectively. The software component of product revenues represented 59%, 55% and 49% of product revenues in fiscal 2022, 2021 and 2020, respectively. The increase in the software component percentage of product revenues in both fiscal 2022 and fiscal 2021 is primarily due to a higher mix of all-flash array systems sales, which contain a higher proportion of software components than other Hybrid Cloud products.

[0000950170-22-011708:mdna:63]
Services Revenues (in millions, except percentages):

[0000950170-22-011708:mdna:64]
|  |  |  | Fiscal Year |  |
|  |  |  | 2022 |  |  | 2021 |  |  | % Change |  |  | 2020 |  |  | % Change |  |
| Services revenues |  |  | $ | 3,034 |  |  | $ | 2,753 |  |  |  | 10 | % |  | $ | 2,417 |  |  |  | 14 | % |
| Support |  |  |  | 2,344 |  |  |  | 2,277 |  |  |  | 3 | % |  |  | 2,114 |  |  |  | 8 | % |
| Professional and other services |  |  |  | 294 |  |  |  | 277 |  |  |  | 6 | % |  |  | 241 |  |  |  | 15 | % |
| Public cloud |  |  |  | 396 |  |  |  | 199 |  |  |  | 99 | % |  |  | 62 |  |  |  | 221 | % |

[0000950170-22-011708:mdna:65]
Hybrid Cloud

[0000950170-22-011708:mdna:66]
Hybrid Cloud services revenues are derived from the sale of: (1) support, which includes both hardware and software support contracts (the latter of which entitle customers to receive unspecified product upgrades and enhancements, bug fixes and patch releases), and (2) professional and other services, which include customer education and training.

[0000950170-22-011708:mdna:67]
Support revenues increased in fiscal 2022 compared to fiscal 2021, despite an extra week in the first quarter of fiscal 2021 that contributed approximately $40 million of additional revenues in that period. The increase is primarily due to a higher mix of all-flash systems, which carry a higher support dollar content than our other products, in the current year. The increase in fiscal 2021 compared to fiscal 2020 was partially due to the additional week in that period. Both periods benefitted from a higher aggregate contract value of the installed base under support contracts.

[0000950170-22-011708:mdna:68]
Professional and other services revenues increased in fiscal 2022 compared to fiscal 2021 primarily due to an increase in demand from increased product sales. The increase in fiscal 2021 compared to fiscal 2020 was primarily due to the additional week in that period and general increase in customer demand for such services.

[0000950170-22-011708:mdna:69]
Public Cloud

[0000950170-22-011708:mdna:70]
Public Cloud revenues are derived from the sale of public cloud offerings primarily delivered as-a-service, which include cloud storage and data services, and cloud operations services.

[0000950170-22-011708:mdna:71]
Public Cloud revenues increased in fiscal 2022 and fiscal 2021 compared to the respective prior years primarily due to growing customer demand for NetApp's diversified cloud offerings, coupled with overall growth in the cloud market, and the acquisition of Spot, Inc. (Spot) late in the first quarter of fiscal 2021. Fiscal 2022 also benefitted from the acquisition of CloudCheckr early in the third quarter of that year.

[0000950170-22-011708:mdna:72]
Revenues by Geographic Area:

[0000950170-22-011708:mdna:73]
|  |  | Fiscal Year |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| United States, Canada and Latin America (Americas) |  |  | 55 | % |  |  | 54 | % |  |  | 53 | % |
| Europe, Middle East and Africa (EMEA) |  |  | 31 | % |  |  | 31 | % |  |  | 32 | % |
| Asia Pacific (APAC) |  |  | 14 | % |  |  | 15 | % |  |  | 15 | % |

[0000950170-22-011708:mdna:74]
Percentages may not add due to rounding

[0000950170-22-011708:mdna:75]
Americas revenues consist of sales to Americas commercial and United States (U.S.) public sector markets. Demand across geographies was relatively consistent across all periods presented.

[0000950170-22-011708:mdna:76]
Cost of Revenues

[0000950170-22-011708:mdna:77]
Our cost of revenues consists of:

[0000950170-22-011708:mdna:78]
(1) cost of product revenues, composed of (a) cost of Hybrid Cloud product revenues, which includes the costs of manufacturing and shipping our products, inventory write-downs, and warranty costs, and (b) unallocated cost of product revenues, which includes stock-based compensation and amortization of intangibles, and;

[0000950170-22-011708:mdna:79]
(2) cost of services revenues, composed of (a) cost of support revenues, which includes the costs of providing support activities for hardware and software support, global support partnership programs, and third party royalty costs, (b) cost of professional and other services revenues, (c) cost of public cloud revenues, constituting the cost of providing our Public Cloud offerings which includes depreciation and amortization expense and third party datacenter fees, and (d) unallocated cost of services revenues, which includes stock-based compensation and amortization of intangibles.

[0000950170-22-011708:mdna:80]
Cost of Product Revenues (in millions, except percentages):

[0000950170-22-011708:mdna:81]
|  |  |  | Fiscal Year |  |
|  |  |  | 2022 |  |  | 2021 |  |  | % Change |  |  | 2020 |  |  | % Change |  |
| Cost of product revenues |  |  | $ | 1,554 |  |  | $ | 1,432 |  |  |  | 9 | % |  | $ | 1,368 |  |  |  | 5 | % |
| Hybrid Cloud |  |  |  | 1,541 |  |  |  | 1,402 |  |  |  | 10 | % |  |  | 1,326 |  |  |  | 6 | % |
| Unallocated |  |  |  | 13 |  |  |  | 30 |  |  |  | (57 | )% |  |  | 42 |  |  |  | (29 | )% |

[0000950170-22-011708:mdna:82]
Hybrid Cloud

[0000950170-22-011708:mdna:83]
Cost of Hybrid Cloud product revenues represented 47%, 47% and 44% of Hybrid Cloud product revenues in fiscal 2022, 2021 and 2020, respectively. Materials costs represented 93%, 91% and 89% of cost of Hybrid Cloud product revenues in fiscal 2022, 2021 and 2020, respectively.

[0000950170-22-011708:mdna:84]
Materials costs increased by approximately $156 million in fiscal 2022 compared to fiscal 2021 reflecting the increase in product revenues in the current year period, the mix of systems sold, and higher component and freight costs as a result of COVID-19 related supply chain challenges. Excess and obsolete inventory reserves were lower in fiscal 2022 compared to fiscal 2021.

[0000950170-22-011708:mdna:85]
Hybrid Cloud product gross margins remained relatively flat in fiscal 2022 compared to fiscal 2021 despite the increase in component and freight costs, which were offset primarily by a higher mix of all-flash array systems sales, which have higher margins than hybrid systems. We anticipate the increase in component and freight costs related to supply chain challenges will continue to impact gross margins into fiscal year 2023.

[0000950170-22-011708:mdna:86]
Materials costs increased by approximately $96 million in fiscal 2021 compared to fiscal 2020. The trend in product mix toward all-flash array systems, which have higher margins, but carry higher materials costs than hybrid systems, was the primary driver of these increases. Excess and obsolete inventory reserves and warranty expenses were lower in fiscal 2021 compared to fiscal 2020.

[0000950170-22-011708:mdna:87]
Hybrid Cloud product gross margins decreased by two percentage points in fiscal 2021 compared to fiscal 2020 primarily due to a decrease in the average selling prices of most of our products, partially offset by a higher mix of all-flash array product sales.

[0000950170-22-011708:mdna:88]
Unallocated

[0000950170-22-011708:mdna:89]
Unallocated cost of product revenues decreased in fiscal 2022 and in fiscal 2021 compared to the prior year of each respective period due to certain intangible assets becoming fully amortized in the second half of fiscal 2021.

[0000950170-22-011708:mdna:90]
Cost of Services Revenues (in millions, except percentages):

[0000950170-22-011708:mdna:91]
|  |  |  | Fiscal Year |  |
|  |  |  | 2022 |  |  | 2021 |  |  | % Change |  |  | 2020 |  |  | % Change |  |
| Cost of services revenues |  |  | $ | 544 |  |  | $ | 497 |  |  |  | 9 | % |  | $ | 421 |  |  |  | 18 | % |
| Support |  |  |  | 184 |  |  |  | 201 |  |  |  | (8 | )% |  |  | 188 |  |  |  | 7 | % |
| Professional and other services |  |  |  | 205 |  |  |  | 206 |  |  |  | — | % |  |  | 188 |  |  |  | 10 | % |
| Public cloud |  |  |  | 118 |  |  |  | 65 |  |  |  | 82 | % |  |  | 35 |  |  |  | 86 | % |
| Unallocated |  |  |  | 37 |  |  |  | 25 |  |  |  | 48 | % |  |  | 10 |  |  |  | 150 | % |

[0000950170-22-011708:mdna:92]
Hybrid Cloud

[0000950170-22-011708:mdna:93]
Cost of Hybrid Cloud services revenues, which are composed of the costs of support and professional and other services, decreased in fiscal 2022 compared to fiscal 2021 and increased in fiscal 2021 compared to fiscal 2020. Cost of Hybrid Cloud services revenues represented 15%, 16% and 16% of Hybrid Cloud services revenues in fiscal 2022, 2021 and 2020, respectively.

[0000950170-22-011708:mdna:94]
Hybrid Cloud support gross margins increased by one percentage point in fiscal 2022 compared to fiscal 2021 due to growth in support revenues achieved with a consistent cost base. Hybrid Cloud support gross margins remained relatively flat in fiscal 2021 compared to fiscal 2020.

[0000950170-22-011708:mdna:95]
Hybrid Cloud professional services gross margins increased by five percentage points in fiscal 2022 compared to fiscal 2021 and increased four percentage points in fiscal 2021 compared to fiscal 2020. The increases in both periods are primarily due to the mix of services provided.

[0000950170-22-011708:mdna:96]
Public Cloud

[0000950170-22-011708:mdna:97]
Cost of Public Cloud revenues increased in fiscal 2022 and in fiscal 2021 compared to the respective prior years, reflecting the ongoing growth in Public Cloud revenues in each period. Public Cloud gross margins increased by three percentage points in fiscal 2022 compared to fiscal 2021 and twenty-four percentage points in fiscal 2021 compared to fiscal 2020, reflecting efficiencies from scaling our Public Cloud segment.

[0000950170-22-011708:mdna:98]
Unallocated

[0000950170-22-011708:mdna:99]
Unallocated cost of services revenues increased in fiscal 2022 and in fiscal 2021 compared to the respective prior years, due to our acquisitions of CloudCheckr in the third quarter of fiscal 2022 and Spot in the first quarter of fiscal 2021, which resulted in higher amortization expense from acquired intangible assets.

[0000950170-22-011708:mdna:100]
Operating Expenses

[0000950170-22-011708:mdna:101]
Sales and Marketing, Research and Development and General and Administrative Expenses

[0000950170-22-011708:mdna:102]
Sales and marketing, research and development, and general and administrative expenses for fiscal 2022 totaled $3,017 million, or 48% of net revenues, representing a decrease of two percentage points compared to fiscal 2021. Sales and marketing, research and development, and general and administrative expenses for fiscal 2021 totaled $2,882 million, or 50% of net revenues, remaining relatively flat in percentage points as compared to fiscal 2020.

[0000950170-22-011708:mdna:103]
Compensation costs represent the largest component of operating expenses. Included in compensation costs are salaries, benefits, other compensation-related costs, stock-based compensation expense and employee incentive compensation plan costs.

[0000950170-22-011708:mdna:104]
Total compensation costs included in operating expenses increased by $74 million, or 4%, during fiscal 2022 compared to fiscal 2021, primarily due to higher salaries, benefits and stock-based compensation expenses, reflecting a 3% increase in average headcount. This increase was partially offset by lower incentive compensation expense. Total compensation costs for fiscal 2021 includes the impact of an additional week in the first quarter of fiscal 2021.

[0000950170-22-011708:mdna:105]
Total compensation costs included in operating expenses increased by $225 million, or 15% during fiscal 2021 compared to fiscal 2020, primarily reflecting higher incentive compensation expense, a 3% increase in average headcount and the impact of one additional week in the first quarter of fiscal 2021.

[0000950170-22-011708:mdna:106]
Sales and Marketing (in millions, except percentages):

[0000950170-22-011708:mdna:107]
|  |  |  | Fiscal Year |  |
|  |  |  | 2022 |  |  | 2021 |  |  | % Change |  |  | 2020 |  |  | % Change |  |
| Sales and marketing expenses |  |  | $ | 1,857 |  |  | $ | 1,744 |  |  |  | 6 | % |  | $ | 1,585 |  |  |  | 10 | % |

[0000950170-22-011708:mdna:108]
Sales and marketing expenses consist primarily of compensation costs, commissions, outside services, facilities and IT support costs, advertising and marketing promotional expense and travel and entertainment expense. The changes in sales and marketing expenses consisted of the following (in percentage points of the total change):

[0000950170-22-011708:mdna:109]
|  |  | Fiscal 2022 to Fiscal 2021 |  |  | Fiscal 2021 to Fiscal 2020 |  |
| Compensation costs |  |  | 4 |  |  |  | 9 |  |
| Commissions |  |  | 1 |  |  |  | 3 |  |
| Advertising and marketing promotional expense |  |  | — |  |  |  | 1 |  |
| Travel and entertainment |  |  | 1 |  |  |  | (4 | ) |
| Other |  |  | — |  |  |  | 1 |  |
| Total change |  |  | 6 |  |  |  | 10 |  |

[0000950170-22-011708:mdna:110]
The increase in compensation costs in fiscal 2022 compared to fiscal 2021 reflected an increase in average headcount of approximately 5%, partially offset by the impact of one less week in fiscal 2022. The expansion of our sales and marketing teams are expected to support our ability to execute on key market opportunities.

[0000950170-22-011708:mdna:111]
The increase in commissions expense in fiscal 2022 primarily reflected the increase in the average headcount of our sales team compared to fiscal 2021, partially offset by slightly lower attainment against sales goals than in fiscal 2021.

[0000950170-22-011708:mdna:112]
Advertising and marketing promotional expense remained relatively flat in fiscal 2022 compared to fiscal 2021, and increased in fiscal 2021 compared to fiscal 2020 primarily due to higher spending levels on certain projects executed in fiscal 2021. Travel and entertainment expenses increased slightly in fiscal 2022 compared to fiscal 2021 as travel restrictions related to the COVID-19 pandemic eased.

[0000950170-22-011708:mdna:113]
The increase in compensation costs in fiscal 2021 compared to fiscal 2020 reflected an increase in average headcount of 7%, with this expansion of our sales and marketing teams supporting our ability to execute on key market opportunities. Compensation costs for fiscal 2021 also reflected the impact of one additional week in the first quarter.

[0000950170-22-011708:mdna:114]
The increase in commissions expense for fiscal 2021 is primarily due to higher performance against sales goals than in fiscal 2020.  Travel and entertainment spend decreased significantly in fiscal 2021 compared to fiscal 2020 due to the COVID-19 pandemic.

[0000950170-22-011708:mdna:115]
Research and Development (in millions, except percentages):

[0000950170-22-011708:mdna:116]
|  |  |  | Fiscal Year |  |
|  |  |  | 2022 |  |  | 2021 |  |  | % Change |  |  | 2020 |  |  | % Change |  |
| Research and development expenses |  |  | $ | 881 |  |  | $ | 881 |  |  |  | — | % |  | $ | 847 |  |  |  | 4 | % |

[0000950170-22-011708:mdna:117]
Research and development expenses consist primarily of compensation costs, facilities and IT support costs, depreciation, equipment and software related costs, prototypes, non-recurring engineering charges and other outside services costs. Changes in research and development expense consisted of the following (in percentage points of the total change):

[0000950170-22-011708:mdna:118]
|  |  | Fiscal 2022 to Fiscal 2021 |  |  | Fiscal 2021 to Fiscal 2020 |  |
| Compensation costs |  |  | (1 | ) |  |  | 7 |  |
| Development projects and outside services |  |  | 1 |  |  |  | (1 | ) |
| Facilities and IT support costs |  |  | — |  |  |  | (1 | ) |
| Travel and entertainment |  |  | — |  |  |  | (1 | ) |
| Total change |  |  | — |  |  |  | 4 |  |

[0000950170-22-011708:mdna:119]
The decrease in compensation costs for fiscal 2022 compared to fiscal 2021 was primarily due to lower incentive compensation expense, while average headcount was relatively consistent in each period. Compensation costs for fiscal 2022 also reflected the impact of one less week in fiscal 2022. The increase in development projects and outside services during fiscal 2022 compared to fiscal 2021 was primarily due to the higher spending on certain engineering projects.

[0000950170-22-011708:mdna:120]
The increase in compensation costs during fiscal 2021 compared to fiscal 2020 was primarily due to higher incentive compensation expense, while average headcount was relatively consistent in each period. Compensation costs for fiscal 2021 also reflected the impact of one additional week in the first quarter. The decrease in development projects and outside services was primarily due to the lower spending on certain engineering projects. The decrease in facilities and IT support costs was primarily due to cost containment efforts, and lower travel and entertainment expense was due to the impact of the COVID-19 pandemic.

[0000950170-22-011708:mdna:121]
General and Administrative (in millions, except percentages):

[0000950170-22-011708:mdna:122]
|  |  |  | Fiscal Year |  |
|  |  |  | 2022 |  |  | 2021 |  |  | % Change |  |  | 2020 |  |  | % Change |  |
| General and administrative expenses |  |  | $ | 279 |  |  | $ | 257 |  |  |  | 9 | % |  | $ | 263 |  |  |  | (2 | )% |

[0000950170-22-011708:mdna:123]
General and administrative expenses consist primarily of compensation costs, professional and corporate legal fees, outside services and facilities and IT support costs. Changes in general and administrative expense consisted of the following (in percentage points of the total change):

[0000950170-22-011708:mdna:124]
|  |  | Fiscal 2022 to Fiscal 2021 |  |  | Fiscal 2021 to Fiscal 2020 |  |
| Compensation costs |  |  | 4 |  |  |  | 9 |  |
| Professional and legal fees and outside services |  |  | 4 |  |  |  | (14 | ) |
| Litigation settlement |  |  | — |  |  |  | 2 |  |
| Facilities and IT support costs |  |  | (1 | ) |  |  | 1 |  |
| Other |  |  | 2 |  |  |  | — |  |
| Total change |  |  | 9 |  |  |  | (2 | ) |

[0000950170-22-011708:mdna:125]
The increase in compensation costs in fiscal 2022 compared to fiscal 2021 were primarily attributable to a 4% increase in average headcount and higher stock-based compensation expense, which was partially offset by lower incentive compensation expense and the impact of one less week in fiscal 2022. The increases in professional and legal fees and outside services expense in fiscal 2022 were primarily due to higher spending on business transformation projects and an increase in legal fees. During fiscal 2021, we incurred a litigation settlement charge of approximately $5 million that was included in general and administrative expenses in our consolidated statements of income. The decreases in facilities and IT support costs were primarily due to lower spending levels on IT projects.

[0000950170-22-011708:mdna:126]
The increase in compensation costs in fiscal 2021 compared to fiscal 2020 was primarily due to higher incentive compensation expense, while average headcount was relatively consistent in each period. The decrease in professional and legal fees and outside services expense in fiscal 2021 was primarily due to lower spending on business transformation projects in the current year. The increase in facilities and IT support costs was primarily due to higher spending levels on IT projects.

[0000950170-22-011708:mdna:127]
42

[0000950170-22-011708:mdna:128]
Restructuring Charges (in millions, except percentages):

[0000950170-22-011708:mdna:129]
|  |  |  | Fiscal Year |  |
|  |  |  | 2022 |  |  | 2021 |  |  | % Change |  |  | 2020 |  |  | % Change |  |
| Restructuring charges |  |  | $ | 33 |  |  | $ | 42 |  |  |  | (21 | )% |  | $ | 21 |  |  |  | 100 | % |

[0000950170-22-011708:mdna:130]
In an effort to reduce our cost structure and redirect resources to our highest return activities, in fiscal years 2022, 2021 and 2020, we initiated a number of business realignment plans designed to streamline our business and focus on key strategic opportunities. These plans resulted in aggregate reductions of our global workforce of approximately 1% in fiscal 2022, 6% in fiscal 2021 and 2% in fiscal 2020, and aggregate charges of $33 million, $42 million and $21 million, respectively, consisting primarily of employee severance costs. The aggregate charges in fiscal 2022 also included legal and tax-related consulting fees associated with our plan to establish an international headquarters in Cork, Ireland. See Note 12 – Restructuring Charges of the Notes to Consolidated Financial Statements for more details regarding our restructuring plans.

[0000950170-22-011708:mdna:131]
Acquisition-related Expense (in millions, except percentages)

[0000950170-22-011708:mdna:132]
|  |  |  | Fiscal Year |
|  |  |  | 2022 |  |  | 2021 |  |  | % Change |  |  | 2020 |  |  | % Change |
| Acquisition-related expense |  |  | $ | 13 |  |  | $ | 16 |  |  |  | (19 | )% |  | $ | — |  |  | NM |

[0000950170-22-011708:mdna:133]
NM - Not Meaningful

[0000950170-22-011708:mdna:134]
We incurred $13 million and $16 million of acquisition-related expenses in fiscal 2022 and fiscal 2021, respectively, primarily legal and consulting fees associated with our acquisition and subsequent integration of CloudCheckr and Spot, respectively.

[0000950170-22-011708:mdna:135]
Gain on Sale or Derecognition of Assets (in millions, except percentages):

[0000950170-22-011708:mdna:136]
|  |  |  | Fiscal Year |  |
|  |  |  | 2022 |  |  | 2021 |  |  | % Change |  |  | 2020 |  |  | % Change |  |
| Gain on sale or derecognition of assets |  |  | $ | — |  |  | $ | (156 | ) |  |  | (100 | )% |  | $ | (38 | ) |  |  | 311 | % |

[0000950170-22-011708:mdna:137]
In April 2021, we sold certain land and buildings located in Sunnyvale, California with an aggregate net book value of $210 million and received cash proceeds of $365 million, resulting in a gain, net of direct selling cost, and adjusted for below-market rent,  of $156 million.

[0000950170-22-011708:mdna:138]
In August 2019, we completed the sale of certain land located in Sunnyvale, California with a net book value of $53 million, and received cash proceeds of $96 million, resulting in a gain, net of direct selling costs, of $38 million.

[0000950170-22-011708:mdna:139]
Other Expense, Net (in millions, except percentages)

[0000950170-22-011708:mdna:140]
The components of other expense, net were as follows:

[0000950170-22-011708:mdna:141]
|  |  |  | Fiscal Year |  |
|  |  |  | 2022 |  |  | 2021 |  |  | % Change |  |  | 2020 |  |  | % Change |  |
| Interest income |  |  | $ | 7 |  |  | $ | 9 |  |  |  | (22 | )% |  | $ | 48 |  |  |  | (81 | )% |
| Interest expense |  |  |  | (73 | ) |  |  | (74 | ) |  |  | (1 | )% |  |  | (55 | ) |  |  | 35 | % |
| Other, net |  |  |  | 4 |  |  |  | (4 | ) |  |  | (200 | )% |  |  | 6 |  |  |  | (167 | )% |
| Total |  |  | $ | (62 | ) |  | $ | (69 | ) |  | NM |  |  | $ | (1 | ) |  | NM |  |

[0000950170-22-011708:mdna:142]
NM - Not Meaningful

[0000950170-22-011708:mdna:143]
Interest income decreased during fiscal 2022 and fiscal 2021 compared to the respective prior years due to both a reduction in the size of our investment portfolio and lower yields earned on the investments.

[0000950170-22-011708:mdna:144]
Interest expense remained flat in fiscal 2022 compared to fiscal 2021 as the aggregate principal amount of our outstanding Senior Notes remained consistent. Interest expense increased during fiscal 2021 compared to fiscal 2020, as we issued Senior Notes in aggregate principal amount of $2.0 billion in the first quarter of fiscal 2021. The impact from the issuance of these Senior Notes was partially offset by the extinguishment of our Senior Notes due June 2021 in the first quarter of fiscal 2021, and a lower average outstanding commercial paper balance during fiscal 2021.

[0000950170-22-011708:mdna:145]
The differences in other, net during fiscal 2022 as compared to fiscal 2021 are partially due to foreign exchange gains and losses year-over-year. In fiscal 2021, other, net includes a $6 million gain recognized on our sale of a minority equity interest in a privately held company for proceeds of approximately $8 million. This benefit was more than offset by a $14 million loss recognized from the extinguishment of our Senior Notes due June 2021 in the first quarter of fiscal 2021.

[0000950170-22-011708:mdna:146]
Provision for Income Taxes (in millions, except percentages):

[0000950170-22-011708:mdna:147]
|  |  |  | Fiscal Year |  |
|  |  |  | 2022 |  |  | 2021 |  |  | % Change |  |  | 2020 |  |  | % Change |  |
| Provision for income taxes |  |  | $ | 158 |  |  | $ | 232 |  |  |  | (32 | )% |  | $ | 125 |  |  |  | 86 | % |

[0000950170-22-011708:mdna:148]
Our effective tax rate for fiscal 2022 was 14% compared to an effective tax rate of 24% for fiscal 2021. Our effective tax rate for fiscal 2022 was lower than the prior year primarily due to the inclusion of one-time benefits related to the prepayment of certain intercompany expenses. Additionally, the fiscal 2021 tax provision included the impact of taxes resulting from the integration of certain acquired companies. Our effective tax rate for fiscal 2020 included a benefit of $61 million related to the lapse of statute of limitations compared to a benefit of $6 million recognized in fiscal 2021.

[0000950170-22-011708:mdna:149]
Liquidity, Capital Resources and Cash Requirements

[0000950170-22-011708:mdna:150]
| (In millions, except percentages) |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Cash, cash equivalents and short-term investments |  | $ | 4,134 |  |  | $ | 4,596 |  |
| Principal amount of debt |  | $ | 2,650 |  |  | $ | 2,650 |  |

[0000950170-22-011708:mdna:151]
The following is a summary of our cash flow activities:

[0000950170-22-011708:mdna:152]
|  |  | Fiscal Year |  |
| (In millions) |  | 2022 |  |  | 2021 |  |
| Net cash provided by operating activities |  | $ | 1,211 |  |  | $ | 1,333 |  |
| Net cash (used in) provided by investing activities |  |  | (561 | ) |  |  | 21 |  |
| Net cash (used in) provided by financing activities |  |  | (1,017 | ) |  |  | 444 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (49 | ) |  |  | 71 |  |
| Net change in cash, cash equivalents and restricted cash |  | $ | (416 | ) |  | $ | 1,869 |  |

[0000950170-22-011708:mdna:153]
As of April 29, 2022, our cash, cash equivalents and short-term investments totaled $4.1 billion, reflecting a decrease of $462 million from April 30, 2021. During fiscal 2022, we generated $1.2 billion of cash from operating activities, offset by $600 million used to repurchase shares of our common stock, $446 million used for the payment of dividends, $226 million in purchases of property and equipment, and $380 million, net of cash acquired, used for the acquisition of three privately-held companies. Net working capital was $2.0 billion as of April 29, 2022, a reduction of $557 million when compared to April 30, 2021. The reduction in net working capital is partially due to the reclassification of $250 million principal amount of our senior notes from long-term to current liabilities in fiscal 2022.

[0000950170-22-011708:mdna:154]
Cash Flows from Operating Activities

[0000950170-22-011708:mdna:155]
During fiscal 2022, we generated cash from operating activities of $1.2 billion, reflecting net income of $937 million, adjusted by non-cash depreciation and amortization of $194 million and non-cash stock-based compensation expense of $245 million.

[0000950170-22-011708:mdna:156]
Significant changes in assets and liabilities during fiscal 2022 included the following:

[0000950170-22-011708:mdna:157]
•
Accounts receivable increased $313 million, primarily reflecting less favorable shipping linearity in the fourth quarter of fiscal 2022 compared to the fourth quarter of fiscal 2021.

[0000950170-22-011708:mdna:158]
•
Deferred revenue and financed unearned services increased by $384 million, due to an increase in the aggregate contract value under software and hardware support contracts, primarily reflecting a higher mix of all-flash systems which carry a higher support dollar content than our other products.

[0000950170-22-011708:mdna:159]
•
Accounts payable increased by $181 million, primarily due to higher inventory purchase levels in fiscal 2022, and the timing of inventory purchases during the fourth quarter of each year.

[0000950170-22-011708:mdna:160]
•
Accrued expenses decreased by $111 million, primarily reflecting a reduction of income tax liabilities, and a decrease in accruals for incentive compensation and commissions plans.

[0000950170-22-011708:mdna:161]
During fiscal 2021, we generated cash from operating activities of $1.3 billion, reflecting net income of $730 million, adjusted by adding non-cash depreciation and amortization expense of $207 million and non-cash stock-based compensation expense of $197 million and subtracting the gain on sale or derecognition of assets of $156 million.

[0000950170-22-011708:mdna:162]
Significant changes in assets and liabilities during fiscal 2021 included the following:

[0000950170-22-011708:mdna:163]
•
Deferred revenue and financed unearned services revenue increased $193 million, primarily due to an increase in deferred software and hardware support contracts associated with a growing installed base as well as growth in Public Cloud contracts.

[0000950170-22-011708:mdna:164]
•
Accrued expenses increased $134 million, primarily due to higher accruals for incentive compensation plans.

[0000950170-22-011708:mdna:165]
We expect that cash provided by operating activities may materially fluctuate in future periods due to a number of factors, including fluctuations in our operating results, shipping linearity, accounts receivable collections performance, inventory and supply chain management, vendor payment initiatives, tax benefits or charges from stock-based compensation, and the timing and amount of compensation and other payments.

[0000950170-22-011708:mdna:166]
Cash Flows from Investing Activities

[0000950170-22-011708:mdna:167]
During fiscal 2022, we generated $45 million primarily from maturities of investments in available-for-sale securities, net of purchases, and paid $226 million for capital expenditures. We paid $380 million, net of cash acquired, for three privately-held companies.

[0000950170-22-011708:mdna:168]
During fiscal 2021, we generated $365 million from the sale of properties located in Sunnyvale, California and $160 million from maturities and sales of investments in available-for-sale debt securities, net of purchases. We paid $350 million, net of cash acquired, for two privately-held companies and $162 million for capital expenditures.

[0000950170-22-011708:mdna:169]
Cash Flows from Financing Activities

[0000950170-22-011708:mdna:170]
During fiscal 2022, cash flows used in financing activities totaled $1.0 billion and include $600 million for the repurchase of approximately seven million shares of common stock and $446 million for the payment of dividends.

[0000950170-22-011708:mdna:171]
During fiscal 2021, we received $2.0 billion from the issuance of Senior Notes, which was partially offset by the use of $513 million for the extinguishment of our Senior Notes due June 2021, $420 million for the net repayment of commercial paper notes with original maturities of three months or less, $427 million for the payment of dividends, and $125 million for the repurchase of two million shares of our common stock.

[0000950170-22-011708:mdna:172]
Key factors that could affect our cash flows include changes in our revenue mix and profitability, our ability to effectively manage our working capital, in particular, accounts receivable, accounts payable and inventories, the timing and amount of stock repurchases and payment of cash dividends, the impact of foreign exchange rate changes, our ability to effectively integrate acquired products, businesses and technologies, and the timing of repayments of our debt. Based on past performance and our current business outlook, we believe that our sources of liquidity, including cash generated from operations, and our ability to access capital markets and committed credit lines will satisfy our working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on our debt and other liquidity requirements associated with operations and meet our cash requirements for at least the next 12 months. However, in the event our liquidity is insufficient, we may be required to curtail spending and implement additional cost saving measures and restructuring actions or enter into new financing arrangements. We cannot be certain that we will continue to generate cash flows at or above current levels or that we will be able to obtain additional financing, if necessary, on satisfactory terms, if at all. For further discussion of factors that could affect our cash flows and liquidity requirements, including the impact of the COVID-19 pandemic, see Item 1A. Risk Factors.

[0000950170-22-011708:mdna:173]
Liquidity

[0000950170-22-011708:mdna:174]
Our principal sources of liquidity as of April 29, 2022 consisted of cash, cash equivalents and short-term investments, cash we expect to generate from operations, and our commercial paper program and related credit facility.

[0000950170-22-011708:mdna:175]
Cash, cash equivalents and short-term investments consisted of the following (in millions):

[0000950170-22-011708:mdna:176]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Cash and cash equivalents |  | $ | 4,112 |  |  | $ | 4,529 |  |
| Short-term investments |  |  | 22 |  |  |  | 67 |  |
| Total |  | $ | 4,134 |  |  | $ | 4,596 |  |

[0000950170-22-011708:mdna:177]
45

[0000950170-22-011708:mdna:178]
As of April 29, 2022 and April 30, 2021, $2.3 billion and $2.5 billion, respectively, of cash, cash equivalents and short-term investments were held by various foreign subsidiaries and were generally based in U.S. dollar-denominated holdings, while $1.8 billion and $2.1 billion, respectively, were available in the U.S.

[0000950170-22-011708:mdna:179]
Our principal liquidity requirements are primarily to meet our working capital needs, support ongoing business activities, fund research and development, meet capital expenditure needs, invest in critical or complementary technologies through asset purchases and/or business acquisitions, service interest and principal payments on our debt, fund our stock repurchase program, and pay dividends, as and if declared. In the ordinary course of business, we engage in periodic reviews of opportunities to invest in or acquire companies or units in companies to expand our total addressable market, leverage technological synergies and establish new streams of revenue, particularly in our Public Cloud Segment.

[0000950170-22-011708:mdna:180]
The principal objectives of our investment policy are the preservation of principal and maintenance of liquidity. We attempt to mitigate default risk by investing in high-quality investment grade securities, limiting the time to maturity and monitoring the counter-parties and underlying obligors closely. We believe our cash equivalents and short-term investments are liquid and accessible. We are not aware of any significant deterioration in the fair value of our cash equivalents or investments from the values reported as of April 29, 2022.

[0000950170-22-011708:mdna:181]
Our investment portfolio has been and will continue to be exposed to market risk due to trends in the credit and capital markets. We continue to closely monitor current economic and market events to minimize the market risk of our investment portfolio. We routinely monitor our financial exposure to both sovereign and non-sovereign borrowers and counterparties. We utilize a variety of planning and financing strategies in an effort to ensure our worldwide cash is available when and where it is needed. We also have an automatic shelf registration statement on file with the Securities and Exchange Commission (SEC). We may in the future offer an additional unspecified amount of debt, equity and other securities.

[0000950170-22-011708:mdna:182]
Senior Notes

[0000950170-22-011708:mdna:183]
The following table summarizes the principal amount of our Senior Notes as of April 29, 2022 (in millions):

[0000950170-22-011708:mdna:184]
| 3.25% Senior Notes Due December 2022 |  | $ | 250 |  |
| 3.30% Senior Notes Due September 2024 |  |  | 400 |  |
| 1.875% Senior Notes Due June 2025 |  |  | 750 |  |
| 2.375% Senior Notes Due June 2027 |  |  | 550 |  |
| 2.70% Senior Notes Due June 2030 |  |  | 700 |  |
| Total |  | $ | 2,650 |  |

[0000950170-22-011708:mdna:185]
Interest on the Senior Notes is payable semi-annually. For further information on the underlying terms, see Note 8 – Financing Arrangements of the Notes to Consolidated Financial Statements.

[0000950170-22-011708:mdna:186]
Commercial Paper Program and Credit Facility

[0000950170-22-011708:mdna:187]
We have a commercial paper program (the Program), under which we may issue unsecured commercial paper notes. Amounts available under the Program may be borrowed, repaid and re-borrowed, with the aggregate face or principal amount of the notes outstanding under the Program at any time not to exceed $1.0 billion. The maturities of the notes can vary, but may not exceed 397 days from the date of issue. The notes are sold under customary terms in the commercial paper market and may be issued at a discount from par or, alternatively, may be sold at par and bear interest at rates dictated by market conditions at the time of their issuance. The proceeds from the issuance of the notes are used for general corporate purposes. No commercial paper notes were outstanding as of April 29, 2022.

[0000950170-22-011708:mdna:188]
In connection with the Program, we have a senior unsecured credit agreement with a syndicated group of lenders. The credit agreement, which was amended on January 22, 2021, provides for a $1.0 billion revolving unsecured credit facility, with a sublimit of $50 million available for the issuance of letters of credit on our behalf. The credit facility matures on January 22, 2026, with an option for us to extend the maturity date for two additional 1-year periods, subject to certain conditions. The proceeds of the loans may be used by us for general corporate purposes and as liquidity support for our existing commercial paper program. As of April 29, 2022, we were compliant with all associated covenants in the agreement.  No amounts were drawn against this credit facility during any of the periods presented.

[0000950170-22-011708:mdna:189]
Capital Expenditure Requirements

[0000950170-22-011708:mdna:190]
We expect to fund our capital expenditures, including our commitments related to facilities, equipment, operating leases and internal-use software development projects over the next few years through existing cash, cash equivalents, investments and cash generated from operations. The timing and amount of our capital requirements cannot be precisely determined and will depend on a number of factors, including future demand for products, changes in the network storage industry, hiring plans and our decisions related to the financing of our facilities and equipment requirements. We anticipate capital expenditures for fiscal 2023 to be between $250 million and $300 million.

[0000950170-22-011708:mdna:191]
Dividends and Stock Repurchase Program

[0000950170-22-011708:mdna:192]
On May 27, 2022, we declared a cash dividend of $0.50 per share of common stock, payable on July 27, 2022 to holders of record as of the close of business on July 8, 2022.

[0000950170-22-011708:mdna:193]
As of April 29, 2022, our Board of Directors had authorized the repurchase of up to $15.1 billion of our common stock under our stock repurchase program. Under this program, we may purchase shares of our outstanding common stock through solicited or unsolicited transactions in the open market, in privately negotiated transactions, through accelerated share repurchase programs, pursuant to a Rule 10b5-1 plan or in such other manner as deemed appropriate by our management. The stock repurchase program may be suspended or discontinued at any time. Since the May 13, 2003 inception of this program through April 29, 2022, we repurchased a total of 347 million shares of our common stock at an average price of $39.95 per share, for an aggregate purchase price of $13.9 billion. As of April 29, 2022, the remaining authorized amount for stock repurchases under this program was $1.3 billion.

[0000950170-22-011708:mdna:194]
Purchase Commitments

[0000950170-22-011708:mdna:195]
In the ordinary course of business, we make commitments to third-party contract manufacturers and component suppliers to manage manufacturer lead times and meet product forecasts, and to other parties, to purchase various key components used in the manufacture of our products. In addition, we have open purchase orders and contractual obligations associated with our ordinary course of business for which we have not yet received goods or services. These off-balance sheet purchase commitments totaled $1.2 billion at April 29, 2022, of which $0.9 billion is due in fiscal 2023, with the remainder due thereafter.

[0000950170-22-011708:mdna:196]
Financing Guarantees

[0000950170-22-011708:mdna:197]
While most of our arrangements for sales include short-term payment terms, from time to time we provide long-term financing to creditworthy customers. We have generally sold receivables financed through these arrangements on a non-recourse basis to third party financing institutions within 10 days of the contracts’ dates of execution, and we classify the proceeds from these sales as cash flows from operating activities in our consolidated statements of cash flows. We account for the sales of these receivables as “true sales” as defined in the accounting standards on transfers of financial assets, as we are considered to have surrendered control of these financing receivables. We sold $59 million and $102 million of receivables during fiscal 2022 and 2021, respectively.

[0000950170-22-011708:mdna:198]
In addition, we enter into arrangements with leasing companies for the sale of our hardware systems products. These leasing companies, in turn, lease our products to end-users. The leasing companies generally have no recourse to us in the event of default by the end-user.

[0000950170-22-011708:mdna:199]
Some of the leasing arrangements described above have been financed on a recourse basis through third-party financing institutions. Under the terms of recourse leases, which are generally three years or less, we remain liable for the aggregate unpaid remaining lease payments to the third-party leasing companies in the event of end-user customer default. These arrangements are generally collateralized by a security interest in the underlying assets. As of April 29, 2022 and April 30, 2021, the aggregate amount by which such contingencies exceeded the associated liabilities was not significant. To date, we have not experienced significant losses under our lease financing programs or other financing arrangements.

[0000950170-22-011708:mdna:200]
We have entered into service contracts with certain of our end-user customers that are supported by third-party financing arrangements. If a service contract is terminated as a result of our non-performance under the contract or our failure to comply with the terms of the financing arrangement, we could, under certain circumstances, be required to acquire certain assets related to the service contract or to pay the aggregate unpaid payments under such arrangements. As of April 29, 2022, we have not been required to make any payments under these arrangements, and we believe the likelihood of having to acquire a material amount of assets or make payments under these arrangements is remote. The portion of the financial arrangement that represents unearned services revenue is included in deferred revenue and financed unearned services revenue in our consolidated balance sheets.

[0000950170-22-011708:mdna:201]
Legal Contingencies

[0000950170-22-011708:mdna:202]
We are subject to various legal proceedings and claims which arise in the normal course of business. See further details on such matters in Note 17 – Commitments and Contingencies of the Notes to Consolidated Financial Statements.

[0000950170-22-011708:mdna:203]
Critical Accounting Policies and Estimates

[0000950170-22-011708:mdna:204]
Our consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States of America (GAAP), which require management to make judgments, estimates and assumptions that affect the reported amounts of assets, liabilities, net revenues and expenses, and the disclosure of contingent assets and liabilities. Our estimates are based on historical experience and various other assumptions that we believe to be reasonable under the circumstances, including the ongoing COVID-19 pandemic, the results of which form the basis for making judgments about the carrying values of assets and liabilities. We believe that the accounting estimates employed and the resulting balances are reasonable; however, actual results may differ from these estimates and such differences may be material.

[0000950170-22-011708:mdna:205]
The summary of significant accounting policies is included in Note 1 – Description of Business and Significant Accounting Policies of the Notes to Consolidated Financial Statements. An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the estimate that are reasonably possible could materially impact the financial statements. The accounting policies described below reflect the significant judgments, estimates and assumptions used in the preparation of the consolidated financial statements.

[0000950170-22-011708:mdna:206]
Revenue Recognition

[0000950170-22-011708:mdna:207]
Our contracts with customers often include the transfer of multiple products and services to the customer. In determining the amount and timing of revenue recognition, we assess which products and services are distinct performance obligations and allocate the transaction price, which may include fixed and/or variable amounts, among each performance obligation on a relative standalone selling price (SSP) basis. The following are the key estimates and assumptions and corresponding uncertainties included in this approach:

[0000950170-22-011708:mdna:208]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | We evaluate whether products and services promised in our contracts with customers are distinct performance obligations that should be accounted for separately versus together. |  |  | In certain contracts, the determination of our distinct performance obligations requires significant judgment. As our business and offerings to customers change over time, the products and services we determine to be distinct performance obligations may change. Such changes may adversely impact the amount of revenue and gross margin we report in a particular period. |
|  | In determining the transaction price of our contracts, we estimate variable consideration based on the expected value, primarily relying on our history. In certain situations, we may also use the most likely amount as the basis of our estimate. |  |  | We may have insufficient relevant historical data or other information to arrive at an accurate estimate of variable consideration using either the “expected value” or “most likely amount” method. Additionally, changes in business practices, such as those related to sales returns or marketing programs, may introduce new forms of variable consideration, as well as more complexity and uncertainty in the estimation process. |
|  | In contracts with multiple performance obligations, we establish SSPs based on the price at which products and services are sold separately. If SSPs are not observable through past transactions, we estimate them by maximizing the use of observable inputs including pricing strategy, market data, internally-approved pricing guidelines related to the performance obligations and other observable inputs. |  |  | As our business and offerings evolve over time, modifications to our pricing and discounting methodologies, changes in the scope and nature of product and service offerings and/or changes in customer segmentation may result in a lack of consistency, making it difficult to establish and/or maintain SSPs. Changes in SSPs could result in different and unanticipated allocations of revenue in contracts with multiple performance obligations. These factors, among others, may adversely impact the amount of revenue and gross margin we report in a particular period. |

[0000950170-22-011708:mdna:209]
48

[0000950170-22-011708:mdna:210]
Inventory Valuation and Purchase Order Accruals

[0000950170-22-011708:mdna:211]
Inventories consist primarily of purchased components and finished goods and are stated at the lower of cost or net realizable value, which approximates actual cost on a first-in, first-out basis. A provision is recorded when inventory is determined to be in excess of anticipated demand or obsolete in order to adjust inventory to its estimated realizable value. The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our inventories:

[0000950170-22-011708:mdna:212]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | We periodically perform an excess and obsolete analysis of our inventory. Inventories are written down based on excess and obsolete reserves determined primarily on assumptions about future demand forecasts and market conditions. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. |  |  | Although we use our best estimates to forecast future product demand, any significant unanticipated changes in demand, which could be exacerbated by the effects of the COVID-19 pandemic, or obsolescence related to technological developments, new product introductions, customer requirements, competition or other factors could have a significant impact on the valuation of our inventory. If actual market conditions are less favorable than those projected, additional write-downs and other charges against earnings that adversely impact gross margins may be required. If actual market conditions are more favorable, we may realize higher gross profits in the period when the written-down inventory is sold.We are subject to a variety of environmental laws relating to the manufacture of our products. If there are changes to the current regulations, we may be required to make product design changes which may result in excess or obsolete inventory, which could adversely impact our operating results. |
|  | We make commitments to our third-party contract manufacturers and other suppliers to manage lead times and meet product forecasts and to other parties to purchase various key components used in the manufacture of our products. We establish accruals for estimated losses on non-cancelable purchase commitments when we believe it is probable that the components will not be utilized in future operations. |  |  | If the actual materials demand is significantly lower than our forecast, we may be required to increase our recorded liabilities for estimated losses on non-cancelable purchase commitments, including incremental commitments made in response to recent developments in the broader technology supply chain, which would adversely impact our operating results. |

[0000950170-22-011708:mdna:213]
Goodwill and Purchased Intangible Assets

[0000950170-22-011708:mdna:214]
We allocate the purchase price of acquisitions to identifiable assets acquired and liabilities assumed at their acquisition date fair values based on established valuation techniques. Goodwill represents the residual value as of the acquisition date, which in most cases is measured as the excess of the purchase consideration transferred over the net of the acquisition date fair values of the assets acquired and liabilities assumed.

[0000950170-22-011708:mdna:215]
The carrying values of purchased intangible assets are reviewed whenever events and circumstances indicate that the net book value of an asset may not be recovered through expected future cash flows from its use and eventual disposition. We periodically review the estimated remaining useful lives of our intangible assets. This review may result in impairment charges or shortened useful lives, resulting in charges to our consolidated statements of income.

[0000950170-22-011708:mdna:216]
We review goodwill for impairment annually and whenever events or changes in circumstances indicate the carrying amount of one of our reporting units may exceed its fair value. The provisions of the accounting standard for goodwill allow us to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. During the first quarter of fiscal 2022, we allocated goodwill to our segments and reporting units using a relative fair value approach and as a result, we performed an interim quantitative goodwill impairment test and determined the fair value of each of our reporting units substantially exceeded its carrying amount, therefore, there was no impairment of goodwill. For our annual goodwill impairment test in the fourth quarter of fiscal 2022, we performed a qualitative test which did not result in any goodwill impairment charges. To date, the impacts of the COVID-19 pandemic have not significantly adversely affected the fair value of our reporting units.

[0000950170-22-011708:mdna:217]
49

[0000950170-22-011708:mdna:218]
The following are the key estimates and assumptions and corresponding uncertainties for estimating the value of our goodwill and purchased intangible assets:

[0000950170-22-011708:mdna:219]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the accounting guidance for the fair value measurement of nonfinancial assets.The valuation of purchased intangible assets is principally based on estimates of the future performance and cash flows expected to be generated by the acquired assets from the acquired business. |  |  | While we employ experts to determine the acquisition date fair value of acquired intangibles, the fair values of assets acquired and liabilities assumed are based on significant management assumptions and estimates, which are inherently uncertain and highly subjective and as a result, actual results may differ from estimates. If different assumptions were to be used, it could materially impact the purchase price allocation. Volatile macroeconomic and market conditions caused by the COVID-19 pandemic have increased the level of uncertainty and subjectivity of certain management assumptions and estimates. |
|  | Evaluations of possible goodwill and purchased intangible asset impairment require us to make judgments and assumptions related to the allocation of our balance sheet and income statement amounts and estimate future cash flows and fair market values of our reporting units and assets. |  |  | In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill or purchased intangible assets. Assumptions and estimates about expected future cash flows and the fair values of our reporting units and purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as the adverse impact of unanticipated changes in macroeconomic conditions, such as those related to the COVID-19 pandemic, and technological changes or new product introductions from competitors. They can also be affected by internal factors such as changes in business strategy or in forecasted product life cycles and roadmaps. Our ongoing consideration of these and other factors could result in future impairment charges or accelerated amortization expense, which could adversely affect our operating results. |

[0000950170-22-011708:mdna:220]
Income Taxes

[0000950170-22-011708:mdna:221]
We are subject to income taxes in the United States and numerous foreign jurisdictions. We compute our provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized for the expected future tax consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, and for operating losses and tax credit carryforwards. Deferred tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets or liabilities are expected to be realized or settled. The Company records a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized.

[0000950170-22-011708:mdna:222]
The following are the key estimates and assumptions and corresponding uncertainties for our income taxes:

[0000950170-22-011708:mdna:223]
|  | Key Estimates and Assumptions |  |  | Key Uncertainties |
|  | Our income tax provision is based on existing tax law and advanced pricing agreements or letter rulings we have with various tax authorities. |  |  | Our provision for income taxes is subject to volatility and could be adversely impacted by future changes in existing tax laws, such as a change in tax rate, possible U.S. changes to the taxation of earnings of our foreign subsidiaries, and uncertainties as to future renewals of favorable tax agreements and rulings. |
|  | The determination of whether we should record or adjust a valuation allowance against our deferred tax assets is based on assumptions regarding our future profitability. |  |  | Our future profits could differ from current expectations resulting in a change to our determination as to the amount of deferred tax assets that are more likely than not to be realized. We could adjust our valuation allowance with a corresponding impact to the tax provision in the period in which such determination is made. |
|  | The estimates for our uncertain tax positions are based primarily on company specific circumstances, applicable tax laws, tax opinions from outside firms and past results from examinations of our income tax returns. |  |  | Significant judgment is required in evaluating our uncertain tax positions. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome or tax court rulings of these matters will not be different from that which is reflected in our historical tax provisions and accruals. |
