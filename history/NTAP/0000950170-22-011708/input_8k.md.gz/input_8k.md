# NTAP 8-K — 0000950170-22-011019 filed 2022-06-01

## item codes, every 8-K on or before 2022-06-16

- 2022-06-01 0000950170-22-011019 — 2.02, 9.01
- 2022-03-22 0001193125-22-081663 — 8.01
- 2022-02-23 0000950170-22-001772 — 2.02, 9.01
- 2022-02-14 0001193125-22-041835 — 5.02
- 2021-11-30 0000950170-21-004947 — 2.02, 9.01
- 2021-09-13 0001193125-21-271444 — 5.02, 5.03, 5.07, 9.01
- 2021-08-25 0001564590-21-045712 — 2.02, 9.01
- 2021-06-02 0001564590-21-031393 — 2.02, 5.02, 8.01, 9.01
- 2021-02-24 0001564590-21-008093 — 2.02, 9.01
- 2021-02-04 0001564590-21-004336 — 5.02, 9.01
- 2021-01-22 0001193125-21-014704 — 1.01, 2.03, 9.01
- 2020-12-01 0001564590-20-055739 — 2.02, 9.01
- 2020-09-24 0001564590-20-044512 — 5.02
- 2020-09-16 0001564590-20-043710 — 5.07
- 2020-08-26 0001564590-20-041346 — 2.02, 2.05, 5.02, 9.01
- 2020-06-26 0001193125-20-180890 — 8.01
- 2020-06-22 0001193125-20-175676 — 1.01, 2.03, 8.01, 9.01
- 2020-06-03 0001564590-20-028235 — 5.02
- 2020-05-27 0001564590-20-027022 — 2.02, 9.01
- 2020-05-12 0001564590-20-024650 — 5.02, 9.01
- 2020-03-30 0001564590-20-014299 — 7.01
- 2020-03-02 0001193125-20-058901 — 5.02
- 2020-02-12 0001564590-20-004352 — 2.02, 5.02, 9.01
- 2020-02-04 0001564590-20-003107 — 5.02, 9.01
- 2019-11-13 0001564590-19-043224 — 2.02, 5.02, 9.01
- 2019-09-18 0001564590-19-034968 — 5.02, 5.07, 9.01
- 2019-08-14 0001564590-19-032131 — 2.02, 5.02, 9.01
- 2019-08-01 0001564590-19-027944 — 2.02, 9.01
- 2019-05-22 0001564590-19-020164 — 2.02, 5.02, 9.01
- 2019-02-13 0001564590-19-002825 — 2.02, 9.01
- 2018-11-14 0001564590-18-029561 — 2.02, 9.01
- 2018-09-19 0001193125-18-277567 — 5.02, 5.07, 9.01
- 2018-08-15 0001564590-18-021828 — 2.02, 9.01
- 2018-05-23 0001564590-18-014236 — 2.02, 5.02, 8.01, 9.01
- 2018-04-30 0001193125-18-143036 — 5.03, 9.01
- 2018-04-05 0001193125-18-108701 — 8.01
- 2018-02-14 0001564590-18-002075 — 2.02, 9.01
- 2018-02-08 0001193125-18-036224 — 5.02
- 2017-11-15 0001564590-17-023882 — 2.02, 5.02, 9.01
- 2017-10-05 0001193125-17-304610 — 8.01
- 2017-09-29 0001193125-17-299733 — 1.01, 2.03, 8.01, 9.01
- 2017-09-19 0001193125-17-288320 — 5.02, 5.07, 9.01
- 2017-09-11 0001193125-17-281263 — 1.01
- 2017-08-16 0001564590-17-017768 — 2.02, 9.01
- 2017-07-17 0001193125-17-229002 — 1.01, 2.03, 9.01
- 2017-05-24 0001564590-17-011611 — 2.02, 9.01
- 2017-05-22 0001193125-17-178018 — 5.02
- 2017-02-15 0001564590-17-001635 — 2.02, 9.01
- 2016-12-12 0001193125-16-790334 — 1.01, 1.02, 2.03, 9.01
- 2016-11-21 0001193125-16-773699 — 5.02, 9.01
- 2016-11-16 0001564590-16-029385 — 2.02, 9.01
- 2016-11-03 0001193125-16-758809 — 2.05
- 2016-09-20 0001193125-16-714795 — 5.02, 5.07, 9.01
- 2016-08-17 0001564590-16-024497 — 2.02, 9.01
- 2016-06-28 0001193125-16-634733 — 1.02, 5.02, 9.01
- 2016-06-06 0001193125-16-613973 — 5.02
- 2016-05-25 0001102624-16-002862 — 2.02, 5.02, 9.01
- 2016-04-11 0001193125-16-537112 — 5.02
- 2016-04-04 0001193125-16-529386 — 5.02
- 2016-03-30 0001193125-16-522571 — 5.02, 8.01, 9.01
- 2016-03-15 0001193125-16-505195 — 1.01
- 2016-02-17 0001102624-16-002144 — 2.02, 2.05, 9.01
- 2016-02-02 0001193125-16-447662 — 1.01, 2.03, 8.01, 9.01
- 2016-01-06 0001193125-16-422537 — 5.02, 7.01, 9.01
- 2015-12-21 0001193125-15-409103 — 1.01, 8.01, 9.01
- 2015-11-18 0001199073-15-000156 — 2.02, 5.02, 9.01
- 2015-09-16 0001193125-15-321395 — 5.02, 5.07, 9.01
- 2015-08-19 0001102624-15-001340 — 2.02, 9.01
- 2015-08-06 0001193125-15-281039 — 5.02, 8.01
- 2015-06-26 0001193125-15-237314 — 5.02, 9.01
- 2015-06-05 0001193125-15-214922 — 5.02, 8.01, 9.01
- 2015-05-20 0001102624-15-000862 — 2.02, 2.05, 9.01
- 2015-02-11 0001102624-15-000197 — 2.02, 8.01, 9.01
- 2014-11-12 0001102624-14-001857 — 2.02
- 2014-09-09 0001193125-14-336826 — 5.02, 5.07, 9.01
- 2014-08-13 0001102624-14-001312 — 2.02, 9.01
- 2014-06-05 0001193125-14-227067 — 1.01, 2.03, 8.01, 9.01
- 2014-06-02 0001193125-14-220241 — 5.02
- 2014-05-21 0001102624-14-000858 — 2.02, 9.01
- 2014-04-07 0001193125-14-133588 — 5.02, 9.01
- 2014-03-12 0001193125-14-095620 — 2.05
- 2014-02-13 0001193125-14-051239 — 5.03, 9.01
- 2014-02-12 0001102624-14-000200 — 2.02, 9.01
- 2013-11-13 0001102624-13-001387 — 2.02, 9.01
- 2013-09-18 0001193125-13-370573 — 5.02, 5.07
- 2013-09-13 0001193125-13-366610 — 5.02
- 2013-08-14 0001102624-13-000997 — 2.02, 9.01
- 2013-06-05 0001193125-13-247840 — 1.01, 2.03
- 2013-05-21 0001102624-13-000648 — 2.02, 2.05, 9.01
- 2013-02-13 0001102624-13-000166 — 2.02, 9.01
- 2013-01-08 0001193125-13-005611 — 1.02
- 2012-12-28 0001193125-12-518486 — 1.01, 2.03, 9.01
- 2012-12-12 0001193125-12-500180 — 1.01, 8.01, 9.01
- 2012-12-06 0001193125-12-493746 — 1.01, 9.01
- 2012-12-05 0001193125-12-491247 — 1.02
- 2012-11-14 0001102624-12-000925 — 2.02, 7.01, 9.01
- 2012-09-06 0001193125-12-383164 — 5.02, 5.03, 5.07, 9.01
- 2012-08-15 0001102624-12-000677 — 2.02, 9.01
- 2012-07-19 0001193125-12-307569 — 5.02
- 2012-06-01 0001193125-12-257385 — 5.02
- 2012-05-23 0001102624-12-000459 — 2.02, 9.01
- 2012-05-01 0001193125-12-201050 — 1.02, 2.04
- 2012-02-15 0001102624-12-000111 — 2.02, 9.01
- 2012-01-04 0001193125-12-002216 — 5.02
- 2011-11-16 0001102624-11-000758 — 2.02, 9.01
- 2011-09-07 0001193125-11-242373 — 5.02, 5.07
- 2011-08-22 0001193125-11-227990 — 1.01, 2.03
- 2011-08-17 0001193125-11-225615 — 5.02
- 2011-08-17 0001102624-11-000512 — 2.02, 9.01
- 2011-07-11 0001193125-11-185351 — 1.01, 2.03
- 2011-05-25 0001102624-11-000322 — 2.02, 9.01
- 2011-05-23 0001193125-11-147889 — 5.02
- 2011-03-22 0001193125-11-073649 — 5.02
- 2011-03-15 0001193125-11-067168 — 1.01
- 2011-03-09 0001193125-11-060887 — 7.01, 9.01
- 2011-02-16 0001102624-11-000097 — 2.02, 9.01
- 2010-11-18 0001193125-10-263468 — 7.01
- 2010-11-17 0001102624-10-000553 — 2.02, 9.01
- 2010-09-09 0000950123-10-084762 — 8.01, 9.01
- 2010-09-07 0000950123-10-084246 — 5.02, 5.03, 5.07, 8.01, 9.01
- 2010-08-18 0001102624-10-000389 — 2.02, 9.01
- 2010-07-02 0000950123-10-063456 — 5.02
- 2010-05-27 0000950123-10-053686 — 5.02, 8.01
- 2010-05-26 0001102624-10-000243 — 2.02, 9.01
- 2010-05-13 0000950123-10-049101 — 5.02
- 2010-04-20 0000950123-10-036276 — 1.02
- 2010-02-17 0001102624-10-000067 — 2.02, 9.01
- 2009-12-23 0000950123-09-073082 — 1.01, 1.02, 5.02, 5.03, 9.01
- 2009-11-25 0000950123-09-066362 — 1.01, 9.01
- 2009-11-18 0001102624-09-000550 — 2.02, 9.01
- 2009-10-20 0000950123-09-051635 — 5.02, 5.03, 9.01
- 2009-09-30 0000950123-09-047402 — 8.01, 9.01
- 2009-08-25 0000950123-09-037902 — 5.02, 9.01
- 2009-08-19 0001102624-09-000399 — 2.02, 9.01
- 2009-07-23 0000950123-09-024861 — 5.02
- 2009-07-09 0000950123-09-021283 — 1.02, 8.01, 9.01
- 2009-06-26 0000950123-09-018041 — 5.02
- 2009-06-03 0000950123-09-011098 — 1.01, 8.01, 9.01
- 2009-05-21 0000950134-09-011244 — 1.01, 8.01, 9.01
- 2009-05-20 0000891618-09-000181 — 2.02, 8.01, 9.01
- 2009-04-30 0001299933-09-001906 — 1.02
- 2009-04-13 0000891618-09-000133 — 1.01
- 2009-04-06 0000950134-09-007029 — 1.02, 2.04, 5.02, 5.03, 9.01
- 2009-02-11 0000950134-09-002474 — 2.02, 2.05, 5.02, 9.01
- 2008-12-10 0000950134-08-021903 — 2.05, 2.06
- 2008-12-05 0001299933-08-005656 — 1.02, 2.04
- 2008-11-12 0001157523-08-009244 — 2.02, 9.01
- 2008-09-08 0000950134-08-016297 — 5.02, 9.01
- 2008-08-14 0001299933-08-003924 — 8.01, 9.01
- 2008-08-13 0001157523-08-006827 — 2.02, 9.01
- 2008-06-25 0000891618-08-000324 — 5.02
- 2008-06-10 0000950134-08-011025 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2008-06-03 0000891618-08-000294 — 8.01, 9.01
- 2008-05-21 0001157523-08-004488 — 2.02, 9.01
- 2008-03-14 0001299933-08-001416 — 5.03, 9.01
- 2008-03-13 0001299933-08-001388 — 5.02, 5.03, 9.01
- 2008-02-13 0001157523-08-001342 — 2.02, 9.01
- 2008-02-07 0001299933-08-000659 — 1.01, 2.03
- 2008-02-01 0001299933-08-000570 — 5.02
- 2007-12-05 0001299933-07-007008 — 1.01, 2.03
- 2007-11-14 0001157523-07-011322 — 2.02, 9.01
- 2007-11-08 0001299933-07-006538 — 1.01, 2.03
- 2007-10-12 0001299933-07-005919 — 1.01, 2.03
- 2007-10-12 0001299933-07-005918 — 1.01, 2.03
- 2007-08-23 0001299933-07-005065 — 1.01, 2.03
- 2007-08-17 0001299933-07-004981 — 1.01
- 2007-08-15 0001299933-07-004933 — 8.01, 9.01
- 2007-08-15 0001157523-07-008454 — 2.02, 9.01
- 2007-08-02 0001157523-07-007757 — 2.02, 9.01
- 2007-07-20 0001299933-07-004288 — 1.01, 2.03
- 2007-05-30 0001299933-07-003347 — 1.01, 2.03
- 2007-05-23 0001157523-07-005541 — 2.02, 9.01
- 2007-04-27 0001299933-07-002577 — 5.02
- 2007-03-23 0001299933-07-001817 — 1.01, 2.03
- 2007-02-14 0001157523-07-001575 — 2.02, 9.01
- 2007-01-19 0001299933-07-000344 — 5.02
- 2006-12-20 0001299933-06-008240 — 1.01, 2.03
- 2006-12-13 0001299933-06-008063 — 1.01, 2.03
- 2006-11-15 0001157523-06-011409 — 2.02, 9.01
- 2006-09-01 0001299933-06-005801 — 5.02, 5.03, 9.01
- 2006-08-16 0001157523-06-008531 — 2.02, 9.01
- 2006-05-24 0001157523-06-005570 — 2.02, 9.01
- 2006-05-19 0001299933-06-003607 — 5.02, 5.03, 9.01
- 2006-04-05 0001299933-06-002478 — 1.01, 2.03
- 2006-02-15 0001157523-06-001623 — 2.02, 9.01
- 2005-12-21 0001299933-05-006762 — 1.01, 2.03
- 2005-12-09 0001299933-05-006454 — 5.02
- 2005-11-16 0001157523-05-010241 — 2.02, 9.01
- 2005-10-20 0001299933-05-005368 — 5.02
- 2005-09-01 0001299933-05-004448 — 2.01, 9.01
- 2005-08-17 0001157523-05-007569 — 2.02, 9.01
- 2005-08-04 0001299933-05-003985 — 5.03, 9.01
- 2005-08-04 0001157523-05-007082 — 2.02, 9.01
- 2005-07-07 0001299933-05-003338 — 1.01, 9.01
- 2005-06-21 0000950134-05-012277 — 1.01, 9.01
- 2005-05-24 0001157523-05-005040 — 2.02, 9.01
- 2005-05-18 0000891618-05-000375 — 1.01, 9.01
- 2005-05-04 0001299933-05-002147 — 1.01, 5.02, 5.03, 9.01
- 2005-02-15 0001157523-05-001486 — 2.02, 9.01
- 2004-12-10 0001299933-04-002205 — 5.02
- 2004-11-16 0001157523-04-010863 — 2.02, 9.01
- 2004-09-09 0000891618-04-001228 — 5.03
- 2004-08-17 0001157523-04-007893 — 12
- 2004-05-18 0001157523-04-004990 — 12
- 2004-04-26 0000950134-04-005899 — 7 — amendment of 0000891618-04-000653
- 2004-02-27 0000891618-04-000653 — 2, 7
- 2004-02-17 0001157523-04-001515 — 12
- 2003-11-18 0001157523-03-006798 — 12
- 2003-11-04 0001157523-03-006204 — 5
- 2003-08-19 0001157523-03-004392 — 9
- 2003-05-13 0001157523-03-001865 — 9
- 2001-12-04 0000891618-01-502471 — 5, 7
- 1997-11-26 0000891618-97-004784 — 5
- 1997-04-16 0000891618-97-001768 — 7 — amendment of 0000891618-97-001464
- 1997-03-28 0000891618-97-001464 — 2, 7
- 1996-09-09 0000891618-96-001968 — 5, 7

## late-filing notifications on or before 2022-06-16

- none on or before 2022-06-16

## item 2.02 — earnings release, exhibit 99.1

[0000950170-22-011019:8k_2_02:1]
EX-99.1
2
ntap-ex99_1.htm
EX-99.1

[0000950170-22-011019:8k_2_02:2]
EX-99.1

[0000950170-22-011019:8k_2_02:3]
Exhibit 99.1

[0000950170-22-011019:8k_2_02:4]
NetApp reports fourth quarter and fiscal year 2022 results

[0000950170-22-011019:8k_2_02:5]
Net revenues for the fourth quarter grew 8% year-over-year to $1.68 billion;

[0000950170-22-011019:8k_2_02:6]
Net revenues for fiscal year 2022 grew 10% to $6.32 billion

[0000950170-22-011019:8k_2_02:7]
•
Q4 billings1 were $2.02 billion, an increase of 16% year-over-year

[0000950170-22-011019:8k_2_02:8]
•
Q4 product revenue grew 6% year-over-year to $894 million, the fifth consecutive quarter of year-over-year growth

[0000950170-22-011019:8k_2_02:9]
•
NetApp™ Public Cloud annualized revenue run rate (ARR)2 increased 68% year-over-year to $505 million

[0000950170-22-011019:8k_2_02:10]
•
All-flash array annualized net revenue run rate3 increased 12% year-over-year to $3.2 billion

[0000950170-22-011019:8k_2_02:11]
•
$1.05 billion returned to shareholders in fiscal year 2022, 86% of cash from operations 106% of free cash flow

[0000950170-22-011019:8k_2_02:12]
SAN JOSE, Calif.—June 1, 2022—NetApp (NASDAQ: NTAP) today reported financial results for the fourth quarter and fiscal year 2022, which ended on April 29, 2022.

[0000950170-22-011019:8k_2_02:13]
“Our solid fourth quarter results cap off a strong year. We made sustained progress against our strategic goals: gaining share in enterprise storage, expanding our public cloud business, and, most notably, delivering record levels of gross margin dollars, operating income, and earnings per share,” said George Kurian, chief executive officer. “The strong fundamentals of our business, including our alignment to customer priorities, strong balance sheet, and prudent operational management put NetApp in a position of strength as we scale our Public Cloud services while continuing to drive growth in our Hybrid Cloud solutions.”

[0000950170-22-011019:8k_2_02:14]
Fourth quarter of fiscal year 2022 financial results

[0000950170-22-011019:8k_2_02:15]
•
Net revenues: $1.68 billion, compared to $1.56 billion in the fourth quarter of fiscal year 2021

[0000950170-22-011019:8k_2_02:16]
o
Hybrid Cloud segment revenue: $1.56 billion, compared to $1.49 billion in the fourth quarter of fiscal year 2021

[0000950170-22-011019:8k_2_02:17]
o
Public Cloud segment revenue: $120 million, compared to $66 million in the fourth quarter of fiscal year 2021

[0000950170-22-011019:8k_2_02:18]
•
Net income: GAAP net income of $259 million, compared to $334 million in the fourth quarter of fiscal year 2021; non-GAAP net income4 of $324 million, compared to $268 million in the fourth quarter of fiscal year 2021

[0000950170-22-011019:8k_2_02:19]
•
Earnings per share: GAAP net income per share5 of $1.14 compared to $1.46 in the fourth quarter of fiscal year 2021; non-GAAP net income per share of $1.42, compared to $1.17 in the fourth quarter of fiscal year 2021

[0000950170-22-011019:8k_2_02:20]
•
Cash, cash equivalents and investments: $4.13 billion at the end of the fourth quarter of fiscal year 2022

[0000950170-22-011019:8k_2_02:21]
•
Cash provided by operations: $411 million, compared to $559 million in the fourth quarter of fiscal year 2021

[0000950170-22-011019:8k_2_02:22]
•
Share repurchase and dividends: Returned $361 million to shareholders through share repurchases and cash dividends

[0000950170-22-011019:8k_2_02:23]
Fiscal year 2022 financial results

[0000950170-22-011019:8k_2_02:24]
•
Net revenues: $6.32 billion, compared to $5.74 billion in fiscal year 2021

[0000950170-22-011019:8k_2_02:25]
•
Hybrid Cloud segment revenue: $5.92 billion, compared to $5.55 billion in the fourth quarter of fiscal year 2021

[0000950170-22-011019:8k_2_02:26]
•
Public Cloud segment revenue: $396 million, compared to $199 million in the fourth quarter of fiscal year 2021

[0000950170-22-011019:8k_2_02:27]
•
Net income: GAAP net income of $937 million, compared to $730 million in fiscal year 2021; non-GAAP net income of $1.21 billion, compared to $917 million in fiscal year 2021

[0000950170-22-011019:8k_2_02:28]
•
Earnings per share: GAAP net income per share of $4.09 compared to $3.23 in fiscal year 2021; non-GAAP net income per share of $5.28, compared to $4.06 in fiscal year 2021

[0000950170-22-011019:8k_2_02:29]
•
Cash provided by operations: $1.21 billion compared to $1.33 billion in fiscal year 2021

[0000950170-22-011019:8k_2_02:30]
•
Share repurchase and dividends: Returned $1.05 billion to shareholders through share repurchases and cash dividends

[0000950170-22-011019:8k_2_02:31]
First quarter of fiscal year 2023 financial outlook

[0000950170-22-011019:8k_2_02:32]
The Company provided the following financial guidance for the first quarter of fiscal year 2023:

[0000950170-22-011019:8k_2_02:33]
| Net revenues are expected to be in the range of: | $1.475 billion to $1.625 billion |
|  | GAAP | Non-GAAP |
| Earnings per share is expected to be in the range of: | $0.72 - $0.82 | $1.05 - $1.15 |

[0000950170-22-011019:8k_2_02:34]
Full fiscal year 2023 financial outlook

[0000950170-22-011019:8k_2_02:35]
The Company provided the following financial guidance for the full fiscal year 2023:

[0000950170-22-011019:8k_2_02:36]
| Net revenues are expected to grow in the range of: | 6% to 8% |
| Public Cloud ARR is expected to exit the fiscal year in the range of: | $780 million to $820 million |
|  | GAAP | Non-GAAP |
| Consolidated gross margins are expected to be in the range of: | 65% - 66% | 66% - 67% |
| Operating margins are expected to be in the range of: | 18% - 19% | 23% - 24% |
| Effective tax rate is expected to be in the range of | 24% - 25% | 21% - 22% |
| Earnings per share is expected to be in the range of: | $3.96 - $4.16 | $5.40 - $5.60 |

[0000950170-22-011019:8k_2_02:37]
Dividend

[0000950170-22-011019:8k_2_02:38]
The next cash dividend of $0.50 per share is to be paid on July 27, 2022, to shareholders of record as of the close of business on July 8, 2022.

[0000950170-22-011019:8k_2_02:39]
Fourth quarter of fiscal year 2022 business highlights

[0000950170-22-011019:8k_2_02:40]
Leading product innovation

[0000950170-22-011019:8k_2_02:41]
•
NetApp acquired Fylamynt, a CloudOps automation technology company that enables customers to build, run, manage, and analyze workflows securely in any cloud with little or no code.

[0000950170-22-011019:8k_2_02:42]
•
NetApp announced the intent to acquire Instaclustr, the industry-leading platform for deploying and managing open-source data and workflow applications as a service. The Instaclustr acquisition closed on May 20, 2022.

[0000950170-22-011019:8k_2_02:43]
•
NetApp announced the general availability of Ocean for Apache Spark on AWS.

[0000950170-22-011019:8k_2_02:44]
•
NetApp introduced NetApp Cloud Volumes Edge Cache software as a service with intelligent caching and global file locking, helping customers reduce risk and improve performance of centrally managed files.

[0000950170-22-011019:8k_2_02:45]
•
NetApp introduced NetApp Cloud Manager Digital Wallet service, which delivers unified license and entitlement management to data storage and data services resources.

[0000950170-22-011019:8k_2_02:46]
•
NetApp announced updates to NetApp Cloud Insights, leveraging artificial intelligence and machine learning to provide dynamic observability of changing conditions that are out of the normal parameters, and to recommend remediation actions to prevent performance, availability, or breach issues.

[0000950170-22-011019:8k_2_02:47]
•
NetApp announced that Spot Ocean by NetApp supports Kubernetes pod topology spread constraints, helping users meet different business needs such as high availability, low latency, and controlled saturation of applications.

[0000950170-22-011019:8k_2_02:48]
•
NetApp announced that Spot by NetApp is available in Azure Marketplace.

[0000950170-22-011019:8k_2_02:49]
•
Spot by NetApp introduced the first Spot Storage optimization capabilities, available to AWS customers in the Spot console, enabling immediate, actionable insights to reduce costs and improve efficiency for all storage components across the customer’s AWS account.

[0000950170-22-011019:8k_2_02:50]
•
NetApp announced a new update to Spot Ocean to automate cloud infrastructure for containers with a new “Revert to Lower-Cost Node” optimization process.

[0000950170-22-011019:8k_2_02:51]
•
NetApp launched a new User Management System for Spot with new capabilities to better manage and control access to the cloud.

[0000950170-22-011019:8k_2_02:52]
•
NetApp and Cisco introduced FlexPod™ XCS, providing one automated platform for modern applications, data, and hybrid cloud services.

[0000950170-22-011019:8k_2_02:53]
•
NetApp introduced StorageGRID™ 11.6 with Google Cloud integration, security and compliance enhancements, and faster performance for analytical workloads.

[0000950170-22-011019:8k_2_02:54]
NetApp Awards and Recognition

[0000950170-22-011019:8k_2_02:55]
•
NetApp was named as one of Newsweek’s most trustworthy companies in 20226.

[0000950170-22-011019:8k_2_02:56]
•
NetApp CloudCheckr™ was named by GigaOm as a leader and outperformer in cloud management7.

[0000950170-22-011019:8k_2_02:57]
•
NetApp AI was named a winner of the Business Intelligence Group’s Artificial Intelligence Excellence Awards8.

[0000950170-22-011019:8k_2_02:58]
•
NetApp was named a winner of the Business intelligence Group’s Excellence in Customer Service Award9.

[0000950170-22-011019:8k_2_02:59]
•
NetApp was included in CRN’s Storage 100 list10, representing industry leaders offering traditional on-premises and cloud deployments for cutting-edge solutions.

[0000950170-22-011019:8k_2_02:60]
Webcast and conference call information

[0000950170-22-011019:8k_2_02:61]
NetApp will host a conference call to discuss these results today at 2:30 p.m. Pacific Time. To access the live webcast of this event, go to the NetApp Investor Relations website at investors.netapp.com. In addition, this press release, historical supplemental data tables, and other information related to the call will be posted on the Investor Relations website. An audio replay will be available on the website after 4:30 p.m. Pacific Time today.

[0000950170-22-011019:8k_2_02:62]
###

[0000950170-22-011019:8k_2_02:63]
NetApp, the NetApp logo, and the marks listed at http://www.netapp.com/TM are trademarks of NetApp, Inc. All other marks are the property of their respective owners.

[0000950170-22-011019:8k_2_02:64]
Footnotes

[0000950170-22-011019:8k_2_02:65]
1Refer to the NetApp Usage of Non-GAAP Financial Information section below for an explanation of billings.

[0000950170-22-011019:8k_2_02:66]
2Public Cloud annualized revenue run rate (ARR) is calculated as the annualized value of all Public Cloud customer commitments with the assumption that any commitment expiring during the next 12 months will be renewed with its existing terms.

[0000950170-22-011019:8k_2_02:67]
3All-flash array annualized net revenue run rate is determined by products and services revenue for the current quarter, multiplied by 4.

[0000950170-22-011019:8k_2_02:68]
4Non-GAAP net income excludes, when applicable, (a) amortization of intangible assets, (b) stock-based compensation expenses, (c) litigation settlements, (d) acquisition-related expenses, (e) restructuring charges, (f) asset impairments, (g) gains/losses on the sale or derecognition of assets, (h) gains/losses on the sale of investments in equity securities, (i) debt extinguishment costs, and (j) our GAAP tax provision, but includes a non-GAAP tax provision based upon our projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. NetApp makes additional adjustments to the non-GAAP tax provision for certain tax matters as described below. A detailed reconciliation of our non-GAAP to GAAP results can be found at http://investors.netapp.com. NetApp’s management uses these non-GAAP measures in making operating decisions because it believes that the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance.

[0000950170-22-011019:8k_2_02:69]
5GAAP net income per share and non-GAAP net income per share are calculated using the diluted number of shares.

[0000950170-22-011019:8k_2_02:70]
6Newsweek, “America’s Most Trustworthy Companies, 2022,” Nancy Cooper, May 9, 2022. America's Most Trustworthy Companies 2022 - All Winners (newsweek.com).

[0000950170-22-011019:8k_2_02:71]
7GigaOm, “GigaOm Radar for Cloud Platforms for Hybrid Integration and Automation,” Enrico Signoretti, Max Mortillaro, Arjan Timmerman, April 4, 2022. GigaOm Radar for High-Performance Object Storage - Gigaom.

[0000950170-22-011019:8k_2_02:72]
8Business Intelligence Group, “Winners of the 2022 Excellence in Customer Service Awards,” April 12, 2022. Here are the 85 Names Leading the Way in Customer Service in 2022 — Business Intelligence Group (bintelligence.com).

[0000950170-22-011019:8k_2_02:73]
9Business Intelligence Group, “Honoring Achievements in Artificial Intelligence,” March 22, 2022. 6 People, 26 Companies, and 65 Products Awarded for Excellence in Artificial Intelligence — Business Intelligence Group (bintelligence.com).

[0000950170-22-011019:8k_2_02:74]
10CRN’s Storage 100 list, “2022 Storage 100: Who’s Got Your Backup, 2022,” Joseph F. Kovar, April 11, 2022. 2022 Storage 100: Who’s Got Your Backup? (crn.com).

[0000950170-22-011019:8k_2_02:75]
NetApp usage of non-GAAP financial information

[0000950170-22-011019:8k_2_02:76]
To supplement NetApp’s condensed consolidated financial statement information presented in accordance with generally accepted accounting principles in the United States (GAAP), NetApp provides investors with

[0000950170-22-011019:8k_2_02:77]
certain non-GAAP measures, including, but not limited to, historical non-GAAP operating results, non-GAAP net income, non-GAAP effective tax rate, free cash flow, billings, and historical and projected non-GAAP earnings per diluted share. NetApp also presents the hardware and software components of our GAAP product revenues. Because our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation, hardware and software components of our product revenues are considered non-GAAP measures. The hardware and software components of our product revenues are derived from an estimated fair value allocation of the transaction price of our contracts with customers, down to the level of the product hardware and software components. This allocation is primarily based on the contractual prices at which NetApp has historically billed customers for such respective components.

[0000950170-22-011019:8k_2_02:78]
NetApp believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP earnings per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations.

[0000950170-22-011019:8k_2_02:79]
NetApp believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock. As free cash flow is not a measure of liquidity calculated in accordance with GAAP, free cash flow should be considered in addition to, but not as a substitute for, the analysis provided in the statement of cash flows.

[0000950170-22-011019:8k_2_02:80]
NetApp believes that the presentation of the software and hardware components of our product revenues is meaningful to investors and management as it illustrates the significance of the Company’s software and provides improved visibility into the value created by our software innovation and R&D investment.

[0000950170-22-011019:8k_2_02:81]
NetApp approximates billings by adding net revenues as reported on our Condensed Consolidated Statements of Operations for the period to the change in total deferred revenue and financed unearned services revenue as reported on our Condensed Consolidated Statements of Cash Flows for the same period. Billings is a performance measure that NetApp believes provides useful information to management and investors because it approximates the amounts under purchase orders received by us during a given period that have been billed.

[0000950170-22-011019:8k_2_02:82]
NetApp’s management uses these non-GAAP measures in making operating decisions because it believes the measurements provide meaningful supplemental information regarding NetApp’s ongoing operational performance. These non-GAAP financial measures are used to: (1) measure company performance against

[0000950170-22-011019:8k_2_02:83]
historical results, (2) facilitate comparisons to our competitors’ operating results and (3) allow greater transparency with respect to information used by management in financial and operational decision making.

[0000950170-22-011019:8k_2_02:84]
NetApp excludes the following items from its non-GAAP measures when applicable:

[0000950170-22-011019:8k_2_02:85]
A. Amortization of intangible assets. NetApp records amortization of intangible assets that were acquired in connection with its business combinations. The amortization of intangible assets varies depending on the level of acquisition activity. Management finds it useful to exclude these charges to assess the appropriate level of various operating expenses to assist in budgeting, planning and forecasting future periods and in measuring operational performance.

[0000950170-22-011019:8k_2_02:86]
B. Stock-based compensation expenses. NetApp excludes stock-based compensation expenses from its non-GAAP measures primarily because the amount can fluctuate based on variables unrelated to the performance of the underlying business. While management views stock-based compensation as a key element of our employee retention and long-term incentives, we do not view it as an expense to be used in evaluating operational performance in any given period.

[0000950170-22-011019:8k_2_02:87]
C. Litigation settlements. NetApp may periodically incur charges or benefits related to litigation settlements. NetApp excludes these charges and benefits, when significant, because it does not believe they are reflective of ongoing business and operating results.

[0000950170-22-011019:8k_2_02:88]
D. Acquisition-related expenses. NetApp excludes acquisition-related expenses, including (a) due diligence, legal and other one-time integration charges and (b) write down of assets acquired that NetApp does not intend to use in its ongoing business, from its non-GAAP measures, primarily because they are not related to our ongoing business or cost base and, therefore, are less useful for future planning and forecasting.

[0000950170-22-011019:8k_2_02:89]
E. Restructuring charges. These charges consist of restructuring charges that are incurred based on the particular facts and circumstances of restructuring decisions, including employment and contractual settlement terms, and other related charges, and can vary in size and frequency. We therefore exclude them in our assessment of operational performance.

[0000950170-22-011019:8k_2_02:90]
F. Asset impairments. These are non-cash charges to write down assets when there is an indication that the asset has become impaired. Management finds it useful to exclude these non-cash charges due to the unpredictability of these events in its assessment of operational performance.

[0000950170-22-011019:8k_2_02:91]
G. Gains/losses on the sale or derecognition of assets. These are gains/losses from the sale of our properties and other transactions in which we transfer control of assets to a fourth party. Management believes that these

[0000950170-22-011019:8k_2_02:92]
transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-22-011019:8k_2_02:93]
H. Gains/losses on the sale of investments in equity securities. These are gains/losses from the sale of our investment in certain equity securities. Typically, such investments are sold as a result of a change in control of the underlying businesses. Management believes that these transactions do not reflect the results of our underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-22-011019:8k_2_02:94]
I. Debt extinguishment costs. NetApp excludes certain non-recurring expenses incurred as a result of the early extinguishment of debt. Management believes such nonrecurring costs do not reflect the results of its underlying, on-going business and, therefore, are less useful for future planning and forecasting.

[0000950170-22-011019:8k_2_02:95]
J. Income tax adjustments. NetApp’s non-GAAP tax provision is based upon a projected annual non-GAAP effective tax rate for the first three quarters of the fiscal year and an actual non-GAAP tax provision for the fourth quarter of the fiscal year. The non-GAAP tax provision also excludes, when applicable, (a) tax charges or benefits in the current period that relate to one or more prior fiscal periods that are a result of events such as changes in tax legislation, authoritative guidance, income tax audit settlements, statute lapses and/or court decisions, (b) tax charges or benefits that are attributable to unusual or non-recurring book and/or tax accounting method changes, (c) tax charges that are a result of a non-routine foreign cash repatriation, (d) tax charges or benefits that are a result of infrequent restructuring of the Company’s tax structure, (e) tax charges or benefits that are a result of a change in valuation allowance, and (f) tax charges resulting from the integration of intellectual property from acquisitions. Management believes that the use of non-GAAP tax provisions provides a more meaningful measure of the Company’s operational performance.

[0000950170-22-011019:8k_2_02:96]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with GAAP, and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. NetApp believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with the Company’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures. NetApp management compensates for these limitations by analyzing current and projected results on a GAAP basis as well as a non-GAAP basis. The presentation of non-GAAP financial information is not meant to be considered in isolation or as a substitute for the directly comparable financial measures prepared in accordance with generally accepted accounting principles in the United States. The non-GAAP financial measures are meant to supplement, and be viewed in conjunction with, GAAP financial measures.

[0000950170-22-011019:8k_2_02:97]
About NetApp

[0000950170-22-011019:8k_2_02:98]
In a world full of generalists, NetApp is a specialist. We’re focused on one thing, helping your business get the most out of your data. NetApp brings the enterprise-grade data services you rely on into the cloud, and the simple flexibility of cloud into the data center. Our industry-leading solutions work across diverse customer environments and the world’s biggest public clouds. As a cloud-led, data-centric software company, only NetApp can help build your unique data fabric, simplify and connect your cloud, and securely deliver the right data, services, and applications to the right people—anytime, anywhere.

[0000950170-22-011019:8k_2_02:99]
NETAPP, INC.

[0000950170-22-011019:8k_2_02:100]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-22-011019:8k_2_02:101]
(In millions)

[0000950170-22-011019:8k_2_02:102]
(Unaudited)

[0000950170-22-011019:8k_2_02:103]
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash, cash equivalents and investments |  | $ | 4,134 |  |  | $ | 4,596 |  |
| Accounts receivable |  |  | 1,230 |  |  |  | 945 |  |
| Inventories |  |  | 204 |  |  |  | 114 |  |
| Other current assets |  |  | 377 |  |  |  | 346 |  |
| Total current assets |  |  | 5,945 |  |  |  | 6,001 |  |
| Property and equipment, net |  |  | 602 |  |  |  | 525 |  |
| Goodwill and purchased intangible assets, net |  |  | 2,488 |  |  |  | 2,140 |  |
| Other non-current assets |  |  | 991 |  |  |  | 694 |  |
| Total assets |  | $ | 10,026 |  |  | $ | 9,360 |  |
| LIABILITIES AND STOCKHOLDERS' EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 607 |  |  | $ | 420 |  |
| Accrued expenses |  |  | 925 |  |  |  | 970 |  |
| Current portion of long-term debt |  |  | 250 |  |  |  | — |  |
| Short-term deferred revenue and financed unearned services revenue |  |  | 2,171 |  |  |  | 2,062 |  |
| Total current liabilities |  |  | 3,953 |  |  |  | 3,452 |  |
| Long-term debt |  |  | 2,386 |  |  |  | 2,632 |  |
| Other long-term liabilities |  |  | 788 |  |  |  | 650 |  |
| Long-term deferred revenue and financed unearned services revenue |  |  | 2,061 |  |  |  | 1,941 |  |
| Total liabilities |  |  | 9,188 |  |  |  | 8,675 |  |
| Stockholders' equity |  |  | 838 |  |  |  | 685 |  |
| Total liabilities and stockholders' equity |  | $ | 10,026 |  |  | $ | 9,360 |  |

[0000950170-22-011019:8k_2_02:104]
NETAPP, INC.

[0000950170-22-011019:8k_2_02:105]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-22-011019:8k_2_02:106]
(In millions, except per share amounts)

[0000950170-22-011019:8k_2_02:107]
(Unaudited)

[0000950170-22-011019:8k_2_02:108]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 894 |  |  | $ | 840 |  |  | $ | 3,284 |  |  | $ | 2,991 |  |
| Services |  |  | 786 |  |  |  | 715 |  |  |  | 3,034 |  |  |  | 2,753 |  |
| Net revenues |  |  | 1,680 |  |  |  | 1,555 |  |  |  | 6,318 |  |  |  | 5,744 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of product |  |  | 446 |  |  |  | 387 |  |  |  | 1,554 |  |  |  | 1,432 |  |
| Cost of services |  |  | 145 |  |  |  | 133 |  |  |  | 544 |  |  |  | 497 |  |
| Total cost of revenues |  |  | 591 |  |  |  | 520 |  |  |  | 2,098 |  |  |  | 1,929 |  |
| Gross profit |  |  | 1,089 |  |  |  | 1,035 |  |  |  | 4,220 |  |  |  | 3,815 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  |  | 480 |  |  |  | 447 |  |  |  | 1,857 |  |  |  | 1,744 |  |
| Research and development |  |  | 235 |  |  |  | 221 |  |  |  | 881 |  |  |  | 881 |  |
| General and administrative |  |  | 72 |  |  |  | 66 |  |  |  | 279 |  |  |  | 257 |  |
| Restructuring charges |  |  | 4 |  |  |  | — |  |  |  | 33 |  |  |  | 42 |  |
| Acquisition-related expense |  |  | 5 |  |  |  | 2 |  |  |  | 13 |  |  |  | 16 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (156 | ) |  |  | — |  |  |  | (156 | ) |
| Total operating expenses |  |  | 796 |  |  |  | 580 |  |  |  | 3,063 |  |  |  | 2,784 |  |
| Income from operations |  |  | 293 |  |  |  | 455 |  |  |  | 1,157 |  |  |  | 1,031 |  |
| Other expense, net |  |  | (21 | ) |  |  | (19 | ) |  |  | (62 | ) |  |  | (69 | ) |
| Income before income taxes |  |  | 272 |  |  |  | 436 |  |  |  | 1,095 |  |  |  | 962 |  |
| Provision for income taxes |  |  | 13 |  |  |  | 102 |  |  |  | 158 |  |  |  | 232 |  |
| Net income |  | $ | 259 |  |  | $ | 334 |  |  | $ | 937 |  |  | $ | 730 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.17 |  |  | $ | 1.50 |  |  | $ | 4.20 |  |  | $ | 3.29 |  |
| Diluted |  | $ | 1.14 |  |  | $ | 1.46 |  |  | $ | 4.09 |  |  | $ | 3.23 |  |
| Shares used in net income per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 222 |  |  |  | 222 |  |  |  | 223 |  |  |  | 222 |  |
| Diluted |  |  | 228 |  |  |  | 229 |  |  |  | 229 |  |  |  | 226 |  |

[0000950170-22-011019:8k_2_02:109]
NETAPP, INC.

[0000950170-22-011019:8k_2_02:110]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-22-011019:8k_2_02:111]
(In millions)

[0000950170-22-011019:8k_2_02:112]
(Unaudited)

[0000950170-22-011019:8k_2_02:113]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | April 29, 2022 |  |  | April 30, 2021 |  |  | April 29, 2022 |  |  | April 30, 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 259 |  |  | $ | 334 |  |  | $ | 937 |  |  | $ | 730 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 51 |  |  |  | 48 |  |  |  | 194 |  |  |  | 207 |  |
| Non-cash operating lease cost |  |  | 15 |  |  |  | 14 |  |  |  | 55 |  |  |  | 52 |  |
| Stock-based compensation |  |  | 66 |  |  |  | 48 |  |  |  | 245 |  |  |  | 197 |  |
| Deferred income taxes |  |  | (78 | ) |  |  | (5 | ) |  |  | (144 | ) |  |  | (6 | ) |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | (156 | ) |  |  | — |  |  |  | (156 | ) |
| Other items, net |  |  | (19 | ) |  |  | (11 | ) |  |  | (54 | ) |  |  | 24 |  |
| Changes in assets and liabilities, net of acquisitions of businesses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (450 | ) |  |  | (146 | ) |  |  | (313 | ) |  |  | 62 |  |
| Inventories |  |  | (37 | ) |  |  | (8 | ) |  |  | (90 | ) |  |  | 31 |  |
| Accounts payable |  |  | 171 |  |  |  | 81 |  |  |  | 181 |  |  |  | (11 | ) |
| Accrued expenses |  |  | 96 |  |  |  | 195 |  |  |  | (111 | ) |  |  | 134 |  |
| Deferred revenue and financed unearned services revenue |  |  | 338 |  |  |  | 183 |  |  |  | 384 |  |  |  | 193 |  |
| Long-term taxes payable |  |  | 21 |  |  |  | (6 | ) |  |  | (45 | ) |  |  | (57 | ) |
| Changes in other operating assets and liabilities, net |  |  | (22 | ) |  |  | (12 | ) |  |  | (28 | ) |  |  | (67 | ) |
| Net cash provided by operating activities |  |  | 411 |  |  |  | 559 |  |  |  | 1,211 |  |  |  | 1,333 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Redemptions of investments, net |  |  | 9 |  |  |  | 20 |  |  |  | 45 |  |  |  | 160 |  |
| Purchases of property and equipment |  |  | (68 | ) |  |  | (38 | ) |  |  | (226 | ) |  |  | (162 | ) |
| Proceeds from sale of properties |  |  | — |  |  |  | 365 |  |  |  | — |  |  |  | 371 |  |
| Acquisitions of businesses, net of cash acquired |  |  | (21 | ) |  |  | — |  |  |  | (380 | ) |  |  | (350 | ) |
| Other investing activities, net |  |  | — |  |  |  | (6 | ) |  |  | — |  |  |  | 2 |  |
| Net cash (used in) provided by investing activities |  |  | (80 | ) |  |  | 341 |  |  |  | (561 | ) |  |  | 21 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of common stock under employee stock award plans |  |  | — |  |  |  | 6 |  |  |  | 105 |  |  |  | 98 |  |
| Payments for taxes related to net share settlement of stock awards |  |  | (5 | ) |  |  | (4 | ) |  |  | (74 | ) |  |  | (42 | ) |
| Repurchase of common stock |  |  | (250 | ) |  |  | (75 | ) |  |  | (600 | ) |  |  | (125 | ) |
| Repayments of commercial paper notes, original maturities of three months or less, net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (420 | ) |
| Issuances of debt, net of issuance costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2,057 |  |
| Repayments and extinguishment of debt |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (689 | ) |
| Dividends paid |  |  | (111 | ) |  |  | (106 | ) |  |  | (446 | ) |  |  | (427 | ) |
| Other financing activities, net |  |  | — |  |  |  | (1 | ) |  |  | (2 | ) |  |  | (8 | ) |
| Net cash (used in) provided by financing activities |  |  | (366 | ) |  |  | (180 | ) |  |  | (1,017 | ) |  |  | 444 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  | (23 | ) |  |  | 1 |  |  |  | (49 | ) |  |  | 71 |  |
| Net change in cash, cash equivalents and restricted cash |  |  | (58 | ) |  |  | 721 |  |  |  | (416 | ) |  |  | 1,869 |  |
| Cash, cash equivalents and restricted cash: |  |  |  |  |  |  |  |  |  |  |  |  |
| Beginning of period |  |  | 4,177 |  |  |  | 3,814 |  |  |  | 4,535 |  |  |  | 2,666 |  |
| End of period |  | $ | 4,119 |  |  | $ | 4,535 |  |  | $ | 4,119 |  |  | $ | 4,535 |  |

[0000950170-22-011019:8k_2_02:114]
| NETAPP, INC. |  |
| SUPPLEMENTAL DATA |  |
| (In millions except net income per share, percentages, DSO, DPO and Inventory Turns) |  |

[0000950170-22-011019:8k_2_02:115]
| (Unaudited) |  |
| In the first quarter of fiscal year 2022, the Company introduced two segments for financial reporting purposes: Hybrid Cloud and Public Cloud. Prior period disclosures have been revised for comparability. |  |
| Revenues by Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| Product |  | $ | 894 |  |  | $ | 846 |  |  | $ | 840 |  |  | $ | 3,284 |  |  | $ | 2,991 |  |
| Support |  |  | 590 |  |  |  | 586 |  |  |  | 576 |  |  |  | 2,344 |  |  |  | 2,277 |  |
| Professional and Other Services |  |  | 76 |  |  |  | 72 |  |  |  | 73 |  |  |  | 294 |  |  |  | 277 |  |
| Hybrid Cloud Segment Net Revenues |  |  | 1,560 |  |  |  | 1,504 |  |  |  | 1,489 |  |  |  | 5,922 |  |  |  | 5,545 |  |
| Public Cloud Segment Net Revenues |  |  | 120 |  |  |  | 110 |  |  |  | 66 |  |  |  | 396 |  |  |  | 199 |  |
| Net Revenues |  | $ | 1,680 |  |  | $ | 1,614 |  |  | $ | 1,555 |  |  | $ | 6,318 |  |  | $ | 5,744 |  |
| Gross Profit by Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| Product |  | $ | 452 |  |  | $ | 442 |  |  | $ | 456 |  |  | $ | 1,743 |  |  | $ | 1,589 |  |
| Support |  |  | 547 |  |  |  | 541 |  |  |  | 525 |  |  |  | 2,160 |  |  |  | 2,076 |  |
| Professional and Other Services |  |  | 22 |  |  |  | 26 |  |  |  | 18 |  |  |  | 89 |  |  |  | 71 |  |
| Hybrid Cloud Segment Gross Profit |  |  | 1,021 |  |  |  | 1,009 |  |  |  | 999 |  |  |  | 3,992 |  |  |  | 3,736 |  |
| Public Cloud Segment Gross Profit |  |  | 82 |  |  |  | 78 |  |  |  | 47 |  |  |  | 278 |  |  |  | 134 |  |
| Total Segments Gross Profit |  |  | 1,103 |  |  |  | 1,087 |  |  |  | 1,046 |  |  |  | 4,270 |  |  |  | 3,870 |  |
| Amortization of Intangible Assets |  |  | (10 | ) |  |  | (9 | ) |  |  | (7 | ) |  |  | (33 | ) |  |  | (41 | ) |
| Stock-based Compensation |  |  | (4 | ) |  |  | (5 | ) |  |  | (4 | ) |  |  | (17 | ) |  |  | (14 | ) |
| Unallocated Cost of Revenues |  |  | (14 | ) |  |  | (14 | ) |  |  | (11 | ) |  |  | (50 | ) |  |  | (55 | ) |
| Gross Profit |  | $ | 1,089 |  |  | $ | 1,073 |  |  | $ | 1,035 |  |  | $ | 4,220 |  |  | $ | 3,815 |  |
| Gross Margin by Segment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| Product |  |  | 50.6 | % |  |  | 52.2 | % |  |  | 54.3 | % |  |  | 53.1 | % |  |  | 53.1 | % |
| Support |  |  | 92.7 | % |  |  | 92.3 | % |  |  | 91.1 | % |  |  | 92.2 | % |  |  | 91.2 | % |
| Professional and Other Services |  |  | 28.9 | % |  |  | 36.1 | % |  |  | 24.7 | % |  |  | 30.3 | % |  |  | 25.6 | % |
| Hybrid Cloud Segment Gross Margin |  |  | 65.4 | % |  |  | 67.1 | % |  |  | 67.1 | % |  |  | 67.4 | % |  |  | 67.4 | % |
| Public Cloud Segment Gross Margin |  |  | 68.3 | % |  |  | 70.9 | % |  |  | 71.2 | % |  |  | 70.2 | % |  |  | 67.3 | % |
| Product Revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| Total |  | $ | 894 |  |  | $ | 846 |  |  | $ | 840 |  |  | $ | 3,284 |  |  | $ | 2,991 |  |
| Software* |  | $ | 530 |  |  | $ | 507 |  |  | $ | 480 |  |  | $ | 1,926 |  |  | $ | 1,636 |  |
| Hardware* |  | $ | 364 |  |  | $ | 339 |  |  | $ | 360 |  |  | $ | 1,358 |  |  | $ | 1,355 |  |
| Software and recurring support and public cloud revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| Product - Software |  | $ | 530 |  |  | $ | 507 |  |  | $ | 480 |  |  | $ | 1,926 |  |  | $ | 1,636 |  |
| Support |  |  | 590 |  |  |  | 586 |  |  |  | 576 |  |  |  | 2,344 |  |  |  | 2,277 |  |
| Public Cloud |  |  | 120 |  |  |  | 110 |  |  |  | 66 |  |  |  | 396 |  |  |  | 199 |  |
| Software and recurring support and public cloud revenue* |  | $ | 1,240 |  |  | $ | 1,203 |  |  | $ | 1,122 |  |  | $ | 4,666 |  |  | $ | 4,112 |  |
| Software and recurring support and public cloud revenue as a percentage of net revenues |  |  | 74 | % |  |  | 75 | % |  |  | 72 | % |  |  | 74 | % |  |  | 72 | % |

[0000950170-22-011019:8k_2_02:116]
| * Our revenue recognition policy under GAAP defines a configured storage system, inclusive of the operating system software essential to its functionality, as a single performance obligation. We have provided a breakdown of our GAAP product revenues into the software and hardware components, which are considered non-GAAP measures, to display the significance of software included in total product revenues. Software and recurring support and public cloud revenue is a non-GAAP measure because it includes the software component of our product revenues, but not the hardware component. |  |
| Geographic Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'22 |  |  | % of Q3 FY'22 |  |  | % of Q4 FY'21 |  |  | % of FY 2022 |  |  | % of FY 2021 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Americas |  |  | 54 | % |  |  | 56 | % |  |  | 53 | % |  |  | 55 | % |  |  | 54 | % |
| Americas Commercial |  |  | 45 | % |  |  | 47 | % |  |  | 44 | % |  |  | 45 | % |  |  | 43 | % |
| U.S. Public Sector |  |  | 9 | % |  |  | 9 | % |  |  | 9 | % |  |  | 10 | % |  |  | 11 | % |
| EMEA |  |  | 32 | % |  |  | 32 | % |  |  | 32 | % |  |  | 31 | % |  |  | 31 | % |
| Asia Pacific |  |  | 14 | % |  |  | 12 | % |  |  | 15 | % |  |  | 14 | % |  |  | 15 | % |
| Pathways Mix |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | % of Q4 FY'22 |  |  | % of Q3 FY'22 |  |  | % of Q4 FY'21 |  |  | % of FY 2022 |  |  | % of FY 2021 |  |
|  |  | Revenue |  |  | Revenue |  |  | Revenue |  |  | Revenue |  |  | Revenue |  |
| Direct |  |  | 24 | % |  |  | 21 | % |  |  | 23 | % |  |  | 23 | % |  |  | 23 | % |
| Indirect |  |  | 76 | % |  |  | 79 | % |  |  | 77 | % |  |  | 77 | % |  |  | 77 | % |
| Non-GAAP Income from Operations, Income before Income Taxes & Effective Tax Rate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| Non-GAAP Income from Operations |  | $ | 382 |  |  | $ | 404 |  |  | $ | 358 |  |  | $ | 1,496 |  |  | $ | 1,184 |  |
| % of Net Revenues |  |  | 22.7 | % |  |  | 25.0 | % |  |  | 23.0 | % |  |  | 23.7 | % |  |  | 20.6 | % |
| Non-GAAP Income before Income Taxes |  | $ | 361 |  |  | $ | 389 |  |  | $ | 339 |  |  | $ | 1,434 |  |  | $ | 1,123 |  |
| Non-GAAP Effective Tax Rate |  |  | 10.2 | % |  |  | 15.2 | % |  |  | 20.9 | % |  |  | 15.7 | % |  |  | 18.3 | % |
| Non-GAAP Net Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| Non-GAAP Net Income |  | $ | 324 |  |  | $ | 330 |  |  | $ | 268 |  |  | $ | 1,209 |  |  | $ | 917 |  |
| Non-GAAP Weighted Average Common Shares Outstanding, Diluted |  |  | 228 |  |  |  | 229 |  |  |  | 229 |  |  |  | 229 |  |  |  | 226 |  |
| Non-GAAP Net Income per Share, Diluted |  | $ | 1.42 |  |  | $ | 1.44 |  |  | $ | 1.17 |  |  | $ | 5.28 |  |  | $ | 4.06 |  |
| Select Balance Sheet Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  |  |  |  |  |  |
| Deferred Revenue and Financed Unearned Services Revenue |  | $ | 4,232 |  |  | $ | 3,969 |  |  | $ | 4,003 |  |  |  |  |  |  |  |
| DSO (days) |  |  | 67 |  |  |  | 45 |  |  |  | 55 |  |  |  |  |  |  |  |
| DPO (days) |  |  | 93 |  |  |  | 73 |  |  |  | 74 |  |  |  |  |  |  |  |
| Inventory Turns |  |  | 12 |  |  |  | 13 |  |  |  | 18 |  |  |  |  |  |  |  |
| Days sales outstanding (DSO) is defined as accounts receivable divided by net revenues, multiplied by the number of days in the quarter. |  |
| Days payables outstanding (DPO) is defined as accounts payable divided by cost of revenues, multiplied by the number of days in the quarter. |  |
| Inventory turns is defined as annualized cost of revenues divided by net inventories. |  |
| Select Cash Flow Statement Items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| Net Cash Provided by Operating Activities |  | $ | 411 |  |  | $ | 260 |  |  | $ | 559 |  |  | $ | 1,211 |  |  | $ | 1,333 |  |
| Purchases of Property and Equipment |  | $ | 68 |  |  | $ | 61 |  |  | $ | 38 |  |  | $ | 226 |  |  | $ | 162 |  |
| Free Cash Flow |  | $ | 343 |  |  | $ | 199 |  |  | $ | 521 |  |  | $ | 985 |  |  | $ | 1,171 |  |
| Free Cash Flow as % of Net Revenues |  |  | 20.4 | % |  |  | 12.3 | % |  |  | 33.5 | % |  |  | 15.6 | % |  |  | 20.4 | % |

[0000950170-22-011019:8k_2_02:117]
| Free cash flow is a non-GAAP measure and is defined as net cash provided by operating activities less purchases of property and equipment. |  |

[0000950170-22-011019:8k_2_02:118]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| NET INCOME |  | $ | 259 |  |  | $ | 252 |  |  | $ | 334 |  |  | $ | 937 |  |  | $ | 730 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 13 |  |  |  | 9 |  |  |  | 46 |  |  |  | 49 |  |
| Stock-based compensation |  |  | 66 |  |  |  | 64 |  |  |  | 48 |  |  |  | 245 |  |  |  | 197 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | 5 |  |
| Restructuring charges |  |  | 4 |  |  |  | — |  |  |  | — |  |  |  | 33 |  |  |  | 42 |  |
| Acquisition-related expense |  |  | 5 |  |  |  | 6 |  |  |  | 2 |  |  |  | 13 |  |  |  | 16 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | (156 | ) |  |  | — |  |  |  | (156 | ) |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (6 | ) |
| Debt extinguishment costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 14 |  |
| Income tax effects |  |  | (24 | ) |  |  | (5 | ) |  |  | 18 |  |  |  | (68 | ) |  |  | (20 | ) |
| Income tax expenses from integration of acquired companies |  |  | — |  |  |  | — |  |  |  | 13 |  |  |  | 1 |  |  |  | 46 |  |
| NON-GAAP NET INCOME |  | $ | 324 |  |  | $ | 330 |  |  | $ | 268 |  |  | $ | 1,209 |  |  | $ | 917 |  |
| COST OF REVENUES |  | $ | 591 |  |  | $ | 541 |  |  | $ | 520 |  |  | $ | 2,098 |  |  | $ | 1,929 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (9 | ) |  |  | (7 | ) |  |  | (33 | ) |  |  | (41 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (5 | ) |  |  | (4 | ) |  |  | (17 | ) |  |  | (14 | ) |
| NON-GAAP COST OF REVENUES |  | $ | 577 |  |  | $ | 527 |  |  | $ | 509 |  |  | $ | 2,048 |  |  | $ | 1,874 |  |
| COST OF PRODUCT REVENUES |  | $ | 446 |  |  | $ | 407 |  |  | $ | 387 |  |  | $ | 1,554 |  |  | $ | 1,432 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (2 | ) |  |  | (2 | ) |  |  | (9 | ) |  |  | (26 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |  |  | (4 | ) |  |  | (4 | ) |
| NON-GAAP COST OF PRODUCT REVENUES |  | $ | 442 |  |  | $ | 404 |  |  | $ | 384 |  |  | $ | 1,541 |  |  | $ | 1,402 |  |
| COST OF SERVICES REVENUES |  | $ | 145 |  |  | $ | 134 |  |  | $ | 133 |  |  | $ | 544 |  |  | $ | 497 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (7 | ) |  |  | (5 | ) |  |  | (24 | ) |  |  | (15 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (4 | ) |  |  | (3 | ) |  |  | (13 | ) |  |  | (10 | ) |
| NON-GAAP COST OF SERVICES REVENUES |  | $ | 135 |  |  | $ | 123 |  |  | $ | 125 |  |  | $ | 507 |  |  | $ | 472 |  |
| GROSS PROFIT |  | $ | 1,089 |  |  | $ | 1,073 |  |  | $ | 1,035 |  |  | $ | 4,220 |  |  | $ | 3,815 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 10 |  |  |  | 9 |  |  |  | 7 |  |  |  | 33 |  |  |  | 41 |  |
| Stock-based compensation |  |  | 4 |  |  |  | 5 |  |  |  | 4 |  |  |  | 17 |  |  |  | 14 |  |
| NON-GAAP GROSS PROFIT |  | $ | 1,103 |  |  | $ | 1,087 |  |  | $ | 1,046 |  |  | $ | 4,270 |  |  | $ | 3,870 |  |

[0000950170-22-011019:8k_2_02:119]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| SALES AND MARKETING EXPENSES |  | $ | 480 |  |  | $ | 461 |  |  | $ | 447 |  |  | $ | 1,857 |  |  | $ | 1,744 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (4 | ) |  |  | (4 | ) |  |  | (2 | ) |  |  | (13 | ) |  |  | (8 | ) |
| Stock-based compensation |  |  | (30 | ) |  |  | (30 | ) |  |  | (22 | ) |  |  | (115 | ) |  |  | (92 | ) |
| NON-GAAP SALES AND MARKETING EXPENSES |  | $ | 446 |  |  | $ | 427 |  |  | $ | 423 |  |  | $ | 1,729 |  |  | $ | 1,644 |  |
| RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 235 |  |  | $ | 220 |  |  | $ | 221 |  |  | $ | 881 |  |  | $ | 881 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (22 | ) |  |  | (19 | ) |  |  | (15 | ) |  |  | (75 | ) |  |  | (64 | ) |
| NON-GAAP RESEARCH AND DEVELOPMENT EXPENSES |  | $ | 213 |  |  | $ | 201 |  |  | $ | 206 |  |  | $ | 806 |  |  | $ | 817 |  |
| GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 72 |  |  | $ | 65 |  |  | $ | 66 |  |  | $ | 279 |  |  | $ | 257 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  | (10 | ) |  |  | (10 | ) |  |  | (7 | ) |  |  | (38 | ) |  |  | (27 | ) |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  | (5 | ) |
| NON-GAAP GENERAL AND ADMINISTRATIVE EXPENSES |  | $ | 62 |  |  | $ | 55 |  |  | $ | 59 |  |  | $ | 239 |  |  | $ | 225 |  |
| RESTRUCTURING CHARGES |  | $ | 4 |  |  | $ | — |  |  | $ | — |  |  | $ | 33 |  |  | $ | 42 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring charges |  |  | (4 | ) |  |  | — |  |  |  | — |  |  |  | (33 | ) |  |  | (42 | ) |
| NON-GAAP RESTRUCTURING CHARGES |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| ACQUISITION-RELATED EXPENSE |  | $ | 5 |  |  | $ | 6 |  |  | $ | 2 |  |  | $ | 13 |  |  | $ | 16 |  |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related expense |  |  | (5 | ) |  |  | (6 | ) |  |  | (2 | ) |  |  | (13 | ) |  |  | (16 | ) |
| NON-GAAP ACQUISITION-RELATED EXPENSE |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  |  | $ | — |  |  | $ | (156 | ) |  | $ | — |  |  | $ | (156 | ) |
| Adjustment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | 156 |  |  |  | — |  |  |  | 156 |  |
| NON-GAAP GAIN ON SALE OR DERECOGNITION OF ASSETS |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| OPERATING EXPENSES |  | $ | 796 |  |  | $ | 752 |  |  | $ | 580 |  |  | $ | 3,063 |  |  | $ | 2,784 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (4 | ) |  |  | (4 | ) |  |  | (2 | ) |  |  | (13 | ) |  |  | (8 | ) |
| Stock-based compensation |  |  | (62 | ) |  |  | (59 | ) |  |  | (44 | ) |  |  | (228 | ) |  |  | (183 | ) |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  | (5 | ) |
| Restructuring charges |  |  | (4 | ) |  |  | — |  |  |  | — |  |  |  | (33 | ) |  |  | (42 | ) |
| Acquisition-related expense |  |  | (5 | ) |  |  | (6 | ) |  |  | (2 | ) |  |  | (13 | ) |  |  | (16 | ) |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | 156 |  |  |  | — |  |  |  | 156 |  |
| NON-GAAP OPERATING EXPENSES |  | $ | 721 |  |  | $ | 683 |  |  | $ | 688 |  |  | $ | 2,774 |  |  | $ | 2,686 |  |

[0000950170-22-011019:8k_2_02:120]
| NETAPP, INC. |  |
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| INCOME STATEMENT INFORMATION |  |
| (In millions, except net income per share amounts) |  |

[0000950170-22-011019:8k_2_02:121]
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| INCOME FROM OPERATIONS |  | $ | 293 |  |  | $ | 321 |  |  | $ | 455 |  |  | $ | 1,157 |  |  | $ | 1,031 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 13 |  |  |  | 9 |  |  |  | 46 |  |  |  | 49 |  |
| Stock-based compensation |  |  | 66 |  |  |  | 64 |  |  |  | 48 |  |  |  | 245 |  |  |  | 197 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | 5 |  |
| Restructuring charges |  |  | 4 |  |  |  | — |  |  |  | — |  |  |  | 33 |  |  |  | 42 |  |
| Acquisition-related expense |  |  | 5 |  |  |  | 6 |  |  |  | 2 |  |  |  | 13 |  |  |  | 16 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | (156 | ) |  |  | — |  |  |  | (156 | ) |
| NON-GAAP INCOME FROM OPERATIONS |  | $ | 382 |  |  | $ | 404 |  |  | $ | 358 |  |  | $ | 1,496 |  |  | $ | 1,184 |  |
| OTHER EXPENSE, NET |  | $ | (21 | ) |  | $ | (15 | ) |  | $ | (19 | ) |  | $ | (62 | ) |  | $ | (69 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt extinguishment costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 14 |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (6 | ) |
| NON-GAAP OTHER EXPENSE, NET |  | $ | (21 | ) |  | $ | (15 | ) |  | $ | (19 | ) |  | $ | (62 | ) |  | $ | (61 | ) |
| INCOME BEFORE INCOME TAXES |  | $ | 272 |  |  | $ | 306 |  |  | $ | 436 |  |  | $ | 1,095 |  |  | $ | 962 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 14 |  |  |  | 13 |  |  |  | 9 |  |  |  | 46 |  |  |  | 49 |  |
| Stock-based compensation |  |  | 66 |  |  |  | 64 |  |  |  | 48 |  |  |  | 245 |  |  |  | 197 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | 5 |  |
| Restructuring charges |  |  | 4 |  |  |  | — |  |  |  | — |  |  |  | 33 |  |  |  | 42 |  |
| Acquisition-related expense |  |  | 5 |  |  |  | 6 |  |  |  | 2 |  |  |  | 13 |  |  |  | 16 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | (156 | ) |  |  | — |  |  |  | (156 | ) |
| Debt extinguishment costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 14 |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (6 | ) |
| NON-GAAP INCOME BEFORE INCOME TAXES |  | $ | 361 |  |  | $ | 389 |  |  | $ | 339 |  |  | $ | 1,434 |  |  | $ | 1,123 |  |
| PROVISION FOR INCOME TAXES |  | $ | 13 |  |  | $ | 54 |  |  | $ | 102 |  |  | $ | 158 |  |  | $ | 232 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 24 |  |  |  | 5 |  |  |  | (18 | ) |  |  | 68 |  |  |  | 20 |  |
| Income tax expenses from integration of acquired companies |  |  | — |  |  |  | — |  |  |  | (13 | ) |  |  | (1 | ) |  |  | (46 | ) |
| NON-GAAP PROVISION FOR INCOME TAXES |  | $ | 37 |  |  | $ | 59 |  |  | $ | 71 |  |  | $ | 225 |  |  | $ | 206 |  |
| NET INCOME PER SHARE |  | $ | 1.14 |  |  | $ | 1.10 |  |  | $ | 1.46 |  |  | $ | 4.09 |  |  | $ | 3.23 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | 0.06 |  |  |  | 0.06 |  |  |  | 0.04 |  |  |  | 0.20 |  |  |  | 0.22 |  |
| Stock-based compensation |  |  | 0.29 |  |  |  | 0.28 |  |  |  | 0.21 |  |  |  | 1.07 |  |  |  | 0.87 |  |
| Litigation settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.01 |  |  |  | 0.02 |  |
| Restructuring charges |  |  | 0.02 |  |  |  | — |  |  |  | — |  |  |  | 0.14 |  |  |  | 0.19 |  |
| Acquisition-related expense |  |  | 0.02 |  |  |  | 0.03 |  |  |  | 0.01 |  |  |  | 0.06 |  |  |  | 0.07 |  |
| Gain on sale or derecognition of assets |  |  | — |  |  |  | — |  |  |  | (0.68 | ) |  |  | — |  |  |  | (0.69 | ) |
| Debt extinguishment costs |  | — |  |  | — |  |  | — |  |  |  | — |  |  |  | 0.06 |  |
| Gain on sale of equity investment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.03 | ) |
| Income tax effects |  |  | (0.11 | ) |  |  | (0.02 | ) |  |  | 0.08 |  |  |  | (0.30 | ) |  |  | (0.09 | ) |
| Income tax expenses from integration of acquired companies |  |  | — |  |  |  | — |  |  |  | 0.06 |  |  |  | — |  |  |  | 0.20 |  |
| NON-GAAP NET INCOME PER SHARE |  | $ | 1.42 |  |  | $ | 1.44 |  |  | $ | 1.17 |  |  | $ | 5.28 |  |  | $ | 4.06 |  |

[0000950170-22-011019:8k_2_02:122]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| Gross margin-GAAP |  |  | 64.8 | % |  |  | 66.5 | % |  |  | 66.6 | % |  |  | 66.8 | % |  |  | 66.4 | % |
| Cost of revenues adjustments |  |  | 0.8 | % |  |  | 0.9 | % |  |  | 0.7 | % |  |  | 0.8 | % |  |  | 1.0 | % |
| Gross margin-Non-GAAP |  |  | 65.7 | % |  |  | 67.3 | % |  |  | 67.3 | % |  |  | 67.6 | % |  |  | 67.4 | % |
| GAAP cost of revenues |  | $ | 591 |  |  | $ | 541 |  |  | $ | 520 |  |  | $ | 2,098 |  |  | $ | 1,929 |  |
| Cost of revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (10 | ) |  |  | (9 | ) |  |  | (7 | ) |  |  | (33 | ) |  |  | (41 | ) |
| Stock-based compensation |  |  | (4 | ) |  |  | (5 | ) |  |  | (4 | ) |  |  | (17 | ) |  |  | (14 | ) |
| Non-GAAP cost of revenues |  | $ | 577 |  |  | $ | 527 |  |  | $ | 509 |  |  | $ | 2,048 |  |  | $ | 1,874 |  |
| Net revenues |  | $ | 1,680 |  |  | $ | 1,614 |  |  | $ | 1,555 |  |  | $ | 6,318 |  |  | $ | 5,744 |  |

[0000950170-22-011019:8k_2_02:123]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| PRODUCT GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| Product gross margin-GAAP |  |  | 50.1 | % |  |  | 51.9 | % |  |  | 53.9 | % |  |  | 52.7 | % |  |  | 52.1 | % |
| Cost of product revenues adjustments |  |  | 0.4 | % |  |  | 0.4 | % |  |  | 0.4 | % |  |  | 0.4 | % |  |  | 1.0 | % |
| Product gross margin-Non-GAAP |  |  | 50.6 | % |  |  | 52.2 | % |  |  | 54.3 | % |  |  | 53.1 | % |  |  | 53.1 | % |
| GAAP cost of product revenues |  | $ | 446 |  |  | $ | 407 |  |  | $ | 387 |  |  | $ | 1,554 |  |  | $ | 1,432 |  |
| Cost of product revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (3 | ) |  |  | (2 | ) |  |  | (2 | ) |  |  | (9 | ) |  |  | (26 | ) |
| Stock-based compensation |  |  | (1 | ) |  |  | (1 | ) |  |  | (1 | ) |  |  | (4 | ) |  |  | (4 | ) |
| Non-GAAP cost of product revenues |  | $ | 442 |  |  | $ | 404 |  |  | $ | 384 |  |  | $ | 1,541 |  |  | $ | 1,402 |  |
| Product revenues |  | $ | 894 |  |  | $ | 846 |  |  | $ | 840 |  |  | $ | 3,284 |  |  | $ | 2,991 |  |

[0000950170-22-011019:8k_2_02:124]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| SERVICES GROSS MARGIN |  |
| ($ in millions) |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| Services gross margin-GAAP |  |  | 81.6 | % |  |  | 82.6 | % |  |  | 81.4 | % |  |  | 82.1 | % |  |  | 81.9 | % |
| Cost of services revenues adjustments |  |  | 1.3 | % |  |  | 1.4 | % |  |  | 1.1 | % |  |  | 1.2 | % |  |  | 1.0 | % |
| Services gross margin-Non-GAAP |  |  | 82.8 | % |  |  | 84.0 | % |  |  | 82.5 | % |  |  | 83.3 | % |  |  | 82.9 | % |
| GAAP cost of services revenues |  | $ | 145 |  |  | $ | 134 |  |  | $ | 133 |  |  | $ | 544 |  |  | $ | 497 |  |
| Cost of services revenues adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets |  |  | (7 | ) |  |  | (7 | ) |  |  | (5 | ) |  |  | (24 | ) |  |  | (15 | ) |
| Stock-based compensation |  |  | (3 | ) |  |  | (4 | ) |  |  | (3 | ) |  |  | (13 | ) |  |  | (10 | ) |
| Non-GAAP cost of services revenues |  | $ | 135 |  |  | $ | 123 |  |  | $ | 125 |  |  | $ | 507 |  |  | $ | 472 |  |
| Services revenues |  | $ | 786 |  |  | $ | 768 |  |  | $ | 715 |  |  | $ | 3,034 |  |  | $ | 2,753 |  |

[0000950170-22-011019:8k_2_02:125]
| RECONCILIATION OF NON-GAAP TO GAAP |  |
| EFFECTIVE TAX RATE |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| GAAP effective tax rate |  |  | 4.8 | % |  |  | 17.6 | % |  |  | 23.4 | % |  |  | 14.4 | % |  |  | 24.1 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax effects |  |  | 5.5 | % |  |  | (2.5 | )% |  |  | 0.5 | % |  |  | 1.4 | % |  |  | (1.0 | )% |
| Income tax expenses from integration of acquired companies |  |  | — | % |  |  | — | % |  |  | (3.0 | )% |  |  | (0.1 | )% |  |  | (4.8 | )% |
| Non-GAAP effective tax rate |  |  | 10.2 | % |  |  | 15.2 | % |  |  | 20.9 | % |  |  | 15.7 | % |  |  | 18.3 | % |

[0000950170-22-011019:8k_2_02:126]
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |  |
| TO FREE CASH FLOW (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| Net cash provided by operating activities |  | $ | 411 |  |  | $ | 260 |  |  | $ | 559 |  |  | $ | 1,211 |  |  | $ | 1,333 |  |
| Purchases of property and equipment |  |  | (68 | ) |  |  | (61 | ) |  |  | (38 | ) |  |  | (226 | ) |  |  | (162 | ) |
| Free cash flow |  | $ | 343 |  |  | $ | 199 |  |  | $ | 521 |  |  | $ | 985 |  |  | $ | 1,171 |  |
| RECONCILIATION OF NET REVENUES |  |
| TO BILLINGS (NON-GAAP) |  |
| (In millions) |  |
|  |  | Q4'FY22 |  |  | Q3'FY22 |  |  | Q4'FY21 |  |  | FY2022 |  |  | FY2021 |  |
| Net revenues |  | $ | 1,680 |  |  | $ | 1,614 |  |  | $ | 1,555 |  |  | $ | 6,318 |  |  | $ | 5,744 |  |
| Change in deferred revenue and financed unearned services revenue* |  |  | 338 |  |  |  | 143 |  |  |  | 183 |  |  |  | 384 |  |  |  | 193 |  |
| Billings |  | $ | 2,018 |  |  | $ | 1,757 |  |  | $ | 1,738 |  |  | $ | 6,702 |  |  | $ | 5,937 |  |
| * As reported on our Condensed Consolidated Statements of Cash Flows |  |

[0000950170-22-011019:8k_2_02:127]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FIRST QUARTER FISCAL 2023 |
|  |  | First Quarter |
|  |  | Fiscal 2023 |
| Non-GAAP Guidance - Net Income Per Share |  | $1.05 - $1.15 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for the First Quarter Fiscal 2023: |  |  |
| Amortization of intangible assets |  | ($0.08) |
| Stock-based compensation expense |  | ($0.30) |
| Income tax effects |  | $0.05 |
| Total Adjustments |  | ($0.33) |
| GAAP Guidance - Net Income Per Share |  | $0.72 - $0.82 |

[0000950170-22-011019:8k_2_02:128]
Some items may not add or recalculate due to rounding.

[0000950170-22-011019:8k_2_02:129]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| FISCAL 2023 |
| (Unaudited) |
|  |  | Fiscal 2023 |
| Gross Margin - Non-GAAP Guidance |  | 66% - 67% |
| Adjustment: |  |  |
| Cost of revenues adjustments |  | (1)% |
| Gross Margin - GAAP Guidance |  | 65% - 66% |
|  |  | Fiscal 2023 |
| Operating Margin - Non-GAAP Guidance |  | 23% - 24% |
| Adjustments: |  |  |
| Amortization of intangible assets |  | (1)% |
| Stock-based compensation expense |  | (4)% |
| Operating Margin - GAAP Guidance |  | 18% - 19% |
|  |  | Fiscal 2023 |
| Effective Tax Rate - Non-GAAP Guidance |  | 21% - 22% |
| Adjustment: |  |  |
| Income tax effects |  | 3% |
| Effective Tax Rate - GAAP Guidance |  | 24% - 25% |

[0000950170-22-011019:8k_2_02:130]
Some items may not add or recalculate due to rounding.

[0000950170-22-011019:8k_2_02:131]
| NETAPP, INC. |
| RECONCILIATION OF NON-GAAP GUIDANCE TO GAAP |
| EXPRESSED AS EARNINGS PER SHARE |
| FISCAL 2023 |
|  |  | Fiscal 2023 |
| Non-GAAP Guidance - Net Income Per Share |  | $5.40 - $5.60 |
| Adjustments of Specific Items to Net Income |  |  |
| Per Share for Fiscal 2023: |  |  |
| Amortization of intangible assets |  | ($0.30) |
| Stock-based compensation expense |  | ($1.33) |
| Income tax effects |  | $0.19 |
| Total Adjustments |  | ($1.44) |
| GAAP Guidance - Net Income Per Share |  | $3.96 - $4.16 |

[0000950170-22-011019:8k_2_02:132]
Some items may not add or recalculate due to rounding.

[0000950170-22-011019:8k_2_02:133]
Contacts:

[0000950170-22-011019:8k_2_02:134]
(Press)

[0000950170-22-011019:8k_2_02:135]
Chris Drago

[0000950170-22-011019:8k_2_02:136]
1 831 900 8889

[0000950170-22-011019:8k_2_02:137]
chris.drago@netapp.com

[0000950170-22-011019:8k_2_02:138]
(Investors)

[0000950170-22-011019:8k_2_02:139]
Lance Berger

[0000950170-22-011019:8k_2_02:140]
1 408 822 6628

[0000950170-22-011019:8k_2_02:141]
lance.berger@netapp.com
